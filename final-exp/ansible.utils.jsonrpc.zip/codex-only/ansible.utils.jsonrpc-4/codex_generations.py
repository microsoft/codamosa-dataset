

# Generated at 2022-06-23 14:07:08.329078
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():

    class testclass(object):
        def test_method(self, *args, **kwargs):
            print("Inside test_method")

    testclass_obj = testclass()

    rpc_server = JsonRpcServer()

    # Call handle_request without registering class
    # test_method in JsonRpcServer
    test_request = """
    {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "test_method",
        "params": [
            "arg1",
            "arg2"
        ]
    }
    """
    response = rpc_server.handle_request(test_request)

# Generated at 2022-06-23 14:07:14.968327
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    sampleRequest = "{\"jsonrpc\":\"2.0\",\"method\":\"run\",\"params\":[[\"show ip bgp summ\"],{\"fail_on_prompts\":false,\"timeout\":60}],\"id\":70}"
    jsonRpcServerObject = JsonRpcServer()
    response = jsonRpcServerObject.handle_request(sampleRequest)
    print(response)


# Generated at 2022-06-23 14:07:17.017383
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc_server = JsonRpcServer()
    assert type(jsonrpc_server._objects) is set


# Generated at 2022-06-23 14:07:24.211358
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc = JsonRpcServer()
    rpc.register(rpc)

    # invalid_request test
    request = '{"method":"__init__"}'
    response = json.loads(rpc.handle_request(request))
    assert response['error']['code'] == -32600

    # method_not_found test
    request = '{"method":"abc"}'
    response = json.loads(rpc.handle_request(request))
    assert response['error']['code'] == -32601

    # internal_error test
    request = '{"method":"_handle_request"}'
    response = json.loads(rpc.handle_request(request))
    assert response['error']['code'] == -32603

    # internal_error test

# Generated at 2022-06-23 14:07:26.686849
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    x = JsonRpcServer()
    y = {}
    x.register(y)
    assert y in x._objects


# Generated at 2022-06-23 14:07:31.560216
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    js = JsonRpcServer()
    json_expected = '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": null}'
    json_received = js.parse_error()
    assert json_expected == json_received


# Generated at 2022-06-23 14:07:34.465958
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    # Create instance of JsonRpcServer class
    jsr = JsonRpcServer()

    # Call method invalid_request of class JsonRpcServer
    res = jsr.invalid_request()

    # Print result
    print(res)


# Generated at 2022-06-23 14:07:41.352346
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    id_temp = server._identifier
    response = server.invalid_request('data')
    assert response['id'] == id_temp
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32600
    assert response['error']['message'] == 'Invalid request'
    assert response['error']['data'] == 'data'

test_JsonRpcServer_invalid_request()

# Generated at 2022-06-23 14:07:44.600149
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.internal_error("Internal Error")

if __name__ == '__main__':
    test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:07:47.716412
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    error_response = json_rpc_server.method_not_found()
    assert error_response.get('error').get('code') == -32601


# Generated at 2022-06-23 14:07:51.455635
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_socket_ipc = JsonRpcServer()
    setattr(json_socket_ipc, '_identifier', 'test_identifier')
    assert json_socket_ipc.header() == {'jsonrpc': '2.0', 'id': 'test_identifier'}


# Generated at 2022-06-23 14:07:57.738088
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    instance = JsonRpcServer()
    setattr(instance, '_identifier', 'test')
    response = instance.parse_error('test')
    assert response['id'] == 'test'
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'
    assert response['error']['data'] == 'test'


# Generated at 2022-06-23 14:08:01.529520
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = "test_identifier"
    header_dict = json_rpc_server.header()
    assert header_dict['jsonrpc'] == '2.0'
    assert header_dict['id'] == "test_identifier"

# Generated at 2022-06-23 14:08:05.489761
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrpc = JsonRpcServer()
    response_error = jrpc.method_not_found()
    assert response_error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found'}}

test_JsonRpcServer_method_not_found()

# Generated at 2022-06-23 14:08:15.850427
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Method name and parameters
    request = json.dumps({'method':'rpc_system', 'params': [{'host':'127.0.0.1', 'port': 2023, 'username':'cisco', 'password':'cisco'}]})
    jrpc_server = JsonRpcServer()
    rpc_system = RpcSystem()
    jrpc_server.register(rpc_system)
    response = jrpc_server.handle_request(request)
    assert response == json.dumps({'jsonrpc': '2.0', 'id': None, 'result': '0', 'result_type': 'pickle'})

# RPC System class

# Generated at 2022-06-23 14:08:20.644650
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', "")
    assert server.error(code=0, message="") == '{"id": "", "jsonrpc": "2.0", "error": {"code": 0, "message": ""}}'
    assert server.error(code=0, message="", data='testdata') == '{"id": "", "jsonrpc": "2.0", "error": {"code": 0, "message": "", "data": "testdata"}}'
    delattr(server, '_identifier')


# Generated at 2022-06-23 14:08:23.647970
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    obj = AnsibleModule()
    server.register(obj)
    assert server._objects == set([obj])



# Generated at 2022-06-23 14:08:30.541879
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    a = JsonRpcServer()
    a._identifier = '1'
    if a.error(-32603, 'Internal error', 'data') != {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'data'}}:
        exit("bug test_JsonRpcServer_error")
    exit("success")

if __name__=="__main__":
    import sys
    sys.exit(test_JsonRpcServer_error())

# Generated at 2022-06-23 14:08:31.059406
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    pass

# Generated at 2022-06-23 14:08:35.128725
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    param = {'params': [[], {}],
             'id': 1439897750,
             'method': 'rpc.invalid_method'}
    try:
        response = JsonRpcServer().handle_request(json.dumps(param))
        response = json.loads(response)
        assert response['error']['code'] == -32600
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-23 14:08:45.783221
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig

    conn = Connection(module=basic)

    module_args = dict(
        username='ansible',
        password='ansible',
        host='localhost',
        provider=dict(
            network_os='junos',
            timeout=5,
        ),
    )

    provider = load_provider(module_args)

# Generated at 2022-06-23 14:08:51.690469
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert server.parse_error('test') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'test'}}


# Generated at 2022-06-23 14:09:00.584554
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # test_JsonRpcServer_handle_request: error_object_creation
    class MockJsonRpcServer(JsonRpcServer):
        pass
    mock_jsonrpc = MockJsonRpcServer()
    mock_jsonrpc.handle_request()
    expected_result = "{\"jsonrpc\": \"2.0\", \"error\": {\"code\": -32600, \
    \"message\": \"Invalid request\", \"data\": \"'' is not JSON serializable\"}, \
    \"id\": 'None'}"
    assert str(mock_jsonrpc.handle_request()) == expected_result
    # test_JsonRpcServer_handle_request: error_object_creation
    class MockJsonRpcServer(JsonRpcServer):
        pass
    mock_jsonrpc = MockJsonRpcServer()

# Generated at 2022-06-23 14:09:07.053986
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    response = server.error(-32603, 'Internal error', 'data')
    assert response == {
        'jsonrpc': '2.0',
        'id': 'test_identifier',
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': 'data'
        }
    }

# Generated at 2022-06-23 14:09:10.845362
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    error = JsonRpcServer().invalid_params()
    assert error['jsonrpc'] == '2.0'
    assert error['id'] == 1
    assert error['error']['code'] == -32602
    assert error['error']['message'] == 'Invalid params'

# Generated at 2022-06-23 14:09:13.797173
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    assert server.invalid_request() == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32600, 'message': 'Invalid request'}}

# Generated at 2022-06-23 14:09:21.433743
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    method_not_found = json_rpc_server.method_not_found()
    assert method_not_found['id'] == None
    assert method_not_found['error']['code'] == -32601
    assert method_not_found['error']['message'] == 'Method not found'
    assert method_not_found['error']['data'] == None

# Generated at 2022-06-23 14:09:26.037159
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    """Test method invalid_params of class JsonRpcServer"""
    
    # Create class instance
    test = JsonRpcServer()
    result = test.invalid_params()
    assert result == {"jsonrpc": "2.0", "id": None, "error": {"code": -32602, "message": "Invalid params"}}


# Generated at 2022-06-23 14:09:28.326860
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    return json_rpc_server.invalid_params("test")

# Generated at 2022-06-23 14:09:37.881798
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # case 1: Method not found
    json_rpc_server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "non_existing_method",
        "id": "1",
        "params": [1, 2, 3]
    }
    response = json_rpc_server.handle_request(json.dumps(request))
    assert json.loads(response) == json_rpc_server.method_not_found()

    # case 2: valid request
    class A:
        def existing_method(self, a, b, c):
            return 'valid-request'

    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(A())

# Generated at 2022-06-23 14:09:42.015562
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123456')
    expected = json.dumps({
        'id': 123456,
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': None
        },
        'jsonrpc': '2.0'
    })
    actual = server.invalid_request()
    assert expected == actual

# Generated at 2022-06-23 14:09:51.668583
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():

    server = JsonRpcServer()
    request = {
        'id': '1',
        'jsonrpc': '2.0',
        'method': 'unknown',
        'params': []
    }

    response = json.loads(server.handle_request(json.dumps(request)))

    expected = {
        'jsonrpc': '2.0',
        'id': '1',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None,
        }
    }

    assert response == expected


# Generated at 2022-06-23 14:09:54.050076
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    j = JsonRpcServer()
    j._identifier = 1
    assert json.loads(j.internal_error()) == {
        'jsonrpc': '2.0', 'id': 1,
        'error': {
            'code': -32603,
            'message': 'Internal error',
        },
    }


# Generated at 2022-06-23 14:09:57.912444
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = '123'
    expected = {'jsonrpc': '2.0', 'id': '123'}
    assert server.header() == expected


# Generated at 2022-06-23 14:10:02.140867
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', {'id':123})
    # import pdb; pdb.set_trace()
    result = server.header()
    assert result == {'jsonrpc': '2.0', 'id': {'id':123}}



# Generated at 2022-06-23 14:10:03.793484
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server

# Generated at 2022-06-23 14:10:09.096691
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    setattr(s, '_identifier', 1)
    d = s.error(302, 'hello world', 'data')
    assert d == {'id': 1, 'error': {'code': 302, 'message': 'hello world', 'data': 'data'}, 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:10:14.251055
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    s = JsonRpcServer()

    assert(s.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}')) == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'
    assert(s.handle_request('{"jsonrpc": "2.0", "method": "invalid", "params": ["hello"], "id": 1}')) == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-23 14:10:20.164626
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    """
    Test case for method header of class JsonRpcServer
    """
    # Arrange
    class TestJsonRpcServer(JsonRpcServer):
        pass
    json_rpc_server_obj = TestJsonRpcServer()
    setattr(json_rpc_server_obj, '_identifier', '00000003')

    # Act
    expected_result = {'jsonrpc': '2.0', 'id': '00000003'}
    actual_result = json_rpc_server_obj.header()

    # Assert
    assert expected_result == actual_result

# Generated at 2022-06-23 14:10:27.105307
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    js = JsonRpcServer()
    setattr(js, '_identifier', "1")
    data = 'sample data'
    resp = js.invalid_params(data)
    assert resp['id'] == "1"
    assert resp['error']['code'] == -32602
    assert resp['error']['message'] == "Invalid params"
    assert resp['error']['data'] == data


# Generated at 2022-06-23 14:10:31.773121
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jsonserver = JsonRpcServer()
    res = jsonserver.invalid_request()
    if (res == {u'jsonrpc': u'2.0', u'error': {u'message': u'Invalid request', u'code': -32600}, u'id': None}):
        return True
    else:
        return False


# Generated at 2022-06-23 14:10:35.677713
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    assert obj.method_not_found() == {u'id': None, u'error': {u'message': u'Method not found', u'code': -32601}, u'jsonrpc': u'2.0'}

# Generated at 2022-06-23 14:10:38.025551
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server.register("myobject")
    return jsonrpc_server._objects


# Generated at 2022-06-23 14:10:42.515794
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
	
	import json
	j = JsonRpcServer()
	print("\nOutput of method invalid_params of class JsonRpcServer:\n")
	print(json.dumps(j.invalid_params(), indent = 4, sort_keys = True))


# Generated at 2022-06-23 14:10:52.543517
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    from message.message_mock import Message
    from base.base_object_mock import BaseObjectMock
    from base.network_driver_mock import NetworkDriverMock
    from base.network_driver_mock import NetworkDriverMockDos

    BaseObjectMock.register(JsonRpcServer)
    NetworkDriverMock.register(JsonRpcServer)
    NetworkDriverMockDos.register(JsonRpcServer)

    jsp = JsonRpcServer()


# Generated at 2022-06-23 14:11:03.118632
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(AnsibleModuleProxy())
    request = {'jsonrpc': '2.0', 'method': 'run_command', 'params':
               [['command', 'no'], {'test': '123'}], 'id': 'id'}
    response = server.handle_request(json.dumps(request))
    result = json.loads(response)
    assert result is not None
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'id'
    assert result['result'] == ''
    assert result['result_type'] == 'pickle'
    return_code = cPickle.loads(to_text(result['result']).encode('utf-8'))
    assert return_code == 0


# Generated at 2022-06-23 14:11:07.606845
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert server._objects == set()
    server.register(1)
    assert server._objects == {1}
    server.register(2)
    assert server._objects == {1, 2}
    server.register(1)
    assert server._objects == {1, 2}

# Generated at 2022-06-23 14:11:16.130758
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    #handle method with no arguments
    request = {
        'jsonrpc': '2.0',
        'method': 'ping',
        'id': '1',
        'params': [
            [],
            {}
        ]
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['result'] == 'pong'

    #handle method with arguments
    request = {
        'jsonrpc': '2.0',
        'method': 'echo',
        'id': '1',
        'params': [
            [
                'hello'
            ],
            {}
        ]
    }
    request = json.dumps(request)
    response = server.handle_

# Generated at 2022-06-23 14:11:18.328635
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    assert JsonRpcServer().header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:11:22.055435
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test_class = JsonRpcServer()
    result = test_class.invalid_request()
    assert result["error"]["code"] == -32600
    assert result["error"]["message"] == "Invalid request"


# Generated at 2022-06-23 14:11:25.884169
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32602
    assert error['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:11:29.603268
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-23 14:11:33.900857
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jr = JsonRpcServer()
    jo = {"jsonrpc": "2.0", "id": None, "error": {"code": -32602, "message": "Invalid params"}}
    assert jr.invalid_params() == jo


# Generated at 2022-06-23 14:11:39.309709
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    Jrs = JsonRpcServer()
    Jrs._identifier = '12345'
    response = Jrs.header()
    print('response[jsonrpc] = ' + response['jsonrpc'])
    assert response['jsonrpc'] == '2.0', 'The value should be 2.0'
    print('response[id] = ' + response['id'])
    assert response['id'] == '12345', 'The value should be 12345'


# Generated at 2022-06-23 14:11:44.046096
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    try:
        _server = JsonRpcServer()
        _server.register
    except Exception:
        print("Function JsonRpcServer.register raised an exception")
    else:
        print("Function JsonRpcServer.register was called successfully")
        

# Generated at 2022-06-23 14:11:49.799637
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # 1- init JsonRpcServer object
    jsonrpc = JsonRpcServer()
    # 2- set id
    jsonrpc._identifier = 12345
    # 3- call header method
    result = jsonrpc.header()
    # 4- check the result
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 12345


# Generated at 2022-06-23 14:11:56.237089
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc_server = JsonRpcServer()
    result = rpc_server.method_not_found()
    assert rpc_server._identifier == result['id']
    assert -32601 == result['error']['code']
    assert 'Method not found' == result['error']['message']


# Generated at 2022-06-23 14:11:57.321546
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    rpcServer = JsonRpcServer()
    try:
        rpcServer.internal_error(data="shutdown -r now")
    except Exception:
        return False
    return True

# Generated at 2022-06-23 14:12:02.304464
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "foobar", "params": "bar", "baz]'
    response = server.handle_request(request)
    result = json.loads(response)
    assert result == {
        'code': -32600,
        'message': 'Invalid request',
        'jsonrpc': '2.0',
        'id': None
    }



# Generated at 2022-06-23 14:12:06.764436
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    JsonRpcServer = JsonRpcServer()
    assert JsonRpcServer.method_not_found(None) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}

# Generated at 2022-06-23 14:12:12.502342
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    response = json.loads(server.handle_request(json.dumps({
        'method': 'some_method',
        'params': [],
        'id': 1,
    })))
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-23 14:12:19.773546
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

# Generated at 2022-06-23 14:12:25.127815
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    data = None
    code = -32603
    message = 'Internal error'
    error = {"code": code, "message": message}
    response = {"jsonrpc": "2.0", "id": "_identifier", "error": error}
    assert response == JsonRpcServer().error(code, message, data)


# Generated at 2022-06-23 14:12:34.225441
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"method":"rpc.run","params": [["show version"]], "id": "abc"}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}'
    request = '{"method":"_connection.get_prompt","params": [], "id": "abc"}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}}'
    request = '{"method":"get_prompt","params": [], "id": "abc"}'
    response = server.handle_request(request)
    assert response

# Generated at 2022-06-23 14:12:37.411582
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonserver = JsonRpcServer()
    setattr(jsonserver, '_identifier', 0)
    assert jsonserver.header() == {'id': 0, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:12:40.611795
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    with open("jsonrpc_server_test.json","r") as f:
        json_content = json.load(f)
        request = json_content["test_case_1"]["request"]

    response = server.handle_request(request)
    print("response: ", response)
    assert response == json.dumps(json_content["test_case_1"]["response"]) 


# Generated at 2022-06-23 14:12:41.465552
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    pass

# Generated at 2022-06-23 14:12:47.504131
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonrpc_server = JsonRpcServer()
    assert jsonrpc_server.parse_error(data='testing') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'testing'}}


# Generated at 2022-06-23 14:12:54.218933
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jserver = JsonRpcServer()
    result = jserver.error(code=-32700, message='Parse error')
    assert json.loads(result) == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32700,
            'message': 'Parse error',
        }
    }


# Generated at 2022-06-23 14:13:04.268655
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # initialize
    rpc = JsonRpcServer()
    rpc.register(rpc)

    # simulate incoming message
    request = {'method': 'parse_error', 'params': [3, 4, 5]}
    request = json.dumps(request)

    # invoke handle_request
    result = rpc.handle_request(request)
    result = json.loads(result)

    # test
    assert result.get("jsonrpc") == "2.0"
    assert result.get("error", {}).get("code") == -32700
    assert result.get("error", {}).get("message") == "Parse error"
    assert result.get("error", {}).get("data") == "incoming message should be a string"


# Generated at 2022-06-23 14:13:07.675983
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    rpc._identifier = '12345'
    expected = {'jsonrpc': '2.0', 'id': '12345'}
    assert rpc.header() == expected


# Generated at 2022-06-23 14:13:10.928637
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrpc_server = JsonRpcServer()
    jrpc_server._identifier = '12345'
    result = jrpc_server.method_not_found()

    assert result == {'jsonrpc': '2.0', 'id': '12345', 'error': {'code': -32601, 'message': 'Method not found'}}

# Generated at 2022-06-23 14:13:14.859390
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    error = obj.internal_error()
    assert(error['id'] == None)
    assert(error['error']['code'] == -32603)
    assert(error['error']['message'] == 'Internal error')
    assert(error['error']['data'] == None)


# Generated at 2022-06-23 14:13:26.480890
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # method to test.
    server = JsonRpcServer()

    # test case 1
    request = ""
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"message": "Invalid request", "code": -32600, "data": ""}}'

    # test case 2
    request = '{"method": "import", "params": "[\"ansible.module_utils.basic\"]"}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"message": "Method not found", "code": -32601}}'

    # test case 3
    request = '{"method": "register", "params": "[{\"a\" : \"b\"}]"}'
    response = server.handle

# Generated at 2022-06-23 14:13:31.592595
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import pytest
    import ansible.module_utils.connection as connection
    server = connection.JsonRpcServer()
    output = server.internal_error('Message')
    assert output['jsonrpc'] == '2.0'
    assert output['error']['code'] == -32603
    assert output['error']['message'] == 'Internal error'
    assert output['error']['data'] == 'Message'


# Generated at 2022-06-23 14:13:34.640828
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    o = JsonRpcServer()
    method_result = o.invalid_params()
    assert method_result['error']['code'] == '-32602'


# Generated at 2022-06-23 14:13:41.243383
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = 1
    internalError = json_rpc_server.internal_error('unfinished business')
    assert internalError['result'] is None
    assert internalError['id'] == 1
    assert internalError['jsonrpc'] == '2.0'
    assert internalError['error']['code'] == -32603
    assert internalError['error']['message'] == 'Internal error'
    assert internalError['error']['data'] == 'unfinished business'


# Generated at 2022-06-23 14:13:53.140646
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    import inspect
    import os
    import yaml

    from ansible.module_utils.basic import AnsibleModule

    def get_fixture(filename):
        path = os.path.join(os.path.dirname(__file__), 'fixtures', filename)
        with open(path) as f:
            return yaml.load(f)

    results = get_fixture('test_json_rpc_server.yaml')

    for result in results:
        args = result.pop('args')
        module = AnsibleModule(argument_spec=result['argument_spec'])
        fixture = result['fixture']
        JsonRpcServer._identifier = 0
        JsonRpcServer._objects = set()

        instance = JsonRpcServer()

# Generated at 2022-06-23 14:14:02.480975
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    request = json.loads('{"jsonrpc": "2.0", "method": "rpc.method_not_found", "params": ["foo", "bar"], "id": 1}')
    method = request.get('method')
    args, kwargs = request.get('params')
    setattr(server, '_identifier', request.get('id'))
    rpc_method = None
    for obj in server._objects:
        rpc_method = getattr(obj, method, None)
        if rpc_method:
            break
    response = json.dumps(server.parse_error())
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": 1}'



# Generated at 2022-06-23 14:14:14.731803
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import sys

    sys.modules['ansible.utils.display'] = sys.modules['__main__']
    for key in sys.modules.keys():
        if key.startswith('ansible.module_utils'):
            sys.modules[key] = sys.modules['__main__']

    if 'ansible.module_utils.connection' in sys.modules:
        del sys.modules['ansible.module_utils.connection']

    jsonrpc = JsonRpcServer()

    print("testing internal error")
    assert jsonrpc.method_not_found() == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}


if __name__ == '__main__':
    test_JsonRpcServer

# Generated at 2022-06-23 14:14:20.401766
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = server.error('code', 'message')
    assert result == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': 'code',
            'message': 'message'
        }
    }
    result = server.error('code', 'message', 'data')
    assert result == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': 'code',
            'message': 'message',
            'data': 'data'
        }
    }

# Generated at 2022-06-23 14:14:26.233870
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.internal_error(data="error") == {'jsonrpc': '2.0', 'id': _identifier, 'error': {'code': -32603, 'message': 'Internal error', 'data': 'error'}}

# Generated at 2022-06-23 14:14:32.986023
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    srv = JsonRpcServer()
    srv.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'rpc.introspect', 'params': [], 'id': 1}))
    assert srv.invalid_request() == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32600,
            'message': 'Invalid request',
        }
    }

# Generated at 2022-06-23 14:14:33.959159
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    pass


# Generated at 2022-06-23 14:14:37.708787
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 101)
    assert server.error(-1, 'Test Error') == {'jsonrpc': '2.0', 'error': {'code': -1, 'message': 'Test Error'}, 'id': 101}


# Generated at 2022-06-23 14:14:42.171006
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_JsonRpcServer = JsonRpcServer()
    test_JsonRpcServer._identifier = 'e6d977d2-2c43-4de7-b6a4-73a8c468dde0'
    header = test_JsonRpcServer.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == 'e6d977d2-2c43-4de7-b6a4-73a8c468dde0'


# Generated at 2022-06-23 14:14:46.829257
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc = JsonRpcServer()
    result = rpc.parse_error()
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert result['error']['data'] == None


# Generated at 2022-06-23 14:14:56.946016
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    from ansible.module_utils.json_rpc_server import JsonRpcServer
    import traceback
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.utils.display import Display

    display = Display()


# Generated at 2022-06-23 14:15:01.686737
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    error = server.internal_error('Error')
    assert("error" in error)
    assert("code" in error["error"])
    assert("message" in error["error"])
    assert("data" in error["error"])
    assert(error["id"] is None)

# Generated at 2022-06-23 14:15:09.831233
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class AnsibleModule(object):

        def __init__(self):
            self.params = {}

    a = JsonRpcServer()
    a.register(AnsibleModule())
    setattr(a, '_identifier', 1)
    result = a.handle_request(b'{ "id": 1, "method": "fooooooo" }')
    assert result == '"{\\"jsonrpc\\": \\"2.0\\", \\"id\\": 1, \\"error\\": {\\"code\\": -32601, \\"message\\": \\"Method not found\\"}}"', result

# Generated at 2022-06-23 14:15:16.787558
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    test = JsonRpcServer()
    expected_error = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32602,
            "message": "Invalid params",
            "data": None
        }
    }
    result = test.invalid_params()
    if result == expected_error:
        print("Test successful")

# Generated at 2022-06-23 14:15:23.118939
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.error(code=1, message="msg")

    assert result == {
        'jsonrpc': '2.0',
        'id': '123',
        'error': {
            'code': 1,
            'message': "msg"
        }
    }

# Generated at 2022-06-23 14:15:31.108797
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    # Test 1 : Registering an object without any methods.
    # Expected response : _objects is empty
    test1 = JsonRpcServer()
    obj = object()
    test1.register(obj)
    assert test1._objects == set(), "Objects list should be empty."

    # Test 2 : Registering an object with methods.
    # Expected response : obj registers successfully
    test2 = JsonRpcServer()
    obj1 = type('obj', (), {'method1': lambda : '1', 'method2': lambda : '2'})()
    test2.register(obj1)
    assert obj1 in test2._objects, "Method not registered successfully."

# Generated at 2022-06-23 14:15:34.813871
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer().parse_error() == {'jsonrpc': '2.0',
                                            'id': None,
                                            'error': {'data': None,
                                                      'message': 'Parse error',
                                                      'code': -32700}}


# Generated at 2022-06-23 14:15:36.625785
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    instance = JsonRpcServer()
    assert isinstance(instance, JsonRpcServer)
    assert instance is not None


# Generated at 2022-06-23 14:15:41.811174
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    
    # Create a jsonrpc object
    jsonrpc = JsonRpcServer()

    # Try to call the method 'method_not_found'
    jsonrpc.method_not_found()


# Generated at 2022-06-23 14:15:49.814190
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """Test method handle_request of class JsonRpcServer"""
    import json

    json_rpc_server = JsonRpcServer()
    params = [1,2,3] # list of positional arguments
    kwargs = {'arg1': 1, 'arg2': 'a'} # dictionary of keyword arguments

    # register an object
    class test_object(object):
        def __init__(self):
            pass

        @property
        def __methods__(self):
            return ['test_method_0', 'test_method_1']

        def test_method_0(self, *args, **kwargs):
            return args, kwargs

        def test_method_1(self):
            return 1
    test_obj = test_object()

# Generated at 2022-06-23 14:15:58.778685
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    expected_result = '{"jsonrpc": "2.0", "result": "dummy_result", "result_type": "pickle", "id": "dummy_id"}'
    json_rpc_server = JsonRpcServer()
    setattr(json_rpc_server, '_identifier', 'dummy_id')
    result = json_rpc_server.response('dummy_result')
    result = json.dumps(result)
    # print(result)
    assert result == expected_result

# Generated at 2022-06-23 14:16:00.572717
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-23 14:16:03.023609
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():

    obj = object()
    j = JsonRpcServer()
    j.register(obj)

    assert j._objects == set([obj])


# Generated at 2022-06-23 14:16:06.570125
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    return_value = JsonRpcServer().invalid_params(data=None)
    assert return_value == {"error": {"code": -32602, "message": "Invalid params"}, "id": None, "jsonrpc": "2.0"}


# Generated at 2022-06-23 14:16:09.656440
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None}


# Generated at 2022-06-23 14:16:14.096926
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # create instance of class JsonRpcServer
    obj = JsonRpcServer()
    # always return the value of the first parameter
    expected = obj.invalid_params("test")
    actual = obj.invalid_params("test")
    assert expected == actual, "Test Failed"

test_JsonRpcServer_invalid_params()

# Generated at 2022-06-23 14:16:18.889860
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import pytest
    rpc_server = JsonRpcServer()
    obj = {}
    setattr(rpc_server, '_objects', set())
    rpc_server.register(obj)
    assert rpc_server._objects == {obj}


# Generated at 2022-06-23 14:16:23.185899
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"},
    "id": None}

# Generated at 2022-06-23 14:16:33.607536
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    params = {"remote_addr": "127.0.0.1", "network_os": "ios", "provider": {"password": "foo", "host": "127.0.0.1", "username": "bar", "port": 22}}
    testjson = {"method": "get_config", "params": [params], "id": 42, "jsonrpc": "2.0"}

    from ansible.module_utils.network import NetworkModule
    from ansible.module_utils.network import BasicModule

    conn = NetworkModule(params, always_pipeline=False)
    module = BasicModule(connection=conn)

    server = JsonRpcServer()
    server.register(module)

    response = server.handle_request(json.dumps(testjson))
    result = json.loads(response)


# Generated at 2022-06-23 14:16:41.176523
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server.register(server)
    response = server.handle_request(b'{"jsonrpc": "2.0", "method": "echo", "params": null, "id": "1"}')
    assert json.loads(response) == {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": "1"}


# Generated at 2022-06-23 14:16:45.361915
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonrpc_server = JsonRpcServer()
    actual = jsonrpc_server.method_not_found(data=None)
    expected = {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}}
    assert expected == actual

# Generated at 2022-06-23 14:16:47.256845
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer().__class__ == JsonRpcServer


# Generated at 2022-06-23 14:16:51.247900
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrpc = JsonRpcServer()
    setattr(jrpc, '_identifier', '1')
    response = jrpc.header()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'



# Generated at 2022-06-23 14:16:56.554671
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    header = {'jsonrpc': '2.0', 'id': 1}
    error = {'code': -32700, 'message': 'Parse error'}
    result = {'jsonrpc': '2.0', 'id': 1, 'error': error}
    assert server.parse_error() == result


# Generated at 2022-06-23 14:16:59.319222
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:17:03.878796
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer().parse_error(data='This is an parse_error') == {
        "id": None,
        "jsonrpc": "2.0",
        "error":
        {
            "code": -32700,
            "message": "Parse error",
            "data": "This is an parse_error"
        }
    }
