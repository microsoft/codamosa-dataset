

# Generated at 2022-06-23 14:07:05.707593
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    j = JsonRpcServer()
    setattr(j, '_identifier' , 1)
    assert j.parse_error() == {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": 1}
    delattr(j, '_identifier')


# Generated at 2022-06-23 14:07:09.611416
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    result = JsonRpcServer().method_not_found()
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:07:14.147273
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    j = JsonRpcServer()
    j._identifier = 123
    result = j.response('reboot')
    if result != {'jsonrpc': '2.0', 'id': 123, 'result': 'reboot'}:
        raise AssertionError('Result is "{}"'.format(result))



# Generated at 2022-06-23 14:07:21.614820
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "id": "test_JsonRpcServer_invalid_request",
        "method": "rpc.test",
        "params": ["test2"]
    }
    response_expected = {
        "jsonrpc": "2.0",
        "id": "test_JsonRpcServer_invalid_request",
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None
        }
    }
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == response_expected

# Generated at 2022-06-23 14:07:26.834567
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params()
    assert isinstance(response, dict)
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'
    assert response['id'] == None



# Generated at 2022-06-23 14:07:30.211681
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    js = JsonRpcServer
    print("JsonRpcServer class is created")

if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-23 14:07:34.429864
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    response = json.loads(server.handle_request(json.dumps({'id': 1, 'jsonrpc': '2.0', 'method': 'invalid.method'})))
    expected = {'code': -32601, 'message': 'Method not found', 'jsonrpc': '2.0', 'id': 1}

    assert response['error'] == expected

# Generated at 2022-06-23 14:07:38.504481
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpc = JsonRpcServer()
    assert jsonrpc.error(0, "") == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 0, 'message': ""}}
    assert jsonrpc.error(0, "", "") == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 0, 'message': "", 'data': ""}}

# Generated at 2022-06-23 14:07:42.554044
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    rpc_error = server.invalid_params()
    assert rpc_error.get('error', {}).get('code') == -32602
    assert rpc_error.get('error', {}).get('message') == 'Invalid params'


# Generated at 2022-06-23 14:07:45.342671
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc = JsonRpcServer()
    rpc.register(rpc)
    request = rpc.method_not_found()
    assert request['error']['code'] == -32601



# Generated at 2022-06-23 14:07:48.185299
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc = JsonRpcServer()
    rpc._identifier = '1'
    result = rpc.parse_error()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == '1'
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:07:50.197429
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer_instance = JsonRpcServer()
    class obj:
        pass
    JsonRpcServer_instance.register(obj)

# Generated at 2022-06-23 14:07:52.867010
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpcserver = JsonRpcServer()

if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-23 14:08:00.739556
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    o = JsonRpcServer()
    setattr(o, '_identifier', 'something')
    r = o.internal_error('either \'host\' or \'hostname\' is required')
    assert r == {
        'jsonrpc': '2.0',
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': 'either \'host\' or \'hostname\' is required'
        },
        'id': 'something'
    }

# Generated at 2022-06-23 14:08:04.460707
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    obj._identifier = "test"
    assert obj.internal_error() == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-23 14:08:14.880724
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    socket = open('/tmp/unittest_JsonRpcServer_handle_request', 'w+')
    server = JsonRpcServer()
    class TestClass:
        def test_method(self, param):
            return param
    server.register(TestClass())
    socket.write('{"id":1,"method":"test_method","params":"hello"}')
    socket.flush()
    socket.seek(0)
    assert server.handle_request(socket.read()) == '{"jsonrpc":"2.0","id":1,"result":"hello"}'
    socket.close()
    import os
    os.system('rm -rf /tmp/unittest_JsonRpcServer_handle_request')


# Generated at 2022-06-23 14:08:19.089896
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    response = rpc_server.error(code=-32700, message="Parse error", data="foobar")
    assert json.dumps(response, sort_keys=True) == '{"error": {"code": -32700, "data": "foobar", "message": "Parse error"}, "id": null, "jsonrpc": "2.0"}'

# Generated at 2022-06-23 14:08:22.306182
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'None')
    response = server.internal_error("This is an internal error")
    return response


# Generated at 2022-06-23 14:08:28.220379
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    result = JsonRpcServer().internal_error(data=None)
    if result != '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": None}':
        raise RuntimeError("test_JsonRpcServer_internal_error() failed")

if __name__ == "__main__":
    test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:08:32.983511
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', '9001')
    result = rpc_server.error(3, 'message', data='testdata')
    assert result == {
        'jsonrpc': '2.0',
        'id': '9001',
        'error': {'code': 3, 'message': 'message', 'data': 'testdata'}
    }

# Generated at 2022-06-23 14:08:40.718277
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)

    result = 'this is a test string'
    response = server.response(result=result)
    assert response['id'] == 1
    assert response['result'] == result
    assert 'error' not in response

    result = {'foo': 'bar'}
    response = server.response(result=result)
    assert response['result_type'] == 'pickle'
    assert response['result'] == cPickle.dumps(result, protocol=0)
    assert 'error' not in response


# Generated at 2022-06-23 14:08:45.638386
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 'some_identifier')
    result = rpc_server.error(-32603, 'Internal error', data='not a real jsonrpc error')
    assert result == dict(
        jsonrpc='2.0',
        id='some_identifier',
        error=dict(
            code=-32603,
            message='Internal error',
            data='not a real jsonrpc error'
        )
    )


# Generated at 2022-06-23 14:08:49.232853
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    result = server.invalid_params()

    assert result == {u'jsonrpc': u'2.0', u'error': {u'message': u'Invalid params', u'code': -32602}, u'id': None}

# Generated at 2022-06-23 14:08:51.502925
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server != None

# Generated at 2022-06-23 14:08:56.151546
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import os
    import sys

    sys.path.insert(0, os.path.dirname(__file__))
    import module_utils.network.cnos.cnos as cnos

    rpc_server = JsonRpcServer()
    rpc_server.register(cnos)
    assert cnos in rpc_server._objects

# Generated at 2022-06-23 14:09:03.768762
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from units.compat import unittest
    from units.compat.mock import Mock, patch
    from ansible.module_utils.connection import Connection

    def _mock_connection(self):
        return (Mock())

    def _ansible_module_runner(self, *args, **kwargs):
        self.result = dict(failed=False)

    connection = Connection()

# Generated at 2022-06-23 14:09:09.109940
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    # input args or kwargs
    server = JsonRpcServer()
    server._identifier = 'test'
    error = server.invalid_request()
    assert error == {"id": "test", "error": {"code": -32600, "message": "Invalid request"}, "jsonrpc": "2.0"}


# Generated at 2022-06-23 14:09:13.288326
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    # example input JsonRpcServer
    rpc_server = JsonRpcServer()

    # example input data dict
    data = {}

    # example call method method_not_found
    result = rpc_server.method_not_found(data)
    assert result == {'id': None, 'jsonrpc': '2.0', 'error':{'code':-32601, 'message': 'Method not found'}}

# Generated at 2022-06-23 14:09:18.670761
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_result = "test_result"
    test_response = JsonRpcServer().response(test_result)
    assert test_response['result'] == test_result and test_response['id'] == 0 and test_response['jsonrpc'] == '2.0'

# Generated at 2022-06-23 14:09:21.471553
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': '_test', 'params': [[1, 2, 3], {'a': 1, 'b': 2}], 'id': 0}
    handle_request = json_rpc_server.handle_request(request)
    print(handle_request)


if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-23 14:09:24.929089
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['error']['code'] == -32602
    assert error['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:09:27.732593
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    header = server.header()
    assert header == {"jsonrpc": "2.0", "id": 1}

# Generated at 2022-06-23 14:09:37.453516
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    mock_response = {'jsonrpc': '2.0', 'id': 1, 'result': 'test'}

    def test_case(test_object):
        test_object.assertListEqual(list(JsonRpcServer._objects), [test_object], 'no method registered')
        rpc_server = JsonRpcServer()
        rpc_server.register(test_object)
        test_object.assertListEqual(list(JsonRpcServer._objects), [test_object, rpc_server], 'register failed')
        test_object.assertEqual(rpc_server.handle_request(json.dumps({'id': 1, 'jsonrpc': '2.0', 'method': 'test_method'})), json.dumps(mock_response), 'handle_request failed')


# Generated at 2022-06-23 14:09:39.323724
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    print("\nUpdate the unit test code for: invalid_params\n")


# Generated at 2022-06-23 14:09:43.094259
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    obj = JsonRpcServer()
    result = obj.error(512, "This is test")
    assert result["error"]["code"] == 512
    assert result["error"]["message"] == "This is test"


# Generated at 2022-06-23 14:09:54.942192
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    
    # JSON-RPC Response Header
    class_object = JsonRpcServer()
    
    # JSON-RPC class instance check
    assert isinstance(class_object, JsonRpcServer)
    
    # Check method response without passing any parameter
    response = class_object.response()
    assert response == {'id': None, 'jsonrpc': '2.0', 'result': None, 'result_type': None}
    
    # Check method response with text-type parameter
    response = class_object.response("result")
    assert response == {'id': None, 'jsonrpc': '2.0', 'result': 'result', 'result_type': None}
    
    # Check method response with byte-type parameter
    response = class_object.response(b"result")

# Generated at 2022-06-23 14:10:00.770702
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    s = JsonRpcServer()
    s.register(s)
    result = to_text(s.handle_request(b'not a real request'))
    response = '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error", "data": "No JSON object could be decoded"}, "id": null}'
    assert result == response

# Generated at 2022-06-23 14:10:06.067012
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrs = JsonRpcServer()
    result = jrs.invalid_request()

    assert 'jsonrpc' in result
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'


# Generated at 2022-06-23 14:10:13.129006
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jr = JsonRpcServer()
    try: 
        assert(jr.method_not_found()['error']['code'] == -32601)
        assert(jr.method_not_found()['error']['message'] == 'Method not found')
    except AssertionError:
        print("Failed test_JsonRpcServer_method_not_found")

test_JsonRpcServer_method_not_found()

# Generated at 2022-06-23 14:10:18.023590
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    jrs.method_not_found()
    jrs.invalid_request()
    jrs.invalid_params()
    expected = {'jsonrpc': '2.0', 'id': None,
                'error': {'code': -32603, 'message': 'Internal error', 'data': None}}
    result = jrs.internal_error()
    assert result == expected

# Generated at 2022-06-23 14:10:21.024282
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    js = JsonRpcServer()
    a = js.method_not_found(2)
    print(a)


# Generated at 2022-06-23 14:10:28.967168
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    obj.register(obj)
    setattr(obj, '_identifier', 1)
    result = {
        'facts': {
            'uptime_seconds': 51,
            'model': 'Cisco ASR903 Router',
        }
    }
    result_str = json.dumps(result)
    response = obj.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['result'] == result_str


# Generated at 2022-06-23 14:10:32.173274
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsr = JsonRpcServer()
    for obj in [{"foo": "foo"}, {"bar": "bar"}]:
        jsr.register(obj)
    assert jsr._objects.__len__() == 2


# Generated at 2022-06-23 14:10:37.866526
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    testobj = JsonRpcServer()
    testobj._identifier = 1
    assert testobj.header() == {'jsonrpc': '2.0', 'id': testobj._identifier}, \
        'test_JsonRpcServer_header: expected "{}" but got "{}"'.format({'jsonrpc': '2.0', 'id': testobj._identifier},
                                                                       testobj.header())


# Generated at 2022-06-23 14:10:43.671381
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = {
        "method": "get_facts",
        "params": [],
        "id": "test",
        "jsonrpc": "2.0"
    }
    JsonRpcServer._objects = set()
    JsonRpcServer().register(obj)
    assert JsonRpcServer._objects[0] == obj


# Generated at 2022-06-23 14:10:45.584232
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    j = JsonRpcServer()
    j.parse_error()


# Generated at 2022-06-23 14:10:49.827917
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    assert JsonRpcServer().invalid_params({'data': 'data'}) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params', 'data': {'data': 'data'}}}

# Generated at 2022-06-23 14:10:51.743904
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:10:56.283931
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    msg = "Parse error"
    err = server.error(-32700, msg)
    assert err['error']['code'] == -32700
    assert err['error']['message'] == msg

# Generated at 2022-06-23 14:10:59.649062
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrs = JsonRpcServer()
    result = jrs.invalid_request()
    assert(result['error']['code'] == -32600)
    assert(result['error']['message'] == 'Invalid request')


# Generated at 2022-06-23 14:11:01.523020
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc = JsonRpcServer()
    result = rpc.invalid_request()
    return result


# Generated at 2022-06-23 14:11:06.074193
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    header = server.header()
    expected_header = {'jsonrpc': '2.0'}
    assert header == expected_header, "header with wrong jsonrpc version"
    server._identifier = "test_id"
    header = server.header()
    expected_header = {'jsonrpc': '2.0', 'id': 'test_id'}
    assert header == expected_header, "header with wrong jsonrpc version"


# Generated at 2022-06-23 14:11:15.504889
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    import src.main
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.jsonrpcServer = src.main.JsonRpcServer()
        # method_not_found: tests for method_not_found
        def method_not_found(self, data=None):
            return self.error(-32601, 'Method not found', data)
        def test_method_not_found(self):
            self.assertEqual("{'error': {'code': -32601, 'message': 'Method not found'}, 'jsonrpc': '2.0', 'id': '1'}", self.method_not_found())
    if __name__ == "__main__":
        unittest.main()


# Generated at 2022-06-23 14:11:16.899469
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class testObject:
        pass

    server.register(testObject())
    assert testObject() in server._objects

# Generated at 2022-06-23 14:11:21.525892
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': None}
    setattr(server, '_identifier', '1234')
    assert server.header() == {'jsonrpc': '2.0', 'id': '1234'}


# Generated at 2022-06-23 14:11:25.297151
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    error = json_rpc_server.invalid_params(data="Invalid params")
    print(error)

if __name__ == '__main__':
    test_JsonRpcServer_invalid_params()

# Generated at 2022-06-23 14:11:31.234796
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    data = "test"

    obj = JsonRpcServer()
    result = obj.internal_error(data)

    assert result == {
        "id": None,
        "jsonrpc": "2.0",
        "error": {
            "message": "Internal error",
            "code": -32603,
            "data": "test"
        }
    }


# Generated at 2022-06-23 14:11:34.258553
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    J = JsonRpcServer()
    J._identifier = 10
    result = J.header()
    assert result == {'jsonrpc': '2.0', 'id': 10}


# Generated at 2022-06-23 14:11:40.351577
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    expected_response = {
        "id": "123",
        "jsonrpc": "2.0",
        "result": "ZGV2L2NvbW1hbmQvY29tbWFuZC5waHA/Y21kPXRlc3Q="
    }
    server = JsonRpcServer()
    setattr(server, "_identifier", "123")
    assert dict(server.response("dev/command/command.php?cmd=test")) == expected_response
    # cleanup
    delattr(server, "_identifier")


# Generated at 2022-06-23 14:11:48.106381
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    a = JsonRpcServer()
    a.register(JsonRpcServer())
    a._identifier = 'ABC'
    result = a.invalid_params()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'ABC'
    assert result['error']['code'] == -32602
    assert result['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:11:59.712472
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    import pytest

    a = JsonRpcServer()
    # {"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found", "data": null}}
    assert json.loads(a.method_not_found()) == {u'jsonrpc': u'2.0', u'id': None, u'error': {u'code': -32601, u'message': u'Method not found', u'data': None}}
    # {"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found", "data": "test"}}

# Generated at 2022-06-23 14:12:06.404562
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'foo'
    response = server.error(code=404, message='bad')
    assert response is not None
    assert response['id'] == 'foo'
    assert 'error' in response
    error = response['error']
    assert 'code' in error
    assert error['code'] == 404
    assert 'message' in error
    assert error['message'] == 'bad'


# Generated at 2022-06-23 14:12:11.764746
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    response = JsonRpcServer().response()
    assert(response['jsonrpc'] == '2.0')
    assert('result' not in response)
    assert('error' not in response)

    response2 = JsonRpcServer().response('response string')
    assert(response2['result'] == 'response string')
    assert('error' not in response2)


# Generated at 2022-06-23 14:12:15.442362
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonRpcServer = JsonRpcServer()
    assert(jsonRpcServer.handle_request('{"method": "foobar"}') == json.dumps({'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32601, 'message': 'Method not found'}}))

# Generated at 2022-06-23 14:12:22.554199
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils._text import to_bytes
    import json
    server = JsonRpcServer()
    server._identifier = to_bytes('test')
    result = json.loads(server.header())
    assert result == {
        'jsonrpc': '2.0',
        'id': 'test'
    }


# Generated at 2022-06-23 14:12:28.119997
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    setattr(server, '_identifier', "request_id")
    result = server.method_not_found()
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'
    assert result['error'].get('data') is None
    assert result['id'] == "request_id"
    assert result['jsonrpc'] == '2.0'


# Generated at 2022-06-23 14:12:32.664349
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrs = JsonRpcServer()
    request = {"jsonrpc": "2.0", "method": "rpc.jstest", "params" : [1], "id": 1}
    response = jrs.handle_request(request)
    assert response['error']['message'] == 'Invalid request'


# Generated at 2022-06-23 14:12:37.091999
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'abc')
    result = server.invalid_params('dfg')
    assert result == json.dumps({"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params", "data": "dfg"}, "id": "abc"})


# Generated at 2022-06-23 14:12:38.110907
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    display.vvv(server.method_not_found())

# Generated at 2022-06-23 14:12:39.587773
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer.register(self, obj)


# Generated at 2022-06-23 14:12:42.529938
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    result = server.method_not_found()
    assert result == {"jsonrpc": "2.0", "id": None, "error": {"code": -32601, "message": "Method not found"}}

# Generated at 2022-06-23 14:12:49.251201
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
  service = JsonRpcServer()
  expected = {
    'jsonrpc': '2.0',
    'id': None,
    'error': {
      'code': -32700,
      'message': 'Parse error',
      'data': None
    }
  }
  actual = service.parse_error()
  assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-23 14:12:53.714192
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    # initialize an instance of class JsonRpcServer
    jrpc_server = JsonRpcServer()
    # check the output type of the constructor
    assert isinstance(jrpc_server, JsonRpcServer)

test_JsonRpcServer()

# Generated at 2022-06-23 14:12:55.436467
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
	jsr = JsonRpcServer()
	print(jsr.method_not_found())

# Generated at 2022-06-23 14:12:59.871275
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    js = JsonRpcServer()
    js._identifier = 3
    assert js.handle_request("{}") == b'{"jsonrpc": "2.0", "id": 3, "error": {"code": -32600, "message": "Invalid request"}}'

# Generated at 2022-06-23 14:13:02.364736
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Arrange
    obj = JsonRpcServer()
    # Act
    actual = obj.invalid_params()
    # Assert
    assert actual['error']['code'] == -32602

# Generated at 2022-06-23 14:13:09.107851
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    resp = server.response()
    assert resp['jsonrpc'] == '2.0'
    assert 'result' not in resp

    resp = server.response('foo')
    assert resp['result'] == 'foo'

    resp = server.response(5)
    assert resp['result'] == '5'

    resp = server.response(dict(foo='bar'))
    assert 'result_type' in resp
    assert 'result' in resp
    assert resp['result_type'] == 'pickle'
    assert 'd3' in resp['result']
    assert 'foo' in resp['result']


# Generated at 2022-06-23 14:13:12.680242
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    instance = JsonRpcServer()
    setattr(instance, '_identifier', '123')
    assert instance.header() == {'jsonrpc': '2.0', 'id': '123'}


# Generated at 2022-06-23 14:13:24.725478
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = { "answer": 42 }
    expected = '{"jsonrpc": "2.0", "id": 42, "result": {"answer": 42}}'
    resp = JsonRpcServer().response(result)
    assert json.dumps(resp) == expected

    result = "this is a string"
    expected = '{"jsonrpc": "2.0", "id": 42, "result": "this is a string"}'
    resp = JsonRpcServer().response(result)
    assert json.dumps(resp) == expected

    result = b"this is a byte string"
    expected = '{"jsonrpc": "2.0", "id": 42, "result": "this is a byte string"}'
    resp = JsonRpcServer().response(result)
    assert json.dumps(resp) == expected

# Generated at 2022-06-23 14:13:28.737074
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32602
    assert error['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:13:35.537273
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    _id = 'id1234'
    setattr(server, '_identifier', _id)
    response = server.error(code=0, message='test message', data=None)
    assert response.get('jsonrpc') == '2.0'
    assert response.get('id') == _id
    assert response.get('error').get('code') == 0
    assert response.get('error').get('message') == 'test message'


# Generated at 2022-06-23 14:13:38.195294
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    srv = JsonRpcServer()
    srv._identifier = 13
    assert srv.header() == {'jsonrpc': '2.0', 'id': 13}


# Generated at 2022-06-23 14:13:40.862329
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
  assert JsonRpcServer().invalid_request() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}


# Generated at 2022-06-23 14:13:52.677176
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # jsonrpclib.JSONRPCException is a subclass of RuntimeError
    assert issubclass(RuntimeError, Exception)
    assert issubclass(RuntimeError, StandardError)

    # Patch built-in `super` (for Python 2 and 3) with mock.
    import mock
    orig_super = super
    super = mock.MagicMock()

    from ansible.module_utils.common._jsonrpc_server import JsonRpcServer

    # Use super in JsonRpcServer by calling method error
    json_rpc_server = JsonRpcServer()
    assert issubclass(super(JsonRpcServer, json_rpc_server).error, Exception) is True
    assert issubclass(super(JsonRpcServer, json_rpc_server).error, StandardError) is True

    # Restore built

# Generated at 2022-06-23 14:13:59.266950
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():

    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = 111
    error = json_rpc_server.invalid_request()

    assert error['id'] == 111
    assert error['jsonrpc'] == '2.0'
    assert isinstance(error['error'], dict)
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:14:03.378165
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_instance = JsonRpcServer()
    test_instance._identifier = 'test_session'
    result = test_instance.header()
    assert result.get('id') == 'test_session'
    assert result.get('jsonrpc') == '2.0'


# Generated at 2022-06-23 14:14:15.459446
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc = JsonRpcServer()
    setattr(rpc, '_identifier', 1)

    result = rpc.response()
    assert result == {
        'jsonrpc': '2.0',
        'id': 1,
        'result': ''
    }

    result = rpc.response(['a', 'b', 'c'])
    assert result == {
        'jsonrpc': '2.0',
        'id': 1,
        'result': "['a', 'b', 'c']"
    }

    result = rpc.response({'a': 'b'})
    assert result == {
        'jsonrpc': '2.0',
        'id': 1,
        'result': "{'a': 'b'}"
    }


# Generated at 2022-06-23 14:14:18.297677
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
	server = JsonRpcServer()
	assert(server.method_not_found()['error']['code'] == -32601)
	assert(server.method_not_found()['error']['message'] == 'Method not found')

# Generated at 2022-06-23 14:14:26.018805
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # test for input as string

    # test for input as string
    assert JsonRpcServer().internal_error().get('result') is None
    # test for input as string and normal execution
    assert JsonRpcServer().internal_error(data='error').get('error').get('data') == 'error'
    # test for input as string and exception 
    assert JsonRpcServer().internal_error().get('error').get('data') is None

# Generated at 2022-06-23 14:14:28.137499
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()
    rpc_server.handle_request(request={})


# Generated at 2022-06-23 14:14:31.424834
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = "foo"
    header = server.header()
    print(header)
    return header


# Generated at 2022-06-23 14:14:36.377211
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()

    result = {
        "jsonrpc": "2.0",
        "id": 148,
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None
        }
    }

    assert rpc_server.invalid_request() == result

# Generated at 2022-06-23 14:14:42.077229
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jsonRpcServer = JsonRpcServer()
    json_dict = {
        "jsonrpc": "2.0",
        "method": "rpc.run",
        "params": [[]],
        "id": "55b5c5d6cc57f822c7da4f1b"
    }
    err_dict = {
        "jsonrpc": "2.0",
        "error": {
            "code": -32600,
            "message": "Invalid request"
        },
        "id": "55b5c5d6cc57f822c7da4f1b"
    }
    err = jsonRpcServer.invalid_request()
    assert err == err_dict

# Generated at 2022-06-23 14:14:52.779825
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc = JsonRpcServer()
    json_rpc._identifier = 'f8cdda83-82b1-4d43-a5ef-6c0a7e2b80d9'

    expected = {
        "jsonrpc": "2.0",
        "error": {
            "code": -32602,
            "message": "Invalid params",
            "data": None
        },
        "id": "f8cdda83-82b1-4d43-a5ef-6c0a7e2b80d9"
    }
    assert expected == json_rpc.invalid_params()


# Generated at 2022-06-23 14:14:56.939343
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', {'jsonrpc': '2.0', 'id': 'ABC'})
    result = server.header()
    assert  result == {'jsonrpc': '2.0', 'id': 'ABC'}


# Generated at 2022-06-23 14:15:01.279585
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonRpcServer = JsonRpcServer()
    assert jsonRpcServer.internal_error(data='error') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error', 'data': 'error'}}

# Generated at 2022-06-23 14:15:07.887174
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    output = server.error(-32603, 'Internal error', 'sample-data')
    expected = {
        'jsonrpc': '2.0',
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': 'sample-data'
        },
        'id': 'sample-data'
    }
    assert (expected == output)

# Generated at 2022-06-23 14:15:16.744187
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_rpc_server_obj = JsonRpcServer()
    setattr(json_rpc_server_obj, '_identifier', "test_identifier_value")
    expected_result = {'jsonrpc': '2.0', 'id': "test_identifier_value", 'error': {'code': -32700, 'message': 'Parse error', 'data': None}}
    result = json_rpc_server_obj.parse_error()
    assert(expected_result == result)


# Generated at 2022-06-23 14:15:20.460809
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    js = JsonRpcServer()
    js._identifier = 1
    print(js.invalid_params())

# Generated at 2022-06-23 14:15:23.290233
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    result = JsonRpcServer().invalid_request()
    assert result["error"]["code"] == -32600
    assert result["error"]["message"] == 'Invalid request'


# Generated at 2022-06-23 14:15:26.487771
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    a = JsonRpcServer()
    actual = a.error("-32603", "Internal error")
    expected = {'jsonrpc': '2.0', 'id': None, 'error': {'code': '-32603', 'message': 'Internal error'}}
    assert actual == expected

# Generated at 2022-06-23 14:15:29.568881
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    s = JsonRpcServer()
    setattr(s, '_identifier', 100)
    x = s.header()
    assert x == {'jsonrpc': '2.0', 'id': 100}
    del x
    del s


# Generated at 2022-06-23 14:15:34.403133
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = {'jsonrpc': '2.0', 'id': '1','result': 123}
    assert result == JsonRpcServer().response(result=123)

    result = {'jsonrpc': '2.0', 'id': '1','result': "123"}
    assert result == JsonRpcServer().response(result="123")


# Generated at 2022-06-23 14:15:35.465482
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert obj is not None

# Generated at 2022-06-23 14:15:41.709594
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    error = server.internal_error()
    assert error['error']['code'] == -32603
    assert error['error']['message'] == 'Internal error'
    assert error['error'].get('data') == None
    assert error['id'] == None

# Generated at 2022-06-23 14:15:47.490941
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    j = JsonRpcServer()
    jsonrpc = j.error(code=404, message="Not Found")
    assert jsonrpc['jsonrpc'] == '2.0'
    assert jsonrpc['error']['code'] == 404
    assert jsonrpc['error']['message'] == "Not Found"

if __name__ == '__main__':
    print("Executing JSON-RPC Server Unit Tests")
    test_JsonRpcServer_error()

# Generated at 2022-06-23 14:15:59.590626
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import copy

    server = JsonRpcServer()
    server._identifier = 1
    result = {'Hello': 'World'}
    result_pickle = cPickle.dumps(result, protocol=0)
    result_text = to_text(result_pickle)


# Generated at 2022-06-23 14:16:05.812660
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    error = JsonRpcServer().invalid_params()
    assert 'jsonrpc' in error
    assert error['jsonrpc'] == '2.0'
    assert 'id' in error
    assert error['id'] == None
    assert 'error' in error
    assert 'code' in error['error']
    assert error['error']['code'] == -32602
    assert 'message' in error['error']
    assert error['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:16:13.961155
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()

    # Test with a class which doesn't have attribute 'rpc_get'
    class TestClass(object):
        def __init__(self):
            pass

        def rpc_get_rpc(self, x, y):
            pass

    # Test with a class which has attribute 'rpc_get'
    class TestClass2(object):
        def __init__(self):
            pass

        def rpc_get(self, x, y):
            pass

    server.register(TestClass2())

    # Test with a class that has both register and get
    class TestClass3(object):
        def __init__(self):
            pass

        def rpc_get(self, x, y):
            pass

        def rpc_register(self, x, y):
            pass

# Generated at 2022-06-23 14:16:21.636913
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    testClass = JsonRpcServer()
    jsonstr='''
{
    "jsonrpc": "2.0",
    "method": "echo",
    "params": ["one", 2, {"three": "four"}],
    "id": 1
}
    '''
    resp = testClass.handle_request(jsonstr)
    print(resp)

if __name__ == "__main__":
    test_JsonRpcServer()

# Generated at 2022-06-23 14:16:31.674446
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    # Invalid json - an error response is expected
    request = '"jsonrpc": "2.0"'
    response = server.handle_request(request)
    response = json.loads(response)
    assert response.get('error')
    assert response.get('error').get('code') == -32700
    # A valid json but not valid request - an error response is expected
    request = '{"jsonrpc": "2.0", "method": "invalid_method", "params": [],"id": 1}'
    response = server.handle_request(request)
    response = json.loads(response)
    assert response.get('error')
    assert response.get('error').get('code') == -32600


# Generated at 2022-06-23 14:16:33.509226
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Obj:
        def foo(self, *args, **kwargs):
            pass
    obj = Obj()
    server.register(obj)
    assert len(server._objects) == 1


# Generated at 2022-06-23 14:16:40.644974
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    import sys
    sys.path.insert(0, '../')
    import ansible_connection_request
    method_not_found = ansible_connection_request.JsonRpcServer.method_not_found()
    assert(method_not_found['error']['code'] == -32601)
    assert(method_not_found['error']['message'] == 'Method not found')

# Generated at 2022-06-23 14:16:44.329878
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}}


# Generated at 2022-06-23 14:16:53.015723
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request = '{"jsonrpc": "2.0", "method": "rpc.invalid", "params": [1,2,3,4,5]}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    result = json.loads(response)
    assert result['id'] is None
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'
    assert result['error']['data'] is None


# Generated at 2022-06-23 14:16:57.312909
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 'Test_header_identifier'
    header = server.header()
    assert header == {'jsonrpc': '2.0', 'id': 'Test_header_identifier'}


# Generated at 2022-06-23 14:16:58.998180
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    assert JsonRpcServer().internal_error(data='test') == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}}
    

# Generated at 2022-06-23 14:17:05.430021
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpcserver = JsonRpcServer()
    rpcserver.register = lambda x: None
    rpcserver.method_not_found = JsonRpcServer.method_not_found
    request = json.dumps({"jsonrpc": "2.0", "method": "test", "id": "123"})
    response = json.loads(rpcserver.handle_request(request))
    assert response == {
        "jsonrpc": "2.0",
        "id": "123",
        "error": {
            "code": -32601,
            "message": "Method not found",
        }
    }