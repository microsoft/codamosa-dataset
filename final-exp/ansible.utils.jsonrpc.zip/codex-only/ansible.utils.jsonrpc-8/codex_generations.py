

# Generated at 2022-06-23 14:07:07.316793
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    instance = JsonRpcServer()
    ret = instance.invalid_request()
    assert ret['jsonrpc'] == '2.0'
    assert ret['id'] == None
    assert ret['error']['code'] == -32600
    assert ret['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:07:14.273125
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = '101'
    err = server.error(999, 'test error message')
    expected = {
        'jsonrpc': '2.0',
        'id': '101',
        'error': {
            'code': 999,
            'message': 'test error message'
        }
    }
    assert err == expected


# Generated at 2022-06-23 14:07:15.901658
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    assert JsonRpcServer().invalid_request()['error']['code'] == -32600


# Generated at 2022-06-23 14:07:20.136088
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()

    params = server.invalid_params()
    assert params["jsonrpc"] == "2.0"
    assert params["id"] == None
    assert params["error"]["code"] == -32602
    assert params["error"]["message"] == "Invalid params"
    assert params["error"]["data"] == None


# Generated at 2022-06-23 14:07:21.660019
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server != None


# Generated at 2022-06-23 14:07:33.474903
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    msg = ('Running unit test: '
           'jsonrpc_connection.JsonRpcServer.parse_error')
    display.vvv(msg)

    rpc_server = JsonRpcServer()
    result = rpc_server.parse_error()

    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'

    try:
        result['error']['data']
    except KeyError:
        pass
    else:
        msg = 'JsonRpcServer.parse_error did not expect "data"'
        display.display(msg, color='red')
        raise AssertionError


# Generated at 2022-06-23 14:07:42.885208
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server.handle_request(request = None) == None
    assert server.register(obj = None) == None
    assert server.header() == {'jsonrpc': '2.0', 'id': None}
    assert server.response(result = None) == {'jsonrpc': '2.0', 'id': None, 'result': None}
    assert server.error(code = -32700, message = 'Parse error', data = None) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}

# Generated at 2022-06-23 14:07:46.012501
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    arg1 = "AnsibleModule"
    obj = JsonRpcServer()

    # Testing when arg1 is valid
    obj.register(arg1)
    assert obj._objects != None

    # Testing when arg1 is invalid
    obj.register(arg1)
    assert obj._objects != None


# Generated at 2022-06-23 14:07:49.587211
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = '1'
    expected = {
        "jsonrpc": "2.0",
        "id": "1"
    }
    assert jsonrpc_server.header() == expected


# Generated at 2022-06-23 14:07:52.868288
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 42)
    assert {'jsonrpc': '2.0', 'id': 42} == server.header()


# Generated at 2022-06-23 14:08:01.275055
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():

    # Unit test for method parse_error of class JsonRpcServer
    rpc_server = JsonRpcServer()

    error = rpc_server.parse_error()
    assert error['id']
    assert error['error']['code'] == -32700
    assert error['error']['message'] == 'Parse error'
    assert 'result' not in error

    error = rpc_server.parse_error(data='oops')
    assert error['id']
    assert error['error']['code'] == -32700
    assert error['error']['message'] == 'Parse error'
    assert error['error']['data'] == 'oops'
    assert 'result' not in error


# Generated at 2022-06-23 14:08:01.993810
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

# Generated at 2022-06-23 14:08:03.921666
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:08:05.378613
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
   internal_error = JsonRpcServer()
   print(internal_error.internal_error())


# Generated at 2022-06-23 14:08:07.039271
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()
    assert isinstance(rpc, JsonRpcServer)

# Generated at 2022-06-23 14:08:12.777137
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    test_object = JsonRpcServer()
    result = test_object.method_not_found()
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:08:17.156884
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test = JsonRpcServer()
    test._identifier = 1
    response = test.response("test")
    assert "jsonrpc" in response
    assert response["id"] == 1
    assert response["result"] == "test"
    assert "result_type" not in response
    assert "error" not in response
    return


# Generated at 2022-06-23 14:08:22.664842
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    module = JsonRpcServer()
    response = module.parse_error()

    expected = {
        'jsonrpc': '2.0',
        'error': {
            'code': -32700,
            'message': 'Parse error'
        },
        'id': None
    }

    assert expected == response


# Generated at 2022-06-23 14:08:25.800961
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.json_rpc import JsonRpcServer
    JsonRpcServer.__init__()
    JsonRpcServer.register()

# Generated at 2022-06-23 14:08:28.055202
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    assert server.invalid_request().get("error").get("code") == -32600


# Generated at 2022-06-23 14:08:34.558228
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc_server = JsonRpcServer()

    # case 1: normal case
    setattr(jsonrpc_server, '_identifier', 1)  # set value to attribute
    output = jsonrpc_server.header()
    expected = {'jsonrpc': '2.0', 'id': 1}
    assert output == expected

    # case 2: set value attribute to None
    setattr(jsonrpc_server, '_identifier', None)  # set value to attribute
    output = jsonrpc_server.header()
    expected = {'jsonrpc': '2.0'}
    assert output == expected


# Generated at 2022-06-23 14:08:40.757727
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonrpc_server = JsonRpcServer()
    response = jsonrpc_server.parse_error()
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'
    response = jsonrpc_server.parse_error(data='Invalid JSON')
    assert response['error']['data'] == 'Invalid JSON'


# Generated at 2022-06-23 14:08:45.830187
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    result = server.invalid_params()

    assert result['id'] is None
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32602
    assert result['error']['message'] == 'Invalid params'



# Generated at 2022-06-23 14:08:48.317587
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonRpcServer = JsonRpcServer()
    print("Message response: %s" % jsonRpcServer.response("success"))
    print("Message response: %s" % jsonRpcServer.response("success", "pickle"))


# Generated at 2022-06-23 14:08:51.284583
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    this = JsonRpcServer()
    result = this.header()
    assert result == {
        'id': this._identifier,
        'jsonrpc': '2.0',
    }


# Generated at 2022-06-23 14:09:00.448556
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpcserver = JsonRpcServer()
    setattr(jsonrpcserver,'_identifier',None)
    assert jsonrpcserver.response("example") == {
        'jsonrpc': '2.0', 'id': None, 'result': 'example'
    }
    assert jsonrpcserver.response("example",) == {
        'jsonrpc': '2.0', 'id': None, 'result': 'example'
    }
    assert jsonrpcserver.response("example",) == {
        'jsonrpc': '2.0', 'id': None, 'result': 'example'
    }
    assert jsonrpcserver.response("example", "example2") == {
        'jsonrpc': '2.0', 'id': None, 'result': 'example'
    }
    assert jsonr

# Generated at 2022-06-23 14:09:05.789096
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj._objects = set()
    class obj1:
        pass
    class obj2:
        pass
    obj1.x = 1
    obj2.y = 2
    obj2.z = 3
    
    obj.register(obj1)
    obj.register(obj2)
    assert(obj._objects == {obj1, obj2})

# Generated at 2022-06-23 14:09:10.168003
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_rpc_obj = JsonRpcServer()
    result = json_rpc_obj.parse_error()
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}, 'id': None}


# Generated at 2022-06-23 14:09:13.988999
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_method = JsonRpcServer()
    try:
        rpc_method.invalid_params("Invalid argument #1: Poblem")
        print("Test case 'test_JsonRpcServer_invalid_params' needs to be fixed")
        exit(1)
    except:
        exit(0)


# Generated at 2022-06-23 14:09:21.681316
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    error_keys = error.keys()
    assert "jsonrpc" in error_keys
    assert "id" in error_keys
    assert "error" in error_keys
    assert error["error"]["code"] == -32700
    assert error["error"]["message"] == "Parse error"
    assert "data" not in error["error"]


# Generated at 2022-06-23 14:09:24.812600
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    assert server.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:09:25.645890
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-23 14:09:29.660061
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jr = JsonRpcServer()
    setattr(jr, '_identifier', "ABCDEF")

    expected = {'jsonrpc': '2.0', 'id': "ABCDEF"}
    actual = jr.header()

    assert actual == expected


# Generated at 2022-06-23 14:09:31.861574
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpc = JsonRpcServer()
    jsonrpc.error(1, "one")

# Generated at 2022-06-23 14:09:39.981415
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jrs = JsonRpcServer()
    assert jrs.handle_request('{"method":"unknown", "params":[1, 2], "id":1}') ==\
            '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'
    assert jrs.handle_request('{"method":"_unknown", "params":[1, 2], "id":1}') ==\
            '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}'

# Generated at 2022-06-23 14:09:44.074730
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error['error']['code'] == -32600
    assert error['error']['message'] == "Invalid request"


# Generated at 2022-06-23 14:09:49.226782
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonrpc_server = JsonRpcServer()
    error = jsonrpc_server.internal_error()
    assert error == {"jsonrpc": "2.0", "id": None, "error": {"code": -32603, "message": "Internal error"}}

# Generated at 2022-06-23 14:09:57.493489
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServer = JsonRpcServer()
    badParams = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": "badparams",
        "id": "1",
        "badMethod": ""
    }
    result = jsonRpcServer.error(-32602, 'Invalid params', badParams)
    assert result =="{\"jsonrpc\": \"2.0\", \"id\": \"1\", \"error\": {\"code\": -32602, \"message\": \"Invalid params\", \"data\": {\"jsonrpc\": \"2.0\", \"method\": \"rpc.test\", \"params\": \"badparams\", \"id\": \"1\", \"badMethod\": \"\"}}}"

# Generated at 2022-06-23 14:09:58.436095
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert(server)


# Generated at 2022-06-23 14:10:03.736143
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Rabbit():
        def parse(self):
            return "running"

    rabbit = Rabbit()
    server.register(rabbit)
    output = server.handle_request(json.dumps({'method': 'parse', 'params':[]}))
    assert json.loads(output)['result'] == 'running'



# Generated at 2022-06-23 14:10:09.047590
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    print("Testing invalid_request")
    response = JsonRpcServer().invalid_request()
    print(response)
    assert response['error'] == {'code': -32600, 'message': 'Invalid request'}

if __name__ == "__main__":
    test_JsonRpcServer_invalid_request()

# Generated at 2022-06-23 14:10:18.540024
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Test with code of 1000 and message of message
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = 100
    result = jsonrpc_server.error(1000, 'message')
    assert result['id'] == 100
    assert result['error']['code'] == 1000
    assert result['error']['message'] == 'message'
    assert result['jsonrpc'] == '2.0'
    # Test with code of 1000, message of message, and data of data
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = 100
    result = jsonrpc_server.error(1000, 'message', data='data')
    assert result['id'] == 100
    assert result['error']['code'] == 1000

# Generated at 2022-06-23 14:10:23.602910
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    parser = json.loads(JsonRpcServer().invalid_params())
    assert parser["id"] == 2
    assert parser["jsonrpc"] == "2.0"
    assert parser["error"]["code"] == -32602
    assert parser["error"]["message"] == "Invalid params"


# Generated at 2022-06-23 14:10:25.545625
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    server.method_not_found()

# Generated at 2022-06-23 14:10:26.896335
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server


# Generated at 2022-06-23 14:10:30.376222
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    srv = JsonRpcServer()
    srv._identifier = "123"

    error = srv.method_not_found()
    assert error == {'id': '123', 'jsonrpc': '2.0', 'error': {'message': 'Method not found', 'code': -32601}}

# Generated at 2022-06-23 14:10:35.425298
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    data = 'something'
    want = {'jsonrpc': '2.0', 'id': None, 'error':
            {'code': -32700, 'message': 'Parse error',
             'data': 'something'}}
    got = server.parse_error(data)
    assert want == got



# Generated at 2022-06-23 14:10:38.462713
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    response = server.invalid_request()
    assert response['id'] == None
    assert response['error']['code'] == -32600
    assert response['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:10:42.811981
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    response = JsonRpcServer().invalid_request("data")
    assert response['jsonrpc'] == "2.0"
    assert response['id'] is None
    assert response['error']['code'] == -32600
    assert response['error']['message'] == "Invalid request"
    assert response['error']['data'] == "data"

test_JsonRpcServer_invalid_request()

# Generated at 2022-06-23 14:10:52.717186
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.network.asmc.asmc import Asmc
    from ansible.module_utils.network.asmc.facts import Facts
    from ansible.module_utils.network.asmc.config import ModuleManager, ConfigManager, NetworkManager

    from ansible.module_utils.network.asmc.asmc import Asmc
    from ansible.module_utils.network.asmc.facts import Facts
    from ansible.module_utils.network.asmc.config import ModuleManager, ConfigManager, NetworkManager

    print("Unit test for method register of class JsonRpcServer")
    asmc = Asmc("10.23.154.1", username="admin", password="pass")
    facts_module = Facts(asmc)
    config_mgr = ConfigManager(asmc)
    module_mgr = ModuleManager

# Generated at 2022-06-23 14:11:01.562191
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import cliconf_loader

    parser = Connection.get_network_cli_option_parser()
    parser.add_argument('--foo', default='ansible')

    # Create JsonRpcServer object
    rpc = JsonRpcServer()

    # Create a Connection object
    conn = Connection(parser=parser)
    conn.connection = cliconf_loader.get('nxos', 'stdin')

    # Test register
    rpc.register(conn)

    # Verify the result
    assert conn in rpc._objects


# Generated at 2022-06-23 14:11:05.903258
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    import pytest

    try:
        json_rpc_server = JsonRpcServer()
        error = json_rpc_server.invalid_request()
    except Exception as e:
        pytest.fail("Exception is raised: %s" %e)
    else:
        assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}


# Generated at 2022-06-23 14:11:06.920482
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    assert False


# Generated at 2022-06-23 14:11:10.502009
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    # Create new instance of JsonRpcServer object
    server = JsonRpcServer()

    # Verify that id is not set
    assert not hasattr(server, '_identifier')


# Generated at 2022-06-23 14:11:14.147717
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = server.response(result='test')
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == None
    assert result['result'] == 'test'


# Generated at 2022-06-23 14:11:24.593322
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    # Happy path, call the response function
    request = json.dumps({
        'jsonrpc': '2.0',
        'id': '',
        'method': 'response'
    })
    result = json.loads(server.handle_request(request))
    assert result == {
        "jsonrpc": "2.0",
        "id": "",
        "result": ""
    }
    # Wrong jsonRpc version
    request = json.dumps({
        'jsonrpc': '1.0',
        'id': '',
        'method': 'response'
    })
    result = json.loads(server.handle_request(request))

# Generated at 2022-06-23 14:11:27.754019
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj = JsonRpcServer()
    obj._identifier = 1
    expected = {'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params'}, 'id': 1}
    assert obj.invalid_params() == expected

# Generated at 2022-06-23 14:11:35.227902
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpcserver = JsonRpcServer()
    rpcserver._identifier = "12345"
    assert rpcserver.response("Hello") == {'jsonrpc': '2.0', 'id': '12345', 'result': "Hello"}
    assert rpcserver.response("World") == {'jsonrpc': '2.0', 'id': '12345', 'result': "World"}
    assert rpcserver.response() == {'jsonrpc': '2.0', 'id': '12345', 'result': None}


# Generated at 2022-06-23 14:11:37.805877
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class TestObj:
        def add(self, a, b):
            return a + b
    test = TestObj()
    server.register(test)
    assert test._identifier is not None
    assert server._objects == set([test])


# Generated at 2022-06-23 14:11:38.996682
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    p = JsonRpcServer()
    assert type(p) is JsonRpcServer

# Generated at 2022-06-23 14:11:46.748585
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    '''Test for method handle_request of class JsonRpcServer'''
    rpc = JsonRpcServer()
    assert rpc.handle_request('{"jsonrpc": "2.0", "method": "foobar", "id": "1", "params": {}}') == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32601, "message": "Method not found", "data": null}}'

# Generated at 2022-06-23 14:11:50.379954
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    try:
        JsonRpcServer().internal_error()
    except:
        print("JsonRpcServer.internal_error raised exception")
        return False

    return True

print("Result of test_JsonRpcServer_internal_error():", test_JsonRpcServer_internal_error())

# Generated at 2022-06-23 14:11:55.065335
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 1
    ret = server.response(3)
    assert ret == {'jsonrpc': '2.0', 'id': 1, 'result': '3'}

# Generated at 2022-06-23 14:11:59.245177
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    test = JsonRpcServer()
    result = test.parse_error(data='test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'test'}}


# Generated at 2022-06-23 14:12:05.802072
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class MockObj(object):
        def hello(self):
            return "hello"

    try:
        server = JsonRpcServer()
        obj = MockObj()
        server.register(obj)
        assert(getattr(server, "_objects") == set([obj]))
        assert(True)
    except Exception as e:
        print(e)
        assert(False)


# Generated at 2022-06-23 14:12:08.100962
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 1234)
    result = rpc_server.header()
    assert result == {'jsonrpc': '2.0', 'id': 1234}


# Generated at 2022-06-23 14:12:11.439246
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    parser = JsonRpcServer()
    method = 'run_command'
    params = ['show version']
    id_ = 42
    request = {'method': method, 'params': [params, {}], 'id': id_}
    request = json.dumps(request)
    actual = parser.handle_request(request)
    expected = json.dumps({'id': id_, 'jsonrpc': '2.0', 'result': None})
    assert actual == expected

# Generated at 2022-06-23 14:12:12.035898
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    pass

# Generated at 2022-06-23 14:12:19.530364
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import time
    import unittest
    import os
    import platform
    import sys

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    item = {'name': 'test', 'age': 100}

    class MyModule(object):
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            pass

        def exit_json(self, changed=False, msg={}):
            if changed:
                print(json.dumps(msg, default=lambda x: "n/a"))
            else:
                print('{}')

        def fail_json(self, **msg):
            raise Exception(msg)


# Generated at 2022-06-23 14:12:26.227019
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonrpc = JsonRpcServer()
    try:
        raise ValueError("test")
    except Exception as e:
        error_msg = e.message
    ret = jsonrpc.internal_error(data=error_msg)
    expected = {'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}, 'id': None, 'jsonrpc': '2.0'}
    assert(ret == expected)

# Generated at 2022-06-23 14:12:35.244216
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # Dummy object is needed for running the unit test without having a real object
    class Dummy_JsonRpcServer(object):
        dummy = 1
    dummy = Dummy_JsonRpcServer
    # Call method of super class when running the unit test
    super(Dummy_JsonRpcServer, dummy).__init__()

    # Create instance of JsonRpcServer
    obj = JsonRpcServer()
    instance_of_JsonRpcServer = isinstance(obj, JsonRpcServer)
    # Test if instance was created successfully
    assert instance_of_JsonRpcServer is True

    # Test if internal_error() method returns a dictionary
    assert isinstance(obj.internal_error(), dict)

    # Test if internal_error() method returns a dictionary which has a member with key 'jsonrpc'


# Generated at 2022-06-23 14:12:39.706770
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    j = JsonRpcServer()
    class M(object):
        def hello(self, name):
            return "Hello %s" % name

    m = M()
    j.register(m)
    assert len(j._objects) == 1
    assert j._objects.pop() == m


# Generated at 2022-06-23 14:12:43.224201
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    '''
    Test for invalid_params method of JsonRpcServer class
    '''
    json_rpc_server_object = JsonRpcServer()
    response = json_rpc_server_object.invalid_params("data")
    assert response['error']['code'] == -32602

# Generated at 2022-06-23 14:12:50.408067
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(-32609, 'test_message')
    assert result['error']['code'] == -32609
    assert result['error']['message'] == 'test_message'
    result = server.error(-32600, 'test_message', 'test_data')
    assert result['error']['data'] == 'test_data'
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'test_message'

# Generated at 2022-06-23 14:12:54.919497
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    actual = server.error(code=100, message="message")
    expected = '{"id": null, "jsonrpc": "2.0", "error": {"code": 100, "message": "message", "data": null}}'
    assert actual == expected


# Generated at 2022-06-23 14:12:55.645077
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

# Generated at 2022-06-23 14:12:59.669279
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test = JsonRpcServer()
    result = test.invalid_request()
    assert result.get('error').get('code') == -32600
    assert result.get('error').get('message') == 'Invalid request'

# Generated at 2022-06-23 14:13:03.781732
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(1234, "test error message")
    assert result["jsonrpc"] == "2.0"
    assert result["error"]["code"] == 1234
    assert result["error"]["message"] == "test error message"


# Generated at 2022-06-23 14:13:07.364880
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    obj = object()
    our_object = object()
    server.register(obj)
    server.register(our_object)
    assert(obj in server._objects)
    assert(our_object in server._objects)


# Generated at 2022-06-23 14:13:11.704004
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc = JsonRpcServer()
    assert rpc.method_not_found() == {'id': None,
                                      'error': {'code': -32601,
                                                'message': 'Method not found'},
                                      'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:13:13.138183
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    print(server)

# Generated at 2022-06-23 14:13:17.116166
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'foo')
    assert server.header() == {'jsonrpc': '2.0', 'id': 'foo'}

# Generated at 2022-06-23 14:13:22.735545
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    assert server.invalid_params() == {
        'jsonrpc': '2.0',
        'id': '',
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': None
        }
    }

# Generated at 2022-06-23 14:13:24.814392
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None

# Generated at 2022-06-23 14:13:28.120716
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    js = JsonRpcServer()
    assert js.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:13:33.437541
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    data = {}
    jrs = JsonRpcServer()
    jrs._identifier = 123
    result = jrs.error(1,'test',data)
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 123
    assert result['error']['code'] == 1
    assert result['error']['message'] == 'test'
    assert result['error']['data'] == {}


# Generated at 2022-06-23 14:13:37.117734
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        server = JsonRpcServer()
        if not server:
            raise Exception
    except:
        print('JsonRpcServer test failure')
    else:
        print('JsonRpcServer test success')


# Generated at 2022-06-23 14:13:39.681359
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import requests
    json_rpc_server = JsonRpcServer()
    # Test for writing a unit test for register method of class JsonRpcServer
    json_rpc_server.register(requests)

# Generated at 2022-06-23 14:13:50.923140
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # input with parameters args and kwargs
    request = {"jsonrpc": "2.0", "method": "run_command", "params": ["show version", {}], "id": 6}
    request = json.dumps(request)
    jr = JsonRpcServer()
    jr.register(Test_Class())
    response = jr.handle_request(request)
    response_expected = {"error":{"message":"Method not found","code":-32601},"jsonrpc":"2.0","id":6}
    response_expected = json.dumps(response_expected)
    assert(response == response_expected)

    request = {"jsonrpc": "2.0", "method": "run_commands", "params": [["show version", {}]], "id": 6}
    request = json.dumps(request)

# Generated at 2022-06-23 14:13:55.225526
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs = JsonRpcServer()
    jrs._identifier = '1234'

    header = jrs.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == '1234'


# Generated at 2022-06-23 14:13:59.193914
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=999, message='Dummy error message')
    assert error['error']['code'] == 999
    assert error['error']['message'] == 'Dummy error message'


# Generated at 2022-06-23 14:14:03.609226
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_class = JsonRpcServer()
    setattr(test_class, '_identifier', 'abc123')
    result = test_class.header()
    assert result == {'jsonrpc': '2.0', 'id': 'abc123'}
    delattr(test_class, '_identifier')


# Generated at 2022-06-23 14:14:12.688025
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert(server)
    assert(hasattr(server, 'error'))
    assert(hasattr(server, 'invalid_request'))
    assert(hasattr(server, 'parse_error'))
    assert(hasattr(server, 'method_not_found'))
    assert(hasattr(server, 'internal_error'))
    assert(hasattr(server, 'response'))
    assert(hasattr(server, 'register'))
    assert(hasattr(server, 'handle_request'))


# Generated at 2022-06-23 14:14:16.791868
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    a = JsonRpcServer()
    result = a.invalid_params()
    expected = {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32602, 'message': 'Invalid params'}}
    assert result == expected



# Generated at 2022-06-23 14:14:18.584767
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # TODO: Write unit test
    print("Unit test for method handle_request of class JsonRpcServer")


# Generated at 2022-06-23 14:14:26.655050
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
	stderr = sys.stderr
	sys.modules.pop('traceback', None)
	from ansible.module_utils.network_common import ConnectionError
	Server = JsonRpcServer()
	error = Server.error(32767, 'Parse error')
	assert error == {'jsonrpc': '2.0', 'id': '*', 'error': {'data': None, 'message': 'Parse error', 'code': 32767}}


# Generated at 2022-06-23 14:14:31.366508
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpcServer = JsonRpcServer()
    jsonrpcServer._identifier = 1
    response = jsonrpcServer.response(result='result')
    expectedResponse = {'jsonrpc': '2.0', 'id': 1, 'result': 'result'}
    assert response == expectedResponse

# Generated at 2022-06-23 14:14:37.628133
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
   assert JsonRpcServer.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
   assert JsonRpcServer.parse_error({'data': 'data'}) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': {'data': 'data'}}}


# Generated at 2022-06-23 14:14:43.768046
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    class TestModule(AnsibleModule):
        @staticmethod
        def result_to_text(result):
            return cPickle.dumps(result, protocol=0)

        @staticmethod
        def text_to_result(text):
            return cPickle.loads(text)

    class TestConnection(Connection):
        @staticmethod
        def get_socket_path():
            return '/tmp/test.conn'

    # Create new JSONRPC server
    server = JsonRpcServer()
    # Register testConnection to the server
    server.register(TestModule)
    server.register(TestConnection)

    # Test rpc methods

# Generated at 2022-06-23 14:14:54.517596
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six.moves import socketserver
    from ansible.module_utils.netconf import *

    class Server(socketserver.ThreadingMixIn, socketserver.TCPServer):
        allow_reuse_address = True

    server = Server(('127.0.0.1', 0), Handler)

    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.start()

    time.sleep(1)

    socket_path = server.socket.getsockname()
    conn = Connection(socket_path)

    rpc = JsonRpcServer()

    # Test cases
    class TestObj:
        def foo(self):
            return 'this is foo'
    obj = TestObj()


# Generated at 2022-06-23 14:15:00.511992
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    # Setup
    obj = JsonRpcServer()
    obj.handle_request('{"jsonrpc": "2.0", "method": "abc", "params": [1,2,3], "id": 1}')
    expected = '{"jsonrpc": "2.0", "id": 1, "error": {"data": null, "code": -32601, "message": "Method not found"}}'

    # Execution
    actual = obj.method_not_found()

    # Assertion/Verification
    assert(actual == expected)


# Generated at 2022-06-23 14:15:06.647988
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # Tests if an error response is returned when an internal error occurs
    jrs = JsonRpcServer()
    id = 0
    jrs._identifier = id
    result = jrs.internal_error()
    expected_result = {'jsonrpc': '2.0', 'id': id,
                       'error': {'code': -32603, 'message': 'Internal error'}}
    assert result == expected_result

# Generated at 2022-06-23 14:15:14.050246
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpcs = JsonRpcServer()
    response = jrpcs.response()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == None
    assert 'result' not in response
    assert 'error' not in response

    try:
        jrpcs._identifier = 'ansible_test'
    except AttributeError:
        return
    response = jrpcs.response()
    assert response['id'] == 'ansible_test'
    assert 'result' not in response
    assert 'error' not in response

    response = jrpcs.response('test_result')
    assert response['id'] == 'ansible_test'
    assert response['result'] == 'test_result'
    assert 'error' not in response

    response = jrpcs.response

# Generated at 2022-06-23 14:15:21.240339
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc_obj = JsonRpcServer()
    obj_result = {"test": "result"}
    result = jsonrpc_obj.response(result=obj_result)
    assert result['id'] == 'None'
    assert result['result_type'] == 'pickle'
    assert result['result'] == b"\x80\x02}q\x00(X\x04\x00\x00\x00testq\x01X\x06\x00\x00\x00resultq\x02s."
    assert result['jsonrpc'] == '2.0'



# Generated at 2022-06-23 14:15:26.121508
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server.register(JsonRpcServer())
    assert json.loads(server.parse_error(data='test')) == {
        'error': {
            'code': -32700, 'message': 'Parse error', 'data': 'test'
        }, 'id': None, 'jsonrpc': '2.0'
    }


# Generated at 2022-06-23 14:15:30.881580
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error()
    assert response == {
                'jsonrpc': '2.0',
                'id': setattr(server, '_identifier'),
                'error': {
                    'code': -32603,
                    'message': 'Internal error',
                    'data': None
                }
            }

# Generated at 2022-06-23 14:15:33.994335
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    try:
        JSONRPC_Server_Object = JsonRpcServer()
        JSONRPC_Server_Object.invalid_request()
    except:
        return False
    else:
        return True


# Generated at 2022-06-23 14:15:39.620005
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert json.dumps(server.parse_error(data='test_data')) == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32700, "message": "Parse error", "data": "test_data"}}'
    assert json.dumps(server.method_not_found(data='test_data')) == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32601, "message": "Method not found", "data": "test_data"}}'

# Generated at 2022-06-23 14:15:41.038433
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc = JsonRpcServer()
    obj = object()
    jsonrpc.register(obj)
    assert (obj in jsonrpc._objects)

# Generated at 2022-06-23 14:15:48.726655
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

    # Check if the header method creates a header with the correct jsonrpc version
    header = server.header()
    equal = header == {'jsonrpc': '2.0', 'id': server._identifier}
    assert equal

    # Check if the response method creates a response with a result that is the same as the input
    result = "testresult"
    response = server.response(result)
    equal = response == {'jsonrpc': '2.0', 'id': server._identifier, 'result': result}
    assert equal

    # Check if the error method creates an error of type Internal error with the given message
    error = server.internal_error()

# Generated at 2022-06-23 14:15:55.178105
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()

    expected = {
        'error': {
            'code': -32700,
            'message': 'Parse error'
        },
        'id': None,
        'jsonrpc': '2.0'
    }

    assert result == expected


# Generated at 2022-06-23 14:15:58.085347
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    server.register(server)
    assert object == type(server)


# Generated at 2022-06-23 14:16:07.526415
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    class foo(object):
        def __init__(self, input1, input2):
            self.input1 = input1
            self.input2 = input2

        def test1(self):
            return self.input1

        def test2(self):
            return self.input2

        def test3(self, value):
            return value

        def test4(self, value=None):
            return value

        def test5(self, value=None, value2=None):
            return value

        def test7(self):
            return self.input1 + self.input2

        def test8(self, value=None):
            return value + 'test'

        def test9(self, value=None):
            return value

        def test10(self, value1=None):
            return value1


# Generated at 2022-06-23 14:16:15.446382
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    def __error(self):
        pass
    def __response(self):
        pass
    JsonRpcServer_instance = JsonRpcServer()
    JsonRpcServer_instance._error = __error
    JsonRpcServer_instance._response = __response
    request_instance = "not a real request"
    # Run test
    with pytest.raises(AttributeError) as excinfo:
        JsonRpcServer_instance.handle_request(request_instance)
    # Make sure we got what we havily deserved
    assert excinfo.value.args[0] == "'JsonRpcServer' object has no attribute '_identifier'"


# Generated at 2022-06-23 14:16:18.831190
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error", "data": null}, "id": null}'

# Generated at 2022-06-23 14:16:25.040544
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    """ Return the same error code and message for invalid_params """
    mock_server = JsonRpcServer()
    error = mock_server.invalid_params()
    assert error.get('jsonrpc') == '2.0'
    assert error.get('id') == None
    assert error.get('error').get('code') == -32602
    assert error.get('error').get('message') == 'Invalid params'

# Generated at 2022-06-23 14:16:30.037243
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrpc = JsonRpcServer()
    jrpc._identifier = 1
    result = jrpc.invalid_params()
    assert result == {'id': 1, 'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params'}}


# Generated at 2022-06-23 14:16:35.059307
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    import random
    import sys
    if sys.version_info[0] > 2:
        long = int
    identifier = random.getrandbits(31) - 2147483648
    server = JsonRpcServer()
    server._identifier = identifier
    header = server.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == identifier


# Generated at 2022-06-23 14:16:41.937133
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    __method__ = JsonRpcServer.error
    __obj__ = JsonRpcServer()

    code = -32001
    message = "Message for test"
    data = "Data for test"

    result = __method__(__obj__, code, message, data)

    assert result['code'] == code
    assert result['message'] == message
    assert result['data'] == data


# Generated at 2022-06-23 14:16:45.669107
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    try:
        server = JsonRpcServer()
        server.invalid_params()
        assert False
    except ConnectionError as e:
        assert e.response['error'].get('code') == -32602
        assert e.response['error'].get('message') == 'Invalid params'


# Generated at 2022-06-23 14:16:50.164173
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrs = JsonRpcServer()
    jrs._identifier = 'test'
    response = jrs.response('test')
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': '"test"'}


# Generated at 2022-06-23 14:16:52.544329
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test_object = JsonRpcServer()
    response = test_object.invalid_request()
    assert response['id'] == test_object._identifier
    assert response['error']['message'] == 'Invalid request'
    assert response['error']['code'] == -32600


# Generated at 2022-06-23 14:16:54.607583
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '12345')
    assert server.response() == {"id": "12345", "jsonrpc": "2.0"}


# Generated at 2022-06-23 14:16:57.413427
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        assert JsonRpcServer
    except NameError:
        print("JsonRpcServer not initialized")


# Generated at 2022-06-23 14:17:01.252982
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_obj = JsonRpcServer()
    test_obj._identifier = 3
    assert test_obj.header() == {'jsonrpc': '2.0', 'id': 3}



# Generated at 2022-06-23 14:17:05.407773
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert not server._objects
    server.register('obj1')
    server.register('obj2')
    assert server._objects == set(['obj1', 'obj2'])   
