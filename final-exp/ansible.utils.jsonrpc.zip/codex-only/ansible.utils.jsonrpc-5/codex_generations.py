

# Generated at 2022-06-23 14:07:05.947403
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    assert 1 == 1, 'test_JsonRpcServer_register for method register of class JsonRpcServer has not been implemented'



# Generated at 2022-06-23 14:07:07.057078
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    assert JsonRpcServer().response().has_key('jsonrpc')

# Generated at 2022-06-23 14:07:13.309459
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result == {"id": None, "jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}}

if __name__ == '__main__':
    test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:07:18.594286
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.parse_error()
    assert isinstance(result, dict)
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert result['error']['data'] is None


# Generated at 2022-06-23 14:07:22.297568
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    srv = JsonRpcServer()
    expected = {"jsonrpc": "2.0", "id": "jsontest", "error": {"code": -32700, "message": "Parse error"}}
    assert srv.parse_error() == expected


# Generated at 2022-06-23 14:07:28.771321
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    rpc_server.register(rpc_server)
    result = json.loads(rpc_server.handle_request('{}'))
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:07:37.221605
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.six import PY2
    import sys
    sys.path.append("/usr/lib/python2.7/site-packages/ansible")
    import ansible_module_jrpcserver
    if PY2:
        reload(ansible_module_jrpcserver)
    else:
        import importlib
        importlib.reload(ansible_module_jrpcserver)

    server = ansible_module_jrpcserver.JsonRpcServer()
    setattr(server, '_identifier', "0")
    result = server.header()
    print(result)



# Generated at 2022-06-23 14:07:39.459221
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test_obj = JsonRpcServer()
    ident_temp = 'test'
    setattr(test_obj, '_identifier', ident_temp)
    assert (test_obj.invalid_request() ==
            {'jsonrpc': '2.0', 'id': ident_temp, 'error': {'data': None, 'code': -32600, 'message': 'Invalid request'}})


# Generated at 2022-06-23 14:07:41.908363
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
  test = JsonRpcServer()
  response = test.method_not_found(data="TestData")
  if response["error"]["code"] == "-32601":
    assert True
  else:
      assert False

# Generated at 2022-06-23 14:07:43.989835
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    test = JsonRpcServer()
    assert test.invalid_request()['error']['code'] == -32600


# Generated at 2022-06-23 14:07:47.275611
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    json_rpc_server = JsonRpcServer()

    error = json_rpc_server.invalid_request()
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:07:56.275948
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Test with data not equal to None
    JsonRpcServerMock = JsonRpcServer()
    JsonRpcServerMock._identifier = 10
    result = JsonRpcServerMock.parse_error('data')
    assert result == "{\"jsonrpc\": \"2.0\", \"id\": 10, \"error\": {\"code\": -32700, \"message\": \"Parse error\", \"data\": \"data\"}}"
    # Test with data equal to None
    result = JsonRpcServerMock.parse_error()
    assert result == "{\"jsonrpc\": \"2.0\", \"id\": 10, \"error\": {\"code\": -32700, \"message\": \"Parse error\"}}"


# Generated at 2022-06-23 14:08:00.936572
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc = JsonRpcServer()
    setattr(rpc, '_identifier', 1)
    data = {'code': -32602,
            'id': 1,
            'error': {'code': -32602, 'message': 'Invalid params', 'data': None},
            'jsonrpc': '2.0'}
    assert rpc.invalid_params() == data

# Generated at 2022-06-23 14:08:02.644823
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
  request = "test"
  with pytest.raises(AttributeError):
    JsonRpcServer.register(request)



# Generated at 2022-06-23 14:08:10.882934
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    object_client = JsonRpcServer()
    result = json.loads(object_client.handle_request("""{
          "jsonrpc": "2.0",
          "method": "method_not_found",
          "params": ["test"],
          "id": 1
        }"""))
    assert result['id'] == 1
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:08:12.921962
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    test_srv = JsonRpcServer()
    assert test_srv._objects == set()


# Generated at 2022-06-23 14:08:18.635368
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrpc = JsonRpcServer()
    assert jrpc.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert jrpc.parse_error(data="any data") == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'any data'}}


# Generated at 2022-06-23 14:08:29.417543
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = "12345"

    expected = '{"jsonrpc": "2.0", "id": "12345", "result": "abc"}'
    assert json.dumps(rpc_server.response("abc")) == expected

    expected = '{"jsonrpc": "2.0", "id": "12345", "result_type": "pickle", "result": "gAJ9cQAoVQByAGMAcgBvAG4AdAAoACAAVwBpAHQAaQBlAG4AdAAgAG8AdQBuAGQAZQByACAAQwByAGUAZABlAG4AdAAuAA=="}'
    assert json.dumps(rpc_server.response({"foo": "bar"}))

# Generated at 2022-06-23 14:08:32.469885
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()

    assert(result == {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": 0})


# Generated at 2022-06-23 14:08:37.529666
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request_dict = {"method": "example"}
    request_str = b'{"method": "example"}'
    server = JsonRpcServer()

    # generate a test class and register it in the JsonRpcServer class
    class TestClass:
        def example(self):
            return "pass"

    test_instance = TestClass()
    server.register(test_instance)

    # check to make sure that with a dictionay input it returns a JSON object
    assert json.loads(server.handle_request(request_dict))
    
    # make sure that with a string input it returns a JSON object
    assert json.loads(server.handle_request(request_str))


# Generated at 2022-06-23 14:08:38.141973
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert issubclass(JsonRpcServer, object)


# Generated at 2022-06-23 14:08:41.691154
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    for key in attr_dict:
        actual = json.loads(server.handle_request(key))
        assert actual == attr_dict[key]
        print("Test execute successfully")

if __name__ == "__main__":
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-23 14:08:46.066685
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_object = JsonRpcServer()
    assert test_object.internal_error() == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error'}, 'id': ''}


# Generated at 2022-06-23 14:08:49.612784
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Given
    expected_response = {
        'jsonrpc': '2.0',
        'id': 5
    }

    # When
    server = JsonRpcServer()
    setattr(server, '_identifier', 5)
    response = server.header()

    # Then
    assert response == expected_response


# Generated at 2022-06-23 14:08:59.532863
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Instantiate JsonRpcServer
    j = JsonRpcServer()
    req = json.dumps({
        'jsonrpc': '2.0',
        'method': '_test',
        'params': [],
        'id': 1
    })
    # Test method with invalid request
    assert j.handle_request(req) == json.dumps(j.invalid_request(req))
    # Test method with method not found
    req = json.dumps({
        'jsonrpc': '2.0',
        'method': '__invalid_method__',
        'params': [],
        'id': 1
    })
    assert j.handle_request(req) == json.dumps(j.method_not_found(req))


# Generated at 2022-06-23 14:09:04.142486
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    setattr(server, "_identifier", "any_identifier")
    result = server.invalid_request()
    assert result == {'error': {'code': -32600, 'message': 'Invalid request'}, 'id': 'any_identifier', 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:09:13.708738
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # pass code and message into method error
    server = JsonRpcServer()
    assert server.error(-1, 'test') == {'jsonrpc': '2.0', 'id': None,
                                        'error': {'code': -1, 'message': 'test'}}

    # pass code and message and data into method error
    assert server.error(-1, 'test', 'test') == {'jsonrpc': '2.0', 'id': None,
                                                'error': {'code': -1, 'message': 'test',
                                                          'data': 'test'}}

    # pass code and message and data into method error

# Generated at 2022-06-23 14:09:25.595107
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()

    # test code -32700
    result1 = server.error(code=-32700, message="Parse error", data=None)
    assert result1['error']['code'] == -32700
    assert result1['error']['message'] == "Parse error"
    assert result1['id'] == server._identifier

    # test code -32601
    result2 = server.error(code=-32601, message="Method not found", data=None)
    assert result2['error']['code'] == -32601
    assert result2['error']['message'] == "Method not found"
    assert result2['id'] == server._identifier

    # test code -32600
    result3 = server.error(code=-32600, message="Invalid request", data=None)


# Generated at 2022-06-23 14:09:29.982458
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request(data='Invalid Request')
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'
    assert result['error']['data'] == 'Invalid Request'



# Generated at 2022-06-23 14:09:36.943268
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()

    class TestObject(object):
        def hello(self, name):
            return 'Hello %s' % name

    json_rpc_server.register(TestObject())

    request = to_text(json.dumps({
        'method': 'hello',
        'params': ['Ansible']
    }))
    response = json_rpc_server.handle_request(request)

    assert json.loads(response) == {'id': None, 'jsonrpc': '2.0', 'result': 'Hello Ansible'}

# Generated at 2022-06-23 14:09:40.536984
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()
    assert result == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32700,
            'message': 'Parse error',
            'data': None,
        }
    }


# Generated at 2022-06-23 14:09:52.616344
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import pytest


# Generated at 2022-06-23 14:09:55.164277
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    import json

    jrs = JsonRpcServer()

    # set _identifier
    jrs._identifier = "id_value"

    # call header() method
    response = jrs.header();
    assert response['id'] == 'id_value'
    assert response['jsonrpc'] == '2.0'

# Generated at 2022-06-23 14:09:57.594232
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc_server = JsonRpcServer()
    class Test:
        def echo(self, text):
            return text

    test = Test()
    rpc_server.register(test)
    assert test in rpc_server._objects

# Generated at 2022-06-23 14:10:01.015998
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()
    assert result == {'error': {'code': -32700, 'message': 'Parse error'}, 'id': '', 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:10:13.179335
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result_str = "hello"
    result_list = ["hello","world"]
    result_dic = {"hello":"world","world":"hello"}
    server._identifier = "0"
    response = server.response(result_str)
    assert "jsonrpc" in response and "result" in response
    assert response["result"] == "hello"
    response = server.response(result_list)
    assert "jsonrpc" in response and "result" in response
    assert response["result"] == "S'\\x80\\x02]q\\x00." and "result_type" in response
    response = server.response(result_dic)
    assert "jsonrpc" in response and "result" in response

# Generated at 2022-06-23 14:10:15.909514
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    assert obj._objects == set()
    class Test:
        pass
    obj.register(Test())
    assert obj._objects == set([Test()])


# Generated at 2022-06-23 14:10:19.212406
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params("data")
    if error["error"]["code"] != -32602:
        print("Invalid error code")
    if error["error"]["message"] != 'Invalid params':
        print("Invalid error message")
    if error["error"]["data"] != "data":
        print("Invalid error data")

# Generated at 2022-06-23 14:10:27.311693
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    type = "pickle"
    result =  "b'c__builtin__\np0\n(S'foobar'\np1\ntp2\nRp3\n."
    JsonRpcServer.header = classmethod(lambda cls: {'jsonrpc': '2.0', 'id': '1'})
    assert JsonRpcServer.response(result) == {'jsonrpc': '2.0', 'id': '1', 'result_type': type, 'result': result}


# Generated at 2022-06-23 14:10:30.564973
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()

    assert len(obj._objects) == 0
    obj.register(obj)
    assert len(obj._objects) == 1
    obj.register(obj)
    assert len(obj._objects) == 1


# Generated at 2022-06-23 14:10:36.005037
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    expected = {'result': None, 'jsonrpc': '2.0', 'id': '1234', 'error': {'message': 'Internal error', 'code': -32603}}
    data = 'this is just a test'
    result = server.internal_error(data)
    assert result == expected

# Generated at 2022-06-23 14:10:42.498423
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc = JsonRpcServer()
    setattr(jsonrpc, '_identifier', 12345)
    res = jsonrpc.response()
    assert res['jsonrpc'] == '2.0'
    assert res['id'] == 12345
    assert 'result' not in res
    assert 'error' not in res
    res = jsonrpc.response(result=u"Test")
    assert res['result'] == u"Test"
    res = jsonrpc.response(result=123)
    assert res['result'] == 'I123\n.'
    assert res['result_type'] == 'pickle'

# Generated at 2022-06-23 14:10:51.533674
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    class TestJsonRpcServer(JsonRpcServer):

        def __init__(self):
            self._objects = set("")

        @property
        def _identifier(self):
            return "test_id"

    jrs = TestJsonRpcServer()

    v = jrs.internal_error("File not found")
    assert v["jsonrpc"] == "2.0"
    assert v["id"] == "test_id"
    assert v["error"]["code"] == -32603
    assert v["error"]["message"] == "Internal error"
    assert v["error"]["data"] == "File not found"


# Generated at 2022-06-23 14:10:57.242213
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    env = {}
    rpc = JsonRpcServer()

    response = rpc.internal_error()
    assert response["id"] == None
    assert response["jsonrpc"] == "2.0"
    assert response["error"]["code"] == -32603
    assert response["error"]["message"] == "Internal error"


# Generated at 2022-06-23 14:11:05.501270
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_method_success = lambda: 'success'
    rpc_method_failure = lambda: 1/0

    class RPC_Methods_Fixture(object):
        rpc_method_success = rpc_method_success
        rpc_method_failure = rpc_method_failure

    rpc_server = JsonRpcServer()
    rpc_server.register(RPC_Methods_Fixture())

    # Test with a successful method invocation
    request = {'id': '1', 'method': 'rpc_method_success'}
    response = rpc_server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert 'result' in response
    assert response['result'] == 'success'

    # Test with a method invocation that fails

# Generated at 2022-06-23 14:11:10.050327
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server._objects = set()
    obj1 = 1
    obj2 = "s"
    server.register(obj1)
    server.register(obj2)
    assert server._objects == set([obj1, obj2])

# Generated at 2022-06-23 14:11:13.521887
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    client = JsonRpcServer()
    obj_a = {'jsonrpc': '1.0', 'id': 1, 'params': [], 'result': 'success'}
    assert client.error(1, "this is an error") == obj_a

# Generated at 2022-06-23 14:11:17.683155
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jr = JsonRpcServer()
    jr._identifier = '1234'
    error = jr.error(404, 'Not Found')
    assert error == {"jsonrpc": "2.0", "id": "1234", "error": {
                    "code": 404, "message": "Not Found"}}

# Generated at 2022-06-23 14:11:27.405664
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import io

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.result = {}

        def save_config(self, *args, **kwargs):
            return args, kwargs

    module = TestModule()

    server = JsonRpcServer()
    server.register(module)

    request = {
        'jsonrpc': '2.0',
        'id': 'test',
        'method': 'save_config',
        'params': [[], {'force': True}]
    }

    result = server.handle_request(io.BytesIO(json.dumps(request).encode('utf-8')))


# Generated at 2022-06-23 14:11:37.796095
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # to_text used for json loads to handle non utf-8 encoded strings
    # it used ansible.module_utils._text._to_text(value, errors='surrogate_or_strict', nonstring='passthru').
    # For Python 3, it always used errors = 'surrogate_or_strict'
    # For Python 2, it used errors = 'strict' if errors is not specified
    # For Python 2, to_text used cPickle to serialize non string data

    # For Python 3:
    # Test 1: Invalid data type
    json_data = json.dumps({'method': 'invalid_params'})
    server = JsonRpcServer()
    # json.loads(json_data) return type is dict
    result = server.handle_request(json_data)
    # json.

# Generated at 2022-06-23 14:11:39.301394
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server._objects == set()

# Generated at 2022-06-23 14:11:47.521859
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server = JsonRpcServer()
    setattr(json_rpc_server, '_identifier', "1")
    response = json_rpc_server.response()
    assert response == {'jsonrpc': '2.0', 'id': '1', 'result': ''}
    response = json_rpc_server.response(result="result")
    assert response == {'jsonrpc': '2.0', 'id': '1', 'result': 'result'}


# Generated at 2022-06-23 14:11:50.136051
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    my_class = JsonRpcServer()
    assert my_class.internal_error()["result_type"] == "error"



# Generated at 2022-06-23 14:11:56.543373
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jrs = JsonRpcServer()
    class Obj1:
        def foo(self):
            return 'bar'
    class Obj2:
        def foo(self):
            return 'baz'
    obj = Obj1()
    jrs.register(obj)
    assert jrs._objects.pop() is obj


# Generated at 2022-06-23 14:12:00.717769
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=200, message='message')
    assert error['jsonrpc'] == '2.0'
    assert error['id'] == None
    assert error['error']['code'] == 200
    assert error['error']['message'] == 'message'
    assert error['error']['data'] == None

# Generated at 2022-06-23 14:12:06.639947
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    input = '{"jsonrpc":"2.0","method":"test_method","params":"test_string","id":1}'
    output = JsonRpcServer().handle_request(input)
    expected = '{"jsonrpc": "2.0", "id": 1, "result": "test_string"}'
    assert output == expected
    assert isinstance(output, text_type)


# Generated at 2022-06-23 14:12:09.303929
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    setattr(server, '_identifier', "123")
    method = '_foo'
    result = server.method_not_found(data = method)
    assert result == {'jsonrpc': '2.0', 'id': '123', 'error': {'code': -32601,
        'message': 'Method not found', 'data': '_foo'}}

# Generated at 2022-06-23 14:12:18.534735
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'abc123')

    # test result is bytes
    result = b'I am bytes'
    response = server.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'abc123'
    assert response['result_type'] == 'pickle'
    assert response['result'] == 'I am bytes'

    # test result is str
    result = 'I am str'
    response = server.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'abc123'
    assert response['result_type'] == 'str'
    assert response['result'] == 'I am str'

    # test result is un-encodable

# Generated at 2022-06-23 14:12:29.218745
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.parse_error().get('error', {}).get('code') == -32700
    assert server.parse_error().get('error', {}).get('message') == "Parse error"
    assert server.invalid_request().get('error', {}).get('code') == -32600
    assert server.invalid_request().get('error', {}).get('message') == "Invalid request"
    assert server.invalid_params().get('error', {}).get('code') == -32602
    assert server.invalid_params().get('error', {}).get('message') == "Invalid params"
    assert server.internal_error().get('error', {}).get('code') == -32603

# Generated at 2022-06-23 14:12:34.028994
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=-1, message="abcd")
    assert error == {"jsonrpc": "2.0", "id": -1, "error": {"code": -1, "message": "abcd"}}

# Generated at 2022-06-23 14:12:38.316581
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    error = rpc_server.invalid_params()
    assert json.dumps(error) == '{"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params"}, "id": null}'

# Generated at 2022-06-23 14:12:43.825641
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class test_JsonRpcServer_method_not_found_class:
        pass
    obj = JsonRpcServer()
    obj.register(test_JsonRpcServer_method_not_found_class())
    result = obj.method_not_found(data=None)
    assert result == {'jsonrpc': '2.0', 'id': obj._identifier, 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}


# Generated at 2022-06-23 14:12:45.607999
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

# Generated at 2022-06-23 14:12:48.662435
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import pytest
    with pytest.raises(AssertionError) as excinfo:
        self = JsonRpcServer()
        assert self.internal_error(data=None)== -32603

# Generated at 2022-06-23 14:12:54.125534
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    s = JsonRpcServer()
    result = s.invalid_params()
    assert result == {'id': '<unknown>',
                      'jsonrpc': '2.0',
                      'error': {'code': -32602,
                                'data': None,
                                'message': 'Invalid params'}}


# Generated at 2022-06-23 14:12:57.551512
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}}

# Generated at 2022-06-23 14:13:00.020150
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    test_obj = 'test'
    j = JsonRpcServer()
    j.register(test_obj)

    assert test_obj in j._objects

# Generated at 2022-06-23 14:13:03.733356
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=1, message="test")
    assert error == {"jsonrpc": "2.0", "error": {"code": 1, "message": "test"}, "id": None}


# Generated at 2022-06-23 14:13:05.413712
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:13:06.276713
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

# Generated at 2022-06-23 14:13:09.333934
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request = {
        "method": "rpc.method",
        "id": 1
    }
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response["error"]["code"] == -32600
    assert response["error"]["message"] == "Invalid request"

# Generated at 2022-06-23 14:13:14.448936
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server._identifier = "12345"
    json_resp = server.internal_error(data=None)
    assert isinstance(json_resp, dict)
    assert json_resp['id'] == "12345"
    assert json_resp['error']['code'] == -32603
    assert json_resp['error']['message'] == 'Internal error'


# Generated at 2022-06-23 14:13:17.266732
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert repr(server) == 'JsonRpcServer()'
    assert len(server._objects) == 0

# Generated at 2022-06-23 14:13:19.449442
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj.register('ansible')
    assert len(obj._objects) == 1


# Generated at 2022-06-23 14:13:26.160010
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 1)
    response = rpc_server.error(code=123, message='test message', data='test data')
    assert response == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': 123, 'message': 'test message', 'data': 'test data'}}


# Generated at 2022-06-23 14:13:29.078298
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    jsr = JsonRpcServer()
    jsr._identifier = "2345"
    assert jsr.header() == {'jsonrpc': '2.0', 'id': "2345"}


# Generated at 2022-06-23 14:13:37.980455
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request({"key":"value"})
    if result['error']['code'] == -32600 and result['error']['message'] == 'Invalid request' and result['error']['data'] == {"key":"value"}:
        return True
    else:
        return False

if __name__ == "__main__":
    result = test_JsonRpcServer_invalid_request()
    if result:
    	print("Function invalid_request of class JsonRpcServer works as expected. Test passed")
    else:
    	print("Function invalid_request of class JsonRpcServer does not work as expected. Test failed")

# Generated at 2022-06-23 14:13:39.518015
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    s = JsonRpcServer()
    assert isinstance(s, JsonRpcServer)


# Generated at 2022-06-23 14:13:46.037899
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    method = 'test_method'
    expected = {
        'id': 1234,
        'jsonrpc': '2.0',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }
    jrs = JsonRpcServer()
    setattr(jrs, '_identifier', 1234)
    response = jrs.method_not_found(data=None)
    assert response == expected


# Generated at 2022-06-23 14:13:57.163718
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    print("\nIn subroutine: test_JsonRpcServer_parse_error")

    rpcserver = JsonRpcServer()

    response = rpcserver.parse_error()
    assert response['error']['code'] == -32700
    print('Test passed: response code is -32700')

    response = rpcserver.parse_error(data='Invalid or malformed JSON')
    assert response['error']['code'] == -32700
    print('Test passed: response code is -32700')
    assert response['error']['data'] == 'Invalid or malformed JSON'
    print('Test passed: data is Invalid or malformed JSON')

    print('All tests in subroutine passed')


# Generated at 2022-06-23 14:14:03.997875
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, Mock

    mock_dict = MagicMock()
    mock_dict.get.side_effect = [{u'id': 1, u'method': u'rpc.start', u'params': [[u'a', u'b', u'c'], {}]}]

    type(mock_dict).__repr__ = MagicMock(return_value="{'method': 'rpc.start', 'params': [['a', 'b', 'c'], {}]}")
    type(mock_dict).__str__ = Mock(return_value="{'method': 'rpc.start', 'params': [['a', 'b', 'c'], {}]}")

    json.loads.side_effect

# Generated at 2022-06-23 14:14:15.986620
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from .connection import Connection
    from .devices import CollectorDevice
    from .junos import JunosModule
    from .facts import Facts
    from .resources import Command
    import sys

    connection_object = Connection()
    device_object = CollectorDevice(host='localhost', port=22,
                                    user='test', password='test123')

    device_object = CollectorDevice(host='localhost', port=22,
                                    user='test', password='test123')

    class ModuleObj(JunosModule):
        def __init__(self, *args, **kwargs):
            self.argument_spec = dict()
            for param in ['host', 'user', 'password', 'port']:
                self.argument_spec[param] = dict()
            super(ModuleObj, self).__init__(*args, **kwargs)
            self._connection

# Generated at 2022-06-23 14:14:18.381994
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 'test'
    assert server.header() == {'jsonrpc': '2.0', 'id': 'test'}


# Generated at 2022-06-23 14:14:23.479082
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    result = JsonRpcServer().invalid_request()
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request', 'data': None}}

# Generated at 2022-06-23 14:14:28.529721
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    """
    Test method JsonRpcServer.internal_error
    """

    obj = JsonRpcServer()
    obj._identifier = '1'
    assert obj.internal_error() == \
        {"id": "1", "jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}}


__all__ = ['JsonRpcServer']

# Generated at 2022-06-23 14:14:29.466834
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()


# Generated at 2022-06-23 14:14:33.777671
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    response = server.response('test')
    assert response == {'jsonrpc': '2.0', 'id': 1, 'result': 'test'}

# Generated at 2022-06-23 14:14:38.716757
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'foo_id'
    result = server.error(123, 'foo_message', 'foo_data')
    expected = {'jsonrpc': '2.0',
                'id': 'foo_id',
                'error': {'code': 123,
                          'message': 'foo_message',
                          'data': 'foo_data'}}

    assert result == expected

# Generated at 2022-06-23 14:14:42.219515
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert JsonRpcServer().method_not_found() == {'id': None, 'jsonrpc': '2.0', 'error': {'message': 'Method not found', 'code': -32601}}

# Generated at 2022-06-23 14:14:47.474033
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    try:
        server = JsonRpcServer()
        request = {}
        request['id'] = 1
        request['method'] = 'rpc.exists'
        request['params'] = []
        server.handle_request(json.dumps(request))
    except Exception as e:
        if e.errno is not 0:
            raise

# Generated at 2022-06-23 14:14:51.501878
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrs = JsonRpcServer()
    assert jrs.error(code=123, message="test") == {
        'jsonrpc': '2.0',
        'error': {'code': 123, 'message': 'test'},
        'id': None
    }



# Generated at 2022-06-23 14:14:56.492908
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    j = JsonRpcServer()
    error = j.method_not_found()
    assert error["error"]["code"] == -32601
    assert error["error"]["message"] == 'Method not found'
    assert error["jsonrpc"] == '2.0'
    assert error["id"] == 'None'
    assert "result" not in error


# Generated at 2022-06-23 14:14:57.442350
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()


# Generated at 2022-06-23 14:14:59.788321
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    response = server.parse_error()
    assert response["error"] == {'code': -32700, 'message': 'Parse error'}


# Generated at 2022-06-23 14:15:10.187546
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc = JsonRpcServer()
    s = rpc.response(result="textdata")
    assert(s == "{'jsonrpc': '2.0', 'id': None, 'result': 'textdata'}")
    j = json.dumps(s)
    r = json.loads(j)
    assert(r == {'jsonrpc': '2.0', 'id': None, 'result': 'textdata'})

    s = rpc.response(result=b"binarydata")
    assert(s == "{'jsonrpc': '2.0', 'result': 'binarydata', 'id': None, 'result_type': 'pickle'}")
    j = json.dumps(s)
    r = json.loads(j)

# Generated at 2022-06-23 14:15:16.470246
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'identifier')
    result = 'result'
    response = server.response(result)
    assert response == {
        'jsonrpc': '2.0',
        'id': 'identifier',
        'result': result,
    }


# Generated at 2022-06-23 14:15:22.194579
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    try:
        print (server.invalid_params())
    except:
        print ("Please do not put print statements in public methods of this class")

if __name__ == '__main__':
    test_JsonRpcServer_invalid_params()

# Generated at 2022-06-23 14:15:24.866438
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 1
    result = server.header()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 1


# Generated at 2022-06-23 14:15:34.849914
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    server = JsonRpcServer()

    class TestModule(object):
        def __init__(self, server=None):
            self.server = server

        def rpc_test(self, *args, **kwargs):
            return self.server.response('test response')

    class TestConnection(Connection):
        def __init__(self):
            self.server = server

        def connection(self):
            return self

        def send_request(self, request):
            return self.server.handle_request(request)

        def close(self):
            pass

    connection = TestConnection()

    module = AnsibleModule(connection=connection)
    server.register(module)

# Generated at 2022-06-23 14:15:45.119916
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    try:
        display.vvv("Start test of method method_not_found of class JsonRpcServer.")
        obj = JsonRpcServer()
        obj.handle_request('{"id": 1, "jsonrpc": "2.0", "method": "method_not_found", "params": []}')
    except Exception as e:
        display.vvv("test of method method_not_found of class JsonRpcServer failed!")
        display.vvv(e)
    else:
        display.vvv("test of method method_not_found of class JsonRpcServer succeed!")


# Generated at 2022-06-23 14:15:48.735190
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Creates a new instance of JsonRpcServer
    instance = JsonRpcServer()

    # Invoke method
    result = instance.parse_error()
    assert result == {'jsonrpc': '2.0', 'id': instance._identifier, 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:16:00.799173
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    posts = {
        "id": "1",
        "jsonrpc": "2.0",
        "method": "mock_get_facts",
        "params": {
            "host": "test_host",
            "port": "test_port",
            "username": "test_username",
            "password": "test_password"
        }
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json"
    }

# Generated at 2022-06-23 14:16:05.637784
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    """Unit test for method invalid_params of class JsonRpcServer"""
    result = -32602
    assert JsonRpcServer.invalid_params({'code': result, 'message': 'Invalid params'}) == {'_identifier': '~', 'error': {'code': result, 'message': 'Invalid params'}, 'jsonrpc': '2.0'}



# Generated at 2022-06-23 14:16:10.126719
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = '12345'
    result = rpc_server.invalid_params(data='Something went wrong')
    expected = '{"jsonrpc": "2.0", "id": "12345", "error": {"code": -32602, "message": "Invalid params", "data": "Something went wrong"}}'
    assert result == expected

# Generated at 2022-06-23 14:16:10.891099
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()


# Generated at 2022-06-23 14:16:16.826443
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrpcs = JsonRpcServer()
    jrpcs.register(jrpcs)
    jrpcs.register(jrpcs)

    setattr(jrpcs, '_identifier', 'ansible-connection')

    # error(self, code, message, data=None):
    result = jrpcs.error(888, 'Invalid params')

    # expected result
    exp_result = dict(
            jsonrpc='2.0',
            id='ansible-connection',
            error={'code': 888, 'message': 'Invalid params'}
            )

    assert result == exp_result


# Generated at 2022-06-23 14:16:22.893198
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc = JsonRpcServer()
    class test_register:
        name = 'test_register'

    test_register_instance = test_register()
    num_objects = len(jsonrpc._objects)
    jsonrpc.register(test_register_instance)
    assert len(jsonrpc._objects) == num_objects + 1



# Generated at 2022-06-23 14:16:33.328226
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    obj = JsonRpcServer()

# Generated at 2022-06-23 14:16:34.131690
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc = JsonRpcServer()


# Generated at 2022-06-23 14:16:41.249440
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpcsrv = JsonRpcServer()
    result = rpcsrv.parse_error(data=None)
    assert result == {
                    'jsonrpc': '2.0',
                    'id': '0',
                    'error': {
                        'code': -32700,
                        'message': 'Parse error',
                        'data': None
                        }
                    }

# Generated at 2022-06-23 14:16:46.005610
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    request = '{"jsonrpc": "2.0", "method": "add", "params": [1,2], "id": 2}'
    server = JsonRpcServer()

    # test
    assert server.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 2}'

# Generated at 2022-06-23 14:16:48.101318
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-23 14:16:59.413554
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with no result
    request = '{"jsonrpc": "2.0", "method": "rpc.success", "id": 100}'
    response = '{"jsonrpc": "2.0", "id": 100, "result": ""}'
    assert JsonRpcServer().handle_request(request) == response

    # Test with result
    request = '{"jsonrpc": "2.0", "method": "rpc.success", "id": 100}'
    response = '{"jsonrpc": "2.0", "id": 100, "result": "success"}'
    assert JsonRpcServer().handle_request(request) == response

    # Test with error
    request = '{"jsonrpc": "2.0", "method": "rpc.failure", "id": 100}'
    response

# Generated at 2022-06-23 14:17:03.958004
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    srv = JsonRpcServer()
    srv._identifier = '2'
    res = srv.invalid_params()
    assert res == {
        "jsonrpc": "2.0",
        "id": "2",
        "error": {
            "code": -32602,
            "message": "Invalid params",
        }
    }


# Generated at 2022-06-23 14:17:09.093879
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    message = "Internal Error Message"
    response = server.internal_error(message)
    assert response["error"]["code"] == -32603
    assert response["error"]["message"] == "Internal error"
    assert response["error"]["data"] == "Internal Error Message"
    assert response["id"] is None
    assert response["jsonrpc"] == "2.0"
    assert response["result"] is None
