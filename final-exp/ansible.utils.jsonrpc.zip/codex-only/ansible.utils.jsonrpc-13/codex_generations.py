

# Generated at 2022-06-23 14:07:07.319275
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpc_server = JsonRpcServer()
    testing_dict = {'jsonrpc': '2.0', 'id': '0', 'error':
                    {'code': -32603, 'message': 'Internal error', 'data': None}}
    assert jsonrpc_server.error(-32603, 'Internal error') == testing_dict

# Generated at 2022-06-23 14:07:10.963858
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error["error"]["code"] == -32602

# Generated at 2022-06-23 14:07:14.497415
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    import unittest
    test = unittest.TestCase()
    server = JsonRpcServer()
    test.assertIsInstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:07:18.181918
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import pytest

    def test_invalid_params():
        server = JsonRpcServer()
        error = server.invalid_params()

        assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}}

# Generated at 2022-06-23 14:07:21.788389
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServer = JsonRpcServer()
    response = jsonRpcServer.invalid_params('params is empty')
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'
    assert response['error']['data'] == 'params is empty'


# Generated at 2022-06-23 14:07:26.987417
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    # check error['code'] == -32600
    assert error["error"]["code"] == -32600
    # check error['message'] == 'Invalid request'
    assert error["error"]["message"] == 'Invalid request'

# Generated at 2022-06-23 14:07:37.826574
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    class JsonRpcServer_internal_error(object):
        def handle_request(self, request):
            request = json.loads(to_text(request, errors='surrogate_then_replace'))

            method = request.get('method')

            if method.startswith('rpc.') or method.startswith('_'):
                error = self.invalid_request()
                return json.dumps(error)

            args, kwargs = request.get('params')
            setattr(self, '_identifier', request.get('id'))

            rpc_method = None
            for obj in self._objects:
                rpc_method = getattr(obj, method, None)
                if rpc_method:
                    break

            if not rpc_method:
                error = self.method_not

# Generated at 2022-06-23 14:07:44.857789
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Prepare test object
    JsonRpcServer_test = JsonRpcServer()
    # Test whether method handle_request of class JsonRpcServer raises exception with correct error code and message
    # on a failure to create response
    try:
        req = None
        JsonRpcServer_test.handle_request(req)
        assert False
    except ValueError as e:
        assert True
    except:
        assert False
    # Test whether method handle_request of class JsonRpcServer raises exception with correct error code and message
    # on a failure to create error
    try:
        req = 'test_string'
        JsonRpcServer_test.handle_request(req)
        assert False
    except ValueError as e:
        assert True
    except:
        assert False

# Generated at 2022-06-23 14:07:52.178731
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    server.register(JsonRpc())
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'test', 'params': [['arg1', 'arg2']]}
    response = server.handle_request(request)
    expected_response = {'jsonrpc': '2.0', 'id': '1', 'error': {
        'code': -32602, 'message': 'Invalid params', 'data': 'too many arguments for test()'}}
    assert json.dumps(response) == json.dumps(expected_response)


# Generated at 2022-06-23 14:07:53.702654
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()


# Generated at 2022-06-23 14:08:02.386783
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    import unittest
    import pytest
    import ansible.module_utils.basic
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            raise Exception(kwargs)
    class MockBundle(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            raise Exception(kwargs)
    class MockConnection(object):
        def __init__(self, **kwargs):
            self.params = kwargs
    class MockConfig(object):
        def __init__(self, **kwargs):
            self.params = kwargs

# Generated at 2022-06-23 14:08:03.672451
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server

# Generated at 2022-06-23 14:08:10.100009
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Test(object):
        def echo(self, *args, **kwargs):
            return "test"
    server.register(Test())
    assert server.handle_request(json.dumps({"jsonrpc": "2.0", "method": "echo"})) == json.dumps({"jsonrpc": "2.0", "result": "test", "id": None})


# Generated at 2022-06-23 14:08:11.170558
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()


# Generated at 2022-06-23 14:08:17.872206
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_server = JsonRpcServer()
    error = test_server.internal_error(data='Unit test for method internal_error of class JsonRpcServer')
    assert error == {'jsonrpc': '2.0', 'id': 'test_JsonRpcServer', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'Unit test for method internal_error of class JsonRpcServer'}}
    print("JsonRpcServer.internal_error() unit test PASSED")



# Generated at 2022-06-23 14:08:24.029808
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrpc = JsonRpcServer()
    response = jrpc.handle_request('{"jsonrpc": "2.0", "method": "foobar, "params": "bar", "baz')
    response = json.loads(response)
    assert response["error"]["code"] == -32600
    assert response["error"]["message"] == "Invalid request"



# Generated at 2022-06-23 14:08:31.484274
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Test with no data
    server = JsonRpcServer()
    res = server.parse_error()
    assert res == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32700, 'message': 'Parse error'}}

    # Test with data
    server = JsonRpcServer()
    res = server.parse_error("something")
    assert res == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'something'}}


# Generated at 2022-06-23 14:08:40.324144
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import sys
    import os
    import pytest

    sys.path.append(os.path.join(os.path.dirname(__file__), '../lib'))

    from jsonrpc.jsonrpc2 import JsonRpcServer

    j = JsonRpcServer()
    j._identifier = "100"
    result = '2018-01-13T13:58:56Z'

    response = j.response(result)
    response_obtained = json.dumps(response)
    response_expected = '{"jsonrpc": "2.0", "id": "100", "result": "2018-01-13T13:58:56Z"}'

    assert response_obtained == response_expected
    assert response_obtained == response_expected


# Generated at 2022-06-23 14:08:43.842306
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    ins = JsonRpcServer()
    response = ins.method_not_found()
    assert response == {'jsonrpc': '2.0', 'id': None,
                        'error': {'code': -32601, 'message': 'Method not found'}}

# Generated at 2022-06-23 14:08:45.926322
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    a = JsonRpcServer()
    a.internal_error()


# Generated at 2022-06-23 14:08:50.830426
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrpcsrv = JsonRpcServer()
    error = jrpcsrv.parse_error()

    assert error['id'] == None
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32700
    assert error['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:08:54.289238
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.method_not_found()
    assert result['error']['code'] == -32601


# Generated at 2022-06-23 14:08:55.891160
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    # TODO: implement unit test



# Generated at 2022-06-23 14:09:02.759874
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.common.network import NetworkError
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.ios.basic import Basic
    from ansible.module_utils.connection import Connection

    test_objects = [Basic, Connection]
    jsonrpc = JsonRpcServer()
    for obj in test_objects:
        jsonrpc.register(obj)

    # Test rpc.run function
    run_method = jsonrpc.rpc_run

# Generated at 2022-06-23 14:09:10.341739
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpcserver = JsonRpcServer()
    setattr(jsonrpcserver, '_identifier', '1234')

    code = -32603
    message = 'Internal error'
    data = 'an error'

    result = jsonrpcserver.error(code, message, data)

    assert result == {"jsonrpc": "2.0",
                      "id": "1234",
                      "error": {"code": -32603,
                                "message": "Internal error",
                                "data": "an error"}}

# Generated at 2022-06-23 14:09:13.909063
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    test_obj = "test_JsonRpcServer_register"
    obj.register(test_obj)
    test_jsonrpc_obj = JsonRpcServer()
    assert test_obj in test_jsonrpc_obj._objects


# Generated at 2022-06-23 14:09:19.115319
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    error = jsonrpc.invalid_params()
    assert error['error']['code'] == -32602
    assert error['error']['message'] == 'Invalid params'

# Generated at 2022-06-23 14:09:25.006137
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    JsonRpc = JsonRpcServer()
    JsonRpc._identifier = 0
    result = JsonRpc.header()
    assert result == {'jsonrpc': '2.0', 'id': 0},\
        "AnsibleModule.get_bin_path() returned %s instead of %s" % \
        (result, {'jsonrpc': '2.0', 'id': 0})


# Generated at 2022-06-23 14:09:30.408600
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error('TestException: for testing')
    assert response['id'] is None
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'
    assert response['error']['data'] == 'TestException: for testing'
    assert response['result'] == None


# Generated at 2022-06-23 14:09:34.159308
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    assert server.invalid_request() == {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": None}


# Generated at 2022-06-23 14:09:39.097685
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import json
    server = JsonRpcServer()
    result = server.invalid_params('Some error')
    assert type(result) == dict
    assert json.dumps(result) == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32602, "message": "Invalid params", "data": "Some error"}}'

# Generated at 2022-06-23 14:09:51.473551
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    def test_jsonrpc(obj):
        # jsonrpc methods should be available
        assert obj['jsonrpc'] == '2.0'
        assert 'id' in obj

    server = JsonRpcServer()
    # test response method is expected format
    test_jsonrpc(server.response())
    # test argument result is included in response
    result = 'This is a response result'
    assert result in server.response(result)
    # test result_type is pickle if result is not a text_type
    result = {'This': 'is a dictionary'}
    assert 'pickle' in server.response(result)
    # test pickled result is text_type
    result = {'This': 'is a dictionary'}
    pickled = server.response(result)['result']

# Generated at 2022-06-23 14:09:56.418078
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server._objects, set)
    assert server.handle_request(request={'method': 'invalid_method'})
    assert server.handle_request(request={'method': 'bad_method', 'params': [1, 2, 'a']})
    assert server.handle_request(request={'method': 'rpc.bad_method', 'params': [1, 2, 'a']})
    assert server.handle_request(request={'method': 'rpc._bad_method', 'params': [1, 2, 'a']})
    assert server.handle_request(request={'method': '__init__', 'params': [1, 2, 'a']})

# Generated at 2022-06-23 14:10:00.855719
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_obj = JsonRpcServer()
    result_json = test_obj.internal_error("text_data")
    assert result_json == {"jsonrpc": "2.0", "id": None, "error": {"code": -32603, "message": "Internal error", "data": "text_data"}}


# Generated at 2022-06-23 14:10:04.772103
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json = JsonRpcServer()
    result = json.method_not_found(data=None)
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:10:10.861968
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    js = JsonRpcServer()
    setattr(js, '_identifier', '1234')
    response = js.error(-32700, 'Parse error')
    assert json.dumps(response) == '{"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": "1234"}'



# Generated at 2022-06-23 14:10:13.091030
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    assert JsonRpcServer().internal_error().get('error').get('code') == -32603


# Generated at 2022-06-23 14:10:16.476859
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    server.register(None)
    server.handle_request(json.dumps(dict(id=0, method='not_exists')))

    assert server.handle_request.__module__ == 'module.json_rpc'


# Generated at 2022-06-23 14:10:23.699042
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_request = {
        "jsonrpc": "2.0",
        "method": "runTest",
        "params": [1, 2, 3],
        "id": 1
    }
    local_result = JsonRpcServer().handle_request(json.dumps(test_request))
    assert isinstance(local_result, str)
    local_result = json.loads(local_result)
    assert local_result['id'] == 1
    assert local_result['result'] == 6


# Generated at 2022-06-23 14:10:28.130589
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrs = JsonRpcServer()
    assert jrs.method_not_found() == { "jsonrpc": "2.0",
                                           "error": {"code": -32601,
                                                     "message": "Method not found"
                                                     }
                                        }

# Generated at 2022-06-23 14:10:33.490524
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpc = JsonRpcServer()
    setattr(jrpc, '_identifier', 1)
    d = {u'jsonrpc': u'2.0', u'result': u'{"changed" : false, "msg": "foo"}', u'id': 1}
    assert jrpc.response({u'changed' : False, u'msg': u'foo'}) == d


# Generated at 2022-06-23 14:10:37.786142
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jr = JsonRpcServer()
    jr._identifier = '1'
    jr.error(100, 'bad')
    assert jr.error(100, 'bad') == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': 100, 'message': 'bad'}}



# Generated at 2022-06-23 14:10:41.552169
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    # create a new jsonrpc instance
    server = JsonRpcServer()
    # create a new request
    request = {"jsonrpc": "2.0", "method": "sum", "params": [1,2], "id": 1}
    # send request to server and print the response
    response = server.handle_request(json.dumps(request))
    print(response)

# Generated at 2022-06-23 14:10:42.915938
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server
    return server

# Generated at 2022-06-23 14:10:45.680907
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert JsonRpcServer.method_not_found(None)["error"] == {'code': -32601, 'message': 'Method not found'}

# Generated at 2022-06-23 14:10:48.046243
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    assert isinstance(JsonRpcServer().invalid_params(), dict)


# Generated at 2022-06-23 14:10:48.740099
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    assert JsonRpcServer.handle_request("") == ""

# Generated at 2022-06-23 14:10:51.804048
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    result = server.method_not_found()
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:10:54.797163
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    obj = JsonRpcServer()
    obj.parse_error(data = None)
    obj.parse_error('1')


# Generated at 2022-06-23 14:10:57.770552
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    assert JsonRpcServer().invalid_request() == {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": None}

# Generated at 2022-06-23 14:11:06.181012
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    my_dict = {'jsonrpc': '2.0', 'method': '_test_JsonRpcServer_error', 'id': 0}
    myerror_dict = {'code': -32603, 'message': 'Internal error'}

    jrpc_serv = JsonRpcServer()
    response = jrpc_serv.error(-32603, 'Internal error')

    try:
        assert my_dict == response
    except AssertionError as e:
        print("Test failed: {}".format(e))
        print("expected: {}\ngot: {}".format(my_dict, response))

    try:
        assert type(response) == dict
    except AssertionError as e:
        print("Test failed: {}".format(e))

# Generated at 2022-06-23 14:11:12.751381
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    test_JsonRpcServer = JsonRpcServer()
    test_JsonRpcServer._objects = set()
    test_self = {'_objects': set()}
    test_obj = {'method': 'enable'}
    JsonRpcServer.register(test_self, test_obj)
    assert test_JsonRpcServer._objects == set((test_obj,))
    assert test_self['_objects'] == test_JsonRpcServer._objects

# Generated at 2022-06-23 14:11:17.903509
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    server.register(server)
    response = server.handle_request('{"jsonrpc": "2.0", "method": "rpc.invalid_request", "id": "1"}')
    assert json.loads(response) == {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": "1"}

# Generated at 2022-06-23 14:11:21.331248
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    content = server.parse_error()
    assert(content['error']['code'] == -32700)
    assert(content['error']['message'] == 'Parse error')


# Generated at 2022-06-23 14:11:26.773784
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server._identifier = "1"
    response = server.internal_error()
    assert isinstance(response, dict)
    assert len(response) == 3
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == "1"
    assert len(response["error"]) == 3
    assert response["error"]["code"] == -32603


# Generated at 2022-06-23 14:11:32.005431
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # The id of the request is not neccessary for this test
    request = {'jsonrpc': '2.0', 'method': 'helloworld', 'params': []}
    server = JsonRpcServer()
    class helloworld():
        def helloworld():
            return "hello, world!"

    server.register(helloworld())
    result = json.loads(server.handle_request(request))
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == None
    assert result['result'] == 'hello, world!'
    assert result['error'] == None


# Generated at 2022-06-23 14:11:37.770692
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import pytest

    print(json.dumps(res, indent=4))
    print(res["result"])

    assert res["result"] == "Hello world!"


if __name__ == "__main__":
    # Create a server
    server = JsonRpcServer()

    # Create an instance of JsonRpcTest to handle requests
    class JsonRpcTest:
        def hello_world(self):
            return "Hello world!"

    obj = JsonRpcTest()

    # Register the instance
    server.register(obj)

    # Create a request
    req = {"jsonrpc": "2.0", "method": "hello_world", "params": [], "id": 1}

    # Handle the request
    res = server.handle_request(json.dumps(req))

   

# Generated at 2022-06-23 14:11:40.955964
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 10
    response = json.dumps(server.error(code=400, message='Bad Request'))
    assert response == '{"jsonrpc": "2.0", "id": 10, "error": {"code": 400, "message": "Bad Request"}}'


# Generated at 2022-06-23 14:11:48.989590
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Init a JsonRpcServer obj
    server = JsonRpcServer()
    # Call method error of the server obj
    resp = server.error(-100, 'Method error', 'data')
    # Check whether the result is correct
    assert resp == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -100,
            'message': 'Method error',
            'data': 'data'
        }
    }



# Generated at 2022-06-23 14:11:51.491592
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import pdb; pdb.set_trace()
    j = JsonRpcServer()
    j.internal_error(1)

# Generated at 2022-06-23 14:11:56.230961
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs = JsonRpcServer()
    jrs._identifier = "id1"
    result = jrs.header()
    assert result == {'jsonrpc': '2.0', 'id': jrs._identifier}


# Generated at 2022-06-23 14:12:03.956686
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils._text import to_bytes
    import traceback

    # create an instance of JsonRpcServer
    obj = JsonRpcServer()

    # send data to test method internal_error
    data = '{"jsonrpc": "2.0", "method": "my_method", "params": [42, 23], "id": 1}'
    response = obj.handle_request(to_bytes(data))

    # dump result json to dict
    result = json.loads(response)

    # check result
    if not isinstance(result, dict):
        raise AssertionError("Internal error, json rpc response can not convert to dict")

# Generated at 2022-06-23 14:12:07.529836
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_obj = JsonRpcServer()
    assert test_obj.internal_error() == {
        "error": {"code": -32603, "message": "Internal error"},
        "id": None,
        "jsonrpc": "2.0"
    }

# Generated at 2022-06-23 14:12:10.346698
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    ans = JsonRpcServer()
    res = ans.parse_error()

    assert res['jsonrpc'] == "2.0"
    assert res['error']['code'] == -32700
    assert res['error']['message'] == "Parse error"
    if 'data' in res:
        assert res['data'] == None


# Generated at 2022-06-23 14:12:14.369864
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    x = JsonRpcServer()
    x._identifier = 1
    assert x.internal_error() == {'id': 1, 'error': {'code': -32603, 'message': 'Internal error'}, 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:12:17.076337
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 'test'
    expected = {'jsonrpc': '2.0', 'id': 'test'}
    assert server.header() == expected


# Generated at 2022-06-23 14:12:18.514838
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer

    assert bool(server) == True


# Generated at 2022-06-23 14:12:29.219847
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    print("test_JsonRpcServer_response")
    json_rpc_server = JsonRpcServer()
    setattr(json_rpc_server, '_identifier', '123')
    result = json_rpc_server.response(result="test")
    print(result)
    assert(result == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'})
    result = json_rpc_server.response(result=u'test')
    print(result)
    assert(result == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'})
    result = json_rpc_server.response(result=b'test')
    print(result)

# Generated at 2022-06-23 14:12:34.666170
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == { 
            'jsonrpc': '2.0',
            'id': None,
            'error': {
                'code': -32700,
                'message': 'Parse error',
                'data': None
            }
        }



# Generated at 2022-06-23 14:12:39.547066
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=-32600, message='Invalid request', data='you made a mistake')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request', 'data': 'you made a mistake'}}

# Generated at 2022-06-23 14:12:42.176230
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    request = '{"method":"test","params":["test"],"id":123}'
    output = server.handle_request(request)
    assert '-32600' in output

# Generated at 2022-06-23 14:12:46.966452
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    testjson = {'jsonrpc': '2.0'}
    testjson['id'] = 1
    result = JsonRpcServer()._identifier
    assert result == 1
    result = JsonRpcServer.header(testjson)

# Generated at 2022-06-23 14:12:52.743874
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    
    # Instantiate the JsonRpcServer class
    js = JsonRpcServer()

    # Invalid request
    code = -32600
    error_message = 'Invalid request'
    error_data = 'Invalid request data'
    error_response = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": code,
            "message": error_message,
            "data": error_data
        }
    }
    assert js.error(code, error_message, error_data) == error_response


# Generated at 2022-06-23 14:12:59.883473
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """
    Unit test for method handle_request of class JsonRpcServer
    """
    module = AnsibleModule(argument_spec=dict(command=dict()), supports_check_mode=False)

    json_rpc = JsonRpcServer()

    request = {
      "jsonrpc": "2.0",
      "method": "validate_certs",
      "params": [],
      "id": 1
    }

    json.dumps(request)

    response = json.loads(json_rpc.handle_request(json.dumps(request)))

    assert response["result_type"] == "pickle"


# Generated at 2022-06-23 14:13:04.969846
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    json_rpc_server.handle_request('{"jsonrpc": "2.0", "method": "register", "params": [[1, 2, 3], {"test": "test_param"}], "id": "1"}')

    assert len(json_rpc_server._objects) == 1


# Generated at 2022-06-23 14:13:14.692341
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    # Set id for header
    setattr(server, '_identifier', '123')

    # Test with different result type
    results = ['test', 21, 0, True, False, None, [], {}]
    for result in results:
        response = server.response(result)
        assert response is not None
        assert response['jsonrpc'] == '2.0'
        assert response['id'] == "123"
        if isinstance(result, (binary_type, text_type)):
            assert result == response['result']
        else:
            assert response["result_type"] == "pickle"
            r = cPickle.loads(response['result'].encode('utf-8'))
            assert r == result

# Generated at 2022-06-23 14:13:25.592254
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    class TmpClass:
        def test_func(self, *args, **kwargs):
            return (args, kwargs)
    tmp_node = TmpClass()
    tmp_conn = JsonRpcServer()
    tmp_conn.register(tmp_node)
    json_header = tmp_conn.header()
    assert json_header['jsonrpc'] == '2.0'
    assert json_header['id'] == tmp_conn._identifier
    result = tmp_conn.response((args, kwargs))
    assert result['jsonrpc'] == '2.0'
    assert result['result_type'] == 'pickle'
    assert result['id'] == tmp_conn._identifier


# Generated at 2022-06-23 14:13:35.806016
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    import json
    import base64
    import cPickle
    import collections

    def test_rpc_method(*args, **kwargs):
        print(args)
        print(kwargs)
        return 'Hello World'

    class TestModule(object):

        def __init__(self):
            pass

        def say_hello(*args, **kwargs):
            print(args)
            print(kwargs)
            return 'Hello World'

    server = JsonRpcServer()
    server.register(TestModule())

    # test jsonrpc request
    request = {
        'jsonrpc': '2.0',
        'method': 'rpc.echo',
        'params': [],
        'id': 'test_jsonrpc'
    }

# Generated at 2022-06-23 14:13:38.446240
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class TestObj:
        def test_method(self):
            pass
    server.register(TestObj())
    assert getattr(server, 'test_method')

# Generated at 2022-06-23 14:13:41.382995
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': '123', 'result': None}


# Generated at 2022-06-23 14:13:46.621104
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs = JsonRpcServer()
    jrs._identifier = 100
    result = jrs.invalid_params("arg")
    assert result == {'jsonrpc': '2.0', 'id': 100, 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'arg'}}

# Generated at 2022-06-23 14:13:52.202410
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = {'server': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': result}

# Generated at 2022-06-23 14:13:58.931564
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    from ansible.module_utils.common.network import network_common

    ip = network_common. get_ip_address(interface='eth1')
    rpc = JsonRpcServer()
    rpc.register(network_common)
    response = rpc.handle_request(json.dumps(dict(id='1', params=[], method='get_ip_address')))
    assert json.loads(response)['error']['code'] == -32602


# Generated at 2022-06-23 14:14:00.384341
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jr = JsonRpcServer()
    assert isinstance(jr, JsonRpcServer)


# Generated at 2022-06-23 14:14:02.585467
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    print(obj.internal_error())


# Generated at 2022-06-23 14:14:09.235895
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error(data='Internal Error')
    assert result == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': 'Internal Error',
        }
    }


# Generated at 2022-06-23 14:14:18.616655
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jr = JsonRpcServer()
    class Test1():
        def __init__(self):
            self.methods = []
            jr.register(self)
        def rpc1(self, *args, **kwargs):
            assert args == ("arg1", 2, 3)
            assert kwargs['kwarg1'] == "k1"
            self.methods.append("rpc1")
        def rpc2(self, *args, **kwargs):
            assert args == (4, "arg5", 6)
            assert kwargs['kwarg2'] == "k2"
            self.methods.append("rpc2")
    class Test2():
        def __init__(self):
            self.methods = []
            jr.register(self)

# Generated at 2022-06-23 14:14:25.660730
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils import basic
    import json

    j = JsonRpcServer()
    setattr(j, '_identifier', 12345)
    header = j.header()

    assert header['jsonrpc'] == '2.0'
    assert header['id'] == 12345


# Unit tests for method response of class JsonRpcServer

# Generated at 2022-06-23 14:14:31.904696
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    response = {}
    server = JsonRpcServer()
    response['error'] = server.parse_error().get('error')
    response['error']['message'] = to_text(response['error']['message'], errors='surrogate_then_replace')
    assert response == {'error': {'code': -32700, 'data': None, 'message': u'Parse error'}}



# Generated at 2022-06-23 14:14:40.212136
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    js = JsonRpcServer()
    class A(object):
        def __init__(self):
            self.name = 'A'
            js.register(self)
        def foo(self, a, b, c=3):
            return a, b, c
    class B(object):
        def __init__(self):
            self.name = 'B'
            js.register(self)
        def bar(self, a, b, c=4):
            return a, b, c
    class C(object):
        def __init__(self):
            self.name = 'C'
            js.register(self)
        def foo(self, a, b, c=5):
            return a, b, c
    A()
    B()
    C()

# Generated at 2022-06-23 14:14:41.023606
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    pass

# Generated at 2022-06-23 14:14:48.980308
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    j = JsonRpcServer()
    setattr(j, '_identifier', 'test_identifier')
    result_msg = {'result': 'test_result'}
    expected_msg = {'jsonrpc': '2.0', 'id': 'test_identifier', 'result_type': 'pickle',
                    'result': u'(dp0\n.'}
    assert(j.response(result_msg) == expected_msg)

if __name__ == '__main__':
    test_JsonRpcServer_response()

# Generated at 2022-06-23 14:14:58.664178
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    from ansible.module_utils.basic import AnsibleModule
    # initializing the server
    server = JsonRpcServer()
    # register the module
    server.register(AnsibleModule(argument_spec={}))
    # building a json rpc request
    request = {
        'jsonrpc': '2.0',
        'method': 'split',
        'params': {'arg1': 'hello'},
        'id': 1
    }
    # handling the request
    response = server.handle_request(json.dumps(request))
    expect = {
        'id': 1,
        'jsonrpc': '2.0',
        'error': {
            'code': -32700,
            'message': 'Parse error',
            'data': None
        }
    }
    assert expect

# Generated at 2022-06-23 14:15:03.673797
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    req = dict(method='invalid_request', params=(), id=1)
    res = dict(jsonrpc='2.0', id=1, error=dict(code=-32600, message='Invalid request'))
    assert JsonRpcServer().handle_request(json.dumps(req)) == json.dumps(res)

# Generated at 2022-06-23 14:15:10.833291
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils._text import to_bytes

    server = JsonRpcServer()
    setattr(server, '_identifier', 0)
    result = {'result': {'key': 'value'}}
    response = json.loads(server.response(result))
    assert response == {'jsonrpc': '2.0', 'result': 'pexpect.async.AsyncSpawn(\n)', 'id': 0}, 'Incorrect Response.'

    delattr(server, '_identifier')

    server.response(result={'key': 'value'})

# Generated at 2022-06-23 14:15:15.552655
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc = JsonRpcServer()
    setattr(jsonrpc, '_identifier', 'some_id')
    result = jsonrpc.header()
    assert result == {'jsonrpc': '2.0', 'id': 'some_id'}


# Generated at 2022-06-23 14:15:20.910474
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer._objects.clear()
    a = JsonRpcServer()
    b = JsonRpcServer()
    a.register(b)
    assert b in JsonRpcServer._objects


# Generated at 2022-06-23 14:15:23.724111
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
  assert JsonRpcServer().invalid_request() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request', 'data': None}}

# Generated at 2022-06-23 14:15:27.157538
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    srv = JsonRpcServer()
    srv._identifier = 'myid'
    srv._objects = set()
    assert srv.parse_error()['error'] == {'code': -32700, 'message': 'Parse error'}


# Generated at 2022-06-23 14:15:30.861668
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    obj = JsonRpcServer()
    obj._identifier = 1
    assert obj.header() == {'jsonrpc': '2.0', 'id': 1}

# Generated at 2022-06-23 14:15:35.978089
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request = json.loads('{"jsonrpc": "2.0", "method": "rpc._test.invalid_request", "params": [1,2,3,4,5], "id": "1234567"}')
    server = JsonRpcServer()
    assert server.handle_request(request) == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": "1234567"}'


# Generated at 2022-06-23 14:15:42.392239
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_obj = JsonRpcServer()
    test_obj._identifier = True
    expected_output = '{"jsonrpc": "2.0", "id": true}'
    assert str(test_obj.header()) == expected_output, 'header method test failed.'


# Generated at 2022-06-23 14:15:45.239840
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    assert server.response("data") == {"jsonrpc": "2.0", "id": None, "result": "data"}


# Generated at 2022-06-23 14:15:48.620018
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    obj1 = object()
    obj2 = object()
    server.register(obj1)
    server.register(obj2)
    assert server._objects == {obj1, obj2}


# Generated at 2022-06-23 14:15:59.110760
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()

    # assert method response
    response = server.error(code=123, message='unit test')
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 123, 'message': 'unit test'}}

    # assert method response with data
    response = server.error(code=123, message='unit test', data={'foo': 'bar'})
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 123, 'message': 'unit test', 'data': {'foo': 'bar'}}}


# Generated at 2022-06-23 14:16:03.602963
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    j = JsonRpcServer()
    setattr(j, "_identifier", 1)
    answer = j.method_not_found()
    assert answer == {'error': {'code': -32601, 'message': 'Method not found'}, 'id': 1, 'jsonrpc': '2.0'}
    return True

# Generated at 2022-06-23 14:16:06.105099
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    a = JsonRpcServer()
    print(a)

# Generated at 2022-06-23 14:16:08.756739
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer = JsonRpcServer()
    JsonRpcServer.register(JsonRpcServer)
    assert JsonRpcServer._objects == {JsonRpcServer}


# Generated at 2022-06-23 14:16:11.438513
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)
    assert server._objects == set()


# Generated at 2022-06-23 14:16:18.177462
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():

    import pytest
    from ansible.module_utils import jsonrpc
    from ansible.module_utils.six import text_type

    # Unit test for method parse_error of class JsonRpcServer
    # A JSON text must at least contain two octets!
    # Case:  a = {}
    # Result:  parse error
    obj = jsonrpc.JsonRpcServer()
    result = obj.parse_error(a = {})
    result_correct = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': {'a': {}}}}
    assert result == result_correct
    assert isinstance(result, dict) == True


# Generated at 2022-06-23 14:16:22.124395
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    test_obj = object()
    test_srv = JsonRpcServer()
    test_srv.register(test_obj)
    assert test_srv._objects.pop() == test_obj


# Generated at 2022-06-23 14:16:26.239104
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    JsonRpcServer = JsonRpcServer()
    expected = {'error': {'code': -32601, 'message': 'Method not found'}, 'id': None, 'jsonrpc': '2.0'}
    actual = JsonRpcServer.method_not_found()
    assert expected == actual

# Generated at 2022-06-23 14:16:36.125664
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():

    from ansible.module_utils.network.cloudengine.ce import ce
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.loader import jpc_loader
    from ansible.module_utils.six.moves import zip
    import ansible.module_utils.connection

    jpc = JsonRpcServer()
    jpc.register(ce)
    jpc.register(Connection)
    jpc.register(Conditional)
    jpc.register(load_provider)

    # register plugins
    for plugin in zip(jpc_loader.all(), jpc_loader.all()):
        jpc.register(plugin)



# Generated at 2022-06-23 14:16:37.914890
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    test = JsonRpcServer()
    assert test._objects == set()

# Generated at 2022-06-23 14:16:41.178210
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['error']['code'] == -32602


# Generated at 2022-06-23 14:16:42.646460
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    j._identifier = "1337"
    result = j.header()
    expected = {'jsonrpc': '2.0', 'id': j._identifier}
    assert result == expected


# Generated at 2022-06-23 14:16:46.525450
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc = JsonRpcServer()
    result = json_rpc.error(1,"error_call")
    expected_result = {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message':'error_call','data':None}}
    assert result == expected_result


# Generated at 2022-06-23 14:16:47.778707
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()
    assert rpc



# Generated at 2022-06-23 14:16:50.734883
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error()
    assert(response['error']['code'] == -32603)


# Generated at 2022-06-23 14:17:01.920023
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    req = {"id": "1", "method": "internal_error", "params": []}
    res = server.handle_request(json.dumps(req))
    # res = {"jsonrpc": "2.0", "id": "1", "error": {"code": -32603, "message": "Internal error", "data": None}}
    exp = json.loads(res)
    assert exp == {"jsonrpc": "2.0", "id": "1", "error": {"code": -32603, "message": "Internal error", "data": None}}
    # res = {"jsonrpc": "2.0", "id": "1", "error": {"code": -32603, "message": "Internal error", "data": "ValueError('hello',)"}}

# Generated at 2022-06-23 14:17:04.699504
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    v = JsonRpcServer()
    assert v._objects is not None