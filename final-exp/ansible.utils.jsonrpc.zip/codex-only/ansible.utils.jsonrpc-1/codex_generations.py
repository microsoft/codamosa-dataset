

# Generated at 2022-06-23 14:07:07.681206
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        server = JsonRpcServer()
        if not isinstance(server, JsonRpcServer):
            return False
        
        if not isinstance(server._objects, set):
            return False
        
        if server._objects:
            return False

        return True

    except:
        return False

# Generated at 2022-06-23 14:07:18.465321
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_obj = JsonRpcServer()
    assert test_obj.header() == {'jsonrpc': '2.0', 'id': None}
    test_obj._identifier = "1"
    assert test_obj.header() == {'jsonrpc': '2.0', 'id': "1"}
    assert test_obj.response("abc") == {'jsonrpc': '2.0', 'id': "1", 'result': "abc"}
    assert test_obj.response(b"abc") == {'jsonrpc': '2.0', 'id': "1", 'result': "abc"}
    assert test_obj.response({}) == {'jsonrpc': '2.0', 'id': "1", 'result': "{}"}

# Generated at 2022-06-23 14:07:21.648875
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {"hello": "world"}
    expected = {'jsonrpc': '2.0', 'result': result, 'id': None}
    actual = server.response(result)
    assert expected == actual

# Generated at 2022-06-23 14:07:31.188088
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # This is a dictionary of arguments used to invoke the method error.
    param_dict = dict()
    param_dict['code'] = 1

    # This is a dictionary of keyword arguments used to invoke the method error.
    kwargs_dict = dict()
    kwargs_dict['message'] = 'test'

    # Create an instance of JsonRpcServer.
    jsonrpcserver_obj = JsonRpcServer()

    # Execute the method error.
    jsonrpcserver_obj.error(**param_dict, **kwargs_dict)


if __name__ == "__main__":
    pass

# Generated at 2022-06-23 14:07:38.633016
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error_dict_default = server.error(0, 'message', data=None)
    error_dict_custom = server.error(1, 'message', data='data')
    errors = [error_dict_default, error_dict_custom]
    for error in errors:
        assert 'jsonrpc' in error
        assert isinstance(error['jsonrpc'], text_type)
        assert error['jsonrpc'] == '2.0'
        assert 'id' in error
        assert isinstance(error['id'], int)
        assert isinstance(error['error'], dict)
        for key in ['code', 'message']:
            assert key in error['error']
            assert isinstance(error['error'][key], text_type)

# Generated at 2022-06-23 14:07:39.291903
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, object)

# Generated at 2022-06-23 14:07:42.883455
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import unittest
    server = JsonRpcServer()
    ex_response = {'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params'}, 'id': 123}
    response = server.invalid_params()
    assert ex_response == response


# Generated at 2022-06-23 14:07:47.672999
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    method_name = "internal_error"
    json_rpc_server = JsonRpcServer()
    setattr(json_rpc_server, '_identifier', "json_rpc_server_id")
    result = getattr(json_rpc_server, method_name)(data="test_data")
    assert result['id'] == "json_rpc_server_id"
    assert result['error']['code'] == -32603
    assert result['error']['message'] == "Internal error"
    assert result['error']['data'] == "test_data"

# Generated at 2022-06-23 14:07:51.199210
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    response = server.method_not_found()
    expected = {"id": None, "jsonrpc": "2.0",
                "error": {"code": -32601, "message": "Method not found"}}
    assert response == expected

# Generated at 2022-06-23 14:07:57.093829
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    """
    Test method response in class JsonRpcServer
    """
    test_server = JsonRpcServer()
    test_server._identifier = "test_id"

    response = test_server.response("test")
    assert type(response) == dict
    assert response == {
        "jsonrpc": "2.0",
        "id": "test_id",
        "result": "test"
    }

# Generated at 2022-06-23 14:07:59.098109
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
  server = JsonRpcServer()
  assert server
  assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:08:01.787107
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == {'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}, 'id': 'None'}


# Generated at 2022-06-23 14:08:09.708807
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class TestObj(object):
        def test(self):
            return 2

    jsonrpc = JsonRpcServer()
    jsonrpc.register(TestObj())

    request = '{"jsonrpc":"2.0","method":"test","params":[2],"id":1}'
    response = jsonrpc.handle_request(request)
    assert json.loads(response) == {'error': {'code': -32601, 'message': 'Method not found'},
                                    'id': 1, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:08:13.920395
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jrpcServer = JsonRpcServer()
    # first test if method exists
    assert hasattr(jrpcServer, 'handle_request'), "Object doesn't have attribute 'handle_request'"
    # test for correct input type
    # test for correct output type

# Generated at 2022-06-23 14:08:16.639905
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
   result = JsonRpcServer().parse_error()
   assert(result['error']['code'] == -32700)
   assert(result['error']['message'] == 'HTTP error')


# Generated at 2022-06-23 14:08:24.266531
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrs = JsonRpcServer()
    jrs.register(JsonRpcServer())
    jrs._identifier = 0
    response = jrs.method_not_found()
    assert response["id"] == 0
    assert response["jsonrpc"] == "2.0"
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == "Method not found"
    assert response["error"]["data"] == None

# Generated at 2022-06-23 14:08:26.229486
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrs = JsonRpcServer()
    jrs.invalid_request()


# Generated at 2022-06-23 14:08:29.630153
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
  obj = JsonRpcServer()
  result = obj.invalid_request()
  if result['error']['code'] == -32600:
    sys.exit(0)
  else:
    sys.exit(1)


# Generated at 2022-06-23 14:08:36.533024
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test_server = JsonRpcServer()
    # Test default parameters
    expected_dict1 = {}
    expected_dict1['jsonrpc'] = '2.0'
    expected_dict1['id'] = None
    expected_dict1['error'] = {}
    expected_dict1['error']['code'] = -32700
    expected_dict1['error']['message'] = 'Parse error'
    expected_dict1['error']['data'] = None

    actual_dict1 = test_server.error(-32700, 'Parse error', data=None)

# Generated at 2022-06-23 14:08:40.041847
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    result = JsonRpcServer().error(0, 'error')
    assert result == {'jsonrpc': '2.0',
                      'id': None,
                      'error': {'code': 0,
                                'message': 'error'}}


# Generated at 2022-06-23 14:08:43.490376
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils._text import to_text
    server = JsonRpcServer()
    result = server.error(1, "foo", data="bar")
    assert result['error'] == {'code': 1, 'message': 'foo', 'data': 'bar'}


# Generated at 2022-06-23 14:08:49.860576
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    import unittest

    class TestJsonRpcServer(unittest.TestCase):
        def test_create_instance(self):
            server = JsonRpcServer()
            self.assertIsInstance(server, JsonRpcServer)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestJsonRpcServer)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 14:08:59.828976
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [
            [1,2,3],
            {
                "5":5,
                "6":6,
                "7":7,
                "8":8,
                "9":9,
                "10":10,
            }
        ],
        "id": 1
    }
    message = {
        "jsonrpc": "2.0",
        "result": "test_result",
        "id": 1
    }
    expect = '{"jsonrpc": "2.0", "result": "test_result", "id": 1}'
    server = JsonRpcServer()
    server._identifier = 1
    result = server.response("test_result")

# Generated at 2022-06-23 14:09:06.674230
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc = JsonRpcServer()
    rpc._identifier = 123
    assert rpc.error(-32700, 'Parse error').get('error') == {
        'code': -32700, 'message': 'Parse error'
    }

    assert rpc.error(-32700, 'Parse error', 'some data').get('error') == {
        'code': -32700, 'message': 'Parse error', 'data': 'some data'
    }


# Generated at 2022-06-23 14:09:15.042509
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    sut = JsonRpcServer()
    error_code = -32602
    error_message = 'Invalid params'
    error_data = 'Invalid params'
    result = sut.invalid_params(error_data)
    assert result['error']['code'] == error_code, 'Expected error code is: {}, actual is: {}'.format(error_code, result['error']['code'])
    assert result['error']['message'] == error_message, 'Expected error message is: {}, actual is: {}'.format(error_message, result['error']['message'])
    assert result['error']['data'] == error_data, 'Expected error data is: {}, actual is: {}'.format(error_data, result['error']['data'])


# Generated at 2022-06-23 14:09:21.958922
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    error = server.error(code=-32603, message='Internal error')

    assert(error['error'] == {'code': -32603, 'message': 'Internal error'})
    assert(error['id'] == '123')
    assert(error['jsonrpc'] == '2.0')


# Generated at 2022-06-23 14:09:26.172752
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    js = JsonRpcServer()
    result = js.internal_error()
    assert result["jsonrpc"] == '2.0'
    assert result["error"]["code"] == -32603
    assert result["error"]["message"] == 'Internal error'
    assert result["error"]["data"] == None


# Generated at 2022-06-23 14:09:30.865323
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs = JsonRpcServer()
    jrs._identifier = 'test123'
    assert jrs.invalid_params() == {'error': {'code': -32602, 'message': 'Invalid params'}, 'id': 'test123', 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:09:36.865210
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    json_rpc_server = JsonRpcServer()
    request = '{"method": "rpc._invalid_request", "params": [], "id": "123"}'
    expected_result = '{"jsonrpc": "2.0", "id": "123", "error": {"code": -32600, "message": "Invalid request"}}'
    result = json.loads(json_rpc_server.handle_request(request))
    assert result == json.loads(expected_result)

# Generated at 2022-06-23 14:09:38.619381
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server._objects == set()


# Generated at 2022-06-23 14:09:50.107117
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrpc_server = JsonRpcServer()
    jrpc_server.register(WrongClass())
    request = {u'method': u'not_found_method', u'params': [[], {}],
               u'id': u'f93c0ffa-e5c5-402f-8b42-4639a9a3f3aa'}
    response = jrpc_server.handle_request(json.dumps(request))
    assert response == '{"id": "f93c0ffa-e5c5-402f-8b42-4639a9a3f3aa", "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-23 14:09:55.484097
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server.register(JsonRpcServer())
    response = server.handle_request('{"jsonrpc": "2.0", "method": "parse_error", "params": [1,2,3,4,5]}')
    assert(response == '{"id": null, "jsonrpc": "2.0", "error": {"message": "Parse error", "code": -32700}}')


# Generated at 2022-06-23 14:09:59.262709
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '0')
    response = server.parse_error()

    assert len(response) == 3
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '0'
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:10:01.144438
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc = JsonRpcServer()
    foo = json_rpc.invalid_params()
    assert foo["error"] == {
            "code": -32602,
            "message": "Invalid params"
    }

# Generated at 2022-06-23 14:10:03.868292
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    obj = JsonRpcServer()
    print(json.dumps(obj.invalid_request()))


# Generated at 2022-06-23 14:10:07.484711
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 0
    response = server.response('test_result')
    assert response == {'jsonrpc': '2.0', 'id': 0, 'result': 'test_result'}

# Generated at 2022-06-23 14:10:14.675975
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.invalid_params(data=None)
    if response['error']['code'] != -32602:
        # "Invalid params" error code is expected
        raise Exception("Invalid code in response")
    if response['error']['message'] != 'Invalid params':
        # "Invalid params" error message is expected
        raise Exception("Invalid message in response")


# Generated at 2022-06-23 14:10:16.556446
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test(object):
        pass

    server = JsonRpcServer()
    server.register(Test())
    assert Test() in server._objects

# Generated at 2022-06-23 14:10:27.901242
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    """
    This test is responsible for verifying that the corresponding error codes
    are properly returned by JsonRpcServer.error()
    """
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = server.error(code=100, message='message')

    # Check if identifier is returned properly
    assert result.get('id') == 'test_identifier'

    # Check if jsonrpc and error is returned properly
    assert result.get('jsonrpc') == '2.0'
    assert result.get('error').get('code') == 100
    assert result.get('error').get('message') == 'message'

    # Check if data is returned properly
    data = 'test_data'

# Generated at 2022-06-23 14:10:30.156941
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    json_rpc_server = JsonRpcServer()
    assert len(json_rpc_server._objects) >= 1


# Generated at 2022-06-23 14:10:32.697255
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    assert rpc.header() == {'jsonrpc': '2.0', 'id': 0}


# Generated at 2022-06-23 14:10:36.630689
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    expected = {"id": None, "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}
    result = JsonRpcServer().method_not_found()
    assert expected == result


# Generated at 2022-06-23 14:10:41.445321
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # We instantiate the server
    server = JsonRpcServer()
    # We get the response of the server to the invalid_params request
    response_json = server.invalid_params()
    # We store the response in an object structure
    response = json.loads(response_json)
    # We get the error object
    error_object = response.get('error')
    # We check that the error code is correct
    assert error_object.get('code') == -32602

# Generated at 2022-06-23 14:10:43.186326
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-23 14:10:45.577817
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    import ansible.module_utils.basic
    ansible.module_utils.basic.ANSIBLE_MODULE_ARGS = {}
    server.register(ansible.module_utils.basic)
    assert 'jsonrpc' in server.handle_request('{"method": "ansible_version"}')



# Generated at 2022-06-23 14:10:50.441753
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    expected = json.dumps({'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request', 'data': None}})
    actual = server.invalid_request()
    assert expected == actual


# Generated at 2022-06-23 14:10:52.060783
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonrpc = JsonRpcServer()
    print(jsonrpc.internal_error())

# Generated at 2022-06-23 14:11:01.078609
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    server.register(None)
    response = server.handle_request(json.dumps({
        "jsonrpc": "2.0",
        "method": "not_existing",
        "params": [],
        "id": "123"
    }))
    assert json.loads(response) == json.loads('''
    {
        "jsonrpc": "2.0",
        "error": {
            "code": -32601,
            "message": "Method not found",
            "data": null
        },
        "id": "123"
    }
    ''')

# Generated at 2022-06-23 14:11:07.364870
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = \
        b'{"jsonrpc": "2.0", "method": "test1", "params": [],"id": "12345"}'
    response = b'{"id": "12345", "jsonrpc": "2.0", "result": "test1"}'
    response1 = b'{"id": "", "jsonrpc": "2.0", "result": "test1"}'
    response2 = b'{"id": "", "jsonrpc": "2.0", "result": "test2"}'

    class A(object):

        def test1(self):
            return 'test1'

        def test2(self):
            return 'test2'

    a = A()
    server = JsonRpcServer()
    server.register(a)

# Generated at 2022-06-23 14:11:16.053535
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpcs = JsonRpcServer()
    setattr(jrpcs, '_identifier', 6)

    # Test if result is unicode
    result = {
        "changed": False,
        "stdout": "GigabitEthernet1/0/1 is down, line protocol is down\n  Hardware is CN Gigabit Ethernet, address is 5254.00ff.a00b (bia 5254.00ff.a00b)\n  Internet protocol processing disabled\n",
        "stdout_lines": [
            "GigabitEthernet1/0/1 is down, line protocol is down",
            "  Hardware is CN Gigabit Ethernet, address is 5254.00ff.a00b (bia 5254.00ff.a00b)",
            "  Internet protocol processing disabled",
        ],
    }
   

# Generated at 2022-06-23 14:11:19.387172
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_class = JsonRpcServer()
    test_result = "test_result"
    response = test_class.response(test_result)

    assert 'result' in response
    assert response['result'] == test_result


# Generated at 2022-06-23 14:11:28.668682
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    obj = JsonRpcServer()
    response = obj.handle_request('{"jsonrpc":"2.0","method":"foo"}')
    response = json.loads(response)
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == 'Method not found'
    assert response["id"] == None
    assert response["jsonrpc"] == '2.0'
    response = obj.handle_request('{"jsonrpc":"2.0","method":"foo","id":2}')
    response = json.loads(response)
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == 'Method not found'
    assert response["id"] == 2
    assert response["jsonrpc"] == '2.0'
   

# Generated at 2022-06-23 14:11:34.618350
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.invalid_request()

    expected = {
        'jsonrpc': '2.0',
        'id': 'test',
        'error': {
            'code': -32600,
            'message': 'Invalid request'
        }
    }

    assert result == expected

# Generated at 2022-06-23 14:11:35.673099
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    testJsonServer = JsonRpcServer()
    return testJsonServer

# Generated at 2022-06-23 14:11:39.922525
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 'req_002')
    assert rpc_server.invalid_params() == {"id":"req_002","jsonrpc":"2.0","error":{"code":-32602,"message":"Invalid params"}}
    delattr(rpc_server, '_identifier')


# Generated at 2022-06-23 14:11:45.237592
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrs = JsonRpcServer()
    setattr(jrs, '_identifier', '1')
    response = jrs.response('test')
    assert response == {'id': '1', 'jsonrpc': '2.0', 'result': 'test'}

# Generated at 2022-06-23 14:11:50.059934
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = '34'
    result = rpc_server.error(code=1, message='Error')
    expected = {'jsonrpc': '2.0', 'id': '34', 'error': {'code': 1, 'message': 'Error'}}
    assert result == expected


# Generated at 2022-06-23 14:11:53.039443
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        JsonRpcServer()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 14:11:54.188768
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer


# Generated at 2022-06-23 14:12:03.239253
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.nxos import nxos_argument_spec, get_config, load_config, run_commands, send_request
    import socket

    # Create JsonRpcServer
    server = JsonRpcServer()

    # Create obj of class nxos (test purpose)
    obj = nxos(params={})

    # Register nxos class obj to server
    server.register(obj)

    # Create dict of valid requests
    request = {
        "jsonrpc": "2.0",
        "method": "get_config",
        "params": [{
            "flags": ["boot"],
            "format": "json"
        }],
        "id": "None"
    }

    # Dump dict to json object
    request = json.dumps(request)

   

# Generated at 2022-06-23 14:12:06.497888
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs=JsonRpcServer()
    jrs._identifier=0
    assert jrs.header() == {'jsonrpc': '2.0', 'id': 0}


# Generated at 2022-06-23 14:12:09.777163
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc = JsonRpcServer()
    class TestClass(object):
        def test_method(self):
            return "test_method"
    obj = TestClass()
    rpc.register(obj)
    assert len(rpc._objects) == 1


# Generated at 2022-06-23 14:12:18.650613
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    obj = JsonRpcServer()
    request = dict(
        id=1,
        jsonrpc="2.0",
        method="rpc.invalid_request",
        params=dict()
    )
    result = obj.handle_request(json.dumps(request))
    assert to_list(json.loads(result)) == to_list({
        'id': 1,
        'jsonrpc': '2.0',
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': None
        }
    })


# Generated at 2022-06-23 14:12:29.328362
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    test_obj = JsonRpcServer()
    assert test_obj.header() == {'jsonrpc': '2.0', 'id': 'None'}
    assert test_obj.response() == {'jsonrpc': '2.0', 'id': 'None', 'result': None}
    assert test_obj.response(result='test') == {'jsonrpc': '2.0', 'id': 'None', 'result': 'test'}
    assert test_obj.error(1, 'test') == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': 1, 'message': 'test'}}

# Generated at 2022-06-23 14:12:36.334330
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    # Create a JsonRpcServer object
    JsonRpcServer_obj = JsonRpcServer()

    # Create attribute rpc_test_obj of type class 'object'
    JsonRpcServer_obj.rpc_test_obj = object()

    # Call method register with argument JsonRpcServer_obj.rpc_test_obj
    JsonRpcServer_obj.register(JsonRpcServer_obj.rpc_test_obj)

    # Call method register with argument JsonRpcServer_obj.rpc_test_obj
    JsonRpcServer_obj.register(JsonRpcServer_obj.rpc_test_obj)

# Generated at 2022-06-23 14:12:40.544198
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    wsman_obj = JsonRpcServer()
    result = wsman_obj.internal_error()
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'


# Generated at 2022-06-23 14:12:41.803639
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.header() == {'jsonrpc': '2.0', 'id': None}

# Generated at 2022-06-23 14:12:43.629470
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server

# Generated at 2022-06-23 14:12:48.560540
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    assert JsonRpcServer().invalid_params() == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32602,
            "message": "Invalid params",
            "data": None
        }
    }


# Generated at 2022-06-23 14:12:54.396344
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpcserver = JsonRpcServer()

    assert rpcserver.header() == {'jsonrpc': '2.0', 'id': None}

    rpcserver._identifier = '1010-101'
    assert rpcserver.header() == {'jsonrpc': '2.0', 'id': '1010-101'}


# Generated at 2022-06-23 14:12:56.879774
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    print("Test constructor JsonRpcServer")
    rpc_server = JsonRpcServer()
    if rpc_server._objects != set():
        raise AssertionError()


# Generated at 2022-06-23 14:13:01.814361
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error(data='Test')
    expected = '{"jsonrpc": "2.0", "error": {"message": "Parse error", "code": -32700, "data": "Test"}, "id": null}'
    assert result == expected


# Generated at 2022-06-23 14:13:03.208816
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    pass

# Generated at 2022-06-23 14:13:10.877702
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest

    # The request must contain a mandatory field named "jsonrpc"
    # with a String value that is set to "2.0"
    def test_jsonrpc():
        request = '{"method": "foo"}'
        server = JsonRpcServer()
        response = server.handle_request(request)
        assert json.loads(response) == {
            "jsonrpc": "2.0", "id": None, "error": {
                "code": -32600, "message": "Invalid request"
            }
        }

    # The value of the "method" member MUST be a String
    def test_method_not_a_string():
        request = '{"method": [], "jsonrpc": "2.0"}'
        server = JsonRpcServer()
        response = server.handle

# Generated at 2022-06-23 14:13:18.584157
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    data = {
        "jsonrpc": "2.0",
        "method": "_ping",
        "params": [
            {"host": "1.1.1.1"},
            {"port": 80}
        ],
        "id": "abcd1234"
    }

    _jsonrpc_server = JsonRpcServer()
    result = _jsonrpc_server.handle_request(json.dumps(data))
    result = json.loads(result)

    assert result['id'] == "abcd1234", "Expected id is abcd1234 but got %s" % result['id']
    assert result['jsonrpc'] == "2.0", "Expected jsonrpc version is 2.0 but got %s" % result['jsonrpc']

# Generated at 2022-06-23 14:13:20.524463
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs=JsonRpcServer()
    expected_result = {
            'jsonrpc': '2.0',
            'error': {
                'code': -32602,
                'message':'Invalid params'
                },
            'id': None
            }
    assert expected_result == jrs.invalid_params()

# Generated at 2022-06-23 14:13:23.346259
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)
    assert server._objects == set()

# Generated at 2022-06-23 14:13:26.119277
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    assert jrs.internal_error()["error"]["message"] == 'Internal error'
    assert jrs.internal_error("Data")["error"]["data"] == 'Data'


# Generated at 2022-06-23 14:13:26.774327
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    pass

# Generated at 2022-06-23 14:13:27.774654
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    pass


# Generated at 2022-06-23 14:13:29.955524
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result['error']['code'] == -32603


# Generated at 2022-06-23 14:13:34.536953
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class ExampleClass1:
        pass
    class ExampleClass2:
        pass
    class ExampleClass3:
        pass

    server.register(ExampleClass1)
    server.register(ExampleClass2)
    server.register(ExampleClass3)

    assert("ExampleClass1" in server._objects)
    assert("ExampleClass2" in server._objects)
    assert("ExampleClass3" in server._objects)

# Generated at 2022-06-23 14:13:39.960495
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    class TestObject:

        def rpc_test_object(self):
            return {'message': 'Hello World'}

    server = JsonRpcServer()
    server.register(TestObject())
    server.handle_request(json.dumps({
        'jsonrpc': '2.0',
        'id': 'ansible01',
        'method': 'rpc_test_object'
    }))

# Generated at 2022-06-23 14:13:41.498002
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
	obj = JsonRpcServer()
	assert JsonRpcServer == type(obj)

# Generated at 2022-06-23 14:13:46.144731
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(1, "test", None)
    expected = {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test'}}
    assert result == expected


# Generated at 2022-06-23 14:13:58.171476
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """ Check the method handle_request
    """

    jsonServer = JsonRpcServer()
    class DummyClass:
        def rpc_something(self, *args, **kwargs):
            return {'something': 'done'}
    dummyInstance = DummyClass()
    jsonServer.register(dummyInstance)

    rpc_method = json.dumps({
        "jsonrpc": "2.0",
        "method": "rpc_something",
        "id": 1
    })
    response = json.loads(jsonServer.handle_request(rpc_method))
    assert response == {'jsonrpc': '2.0', 'id': 1, 'result': {'something': 'done'}}


# Generated at 2022-06-23 14:14:06.139278
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Foo(object):
        def __init__(self):
            pass

        def bar(self, a, b):
            return a + b

    # create a rpc.server object
    rpc_server = JsonRpcServer()
    rpc_server.register(Foo())

    # test for json-rpc standard errors
    for i in range(-32768, -32001):
        response = rpc_server.handle_request(json.dumps({'id': '1.1', 'method': rpc.json_methods[i],
                                                         'params': [], 'jsonrpc': '2.0'}))
        assert json.loads(response)['error']['code'] == i

    # test for method not found

# Generated at 2022-06-23 14:14:09.805050
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class TestClass():
        def test_method(self):
            pass

    obj = TestClass()

    server = JsonRpcServer()
    server.register(obj)

    assert obj in server._objects

# Generated at 2022-06-23 14:14:18.915490
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Setup the mocks
    class MockDisplay():
        def __init__(self):
            self.vars = []
        def vvv(self, value):
            self.vars.append(value)

    class MockJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self._identifier = None
            self._objects = set()

    mock_display = MockDisplay()
    mock_JsonRpcServer = MockJsonRpcServer()

    # Setup the test
    mock_request = '{"jsonrpc": "2.0", "method": "foo", "params": [[], {}], "id": "123"}'

# Generated at 2022-06-23 14:14:25.193626
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request_json = {"method":"invalid"}
    server = JsonRpcServer()
    result = server.handle_request(request_json)
    assert(result == '{"id": null, "jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request", "data": null}}')


# Generated at 2022-06-23 14:14:36.503357
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    obj = JsonRpcServer()
    server.register(obj)
    request = {
        "jsonrpc": "2.0",
        "id": "77f6b31a-ee33-11e6-8f88-34363bd7b958",
        "method": "parse_error",
        "params": {
            "data": "data"
        }
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-23 14:14:40.738980
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(999, "message", "data")
    assert result == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": 999,
            "message": "message",
            "data": "data"
        }
    }

    # Unit test for method parse_error of class JsonRpcServer

# Generated at 2022-06-23 14:14:44.238754
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 1234
    val = server.header()
    assert val == {'jsonrpc': '2.0', 'id': 1234}



# Generated at 2022-06-23 14:14:47.204066
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer_object = JsonRpcServer()
    assert JsonRpcServer_object.register(JsonRpcServer_object) == None


# Generated at 2022-06-23 14:14:55.037435
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server._identifier = "12345"
    assert server.parse_error() == {u'jsonrpc': u'2.0', u'error': {u'message': u'Parse error', u'code': -32700}, u'id': u'12345'}
    assert server.parse_error("testing") == {u'jsonrpc': u'2.0', u'error': {u'message': u'Parse error', u'data': u'testing', u'code': -32700}, u'id': u'12345'}


# Generated at 2022-06-23 14:15:02.263621
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    import traceback
    from ansible.module_utils.six import PY3
    if PY3:
        unicode = str
    myjsonrpc = JsonRpcServer()
    try:
        setattr(myjsonrpc, '_identifier', 'test_id')
        if isinstance(myjsonrpc.header(), dict) and myjsonrpc.header()['jsonrpc'] == '2.0' and myjsonrpc.header()['id'] == 'test_id':
            return True
        else:
            raise AssertionError()
    except AssertionError:
        traceback.print_exc()
        display.display('header() of class JsonRpcServer is not working', color='red')


# Generated at 2022-06-23 14:15:06.691808
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    response = json.loads(server.invalid_request())
    assert response['id'] is None
    assert response['error']['code'] == -32600
    assert response['error']['message'] == 'Invalid request'


# Generated at 2022-06-23 14:15:10.042221
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc_server = JsonRpcServer()
    assert "error" in rpc_server.handle_request(
        "{\"jsonrpc\": \"2.0\", \"method\": \"rpc.test\", \"id\": 1}"
    )


# Generated at 2022-06-23 14:15:20.916961
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.net_tools import to_list
    from ansible.module_utils.basic import AnsibleModule

    def fail_json(*args, **kwargs):
        raise AssertionError('fail_json has been called')

    def to_text(obj):
        return str(obj)

    class TestModule(object):

        def __init__(self, **kwargs):
            self.argument_spec = kwargs
            self.params = dict()


# Generated at 2022-06-23 14:15:24.068870
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc = JsonRpcServer()
    jsonrpc._identifier = "123456789"
    assert jsonrpc.header() == {'jsonrpc': '2.0', 'id': '123456789'}


# Generated at 2022-06-23 14:15:26.020647
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert throw_exception_if_not(type(server) is JsonRpcServer, "server is not JsonRpcServer")


# Generated at 2022-06-23 14:15:32.117432
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()

    assert server.header() == {'jsonrpc': '2.0', 'id': None}

    server._identifier = 'identifier'
    assert server.header() == {'jsonrpc': '2.0', 'id': 'identifier'}

    delattr(server, '_identifier')
    assert server.header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:15:35.811002
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    expected = {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': '1'}
    j = JsonRpcServer()
    j._identifier = '1'
    result = j.method_not_found()
    assert result == expected

# Generated at 2022-06-23 14:15:42.201196
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    a = JsonRpcServer()
    if a.method_not_found() != {
        'error': {'code': -32601, 'message': 'Method not found'},
        'id': None,
        'jsonrpc': '2.0'
    }:
        raise AssertionError()

# Generated at 2022-06-23 14:15:43.206875
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        JsonRpcServer()
    except:
        assert False


# Generated at 2022-06-23 14:15:46.299263
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert obj is not None

if __name__ == '__main__':
    obj = JsonRpcServer()
    obj.handle_request("")

# Generated at 2022-06-23 14:15:48.398269
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    result = rpc.header()
    assert result["jsonrpc"] == "2.0"
    assert result["id"] == None


# Generated at 2022-06-23 14:15:50.508754
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-23 14:15:58.396435
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = {
        'method': 'test',
        'params': [],
        'id': 'id1'
    }
    request = json.dumps(request)
    response = JsonRpcServer().handle_request(request)
    assert(response == json.dumps({'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': 'id1'}))

# Generated at 2022-06-23 14:16:04.610948
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    """
    This is a unit test for method invalid_params of class JsonRpcServer.
    """
    jsonRpcServer = JsonRpcServer()
    res = jsonRpcServer.invalid_params()
    assert res['jsonrpc'] == '2.0'
    assert res['id'] == None
    assert res['error']['code'] == -32602
    assert res['error']['message'] == 'Invalid params'
    assert res['error']['data'] == None


# Generated at 2022-06-23 14:16:09.178081
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    setattr(server, '_identifier', "a")
    result = server.invalid_params()
    expected = {
        'jsonrpc': '2.0',
        'id': 'a',
        'error': {
            'code': -32602,
            'message': 'Invalid params',
        }
    }
    assert expected == result

# Generated at 2022-06-23 14:16:16.759154
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    from ansible.module_utils.basic import AnsibleModule

    obj = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=True
    )

    server = JsonRpcServer()
    server.register(obj)

    assert hasattr(server, 'register')
    assert hasattr(server, 'handle_request')

    assert hasattr(server, 'response')
    assert hasattr(server, 'error')

    assert hasattr(server, 'parse_error')
    assert hasattr(server, 'method_not_found')
    assert hasattr(server, 'invalid_request')
    assert hasattr(server, 'internal_error')

# Generated at 2022-06-23 14:16:25.973054
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test_obj = JsonRpcServer()
    method = 'error'
    code = -32700
    message = 'Parse error'
    data = None
    result = test_obj.error(code, message, data)
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': code, 'message': message}}
    data = 'error'
    result = test_obj.error(code, message, data)
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': code, 'message': message, 'data': data}}


# Generated at 2022-06-23 14:16:30.179465
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    js = JsonRpcServer()
    resp = js.invalid_params()
    if resp.get('error').get('message') != 'Invalid params':
        return False
    return True

# Unit tets for method internal_error of class JsonRpcServer

# Generated at 2022-06-23 14:16:31.998372
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:16:37.230936
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
        rpc_server = JsonRpcServer()
        response_dict = {
            'jsonrpc': '2.0',
            'id': '1486745206486',
            'error': {
                'code': -32600,
                'message': 'Invalid request',
                'data': ''
            }
        }
        assert(rpc_server.invalid_request() == response_dict)


# Generated at 2022-06-23 14:16:43.340986
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request()
    assert(result['jsonrpc'] == "2.0")
    assert(result['id'] == None)
    assert(result['error']['code'] == -32600)
    assert(result['error']['message'] == "Invalid request")
    assert(result['error']['data'] == None)


# Generated at 2022-06-23 14:16:46.692283
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test:
        def method1(self):
            return 1

        def method2(self, arg1=None, arg2=None):
            return arg1 + arg2
    test = Test()
    server = JsonRpcServer()
    server.register(test)
    assert server._objects



# Generated at 2022-06-23 14:16:57.312363
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'yyyy-mm-dd hh:mm:ss')

    result = server.error(500, 'Some error message')
    test_result = {
        'jsonrpc': '2.0',
        'id': 'yyyy-mm-dd hh:mm:ss',
        'error': {
            'code': 500,
            'message': 'Some error message'
        }
    }
    assert(result == test_result)

    result = server.error(500, 'Some error message', 'error details')

# Generated at 2022-06-23 14:17:01.159790
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    response = server.method_not_found()
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:17:02.967434
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    myobj = JsonRpcServer()
    assert myobj.invalid_params()['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:17:11.676256
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    def method(x, y):
        return x + y

    request = {"method": "foo", "params": [], "id": 0}
    request = json.dumps(request)

    server = JsonRpcServer()
    error = {"jsonrpc": "2.0", "id": 0, "error": {"code": -32600, "message": "Invalid request"}}
    error = json.dumps(error)

    assert server.handle_request(request) == error

    server.register(method)
    response = server.handle_request(request)
    assert json.loads(response) == error

    request = {"method": "foo", "params": [1, 2], "id": 0}
    request = json.dumps(request)

    response = server.handle_request(request)