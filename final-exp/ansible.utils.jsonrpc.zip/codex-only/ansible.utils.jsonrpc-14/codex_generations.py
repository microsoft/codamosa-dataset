

# Generated at 2022-06-23 14:07:02.756431
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    rpc._identifier = "0"
    result = rpc.header()
    expected = {'jsonrpc': '2.0', 'id': '0'}
    assert(result == expected)


# Generated at 2022-06-23 14:07:10.191336
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    setattr(obj, '_identifier', 0)
    assert obj.response() == {"id": 0, "jsonrpc": "2.0"}
    assert obj.response(result='hello world') == {"id": 0, "jsonrpc": "2.0", "result": "hello world"}
    assert obj.response(result=b'hello world') == {"id": 0, "jsonrpc": "2.0", "result": "hello world"}
    assert obj.response(result=bytearray(b'hello world')) == {"id": 0, "jsonrpc": "2.0", "result": "hello world"}

# Generated at 2022-06-23 14:07:13.854290
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    controller = JsonRpcServer()

    response = controller.method_not_found()

    assert response == {"error": {"code": -32601, "message": "Method not found"}, "id": None, "jsonrpc": "2.0"}

# Generated at 2022-06-23 14:07:17.896207
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()
    result = rpc_server.invalid_request({'a': 1})
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'
    assert result['error']['data'] == {'a': 1}


# Generated at 2022-06-23 14:07:22.085329
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import sys
    if "ansible.module_utils.basic.jsonrpc" in sys.modules:
        del sys.modules["ansible.module_utils.basic.jsonrpc"]
    from ansible.module_utils.basic.jsonrpc import JsonRpcServer
    j = JsonRpcServer()
    assert isinstance(j.internal_error("test_data"), dict)


# Generated at 2022-06-23 14:07:23.815919
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    client = JsonRpcServer()
    assert client

# Generated at 2022-06-23 14:07:25.338710
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    assert (24 == len(JsonRpcServer._objects))

# Generated at 2022-06-23 14:07:33.512907
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    code = -32603
    message = 'Internal error'
    data = 'Invalid json format'

    expected = {
        'jsonrpc': '2.0',
        'id': 'test',
        'error': {
            'code': code,
            'message': message,
            'data': data
        }
    }

    cls = JsonRpcServer()
    setattr(cls, '_identifier', 'test')
    response = cls.error(code, message, data)

    assert response == expected



# Generated at 2022-06-23 14:07:40.371493
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    #test: handle_request calls rpc_method with the same name as method,
    #         except when method starts with 'rpc.' or '_'
    #expected: method_not_found is returned
    #assertions: call count of method called, with the same name as method
    #            is 0
    #given: a JsonRpcServer with a non-existent method
    testJsonRpcServer = JsonRpcServer()
    request = {'method': 'test', 'params': "params", 'id': "id"}
    request = to_text(json.dumps(request), errors='surrogate_then_replace')

    JsonRpcServer.handle_request(testJsonRpcServer, request)
    response = json.loads(request)


# Generated at 2022-06-23 14:07:50.100773
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    import re
    import subprocess
    import sys
    import uuid
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import socketserver

    class MockStream(object):
        def __init__(self, request):
            self.request = request

        def get_stdout(self):
            return self.request

        def get_stderr(self):
            return self.request

        def close(self):
            pass

    class TestServer(object):
        def __init__(self, server_address, handler):
            pass

        def serve_forever(self):
            pass

        def shutdown(self):
            pass


# Generated at 2022-06-23 14:08:00.031698
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    rval = server.response()
    assert rval.get('jsonrpc') == '2.0'
    assert rval.get('id') == 1
    assert rval.get('result') == None

    rval = server.response(dict())
    assert rval.get('jsonrpc') == '2.0'
    assert rval.get('id') == 1
    assert rval.get('result') == "{}"

    rval = server.response({'a': 1, 'b': 2})
    assert rval.get('jsonrpc') == '2.0'
    assert rval.get('id') == 1
    assert rval.get('result') == '{"a":1,"b":2}'

# Generated at 2022-06-23 14:08:02.737204
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    display.current_verbosity = 4
    rpc = JsonRpcServer()
    result = rpc.error(code = -11, message = 'error_message', data = 'error_data')
    assert result == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -11, 'message': 'error_message', 'data': 'error_data'}}


# Generated at 2022-06-23 14:08:07.583340
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc = JsonRpcServer()

    result = {"test": "data"}
    rpc._identifier = "test_id"
    response = rpc.response(result)
    assert response == {'jsonrpc': '2.0', 'result': '{"test": "data"}', 'result_type': 'pickle', 'id': 'test_id'}

# Generated at 2022-06-23 14:08:08.235483
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

# Generated at 2022-06-23 14:08:14.293749
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    result = server.handle_request('{"jsonrpc": "2.0", "method": "echo", "id": 1, "params": ["hello"]}')
    assert result == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'



# Generated at 2022-06-23 14:08:21.070629
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    obj.register(obj)
    request = json.dumps({
        'method': 'whatever',
        'params': [],
        'id': 'uuid'
    })
    response = json.loads(obj.handle_request(request))
    if 'error' in response:
        if response['error']['code'] != -32601:
            print("Expected code of -32601 for method_not_found but got %s" % response['error']['code'])
            return False
        if response['error']['message'] != 'Method not found':
            print("Expected message of 'Method not found' but got %s" % response['error']['message'])
            return False
        return True
    print("Error response not found")
    return False


# Generated at 2022-06-23 14:08:27.187553
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    """ Unit Test for method method_not_found of class JsonRpcServer """
    server = JsonRpcServer()
    response = server.method_not_found()
    assert response == {
        u'id': None,
        u'error': {
            u'message': 'Method not found',
            u'code': -32601
        },
        u'jsonrpc': '2.0'
    }

# Generated at 2022-06-23 14:08:32.170500
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    """Test the method method_not_found"""
    server = JsonRpcServer()
    setattr(server, '_identifier', "112233")
    response = server.method_not_found("Some Error")
    assert(response == '{"jsonrpc": "2.0", "id": "112233", "error": {"code": -32601, "message": "Method not found", "data": "Some Error"}}')

# Generated at 2022-06-23 14:08:35.700856
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsr = JsonRpcServer()
    try:
        jsr.handle_request('<unknown>')
    except ValueError:
        pass
    except Exception:
        print("JsonRpcServer.handle_request does not handle ValueError")
        return 1
    else:
        print("JsonRpcServer.handle_request does not handle ValueError")
        return 1
    return 0


# Generated at 2022-06-23 14:08:42.523053
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    host = 'test_host'
    port = 8888
    msg = 'Invalid credentials, cannot connect to router {} port {}'.format(host, port)
    server = JsonRpcServer()
    error = server.method_not_found(data=msg)
    expected_result = '{"id": null, "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found", "data": "Invalid credentials, cannot connect to router test_host port 8888"}}'
    assert error == expected_result



# Generated at 2022-06-23 14:08:46.066557
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    try:
        raise Exception('test_JsonRpcServer_internal_error')
    except Exception as exc:
        JsonRpcServer.internal_error(data=str(exc)) == 'Internal error'

# Generated at 2022-06-23 14:08:49.458803
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc = JsonRpcServer()
    rpc._identifier = 1
    try:
        rpc.invalid_params()
    except Exception as err:
        assert True
    else:
        assert False


# Generated at 2022-06-23 14:08:58.592207
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {
        'ansible_facts': {
            "ansible_module_facts": True
        },
        'warnings': ['hello']
    }

    server.register(server)
    setattr(server, '_identifier', 'test')
    response = server.response(result)
    delattr(server, '_identifier')

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'test'
    assert response['result_type'] == 'pickle'
    assert response['result'] == to_text(cPickle.dumps(result, protocol=0))



# Generated at 2022-06-23 14:09:01.071158
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    r1 = JsonRpcServer()
    setattr(r1, '_identifier', 5)
    assert r1.header() == {'jsonrpc': '2.0', 'id': 5}


# Generated at 2022-06-23 14:09:07.104140
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 101)
    error_response = rpc_server.parse_error('test data')
    assert(error_response == {'jsonrpc': '2.0', 'id': 101, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'test data'}})


# Generated at 2022-06-23 14:09:15.303259
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    rpc = JsonRpcServer()
    rpc.register(rpc)

    request = json.dumps({'jsonrpc': '2.0', 'method': 'response', 'params': [[]]})
    expected = json.dumps(rpc.response())
    assert(expected == rpc.handle_request(request))

    request = json.dumps({'jsonrpc': '2.0', 'method': 'error', 'params': [[]]})
    expected = json.dumps(rpc.error(code=-32603, message='Internal error'))
    assert(expected == rpc.handle_request(request))

    request = json.dumps({'jsonrpc': '2.0', 'method': 'invalid_request', 'params': [[]]})

# Generated at 2022-06-23 14:09:20.194997
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = "some_id"
    result = server.header()
    assert result == {'jsonrpc': '2.0', 'id': server._identifier}



# Generated at 2022-06-23 14:09:22.374723
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    assert hasattr(JsonRpcServer,'register')
    assert callable(getattr(JsonRpcServer,'register'))


# Generated at 2022-06-23 14:09:29.887012
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    assert JsonRpcServer.response({'jsonrpc': '2.0', 'id': '_identifier'}, result={'result': 'test'}) == {'jsonrpc': '2.0', 'id': '_identifier', 'result': {'result': 'test'}}
    assert JsonRpcServer.response({'jsonrpc': '2.0', 'id': '_identifier'}, "test") == {'jsonrpc': '2.0', 'id': '_identifier', 'result': 'test'}
    assert JsonRpcServer.response({'jsonrpc': '2.0', 'id': '_identifier'}) == {'jsonrpc': '2.0', 'id': '_identifier'}

# Generated at 2022-06-23 14:09:31.359355
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    assert 'Internal error' in server.internal_error()['error']['message']

# Generated at 2022-06-23 14:09:33.916698
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    result = JsonRpcServer.error(-32603, 'Internal error', 'Rozkol')
    assert result['id'] == 'Rozkol'


# Generated at 2022-06-23 14:09:37.246715
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    JsonRpcServerObj = JsonRpcServer()
    result = JsonRpcServerObj.invalid_request()
    assert result == {"id": None, "jsonrpc": "2.0", "error": {"code": -32600,
        "message": "Invalid request", "data": None}}

# Generated at 2022-06-23 14:09:43.668281
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Setup
    jsr = JsonRpcServer()
    class MyTestClass:
        def param_checker(self, a, b=20):
            return (a, b)
    instance = MyTestClass()
    jsr.register(instance)
    # Case: Valid call - Method is registered
    request = json.dumps({'jsonrpc': '2.0', 'method': 'param_checker', 'params': [10], 'id': 1})
    expected_response = json.dumps(jsr.response((10, 20)))
    response = jsr.handle_request(request)
    assert response == expected_response
    # Case: Invalid call - Method isn't registered

# Generated at 2022-06-23 14:09:50.841699
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    myobj = {'method_not_found': 'test'}
    jrpc = JsonRpcServer()
    jrpc.register(myobj)
    assert jrpc.method_not_found() == {'error': {'code': -32601, 'message': 'Method not found'}, 'id': None, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:09:53.844079
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 'test_obj')
    header = rpc_server.header()
    assert header == {'jsonrpc': '2.0', 'id': 'test_obj'}



# Generated at 2022-06-23 14:09:58.606585
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer._identifier = 12
    res = jsonRpcServer.internal_error()
    assert res['id'] == 12
    assert res['error']['code'] == -32603
    assert res['error']['message'] == 'Internal error'


# Generated at 2022-06-23 14:10:01.753763
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    rpc_server.handle_request("""{"jsonrpc": "2.0", "method": "rpc.parse_error", "params": [42, 23], "id": 1}""")

# Generated at 2022-06-23 14:10:06.705058
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    error = jrs.internal_error()
    assert error['jsonrpc'] == '2.0'
    assert error['id'] == None
    assert error['error']['code'] == -32603
    assert error['error']['message'] == 'Internal error'

# Generated at 2022-06-23 14:10:17.447886
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils.network.nxos.nxos import nxos_argument_spec
    from ansible.module_utils.network.nxos.nxos import get_connection
    from ansible.module_utils.network.nxos.nxos import run_commands
    import socket
    import ssl
    import os
    import json

    # Mock initial configuration
    argspec = nxos_argument_spec()
    setattr(argspec, 'host', dict(type='str', required=True))
    setattr(argspec, 'username', dict(type='str', required=True, aliases=['user']))
    setattr(argspec, 'password', dict(type='str', required=True, no_log=True))

# Generated at 2022-06-23 14:10:19.308428
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    return JsonRpcServer().invalid_params()


# Generated at 2022-06-23 14:10:23.263625
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found()
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:10:33.918542
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_server = JsonRpcServer()
    test_server._identifier = '1'
    
    result = {'test': 'true'}
    response = test_server.response(result)
    # Test type
    assert type(response) is dict
    # Test headers: id, jsonrpc
    assert response.get('id') == '1'
    assert response.get('jsonrpc') == '2.0'
    # Test body: result
    assert response.get('result') == json.dumps(result)
    # Test result_type
    assert response.get('result_type') is None
    
    result = 'string'
    response = test_server.response(result)
    # Test body: result
    assert response.get('result') == result
    # Test result_type

# Generated at 2022-06-23 14:10:37.504718
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonRpcServer = JsonRpcServer()
    assert jsonRpcServer.method_not_found() == {'id': None, 'error': {'code': -32601, 'message': 'Method not found'}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:10:43.429734
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    params = {
        "jsonrpc": "2.0",
        "id": "1",
        "error": {
            "code": -32700,
            "message": "Parse error",
        }
    }
    jr = JsonRpcServer()
    setattr(jr, '_identifier', "1")
    assert (jr.parse_error() == params)


# Generated at 2022-06-23 14:10:52.992144
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = """{"jsonrpc":"2.0","method":"read_config","params":[],"id":1}"""
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    
if __name__ == '__main__':
    try:
        server = JsonRpcServer()
        server.register(user_defined_object)
        #user_defined_object.method_1()
    except Exception as exc:
        display.vvv(traceback.format_exc())
        #error = server.internal_error(data=to_text(exc, errors='surrogate_then_replace'))
        #response = json

# Generated at 2022-06-23 14:10:58.118926
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc_server = JsonRpcServer()
    assert rpc_server.method_not_found() == {'id': None,
                                             'jsonrpc': '2.0',
                                             'error': {'message': 'Method not found',
                                                       'code': -32601}}

# Generated at 2022-06-23 14:11:01.160574
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    j = JsonRpcServer()
    assert j.invalid_request() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}



# Generated at 2022-06-23 14:11:03.392993
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    js = JsonRpcServer()
    err = js.parse_error()
    assert err['error']['code'] == -32700


# Generated at 2022-06-23 14:11:11.785585
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonRpcServer = JsonRpcServer()
    assert jsonRpcServer.handle_request is not None
    assert jsonRpcServer.register is not None
    assert jsonRpcServer.header is not None
    assert jsonRpcServer.response is not None
    assert jsonRpcServer.error is not None
    assert jsonRpcServer.parse_error is not None
    assert jsonRpcServer.method_not_found is not None
    assert jsonRpcServer.invalid_request is not None
    assert jsonRpcServer.invalid_params is not None
    assert jsonRpcServer.internal_error is not None

# Generated at 2022-06-23 14:11:16.904823
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_data = ("hello", {"hello": "world"}, ["hello", "world"], b"\x80\x03.", 1, True)
    for data in test_data:
        server = JsonRpcServer()
        server._identifier = "0"
        response = server.response(data)
        print(response)


if __name__ == "__main__":
    test_JsonRpcServer_response()

# Generated at 2022-06-23 14:11:25.256832
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Test1(object):
        def two(self, one):
            print("one: %s" % one)
            return two

        def two_1(self, one, two):
            print("one: %s, two: %s" % (one, two))
            return two

    class Test2(object):
        def one(self):
            return {'jsonrpc': '2.0', 'id': 1, 'result': 'success'}

        def two(self, one):
            print("one: %s" % one)
            return two

    try:
        import json
    except ImportError:
        import simplejson as json

    # order of registration matters for class Test2
    obj = JsonRpcServer()
    obj.register(Test1())
    obj.register(Test2())

    # connect

# Generated at 2022-06-23 14:11:31.187295
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test:
        def __init__(self):
            self.arbitrary = "I want this to be arbitrary"

    server = JsonRpcServer()
    first = Test()
    second = Test()
    third = Test()

    server.register(first)
    server.register(second)
    server.register(third)

    assert server._objects == set([first, second, third])


# Generated at 2022-06-23 14:11:34.581213
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    instance = JsonRpcServer()
    assert instance.parse_error() == {"id": None, "error": {"code": -32700, "message": "Parse error"}, "jsonrpc": "2.0"}


# Generated at 2022-06-23 14:11:40.373801
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    class TestClass:

        def __init__(self,disp):
            self.disp=disp;

        def testMethod(self,disp):
            self.disp=disp;
        def testMethod1(self,disp):
            self.disp=disp;

    class TestClass1():

        def __init__(self,disp):
            self.disp=disp;

        def testMethod(self,disp):
            self.disp=disp;
        def testMethod1(self,disp):
            self.disp=disp;


# Generated at 2022-06-23 14:11:47.222363
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class TestJsonRpcServer_register():
        def __init__(self):
            self._objects = ['foo','bar']
        def register(self, obj):
            self._objects.append(obj)
    obj = TestJsonRpcServer_register()
    obj.register('obj')
    assert obj._objects == ['foo', 'bar', 'obj']


# Generated at 2022-06-23 14:11:52.293766
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # Initialize a new object of class JsonRpcServer
    myjsonrpcserver = JsonRpcServer()

    # Call method internal_error of class JsonRpcServer
    myjsonrpcserver.internal_error()

# Generated at 2022-06-23 14:11:58.133919
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server.register(server)
    error_response = server.handle_request(json.dumps({'method': 'internal_error', 'id': '12345'}))
    assert error_response == '{"error": {"code": -32603, "message": "Internal error"}, "id": "12345", "jsonrpc": "2.0"}'

# Generated at 2022-06-23 14:12:03.583756
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Foo(object):
        def __init__(self):
            self.server = JsonRpcServer()

    foo = Foo()

    assert foo.server._objects == set()

    foo.server.register(foo)
    assert foo.server._objects == set([foo])



# Generated at 2022-06-23 14:12:04.938324
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server_instance = JsonRpcServer()
    response = rpc_server_instance.invalid_params()
    assert response.get("error").get("code") == -32602

# Generated at 2022-06-23 14:12:09.092779
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrpc_server = JsonRpcServer()
    result = jrpc_server.invalid_request()
    if result == {'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None, 'jsonrpc': '2.0'}:
        return True
    else:
        return False


# Generated at 2022-06-23 14:12:15.160000
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
  from ansible.module_utils.basic import AnsibleModule
  obj=JsonRpcServer()
  result=obj.method_not_found()
  module=AnsibleModule(argument_spec={})
  assert result['error']['code'] == -32601
  assert result['error']['message'] == 'Method not found'
  module.exit_json(changed=False, meta=result)


# Generated at 2022-06-23 14:12:25.705830
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    receiver_mock = Mock()
    setattr(receiver_mock, "test_method", lambda test_arg: "{test_arg}")

    server = JsonRpcServer()
    server.register(receiver_mock)

    response = server.handle_request(
        '{"jsonrpc": "2.0", "method": "test_method", "params": ["test_arg_value"], "id": "MOCK"}'
    )

    assert json.loads(response) == {"jsonrpc": "2.0", "id": "MOCK", "result_type": "pickle", "result": bytes("{'test_arg': 'test_arg_value'}", 'UTF-8')}

# Generated at 2022-06-23 14:12:27.668307
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    test = JsonRpcServer()
    assert test._objects == set()
    test.register(test)
    assert test._objects == {test}


# Generated at 2022-06-23 14:12:32.330915
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    tester = JsonRpcServer()
    response = tester.invalid_request()
    assert(response == {'id': None,
                        'jsonrpc': '2.0',
                        'error': {
                            'code': -32600,
                            'message': 'Invalid request',
                            'data': None}})


# Generated at 2022-06-23 14:12:42.017544
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six.moves import StringIO

    class StubConnection(Connection):

        def __init__(self, *args, **kwargs):
            self._data = StringIO()
            self._result = {'rc': 0, 'stdout': to_text(self._data.getvalue(), errors='surrogate_then_replace')}

    connection = StubConnection()

    server = JsonRpcServer()
    server.register(connection)
    server.handle_request(to_text(json.dumps({'jsonrpc': '2.0', 'method': 'execute', 'params': [['ls']], 'id': 0}), errors='surrogate_then_replace'))
    assert connection.result['rc'] == 0

    server = J

# Generated at 2022-06-23 14:12:52.119502
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from unittest import TestCase
    from ansible.module_utils.json_rpc_server import JsonRpcServer

    class TestJsonRpcServer(TestCase):
        def setUp(self):
            self.server = JsonRpcServer()

        def test_error(self):
            self.server._identifier = 3
            result = self.server.error(code=100, message='message')
            self.assertEqual(result, {"jsonrpc": "2.0",
                                      "id": 3,
                                      "error": {
                                          "code": 100,
                                          "message": "message"
                                      }
                                      }
                             )

    # Run tests
    import unittest

# Generated at 2022-06-23 14:13:01.274128
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    req_id = setattr(server, '_identifier', 'test_id')


# Generated at 2022-06-23 14:13:12.326006
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import ConnectionError

    def test_module(*args, **kwargs):
        return {'result': {'changed': False, 'foo': 'bar'}}

    display.verbosity = 1
    server = JsonRpcServer()
    jsonrpc = AnsibleModule(argument_spec={}, supports_check_mode=True)
    server.register(jsonrpc)
    server.register(jsonrpc.params)
    server.register(jsonrpc.exit_json)
    server.register(jsonrpc.fail_json)
    server.register(jsonrpc.run_command)
    server.register(jsonrpc.get_bin_path)
    server.register(jsonrpc.add_path_info)


# Generated at 2022-06-23 14:13:18.218545
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    obj = Mock()
    jsonrpc.register(obj)
    jsonrpc.handle_request(b'{"jsonrpc": "2.0", "method": "invalid_params", "params": [], "id": null}')
    assert jsonrpc._identifier == None
    assert obj.invalid_params.called == False


# Generated at 2022-06-23 14:13:23.721091
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(-32600, 'Invalid Request', data='Some data')
    assert error == {'id': None, 'error': {'code': -32600, 'message': 'Invalid Request', 'data': 'Some data'},
                     'jsonrpc': '2.0'}



# Generated at 2022-06-23 14:13:27.013766
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs = JsonRpcServer()
    vars(jrs).update({'_identifier': '0'})
    assert jrs.header() == {"jsonrpc": "2.0", "id": "0"}


# Generated at 2022-06-23 14:13:34.597942
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():

    server = JsonRpcServer()
    assert server is not None
    assert server.handle_request is not None
    assert server.register is not None
    assert server.header is not None
    assert server.response is not None
    assert server.error is not None
    assert server.parse_error is not None
    assert server.method_not_found is not None
    assert server.invalid_request is not None
    assert server.invalid_params is not None
    assert server.internal_error is not None

if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-23 14:13:40.002185
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils.json_rpc import JsonRpcServer
    jrs = JsonRpcServer()
    jrs._identifier = 'abc'
    assert json.dumps(jrs.error(-100, "message", "data")) == '{"jsonrpc": "2.0", "id": "abc", "error": {"code": -100, "message": "message", "data": "data"}}'

# Generated at 2022-06-23 14:13:43.097733
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    s = JsonRpcServer()
    resp = s.invalid_request()
    assert resp != None
    assert resp.get('error') != None
    assert resp.get('error').get('code') == -32600

# Generated at 2022-06-23 14:13:45.734213
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Test:
        pass
    obj = Test()
    server.register(obj)
    assert server._objects == {obj}

# Generated at 2022-06-23 14:13:48.943361
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    """ test method invalid_request of class JsonRpcServer """
    assert isinstance(JsonRpcServer().invalid_request(), dict)


# Generated at 2022-06-23 14:13:59.958410
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    assert server.response() == {'jsonrpc': '2.0', 'id': '1234', 'result': ''}
    assert server.response(result={'jsonrpc': '2.0', 'id': '1234', 'result': 'test'}) == {'jsonrpc': '2.0', 'id': '1234', 'result': {'jsonrpc': '2.0', 'id': '1234', 'result': 'test'}}
    assert server.response(result='test') == {'jsonrpc': '2.0', 'id': '1234', 'result': 'test'}

# Generated at 2022-06-23 14:14:08.389731
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    
    # test 1
    request = {
        'jsonrpc': '2.0',
        'id': 'test',
        'method': 'method',
        'params': (1, 2),
    }
    
    
    import json
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == u'{"error": {"code": -32601, "message": "Method not found"}, "id": "test", "jsonrpc": "2.0"}', 'error test_JsonRpcServer_handle_request #1'

    # test 2
    request = {
        'jsonrpc': '2.0',
        'id': 'test',
        'method': 'method',
        'params': None,
    }

# Generated at 2022-06-23 14:14:15.368192
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer.parse_error(data=None) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': None}}
    assert JsonRpcServer.parse_error(data="some_data") == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': "some_data"}}



# Generated at 2022-06-23 14:14:17.934009
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    JsonRpcServer_obj = JsonRpcServer()
    assert JsonRpcServer_obj.invalid_request().get("jsonrpc") == "2.0"


# Generated at 2022-06-23 14:14:23.844286
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs = JsonRpcServer()

    # Positive tests
    try:
        assert(set(jrs.header().keys()) == {'jsonrpc', 'id'})
    except:
        assert(False)
    finally:
        pass

    # Negative tests
    pass


# Generated at 2022-06-23 14:14:28.454046
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonrpc_server = JsonRpcServer()
    response = jsonrpc_server.parse_error("The data")
    expected = json.dumps({"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error", "data": "The data"}, "id": None})
    assert response == expected


# Generated at 2022-06-23 14:14:32.366237
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert JsonRpcServer().method_not_found() == '{"jsonrpc": "2.0", "id": null, "error": {"code": "-32601", "message": "Method not found"}}'

# Generated at 2022-06-23 14:14:40.344386
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    JsonRpcServer = __import__('ansible.module_utils.remote_management.jsonrpc_server').module_utils.remote_management.jsonrpc_server.JsonRpcServer
    rpcserver = JsonRpcServer()
    rpcserver._identifier = '12'
    assert rpcserver.invalid_params(data=None) == {'jsonrpc': '2.0', 'id': '12', 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}}
    assert rpcserver.invalid_params(data='test') == {'jsonrpc': '2.0', 'id': '12', 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'test'}}

# Generated at 2022-06-23 14:14:45.417535
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc = JsonRpcServer()
    setattr(jsonrpc, '_identifier', '42')
    assert jsonrpc.header() == {'jsonrpc': '2.0', 'id': '42'}
    delattr(jsonrpc, '_identifier')


# Generated at 2022-06-23 14:14:50.945082
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server.register(server)
    setattr(server, '_identifier', '5')
    response = server.response('foo')
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '5'
    assert response['result'] == 'foo'
    assert response.get('result_type') is None


# Generated at 2022-06-23 14:15:00.178162
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    JRS = JsonRpcServer()
    setattr(JRS, '_identifier', 'identifier')
    result = JRS.internal_error()
    assert result['id'] == JRS._identifier
    assert result['jsonrpc'] == '2.0'
    assert result['error'] == {'code': -32603, 'message': 'Internal error', 'data': None}
    assert result['result'] == None
    assert result == {'id': 'identifier', 'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': None}}

    JRS = JsonRpcServer()
    setattr(JRS, '_identifier', 'identifier')
    result = JRS.internal_error(data='This is a fake error')

# Generated at 2022-06-23 14:15:03.390315
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = "12345"
    assert server.header() == {'jsonrpc': '2.0', 'id': "12345"}


# Generated at 2022-06-23 14:15:07.358416
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    import pytest

    with pytest.raises(AttributeError) as exc_info:
        json_rpc = JsonRpcServer()
        assert exc_info.value == "No attribute '_identifier'"


# Generated at 2022-06-23 14:15:13.341863
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.method_not_found()
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:15:17.828160
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error('data')
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'
    assert result['error']['data'] == 'data'


# Generated at 2022-06-23 14:15:23.637021
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()
    assert result == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32700,
            'message': 'Parse error'
        }
    }


# Generated at 2022-06-23 14:15:26.392259
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    try:
        result = JsonRpcServer().invalid_params()
        print(json.dumps(result))
    except NameError:
        pass # no need to print error if the function is renamed


# Generated at 2022-06-23 14:15:27.532373
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()


# Generated at 2022-06-23 14:15:36.529902
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_obj = JsonRpcServer()
    test_obj._identifier = 42
    assert test_obj.response() == {"jsonrpc": "2.0", "id": 42, "result": ""}
    assert test_obj.response("") == {"jsonrpc": "2.0", "id": 42, "result": ""}
    assert test_obj.response("test") == {"jsonrpc": "2.0", "id": 42, "result": "test"}
    assert test_obj.response(test_obj) == {"jsonrpc": "2.0", "id": 42, "result": "", "result_type": "pickle"}
    assert isinstance(test_obj.response("test"), dict)


# Generated at 2022-06-23 14:15:40.972786
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    try:
        result = server.internal_error()
        assert isinstance(result, dict)
    except:
        assert False

# Generated at 2022-06-23 14:15:48.639184
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    identifier = 'identifier'
    setattr(server, '_identifier', identifier)
    result = 'result'
    response = server.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == identifier
    assert response['result'] == result
    result = b'result'
    response = server.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == identifier
    assert response['result'] == 'result'
    assert 'result_type' not in response
    result = {'key': 'value'}
    response = server.response(result)
    assert response['result_type'] == 'pickle'

# Generated at 2022-06-23 14:15:53.702675
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    message = 'Parse error'
    result = server.parse_error()
    assert result['error']['code'] == -32700
    assert result['error']['message'] == message


# Generated at 2022-06-23 14:15:57.175960
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server._identifier = 2
    result = server.internal_error(data='test')
    assert result['id'] == 2


# Generated at 2022-06-23 14:16:07.057503
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_result = {'banner': {'banner': text_type('R1#'), 'result': True}}
    test_data = {'jsonrpc': '2.0', 'id': 1, 'result': to_text(cPickle.dumps(test_result, protocol=0), errors='strict')}
    dummy_JsonRpcServer = JsonRpcServer()
    dummy_JsonRpcServer._identifier = 1
    assert dummy_JsonRpcServer.response(test_result) == test_data
    # Testing with unicode
    test_result = {'banner': {'banner': text_type(u'\u0041\u0042\u0043'), 'result': True}}

# Generated at 2022-06-23 14:16:10.972557
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    response = obj.internal_error()
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-23 14:16:13.831174
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_rpc_server_obj = JsonRpcServer()
    json_rpc_server_obj._identifier = 100
    test_obj = json_rpc_server_obj.header()
    if test_obj.get('jsonrpc') == '2.0' and test_obj.get('id') == 100:
        return True
    else:
        return False


# Generated at 2022-06-23 14:16:25.686597
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    class Test:
        def error(self, code, message, data=None):
            return {
                'jsonrpc': '2.0',
                'id': 'identifier',
                'error': {
                    'code': code,
                    'message': message,
                    'data': data
                }
            }

    obj = Test()
    rpcserver = JsonRpcServer()
    rpcserver.register(obj)
    setattr(rpcserver, '_identifier', 'identifier')
    result = rpcserver.error(1, 'message')
    expected = {
        'jsonrpc': '2.0',
        'id': 'identifier',
        'error': {
            'code': 1,
            'message': 'message'
        }
    }
    assert expected == result

# Generated at 2022-06-23 14:16:30.651042
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class TestObj():
        def first():
            pass
        def second():
            pass
    obj1 = TestObj()
    obj2 = TestObj()
    server.register(obj1)
    server.register(obj2)
    assert server._objects == {obj1, obj2}


# Generated at 2022-06-23 14:16:34.293869
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    assert server.invalid_params() == {'error': {'data': None, 'code': -32602, 'message': 'Invalid params'}, 'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:16:45.932747
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # test_dict
    assert JsonRpcServer().response({'1': '2'}) == {
        "jsonrpc": "2.0",
        "id": None,
        "result": '{"1": "2"}',
    }

    # test_list
    assert JsonRpcServer().response(['1', '2']) == {
        "jsonrpc": "2.0",
        "id": None,
        "result": '[1, 2]',
    }

    # test_str
    assert JsonRpcServer().response('test') == {
        "jsonrpc": "2.0",
        "id": None,
        "result": 'test',
    }

    # test_unicode

# Generated at 2022-06-23 14:16:57.062954
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    unit_test_obj = JsonRpcServer()

    class Base():
        def test_method(self):
            return "test"

    class Derived(Base):
        def test_method(self):
            return "test2"

    unit_test_obj.register(Base())
    assert unit_test_obj.handle_request(json.dumps({'id':1, 'method':'test_method'})) == '{"id": 1, "jsonrpc": "2.0", "result": "test"}'

    unit_test_obj.register(Derived())
    assert unit_test_obj.handle_request(json.dumps({'id':1, 'method':'test_method'})) == '{"id": 1, "jsonrpc": "2.0", "result": "test2"}'

# Generated at 2022-06-23 14:17:02.622684
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc_server = JsonRpcServer()
    setattr(jsonrpc_server, '_identifier', '12345')

    actual = jsonrpc_server.header()

    expected = {'jsonrpc': '2.0', 'id': '12345'}
    assert actual == expected, 'Actual: {0}'.format(actual)
