

# Generated at 2022-06-23 14:07:08.618791
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import create_socket
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.connection import Connection
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.netconf import NetconfConnection

    server = JsonRpcServer()
    conn = Connection(create_socket("/tmp/ansible-connection"))
    netconf = NetconfConnection(conn._socket_path)
    server.register(netconf)

    #rpc_method = getattr(netconf, 'get_config')


# Generated at 2022-06-23 14:07:13.759519
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    print("Running Unit Test for Internal Error")
    print("Expected Result: {'id': '_identifier', 'error': {'message': 'Internal error', 'code': -32603}, 'jsonrpc': '2.0'}")

    json_rpc_server_test = JsonRpcServer()
    setattr(json_rpc_server_test, '_identifier', '_identifier')
    result = json_rpc_server_test.internal_error()

    print("Test Result: {}".format(result))
    assert result == {'id': '_identifier', 'error': {'message': 'Internal error', 'code': -32603}, 'jsonrpc': '2.0'}
    print("Unit Test for Internal Error: Passed\n")


# Generated at 2022-06-23 14:07:17.190312
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    srv = JsonRpcServer()
    srv._identifier = 'ABC'
    result = srv.invalid_request()
    assert result == {'jsonrpc': '2.0', 'id': 'ABC',
                      'error': {'code': -32600, 'message': 'Invalid request'}}

# Generated at 2022-06-23 14:07:20.739580
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}



# Generated at 2022-06-23 14:07:33.135400
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_server = JsonRpcServer()

    # Handle request method returns proper data for valid request
    test_server._identifier = 333
    test_request = {'params': [['this', 'input'], {'key': 'value'}], 'method': 'unimplemented', 'jsonrpc': '2.0', 'id': 333}
    
    expected = '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 333}'
    result = test_server.handle_request(json.dumps(test_request))
    assert expected in result

    # Handle request method returns proper data for invalid request
    test_server._identifier = 332

# Generated at 2022-06-23 14:07:38.918959
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    response = JsonRpcServer().parse_error()
    assert response == {'jsonrpc': '2.0', 'id': -1, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert type(response) == dict
    response = JsonRpcServer().parse_error(data="my_data")
    assert response == {'jsonrpc': '2.0', 'id': -1, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'my_data'}}
    assert type(response) == dict
    display.display("Test Passed")


# Generated at 2022-06-23 14:07:42.824743
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'
    assert error['id'] == 'None'
    assert error['jsonrpc'] == '2.0'


# Generated at 2022-06-23 14:07:46.400342
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    try:
        1/0
    except Exception as e:
        error = server.internal_error(None)
    assert error['error']['code'] == -32603
    assert 'Internal error' in error['error']['message']
    assert 'division by zero' in error['error']['data']


# Generated at 2022-06-23 14:07:56.390067
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class TestClass:
        last_rpc_call = None

        def rpc_call(self, *args, **kwargs):
            self.last_rpc_call = {
                'args': args,
                'kwargs': kwargs
            }

    obj = TestClass()

    server = JsonRpcServer()
    server.register(obj)

    args, kwargs = [1, 2, 3], {'a': 4, 'b': 5}
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'rpc_call',
        'params': [args, kwargs]
    }

    response = server.handle_request(json.dumps(request))


# Generated at 2022-06-23 14:08:04.340867
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import requests

    if sys.version_info.major < 3:
        from urllib import quote
    else:
        from urllib.parse import quote

    from ansible.utils.urls import open_url

    from .client import JsonRpcClient

    class TestModule(object):
        def test_one_arg(self, param):
            return '{} bar'.format(param)

        def test_two_args(self, param1, param2):
            return '{} {}'.format(param1, param2)

        def test_var_args(self, *args):
            return ' '.join(args)


# Generated at 2022-06-23 14:08:07.937976
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    result = server.error(123, "My Message")
    assert result == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': 123, 'message': 'My Message'}}

# Generated at 2022-06-23 14:08:14.965367
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_obj = JsonRpcServer()
    json_obj.register(JsonRpcServer())
    assert (json_obj.handle_request('{"id": 1, "method": "invalid_params"}') ==
            '{"id": 1, "jsonrpc": "2.0", "error": {"data": null, "message": "Invalid params", "code": -32602}}')



# Generated at 2022-06-23 14:08:17.266268
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test(object):
        pass

    test = Test()

    server = JsonRpcServer()
    server.register(test)

    assert Test in server._objects


# Generated at 2022-06-23 14:08:21.400613
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    assert server.internal_error() == {'error': {'code': -32603, 'message': 'Internal error'}, 'id': None, 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:08:26.557641
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server._identifier = '12345'
    assert server.internal_error() == \
        {
            "id": "12345",
            "jsonrpc": "2.0",
            "error": {
                "code": -32603,
                "message": "Internal error"
            }
        }

# Generated at 2022-06-23 14:08:34.884062
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    # create module
    module = AnsibleModule(
        argument_spec=dict(
            host=dict(type='str', required=True),
            port=dict(type='int', required=True),
            user=dict(type='str', required=True),
            password=dict(type='str', required=True, no_log=True),
        )
    )
    # create a connection to switch

# Generated at 2022-06-23 14:08:45.537208
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Register an object with the server to expose via RPC
    server.register(Test())

    # Create a json-rpc request
    method = 'test_method'
    params = [[1,2,3], {'kwarg1': 'val1', 'kwarg2': 'val2'}]
    request = json.dumps({'jsonrpc': '2.0', 'method': method, 'params': params, 'id': 0})
    result = server.handle_request(request)
    assert json.loads(result) == {'jsonrpc': '2.0', 'id': 0, 'result': 'test:1,2,3,kwarg1=val1,kwarg2=val2'}

    # Create a json-r

# Generated at 2022-06-23 14:08:54.158497
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    response = obj.response(True)
    assert response["id"] == None
    assert response["result_type"] == None
    assert response["result"] == True
    response = obj.response("OK")
    assert response["id"] == None
    assert response["result_type"] == None
    assert response["result"] == "OK"
    response = obj.response(dict(a=1, b=2))
    assert response["id"] == None
    assert response["result_type"] == "pickle"
    assert response["result"] == "c__builtin__\ndict\np0\n(dp1\nS'a'\np2\nI1\nsS'b'\np3\nI2\nsb."


# Generated at 2022-06-23 14:08:58.707353
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test_obj = JsonRpcServer()
    test_obj._identifier = 'test_id'
    result = test_obj.error(code=-32700, message='Parse error')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-23 14:09:02.163151
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.six import PY3
    jsonrpc_server = JsonRpcServer()

    # Test with different python versions
    if PY3:
        setattr(jsonrpc_server, '_identifier', 'test123')
        header = jsonrpc_server.header()
        assert header['id'] == 'test123'
        assert header['jsonrpc'] == '2.0'



# Generated at 2022-06-23 14:09:08.146398
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    expected_output = {'jsonrpc': '2.0', 'id': 98989898, 'error': {'code': -32700, 'message': 'Parse error'}}
    obj = JsonRpcServer()
    setattr(obj, '_identifier', 98989898)
    actual_output = obj.parse_error()
    assert actual_output == expected_output


# Generated at 2022-06-23 14:09:11.012639
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    header = j.header()
    if header['jsonrpc'] != '2.0':
        raise Exception('not pass')

test_JsonRpcServer_header()

# Generated at 2022-06-23 14:09:21.682476
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_obj = {"jsonrpc": "2.0", "method": "echo", "params": ["hello", {"k1": "v1", "k2": "v2"}], "id": "123"}
    json_obj = json.dumps(json_obj)

    class TestClass:
        def echo(self, *args, **kwargs):
             return {"jsonrpc": "2.0", "method": "echo", "params": ["hello", {"k1": "v1", "k2": "v2"}], "id": "123"}

    t = TestClass()
    j = JsonRpcServer()
    j.register(t)
    result = j.handle_request(json_obj)
    assert result == json_obj

# Generated at 2022-06-23 14:09:27.502545
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request(): 
    json_rpc_server = JsonRpcServer()
    request = "test"
    result = json_rpc_server.handle_request(request)
    print(result) 

# Generated at 2022-06-23 14:09:35.493570
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    from ansible.module_utils import basic
    import os

    m = basic.AnsibleModule(
        argument_spec={},
    )

    server = JsonRpcServer()
    server.register(m)

    request = {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "invalid_method"
    }
    response = json.loads(server.handle_request(json.dumps(request)))

    assert response.get('error').get('code') == -32601
    assert response.get('error').get('message') == 'Method not found'

# Generated at 2022-06-23 14:09:40.161383
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Obj(object):
        def echo(self, data):
            return data

    class Obj1(object):
        def echo(self, data):
            return data

    server = JsonRpcServer()
    server.register(Obj())
    server.register(Obj1())
    server._objects == set([Obj(), Obj1()])


# Generated at 2022-06-23 14:09:43.137346
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    print("Error message: " + server.method_not_found()['error']['message'])


# Generated at 2022-06-23 14:09:45.799808
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()
    assert rpc

# Generated at 2022-06-23 14:09:49.319201
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Test setup
    test_obj = JsonRpcServer()
    print("Testing JsonRpcServer.parse_error")
    # Test
    output = test_obj.parse_error()
    # Test assertions
    assert output == {'jsonrpc': '2.0',
                      'id': None,
                      'error': {'code': -32700,
                                'message': 'Parse error'}}
    print("Test succeeded")


# Generated at 2022-06-23 14:09:58.083755
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # pylint: disable=no-self-use
    def create_request(method):
        return {
            'method': method,
            'params': [],
            'id': 'identifier'
        }
    request_dict = create_request('cdp_is_enabled')

    request = json.dumps(request_dict)
    server = JsonRpcServer()

    response = server.handle_request(request)

    response_dict = json.loads(response)
    assert response_dict.get('jsonrpc') == '2.0'
    assert response_dict.get('id') == 'identifier'
    assert response_dict.get('error') == \
        {'code': -32603, 'message': 'Internal error'}


# Generated at 2022-06-23 14:10:09.556622
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import json
    js = JsonRpcServer()
    setattr(js, '_identifier', 'testid')
    ret = js.response(['test1', 'test2'])
    assert ret['result'] == ['test1', 'test2']
    assert ret['result_type'] == 'pickle'
    ret = js.response({'test1': 'test2'})
    assert ret['result'] == {'test1': 'test2'}
    assert ret['result_type'] == 'pickle'
    ret = js.response(['test1', 'test2'])
    assert ret['result'] == ['test1', 'test2']
    assert ret['result_type'] == 'pickle'
    ret = js.response(json.dumps({'test1': 'test2'}))
    assert ret

# Generated at 2022-06-23 14:10:14.458004
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    cls = JsonRpcServer
    obj = cls()
    cls._identifier = 3
    expected = {'jsonrpc': '2.0', 'id': 3}
    actual = obj.header()
    assert actual == expected, "Expected '{0}', got '{1}'".format(expected, actual)


# Generated at 2022-06-23 14:10:17.888360
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.internal_error()
    assert result == {'error': {'code': -32603, 'message': 'Internal error'}, 'id': '123', 'jsonrpc': '2.0'}

# Generated at 2022-06-23 14:10:20.095103
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    assert JsonRpcServer().header() == {'jsonrpc': '2.0', 'id': None}

# Generated at 2022-06-23 14:10:24.393314
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer._identifier = 'test_id'
    result = jsonRpcServer.header()
    assert result == {'jsonrpc': '2.0', 'id': 'test_id'}


# Generated at 2022-06-23 14:10:34.965271
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    obj = JsonRpcServer()
    obj.register(obj)

    req = '{"method": "rpc.method_missing", "id": "42", "params": [1,2,3]}'
    res = obj.handle_request(req)
    assert json.loads(res) == {
        "id": "42",
        "error": {
            "code": -32603,
            "message": "Internal error"
        },
        "jsonrpc": "2.0"
    }, "Invalid response"

    req = '{"method": "test_method","id": "42", "params": [1,2,3]}'
    res = obj.handle_request(req)

# Generated at 2022-06-23 14:10:39.909033
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test = JsonRpcServer()
    test._identifier = 1
    res = test.error(100,'test error')
    assert res['jsonrpc'] == '2.0'
    assert res['id'] == 1
    assert res['error']['code'] == 100
    assert res['error']['message'] == 'test error'
    assert 'result' not in res
    assert 'result_type' not in res

# Generated at 2022-06-23 14:10:43.042705
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    params = {}
    obj = server.invalid_params(params)
    assert obj['error']['code'] == -32602
    assert obj['error']['message'] == 'Invalid params'
    assert obj['error']['data'] == params


# Generated at 2022-06-23 14:10:52.659842
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # dict_to_test = dict_to_test
    dict_to_test = {'jsonrpc': '2.0', 'id': -32603, 'error': {'code': -32603, 'message': 'Internal error', 'data': ''}}
    print(dict_to_test['jsonrpc'])
    assert dict_to_test['jsonrpc'] == "2.0"
    print(dict_to_test['id'])
    assert dict_to_test['id'] == -32603
    print(dict_to_test['error'])
    assert dict_to_test['error'] == {'code': -32603, 'message': 'Internal error', 'data': ''}

test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:10:58.412240
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    my_server = JsonRpcServer()
    try:
        my_server.handle_request({'id': '1', 'jsonrpc': '2.0', 'method': 'show', 'params': ([], {})})
    except Exception as exc:
        print(exc)

test_JsonRpcServer_internal_error()

# Generated at 2022-06-23 14:11:04.159543
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jrs = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': '_mock_method', 'params': []}
    request = json.dumps(request)
    result = jrs.handle_request(request)
    result = json.loads(result)
    assert result['error']['code'] == -32600
    assert result['error']['message'] == 'Invalid request'
    assert result['id'] == None
    assert result['jsonrpc'] == '2.0'


# Generated at 2022-06-23 14:11:08.072192
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    j = JsonRpcServer()
    assert j.method_not_found() == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': None}

# Generated at 2022-06-23 14:11:14.219213
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import os

    server = JsonRpcServer()
    server.register(os)

    with open('./tests/jsonrpc/fixtures/handle_request.json', 'r') as f:
        request = json.load(f).get('params')

    with open('./tests/jsonrpc/fixtures/handle_request.response.json', 'r') as f:
        response = json.load(f)

    assert server.handle_request(request) == json.dumps(response)

# Generated at 2022-06-23 14:11:18.143003
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    test_error = JsonRpcServer().invalid_params()
    assert (test_error == { 'error': { 'code': -32602, 'message': 'Invalid params' }, 'id': None, 'jsonrpc': '2.0' })


# Generated at 2022-06-23 14:11:23.412789
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    aJsonRpcServer = JsonRpcServer()
    aJsonRpcServer._identifier = "test"
    output = aJsonRpcServer.invalid_params()
    assert output == {"jsonrpc": "2.0", "id": "test", "error": {"code": -32602, "message": "Invalid params"}}

# Generated at 2022-06-23 14:11:34.575150
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.basic import AnsibleModule

    json_string = '{"params": [], "jsonrpc": "2.0", "id": 0, "method": "get_config"}'
    server = JsonRpcServer()
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    server.register(module)
    response = server.handle_request(json_string)
    result = json.loads(response)
    assert result['result'] == "{'encoding': u'json', 'version': 1, 'candidate': None, 'startup': None, 'running': {}, 'intended': None}"
    assert result['result_type'] == 'pickle'

# Generated at 2022-06-23 14:11:36.347267
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert len(server._objects) == 0
    server.register(server)
    assert len(server._objects) == 1


# Generated at 2022-06-23 14:11:38.060783
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    response = server.error(code=1, message='Error')
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'Error'}}


# Generated at 2022-06-23 14:11:40.022593
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    test_obj = JsonRpcServer()
    response = test_obj.header()
    assert response["jsonrpc"] == "2.0"


# Generated at 2022-06-23 14:11:50.273199
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()
    method = 'rpc.invalid_request'
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': method
    }

    rpc_server._identifier = 1
    response = rpc_server.handle_request(json.dumps(request))
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'error': {
            'code': -32600,
            'message': 'Invalid request'
        },
        'id': 1
    }
    delattr(rpc_server, '_identifier')


# Generated at 2022-06-23 14:11:54.389035
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():    
    # create an instance of class JsonRpcServer
    obj = JsonRpcServer()
    if debug:
        print(obj)
    assert obj is not None
    

# Generated at 2022-06-23 14:12:03.369407
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    json_response = server.internal_error()
    # <class 'str'>
    assert isinstance(json_response, str)
    # {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}}
    assert {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}} == eval(json_response)
    json_response = server.internal_error("data")
    # {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error', 'data': 'data'}}

# Generated at 2022-06-23 14:12:12.502356
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class ClassA(object):
        def rpc_method_a(self):
            pass
    class ClassB(object):
        def rpc_method_b(self):
            pass
    server = JsonRpcServer()
    server.register(ClassA())
    server.register(ClassB())
    method_a = getattr(server, 'rpc_method_a', None)
    method_b = getattr(server, 'rpc_method_b', None)
    assert method_a != None
    assert method_b != None
    assert hasattr(method_a, '__call__')
    assert hasattr(method_b, '__call__')


# Generated at 2022-06-23 14:12:17.340346
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    invalid_params = server.invalid_params()
    assert invalid_params['id'] is None
    assert invalid_params['jsonrpc'] == '2.0'
    assert invalid_params['error']['code'] == -32602
    assert invalid_params['error']['message'] == 'Invalid params'


# Generated at 2022-06-23 14:12:25.423484
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_json_rpc_server = JsonRpcServer()
    test_error = {'code': -32603, 'message': 'Internal error'}
    assert test_json_rpc_server.internal_error() == test_error
    test_error = {'error': {'data': 'test_data', 'code': -32603, 'message': 'Internal error'}, 'jsonrpc': '2.0', 'id': ''}
    assert test_json_rpc_server.internal_error('test_data') == test_error


# Generated at 2022-06-23 14:12:29.035147
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    request = '{"jsonrpc": "2.0", "method": "x", "params": {}, "id": "1"}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:12:33.825168
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    setattr(s, "_identifier", 5)
    result = s.error(404, "Method not found")
    assert result["jsonrpc"] == "2.0"
    assert result["id"] == 5
    assert result["error"]["code"] == 404
    assert result["error"]["message"] == "Method not found"


# Generated at 2022-06-23 14:12:39.093363
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'abcdefg'
    actual = server.error(-32603, 'Internal error', 'This is a test')
    # Actual json response: '{"jsonrpc": "2.0", "result": null, "id": "abcdefg", "error": {"code": -32603, "message": "Internal error", "data": "This is a test"}}'
    expect = json.loads('{"jsonrpc": "2.0", "result": null, "id": "abcdefg", "error": {"code": -32603, "message": "Internal error", "data": "This is a test"}}')
    assert actual == expect


# Generated at 2022-06-23 14:12:42.057388
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    x = JsonRpcServer()
    error = x.internal_error()
    assert error.get('error',{}).get('code') == -32603
    assert error.get('error',{}).get('message') == 'Internal error'

# Generated at 2022-06-23 14:12:44.938456
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # As of now all the test cases of this class are covered in test_JsonRpcHTTPServer
    pass

# Generated at 2022-06-23 14:12:46.617825
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    server.__repr__()
    assert server

# Generated at 2022-06-23 14:12:58.536831
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import ConnectionBase

    rpc_server = JsonRpcServer()

    mock_class = ConnectionBase
    rpc_server.register(mock_class)

    z = 1
    y = 2
    mock_class.send_message = lambda x, y, z: x

    request1 = json.dumps({'method': 'send_message',
                           'params': [z, y, z],
                           'id': 1})
    request2 = json.loads(request1)
    assert rpc_server.handle_request(request1) == request1

    request2['error'] = {'message': 'Method not found', 'code': -32601}
    assert rpc_server.handle_request(request1) == json.dumps(request2)


# Generated at 2022-06-23 14:13:01.766977
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    RpcServer = JsonRpcServer()
    RpcServer.register(None)
    assert RpcServer.method_not_found().get('error').get('message') == 'Method not found'

# Generated at 2022-06-23 14:13:06.308053
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    s = JsonRpcServer()
    s._identifier = 'test'
    error = s.parse_error('test')
    assert error['error']['code'] == -32700
    assert error['error']['message'] == 'Parse error'
    assert error['error']['data'] == 'test'
    assert error['id'] == 'test'


# Generated at 2022-06-23 14:13:08.363240
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    j = JsonRpcServer()
    assert j is not None

# Generated at 2022-06-23 14:13:13.284068
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error('message')
    assert response['jsonrpc'] == '2.0'
    assert response['id'] is None
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'
    assert response['error']['data'] == 'message'

# Generated at 2022-06-23 14:13:16.902423
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    j = JsonRpcServer()
    test = Test()
    j.register(test)
    assert getattr(j, '_objects') == {test}


# Generated at 2022-06-23 14:13:22.613599
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 1
    ret = server.jsonrpc_error(1,2,3)
    assert ret['jsonrpc'] == '2.0'
    assert ret['id'] == 1
    assert ret['error'] == {'code': 1, 'message': 2, 'data': 3}


# Generated at 2022-06-23 14:13:26.625285
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    error = JsonRpcServer().invalid_params('data')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'data'}}


# Generated at 2022-06-23 14:13:29.785227
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    try:
        server = JsonRpcServer()
        server.parse_error("Unexpected error!")
    except Exception as exc:
        assert False, 'Failed test_JsonRpcServer_parse_error: {0}'.format(exc)

# Generated at 2022-06-23 14:13:33.437017
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    server = JsonRpcServer()
    server._identifier = 1

    assert server.header() == {'jsonrpc': '2.0', 'id': server._identifier}

    delattr(server, '_identifier')


# Generated at 2022-06-23 14:13:38.152305
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    print("\n---------------Test method parse_error of class JsonRpcServer---------------")
    server = JsonRpcServer()
    setattr(server, '_identifier', '12345')
    result_dict = server.parse_error()
    print("Parse error method returns: ")
    print(result_dict)


# Generated at 2022-06-23 14:13:41.638092
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrs = JsonRpcServer()
    jrs._identifier = "123"
    ret = jrs.error(-32700, "Parse error", None)
    assert ret == {'jsonrpc': '2.0', 'id': '123',
                       'error': {'code': -32700, 'message': "Parse error"}}

# Generated at 2022-06-23 14:13:46.248832
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    cls = JsonRpcServer()
    setattr(cls, '_identifier', 23)
    response = cls.response({"jsonrpc": "2.0", "result": "success"})
    assert response['result'] == "success"
    assert response['id'] == 23

# Generated at 2022-06-23 14:13:55.116896
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request = dict(
        method='method.not.found',
        params=([], {}),
        id=1
    )
    response = server.handle_request(json.dumps(request))
    resp = json.loads(response)
    assert resp.get('id') == 1
    assert resp.get('error', {}).get('code') == -32601
    assert resp.get('error', {}).get('message') == 'Method not found'
    assert resp.get('error', {}).get('data') is None

# Generated at 2022-06-23 14:13:56.790916
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrpcs = JsonRpcServer();
    result = jrpcs.invalid_params();
    json_str = json.dumps(result);
    print(json_str);


# Generated at 2022-06-23 14:14:00.568178
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    assert JsonRpcServer().invalid_request({'msg': 'Invalid request'}) == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request', 'data': {'msg': 'Invalid request'}}, 'id': 'None'}


# Generated at 2022-06-23 14:14:01.290144
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    pass

# Generated at 2022-06-23 14:14:04.156930
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', '0')
    assert server.header() == {'jsonrpc': '2.0', 'id': '0'}


# Generated at 2022-06-23 14:14:06.403888
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    return True


# Generated at 2022-06-23 14:14:12.523087
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    params = {'method': 'rpc._get_device_info'}
    request = json.dumps(params)
    response = server.handle_request(request)
    result = json.loads(response)
    assert result['error']['code'] == -32600
    assert result['error']['message'] == "Invalid request"



# Generated at 2022-06-23 14:14:16.029473
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    req=JsonRpcServer()
    try:
        result = req.internal_error()
    except:
        result = None
    finally:
        assert result is not None,"Failed to test internal_error"


# Generated at 2022-06-23 14:14:22.797142
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    error = rpc_server.method_not_found()
    error['jsonrpc'] = '2.0'
    error['id'] = 'test_id'
    error.pop('error')
    expected_error = {'code': -32601, 'message': 'Method not found', 'jsonrpc': '2.0', 'id': 'test_id'}
    assert error == expected_error

# Generated at 2022-06-23 14:14:30.926794
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    assert s.error(1, 'test error message') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test error message'}}
    assert s.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert s.method_not_found() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found'}}
    assert s.invalid_request() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}


# Generated at 2022-06-23 14:14:39.725615
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    obj.register(obj)

    result = obj.handle_request(json.dumps({'method': 'method_not_found'}))
    assert json.loads(result) == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': None}

    result = obj.handle_request(json.dumps({'method': 'handle_request'}))
    assert json.loads(result) == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': None}

    result = obj.handle_request(json.dumps({'method': '_handle_request'}))

# Generated at 2022-06-23 14:14:44.559012
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = ({'jsonrpc': '2.0', 'id': '_identifier', 'error': {'code': -32603, 'message': 'Internal error', 'data': None}})
    assert server.internal_error() == result

# Generated at 2022-06-23 14:14:46.047550
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None


# Generated at 2022-06-23 14:14:49.672556
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = "1234"
    response = server.header()
    expected = {'jsonrpc': '2.0', 'id': "1234"}
    assert response == expected


# Generated at 2022-06-23 14:14:55.809156
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc_server = JsonRpcServer()
    rpc_server.register(object())
    method = 'not_exist'
    params = ()
    result = rpc_server.handle_request(json.dumps(dict(id=1, method=method, params=params)))
    assert "jsonrpc" in result
    assert "error" in result
    assert "-32601" in result
    assert "Method not found" in result


# Generated at 2022-06-23 14:14:59.638794
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc_method_register = JsonRpcServer()
    obj1 = object()
    obj2 = object()

    rpc_method_register.register(obj1)
    rpc_method_register.register(obj2)

    assert obj1 in rpc_method_register._objects
    assert obj2 in rpc_method_register._objects

# Generated at 2022-06-23 14:15:10.153019
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """Unit test for method handle_request of class JsonRpcServer"""
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer
    import sys
    import json

    json_rpc = JsonRpcServer()

    class TestClass:

        def __init__(self):
            json_rpc.register(self)

        def sample(self, test_1, test_2=None):
            return test_1 + test_2

    obj = TestClass()


# Generated at 2022-06-23 14:15:21.010341
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import cPickle

    # Create a JsonRpcServer object
    jrpc = JsonRpcServer()

    # Create the request dict
    request = dict()
    request['jsonrpc'] = '2.0'
    request['id'] = '0'
    request['method'] = 'show_version'
    request['params'] = ([], {})

    # Call the handle_request() method of the JsonRpcServer object
    response = jrpc.handle_request(to_bytes(json.dumps(request)))

    # Create the expected response dict
    expected_response = dict()
    expected_response['jsonrpc'] = '2.0'

# Generated at 2022-06-23 14:15:27.077675
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    expected = '{"error": {"code": -32600, "message": "Invalid request"}, "jsonrpc": "2.0", "id": "id"}'
    jsonRpcServer = JsonRpcServer()
    result = jsonRpcServer.invalid_request();
    if (result == expected):
        print(result)
    else:
        print("Expected: "+expected)
        print("Result: "+result)
        print("Unit test failed")
    print("Unit test ended")


# Generated at 2022-06-23 14:15:32.356095
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrpc = JsonRpcServer()
    jrpc._identifier = "test"
    result = jrpc.header()
    assert result == {'id': 'test', 'jsonrpc': '2.0'}

# Unit test function test_JsonRpcServer_response

# Generated at 2022-06-23 14:15:38.803994
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    JsonRpcServer_instance = JsonRpcServer()
    JsonRpcServer_instance.register(__builtins__)

    request = '{"id":1,"method":"print","params":["test"]}'
    response = JsonRpcServer_instance.handle_request(request)

    assert json.loads(response)['id'] == 1
    assert json.loads(response)['result'] == "test\\n"
    assert json.loads(response)['error'] == None

    request = '{"id":1,"method":"random"}'
    response = JsonRpcServer_instance.handle_request(request)

    assert json.loads(response)['id'] == 1
    assert json.loads(response)['result'] != None
    assert json.loads(response)['error'] == None

    request

# Generated at 2022-06-23 14:15:44.412393
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    result = server.handle_request(b'{"method":"not_found","params":[],"id":"0"}')
    response = json.loads(result)
    assert response["error"]["code"] == -32601


# Generated at 2022-06-23 14:15:45.738687
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

    assert server is not None


# Generated at 2022-06-23 14:15:48.896969
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    test_obj = JsonRpcServer()
    response = test_obj.parse_error()

    assert response == {
        "error": {
            "code": -32700,
            "message": "Parse error"
        },
        "id": None,
        "jsonrpc": "2.0"
    }


# Generated at 2022-06-23 14:15:54.171623
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
	j=JsonRpcServer()
	j.register(j)
	assert j.handle_request(json.dumps({"params": [], "method": "method_not_found"})) == json.dumps(j.method_not_found())

# Generated at 2022-06-23 14:15:58.986238
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    assert obj is not None
    obj._objects.clear()
    obj.register(obj)
    assert obj._objects != None
    assert obj._objects != set()
    assert obj._objects.__len__() == 1
    obj._objects.clear()
    return


# Generated at 2022-06-23 14:16:03.071234
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    j = JsonRpcServer()
    assert j.parse_error() == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32700,
            'message': 'Parse error'}
    }



# Generated at 2022-06-23 14:16:08.542841
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params()
    assert response == {
        'jsonrpc': '2.0',
        'id': 'None',
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': None
        }
    }

# Generated at 2022-06-23 14:16:11.560879
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # remotable method
    def parse_error(self, data=None):
        return self.error(-32700, 'Parse error', data)


# Generated at 2022-06-23 14:16:14.546783
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    identifier = '12345'
    setattr(server, '_identifier', identifier)
    data = server.header()
    assert data['jsonrpc'] == '2.0'
    assert data['id'] == identifier


# Generated at 2022-06-23 14:16:17.139911
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    assert j.header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-23 14:16:28.725704
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Testing the handle_request method of class JsonRpcServer
    # Initializing objects of class JsonRpcServer
    myJsonRpcServer = JsonRpcServer()

    # class JsonRpcServer testing method handle_request

    # Testing the method handle_request with correct values
    # and checking if the expected output matches

# Generated at 2022-06-23 14:16:31.813990
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    response = server.header()
    assert response['id'] == 'test_id'


# Generated at 2022-06-23 14:16:33.913332
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import inspect

    server = JsonRpcServer()
    assert inspect.ismethod(server.register) == True


# Generated at 2022-06-23 14:16:38.241210
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request = {'jsonrpc': '2.0', 'method': 'rpc.foo', 'params': [], 'id': None}
    server = JsonRpcServer()
    response = json.loads(server.handle_request(json.dumps(request)))
    assert response['jsonrpc'] == '2.0'
    assert response['error'] == {'code': -32600, 'message': 'Invalid request'}
    assert response['id'] == None


# Generated at 2022-06-23 14:16:42.656317
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    try:
        server = JsonRpcServer()
        result = server.error(code=404, message="Test Error")
    except Exception as e:
        raise(e)
    else:
        print("Returning JSON: {}".format(result))


# Generated at 2022-06-23 14:16:44.922966
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    service = JsonRpcServer()
    setattr(service, '_identifier', 1)
    assert service.header() == {'jsonrpc': '2.0', 'id': 1}


if __name__ == "__main__":
    service = JsonRpcServer()
    setattr(service, '_identifier', 1)
    print(service.header())

# Generated at 2022-06-23 14:16:47.381593
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    rpc_server.invalid_params()

# Generated at 2022-06-23 14:16:58.602981
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Task:
        def hello(self):
            return 'world'

    class ActionModule:
        def hello(self):
            return 'world'

    class MockModule:
        def __init__(self, action_plugin=None, task_plugin=None):
            self.action = action_plugin
            self.task = task_plugin

    rpc_server = JsonRpcServer()
    rpc_server._objects = set()
    rpc_server.register(MockModule(
        action_plugin=ActionModule(),
        task_plugin=Task()))
    request1 = {'jsonrpc': '2.0', 'method': 'hello', 'params': [], 'id': 42}
    result1 = {'jsonrpc': '2.0', 'result': 'world', 'id': 42}
    request2

# Generated at 2022-06-23 14:17:03.045157
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error_msg = server.method_not_found()
    assert error_msg == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32601,
            'message': 'Method not found',
        },
    }