

# Generated at 2022-06-23 14:07:05.265876
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

# Generated at 2022-06-23 14:07:12.331989
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = "test-JsonRpcServer-internal_error"
    ret = json_rpc_server.internal_error()
    assert ret == {"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": "test-JsonRpcServer-internal_error"}


# Generated at 2022-06-23 14:07:17.058414
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    data = "Unit test"
    response = server.internal_error(data)
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'
    assert response['error']['data'] == "Unit test"

# Generated at 2022-06-23 14:07:20.104234
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpcobj = JsonRpcServer()
    rpcobj._identifier = 'test_identifier'
    assert rpcobj.header() == {'jsonrpc': '2.0', 'id': 'test_identifier'}


# Generated at 2022-06-23 14:07:29.803015
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
  print('Method error of class JsonRpcServer:')
  from ansible.module_utils.basic import AnsibleModule
  module = AnsibleModule(argument_spec={})
  json_rpc = JsonRpcServer()
  json_rpc.register(module)
  response = module._run_method('error', [-1, 'message', 'data'])
  print('Response should be {}, and is {}'.format('{"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "message", "data": "data"}}', response))


# Generated at 2022-06-23 14:07:31.589669
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    err = JsonRpcServer().parse_error()
    assert err['error']['code'] == '-32700'


# Generated at 2022-06-23 14:07:33.619314
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['error']['code'] == -32602

# Generated at 2022-06-23 14:07:35.941470
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs = JsonRpcServer()
    jrs._identifier = 1

    response = jrs.invalid_params('data')

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'
    assert response['error']['data'] == 'data'

# Generated at 2022-06-23 14:07:40.015162
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    data = {'code': -32700, 'message': 'Parse error', 'error': {'data': {1:2, 3:4}}}
    assert server.parse_error({1:2, 3:4}) == data


# Generated at 2022-06-23 14:07:43.038546
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = object()
    server = JsonRpcServer()
    server.register(obj)
    assert obj in server._objects


# Generated at 2022-06-23 14:07:48.320566
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert isinstance(error, dict)
    assert error['id'] == None
    assert error['jsonrpc'] == "2.0"
    assert error['error']['code'] == -32600
    assert error['error']['message'] == "Invalid request"
    assert error['error']['data'] == None


# Generated at 2022-06-23 14:07:50.506715
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    result = JsonRpcServer().error(100, "Test error")
    assert '"code": 100' in result
    assert '"message": "Test error"' in result



# Generated at 2022-06-23 14:07:53.981303
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    expected = {'jsonrpc': '2.0', 'id': None}
    server = JsonRpcServer()
    result = server.header()
    assert expected == result


# Generated at 2022-06-23 14:08:01.161169
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    instance = JsonRpcServer()
    setattr(instance, '_identifier', 100)
    payload = {
        "jsonrpc": "2.0",
        "method": "testmethod",
        "params": [
            "testparams"
        ],
        "id": 100
    }
    response = instance.response(payload)
    assert len(response) == 2
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 100


# Generated at 2022-06-23 14:08:03.346319
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 3)
    assert server.header() == {'jsonrpc': '2.0', 'id': 3}


# Generated at 2022-06-23 14:08:07.667846
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrpc = JsonRpcServer()

    response = jrpc.invalid_params('invalid_params')
    assert(response['error']['code'] == -32602)
    assert(response['error']['message'] == 'Invalid params')
    assert(response['error']['data'] == 'invalid_params')


# Generated at 2022-06-23 14:08:13.440622
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    id = 10
    setattr(server, '_identifier', id)
    response = server.header()
    assert response['id'] == id
    assert response['jsonrpc'] == "2.0"
    delattr(server, '_identifier')


# Generated at 2022-06-23 14:08:17.304746
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error(data=None)
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == None
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'

# Generated at 2022-06-23 14:08:21.896523
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    error = jsonrpc.invalid_params()
    assert(error['error']['code'] == -32602)
    assert(error['error']['message'] == 'Invalid params')


# Generated at 2022-06-23 14:08:27.498856
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(MockObj())
    response = server.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["echo message"], "id": "1"}')
    assert response == '{"jsonrpc": "2.0", "id": "1", "result": "echo message"}'


# Generated at 2022-06-23 14:08:31.523494
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    expected_response = {
        "jsonrpc": "2.0",
        "id": "_identifier",
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None
        }
    }
    assert expected_response == JsonRpcServer().invalid_request()

# Generated at 2022-06-23 14:08:36.358849
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test(object):

        def method(self):
            pass

        def second(self):
            pass

    jrs = JsonRpcServer()
    jrs.register(Test())
    jrs.register(Test())
    jrs.register(Test())
    jrs.register(Test())
    jrs.register(Test())

    assert len(jrs._objects) == 5



# Generated at 2022-06-23 14:08:39.585430
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = '123'
    header = server.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == '123'


# Generated at 2022-06-23 14:08:45.739868
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    display.debug("Running test_JsonRpcServer_error")
    server = JsonRpcServer()
    iden = 'My_ID'
    setattr(server, '_identifier', iden)
    code = -32602
    msg = 'Invalid params'
    data = "data"
    res = server.error(code, msg, data)
    exp = {'result': None, 'jsonrpc': '2.0', 'id': iden, 'error': {'code': code, 'message': msg, 'data': data}}
    assert res == exp


# Generated at 2022-06-23 14:08:47.678226
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Foo:
        pass
    server.register(Foo)
    assert len(server._objects) == 1


# Generated at 2022-06-23 14:08:53.298625
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import module_utils.network.nxos.nxos
    jrpc_server = JsonRpcServer()
    device = module_utils.network.nxos.nxos.Nxos
    assert id(device) not in [id(obj) for obj in jrpc_server._objects]
    jrpc_server.register(device)
    assert id(device) in [id(obj) for obj in jrpc_server._objects]

# Generated at 2022-06-23 14:08:56.627686
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    '''The function tests the response function of the JsonRpcServer class'''
    rpc_server = JsonRpcServer()
    # The test will pass if the response is a json object
    assert isinstance(rpc_server.response(), dict)


# Generated at 2022-06-23 14:09:00.229655
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Arrange
    server = JsonRpcServer()
    # Act
    result = server.invalid_params()
    # Assert
    assert result == {'id': None, 'error': {'data': None, 'code': -32602, 'message': 'Invalid params'}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:09:06.962085
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jr = JsonRpcServer()
    jr.register(jr)
    result = jr.handle_request(json.dumps({
        u'jsonrpc': u'2.0',
        u'method': u'error',
        u'params': [1, u'message', u'data'],
        u'id': 1
        }))
    result = json.loads(result)
    print(result)


# Generated at 2022-06-23 14:09:12.927249
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    """Unit test method invalid_request of class JsonRpcServer"""
    expected_result = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None
        }
    }
    j_rpc_srv = JsonRpcServer()
    result = j_rpc_srv.invalid_request()
    assert result == expected_result


# Generated at 2022-06-23 14:09:18.177916
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Handler1:
        pass

    class Handler2:
        pass

    srv = JsonRpcServer()
    srv.register(Handler1)

    assert Handler1 in srv._objects
    assert Handler2 not in srv._objects



# Generated at 2022-06-23 14:09:27.417411
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class A(object):
        def hello_world(self):
            return 'Hello World!'

    class B(object):
        def foo(self, bar, baz):
            return bar, baz

    rpc = JsonRpcServer()
    rpc.register(A())
    rpc.register(B())

    result = rpc.handle_request('{"jsonrpc": "2.0", "method": "hello_world", "params": [], "id": 123}')
    assert json.loads(result) == {
        'id': 123,
        'result': 'Hello World!',
        'jsonrpc': '2.0'
    }


# Generated at 2022-06-23 14:09:32.546896
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test = JsonRpcServer()
    result = {'changed': False, 'foo': 'bar'}
    response = test.response(result)
    assert 'jsonrpc' in response
    assert 'id' in response
    assert 'result' in response
    assert response['result'] == result
    assert 'result_type' not in response

# Generated at 2022-06-23 14:09:36.485286
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {'somekey': 'somevalue'}
    response = server.response(result)
    result = cPickle.loads(cPickle.dumps(json.dumps(response)))
    assert type(result) == str
    assert 'somekey' in result
    assert 'somevalue' in result

# Generated at 2022-06-23 14:09:41.913228
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Test initialize class
    server = JsonRpcServer()
    # Test using wrong data type for attribute id
    server._identifier = "wrong type"
    # Test what happens when executing function with wrong data type for attribute id
    response = server.header()
    # Check if response is a string
    assert isinstance(response, str)
    # Check if response contains jsonrpc string
    assert 'jsonrpc' in response
    # Check if response contains id of wrong data type
    assert response["id"] == "wrong type"


# Generated at 2022-06-23 14:09:42.834119
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-23 14:09:50.585156
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    print('obj: {}'.format(obj))
    print(obj.header())
    print(obj.response())
    print(obj.error(1, 'internal'))
    print(obj.parse_error())
    print(obj.method_not_found())
    print(obj.invalid_request())
    print(obj.invalid_params())
    print(obj.internal_error())

# Generated at 2022-06-23 14:09:53.638859
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrpc = JsonRpcServer()
    jrpc._identifier = 11
    assert jrpc.header() == {'jsonrpc': '2.0', 'id': 11}
    delattr(jrpc, '_identifier')
    

# Generated at 2022-06-23 14:09:56.025493
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 0)
    assert server.header() == {'jsonrpc': '2.0', 'id': 0}


# Generated at 2022-06-23 14:10:00.682184
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    TestServer = JsonRpcServer()
    TestServer._identifier = 1234
    invalid_params = TestServer.invalid_params()
    expected = {'jsonrpc': '2.0', 'id': 1234, 'error': {'code': -32602, 'message': 'Invalid params'}}
    assert invalid_params == expected

# Generated at 2022-06-23 14:10:12.538354
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)

    # Expected to return unicode
    result = server.response(result='foo')
    assert(isinstance(result, dict) and result['result'] == 'foo')

    # Expected to return json serializable
    result = server.response(result={'foo': 'bar'})
    assert('result_type' in result and result['result_type'] == 'pickle')

    # Expected to return unicode
    result = server.response(result=u'foo')
    assert(isinstance(result, dict) and result['result'] == u'foo')

    delattr(server, '_identifier')

    # Expected to return unicode
    result = server.response(result='foo')

# Generated at 2022-06-23 14:10:18.263988
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    import pytest
    def _header():
        rpc_server._identifier = 42
        return rpc_server.header()

    rpc_server = JsonRpcServer()

    # _identifier is correct
    rpc_server._identifier = 42
    assert rpc_server.header() == {'jsonrpc': '2.0', 'id': rpc_server._identifier}

    # _identifier is missing
    with pytest.raises(AttributeError):
        _header()


# Generated at 2022-06-23 14:10:23.699063
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class TestClass:
        def __init__(self):
            self.register = JsonRpcServer().register(self)

        def test_method(self):
            pass

    Test1 = TestClass()
    Test2 = TestClass()

    Test1.register
    Test2.register

    assert(Test1.register == Test2.register)

# Generated at 2022-06-23 14:10:28.835029
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc_server = JsonRpcServer()
    class TestClass(object):
        pass
    test_class = TestClass()
    assert test_class not in jsonrpc_server._objects
    jsonrpc_server.register(test_class)
    assert test_class in jsonrpc_server._objects


# Generated at 2022-06-23 14:10:32.793099
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '00001')
    result = "response"
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '00001', 'result': 'response'}

# Generated at 2022-06-23 14:10:36.345446
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    obj = JsonRpcServer()
    assert isinstance(obj.header(), dict)
    assert obj.header()['jsonrpc'] == '2.0'
    assert obj.header()['id'] is None


# Generated at 2022-06-23 14:10:39.490619
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Command(object):
        def echo(self, text):
            return text
    command = Command()
    server.register(command)
    assert command in server._objects

# Generated at 2022-06-23 14:10:43.140912
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    res = server.internal_error(data=None)
    assert res == {'id': None, 'error': {'message': 'Internal error', 'code': -32603}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:10:51.158416
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    res = s.error(1, "message")
    assert res == {
        'id': None,
        'error': {'code': 1, 'message': 'message'},
        'jsonrpc': '2.0'
        }
    res = s.error(1, "message", "data")
    assert res == {
        'id': None,
        'error': {'code': 1, 'message': 'message', 'data': 'data'},
        'jsonrpc': '2.0'
        }

# Generated at 2022-06-23 14:10:56.709908
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    test_obj = object()
    test_obj1 = object()
    # check all objects are registed in class
    cls = JsonRpcServer()
    cls.register(test_obj)
    cls.register(test_obj1)
    assert cls._objects == {test_obj, test_obj1}

# Generated at 2022-06-23 14:11:05.161667
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import types
    import pytest
    server = JsonRpcServer()

    result = server.error(1, "message")
    assert isinstance(result, types.DictType)
    assert result['id'] is None
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == 1
    assert result['error']['message'] == "message"
    assert result['error'].get('data') is None

    result = server.error(1, "message", data='error-data')
    assert isinstance(result, types.DictType)
    assert result['id'] is None
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == 1
    assert result['error']['message'] == "message"

# Generated at 2022-06-23 14:11:13.485263
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Set up mock
    class MockObject(object):
        pass
    server = JsonRpcServer()
    server.register(MockObject())
    expected = {
        "jsonrpc": "2.0",
        "result": None,
        "id": None,
        "error": {
            "code": -32700,
            "message": "Parse error",
            "data": None
        }
    }

    # Run code being tested
    result = server.parse_error()

    # Assert Expected vs Actual
    assert(expected == result)


# Generated at 2022-06-23 14:11:23.851834
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.json_rpc_server import JsonRpcServer
    server = JsonRpcServer()

    result = "listen-address=192.168.1.1"
    server._identifier = 0
    response = server.response(result)
    assert response == {"result": "listen-address=192.168.1.1", "id": 0, "jsonrpc": "2.0"}

    result = u"listen-address=192.168.1.1"
    server._identifier = 0
    response = server.response(result)
    assert response == {"result": u"listen-address=192.168.1.1", "id": 0, "jsonrpc": "2.0"}

    result = [1, 2, 3]
    server._identifier = 0


# Generated at 2022-06-23 14:11:25.761001
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jrs = JsonRpcServer()
    assert jrs

if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-23 14:11:29.010108
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    assert json_rpc_server in json_rpc_server._objects


# Generated at 2022-06-23 14:11:37.166766
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {'foo': 'bar'}
    assert server.response(result) == {'jsonrpc': '2.0', 'id': 'None', 'result': {'foo': 'bar'}}

    result = 'test-encoding'
    assert server.response(result) == {'jsonrpc': '2.0', 'id': 'None', 'result': 'test-encoding'}

    result = {u'foo': 'bar'}
    assert server.response(result) == {'jsonrpc': '2.0', 'id': 'None', 'result': {u'foo': 'bar'}}

# Generated at 2022-06-23 14:11:38.578591
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server.header()


# Generated at 2022-06-23 14:11:43.283891
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    rpc_server.register(rpc_server)
    try:
        rpc_server.handle_request('{"id":null,"method":"error","params":["Parse error",-32700]}')
    except Exception as exc:
        print(exc)

# Generated at 2022-06-23 14:11:48.148358
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpcsrv = JsonRpcServer()
    setattr(jsonrpcsrv, '_identifier', 1)
    assert jsonrpcsrv.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:11:57.370320
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    
    connection = Connection()
    request = {
        "jsonrpc": "2.0",
        "method": "get_inventory",
        "params": "[]",
        "id": 1
    }
    
    json_rpc = JsonRpcServer()
    json_rpc.register(connection)
    response = json_rpc.handle_request(json.dumps(request))
    print(response)

if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-23 14:12:01.343944
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server._objects = set()
    server.register("obj")
    assert server._objects == {"obj"}


# Generated at 2022-06-23 14:12:02.553519
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()


# Generated at 2022-06-23 14:12:07.363272
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    s = JsonRpcServer()
    r = s.response('hello')
    assert r['result'] == 'hello'
    assert r['jsonrpc'] == '2.0'
    r = s.response(4)
    assert r['result'] == '4'
    assert r['jsonrpc'] == '2.0'


# Generated at 2022-06-23 14:12:17.002115
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_server = JsonRpcServer()
    result = test_server.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["doit"], "id": 1}')
    assert result == '{"jsonrpc": "2.0", "id": 1}'
    result = test_server.handle_request('"jsonrpc": "2.0", "method": "echo", "params": ["doit"], "id": 1')
    assert result == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'
    result = test_server.handle_request('{"jsonrpc": "2.0", "method": "echo", "id": 1}')

# Generated at 2022-06-23 14:12:20.234470
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    assert server.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:12:23.595808
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()
    assert isinstance(rpc, JsonRpcServer)
    assert not hasattr(rpc, '_identifier')



# Generated at 2022-06-23 14:12:26.642327
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jsonrpc = JsonRpcServer()
    assert jsonrpc.invalid_request()['error']['code'] == -32600
    assert jsonrpc.invalid_request()['error']['message'] == 'Invalid request'

# Generated at 2022-06-23 14:12:30.897700
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrpc = JsonRpcServer()
    response = jrpc.method_not_found()
    assert response['id'] == None
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-23 14:12:34.624221
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    s = JsonRpcServer()
    err = s.method_not_found()
    expected = {u'id': None, u'error': {u'message': u'Method not found', u'code': -32601}, u'jsonrpc': u'2.0'}
    assert err == expected

# Generated at 2022-06-23 14:12:36.616320
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = None
    rpc_server.internal_error()

# Generated at 2022-06-23 14:12:41.819367
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    config_data = {
        "method": "rpc.parse_error",
        "params": [],
        "id": 12345
    }
    server = JsonRpcServer()
    response = server.handle_request(config_data)
    json_data = json.loads(response)
    assert json_data['error']['code'] == -32700

# Generated at 2022-06-23 14:12:45.508250
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server.register("hello")
    assert(server._objects == set("hello"))


# Generated at 2022-06-23 14:12:53.531878
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    """
    Test to check method handle_request of class JsonRpcServer
    """
    try:
        from ansible.module_utils.network.cnos.cnos import cnos
        from ansible.module_utils.network.cnos.cnos import get_capabilities
    except Exception:
        print("Module unavailable")
        return False
    request = '{"id": "1", "jsonrpc": "2.0", '
    request = request + '"method": "get_config", '
    request = request + '"params": [{"src": "running-config"}, {"flag": ""}]}'
    request = request.encode('utf-8')
    obj = JsonRpcServer()
    test_obj = cnos()
    obj.register(test_obj)

# Generated at 2022-06-23 14:12:58.057094
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsrs = JsonRpcServer()
    next_json = jsrs.invalid_params()
    expected_json = '{"jsonrpc": "2.0", "id": null, "error": {"code": -32602, "message": "Invalid params"}}'
    assert next_json == expected_json


# Generated at 2022-06-23 14:13:01.814289
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpcsrv = JsonRpcServer()
    setattr(rpcsrv, '_identifier', 3)
    hdr = rpcsrv.header()
    assert hdr['id'] == 3


# Generated at 2022-06-23 14:13:07.572549
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print ("\n===== Test 'handle_request' method of class JsonRpcServer=====")
    request = {'method': 'get_device_info'}
    request = json.dumps(request)
    rpcserver = JsonRpcServer()
    assert (rpcserver.handle_request(request) == rpcserver.method_not_found())
    print ("Testcase is passed")

# unit test of JsonRpcServer class
test_JsonRpcServer_handle_request()

# Generated at 2022-06-23 14:13:13.831286
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():

    t = JsonRpcServer()
    assert t.parse_error() == {'jsonrpc': '2.0', 'id': 0, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert t.parse_error('test') == {'jsonrpc': '2.0', 'id': 0, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'test'}}



# Generated at 2022-06-23 14:13:18.479690
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    c = JsonRpcServer()
    assert c.error(1, "An error message", {}) == {'id': None, 'error': {'code': 1, 'message': 'An error message', 'data': {}}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:13:22.614173
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    r = server.parse_error()
    assert r['error']['message'] == 'Parse error'
    assert r['error']['code'] == -32700


# Generated at 2022-06-23 14:13:27.398906
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
	JsonRpcServer_instance = JsonRpcServer()
	JsonRpcServer_instance._identifier = "an_id"
	result = JsonRpcServer_instance.response()
	expected = {'id':'an_id', 'jsonrpc':'2.0'}
	assert result == expected


# Generated at 2022-06-23 14:13:31.082581
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():

    server = JsonRpcServer()
    response = server.handle_request(json.dumps({"jsonrpc":"2.0", "method":"method_not_found", "params":[], "id":0}))
    assert json.loads(response)["error"]["code"] == -32601

# Generated at 2022-06-23 14:13:38.023250
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    response = obj.method_not_found()
    assert isinstance(response, dict)
    assert response.get('id') is None
    assert response.get('jsonrpc') == '2.0'
    assert isinstance(response.get('error'), dict)
    assert response.get('error').get('code') == -32601
    assert response.get('error').get('message') == 'Method not found'
    assert response.get('error').get('data') is None

# Generated at 2022-06-23 14:13:40.507915
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Create the object
    obj = JsonRpcServer()

    # Testing method invalid_params and its return value
    assert isinstance(obj.invalid_params(), dict)

# Generated at 2022-06-23 14:13:45.734213
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.method_not_found() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found'}}

test_JsonRpcServer_method_not_found()



# Generated at 2022-06-23 14:13:57.835991
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jr = JsonRpcServer()
    # Test for method invalid_params of class JsonRpcServer
    # Test for method header of class JsonRpcServer
    # Test for method error of class JsonRpcServer
    response = jr.invalid_params()
    jr._identifier = "123"
    assert response == {u'id': '123', u'jsonrpc': '2.0', u'error': {u'code': -32602, u'message': u'Invalid params'}}
    # Test for method error of class JsonRpcServer
    # Test for method header of class JsonRpcServer
    response = jr.invalid_params("data")
    jr._identifier = "123"

# Generated at 2022-06-23 14:14:02.624411
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = 1
    assert rpc_server.parse_error(data='a') == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32700, "message": "Parse error", "data": "a"}}


# Generated at 2022-06-23 14:14:04.648525
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    assert JsonRpcServer.invalid_params.__name__ == "invalid_params"

# Generated at 2022-06-23 14:14:06.625107
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    j = JsonRpcServer()
    assert j

# Generated at 2022-06-23 14:14:11.790976
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    assert server.internal_error() == {'jsonrpc': '2.0', 'id': '123', 'error': {'code': -32603, 'message': 'Internal error', 'data': None}}


# Generated at 2022-06-23 14:14:16.114563
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    srv = JsonRpcServer()
    data = {'method': 'invalid_request'}
    result = srv.invalid_request(data)
    assert result['error']['message'] == 'Invalid request'
    assert result['error']['data'] == data


# Generated at 2022-06-23 14:14:26.361224
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

    assert(isinstance(server, JsonRpcServer))
    assert(isinstance(server.handle_request, object))
    assert(isinstance(server.register, object))
    assert(isinstance(server.header, object))
    assert(isinstance(server.response, object))
    assert(isinstance(server.error, object))
    assert(isinstance(server.parse_error, object))
    assert(isinstance(server.method_not_found, object))
    assert(isinstance(server.invalid_request, object))
    assert(isinstance(server.invalid_params, object))
    assert(isinstance(server.internal_error, object))

# Generated at 2022-06-23 14:14:33.871911
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class MyClass(object):
        pass
    jsonrpc_obj = JsonRpcServer()
    jsonrpc_obj.register(MyClass())
    req = {'jsonrpc': '2.0', 'method': 'get_config', 'id': 1}
    error = jsonrpc_obj.handle_request(json.dumps(req))
    assert error == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'



# Generated at 2022-06-23 14:14:34.813597
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Not implemented yet
    pass


# Generated at 2022-06-23 14:14:39.419354
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    stub_obj = JsonRpcServer()
    test_data = {'id': 'test_id', 'method': 'invalid_method', 'params': []}
    test_result = {'id': 'test_id', 'method': 'invalid_method',
                   'error': {'code': -32601, 'message': 'Method not found'}}
    assert stub_obj.handle_request(test_data) == test_result


# Generated at 2022-06-23 14:14:44.147019
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs = JsonRpcServer()
    resp = jrs.invalid_params()
    assert resp == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}}


# Generated at 2022-06-23 14:14:54.826228
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    assert json_rpc_server.handle_request("{}") == '{"jsonrpc": "2.0", "error": {"code": -32600, ' \
                                                   '"message": "Invalid request"}, "id": null}'
    assert json_rpc_server.handle_request('{"method": "rpc.method", "id": null, "params": '
                                          '(["arg1", "arg2"], {"kwarg1": "kwarg1"})}') == '{"jsonrpc": "2.0", "error": {"code": -32600, ' \
                                                                                           '"message": "Invalid request"}, "id": null}'

# Generated at 2022-06-23 14:15:01.256687
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    class object(object):
        def method(self):
            pass
    srv = JsonRpcServer()
    obj = object()
    srv.register(obj)

    request = json.dumps({'method': 'method', 'params': [], 'id': 'id'})
    response = srv.handle_request(request)
    response = json.loads(response)

    assert response['id'] == 'id'
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'


# Generated at 2022-06-23 14:15:05.692886
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    assert error == {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
    error = server.parse_error("data")
    assert error == {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error", "data": "data"}}


# Generated at 2022-06-23 14:15:08.043385
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    obj = {}
    server.register(obj)
    assert obj in server._objects


# Generated at 2022-06-23 14:15:15.552241
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
	expected = '''{"error": {"code": -32602, "message": "Invalid params"}, "id": "123456789", "jsonrpc": "2.0"}'''
	test_JsonRpcServer = JsonRpcServer()
	test_JsonRpcServer._identifier = "123456789"
	assert test_JsonRpcServer.invalid_params() == json.loads(expected)


# Generated at 2022-06-23 14:15:20.557911
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 1
    result = server.header()
    assert result == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:15:25.787164
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'rpc.run', 'id': 1}
    data = server.parse_error('JSON parsing error')

    assert data['error']['code'] == -32700
    assert data['error']['message'] == 'Parse error'
    assert data['error']['data'] == 'JSON parsing error'


# Generated at 2022-06-23 14:15:26.831210
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rs = JsonRpcServer()

# Generated at 2022-06-23 14:15:34.243896
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    message = 'Internal error'
    data = 'exception'

    error = JsonRpcServer().internal_error(data)
    assert error.get('jsonrpc') == '2.0'
    assert error.get('id') == 'test_JsonRpcServer_internal_error'
    assert error.get('error').get('code') == -32603
    assert error.get('error').get('message') == message
    assert error.get('error').get('data') == data



# Generated at 2022-06-23 14:15:45.698112
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    #
    # setup
    #
    # create a connection object and initialize it with stubs
    conn = JsonRpcServer()

    #
    # execution
    #
    # run the register method
    conn.register(conn)
    # run the handle_request method
    conn.handle_request('{"jsonrpc": "2.0", "method": "funtion_name_ann", "params": [1,2,3], "id": 0}')

    #
    # verification
    #
    # verify that all of the stubbed methods have been called
    # and all expected values have been validated
    assert conn != None

    #
    # cleanup
    #
    # all of the stubbed methods must be restored
    # and any other cleanup must be completed
    #

# Generated at 2022-06-23 14:15:46.767333
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonrpc_server = JsonRpcServer()
    assert jsonrpc_server

# Generated at 2022-06-23 14:15:55.942638
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    msg = {"jsonrpc": "2.0", "params": [[],{}], "method": "test", "id": 1}
    try:
        server.handle_request(msg)
    except Exception as e:
        assert(str(e) == "Method not found")
    server.register(_unit_test_module)
    try:
        resp = server.handle_request(msg)
        assert(resp == "Method \"test\" executed")
    except Exception as e:
        assert(False)


# Generated at 2022-06-23 14:15:59.395429
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():

    class TestClass(object):
        def rpc_method(self):
            return 'test'

    server = JsonRpcServer()
    server.register(TestClass())

    assert server._objects == set([TestClass()])



# Generated at 2022-06-23 14:16:03.558268
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    objJsonRpcServer = JsonRpcServer()
    id = 'test'
    objJsonRpcServer._identifier = id
    ret = objJsonRpcServer.header()
    assert ret == {'jsonrpc': '2.0', 'id': id}


# Generated at 2022-06-23 14:16:13.158568
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Create a instance of JsonRpcServer
    json_rpc_server = JsonRpcServer()

    # Create a dict object and append it to the attrbute _objects of the class JsonRpcServer
    # with 'request' as key and the value will be the object of class X.
    # Create a instance of class X
    class X(object):
        def trivial(self):
            return 42

    x = X()

    json_rpc_server._objects.add(x)

    # Create a dict object with request and params as keys
    request = {'method': 'trivial', 'params': ([], {})}

    # Convert the dict object to json object
    request = json.dumps(request)

    # convert the json object to json string
    request = str(request)

    # Execute the method handle

# Generated at 2022-06-23 14:16:17.330184
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():

    # Using the default __init__ method is fine, as it is tested in test_JsonRpc.py
    j = JsonRpcServer()

    setattr(j, '_identifier', 1)

    err = j.internal_error("This is a test error message")
    assert err == {
        'id': 1,
        'jsonrpc': '2.0',
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': 'This is a test error message'
        }
    }

# Generated at 2022-06-23 14:16:21.980526
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    response = JsonRpcServer().parse_error()
    expected = {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": None}
    assert response == expected


# Generated at 2022-06-23 14:16:23.740357
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')

    assert server.header() == { 'jsonrpc': '2.0', 'id': '1234'}


# Generated at 2022-06-23 14:16:28.886948
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    t = JsonRpcServer()
    # test handle_request method with params of string type
    # check if handle_request returns error for invalid params
    assert "error" in t.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": "Invalid number of inputs for echo", "id": 1}')
    # check if handle_request returns echo back of msg with params of string type
    assert "result" in t.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["ansible"], "id": 1}')
    # test handle_request method with params of integer type
    # check if handle_request returns error for invalid params

# Generated at 2022-06-23 14:16:36.562733
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    request = json.loads("""
        {
            "jsonrpc": "2.0",
            "method": "echo",
            "params": ["hello world"],
            "id": "1"
        }
        """)
    expected = json.loads("""
        {
            "jsonrpc": "2.0",
            "result": "hello world",
            "id": "1"
        }
        """)
    response = JsonRpcServer().handle_request(json.dumps(request))
    assert json.loads(response) == expected

if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-23 14:16:43.488116
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    err = server.parse_error()
    assert err['error']['code'] == -32700
    assert err['error']['message'] == 'Parse error'
    err = server.parse_error('error message')
    assert err['error']['code'] == -32700
    assert err['error']['message'] == 'Parse error'
    assert err['error']['data'] == 'error message'


# Generated at 2022-06-23 14:16:44.922915
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    """ test_JsonRpcServer_method_not_found """
    server = JsonRpcServer()
    ret = server.method_not_found()
    return ret


# Generated at 2022-06-23 14:16:47.382009
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer().parse_error()['id'] == -32700


# Generated at 2022-06-23 14:16:50.642427
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsr = JsonRpcServer()
    jsr._identifier = 1
    assert jsr.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:16:57.114781
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class test:
        def method1(self):
            return 'Success'
        def method2(self):
            return True
        def method3(self):
            return False
        def method4(self):
            return 43
        def method5(self):
            return
    obj = test()
    server.register(obj)
    # Check that the object was registered
    assert obj in server._objects


# Generated at 2022-06-23 14:17:01.998417
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    def test():
        server = JsonRpcServer()
        class TestModule:
            def test_method(self):
                return "test"
        test_module = TestModule()
        server.register(test_module)
        assert server._objects == set([test_module])
    test()



# Generated at 2022-06-23 14:17:06.029142
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    _obj = JsonRpcServer()
    _obj1 = JsonRpcServer()
    _obj2 = JsonRpcServer()
    _obj._objects = set([_obj1, _obj2])
    assert not _obj._objects