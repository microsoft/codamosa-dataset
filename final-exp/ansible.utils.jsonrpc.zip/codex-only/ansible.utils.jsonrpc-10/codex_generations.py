

# Generated at 2022-06-23 14:07:09.695524
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrs = JsonRpcServer()
    jrs._identifier = "test"
    result = dict(key1 = "value1", key2 = "value2", key3 = "value3")
    res = jrs.response(result)
    assert res == {'jsonrpc': '2.0', 'id': 'test', 'result_type': 'pickle', 'result': "c__builtin__\n"
                   "dict\np0\n(dp1\nS'key1'\np2\nS'value1'\np3\nsS'key3'\np4\nS'value3'\np5\nsS'key2'\np6\nS'value2'\np7\ns."}


# Generated at 2022-06-23 14:07:12.281560
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server.register(None)
    assert len(server._objects) == 1


# Generated at 2022-06-23 14:07:21.237010
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    # mock objects
    import json

    class MockJsonRpcServer(object):
        def __init__(self, extobj):
            self._objects = set()
            self._objects.add(extobj)

    # module to test
    from ansible.module_utils import basic
    import copy

    # test case: normal passes
    extobj = copy.copy(basic)
    obj = MockJsonRpcServer(extobj)
    obj.register(extobj)
    assert isinstance(obj._objects, set)
    assert extobj in obj._objects

    # test case: obj not in _objects
    extobj = copy.copy(basic)
    obj = MockJsonRpcServer(extobj)
    obj.register(extobj)
    assert isinstance(obj._objects, set)

# Generated at 2022-06-23 14:07:33.438346
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Module(object):
        def rpc_method(self, a, b, c):
            return json.dumps({'jsonrpc': '2.0', 'result': a + b + c})

    server = JsonRpcServer()
    server.register(Module())

    # test method not found
    request = {
        'jsonrpc': '2.0',
        'method': 'notexisting',
        'params': [[1, 2, 3]],
        'id': '1'
    }
    response = json.loads(server.handle_request(json.dumps(request)))
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'

    # test server error

# Generated at 2022-06-23 14:07:40.686658
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    assert type(obj.internal_error()) == dict
    assert obj.internal_error()['jsonrpc'] == '2.0'
    assert obj.internal_error()['error']['code'] == -32603
    assert obj.internal_error()['error']['message'] == 'Internal error'
    assert obj.internal_error()['error']['data'] == ''
    assert obj.internal_error('Message')['error']['data'] == 'Message'


# Generated at 2022-06-23 14:07:48.609841
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    display.display('Unit test for method parse_error of class JsonRpcServer')
    instance = JsonRpcServer()

    error = instance.parse_error()
    assert error == {'jsonrpc': '2.0', 'id': instance._identifier, 'error': {'code': -32700, 'message': 'Parse error'}}

    error = instance.parse_error('data')
    assert error == {'jsonrpc': '2.0', 'id': instance._identifier, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'data'}}


# Generated at 2022-06-23 14:07:52.210160
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(-32600, "Invalid request", "data")
    expected = {
        "error": {"code": -32600, "message": "Invalid request", "data": "data"},
        "jsonrpc": "2.0",
        "id": None
    }
    assert json.dumps(expected) == json.dumps(result)

# Generated at 2022-06-23 14:07:53.375056
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    #rpcserver = JsonRpcServer()
    #rpcserver.invalid_request()
    assert True

# Generated at 2022-06-23 14:08:00.050434
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()

    class Foo(object):

        def bar(self):
            return True

    server.register(Foo())

    assert len(server._objects) == 1

    class Baz(object):

        def bing(self):
            return False

    server.register(Baz())

    assert len(server._objects) == 2


# Generated at 2022-06-23 14:08:02.202905
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpctest = JsonRpcServer()
    jrpctest._identifier = 1
    testresult = jrpctest.response()
    result = {'jsonrpc': '2.0', 'id': 1, 'result': None}
    assert testresult == result


# Generated at 2022-06-23 14:08:06.391961
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    msg = 'Parse error'
    test_response = {'jsonrpc': '2.0', 'id': '', 'error': {'code': -32700, 'message': msg, 'data': None}}
    assert server.parse_error() == test_response


# Generated at 2022-06-23 14:08:07.750158
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
     server = JsonRpcServer()
     assert server


# Generated at 2022-06-23 14:08:14.797893
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = server.error(1, "hello error")
    assert result == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": 1,
            "message": "hello error",
        },
    }


# Generated at 2022-06-23 14:08:19.027335
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.json_rpc import JsonRpcServer
    rpc_server = JsonRpcServer()
    rpc_server._identifier = 1
    result = rpc_server.header()
    assert result == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-23 14:08:27.281947
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.response({"jsonrpc": "2.0", "result": {"code": 3, "message": "test"}, "id": 12})
    error = json_rpc_server.error(code=1, message="test")
    error = json_rpc_server.internal_error(data="test")
    error = json_rpc_server.method_not_found(data="test")
    error = json_rpc_server.invalid_params(data="test")

# Generated at 2022-06-23 14:08:29.638056
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {u'params': [[], {}], u'method': u'random', u'jsonrpc': u'2.0', u'id': 1}
    server.handle_request(cPickle.dumps(request))

# Generated at 2022-06-23 14:08:30.600760
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None, 'Failed to create JsonRpcServer object'


# Generated at 2022-06-23 14:08:39.794906
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    j = JsonRpcServer()
    # method
    result = 'unit test ok'
    expect = {u'jsonrpc': u'2.0', u'id': 1, u'result': 'unit test ok'}
    assert(j.response(result) == expect)
    # method
    result = b'unit test ok'
    expect = {u'jsonrpc': u'2.0', u'id': 1, u'result': 'unit test ok'}
    assert(j.response(result) == expect)
    # method
    result = [1, 2, 3]

# Generated at 2022-06-23 14:08:46.615105
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(1000, 'Invalid params')
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': 1000, 'message': 'Invalid params'}}

    result = server.error(1000, 'Invalid params', data='Test')
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': 1000, 'message': 'Invalid params', 'data': 'Test'}}

# Generated at 2022-06-23 14:08:51.761346
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    _JsonRpcServer_instance = JsonRpcServer()
    _JsonRpcServer_instance.identifier = 1
    _output = {'error': {'code': -32600, 'message': 'Invalid request'},
               'id': 1, 'jsonrpc': '2.0'}
    assert _JsonRpcServer_instance.invalid_request() == _output


# Generated at 2022-06-23 14:08:57.648639
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    args, kwargs = '', {}
    setattr(JsonRpcServer, '_identifier', '0')
    rpc_response = JsonRpcServer().error(14, 'Some error')
    rpc_response = json.dumps(rpc_response)
    assert rpc_response == '{"jsonrpc": "2.0", "id": "0", "error": {"code": 14, "message": "Some error"}}'


# Generated at 2022-06-23 14:09:01.768552
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print("test_JsonRpcServer_handle_request")
    server = JsonRpcServer()
    response = server.handle_request("""{"jsonrpc": "2.0", "method": "test.method", "id": 1408}""")
    assert response == """{"id": 1408, "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}"""



# Generated at 2022-06-23 14:09:07.153616
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    response = server.error(code=-32700, message='Parse error', data=None)
    assert response['id'] == None
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'

# Generated at 2022-06-23 14:09:11.571057
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    args = ['bogus message']
    jr = JsonRpcServer()
    assert jr.internal_error(*args) == {
        'jsonrpc': '2.0', 'id': None, 'error': {
            'code': -32603, 'message': 'Internal error', 'data': 'bogus message'
        }
    }

# Generated at 2022-06-23 14:09:16.963269
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    testData = {
        'result': 'test',
        'jsonrpc': '2.0',
        'id': 'test'
    }
    test_server = JsonRpcServer()
    setattr(test_server, '_identifier', 'test')
    testResult = test_server.response('test')
    assert testResult == testData

# Generated at 2022-06-23 14:09:19.698038
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    ins = JsonRpcServer()
    result = ins.invalid_params()
    print(result)
    #return result


# Generated at 2022-06-23 14:09:25.969838
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    response = server.parse_error()
    assert response.get('error', None) != None
    error = response.get('error')
    assert error.get('code') == -32700
    assert error.get('message') == 'Parse error'
    response = server.parse_error('data')
    assert response.get('error', None) != None
    error = response.get('error')
    assert error.get('data') == 'data'


# Generated at 2022-06-23 14:09:33.640748
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    print('\nTest method invalid_request of class JsonRpcServer...', end='')
    data = {'method': 'rpc.invalid_request'}
    server = JsonRpcServer()
    request = json.dumps(data)
    response = server.handle_request(request)
    response = json.loads(response)
    print('Ok') if response['error']['code'] == -32600 else print('Fail')
    print('Test method invalid_request of class JsonRpcServer completed\n')


# Generated at 2022-06-23 14:09:37.273198
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc_server_class = JsonRpcServer()
    setattr(jsonrpc_server_class, '_identifier', "id_123")
    result = jsonrpc_server_class.header()
    assert result == {'jsonrpc': '2.0', 'id': "id_123"}


# Generated at 2022-06-23 14:09:42.844323
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    assert JsonRpcServer()
    rpc_server = JsonRpcServer()
    assert rpc_server.invalid_request()
    assert rpc_server.invalid_request('test')
    assert rpc_server.invalid_request() == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None}
    assert rpc_server.invalid_request('test') == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request', 'data': 'test'}, 'id': None}

# Generated at 2022-06-23 14:09:51.374875
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test = JsonRpcServer()
    test._identifier = "test_parser"
    expected_result = {
        "jsonrpc": "2.0",
        "id": "test_parser",
        "error": {
            "code": -32768,
            "message": "Parse error",
            "data": "test_data"
        }
    }
    assert expected_result == test.error(-32768, "Parse error", "test_data")


# Generated at 2022-06-23 14:09:52.701396
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    js_object = JsonRpcServer()
    js_object.header()

# Generated at 2022-06-23 14:09:56.761170
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jr = JsonRpcServer()
    jr._identifier = '87'
    error = jr.error(-32602, 'Invalid params')
    output = json.dumps({'error': {'code': -32602, 'message': 'Invalid params'}, 'id': '87', 'jsonrpc': '2.0'})
    assert error == output


# Generated at 2022-06-23 14:09:58.954575
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrpc = JsonRpcServer()
    assert jrpc.error(code=-32601, message='Method not found', data='test_data') == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found', 'data': 'test_data'}, 'id': None}

# Generated at 2022-06-23 14:10:03.846420
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider

    server = JsonRpcServer()

    obj = load_provider(AnsibleModule({}, {}))
    server.register(obj)

    expected = {}
    expected['jsonrpc'] = '2.0'
    expected['id'] = '123'
    expected['result_type'] = 'pickle'
    expected['result'] = u'\x80\x02}q\x01.'

    actual = server.handle_request(b'{"jsonrpc": "2.0", "method":"get_capabilities", "params": [], "id": "123"}')

    assert expected==json.loads(actual)

# Generated at 2022-06-23 14:10:06.618887
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', '12345')
    # no exception is raised
    server.header()



# Generated at 2022-06-23 14:10:08.997325
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
   s = JsonRpcServer()

   print(s.error(1, 'error'))

# Generated at 2022-06-23 14:10:13.867559
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Foo(object):
        pass
    foo1 = Foo()
    foo2 = Foo()
    server.register(foo1)
    server.register(foo2)

    assert foo1 in server._objects
    assert foo2 in server._objects


# Generated at 2022-06-23 14:10:17.703022
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    expected = {'jsonrpc': '2.0', 'id': 5}
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', '5')
    result = rpc_server.header()
    assert isinstance(result, dict)
    assert result == expected


# Generated at 2022-06-23 14:10:21.339118
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
	request = "invalid_request"
	error = JsonRpcServer().invalid_request()
	return json.dumps(error)


# Generated at 2022-06-23 14:10:31.433569
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    payload = {
        "params": ([], {}),
        "jsonrpc": "2.0",
        "id": 0,
        "method": "get_config"
    }

    def _json_hook(json_dict):
        return json_dict

    server = JsonRpcServer()
    result = server.handle_request(json.dumps(payload, default=_json_hook))

    assert result['id'] == 0
    assert result['jsonrpc'] == "2.0"
    assert result['result'] == "{\n  \"ansible_facts\": {\n    \"discovered_interpreter_python\": \"/usr/bin/python\"\n  }, \n  \"changed\": false, \n  \"failed\": false\n}"

# Generated at 2022-06-23 14:10:37.207797
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.connection import Connection
    t_jsonRpcServer = JsonRpcServer()
    conn = Connection()
    t_jsonRpcServer.register(conn)
    t_jsonRpcServer.handle_request('{"method": "_connect", "params": [], "id": 0}')
    assert t_jsonRpcServer.header() == {'jsonrpc': '2.0', 'id': 0}


# Generated at 2022-06-23 14:10:43.095417
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    from ansible.module_utils.six import StringIO

    jrs = JsonRpcServer()
    req = {"jsonrpc": "2.0", "method": "invalid_params", "params": ["user"], "id": 1}
    req = json.dumps(req)

    response = jrs.handle_request(req)
    response = json.loads(response)

    cmp_response = {"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params", "data": "user"}, "id": 1}

    assert response == cmp_response

# Generated at 2022-06-23 14:10:48.045869
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc = JsonRpcServer()
    result = jsonrpc.response()
    expected = {'jsonrpc': '2.0', 'id': None, 'result_type': 'text', 'result': None}
    assert result == expected


# Generated at 2022-06-23 14:10:51.608138
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request = '{"method":"not_found","params":[],"id":"100"}'
    response = server.handle_request(request)
    assert json.loads(response) == server.method_not_found(), \
        'method_not_found is not handled correctly'

# Generated at 2022-06-23 14:10:57.774510
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server._identifier = "test function"
    assert server.parse_error("test data") == \
        {'jsonrpc': '2.0', 'id': 'test function',
        'error': {'code': -32700, 'message': 'Parse error', 'data': 'test data'}
        }


# Generated at 2022-06-23 14:11:01.369015
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    result = JsonRpcServer().error(-32600, 'Invalid request', "data")
    assert result == {
        'id': -1,
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': 'data'
        },
        'jsonrpc': '2.0'
    }


# Generated at 2022-06-23 14:11:06.877730
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # create instance of class JsonRpcServer
    rpcserver = JsonRpcServer()
    # create instance of class JsonRpcServer
    jsonrpcserver = JsonRpcServer()
    # register instance of class JsonRpcServer
    rpcserver.register(jsonrpcserver)
    # execute method parse_error of class JsonRpcServer
    result = jsonrpcserver.parse_error()
    # check result of method parse_error of class JsonRpcServer
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}

# Generated at 2022-06-23 14:11:09.131309
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-23 14:11:12.500662
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server._objects = set()
    obj = {'test' : 'test_value'}
    server.register(obj)
    assert obj in server._objects
    assert not server._objects == set()

# Generated at 2022-06-23 14:11:16.751079
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import json
    expected = {'id': 1234, 'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}}
    result = JsonRpcServer().error(code=-32603, message='Internal error', data='test')
    assert expected == result


# Generated at 2022-06-23 14:11:21.332191
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    j = JsonRpcServer()
    result = j.internal_error("test cat")
    assert isinstance(result, dict)
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test cat'}, 'id': None}



# Generated at 2022-06-23 14:11:29.879219
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.basic import AnsibleModule
    class Foo(object):
        def _foo(self, *args, **kwargs):
            return "foo"

        def bar(self, *args, **kwargs):
            return "bar"

        def is_registered(self, *args, **kwargs):
            return self._identifier == ansible_module.params["identifier"]

        def reverse_args(self, *args, **kwargs):
            args = list(args)
            args.reverse()
            return args

        def reverse_kwargs(self, *args, **kwargs):
            kwargs = kwargs.copy()
            kwargs.update(args)
            keys = list(kwargs.keys())
            keys.reverse()
            return keys


# Generated at 2022-06-23 14:11:39.593717
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc = JsonRpcServer()
    setattr(jsonrpc, '_identifier', 1234567890)

    result = jsonrpc.response(result="Hello World")
    assert "jsonrpc" in result and "2.0" == result.get("jsonrpc")
    assert "1234567890" == result.get("id")
    assert "Hello World" == result.get("result")
    assert not result.get("error")

    result = jsonrpc.response(result=b"bHello World")
    assert "jsonrpc" in result and "2.0" == result.get("jsonrpc")
    assert "1234567890" == result.get("id")
    assert "bHello World" == result.get("result")
    assert not result.get("error")

    result = json

# Generated at 2022-06-23 14:11:45.237882
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    o = JsonRpcServer()
    o._identifier = "a"
    assert o.response("{'a': 'good'}" == "{'jsonrpc': '2.0', 'id': 'a', 'result': \"{'a': 'good'}\"}")


# Generated at 2022-06-23 14:11:49.458073
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    param = {"result" : "hello"}
    server = JsonRpcServer()
    server.register(server)
    server._identifier = 1
    assert server.response(param) == {"jsonrpc": "2.0", "id": 1, "result": "hello"}



# Generated at 2022-06-23 14:11:58.383104
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Case 1: normal case, check data type error
    #assert JsonRpcServer().error(1, '1', [1, 2, 3])
    #assert JsonRpcServer().error(1, 1, [1, 2, 3])

    # Case 2: checking the data type of the return value
    #assert JsonRpcServer().error(1, '1', [1, 2, 3])
    assert isinstance(JsonRpcServer().error(1, '1', [1, 2, 3]), dict)


# Generated at 2022-06-23 14:12:03.496807
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    obj.register(JsonRpcServer())
    result = json.loads(obj.handle_request(json.dumps({
        'jsonrpc': '2.0',
        'method': 'internal_error',
        'params': [[]],
        'id': 1
    })))

    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'


# Generated at 2022-06-23 14:12:06.312723
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': server._identifier}


# Generated at 2022-06-23 14:12:09.616019
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    e = JsonRpcServer().invalid_request()
    assert e["jsonrpc"] == "2.0"
    assert e["id"] == None
    assert e["error"]["code"] == -32600
    assert e["error"]["message"] == "Invalid request"

# Generated at 2022-06-23 14:12:11.901013
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert isinstance(JsonRpcServer(), JsonRpcServer)

# Generated at 2022-06-23 14:12:13.178521
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpcserver = JsonRpcServer()
    rpcserver.register({"test" : 1})
    assert rpcserver._objects == set([{"test" : 1}])


# Generated at 2022-06-23 14:12:14.084283
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
	pass


# Generated at 2022-06-23 14:12:16.257634
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc = JsonRpcServer()
    assert jsonrpc.invalid_params()["error"]["code"] == -32602


# Generated at 2022-06-23 14:12:17.630776
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert True is True

# Generated at 2022-06-23 14:12:22.838199
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    srv = JsonRpcServer()
    assert srv.method_not_found() == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32601,
            'message': 'Method not found'
        }
    }

# Generated at 2022-06-23 14:12:28.120208
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    message = {
        'jsonrpc': '2.0',
        'method': 'rpc.run',
        'params': ('', '')
    }
    res = server.handle_request(json.dumps(message))
    assert res == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32600, "message": "Invalid request", "data": null}}'

# Generated at 2022-06-23 14:12:31.092616
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    error = json_rpc_server.invalid_params()
    assert error.get('error').get('code') == -32602


# Generated at 2022-06-23 14:12:32.975235
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server.register(server)
    assert (len(server._objects) == 1)


# Generated at 2022-06-23 14:12:42.333456
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    server = JsonRpcServer()

    class Module(object):
        def rpc_test(self):
            pass

    server.register(Module())

    result = json.loads(server.handle_request(json.dumps({'jsonrpc': '2.0', 'id': 'foo', 'method': 'rpc.test', 'params': [[], {}]})))

    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'foo'
    assert result['error'] == {'code': -32600, 'message': 'Invalid request'}


# Generated at 2022-06-23 14:12:50.039483
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    class Test:
        def echo(self, msg):
            return msg

    server = JsonRpcServer()
    server.register(Test())

    request = {
        'method': 'echo',
        'params': [['hello']],
        'id': 1
    }

    result = server.handle_request(json.dumps(request))
    result = json.loads(result)

    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 1
    assert result['result'] == 'hello'


# Generated at 2022-06-23 14:12:52.421681
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-23 14:13:00.906770
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    # Create a JsonRpcServer instance
    server = JsonRpcServer()

    # Set the _identifier attribute of server to "foo"
    setattr(server, '_identifier', "foo")

    # Call method error of server using code, message and data
    # because of traceback.excepthook's print_exception, I added the
    # to_text function to message and data.
    result = server.error(code = -32603, message = to_text("Internal error"), data = to_text("Foo"))

    # assert error method of server returns -32603 as code and
    # "Internal error" as message and "Foo" as data
    assert result.get("error").get("code") == -32603
    assert result.get("error").get("message") == "Internal error"

# Generated at 2022-06-23 14:13:04.948663
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    error = json.dumps(error)

    assert(error == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32600, "message": "Invalid request"}}')

# Generated at 2022-06-23 14:13:10.619276
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    assert jrs.internal_error({'data': 'test1', 'code': 100}) == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32603,
            'message': 'Internal error',
            'data': {'data': 'test1', 'code': 100}
        }
    }

# Generated at 2022-06-23 14:13:11.900586
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert jsonrpc_server

# Generated at 2022-06-23 14:13:14.656261
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    JsonRpcServer = JsonRpcServer()
    JsonRpcServer._identifier = "id"
    res = JsonRpcServer.invalid_params()
    assert res['error']['code'] == -32602

# Generated at 2022-06-23 14:13:18.269648
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_server = JsonRpcServer()
    assert json_server.parse_error()['error'] == {'code': -32700, 'message': 'Parse error'}


# Generated at 2022-06-23 14:13:29.160979
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Small hack to dynamically create classes based on different params in test_data
    class DummyNetworkModule:
        def get_config(self):
            return "hostname dummyHostname"
        def load_config(self, **kwargs):
            return True
        def run_commands(self, **kwargs):
            return True

    class DummyNetworkModuleConnectionFailure(DummyNetworkModule):
        def load_config(self, **kwargs):
            raise ConnectionError("Connection error")
        def run_commands(self, **kwargs):
            raise ConnectionError("Connection error")

    class DummyNetworkModuleException(DummyNetworkModule):
        def load_config(self, **kwargs):
            raise Exception("Exception")
        def run_commands(self, **kwargs):
            raise Exception("Exception")


# Generated at 2022-06-23 14:13:33.921055
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()

    expected = {"id": None, "jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params", "data": None}}
    error = server.invalid_params()
    success = (error == expected)
    message = "JsonRpcServer.invalid_params() failed"
    assert success, message


# Generated at 2022-06-23 14:13:35.625761
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert "-32601" in JsonRpcServer.method_not_found()

# Generated at 2022-06-23 14:13:37.249598
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc_server = JsonRpcServer()
    rpc_server.register(rpc_server)

# Generated at 2022-06-23 14:13:41.006870
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    assert JsonRpcServer().error(1, 2, 3) == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': 1,
            'message': 2,
            'data': 3
        }
    }

test_JsonRpcServer_error()

# Generated at 2022-06-23 14:13:50.112998
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    from ansible.module_utils.json_utils import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    m = JsonRpcServer()
    body = {'method': 'rpc.invalid_request', 'params': [], 'id': 1}
    request = json.dumps(body)
    response = m.handle_request(request)
    response = json.loads(response)
    assert 'error' in response
    assert response['error']['code'] == -32600
    assert response['error']['message'] == 'Invalid request'


# Generated at 2022-06-23 14:13:54.713170
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    data = 'test'
    ret_val = server.internal_error(data=data)
    assert ret_val.get("error", {}).get("message") == 'Internal error'
    assert ret_val.get("error", {}).get("data") == data



# Generated at 2022-06-23 14:13:59.225196
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '100')
    result = 'hello world'
    response = server.response(result)
    assert response == {'id': '100', 'jsonrpc': '2.0', 'result': 'hello world'}


# Generated at 2022-06-23 14:14:07.726380
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    test_method_result = True
    def method():
        return test_method_result
    server.register(method)
    # Valid request to method that return response
    request_id = '1'
    request = json.dumps(dict(jsonrpc='2.0', id=request_id, method='method'))
    response = json.loads(server.handle_request(request))
    result = json.loads(response['result'])
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == request_id
    assert result == test_method_result
    # Request to unknown method
    request_id = '2'

# Generated at 2022-06-23 14:14:09.515104
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    test = JsonRpcServer()
    assert getattr(test, "_objects") == set()


# Generated at 2022-06-23 14:14:13.175749
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc = JsonRpcServer()
    try:
        setattr(rpc, '_identifier', 10)
        rpc.invalid_params()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 14:14:16.828395
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    resp = server.invalid_params('data')
    assert resp['error']['code'] == -32602
    assert resp['error']['message'] == 'Invalid params'
    assert resp['error']['data'] == 'data'

# Generated at 2022-06-23 14:14:28.111337
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    header = {'jsonrpc': '2.0', 'id': 100}
    # fail with method not found
    data = json.dumps(({'jsonrpc': '2.0', 'id': 100, 'method': 'no_such_method', 'params': ([], {})}))
    response = json.loads(server.handle_request(data))
    assert response=={'jsonrpc': '2.0', 'id': 100, 'error': {'code': -32601, 'message': 'Method not found'}}
    # pass with method found
    class ExistingObject:
        @staticmethod
        def existing_method():
            return {"existing": "string"}
    server.register(ExistingObject)

# Generated at 2022-06-23 14:14:38.356734
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    JsonServer = JsonRpcServer()
    header = JsonServer.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == JsonServer._identifier
    test_1 = JsonServer.response(None)
    assert test_1['result'] is None
    test_2 = JsonServer.response(u"test")
    assert isinstance(test_2['result'], text_type)
    assert test_2['result'] == u"test"
    test_3 = JsonServer.response(b"test")
    assert isinstance(test_3['result'], text_type)
    assert test_3['result'] == u"test"
    test_4 = JsonServer.response({"test"})

# Generated at 2022-06-23 14:14:49.484946
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    """Create a new instance of JsonRpcServer class, set the identifier,
    and create a result, then call response. [[[TODO: Explain more]]]
    """

    # Create a new instance of JsonRpcServer class
    myJsonRpcServer = JsonRpcServer()

    # Set the _identifier to "FakeID" for testing purposes
    setattr(myJsonRpcServer, '_identifier', "FakeID")

    # Actual Result
    result = "This is my test result"

    # Call the method JsonRpcServer.response()
    response = myJsonRpcServer.response(result=result)

    # Expected Output:

# Generated at 2022-06-23 14:14:52.283808
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 123)
    assert server.header() == {'jsonrpc': '2.0', 'id': 123}



# Generated at 2022-06-23 14:14:53.723214
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    method = 'method_not_found'
    data = {'key': 'value'}
    response = obj.error(-32601, 'Method not found', data)
    assert obj.method_not_found(data) == response

# Generated at 2022-06-23 14:14:55.483786
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    try:
        inst_JsonRpcServer = JsonRpcServer()
        inst_JsonRpcServer.invalid_request()
    except Exception as e:
        print ("Error: " + str(e))


# Generated at 2022-06-23 14:14:57.498905
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    rpc_server.handle_request('{"method":"unknown","id":1}')

# Generated at 2022-06-23 14:15:02.602738
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    server._identifier = 1
    assert server.invalid_params() == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}}


# Generated at 2022-06-23 14:15:05.989621
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Foo:
        def bar(self):
            return "bar"
    class Bar:
        def baz(self):
            return "baz"
    server = JsonRpcServer()
    server.register(Foo())
    server.register(Bar())
    assert isinstance(server._objects, set)
    assert server._objects == set([Foo(), Bar()])


# Generated at 2022-06-23 14:15:08.173940
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    r = JsonRpcServer()
    assert not r._objects
    r.register(r)
    assert r._objects
    assert r in r._objects

# Generated at 2022-06-23 14:15:19.492247
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.json_rpc import JsonRpcServer
    server = JsonRpcServer()
    result = server.response()
    assert result['id'] is None
    assert result['jsonrpc'] is '2.0'
    assert result['result'] == ''

    result = server.response('Test')
    assert result['result'] == 'Test'

    result = server.response({'a': 1})
    assert result['result'] == '{' + '\'a\': 1' + '}'
    assert result['result_type'] == 'pickle'

    result = server.response(text_type('Test'))
    assert result['result_type'] is None
    assert result['result'] == 'Test'


# Generated at 2022-06-23 14:15:24.027892
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonrpcserver = JsonRpcServer()
    result = jsonrpcserver.parse_error()
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == None


# Generated at 2022-06-23 14:15:33.790943
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    print ("\n\ntesting JsonRpcServer_parse_error ... ")
    request = '{"jsonrpc": "2.0", "method": "foobar, "params": "bar", "baz]'
    req2 = '{"jsonrpc": "2.0", "method": "foobar, "params": "bar", "baz]'
    request = json.loads(to_text(request, errors='surrogate_then_replace'))

    method = request.get('method')

    if method.startswith('rpc.') or method.startswith('_'):
        error = JsonRpcServer().invalid_request()
        return json.dumps(error)

    args, kwargs = request.get('params')

# Generated at 2022-06-23 14:15:37.267745
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    jrs.register(jrs)
    id = '1234'
    jrs._identifier = id
    json_response = jrs.handle_request('{"jsonrpc": "2.0", "method": "internal_error", "params": [], "id": "' + str(id) + '"}')
    assert '"id": 1234' in json_response

# Generated at 2022-06-23 14:15:46.119321
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    test = JsonRpcServer()
    test._identifier = 1
    assert test.invalid_params() == {'id': 1, 'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params'}}
    assert test.invalid_params("data") == {'id': 1, 'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'data'}}


# Generated at 2022-06-23 14:15:49.133378
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonrpc_server = JsonRpcServer()
    msg = jsonrpc_server.method_not_found("test")
    assert msg == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found', 'data': 'test'}, 'id': None}


# Generated at 2022-06-23 14:15:54.071734
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    result = JsonRpcServer().method_not_found()
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:15:59.193827
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'id': 7, 'method': 'get_device_info', 'params': [[], {}]}
    json_string = json.dumps(request)
    json_rpc_server.handle_request(json_string)

# Generated at 2022-06-23 14:16:02.258564
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Test:
        def test(self):
            pass
    t = Test()
    server.register(t)
    assert(t in server._objects)

# Generated at 2022-06-23 14:16:11.880084
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.network.common.utils import to_list
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    class TestConnection:
        def __init__(self, module):
            self._socket_path = 'test_socket_path'
            self._connection = None
            self._connected = False
            self._connected_params = dict()
            self._socket = None
            self._socket_isopen = False
            self._last_recv_timeout = 0
        def connect(self, params, **kwargs):
            self._connected = True
            self

# Generated at 2022-06-23 14:16:15.140341
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    expected_error = '''{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error", "data": "test"}, "id": "test"}'''
    checked_error = JsonRpcServer().internal_error('test')
    assert checked_error == expected_error

# Generated at 2022-06-23 14:16:16.200183
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    assert False, "Test not implemented"

# Generated at 2022-06-23 14:16:22.597462
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import pytest
    from ansible.module_utils.connection import Connection
    rpc_server = JsonRpcServer()
    connection = Connection()
    connection.register_jsonrpc_backend('test', rpc_server)
    result = connection._exec_jsonrpc_request('test', method='internal_error')
    assert result == json.dumps(rpc_server.internal_error())

# Generated at 2022-06-23 14:16:27.762976
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    response = json.loads(server.handle_request(request=json.dumps({
        "id": 1,
        "method": "nonexistant",
        "params": [],
    })))

    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'

# Generated at 2022-06-23 14:16:32.465498
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    """ Method: method_not_found|Args: none"""
    jrs=JsonRpcServer()
    assert jrs.method_not_found() == {'id': None, 'error': {'message': 'Method not found', 'code': -32601}, 'jsonrpc': '2.0'}


# Generated at 2022-06-23 14:16:36.332104
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    x = JsonRpcServer()
    r1 = x.handle_request('{"jsonrpc": "2.0", "method": "method_not_found", "params": ["m1"], "id": 1}')
    r2 = x.method_not_found()
    assert(r1 == json.dumps(r2))


# Generated at 2022-06-23 14:16:37.143518
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    pass

# Generated at 2022-06-23 14:16:44.014152
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')

    response = server.error(-32003, 'method error', 'test data')
    assert json.loads(json.dumps(response)) == {
        'jsonrpc': '2.0',
        'id': '123',
        'error': {
            'code': -32003,
            'message': 'method error',
            'data': 'test data'
        }
    }

# Generated at 2022-06-23 14:16:48.680703
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Test:
        def test(self):
            return 'bar'
    obj = Test()
    assert not server._objects
    server.register(obj)
    assert server._objects
    assert obj in server._objects


# Generated at 2022-06-23 14:16:56.130855
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    srv = JsonRpcServer()
    b = srv.internal_error()
    assert b == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error'}, 'id': None}
    b = srv.internal_error(data='test')
    assert b == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'}, 'id': None}


# Generated at 2022-06-23 14:17:02.814418
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    expected = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}
    result = obj.method_not_found()
    assert (expected['error']['code'] == result['error']['code'])
    assert (expected['error']['message'] == result['error']['message'])
