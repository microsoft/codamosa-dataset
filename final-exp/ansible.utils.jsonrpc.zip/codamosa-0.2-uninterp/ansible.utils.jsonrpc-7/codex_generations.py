

# Generated at 2022-06-17 15:14:31.666609
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': 1
    })
    response = server.handle_request(request)
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }


# Generated at 2022-06-17 15:14:37.068769
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:14:44.463904
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import pickle
    import traceback
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

        def test_exception(self):
            raise Exception('test exception')

        def test_connection_error(self):
            raise ConnectionError('test connection error')

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = Json

# Generated at 2022-06-17 15:14:49.437471
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'a': 1, 'b': 2}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': result}


# Generated at 2022-06-17 15:14:51.785846
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = server.error(code=1, message='test_message', data='test_data')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'error': {'code': 1, 'message': 'test_message', 'data': 'test_data'}}


# Generated at 2022-06-17 15:14:56.040471
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test'
    error = server.error(code=1, message='test')
    assert error == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:06.567360
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:15:12.023876
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_JsonRpcServer_error')
    result = server.error(code=1, message='test_JsonRpcServer_error')
    assert result == {'jsonrpc': '2.0', 'id': 'test_JsonRpcServer_error', 'error': {'code': 1, 'message': 'test_JsonRpcServer_error'}}


# Generated at 2022-06-17 15:15:17.489162
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, World!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, World!", "id": 1}'


# Generated at 2022-06-17 15:15:21.748003
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:15:27.593636
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:36.512216
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a class to register with the JsonRpcServer
    class TestClass(object):
        def __init__(self):
            pass

        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Create an instance of the class
    test_obj = TestClass()

    # Register the class with the JsonRpcServer
    server.register(test_obj)

    # Create a request
    request = {
        'jsonrpc': '2.0',
        'id': '1',
        'method': 'test_method',
        'params': [1, 2]
    }

    # Convert the request to a string
    request = json.dumps(request)

    # Call the method

# Generated at 2022-06-17 15:15:45.709499
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": "1"
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:15:52.937778
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()
    # Create a request
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": 1
    }
    # Create a class that contains the method echo
    class Echo:
        def echo(self, message):
            return message
    # Register the class with the server
    server.register(Echo())
    # Call the method handle_request of the server
    response = server.handle_request(json.dumps(request))
    # Check if the response is correct
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'


# Generated at 2022-06-17 15:15:56.090229
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:16:00.253077
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '123'
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': result}


# Generated at 2022-06-17 15:16:09.774725
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer
    from ansible.module_utils.network.common.json_rpc import JsonRpcClient
    from ansible.module_utils.network.common.json_rpc import JsonRpcError
    from ansible.module_utils.network.common.json_rpc import JsonRpcProtocolError
    from ansible.module_utils.network.common.json_rpc import JsonRpcMethodNotFoundError
    from ansible.module_utils.network.common.json_rpc import JsonRpcInvalidRequestError
    from ansible.module_utils.network.common.json_rpc import JsonRpcInvalidParamsError

# Generated at 2022-06-17 15:16:17.108120
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:16:21.888446
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:16:33.617376
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": [1, 2, 3], "id": 2}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "1 2 3", "id": 2}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": [], "id": 3}'
   

# Generated at 2022-06-17 15:16:44.471216
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:16:48.672565
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:16:53.579022
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = {'test': 'test_result'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': result}


# Generated at 2022-06-17 15:16:58.360490
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:17:02.818824
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': result}

# Generated at 2022-06-17 15:17:13.558503
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    import json
    import sys
    import os

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'not_found', 'id': 1})
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}')


# Generated at 2022-06-17 15:17:21.498762
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'


# Generated at 2022-06-17 15:17:24.719195
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:17:31.900652
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:17:42.553813
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()
    # Create an instance of JsonRpcTest
    test = JsonRpcTest()
    # Register the instance of JsonRpcTest with JsonRpcServer
    server.register(test)
    # Create a request to test the method handle_request
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    # Call the method handle_request
    response = server.handle_request(request)
    # Check if the response is correct
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:17:56.374563
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'not_found',
                'params': [],
                'id': '1'
            })
            response = json.loads(self.server.handle_request(request))
            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], '1')
            self.assertEqual(response['error']['code'], -32601)
           

# Generated at 2022-06-17 15:18:03.658815
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.connection

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(ansible.module_utils.basic)
            self.server.register(ansible.module_utils.connection)

        def test_response(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'run_command', 'params': [['echo', 'hello']], 'id': 1})
            response = self.server.handle_request(request)
            response = json.loads(response)
            self.assertEqual(response['id'], 1)

# Generated at 2022-06-17 15:18:08.312200
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:12.287277
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_identifier'
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': 'test_result'}


# Generated at 2022-06-17 15:18:24.421634
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:33.682131
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            [],
            {}
        ],
        "id": 1
    }
    # Convert the request object to a string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to a string
    response = json.dumps(response)
    # Check if the response is correct
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "", "result_type": "pickle"}'

# Generated at 2022-06-17 15:18:46.406597
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())


# Generated at 2022-06-17 15:18:54.566571
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [
            [
                "show version"
            ],
            {
                "text": True
            }
        ],
        "id": 1
    }
    # Convert the request object to string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)
    # Convert the response object to string
    response = json.dumps(response)
    # Print the response
    print(response)


# Generated at 2022-06-17 15:19:00.551497
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = "test_id"
    result = server.response("test_result")
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:19:05.528266
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 3}'
    response = server.handle_request(request)
    assert json.loads(response) == {"jsonrpc": "2.0", "id": 3, "error": {"code": -32603, "message": "Internal error"}}

# Generated at 2022-06-17 15:19:17.663220
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:29.763940
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.ios.ios import ios_argument_spec
    from ansible.module_utils.network.ios.ios import get_config
    from ansible.module_utils.network.ios.ios import load_config
    from ansible.module_utils.network.ios.ios import run_commands
    from ansible.module_utils.network.ios.ios import get_capabilities
    from ansible.module_utils.network.ios.ios import get_connection_info
    from ansible.module_utils.network.ios.ios import get_defaults_flag

# Generated at 2022-06-17 15:19:33.723405
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = "test"
    result = server.response("test")
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:19:46.371385
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class Test(object):
        def rpc_test(self, *args, **kwargs):
            return args, kwargs

    server.register(Test())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "[1, 2, 3]", "id": 1}'

# Generated at 2022-06-17 15:19:51.009812
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["foo"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "foo", "id": 1}'


# Generated at 2022-06-17 15:19:55.961522
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-17 15:20:04.978969
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self._objects = set()
            self.register(TestClass())

    class TestJsonRpcServerTestCase(unittest.TestCase):
        def test_handle_request(self):
            server

# Generated at 2022-06-17 15:20:15.202489
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'
    class TestClass:
        def test_method(self):
            return "test_method"
    server.register(TestClass())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "test_method"}'


# Generated at 2022-06-17 15:20:20.511395
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'


# Generated at 2022-06-17 15:20:25.359445
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601

# Generated at 2022-06-17 15:20:34.798900
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": null}'


# Generated at 2022-06-17 15:20:41.755804
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

# Generated at 2022-06-17 15:20:51.457894
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.connection = Connection(self._socket_path)
            self._config = None

        @property
        def config(self):
            if not self._config:
                self._config = NetworkConfig(indent=1, contents=self.params['config'])
            return self._config



# Generated at 2022-06-17 15:20:57.144529
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:21:07.950632
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.ios.ios import ios_provider_spec
    from ansible.module_utils.network.ios.ios import ios_argument_spec
    from ansible.module_utils.network.ios.ios import get_config
    from ansible.module_utils.network.ios.ios import load_config

# Generated at 2022-06-17 15:21:19.220077
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import unittest
    from ansible.module_utils.six.moves import StringIO

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request(self):
            request = '{"jsonrpc": "2.0", "method": "test_method", "params": [1, 2, 3], "id": 1}'
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "result": "test_method(1, 2, 3)", "id": 1}')


# Generated at 2022-06-17 15:21:24.814167
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:21:31.887507
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys

    class TestJsonRpcServer(unittest.TestCase):
        def test_handle_request(self):
            server = JsonRpcServer()
            request = '{"jsonrpc": "2.0", "method": "test_method", "params": [], "id": 1}'
            response = server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestJsonRpcServer)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 15:21:41.334895
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import StringIO

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self.register(self)

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}


# Generated at 2022-06-17 15:21:46.108456
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '123'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'}


# Generated at 2022-06-17 15:22:07.644141
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': None}
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}
    result = server.response(b'test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}
    result = server.response(b'test_result', 'test_result_type')

# Generated at 2022-06-17 15:22:17.238521
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': 1
    })
    response = server.handle_request(request)
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32601,
            'message': 'Method not found'
        }
    }


# Generated at 2022-06-17 15:22:21.808932
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = {'test_key': 'test_value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': result}


# Generated at 2022-06-17 15:22:31.532620
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": "1"
    }

    # Convert the request object to a string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to a dictionary
    response = json.loads(response)

    # Check if the response is correct
    assert response == {
        "jsonrpc": "2.0",
        "result": "hello",
        "id": "1"
    }


# Generated at 2022-06-17 15:22:43.130280
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2

        def test_method_with_exception(self):
            raise Exception('test_method_with_exception')

        def test_method_with_connection_error(self):
            raise ConnectionError('test_method_with_connection_error')


# Generated at 2022-06-17 15:22:53.229245
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = {'jsonrpc': '2.0', 'method': 'not_found', 'id': 1}
            response = self.server.handle_request(json.dumps(request))
            response = json.loads(response)
            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], 1)
            self.assertEqual(response['error']['code'], -32601)

# Generated at 2022-06-17 15:22:58.472744
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:23:10.230685
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'

    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'


# Generated at 2022-06-17 15:23:21.045197
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class Test(object):
        def test(self, arg1, arg2=None):
            return {'arg1': arg1, 'arg2': arg2}

    server = JsonRpcServer()
    server.register(Test())

    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [['foo'], {'arg2': 'bar'}],
        'id': 'test'
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'
    assert response['id']

# Generated at 2022-06-17 15:23:32.737173
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return (arg1, arg2, kwarg1, kwarg2)

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self.register(TestClass())

    server = TestJsonRpcServer()

    # Test valid request
    request = {'method': 'test_method', 'params': [['arg1', 'arg2'], {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}], 'id': '1'}
    response = server.handle_

# Generated at 2022-06-17 15:24:06.292557
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:24:11.487808
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '1', 'result': result}


# Generated at 2022-06-17 15:24:18.299013
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
