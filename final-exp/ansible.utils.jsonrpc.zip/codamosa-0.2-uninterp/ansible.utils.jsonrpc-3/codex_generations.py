

# Generated at 2022-06-17 15:14:31.638130
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': result}


# Generated at 2022-06-17 15:14:37.433969
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

# Generated at 2022-06-17 15:14:44.784472
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'id': 'test',
                'method': 'test_method',
                'params': [1, 2]
            })
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": "test", "result": "test_method(1, 2)"}')


# Generated at 2022-06-17 15:14:49.668508
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:14:59.101272
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [
            [],
            {}
        ],
        'id': 1
    }

    # Convert request object to json string
    request = json.dumps(request)

    # Call method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert response to json object
    response = json.loads(response)

    # Check if response is correct

# Generated at 2022-06-17 15:15:08.982681
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {'jsonrpc': '2.0', 'method': 'rpc.test', 'params': [], 'id': 1}
    # Convert the request object to json
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to json
    response = json.loads(response)
    # Check if the response is correct
    assert response == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:15:16.821875
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': None}
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(b'test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(1)
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'I1\n.', 'result_type': 'pickle'}


# Generated at 2022-06-17 15:15:21.423948
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': '{}'}


# Generated at 2022-06-17 15:15:28.464538
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    request = {
        'jsonrpc': '2.0',
        'method': 'error',
        'params': [],
        'id': '1'
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'

# Generated at 2022-06-17 15:15:32.131725
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    response = server.response('test')
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:47.669849
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()

    # Create an instance of a class that will be registered with the server
    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the class with the server
    server.register(TestClass())

    # Create a request that will be passed to the server
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Convert the request to a string
    request = json.dumps(request)

    # Call the server's handle_request method
    response = server.handle_request(request)

    # Convert the response to a dictionary
   

# Generated at 2022-06-17 15:15:52.879323
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            [],
            {}
        ],
        "id": "1"
    }

    # Convert the request object to a JSON string
    request = json.dumps(request)

    # Call the method handle_request of the JsonRpcServer object
    response = server.handle_request(request)

    # Convert the response object to a JSON string
    response = json.loads(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:15:58.988544
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.error(code=1, message='test_message', data='test_data')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': 1, 'message': 'test_message', 'data': 'test_data'}}


# Generated at 2022-06-17 15:16:08.291004
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a test class
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the test class with the server
    server.register(TestClass())

    # Create a test request
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Convert the request to a string
    request = json.dumps(request)

    # Call the method
    response = server.handle_request(request)

    # Convert the response to a dictionary
    response = json.loads(response)

    # Check the response

# Generated at 2022-06-17 15:16:17.912845
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Test:
        def test(self, a, b):
            return a + b

    server = JsonRpcServer()
    server.register(Test())

    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [1, 2],
        'id': 1
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['result'] == 3

# Generated at 2022-06-17 15:16:24.765641
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestClass(object):
        def __init__(self):
            self.test_var = "test_var"

        def test_method(self, *args, **kwargs):
            return "test_method"

    class TestCase(unittest.TestCase):
        def test_handle_request(self):
            server = JsonRpcServer()
            server.register(TestClass())

            request = json.dumps({
                "jsonrpc": "2.0",
                "method": "test_method",
                "params": [],
                "id": 1
            })

            response = server.handle_request(request)
            response = json.loads(response)

            self.assertEqual(response["jsonrpc"], "2.0")

# Generated at 2022-06-17 15:16:34.507535
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    assert server.error(code=1, message='test_message') == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': 1, 'message': 'test_message'}}
    assert server.error(code=1, message='test_message', data='test_data') == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': 1, 'message': 'test_message', 'data': 'test_data'}}


# Generated at 2022-06-17 15:16:41.502238
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'


# Generated at 2022-06-17 15:16:46.577292
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'id': '1'}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:16:57.166110
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }

    # Convert the request object to a json string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to a json string
    response = json.loads(response)

    # Check if the response is a valid json-rpc response
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32601

# Generated at 2022-06-17 15:17:06.800809
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:17:18.312154
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.connection import Connection

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.connection = Connection()
            self.server.register(self.connection)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'not_found', 'params': [], 'id': 1})
            response = self.server.handle_request(request)
            self.assertEqual(json.loads(response), {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}})



# Generated at 2022-06-17 15:17:23.642082
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'


# Generated at 2022-06-17 15:17:31.562937
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': '1'
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:17:40.357296
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:50.039229
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [["show version"]],
        "id": "1"
    }

    # Convert the request object to string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)

    # Convert the response object to string
    response = json.dumps(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:17:57.635568
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test',
                'params': [],
                'id': 1
            })
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}')


# Generated at 2022-06-17 15:18:02.991663
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:18:09.081727
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    import json

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.jsonrpc = JsonRpcServer()
            self.jsonrpc.register(self)

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test_method',
                'params': [],
                'id': 1
            })
            response = self.jsonrpc.handle_request(request)
            self.assertEqual(response, '{"id": 1, "jsonrpc": "2.0", "result": "test_method"}')


# Generated at 2022-06-17 15:18:14.104067
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:23.606816
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "Hello, world!"}'

# Generated at 2022-06-17 15:18:32.458442
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:46.144465
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [
            [
                "show version"
            ],
            {
                "text": True
            }
        ],
        "id": "1"
    }

    # Convert the request object to a string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)

    # Convert the response object to a string
    response = json.dumps(response)

    # Print the response object
    print(response)


# Generated at 2022-06-17 15:18:54.431719
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:19:05.643186
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:09.741616
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:17.173000
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'

# Generated at 2022-06-17 15:19:26.000465
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:31.166304
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:38.409755
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": [
            "hello world"
        ],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {
        "jsonrpc": "2.0",
        "result": "hello world",
        "id": 1
    }

# Generated at 2022-06-17 15:19:52.860353
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # test case 1
    request = {'jsonrpc': '2.0', 'method': 'rpc.run', 'params': [['show version'], {}], 'id': '1'}
    request = json.dumps(request)
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32600
    assert response['error']['message'] == 'Invalid request'
    assert response['error']['data'] == 'Method name cannot start with rpc.'

    # test case 2
    request = {'jsonrpc': '2.0', 'method': '_run', 'params': [['show version'], {}], 'id': '1'}


# Generated at 2022-06-17 15:20:03.578286
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:20:14.222013
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import sys
    import os
    import unittest
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.json_rpc import JsonRpcServer

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

        def test_method_with_error(self, *args, **kwargs):
            raise ConnectionError(code=1, message='test error')

        def test_method_with_exception(self, *args, **kwargs):
            raise Exception('test exception')

# Generated at 2022-06-17 15:20:22.798105
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())


# Generated at 2022-06-17 15:20:31.163153
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import NetworkResourceConfig
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff

# Generated at 2022-06-17 15:20:41.051733
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.connection = Connection(self._socket_path)

# Generated at 2022-06-17 15:20:51.056882
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "get_facts",
        "params": [],
        "id": 1
    }

    # Convert the request object to json
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to json
    response = json.loads(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:21:01.745945
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:21:05.071089
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Internal error"}}'


# Generated at 2022-06-17 15:21:16.302324
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:21:22.838234
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {
        "jsonrpc": "2.0",
        "result": "hello world",
        "id": 1
    }

# Generated at 2022-06-17 15:21:29.967563
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:21:40.561447
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        'method': 'test_method',
        'params': [],
        'id': 'test_id'
    }

    # Convert the request object to a string
    request = json.dumps(request)

    # Call the method handle_request of the JsonRpcServer object
    response = server.handle_request(request)

    # Convert the response object to a string
    response = json.dumps(response)

    # Check if the response is equal to the expected result
    assert response == '{"jsonrpc": "2.0", "id": "test_id", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:46.013004
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:21:55.426781
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    from ansible.module_utils.six import PY3

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'foo',
                'params': [],
                'id': 1
            })
            response = self.server.handle_request(request)

# Generated at 2022-06-17 15:22:01.773240
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:11.182743
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:20.888030
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    import json
    import traceback
    import tempfile
    import shutil
    import socket
    import threading
    import time
    import subprocess
    import signal
    import re
    import copy
    import base64
    import pickle
    import random
    import string
    import importlib
    import inspect
    import ansible.module_utils.connection
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.http_client
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.ur

# Generated at 2022-06-17 15:22:29.512363
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "run_command", "params": ["show version"], "id": 1}'
    response = server.handle_request(request)
    print(response)

if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-17 15:22:41.762847
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonR

# Generated at 2022-06-17 15:22:55.572353
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    import mock

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.jsonrpc = JsonRpcServer()

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'id': 1})
            response = self.jsonrpc.handle_request(request)
            response = json.loads(response)
            self.assertEqual(response['error']['code'], -32601)
            self.assertEqual(response['error']['message'], 'Method not found')


# Generated at 2022-06-17 15:23:06.793419
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # create a JsonRpcServer object
    server = JsonRpcServer()
    # create a request
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": [
            "hello world"
        ],
        "id": 1
    }
    # create a response
    response = {
        "jsonrpc": "2.0",
        "result": "hello world",
        "id": 1
    }
    # create a class
    class TestClass:
        def echo(self, msg):
            return msg
    # register the class
    server.register(TestClass())
    # call the method handle_request
    result = server.handle_request(json.dumps(request))
    # compare the result with the response
    assert result == json.d

# Generated at 2022-06-17 15:23:10.657943
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

# Generated at 2022-06-17 15:23:18.807397
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": "1"
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:23:21.888401
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'


# Generated at 2022-06-17 15:23:33.033515
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_diff
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.utils import remove_empties
    from ansible.module_utils.network.common.utils import validate_ipv4_address
    from ansible.module_utils.network.common.utils import validate_ipv6_address
    from ansible.module_utils.network.common.utils import validate_ipv6_prefix


# Generated at 2022-06-17 15:23:46.386586
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class TestClass(object):
        def test_method(self):
            return "test_method"

    server.register(TestClass())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "result": "test_method", "id": 1}'

# Generated at 2022-06-17 15:23:50.304609
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:23:55.799054
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:24:06.852366
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": [
            "hello",
            "world"
        ],
        "id": 1
    }
    # Convert the request object to a JSON string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to a JSON string
    response = json.loads(response)
    # Check if the response object is valid
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["result"] == "hello world"



# Generated at 2022-06-17 15:24:22.379842
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))