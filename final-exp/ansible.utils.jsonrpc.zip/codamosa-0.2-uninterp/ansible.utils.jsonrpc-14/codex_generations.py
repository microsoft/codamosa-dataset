

# Generated at 2022-06-17 15:14:34.537061
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test_method", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:14:41.813751
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:14:51.426959
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '123'
    response = server.response()
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': None}
    response = server.response('foo')
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': 'foo'}
    response = server.response(b'foo')
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': 'foo'}
    response = server.response({'foo': 'bar'})

# Generated at 2022-06-17 15:14:57.650799
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    response = server.error(code=1, message='test_message', data='test_data')
    assert response == {
        'jsonrpc': '2.0',
        'id': 'test_identifier',
        'error': {
            'code': 1,
            'message': 'test_message',
            'data': 'test_data'
        }
    }


# Generated at 2022-06-17 15:15:02.333701
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:15:11.529389
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.basic import AnsibleModule

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.module = AnsibleModule(argument_spec={})

        def test_handle_request_method_not_found(self):
            request = {
                'jsonrpc': '2.0',
                'id': '1',
                'method': 'not_found',
                'params': []
            }
            response = self.server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:15:18.294893
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:15:27.180465
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': None}
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(b'test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response({'test': 'test'})

# Generated at 2022-06-17 15:15:32.759143
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:15:39.955281
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': result}


# Generated at 2022-06-17 15:15:49.903345
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = json.dumps({'jsonrpc': '2.0', 'method': 'error', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-17 15:15:53.676133
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:15:55.857181
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '1'
    result = {'foo': 'bar'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '1', 'result': {'foo': 'bar'}}


# Generated at 2022-06-17 15:16:01.312587
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": "1"}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:16:10.250414
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "{}"}'
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Internal error"}}'

# Generated at 2022-06-17 15:16:16.680383
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'


# Generated at 2022-06-17 15:16:25.026149
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:16:31.303638
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "foo", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:16:40.615027
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import traceback
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.utils.display import Display
    display = Display()
    request = '{"jsonrpc": "2.0", "method": "run_command", "params": [["show version"]], "id": 1}'
    request = json.loads(to_text(request, errors='surrogate_then_replace'))
    method = request.get('method')
    if method.startswith('rpc.') or method.startswith('_'):
        error = self.invalid_request()
        return json.dumps(error)
    args, k

# Generated at 2022-06-17 15:16:47.546867
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

    # Test case 2
    request = '{"jsonrpc": "2.0", "method": "test", "params": [], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)

# Generated at 2022-06-17 15:16:59.003572
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:09.017504
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.connection import ConnectionError

    class TestClass(object):
        def __init__(self):
            self.test_attr = "test_attr"

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

        def test_method_with_exception(self):
            raise ConnectionError("test_method_with_exception")

        def test_method_with_internal_error(self):
            raise Exception("test_method_with_internal_error")


# Generated at 2022-06-17 15:17:19.201678
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()
    # Create a request object
    request = {'method': 'test_method', 'params': [], 'id': '1'}
    # Convert the request object to a json string
    request_json = json.dumps(request)
    # Call the handle_request method of the JsonRpcServer object
    response = json_rpc_server.handle_request(request_json)
    # Convert the response to a python object
    response_obj = json.loads(response)
    # Check if the response object has the expected keys
    assert 'jsonrpc' in response_obj
    assert 'id' in response_obj
    assert 'result' in response_obj
    # Check if the response object has the expected values
    assert response

# Generated at 2022-06-17 15:17:24.153061
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1, 2, 3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:35.356489
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDump
    from ansible.module_utils.network.common.parsing import NetworkConfigDumpError

# Generated at 2022-06-17 15:17:41.162153
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 1
    response = server.response(result={"key": "value"})
    assert response == {"jsonrpc": "2.0", "id": 1, "result": {"key": "value"}}


# Generated at 2022-06-17 15:17:45.799725
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = {'key': 'value'}
    response = server.response(result)
    assert response['id'] == 'test_id'
    assert response['result'] == result


# Generated at 2022-06-17 15:17:56.374549
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a class to register with the JsonRpcServer object
    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2
    # Register the class with the JsonRpcServer object
    server.register(TestClass())
    # Create a request
    request = {'jsonrpc': '2.0', 'id': 1, 'method': 'test_method', 'params': [1, 2]}
    # Call the method handle_request of the JsonRpcServer object with the request
    response = server.handle_request(json.dumps(request))
    # Check the response

# Generated at 2022-06-17 15:18:03.657916
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:08.158370
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_identifier'
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': 'test_result'}


# Generated at 2022-06-17 15:18:16.842004
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:18:28.533506
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:18:35.051126
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": "hello"
    }


# Generated at 2022-06-17 15:18:46.823005
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-17 15:18:56.272981
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:02.635058
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 0}'

# Generated at 2022-06-17 15:19:13.427087
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.six.moves import cPickle

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.jsonrpc = JsonRpcServer()
            self.jsonrpc.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'not_found', 'params': [], 'id': 1})
            response = self.jsonrpc.handle_request(request)
            self.assertEqual(json.loads(response), {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}})

# Generated at 2022-06-17 15:19:20.894141
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:19:28.990919
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [[], {}],
        'id': '1'
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == '1'
    assert response['jsonrpc'] == '2.0'

# Generated at 2022-06-17 15:19:40.777283
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list

    class TestModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     add_file_common_args=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive
            self.required_together = required

# Generated at 2022-06-17 15:19:52.253753
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import StringIO

    class Test(object):
        def test(self, *args, **kwargs):
            return args, kwargs

    server = JsonRpcServer()
    server.register(Test())

    request = json.dumps({'method': 'test', 'params': [[1, 2, 3], {'a': 'b'}], 'id': 'test'})
    response = server.handle_request(request)
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 'test', 'result': [[1, 2, 3], {'a': 'b'}]}


# Generated at 2022-06-17 15:19:56.711130
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:05.449875
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:20:09.201533
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    result = server.response(result='test')
    assert result == {'jsonrpc': '2.0', 'id': '1', 'result': 'test'}


# Generated at 2022-06-17 15:20:19.378118
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(b'test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(1)
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result_type': 'pickle', 'result': 'K\x01.'}
    result = server.response(1.0)

# Generated at 2022-06-17 15:20:23.408941
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:26.737114
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': 'test_result'}


# Generated at 2022-06-17 15:20:35.500309
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

    # Test case 2
    request = '{"jsonrpc": "2.0", "method": "_test", "params": [1,2,3], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)

# Generated at 2022-06-17 15:20:42.004720
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'

    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'

    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
   

# Generated at 2022-06-17 15:20:49.712183
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": -32601,
            "message": "Method not found",
            "data": None
        }
    }


# Generated at 2022-06-17 15:21:03.477726
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'test_method', 'params': [], 'id': 1})
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "result": "test_method"}')


# Generated at 2022-06-17 15:21:14.567844
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [
            [],
            {}
        ],
        "id": "1"
    }
    # Convert the request object to JSON
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to JSON
    response = json.loads(response)
    # Check if the response is correct

# Generated at 2022-06-17 15:21:24.761474
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    class TestClass:
        def test(self, *args, **kwargs):
            return args, kwargs
    server.register(TestClass())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "(\\x80\\x03]q\\x00(K\\x01K\\x02K\\x03e.", "id": 1}'

# Generated at 2022-06-17 15:21:32.000140
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:21:41.387022
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import Connection
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import NetworkConfigDump
    from ansible.module_utils.network.common.parsing import NetworkConfigDumpError

# Generated at 2022-06-17 15:21:52.592524
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "header", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": null}'

    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": null}'

    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_

# Generated at 2022-06-17 15:21:58.207707
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:22:04.933045
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:12.931247
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:18.275661
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1, 2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:31.301570
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def test_handle_request(self):
            server = JsonRpcServer()
            request = json.dumps({'method': 'test', 'params': [], 'id': 1})
            response = server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}')

    unittest.main()

# Generated at 2022-06-17 15:22:43.020355
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:48.583198
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:22:53.309311
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["foo"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "foo"}'


# Generated at 2022-06-17 15:23:05.011524
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'

# Generated at 2022-06-17 15:23:09.462281
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:23:22.775223
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            "arg1",
            "arg2"
        ],
        "id": "1"
    }
    # Convert the request object to JSON
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response to JSON
    response = json.loads(response)
    # Check if the response is correct

# Generated at 2022-06-17 15:23:34.868291
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import NetworkParseWarning
    from ansible.module_utils.network.common.parsing import NetworkParserWarning

# Generated at 2022-06-17 15:23:45.496753
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [[], {}], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class Test(object):
        def test(self):
            return 'test'

    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "result": "test", "id": 1}'


# Generated at 2022-06-17 15:23:48.052502
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test_method", "params": [1, 2, 3], "id": "1"}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'



# Generated at 2022-06-17 15:24:00.263559
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    request = '{"jsonrpc": "2.0", "method": "handle_request", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

# Generated at 2022-06-17 15:24:06.193828
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:24:16.253975
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    class TestClass(object):
        def __init__(self):
            self.test_list = []

        def test_method(self, *args, **kwargs):
            self.test_list.append(args)
            self.test_list.append(kwargs)
            return self.test_list

    server = JsonRpcServer()
    server.register(TestClass())


# Generated at 2022-06-17 15:24:27.586172
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a class to be registered with the JsonRpcServer object
    class TestClass:
        def __init__(self):
            self.test_var = "test_var"

        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Create a TestClass object
    test_obj = TestClass()

    # Register the TestClass object with the JsonRpcServer object
    server.register(test_obj)

    # Create a request dictionary
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Convert the request dictionary to a json string
    request_