

# Generated at 2022-06-17 15:14:31.897762
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '123'
    response = server.response('test')
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'}


# Generated at 2022-06-17 15:14:37.478268
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test_identifier'
    error = server.error(code=1, message='test_message')
    assert error == {'jsonrpc': '2.0', 'id': 'test_identifier', 'error': {'code': 1, 'message': 'test_message'}}


# Generated at 2022-06-17 15:14:47.709818
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class TestClass(object):
        def __init__(self):
            self.test_method_called = False
            self.test_method_args = None
            self.test_method_kwargs = None

        def test_method(self, *args, **kwargs):
            self.test_method_called = True
            self.test_method_args = args
            self.test_method_kwargs = kwargs
            return 'test_method_result'

    test_class = TestClass()
    server = JsonRpcServer()
    server.register(test_class)

    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': 'test_id'
    }


# Generated at 2022-06-17 15:14:52.788842
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': '123', 'result': None}


# Generated at 2022-06-17 15:14:58.223263
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=1, message='test')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:14:59.751176
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    error = server.error(code=1, message='test')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test'}}

# Generated at 2022-06-17 15:15:03.849223
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:07.740426
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': result}


# Generated at 2022-06-17 15:15:12.436758
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.error(-32603, 'Internal error', 'test_data')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'test_data'}}


# Generated at 2022-06-17 15:15:18.908843
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:15:33.898819
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfConnectionError
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorCode
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorMessage
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorData
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorCode
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorMessage
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorData

# Generated at 2022-06-17 15:15:47.223410
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfSession
    from ansible.module_utils.network.common.netconf import NetconfTransport
    from ansible.module_utils.network.common.netconf import NetconfXMLSession
    from ansible.module_utils.network.common.netconf import NetconfXMLTransport
    from ansible.module_utils.network.common.netconf import NetconfXMLSSHSession
    from ansible.module_utils.network.common.netconf import NetconfX

# Generated at 2022-06-17 15:15:52.900552
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    import mock
    from ansible.module_utils.json_rpc_server import JsonRpcServer

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.json_rpc_server = JsonRpcServer()
            self.json_rpc_server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'not_found',
                'params': [],
                'id': 1
            })
            response = self.json_rpc_server.handle_request(request)

# Generated at 2022-06-17 15:15:58.651502
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:16:05.907537
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': '1'
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-17 15:16:10.578999
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:16:22.353080
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'

# Generated at 2022-06-17 15:16:29.304411
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'test', 'params': [[], {}]})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:16:39.989137
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize the JsonRpcServer object
    server = JsonRpcServer()

    # Create a test class
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2):
            return self.test_value

    # Create an instance of the test class
    test_class = TestClass()

    # Register the test class with the JsonRpcServer
    server.register(test_class)

    # Create a test request
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': ['arg1', 'arg2'],
        'id': 'test_id'
    }

    # Convert the request to a json string

# Generated at 2022-06-17 15:16:50.039447
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.tmpdir = tempfile.mkdtemp()
            self.filename = os.path.join(self.tmpdir, 'test.txt')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'not_found', 'id': 1})
            response = self.server.handle_request(request)

# Generated at 2022-06-17 15:16:59.985688
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': '1'
    })
    response = server.handle_request(request)
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': '1',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }

# Generated at 2022-06-17 15:17:06.662096
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.network.common.utils import to_text
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    class TestClass(object):
        def __init__(self):
            self.test_method_called = False
            self.test_method_args = None
            self.test_method_kwargs = None
            self.test_method_result = None

        def test_method(self, *args, **kwargs):
            self.test_method_called = True
            self.test_method_args = args
           

# Generated at 2022-06-17 15:17:15.393573
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "id": 1,
        "params": [
            [],
            {}
        ]
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:17:22.571334
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:29.807777
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1, 2, 3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:36.433858
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': '1'
    })
    response = server.handle_request(request)
    assert response == json.dumps({
        'jsonrpc': '2.0',
        'id': '1',
        'error': {
            'code': -32601,
            'message': 'Method not found'
        }
    })


# Generated at 2022-06-17 15:17:47.690255
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1
    request = '{"jsonrpc": "2.0", "method": "rpc.run", "params": [["show version"]], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

    # Test case 2
    request = '{"jsonrpc": "2.0", "method": "run", "params": [["show version"]], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)

# Generated at 2022-06-17 15:17:56.741290
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.connection = Connection(None)
            self.server = JsonRpcServer()
            self.server.register(self.connection)

        def test_handle_request(self):
            request = {
                'jsonrpc': '2.0',
                'method': 'get_config',
                'params': [],
                'id': 1
            }
            response = self.server.handle_request(json.dumps(request))
            response = json.loads(response)
            self.assertEqual(response['jsonrpc'], '2.0')

# Generated at 2022-06-17 15:18:03.868617
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    request = {
        'jsonrpc': '2.0',
        'method': 'error',
        'params': [],
        'id': 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response['id'] == 1
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'

    request = {
        'jsonrpc': '2.0',
        'method': 'response',
        'params': [],
        'id': 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

# Generated at 2022-06-17 15:18:09.400379
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

# Generated at 2022-06-17 15:18:24.617541
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:28.798909
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.network.common.utils import to_text
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer
    from ansible.module_utils.network.common.json_rpc import JsonRpcError
    from ansible.module_utils.network.common.json_rpc import JsonRpcMethodNotFound
    from ansible.module_utils.network.common.json_rpc import JsonRpcInvalidParams
    from ansible.module_utils.network.common.json_rpc import JsonRpcInternalError

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

    server = JsonRpcServer()
    server.register(TestClass())



# Generated at 2022-06-17 15:18:34.193258
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:46.559066
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestCase(unittest.TestCase):
        def test_handle_request(self):
            server = JsonRpcServer()
            server.register(TestClass())


# Generated at 2022-06-17 15:18:51.335136
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:18:59.804601
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:08.151621
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:19.715904
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    request = '{"jsonrpc": "2.0", "method": "invalid_request", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)
    assert json.loads(response) == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}
    request = '{"jsonrpc": "2.0", "method": "method_not_found", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)

# Generated at 2022-06-17 15:19:25.738957
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(request)

# Generated at 2022-06-17 15:19:30.500630
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:19:47.138218
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:19:58.595267
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.jsonrpc_server = JsonRpcServer()
            self.connection = Connection(load_provider({'transport': 'network_cli'}))
            self.jsonrpc_server.register(self.connection)

        def test_handle_request_method_not_found(self):
            request = {'jsonrpc': '2.0', 'method': 'not_found', 'params': [], 'id': 1}
            response = self.jsonrpc_server.handle_request(json.dumps(request))
            self

# Generated at 2022-06-17 15:20:10.784934
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    class TestConnection(Connection):
        def __init__(self, *args, **kwargs):
            self._socket_path = '/dev/null'
            self.transport = 'network_cli'
            self.connected

# Generated at 2022-06-17 15:20:16.644053
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:20:21.643734
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32600, "message": "Invalid request"}}'


# Generated at 2022-06-17 15:20:26.482385
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            [],
            {}
        ],
        "id": "1"
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == '1'


# Generated at 2022-06-17 15:20:35.192221
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response == {
        "jsonrpc": "2.0",
        "error": {
            "code": -32601,
            "message": "Method not found",
            "data": None
        },
        "id": 1
    }

    class TestClass(object):
        def test_method(self):
            return "test_method"

    server.register(TestClass())
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:20:41.814985
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.json_rpc import JsonRpcServer

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

        def test_method_with_error(self, *args, **kwargs):
            raise ConnectionError(code=1, msg='test error')

        def test_method_with_exception(self, *args, **kwargs):
            raise Exception('test exception')


# Generated at 2022-06-17 15:20:51.535370
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a test class
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the test class
    server.register(TestClass())

    # Create a test request
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Call the method handle_request
    response = server.handle_request(json.dumps(request))

    # Check the response
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": 3}'


# Generated at 2022-06-17 15:20:58.502220
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello"],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": "hello"
    }


# Generated at 2022-06-17 15:21:19.171113
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [[], {}], 'id': '1'}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:21:22.994836
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-17 15:21:36.612159
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.connection import Connection

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.connection = Connection()
            self.server.register(self.connection)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'method': 'not_found', 'params': [], 'id': 1})
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}')


# Generated at 2022-06-17 15:21:45.667611
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    server = JsonRpcServer()
    server.register(TestClass())

    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [['arg1', 'arg2'], {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}],
        'id': 'test_id'
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)



# Generated at 2022-06-17 15:21:55.199727
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:05.592313
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    import json
    import traceback
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.utils.display import Display
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.json_rpc import JsonRpcServer
    display = Display()
    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.jsonrpc = JsonRpcServer()
            self.jsonrpc.register(self)
        def tearDown(self):
            pass

# Generated at 2022-06-17 15:22:09.372078
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 0}'


# Generated at 2022-06-17 15:22:13.955949
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': 1
    })
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:22:24.565861
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    request = {
        "jsonrpc": "2.0",
        "method": "rpc._test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:22:30.654359
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1, 2, 3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:54.693866
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig

    module = AnsibleModule(
        argument_spec=dict(
            host=dict(required=True),
            port=dict(required=True),
            username=dict(required=True),
            password=dict(required=True),
            use_ssl=dict(required=True),
            validate_certs=dict(required=True),
            provider=dict(required=True),
        ),
        supports_check_mode=True
    )

    provider = load_provider(module)
    conn = Connection(module._socket_path)

    rpc_

# Generated at 2022-06-17 15:23:00.884312
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'


# Generated at 2022-06-17 15:23:06.513294
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError

# Generated at 2022-06-17 15:23:11.697362
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:23:17.400872
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:23:23.114101
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {"jsonrpc": "2.0", "method": "test", "params": [], "id": 1}
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:23:35.178590
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:23:44.479145
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    class Test(object):
        def test(self):
            return 'test'
    server.register(Test())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "test", "id": 1}'

# Generated at 2022-06-17 15:23:51.752090
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a test class
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the test class with the JsonRpcServer
    server.register(TestClass())

    # Create a test request
    request = {'jsonrpc': '2.0', 'method': 'test_method', 'params': [1, 2], 'id': 1}

    # Call the handle_request method of the JsonRpcServer
    response = server.handle_request(json.dumps(request))

    # Verify the response
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'result': 3}

# Generated at 2022-06-17 15:23:57.458979
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == json.dumps({'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}})


# Generated at 2022-06-17 15:24:22.385498
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.network.common.utils import to_text

    class TestClass(object):
        def __init__(self):
            self.test_string = 'test_string'
            self.test_int = 1
            self.test_list = [1, 2, 3]
            self.test_dict = {'a': 1, 'b': 2}
            self.test_binary = binary_type('test_binary')

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2
