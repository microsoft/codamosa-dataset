

# Generated at 2022-06-17 15:14:36.367539
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': '{}', 'result_type': 'pickle'}


# Generated at 2022-06-17 15:14:39.682883
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:14:50.197496
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import pickle
    import traceback
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self):
            return self.test_value

        def test_method_with_args(self, arg1, arg2):
            return arg1 + arg2

        def test_method_with_kwargs(self, arg1, arg2):
            return arg1 + arg2


# Generated at 2022-06-17 15:14:55.093215
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:05.580878
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    class TestConnection(Connection):
        def __init__(self, module):
            self._module = module

# Generated at 2022-06-17 15:15:09.975942
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:14.012302
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:18.724661
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:22.465813
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:15:25.961394
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:42.337333
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:15:51.351119
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six import PY3

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self.register(self)

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestJsonRpcServerTestCase(unittest.TestCase):
        def setUp(self):
            self.server = TestJsonRpcServer()


# Generated at 2022-06-17 15:15:55.934215
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:16:04.498978
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import traceback
    import copy
    import pickle
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter

# Generated at 2022-06-17 15:16:12.495536
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())


# Generated at 2022-06-17 15:16:21.694203
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    import json
    import sys
    import os
    import traceback
    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils._text
    import ansible.utils.display
    import ansible.module_utils.json_rpc

    class MockDisplay(object):
        def __init__(self):
            self.v = False
            self.vv = False
            self.vvv = False

        def display(self, msg, *args, **kwargs):
            pass

        def v(self, msg, *args, **kwargs):
            pass


# Generated at 2022-06-17 15:16:30.062592
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'error',
        'params': [],
        'id': 1
    })
    response = server.handle_request(request)
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32603,
            'message': 'Internal error'
        }
    }

# Generated at 2022-06-17 15:16:40.273428
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [[], {}], 'id': 1}

    # Convert the request object to json
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to json
    response = json.loads(response)

    # Check if the response object is valid
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-17 15:16:46.249430
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:16:57.167684
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2, 'test_value': self.test_value}

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self.test_class = TestClass()
            self.register(self.test_class)


# Generated at 2022-06-17 15:17:10.506276
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}


# Generated at 2022-06-17 15:17:19.429760
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {'method': 'test_method', 'params': [[], {}], 'id': 'test_id'}
    # Convert the request object to JSON string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to JSON string
    response = json.loads(response)
    # Check the response object
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 'test_id'
    assert response['result'] == 'test_result'


# Generated at 2022-06-17 15:17:24.515781
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1, 2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:17:31.372809
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:17:39.469920
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDump
    from ansible.module_utils.network.common.parsing import NetworkConfigDumpError

# Generated at 2022-06-17 15:17:45.625100
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:17:52.986100
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:18:04.696569
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from lib.connection import Connection
    from lib.utils.shell import ShellError
    from lib.utils.shell import CommandError
    from lib.utils.shell import Shell
    from lib.utils.shell import CliError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError
    from lib.utils.shell import ConnectionError

# Generated at 2022-06-17 15:18:14.492103
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with valid request
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': [{'a': 1, 'b': 2}], 'id': 1})
    response = server.handle_request(request)
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'result': {'a': 1, 'b': 2}}

    # Test with invalid request
    request = json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': [{'a': 1, 'b': 2}]})
    response = server.handle_request(request)

# Generated at 2022-06-17 15:18:21.333997
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:18:33.705100
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test_method',
                'params': [[1, 2, 3], {'a': 'b'}],
                'id': 1
            })
            response = self.server.handle_request(request)

# Generated at 2022-06-17 15:18:41.695339
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'id': 1, 'method': 'test', 'params': [[], {}]}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:18:48.558159
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:58.263330
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfig
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-17 15:19:03.211410
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:19:07.764641
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:19:15.088898
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:21.081033
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:19:31.130247
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:40.193051
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    class Test(object):
        def test(self):
            return 'test'

    server.register(Test())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "test"}'

# Generated at 2022-06-17 15:19:55.321707
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import sys
    import os
    import unittest
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_text
    from ansible.module_utils.network.common.utils import to_bytes
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer
    from ansible.module_utils.network.common.json_rpc import JsonRpcClient

# Generated at 2022-06-17 15:20:00.006918
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "id": 1, "params": ["foo"]}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "foo"}'

# Generated at 2022-06-17 15:20:05.188960
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:15.672921
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'test', 'params': [[], {}]}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

    class Test(object):
        def test(self):
            return 'test'

    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "result": "test"}'


# Generated at 2022-06-17 15:20:23.082615
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {"jsonrpc": "2.0", "method": "test", "params": [], "id": 1}
    # Convert the request object to json
    request = json.dumps(request)
    # Call the handle_request method of the JsonRpcServer object
    response = server.handle_request(request)
    # Convert the response object to json
    response = json.loads(response)
    # Check if the response is correct
    assert response == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}


# Generated at 2022-06-17 15:20:31.439780
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test_method',
                'params': [],
                'id': 1
            })
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "result": "test_method"}')


# Generated at 2022-06-17 15:20:36.508753
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1, 2, 3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:44.110937
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }

    # Convert the request object to json string
    request = json.dumps(request)

    # Call the handle_request method of JsonRpcServer class
    response = server.handle_request(request)

    # Convert the response to json object
    response = json.loads(response)

    # Check if the response is valid
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["error"]["code"] == -32601

# Generated at 2022-06-17 15:20:49.210799
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "Hello, world!"}'

# Generated at 2022-06-17 15:20:54.904105
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle

    class Test(object):
        def test(self, *args, **kwargs):
            return args, kwargs

    server = JsonRpcServer()
    server.register(Test())

    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [[1, 2, 3], {'a': 'b'}],
        'id': '1'
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
   

# Generated at 2022-06-17 15:21:03.806844
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:21:14.801042
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    # test invalid request
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3,4,5]}'
    response = server.handle_request(request)
    assert json.loads(response) == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': None
        }
    }

    # test method not found
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3,4,5]}'
    response = server.handle_request(request)
    assert json

# Generated at 2022-06-17 15:21:21.567730
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:29.964636
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["Hello World"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "Hello World"}'


# Generated at 2022-06-17 15:21:40.562130
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a JsonRpcServer object

# Generated at 2022-06-17 15:21:52.229903
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig

    # create a mock connection object
    conn = Connection()
    conn._socket_path = '/tmp/ansible_test_socket'
    conn._play_context = {'port': 22}

    # create a mock network module
    module = {'params': {'provider': {'username': 'admin', 'password': 'admin'}}}
    load_provider(module)

    # create a mock network module
    module = {'params': {'provider': {'username': 'admin', 'password': 'admin'}}}
    load_provider(module)

    # create a mock network module
   

# Generated at 2022-06-17 15:22:01.719222
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import traceback
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle
    from ansible.utils.display import Display
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.json_rpc import JsonRpcServer

    display = Display()

    class JsonRpcServer(object):

        _objects = set()

        def handle_request(self, request):
            request = json.loads(to_text(request, errors='surrogate_then_replace'))

            method = request.get('method')


# Generated at 2022-06-17 15:22:11.148786
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return (arg1, arg2, kwarg1, kwarg2)

    server = JsonRpcServer()
    server.register(TestClass())

    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [['arg1', 'arg2'], {'kwarg1': 'kwarg1', 'kwarg2': 'kwarg2'}],
        'id': '1'
    }


# Generated at 2022-06-17 15:22:17.173024
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestClass(object):
        def __init__(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.test_class = TestClass()


# Generated at 2022-06-17 15:22:25.370430
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()

    # Create a class to register with the server
    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the class with the server
    server.register(TestClass())

    # Create a valid request
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [1, 2],
        'id': 1
    }

    # Convert the request to a string
    request = json.dumps(request)

    # Call the handle_request method
    response = server.handle_request(request)

    # Convert the response to a dictionary
    response = json.loads(response)

    # Check the

# Generated at 2022-06-17 15:22:43.261856
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:48.490515
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'


# Generated at 2022-06-17 15:22:57.576380
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [["show version"]],
        "id": 1
    }

    # Convert the request object to string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)

    # Convert the response object to string
    response = json.dumps(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:23:04.012133
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()
    # Create a request object
    request = {"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}
    # Convert the request object to json string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)
    # Convert the response to json object
    response = json.loads(response)
    # Check if the response is a valid json-rpc error response
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["error"]["code"] == -32600

# Generated at 2022-06-17 15:23:10.859310
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == "Method not found"


# Generated at 2022-06-17 15:23:17.577785
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'


# Generated at 2022-06-17 15:23:26.089883
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "get_facts",
        "params": [],
        "id": "1"
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == "1"
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == "Method not found"


# Generated at 2022-06-17 15:23:35.464218
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:23:41.253314
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'echo', 'params': ['hello'], 'id': 1})
    response = json.loads(server.handle_request(request))
    assert response == {'jsonrpc': '2.0', 'id': 1, 'result': 'hello'}

# Generated at 2022-06-17 15:23:46.953098
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 0})
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 0


# Generated at 2022-06-17 15:23:59.468865
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {'method': 'test_method', 'params': [], 'id': '1'}
    request = json.dumps(request)

    # Call the method
    response = server.handle_request(request)

    # Check the response
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:24:05.061804
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:24:10.093783
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:24:22.302018
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()

    # Create a class with a method that will be called by the server
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the class with the server
    server.register(TestClass())

    # Create a request that will be passed to the server
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Call the server
    response = server.handle_request(json.dumps(request))

    # Verify the response
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": 3}'

# Generated at 2022-06-17 15:24:30.052397
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.iosxr.iosxr import iosxr_provider_spec
    from ansible.module_utils.network.iosxr.iosxr import get_config, load_config
    from ansible.module_utils.network.iosxr.iosxr import get_connection
    from ansible.module_utils.network.iosxr.iosxr import run_commands
    from ansible.module_utils.network.iosxr.iosxr import get_capabilities
    from ansible.module_utils.network.iosxr.iosxr import get_defaults_flag