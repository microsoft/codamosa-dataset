

# Generated at 2022-06-17 15:14:46.912696
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    import json

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'test', 'params': []})
            response = self.server.handle_request(request)
            self.assertEqual(json.loads(response), {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}})


# Generated at 2022-06-17 15:14:58.382668
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.loader import connection_loader

    # Create a connection object
    conn = Connection(None)
    # Create a JsonRpcServer object
    rpc_server = JsonRpcServer()
    # Register the connection object with the JsonRpcServer object
    rpc_server.register(conn)

    # Create a request object
    request = {
        'jsonrpc': '2.0',
        'method': 'get_capabilities',
        'params': [],
        'id': 1
    }
    # Convert the request object to a JSON string
    request = json.dumps(request)
    # Call the handle_request method of the JsonRpcServer

# Generated at 2022-06-17 15:15:08.566055
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError

# Generated at 2022-06-17 15:15:16.575761
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:15:22.542481
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:15:26.405050
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}

# Generated at 2022-06-17 15:15:29.972920
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:42.419814
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError

# Generated at 2022-06-17 15:15:46.558142
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    result = server.response(result='test')
    assert result == {'jsonrpc': '2.0', 'id': '1', 'result': 'test'}


# Generated at 2022-06-17 15:15:52.471895
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigPar

# Generated at 2022-06-17 15:16:02.077508
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:16:10.670186
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 0, "result": null}'
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 0, "error": {"code": -32603, "message": "Internal error"}}'

# Generated at 2022-06-17 15:16:13.958816
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.error(code=1, message='test_message')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': 1, 'message': 'test_message'}}


# Generated at 2022-06-17 15:16:21.044805
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': '1'
    })
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {
        'jsonrpc': '2.0',
        'id': '1',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }


# Generated at 2022-06-17 15:16:27.651236
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = server.error(code=1, message='test_message', data='test_data')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'error': {'code': 1, 'message': 'test_message', 'data': 'test_data'}}

# Generated at 2022-06-17 15:16:34.852978
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:16:41.514593
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    response = server.error(code=1, message='test')
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:44.964271
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:57.037916
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a test class
    class TestClass(object):
        def __init__(self):
            self.name = 'test'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2

    # Register the test class with the server
    server.register(TestClass())

    # Create a test request
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [1, 2, {'kwarg1': 3, 'kwarg2': 4}],
        'id': 1
    }

    # Call the handle_request method of the

# Generated at 2022-06-17 15:17:08.368581
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': None}
    result = server.response(result='test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'test'}
    result = server.response(result=b'test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'test'}
    result = server.response(result={'test': 'test'})

# Generated at 2022-06-17 15:17:21.144423
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a class to register with the JsonRpcServer object
    class TestClass:
        def test_method(self):
            return "test_method"

    # Register the class with the JsonRpcServer object
    json_rpc_server.register(TestClass())

    # Create a request to test the handle_request method
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }

    # Call the handle_request method
    response = json_rpc_server.handle_request(json.dumps(request))

    # Verify the response is correct

# Generated at 2022-06-17 15:17:27.315152
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.connection import Connection

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.connection = Connection()
            self.server.register(self.connection)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'invalid', 'id': 1})
            response = self.server.handle_request(request)
            self.assertEqual(json.loads(response), {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}})


# Generated at 2022-06-17 15:17:34.304557
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-17 15:17:46.847394
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'rpc.test', 'params': [[], {}]}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32600, "message": "Invalid request"}}'

    # Test case 2
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'id': '1', 'method': '_test', 'params': [[], {}]}
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:17:56.435998
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:03.740734
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import sys
    import os
    import unittest
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_text
    from ansible.module_utils.network.common.utils import to_bytes
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.utils import ComplexList
    from ansible.module_utils.network.common.utils import dict_diff

# Generated at 2022-06-17 15:18:14.174478
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:22.657413
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = json.loads(server.handle_request(request))
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-17 15:18:26.974010
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:18:36.769865
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [["show version"]],
        "id": 1
    }

    # Convert the request object to string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to string
    response = json.dumps(response)

    # Check if the response is valid

# Generated at 2022-06-17 15:18:51.135185
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    class Test(object):
        def test(self):
            return 'test'

    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "test"}'


# Generated at 2022-06-17 15:18:54.858600
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:19:05.680046
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.nxos.nxos import get_config, load_config
    from ansible.module_utils.network.nxos.nxos import get_capabilities
    from ansible.module_utils.network.nxos.nxos import get_defaults_flag
    from ansible.module_utils.network.nxos.nxos import get_connection_params
    from ansible.module_utils.network.nxos.nxos import get_connection_params
    from ansible.module_utils.network.nxos.nxos import get_defaults_flag

# Generated at 2022-06-17 15:19:09.272706
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:19:12.742283
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpc = JsonRpcServer()
    jrpc._identifier = 'test_identifier'
    result = {'test': 'test'}
    response = jrpc.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:19:18.866518
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError

# Generated at 2022-06-17 15:19:25.683784
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': '{}'}


# Generated at 2022-06-17 15:19:33.227476
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

        def test_method_error(self, *args, **kwargs):
            raise Exception('Test error')

        def test_method_connection_error(self, *args, **kwargs):
            raise ConnectionError('Test error')

        def test_method_connection_error_with_code(self, *args, **kwargs):
            raise ConnectionError('Test error', code=123)


# Generated at 2022-06-17 15:19:43.062334
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:54.644284
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        'jsonrpc': '2.0',
        'method': 'echo',
        'params': ['hello'],
        'id': '1'
    }

    # Convert the request object to string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to string
    response = json.loads(response)

    # Check the response object
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response['result'] == 'hello'


# Generated at 2022-06-17 15:20:10.732549
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()

    # Create a class to register with the server
    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the class with the server
    server.register(TestClass())

    # Create a request to send to the server
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Send the request to the server
    response = server.handle_request(json.dumps(request))

    # Check the response
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "3"}'

# Generated at 2022-06-17 15:20:16.213705
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:20:24.214030
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Initialize the JsonRpcServer object
    server = JsonRpcServer()

    # Create a class with a method to be called
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Register the class with the JsonRpcServer
    server.register(TestClass())

    # Create the request
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [1, 2],
        'id': 1
    }

    # Call the method
    response = server.handle_request(json.dumps(request))

    # Verify the response
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": 3}'

# Generated at 2022-06-17 15:20:29.865179
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [],
        'id': 1
    })
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    })


# Generated at 2022-06-17 15:20:34.994597
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:41.687586
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.iosxr.iosxr import iosxr_provider_spec
    from ansible.module_utils.network.iosxr.iosxr import iosxr_argument_spec
    from ansible.module_utils.network.iosxr.iosxr import get_config
    from ansible.module_utils.network.iosxr.iosxr import load_config
    from ansible.module_utils.network.iosxr.iosxr import run_commands
    from ansible.module_utils.network.iosxr.iosxr import get_capabilities

# Generated at 2022-06-17 15:20:48.967730
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": [
            "hello"
        ],
        "id": 1
    }

    # Call the method
    response = server.handle_request(request)

    # Check the result
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'



# Generated at 2022-06-17 15:20:53.162760
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': '1'
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:20:58.241722
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '1'
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '1', 'result': '{}', 'result_type': 'pickle'}

# Generated at 2022-06-17 15:21:04.190697
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:16.433148
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:21:22.724159
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:21:31.223236
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.ios.ios import ios_argument_spec
    from ansible.module_utils.network.ios.ios import get_config
    from ansible.module_utils.network.ios.ios import load_config
    from ansible.module_utils.network.ios.ios import run_commands

# Generated at 2022-06-17 15:21:36.980223
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:21:48.649983
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1:
    #   request = {
    #       "jsonrpc": "2.0",
    #       "method": "rpc.test",
    #       "params": [],
    #       "id": 1
    #   }
    #   expected_response = {
    #       "jsonrpc": "2.0",
    #       "error": {
    #           "code": -32600,
    #           "message": "Invalid request"
    #       },
    #       "id": 1
    #   }
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }

# Generated at 2022-06-17 15:21:57.352334
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class Test(object):
        def test(self, arg1, arg2, kwarg1=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1}

        def test_exception(self):
            raise Exception('test exception')

        def test_connection_error(self):
            raise ConnectionError('test connection error')

    server = JsonRpcServer()
    server.register(Test())


# Generated at 2022-06-17 15:22:05.507039
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-17 15:22:13.133770
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:22:18.496595
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": [1, 2, 3]}'


# Generated at 2022-06-17 15:22:23.335435
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 0}'

# Generated at 2022-06-17 15:22:34.196163
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    class TestClass(object):
        def test_method(self):
            return "test_method"

    server.register(TestClass())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "test_method"}'


# Generated at 2022-06-17 15:22:46.928408
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser

# Generated at 2022-06-17 15:22:48.327959
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = server.response(result='test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': 'test'}


# Generated at 2022-06-17 15:22:57.442377
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:23:07.103766
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:23:13.824414
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:23:25.794796
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'

# Generated at 2022-06-17 15:23:35.161251
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:23:41.353269
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:23:49.882175
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return (arg1, arg2, kwarg1, kwarg2)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())

        def test_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'not_found',
                'params': [],
                'id': 1
            })
            response = self.server.handle_request

# Generated at 2022-06-17 15:23:58.208948
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'


# Generated at 2022-06-17 15:24:04.914165
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:24:10.587250
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:24:17.480283
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": null}'
