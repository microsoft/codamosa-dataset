

# Generated at 2022-06-17 15:14:31.091967
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '1'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': '1', 'result': 'test'}


# Generated at 2022-06-17 15:14:34.734055
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:14:41.976886
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

# Generated at 2022-06-17 15:14:51.558753
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}'

    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:15:00.475309
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': None}
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(b'test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response({'test': 'test'})

# Generated at 2022-06-17 15:15:04.257118
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:15:09.614937
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:15:12.868690
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '123'
    response = server.response('test')
    assert response == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'}


# Generated at 2022-06-17 15:15:21.880949
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            "arg1",
            "arg2"
        ],
        "id": "1"
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-17 15:15:25.390812
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 1
    result = {'a': 1, 'b': 2}
    response = server.response(result)
    assert response['id'] == 1
    assert response['result'] == result


# Generated at 2022-06-17 15:15:32.942558
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:43.081493
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:15:48.632590
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:15:51.886085
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:02.186627
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test case 1
    request = '{"jsonrpc": "2.0", "method": "rpc.run", "params": [], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

    # Test case 2
    request = '{"jsonrpc": "2.0", "method": "rpc._run", "params": [], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)

# Generated at 2022-06-17 15:16:04.216965
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrpc = JsonRpcServer()
    error = jrpc.error(code=1, message='test')
    assert error == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:08.408662
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:11.976633
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:16:23.868588
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:16:35.571472
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_diff


# Generated at 2022-06-17 15:16:45.968425
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': '123', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:16:57.169633
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    request = {
        'jsonrpc': '2.0',
        'method': 'error',
        'params': [],
        'id': 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response['id'] == 1
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'

    request = {
        'jsonrpc': '2.0',
        'method': 'header',
        'params': [],
        'id': 1
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

# Generated at 2022-06-17 15:17:04.966448
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:17:13.255210
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:17:17.329866
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:17:24.220947
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.error(code=1, message='test_message')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': 1, 'message': 'test_message'}}


# Generated at 2022-06-17 15:17:35.356439
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff

# Generated at 2022-06-17 15:17:47.301529
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create an instance of JsonRpcServer
    server = JsonRpcServer()

    # Create an instance of JsonRpcTest
    test = JsonRpcTest()

    # Register the instance of JsonRpcTest with the instance of JsonRpcServer
    server.register(test)

    # Create a request to call the method 'test_method' of JsonRpcTest
    request = {
        'jsonrpc': '2.0',
        'id': '1',
        'method': 'test_method',
        'params': [
            [],
            {
                'arg1': 'value1',
                'arg2': 'value2'
            }
        ]
    }

    # Call the method handle_request of JsonRpcServer

# Generated at 2022-06-17 15:17:53.527059
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:18:00.360676
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:18:09.216550
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestCase(unittest.TestCase):
        def test_handle_request(self):
            server = JsonRpcServer()
            server.register(TestClass())


# Generated at 2022-06-17 15:18:16.350713
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:18:22.987347
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["Hello, world!"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "Hello, world!"}'

# Generated at 2022-06-17 15:18:35.965663
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.six import PY3

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.jsonrpc = JsonRpcServer()

        def test_handle_request_with_invalid_request(self):
            request = '{"jsonrpc": "2.0", "method": "rpc.foo", "params": [1,2,3], "id": 1}'
            response = self.jsonrpc.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}')


# Generated at 2022-06-17 15:18:43.857372
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'id': '1'})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:18:53.173298
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a class object
    class TestClass:
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Create an instance of TestClass
    obj = TestClass()

    # Register the object
    server.register(obj)

    # Create a request
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [1, 2],
        "id": 1
    }

    # Convert the request to json
    request = json.dumps(request)

    # Call the method handle_request
    response = server.handle_request(request)

    # Convert the response to json
    response = json.loads(response)

    #

# Generated at 2022-06-17 15:19:05.565925
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a class for testing
    class TestClass(object):
        def __init__(self):
            self.test_value = 'test'

        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Create a TestClass object
    test_obj = TestClass()

    # Register the TestClass object
    server.register(test_obj)

    # Create a request
    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': ['test', 'test'],
        'id': '1'
    }

    # Convert the request to json
    request = json.dumps(request)

    # Call the method handle_request


# Generated at 2022-06-17 15:19:09.142718
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 0}'

# Generated at 2022-06-17 15:19:19.956653
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    import json
    import mock
    from ansible.module_utils.six import PY3

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = {
                'jsonrpc': '2.0',
                'method': 'test_method',
                'params': [],
                'id': 1
            }
            request = json.dumps(request)
            response = self.server.handle_request(request)
            response = json.loads(response)
            self.assertEqual(response['jsonrpc'], '2.0')


# Generated at 2022-06-17 15:19:30.867396
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [["show version"]],
        "id": "1"
    }

    # Convert the request object to JSON string
    request_str = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request_str)

    # Convert the response to JSON object
    response_obj = json.loads(response)

    # Check the response
    assert response_obj["jsonrpc"] == "2.0"
    assert response_obj["id"] == "1"

# Generated at 2022-06-17 15:19:46.641282
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a test class
    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return {'jsonrpc': '2.0', 'id': json_rpc_server._identifier, 'result': 'test_method'}

    # Register the test class with the JsonRpcServer object
    json_rpc_server.register(TestClass())

    # Create a test request
    test_request = {'jsonrpc': '2.0', 'id': '1', 'method': 'test_method', 'params': [[], {}]}

    # Call the handle_request method of the JsonRpcServer object
    test_response = json_rpc_server.handle_request

# Generated at 2022-06-17 15:19:52.223664
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:19:57.275247
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # create a JsonRpcServer object
    server = JsonRpcServer()

    # create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }

    # create a response object
    response = {
        "jsonrpc": "2.0",
        "result": None,
        "id": 1
    }

    # test the handle_request method
    assert server.handle_request(request) == response

# Generated at 2022-06-17 15:20:02.316855
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:07.829947
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1, 2, 3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:20:18.188381
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return 'test_method_result'

        def test_method_with_exception(self, arg1, arg2, kwarg1=None, kwarg2=None):
            raise Exception('test_method_with_exception')

        def test_method_with_connection_error(self, arg1, arg2, kwarg1=None, kwarg2=None):
            raise ConnectionError('test_method_with_connection_error')


# Generated at 2022-06-17 15:20:29.973731
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            [],
            {}
        ],
        "id": 1
    }

    # Convert the request object to string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to string
    response = json.loads(response)

    # Check if the response object is equal to the expected object

# Generated at 2022-06-17 15:20:40.263333
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfConnectionError
    from ansible.module_utils.network.common.netconf import NetconfConnectionFailure
    from ansible.module_utils.network.common.netconf import NetconfConnectionTimeout
    from ansible.module_utils.network.common.netconf import NetconfConnectionUnknownHostError
    from ansible.module_utils.network.common.netconf import NetconfConnectionAuthenticationError

# Generated at 2022-06-17 15:20:47.231686
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:52.106161
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:21:03.439204
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == "Method not found"


# Generated at 2022-06-17 15:21:14.522449
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:21:24.754972
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser

# Generated at 2022-06-17 15:21:32.444236
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:45.289563
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:21:51.339916
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:01.663774
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:22:11.114647
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import mock
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.json_rpc_server = JsonRpcServer()
            self.json_rpc_server.register(Connection())
            self.json_rpc_server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.d

# Generated at 2022-06-17 15:22:15.885095
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

# Generated at 2022-06-17 15:22:20.113759
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

# Generated at 2022-06-17 15:22:30.801436
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = json.loads(server.handle_request(request))
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-17 15:22:42.652376
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import NetworkConfigDump
    from ansible.module_utils.network.common.parsing import NetworkConfigDumpError

# Generated at 2022-06-17 15:22:52.950092
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:23:00.491747
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:23:04.368095
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = {
        "jsonrpc": "2.0",
        "method": "error",
        "params": [1, 2, 3],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32603, "message": "Internal error"}}'

# Generated at 2022-06-17 15:23:14.750969
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run",
        "params": [
            [
                "show version"
            ],
            {
                "host": "localhost",
                "port": 22,
                "username": "admin",
                "password": "admin",
                "timeout": 10,
                "ssh_keyfile": None,
                "become": False,
                "become_method": "enable",
                "become_user": None,
                "become_pass": None,
                "transport": "cli",
                "provider": None
            }
        ],
        "id": "1"
    }
    # Convert the request

# Generated at 2022-06-17 15:23:22.938466
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import unittest
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())

        def test_handle_request(self):
            request = '{"jsonrpc": "2.0", "method": "test_method", "params": [1, 2], "id": 1}'

# Generated at 2022-06-17 15:23:35.023171
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class Test(object):
        def test(self):
            return 'test'
    server.register(Test())
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "test", "id": 1}'

    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})

# Generated at 2022-06-17 15:23:40.703256
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:23:46.523329
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:24:01.844663
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonRpcServer
    jsonrpc_server = JsonRpcServer()

    # Create a new instance of JsonR

# Generated at 2022-06-17 15:24:07.678601
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:24:13.942127
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:24:18.916043
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'