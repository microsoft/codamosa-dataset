

# Generated at 2022-06-17 15:14:42.827202
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': None}
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response(b'test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}
    result = server.response({'test': 'test'})

# Generated at 2022-06-17 15:14:48.204735
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:14:53.664266
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': '123', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:02.033118
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'not_found',
                'params': [],
                'id': 1
            })
            response = self.server.handle_request(request)

# Generated at 2022-06-17 15:15:06.222584
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:15:09.885466
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:15:14.301808
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = server.response('test_result')
    assert result == {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:15:20.741805
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:15:25.754561
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    result = server.error(code=1, message='test_message')
    assert result == {'jsonrpc': '2.0', 'id': 'test_identifier', 'error': {'code': 1, 'message': 'test_message'}}


# Generated at 2022-06-17 15:15:30.759621
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = 'test_identifier'
    response = server.error(code=1, message='test_message', data='test_data')
    assert response == {'jsonrpc': '2.0', 'id': 'test_identifier', 'error': {'code': 1, 'message': 'test_message', 'data': 'test_data'}}


# Generated at 2022-06-17 15:15:38.823215
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:15:42.132434
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:15:47.608883
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'

# Generated at 2022-06-17 15:15:51.328187
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1

# Generated at 2022-06-17 15:15:59.509232
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {
        "jsonrpc": "2.0",
        "error": {
            "code": -32601,
            "message": "Method not found"
        },
        "id": 1
    }


# Generated at 2022-06-17 15:16:04.834225
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:16:08.989369
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_id'
    result = {'test_key': 'test_value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': result}


# Generated at 2022-06-17 15:16:13.765529
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'
    assert response['id'] == 1


# Generated at 2022-06-17 15:16:22.558521
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:16:30.295849
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": [
            "hello world"
        ],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "result": "hello world"}'


# Generated at 2022-06-17 15:16:42.012263
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': result}


# Generated at 2022-06-17 15:16:50.401079
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:16:58.305101
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    class Test(object):
        def test(self):
            return 'test'

    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "result": "test", "id": 1}'

    request["method"] = "test_error"
    response = server.handle

# Generated at 2022-06-17 15:17:02.405291
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_identifier')
    response = server.response('test_result')
    assert response == {'jsonrpc': '2.0', 'id': 'test_identifier', 'result': 'test_result'}


# Generated at 2022-06-17 15:17:06.661518
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfConnectionError
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorCode
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorMessage
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorData
    from ansible.module_utils.network.common.netconf import NetconfConnectionErrorCode

# Generated at 2022-06-17 15:17:18.310680
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Test with invalid request
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'

    # Test with valid request
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    server = JsonRpcServer()
    response = server.handle_request(request)

# Generated at 2022-06-17 15:17:26.925642
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass:
        def __init__(self):
            self.test_value = 'test'

        def test_method(self, *args, **kwargs):
            return self.test_value

    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            self.register(TestClass())

    class TestJsonRpcServerTestCase(unittest.TestCase):
        def setUp(self):
            self.server = TestJsonRpcServer()


# Generated at 2022-06-17 15:17:32.471991
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 1
    result = server.response()
    assert result == {'jsonrpc': '2.0', 'id': 1, 'result': None}
    result = server.response(result='test')
    assert result == {'jsonrpc': '2.0', 'id': 1, 'result': 'test'}
    result = server.response(result=b'test')
    assert result == {'jsonrpc': '2.0', 'id': 1, 'result': 'test'}
    result = server.response(result=1)
    assert result == {'jsonrpc': '2.0', 'id': 1, 'result': 'I1\n.', 'result_type': 'pickle'}


# Generated at 2022-06-17 15:17:41.450363
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:17:47.157752
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'result': '{}'}
    delattr(server, '_identifier')


# Generated at 2022-06-17 15:17:55.181369
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "foo", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:05.569966
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())

        def test_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'not_found', 'id': 1})
            response = self.server.handle_request(request)
            response = json.loads(response)
            self.assertEqual(response['jsonrpc'], '2.0')

# Generated at 2022-06-17 15:18:15.043697
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    import json
    import sys
    import os
    import inspect
    import shutil
    import tempfile
    import ansible.module_utils.connection
    import ansible.module_utils.basic
    import ansible.module_utils.network.nxos.nxos
    import ansible.module_utils.network.nxos.nxos_config
    import ansible.module_utils.network.nxos.nxos_file_copy
    import ansible.module_utils.network.nxos.nxos_logging
    import ansible.module_utils.network.nxos.nxos_system
    import ansible.module_utils.network.nxos.nxos_user
    import ansible.module_utils.network.nxos.nxos_

# Generated at 2022-06-17 15:18:22.333172
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_JsonRpcServer_response'
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test_JsonRpcServer_response', 'result': {'key': 'value'}}


# Generated at 2022-06-17 15:18:28.527371
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:18:37.636613
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_string = "test_string"

        def test_method(self, arg1, arg2):
            return arg1 + arg2

        def test_method_with_kwargs(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1 + arg2 + kwarg1 + kwarg2

        def test_method_with_pickle(self):
            return self.test_string

        def test_method_with_exception(self):
            raise Exception("test_method_with_exception")


# Generated at 2022-06-17 15:18:49.193709
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfConnectionError
    from ansible.module_utils.network.common.netconf import NetconfConnectionTimeout
    from ansible.module_utils.network.common.netconf import NetconfConnectionAuthenticationError
    from ansible.module_utils.network.common.netconf import NetconfConnectionUnknownHostError
    from ansible.module_utils.network.common.netconf import NetconfConnectionSSHError
    from ansible.module_utils.network.common.netconf import NetconfConnectionSSHUnknownHostError

# Generated at 2022-06-17 15:18:55.596300
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": "1"}'


# Generated at 2022-06-17 15:19:03.575634
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:07.759084
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:19:17.635382
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)

    # Test for method not found
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'not_found', 'params': []}
    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32601, 'message': 'Method not found'}}

    # Test for invalid request
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'rpc.not_found', 'params': []}
    response = server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:19:26.043776
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:32.792041
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:41.511020
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:19:43.475205
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:19:49.758414
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:57.863457
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetconfConnection
    from ansible.module_utils.network.common.netconf import NetconfConnectionError
    from ansible.module_utils.network.common.netconf import NetconfConnectionTimeout
    from ansible.module_utils.network.common.netconf import NetconfConnectionAuthenticationError
    from ansible.module_utils.network.common.netconf import NetconfConnection

# Generated at 2022-06-17 15:20:06.203035
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()

        def test_handle_request(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'id': '1'})
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestJsonRpcServer)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Unit

# Generated at 2022-06-17 15:20:13.954270
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser

# Generated at 2022-06-17 15:20:19.418143
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:20:26.517403
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 0}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 0, "result": null}'


# Generated at 2022-06-17 15:20:30.992883
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:20:40.932814
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six import binary_type, text_type

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return args, kwargs

        def test_method_with_error(self, *args, **kwargs):
            raise Exception('test exception')

        def test_method_with_connection_error(self, *args, **kwargs):
            raise ConnectionError('test connection error')

        def test_method_with_connection_error_and_code(self, *args, **kwargs):
            raise ConnectionError('test connection error', code=400)


# Generated at 2022-06-17 15:20:46.813871
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:20:53.947190
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "invalid_request", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'
    request = '{"jsonrpc": "2.0", "method": "handle_request", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:21:05.514176
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:13.329958
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'

# Generated at 2022-06-17 15:21:20.053822
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:21:30.662901
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import pickle
    import traceback
    import ansible.module_utils.connection
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.cPickle
    import ansible.module_utils.network.common.utils
    import ansible.module_utils.network.common.config
    import ansible.module_utils.network.common.connection
    import ansible.module_utils.network.ios.ios
    import ansible.module_utils.network.ios.ios_config
    import ansible.module_utils.network.ios.ios_template

# Generated at 2022-06-17 15:21:38.271187
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:21:53.708637
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

    class Test(object):
        def rpc_test(self):
            return "test"

    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "test"}'

# Generated at 2022-06-17 15:21:58.447184
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'


# Generated at 2022-06-17 15:22:02.695196
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = {'key': 'value'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 1, 'result': result}


# Generated at 2022-06-17 15:22:08.217930
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:22:15.172157
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, *args, **kwargs):
            return {'args': args, 'kwargs': kwargs}

    server = JsonRpcServer()
    server.register(TestClass())

    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [[1, 2, 3], {'a': 'b'}],
        'id': 1
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'

# Generated at 2022-06-17 15:22:19.795769
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello", "world"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello world", "id": 1}'

# Generated at 2022-06-17 15:22:26.621463
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    import mock

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'method': 'test_method', 'params': [], 'id': 1})
            response = self.server.handle_request(request)
            response = json.loads(response)
            self.assertEqual(response['error']['code'], -32601)

        def test_handle_request_invalid_request(self):
            request = json.dumps({'method': 'rpc.test_method', 'params': [], 'id': 1})

# Generated at 2022-06-17 15:22:34.026397
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    sys.path.append('../')
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.iosxr.iosxr import iosxr_provider_spec
    from ansible.module_utils.network.iosxr.iosxr import get_config
    from ansible.module_utils.network.iosxr.iosxr import load_config
    from ansible.module_utils.network.iosxr.iosxr import run_commands
    from ansible.module_utils.network.iosxr.iosxr import get_capabilities
    from ansible.module_utils.network.iosxr.iosxr import get_defaults_

# Generated at 2022-06-17 15:22:41.088725
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:22:47.029313
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:23:08.609431
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    import json
    import tempfile
    import shutil

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'echo',
                'params': ['hello'],
                'id': '1'
            })
            response = self.server.handle_request(request)

# Generated at 2022-06-17 15:23:21.291222
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.ios.ios import ios_provider_spec
    from ansible.module_utils.network.ios.ios import ios_argument_spec
    from ansible.module_utils.network.ios.ios import ios_load_config
    from ansible.module_utils.network.ios.ios import ios_get_config
    from ansible.module_utils.network.ios.ios import ios_get_capabilities
    from ansible.module_utils.network.ios.ios import ios_get_interfaces
    from ansible.module_utils.network.ios.ios import ios_get_lldp_neighbors

# Generated at 2022-06-17 15:23:24.451500
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': result}


# Generated at 2022-06-17 15:23:34.578340
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:23:40.855789
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:23:49.548357
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import json
    import sys
    from ansible.module_utils.six import PY3

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request(self):
            request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
            response = self.server.handle_request(request)
            self.assertEqual(response, '{"jsonrpc": "2.0", "result": "hello", "id": 1}')


# Generated at 2022-06-17 15:23:55.344510
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "Hello, world!", "id": 1}'

# Generated at 2022-06-17 15:24:00.632037
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'

# Generated at 2022-06-17 15:24:10.952379
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:24:22.138590
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {'jsonrpc': '2.0', 'method': '_test', 'params': [], 'id': 1}
    # Convert the request object to a string
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to a string
    response = json.dumps(response)
    # Check if the response is equal to the expected response
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'
