

# Generated at 2022-06-17 15:14:32.362735
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '123')
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': '123', 'result': 'test'}


# Generated at 2022-06-17 15:14:40.146183
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test')
    result = server.error(code=1, message='test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-17 15:14:48.421613
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.iosxr.iosxr import iosxr_argument_spec
    from ansible.module_utils.network.iosxr.iosxr import get_config
    from ansible.module_utils.network.iosxr.iosxr import load_config
    from ansible.module_utils.network.iosxr.iosxr import run_commands

# Generated at 2022-06-17 15:14:51.200077
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': 'test', 'result': 'test'}


# Generated at 2022-06-17 15:14:57.416857
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    assert server.error(code=1, message='test') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test'}}
    assert server.error(code=1, message='test', data='data') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'test', 'data': 'data'}}


# Generated at 2022-06-17 15:15:03.808224
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    assert server.error(1, 'test_message', 'test_data') == {
        'jsonrpc': '2.0',
        'id': 'test_id',
        'error': {
            'code': 1,
            'message': 'test_message',
            'data': 'test_data'
        }
    }


# Generated at 2022-06-17 15:15:08.044212
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test'
    result = {'test': 'test'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': 'test', 'result': {'test': 'test'}}


# Generated at 2022-06-17 15:15:11.401561
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {'foo': 'bar'}
    response = server.response(result)
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == result
    assert response['id'] == None


# Generated at 2022-06-17 15:15:21.932252
# Unit test for method response of class JsonRpcServer

# Generated at 2022-06-17 15:15:31.512693
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2}

    server = JsonRpcServer()
    server.register(TestClass())

    # Test with valid request

# Generated at 2022-06-17 15:15:49.143958
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    }

    # Convert the request object to JSON string
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)

    # Convert the response object to JSON string
    response = json.loads(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:15:55.608243
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [
            "arg1",
            "arg2"
        ],
        "id": 1
    }

    # Convert the request object to a string
    request = json.dumps(request)

    # Handle the request
    response = server.handle_request(request)

    # Convert the response object to a string
    response = json.dumps(response)

    # Check if the response is correct
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:16:04.271901
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jrs = JsonRpcServer()
    jrs.register(jrs)
    request = json.dumps({'jsonrpc': '2.0', 'method': 'response', 'params': [[], {}], 'id': '1'})
    response = jrs.handle_request(request)
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': '1', 'result': None}
    request = json.dumps({'jsonrpc': '2.0', 'method': 'error', 'params': [[], {}], 'id': '1'})
    response = jrs.handle_request(request)

# Generated at 2022-06-17 15:16:12.324241
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestClass(object):
        def __init__(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_method(self, *args, **kwargs):
            return {'jsonrpc': '2.0', 'id': self.server._identifier, 'result': 'test_method called'}

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.test_obj = TestClass()

        def test_handle_request(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'test_method', 'id': '1'})
            response = self.test_obj.server.handle_request(request)
           

# Generated at 2022-06-17 15:16:23.868470
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "get_config",
        "params": [],
        "id": 1
    }

    # Convert the request object to a string
    request = json.dumps(request)

    # Call the method handle_request of the JsonRpcServer object
    response = server.handle_request(request)

    # Convert the response to a dictionary
    response = json.loads(response)

    # Assert that the response is a dictionary
    assert isinstance(response, dict)

    # Assert that the response contains the key 'jsonrpc'
    assert 'jsonrpc' in response

    # Assert that the response contains the key 'id

# Generated at 2022-06-17 15:16:35.571000
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)

    # Test for method not found
    request = {'jsonrpc': '2.0', 'method': 'test_method', 'id': '1'}
    response = json_rpc_server.handle_request(json.dumps(request))
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32601, 'message': 'Method not found'}}

    # Test for invalid request
    request = {'jsonrpc': '2.0', 'method': '_handle_request', 'id': '1'}
    response = json_rpc_server.handle_request(json.dumps(request))

# Generated at 2022-06-17 15:16:40.025141
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': '1'})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:16:47.269314
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    request = '{"jsonrpc": "2.0", "method": "invalid_request", "params": [1,2,3,4,5], "id": 1}'
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}'

# Generated at 2022-06-17 15:16:57.189820
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def test_handle_request_method_not_found(self):
            request = json.dumps({'jsonrpc': '2.0', 'method': 'test_method', 'id': 1})
            response = json.loads(self.server.handle_request(request))
            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], 1)
            self.assertEqual(response['error']['code'], -32601)

# Generated at 2022-06-17 15:17:03.189595
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        "jsonrpc": "2.0",
        "method": "test_method",
        "params": [],
        "id": 1
    })
    response = server.handle_request(request)
    assert response == json.dumps({
        "jsonrpc": "2.0",
        "error": {
            "code": -32601,
            "message": "Method not found",
            "data": None
        },
        "id": 1
    })



# Generated at 2022-06-17 15:17:18.112545
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-17 15:17:26.732989
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()
    # Create a request object
    request = {'method': 'test_method', 'params': [[], {}], 'id': 'test_id'}
    # Convert the request object to json
    request = json.dumps(request)
    # Call the method handle_request of class JsonRpcServer
    response = server.handle_request(request)
    # Convert the response object to json
    response = json.loads(response)
    # Check if the response object is equal to the expected object
    assert response == {'jsonrpc': '2.0', 'id': 'test_id', 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:17:36.802842
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkConfigParseError

# Generated at 2022-06-17 15:17:44.275690
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:17:56.274874
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer

    class TestClass(object):
        def __init__(self):
            self.connection = Connection()

        def test_method(self, *args, **kwargs):
            return self.connection.get_prompt()

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())


# Generated at 2022-06-17 15:18:02.339869
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": "1"
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": "1", "result": "hello world"}'

# Generated at 2022-06-17 15:18:07.906967
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    class Test(object):
        def test(self, arg1, arg2):
            return arg1 + arg2

    server.register(Test())

    request = {
        'jsonrpc': '2.0',
        'id': '1',
        'method': 'test',
        'params': [1, 2]
    }

    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response['result'] == 3


# Generated at 2022-06-17 15:18:15.708530
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:18:24.386754
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    request = json.dumps({'jsonrpc': '2.0', 'id': '1', 'method': 'error', 'params': [[], {}]})
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:18:31.087894
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:37.928596
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:18:49.445877
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    import unittest.mock

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()

        def test_handle_request_method_not_found(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test',
                'params': [],
                'id': '1'
            })

            response = self.server.handle_request(request)
            response = json.loads(response)

            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], '1')

# Generated at 2022-06-17 15:18:55.125793
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1}
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:19:02.217290
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:19:09.773052
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:19:19.980864
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "rpc.test",
        "params": [],
        "id": 1
    }

    # Convert the request object to a JSON string
    request = json.dumps(request)

    # Call the method handle_request of the JsonRpcServer object
    response = server.handle_request(request)

    # Convert the response to a JSON object
    response = json.loads(response)

    # Check if the response is correct

# Generated at 2022-06-17 15:19:22.870412
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello"}'

# Generated at 2022-06-17 15:19:28.119058
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:19:40.533331
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import json
    import traceback
    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.urls
    import ansible.module_utils.network.nxos.nxos
    import ansible.module_utils.network.nxos.nxos_config
    import ansible.module_

# Generated at 2022-06-17 15:19:47.490681
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:19:57.892342
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    server = JsonRpcServer()
    server.register(module)

    request = '{"jsonrpc": "2.0", "method": "ping", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "pong", "id": 1}'

    request = '{"jsonrpc": "2.0", "method": "fail", "params": [], "id": 1}'
    response = server.handle_request(request)

# Generated at 2022-06-17 15:20:06.350091
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

# Generated at 2022-06-17 15:20:14.023161
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return 'test_method'

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.server.register(TestClass())


# Generated at 2022-06-17 15:20:22.635854
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()

        def test_handle_request(self):
            request = json.dumps({
                'jsonrpc': '2.0',
                'method': 'test_method',
                'params': [],
                'id': '1'
            })

            response = self.server.handle_request(request)
            response = json.loads(response)

            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], '1')
            self.assertEqual(response['error']['code'], -32601)

# Generated at 2022-06-17 15:20:30.992814
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:20:36.460381
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {'jsonrpc': '2.0', 'id': '1', 'method': 'test', 'params': [[], {}]}
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-17 15:20:42.520479
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:20:51.918564
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.connection import ConnectionError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import NetworkResourceConfig
    from ansible.module_utils.network.common.parsing import NetworkConfigDiff

# Generated at 2022-06-17 15:21:02.652126
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest
    from ansible.module_utils.six.moves import cPickle

    class TestClass(object):
        def __init__(self):
            self.test_value = 'test_value'

        def test_method(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return {'arg1': arg1, 'arg2': arg2, 'kwarg1': kwarg1, 'kwarg2': kwarg2, 'test_value': self.test_value}

        def test_method_exception(self):
            raise Exception('test_method_exception')

        def test_method_connection_error(self):
            raise ConnectionError('test_method_connection_error')


# Generated at 2022-06-17 15:21:09.986939
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({
        'jsonrpc': '2.0',
        'method': 'test',
        'params': [],
        'id': 1
    })
    response = server.handle_request(request)
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }

# Generated at 2022-06-17 15:21:22.460178
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'


# Generated at 2022-06-17 15:21:32.015184
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)

    # Test for method not found
    request = '{"jsonrpc": "2.0", "method": "not_found", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'

    # Test for invalid request
    request = '{"jsonrpc": "2.0", "method": "rpc.not_found", "params": [], "id": 1}'
    response = json_rpc_server.handle_request(request)

# Generated at 2022-06-17 15:21:37.534936
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:21:48.649948
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test",
        "params": [],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}, "id": 1}'
    class Test(object):
        def test(self):
            return "test"
    server.register(Test())
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "result": "test", "id": 1}'


# Generated at 2022-06-17 15:21:54.331505
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["Hello, world!"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "Hello, world!"}'


# Generated at 2022-06-17 15:22:00.367818
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "response", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "{\\"jsonrpc\\": \\"2.0\\", \\"id\\": 1}"}'

# Generated at 2022-06-17 15:22:09.152234
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import NetworkInclude
    from ansible.module_utils.network.common.parsing import NetworkIncludeError
    from ansible.module_utils.network.common.parsing import NetworkIncludeConditionalError

# Generated at 2022-06-17 15:22:12.889342
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": "hello", "id": 1}'


# Generated at 2022-06-17 15:22:24.538775
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.six import PY3

    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    server = JsonRpcServer()
    server.register(TestClass())

    request = {
        'jsonrpc': '2.0',
        'method': 'test_method',
        'params': [1, 2],
        'id': 1
    }

    response = server.handle_request(json.dumps(request))
    assert json.loads(response) == {
        'jsonrpc': '2.0',
        'id': 1,
        'result': 3
    }


# Generated at 2022-06-17 15:22:26.700062
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "hello", "params": [42, 23], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:22:46.542047
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'

    request = {
        "jsonrpc": "2.0",
        "method": "echo",
        "params": ["hello world"],
        "id": 1
    }
    response = server.handle_request(json.dumps(request))
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": "hello world"}'


# Generated at 2022-06-17 15:22:51.778302
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-17 15:23:00.359821
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import sys
    import os
    import pytest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from lib.connection import Connection
    from lib.utils import to_list
    from lib.utils import to_text
    from lib.utils import to_bytes
    from lib.utils import to_native
    from lib.utils import to_bytes
    from lib.utils import to_text
    from lib.utils import to_native
    from lib.utils import to_bytes
    from lib.utils import to_text
    from lib.utils import to_native
    from lib.utils import to_bytes
    from lib.utils import to_text
    from lib.utils import to_native

# Generated at 2022-06-17 15:23:09.946420
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import sys
    import os
    import json
    import traceback
    import tempfile
    import shutil
    import copy
    import time
    import random
    import string
    import subprocess
    import socket
    import threading
    import select
    import errno
    import signal
    import re
    import copy
    import logging
    import logging.handlers
    import tempfile
    import shutil
    import copy
    import time
    import random
    import string
    import subprocess
    import socket
    import threading
    import select
    import errno
    import signal
    import re
    import copy
    import logging
    import logging.handlers
    import tempfile
    import shutil
    import copy
    import time
    import random
    import string
    import subprocess
   

# Generated at 2022-06-17 15:23:17.838780
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    server = JsonRpcServer()

    # Create a class to register with the JsonRpcServer object
    class TestClass(object):
        def test_method(self, arg1, arg2):
            return arg1 + arg2

    # Create a TestClass object and register it with the JsonRpcServer object
    test_obj = TestClass()
    server.register(test_obj)

    # Create a valid JSON-RPC request
    request = {'jsonrpc': '2.0', 'method': 'test_method', 'params': [1, 2], 'id': 1}
    request_str = json.dumps(request)

    # Call the handle_request method of the JsonRpcServer object
    response = server.handle_request(request_str)

    #

# Generated at 2022-06-17 15:23:29.572843
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import sys
    import unittest
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils._text import to_text

    class TestClass(object):
        def __init__(self):
            self.test_attr = 'test_attr'

        def test_method(self, *args, **kwargs):
            return 'test_method'

        def test_method_with_result(self, *args, **kwargs):
            return {'jsonrpc': '2.0', 'id': 'test_id', 'result': 'test_result'}


# Generated at 2022-06-17 15:23:37.056017
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    import unittest

    class TestJsonRpcServer(unittest.TestCase):
        def setUp(self):
            self.jsonrpc = JsonRpcServer()

        def test_handle_request_method_not_found(self):
            request = {'jsonrpc': '2.0', 'id': '1', 'method': 'test', 'params': []}
            response = self.jsonrpc.handle_request(json.dumps(request))
            response = json.loads(response)
            self.assertEqual(response['jsonrpc'], '2.0')
            self.assertEqual(response['id'], '1')
            self.assertEqual(response['error']['code'], -32601)

# Generated at 2022-06-17 15:23:47.399162
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Create a request object
    request = {
        "jsonrpc": "2.0",
        "method": "run_command",
        "params": [
            [
                "show version"
            ],
            {
                "encoding": "text"
            }
        ],
        "id": 1
    }

    # Convert the request object to json
    request = json.dumps(request)

    # Call the method handle_request of class JsonRpcServer
    response = json_rpc_server.handle_request(request)

    # Convert the response to json
    response = json.loads(response)

    # Check if the response is a valid json
    assert isinstance(response, dict)

    #

# Generated at 2022-06-17 15:23:59.329407
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-17 15:24:05.310726
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = json.dumps({'jsonrpc': '2.0', 'method': 'test', 'params': [], 'id': 1})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-17 15:24:24.386186
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    server.register(server)
    request = '{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32603, "message": "Internal error"}, "id": 1}'