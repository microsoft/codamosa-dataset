

# Generated at 2022-06-21 08:35:15.987377
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = '1234'
    result = jsonrpc_server.header()
    assert result == {'jsonrpc': '2.0', 'id': '1234'}

# Unittest for method response of class JsonRpcServer

# Generated at 2022-06-21 08:35:26.981702
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    ba = JsonRpcServer()
    assert ba.response('Hello') == {'jsonrpc': '2.0', 'id': None, 'result': u'Hello'}
    assert ba.response({'test':'dict'}) == {'jsonrpc': '2.0', 'id': None, 'result': u'cPickle.dumps({"test": "dict"}, protocol=0)', 'result_type': u'pickle'}
    assert ba.response('\u00e4') == {'jsonrpc': '2.0', 'id': None, 'result': u'\xe4'}
    assert ba.response('\u00e4'.encode('utf-8')) == {'jsonrpc': '2.0', 'id': None, 'result': u'\xe4'}

# Generated at 2022-06-21 08:35:31.362361
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.internal_error()
    assert result['id'] == None
    assert result['error']['code'] == -32603



# Generated at 2022-06-21 08:35:39.194055
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server,'_identifier',1) 
    assert server.response() == {'jsonrpc': '2.0', 'id': 1, 'result': ''}
    setattr(server,'_identifier',2) 
    assert server.response('test') == {'jsonrpc': '2.0', 'id': 2, 'result': 'test'}
    assert server.error(1,'test') == {'jsonrpc': '2.0', 'id': 2, 'error': {'code': 1, 'message': 'test'}}


# Generated at 2022-06-21 08:35:41.473846
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    object = JsonRpcServer()
    assert isinstance(object, JsonRpcServer)
    assert isinstance(object._objects, set)
    assert object._objects == set()


# Generated at 2022-06-21 08:35:45.728129
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()
    assert -32700 == result['error']['code']
    assert 'Parse error' == result['error']['message']


# Generated at 2022-06-21 08:35:47.122818
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server


# Generated at 2022-06-21 08:35:54.026629
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import Mock
    request = '{"id": "1", "method": "wrong_method", "params": []}'
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.handle_request(request)
    assert jsonRpcServer.method_not_found.call_count == 1


# Generated at 2022-06-21 08:35:57.527545
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc = JsonRpcServer()
    jsonrpc._identifier = '1'
    assert jsonrpc.header() == {'jsonrpc': '2.0', 'id': '1'}


# Generated at 2022-06-21 08:35:59.565476
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    obj = JsonRpcServer()
    # method invoke not implemented yet
    pass


# Generated at 2022-06-21 08:36:13.690777
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    # Test for id not being set
    response = obj.response(result="Here's some result from the method call")
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == "Here's some result from the method call"
    assert response['id'] == 'None'
    # Test for id being set
    obj._identifier = '1122'
    response = obj.response(result="Here's some result from the method call")
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == "Here's some result from the method call"
    assert response['id'] == '1122'
    # Test for result_type being set
    response = obj.response(result=dict(name='Peter'))

# Generated at 2022-06-21 08:36:17.486234
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    j._identifier = 'ansible'
    result = j.header()
    assert result['jsonrpc'] == '2.0' and result['id'] == 'ansible'


# Generated at 2022-06-21 08:36:26.793981
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    response = server.response()

    assert response['id'] == None
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == None

    response = server.response('hello')
    assert response['result'] == 'hello'
    assert response["result_type"] == None

    response = server.response(b'hello')
    assert response['result'] == 'hello'
    assert response["result_type"] == None

    data = [{'key': 'value'}]
    response = server.response(data)
    assert response['result'] == data
    assert response["result_type"] == None

    data = [{'key': 'value'}]

# Generated at 2022-06-21 08:36:34.329037
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
	
	def test_function():
		print('RPC test function')
		pass

	jsonrpc = JsonRpcServer()
	jsonrpc.register(test_function)
	error = jsonrpc.method_not_found()
	assert error['error']['code'] == -32601
	assert error['error']['message'] == 'Method not found'
	

# Generated at 2022-06-21 08:36:45.174307
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    class Test(object):
        def test(self, a):
            return a

    server = JsonRpcServer()

    server.register(Test())

    request = b'{"jsonrpc": "2.0", "method": "test", "params": [1], "id": 1}'
    result = server.handle_request(request)

    assert result == '{"jsonrpc": "2.0", "id": 1, "result": "1"}'

    request = b'{"jsonrpc": "2.0", "method": "test", "params": 1, "id": 1}'
    result = server.handle_request(request)

    assert result == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params"}}'

    request

# Generated at 2022-06-21 08:36:51.085426
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    rpc_server = JsonRpcServer()
    rpc_server._identifier = '23'
    response = rpc_server.internal_error('some error')
    result = {'jsonrpc': '2.0', 'id': '23', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'some error'}}
    assert(result == response)



# Generated at 2022-06-21 08:37:01.240900
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "rpc.ping",
        "params": []
    }
    # _identifier should be None, because _identifier should be set only in handle_request method
    # and it should be removed only when the response is generated.
    assert JsonRpcServer()._identifier is None
    # The error should be returned
    response = JsonRpcServer().handle_request(json.dumps(request))
    assert JsonRpcServer()._identifier is None
    assert response == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": 1}'



# Generated at 2022-06-21 08:37:11.102675
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Test(object):
        pass
    test = Test()
    test.run = lambda *args, **kwargs: {'jsonrpc': '2.0', 'result': args, 'id': 1}
    server = JsonRpcServer()
    server.register(test)
    request = json.dumps({'jsonrpc': '2.0', 'method': 'run', 'params': [1, 2, 3], 'id': 1})
    response = server.handle_request(request)
    assert response == json.dumps({'jsonrpc': '2.0', 'result': [1, 2, 3], 'id': 1})

# Generated at 2022-06-21 08:37:15.755490
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)
    server._identifier = 'identifier'
    result = server.header()
    assert isinstance(result, dict)
    assert len(result) == 2
    assert 'jsonrpc' in result
    assert result['jsonrpc'] == '2.0'
    assert 'id' in result
    assert result['id'] == 'identifier'


# Generated at 2022-06-21 08:37:18.643825
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None
    assert isinstance(server, JsonRpcServer)



# Generated at 2022-06-21 08:37:25.641532
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    result = json_rpc_server.invalid_params()
    assert result.get('error').get('code') == -32602
    assert result.get('error').get('message') == 'Invalid params'


# Generated at 2022-06-21 08:37:35.429083
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    """
    Test for register of class JsonRpcServer
    """
    json_rpc_server = JsonRpcServer()
    module_test = ModuleTest()
    camel_case_test = CamelCaseTest()
    json_rpc_server.register(module_test)
    json_rpc_server.register(camel_case_test)

    request = {"id": 1, "method": "send_config", "params": [[]]}
    request_str = json.dumps(request)
    response = json_rpc_server.handle_request(request_str)

    assert(response == '{"jsonrpc": "2.0", "id": 1, "result": "send_config"}')

    request = {"id": 2, "method": "send_command", "params": [[]]}
    request_

# Generated at 2022-06-21 08:37:36.989972
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer() != None


# Generated at 2022-06-21 08:37:39.656769
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    test_object = JsonRpcServer()
    result = test_object.parse_error()
    assert result["error"]["code"] == -32700


# Generated at 2022-06-21 08:37:47.501899
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    try:
        server._objects
    except AttributeError:
        print('Test Failed')
        return

    if len(server._objects) != 0:
        print('Test Failed')
        return

    class TestClass(object):
        pass
    server.register(TestClass)

    if len(server._objects) != 1:
        print('Test Failed')
        return

    TestClass2 = TestClass()
    TestClass2.test = TestClass2.test

    class TestClass3(object):
        def test(self):
            pass
    TestClass3.test = TestClass3.test
    server.register(TestClass3)
    if len(server._objects) != 3:
        print('Test Failed')
        return
    print('Test Passed')


# Generated at 2022-06-21 08:37:50.509680
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    pass


if __name__ == '__main__':
    test_JsonRpcServer()

# Generated at 2022-06-21 08:37:56.397996
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():

    server = JsonRpcServer()
    request = {
        'method': 'test_method',
        'params': [[]],
        'id': 'test_request'
    }
    response = server.handle_request(request)
    assert 'Parse error' in response
    assert 'id' in response
    assert 'jsonrpc' in response


# Generated at 2022-06-21 08:38:03.499225
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    class TestModule:
        def test_method(self):
            return 'Test Successful'

    server = JsonRpcServer()
    server.register(module)
    server.register(TestModule())

    req = '{"jsonrpc": "2.0", "method": "test_method", "params": [], "id": 1}'
    result = server.handle_request(req)
    response = json.loads(result)
    assert response['result'] == 'Test Successful'

# Generated at 2022-06-21 08:38:09.805109
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
	
	obj = JsonRpcServer()
	obj._identifier = 1
	result =  obj.internal_error()

	assert result['jsonrpc'] == '2.0'
	assert result['id'] == 1
	assert result['error']['code'] == -32603
	assert result['error']['message'] == 'Internal error'

# Generated at 2022-06-21 08:38:13.580398
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrs = JsonRpcServer()
    msg = 'some error message'
    error = jrs.error(1, msg)
    assert error.get('error').get('code') == 1
    assert error.get('error').get('message') == msg


# Generated at 2022-06-21 08:38:21.207431
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc_server = JsonRpcServer()
    class JsonRpcServer_test(object):
        pass
    rpc_server.register(JsonRpcServer_test())
    assert rpc_server._objects.__len__() == 1
    rpc_server._objects.clear()


# Generated at 2022-06-21 08:38:23.183396
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = {}

    obj = JsonRpcServer()
    obj._identifier = 1
    obj.response()

# Generated at 2022-06-21 08:38:30.914736
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.six.moves import cPickle
    test = JsonRpcServer()
    test_result = {'test': 'result'}
    test._identifier = 'test_id'
    response = test.response(test_result)
    assert response['id'] == 'test_id'
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == to_text(cPickle.dumps(test_result, protocol=0))
    assert response["result_type"] == "pickle"


# Generated at 2022-06-21 08:38:33.688435
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    assert JsonRpcServer().header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-21 08:38:36.053763
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils.common._collections_compat import Mapping
    js = JsonRpcServer()
    js._identifier = 1
    assert type(js.internal_error()) is Mapping
    assert js.internal_error()['jsonrpc'] == '2.0'
    assert js.internal_error()['error']['code'] == -32603

# Generated at 2022-06-21 08:38:47.221545
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    rpc_method = server.response
    rpc_method_result = rpc_method()
    assert rpc_method_result == {'jsonrpc': '2.0', 'id': None, 'result': None}
    rpc_method_result = rpc_method(result=12)
    assert rpc_method_result == {'jsonrpc': '2.0', 'id': None, 'result': 12}
    rpc_method_result = rpc_method(result=b"test")
    assert rpc_method_result == {'jsonrpc': '2.0', 'id': None, 'result': 'test'}
    rpc_method_result = rpc_method(result={1: 2})

# Generated at 2022-06-21 08:38:52.041746
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    global rpc_server, test_object
    rpc_server = JsonRpcServer()
    test_object = "123"
    assert rpc_server.register(test_object) == None
    assert rpc_server._objects == {test_object}

test_JsonRpcServer_register()


# Generated at 2022-06-21 08:38:54.844488
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert len(server._objects) == 0
    server.register("socks")
    assert len(server._objects) == 1


# Generated at 2022-06-21 08:38:57.705806
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Foo(object):
        pass
    server.register(Foo())
    assert (Foo() in server._objects) == True


# Generated at 2022-06-21 08:39:09.940118
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils.basic import AnsibleModule
    import base64

    server = JsonRpcServer()

    request = {
        'jsonrpc': '2.0',
        'method': 'internal_error',
        'params': [[], {}],
        'id': 'req1'
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'

    # Testing with pickle result
    request = {
        'jsonrpc': '2.0',
        'method': 'test_result',
        'params': [[], {}],
        'id': 'req1'
    }
    response = server.handle_

# Generated at 2022-06-21 08:39:17.660413
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsr = JsonRpcServer()
    jsr._identifier = 'abc'
    result = jsr.header()
    assert (result['jsonrpc'] == '2.0') and (result['id'] == 'abc')


# Generated at 2022-06-21 08:39:25.308815
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()

    # message has proper error value
    error = server.internal_error()
    message = error.get('error')
    assert message['message'] == 'Internal error'

    # code has proper error value
    code = error.get('error')
    assert code['code'] == -32603

    # data is passed and set to error
    data = 'memory error'
    error = server.internal_error(data)
    assert error.get('error')['data'] == data



# Generated at 2022-06-21 08:39:35.427756
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import become_loader

    class FakeArgs(object):
        become = None
        become_method = None
        become_user = None
        network_os = 'dummy'
        connection = 'network_cli'

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.args = FakeArgs()

    # create connection plugins stub
    con_loader = become_loader.get('dummy', class_only=True)
    con_obj = con_loader()

    module = FakeModule()
    module.params['provider'] = {}
    module.params['provider']['transport'] = 'dummy'


# Generated at 2022-06-21 08:39:40.211276
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    obj = JsonRpcServer()
    result = obj.method_not_found()
    assert result['id'] is None
    assert result['error'] == {'code': -32601, 'message': 'Method not found'}
    assert result['jsonrpc'] == '2.0'

# Generated at 2022-06-21 08:39:45.630680
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    dummy_server = JsonRpcServer()
    dummy_server.register(object)
    assert dummy_server.handle_request('{"method": "__init__"}') == '{"jsonrpc": "2.0", "id": null, "error": {"code": -32600, "message": "Invalid request", "data": null}}'

# Generated at 2022-06-21 08:39:48.110776
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    test1 = JsonRpcServer()
    test1._identifier = "sample"
    response = test1.invalid_params()

    # Assertion
    assert response == {"jsonrpc": "2.0", "id": "sample", "error": {"code": -32602, "message": "Invalid params"}}


# Generated at 2022-06-21 08:39:55.397527
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test response with no result, should return a dict with 'result' value: None
    a = JsonRpcServer.response(None)
    assert(a == {'jsonrpc': '2.0', 'id': None, 'result': None})

    # Test response with a text string, should return a dict with 'result' value: 'text'
    a = JsonRpcServer.response('text')
    assert(a == {'jsonrpc': '2.0', 'id': None, 'result': 'text'})

    # Test response with a text string, should return a dict with 'result' value: 'text'
    a = JsonRpcServer.response(1)

# Generated at 2022-06-21 08:39:59.854995
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    print(json.dumps(s.error(code=32415, message='A test error')))
    print(json.dumps(s.error(code=32415, message='A test error without data')))


# Generated at 2022-06-21 08:40:01.276285
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    JsonRpcServer().method_not_found()


# Generated at 2022-06-21 08:40:05.122867
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj1 = JsonRpcServer()
    obj1.handle_request('{"jsonrpc": 2.0, "method": "ping", "params": {"foo": 0}, "id": 1}')
    assert obj1._identifier == 1


# Generated at 2022-06-21 08:40:13.014979
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 100
    result = {'a': 'b'}
    response = server.response(result)
    assert response == {'id': 100, 'jsonrpc': '2.0', 'result': {'a': 'b'}}


# Generated at 2022-06-21 08:40:15.343435
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    test = isinstance(server, JsonRpcServer)
    assert test == True


# Generated at 2022-06-21 08:40:16.597512
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    proto = JsonRpcServer()
    error = proto.method_not_found()
    assert error['id'] == 0
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'

# Generated at 2022-06-21 08:40:17.578485
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-21 08:40:22.785257
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
	result = JsonRpcServer().parse_error()
	assert result['jsonrpc'] == '2.0'
	assert result['error']['code'] == -32700
	assert result['error']['message'] == 'Parse error'
	assert result['error']['data'] is None

# Unit test to check attribute of method parse_error of class JsonRpcServer

# Generated at 2022-06-21 08:40:26.896638
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = server.response('test')
    assert result == {'jsonrpc': '2.0', 'id': None, 'result': '"test"'}

# Generated at 2022-06-21 08:40:30.276988
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
  server = JsonRpcServer()
  setattr(server, '_identifier', '123')

  actual_header = server.header()
  assert actual_header == {'jsonrpc': '2.0', 'id': '123'}


# Generated at 2022-06-21 08:40:41.307470
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    assert rpc_server.invalid_params(None) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}}
    assert rpc_server.invalid_params('error') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'error'}}
    rpc_server.method_not_found()
    rpc_server.handle_request({'method': 'method_not_found', 'params': [[], {}], 'id': 1})
    # Test for negative id

# Generated at 2022-06-21 08:40:45.810204
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    expected = {'jsonrpc': '2.0', 'id': server._identifier, 'error': {'code': -32603, 'message': 'Internal error'}}
    assert server.internal_error() == expected


# Generated at 2022-06-21 08:40:50.597941
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class FakeClass():
        def hello(self):
            return {"hello": "world"}
    fake_instance = FakeClass()
    server = JsonRpcServer()
    server.register(fake_instance)
    assert(fake_instance in server._objects)


# Generated at 2022-06-21 08:40:55.885828
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': None}
#


# Generated at 2022-06-21 08:40:59.794417
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    test = JsonRpcServer()
    data = 'Request JSON parse error'
    response = test.parse_error(data)
    assert response == {
        "jsonrpc": "2.0",
        "id": "_identifier",
        "error": {
            "code": -32700,
            "message": "Parse error",
            "data": data
        }
    }


# Generated at 2022-06-21 08:41:01.085254
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc_server = JsonRpcServer()
    rpc_server.invalid_params()

# Generated at 2022-06-21 08:41:05.073729
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'


# Generated at 2022-06-21 08:41:11.623176
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    jrpc_server = JsonRpcServer()

    # this value is not required for unit test
    jrpc_server._identifier = 1

    # Unit test for method handle_request of class JsonRpcServer
    # when the method is not set in the request
    request = {'params': ([], {})}
    expected_response = '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request"}}'
    assert jrpc_server.handle_request(request) == expected_response

    # Unit test for method handle_request of class JsonRpcServer
    # when the method is starting with 'rpc.' or '_'
    request = {'method': 'rpc.something', 'params': ([], {})}

# Generated at 2022-06-21 08:41:23.042811
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    # Tests error() method of class JsonRpcServer
    # Args:
    #   code: error code
    #   message: error message
    #   data: additional error data
    # Returns:
    #   json object

    # Create an object instance of class JsonRpcServer
    json_rpc_server = JsonRpcServer()

    # Get the header dictionary
    header = json_rpc_server.header()

    # Get the error dictionary
    error = json_rpc_server.error(code=102, message='method failed')

    # Check if the header dictionary is equal to the expected dictionary
    assert header == {'jsonrpc': '2.0', 'id': None}, "Error sending error message"

    # Check if the error dictionary is equal to the expected dictionary

# Generated at 2022-06-21 08:41:27.978793
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Always return {'jsonrpc': '2.0', 'id': self._identifier}, with self._identifier = 1
    # According to the above line, it should be {'jsonrpc': '2.0', 'id': 1}
    s = JsonRpcServer()
    s._identifier = 1
    reponse = s.header()
    assert reponse == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-21 08:41:35.306357
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = '{"params": [[1,2], [3,4]], "method": "test_method", "jsonrpc": "2.0", "id": 1}'
    server = JsonRpcServer()
    result = json.loads(server.handle_request(request))
    assert result == {'jsonrpc': '2.0', 'id': 1, 'result': [[1, 2], [3, 4]]}



# Generated at 2022-06-21 08:41:39.951274
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    testobj = JsonRpcServer()
    assert testobj.error(-32601, 'Method not found') == {'jsonrpc': '2.0', 'id': '0', 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-21 08:41:50.756927
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = 'test'
    expected = {'jsonrpc': '2.0', 'id': None, 'result': 'test'}
    response = JsonRpcServer().response(result=result)
    assert response == expected
    assert not response['result_type']

    result = b'btest'
    expected = {'jsonrpc': '2.0', 'id': None, 'result': 'btest'}
    response = JsonRpcServer().response(result=result)
    assert response == expected
    assert not response['result_type']

    result = {'pickle': 'this'}
    expected = {'jsonrpc': '2.0', 'id': None, 'result': "V{'pickle': 'this'\r\n."}

# Generated at 2022-06-21 08:41:56.397966
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    assert json.loads(JsonRpcServer().response()).get('jsonrpc') == '2.0'


# Generated at 2022-06-21 08:42:00.805017
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    error_msg = "test"
    test_data = {'error': {'code': -32603, 'message': 'Internal error', 'data': error_msg}}
    rpc_server = JsonRpcServer()
    assert test_data == rpc_server.internal_error(error_msg)

# Generated at 2022-06-21 08:42:06.489176
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_obj = JsonRpcServer()
    id_val = test_obj._identifier = '1'
    result = "test_result"
    result_type = "pickle"
    result_value = b'p\x03cbuiltins\nobject\np0\n.'

    response = test_obj.response(result)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1'
    assert response["result_type"] == "pickle"
    assert response["result"] == b'p\x03cbuiltins\nobject\np0\n.'

# Generated at 2022-06-21 08:42:08.404822
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    rpc = JsonRpcServer()
    error = rpc.internal_error()
    assert error == {"jsonrpc": "2.0", "error": {"message": "Internal error", "code": -32603}, "id": None}



# Generated at 2022-06-21 08:42:15.500167
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    s = JsonRpcServer()

    setattr(s, '_identifier', 1)
    response = s.internal_error()

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'

# Generated at 2022-06-21 08:42:25.459144
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils.json_rpc import JsonRpcServer
    assert_equals = "assert_equals"
    jsonrpc = "jsonrpc"
    id_ = "id"
    error = "error"
    code = "code"
    message = "message"
    data = "data"
    jsr = JsonRpcServer()
    
    # Check that the JSONRPC header is populated
    jsr._identifier = assert_equals
    response = jsr.error(-30000, "Test error", assert_equals)
    assert response[jsonrpc] == "2.0"
    assert response[id_] == assert_equals
    assert response[error][code] == -30000
    assert response[error][message] == "Test error"

# Generated at 2022-06-21 08:42:30.931037
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    class MyObject(object):
        def __init__(self, data):
            self.data = data

        def method1(self, data):
            print(data)

    obj1 = MyObject(10)
    server.register(obj1)

    test_data = [{'method': 'm1',
                 'params': [],
                 'id': 0,
                 'jsonrpc': '2.0'},
                {'method': 'method1',
                 'params': ['id', 'pass'],
                 'id': 1,
                 'jsonrpc': '2.0'},
                {'method': 'method1',
                 'params': [10],
                 'id': 2,
                 'jsonrpc': '2.0'}]


# Generated at 2022-06-21 08:42:40.965995
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_server = JsonRpcServer()
    setattr(json_server, '_identifier', 'foo')
    result = json_server.response(['hello', 'world'])
    assert result['id'] == 'foo'
    assert result['result'] == "['hello', 'world']"
    # test json encoding of non string objects
    result = json_server.response({'hello': 'world'})
    assert result['id'] == 'foo'
    assert result['result'] == "{'hello': 'world'}"
    assert result['result_type'] == "pickle"
    assert isinstance(result['result'],str)

    # test handling of nested objects
    data = [{'hello': 'world'}, {'ansible': 'rocks'}]
    result = json_server.response(data)
   

# Generated at 2022-06-21 08:42:45.946329
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found()
    assert error['id'] == "None"
    assert error['error']['code'] == -32601
    assert error['error']['message'] == "Method not found"
    assert error['jsonrpc'] == "2.0"
    assert error['result'] == None

# Generated at 2022-06-21 08:42:49.462155
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    setattr(rpc, '_identifier', 107)
    assert rpc.header() == {'jsonrpc': '2.0', 'id': 107}


# Generated at 2022-06-21 08:43:01.579422
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class Test1(object):
        pass
    
    class Test2(object):
        pass

    class Test3(object):
        pass

    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.register(Test1())
    assert Test1 in jsonRpcServer._objects

    jsonRpcServer.register(Test2())
    assert Test2 in jsonRpcServer._objects

    jsonRpcServer.register(Test3())
    assert Test3 in jsonRpcServer._objects



# Generated at 2022-06-21 08:43:04.933235
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    x = JsonRpcServer()
    if x.parse_error() != {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}:
        raise RuntimeError("test_JsonRpcServer_parse_error failed!")


# Generated at 2022-06-21 08:43:08.913864
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonRpcServer = JsonRpcServer()
    assert len(jsonRpcServer._objects) == 0
    jsonRpcServer.register('a')
    assert len(jsonRpcServer._objects) == 1
    assert 'a' in jsonRpcServer._objects


# Generated at 2022-06-21 08:43:12.118604
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer.parse_error(self=JsonRpcServer()) == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-21 08:43:18.491741
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.six.moves import StringIO
    import sys
    
    s = JsonRpcServer()

    json_request = '''{
      "jsonrpc": "2.0",
      "method": "test_method",
      "params": [{"first": 1, "second": 2}],
      "id": 1
    }'''

    # no method found
    result = s.handle_request(json_request)
    assert 'NoSuchMethod' in result

    # normal request
    class Test:
        def test_method(self, first, second):
            return first + second

    s.register(Test())
    result = s.handle_request(json_request)

# Generated at 2022-06-21 08:43:24.591129
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = {
        "method": "rpc.ping",
        "params": [],
        "id": 1
    }
    response = {
        "jsonrpc": "2.0",
        "id": 1,
        "result": "pong"
    }
    assert JsonRpcServer().response("pong") == response


# Generated at 2022-06-21 08:43:26.506469
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    b = JsonRpcServer()
    assert(isinstance(b, JsonRpcServer))

# Generated at 2022-06-21 08:43:28.458340
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 0
    test_data = {"jsonrpc": "2.0", "id": 0}
    assert server.header() == test_data

# Generated at 2022-06-21 08:43:30.050729
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    j = JsonRpcServer()
    assert j is not None

# Generated at 2022-06-21 08:43:33.431134
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    server.register(JsonRpcServer())
    setattr(server, '_id', '1')
    assert server.invalid_params()['error']['code'] == -32602


# Generated at 2022-06-21 08:43:48.402424
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    given_data = {'a':'b'}
    expected_err_code = -32602
    expected_err_msg = 'Invalid params'
    expected_result = {'jsonrpc': '2.0', 'id': 11, 'error': {'code': expected_err_code, 'message': expected_err_msg, 'data': given_data}}

    given_jsonrpc_server = JsonRpcServer()
    setattr(given_jsonrpc_server, '_identifier', 11)
    actual_result = given_jsonrpc_server.invalid_params(given_data)

    assert(actual_result == expected_result)

# Generated at 2022-06-21 08:43:51.798886
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    assert JsonRpcServer().parse_error().get('error').get('message') == 'Parse error'
    assert JsonRpcServer().parse_error('bogus_data').get('error').get('data') == 'bogus_data'


# Generated at 2022-06-21 08:43:56.806376
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    obj = JsonRpcServer()
    assert obj.invalid_request() == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': None
        }
    }

# Generated at 2022-06-21 08:43:58.218731
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
	json_server = JsonRpcServer()
	json_server.register()

# Generated at 2022-06-21 08:44:01.882131
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    # Pass empty dictionary
    response = server.method_not_found({'Test': "Hello"})
    assert response['error']['code'] == -32601


# Generated at 2022-06-21 08:44:05.002808
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    res = JsonRpcServer().invalid_request()
    assert res == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None}

# Generated at 2022-06-21 08:44:07.374456
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    serv = JsonRpcServer()
    error = serv.method_not_found()
    assert(error['id'] == None)
    assert(error['error']['code'] == -32601)


# Generated at 2022-06-21 08:44:18.826987
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    class TestClass(object):
        def test1(self, param1, param2, param3):
            print("Called test1... with params: {} {} {}".format(param1, param2, param3))
            return "test1"

        def test2(self, param1):
            print("Called test2... with param: {}".format(param1))
            return 2

    jrpc_server = JsonRpcServer()
    jrpc_server.register(TestClass())

    msg = "{\"jsonrpc\": \"2.0\", \"method\": \"test1\", \"params\": [1, 2, 3], \"id\": 123}"
    print(jrpc_server.handle_request(msg))

# Generated at 2022-06-21 08:44:22.552713
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = "12345"
    result = "test"
    expected = '{"id": "12345", "jsonrpc": "2.0", "result": "test"}'
    assert server.response(result) == json.loads(expected)

# Generated at 2022-06-21 08:44:25.798277
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    assert(JsonRpcServer().header() == {'jsonrpc': '2.0', 'id': None})


# Generated at 2022-06-21 08:44:48.825183
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsr = JsonRpcServer()
    class test(object):
        pass
    obj = test()
    jsr.register(obj)
    assert obj in jsr._objects

# Generated at 2022-06-21 08:44:51.748171
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    result = server.invalid_params()
    assert result == {'error': {'code': -32602, 'message': 'Invalid params'}, 'id': None, 'jsonrpc': '2.0'}

# Generated at 2022-06-21 08:44:53.104717
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc_server = JsonRpcServer()
    assert isinstance(rpc_server, JsonRpcServer)

# Generated at 2022-06-21 08:44:58.782762
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc = JsonRpcServer()
    rpc.register(rpc)

    # Test if exception is handled correctly
    request = {
        'jsonrpc': '2.0',
        'method': 'rpc.parse_error',
        'params': [],
        'id': '1'
    }
    response = json.loads(rpc.handle_request(json.dumps(request)))

    correct_response = {
        'jsonrpc': '2.0',
        'error': {
            'code': -32700,
            'message': 'Parse error'
        },
        'id': '1'
    }

    assert response == correct_response, 'JsonRpcServer parse_error() method is not working'


# Generated at 2022-06-21 08:45:03.078254
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params()
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'
