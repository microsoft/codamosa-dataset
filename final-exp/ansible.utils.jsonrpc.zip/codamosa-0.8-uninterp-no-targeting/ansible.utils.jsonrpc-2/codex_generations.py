

# Generated at 2022-06-21 08:35:19.448136
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    j = JsonRpcServer()
    j.register(j)
    print (j.handle_request(b'{"jsonrpc":"2.0","method":"rpc.pong","params":[],"id":1}'))
    print (j.handle_request(b'{"jsonrpc":"2.0","method":"ping","params":[],"id":1}'))

if __name__ == '__main__':
    test_JsonRpcServer_internal_error()

# Generated at 2022-06-21 08:35:30.888934
# Unit test for method handle_request of class JsonRpcServer

# Generated at 2022-06-21 08:35:32.656015
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    obj = JsonRpcServer()
    obj.error(code=0, message='Test Message')


# Generated at 2022-06-21 08:35:41.940291
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class FakeJsonRpcServer(object):
        def __init__(self):
            self.server = JsonRpcServer()

        def request(self, method, params):
            self.server.register(self)
            return self.server.handle_request(json.dumps({
                'jsonrpc': '2.0',
                'method': method,
                'params': params,
                'id': 'test'
            }))

        def bad_method(self):
            pass

    server = FakeJsonRpcServer()
    response = server.request('bad_method', [])


# Generated at 2022-06-21 08:35:51.098914
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    testSvr = JsonRpcServer()
    assert testSvr.invalid_params() == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32602,
            'message': 'Invalid params'
        }
    }
    assert testSvr.invalid_params('data') == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': 'data'
        }
    }

# Generated at 2022-06-21 08:35:52.666122
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.common.collections import ImmutableDict
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    assert server.header() == {'jsonrpc': '2.0', 'id': '1234'}



# Generated at 2022-06-21 08:35:54.011882
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-21 08:35:56.749562
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsr = JsonRpcServer()
    response = jsr.header()
    assert response == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-21 08:36:02.922781
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)
    result = json_rpc_server.handle_request(b"{\"jsonrpc\": \"2.0\", \"method\": \"invalid_params\", \"params\": [2, 3], \"id\": 1}")
    expected_result = '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params"}}'
    assert result == expected_result

# Generated at 2022-06-21 08:36:13.103572
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    client = JsonRpcClient()

    response = server.handle_request(client.request("rpc.echo", "Hello world!"))
    response = json.loads(response)
    assert response.get("jsonrpc") == "2.0"
    assert response.get("result") == "Hello world!"

    response = server.handle_request(client.request("rpc.echo", "Hello world!", 1, 2, 3))
    response = json.loads(response)
    assert response.get("jsonrpc") == "2.0"
    assert response.get("result") == "Hello world!"

    response = server.handle_request(client.request("rpc._get_socket"))
    response = json.loads(response)

# Generated at 2022-06-21 08:36:25.356789
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request={"id":"9cd6c5f5-5e4d-4a86-b074-b7c4a7020c7d","jsonrpc":"2.0","params":[[],{}],"method":"non_existing_method"}
    response = server.handle_request(request)
    print(response)


if __name__ == "__main__":
    test_JsonRpcServer_method_not_found()
    print("Tests Completed")

# Generated at 2022-06-21 08:36:34.566536
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    js = JsonRpcServer()
    js._identifier = "test-header"
    result = {"a": "b"}
    response = js.response(result)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == "test-header"
    assert response["result"] == result
    assert response["result_type"] == "pickle"
    r2 = js.response(to_text("test"))
    assert r2["result"] == "test"
    assert r2["result_type"] not in r2


# Generated at 2022-06-21 08:36:43.368049
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import time

    class Test(object):
        def __init__(self):
            self.obj = 'obj'
            self.int = 1
            self.request = {'method': 'status',
                            'params': [],
                            'id': 7}
            self.values = {'obj': 'obj',
                           'int': 1}

        def status(self):
            return self.values
    
    server = JsonRpcServer()
    server.register(Test())

    response = server.handle_request(json.dumps(server.request))

    print (response)

# Generated at 2022-06-21 08:36:50.092513
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # check for correct result
    import ansible.module_utils.json_rpc_server as json_rpc_server
    server = json_rpc_server.JsonRpcServer()
    result = "result"
    response = server.response(result)
    assert response["result"] == result and response["jsonrpc"] == "2.0" and response["id"] == None

    # check for pickle result
    server = json_rpc_server.JsonRpcServer()
    result = {"pickle": "result"}
    response = server.response(result)
    assert response["result_type"] == "pickle"

    # check for error result
    result = {"error": "error"}
    response = server.response(result)
    assert response["result_type"] == "pickle"


# Generated at 2022-06-21 08:37:01.348052
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Create instance of JsonRpcServer class
    server = JsonRpcServer()
    # Create connection ansible_netconf
    conn = Connection(server)
    # Create object of class NetconfConnection
    netconf = NetconfConnection(conn)
    # Register NetconfConnection object in JsonRpcServer
    server.register(netconf)

    # This method makes a request to the endpoint and returns the response.
    def send_request(request):
        """
        Handle the json rpc request and return the response.
        """
        response = server.handle_request(request)
        return json.loads(response)

    # Create request
    req_data = dict(jsonrpc='2.0',
                    method='system.connect',
                    id=1)
    # Convert request to text

# Generated at 2022-06-21 08:37:05.537741
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc_server = JsonRpcServer()
    mock_object = MockObject()
    rpc_server.register(mock_object)
    assert mock_object in rpc_server._objects


# Generated at 2022-06-21 08:37:11.833687
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = server.error(code=1, message='error_message', data='error_data')
    expected_result = {'jsonrpc': '2.0', 'id': 1, 'error': {'code': 1, 'message': 'error_message', 'data': 'error_data'}}
    assert result == expected_result


# Generated at 2022-06-21 08:37:19.882357
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "echo_method", "params": ["foo", "bar"], "id": "1111"}'
    result = json.loads(server.handle_request(request))
    if (result["result"][0] != "foo" or
        result["result"][1] != "bar" or
        result["result_type"] != "pickle" or
        result["id"] != "1111" or
        result["jsonrpc"] != "2.0"):
        raise AssertionError('result={}'.format(result))


# Generated at 2022-06-21 08:37:22.476726
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server1 = JsonRpcServer()
    obj = module()
    server1.register(obj)
    assert obj in server1._objects


# Generated at 2022-06-21 08:37:27.081965
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    setattr(server,'_identifier',1)
    assert server.internal_error(data="error") == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Internal error", "data": "error"}}


# Generated at 2022-06-21 08:37:34.423030
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrsc = JsonRpcServer()
    response_json = jrsc.parse_error()
    response = json.loads(response_json)
    assert response["error"]["code"] == -32700
    assert response["error"]["message"] == "Parse error"



# Generated at 2022-06-21 08:37:39.604810
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    error = JsonRpcServer().error(code=-32600, message='Invalid request')
    assert error == {
        "error": {
            "message": "Invalid request",
            "code": -32600,
        },
        "jsonrpc": "2.0",
        "id": None
    }

# Generated at 2022-06-21 08:37:43.920082
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    """Unit test for ansible_collections.ansible.netcommon.plugins.connection.network_cli.connection.JsonRpcServer.header"""
    jrs = JsonRpcServer()
    setattr(jrs, '_identifier', 1234)
    assert jrs.header() == {'jsonrpc': '2.0', 'id': 1234}


# Generated at 2022-06-21 08:37:54.874152
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.ftd.jsonrpc_server import JsonRpcServer

    # Create mock objects
    module = AnsibleModule({})
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(module)

    # Create sample request
    request = {
        "method": "execute_task",
        "params": [],
        "id": 0
    }

    request = json.dumps(request)

    # Call method
    response = json_rpc_server.handle_request(request)

    # Assert that the result JSONRPC response matches expectation
    result = json.loads(response)
    assert result

# Generated at 2022-06-21 08:37:59.686927
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    mock_obj = object
    server = JsonRpcServer()

    server.register(mock_obj)

    if not mock_obj in server._objects:
        raise AssertionError("test_JsonRpcServer_register Failed: Expected %s to be in %s" % (mock_obj, server._objects))


# Generated at 2022-06-21 08:38:02.378062
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(1, 'message')
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'message'}}


# Generated at 2022-06-21 08:38:07.413081
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request()
    assert result == {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": None}



# Generated at 2022-06-21 08:38:15.954780
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    print("Testing method 'test_JsonRpcServer_internal_error' of class 'JsonRpcServer'")
    jrs = JsonRpcServer()
    jrs.register(JsonRpcServer())
    jrs._identifier = 1
    result = jrs.handle_request(r"""{"method":"internal_error", "params":[], "id":1}""")
    result = json.loads(to_text(result, errors='surrogate_then_replace'))
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'

# Generated at 2022-06-21 08:38:18.525164
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    js = JsonRpcServer()
    assert js._objects == set()
    assert not hasattr(js, '_identifier')


# Generated at 2022-06-21 08:38:23.042671
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    error = server.invalid_params()
    assert error['id'] == None
    assert error['error']['code'] == -32602


# Generated at 2022-06-21 08:38:33.059792
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    data = {'example_data': 'test'}
    error = server.parse_error(data=data)
    assert error == {'id': None, 'jsonrpc': '2.0', 'error': {'message': 'Parse error', 'code': -32700, 'data': {'example_data': 'test'}}}


# Generated at 2022-06-21 08:38:35.015249
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server._objects == set()


# Generated at 2022-06-21 08:38:40.713771
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = '123456'
    if server.header() == {'jsonrpc': '2.0', 'id': '123456'}:
        display.display('Test of method header is passed')
        return
    else:
        display.display('Test of method header is not passed')
        return


# Generated at 2022-06-21 08:38:43.881108
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    """Unit test for constructor of class JsonRpcServer"""
    req = '{"jsonrpc": "2.0", "params": [1, 2, 3], "id": 0, "method": "call_function"}'
    server = JsonRpcServer()
    result = server.handle_request(req)
    print(result)


if "__main__" == __name__:
    test_JsonRpcServer()

# Generated at 2022-06-21 08:38:45.901792
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)

# Generated at 2022-06-21 08:38:55.323209
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    JsonRpcServerClass = JsonRpcServer()
    # Test case 1: Header default
    try:
        JsonRpcServerClass._identifier = 0
        display.vvv(JsonRpcServerClass.header())
    # Test case 2: Header has been set
    except AttributeError as e:
        print(e.args)
        print("Test case 2: pass")
    # Test case 3: Testing error with no id
    JsonRpcServerClass._identifier = None
    try:
        display.vvv(JsonRpcServerClass.header())
    except AttributeError as e:
        print(e.args)
        print("Test case 3: pass")


# Generated at 2022-06-21 08:38:59.238788
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj = JsonRpcServer()
    result = obj.invalid_params()
    assert 'error' in result
    assert result['id'] == 0
    assert result['error']['code'] == -32602
    assert result['error']['message'] == 'Invalid params'


# Generated at 2022-06-21 08:39:10.679439
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import pickle
    pack_data = {'jsonrpc': '2.0', 'id': None, 'result': 'hello'}
    obj = JsonRpcServer()
    assert pack_data == obj.response({"hello"})


# Generated at 2022-06-21 08:39:17.467496
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    assert error["id"] == None, "id is not None"
    assert error["error"]["code"] == -32700, "error code is not -32700"
    assert error["error"]["message"] == "Parse error", "error message is not Parse error"
    assert error["error"]["data"] == None, "error data is not None"


# Generated at 2022-06-21 08:39:21.474011
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    # Method handle_request of class JsonRpcServer can be called
    # with a request parameter of type str


if __name__ == '__main__':
    test_JsonRpcServer_handle_request()

# Generated at 2022-06-21 08:39:36.209986
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    assert -32602 == server.invalid_params(b'unicode')['error']['code']

# Generated at 2022-06-21 08:39:39.450746
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    response = server.parse_error()
    assert response["error"]["code"] == -32700


# Generated at 2022-06-21 08:39:50.205762
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import os
    import sys
    import tempfile
    import textwrap
    import yaml
    import time
    import pprint
    import socket

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import http_client
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes, to_text

    TEST_DIR = os.path.dirname(os.path.abspath(__file__))

    class RemoteProcess:
        def __init__(self):
            self._socket_path = None

        def start(self):
            self._socket_path = tempfile.mktemp()

# Generated at 2022-06-21 08:39:54.542174
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error("testing")
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error', 'data': "testing"}}


# Generated at 2022-06-21 08:40:00.799286
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request = json.dumps(dict(method='test', params=[[], {}], id=1))
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-21 08:40:06.695458
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # Initialize class object
    obj = JsonRpcServer()

    # Call method
    result = obj.invalid_params(data=None)

    # Check result
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == None
    assert result['error']['code'] == -32602
    assert result['error']['message'] == 'Invalid params'
    assert result['error']['data'] == None


# Generated at 2022-06-21 08:40:10.520908
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jrs = JsonRpcServer()
    jrs._identifier = 1
    assert jrs.header() == {'jsonrpc': '2.0', 'id': 1}

# Generated at 2022-06-21 08:40:13.998850
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 0
    result = server.header()
    response = {'jsonrpc': '2.0', 'id': 0}
    assert result == response


# Generated at 2022-06-21 08:40:18.909251
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrpc = JsonRpcServer()
    result = jrpc.parse_error()
    assert result['jsonrpc'] == '2.0'
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'


# Generated at 2022-06-21 08:40:23.425151
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    error = server.internal_error()
    assert error["error"]["code"] == -32603
    assert error["error"]["message"] == 'Internal error'
    assert error["error"]["data"] is None
    error = server.internal_error(data="test data")
    assert error["error"]["code"] == -32603
    assert error["error"]["message"] == 'Internal error'
    assert error["error"]["data"] == "test data"

if __name__ == "__main__":
    test_JsonRpcServer_internal_error()

# Generated at 2022-06-21 08:40:56.743925
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    test_obj = JsonRpcServer()
    setattr(test_obj, '_identifier', 1)
    res = test_obj.parse_error()
    assert res is not None
    assert 'result' not in res
    assert res['error']['code'] == -32700
    assert res['error']['message'] == 'Parse error'
    setattr(test_obj, '_identifier', 1)
    res = test_obj.parse_error({"error_data": "error_data"})
    assert 'result' not in res
    assert res['error']['code'] == -32700
    assert res['error']['message'] == 'Parse error'
    assert res['error']['data'] == {"error_data": "error_data"}


# Generated at 2022-06-21 08:41:00.568776
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    response1 = {'result':'ok', 'id':'123'}
    response2 = JsonRpcServer().response('ok')
    assert response1 == response2


# Generated at 2022-06-21 08:41:04.675146
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = server.header()
    assert result == {'jsonrpc': '2.0', 'id': 1}



# Generated at 2022-06-21 08:41:05.981519
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    json_obj = JsonRpcServer()
    assert (json_obj)

# Generated at 2022-06-21 08:41:09.025291
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    Js = JsonRpcServer()
    setattr(Js, '_identifier', '1234')
    response = Js.header()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '1234'


# Generated at 2022-06-21 08:41:16.933372
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    test_data = [None, 'test']
    for data in test_data:
        result = server.parse_error(data)
        assert result['error']['code'] == -32700
        assert result['error']['message'] == 'Parse error'
        if data is None:
            assert 'data' not in result['error']
        else:
            assert result['error']['data'] == data


# Generated at 2022-06-21 08:41:18.325951
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result == {'error': {'code': -32603, 'message': 'Internal error'}, 'id': None, 'jsonrpc': '2.0'}


# Generated at 2022-06-21 08:41:21.139811
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None, "Failed to create JsonRpcServer object"
    print("JsonRpcServer object successfully created")

# Generated at 2022-06-21 08:41:29.029751
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    JsonRpcServer._objects.clear()
    cls = JsonRpcServer()
    assert cls.response() == '{"jsonrpc": "2.0", "id": None, "result": ""}'
    assert cls.response('foobar') == '{"jsonrpc": "2.0", "id": None, "result": "foobar"}'

    # test __dict__ method
    class MockObject(object):
        def __init__(self):
            self.host = '10.10.10.10'
            self.port = 22
            self.username = 'user1'
            self.password = 'passwd'

    cls.register(MockObject())
    JsonRpcServer._objects.add(MockObject())


# Generated at 2022-06-21 08:41:34.533020
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    json_rpc_server = JsonRpcServer()
    rpc_error = json_rpc_server.method_not_found()
    assert rpc_error['error']['code'] == -32601
    assert rpc_error['error']['message'] == 'Method not found'

# Generated at 2022-06-21 08:42:25.236713
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    response = server.header()
    assert 'id' in response
    assert response['id'] == '1234'
    assert 'jsonrpc' in response
    assert response['jsonrpc'] == '2.0'
    assert len(response.keys()) == 2



# Generated at 2022-06-21 08:42:28.189375
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    result = JsonRpcServer().invalid_request()
    assert result == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32600,
            'message': 'Invalid request',
            'data': None
        }
    }


# Generated at 2022-06-21 08:42:31.383146
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    def test_obj_method():
        pass

    test_obj = type("TestObj", (object,), {"method": test_obj_method})
    test_server = JsonRpcServer()
    test_server.register(test_obj)

    assert test_obj in test_server._objects


# Generated at 2022-06-21 08:42:36.455920
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    expected_json = r'{"jsonrpc": "2.0", "id": "1234", "error": {"data": null, "code": -32602, "message": "Invalid params"}}'
    assert expected_json == server.invalid_params()

# Generated at 2022-06-21 08:42:40.718590
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32700
    assert error['error']['message'] == 'Parse error'


# Generated at 2022-06-21 08:42:47.446282
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    
    x = JsonRpcServer()
    x.register(x)
    
    client_request = '{"id": 1, "method": "invalid_params", "params": [], "jsonrpc": "2.0"}'
    response = x.handle_request(client_request)

    assert json.loads(response)["error"]["code"] == -32602
    
test_JsonRpcServer_invalid_params()

# Generated at 2022-06-21 08:42:49.879929
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    json_rpc_server = JsonRpcServer()

    assert(type(json_rpc_server) == JsonRpcServer)

# Test for RPC methods of class JsonRpcServer

# Generated at 2022-06-21 08:43:00.091347
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import traceback
    import platform

    # this module is used for unit testing the jsonrpcserver code
    import ansible.module_utils.jsonrpc2 as jsonrpc
    import sys

    # always make sure that protocol version is imported properly
    global __protocol_version__
    try:
        __protocol_version__ = sys.modules['__main__'].__protocol_version__
    except Exception:
        raise Exception(traceback.format_exc())

    # Set up some test data
    valid_argspec = {'foo': dict(type='str', default='one'),
                     'bar': dict(type='int')}

    platform_args = {'foo': 'one', 'bar': 32}
    invalid_args = {'foo': 1, 'bar': 'two'}

    # Configure the test setup


# Generated at 2022-06-21 08:43:03.394539
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    s = JsonRpcServer()
    setattr(s, '_identifier', 1)
    assert s.internal_error() == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32603, 'message': 'Internal error', 'data': None}}


# Generated at 2022-06-21 08:43:12.849213
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.loader import cliconf_loader, netconf_loader

    cliconf = {}
    netconf = {}
    device_args = {'provider': {}}

    load_provider(cliconf, netconf, device_args)
    obj = JsonRpcServer()
    obj.register(cliconf)
    obj.register(netconf)
    obj.register(device_args)

    # this test case is used to check invalid_params method
    assert isinstance(obj.invalid_params(), dict)
    assert 'jsonrpc' in obj.invalid_params()
    assert 'id' in obj.invalid_params()
    assert 'error' in obj.invalid_params()

# Generated at 2022-06-21 08:44:55.964737
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    Server = JsonRpcServer()
    Server._identifier = "1"
    result = Server.method_not_found()
    assert result == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32601, 'message': 'Method not found'}}

# Generated at 2022-06-21 08:45:02.240747
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jrs = JsonRpcServer()
    setattr(jrs, '_identifier', 'test_identifier')
    assert jrs.method_not_found() == {
        u'id': 'test_identifier',
        u'error': {
            u'message': 'Method not found',
            u'code': -32601 },
        u'jsonrpc': '2.0'}


# Generated at 2022-06-21 08:45:12.478079
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()

    # Method for testing error case of 'execute_command' with none as input
    def execute_command_error(self, command, prompt=None, answer=None, sendonly=False, output=None, newline=True, prompt_retry_check=False, check_all=False):
        return None

    # Method for testing error case of 'get_capabilities' with none as input
    def get_capabilities_error(self, var):
        return None

    # Method for testing error case of 'load_config' with none as input
    def load_config_error(self, config=None, **commands):
        return None

    # Loading error class for 'execute_command'