

# Generated at 2022-06-21 08:35:20.267048
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    import json
    import unittest
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.six import PY3

    class Connection(object):

        def __init__(self):
            pass

        def exec_command(self, cmd):
            return (0, '', '')

    class NetworkModule(object):

        def __init__(self, connection):
            self._connection = connection

        def execute(self, commands, **kwargs):
            return list()

    class Cli(object):

        def __init__(self, module):
            self._module = module

        def run_commands(self, command_list):
            return list()

    class JsonRpcTestCase(unittest.TestCase):
        ''' a group of related Unit Tests '''


# Generated at 2022-06-21 08:35:25.751893
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server_instance = JsonRpcServer()
    result = json_rpc_server_instance.invalid_params()
    assert result["jsonrpc"] == "2.0"
    assert result["id"] == None
    assert result["error"]["code"] == -32602
    assert result["error"]["message"] == "Invalid params"


# Generated at 2022-06-21 08:35:27.076561
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    srv = JsonRpcServer()
    assert srv != None

# Generated at 2022-06-21 08:35:38.370573
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils import basic

    # JsonRpcServer.response() normal
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer._identifier = "test_identifier"
    response = jsonRpcServer.response()
    assert (response == {'jsonrpc': '2.0', 'id': "test_identifier", 'result': None})

    # JsonRpcServer.response() error
    jsonRpcServer._identifier = "test_identifier"
    response = jsonRpcServer.response(test_message)

# Generated at 2022-06-21 08:35:39.909353
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()
    assert rpc is not None


# Generated at 2022-06-21 08:35:43.394173
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found()
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'


# Generated at 2022-06-21 08:35:49.403026
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    a = JsonRpcServer()
    a.test = {'test': 'test'}
    assert a.handle_request({'method':'test'}) == json.dumps({'jsonrpc':'2.0', 'id': None, 'error': {'code':-32601, 'message':'Method not found', 'data': None}})


# Generated at 2022-06-21 08:36:00.490001
# Unit test for method error of class JsonRpcServer

# Generated at 2022-06-21 08:36:04.243611
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    body = {'jsonrpc': '2.0', 'id': 1, 'result': 'result'}
    rpc = JsonRpcServer()
    rpc._identifier = 1
    assert json.loads(rpc.response('result')) == body


body = {'jsonrpc': '2.0', 'id': 1, 'result_type': 'pickle', 'result': 'GANSBh4='}


# Generated at 2022-06-21 08:36:08.554243
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    rpc._identifier = "5"

    result = rpc.header()
    assert result == {"jsonrpc": "2.0", "id": "5"}


# Generated at 2022-06-21 08:36:18.785456
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    JRS = JsonRpcServer()
    response = JRS.method_not_found()
    assert response["jsonrpc"] == "2.0"
    assert response["error"]["code"] == -32601

# Generated at 2022-06-21 08:36:23.987909
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj = JsonRpcServer()
    obj._identifier = 123
    result = obj.invalid_params('invalid value')
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'invalid value'}, 'id': 123}

# Generated at 2022-06-21 08:36:25.819352
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
   print("Testing register...")
   ob = JsonRpcServer()
   ob.register("dummy")
   ob.register("dummy")
   ob.register("dummy")
   print(ob._objects)


# Generated at 2022-06-21 08:36:34.617938
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    request = {
        "id": 1,
        "jsonrpc": "2.0",
        "method": "rpc.invalid_request"
    }
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32600, "message": "Invalid request", "data": {"message": "The request message was malformed"}}}'


# Generated at 2022-06-21 08:36:38.618487
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    result = server.invalid_request()
    assert result == {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request", "data": None}}

# Generated at 2022-06-21 08:36:41.177561
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    print(obj.response())
    print(obj.method_not_found())


# Generated at 2022-06-21 08:36:43.096739
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert isinstance(server, JsonRpcServer)


# Generated at 2022-06-21 08:36:49.297944
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jrpc = JsonRpcServer()
    class obj:
        pass

    # Unit test for method handle_request
    while True:
        class obj1:
            pass

        jrpc.handle_request("{}")

        jrpc.register(obj1)

        class obj2:
            pass

        jrpc.register(obj2)

        class obj3:
            pass

        jrpc.register(obj3)

        class obj4:
            pass

        jrpc.register(obj4)
        jrpc.register(obj4)

        # Unit test for method handle_request
        jrpc.handle_request("{}")

# Generated at 2022-06-21 08:36:52.664229
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    j = JsonRpcServer()
    assert isinstance(j, JsonRpcServer)


# Generated at 2022-06-21 08:36:55.092394
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    testobj = JsonRpcServer()
    assert  testobj.handle_request({"method": "test"}) is not None

# Generated at 2022-06-21 08:37:13.375523
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    expected = {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': -32700,
            'message': 'Parse error',
            'data': None
        }
    }
    assert server.parse_error() == expected


# Generated at 2022-06-21 08:37:17.440695
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error_dict = server.method_not_found()
    assert error_dict["code"] == -32601
    assert error_dict["message"] == "Method not found"


# Generated at 2022-06-21 08:37:20.377572
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    response = JsonRpcServer().method_not_found()
    assert response.get('error') == {'code': -32601, 'message': 'Method not found'}


# Generated at 2022-06-21 08:37:27.082637
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # Create JsonRpcServer object
    test_jsonrpc_server = JsonRpcServer()

    # Set the id attribute of JsonRpcServer object
    setattr(test_jsonrpc_server, '_identifier', "test_jsonrpc_server")

    # call header method
    result = test_jsonrpc_server.header()
    assert result == {'jsonrpc': '2.0', 'id': "test_jsonrpc_server"}, 'Test Failed'    


# Generated at 2022-06-21 08:37:33.811737
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServerInstance = JsonRpcServer()
    try:
        result = jsonRpcServerInstance.invalid_params()
        expected = {
            'jsonrpc': '2.0',
            'id': None,
            'error': {
                'code': -32602,
                'message': 'Invalid params',
                'data': None
            }
        }
        assert result == expected
    except Exception as e:
        print("Test invalid_params: FAILED")
        print(e)

# Generated at 2022-06-21 08:37:35.327103
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-21 08:37:41.755403
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    j = JsonRpcServer()
    j._identifier = "id"
    assert j.response() == {
        "result_type": "pickle",
        "jsonrpc": "2.0",
        "id": "id",
        "result": to_text(cPickle.dumps(None, protocol=0)),
    }
    assert j.response("string") == {
        "jsonrpc": "2.0",
        "id": "id",
        "result": "string"
    }

# Generated at 2022-06-21 08:37:45.046539
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonRpc = JsonRpcServer()
    res = jsonRpc.method_not_found()
    assert res.get('error').get('code') == -32601
    assert res.get('error').get('message') == 'Method not found'


# Generated at 2022-06-21 08:37:48.530910
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    request = {'jsonrpc': '2.0', 'id': 0, 'method': 'invalid', 'params': []}
    server = JsonRpcServer()
    response = json.loads(server.handle_request(json.dumps(request)))
    assert response == {'jsonrpc': '2.0', 'id': 0, 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-21 08:37:54.679825
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    fixture = JsonRpcServer()
    expected_result = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None,
        },
    }
    result = fixture.invalid_request()
    assert result == expected_result

# Generated at 2022-06-21 08:38:05.525020
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-21 08:38:15.267338
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', "id")
    result = server.error(100100, "message", data=None)
    assert result == {"jsonrpc": "2.0", "id": "id", "error": {"code": 100100,
                                                             "message": "message", "data": None}}
    result = server.error(100100, "message", data="data")
    assert result == {"jsonrpc": "2.0", "id": "id", "error": {"code": 100100,
                                                             "message": "message", "data": "data"}}


# Generated at 2022-06-21 08:38:24.648997
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    ex = 'this is an exception'
    assert server.error(-32700, 'Parse error', data=ex) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'this is an exception'}}
    assert server.error(-32601, 'Method not found', data=ex) == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found', 'data': 'this is an exception'}}

# Generated at 2022-06-21 08:38:33.299415
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc = JsonRpcServer()
    response = rpc.invalid_request()
    assert json.dumps(response) == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'
    response = rpc.invalid_request(data={'a':1})
    assert json.dumps(response) == '{"jsonrpc": "2.0", "error": {"code": -32600, "data": {"a": 1}, "message": "Invalid request"}, "id": null}'


# Generated at 2022-06-21 08:38:35.696472
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    js = JsonRpcServer()
    display.display(js.parse_error(data="data"))



# Generated at 2022-06-21 08:38:42.509638
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    json_rpc_server = JsonRpcServer()
    json_rpc_server._identifier = "123"
    response = json_rpc_server.error(404, "Not Found", data=None)
    assert response == {
            'jsonrpc': '2.0',
            'id': '123',
            'error': {
                'code': 404,
                'message': 'Not Found',
                }
            }


# Generated at 2022-06-21 08:38:51.304390
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    temp = dict()
    temp['jsonrpc'] = '2.0'
    temp['id'] = 'Ansible'
    temp['error'] = {'code': -32700, 'message': 'Parse error', 'data': None}
    temp['result'] = None

    # Call the method with no data
    assert server.parse_error() == temp

    # Call the method with data
    temp['error']['data'] = 'test_JsonRpcServer_parse_error'
    assert server.parse_error('test_JsonRpcServer_parse_error') == temp


# Generated at 2022-06-21 08:38:53.353747
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    js = JsonRpcServer()
    assert isinstance(js, JsonRpcServer)


# Generated at 2022-06-21 08:38:56.534942
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    r = JsonRpcServer()
    test = JsonRpcServer_register_TestClass()
    r.register(test)
    assert test in r._objects, "Failed to add object to _objects set"


# Generated at 2022-06-21 08:39:00.775283
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrpc_server = JsonRpcServer()
    # Set the identifier to 0
    jrpc_server._identifier = 0
    msg = jrpc_server.invalid_params()
    assert msg == {'jsonrpc': '2.0', 'id': 0, 'error': {'code': -32602, 'message': 'Invalid params'}}

# Generated at 2022-06-21 08:39:31.834934
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(sys.argv[0])))
    from test.units.compat import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()

        def test_invalid_params(self):
            self.server.register(self)
            data = {'data': 'not a real message'}

            result = self.server.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'invalid_params', 'id': '1', 'params': [data]}))
            result = json.loads(result)

# Generated at 2022-06-21 08:39:35.395007
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    args=dict()
    obj=JsonRpcServer()
    result=obj.invalid_request()
    assert result['error']['code']==-32600
    assert result['error']['message']=='Invalid request'
    assert result['id']==None
    assert result['jsonrpc']=='2.0'


# Generated at 2022-06-21 08:39:47.052959
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc = JsonRpcServer()
    rpc.register(JsonRpcServer())
    rpc.handle_request('{"jsonrpc": "2.0", "method": "error", "params": []}')
    rpc.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [], "id": 1}')
    rpc.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [], "id": "1"}')
    rpc.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [], "id": "1.1"}')

# Generated at 2022-06-21 08:39:50.122412
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': None}

# Generated at 2022-06-21 08:39:56.609025
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import mock
    from ansible.module_utils.network.junos.junos import Class1
    from ansible.module_utils.network.junos.junos import Class2
    from ansible.module_utils.network.junos.junos import Class3
    from ansible.module_utils.network.junos.junos import Class4

    cls1 = Class1()
    cls2 = Class2()
    cls3 = Class3()
    cls4 = Class4()

    ##
    ## MOCKS for _connection.send_request
    ##
    class MockConnectionSuccess(object):
        def __init__(self):
            self.res_data = {'jsonrpc': '2.0', 'id': '12345'}


# Generated at 2022-06-21 08:40:02.761894
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = '{"jsonrpc": "2.0", "method": "get", "params": [], "id": 1}'
    response = '{"jsonrpc": "2.0", "result": null, "id": 1}'
    mock_response = JsonRpcServer().handle_request(request)
    assert mock_response == response, 'handle request error, response: %s' % str(mock_response)

# Generated at 2022-06-21 08:40:13.340122
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    # init
    server = JsonRpcServer()

    # test invalid method
    request = {
        "method": "rpc.invalid_method",
        "id": "1",
        "jsonrpc": "2.0",
        "params": ([], {})
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)
    assert response['error']['code'] == -32601 and response['error']['message'] == 'Method not found'

    # test parse error
    request = {
        "method": "test_parse",
        "id": "1",
        "jsonrpc": "2.0",
        "params": ([]),
    }
    response = server.handle_request(json.dumps(request))
    response

# Generated at 2022-06-21 08:40:18.632725
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jrs = JsonRpcServer()
    response = jrs.internal_error("")
    assert response['id'] == None
    assert response['error']['code'] == -32603
    assert response['error']['message'] == "Internal error"
    assert response['error']['data'] == ""


# Generated at 2022-06-21 08:40:19.637568
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server

# Generated at 2022-06-21 08:40:28.202886
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils import basic

    json_server = JsonRpcServer()
    json_server.register(basic)
    setattr(json_server, '_identifier', u'f5c957f4-c5b4-11e7-b4a6-005056837bd2')
    expected = {'jsonrpc': '2.0', 'id': u'f5c957f4-c5b4-11e7-b4a6-005056837bd2'}
    actual = json_server.header()
    assert expected == actual



# Generated at 2022-06-21 08:40:45.264043
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    try:
        testobj = JsonRpcServer()
        response = testobj.handle_request("{}")
        assert json.loads(response)['error']['code'] == -32600 and json.loads(response)['error']['message'] == 'Invalid request', "Method invalid_request of class JsonRpcServer does not return correct value."
    except:
        assert False, "Something wrong during method invalid_request testing for class JsonRpcServer."


# Generated at 2022-06-21 08:40:56.661987
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print('Testing method handle_request')
    server = JsonRpcServer()
    display = Display()
    response = server.handle_request({})
    assert(response in {'{"id": null, "error": {"code": -32600, "message": "Invalid request"}, "jsonrpc": "2.0"}',
                                    '{"jsonrpc": "2.0", "id": null, "error": {"message": "Invalid request", "code": -32600}}'})
    response = server.handle_request('{"method": "rpc.x"}')
    assert(response == '{"id": null, "error": {"code": -32600, "message": "Invalid request"}, "jsonrpc": "2.0"}')
    response = server.handle_request('{"method": "_x"}')

# Generated at 2022-06-21 08:41:08.253388
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 5)

    assert server.response() == {'jsonrpc': '2.0', 'id': 5, 'result': ''}
    assert server.response('') == {'jsonrpc': '2.0', 'id': 5, 'result': ''}

# Generated at 2022-06-21 08:41:11.996149
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    error = JsonRpcServer().invalid_params("test_data")
    assert error['error']['code'] == -32602 and error['error']['message'] == 'Invalid params' and error['error']['data'] == "test_data"

# Generated at 2022-06-21 08:41:14.215813
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    assert JsonRpcServer().internal_error()['error']['code'] == -32603

# Generated at 2022-06-21 08:41:18.967579
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonrpc_server = JsonRpcServer()
    invalid_params_response = jsonrpc_server.invalid_params()

    error = invalid_params_response['error']
    assert error['code'] == -32602
    assert error['message'] == 'Invalid params'

# Generated at 2022-06-21 08:41:24.929738
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():

    JsonRpcServer_obj = JsonRpcServer()
    setattr(JsonRpcServer_obj, '_identifier', "test_JsonRpcServer_invalid_request")
    result = JsonRpcServer_obj.invalid_request()

    assert result == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': 'test_JsonRpcServer_invalid_request'}


# Generated at 2022-06-21 08:41:28.166052
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj.register(obj)
    assert to_text(obj._objects) == "set([<ansible.module_utils.json_rpc.JsonRpcServer object at 0x7f2a6c451e48>])"


# Generated at 2022-06-21 08:41:32.836023
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    response = server.parse_error()
    assert not response['result']
    assert response['error']['code'] == -32700


# Generated at 2022-06-21 08:41:36.094156
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
       server = JsonRpcServer()
       assert(server.invalid_params() == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32602, 'message': 'Invalid params'}})

# Generated at 2022-06-21 08:41:51.406396
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(code=1, message='Test error')
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 1, 'message': 'Test error'}}


# Generated at 2022-06-21 08:41:58.869534
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    client = JsonRpcServer()

    class Test(object):
        def foo(self):
            return 'foo'

    obj = Test()

    client.register(obj)
    assert client.handle_request(json.dumps({'id': '1', 'method': 'foo'})) == '{"result": "foo", "id": "1", "jsonrpc": "2.0"}'

# Generated at 2022-06-21 08:42:07.432280
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    class Server(object):
        def get(self, *args, **kwargs):
            return kwargs

    server = JsonRpcServer()
    server.register(Server())

    request = {
        'jsonrpc': '2.0',
        'id': 0,
        'method': 'get',
        'params': {
            'args': ['arg1'],
            'kwargs': {'key': 'val'}
        }
    }
    response = server.handle_request(json.dumps(request))
    response = json.loads(response)

    assert response['id'] == 0
    assert response['result'] == {'key': 'val'}

# Generated at 2022-06-21 08:42:13.893519
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request = json.loads('{"id": "1", "method": "method", "params": [["arg"]]}')
    response = json.loads('{"id": "1", "error": {"code": -32601, "message": "Method not found"}, "jsonrpc": "2.0"}')
    assert server.handle_request(json.dumps(request)) == json.dumps(response)

# Generated at 2022-06-21 08:42:23.420406
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    # If a rpc call contains an invalid JSON or an empty JSON, the server
    # returns an error response
    json_rpc_server = JsonRpcServer()
    # regular dictionary
    request = {"method": "add", "params": [1, 2], "id": 1}
    response = json_rpc_server.handle_request(request)
    # empty json
    request = {}
    response = json_rpc_server.handle_request(request)
    # regular json
    request = {"method": "add", "params": [1, 2], "id": 1}
    response = json_rpc_server.handle_request(request)
    assert response["error"]["message"] == "Invalid request"
    assert response["error"]["code"] == -32600


# Generated at 2022-06-21 08:42:25.597371
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj.register("1")
    assert obj._objects == set(["1"])


# Generated at 2022-06-21 08:42:28.001193
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    rpc_server = JsonRpcServer()
    rpc_server.register(obj=None)
    assert len(rpc_server._objects) == 1

# Generated at 2022-06-21 08:42:28.853150
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer() is not None

# Generated at 2022-06-21 08:42:35.030763
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    from test.support import captured_stdout
    from ansible.module_utils.network.common.utils import to_list

    class MyRpcServer(JsonRpcServer):

        @staticmethod
        def _tuple(data):
            return to_list(data)

        @staticmethod
        def _str(data):
            return to_text(data)

        @staticmethod
        def _dict(data):
            return {'K': to_text(data)}

        @staticmethod
        def _reduce_list(data):
            return to_list(data)

        @staticmethod
        def _reduce_dict(data):
            return {'K': to_text(data)}

    server = MyRpcServer()


# Generated at 2022-06-21 08:42:38.466585
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc = JsonRpcServer()

    assert rpc.invalid_params() == {
        "id": None,
        "jsonrpc": "2.0",
        "error": {"code": -32602, "message": "Invalid params"}
    }

# Generated at 2022-06-21 08:43:09.912503
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    json_rpc_server = JsonRpcServer()
    error = json_rpc_server.invalid_params()
    valid_error = error == {'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}, 'jsonrpc': '2.0'}
    print(valid_error)


# Generated at 2022-06-21 08:43:12.320216
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    a=JsonRpcServer()
    b=JsonRpcServer()
    a.register(b)
    assert b in a._objects


# Generated at 2022-06-21 08:43:15.318857
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    rpc = JsonRpcServer()
    setattr(rpc, '_identifier', 'test')
    result = rpc.header()
    assert result == {'jsonrpc': '2.0', 'id': 'test'}


# Generated at 2022-06-21 08:43:26.230595
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = {'key1': 'value1', 'key2': 'value2'}
    response = server.response(result)
    assert response['id'] is None
    assert response['jsonrpc'] == '2.0'
    assert response['result'] == result
    assert not response.get('error')
    # Test type coercion for result to JSON serializable type.
    result = [1, 2, 3, 4]
    response = server.response(result)
    assert len(response['result']) == len(result)
    assert response['result'] == result
    # Test pickling, which is required for non-JSON serializable types
    result = {'key1': 1, 'key2': 2}
    response = server.response(result)

# Generated at 2022-06-21 08:43:28.129559
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    print(server.internal_error())


# Generated at 2022-06-21 08:43:38.597796
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '101')
    assert server.response() == {'jsonrpc': '2.0', 'id': '101'}
    assert server.response('hello world') == {
        'jsonrpc': '2.0', 'id': '101', 'result': 'hello world'
    }
    assert server.response(b'hello world') == {
        'jsonrpc': '2.0', 'id': '101', 'result': 'hello world'
    }
    assert "pickle" in server.response({'foo': 'bar'})
    assert server.response({'foo': 'bar'})['result'] != 'hello world'
    assert "pickle" in server.response({'hello world': 'hello world'})

# Generated at 2022-06-21 08:43:39.740416
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None

# Generated at 2022-06-21 08:43:43.372372
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-21 08:43:46.356332
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    try:
        server._identifier
    except AttributeError:
        pass
    else:
        assert False

# Test if the value of JsonRpcServer.header() == {'jsonrpc': '2.0', 'id': self._identifier}

# Generated at 2022-06-21 08:43:48.801342
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    res = server.internal_error()
    assert res['error']['code'] == -32603
    assert res['error']['message'] == 'Internal error'


# Generated at 2022-06-21 08:44:20.120792
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()

    return_value = server.error(1234, "message")
    assert return_value["error"]["code"] == 1234
    assert return_value["id"] is None
    assert return_value["result"] is None
    assert return_value["result_type"] is None
    assert return_value["jsonrpc"] == "2.0"


# Generated at 2022-06-21 08:44:31.103434
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    try:
        from ansible.inventory.manager import InventoryManager
    except ImportError:
        from ansible.inventory.manager import InventoryManager
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, bypass_checks=True)
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["host_vars"])
    options = None
    passwords = dict()
   

# Generated at 2022-06-21 08:44:34.675967
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    request = json.dumps({'id': 1, 'method': 'foobar'})
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'

# Generated at 2022-06-21 08:44:38.160354
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    error = server.parse_error()
    assert error['id'] == None
    assert error['error'] == {'code': -32700, 'message': 'Parse error'}


# Generated at 2022-06-21 08:44:43.353622
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    response = server.header()
    assert response == {'jsonrpc': '2.0', 'id': 1}, "The response should be {'jsonrpc': '2.0', 'id': 1}"
    delattr(server, '_identifier')


# Generated at 2022-06-21 08:44:50.472001
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    data = "some_data"
    result = server.parse_error(data)
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert result['error']['data'] == data
    result = server.parse_error()
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert 'data' not in result['error']


# Generated at 2022-06-21 08:44:54.872004
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    result = server.parse_error()
    assert result.get('jsonrpc') == '2.0'
    assert isinstance(result.get('id'), int)
    error = result.get('error')
    assert error.get('message') == 'Parse error'
    assert error.get('code') == -32700


# Generated at 2022-06-21 08:44:56.250812
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
  jsonrpc = JsonRpcServer()
  jsonrpc.invalid_params()

# Generated at 2022-06-21 08:45:08.049459
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import connection
    connection.Connection._module_name = None
    output = StringIO()
    connection.Connection._log_messages = lambda self, messages, level: output.write(messages[0])
    server = JsonRpcServer()
    res = server.internal_error(data='testing')
    assert res == {u'jsonrpc': u'2.0', u'id': None, u'error': {u'code': -32603, u'message': u'Internal error', u'data': u'testing'}}
    assert "Internal error encountered:\ntesting" in output.getvalue()
    connection.Connection._module_name = 'network_cli'
    connection.Connection._log_messages = None