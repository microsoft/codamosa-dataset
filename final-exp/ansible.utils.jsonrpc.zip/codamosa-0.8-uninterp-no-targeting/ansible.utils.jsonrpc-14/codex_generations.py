

# Generated at 2022-06-21 08:35:15.009486
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj.register(obj)
    assert len(obj._objects) == 1

# Generated at 2022-06-21 08:35:16.788698
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

    assert server is not None


# Generated at 2022-06-21 08:35:19.257505
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
	test_obj = JsonRpcServer()
	test_req = {"method": "foo"}
	test_obj.handle_request(test_req)

# Generated at 2022-06-21 08:35:24.946475
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonRpcServer = JsonRpcServer()

    # test method_not_found()
    try:
        response = jsonRpcServer.method_not_found()
        assert response.get('error').get('code') == -32601
    except Exception as e:
        print("Test failed")
        print(e)
        raise e
    else:
        print("Test passed")

# Generated at 2022-06-21 08:35:34.045280
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonRpcServer = JsonRpcServer()
    result = jsonRpcServer.parse_error()
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}}

    jsonRpcServer = JsonRpcServer()
    result = jsonRpcServer.parse_error({'data': 'some data'})
    assert result == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error', 'data': {'data': 'some data'}}}


# Generated at 2022-06-21 08:35:36.516892
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer_obj = JsonRpcServer()
    class testclass:
        def testmethod(self):
            return True
    testobj = testclass()
    JsonRpcServer_obj.register(testobj)
    response = JsonRpcServer_obj.handle_request(json.dumps({
            'method': 'testmethod',
            'params': [],
            'id': 1
        }))
    assert json.loads(response)['result']

# Generated at 2022-06-21 08:35:39.538490
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    j = JsonRpcServer()
    response = j.invalid_request()
    assert response['id'] is None
    assert response['error']['code'] == -32600


# Generated at 2022-06-21 08:35:46.923602
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    # Create an instance of JsonRpcServer to test
    server = JsonRpcServer()

    # Mock the request
    mock_request = {"id":123,"jsonrpc":"2.0","method":"hello","params":["world"]}

    # Call function under test
    res = server.handle_request(mock_request)

    # Check if the correct response has been returned
    assert res == '{"error": {"code": -32600, "message": "Invalid request"}, "id": 123, "jsonrpc": "2.0"}'


# Generated at 2022-06-21 08:35:55.214848
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()

    expected_dict = dict()
    expected_dict['jsonrpc'] = '2.0'
    expected_dict['id'] = None
    expected_dict['error'] = {}
    expected_dict['error']['code'] = -32602
    expected_dict['error']['message'] = 'Invalid params'
    expected_dict['error']['data'] = None

    actual_dict = server.invalid_params()

    assert actual_dict == expected_dict


# Generated at 2022-06-21 08:36:00.365013
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    error = JsonRpcServer().internal_error()
    assert isinstance(error, dict)
    assert error['id'] is None
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32603
    assert error['error']['message'] == 'Internal error'
    assert 'data' not in error['error']

# Generated at 2022-06-21 08:36:12.151390
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = dict(key='value')
    response = server.response(result)
    assert response == {
        'jsonrpc': '2.0',
        'id': None,
        'result_type': 'pickle',
        'result': to_text(cPickle.dumps(dict(key='value'), protocol=0))
    }

# Generated at 2022-06-21 08:36:18.661077
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrpcserver = JsonRpcServer()
    setattr(jrpcserver, '_identifier', -1)
    exp_result = {'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}, 'id': -1}
    res = jrpcserver.invalid_params()
    assert res == exp_result


# Generated at 2022-06-21 08:36:19.939685
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server._objects == set()

# Generated at 2022-06-21 08:36:28.579571
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils._text import to_bytes

    server = JsonRpcServer()

    def test_method(n):
        if n == 1:
            raise AttributeError("test_method")
        return n

    server.register(test_method)

    content = {"jsonrpc": "2.0", "method": "test_method", "params": [1], "id": 1}
    content = json.dumps(content)
    response = to_bytes(server.handle_request(content))

    assert response == b'{"id": 1, "jsonrpc": "2.0", "error": {"message": "Internal error", "code": -32603, "data": "AttributeError(\\"test_method\\",)"}}'


# Generated at 2022-06-21 08:36:35.348747
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import dict_merge
    result = dict_merge(Connection().get_connection_info(), {'result': 'connection'})
    id = 1
    response = JsonRpcServer().header()
    assert response == {'jsonrpc': '2.0', 'id': id}


# Generated at 2022-06-21 08:36:36.595489
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server

# Generated at 2022-06-21 08:36:40.008232
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer
    print("The jsonrpc version is: %s" % server.header(None))

if __name__ == "__main__":
    test_JsonRpcServer()

# Generated at 2022-06-21 08:36:44.060608
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    import pytest
    server = JsonRpcServer()
    result = server.invalid_params()
    assert result == {'jsonrpc': '2.0', 'id': '', 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}}

# Generated at 2022-06-21 08:36:52.008724
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    def test_rpc_method(param):
        return 42

    request = {'jsonrpc': '2.0', 'id': '5', 'method': 'test_rpc_method', 'params': ['param']}

    server = JsonRpcServer()

    server.register(server)
    server.register(test_rpc_method)

    response = server.handle_request(json.dumps(request))

    expected = {'jsonrpc': '2.0', 'id': '5', 'result': '42'}
    assert json.loads(response) == expected


# Generated at 2022-06-21 08:36:55.108782
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    assert JsonRpcServer().internal_error().get('error')['message'] == 'Internal error'

# Generated at 2022-06-21 08:37:02.727520
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'test_id')
    expected_result = {"jsonrpc": "2.0", "id": "test_id"}
    result = server.header()
    assert result == expected_result


# Generated at 2022-06-21 08:37:04.739520
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
   jrs = JsonRpcServer()

# Generated at 2022-06-21 08:37:14.594915
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    from ansible.module_utils.network_common import JsonRpcServer
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves import cPickle

    server = JsonRpcServer()
    server.register(JsonRpcServer)

    result = server.handle_request('''{"method":"parse_error","params":[],"id":12}''')
    result = json.loads(result)

    assert result["id"] == 12
    assert result["result"] is None
    assert result["error"]["code"] == -32700
    assert result["error"]["message"] == 'Parse error'
    assert result["error"]["data"] is None


# Generated at 2022-06-21 08:37:19.882455
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc = JsonRpcServer()
    rpc._identifier = 'identifier'
    result = rpc.parse_error()
    assert result == {'jsonrpc': '2.0', 'id': 'identifier', 'error': {'code': -32700,  'message': 'Parse error'}}


# Generated at 2022-06-21 08:37:22.145256
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    j = JsonRpcServer()
    s = j.invalid_params()
    assert s['error']['code'] == -32602

# Generated at 2022-06-21 08:37:25.549932
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    response = JsonRpcServer().internal_error(data=None)
    assert response == {'jsonrpc': '2.0', 'error': {'message': 'Internal error', 'code': -32603}, 'id': None}

# Generated at 2022-06-21 08:37:31.574035
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
  rpc_server = JsonRpcServer()
  rpc_server._identifier = 10
  result = rpc_server.invalid_params("sample string")
  assert "jsonrpc" in result
  assert "2.0" in result["jsonrpc"]
  assert "id" in result
  assert 10 in result["id"]
  assert "error" in result
  assert "code" in result["error"]

# Generated at 2022-06-21 08:37:36.876117
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.register(jsonRpcServer)
    request = {
        'jsonrpc': '2.0',
        'method': 'testingInvalidMethod',
        'id': 0
    }
    actual = jsonRpcServer.handle_request(json.dumps(request))
    expected = '{"jsonrpc": "2.0", "id": 0, "error": {"code": -32601, "message": "Method not found"}}'
    assert actual == expected

# Generated at 2022-06-21 08:37:39.909696
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jr = JsonRpcServer()
    jr._identifier = 3
    assert jr.header() == {'jsonrpc': '2.0', 'id': 3}



# Generated at 2022-06-21 08:37:41.465907
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
 testobj = JsonRpcServer()
 print(testobj.invalid_params())
 

# Generated at 2022-06-21 08:37:56.399812
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    assert server.handle_request('{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["hello"], "id": 1}') != None
    assert server.handle_request('{"jsonrpc": "2.0", "method": "_echo", "params": ["hello"], "id": 1}') != None
    assert server.handle_request('{"jsonrpc": "2.0", "method": "__echo", "params": ["hello"], "id": 1}') != None
    assert server.handle_request('{"jsonrpc": "2.0", "method": "echo", "params": ["hello"], "id": 1}') != None

# Generated at 2022-06-21 08:38:02.022400
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    class TestJsonRpcServer(JsonRpcServer):
        def __init__(self):
            pass
        
    result = None
    expected = {'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}, 'id': ''}
    server = TestJsonRpcServer()
    result = server.parse_error()
    assert result == expected


# Generated at 2022-06-21 08:38:06.581081
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    rpc_server = JsonRpcServer()
    error = 'Internal error'
    rpc_server.internal_error(error)
    assert rpc_server.error(-32603, 'Internal error', error) == error

# Generated at 2022-06-21 08:38:12.403733
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    result = 'test_result'
    # JsonRpcServer()._identifier = 100
    setattr(server, '_identifier', 100)
    expected = {'jsonrpc': '2.0', 'id': 100, 'result': 'test_result'}
    actual = server.response(result)
    assert actual == expected

# Generated at 2022-06-21 08:38:20.820184
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.json_rpc import JsonRpcServer
    data = [
         {'jsonrpc': '2.0', 'id': '', 'error': {'code': -32700, 'message': 'Parse error', 'data': None}}
    ]
    server = JsonRpcServer()
    actual = to_list(server.parse_error())
    assert not actual.difference(data)
    assert not data.difference(actual)


# Generated at 2022-06-21 08:38:21.980299
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    pass


# Generated at 2022-06-21 08:38:27.787709
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    config = {
        'jsonrpc': '2.0',
        'result': '',
        'id': '1',
        'error': {
            'code': -32601,
            'message': 'Method not found',
            'data': None
        }
    }

    instance = JsonRpcServer()
    assert config == instance.method_not_found()


# Generated at 2022-06-21 08:38:29.569857
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jsonRpcServer = JsonRpcServer()
    assert isinstance(jsonRpcServer, JsonRpcServer)

# Generated at 2022-06-21 08:38:36.094724
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
  server = JsonRpcServer()

  identifier1 = 'test1'
  identifier2 = 'test2'

  server._identifier = identifier1
  assert server.header() == {'jsonrpc': '2.0', 'id': identifier1}

  server._identifier = identifier2
  assert server.header() == {'jsonrpc': '2.0', 'id': identifier2}


# Generated at 2022-06-21 08:38:41.347910
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    expected = json.dumps(
        {'jsonrpc': '2.0', 'id': None, 'error':
         {'code': -32600, 'message': 'Invalid request', 'data': None}}
    )
    actual = server.invalid_request()
    assert actual == expected


# Generated at 2022-06-21 08:38:46.687569
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    obj.register(None)

# Generated at 2022-06-21 08:38:50.326151
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        JsonRpcServer()
    except Exception as e:
        print(e)
        return(1)
    else:
        return(0)

#Unit test for register of class JsonRpcServer

# Generated at 2022-06-21 08:38:59.968257
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    # Test invalid request
    request = {
        "jsonrpc": "2.0",
        "method": "rpc._invalid_request",
        "id": "0",
        "params": []
    }
    request = json.dumps(request)
    response = server.handle_request(request)
    response = json.loads(response)
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == "0"
    assert "error" in response
    assert response["error"]["code"] == -32603
    assert response["error"]["message"] == "Internal error"
    assert response["error"]["data"] == "Method '_invalid_request' not found"

    # Test method not found

# Generated at 2022-06-21 08:39:05.637189
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    test_obj = JsonRpcServer()
    expected_result = {"id": None, "error": {"code": -32603, "message": "Internal error", "data": None}, "jsonrpc": "2.0"}
    actual_result = test_obj.internal_error()
    assert actual_result == expected_result


# Generated at 2022-06-21 08:39:16.351918
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # Negative case (unit test)
    try:
        error = JsonRpcServer().internal_error(data="This is an error message!")
    except Exception as e:
        error = None
    assert error == {'jsonrpc': '2.0', 'id': 'None', 'error': {'code': -32603, 'message': 'Internal error', 'data': 'This is an error message!'}}
    # Positive case (unit test)
    try:
        error = JsonRpcServer().internal_error(data={"key": "value"})
    except Exception as e:
        error = None

# Generated at 2022-06-21 08:39:21.932530
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj = JsonRpcServer()
    obj._identifier = "test_uuid"
    response = obj.invalid_params()
    return response == '{"jsonrpc": "2.0", "id": "test_uuid", "error": {"code": -32602, "message": "Invalid params"}}'


# Generated at 2022-06-21 08:39:32.954956
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    # Testing method error with standard error code
    jrpc = JsonRpcServer()
    result = jrpc.error(code=-32600, message='Invalid request')
    expected = {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}}
    assert result == expected, 'Return value does not match with expected value'

    # Testing method error with custom error code
    jrpc = JsonRpcServer()
    result = jrpc.error(code=1, message='Custom error')
    expected = {'id': None, 'jsonrpc': '2.0', 'error': {'code': 1, 'message': 'Custom error'}}
    assert result == expected, 'Return value does not match with expected value'

    # Testing method error with

# Generated at 2022-06-21 08:39:33.745002
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    pass


# Generated at 2022-06-21 08:39:40.702362
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params()
    assert response["error"]["code"] == -32602
    assert response["error"]["message"] == 'Invalid params'

if __name__ == '__main__':
    from pytest import main
    main([__file__, '-vv', '-x'])

    # Example of testing class methods
    # test_JsonRpcServer_invalid_params()

# Generated at 2022-06-21 08:39:47.903474
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    class client1:
        def hello(self, *args, **kwargs):
            return "hello"

    class client2:
        def world(self, *args, **kwargs):
            return "world"

    module = JsonRpcServer()
    module.register(client1)
    module.register(client2)
    assert(callable(getattr(module, "hello")) and callable(getattr(module, "world")))


# Generated at 2022-06-21 08:40:05.613537
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import sys
    import inspect
    import ansible_collections

    # Load internal plugins
    for p in ansible_collections.__path__:
        sys.path.append(p)

    from ansible_collections.notstdlib.moveitallout.plugins import ansible_module_utils

    # Load utils, connection
    mod = __import__('ansible_module_utils.connection', fromlist=['connection'])
    mod_cls = getattr(mod, 'Connection')
    mod_funcs = inspect.getmembers(mod_cls, predicate=inspect.isfunction)

    # Load utils, shell_default, cliconf , modules
    mod = __import__('ansible_module_utils.network.common.utils', fromlist=['shell_default', 'modules', 'cliconf'])


# Generated at 2022-06-21 08:40:12.829966
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    x = JsonRpcServer()
    try:
        error = x.internal_error(data="Error message: 1/0")
        assert error["jsonrpc"] == "2.0"
        assert error["error"]["code"] == -32603
        assert error["error"]["message"] == "Internal error"
        assert error["error"]["data"] == "Error message: 1/0"
    except:
        assert False

# Generated at 2022-06-21 08:40:16.776714
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    id = 1
    setattr(server, '_identifier', id)

    header = server.header()

    assert header == {'jsonrpc': '2.0', 'id': id}


# Generated at 2022-06-21 08:40:19.075887
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found()
    assert error['error']['message'] == 'Method not found'

# Generated at 2022-06-21 08:40:23.272698
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    rpc = JsonRpcServer()
    rpc.header()
    error_json_string = rpc.invalid_params('data')
    # print(error_json_string)
    # {"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params", "data": "data"}, "id": None}
    assert error_json_string == '{"jsonrpc": "2.0", "error": {"code": -32602, "message": "Invalid params", "data": "data"}, "id": None}'


# Generated at 2022-06-21 08:40:32.756826
# Unit test for method parse_error of class JsonRpcServer

# Generated at 2022-06-21 08:40:40.981013
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json.dumps({
        'jsonrpc': '2.0',
        'id': '0',
        'result': '{"host": "192.0.2.1", "port": 22, "username": "johndoe", "password": "abc123"}',
    })

    json.dumps({
        'jsonrpc': '2.0',
        'id': '0',
        'error': {'code': -32603, 'message': 'Internal error', 'data': 'AttributeError("\'Facts\' object has no attribute \'test\'",)'}
    })

# Generated at 2022-06-21 08:40:44.912614
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    # arrange
    json_rpc_server = JsonRpcServer()

    # act
    result = json_rpc_server.header()

    # assert
    assert result == {'jsonrpc': '2.0', 'id': 'remote'}



# Generated at 2022-06-21 08:40:48.923069
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    obj = JsonRpcServer()
    obj._identifier = '12345'
    assert obj.header() == {'jsonrpc': '2.0', 'id': '12345'}

# Generated at 2022-06-21 08:40:51.724916
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj = JsonRpcServer()
    x = {1:2, 3:4}
    obj.register(x)
    assert x in obj._objects


# Generated at 2022-06-21 08:41:13.402839
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer.register({})
    result = jsonRpcServer.handle_request(b'{"jsonrpc": "2.0", "method": "rpc.echo", "params": ["foo"], "id": 1}')
    assert json.loads(result) == {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}, "id": 1}


# Generated at 2022-06-21 08:41:17.942736
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    response = JsonRpcServer().invalid_request()
    expected = json.dumps({'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None})
    assert response == expected

# Generated at 2022-06-21 08:41:20.024176
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    jrs = JsonRpcServer()
    assert jrs._objects == set()


# Generated at 2022-06-21 08:41:25.137133
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jrpc_obj = JsonRpcServer()
    expected_result = '{"jsonrpc": "2.0", "id": "id_12345", "result_type": "pickle", "result": "gAJ9cQAoVQ==\\n."}'
    response = jrpc_obj.response(result={'test': 'data'})
    assert expected_result == json.dumps(response)


# Generated at 2022-06-21 08:41:28.548655
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    response = server.invalid_request()
    assert response == {
        "id": None,
        "jsonrpc": "2.0",
        "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": None
        }
    }


# Generated at 2022-06-21 08:41:39.420482
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    js = JsonRpcServer()

    # generator return dict
    js.response = MagicMock()
    js.response.return_value = {'jsonrpc': '2.0', 'id': 123, 'result': 'foo'}
    js.response.return_value = {'jsonrpc': '2.0', 'id': 123, 'error': 'bar'}
    # generator return non-dict
    js.response = MagicMock()
    js.response.return_value = 'foo'
    js.response.return_value = {'jsonrpc': '2.0', 'id': 123, 'error': 'foo'}
    # generator return non-dict
    js.response = MagicMock()
    js.response.return_value = 'foo'

# Generated at 2022-06-21 08:41:45.615127
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    assert server.invalid_params() == {
        'code': -32602,
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': None
        }
    }

# Generated at 2022-06-21 08:41:48.560698
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    JsonRpcServer_instance = JsonRpcServer()
    method = "invalid_request"
    function = getattr(JsonRpcServer_instance, method)
    function()


# Generated at 2022-06-21 08:41:55.321420
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 42
    data = {'code': -32601, 'message': 'Method not found', 'data': 'method not found error'}

# Generated at 2022-06-21 08:42:01.964474
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Create a JsonRpcServer object
    json_rpc_server = JsonRpcServer()

    # Unit test function parse_error passing an arbitrary value as data
    assert json_rpc_server.parse_error(data = True) == {
        'jsonrpc': '2.0',
        'id': None,
        'error': {
            'code': -32700,
            'message': 'Parse error',
            'data': True
        }
    }


# Generated at 2022-06-21 08:42:26.171792
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc = JsonRpcServer()
    result = rpc.parse_error()
    assert result is not None


# Generated at 2022-06-21 08:42:31.868755
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jrs = JsonRpcServer()
    jrs._identifier = "req_id"
    expected = json.dumps({
        "jsonrpc": "2.0",
        "id": "req_id",
        "error": {
            "code": -32603,
            "message": "Internal error",
            "data": "Test error message"
        }
    })
    assert jrs.error(code = -32603, message = "Internal error", data = "Test error message") == json.loads(expected)

# Generated at 2022-06-21 08:42:35.139902
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    server._identifier = 'key'
    assert server.header() == {'jsonrpc': '2.0', 'id': 'key'}


# Generated at 2022-06-21 08:42:38.228625
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpc = JsonRpcServer()
    setattr(jsonrpc, '_identifier', 1)
    assert jsonrpc.header() == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-21 08:42:42.981997
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    req = '{"jsonrpc": "2.0", "method": "test", "params": [1,2,3], "id": "test"}'
    res = server.handle_request(req)
    assert '-32600' in res


# Generated at 2022-06-21 08:42:44.385598
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None


# Generated at 2022-06-21 08:42:49.050426
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params()
    assert response == {
        'error': {
            'code': -32602,
            'message': 'Invalid params',
        },
        'id': None,
        'jsonrpc': '2.0'
    }



# Generated at 2022-06-21 08:42:54.977667
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    class TestObj:
        def test_method(self):
            pass

    test = JsonRpcServer()
    test.register(TestObj)
    result = test.handle_request('{"jsonrpc": "2.0", "method": "test_method", "params": [1, 2, 3, 4, 5], "id": 1}')
    assert(result == '{"id": 1, "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}')
    result = json.loads(result)
    assert(result['id'] == 1)
    assert(result['jsonrpc'] == '2.0')
    assert(result['error']['code'] == -32601)
    assert(result['error']['message'] == 'Method not found')


# Generated at 2022-06-21 08:42:56.758891
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert(obj)


# Generated at 2022-06-21 08:43:00.810547
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    s_obj = JsonRpcServer()
    setattr(s_obj, '_identifier', 1)
    assert s_obj.header() == {'id': 1, 'jsonrpc': '2.0'}
    delattr(s_obj, '_identifier')

# unit test for error handling

# Generated at 2022-06-21 08:43:42.991181
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import os

    server = JsonRpcServer()
    server._identifier = "123"
    assert server.error('7', 'oh noes') == os.linesep.join([
        '{',
        '    "jsonrpc": "2.0",',
        '    "id": "123",',
        '    "error": {',
        '        "code": "7",',
        '        "message": "oh noes"',
        '    }',
        '}'
    ])


# Generated at 2022-06-21 08:43:43.983180
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

# Generated at 2022-06-21 08:43:51.067694
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    # ConnectionError
    # Case 1: serialize without code
    try:
        raise ConnectionError('ConnectionError without code')
    except ConnectionError:
        request = {
            'id': 0,
            'method': 'error'
        }
        expected = {
            'jsonrpc': '2.0',
            'id': 0,
            'error': {
                'code': -32603,
                'message': 'ConnectionError without code',
                'data': 'ConnectionError without code'
            }
        }
        assert server.handle_request(json.dumps(request)) == json.dumps(expected)

    # Case 2: serialize with code

# Generated at 2022-06-21 08:44:02.273794
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "method": "rpc.invalid_request", "id": 81}'
    error = server.handle_request(request)
    #assert error.has_key('id')
    #assert error.has_key('jsonrpc')
    #assert error.has_key('error')
    #assert error.has_key('code')
    #assert error.has_key('message')
    #assert error.has_key('data')
    #assert error['id'] == 81
    #assert error['jsonrpc'] == "2.0"
    #assert error['error']['code'] == -32604
    #assert error['error']['message'] == 'Invalid request'


# Generated at 2022-06-21 08:44:06.400386
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found(data="foo")
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'
    assert error['error']['data'] == "foo"

# Generated at 2022-06-21 08:44:09.448488
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    assert JsonRpcServer().invalid_params() == {"jsonrpc": "2.0", "id": None, "error": {"code": -32602, "message": "Invalid params", "data": None}, "result": None}

# Generated at 2022-06-21 08:44:16.402446
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    server.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'invalid', 'id': 1}))
    assert 'method not found' in server.handle_request(json.dumps({'jsonrpc': '2.0', 'method': 'invalid', 'id': 1}))


# Generated at 2022-06-21 08:44:21.761445
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
 
    js = JsonRpcServer()
    js.register(JsonRpcServer())
 
    result = js.handle_request(b'{"jsonrpc": "2.0", "method": "rpc.parse_error", "params": [], "id": 123}')
    expected = '{"jsonrpc": "2.0", "id": 123, "error": {"code": -32700, "message": "Parse error"}}'
    assert result == expected


# Generated at 2022-06-21 08:44:27.711802
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 1
    response = server.response(result="result_test")
    if response['jsonrpc'] != '2.0' or response['id'] != 1 or response['result'] != '"result_test"':
        raise AssertionError()


# Generated at 2022-06-21 08:44:31.564179
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jsonrpc_server = JsonRpcServer()
    result = jsonrpc_server.method_not_found()
    expected = {'jsonrpc': '2.0', 'error': {'code': -32601, 'message': 'Method not found'}, 'id': None}
    assert result == expected