

# Generated at 2022-06-21 08:35:20.682857
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    j = JsonRpcServer()
    expected = {'error': {'code': 1, 'message': 'testing error'}, 'jsonrpc': '2.0', 'id': 0}
    assert j.error(1, 'testing error') == expected

    expected = {'error': {'code': 1, 'message': 'testing error', 'data': 'testing data'}, 'jsonrpc': '2.0', 'id': 0}
    assert j.error(1, 'testing error', 'testing data') == expected

# Generated at 2022-06-21 08:35:25.401777
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    expected = {"jsonrpc": "2.0", "id": "1234", "error":{"code":-32603, "message": "Internal error", "data": "error message test"}}
    result = JsonRpcServer().error(-32603, "Internal error","error message test")
    assert result == expected


# Generated at 2022-06-21 08:35:33.198786
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    # Create a test JsonRpcServer object
    jsonrpc_server = JsonRpcServer()

    # Call the internal_error method of the created JsonRpcServer object with
    # no data and the result is a JsonRpcServer response message with code of
    # -32603 and message of Internal error
    assert jsonrpc_server.internal_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}}


# Generated at 2022-06-21 08:35:37.133906
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpcserver = JsonRpcServer()
    jsonrpcserver._identifier = 'test'
    actual = jsonrpcserver.header()
    expected = {'jsonrpc': '2.0', 'id': 'test'}
    assert actual == expected


# Generated at 2022-06-21 08:35:38.420631
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
	"""Unit test for method register of class JsonRpcServer"""
	from copy import copy
	from datetime import date
	from datetime import time
	pass


# Generated at 2022-06-21 08:35:43.349511
# Unit test for method parse_error of class JsonRpcServer

# Generated at 2022-06-21 08:35:47.645616
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()

    result = server.invalid_request()

    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}


# Generated at 2022-06-21 08:35:57.136253
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    rpc = JsonRpcServer()
    rpc.register(JsonRpcServer())

    # test missing code
    test_method_name = 'error'
    test_method = getattr(rpc, test_method_name, None)
    test_arguments = [None, None]
    test_keywords = {}
    result = test_method(*test_arguments, **test_keywords)
    assert result['error']['code'] == -32603
    assert result['error']['message'] == 'Internal error'
    assert result['id'] == None
    assert result['jsonrpc'] == '2.0'

# Generated at 2022-06-21 08:36:01.537976
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    server.register(server)
    response = server.method_not_found("Data")
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == "Method not found"
    assert response["error"]["data"] == "Data"  


# Generated at 2022-06-21 08:36:07.781005
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jrs = JsonRpcServer()
    assert jrs.invalid_params() == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32602,
            'message': 'Invalid params',
            'data': None}
    }


# Generated at 2022-06-21 08:36:17.852989
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    '''test_JsonRpcServer_internal_error'''

    jsonrpcserver = JsonRpcServer()
    jsonrpcserver.handle_request('{"method": "internal_error"}')


# Generated at 2022-06-21 08:36:20.939911
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrs = JsonRpcServer()
    p = 5
    assert jrs.error(-32700, 'Parse error', p) == jrs.parse_error(p)


# Generated at 2022-06-21 08:36:28.771345
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    # Testing default behavior
    server = JsonRpcServer()
    result = server.parse_error()
    assert result == {
        'jsonrpc': '2.0', 
        'error': {
            'code': -32700, 
            'message': 'Parse error'
        }, 
        'id': None
    }

    # Testing with extra arguments
    server = JsonRpcServer()
    result = server.parse_error('Some data')
    assert result == {
        'jsonrpc': '2.0', 
        'error': {
            'code': -32700, 
            'message': 'Parse error', 
            'data': 'Some data'
        }, 
        'id': None
    }


# Generated at 2022-06-21 08:36:35.009880
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    test = JsonRpcServer()
    setattr(test, '_identifier', 1)
    result = test.error(code=-32603, message='Internal error', data=None)
    assert result == {'result': None, 'error': {'message': 'Internal error', 'code': -32603}, 'id': 1, 'jsonrpc': '2.0'}

# Generated at 2022-06-21 08:36:42.340071
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    srv = JsonRpcServer()
    request = {"jsonrpc": "2.0", "method": "rpc._invalid", "id": 1, "params": []}
    response = srv.handle_request(json.dumps(request))
    assert json.loads(response) == {'jsonrpc': '2.0', 'id': 1, 'error': {'code': -32600, 'message': 'Invalid request', 'data': None}}


# Generated at 2022-06-21 08:36:51.303568
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class TestClass(object):
        def __init__(self):
            self.server = JsonRpcServer()
            self.server.register(self)

        def method1(self, *args, **kwargs):
            return args, kwargs

        def show_version(self, *args, **kwargs):
            e = self.server.error(code=100, message="This is an error")
            return e

        def test_error(self):
            req = json.loads("""{
                "jsonrpc": "2.0",
                "method": "show_version",
                "params": [],
                "id": 1}""")

# Generated at 2022-06-21 08:37:01.994352
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test 1: no result
    server = JsonRpcServer()
    server._identifier = 1
    response = server.response()
    assert response == {'jsonrpc': '2.0', 'id': 1}
    # Test 2: result is text
    server = JsonRpcServer()
    server._identifier = 2
    response = server.response('Hello')
    assert response == {'jsonrpc': '2.0', 'id': 2, 'result': 'Hello'}
    # Test 3: result is binary
    server = JsonRpcServer()
    server._identifier = 3
    response = server.response(b'Hello')
    assert response == {'jsonrpc': '2.0', 'id': 3, 'result': 'Hello'}
    # Test 4: result is a JSON object
   

# Generated at 2022-06-21 08:37:13.643665
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import json
    
    # mock 'passthru.runner'
    class Runner(object):
        def __init__(self):
            self.commands = []
            self.results = []
            self.already_run = {}

        def module_args(self):
            return {'_ansible_keep_remote_files': None, '_ansible_no_log': False, '_ansible_remote_tmp': '/tmp'}

        def run(self, command, **kwargs):
            self.commands.append(command)
            if command not in self.already_run:
                self.already_run[command] = True
                result = self.results.pop(0)
                if isinstance(result, Exception):
                    raise result
                return result

    runner = Runner()

# Generated at 2022-06-21 08:37:21.982133
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert hasattr(server, 'handle_request')
    assert hasattr(server, 'register')
    assert hasattr(server, 'header')
    assert hasattr(server, 'response')
    assert hasattr(server, 'error')
    assert hasattr(server, 'parse_error')
    assert hasattr(server, 'method_not_found')
    assert hasattr(server, 'invalid_request')
    assert hasattr(server, 'invalid_params')
    assert hasattr(server, 'internal_error')

# Generated at 2022-06-21 08:37:25.360290
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    assert JsonRpcServer().method_not_found() == \
            {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found', 'data': None}}

# Generated at 2022-06-21 08:37:34.423143
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    response = JsonRpcServer().internal_error()
    assert response[u'jsonrpc'] == u'2.0'
    assert response[u'id'] is None
    assert response[u'error'][u'code'] == -32603
    assert response[u'error'][u'message'] == u'Internal error'
    assert u'data' not in response[u'error']

# Generated at 2022-06-21 08:37:37.062991
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    expected = {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}}
    assert server.invalid_request() == expected



# Generated at 2022-06-21 08:37:39.746515
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    rpc = JsonRpcServer()

    assert rpc._objects == set()
    assert not hasattr(rpc, '_identifier')



# Generated at 2022-06-21 08:37:42.759445
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    # Get the class object
    json_server = JsonRpcServer()
    # Check the instance of the class
    assert isinstance(json_server, JsonRpcServer)
    assert json_server is not None


# Generated at 2022-06-21 08:37:44.225114
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    a = JsonRpcServer()
    a.invalid_request()
    a.internal_error()

# Generated at 2022-06-21 08:37:46.188130
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    # No exception is expected in the initial state:
    server.handle_request('{"jsonrpc": "2.0", "method": "foobar", "params": [1, 2], "id": 1}')

# Generated at 2022-06-21 08:37:50.990762
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    msg = "This is a test"
    data = server.internal_error(data=msg)
    print(data)
    assert data['error']['message'] == msg


# Generated at 2022-06-21 08:37:56.796454
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    assert {'jsonrpc': '2.0', 'id': '123', 'result': 'foo'} == JsonRpcServer().response(result='foo')
    assert {'jsonrpc': '2.0', 'id': '123', 'result': 'foo', 'result_type': 'pickle'} == JsonRpcServer().response(result=b'foo')


# Generated at 2022-06-21 08:38:01.314528
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jsonrpc = JsonRpcServer()
    object1 = {'name': 'object1'}
    object2 = {'name': 'object2'}
    jsonrpc.register(object1)
    jsonrpc.register(object2)

    assert object1 in jsonrpc._objects
    assert object2 in jsonrpc._objects



# Generated at 2022-06-21 08:38:07.140714
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    from tests.unit.mock import Mock

    server = JsonRpcServer()
    attrs = {
        'method_not_found.return_value': {
            'jsonrpc': '2.0', 'id': None, 'error': {
                'code': -32601, 'message': 'Method not found'
            }
        }
    }
    server._identifier = None
    m = Mock(server, attrs)
    m.method_not_found()

    expected = {
        'jsonrpc': '2.0', 'id': None, 'error': {
            'code': -32601, 'message': 'Method not found'
        }
    }
    result = server.method_not_found()

    assert result == expected

# Generated at 2022-06-21 08:38:16.156357
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    request = '{"jsonrpc": "2.0", "params": [42, 23], "method": "subtract", "id": 1}'
    response = server.handle_request(request)
    assert response == '{"jsonrpc": "2.0", "result": 19, "id": 1}'

# Generated at 2022-06-21 08:38:21.682008
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    stub_identifier = 10
    test_JsonRpcServer = JsonRpcServer()
    test_JsonRpcServer._identifier = stub_identifier
    actual_result = test_JsonRpcServer.header()
    except_data = {'jsonrpc': '2.0', 'id': stub_identifier}
    assert actual_result == except_data


# Generated at 2022-06-21 08:38:29.090256
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    try:
        server = JsonRpcServer()
        assert 'Method not found' in server.method_not_found()['error']['message'], "method_not_found method of JsonRpcServer should return Method not found"
    except AssertionError as e:
        print("Unit test for method method_not_found of class JsonRpcServer failed: " + str(e))
        return 0
    print("Unit test for method method_not_found of class JsonRpcServer passed")
    return 1


# Generated at 2022-06-21 08:38:41.064763
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpc = JsonRpcServer()
    # test method response
    response = jsonrpc.handle_request('{"jsonrpc": "2.0", "method": "response", "params": [1,2], "id": 1}')
    assert response == '{"jsonrpc": "2.0", "id": 1, "result": 1, "result_type": "pickle"}'
    # test method error
    response = jsonrpc.handle_request('{"jsonrpc": "2.0", "method": "error", "params": [1,2], "id": 1}')
    assert response == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Internal error"}}'
    # test method parse_error

# Generated at 2022-06-21 08:38:44.451584
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 100)
    assert server.header() == {'jsonrpc':'2.0', 'id':100}
    delattr(server, '_identifier')


# Generated at 2022-06-21 08:38:46.214819
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None


# Generated at 2022-06-21 08:38:56.583549
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest
    import os
    import sys

    class TestJsonRpcServer_handle_request(unittest.TestCase):

        def test_handle_request_one(self):
            server = JsonRpcServer()
            request_dict = {
                "method": "GET",
                "params": [["a"], {"b": "c"}],
                "id": "test_JsonRpcServer_handle_request_one"
            }
            request_str = json.dumps(request_dict)
            response = server.handle_request(request_str)
            response_dict = json.loads(response)

# Generated at 2022-06-21 08:38:59.892507
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    expected_output = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params'}}
    assert JsonRpcServer().invalid_params() == expected_output

# Generated at 2022-06-21 08:39:06.298023
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'jsonrpc_server_test_id')
    result = 'test'
    result_response = server.response(result)
    assert result_response['result'] == result
    assert result_response['id'] == 'jsonrpc_server_test_id'
    assert result_response['jsonrpc'] == '2.0'

# Generated at 2022-06-21 08:39:16.262213
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    
    # instance of JsonRpcServer class
    jsr = JsonRpcServer()
    # init jsonrpc request
    request = '{"jsonrpc": "2.0", "method": "rpc.runTask", "params": ["test_127.0.0.1"], "id": 0}'
    
    method_response = jsr.handle_request(request)
    response = json.loads(method_response)
    code = response.get('error').get('code')
    message = response.get('error').get('message')
    data = response.get('error').get('data')
    
    assert code == -32601
    assert message == 'Method not found'
    assert data == None


# Generated at 2022-06-21 08:39:24.928257
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error == {
        u'jsonrpc': u'2.0',
        u'id': None,
        u'error': {
            u'code': -32600,
            u'message': u'Invalid request',
            u'data': None
        }
    }

# Generated at 2022-06-21 08:39:33.107850
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    ''' Unit test for method invalid_request of class JsonRpcServer '''
    instance = JsonRpcServer()
    instance.handle_request('{"jsonrpc": "2.0", "method": "rpc.some", "params": [1, 2], "id": "1"}')
    assert instance._identifier == "1"
    assert instance.invalid_request() == {
        'error': {'code': -32600, 'message': 'Invalid request'},
        'id': '1',
        'jsonrpc': '2.0'}


# Generated at 2022-06-21 08:39:40.311948
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    obj = JsonRpcServer()
    result = obj.parse_error()
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'

    result = obj.parse_error(data='A parse error')
    assert result['error']['code'] == -32700
    assert result['error']['message'] == 'Parse error'
    assert result['error']['data'] == 'A parse error'


# Generated at 2022-06-21 08:39:46.653218
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    json_server = JsonRpcServer()
    error_response = json_server.invalid_request()
    expected_response = {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32600,
            "message": "Invalid request",
        }
    }
    assert error_response == expected_response


# Generated at 2022-06-21 08:39:55.396820
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print('Running unittest for JsonRpcServer.handle_request')

    s = JsonRpcServer()
    class TestPlugin:
        pass
    t = TestPlugin()
    t.foo = lambda: 42
    s.register(t)

    print('Testing method_not_found')
    result = s.handle_request('''
        {
            "id": 1,
            "method": "bar"
        }
    ''')
    p = json.loads(result)
    assert p['id'] == 1
    assert p['error']['code'] == -32601
    assert p['error']['message'] == 'Method not found'

    print('Testing invalid_request')

# Generated at 2022-06-21 08:40:06.064439
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import ansible.module_utils.connection as connection
    import ansible.module_utils.network.common.utils as module_utils
    from ansible.module_utils.network.common.utils import to_list, ComplexList

    connection.Connection = module_utils.Connection
    _to_list = to_list
    _ComplexList = ComplexList

    class TestNetwork():
        def __init__(self):
            self.facts = {}
        def get_facts(self, *args, **kwargs):
            self.facts['hello?'] = True
            return self.facts

    server = JsonRpcServer()
    server.register(TestNetwork())
    data = {'method': 'get_facts', 'params': [[], {}], 'id': 1}
    result = server.handle_request(json.dumps(data))

# Generated at 2022-06-21 08:40:15.294351
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    obj = JsonRpcServer()
    obj.register(obj)
    error = obj.invalid_params(data="Invalid Params")
    if error == {'error': {'code': -32602, 'message': 'Invalid params', 'data': 'Invalid Params'}, 'jsonrpc': '2.0', 'id': 'None'}:
        print("Unit test for method invalid_params of class JsonRpcServer is passed")
    else:
        print("Unit test for method invalid_params of class JsonRpcServer is failed")

test_JsonRpcServer_invalid_params()


# Generated at 2022-06-21 08:40:19.944861
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    data = '{"error": {"code": -32600, "message": "Invalid request", "data": null}, "id": null}'
    s = JsonRpcServer()
    response = s.invalid_request()
    assert isinstance(response, dict)
    assert response == json.loads(data)

# Generated at 2022-06-21 08:40:24.008561
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_server = JsonRpcServer()
    setattr(json_server, '_identifier', dict())
    assert json_server.header() == {'jsonrpc': '2.0', 'id': dict()}


# Generated at 2022-06-21 08:40:32.871685
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    json_rpc_server = JsonRpcServer()
    json_rpc_server.register(json_rpc_server)

    assert json_rpc_server.handle_request('{"jsonrpc": "2.0", "method": "handle_request", "params": [null], "id": 1}') == '{"jsonrpc": "2.0", "result": "2.0", "id": 1}'
    assert json_rpc_server.handle_request('{"jsonrpc": "2.0", "method": "method_not_found", "params": [null], "id": 1}') == '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}}'


# Generated at 2022-06-21 08:40:42.935191
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    test_value = "test_string"
    obj = JsonRpcServer()
    resp = obj.invalid_params(data=test_value)
    assert resp == {u'jsonrpc': u'2.0', u'id': None, u'error': {u'data': u'test_string', u'code': -32602, u'message': u'Invalid params'}}

# Generated at 2022-06-21 08:40:47.215081
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    response = JsonRpcServer().response('OK')
    assert response["result"] == "OK"
    assert response["id"] == 0
    assert response["jsonrpc"] == "2.0"



# Generated at 2022-06-21 08:40:57.507278
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import pytest
    jrpc = JsonRpcServer()
    # request id is None
    request = { "jsonrpc": "2.0", "method": "test_result", "id": None }
    response = { "jsonrpc": "2.0", "result": "test_result" }
    assert jrpc.handle_request(request) == response
    # request id is valid
    request = { "jsonrpc": "2.0", "method": "test_result", "id": "test" }
    response = { "jsonrpc": "2.0", "result": "test_result", "id": "test" }
    assert jrpc.handle_request(request) == response
    # request method is private

# Generated at 2022-06-21 08:41:06.237972
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    try:
        ret = JsonRpcServer().internal_error()
        assert ret['error']['code'] == -32603
    except AssertionError as e:
        print('\nJsonRpcServer.internal_error test failed: ' + str(e))
        raise e
    except Exception as e:
        print('\nJsonRpcServer.internal_error test failed: ' + str(e))
        raise e
    else:
        print('\nJsonRpcServer.internal_error test passed')

# Generated at 2022-06-21 08:41:12.040424
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    input_json = {
        "jsonrpc": "2.0", "id": 5, "method": "rpc.run", "params": [
            [{"network_os": "mlnxos", "host": "172.20.0.11", "port": 22,
              "username": "admin", "password": "zte9x15!"}],
            "show version"
        ]
    }
    expected_json = {
        "jsonrpc": "2.0", "id": 5, "error": {
            "code": -32600,
            "message": "Invalid request",
            "data": u"Method name must not start with 'rpc.'"
        }
    }

# Generated at 2022-06-21 08:41:20.967793
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    j = JsonRpcServer()
    j.__dict__['_identifier'] = '1bd9a7b9-d5aa-44b1-8f62-7bf2d8b4eb7d'
    assert j.method_not_found() == {'id': '1bd9a7b9-d5aa-44b1-8f62-7bf2d8b4eb7d', 'jsonrpc': '2.0', 'error': 
    {'code': -32601, 'message': 'Method not found'}}


# Generated at 2022-06-21 08:41:24.201619
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    a = JsonRpcServer()
    result = a.parse_error()
    assert result == {'error': {'code': -32700, 'data': None, 'message': 'Parse error'}, 'jsonrpc': '2.0'}


# Generated at 2022-06-21 08:41:29.973475
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():

    from ansible.module_utils.common._collections_compat import Mapping

    class Dummy(object):
        def method_found(self):
            return None

    bases = [json.JSONDecoder, json.JSONEncoder, Mapping, JsonRpcServer]
    bases += [type(x) for x in Dummy.__mro__]
    c = type('Dummy', bases, {})()

    c.register(Dummy())
    c.handle_request(json.dumps({'id': '7', 'method': 'method_not_found', 'params': [], 'jsonrpc': '2.0'}))

# Generated at 2022-06-21 08:41:34.863122
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    obj = JsonRpcServer()
    obj._identifier = 1
    result = obj.header()
    # Assertion for method header of class JsonRpcServer
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 1


# Generated at 2022-06-21 08:41:39.477863
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert obj is not None

if __name__ == '__main__':
    obj = JsonRpcServer()

    request = json.dumps({'jsonrpc': '2.0', 'params': [], 'id': 0, 'method': 'test'})

    response = obj.handle_request(request)
    print(response)

# Generated at 2022-06-21 08:41:58.868983
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    response =  server.error('-32601', 'Method not found')
    expected = {'jsonrpc': '2.0', 'result': None, 'id': '1', 'error': {'code': '-32601', 'message': 'Method not found'}}
    assert response == expected

# Generated at 2022-06-21 08:42:04.042548
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    mydevice = {'host': '1.1.1.1', 'username': 'u', 'password': 'p'}
    rpc_server = JsonRpcServer()
    rpc_server.register(mydevice)
    expected_objects = [{'username': 'u', 'password': 'p', 'host': '1.1.1.1'}]
    assert rpc_server._objects == set(expected_objects)


# Generated at 2022-06-21 08:42:07.645949
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    a = JsonRpcServer()
    a._identifier = 1234
    assert a.header() == {'jsonrpc': '2.0', 'id': 1234}


# Generated at 2022-06-21 08:42:10.973743
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    jsonrpc = JsonRpcServer()
    assert jsonrpc.internal_error(data=None) == {'jsonrpc': '2.0', 'id': jsonrpc._identifier, 'error': {'code': -32603, 'message': 'Internal error'}}

# Generated at 2022-06-21 08:42:11.852309
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    obj = JsonRpcServer()
    assert obj

# Generated at 2022-06-21 08:42:15.407990
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    header = server.header()
    assert header == {'jsonrpc': '2.0', 'id': server._identifier}


# Generated at 2022-06-21 08:42:18.810232
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    resp = JsonRpcServer().error(-32603, 'Internal error')
    assert resp == {'id': None, 'jsonrpc': '2.0', 'error': {'message': 'Internal error', 'code': -32603}}

# Generated at 2022-06-21 08:42:22.505245
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error()
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32603, 'message': 'Internal error'}, 'id': None}

# Generated at 2022-06-21 08:42:25.459493
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    jserv = JsonRpcServer()
    response = jserv.method_not_found()
    assert response['error']['code'] == -32601
    assert response['error']['message'] == 'Method not found'


# Generated at 2022-06-21 08:42:28.487842
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
   a = JsonRpcServer()
   assert len(a._objects) == 0
   obj = type('obj', (), {})()
   a.register(obj)
   assert len(a._objects) == 1


# Generated at 2022-06-21 08:42:58.574868
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = '1234'
    expected = {'jsonrpc':'2.0','result':"value",'id':'1234'}
    actual = server.response('value')
    assert expected == actual

# Generated at 2022-06-21 08:43:02.360113
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_rpc = JsonRpcServer()
    setattr(json_rpc, '_identifier', 'my_identifier')
    assert json_rpc.header() == {'jsonrpc': '2.0', 'id': 'my_identifier'}
    delattr(json_rpc, '_identifier')


# Generated at 2022-06-21 08:43:05.858025
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()

# Generated at 2022-06-21 08:43:10.337769
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    message = 'SUCCESSFULLY INSTALLED'
    error = server.internal_error(data=message)['error']
    assert error['code'] == -32603
    assert error['message'] == 'Internal error'
    assert error['data'] == message

# Generated at 2022-06-21 08:43:12.683444
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    JsonRpcServer = JsonRpcServer()
    assert JsonRpcServer.response() == {'jsonrpc': '2.0', 'id': None, 'result': None}

# Generated at 2022-06-21 08:43:17.395048
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    request = {
        "id": "1",
        "method": "test_method",
        "params": [
        [
            "test",
            "this",
            "out"
        ],
        {
            "more": "params"
        }
        ]
    }
    response = json.loads(server.handle_request(json.dumps(request)))
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32602

# Generated at 2022-06-21 08:43:21.047950
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    test_string = '{"jsonrpc": "2.0", "method": "update", "params": ["foo", "bar"], "id": 1}'
    assert '"id": 1' in JsonRpcServer().handle_request(test_string)

# Generated at 2022-06-21 08:43:24.489202
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    ret = server.invalid_params()

# Generated at 2022-06-21 08:43:28.783859
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32601,
            'message': 'Method not found'
        }
    }

# Generated at 2022-06-21 08:43:30.715617
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    r = JsonRpcServer()
    r._identifier = None
    r.parse_error()


# Generated at 2022-06-21 08:44:04.731608
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    """
    Unit test for method invalid_params of class JsonRpcServer.
    """
    # Create a new instance of the object
    js = JsonRpcServer()
    js._identifier = 1
    assert js._identifier == 1
    # Call the method invalid_params
    error = js.invalid_params(data=None)
    assert error["id"] == 1
    assert error["error"]["code"] == -32602
    assert error["error"]["message"] == "Invalid params"
    assert error["error"]["data"] == None
    assert error["jsonrpc"] == "2.0"


# Generated at 2022-06-21 08:44:08.534964
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0', 'id': None}
    server._identifier = 3
    assert server.header() == {'jsonrpc': '2.0', 'id': 3}
    del server._identifier
    assert server.header() == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-21 08:44:14.654848
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    request = {'method': 'system.version'}
    server = JsonRpcServer()
    setattr(server, '_identifier', '22')
    response = server.header()
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == '22'



# Generated at 2022-06-21 08:44:17.000818
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    JsonRpcServer_response = JsonRpcServer()
    result = JsonRpcServer_response.response()
    return result


# Generated at 2022-06-21 08:44:19.848868
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    ret = server.invalid_request()
    assert ret == {'jsonrpc': '2.0', 'error': {'message': 'Invalid request', 'code': -32600}, 'id': None}

# Generated at 2022-06-21 08:44:24.267771
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    request = {'id': 1}
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    response = server.header()
    assert response == {'jsonrpc': '2.0', 'id': 1}


# Generated at 2022-06-21 08:44:33.857140
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils.connection import _load_params

    obj = _load_params()
    server = JsonRpcServer()
    server.register(obj)

    result = {'content': {'name': 'example'}}
    # result = {'content': 'example'}
    response = server.response(result)
    assert response == {'jsonrpc': '2.0', 'id': '2df2d1a2-6a83-11e7-8bc8-080027d10022', 'result': 'c2V0KCduYW1lJywgJ2V4YW1wbGUnKQ=='}


# Generated at 2022-06-21 08:44:37.637708
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    console = JsonRpcServer()
    response = console.error(0, "test message", "test data")
    assert response['error'] == {
        'code': 0,
        'data': 'test data',
        'message': 'test message'
        }


# Generated at 2022-06-21 08:44:39.457616
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    try:
        assert JsonRpcServer().handle_request("{}")
    except ImportError:
        pass

# Generated at 2022-06-21 08:44:43.091712
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    JsonRpcServer_obj = JsonRpcServer()
    result = JsonRpcServer_obj.header()
    assert result == {'jsonrpc': '2.0', 'id': 1}
