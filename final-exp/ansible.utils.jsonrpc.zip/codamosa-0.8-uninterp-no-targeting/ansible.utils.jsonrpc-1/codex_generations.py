

# Generated at 2022-06-21 08:35:18.777262
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    initial_object_count = len(server._objects)
    test_object = {'test_object_id': 'test_object_value'}
    server.register(test_object)
    assert len(server._objects) == initial_object_count + 1


# Generated at 2022-06-21 08:35:20.100271
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    # TODO: why is this test so complicated?
    pass

# Generated at 2022-06-21 08:35:22.746409
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsrpc = JsonRpcServer()
    ans = jsrpc.invalid_params()
    assert ans['error']['code'] == -32602

# Generated at 2022-06-21 08:35:28.422962
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert hasattr(JsonRpcServer(), 'handle_request')
    assert hasattr(JsonRpcServer(), 'register')
    assert hasattr(JsonRpcServer(), 'header')
    assert hasattr(JsonRpcServer(), 'response')
    assert hasattr(JsonRpcServer(), 'error')
    assert hasattr(JsonRpcServer(), 'internal_error')

# Generated at 2022-06-21 08:35:33.199622
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    my_class = JsonRpcServer()
    setattr(my_class, '_identifier', '1234')
    test_result = my_class.header()
    assert test_result == {'jsonrpc': '2.0', 'id': '1234'}



# Generated at 2022-06-21 08:35:37.134533
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 5)
    header = server.header()
    assert header == {'jsonrpc': '2.0', 'id': 5}
    delattr(server, '_identifier')


# Generated at 2022-06-21 08:35:44.201784
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    try:
        from module_utils.connection import Connection
        from ansible.module_utils.network.common.utils import to_list
    except:
        module = None
    else:
        module = Connection("localhost")

    class TestModule(object):
        def __init__(self, module=None):
            self.module = module
            self.params = {'provider': None}
            self.check_mode = False
            self.fail_json = None
            self.check_result = None
            self.json_rpc_server = JsonRpcServer()

        def run_command(self, *args, **kwargs):
            commands = args[0]
            return self.command(commands)

        def command(self, command):
            self.json_rpc_server.register(self.module)


# Generated at 2022-06-21 08:35:50.786862
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1')
    response = server.error(code=-32603, message='Internal error')
    assert response == {'jsonrpc': '2.0', 'id': '1', 'error': {'code': -32603, 'message': 'Internal error'}}
    delattr(server, '_identifier')

# Generated at 2022-06-21 08:35:54.296798
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    result = JsonRpcServer().header()
    assert result == {'jsonrpc': '2.0', 'id': None}


# Generated at 2022-06-21 08:36:03.397438
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    # Test with a string argument
    data = "Hello World"
    result = JsonRpcServer().response(result=data)
    assert result == {"jsonrpc": "2.0", "result": data, "id": None}

    # Test with a dict argument
    data = {"foo": "blah", "bar": 1234}
    result = JsonRpcServer().response(result=data)
    assert result == {"jsonrpc": "2.0", "result": data, "id": None}

    # Test with a byte argument
    data = u"Hello World".encode('utf-8')
    result = JsonRpcServer().response(result=data)
    assert result == {"jsonrpc": "2.0", "result": "Hello World", "id": None}


# Generated at 2022-06-21 08:36:23.495564
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server.handle_request('{}') == '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'

# Generated at 2022-06-21 08:36:28.004047
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, "_identifier", "foobarbaz")
    response = server.error(-17, "a message", "some data")
    assert response == {'jsonrpc': '2.0',
                        'id': 'foobarbaz',
                        'error': {'code': -17,
                                  'message': 'a message',
                                  'data': 'some data'}}


# Generated at 2022-06-21 08:36:39.953484
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    method_name = 'response'
    setattr(obj, '_identifier', 'test_identifier')
    result = obj.response('test_result')
    response = {u'jsonrpc': u'2.0', u'result': u'test_result', u'id': u'test_identifier'}
    #print(result)
    #print(response)
    if result == response:
        print('%s method response test pass' % (method_name))
    else:
        print('%s method response test fail' % (method_name))


# Generated at 2022-06-21 08:36:45.335510
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    from ansible.module_utils.network.nxos.pycliconf import NXOSPycliConf
    conftest = JsonRpcServer()
    obj = NXOSPycliConf()
    JsonRpcServer._objects.clear()
    assert not JsonRpcServer._objects
    conftest.register(obj)
    assert obj in JsonRpcServer._objects


# Generated at 2022-06-21 08:36:49.410946
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    print('Test JsonRpcServer.handle_request()')
    jrpcs = JsonRpcServer()
    request = {
        "jsonrpc": "2.0",
        "method": "test_JsonRpcServer_handle_request",
        "params": [],
        "id": 0
    }
    result = jrpcs.handle_request(json.dumps(request))
    print('result:', result)
    

# Generated at 2022-06-21 08:36:55.363031
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    obj1 = object()
    obj2 = object()
    server = JsonRpcServer()
    server.register(obj1)
    assert server._objects == set([obj1])
    server.register(obj2)
    assert server._objects == set([obj1, obj2])


# Generated at 2022-06-21 08:36:59.944052
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    setattr(server, '_identifier', 0)
    method_not_found = server.method_not_found()
    method_not_found = json.loads(json.dumps(method_not_found))
    assert method_not_found['error']['code'] == -32601


# Generated at 2022-06-21 08:37:06.677467
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    json_rpc_server_obj = JsonRpcServer()
    json_rpc_server_obj._identifier = 'test_id'
    result = json_rpc_server_obj.response()
    assert result == {
        'jsonrpc': '2.0',
        'id': 'test_id',
        'result': None
    }
    result = json_rpc_server_obj.response("test_result")
    assert result == {
        'jsonrpc': '2.0',
        'id': 'test_id',
        'result': 'test_result'
    }
    result = json_rpc_server_obj.response("\x80\x03X\x0b\x00\x00\x00hello worldq\x00.")

# Generated at 2022-06-21 08:37:12.762623
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    js = JsonRpcServer()
    message="some message"
    data="some data"
    result=js.invalid_params(data=data)
    assert (result['jsonrpc'] == '2.0')
    assert (result['error']['code'] == -32602)
    assert (result['error']['message'] == message)
    assert (result['error']['data'] == data)
    assert (result['id'] == None)


# Generated at 2022-06-21 08:37:15.561301
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    j = JsonRpcServer()
    class A(object):
        def test_method(self):
            return "test_method"
    obj = A()
    j.register(obj)
    assert 'test_method' in dir(obj)


# Generated at 2022-06-21 08:37:25.173429
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import json
    from ansible.module_utils.json_rpc_server import JsonRpcServer
    json_rpc = JsonRpcServer()
    response = json_rpc.internal_error('test_data')
    assert response['error']['code'] == -32603
    assert response['error']['message'] == 'Internal error'
    assert response['error']['data'] == 'test_data'



# Generated at 2022-06-21 08:37:28.972375
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    assert server.invalid_request() == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": -32600,
            "message": "Invalid request"
        }
    }

# Generated at 2022-06-21 08:37:35.498738
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    server = JsonRpcServer()
    _id = '123'
    setattr(server, '_identifier', _id)

    expected_response = {'jsonrpc': '2.0', 'id': _id,
                         'error': {'code': -32601,
                                   'message': 'Method not found',
                                   'data': None}}

    response = server.method_not_found()
    assert response == expected_response
    assert isinstance(response['error']['code'], int)



# Generated at 2022-06-21 08:37:42.718057
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    rpc_server = JsonRpcServer()
    setattr(rpc_server, '_identifier', 10)
    result = {
        "result_type": "pickle",
        "result": "gAN9cQAoVQBuAC4AcwB3AG4AbABvAHEAKABzADoALwBlAHgAdAAuAHcAaQB0AGgAIAB0AGUAcwB0ACgA",
        "jsonrpc": "2.0",
        "id": 10
    }
    assert rpc_server.response() == result

# Generated at 2022-06-21 08:37:45.379148
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    result = JsonRpcServer().invalid_request()
    assert result == {'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request'}, 'id': None}


# Generated at 2022-06-21 08:37:47.378789
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    server._identifier = 1
    print(server.internal_error())


# Generated at 2022-06-21 08:37:53.468217
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()
    expected_output = '{"error": {"code": -32600, "message": "Invalid request"}, "id": null, "jsonrpc": "2.0"}'
    assert rpc_server.invalid_request() == json.loads(expected_output)

# Generated at 2022-06-21 08:37:58.003276
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    j = JsonRpcServer()
    text = {'hello': 'world'}
    result = j.response(result=text)
    assert result == {'jsonrpc': '2.0',
                      'id': None,
                      'result': "{'hello': 'world'}",
                      'result_type': "pickle"}


# Generated at 2022-06-21 08:38:05.763294
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    request = '{"jsonrpc": "2.0", "method": "rpc_echo", "params": ["hello"], "id": 1234}'
    response = json.loads(server.handle_request(request))
    assert response["error"]["code"] == -32601
    assert response["error"]["message"] == 'Method not found'

    request = '{"jsonrpc": "2.0", "method": "invalid_request", "params": ["hello"], "id": 1234}'
    response = json.loads(server.handle_request(request))
    assert response["error"]["code"] == -32600
    assert response["error"]["message"] == 'Invalid request'


# Generated at 2022-06-21 08:38:10.118055
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    rpc_server = JsonRpcServer()
    request = {"jsonrpc": "2.0", "method": "rpc.test"}
    assert rpc_server.handle_request(request) == "{}"


# Generated at 2022-06-21 08:38:21.762141
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    JsonRpcServer1 = JsonRpcServer()
    class TestClass:
        def test_method(self, arg1, arg2):
            print(arg1, arg2)
    TestClass1 = TestClass()
    JsonRpcServer1.register(TestClass1)
    setattr(JsonRpcServer1, '_identifier', '1')
    request = {u"jsonrpc": u"2.0", u"method": u"test_method", u"params": [u"arg1", u"arg2"], u"id": u"1"}
    JsonRpcServer1.handle_request(request)
    return True

# Generated at 2022-06-21 08:38:22.899757
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert JsonRpcServer()

# Generated at 2022-06-21 08:38:26.160551
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    obj._identifier = 2
    assert obj.response({"foo": "bar"}) == {'jsonrpc': '2.0', 'result': {"foo": "bar"}, 'id': 2}


# Generated at 2022-06-21 08:38:31.836285
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    json_rpc_server = JsonRpcServer()
    error = json_rpc_server.parse_error()
    assert error == {
        "error": {
            "code": -32700,
            "message": "Parse error"
        },
        "id": None,
        "jsonrpc": "2.0"
    }


# Generated at 2022-06-21 08:38:43.529497
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from ansible.module_utils.network.common.utils import to_bytes
    obj = JsonRpcServer()
    obj._identifier = "123"
    json_out = obj.header()
    assert json_out["jsonrpc"] == "2.0"
    assert json_out["id"] == "123"
    assert len(json_out) == 2
    # Method header expects that json_out will be str
    # In this case we will get b'{"jsonrpc": "2.0", "id": "123"}'
    assert obj.header() == to_bytes('{"jsonrpc": "2.0", "id": "123"}')
    # Create dict with bytes values

# Generated at 2022-06-21 08:38:49.530677
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    expected = '{"jsonrpc": "2.0", "id": "bogus", "error": {"code": -32600, "message": "Invalid request"}}'
    request = JsonRpcServer()
    setattr(request, '_identifier', 'bogus')
    actual = json.dumps(request.invalid_request())
    assert actual == expected



# Generated at 2022-06-21 08:38:56.486152
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    assert JsonRpcServer().error(1, 'test') == {'jsonrpc': '2.0',
                                               'id': None, 'error': {'code': 1,
                                                                     'message': 'test'}}
    assert JsonRpcServer().error(1, 'test', 'data') == {'jsonrpc': '2.0',
                                                        'id': None, 'error': {'code': 1,
                                                                              'message': 'test',
                                                                              'data': 'data'}}

# Generated at 2022-06-21 08:38:59.550227
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    x = JsonRpcServer()
    d = {'id': None, 'jsonrpc': '2.0'}
    x.handle_request(json.dumps(d))
    assert x.header() == d


# Generated at 2022-06-21 08:39:11.021012
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    def func1():
        return 'result1'

    def func2(arg1, arg2):
        return arg1 * arg2

    def func3(arg1):
        return {'jsonrpc': '2.0', 'id': 1, 'result': arg1 * 3}

    def func4(arg1):
        raise ConnectionError('code1', 'message1', 'data1')

    def func5(arg1):
        raise Exception('error message')

    class Dummy:
        pass

    obj = Dummy()

    obj.func1 = func1
    obj.func2 = func2
    obj.func3 = func3
    obj.func4 = func4
    obj.func5 = func5

    server = JsonRpcServer()

    server.register(obj)

    # test case 1: simple result

# Generated at 2022-06-21 08:39:14.732328
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServer = JsonRpcServer()
    response = jsonRpcServer.invalid_params()
    if response['error']['code'] == -32602:
        pass
    else:
        raise Exception(response['error']['code'])


# Generated at 2022-06-21 08:39:25.309145
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(code='test_code', message='test_message')
    assert result == {'jsonrpc': '2.0', 'id': None, 'error': {'code': 'test_code', 'message': 'test_message'}}

# Generated at 2022-06-21 08:39:27.574725
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    error = server.invalid_request()
    assert error["error"]["code"] == -32600
    assert error["error"]["message"] == "Invalid request"


# Generated at 2022-06-21 08:39:29.749709
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    print(server.error(code=300, message='message'))

# Generated at 2022-06-21 08:39:34.108716
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', '1234')
    result = server.error(code=1, message='test')
    assert result['error']['code'] == 1
    assert result['error']['message'] == 'test'
    assert result['id'] == '1234'
    assert result['jsonrpc'] == '2.0'

# Generated at 2022-06-21 08:39:45.818229
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    exp_result = '{"jsonrpc": "2.0", "id": "abc", "error": {"code": -32600, "message": "Invalid request", "data": "def"}}'
    obj = JsonRpcServer()
    setattr(obj, '_identifier', 'abc')
    assert obj.invalid_request('def') == exp_result
    delattr(obj, '_identifier')
    exp_result = '{"jsonrpc": "2.0", "id": "abc", "error": {"code": -32600, "message": "Invalid request"}}'
    setattr(obj, '_identifier', 'abc')
    assert obj.invalid_request() == exp_result
    delattr(obj, '_identifier')

# Generated at 2022-06-21 08:39:48.513599
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonRpcServer = JsonRpcServer()
    response = jsonRpcServer.error(-32603, 'Internal error', data="testdata")
    assert response == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error', 'data': 'testdata'}}


# Generated at 2022-06-21 08:39:58.490762
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    from ansible.module_utils import basic

    args = dict(
        _ansible_no_log=False,
        ansible_loop_var=None,
        ansible_module_name=None,
        ansible_module_args=None,
        ansible_play_hosts=None,
        ansible_verbosity=None,
        ansible_version=None,
        ansible_facts=None,
        ansible_host=None,
    )

    obj = basic.AnsibleModule(**args)
    obj._ansible_verbosity = 5
    obj._ansible_debug = True

    response = JsonRpcServer()
    response.register(obj)

    result = dict(
        changed=True,
        skipped=False,
        msg=''
    )
    res = response.response

# Generated at 2022-06-21 08:40:06.626280
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    JsonRpcServer = __import__('ansible.module_utils.connection.JsonRpcServer').connection.JsonRpcServer
    jrpc = JsonRpcServer()
    rpc = '{"jsonrpc": "2.0", "method": "rpc._rpc", "params": [], "id": 0}'
    error = jrpc.handle_request(rpc)
    error = json.loads(error)
    assert error['error']['code'] == -32600
    assert error['error']['message'] == 'Invalid request'
    assert error['error']['data'] == None


# Generated at 2022-06-21 08:40:13.015595
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = 1
    response = jsonrpc_server.error(code=3, message="test error message")
    expected_response = {"jsonrpc": "2.0", "id": 1, "error": {"code": 3, "message": "test error message"}}
    assert response == expected_response

# Generated at 2022-06-21 08:40:14.428706
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    assert isinstance(JsonRpcServer(), JsonRpcServer)

# Generated at 2022-06-21 08:40:33.718389
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    result = {'host': 'localhost', 'port': 22, 'username': 'admin', 'password': 'admin'}
    _jsonrpc_server_obj = JsonRpcServer()
    response = _jsonrpc_server_obj.response(result)
    # The below is the expected result

# Generated at 2022-06-21 08:40:43.582856
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonRpcServer = JsonRpcServer()
    jsonRpcServer._identifier = "id"
    result = jsonRpcServer.response("test")
    assert result["result"] == "test"
    result = jsonRpcServer.response({"a":"b"})
    assert "result_type" not in result
    result = jsonRpcServer.response(binary_type("test"))
    assert result["result"] == "test"
    cPickle.loads(cPickle.dumps({"a":"b"}, protocol=0))
    result = jsonRpcServer.response({"a":"b"})
    assert result["result_type"] == "pickle"
    assert result["result"] == "cos\n.(S'a'\np0\nS'b'\np1\ntp2\n."

# Generated at 2022-06-21 08:40:49.025591
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {
        'id': None,
        'jsonrpc': '2.0',
        'error': {
            'code': -32601,
            'message': 'Method not found'
        }
    }


# Generated at 2022-06-21 08:40:53.402878
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 123)
    result = server.response(result={'a': 'b'})
    assert result == {'jsonrpc': '2.0', 'id': 123, 'result': {'a': 'b'}}


# Generated at 2022-06-21 08:40:57.194790
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    print("\n"+'Unit test for method invalid_request of class JsonRpcServer')
    result = JsonRpcServer().invalid_request()
    print(result)
    assert result['error']['message'] == 'Invalid request'


# Generated at 2022-06-21 08:40:58.936554
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server=JsonRpcServer()

# Generated at 2022-06-21 08:41:04.077292
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    s = JsonRpcServer()
    msg = 'error'
    assert s.error(-32700, msg) == {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': msg}}



# Generated at 2022-06-21 08:41:11.220453
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    request = '{"jsonrpc": "2.0", "method": "say_hello", "params": ["Peter"], "id": "1"}'

    def say_hello(name):
        return 'Hello %s' % name

    j = JsonRpcServer()
    j.register(say_hello)
    response = j.handle_request(request)
    response = response.strip()
    assert response == '{"jsonrpc": "2.0", "id": "1", "result": "Hello Peter"}'

    def none():
        pass

    j = JsonRpcServer()
    j.register(none)
    response = j.handle_request(request)
    response = json.loads(response)
    assert 'error' in response
    assert response.get('error', {}).get('code') == -32601

# Generated at 2022-06-21 08:41:18.736127
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    j = JsonRpcServer()
    j._identifier = 1
    response = j.parse_error("Error")
    assert response['jsonrpc'] == '2.0'
    assert response['id'] == 1
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'
    assert response['error']['data'] == "Error"


# Generated at 2022-06-21 08:41:19.801621
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()


# Generated at 2022-06-21 08:41:49.438185
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    expected = dict()
    expected['jsonrpc'] = '2.0'
    expected['id'] = '1'
    expected['error'] = dict()
    expected['error']['code'] = -32700
    expected['error']['message'] = 'Parse error'
    expected['error']['data'] = None
    assert expected == JsonRpcServer().parse_error()


# Generated at 2022-06-21 08:41:53.843851
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    j._identifier='12345'
    header = j.header()
    assert header.get('jsonrpc') == '2.0'
    assert header.get('id') == 12345

# Generated at 2022-06-21 08:41:57.275798
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    assert server.internal_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Internal error'}}

# Generated at 2022-06-21 08:42:01.279433
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    # invalid_params returns an error object with error code -32602
    obj = JsonRpcServer()
    response = obj.invalid_params()
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'

# Generated at 2022-06-21 08:42:04.266779
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    response = JsonRpcServer().parse_error()
    assert response['error'] ==  {'code': -32700, 'message': 'Parse error'}
    assert response['id'] ==  None
    assert response['jsonrpc'] == '2.0'


# Generated at 2022-06-21 08:42:08.697808
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'foo')
    result = server.header()
    assert type(result) is dict
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'foo'

# Generated at 2022-06-21 08:42:12.382436
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
	assert JsonRpcServer().invalid_request() == {
		'jsonrpc': '2.0',
		'id': '',
		'error': {
			'code': -32600,
			'message': 'Invalid request',
			'data': None
		}
	}

# Generated at 2022-06-21 08:42:17.951856
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
      #Create an object of JsonRpcServer
      test_obj = JsonRpcServer()
      #Create a request
      request = {"method":"test_method", "id": "test_id"}
      #Call the method handle_request on the object created above
      response = test_obj.handle_request(request)
      #Print the response
      print(response)



# Generated at 2022-06-21 08:42:22.787428
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    jsonRpcServer = JsonRpcServer()
    result = jsonRpcServer.invalid_params()
    expected = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32602, 'message': 'Invalid params', 'data': None}}
    assert result == expected


# Generated at 2022-06-21 08:42:26.468444
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jsonrpc = JsonRpcServer()
    request = {}
    actual = jsonrpc.handle_request(request)
    expected = '{"jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request"}, "id": null}'
    assert actual == expected


# Generated at 2022-06-21 08:43:37.271432
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    t = JsonRpcServer()
    t._identifier = 123
    assert t.invalid_params() == {
        'jsonrpc': '2.0',
        'id': 123,
        'error': {
            'code': -32602,
            'message': 'Invalid params',
        }
    }


# Generated at 2022-06-21 08:43:44.092107
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    import unittest
    import json
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest2

    class TestJsonRpcServerError(unittest2.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()

        def test_error(self):
            response = self.server.error(code=-32700, message='Parse error', data='Boom')
            self.assertEqual(json.loads(json.dumps(response)), {"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error", "data": "Boom"}, "id": self.server._identifier})

    return unittest.TestLoader().loadTestsFromTestCase(TestJsonRpcServerError)


# Generated at 2022-06-21 08:43:49.340521
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    rpc_server = JsonRpcServer()
    rpc_server.register(rpc_server)

    request = b'{"jsonrpc": "2.0", "method": "rpc.parse_error", "params": [1,2,3], "id": 1}'
    response = b'{"error": {"code": -32700, "message": "Parse error"}, "jsonrpc": "2.0", "id": 1}'

    assert rpc_server.handle_request(request) == response


# Generated at 2022-06-21 08:43:52.923630
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'devnet_123')
    assert server.header() == {'jsonrpc': '2.0', 'id': 'devnet_123'}


# Generated at 2022-06-21 08:44:04.253098
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    data_type = [
        None,
        "hello world",
        0,
        True,
        [0, 1, 2, 3],
        {'a':1, 'b':2}
    ]

    server = JsonRpcServer()
    server._identifier = 1
    response = server.response(data_type[0])
    assert response == {'id': 1, 'jsonrpc': '2.0', 'result': None}

    response = server.response(data_type[1])
    assert response == {'id': 1, 'jsonrpc': '2.0', 'result': 'hello world'}

    response = server.response(data_type[2])
    assert response == {'id': 1, 'jsonrpc': '2.0', 'result': 0}

    response = server.response

# Generated at 2022-06-21 08:44:08.961681
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    res = JsonRpcServer.response(None, "test")
    assert res == {'id': 'test', 'jsonrpc': '2.0', 'result': 'None'}
    res = JsonRpcServer.response(None, "test", result_type="pickle")
    assert res == {'id': 'test', 'jsonrpc': '2.0', 'result': 'gAN9cQAoVQ==\n', 'result_type': 'pickle'}


# Generated at 2022-06-21 08:44:13.788549
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    rpc_server = JsonRpcServer()
    rpc_server.handle_request(b'{"jsonrpc": "2.0", "method": "error"}')


# Generated at 2022-06-21 08:44:16.190543
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    result = server.method_not_found()["error"]["code"] == -32601
    assert result == True

# Generated at 2022-06-21 08:44:20.641082
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():

    print("start test_JsonRpcServer_invalid_request")
    test_server = JsonRpcServer()
    assert test_server.invalid_request() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32600, 'message': 'Invalid request'}}
    print("end test_JsonRpcServer_invalid_request")


# Generated at 2022-06-21 08:44:28.007166
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "echo",
        "params": ["hello"]
    })
    server = JsonRpcServer()
    server.register(server)
    response = json.loads(server.handle_request(request))
    assert response == {
        "jsonrpc": "2.0",
        "id": 1,
        "result": "hello"
    }