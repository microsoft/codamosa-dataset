

# Generated at 2022-06-21 08:35:16.195535
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    response = server.internal_error(data="test")
    assert response == {'error': {'code': -32603, 'message': 'Internal error', 'data': 'test'},
                        'id': None, 'jsonrpc': '2.0'}



# Generated at 2022-06-21 08:35:21.151141
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    result = server.invalid_params('invalid')
    assert result == {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params", "data": "invalid"}}

# Generated at 2022-06-21 08:35:24.997256
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jrs = JsonRpcServer()

    class Resource:
        def __init__(self):
            self.test = 'test'

    r = Resource()
    jrs.register(r)
    assert r in jrs._objects


# Generated at 2022-06-21 08:35:29.584351
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    assert server.invalid_request() == {u'id': None, u'error': {u'code': -32600, u'message': u'Invalid request'}, u'jsonrpc': u'2.0'}


# Generated at 2022-06-21 08:35:31.460498
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server.register(server)
    assert obj in server._objects


# Generated at 2022-06-21 08:35:41.102188
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    ''' Unit test for method error of class JsonRpcServer '''
    server = JsonRpcServer()
    setattr(server, '_identifier', 'ABC-123')

    response = server.error(code=123, message='test message')
    assert response == {'jsonrpc': '2.0', 'error': {'code': 123, 'message': 'test message'}, 'id': 'ABC-123'}

    response = server.error(code=1234, message='test message', data='this is data')
    assert response == {'jsonrpc': '2.0', 'error': {'code': 1234, 'message': 'test message', 'data': 'this is data'}, 'id': 'ABC-123'}
    delattr(server, '_identifier')


# Generated at 2022-06-21 08:35:46.053894
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    server._identifier = 0
    result = server.parse_error()
    assert result == {'id': 0, 'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}}


# Generated at 2022-06-21 08:35:51.891114
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    response = server.invalid_params('data')

    assert response['id'] == None
    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == -32602
    assert response['error']['message'] == 'Invalid params'
    assert response['error']['data'] == 'data'

# Generated at 2022-06-21 08:35:56.133371
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    from nose.tools import assert_equals
    server = JsonRpcServer()
    server._identifier = '123'
    result = server.header()
    assert_equals(result, {'jsonrpc': '2.0', 'id': '123'})


# Generated at 2022-06-21 08:35:59.760038
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    obj = JsonRpcServer()
    response = obj.parse_error()
    assert response['error']['code'] == -32700
    assert response['error']['message'] == 'Parse error'


# Generated at 2022-06-21 08:36:13.688963
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    import json
    import jsonrpclib
    import unittest

    class TestClass(object):
        pass

    class TestCase(unittest.TestCase):
        def test_simple(self):
            server = JsonRpcServer()
            server.register(TestClass())
            request = json.dumps({
                'jsonrpc': '2.0',
                'id': 1,
                'method': 'method_not_found',
            })
            response = json.loads(server.handle_request(request))
            expected = json.loads(jsonrpclib.dumps({
                'jsonrpc': '2.0',
                'id': 1,
                'error': {
                    'code': -32601,
                    'message': 'Method not found'
                }
            }))
            self

# Generated at 2022-06-21 08:36:19.303370
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    setattr(server, '_identifier', 1)
    error = server.error(code=1, message='test')
    expected = {
        'jsonrpc': '2.0',
        'id': 1,
        'error': {
            'code': 1,
            'message': 'test'
        }
    }
    assert error == expected

# Generated at 2022-06-21 08:36:28.206608
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', 3)
    response = server.response('response')
    assert json.dumps(response) == '{"jsonrpc": "2.0", "id": 3, "result": "response"}'

    response = server.response(b'response')
    assert json.dumps(response) == '{"jsonrpc": "2.0", "id": 3, "result": "response"}'

    response = server.response([1, 2])

# Generated at 2022-06-21 08:36:35.057730
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():

    t = JsonRpcServer()
    setattr(t, '_identifier', "59c4531a8f3dg")

    val = t.invalid_params()
    assert val == {'jsonrpc': '2.0', 'id': '59c4531a8f3dg', 'error': {'code': -32602, 'message': 'Invalid params'}}



# Generated at 2022-06-21 08:36:43.764860
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    import sys
    import os
    import pytest
    src = os.path.join(os.path.dirname(__file__), '../../')
    sys.path.append(src)
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.json_rpc import JsonRpcServer

    with pytest.raises(AttributeError) as exc:
        result = JsonRpcServer().internal_error(data="test_data")

    assert exc.value.args[0] == 'data'

# Generated at 2022-06-21 08:36:47.069995
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    jsonrpcserver = JsonRpcServer()
    result = jsonrpcserver.header()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == getattr(jsonrpcserver, '_identifier')
    assert len(result) == 2


# Generated at 2022-06-21 08:36:57.029693
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    """Unit test for method method_not_found of class JsonRpcServer"""

    # Setup test environment
    obj = JsonRpcServer()
    obj.register(obj)

    # Perform the test
    response = obj.handle_request(b'{"jsonrpc": "2.0", "method": "not_found", "id": "1234567"}')
    result = json.loads(response)

    # Check the results
    assert result["jsonrpc"] == "2.0"
    assert result["error"]["code"] == -32601
    assert result["error"]["message"] == "Method not found"

# Generated at 2022-06-21 08:37:05.165892
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():

    # class JsonRpcServer definition
    class JsonRpcServer:

        def __init__(self):
            self._identifier = None

        def header(self):
            return {"jsonrpc": "2.0", "id": self._identifier}


    # function definition(s)
    def run_module():
        # define available arguments/parameters a user can pass to the module
        module_args = dict()
        module_args.update(
            dict(
            )
        )

# Generated at 2022-06-21 08:37:14.868903
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_rpc = JsonRpcServer()

    setattr(test_rpc, '_identifier', 1)

    result_string = '{"test_string": "string"}'
    response = test_rpc.response(result=result_string)
    assert response["result"] == '"{\\"test_string\\": \\"string\\"}"'
    assert response["id"] == 1

    result_dict = {'test_dict': 'dict'}
    response = test_rpc.response(result=result_dict)
    assert response["result"] == 'gANjdHlwZSI6ICJkb2N0IiwgJ3Rlc3RfZGljdCc6ICdkaWN0JwpwcmludCgpCmV4aXQoKQ=='
    assert response

# Generated at 2022-06-21 08:37:25.688651
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    server._identifier = 'test_identifier'
    # empty result
    result = server.response()
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'test_identifier'
    # non-text result
    result = server.response(result="this_is_a_test_result")
    assert result['jsonrpc'] == '2.0'
    assert result['id'] == 'test_identifier'
    assert result['result_type'] == 'pickle'
    assert result['result'] == 'cnltIzcKgXRoaXNfaXNfYSB0ZXN0X3Jlc3VsdAk='
    # text result

# Generated at 2022-06-21 08:37:31.573503
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    JsonRpcServer().invalid_params()

# Generated at 2022-06-21 08:37:39.779774
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    setattr(obj, '_identifier', '0')
    assert obj.response({'jsonrpc': '2.0'}) == {
        'jsonrpc': '2.0',
        'id': '0',
        'result': {'jsonrpc': '2.0'},
    }
    assert obj.response("hello") == {
        'jsonrpc': '2.0',
        'id': '0',
        'result': 'hello',
    }
    assert obj.response(b"hello") == {
        'jsonrpc': '2.0',
        'id': '0',
        'result': 'hello',
    }

# Generated at 2022-06-21 08:37:40.670217
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

# Generated at 2022-06-21 08:37:46.571706
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    obj = JsonRpcServer()
    obj.register(obj)
    payload = '{"jsonrpc":"2.0","id":"1","method":"internal_error","params":[]}'
    response = obj.handle_request(payload)
    expected = '{"jsonrpc": "2.0", "id": "1", "error": {"code": -32603, "message": "Internal error", "data": null}}'
    assert json.dumps(json.loads(response), sort_keys=True) == json.dumps(json.loads(expected), sort_keys=True)

# Generated at 2022-06-21 08:37:52.045004
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    JsonRpcServer_instance = JsonRpcServer()
    assert isinstance(JsonRpcServer_instance.method_not_found(), dict)
    assert isinstance(JsonRpcServer_instance.method_not_found(data='hi'), dict)

# Generated at 2022-06-21 08:37:55.354572
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    json_object = JsonRpcServer()
    json_object._identifier = 4
    result = json_object.header()
    assert result == {"jsonrpc": "2.0", "id": 4}

# Generated at 2022-06-21 08:38:02.784727
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    import unittest

    class JsonRpcServerTest(unittest.TestCase):
        def setUp(self):
            self.server = JsonRpcServer()
            self.obj = Foo()

        def tearDown(self):
            self.server = None
            self.obj = None

        def test_register(self):
            self.server.register(self.obj)
            self.assertIn(self.obj, self.server._objects)

    class Foo(object):
        pass

    return unittest.TestLoader().loadTestsFromTestCase(JsonRpcServerTest)


# Generated at 2022-06-21 08:38:14.933627
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    assert server.error(code=0, message='test') == {'jsonrpc': '2.0', 'id': None,
                                                    'error': {'code': 0, 'message': 'test'}}
    assert server.error(code=-32600, message='test', data='test') == {'jsonrpc': '2.0', 'id': None,
                                                                      'error': {'code': -32600,
                                                                                'message': 'test',
                                                                                'data': 'test'}}
    assert server.error(code=0, message='test', data=None) == {'jsonrpc': '2.0', 'id': None,
                                                               'error': {'code': 0, 'message': 'test'}}

# Generated at 2022-06-21 08:38:24.316801
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    import unittest

    class TestJsonRpcServer(unittest.TestCase):

        def setUp(self):
            self.server = JsonRpcServer()

        def test_01(self):

            # This test is intended to test the server logic but it is not
            # possible to test the raw json returned by handle_request()
            # because the result could be a response or a notification
            # (because of the connection errors) and a notification does
            # not contain the "id" field required by the JSON-RPC 2.0
            # specification.
            # That's why we need to call handle_request like if it were
            # called by the handle() method of the JsonRpcConnection
            # object.

            connection = MockJsonRpcConnection()
            connection.server = self.server
            self.server.handle

# Generated at 2022-06-21 08:38:31.202518
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    obj = JsonRpcServer()
    obj._identifier = "test_JsonRpcServer_response"
    result = "test_JsonRpcServer_response"
    resp = obj.response(result)
    assert resp["id"] == "test_JsonRpcServer_response"
    assert resp["result"] == "test_JsonRpcServer_response"
    assert resp["jsonrpc"] == "2.0"
    assert "result_type" not in resp.keys()


# Generated at 2022-06-21 08:38:42.464856
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    obj = JsonRpcServer()
    obj._identifier = '1234'
    assert obj.header() == {'jsonrpc': '2.0', 'id': '1234'}


# Generated at 2022-06-21 08:38:53.676632
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():

    server = JsonRpcServer()
    assert server.header() == {'jsonrpc': '2.0'}
    # test with default args
    assert server.error(-32700, "Parse error") == {'jsonrpc': '2.0', "error": {"code": -32700, "message": "Parse error"}, "id": None}
    # test with custom id
    server._identifier = "1"
    assert server.error(-32700, "Parse error") == {'jsonrpc': '2.0', "error": {"code": -32700, "message": "Parse error"}, "id": "1"}
    # test with custom data

# Generated at 2022-06-21 08:38:55.581099
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    class Test(object):
        pass
    obj = Test()
    server.register(obj)
    try:
        assert obj in server._objects
    except ValueError as exc:
        print(exc)

# Generated at 2022-06-21 08:38:56.581484
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()

# Generated at 2022-06-21 08:38:58.334577
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
        return json.dumps(JsonRpcServer.invalid_request())


# Generated at 2022-06-21 08:39:02.020157
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    # Create the JsonRpcServer object
    jsonrpcserver = JsonRpcServer()
    
    if isinstance(jsonrpcserver, JsonRpcServer):
        print("The object is an instance of the class JsonRpcServer")
    else:
        print("The object is not an instance of the class JsonRpcServer")

test_JsonRpcServer()

# Generated at 2022-06-21 08:39:07.640275
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    setattr(server, '_identifier', None)
    assert server.invalid_request() == {
        'code': -32600,
        'id': None,
        'jsonrpc': '2.0',
        'message': 'Invalid request'
    }


# Generated at 2022-06-21 08:39:11.626129
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    expected = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}
    actual = server.parse_error()
    assert expected == actual


# Generated at 2022-06-21 08:39:18.431077
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    server = JsonRpcServer()
    request = '{"id": "1", "method": "rpc.invalid_method"}'
    expected = '{"id": "1", "jsonrpc": "2.0", "error": {"code": -32600, "message": "Invalid request", "data": null}}'
    assert server.handle_request(request) == expected

if __name__ == '__main__':
    test_JsonRpcServer_invalid_request()

# Generated at 2022-06-21 08:39:21.577015
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    host = JsonRpcServer()
    assert '_objects' in host.__dict__
    host.register(host)
    assert host in host._objects


# Generated at 2022-06-21 08:39:39.678111
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    from ansible.module_utils.connection import Connection

    class MyServer(Connection):
        def __init__(self, module_args):
            super(MyServer, self).__init__(module_args)

        def connect(self):
            super(MyServer, self).connect()
            self.server = JsonRpcServer()

        def send_request(self):
            self.server.register(self)
            return

        def do_something(self):
            return 'foo'

        def do_something_else(self, something):
            return something

    class TestModule:
        def __init__(self):
            self.params = dict()

    my_module = TestModule()
    my_module.params['server'] = 'foo'
    my_module.params['port'] = 'foo'
    my_module

# Generated at 2022-06-21 08:39:43.062300
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    assert server.method_not_found() == {"id": None, "jsonrpc": "2.0", "error": {"code": -32601, "message": "Method not found"}}

# Generated at 2022-06-21 08:39:49.252653
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    expceted_json = {
        "jsonrpc": "2.0",
        "id": "1",
        "result": "TEST"
    }
    assert server.header() == {"jsonrpc": "2.0", "id": "_identifier"}
    assert server.response("TEST") == expceted_json


# Generated at 2022-06-21 08:39:54.734994
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    test_input = {"id": "dummy_id", "params": [["dummy_arg1", "dummy_arg2"]], "method": "dummy_method"}
    test_json = json.dumps(test_input)
    test_instance = JsonRpcServer()
    test_response = json.loads(test_instance.handle_request(test_json))
    assert test_response['id'] == 'dummy_id'
    assert test_response['error']['code'] == -32601
    assert test_response['error']['message'] == 'Method not found'

# Generated at 2022-06-21 08:40:03.608850
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    server = JsonRpcServer()
    setattr(server, '_identifier', '2')
    response = server.response('test')
    assert response == {'jsonrpc': '2.0', 'result': 'test', 'id': '2'}
    response = server.response(['a', 'b', 'c'])
    assert response == {'jsonrpc': '2.0', 'result_type': 'pickle', 'result': b'(lp0\nL1\naL1\naL1\na.', 'id': '2'}

# Generated at 2022-06-21 08:40:08.471295
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():

    # create object JsonRpcServer for testing purpose
    test_obj = JsonRpcServer()
    # create object TestClass2 for testing purpose
    class TestClass2:
        def __init__(self, name):
            self.name = name
    # instantiate object
    test_obj2 = TestClass2(name='testname')
    # register the object
    test_obj.register(test_obj2)
    # check if the object has been registered
    assert test_obj._objects == set([test_obj2])

# Generated at 2022-06-21 08:40:14.093034
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    json_rpc_server = JsonRpcServer()
    response = json_rpc_server.invalid_request("test")
    expected_response = {'id': None, 'jsonrpc': '2.0', 'error': {'code': -32600, 'message': 'Invalid request', 'data': 'test'}}
    assert response == expected_response 


# Generated at 2022-06-21 08:40:18.582164
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    server = JsonRpcServer()
    setattr(server, '_identifier', 'id')
    header = server.header()
    assert header['jsonrpc'] == '2.0'
    assert header['id'] == 'id'


# Generated at 2022-06-21 08:40:25.186763
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    j = JsonRpcServer()
    j._identifier = 'test'
    result = j.header()

    if(result == {'jsonrpc': '2.0', 'id': 'test'}):
        print('Test result of method "header" of class JsonRpcServer is OK')
    else:
        print('Test result of method "header" of class JsonRpcServer is FAILED')


# Generated at 2022-06-21 08:40:26.280123
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    JsonRpcServer()

# Generated at 2022-06-21 08:40:48.265850
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    # Test method parse_error with  arguments
    print(server.parse_error())
    print(server.parse_error())


# Generated at 2022-06-21 08:40:50.300120
# Unit test for method header of class JsonRpcServer
def test_JsonRpcServer_header():
    assert JsonRpcServer().header() == {'jsonrpc': '2.0', 'id': None}

# Generated at 2022-06-21 08:40:57.507086
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    server._identifier = '401'
    error_code = -32603
    error_message = 'Internal error'
    error_data = "missing device in connection"
    error = server.error(error_code, error_message, error_data)

    assert error_code == error['error']['code']
    assert error_message == error['error']['message']
    assert error_data == error['error']['data']
    assert 401 == error['id']
    assert '2.0' == error['jsonrpc']

# Generated at 2022-06-21 08:41:03.268423
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    _objects = set()
    _objects.add(2)
    _objects.add(5)
    obj = JsonRpcServer()
    assert isinstance(obj, JsonRpcServer)
    obj._objects = _objects
    assert obj._objects == _objects

# Generated at 2022-06-21 08:41:04.674400
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server is not None


# Generated at 2022-06-21 08:41:07.148373
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():

    server = JsonRpcServer()

    # check if the object is JsonRpcServer
    assert isinstance(server, JsonRpcServer)

    return


# Generated at 2022-06-21 08:41:09.229791
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    assert len(server._objects) == 0
    server.register(object())
    assert len(server._objects) == 1


# Generated at 2022-06-21 08:41:15.909241
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    response = server.error(code=123, message='test message')

    assert response['jsonrpc'] == '2.0'
    assert response['error']['code'] == 123
    assert response['error']['message'] == 'test message'
    assert response['error']['data'] == None


# Generated at 2022-06-21 08:41:21.652861
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    server = JsonRpcServer()
    result = server.error(-32601, 'Method not found', 'data')
    expect = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32601, 'message': 'Method not found', 'data': 'data'}}
    assert result == expect

test_JsonRpcServer_error()

# Generated at 2022-06-21 08:41:25.515757
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test = JsonRpcServer()
    test.register(None)
    setattr(test, '_identifier', 1)
    result = test.response("result")
    actual = {'jsonrpc': '2.0', 'id': 1, 'result': "result", 'result_type': 'pickle'}
    assert result == actual

# Generated at 2022-06-21 08:42:11.957564
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    test_server = JsonRpcServer()
    result = 'I am a normal result'
    response = test_server.response(result)
    assert response['result'] == 'I am a normal result'
    assert response['result_type'] is None
    result = '測試'
    response = test_server.response(result)
    assert response['result'] == '測試'
    assert response['result_type'] is None
    result = {'haha': 'today'}
    response = test_server.response(result)
    assert response['result_type'] == 'pickle'
    assert response['result'] == to_text(cPickle.dumps(result, protocol=0))

# Generated at 2022-06-21 08:42:19.251876
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    jsonrpc_server = JsonRpcServer()
    setattr(jsonrpc_server, "_identifier", 12345)

    response = jsonrpc_server.error(-32700, 'Parse error', {'key': 'value'})
    assert response == {
        'jsonrpc': '2.0',
        'id': 12345,
        'error': {
            'code': -32700,
            'message': 'Parse error',
            'data': {'key': 'value'}
        }
    }

# Generated at 2022-06-21 08:42:24.348217
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
    server = JsonRpcServer()
    assert server.invalid_params('Invalid parameters') == \
        {
            'id': None,
            'jsonrpc': '2.0',
            'error': {
                'code': -32602,
                'message': 'Invalid params',
                'data': 'Invalid parameters'
            }
        }


# Generated at 2022-06-21 08:42:26.597894
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    jr = JsonRpcServer()
    obj = {'name': 'object1'}
    jr.register(obj)
    assert obj in jr._objects
    return True



# Generated at 2022-06-21 08:42:31.638169
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    jsonrpc_server_obj = JsonRpcServer()
    # test with complete request
    request = '{"jsonrpc": "2.0", "method": "get_facts", "params": ["str_param1", "str_param2", false, true], "id": 1}'
    response = jsonrpc_server_obj.handle_request(request)
    assert 'result_type' in json.loads(response)
    assert 'pickle' == json.loads(response)['result_type']
    assert 'result' in json.loads(response)

# Generated at 2022-06-21 08:42:41.931811
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()

    class Foo(object):
        def bar(self, data):
            return data

    foo = Foo()

    server.register(foo)
    server.register(server)

    # method exists
    result = server.handle_request(json.dumps({'method': 'bar', 'id': 1, 'params': [{'data': 'Hello World'}]}))
    assert json.loads(result) == {'id': 1, 'jsonrpc': '2.0', 'result': 'Hello World'}

    # method does not exist
    result = server.handle_request(json.dumps({'method': 'baz', 'id': 2, 'params': [{'data': 'Hello World'}]}))

# Generated at 2022-06-21 08:42:51.415483
# Unit test for method error of class JsonRpcServer
def test_JsonRpcServer_error():
    print('Testing JsonRpcServer.error...')
    JsonRpcServer_instance = JsonRpcServer()
    setattr(JsonRpcServer_instance, '_identifier', 1234567)
    result = JsonRpcServer_instance.error(code=-123, message=u'This is a test')
    print('Result:')
    print(result)
    print('Expected Result:')
    print(json.dumps({u'id': 1234567, u'error': {u'message': u'This is a test', u'code': -123}, u'jsonrpc': u'2.0'}))

# Generated at 2022-06-21 08:42:56.595739
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    server = JsonRpcServer()
    result = server.internal_error(data="very bad")
    assert result == {
        "id": None,
        "jsonrpc": "2.0",
        "error": {
            "code": -32603,
            "message": "Internal error",
            "data": "very bad"
        }
    }

# Generated at 2022-06-21 08:43:02.283701
# Unit test for method register of class JsonRpcServer
def test_JsonRpcServer_register():
    server = JsonRpcServer()
    server._objects = set()

    class testClass(object):
        def method(self, arg, kwarg=None):
            pass

    obj = testClass()

    server.register(obj)

    assert isinstance(
        server._objects,
        set) == True

    assert len(server._objects) == 1

    assert server._objects == {
        obj}

    server._objects.clear()



# Generated at 2022-06-21 08:43:05.665763
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():
    server = JsonRpcServer()
    message = {
        'jsonrpc': '2.0',
        'method': 'add',
        'id': 1,
        'params': [1, 2],
    }
    request = json.dumps(message)
    response = server.handle_request(request)
    assert json.loads(response)['result'] == 3

# Generated at 2022-06-21 08:43:35.982509
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    result = server.method_not_found()
    assert result['error']['code'] == -32601
    assert result['error']['message'] == 'Method not found'
    assert result['jsonrpc'] == '2.0'

# Generated at 2022-06-21 08:43:41.226337
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()

    code = -32700
    message = 'Parse error'
    data = 'Some data'

    response = server.parse_error(data)

    assert response['jsonrpc'] == '2.0'
    assert response['id'] == server._identifier
    assert response['error']['code'] == code
    assert response['error']['message'] == message
    assert response['error']['data'] == data



# Generated at 2022-06-21 08:43:44.950815
# Unit test for method response of class JsonRpcServer
def test_JsonRpcServer_response():
    jsonrpc_server = JsonRpcServer()
    jsonrpc_server._identifier = 1
    resp_return = jsonrpc_server.response(1)
    assert resp_return["jsonrpc"] == "2.0"


# Generated at 2022-06-21 08:43:47.531216
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    server = JsonRpcServer()
    assert server.parse_error() == {'error': {'code': -32700, 'message': 'Parse error'}, 'id': None, 'jsonrpc': '2.0'}


# Generated at 2022-06-21 08:43:52.801506
# Unit test for method invalid_params of class JsonRpcServer
def test_JsonRpcServer_invalid_params():
        json_rpc_server = JsonRpcServer()
        expected_value = {'jsonrpc': '2.0', 'id': 'haha', 'error': {'code': -32602, 'message': 'Invalid params', 'data': 'lol'}}
        actual_value = json_rpc_server.invalid_params('lol')
        assert (expected_value == actual_value)
        json_rpc_server = JsonRpcServer()
        expected_value = {'jsonrpc': '2.0', 'id': 'haha', 'error': {'code': -32602, 'message': 'Invalid params'}}
        actual_value = json_rpc_server.invalid_params()
        assert (expected_value == actual_value)


# Generated at 2022-06-21 08:43:57.749669
# Unit test for method internal_error of class JsonRpcServer
def test_JsonRpcServer_internal_error():
    json_rpc_server_object = JsonRpcServer()
    json_rpc_server_object._identifier = 0
    json_rpc_server_object.internal_error()
    # assert dict 'id' is equal to 0
    assert json_rpc_server_object.header()['id'] == 0

# Generated at 2022-06-21 08:44:05.846930
# Unit test for method handle_request of class JsonRpcServer
def test_JsonRpcServer_handle_request():

    from ansible.module_utils.facts.hardware.base import Hardware

    class TestHardware(Hardware):

        def get_all(self):
            return {}

    json_rpc = JsonRpcServer()
    json_rpc.register(TestHardware())
    result = json_rpc.handle_request('{"jsonrpc": "2.0", "method": "get_all", "params": [{}], "id": 1}')

    assert result == '{"jsonrpc": "2.0", "id": 1, "result": "{}"}'

# Generated at 2022-06-21 08:44:07.152418
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server
    assert server.handle_request

# Generated at 2022-06-21 08:44:13.003849
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    rpc = JsonRpcServer()
    assert rpc.method_not_found() == {
      'id': None,
      'jsonrpc': '2.0',
      'error': {
      'code': -32601,
      'message': 'Method not found',
      'data': None
      }
    }

# Generated at 2022-06-21 08:44:17.043883
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    expected = '{"jsonrpc": "2.0", "id": 1, "error": {"code": -32700, "message": "Parse error", "data": "the data"}}'
    assert JsonRpcServer().parse_error("the data") == expected


# Generated at 2022-06-21 08:44:43.675396
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    server = JsonRpcServer()
    assert server
    return server


# Generated at 2022-06-21 08:44:46.540233
# Unit test for constructor of class JsonRpcServer
def test_JsonRpcServer():
    import json
    json.loads(JsonRpcServer().invalid_request())

# Test for methode handle_request of class JsonRpcServer

# Generated at 2022-06-21 08:44:52.110516
# Unit test for method parse_error of class JsonRpcServer
def test_JsonRpcServer_parse_error():
    jrs = JsonRpcServer()
    assert jrs.parse_error() == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error'}}
    assert jrs.parse_error('test') == {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Parse error', 'data': 'test'}}


# Generated at 2022-06-21 08:44:54.948585
# Unit test for method invalid_request of class JsonRpcServer
def test_JsonRpcServer_invalid_request():
    jsr = JsonRpcServer()
    result = jsr.invalid_request()
    assert(result['error']['code'] == -32600)
    assert(result['error']['message'] == 'Invalid request')


# Generated at 2022-06-21 08:45:05.537684
# Unit test for method method_not_found of class JsonRpcServer
def test_JsonRpcServer_method_not_found():
    server = JsonRpcServer()
    error = server.method_not_found()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'
    assert error['error'].get('data') is None
    server.register(None)
    error = server.method_not_found()
    assert error['jsonrpc'] == '2.0'
    assert error['error']['code'] == -32601
    assert error['error']['message'] == 'Method not found'
    assert error['error'].get('data') == 'method not implemented in rpc object'
