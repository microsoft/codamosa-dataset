

# Generated at 2022-06-11 13:47:48.880259
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    hostname = 'test_hostname_value'
    key = 'test_key_value'
    key_type = 'test_key_type_value'
    fingerprint = 'test_fingerprint_value'
    new_stdin = 'test_new_stdin_value'
    connection = 'test_connection_value'
    inp = 'test_inp_value'
    instance = MyAddPolicy(new_stdin, connection)

    # Mock MyAddPolicy._new_stdin
    # for testing
    instance._new_stdin = None

    # Mock MyAddPolicy.connection
    # for testing
    instance.connection = None

    # Mock MyAddPolicy._options
    # for testing
    instance._options = None

    # Mock missing_host_key() input arguments
    # for testing
    client = hostname


# Generated at 2022-06-11 13:47:53.195308
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    config = ConfigParser.RawConfigParser()
    config.read('ansible.cfg')

    conn = Connection(config.get('defaults', 'inventory'))
    conn.fetch_file('in_path', 'out_path')



# Generated at 2022-06-11 13:48:04.966791
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    host, port = '127.0.0.1', 8888
    display = DummyDisplay()
    loader = DummyLoader()
    variable_manager = DummyVariableManager()
    options = Mock()
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 10
    options.become = None
    options.become_method = None
    options.become_user = None
    options.remote_user = 'root'
    options.private_key_file = None
    options.check = False
    options.timeout = 10
    options.ssh_common_args = "-o StrictHostKeyChecking=no"
    options.ssh_extra_args = ""
    options.sftp_extra_args = ""
    options.scp_extra_args = ""
    options

# Generated at 2022-06-11 13:48:07.109360
# Unit test for method close of class Connection
def test_Connection_close():
    conn_obj = Connection()
    # No test available without running the connection
    return
# Unit tests to be run from command line

# Generated at 2022-06-11 13:48:18.667983
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    writer = Writer()
    p = Mock()
    p.transport = 'ssh'
    p.host = 'host'
    p.port = None
    p.user = 'user'
    p.remote_user = None
    p.password = 'password'
    p.private_key_file = None
    p.timeout = 10
    p.connection_lock = None
    p.no_log = False
    p.verbosity = 0
    p.become = False
    p.become_method = None
    p.become_user = None
    p.become_pass = None
    p.become_exe = None
    p.become_flags = None
    p.become_ask_pass = False
    p.ask_pass = False
    p.ansible_ssh_common_args

# Generated at 2022-06-11 13:48:30.587448
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    '''
    Unit test for method missing_host_key of class MyAddPolicy
    '''

    try:
        from unittest.mock import MagicMock, patch
        from ansible.module_utils.common._collections_compat import MutableMapping
    except ImportError:
        from mock import MagicMock, patch
        from collections import MutableMapping

    from ansible.plugins.connection import ConnectionBase
    from ansible_collections.local.community.plugins.modules.connection.paramiko import MyAddPolicy

    client = MagicMock()
    hostname = "hostname"
    key = "key"
    new_stdin = "new_stdin"
    connection = MagicMock()
    connection._options = dict()
    connection.get_option = MagicMock(return_value=True)

   

# Generated at 2022-06-11 13:48:40.309570
# Unit test for method reset of class Connection
def test_Connection_reset():
    paramiko.Transport.reset = MagicMock()
    paramiko.Transport.close = MagicMock()
    paramiko.Transport._connected = True
    paramiko.Transport.close.return_value = None
    myConn = Connection(play_context=dict(remote_addr='192.168.1.1', password='pass', remote_user='user'))
    original_transport = myConn.ssh.get_transport()
    myConn.reset()
    original_transport.reset.assert_called_once_with()
    original_transport.close.assert_called_once_with()
    assert myConn.ssh.get_transport() != original_transport


# Generated at 2022-06-11 13:48:48.049946
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    cmd = 'ls'
    in_data = None
    sudoable = None
    (exit_status, stdout, stderr) = connection.exec_command(cmd, in_data, sudoable)
    #
    assert type(exit_status) is int
    assert type(stdout) is bytes
    assert type(stderr) is bytes
    # method returns a tuple
    assert type(connection.exec_command(cmd, in_data, sudoable)) is tuple


# Generated at 2022-06-11 13:48:59.370206
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # setup
    conn = Connection()
    conn._cached_result = {'stdout': 'the output'}
    conn._connected = True
    conn.become = False
    conn.become_method = 'sudo'
    conn.become_user = 'testBecomeUser'
    conn.get_option = MagicMock(name='get_option')
    conn.get_option.side_effect = ['test' if arg == 'remote_tmp' else 'testValue' for arg in ['remote_tmp', 'protocol', 'persistent_command_timeout', 'host_key_checking', 'look_for_keys', 'compression', 'host_key_auto_add']]
    conn.exec_command = MagicMock(name='exec_command')
    conn.exec_command.side_effect = ['the output']


# Generated at 2022-06-11 13:49:00.966195
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = create_connection()
    assert connection.reset() == None

# Generated at 2022-06-11 13:49:24.799317
# Unit test for method close of class Connection
def test_Connection_close():
    '''
    There is no unit test for method close() of class Connection in test/lib/ansible/caps.py

    '''

    pass

    # TODO: test that cache is cleaned up


# Generated at 2022-06-11 13:49:31.565182
# Unit test for method close of class Connection
def test_Connection_close():
    a = Connection()
    # check that correct exception is raised when not connected
    try:
        a.close()
    except AnsibleConnectionFailure as e:
        assert e.err == "unable to close connection (not connected)"
    # test success
    # TODO: test passes even if method does nothing at all
    a._connected = True
    a.close()
    assert a._connected is False

# Generated at 2022-06-11 13:49:36.578610
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
   MyAddPolicy_obj = MyAddPolicy( new_stdin, connection )
   client_obj = client
   hostname = "hostname"
   key_obj = key
   MyAddPolicy_obj.missing_host_key(client_obj,hostname,key_obj)


# Generated at 2022-06-11 13:49:44.782060
# Unit test for method reset of class Connection
def test_Connection_reset():

    # Make sure we can reset the connection
    conn = Connection(play_context=dict(remote_addr="1.2.3.4", remote_user="bob"),
                      new_stdin=open(os.devnull, 'r'),
                      runner=MagicMock(),
                      host_input_data=dict(host='1.2.3.4',port=22,username='bob'))
    # mock up a connection
    conn.set_options()
    conn.ssh=MagicMock()
    # call reset
    conn.reset()
    # make sure at least the ssh connection was called
    conn.ssh.close.called_once()


# Generated at 2022-06-11 13:49:57.382491
# Unit test for method reset of class Connection
def test_Connection_reset():
    args = dict(
        host=dict(type='str', required=True),
        port=dict(type='int', default=22),
        username=dict(type='str', aliases=['user', 'admin'], required=True),
        password=dict(type='str', no_log=True),
        key_file=dict(type='path'),
        timeout=dict(default=10, type='int'),
        become=dict(default=False, type='bool'),
        become_method=dict(),
        become_user=dict()
    )

# Generated at 2022-06-11 13:50:08.535166
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    '''
    Unit test for method put_file of class Connection
    '''
    print("in test_Connection_put_file ")
    CONN_GET_URL = 'https://github.com/ansible/ansible/pull/13898/commits/c6d5cc6368b9f8120634c73a6b0a6ec1d6ff8e03.diff'
    remote_addr="127.0.0.1"
    remote_user="root"

    pc=play_context.PlayContext()
    pc.connection='ssh'
    pc.remote_addr=remote_addr
    pc.remote_user=remote_user
    pc.timeout = 10
    pc.password = None
    pc.port = 22
    pc.private_key_file = None
    pc.become = False

# Generated at 2022-06-11 13:50:18.349898
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    from ansible.plugins.connection.ssh import Connection
    from ansible.module_utils.six.moves.mock import patch

    with patch.object(Display, 'vvvv') as mock_display:
        # I'm not sure how best to unit test this.  We're mostly testing stdin interactions.
        self = Connection(None, '/dev/null')
        self._new_stdin = open('/dev/null', 'r')
        policy = MyAddPolicy(self._new_stdin, self)
        policy.missing_host_key(paramiko.SSHClient(), 'a', 'b')
        mock_display.assert_called_with("Unable to load host key: 'b'")


# Generated at 2022-06-11 13:50:29.674743
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # setup test environment

    # create a mock object
    mock_display = Mock(spec=Display)
    mock_self = Mock(spec=Connection)

    # noinspection PyUnresolvedReferences
    mock_self.become = None
    # noinspection PyUnresolvedReferences
    mock_self.keyfile = "~/.ssh/known_hosts"
    # noinspection PyUnresolvedReferences
    mock_self.ssh = None
    # noinspection PyUnresolvedReferences
    mock_self.sftp = None

    mock_self._play_context = Mock(spec=PlayContext)
    mock_self._play_context.password = None

    # noinspection PyUnresolvedReferences
    mock_self._play_context.remote_addr = "REMOTE_ADDR"
    # noinspection PyUn

# Generated at 2022-06-11 13:50:35.850785
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a new Connection object
    conn = Connection(
        module_name='shell', 
        become=True
    )
    in_path = '/tmp/file.txt'
    out_path = '/home/ubuntu/file.txt'

# Generated at 2022-06-11 13:50:43.256353
# Unit test for method reset of class Connection
def test_Connection_reset():
  ssh = paramiko.SSHClient()
  ssh._host_keys = {u'127.0.0.1': {u'ssh-rsa': key}}
  ssh.set_missing_host_key_policy(MyAddPolicy(None, None))
  ssh.get_transport().set_keepalive(5)
  chan = ssh.get_transport().open_session()
  conn = Connection()
  conn.ssh = ssh
  conn.sftp = chan
  conn.ssh.get_transport().is_active()
  conn.close()


# Generated at 2022-06-11 13:51:02.830023
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-11 13:51:03.868817
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    raise NotImplementedError



# Generated at 2022-06-11 13:51:13.037911
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    username = 'root'
    password = '123456'

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('192.168.0.10', 22, username=username, password=password)
    sftp = ssh.open_sftp()
    sftp.put('C:\\Users\\Administrator\\Desktop\\quicksort.py', '/root/quicksort.py')
    sftp.get('/root/quicksort.py', 'C:\\Users\\Administrator\\Desktop\\sftp_get.py')
    ssh.close()


# Generated at 2022-06-11 13:51:22.456439
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    '''
    Unit test for method exec_command of class Connection
    '''

    import ansible.module_utils.connection as connection

    class TestClass:
        def __init__(self):
            self.connection = connection.Connection(dict(vars=dict()))


# Generated at 2022-06-11 13:51:30.036383
# Unit test for method close of class Connection
def test_Connection_close():
    import tempfile, os, uuid, stat

    class MyConnection(Connection):
        _lockfile_name = 'lock'
        def get_option(self, option):
            return True
        def __init__(self):
            self.ssh = True
            self.keyfile = self.tmp_keyfile = self.tmp_lockfile = None

# Generated at 2022-06-11 13:51:31.434797
# Unit test for method close of class Connection
def test_Connection_close():
    connection = get_connector(dict(
        Transport='paramiko'
    ))
    assert connection.close() == False


# Generated at 2022-06-11 13:51:32.961761
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    MyAddPolicy(new_stdin, connection)


# Generated at 2022-06-11 13:51:34.935807
# Unit test for method close of class Connection
def test_Connection_close():
  paramiko_connection = Connection(play_context=play_context)
  # TODO : write a real test
  # paramiko_connection.close()
  assert False



# Generated at 2022-06-11 13:51:40.318357
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    print("test MyAddPolicy_missing_host_key")
    client = paramiko.SSHClient()
    hostname = '192.168.1.1'
    key = "test"
    clk = MyAddPolicy(hostname, key, client) 
    clk.missing_host_key()


# Generated at 2022-06-11 13:51:50.001521
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    p1 = Mock(
        _play_context=Mock(
            remote_addr='128.0.0.1',
            remote_user='root'
        )
    )

    p2 = Mock(
        get_option=Mock(
            return_value=True
        )
    )

    p3 = Mock(
        get_option=Mock(
            return_value='key_filename'
        )
    )

    p4 = Mock(
        get_option=Mock(
            return_value='password'
        )
    )

    p5 = Mock(
        _play_context=Mock(
            timeout=10
        )
    )

    p6 = Mock(
        get_option=Mock(
            return_value='secret'
        )
    )

    p7 = Mock

# Generated at 2022-06-11 13:52:12.844413
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    paramiko_ansible_connection = Connection()
    paramiko_ansible_connection.exec_command(cmd='ls')

# Generated at 2022-06-11 13:52:15.041243
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection(None, None)
    conn.close()
    # TODO: We need to verify the state of the object after calling close()
    #assert not conn.connected


# Generated at 2022-06-11 13:52:20.994393
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock paramiko.SSHClient() object
    test_client = mock.MagicMock(spec=paramiko.SSHClient)

    # Create a mock paramiko.SFTPClient() object
    test_sftp = mock.MagicMock(spec=paramiko.SFTPClient)

    sftp_conn_cache = {}
    ssh_conn_cache = {}

    test_client.open_sftp.return_value = test_sftp
    test_sftp.get.return_value = True

    # Create a mock ansible.playcontext.PlayContext() object
    test_play_context = mock.MagicMock(spec=PlayContext)

    # Create an instance of our class
    ssh_conn = Connection(play_context=test_play_context, new_stdin=None)
    ssh

# Generated at 2022-06-11 13:52:26.459803
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_fetch_file = Connection(host=fake.host(), port=fake.random_int(min=0, max=65535), user=fake.user_name(), password=fake.password(), private_key_file=fake.file_path(), connection_timeout=fake.random_int(min=0, max=9999), become_method=fake.random_element(elements=['', 'sudo', 'su', 'pbrun', 'pfexec']), become_user=fake.user_name(), become_pass=fake.password())
    # Call method
    out = connection_fetch_file.fetch_file(in_path=fake.file_path(), out_path=fake.file_path())
    assert out is None  # validate if the test output was correct



# Generated at 2022-06-11 13:52:27.995956
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
        display.debug("test_MyAddPolicy_missing_host_key() called")



# Generated at 2022-06-11 13:52:30.071515
# Unit test for method close of class Connection
def test_Connection_close():
    # set up Connection object
    c = Connection()
    c.keyfile = os.path.expanduser("~/.ssh/known_hosts")
    c._connected = True
    # test Connection.close()
    c.close()



# Generated at 2022-06-11 13:52:31.417604
# Unit test for method close of class Connection
def test_Connection_close():
    test = Connection()
    # This test method is not supported
    assert False


# Generated at 2022-06-11 13:52:38.900500
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    class MockClient(object):
        _host_keys = {}

    conn = paramiko.SSHClient()
    conn._options = {'host_key_checking': True, 'host_key_auto_add': False}

    policy = MyAddPolicy(sys.stdin, conn)
    policy._options = conn._options

    client = MockClient()

    key = paramiko.RSAKey.generate(bits=1024)
    hostname = '127.0.0.1'

    policy.missing_host_key(client, hostname, key)

    assert client._host_keys[hostname][key.get_name()] == key
    assert key._added_by_ansible_this_time is True



# Generated at 2022-06-11 13:52:39.554529
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    #FIXME: TBD
    pass

# Generated at 2022-06-11 13:52:40.597462
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()

    # Place your code here
    raise Exception("Test not implemented")


# Generated at 2022-06-11 13:53:45.067509
# Unit test for method reset of class Connection
def test_Connection_reset():
    paramiko = import_module('paramiko')
    connection = Connection()
    connection.set_options({
        'host_key_checking': True,
        'record_host_keys': True,
        'timeout': 10,
        'banner_timeout': 10,
    })
    ssh = connection.ssh = paramiko.SSHClient()
    ssh._host_keys.update({
        '127.0.0.1': {'ssh-rsa': paramiko.rsakey.RSAKey(filename="")},
    })
    connection.keyfile = "~/.ssh/known_hosts"
    connection.ssh.close()
    try:
        connection._save_ssh_host_keys("/tmp/test.tmp.py")
    except PermissionError:
        pass

# Generated at 2022-06-11 13:53:50.140946
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Uses a mock of the Paramiko Channel class to test the method.
    #
    # Note: _connect_uncached() is called because the fixture for the
    # Connection class does not provide a Paramiko Channel object.

    #
    # Set up test data
    #
    def ExampleClass(self):
        self.chan = mock.Mock()
        self.become = mock.Mock()
        self.become.expect_prompt.return_value = False
        self.get_option = mock.Mock(return_value=True)
        self.get_option.return_value = True
        self.sftp = mock.Mock()
        self.ssh = mock.Mock()
        self.ssh.get_transport.return_value.set_keepalive.return_value = 0

# Generated at 2022-06-11 13:53:56.442284
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Make sure that host_keys are written out and that we munge the filemode
    to chmod 0600 (which is required for ssh)
    """
    test_conn = Connection()
    test_conn.ssh = module_mock("paramiko.SSHClient")

    test_conn.keyfile = os.path.expanduser("~/.ssh/known_hosts")

    test_conn.ssh._host_keys = dict()

# Generated at 2022-06-11 13:54:04.273952
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  # Create an object of class Connection
  connection = Connection(None, False, False)
  # This is an example input dictionary
  kwargs = {'_play_context': None, 'in_path': None, 'out_path': None}
  # Run the put_file with the input
  put_file_result = connection.put_file(kwargs)
  # This is the expected output of put_file
  expected_result = None
  assert put_file_result == expected_result

# Generated at 2022-06-11 13:54:04.926342
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-11 13:54:15.267012
# Unit test for method reset of class Connection
def test_Connection_reset():
    global __testbasedir
    __testbasedir = os.getcwd()
    import ansible.constants as C
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.virtual
    import ansible.utils
    ansible.constants.HOST_VARS_FILE=None
    ansible.constants.HOSTVARS=None
    ansible.constants.HOST_PATTERN_MATCH=False
    ansible.constants.DEFAULT_HASH_BEHAVIOUR='replace'
    ansible.constants.SYSTEM_WARNINGS=True
    ansible.constants.DEFAULT_MODULE_NAME=''
    ansible.constants.DEFAULT_MODULE_PATH=''
    ansible.constants.MODULE_CACHE

# Generated at 2022-06-11 13:54:20.097779
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    fetch_file_args = {"in_path": "in_path", "out_path": "out_path"}
    fetch_file_kwargs = {}
    con = Connection()
    con.fetch_file(**fetch_file_args)
    # expect to be able to make a call with no parameters
    con.fetch_file()


# Generated at 2022-06-11 13:54:30.279301
# Unit test for method close of class Connection
def test_Connection_close():

    module = AnsibleModule({})
    connection = Connection(module._socket_path)

    connection.ssh = MagicMock()
    connection.ssh.close.return_value = None

    connection.sftp = MagicMock()
    connection.sftp.close.return_value = None

    connection._connected = True
    connection._cache_key = MagicMock()
    connection._cache_key.return_value = 'Test'

    SSH_CONNECTION_CACHE.pop('Test', None)
    SFTP_CONNECTION_CACHE.pop('Test', None)

    connection.close()

    assert connection.ssh.close.call_count == 1
    assert connection.sftp.close.call_count == 1
    assert connection._connected == False


#
# Pseudo-ansible module for testing the

# Generated at 2022-06-11 13:54:39.232729
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    #
    # Test for a connection event which raises an exception which is handled
    #
    connection = Connection()

    connection._connected = False
    mock_ssh = Mock()
    connection.ssh = mock_ssh

    mock_ssh.get_transport.return_value.open_session.side_effect = \
        paramiko.ssh_exception.AuthenticationException("Authentication Exception")

    msg = "Failed to authenticate: Authentication Exception"
    with pytest.raises(AnsibleAuthenticationFailure) as execinfo:
        connection.exec_command("echo test123")
    assert msg in str(execinfo.value)
    connection.close()
    assert connection._connected == False

# Generated at 2022-06-11 13:54:40.237961
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    pass


# Generated at 2022-06-11 13:56:55.142639
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # TODO: write unit test
    pass


# Generated at 2022-06-11 13:56:56.398277
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
  # TODO: add unit test for Connection.fetch_file
  pass


# Generated at 2022-06-11 13:57:02.117274
# Unit test for method close of class Connection
def test_Connection_close():
    pass

    # TODO: uncomment the following when SSHClient.close and SSHClient.load_system_host_keys are implemented
#     def _save_ssh_host_keys(self, filename):
#         '''
#         not using the paramiko save_ssh_host_keys function as we want to add new SSH keys at the bottom so folks
#         don't complain about it :)
#         '''
#
#         if not self._any_keys_added():
#             return False
#
#         with open(filename, 'w') as f:
#
#             for hostname, keys in iteritems(self.ssh._host_keys):
#
#                 for keytype, key in iteritems(keys):
#
#                     # was f.write
#                     added_this_time = getattr(key, '_added_by_

# Generated at 2022-06-11 13:57:11.296283
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    class Response:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Create a mock object for the SSH connection
    class ssh:
        def get_transport(self):
            return None

        def get_pty(self):
            return None

        def open_session(self):
            return None

        def load_system_host_keys(self):
            raise IOError()

        def connect(self):
            return None

        def set_missing_host_key_policy(self):
            return None

        def close(self):
            return None

        def is_active(self):
            return True

    # Create a mock object for the SSH connection
    class chan:
        def get_pty(self):
            return None


# Generated at 2022-06-11 13:57:19.833536
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    hostname = '127.0.0.1'
    password = 'vagrant'
    username = 'vagrant'
    port = '22'
    transport = 'ssh'
    connection = Connection(host=hostname, user=username, password=password, port=port, connect_timeout=None, connect_retries=None, transport=transport)

    result = connection.put_file(in_path='/home/vagrant/ansible-2.8.6/lib/ansible/module_utils/basic.py', out_path='/tmp/basic.py')
    assert result == None
    connection.close()
    # TODO: Add tests for other methods of class Connection
