

# Generated at 2022-06-25 08:59:46.879815
# Unit test for method reset of class Connection
def test_Connection_reset():
    print('Test reset method')
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    connection_0._connected = False
    connection_0.reset()



# Generated at 2022-06-25 08:59:55.645446
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    host_key_checking_0 = False
    host_key_auto_add_0 = True
    pty_0 = True
    host_key_checking_1 = False
    host_key_auto_add_1 = True
    pty_1 = False
    host_key_checking_2 = True
    host_key_auto_add_2 = True
    pty_2 = True
    host_key_checking_3 = False
    host_key_auto_add_3 = False
    pty_3 = True
    host_key_checking_4 = False
    host_key_auto_add_4 = False
    pty_4 = False
    host_key_checking_5 = True
    host_key_auto_add_5 = False
    pty_5 = True
    host_key_checking_

# Generated at 2022-06-25 08:59:57.282434
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    assert True == True


# Generated at 2022-06-25 09:00:03.692590
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    in_path_0 = '?QP/A'
    out_path_0 = '?QP/A'
    try:
        connection_0.put_file(in_path_0, out_path_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:00:10.895675
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()
    bytes_1 = b'\xde\xa6I\x8d2J\x19'
    str_1 = 'Z33J4QopdiT"\';F-'
    connection_1 = Connection(bytes_1, str_1)
    connection_1.reset()


# Generated at 2022-06-25 09:00:23.041280
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    str_1 = 'a\x88\x13\x8b\xd7\x0c\xf3\xe3\xc2\x1b\x06'
    str_2 = '/\xc6\x02\xb2\xdd\xba\x8c\xea\x1e\xb7\xc9\xd6'
    connection_0.fetch_file(str_1, str_2)



# Generated at 2022-06-25 09:00:31.739139
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    r'''
    Unit test for method fetch_file
    '''
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    str_1 = 'gk#\x04\x0f\x19\x02\rE\x15\x1c\x17\t\x1b\x0b'
    str_2 = '\x03\x00\x13\x14\x12\x0f\x18\x05\x12\x00\x19+'
    connection_0.fetch_file(str_1, str_2)


# Generated at 2022-06-25 09:00:44.783865
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    str_1 = '!B:ei1\x1d\x0b'
    tuple_0 = connection_0.exec_command(str_1)
    bytes_1 = b'\xde\xa6I\x8d2J\x19'
    str_2 = 'Z33J4QopdiT"\';F-'
    connection_1 = Connection(bytes_1, str_2)
    str_3 = 'J\x7f`\x8c\x0c\x1e'
    tuple_1 = connection_1.exec_command

# Generated at 2022-06-25 09:00:53.180011
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    # Setup
    client_0 = paramiko.client.SSHClient()
    hostname_0 = '4}'

# Generated at 2022-06-25 09:00:58.217721
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    bytes_0 = b'\xde\xa6I\x8d2J\x19'
    str_0 = 'Z33J4QopdiT"\';F-'
    connection_0 = Connection(bytes_0, str_0)
    path_0 = 'f61gB-L1R]s/QK68'
    path_1 = 'a8m\n!\x0c\x13E\x02'
    bytes_1 = b'\xde\xa6I\x8d2J\x19'
    str_1 = 'Z33J4QopdiT"\';F-'
    connection_1 = Connection(bytes_1, str_1)


# Generated at 2022-06-25 09:01:26.811405
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = '/xpnQ=7?_,Y.1V'
    out_path = ' 2m,!I'
    str_0 = connection_0.put_file(in_path, out_path)
    assert_equals(str_0, None)


# Generated at 2022-06-25 09:01:34.674190
# Unit test for method close of class Connection
def test_Connection_close():
    bool_0 = False
    str_0 = 'T#+7IZ(Y$'
    # NOTE: This has been moved to setup
    # list_0 = []
    # list_0 = [str_0, str_0]
    # connection_0 = Connection(bool_0, str_0, *list_0)
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:40.956645
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    bool_0 = False
    str_0 = '=u`7V.i"Iu)7'
    list_0 = []
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_2 = 'kC]7zkDgr'
    str_3 = ''
    connection_0.fetch_file(str_2, str_3)


# Generated at 2022-06-25 09:01:44.796195
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    bool_0 = False
    str_0 = '4gK0 D~fo?'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_1 = '%_Lz, 5]C~'
    str_2 = 'BV@x,#(t'
    connection_0.fetch_file(str_1, str_2)


# Generated at 2022-06-25 09:01:49.892039
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    bool_0 = False
    str_0 = '.'
    list_0 = [str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_1 = '-'
    var_0 = connection_0.exec_command(str_1)


# Generated at 2022-06-25 09:01:56.304199
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    str_0 = '<%re$'
    client_0 = paramiko.SSHClient()
    str_1 = '/Zi?s)t'
    key_0 = paramiko.ECDSAKey
    var_0 = MyAddPolicy(List, client_0, str_1, key_0)
    var_0.missing_host_key(client_0, str_1, key_0)


# Generated at 2022-06-25 09:02:00.681887
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print('Test put_file of class Connection')
    bool_0 = False
    str_0 = '4X9PuAiCF'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    # TODO : add assertion


# Generated at 2022-06-25 09:02:05.651922
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    bool_0 = False
    str_0 = 'p4;u+]4.5|u'
    list_0 = ['f7VQb~xu)E', len()]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_1 = '9z(;0L-G?%c'
    str_2 = 'N1b[SBeeG`)'
    tuple_0 = (connection_0.exec_command(str_1, str_2),)


# Generated at 2022-06-25 09:02:08.828210
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    bool_0 = False
    str_0 = 'a'
    list_0 = ['a', str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_1 = 'f+'
    str_2 = 'eGP,d'
    in_data = [str_1, str_2]
    cmd = connection_0.exec_command(str_1, in_data)

# Generated at 2022-06-25 09:02:16.841434
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-25 09:03:08.570005
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    ssh_client_0 = paramiko.SSHClient()
    str_0 = 'd!qz.(4?K4}'
    str_1 = ':(fCmg\x7fF'
    key_0 = paramiko.RSAKey(obj={str_1: str_0})
    file_0 = tempfile.NamedTemporaryFile()
    connection_0 = Connection(obj={'host_key_auto_add': True}, stdin=file_0)
    policy_0 = MyAddPolicy(file_0, connection_0)
    policy_0.missing_host_key(ssh_client_0, str_1, key_0)


# Generated at 2022-06-25 09:03:14.521699
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    bool_0 = False
    str_0 = 't@3)e'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    client_0 = connection_0.client
    hostname_0 = str_0
    key_0 = MyAddPolicy(client_0, hostname_0)
    var_0 = key_0.missing_host_key()


# Generated at 2022-06-25 09:03:15.870925
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    print("Test case: MyAddPolicy_missing_host_key")
    # TODO
    assert False


# Generated at 2022-06-25 09:03:23.451423
# Unit test for method reset of class Connection
def test_Connection_reset():
    bool_0 = False
    str_0 = 'g{I<}7V'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    var_0 = connection_0.reset()
    connection_0.close()


# Generated at 2022-06-25 09:03:26.417836
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    bool_0 = False
    str_0 = '8`v0pGyk4Bg'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    connection_0.put_file(str_0, str_0)


# Generated at 2022-06-25 09:03:35.647060
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    bool_0 = False
    str_0 = '\x1c{zfNvy]n'
    list_0 = ['xAV#w', bool_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_1 = 'A\x1c%'
    str_2 = 'O>;\rt\t'
    bool_1 = False
    list_1 = [str_2, bool_1]
    tuple_0 = connection_0.exec_command(str_1, *list_1)
    print(tuple_0, '\n', str_1, '\n', bool_1)


# Generated at 2022-06-25 09:03:45.092888
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = 'in_path'
    out_path = 'out_path'
    connection = Connection(False, 'ansible_ssh_pass')
    connection.sftp = mock.Mock()
    connection.ssh = mock.Mock()
    connection.sftp.put = mock.Mock()
    connection.put_file(in_path, out_path)

    connection.ssh.open_sftp.assert_called_once_with()
    connection.sftp.put.assert_called_once_with('in_path', 'out_path')

# Unit test

# Generated at 2022-06-25 09:03:47.694150
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection(False, 'deploy')
    ssh = conn._connect()
    conn.sftp = ssh.open_sftp()
    conn.close()
    conn.fetch_file('/opt/test/test.txt', '/opt/test/')


# Generated at 2022-06-25 09:03:51.687078
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    bool_0 = False
    str_0 = '!'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_0 = 'rCQ^o )'
    str_1 = ''
    exception_0 = None
    try:
        connection_0.put_file(str_0, str_1)
    except Exception as exc:
        exception_0 = exc
    assert type(exception_0) == AnsibleError


# Generated at 2022-06-25 09:03:58.677113
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    bool_0 = False
    str_0 = 'r5a5$tL'
    list_0 = [str_0, str_0]
    connection_0 = Connection(bool_0, str_0, *list_0)
    str_0 = 'I/'
    str_1 = 'Rr{)5m'
    connection_0.put_file(str_0, str_1)


# Generated at 2022-06-25 09:07:46.603136
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    str_0 = '*l'
    list_0 = [str_0]
    str_1 = ';8#f'
    list_1 = []
    list_2 = list_1
    str_2 = '6_2'
    list_2.append(str_2)
    str_3 = '4YJ)y'
    list_2.append(str_3)
    str_4 = '^a!'
    list_2.append(str_4)
    str_5 = 'F=}'
    list_2.append(str_5)
    str_6 = '#~6'
    list_2.append(str_6)
    list_2.append(str_6)
    connection_0 = Connection(list_0, list_0, list_2)
    var

# Generated at 2022-06-25 09:07:48.199896
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection([1, 2], [1, 2], [1, 2])
    connection_0.put_file(['e9Q'], connection_0.reset())


# Generated at 2022-06-25 09:07:52.120706
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection(list_0, list_0, list_0)
    var_0 = connection_0.reset()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:08:00.583871
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    list_0 = ['zpk5 }jK!z3Z=', '', 'Nw6Uu[JA0b@j9k', '4P&a_u?Cjd0/Tn', '+jH$hQlEg?0n}X']
    list_1 = ['`h%c~s?&+jt8A', 'a=n%*JqjQ!v;8W', ' {M88E}C>h=T0W', '8T_2[HN1y{0YhC', '8T_2[HN1y{0YhC']
    connection_1 = Connection(list_0, list_1, list_0)

# Generated at 2022-06-25 09:08:08.968808
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    str_0 = 'y'
    list_1 = ['', str_0, str_0, str_0, str_0]
    list_0 = [str_0, str_0, str_0, str_0, str_0]
    connection_0 = Connection(list_0, list_0, list_0)
    str_1 = 'a'
    str_2 = ';'
    str_3 = 'q'
    dict_0 = {str_3: str_0, str_2: str_1}
    result = connection_0.exec_command(dict_0, list_1, list_1)
    assert result == None


# Generated at 2022-06-25 09:08:13.191593
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    for _ in range(50):
        test_case_0()

# Generated at 2022-06-25 09:08:17.913183
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    str_0 = '?7]4oW ZrUE#'
    list_0 = [str_0, str_0, str_0, str_0, str_0]
    connection_0 = Connection(list_0, list_0, list_0)
    var_0 = connection_0.reset()
    str_0 = '9*[-Q%H^!Dd'
    str_1 = 'J$w#<>0)4+'
    var_1 = connection_0.put_file(str_0, str_1)


# Generated at 2022-06-25 09:08:20.991065
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    def mock_AnsibleError(str_1):
        print(str_1)

    def mock_input(str_2):
        return str_2

    AnsibleError = mock_AnsibleError
    input = mock_input

    obj = MyAddPolicy(None, None)
    obj.missing_host_key(None, None, None)


# Generated at 2022-06-25 09:08:31.306956
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    str_0 = ']q9;?T90'
    list_0 = [str_0, str_0, str_0, str_0, str_0]
    connection_0 = Connection(list_0, list_0, list_0)
    tuple_0 = connection_0.exec_command('fsck')
    int_0 = tuple_0[0]
    str_0 = '5'
    str_1 = '7?uXJ'
    list_1 = [str_1, str_1, str_1, str_1, str_1]
    var_0 = connection_0.exec_command('fsck', list_1)
    var_2 = connection_0.exec_command(str_1, list_1)


# Generated at 2022-06-25 09:08:35.847366
# Unit test for method put_file of class Connection