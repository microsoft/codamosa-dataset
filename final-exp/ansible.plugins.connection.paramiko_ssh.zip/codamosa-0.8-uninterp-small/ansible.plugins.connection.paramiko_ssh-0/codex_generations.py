

# Generated at 2022-06-25 08:59:53.711693
# Unit test for method close of class Connection
def test_Connection_close():
    pass


# Generated at 2022-06-25 08:59:56.248644
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    cmd = "ls"
    (status, stdout, stderr) = conn.exec_command(cmd)
    print(stdout.readlines())
    print(stderr.readlines())
    print(status)


# Generated at 2022-06-25 08:59:59.108278
# Unit test for method reset of class Connection
def test_Connection_reset():
    int_0 = 37
    connection_0 = Connection(int_0, int_0)
    connection_0.reset()


# Generated at 2022-06-25 09:00:00.737604
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    int_0 = 457
    connection_0 = Connection(int_0, int_0)
    myaddpolicy_0 = MyAddPolicy(int_0, connection_0)



# Generated at 2022-06-25 09:00:07.620937
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    in_path_0 = 'a'
    out_path_0 = 'b'
    connection_0 = Connection('a', 'b')
    connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:00:13.992188
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = 'in_path'
    out_path = 'out_path'
    expected = ValueError
    actual = None
    try:
        connection_0 = Connection(int(0), int(0))
        connection_0.put_file(in_path, out_path)
    except ValueError as e:
        actual = e
    assert expected == actual


# Generated at 2022-06-25 09:00:19.329917
# Unit test for method close of class Connection
def test_Connection_close():
    int_0 = 84
    connection_0 = Connection(int_0, int_0)
    connection_0.close()


# Generated at 2022-06-25 09:00:24.259172
# Unit test for method reset of class Connection
def test_Connection_reset():
    int_0 = 457
    connection_0 = Connection(int_0, int_0)
    reset_0 = connection_0.reset()


# Generated at 2022-06-25 09:00:26.435237
# Unit test for method close of class Connection
def test_Connection_close():
    int_4 = 465
    connection_0 = Connection(int_4, int_4)
    connection_0.close()


# Generated at 2022-06-25 09:00:28.964929
# Unit test for method reset of class Connection
def test_Connection_reset():
    int_0 = 457
    connection_0 = Connection(int_0, int_0)
    connection_0.reset()


# Generated at 2022-06-25 09:01:17.266269
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:23.868434
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-25 09:01:30.048732
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)

    str_1 = '.'
    str_2 = './.cache/ansible/tmp/ansible-tmp-1477154775.61-103637079382872/command'

    try:
        connection_0.put_file(str_1, str_2)
    except Exception:
        pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:01:37.687853
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print('Testing put_file')
    dict_0 = {}
    str_0 = '}bo wQ6Dfw(E8qO{'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:01:41.518421
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

  # get the execution command from the module
  cmd = remote_module_0.exec_command()

  # get the execution context from the module
  context = remote_module_0.execution_context()

  # Create object of class Connection
  connection_0 = Connection(context, '127.0.0.1', None)

  # Execute the command on the host
  connection_0.exec_command(cmd, None, True)


# Generated at 2022-06-25 09:01:46.011848
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    dict_0 = {}
    str_0 = '|YX%G>I5Jlh1_]mv'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    client_0 = connection_0.SSHClient()
    var_0 = connection_0.get_option('host_key_checking')
    str_0 = ';?[~o}fR]E'
    str_0 = 'ey/&wM.)C@)<'
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}
    dict_0 = {}

# Generated at 2022-06-25 09:01:56.560410
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    myaddpolicy_0 = MyAddPolicy(str_0, connection_0)
    client_0 = paramiko.client.SSHClient()
    hostname_0 = 'cX~7q$5xQ|1=V@jEiR8='
    key_0 = paramiko.RSAKey.RSAKey()
    myaddpolicy_0.missing_host_key(client_0, hostname_0, key_0)


# Generated at 2022-06-25 09:02:02.137028
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    str_1 = 'echo hello world &!'
    tuple_0 = connection_0.exec_command(str_1)
    print(tuple_0)


# Generated at 2022-06-25 09:02:06.642621
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    dict_0 = {}
    str_0 = '0%2{=N49I/~<Y[wBv5(5{'
    list_0 = [dict_0]
    myaddpolicy_0 = MyAddPolicy(dict_0, *list_0)
    
    client_0 = None
    hostname_0 = None
    key_0 = None
    var_0 = myaddpolicy_0.missing_host_key(client_0, hostname_0, key_0)
    return var_0


# Generated at 2022-06-25 09:02:18.273175
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {
        'become': None,
        'changed': False,
        'pipelining': None,
        'port': None,
        'result': {'end': '', 'invocation': {'module_args': 'command', 'module_name': 'command'}, 'rc': 0, 'start': '', 'stderr': '', 'stdout': ''},
        'stdout_lines': [],
        'warnings': []
    }

    str_0 = 'Y29tbWFuZA=='
    list_0 = [dict_0]

    connection_0 = Connection(dict_0, str_0, list_0, *list_0)

    var_0 = connection_0.exec_command(str_0, list_0)

# Generated at 2022-06-25 09:03:10.330772
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    str_1 = '^yH`Yk$Fg{(+WZ$V#'
    str_2 = ')_kW8*v|PQ|{cs'
    setattr(connection_0._play_context, 'remote_addr', 'g.k8n(_k4')
    setattr(connection_0._play_context, 'remote_user', 'o?%c~*A0d4|4')
    connection_0.test()

# Generated at 2022-06-25 09:03:16.770660
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    str_0 = 'Mk! x*#Pf+#:jB]|Aja'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    str_1 = '+$NZ+9m#y(0]m_DtJ'
    str_0 = 'p!x&%j*vVS7#N9+R-O'
    connection_0.put_file(str_1, str_0)


# Generated at 2022-06-25 09:03:19.555213
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:03:23.419981
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    str_0 = 'cXJ(U|'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    str_1 = '=4t'
    str_2 = 'n_[aF9G'
    var_0 = connection_0.put_file(str_1, str_2)


# Generated at 2022-06-25 09:03:26.173052
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = []
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    connection_0.close()


# Generated at 2022-06-25 09:03:34.536678
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    str_1 = 'Rn|PuV(?BbM#u`7x`3q'
    str_2 = '8u@-h<3ms$5Y0c%y]Uh'
    str_3 = 'zZ><}0g~`KA[M(0h:O-^'
    str_4 = 'r6rXB!h2Z6=!U637hJlN'

# Generated at 2022-06-25 09:03:43.375567
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    dict_0 = {}
    str_0 = 'Hb}T`C3:7VuS;0|_'
    list_0 = [dict_0]
    client_0 = SSHClient()
    hostname_0 = ';Q}c%?~\x7fO'
    key_0 = RSAKey(None)
    myaddpolicy_0 = MyAddPolicy(dict_0, client_0)
    var_0 = myaddpolicy_0.missing_host_key(client_0, hostname_0, key_0)


# Generated at 2022-06-25 09:03:45.926864
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    str_0 = '/j/p/V#XGknuBjk|m)G'
    list_0 = []
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    assert_equals(connection_0.close(), None)


# Generated at 2022-06-25 09:03:49.677054
# Unit test for method reset of class Connection
def test_Connection_reset():
    dict_0 = {}
    str_0 = '#f|0Ac)Y+-H0X@a1(v_Z'
    list_0 = [dict_0]
    connection_0 = Connection(dict_0, str_0, list_0, *list_0)
    var_0 = connection_0.reset()
    assert var_0 == None, "Assertion failed"


# Generated at 2022-06-25 09:03:53.690947
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection(None, None, None, *None)
    var_0 = connection_0._save_ssh_host_keys(None)
    var_1 = connection_0.close()
    return var_1


# Generated at 2022-06-25 09:05:00.025709
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    str_0 = '#f|AcYNO0@>1(v_Z'
    connection_0 = Connection(str_0, str_0, str_0, *str_0)
    var_0 = connection_0.reset()
    var_0 = connection_0.exec_command(*str_0)
    # AssertionError: <class 'AnsibleError'>: Failed to open session: <ssh_exception.SSHException object at 0x10a0f45c8>


# Generated at 2022-06-25 09:05:06.991108
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    str_0 = 'jQ|w/z0/@>1(v_Z'
    client_0 = paramiko.SSHClient()
    hostname_0 = '1Yu3NO0@>1(v_Z'
    key_0 = paramiko.RSAKey(data=None)
    connection = Connection(str_0, str_0, str_0, *str_0)
    MyAddPolicy(connection).missing_host_key(client_0, hostname_0, key_0)


# Generated at 2022-06-25 09:05:12.678519
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    new_stdin = StringIO()
    connection = Connection('host', 'username', 'password')
    policy = MyAddPolicy(new_stdin, connection)
    client = Mock(host_keys=Mock())
    hostname = 'somehost.com'
    key = 'SomeKey'
    try:
        policy.missing_host_key(client, hostname, key)
    except Exception as e:
        assert e.args[0] == AUTHENTICITY_MSG[1:92] % (hostname, key, hexlify('SomeKey'))
    else:
        assert False


# Generated at 2022-06-25 09:05:15.370381
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    str_0 = 'qIexbX?7V'
    connection_0 = Connection(str_0, str_0, str_0, *str_0)
    var_0 = connection_0.fetch_file(str_0, *str_0)
    assert_equal(var_0, None)


# Generated at 2022-06-25 09:05:16.361840
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:05:20.981907
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Setup
    str_0 = '#f|AcYNO0@>1(v_Z'
    connection_0 = Connection(str_0, str_0, str_0, *str_0)
    in_path, out_path = str_0, './tmp/ansible_test_file_out_path'

    # Exercise
    connection_0.fetch_file(in_path, out_path)

    # Verify
    assert os.path.isfile(out_path)
    # Teardown
    os.remove(out_path)


# Generated at 2022-06-25 09:05:26.885768
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    str_0 = '#f|AcYNO0@>1(v_Z'
    client_0 = None
    hostname_0 = 'd>x72C;G'
    key_0 = RSAKey()
    policy_0 = MyAddPolicy(str_0, client_0)
    policy_0.missing_host_key(client_0, hostname_0, key_0)


# Generated at 2022-06-25 09:05:31.594532
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    str_0 = '#f|AcYNO0@>1(v_Z'
    connection_0 = Connection(str_0, str_0, str_0, *str_0)

# Generated at 2022-06-25 09:05:39.507981
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    # Create a test MyAddPolicy object
    my_add_policy_0 = MyAddPolicy()
    # Create a test client
    client_0 = paramiko.SSHClient()
    # Create a test hostname
    str_0 = '_yN3qyP+l~'
    # Create a test key
    key_0 = paramiko.RSAKey()
    # Call the missing_host_key method
    my_add_policy_0.missing_host_key(client_0, str_0, key_0)


# Generated at 2022-06-25 09:05:46.653315
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    str_0 = '#f|AcYNO0@>1(v_Z'
    connection_0 = Connection(str_0, str_0, str_0, *str_0)
    tuple_0 = connection_0.exec_command('echo', str_0)
    check_0 = tuple_0[1] == str_0
    check_1 = tuple_0[2] == str_0


# Generated at 2022-06-25 09:08:42.932238
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    str_0 = '*c%$Rv1QM'
    str_1 = '#f|AcYNO0@>1(v_Z'
    str_2 = '9XW<}8'
    str_3 = 'bAn+04z`~'
    list_0 = [str_1, str_2, str_3]
    tuple_0 = (str_1, str_2, str_3)


# Generated at 2022-06-25 09:08:55.261372
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    var_0 = 'jb'
    var_1 = 'Zå{z'
    var_2 = 'jb'
    var_3 = 'Zå{z'
    var_4 = fcntl.fcntl(var_3, var_4)
    var_5 = 'Zå{z'
    var_6 = 'AcYNO0@>1(v_Z'
    var_7 = '1(v_Z'
    var_8 = 'AcYNO0@>1(v_Z'
    var_9 = '1(v_Z'
    var_10 = 'AcYNO0@>1(v_Z'
    var_11 = '1(v_Z'
    var_12 = 'AcYNO0@>1(v_Z'

# Generated at 2022-06-25 09:08:58.741453
# Unit test for method close of class Connection
def test_Connection_close():
    test_case_0()

# Testcases
if __name__ == '__main__':
    test_Connection_close()

# Generated at 2022-06-25 09:09:05.601856
# Unit test for method missing_host_key of class MyAddPolicy
def test_MyAddPolicy_missing_host_key():
    str_1 = '#f|AcYNO0@>1(v_Z'
    connection_1 = Connection(str_1, str_1, str_1, *str_1)
    myaddpolicy = MyAddPolicy(sys.stdin, connection_1)
    assert myaddpolicy._new_stdin == sys.stdin
    assert myaddpolicy.connection == connection_1
    assert myaddpolicy._options == connection_1._options
    assert myaddpolicy.missing_host_key(client=None, hostname=str_1, key=None) == None
    assert myaddpolicy._new_stdin == sys.stdin
    assert myaddpolicy.connection == connection_1
    assert myaddpolicy._options == connection_1._options
