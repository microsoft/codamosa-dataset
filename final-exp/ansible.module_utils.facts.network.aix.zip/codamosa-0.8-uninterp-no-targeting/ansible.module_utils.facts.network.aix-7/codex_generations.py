

# Generated at 2022-06-20 17:49:09.561973
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ''' Unit test for function AIXNetworkCollector in module AIXNetwork '''
    # create dummy object module
    from ansible.module_utils.facts.network.interfaces import Interfaces
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    my_collector = default_collectors.get('network')
    my_module = AnsibleModule(argument_spec=dict())
    my_collector.collect(my_module)
    my_interface = Interfaces(my_module)
    my_net = my_interface.network.collectors[0]
    assert isinstance(my_net, AIXNetwork)

# Generated at 2022-06-20 17:49:20.762287
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule(object):

        def __init__(self):
            self.run_command_called = False
            self.run_command_calls = list()

        def fail_json(self, *args, **kwargs):
            self.failed = True

        def get_bin_path(self, *args, **kwargs):
            return '/etc/bin/'

        def run_command(self, args, *kwargs, **cmd_kwargs):
            self.run_command_called = True
            self.run_command_calls.append(args)
            if args[0] == '/etc/bin/uname':
                return 0, "  0 wpar1", ""

# Generated at 2022-06-20 17:49:29.517538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix.netstat_parser import NetstatParser

    TEST_FILE_NETSTAT = 'netstat_route_AIX.txt'

    class TestAIXNetwork(AIXNetwork):
        def run_netstat(self):
            netstat_parser = NetstatParser(self.module, TEST_FILE_NETSTAT)
            return netstat_parser.route

    def test_AIXNetwork_get_default_interfaces():
        test_AIXNetwork = TestAIXNetwork(dict())

        interfaces = test_AIXNetwork.get_default_interfaces()

        assert interfaces['v4']['gateway'] == '172.27.1.1'
        assert interfaces['v4']['interface'] == 'en0'

# Generated at 2022-06-20 17:49:32.210941
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:49:38.581875
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    aix = AIXNetwork(module)
    aix.get_default_interfaces = None  # to allow cover the method with unit test
    route_path = module.get_bin_path('route')
    assert aix.get_default_interfaces(route_path) == ({}, {})
    # todo: test when there are results


# Generated at 2022-06-20 17:49:40.248551
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork({'module': 'test'})
    assert net.platform == 'AIX'



# Generated at 2022-06-20 17:49:49.896002
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    aix = AIXNetwork()
    current_if = aix.parse_interface_line(['en0:', 'flags=842<BROADCAST,RUNNING,MULTICAST>', 'mtu', '1280'])
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-20 17:50:00.004140
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    aixnet = AIXNetwork(module=None)

    words_1 = ['wlp2s0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    current_if_1 = aixnet.parse_interface_line(words_1)

# Generated at 2022-06-20 17:50:04.417590
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test method get_default_interfaces of class AIXNetwork

    :return:
    """
    network_collector = AIXNetworkCollector()
    network_collector.module = object()
    network = network_collector.get_network_collector()


# Generated at 2022-06-20 17:50:11.747556
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ test the constructor of AIXNetworkCollector """
    mod = 'ansible.module_utils.facts.network.aix.AIXNetworkCollector'
    test_class = AIXNetworkCollector()
    assert test_class._fact_class is AIXNetwork
    assert test_class._platform == 'AIX'
    assert test_class._fact_class._platform == 'AIX'
    assert test_class._fact_class.__module__ == mod

# Generated at 2022-06-20 17:50:30.737062
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Variables initialization
    AIX_NET_OBJ = AIXNetwork()

    # Tests
    assert AIX_NET_OBJ.platform == 'AIX'
    assert AIX_NET_OBJ.get_default_interfaces(route_path='/usr/bin/netstat') == ({'gateway': '10.10.10.1', 'interface': 'en0'}, {'gateway': 'fe80::21c:42ff:fe0b:9e32', 'interface': 'en0'})


# Generated at 2022-06-20 17:50:33.681534
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network = AIXNetwork({})
    assert network.platform == 'AIX'


# Generated at 2022-06-20 17:50:40.849578
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ifc_net = AIXNetwork(module)
    line = "lo0: flags=8c02<UP,LOOPBACK,RUNNING,MULTICAST> "
    words = line.split()
    current_if = ifc_net.parse_interface_line(words)
    module.exit_json(msg=current_if)

from ansible.module_utils.basic import *
main()

# Generated at 2022-06-20 17:50:44.034492
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__module__ == 'ansible.module_utils.facts.network.aix'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-20 17:50:54.868830
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import subprocess
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_network_resources'] = 'all'

            self.facts = dict()
            self.facts['ansible_local'] = dict()
            self.facts['ansible_local']['interface_map'] = dict()

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg in ('ifconfig', 'netstat', 'uname', 'entstat', 'lsattr'):
                return arg


# Generated at 2022-06-20 17:51:05.651501
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor test of AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX', 'test of AIXNetworkCollector._platform has failed'
    assert AIXNetworkCollector._fact_class == AIXNetwork,\
           'test of AIXNetworkCollector._fact_class has failed'
    assert isinstance(AIXNetworkCollector(), NetworkCollector),\
           'test of constructor of class AIXNetworkCollector has failed'
    assert AIXNetworkCollector()._platform == 'AIX',\
           'test of AIXNetworkCollector()._platform has failed'
    assert isinstance(AIXNetworkCollector()._fact_class, AIXNetwork),\
           'test of AIXNetworkCollector()._fact_class has failed'


# Generated at 2022-06-20 17:51:08.375610
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'


# Generated at 2022-06-20 17:51:20.613704
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test1_aix = dict(
        device = 'en0',
        type = 'ether',
        macaddress = '0:C:29:C:2:C',
        ipv4 = [],
        ipv6 = [],
        flags = {'BROADCAST', 'MULTICAST'}
    )

    test2_aix = dict(
        device = 'lo0',
        type = 'ether',
        macaddress = 'unknown',
        ipv4 = [
                '127.0.0.1/8'
        ],
        ipv6 = [
                '::1/0',
                'fe80::1/0'
        ],
        flags = {'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'}
    )

    test3_aix = dict

# Generated at 2022-06-20 17:51:25.433687
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.__class__.__name__ == 'AIXNetworkCollector'
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class.__class__.__name__ == 'AIXNetwork'


# Generated at 2022-06-20 17:51:28.055309
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _fact_class = AIXNetworkCollector._fact_class
    _platform = AIXNetworkCollector._platform
    assert _fact_class == AIXNetwork
    assert _platform == 'AIX'

# Generated at 2022-06-20 17:51:59.754973
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class ModuleMock(object):
        def __init__(self, module_utils, params):
            self.params = params
            self.module_utils = module_utils

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'netstat':
                return '/usr/bin/netstat'

    class ModuleUtilMock(object):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-20 17:52:01.924025
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.platform == 'AIX'



# Generated at 2022-06-20 17:52:11.577324
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-20 17:52:20.920906
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    test_class = AIXNetwork()

    test_args = dict(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )

    current_if = dict(
        device='lo0',
        type='unknown',
        ipv4=[],
        ipv6=[],
        flags=['UP', 'HOST', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        macaddress='unknown',
    )

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Create an example of AIX ifconfig -a output
    # This example is on a freshly installed system and contains some real
    # interfaces, but the entries needed for this test are marked
    #

# Generated at 2022-06-20 17:52:31.658235
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = ''
    ifconfig_options = '-a'
    route_path = ''

    c = AIXNetwork(ifconfig_path, ifconfig_options, route_path)


# Generated at 2022-06-20 17:52:42.196941
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # create the class
    aix_net = AIXNetwork()

    # test the platform
    assert aix_net.platform == 'AIX'

    # test the constructor and test the get_default_interfaces method
    route_path = aix_net.module.get_bin_path('route')
    aix_net.get_default_interfaces(route_path)

    # test the constructor and test the get_interfaces_info method
    ifconfig_path = aix_net.module.get_bin_path('ifconfig')
    aix_net.get_interfaces_info(ifconfig_path, ifconfig_options='-a')

    # test the parse_interface_line method

# Generated at 2022-06-20 17:52:52.053284
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args, exit_json
    from ansible.module_utils import basic
    import ansible_collections.ansible.community.plugins.module_utils.network.aix.facts.network.aix_network as aix_network

    m_run_command = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    m_run_command.run_command = MagicMock(return_value=(0, '', ''))
    set_module_args(dict(gather_subset='!all', filter='**'))
    with pytest.raises(SystemExit):
        aix_network.main()
    out = m_run_command.exit_json


# Generated at 2022-06-20 17:52:52.941347
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork()


# Generated at 2022-06-20 17:52:58.083050
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This testcase is to test that:
    1. AIXNetworkCollector() is an instance of NetworkCollector.
    2. AIXNetworkCollector() is an instance of AIXNetworkCollector
    """
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    nc = AIXNetworkCollector()
    assert isinstance(nc, NetworkCollector)
    assert isinstance(nc, AIXNetworkCollector)



# Generated at 2022-06-20 17:53:09.187821
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    new_AIXNetwork = AIXNetwork()
    words = ['ent0:', 'flags=9e00<UP,BROADCAST,NOTRAILERS,PROMISC,SIMPLEX,MULTICAST>',
             'address:90e2ba5cb5e5', 'media:Ethernet', 'defspeed:10', 'defduplex:full', 'autoselect']

    expected = {'device': 'ent0',
                'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'PROMISC', 'SIMPLEX', 'MULTICAST'],
                'macaddress': 'unknown',
                'type': 'unknown'}
    result = new_AIXNetwork.parse_interface_line(words)

    assert result == expected

# Generated at 2022-06-20 17:54:01.031694
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    m = dict(
        module=dict(
            get_bin_path=dict(
                return_value='/usr/bin'
            ),
            run_command=dict(
                return_value=(0, 'a', 'b')
            )
        )
    )

    set_module_args(m)
    aix = AIXNetworkCollector()
    assert aix.platform == 'AIX'



# Generated at 2022-06-20 17:54:02.616538
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork

# Generated at 2022-06-20 17:54:13.379625
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    _AIXNetwork = AIXNetwork()
    ifconfig_lines = dict(words=['lo0:', 'UP', 'LOOPBACK', 'RUNNING', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1',
                                 'netmask', 'ffffff00']
                          )
    current_if = _AIXNetwork.parse_interface_line(ifconfig_lines['words'])
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['LOOPBACK', 'MULTICAST', 'UP']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['mtu'] == '8232'

# Generated at 2022-06-20 17:54:23.059838
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:54:33.696088
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    if_info = b"""en0: flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000 broadcast 127.255.255.255
        inet 10.1.1.1 netmask ffff0000 broadcast 10.1.255.255
        inet 10.128.218.90 netmask ffffff00 broadcast 10.128.218.255
        inet6 ::1/128
        options=3<RXCSUM,TXCSUM,TCP_URGENT_DATA>
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
        media: Ethernet autoselect (1000baseT )
        status: active
    """
    net = AI

# Generated at 2022-06-20 17:54:35.639339
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'
    assert obj.fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:54:39.057268
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork

    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert isinstance(aix_network, NetworkCollector)

# Generated at 2022-06-20 17:54:44.803395
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    network_collector = AIXNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)
    assert isinstance(network_collector, AIXNetworkCollector)

# Generated at 2022-06-20 17:54:52.598770
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    result = dict(
        changed=False,
        ansible_network_resources={},
    )
    nc = AIXNetworkCollector(module=module, platform='AIX')

    assert nc._fact_class == AIXNetwork
    assert nc._platform == 'AIX'
    assert nc.facts == {}
    assert nc.ignore_params == []
    assert nc._cache.cache == {}


# Generated at 2022-06-20 17:55:00.089769
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_if = AIXNetwork()
    test_if.module.run_command = nosh_run_command_test

    # netstat -r output with two IPv4 and two IPv6 default gateways
    def test_1():
        instance = test_if.get_default_interfaces('/sbin/netstat')
        assert instance == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en1'})

    test_1()


# Generated at 2022-06-20 17:56:49.721338
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    facts = AIXNetwork()
    interfaces = facts.get_interfaces_info('/sbin/ifconfig', '-a')
    assert len(interfaces) > 0
    for if_dev in interfaces[0]:
        assert 'device' in interfaces[0][if_dev]
        assert 'ipv4' in interfaces[0][if_dev]
        assert 'ipv6' in interfaces[0][if_dev]
        assert 'macaddress' in interfaces[0][if_dev]
        assert 'type' in interfaces[0][if_dev]

# Generated at 2022-06-20 17:57:01.189254
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_module = AnsibleModule(argument_spec={'name': dict(type='str', required=True)})
    test = AIXNetwork(fake_module)

    with open('tests/unit/module_utils/facts/network/AIX.netstat') as f:
        fake_command = f.read()
    netstat_path = '/usr/bin/netstat'
    fake_module.run_command = Mock(return_value=(0, fake_command, ''))
    v4_default, v6_default = test.get_default_interfaces(netstat_path)
    assert v4_default['gateway'] == '9.6.45.1'
    assert v4_default['interface'] == 'en0'

# Generated at 2022-06-20 17:57:03.031310
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-20 17:57:14.962283
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule(
        argument_spec=(),
        supports_check_mode=False
    )

    class AIXNetworkTest(AIXNetwork):
        def __init__(self, module):
            self.module = module
            self.facts = {}

    aix_network = AIXNetworkTest(ansible_module)
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    line_words = line.split()
    parsed_line = aix_network.parse_interface_line(line_words)
    assert parsed_line['device'] == 'en0'
    assert parsed_line

# Generated at 2022-06-20 17:57:21.124774
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # no arguments
    _obj = AIXNetworkCollector()

    # arguments
    _obj = AIXNetworkCollector(
        params=dict(
            gather_subset=['!all', '!min'],
            gather_network_resources=['all'],
        ),
        collector=None,
        module=None,
    )

    # check attributes
    assert hasattr(_obj, 'params')
    assert hasattr(_obj, 'collector')
    assert hasattr(_obj, 'module')
    assert hasattr(_obj, '_fact_class')
    assert hasattr(_obj, '_platform')
    assert hasattr(_obj, '_warnings')



# Generated at 2022-06-20 17:57:31.539608
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # The following lines are copied from AIXNetwork.get_interfaces_info
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    for line in out.splitlines():

        if line:
            words = line.split()

            # only this condition differs from GenericBsdIfconfigNetwork
            if re.match(r'^\w*\d*:', line):
                current_if = parse_interface_line(words)
                interfaces[current_if['device']] = current_if

# Generated at 2022-06-20 17:57:42.311435
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This is the test for the aix network module class and the
    get_interfaces_info function. It is used to collect facts from the
    AIX system.  These tests compare the facts collected by this
    function to the contents of an example ifconfig command output.
    """

    # Set up the class AIXNetwork object.
    MockModule = type('', (object,), dict(exit_json=exit_json, fail_json=exit_fail))
    mock_module = MockModule()
    mock_module.params = {}
    aixnetwork = AIXNetwork(mock_module)

    # Get the string of the output from an example ifconfig command.
    ifconfig_path = aixnetwork.module.get_bin_path('ifconfig')
    ifconfig_rc, ifconfig_out, ifconfig_err = aix

# Generated at 2022-06-20 17:57:44.515392
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = NetworkCollector()
    assert type(net_collector) == AIXNetworkCollector

# Generated at 2022-06-20 17:57:52.142369
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    module_mock = type('module_mock', (), {
        'get_bin_path': lambda *args: args[0],
        'run_command': lambda *args: (0, '', '')
    })()

    with patch.multiple(module_mock, get_bin_path=module_mock.get_bin_path,
                        run_command=module_mock.run_command):
        network = AIXNetwork(module_mock)
        words = ['en0:', 'flags=1e080863,']
        current_if = network.parse_interface_line(words)

    assert current_if['device'] == 'en0'

# Generated at 2022-06-20 17:58:01.443288
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.ifconfig import Interface
    from ansible.module_utils.facts.network.generic_bsd import InterfaceFlags
    import subprocess
    import unittest

    class MockModule(object):
        """
        This is the simple mock module class
        """
        def __init__(self):
            self.run_command_counter = 0

        def get_bin_path(self, arg):
            if arg == 'uname':
                return '/usr/bin/uname'

            if arg == 'entstat':
                return '/usr/sbin/entstat'

            if arg == 'ifconfig':
                return '/usr/sbin/ifconfig'

            if arg == 'netstat':
                return