

# Generated at 2022-06-20 17:49:03.463783
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    net = AIXNetwork()

    net.module = FakeModule()

    net.module.run_command = lambda args, check_rc=None: ["", "default 192.168.1.1 UGS eth0", ""]
    g = net.get_default_interfaces('/sbin/route')
    assert g == {'v4': {'gateway': '192.168.1.1', 'interface': 'eth0'}, 'v6': {}}

    net.module.run_command = lambda args, check_rc=None: ["", "default ::/0 UGS lo0", ""]
    g = net.get_default_inter

# Generated at 2022-06-20 17:49:10.656390
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModuleMock()
    aix_net = AIXNetwork(module)
    words = ['en0:', 'flags=2e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    ifoutput = aix_net.parse_interface_line(words)
    assert 'en0' in ifoutput
    assert 'flags' in ifoutput
    assert 'macaddress' in ifoutput

# Generated at 2022-06-20 17:49:17.316856
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test constructor of AIXNetwork class."""
    ifconfig_path='/usr/sbin/ifconfig'
    ifconfig_options='-a'
    network = AIXNetwork(ifconfig_path, ifconfig_options)
    assert network.platform == 'AIX'
    assert network.ifconfig_path == ifconfig_path
    assert network.ifconfig_options == ifconfig_options
    assert network.procfs_path == '/proc/net/'


# Generated at 2022-06-20 17:49:20.598289
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_class = AIXNetwork()   # fake AnsibleModule class, it has get_bin_path() method
    assert test_class.get_default_interfaces('') == ({}, {})

# Generated at 2022-06-20 17:49:29.412234
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    aix_network = AIXNetwork(module)

# Generated at 2022-06-20 17:49:33.563430
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    iface_collector = AIXNetworkCollector(module=module)
    assert isinstance(iface_collector, NetworkCollector)



# Generated at 2022-06-20 17:49:42.305437
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    if_module = AIXNetwork(module)

    # Successfully read default gateway from netstat output
    if_module.module.run_command = lambda x, check_rc=True: (0, "default 192.0.2.254 UG 0 7 en1", "")
    if_v4, if_v6 = if_module.get_default_interfaces("netstat")
    assert if_v4['gateway'] == "192.0.2.254"
    assert if_v4['interface'] == "en1"
    assert if_v6 == {}

    # Successfully read both IPv4 and IPv6 default gateways from netstat output

# Generated at 2022-06-20 17:49:50.741570
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module=module)
    interfaces = network.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    print(network.get_interfaces_info('/usr/sbin/ifconfig', '-a'))
    print(network.get_interfaces_info('/etc/asdf', '-a'))
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-20 17:50:00.643734
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    # create testing object
    myTest = AIXNetwork()

    # substitute for run_command, return given string
    myTest.module.run_command = lambda args: ['', args[1], '']
    myTest.module.get_bin_path = lambda args: args

    # create sample data to test against

# Generated at 2022-06-20 17:50:11.351447
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_obj = AIXNetwork()

    assert test_obj.parse_interface_line(['en0:']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': []}
    assert test_obj.parse_interface_line(['en0:', 'flags=1<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']}

# Generated at 2022-06-20 17:50:36.140339
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network = AIXNetwork()

    assert network.get_default_interfaces == AIXNetwork.get_default_interfaces
    assert network.get_interfaces_info == AIXNetwork.get_interfaces_info
    assert network.parse_interface_line == AIXNetwork.parse_interface_line
    assert network.parse_options_line == AIXNetwork.parse_options_line
    assert network.parse_nd6_line == AIXNetwork.parse_nd6_line
    assert network.parse_ether_line == AIXNetwork.parse_ether_line
    assert network.parse_media_line == AIXNetwork.parse_media_line
    assert network.parse_status_line == AIXNetwork.parse_status_line
    assert network.parse_lladdr_line == AIXNetwork.parse_lladdr_line
    assert network

# Generated at 2022-06-20 17:50:46.027546
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import json
    import os.path
    import sys
    import tempfile

    class ModuleStub(object):

        def get_bin_path(self, arg1):
            return 'netstat'


# Generated at 2022-06-20 17:50:56.473412
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    netstat_path = '/usr/bin/netstat'
    route_path = '/etc/netstat'

    # Fake the module
    class FakeModule(object):
        def get_bin_path(self, path, opts=None):
            # Always return the same path
            return netstat_path
        def run_command(self, cmd):
            # Return the correct output
            return 0, """
Kernel IP routing table
Destination Gateway Flags Refs Use Interface
default     10.0.0.1      UG   2   325 en1
10.0.0.0/8 link#4      UCSI  0 0 en1
10.0.0.1    0:11:22:33:44:55  UHLWIi   2   205 en1      814
""", ""

    facts_module = AIXNetwork

# Generated at 2022-06-20 17:51:06.651360
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    s = AIXNetwork()
    words = ['en3:', 'flags=1E080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND>']
    ifc = s.parse_interface_line(words)
    assert ifc['device'] == 'en3'
    assert ifc['flags'] == 'UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND'
    assert ifc['type'] == 'unknown'


# Generated at 2022-06-20 17:51:11.732809
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(basic.AnsibleModule)
    aix_network = AIXNetwork(generic_bsd_ifconfig_network)
    assert aix_network

# Generated at 2022-06-20 17:51:23.530565
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Constructor of class AIXNetwork
    result = AIXNetwork()

    # Check type of `result`
    assert isinstance(result, AIXNetwork)

    # Check attributes of object
    assert result.platform == 'AIX'

    # Check attributes of object
    assert result.default_collectors == ['generic_bsd', 'aixtcpip']

    # Check attributes of object
    assert result.valid_providers == {'route': 'get_default_interfaces', 'ifconfig': 'get_interfaces_info'}

    # Check attributes of object
    assert result.interfaces_fact_class == 'ansible.module_utils.facts.network.interfaces.Linux_Interfaces'

    # Check attributes of object

# Generated at 2022-06-20 17:51:28.855410
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:51:37.727501
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModuleMock()
    AIXnet = AIXNetwork(module)

    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '10.7.126.39', 'netmask', '0xffffff00', 'broadcast', '10.7.126.255']
    current_if = AIXnet.parse_interface_line(words)

    assert(current_if['device'] == 'en0')

# Generated at 2022-06-20 17:51:49.735724
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('test_module', (object,), {})
    module.params = {}
    module.run_command = lambda *args: (0, '', '')
    module.get_bin_path = lambda path: path
    network_collector = AIXNetworkCollector(module=module)
    network = AIXNetwork(network_collector=network_collector)


# Generated at 2022-06-20 17:51:58.689459
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {'run_command': lambda self, cmd: (0, 'default 127.0.0.1 UG 0' + '\n' + 'default ::1 UG 32768' + '\n', ''),
                           'get_bin_path': lambda self, cmd: cmd})()
    net = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    (ipv4_default, ipv6_default) = net.get_default_interfaces(route_path)
    assert ipv4_default == {'gateway': '127.0.0.1', 'interface': '0'}
    assert ipv6_default == {'gateway': '::1', 'interface': '32768'}

# Generated at 2022-06-20 17:52:22.400010
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Create a dict that represents a single line of the output of
    # ifconfig -a
    def create_line(opcode, data):
        return opcode + ' ' + ' '.join(map(str, data)) + '\n'

    # Create the output of ifconfig -a
    def create_ifconfig_a_output(**ifconfig_a_output):

        output = ''
        for ifname in ifconfig_a_output:
            output += create_line('ent0:', ifconfig_a_output[ifname]['ent0'])
            if 'ent1' in ifconfig_a_output[ifname]:
                output += create_line('ent1:', ifconfig_a_output[ifname]['ent1'])
        return output

    # Create the expected output of get_interfaces_info of class AI

# Generated at 2022-06-20 17:52:33.565042
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # This object will be passed to get_default_interfaces method as 'self' argument
    aix = AIXNetwork()

    # It is expected to return a dictionary with two keys: IPv4 and IPv6

# Generated at 2022-06-20 17:52:45.436316
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class Module:
        def get_bin_path(self, name):
            if name == 'netstat':
                return '/usr/bin/netstat'
            return None

        def run_command(self, cmd):
            nrc = 0
            nout = """
            default 192.168.122.1 UGS
            default ::1 UGS
            default fe80::1 UGS
            default fe80::2e0:4cff:fe8e:9f2d UGS
            """
            nerrs = ''
            return nrc, nout, nerrs

    class Facts:
        def __init__(self):
            self.module = Module()
            self.network = AIXNetwork(self.module)


# Generated at 2022-06-20 17:52:54.776363
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    file = open('aix_ifconfig_a', 'r')
    output = file.read()
    file.close()

    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.run_command = MagicMock(return_value=(0, output, ''))

    obj = AIXNetwork()
    obj.module = ansible_module

    interfaces, ips = obj.get_interfaces_info('/usr/sbin/ifconfig')

    assert interfaces['lo0']['ipv4'] == [{
        'address': '127.0.0.1',
        'netmask': '255.0.0.0',
        'broadcast': '127.255.255.255'
        }]


# Generated at 2022-06-20 17:53:01.951910
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 17:53:03.100400
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)

# Generated at 2022-06-20 17:53:13.700245
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector

    Object instantiation creates a set of (key, value) pairs,
    where the key is the name of the fact and the value is a
    fact collecting object.

    A fact collecting object is instantiated with the module object,
    and it has to implement a method called populate_facts().

    The method populate_facts() returns another set of (key, value)
    pairs.

    The key-value pairs returned by the method populate_facts() are
    then merged into the original set of key-value pairs in the main
    object (the original set of key-value pairs is not changed).
    """

    # Initialize object of class AIXNetworkCollector
    # without arguments
    obj1 = AIXNetworkCollector()

    # Initialize object of class AIXNetworkCollector
    # with

# Generated at 2022-06-20 17:53:16.061255
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-20 17:53:23.683853
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # original test from GenericBsdIfconfigNetwork
    result = AIXNetwork(dict(module=dict(run_command=run_command)))
    assert result.module.run_command == run_command
    assert result.platform == 'AIX'
    assert result.interfaces == []
    assert result.default_interface == {}
    assert result.default_ipv4 == {}
    assert result.default_ipv6 == {}

    # own test
    mod_ret_run_command = dict(
        rc=0,
        stdout='',
        stderr='',
    )

# Generated at 2022-06-20 17:53:35.863828
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces() of class AIXNetwork."""
    AIXNetwork = AIXNetworkCollector.get_network_collector_class()

    class TestModule(object):
        """Test module for class AIXNetwork."""
        def __init__(self):
            self.params = {}

        def get_bin_path(self, _):
            """Fake get_bin_path method for class AIXNetwork."""
            return '/usr/bin/netstat'

        def run_command(self, cmd):
            """Fake run_command method for class AIXNetwork."""
            output = ""

# Generated at 2022-06-20 17:54:08.071866
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network.platform == 'AIX'


# Generated at 2022-06-20 17:54:16.150743
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = DummyModule()
    aix_network = AIXNetwork(module)
    rc1 = 0
    out1 = 'default 192.168.1.1 UGHD 12 1231 lo0'
    rc2 = 0
    out2 = 'default fe80::%en0 UGHD 12 1231 en0'
    rc3 = 0
    out3 = 'default fe80::%en1 UGHD 12 1231 en1'
    rc4 = 0
    out4 = 'default 192.168.2.1 UGHD 12 1231 en0'
    rc5 = 0
    out5 = 'default fe80::%lo0 UGHD 12 1231 lo0'
    rc6 = 0
    out6 = 'default fe80::%en2 UGHD 12 1231 en2'
    module.run_command.side

# Generated at 2022-06-20 17:54:22.294556
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['test0:', 'flags=8843', 'mtu', '16384', 'index', '4']
    current_if = AIXNetwork.parse_interface_line(AIXNetwork(), words)
    assert current_if['device'] == 'test0'
    assert current_if['flags'] == '8843'
    assert current_if['macaddress'] == 'unknown'
    assert 'mtu' not in current_if    # removed because missing in AIXNetwork.get_interfaces_info



# Generated at 2022-06-20 17:54:23.832244
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork(dict(module=dict()))
    assert aix_network

# Generated at 2022-06-20 17:54:29.584791
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = AIXNetwork()
    m.module = MagicMock()
    m.run_command = MagicMock()
    m.module.run_command.return_value = [0, '', '']
    m.get_bin_path = MagicMock()
    m.get_bin_path.return_value = None
    r4, r6 = m.get_default_interfaces('route')
    assert r4 == r6 == {}

    m.get_bin_path.return_value = '/usr/bin/netstat'
    m.module.run_command = MagicMock()
    m.module.run_command.return_value = [0, 'default ' + '1.1.1.1' + ' 1 u ' + '2.2.2.2', '']

# Generated at 2022-06-20 17:54:37.207051
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    uname_path = module.get_bin_path('uname')
    if uname_path:
        uname_rc, uname_out, uname_err = module.run_command([uname_path, '-W'])
        if uname_rc == 0 and uname_out.split()[0] == '0':
            # we are in wpar but net-tools is not available there
            pass
        else:
            AIXNetwork()
            assert True
    else:
        assert True


# Generated at 2022-06-20 17:54:39.317780
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = NetworkCollector._create_module()
    collector = AIXNetworkCollector(module=module)
    assert collector.get_facts() == collector.collect()

# Generated at 2022-06-20 17:54:46.281773
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    assert AIXNetwork().parse_interface_line(['en0:']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert AIXNetwork().parse_interface_line(['fcs0:']) == {'device': 'fcs0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert AIXNetwork().parse_interface_line(['ent0:']) == {'device': 'ent0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 17:54:47.942743
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = None
    AIXNetwork(module)

# Generated at 2022-06-20 17:54:55.298202
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = type('module', (object,), {})()
    test_module.run_command = lambda x: (0, x[1], '')
    test_module.get_bin_path = lambda x: 'test_bin'
    test_module.fail_json = lambda **x: None

    ifc = AIXNetwork(test_module)

    assert ifc.parse_interface_line(['en0:', 'flags=0x1,1<UP,BROADCAST>']) == {'device': 'en0', 'type': 'unknown', 'ipv4': [], 'ipv6': [], 'flags': ['UP', 'BROADCAST'], 'macaddress': 'unknown'}

# Generated at 2022-06-20 17:56:04.542362
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnet = AIXNetworkCollector()
    # aix network collector has its own class as fact class
    assert aixnet._fact_class.__name__ == 'AIXNetwork'
    # aix network collector has its own platform
    assert aixnet._platform == 'AIX'

# Generated at 2022-06-20 17:56:16.042545
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    aix = AIXNetwork(module=module)

    # Legacy data format
    module.run_command.return_value = (0, 'default 192.168.0.1 UG    0 0   en37\ndefault 192.168.1.1 UG    0 0   en38\ndefault :: UG    0 0   lo0\n', '')
    module.get_bin_path.return_value = True
    v4, v6 = aix.get_default_interfaces('route_path')
    assert v4['gateway'] == '192.168.0.1'
    assert v4['interface'] == 'en37'
    assert v6['gateway'] == '::'
    assert v6['interface'] == 'lo0'



# Generated at 2022-06-20 17:56:25.039199
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    print("test_AIXNetwork_get_interfaces_info")
    import sys
    import os
    import ansible.module_utils.facts.network.aix as aix
    from ansible.module_utils.facts.network.aix import AIXNetwork

    class FakeModule():
        def __init__(self):
            self._debug = True
        def debug(self, msg):
            print(msg)
        def get_bin_path(self, path):
            return "test_bin_path"

    class FakeCmd():
        def __init__(self, module, command):
            self._module = module
            self._command = command
        def __run(self, output):
            print("--- {}".format(self._command))

# Generated at 2022-06-20 17:56:31.275692
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    #pylint: disable=R0903
    # TODO: add a test to check that AIXNetwork really uses GenericBsdIfconfigNetwork
    module = None
    network = AIXNetwork(module)
    assert network.platform == 'AIX'


# Generated at 2022-06-20 17:56:37.986592
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.base import Network
    import platform

    module = AnsibleModuleMock()
    module.run_command = module_run_command
    module.params = dict(gather_subset=['all'])
    module.get_bin_path = module_get_bin_path

    network_collector = Network(module)
    network_collector.get_interfaces_info = get_interfaces_info_mock
    network_collector.get_default_interfaces = get_default_interfaces_mock
    network_collector.platform = platform
    network_collector.platform.system = lambda: 'AIX'

    network_facts = network_collector.get_network_facts()

# Generated at 2022-06-20 17:56:47.850506
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create a dictionary of module_utils.basic.AnsibleModule return values
    #   defaultdict(lambda: None, {'module': module, 'threshold': threshold,
    #   'wait': wait, 'path': path, 'fact_path': fact_path, 'verbose': verbose})

    test_module = dict(
        params=dict(
            gather_subset='min')
    )

    # Create a dictionary of AnsibleModule return values
    #   defaultdict(lambda: None, {'command': command, 'rc': rc, 'stdout': stdout,
    #   'stderr': stderr, 'start': start, 'end': end, 'delta': delta, 'msg': msg,
    #   'changed': changed, 'invocation': invocation, 'module_name': module_name
    #  

# Generated at 2022-06-20 17:56:54.760988
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:57:00.967029
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    (facts_module_mock, _ansible_module_mock) = get_module_mock()
    network_collector = AIXNetworkCollector(facts_module_mock)
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork

# Unit test if the function AIXNetwork.get_default_interfaces()
# gets the macaddress for AIX 6.1.

# Generated at 2022-06-20 17:57:13.296077
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork.
    It is taken an output of ifconfig -a command and it is ensured
    that the method returns the right results
    """
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    module_aix = MockModuleAIX()

    network_aix = AIXNetwork(module=module_aix)
    file_handler_aix = MockFileHandlerAIX()
    network_aix.read_file_lines = file_handler_aix.read_file_lines


# Generated at 2022-06-20 17:57:20.615980
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    _handler = AIXNetworkCollector({})

    def get_file_content(filename):
        if filename == '/etc/myroute':
            return 'default: gateway: en1 fe80::a00:27ff:fe0f:c7f2%en1 v6 default: gateway: 192.168.0.1 en1'
        else:
            return ''

    _handler.module.get_file_content = get_file_content
    _handler.get_default_interfaces('/etc/myroute')

    assert _handler._fact_class.interface['v4']['gateway'] == '192.168.0.1'
    assert _handler._fact_class.interface['v6']['gateway'] == 'fe80::a00:27ff:fe0f:c7f2%en1'