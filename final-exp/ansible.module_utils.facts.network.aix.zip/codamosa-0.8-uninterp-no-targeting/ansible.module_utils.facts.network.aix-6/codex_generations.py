

# Generated at 2022-06-20 17:49:00.727099
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    This function tests creation of the object of class AIXNetwork.
    """
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module=module)
    assert network.platform == 'AIX'
    assert network.ifconfig_path == '/usr/sbin/ifconfig'
    assert network.route_path == '/usr/sbin/route'



# Generated at 2022-06-20 17:49:11.127384
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class module():
        def __init__(self):
            self.run_command_count = 0

        @staticmethod
        def fail_json(*args, **kwargs):
            """function to stub AnsibleModule.fail_json"""
            pass

        @staticmethod
        def get_bin_path(name):
            """function to stub AnsibleModule.get_bin_path"""
            if name == 'uname':
                return name
            elif name == 'ifconfig':
                return name
            elif name == 'netstat':
                return name
            else:
                return None

        def run_command(self, args):
            self.run_command_count += 1
            if args[0] == 'uname':
                return 0, '0 AIX 7.1', ''

# Generated at 2022-06-20 17:49:21.332248
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible = AnsibleModule({})
    testNetwork = AIXNetwork(ansible)
    assert isinstance(testNetwork, object)

    expectedInterface = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'WITHMTU']}

    words = ['en0', 'flags=842<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,WITHMTU>']
    testInterface = testNetwork.parse_interface_line(words)

    assert testInterface == expectedInterface

    return True


# Generated at 2022-06-20 17:49:25.867048
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # test_ifconfig_path, test_route_path not used in constructor of class AIXNetworkCollector
    # test_sysctl_path not used in AIX ifconfig facts
    test_AIX_net = AIXNetworkCollector(test_ifconfig_path=None, test_route_path=None, test_sysctl_path=None)
    assert isinstance(test_AIX_net, AIXNetworkCollector)


# Generated at 2022-06-20 17:49:31.813641
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    AIXNetwork unit test
    """

    assert AIXNetwork
    # assert AIXNetwork(dict())

    s = AIXNetwork()
    assert s.device_regex
    assert s.ignored_regexs
    assert s.network_prefix
    assert s.ignored_interface_list
    assert s.default_ipv4_interface
    assert s.default_ipv6_interface
    assert s.interfaces
    assert s.ipv4
    assert s.ipv6
    assert s.all_ipv4_addresses
    assert s.all_ipv6_addresses



# Generated at 2022-06-20 17:49:41.445187
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import tempfile
    # Create a temporary file to hold test data

# Generated at 2022-06-20 17:49:44.723105
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = {}
    network_collector = AIXNetworkCollector(result)
    assert repr(network_collector) == repr({})
    assert network_collector.result == {}

# Generated at 2022-06-20 17:49:52.138885
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_netstat_path = 'test_data/netstat_01'
    test_netstat_path_02 = 'test_data/netstat_02'

    # no netstat
    iface_v4, iface_v6 = AIXNetwork(dict(module=dict())).get_default_interfaces(None)
    assert iface_v4 == dict()
    assert iface_v6 == dict()

    # netstat present, no default gw
    iface_v4, iface_v6 = AIXNetwork(dict(module=dict(get_bin_path=lambda x: test_netstat_path_02))).get_default_interfaces(None)
    assert iface_v4 == dict()
    assert iface_v6 == dict()

    # netstat present, default gw

# Generated at 2022-06-20 17:50:01.650248
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Default interface
    network = AIXNetwork(dict(module=dict()), dict())
    route_path = 'target/test/test_AIXNetwork_get_default_interfaces/route'
    network.module.get_bin_path.return_value = route_path
    network.module.run_command.return_value = (0, 'default 192.168.1.1 UGS en0 0      0        -\ndefault ::/0     UGS lo0      4      56    32768\n', '')
    assert network.get_default_interfaces(route_path) == ({'interface': 'en0', 'gateway': '192.168.1.1'}, {'interface': 'lo0', 'gateway': '::/0'})


# Generated at 2022-06-20 17:50:13.264159
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    uname_path = '/usr/bin/uname'
    module = AnsibleModule(argument_spec={})

    aixnetwork = AIXNetwork(module)
    aixnetwork.module.run_command = MagicMock(return_value=(0, '', ''))

    m = aixnetwork.module.run_command.return_value[0]
    o = aixnetwork.module.run_command.return_value[1]
    e = aixnetwork.module.run_command.return_value[2]
    aixnetwork.module.run_command = MagicMock(return_value=(m, o, e))
    aixnetwork.module.get_bin_path = MagicMock(return_value=uname_path)


# Generated at 2022-06-20 17:50:25.237490
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork()


# Generated at 2022-06-20 17:50:32.398049
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork = AIXNetwork()
    case1 = AIXNetwork.parse_interface_line(['lo0:'])
    assert case1 == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'}

    case2 = AIXNetwork.parse_interface_line(['en0: flags=1e084863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> metric 0 mtu 1500'])

# Generated at 2022-06-20 17:50:42.177003
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network_collector_instance = AIXNetworkCollector(None)
    network_instance = network_collector_instance._fact_class(None)
    network_instance.module.run_command = lambda args: (0, "default 192.168.1.1 UG 1 en0\ndefault ::1 UG 1 lo0", "")
    assert {'interface': 'en0', 'gateway': '192.168.1.1'} == network_instance.get_default_interfaces("route")
    assert {'interface': 'lo0', 'gateway': '::1'} == network_instance.get_default_interfaces("route6")


# Generated at 2022-06-20 17:50:48.925642
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    module = AnsibleModuleMock()
    aix_network = AIXNetwork(module, ifconfig_path, ifconfig_options)
    options = {'alias': 'alias', 'lladdr': 'lladdr', 'media': 'media',
               'status': 'status', 'nd6': 'nd6', 'ether': 'ether'}
    assert aix_network.options == options
    assert aix_network.platform == 'AIX'
    assert not aix_network.options_regex


# Generated at 2022-06-20 17:50:50.142025
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network = AIXNetworkCollector()

    assert network


# Generated at 2022-06-20 17:50:58.612149
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = type('module', (object, ), dict(path=dict(alias=[dict(path='/sbin/ifconfig')], ifconfig=['/sbin/ifconfig'])))
    test_module.run_command = lambda args, check_rc=True: (0, '', '')
    test_network = AIXNetwork(module=test_module)
    interfaces, ips = test_network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['device'] == 'lo0'

# Generated at 2022-06-20 17:51:09.217463
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    gbi_get_default_interfaces = GenericBsdIfconfigNetwork().get_default_interfaces

    rcp = dict()
    rcp['gbi_return_code'] = 0
    rcp['gbi_rc'] = 0

# Generated at 2022-06-20 17:51:20.748073
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from unittest import TestCase, mock

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command = mock.Mock()

        def get_bin_path(self, name, required=False):
            return '/bin/netstat'

    fake_module = FakeModule()

# Generated at 2022-06-20 17:51:31.730162
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class FakeModule:
        def __init__(self):
            self.params = dict(
                gather_network_resources=['all'],
                config_file=None,
            )

        def get_bin_path(self, executable):
            return '/usr/sbin/' + executable

        def fail_json(self, *_, **kwargs):
            raise Exception(kwargs['msg'])

        def run_command(self, args):
            if 'ifconfig' in args:
                return 0, fake_out, ''
            elif 'uname' in args:
                return 0, '3', ''
            elif 'entstat' in args:
                return 0, entstat_out, ''
            elif 'lsattr' in args:
                return 0, lsattr_out, ''

# Generated at 2022-06-20 17:51:39.265650
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = type('AnsibleModule', (object,), {})()
    module.get_bin_path = lambda x: '/sbin/%s' % x
    module.run_command = lambda x: (0, '', '')
    network = AIXNetwork(module=module)

    # this is the original line from AIX:
    # ent0: flags=0x41<UP,BROADCAST,RUNNING>
    # this contains the data to be parsed:
    words = ['ent0:', 'flags=0x41<UP,BROADCAST,RUNNING>']
    parsed = network.parse_interface_line(words)
    assert parsed['device'] == 'ent0'
    assert parsed['type'] == 'unknown'
    assert parsed['flags'] == ['UP', 'BROADCAST', 'RUNNING']

# Generated at 2022-06-20 17:52:04.729383
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert(nc.platform == 'AIX')
    assert(nc.fact_class == AIXNetwork)


# Generated at 2022-06-20 17:52:13.269636
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fact_network = AIXNetwork()
    facts = fact_network.__get_facts__()

    route_path = fact_network.module.get_bin_path('route')
    ipv4_dflt_gw, ipv6_dflt_gw = fact_network.get_default_interfaces(route_path)

    assert ipv4_dflt_gw['interface'] == facts['default_ipv4']['interface'] and \
        ipv4_dflt_gw['gateway'] == facts['default_ipv4']['gateway']
    assert ipv6_dflt_gw['interface'] == facts['default_ipv6']['interface'] and \
        ipv6_dflt_gw['gateway'] == facts['default_ipv6']['gateway']


# Generated at 2022-06-20 17:52:23.657640
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class All:
        def __init__(self, mydict):
            self.__dict__ = mydict

    class FakeModule:
        def __init__(self, mydict):
            self.__dict__ = mydict
            self.params = All(mydict['params'])

    class ModuleUtil:
        def __init__(self, mydict):
            self.__dict__ = mydict

    class FakeCommand:
        def __init__(self, mydict):
            self.__dict__ = mydict


# Generated at 2022-06-20 17:52:27.814095
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collector = AIXNetworkCollector(module=module, facts=dict())
    assert collector.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-20 17:52:36.385916
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os

    c = AIXNetwork(dict(module=dict(params=dict(gather_subset=['default']))), None)

    # There is no default route
    rc, out, err = os.system("/usr/sbin/netstat -nr > /tmp/netstat-route.txt && echo SUCCESS >> /tmp/netstat-route.txt")
    with open("/tmp/netstat-route.txt", 'r') as fp:
        lines = fp.readlines()

    if lines[-1].split()[0] == 'SUCCESS':
        os.remove("/tmp/netstat-route.txt")
    assert (lines[0] == 'P.I.P.  Destination Gateway   Flags Refs If  Exp Time  Interface\n')
    out = c.get_default_

# Generated at 2022-06-20 17:52:47.443986
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, Mock

    class TestAIXNetwork(unittest.TestCase):
        def setUp(self):
            self.mock_module = type('module', (object,), {'run_command': Mock()})()
            self.mock_module.run_command.return_value = (0, 'out', 'err')
            self.mock_module.get_bin_path.return_value = 'ifconfig'

            self.network = AIXNetwork(self.mock_module)


# Generated at 2022-06-20 17:52:49.361353
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector"""

    x = AIXNetworkCollector()
    assert x.platform == 'AIX'


# Generated at 2022-06-20 17:52:58.156618
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    Test of method get_interfaces_info of class AIXNetwork
    and especially ifconfig -a output parsing.
    '''


# Generated at 2022-06-20 17:53:10.094784
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import sys
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import ansible.module_utils.facts.network.aix
    import inspect
    # Check if super class is 'object'
    obj_name = inspect.getmro(AIXNetworkCollector)[1].__name__
    assert obj_name == 'NetworkCollector', \
        "Super class of AIXNetworkCollector should have been 'NetworkCollector' but found '{0}'".format(obj_name)

    # Check if super class 'NetworkCollector' has been cached (for performance reasons)

# Generated at 2022-06-20 17:53:18.682799
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetwork(module)

    assert network_collector.get_default_interfaces("") == ({}, {})

    module.run_command.return_value = (0, "", "")
    assert network_collector.get_default_interfaces("") == ({}, {})

    module.run_command.return_value = (0, "default       10.75.3.1        UGS         en0", "")
    assert network_collector.get_default_interfaces("") == ({'interface': 'en0', 'gateway': '10.75.3.1'}, {})


# Generated at 2022-06-20 17:54:05.580074
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = MockModule()
    net.module.run_command = Mock(return_value=(0, 'default 172.17.0.1 UG 2 0 en0', ''))
    route_path = net.module.get_bin_path('netstat')
    net.get_default_interfaces(route_path)


# Generated at 2022-06-20 17:54:10.307671
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    aix_network = AIXNetwork()

    aix_network.get_default_interfaces('/usr/sbin/netstat')
    aix_network.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    aix_network.parse_interface_line(['en0:'])

# Generated at 2022-06-20 17:54:12.778636
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network = AIXNetworkCollector()
    assert aix_network is not None


# Generated at 2022-06-20 17:54:22.466329
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # prepare module, with the test output of ifconfig
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock(return_value=ifconfig_output)
    network_module = AIXNetwork(module)

    # test
    network_module.get_interfaces_info = mock.Mock()
    network_module.get_interfaces_info.return_value = ifconfig_result
    interfaces, ports = network_module.get_interfaces_info()

    # check results
    assert interfaces == ifconfig_result[0]
    assert ports == ifconfig_result[1]
    assert len(interfaces) == 16
    assert len(ports) == 16
    assert len(ports['all_ipv6_addresses']) == 7
    assert 'eth0' in interfaces



# Generated at 2022-06-20 17:54:23.960441
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class is AIXNetwork



# Generated at 2022-06-20 17:54:26.174084
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_network = AIXNetwork(test_module)

    assert test_network.get_default_interfaces('/usr/sbin/route') == ({}, {})

# Generated at 2022-06-20 17:54:37.869559
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec={})
    net = AIXNetwork(mod)
    assert net.facts['default_ipv4']['gateway'] == '10.1.3.1'
    assert net.facts['default_ipv4']['interface'] == 'en0'
    assert net.facts['default_ipv6']['gateway'] == 'fe80::94e4:bfff:fe0d:a62b%en0'
    assert net.facts['default_ipv6']['interface'] == 'en0'
    assert net.facts['all_ipv4_addresses'] == ['10.1.3.102']
    assert net.facts['all_ipv6_addresses'] == ['fe80::94e4:bfff:fe0d:a62b']
   

# Generated at 2022-06-20 17:54:46.615527
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """

    test = AIXNetwork(None)

    # test case 1
    # test empty string
    # expected output: ({}, {})
    test_input = ''
    expected = ({}, {})
    observed = test.get_interfaces_info(test_input)
    assert observed == expected, \
        "expected {}, but observed {}".format(expected, observed)

    # test case 2
    # test a line that cannot be parsed by AIX netowrk class
    # expected output: ({}, {})
    test_input = '''
    #ifconfig -a
    '''
    expected = ({}, {})
    observed = test.get_interfaces_info(test_input)

# Generated at 2022-06-20 17:54:55.386760
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:55:01.428923
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.test_data import ifconfig_result_sample
    # setup a test object
    aixnetwork = AIXNetwork(None)
    # test the method
    test_return_value = aixnetwork.get_interfaces_info('ifconfig', '-a')
    assert test_return_value == ifconfig_result_sample



# Generated at 2022-06-20 17:56:45.928764
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    AIXNetwork.get_interfaces_info(None, ifconfig_path, ifconfig_options)

# Generated at 2022-06-20 17:56:53.161966
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    aix_network = AIXNetwork('/usr/bin/ifconfig')

    assert aix_network.platform == 'AIX'
    assert aix_network._has_addr_show == False
    assert aix_network._has_ip_addr == False
    assert aix_network._has_iproute2 == False
    assert aix_network._has_netstat == True
    assert aix_network._has_ifconfig == True
    assert aix_network._ifconfig_path == '/usr/bin/ifconfig'
    assert aix_network._route_path == None
    assert aix_network._netstat_path == None
    assert aix_network._ip_path == None


# Generated at 2022-06-20 17:57:03.659983
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    network = AIXNetwork()

    (interfaces, ips) = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['flags'] == ['BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['ipv4'] == []
    assert interfaces['en0']['ipv6'] == []

# Generated at 2022-06-20 17:57:14.440481
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    assert issubclass(AIXNetworkCollector, Collector)
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._command == 'ifconfig -a'
    assert AIXNetworkCollector._fact_name == 'ansible_net_all_ipv4_addresses'
    assert AIXNetworkCollector._required_facts == ['kernel', 'domain', 'fqdn']

# Test constructor of AIXNetworkCollector
test_AIXNetworkCollector()


# Generated at 2022-06-20 17:57:18.534087
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix = AIXNetwork()
    assert aix.platform == 'AIX'
    assert aix.all_ipv4_addresses == []
    assert aix.all_ipv6_addresses == []
    assert aix.interfaces == {}
    assert aix.default_interface == {}


# Generated at 2022-06-20 17:57:27.684653
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    node = dict()
    node['default'] = dict()
    node['default']['v4'] = dict()
    node['default']['v4']['interface'] = 'en4'
    node['default']['v4']['gateway'] = '192.168.1.1'
    aix = AIXNetwork()
    result = aix.get_default_interfaces('')

    assert node == result

# Generated at 2022-06-20 17:57:31.968929
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network._platform == 'AIX'
    assert isinstance(aix_network._fact_class, AIXNetwork)


# Generated at 2022-06-20 17:57:42.670442
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    network = AIXNetwork(test_module)
    test1 = network.parse_interface_line(['en0:', 'flags=540902<UP,BROADCAST,RUNNING,MULTICAST,DELAY>', 'mtu', '1500'])
    assert test1 == {
        'device': 'en0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': {'broadcast': True, 'delay': True, 'multicast': True, 'running': True, 'up': True},
        'macaddress': 'unknown',
    }

# Generated at 2022-06-20 17:57:45.113697
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'


# Generated at 2022-06-20 17:57:51.489940
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import CommonBsdIfconfigNetwork

    class BsdIfconfigNetwork(CommonBsdIfconfigNetwork):
        def get_interfaces_info(self, ifconfig_path, ifconfig_options='-a'):
            return (
                super(BsdIfconfigNetwork, self).get_interfaces_info(
                    ifconfig_path,
                    ifconfig_options
                )
            )
