

# Generated at 2022-06-20 17:49:02.466103
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create a fake module object
    m = type('AnsibleModule', (object,), {'run_command': run_command})

    n = AIXNetwork(m)

    gateway_ipv4, gateway_ipv6 = n.get_default_interfaces('route')

    assert gateway_ipv4 == {'gateway': '10.20.0.1', 'interface': 'en0'}
    assert gateway_ipv6 == {'gateway': 'fe80::250:bfff:fef2:cfb4', 'interface': 'en0'}


# Generated at 2022-06-20 17:49:12.463357
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = MagicMock()
    net.module.get_bin_path.return_value = '/usr/bin/netstat'
    net.module.run_command.return_value = (0, 'default 192.168.0.254 UG 0 0 en0\ndefault fe80::%p204:1:3:8:0:0 UG 0 0 fred\ndefault ::1 UG 0 0 lo0\ncmics 192.168.0.0 UGSc 0 0 en1\nlink#1 UC 0 0 lo0\nlink#2 UC 0 0 fred\n', '')

# Generated at 2022-06-20 17:49:22.950285
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test cases for method get_default_interfaces of class AIXNetwork
    """

    # check the routes output given in:
    # https://www.ibm.com/support/knowledgecenter/ssw_aix_72/network/alters_a_route.html

    # this is the output from netstat -nr
    #
    # default      192.10.1.1     UG        1  10 en0
    # 127          127.0.0.1      UH        0   9 664
    # 192.168.1    192.168.96.1       UG        0   8 en1
    # 192.168.96   0.0.0.0      U         0   8 en1
    # 224          127.0.0.1      UH        0   9 664
    # 255         

# Generated at 2022-06-20 17:49:25.902856
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_coll = AIXNetworkCollector()
    assert isinstance(net_coll, NetworkCollector)
    assert isinstance(net_coll._fact_class, AIXNetwork)
    assert net_coll._platform == 'AIX'

# Generated at 2022-06-20 17:49:28.239750
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class is AIXNetwork

# Generated at 2022-06-20 17:49:31.787974
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AIXNetwork()
    assert module.platform == 'AIX'
    assert module.get_interfaces_info == AIXNetwork.get_interfaces_info



# Generated at 2022-06-20 17:49:33.304980
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert result.platform == 'AIX'

# Generated at 2022-06-20 17:49:35.578089
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    test_obj = AIXNetwork(dict(module=dict()))
    assert test_obj


# Generated at 2022-06-20 17:49:45.303355
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    module.params = dict(
        gather_subset='!all',
        gather_network_resources='default_ipv4,default_ipv6',
    )
    network = AIXNetwork(module=module)
    network.get_default_interfaces(route_path='/usr/bin/netstat')

    assert network.interface_has_ip('default_ipv4') == True
    assert network.get_default_interface_from_ip('default_ipv4', '192.168.44.1') == 'en0'
    assert network.interface_has_ip('default_ipv6') == True

# Generated at 2022-06-20 17:49:52.427592
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MockModule()
    module.run_command = Mock(side_effect=[
        (1, '', 'error'),
        (2, '', 'error'),
        (0, '', ''),
    ])

    cls = AIXNetwork(module)

    module.run_command.reset_mock()

# Generated at 2022-06-20 17:50:10.517863
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    def test(route_path, expected_result):
        collector = AIXNetworkCollector(dict(path=dict(route=route_path)))
        result = collector.get_default_interfaces(route_path)
        assert result == expected_result

    test('/usr/bin/netstat', {'gateway': '192.168.0.1', 'interface': 'en1'})

# Generated at 2022-06-20 17:50:21.316615
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_line = """en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
                inet 10.68.188.40 netmask 0xffffff00 broadcast 10.68.188.255
                tcp_sendspace 131072 tcp_recvspace 131072 rfc1323 1"""

    test_network = AIXNetwork()
    test_network.parse_interface_line(ifconfig_line.split())


# Generated at 2022-06-20 17:50:25.723881
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

    assert aix_network_collector.platform == 'AIX'

    assert aix_network_collector.default_output=="text"
    assert aix_network_collector.default_options=="a"
    assert aix_network_collector.fact_class == AIXNetwork

# Generated at 2022-06-20 17:50:27.571860
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nx=AIXNetworkCollector()
    assert nx.platform == 'AIX'
    assert nx._fact_class == AIXNetwork


# Generated at 2022-06-20 17:50:33.622250
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This function tests the NetworkCollector for AIX.
    :return:
    """
    # setup
    fake_module = FakeModule()
    # test specific setup
    fake_module.run_command = [
        [[0, netstat_out_default_ipv4, '']],
        [[0, netstat_out_default_ipv6, '']],
        [[0, netstat_out_default_ipv4_and_ipv6, '']],
        [[0, netstat_out_default_no_ipv4_nor_ipv6, '']],
    ]
    # test
    ipv4, ipv6 = AIXNetwork(fake_module).get_default_interfaces('/etc/route')

# Generated at 2022-06-20 17:50:44.365440
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # create an instance of AIXNetwork
    ansible_module = type('AnsibleModule', (object,), {'params': {'gather_subset': ['all']}})
    aix = AIXNetwork(ansible_module)

    # get the ifconfig_path of AIXNetwork
    ifconfig_path = aix.get_ifconfig_path()

    # create an instance of AIXNetworkCollector
    aix_collector = AIXNetworkCollector()

    # get the default_ifconfig_path of AIXNetworkCollector
    default_ifconfig_path = aix_collector.get_default_ifconfig_path()

    # compare the ifconfig

# Generated at 2022-06-20 17:50:46.296581
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-20 17:50:56.756287
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    def mock_run_command(binpath, ifconfig_path, ifconfig_options):
        command = binpath + ifconfig_options
        options = ifconfig_options.split()
        if command == 'netstat -nr':
            out = '''
            Routing tables
            Destination        Gateway            Flags Refs Use  If  Pmt  Prio
            default            192.168.1.1        UG        1   0   en0  240   1
            default            192:1681:2::1      UG        1   0   en0  240   1
            default            192.168.1.1        UG        1   0   en0  240   1
            127.0.0.1          127.0.0.1          UH       21   0    2    0
            '''
            return 0, out, ''

# Generated at 2022-06-20 17:51:09.037974
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:51:10.027501
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-20 17:51:33.194357
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_facts = AIXNetworkCollector()
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-20 17:51:37.788657
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.solaris import SolarisNetwork
    from ansible.module_utils.facts.network.solaris import SolarisNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network import NetworkCollector

    fact_collector = FactCollector()
    fact_collector._collectors = [GenericBsdIfconfigNetwork, SolarisNetwork, SolarisNetworkCollector, AIXNetwork, AIXNetworkCollector, NetworkCollector]

    # set

# Generated at 2022-06-20 17:51:42.442580
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    Constructor of class AIXNetwork
    '''

    aixnetwork = AIXNetwork()
    assert aixnetwork.get_default_interfaces('.') == ({}, {})

# Generated at 2022-06-20 17:51:53.074966
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    test_interfaces = []
    test_interfaces.append(['en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu 1500', 'index 3', 'inet 10.85.1.16 netmask 0xffffff00 broadcast 10.85.1.255'])
    test_interfaces.append(['lo0: flags=e08084b,c0<UP,BROADCAST,LOOPBACK>', 'mtu 65536', 'index 1'])

    interfaces, ipv4, ipv6 = {}, {}, {}

# Generated at 2022-06-20 17:52:00.426004
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    ansible_AIXNetwork_instance = AIXNetwork(module)

    expected_interface_v4 = dict(
        gateway='192.168.1.1',
        interface='en0'
    )
    expected_interface_v6 = dict(
        gateway='fe80::a00:27ff:fe79:891f',
        interface='en0'
    )

    ifconfig_path = module.get_bin_path('ifconfig')
    netstat_path = module.get_bin_path('netstat')
    route_path = module.get_bin_path('route')

    interface_v4, interface_v6 = ansible_AIXNetwork_instance.get_default_interfaces(route_path)

    assert interface_v4 == expected_interface_v4


# Generated at 2022-06-20 17:52:10.393680
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    module_path = 'ansible.module_utils.facts.network.aix'
    d = AIXNetwork(ifconfig_path, ifconfig_options, module_path)
    assert d.get_default_interfaces(route_path='/usr/sbin/netstat') == (
        {'gateway': '10.10.191.2', 'interface': 'enX'}, {}
    )

# Generated at 2022-06-20 17:52:13.312692
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    aix_network = AIXNetwork(module)
    assert aix_network._platform == 'AIX'
    assert aix_network._fact_class == AIXNetwork

# Generated at 2022-06-20 17:52:16.469454
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    res = AIXNetworkCollector()
    assert isinstance(res, NetworkCollector)
    assert hasattr(res, '_fact_class')
    assert isinstance(res._fact_class, AIXNetwork)
    assert res._platform == 'AIX'

# Generated at 2022-06-20 17:52:18.856740
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-20 17:52:21.701911
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert isinstance(collector, AIXNetworkCollector)
    assert isinstance(collector.facts, AIXNetwork)

# Generated at 2022-06-20 17:53:14.374820
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    def my_run_command(self, args, check_rc=True):
        if 'ifconfig' in args:
            return 0, ifconfig_out, ''
        else:
            return 1, None, None

    my_module = AnsibleModule(argument_spec={})
    my_module.run_command = my_run_command


# Generated at 2022-06-20 17:53:15.910569
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    assert AIXNetwork.get_interfaces_info('ls') == ([], {})



# Generated at 2022-06-20 17:53:17.191209
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__doc__ is not None

# Generated at 2022-06-20 17:53:24.122650
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os
    import sys
    import pytest
    import difflib
    from ansible.module_utils.basic import AnsibleModule

    def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        cmd = args[0]
        if cmd == 'ifconfig':
            ifconfig_path = os.path.join(os.path.dirname(__file__), 'aix_ifconfig_output')
            f = open(ifconfig_path)
            return 0, f.read(), ''
        else:
            raise Exception('Unexpected command: %s' % cmd)

    def get_bin_path(self, arg):
        return arg

   

# Generated at 2022-06-20 17:53:34.998343
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    testing the parse_interface_line method
    """
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> metric 1 mtu 1500'
    words = line.split()
    current_if = dict()
    result = AIXNetwork.parse_interface_line(AIXNetwork(), words)
    assert result['device'] == 'en0'
    assert result['flags'] == '1e080863,480'
    assert result['macaddress'] == 'unknown'
    assert result['type'] == 'unknown'

# Generated at 2022-06-20 17:53:41.733318
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create instance of class AIXNetwork and
    # test method get_default_interfaces
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module,
                                            custom_facts={})
    network = network_collector.collect()

    # Print out network
    # verify result
    assert network['interfaces']
    assert network['default_ipv4']['gateway']
    assert network['default_ipv4']['interface']
    assert network['default_ipv6']['gateway']
    assert network['default_ipv6']['interface']


# Generated at 2022-06-20 17:53:53.112207
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class ModuleStub():

        def __init__(self):
            self.params = None
            self.bin_path = {}
            self.bin_path['netstat'] = '/usr/bin/netstat'
            self.exit_json = None
            self.run_command = None
            return

        def get_bin_path(self, param):
            return self.bin_path[param]

        def run_command(self, paths):
            return self.run_command(paths)

    class TestAIXNetwork():
        platform = 'Default'
        module = ModuleStub()

    # Unit test for IPv4
    class TestRunCommand():

        def __init__(self):
            self.call_count = 0

# Generated at 2022-06-20 17:54:02.783222
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import json
    import textwrap
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    class RunCommandMock(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    class AIXNetworkClassMock(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name != 'netstat':
                return None
            return '/path/to/netstat'


# Generated at 2022-06-20 17:54:13.540267
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    result = module.exit_json(changed=False)

    fake_bins = {}

# Generated at 2022-06-20 17:54:16.239385
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Constructor of class AIXNetwork only needs objects of module
    """
    module = None
    facts = AIXNetwork(module)
    assert facts is not None


# Generated at 2022-06-20 17:56:00.416519
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ..network.base import Interface
    module = None
    ifc = AIXNetwork(module)

    interface = Interface('eth0')

    words = ['eth0:', 'flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>,']
    interface = ifc.parse_interface_line(words)
    assert interface['device'] == 'eth0'
    assert interface['flags'] == '8943'
    assert interface['type'] == 'unknown'
    assert interface['macaddress'] == 'unknown'
    assert interface['mtu'] == ''



# Generated at 2022-06-20 17:56:07.348123
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    network = AIXNetwork()

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = AIXNetwork.run_command
            self.get_bin_path = AIXNetwork.get_bin_path
        def fail_json(self, *args, **kwargs):
            pass

    network.module = FakeModule()

    # simulate that netstat does not exist
    network.module.get_bin_path.side_effect = lambda x: None
    assert network.get_default_interfaces(None) == (None, None)

    # simulate netstat output with ipv4 and ipv6 gateways
    netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-20 17:56:18.284651
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    AixInterface = dict(
        device='lo0',
        type='ether',
        ipv4=[],
        ipv6=[
            dict(address='::1', netmask='ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff', address_ipv6=dict(address='::1', prefix=128)),
            dict(address='::ffff:127.0.0.1', netmask='ffff:ffff:ffff:ffff::', address_ipv6=dict(address='::ffff:127.0.0.1', prefix=96)),
        ],
        macaddress='unknown',
        flags=dict(
            loopback=True,
        ),
        mtu=0,
    )


# Generated at 2022-06-20 17:56:24.769727
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    net = AIXNetwork(module)

    route_path = module.get_bin_path('route')

    default_interfaces = net.get_default_interfaces(route_path)

    out = to_text(str(default_interfaces))

    print(out)

# Generated at 2022-06-20 17:56:35.812133
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    _test_AIXNetwork = AIXNetwork()
    interfaces = dict(v4={}, v6={})
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ('et0:', 'flags=8c3<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'index', '14')
    result = _test_AIXNetwork.parse_interface_line(words)

# Generated at 2022-06-20 17:56:42.005384
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork()

    result = network.get_default_interfaces('/bin/netstat')
    assert result == ({'gateway': '10.0.0.1', 'interface': 'en1'}, {'gateway': 'fe80::21e:c8ff:fe9f:c7f', 'interface': 'en1'})



# Generated at 2022-06-20 17:56:51.203506
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils import facts
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    collector.collector.load_collectors([AIXNetworkCollector])
    test = AIXNetwork(facts.__file__)

    rc, out, err = 0, '', ''
    rc, out, err = test.module.run_command(['ifconfig', '-a'])
    if rc != 0:
        return (None, None)
    interfaces, ips = test.get_interfaces_info(test.module.get_bin_path('ifconfig'))
    return (interfaces, ips)


# Unit testing for get_interfaces_info() method

# Generated at 2022-06-20 17:57:02.071333
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()

    # Test default attributes of class AIXNetwork
    assert aix_network.default_options == '-a'
    assert aix_network.interface_regex == r'^\w*\d*:.*'

    # Test network attributes on AIX
    interfaces, ips = aix_network.get_interfaces_info(aix_network.ifconfig_path)

    for key in interfaces:
        assert 'device' in interfaces[key]
        assert 'flags' in interfaces[key]
        assert 'macaddress' in interfaces[key]
        assert 'type' in interfaces[key]
        assert 'mtu' in interfaces[key]

    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

    # Test

# Generated at 2022-06-20 17:57:07.653529
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of class AIXNetworkCollector
    """
    # Test with _platform = 'AIX' and _fact_class = AIXNetwork
    obj = AIXNetworkCollector()
    assert obj._platform == 'AIX' and obj._fact_class == AIXNetwork

# Generated at 2022-06-20 17:57:17.157072
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """ check that get_default_interfaces returns the default interface which has the gateway """
    aix_network = AIXNetwork({ 'module_setup': True, 'path': { 'netstat': 'no_netstat'} })
    assert aix_network.get_default_interfaces('no_route') == (None, None)

    aix_network = AIXNetwork({ 'module_setup': True, 'path': { 'netstat': './netstat_aix'} })
    assert aix_network.get_default_interfaces('./route_aix') == ({'gateway': '192.168.1.1', 'interface': 'en0'},
                                                                   {'gateway': 'fe80::200:5efe:192.168.1.1%en0', 'interface': 'en0'})

