

# Generated at 2022-06-20 17:49:03.580120
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert collector.platform == 'AIX'
    assert isinstance(collector.fact_class, AIXNetwork)



# Generated at 2022-06-20 17:49:12.570566
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
    )


# Generated at 2022-06-20 17:49:21.227930
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod = AnsibleModule(argument_spec={})
    words = ['en0:', 'flags=8b63', 'mtu', '1500', 'index', '1', 'inet', '10.2.3.3', 'netmask', '0xffffff00', 'broadcast', '10.2.3.255', 'tcp_sendspace', '131072', 'tcp_recvspace', '262144', 'rfc1323', '1']
    aix = AIXNetwork()
    res = aix.parse_interface_line(words)
    mod.exit_json(ansible_facts={'res': res})



# Generated at 2022-06-20 17:49:29.826142
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-20 17:49:34.368437
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    This function unit tests the object constructor of class AIXNetwork.
    """
    module = AnsibleModule(argument_spec={})
    network_aix = AIXNetwork(module=module)
    assert(network_aix.platform == 'AIX')

# Generated at 2022-06-20 17:49:36.231373
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    interface = AIXNetwork({})
    assert 'AIX' == interface.platform

# Generated at 2022-06-20 17:49:45.729971
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-20 17:49:47.986667
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Constructor of AIXNetworkCollector
    aix = AIXNetworkCollector(None, None)
    assert aix.get_default_interfaces(None) == ({}, {})

# Generated at 2022-06-20 17:49:51.641765
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:49:59.597960
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = ifconfig_path
    module_mock.run_command.return_value = (0,"","")

    # create instance of class
    aix_network = AIXNetwork(module=module_mock)
    assert isinstance(aix_network, AIXNetwork)
    assert aix_network.platform == 'AIX'
    assert aix_network.ifconfig_options == ifconfig_options


# Generated at 2022-06-20 17:50:21.537587
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network import AIXNetwork
    aix_ifconfig_output_line1 = 'lo0: flags=E<UP,LOOPBACK,RUNNING> inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255'
    words1 = aix_ifconfig_output_line1.split()
    aix_network = AIXNetwork()
    assert aix_network.parse_interface_line(words1) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING']}
    #

# Generated at 2022-06-20 17:50:30.158024
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ans = AIXNetwork()
    s = "en0: flags=1e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    words = s.split()
    interface = ans.parse_interface_line(words)
    assert interface['device'] == 'en0'
    assert interface['type'] == 'unknown'
    assert interface['flags'] == [
        'UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX',
        'MULTICAST', 'GROUPRT', '64BIT',
        'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN'
        ]
    assert interface

# Generated at 2022-06-20 17:50:36.128383
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    aix.module = None

    # this example is taken from ifconfig -a running on AIX
    words = ['en0:']
    current_if = aix.parse_interface_line(words)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 17:50:46.025948
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_mock_path = '/usr/sbin/ifconfig'
    dummy_interface = dict()
    dummy_interface['device'] = 'en0'
    dummy_interface['flags'] = ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    dummy_interface['macaddress'] = 'unknown'
    dummy_interface['ipv4'] = []
    dummy_interface['ipv6'] = []
    dummy_interface['type'] = 'unknown'
    aixnettest = AIXNetwork(ifconfig_mock_path)
    cur_int = dict()
    words = ["en0:", "UP", "BROADCAST", "RUNNING", "SIMPLEX", "MULTICAST"]

# Generated at 2022-06-20 17:50:56.422824
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:51:07.825355
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(**{})

    ifconfig_path = module.get_bin_path('ifconfig')
    class_ifconfig_options = '-a'
    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')

    m_args = MagicMock(return_value=(0, '', ''))
    with patch('ansible.module_utils.facts.network.generic_bsd.get_file_content', m_args):
        an = AIXNetwork()

    interfaces, ips = an.get_interfaces_info(ifconfig_path, class_ifconfig_options)
    for device in interfaces:
        interface = interfaces[device]

# Generated at 2022-06-20 17:51:14.498370
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    interface_line = '      lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'
    words = interface_line.split()
    current_if = test_object.parse_interface_line(words)

    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['LOOPBACK', 'MULTICAST', 'RUNNING', 'UP']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert 'mtu' not in current_if
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    return True

# Generated at 2022-06-20 17:51:18.365019
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module,
                                    command='ifconfig -a')
    assert collector.get_default_interfaces('/tmp/route_path') == ({}, {})

# Generated at 2022-06-20 17:51:20.441093
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-20 17:51:25.627064
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    hosts = AIXNetwork()
    assert hosts.get_interfaces_info('/usr/sbin/ifconfig') is not None
    assert hosts.get_default_interfaces('/usr/sbin/route') is not None
    assert hosts.interfaces is not None
    assert hosts.default_interface is not None
    assert hosts.default_ipv4 is not None


# Generated at 2022-06-20 17:51:57.862780
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class AIXModule:

        def __init__(self):
            self.name = 'ansible_test'
            self.params = {}
            self.config = {}
            self.config['persistent_command_timeout'] = 0
            self.config['network_debug'] = 0

        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, executable):
            if executable == 'netstat':
                return '/usr/bin/netstat'
            elif executable == 'uname':
                return '/usr/bin/uname'
            elif executable == 'netstat':
                return '/usr/bin/netstat'
            elif executable == 'ifconfig':
                return '/usr/sbin/ifconfig'

# Generated at 2022-06-20 17:52:06.350008
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_string = 'en0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500'
    words = test_string.split()
    aix = AIXNetwork()
    result = aix.parse_interface_line(words)

    device = 'en0'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = aix.get_options(words[1])
    current_if['macaddress'] = 'unknown'
    assert result == current_if

# Generated at 2022-06-20 17:52:12.104728
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'uname_info', ''))
    module.get_bin_path = MagicMock(return_value='path')
    iface = AIXNetwork(module)
    ips_v4, ips_v6 = iface.get_default_interfaces('ifconfig')
    assert ips_v4 == {}
    assert ips_v6 == {}



# Generated at 2022-06-20 17:52:17.855615
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test method get_default_interfaces of class AIXNetwork in module aix.py
    """
    success_data = """
    netstat -nr
    Routing Tables
    Destination        Gateway            Flags   Refs     Interface 
     ----------------------------------------- -----   -----   ----------
    0.0.0.0/0          10.10.10.10        UG        0        en0     
    1.1.1.1/32         10.10.10.10        UG        0        en0        
     -- snip --      
    """
    success_return_val = {'v4': {'gateway': '10.10.10.10', 'interface': 'en0'}, 'v6': {'gateway': None, 'interface': None}}


# Generated at 2022-06-20 17:52:25.562465
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = {'ansible_facts': {}}
    test_instance = AIXNetwork(test_module)
    line1 = 'en0: flags=6a000098<UP,BROADCAST,NOTRAILERS,LOOPBACK,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT,NOXMIT> mtu 0'
    line2 = 'ether unknown'
    line3 = 'nd6 options=3<PERFORMNUD,ACCEPT_RTADV>'
    line4 = 'media: Ethernet autoselect (1000baseT full-duplex)'
    line5 = 'status: active'
    line6 = 'lladdr 0:30:48:92:4d:4d'

# Generated at 2022-06-20 17:52:34.978987
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    teststring = "lo0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN> mtu 8232 index 1\n"
    words = teststring.split()
    current_if = AIXNetwork().parse_interface_line(words)
    assert 'mtu' not in current_if
    assert current_if['device'] == 'lo0'

# Generated at 2022-06-20 17:52:46.697874
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:52:55.661785
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins   # pylint: disable=import-error
    else:
        import builtins   # pylint: disable=import-error

    class RunCommand:
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, args, **kwargs):
            return self.rc, self.out, self.err

    module = MockModule()
    aix_network = AIXNetwork(module=module)

    # execute method get_default_interfaces with network route of AIX

# Generated at 2022-06-20 17:52:57.854901
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    a = AIXNetwork(dict(module=dict()))
    assert a.platform == 'AIX'
    assert a.interfaces == 'the interfaces'


# Generated at 2022-06-20 17:53:00.441001
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork({}).platform == 'AIX'


# Generated at 2022-06-20 17:53:49.916011
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [[0, OUT_IFCONFIG.format(ifconfig_options='-a', option='none'), '']]
    unit = AIXNetwork(mock_module)
    interfaces, ips = unit.get_interfaces_info(mock_module.get_bin_path.return_value)
    assert interfaces == EXPECTED_INTERFACES, interfaces
    assert ips == EXPECTED_IPS, ips


# Generated at 2022-06-20 17:53:57.553148
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric=1']
    expected = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN'], 'macaddress': 'unknown'}

    myAIXNetwork = AIXNetwork()
    actual = myAIXNetwork.parse_interface_

# Generated at 2022-06-20 17:54:00.505683
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert not hasattr(AIXNetworkCollector, '_cache')
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:54:02.694902
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_obj = AIXNetworkCollector()
    assert my_obj._platform == 'AIX'
    assert my_obj._fact_class == AIXNetwork


# Generated at 2022-06-20 17:54:13.458881
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class moduleAIXNetwork:
        def get_bin_path(self, arg):
            return None


# Generated at 2022-06-20 17:54:19.060338
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class AIXNetwork
    :return:
    """
    aixnet = AIXNetwork(None)
    words = 'eno0: flags=1e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    current_if = aixnet.parse_interface_line(words.split())

# Generated at 2022-06-20 17:54:21.269247
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'


# Generated at 2022-06-20 17:54:28.346320
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork_inst = AIXNetwork()
    words = ['en0:','flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>','metric','0','mtu','1500']
    expected_device = 'en0'
    expected_flags = ('UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST')
    expected_macaddress = 'unknown'
    expected_type = 'unknown'
    current_if = AIXNetwork_inst.parse_interface_line(words)
    assert current_if['device'] == expected_device
    assert current_if['flags'] == expected_flags
    assert current_if['macaddress'] == expected_macaddress
    assert current_if['type'] == expected_type

   

# Generated at 2022-06-20 17:54:30.178959
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(module=None)).platform == 'AIX'


# Generated at 2022-06-20 17:54:35.233130
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Creates a instance of the AIXNetworkCollector class
    """

    network_collector = AIXNetworkCollector(None)

    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork

# Generated at 2022-06-20 17:56:23.856096
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    '''
    Test for parse_interface_line method of AIXNetwork
    '''

    # Fake module to use AnsibleModule
    from ansible.module_utils.facts.network.aix import AIXNetwork
    module = type('AnsibleModule', (object,), dict(params=dict()))()
    module.get_bin_path = lambda path: True
    module.run_command = lambda cmd: (0, '', '')
    module.fail_json = lambda **kwargs: None

    net = AIXNetwork(module)

    # Just to be sure
    assert net.platform == 'AIX'

    # Parse a line from ifconfig -a output

# Generated at 2022-06-20 17:56:34.557936
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'network_debug': {'type': 'bool', 'default': True}})

    mocker = patch('ansible.module_utils.facts.network.aix.AIXNetwork.get_default_interfaces')
    mocker.return_value = {'v4': {'interface': 'en0', 'gateway': '192.0.2.1'},
                           'v6': {'interface': 'en0', 'gateway': '2001:db8::1'}}

    obj = AIXNetwork(module)
    routes = obj.get_default_interfaces('route_path')

# Generated at 2022-06-20 17:56:43.956177
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """ Unit test for method parse_interface_line of class AIXNetwork """
    facts = AIXNetwork()
    words = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '8']
    current_if = facts.parse_interface_line(words)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']}

# Generated at 2022-06-20 17:56:52.625684
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['network']['default_ipv4']['interface'] is not None
    assert facts['network']['default_ipv6']['interface'] is not None
    assert facts['network']['interfaces']['lo0']['type'] == 'Loopback'
    assert facts['network']['interfaces']['lo0']['flags'] == ['UP', 'RUNNING']
    assert facts['network']['interfaces']['lo0']['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:56:54.164003
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None).collect()
    assert facts['network'] != {}


# Generated at 2022-06-20 17:57:04.949558
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:57:09.067930
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector(None)
    assert collector.platform == 'AIX'
    assert collector.fact_class is AIXNetwork



# Generated at 2022-06-20 17:57:17.877776
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    line = 'en0: flags=8963<UP,BROADCAST,NOTRAILERS,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500 inet 10.65.4.212 netmask 0xfffffe00 broadcast 10.65.5.255 inet6 fe80::2a0:a5ff:fef0:c547%en0 prefixlen 64 scopeid 0x5 ether 00:a0:a5:f0:c5:47 media: Ethernet autoselect (1000baseT <full-duplex>) status: active'
    test_class = AIXNetwork()
    words = line.split()
    result = test_class.parse_interface_line(words)

# Generated at 2022-06-20 17:57:30.393142
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    an = AIXNetwork()
    s = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN> mtu 1500'
    words = s.split()
    current_if = an.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'LARGESEND', 'CHAIN']

# Generated at 2022-06-20 17:57:39.752798
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    optional_args = dict(
        config_options='-a',
        route_path='/bin/netstat'
    )
    module = FakeModule(**optional_args)
    new_obj = AIXNetwork(module)

    line = "en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\ninet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255\n"
    words = line.split()
    current_if = new_obj.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['ipv4'] == []
