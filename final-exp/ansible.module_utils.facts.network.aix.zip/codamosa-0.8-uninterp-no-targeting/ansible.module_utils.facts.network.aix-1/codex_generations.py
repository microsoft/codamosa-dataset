

# Generated at 2022-06-20 17:49:00.200908
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list')
    })
    module.exit_json(ansible_facts={'ansible_net_interfaces': {'default': [[None], [None]]}})



# Generated at 2022-06-20 17:49:09.238500
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import EXAMPLE_OUTPUT
    from ansible.module_utils.facts.network.aix import expected_info

    ifconfig_path = "ifconfig"
    ifconfig_options = '-a'

    an = AIXNetwork(None)
    ifconfig, ips = an.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert ifconfig == expected_info['ifconfig']
    assert ips == expected_info['ips']


# Generated at 2022-06-20 17:49:18.011975
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network.platform == 'AIX'
    assert network.get_default_interfaces(None) == ({}, {})
    assert network.get_interfaces_info(None) == ({}, {})
    # ifconfig_path = sys.executable or 'python'
    # ifconfig_path = '/bin/echo'
    # interfaces, ip_addresses = network.get_interfaces_info(ifconfig_path)
    # assert interfaces is not None
    # assert ip_addresses is not None

# Generated at 2022-06-20 17:49:21.330717
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # initialise the generic FreeBSD network class
    network = AIXNetwork()

    # initialise the AIX network class
    # AIXNetwork() = AIXNetwork()
    network = AIXNetwork()



# Generated at 2022-06-20 17:49:23.675229
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc._fact_class == AIXNetwork
    assert nc._platform == 'AIX'


# Generated at 2022-06-20 17:49:27.256298
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector
    assert isinstance(network_collector, AIXNetworkCollector)
    assert hasattr(network_collector, '_fact_class')
    assert isinstance(network_collector._fact_class, AIXNetwork)

# Generated at 2022-06-20 17:49:36.434262
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # construct object
    aix = AIXNetwork()
    assert isinstance(aix, AIXNetwork)

    # check for class attributes
    for attr in ['platform', 'get_interfaces_info', 'get_default_interfaces']:
        assert hasattr(aix, attr)

    # check for class methods
    for attr in ['get_interfaces_info', 'get_default_interfaces']:
        assert callable(getattr(aix, attr))


if __name__ == "__main__":
    test_AIXNetwork()

# Generated at 2022-06-20 17:49:40.052728
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    network_collector = AIXNetworkCollector(module=module)
    facts = network_collector.collect()

    iface_default_gw = facts['default_ipv4']['gateway']
    route_path = module.get_bin_path('route')
    if iface_default_gw:
        rc, out, err = module.run_command([route_path, '-n', '-f', '/usr/sbin/netstat'])
        for line in out.splitlines():
            if iface_default_gw in line:
                assert iface_default_gw == line

# Generated at 2022-06-20 17:49:46.077591
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix = NetworkCollector.get_network_collector('AIX', None)
    if not aix:
        # This should never happen.
        print("ERROR: Failed to instantiate AIXNetworkCollector.")
        assert 0
    else:
        print("AIXNetworkCollector is instantiated.")
        assert isinstance(aix, AIXNetworkCollector)

test_AIXNetworkCollector()

# Generated at 2022-06-20 17:49:51.710556
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    test_line = 'en5: flags=5c43<UP,BROADCAST,RUNNING,ALLMULTI,IPv6,NOINET6_LL0,ROUTER,MULTICAST,GROUPRT,NOARP> mtu 1500'
    words = test_line.split()
    result = aix_network.parse_interface_line(words)
    assert result['device'] == 'en5'
    assert result['ipv4'] == []
    assert result['ipv6'] == []
    assert result['type'] == 'unknown'
    assert 'UP' in result['flags']
    assert 'BROADCAST' in result['flags']
    assert 'RUNNING' in result['flags']
    assert 'ALLMULTI' in result['flags']
   

# Generated at 2022-06-20 17:50:06.793876
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.facts['network'] == 'AIXNetwork'

# Generated at 2022-06-20 17:50:18.153988
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    '''Test method parse_interface_line for class AIXNetwork'''
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_net = AIXNetwork()
    words = ['en0:', '<BROADCAST,MULTICAST,NOARP>', 'mtu', '1500', 'options', '=', '80000<LINKSTATE>']

    # the first test case differs from the one in the method parse_interface_line of class GenericBsdIfconfigNetwork
    expected_if_dict = {'device': 'en0', 'macaddress': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['BROADCAST', 'MULTICAST', 'NOARP']}

# Generated at 2022-06-20 17:50:27.805765
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class TestModule(object):
        def __init__(self, out, err, rc):
            self.out = out
            self.err = err
            self.rc = rc
        def run_command(self, args):
            return self.rc, self.out, self.err
        def get_bin_path(self, arg):
            return 'some_path'


# Generated at 2022-06-20 17:50:29.318646
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork({})
    assert net.platform == 'AIX'

# Unit test

# Generated at 2022-06-20 17:50:41.864145
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    real_rc, real_out, real_err = module.run_command('netstat -rn')
    if 'lo0:' in real_out:
        out = real_out.replace('lo0:', 'ut0:')
    else:
        out = real_out.replace('lo1:', 'ut0:')
    module = AnsibleModule(argument_spec=dict())
    obj = AIXNetwork(module, out)
    expected_interface = dict(v4={}, v6={})
    if 'default' in out:
        if '.' in out.split()[1]:
            expected_interface['v4']['gateway'] = out.split()[1]
            expected_interface['v4']['interface'] = out.split()[5]

# Generated at 2022-06-20 17:50:50.690307
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix = AIXNetwork(None)
    interf = dict(v4={}, v6={})

    # route -n is not available
    routen = dict(rc=127, out='', err='', path='/usr/sbin/route')
    result = aix.get_default_interfaces(routen)
    assert result == (interf['v4'], interf['v6'])

    # test with IPv6

# Generated at 2022-06-20 17:50:55.948497
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    test_module = NetworkCollector()
    test_AIXNetwork = AIXNetwork(test_module)


# Generated at 2022-06-20 17:51:07.394201
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Simple test to check that get_default_interfaces works. Uses fake network routes file
    # (/etc/networks)
    mod = AnsibleModule(argument_spec=dict())
    net = AIXNetwork()

    rc, out, err = net.module.run_command(['cat', '/etc/networks'])
    def_ipv4, def_ipv6 = net.get_default_interfaces('/etc/networks')
    assert def_ipv4 and def_ipv6
    assert def_ipv4['interface'] == 'en0'
    assert def_ipv4['gateway'] == '10.0.0.1'
    assert def_ipv6['interface'] == 'lo0'
    assert def_ipv6['gateway'] == 'fe80::2%lo0'

   

# Generated at 2022-06-20 17:51:14.674664
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:51:25.281414
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()

    # this test is for AIX only
    words = ['en0:','flags=8c63','<up,broadcast>','mtu','1500','index','2','inet','192.168.0.37','netmask','0xffffff00','broadcast','192.168.0.255']
    current_if = aix.parse_interface_line(words)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['broadcast', 'multi', 'up'], 'macaddress': 'unknown'}

    words = ['lo0:','options=3']
    current_if = aix.parse_interface_line(words)

# Generated at 2022-06-20 17:51:45.469296
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net = AIXNetwork()
    net.module.params['gather_subset'] = ['!all', 'min']
    interfaces, ips = net.get_interfaces_info('ifconfig')
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0



# Generated at 2022-06-20 17:51:55.426958
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net_module = {}

# Generated at 2022-06-20 17:52:01.851046
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork.parse_interface_line(['en0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>','metric','1','mtu','1500','options','=','<mru','1468,','broadcast>]',''])
    AIXNetwork.parse_interface_line(['en1:','flags=4163<UP,BROADCAST,RUNNING,MULTICAST>','metric','1','mtu','1500','options','=','<mru','1468,','broadcast>]',''])

# Generated at 2022-06-20 17:52:11.539551
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface = dict(
        ifname='en0',
        flags=['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'MULTICAST'],
        mtu='1500',
        macaddress='unknown',
        type='ether'
    )

    test_module = module_set_up()
    network = AIXNetwork(test_module)
    words = [interface['ifname'] + ':', interface['flags'][0], interface['flags'][1],
             interface['flags'][2], interface['flags'][3], interface['flags'][4]]

    current_if = network.parse_interface_line(words)
    assert (current_if['device'] == interface['ifname'])
    assert (current_if['flags'] == interface['flags'])

# Generated at 2022-06-20 17:52:20.875014
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    :return:
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork as AIXNetwork_fact
    from ansible.module_utils.facts.network import AIXNetwork as AIXNetwork_module
    from ansible.module_utils.facts.collector import TestCollecotor

    kw_args = {'uname_path': 'bin/uname',
               'ifconfig_path': 'bin/ifconfig',
               }


# Generated at 2022-06-20 17:52:31.561126
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    class Mock:
        def __init__(self):
            self.run_command_value = 0

        def run_command(self, command):
            if command[0] == "/usr/bin/which":
                return self.run_command_value, "/usr/bin/ifconfig", ""

# Generated at 2022-06-20 17:52:38.016161
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    unit = AIXNetwork()
    words = ['en0:', 'flags=1e084863,480', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '172.30.7.158', 'netmask', '0xffff0000', 'broadcast', '172.30.255.255']

    current_if = unit.parse_interface_line(words)

# Generated at 2022-06-20 17:52:48.775668
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    
    # input_line must be in format 'informative_name1: flags1 informative_name2: flags2'
    def test_parse_interface_line(input_line, expected_dict):
        aix_network = AIXNetwork(dict(module=None, params=None))
        ifconfig_line = input_line.split()
        result_dict = aix_network.parse_interface_line(ifconfig_line)
        print('input_line =', input_line)
        print('expected_dict =', expected_dict)
        print('result_dict =', result_dict)
        assert result_dict == expected_dict
    

# Generated at 2022-06-20 17:52:57.701310
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    network_facts = AIXNetwork(module=module)
    command = 'netstat -nr'

# Generated at 2022-06-20 17:52:59.989499
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector()

# Generated at 2022-06-20 17:53:34.511580
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'default 192.168.1.0 UG eth0', ''))
    mock_module.get_bin_path = Mock(return_value='/usr/bin')
    mock_module.params = {}
    mock_module.get_bin_path.return_value = 'netstat'
    mock_AIXNetwork = AIXNetwork(mock_module)
    assert mock_AIXNetwork.get_default_interfaces('/sbin/route') == ({'interface': 'eth0', 'gateway': '192.168.1.0'}, {})



# Generated at 2022-06-20 17:53:37.759874
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()         # Constructor of AIXNetworkCollector
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork

# Generated at 2022-06-20 17:53:44.039182
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
        ),
    )
    net_collector = AIXNetworkCollector(module=module)
    interfaces_info, ips = net_collector.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')
    assert len(interfaces_info) != 0
    assert isinstance(interfaces_info, dict)
    assert isinstance(ips, dict)
    for interface in interfaces_info.keys():
        assert 'flags' in interfaces_info[interface]
        assert 'mtu' in interfaces_info[interface]

# Generated at 2022-06-20 17:53:53.832813
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 17:54:03.213591
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    AnsibleModule = None
    AIXNetwork = AIXNetwork(AnsibleModule)
    path = ['/usr/sbin/ifconfig']
    options = '-a'
    result = AIXNetwork.get_interfaces_info(path, options)

    devices = result[0]
    ips = result[1]


# Generated at 2022-06-20 17:54:14.055340
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # test input
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    uname_path = '/usr/bin/uname'
    uname_options = ['-W']
    entstat_path = '/usr/bin/entstat'
    lsattr_path = '/usr/bin/lsattr'

    # object under test
    aix = AIXNetwork()

    # test preparations
    aix.module = MockModule()
    aix.module.run_command = MockRunCommand()
    aix.module.get_bin_path = MockGetBinPath(ifconfig_path)
    aix.module.run_command.return_value = (0, ifconfig_out, '')
    aix.module.get_bin_path.return_value = un

# Generated at 2022-06-20 17:54:23.831398
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import sys
    import mock
    from ansible.module_utils.facts.network.aix import AIXNetwork

    if os.getuid() == 0:
        SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
        CONTENT_FILE = os.path.join(SCRIPT_DIR, 'netstat_output_example.txt')

        with open(CONTENT_FILE, 'r') as f:
            content = f.read()

        mock_run_command_list = []
        def mock_run_command(cmd):
            if cmd[0] == '/usr/bin/netstat':
                rc = 0
                out = content
                err = ''
            else:
                rc = 1
                out = ''
                err = 'Unknown command'

            mock_

# Generated at 2022-06-20 17:54:35.007984
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # test high level method get_interfaces_info of class AIXNetwork
    # load test input
    import sys
    testfile = open("/tmp/aix_ifconfig_a.txt")
    sys.stdin = testfile

    # load test output
    testoutput = open("/tmp/aix_ifconfig_a.txt.out")
    sys.stdout = testoutput

    # load module loader
    from ansible.module_utils.facts import ModuleLoader
    mod_loader = ModuleLoader()
    if mod_loader == None:
        print("mod_loader is none")
        return

    # load module path
    from ansible.module_utils.facts.facts import ModulePaths
    mod_paths = ModulePaths('')

# Generated at 2022-06-20 17:54:41.998509
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'default_interface': dict(default=None, required=False)})
    platform = 'AIX'

    nc = AIXNetworkCollector(module=module, platform=platform)
    result = nc.get_default_interfaces('/usr/sbin/route')
    assert (result == {'gateway': '172.17.0.1', 'interface': 'en0'})
    #assert (result == {'gateway': '172.23.33.1', 'interface': 'en0'})


# Generated at 2022-06-20 17:54:52.335789
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = None
    ans = AIXNetwork(module)

    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '1500']
    # only this condition differs from GenericBsdIfconfigNetwork
    if re.match(r'^\w*\d*:', words[0]):
        current_if = ans.parse_interface_line(words)

# Generated at 2022-06-20 17:55:53.163293
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_module = AIXNetworkCollector()
    assert isinstance(fact_module, NetworkCollector)
    assert isinstance(fact_module, AIXNetworkCollector)
    assert fact_module._platform == 'AIX'


# Generated at 2022-06-20 17:56:01.460385
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()

    class Module(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/netstat'

        def run_command(self, cmd, check_rc=True):
            return 0, """default 172.17.0.1 UG 1 0 en3
default fe80::%en3 UG 0 0 en3
default fe80::%en4 UG 0 0 en4
""", ''

    aix_network.module = Module()

    assert aix_network.get_default_interfaces(None) == ({'gateway': '172.17.0.1', 'interface': 'en3'}, {'gateway': 'fe80::%en3', 'interface': 'en3'})

# Generated at 2022-06-20 17:56:08.082518
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    print("test_AIXNetwork_parse_interface_line()")
    # use a class instead of a module
    # (in Python one can instantiate a class without creating an object)
    aixNetwork = AIXNetwork()
    # create a mock class object, to test the class method
    aixNetwork.module = FakeAnsibleModule()
    line = 'en1: flags=63<UP,BROADCAST,NOTRAILERS,RUNNING,NOARP> mtu 1500'
    words = line.split()
    print("line='%s', words='%s'" % (line, words))
    current_if = aixNetwork.parse_interface_line(words)
    print("current_if='%s'" % (current_if))
    assert current_if['device'] == 'en1'

# Generated at 2022-06-20 17:56:19.041280
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec = dict(),
    )
    test_network = AIXNetwork({}, test_module)

    # fake /usr/bin/netstat to return an output for IPv4 and IPv6

# Generated at 2022-06-20 17:56:26.196062
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_str = 'en0: flags=0x8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>'
    aix_nw = AIXNetwork()
    aix_nw.get_interfaces_info = lambda x, y: (None, None)
    aix_nw.parse_interface_line(test_str.split())
    assert aix_nw.interfaces['en0']['device'] == 'en0'

# Generated at 2022-06-20 17:56:35.290105
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifc = AIXNetwork()

    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>']
    interface = ifc.parse_interface_line(words)

    assert interface['device'] == 'en0'
    assert interface['flags'] == ['1e080863', '480', 'UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interface['macaddress'] == 'unknown'
    assert interface['type'] == 'unknown'



# Generated at 2022-06-20 17:56:43.246143
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    arguments = ['en0:', 'flags=0x80c05', 'mtu', '1500', 'options=3']
    aix_network_object = AIXNetwork()
    aix_result = aix_network_object.parse_interface_line(arguments)
    assert aix_result == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                          'flags': ['80c05'], 'macaddress': 'unknown'}

# Generated at 2022-06-20 17:56:49.479127
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    test_module = { }
    test_module['platform'] = 'AIX'

    test_module['run_command'] = run_command
    test_module['get_bin_path'] = get_bin_path

    test_AIXNetworkCollector = AIXNetworkCollector()

    assert test_AIXNetworkCollector.module == test_module
    assert test_AIXNetworkCollector.facts == {}
    assert test_AIXNetworkCollector.legacy_facts == {}


# Generated at 2022-06-20 17:56:53.161952
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-20 17:56:56.862352
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    This function is used to test the constructor of class AIXNetwork
    '''
    network_AIX = AIXNetwork()
    assert network_AIX.platform == 'AIX'