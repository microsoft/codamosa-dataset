

# Generated at 2022-06-20 17:49:09.687319
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Constructor of class AIXNetwork.
    """

    # Call the constructor with module_mock
    aix_network = AIXNetwork(module_mock)

    assert aix_network.platform == 'AIX'


# Generated at 2022-06-20 17:49:16.822131
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod = AnsibleModule(argument_spec=dict())

    # simple interface line output from AIX
    words1 = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'.split()
    # complex interface line output from AIX
    words2 = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>'.split(',')
    # Physical Interface line output from AIX

# Generated at 2022-06-20 17:49:21.020618
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork({})
    result = test.parse_interface_line("en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>".split())
    print(result)



# Generated at 2022-06-20 17:49:29.692455
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = None
    facts = AIXNetworkCollector(module).get_facts()
    interfaces = facts['ansible_interfaces']
    ipv4_addresses = facts['ansible_all_ipv4_addresses']
    ipv6_addresses = facts['ansible_all_ipv6_addresses']

    assert interfaces is not None
    assert ipv4_addresses is not None
    assert ipv6_addresses is not None

    # check that all IPv4 addresses are present in interfaces as well
    for ipv4_address in ipv4_addresses:
        assert any(x['ipv4'] and ipv4_address in x['ipv4'] for x in interfaces.values())

    # check that all IPv6 addresses are present in interfaces as well

# Generated at 2022-06-20 17:49:38.432424
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # init
    collected_facts = dict()
    ansible_module = object()
    net_collector = AIXNetworkCollector(collected_facts, ansible_module)

    # verify
    assert net_collector.platform == 'AIX'
    assert net_collector.fact_class == AIXNetwork
    assert net_collector.facts == collected_facts
    assert net_collector.module == ansible_module
    assert net_collector._platform == 'AIX'
    assert net_collector.ignore_interface == ['lo0', 'pfsync0', 'pflog0']



# Generated at 2022-06-20 17:49:48.254601
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class AIXModule:

        def __init__(self):
            self._bin_path = {}
            self._bin_path['netstat'] = 'bin/netstat'

        def get_bin_path(self, app, required=False):
            return self._bin_path.get(app, '')


# Generated at 2022-06-20 17:49:59.420174
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    class TestModule(object):
        """
        Test class for module
        """

        def __init__(self, platform_version, bin_dir):
            """
            Constructor for TestModule
            :param platform_version:
            :param bin_dir:
            """
            self.platform_version = platform_version
            self.bin_dir = bin_dir

        def get_bin_path(self, executable):
            """
            Get path of the executable (binary)
            :param executable:
            :return:
            """
            return executable

        def run_command(self, cmd):
            """
            Run the command given by cmd.
            :param cmd:
            :return:
            """
            if cmd == ['ifconfig', '-a']:
                return 0, ifconfig_output, None

# Generated at 2022-06-20 17:50:06.610871
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-20 17:50:08.173266
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.network

# Generated at 2022-06-20 17:50:19.426553
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create AIXNetwork instance to test
    aixnetwork = AIXNetwork()

    # test with sample output of netstat -nr command
    route_path = '/path/to/netstat'

# Generated at 2022-06-20 17:50:39.937443
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    # noinspection PyPep8
    assert issubclass(AIXNetwork, GenericBsdIfconfigNetwork)

    net = AIXNetwork(None)
    assert net.platform == 'AIX'

    # The following cannot be tested without real AIX system:
    # get_default_interfaces(), get_interfaces_info()



# Generated at 2022-06-20 17:50:49.478030
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_fact_network = AIXNetwork(dict(module=None, params=None))

    route_path = '/usr/sbin/route'
    interfaces_func = aix_fact_network.get_default_interfaces(route_path)
    interfaces_func_v4 = interfaces_func[0]
    interfaces_func_v6 = interfaces_func[1]

    route_path = '/path/to/command/not/existing'
    interfaces_none = aix_fact_network.get_default_interfaces(route_path)
    interfaces_none_v4 = interfaces_none[0]
    interfaces_none_v6 = interfaces_none[1]


# Generated at 2022-06-20 17:50:55.100071
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class FakeModule:
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, exe, required=False):
            if exe != 'entstat':
                return exe

        def run_command(self, cmd, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=False):
            return (self.rc, self.out, self.err)

    net_AIX = AIXNetwork()
    net_AIX.module = FakeModule()
    rc, out, err = net_AIX.module.run_command(['ifconfig', '-a'])


# Generated at 2022-06-20 17:50:58.072842
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_net = AIXNetwork()
    aix_net.get_default_interfaces(None)


# Generated at 2022-06-20 17:51:00.284263
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor test of class AIXNetworkCollector
    """
    return AIXNetworkCollector()


# Generated at 2022-06-20 17:51:10.531982
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = AIXNetwork()

    # case when there is no 'default' route in 'netstat -nr'
    assert {}, m.get_default_interfaces('netstat')
    assert {}, m.get_default_interfaces('/sbin/netstat')

    # case when there is 'default' route in 'netstat -nr'
    # default 192.168.55.0 UG 0 0 en0
    # default link#5 UCSI 0 0 en5
    m.module.run_command = lambda cmd: (0, 'default 192.168.55.0 UG 0 0 en0\ndefault link#5 UCSI 0 0 en5\n', '')
    assert {'interface': 'en0', 'gateway': '192.168.55.0'}, m.get_default_interfaces('netstat')


# Generated at 2022-06-20 17:51:11.721819
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    net


# Generated at 2022-06-20 17:51:21.162569
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_module.module = AnsibleModule(argument_spec=dict())
    test_module.module.run_command = mock.Mock(return_value=(0, "default 10.0.0.1 UGS en0", ""))
    test_module.normpath = mock.Mock(return_value="/usr/bin")
    test_AIXNetwork = AIXNetwork(test_module)
    assert test_AIXNetwork.get_default_interfaces("") == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {})



# Generated at 2022-06-20 17:51:23.754700
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_obj = AIXNetworkCollector()
    assert my_obj
    assert isinstance(my_obj, NetworkCollector)


# Generated at 2022-06-20 17:51:25.852834
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_platform = 'AIX'
    test_instance = AIXNetworkCollector()
    assert test_instance.platform == test_platform


# Generated at 2022-06-20 17:51:55.267594
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # module.run_command = MagicMock(return_value=(0, '', ''))
    # module.get_bin_path = MagicMock(return_value='')

    actual = {}
    actual[0] = AIXNetwork(module)
    actual[0].get_interfaces_info('abc')

    assert actual[0].platform == 'AIX'


# Generated at 2022-06-20 17:52:01.760310
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    module.params['gather_network_resources'] = 3

    # create object to test the get_interfaces_info method
    # note: the module object has no 'run_command' method
    aixnetwork_test_obj = AIXNetwork(module)

    # test with real ifconfig command output
    rc, out, err = aixnetwork_test_obj.module.run_command(['/usr/sbin/ifconfig', '-a'])

    assert rc == 0
    assert aixnetwork_test_obj.get_interfaces_info('/usr/sbin/ifconfig') != ({}, {})

    # test with a fake 'ifconfig -a' output
    fake_ifconfig

# Generated at 2022-06-20 17:52:05.273012
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Unit test for class AIXNetwork
    :return: None
    """
    module = None
    aix_net = AIXNetwork(module)
    assert aix_net.platform == 'AIX'


# Generated at 2022-06-20 17:52:12.137068
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en2:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    ansible_module = MagicMock(params={})
    network = AIXNetwork(ansible_module)
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en2'
    assert current_if['type'] == 'unknown'
    assert current_if['mtu'] is None

# Generated at 2022-06-20 17:52:13.425185
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'
    assert isinstance(collector._fact_class(), AIXNetwork)

# Generated at 2022-06-20 17:52:15.832891
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-20 17:52:24.117076
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_mock = AnsibleModuleMock()
    module_mock.get_bin_path.side_effect = [
        'ifconfig',
        'entstat',
        'lsattr',
    ]
    aix_network = AIXNetwork(module_mock)

    interfaces, ips = aix_network.get_interfaces_info('ifconfig', '-a')

    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['macaddress'] == '02:c0:f2:b7:b4:10'
    assert interfaces['en0']['ipv4'][0] == '10.19.4.56/24'

# Generated at 2022-06-20 17:52:29.574842
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils import basic
    m_basic_mock = basic.AnsibleModule
    m_basic_mock.run_command = run_command_mock
    module = m_basic_mock
    aix_network_collector = AIXNetworkCollector(module)
    assert(aix_network_collector._platform == 'AIX')


# Generated at 2022-06-20 17:52:37.220623
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        """Mock module for testing get_interfaces_info method"""

        def __init__(self):
            self.run_command_calls = []
            self.run_command_responses = []
            self.run_command_exceptions = []
            self.get_bin_path_paths = []
            self.get_bin_path_returns = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            response = self.run_command_responses.pop(0)
            if response is OSError:
                raise response
            return response


# Generated at 2022-06-20 17:52:38.555102
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = AIXNetwork()
    assert facts is not None


# Generated at 2022-06-20 17:53:24.403050
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    iface = AIXNetwork()
    assert iface.platform == 'AIX'


# Generated at 2022-06-20 17:53:36.492587
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.utils import parse_ipv4
    from ansible.module_utils.facts.network.utils import parse_ipv6

    ifconfig_path = 'testing_ifconfig_path'
    ifconfig_options = '-a'

# Generated at 2022-06-20 17:53:43.913482
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # test with device name starting with letter 'e'
    words = ['e1:', 'flags=1e0800<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>', 'mtu=1500', 'index=1']
    test_AIXNetwork = AIXNetwork()
    result = test_AIXNetwork.parse_interface_line(words)

# Generated at 2022-06-20 17:53:54.447386
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ansible_module = AnsibleModuleMock()
    ansible_module.run_command = run_command_mock_return(0, '', '')
    aix_network = AIXNetwork()
    aix_network.module = ansible_module


# Generated at 2022-06-20 17:54:01.031757
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork()
    module = FakeAnsibleModule()
    network.module = module
    network.get_default_interfaces('/etc/route')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args_list[0][0][0] == '/usr/bin/netstat'
    assert module.run_command.call_args_list[0][0][1] == '-nr'


# Generated at 2022-06-20 17:54:10.988351
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule({})
    net = AIXNetwork(module)
    (interface_v4, interface_v6) = net.get_default_interfaces('/etc/not_existing_file')
    assert interface_v4 is not None
    assert interface_v6 is not None
    assert interface_v4['interface'] == 'en0'
    assert interface_v4['gateway'] == '172.16.2.254'
    assert interface_v6['interface'] == 'en0'
    assert interface_v6['gateway'] == 'fe80:1::1'


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if len(sys.argv) == 2 and sys.argv[1] == 'test':
        test

# Generated at 2022-06-20 17:54:21.439224
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_content
    ifc_content = get_file_content('tests/unit/module_utils/facts/network/files/aix_ifconfig_a')
    aix = AIXNetwork()
    aix.module = FactCollector()
    aix.module.run_command = lambda args: (0, ifc_content, '')
    interfaces, ips = aix.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-20 17:54:28.437103
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

# Generated at 2022-06-20 17:54:39.056364
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net_collector = AIXNetwork(dict(module=None))


# Generated at 2022-06-20 17:54:46.134565
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = Mock(params={})
    module.get_bin_path.side_effect = lambda x: x

    def run_command(command):
        return 0, '', ''

    del module.run_command
    module.run_command = run_command

    ans = AIXNetwork(module)
    assert ans.parse_interface_line(['en0:']) == {'device': 'en0',
                                                  'ipv4': [],
                                                  'ipv6': [],
                                                  'type': 'unknown',
                                                  'flags': [],
                                                  'macaddress': 'unknown'}

# Generated at 2022-06-20 17:56:36.557368
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-20 17:56:47.096987
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.collector import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.facts import Facts

    class Mymodule(object):

        def __init__(self):
            self.facts = Facts(
                module_name='',
                module_args='',
                facts_module=AIXNetworkCollector,
            )
            self.network = AIXNetworkCollector.load_platform_subclass(self.facts)


# Generated at 2022-06-20 17:56:48.139141
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetworkcollector = AIXNetworkCollector()
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-20 17:56:54.110544
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    def fake_execute(self, args, run_kwargs):
        return (0,
            'default 172.24.12.1 UG eth0',
            None)

    existing_fake_execute = NetworkCollector._execute
    NetworkCollector._execute = fake_execute

    aixNetwork_1 = AIXNetwork(dict(module=None, params=None))
    v4, v6 = aixNetwork_1.get_default_interfaces(None)
    assert v4['gateway'] == '172.24.12.1'
    assert v4['interface'] == 'eth0'

    NetworkCollector._execute = existing_fake_execute


# Generated at 2022-06-20 17:57:04.900962
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:57:16.170195
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import FakeModule
    from ansible.module_utils.facts.network.linux import FakeNetworkParams

    # basic test of AIXNetwork.get_interfaces_info() method
    # input is a string given by ifconfig -a on AIX 7.2
    # output is given by python dict
    # but AIXNetwork.get_interfaces_info() returns a tuple of two dicts

# Generated at 2022-06-20 17:57:22.216127
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec=dict())

    class TestAIXNetwork(AIXNetwork):

        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 17:57:31.724163
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    failed_conditions = []

    # Unit test for querying interface data
    def query_interfaces():
        collect_subset = ['interfaces']
        try:
            network = AIXNetwork(module)
            interfaces = network.get_interfaces_facts(collect_subset)
            assert 'interfaces' in interfaces
        except BaseException:
            failed_conditions.append('Failed to collect interface data')

    query_interfaces()

    # Unit test for querying default gateway data
    def query_default_gateways():
        collect_subset = ['default_gateway']

# Generated at 2022-06-20 17:57:42.669688
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:57:51.418675
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    class TrueModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, command):
            return 0, '', ''

        def get_bin_path(self, binary):
            return '/usr/bin/binary_path'

    ifconfig_path = '/usr/bin/binary_path'
    ifconfig_options = '-a'
    route_path = '/usr/bin/binary_path'
    params = dict(
        ifconfig_path=ifconfig_path,
        ifconfig_options=ifconfig_options,
        route_path=route_path,
    )

    true_module = TrueModule(params)
    aix_network = AIXNetwork(true_module)

    assert aix_network.platform == 'AIX'
    assert aix