

# Generated at 2022-06-20 17:49:08.714672
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})

    nl = AIXNetwork()
    interfaces, ips = nl.get_interfaces_info(nl.module.get_bin_path('ifconfig'))

    print(interfaces)
    print(ips)

    module.exit_json(ansible_facts=dict(ansible_net_interfaces=interfaces, ansible_net_all_ipv4_addresses=ips['all_ipv4_addresses'],
                                        ansible_net_all_ipv6_addresses=ips['all_ipv6_addresses']))



# Generated at 2022-06-20 17:49:16.097604
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    args = dict(
        params=dict(
            route_path='/sbin/route'
        )
    )
    module = AnsibleModule(**args)
    aix_network = AIXNetwork(module)
    result = aix_network.get_default_interfaces('/sbin/route')
    assertEqual(result, ([{'gateway': '10.0.0.1', 'interface': 'en0'}], []))



# Generated at 2022-06-20 17:49:19.772014
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix = AIXNetwork()
    aix.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')


if __name__ == '__main__':
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-20 17:49:29.041774
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork(None)
    test_string = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    test_string += "        inet 10.0.0.100 netmask 0xfffffff0 broadcast 10.0.0.255\n"
    test_string += "        inet6 fe80::5054:ff:fea2:9f67%en0 prefixlen 64 scopeid 0x3\n"
    test_string += "        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>\n"

# Generated at 2022-06-20 17:49:30.808484
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network._platform == 'AIX'
    assert network.get_default_interfaces

# Generated at 2022-06-20 17:49:32.216695
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    assert facts._platform == 'AIX'

# Generated at 2022-06-20 17:49:41.664125
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:49:43.694119
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for class AIXNetworkCollector is tested indirectly via
    its subclasses.
    """
    pass

# Generated at 2022-06-20 17:49:51.519768
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    # create a nested dictionary of facts and call common default_network_collector.get_interfaces_info
    # to populate interfaces and ips dictionaries.
    # Note: no 'facts' module used here - could use it if this were a function rather than a method in
    # default_network_collector class.
    ansible_facts = dict(networks=dict())

    default_network_collector = AIXNetworkCollector()
    default_network_collector.parse_options(ansible_facts, module.params)
    default_network_collector.find_network_resources(ansible_facts, module.params)

   

# Generated at 2022-06-20 17:49:58.735873
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_words = ["lo0:", "flags=849<UP,LOOPBACK,RUNNING,MULTICAST>", "mtu", "32768"]
    real_result = dict({'device': 'lo0', 'ipv4': [],
                        'ipv6': [], 'type': 'unknown',
                        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']})
    test_object = AIXNetwork()
    assert test_object.parse_interface_line(test_words) == real_result



# Generated at 2022-06-20 17:50:16.715386
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This test is for constructor of class AIXNetworkCollector
    """
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    assert issubclass(AIXNetworkCollector, NetworkCollector)



# Generated at 2022-06-20 17:50:17.661888
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-20 17:50:19.519596
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    m = AIXNetwork(dict(module=dict()))
    assert m.platform == 'AIX'


# Generated at 2022-06-20 17:50:24.912024
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('netstat')
    network = AIXNetwork(module, ifconfig_path, route_path)
    assert set(network.interfaces.keys()) == set(['lo0', 'eth0', 'eth1', 'eth2', 'eth3'])

# Generated at 2022-06-20 17:50:32.192803
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    out = """
0        link#1              UHC0                        43        8     en0
        default            192.168.0.1        UGSc           2        27     en0
0        link#2              UHW0                        0        9     en2
0        link#3              UHL1                        0        8     en1
        default            172.16.2.32       UGScI           0        50     en1
        default            10.0.0.4        UGSc           0        15     en2
    """
    test = AIXNetwork()
    assert test.get_default_interfaces(out) == ({'gateway': '192.168.0.1', 'interface': 'en0'}, {'gateway': '10.0.0.4', 'interface': 'en2'})

# Generated at 2022-06-20 17:50:34.444238
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(module=None)).platform == 'AIX'


# Generated at 2022-06-20 17:50:44.972923
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import sys
    import os
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts import ModuleExecutor
    from ansible.module_utils._text import to_bytes

    # create the AIXNetwork object
    ifconfig_path = '/extra/ifconfig'
    module_executor = ModuleExecutor()
    network = AIXNetwork(module_executor, ifconfig_path=ifconfig_path)

    # ifconfig -a output of one interface and expected result

# Generated at 2022-06-20 17:50:52.074021
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import datetime
    import platform
    import sys

    class AIXnetwork_module:
        def __init__(self):
            self.params = None
            self.distribution = None

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            return executable

        def _get_platform_impl_module(self, name=None):
            return AIXnetwork_module()


        def get_module_path(self):
            return self.params

        def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None, binary_data=True):
            return (0, 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 0', '')


# Generated at 2022-06-20 17:51:04.176174
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """Test of method get_default_interfaces of class Network"""
    # File names
    fake_netstat_path = '/tmp/fake_netstat_path'

    # Interface names
    interface_wire = 'wire'
    interface_wireless = 'wireless'
    interface_dummy1 = 'dummy1'
    interface_dummy2 = 'dummy2'
    interface_dummy3 = 'dummy3'

    # IP addresses
    ipv4_default = '1.2.3.4'
    ipv4_dummy = '4.3.2.1'
    ipv6_default = 'fe80:1:2:3:4:5:6:7'
    ipv6_dummy = '7:6:5:4:3:2:1:fe80'

    #

# Generated at 2022-06-20 17:51:10.225298
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_obj = AIXNetwork()
    test_obj.module.run_command = lambda x: (0,
                                             'default 192.168.1.1 UGS en0\ndefault ::1 UGS lo0\ndefault fe80::%en1 UGS en1\n',
                                             '')
    result_v4, result_v6 = test_obj.get_default_interfaces('')
    assert result_v4['interface'] == 'en0'
    assert result_v4['gateway'] == '192.168.1.1'
    assert result_v6['interface'] == 'lo0'
    assert result_v6['gateway'] == '::1'



# Generated at 2022-06-20 17:51:33.686866
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # interface line with flags
    words = 'ent0: flags=0x843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> index 2'
    words = words.split()
    new_AIXNetwork = AIXNetwork()
    current_if = new_AIXNetwork.parse_interface_line(words)

    correct_result = dict(
        device='ent0',
        flags=['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'],
        ipv4=[],
        ipv6=[],
        macaddress='unknown',
        type='unknown')

    assert correct_result == current_if



# Generated at 2022-06-20 17:51:37.670651
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_item = AIXNetwork()
    assert test_item.parse_interface_line(['en0:']) == {
        'device': 'en0', 'flags': ['UP'], 'ipv4': [], 'ipv6': [],
        'macaddress': 'unknown', 'type': 'unknown'
    }

# Generated at 2022-06-20 17:51:48.282072
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    ifconfig_path = '/sbin/ifconfig'

    # Negative
    aix_network_test = AIXNetwork(None, ifconfig_path)
    assert aix_network_test.get_default_interfaces('/sbin/route') is None

    # Positive
    route_path = '/usr/sbin/route'
    aix_network_test = AIXNetwork(None, ifconfig_path)
    assert aix_network_test.get_default_interfaces(route_path) == {'192.169.0.1', '10.0.0.1'}


# Generated at 2022-06-20 17:51:57.827024
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test_case = {
        'en0: ': {'device': 'en0', 'flags': ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST'], 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'},
        'lo0: flags=80049 mtu 33152': {'device': 'lo0', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'},
    }

    result = AIXNetwork.parse_interface_line

    for data in test_case:
        assert result(data.split()) == test_case[data]

# Generated at 2022-06-20 17:52:08.504238
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts import ModuleFactCollector

    test_module = ModuleFactCollector()

    test_module.run_command = lambda command: (0, '', '')    # do not test commands in this unit test

    test_AIXNetwork = AIXNetwork(test_module)
    test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig', '-a')


# Generated at 2022-06-20 17:52:18.216695
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible_collections.ansible.os_mixed.plugins.module_utils.network.common.config.base as conf_base
    import ansible_collections.ansible.os_mixed.plugins.module_utils.network.common.utils as utils

    aixnetwork = AIXNetwork(NetworkCollector, conf_base, utils)

    (v4, v6) = aixnetwork.get_default_interfaces('/etc/routes')

    assert v4 == {'gateway': '10.34.161.1', 'interface': 'en8'}

# Generated at 2022-06-20 17:52:24.383556
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork = AIXNetworkCollector._fact_class({})
    assert AIXNetwork.platform == 'AIX'

    assert AIXNetwork.get_default_interfaces('') == ({}, {})
    assert AIXNetwork.get_interfaces_info('', '') == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

# Generated at 2022-06-20 17:52:34.631244
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Several tests are implemented here:
    1. The whole expected output is tested in test_GenericBsdIfconfigNetwork_get_interfaces_info
    2. Here only data specific to AIX is tested
        * AIX 'ifconfig -a' does not inform about MTU, so remove 'mtu' in AIXNetwork_parse_interface_line output
        * AIX 'ifconfig -a' does not have three words in the interface line
        * AIX 'ifconfig -a' does not have 'ether' before macaddress
    """

# Generated at 2022-06-20 17:52:46.358160
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.params = {}
    network = AIXNetwork()


# Generated at 2022-06-20 17:52:50.545634
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module_mock = MockModule()
    network_collector = AIXNetworkCollector(module_mock)
    network_collector._network_class.get_default_interfaces(route_path='route')
    module_mock.run_command.assert_called_once_with(['netstat', '-nr'])


# Generated at 2022-06-20 17:53:24.492465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import platform
    import sys

    import ansible.module_utils.facts.network.aix as aix

    if platform.system() != 'AIX':
        sys.exit('test skipped')

    interface_name = 'en0'

    netmngr_obj = aix.AIXNetwork()

    rc, out, err = netmngr_obj.module.run_command(['ifconfig', '-a'])

    interfaces, ips = netmngr_obj.get_interfaces_info('ifconfig', '-a')

    print('Interfaces found:')
    for interface, data in interfaces.items():
        print('Interface: ' + interface)
        for key, value in data.items():
            print('\t' + key + ': ' + str(value))

    print('Default routes found:')

# Generated at 2022-06-20 17:53:36.492757
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    collected_facts = dict()
    module = AnsibleModule(argument_spec=dict())

    # some interfaces

# Generated at 2022-06-20 17:53:43.887524
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    network_obj = AIXNetwork(module)

    # test 1
    route_path = '/usr/bin'
    (default_interface_v4, default_interface_v6) = network_obj.get_default_interfaces(route_path)

    if default_interface_v4['interface'] == 'en1' and default_interface_v4['gateway'] == '192.168.56.1':
        module.exit_json(changed=False, ansible_facts=dict())

    # test 2
    route_path = '/usr/bin'

# Generated at 2022-06-20 17:53:47.116291
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.platform == 'AIX'
    assert aix_network_collector._fact_class == AIXNetwork

# Generated at 2022-06-20 17:53:55.011902
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Class AIXNetwork: method get_interfaces_info returns dictionary of dictionaries of interfaces
    """

# Generated at 2022-06-20 17:54:03.490725
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    network = AIXNetwork(module)
    ifconfig_path = network.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    # Check if all interfaces are returned
    assert len(interfaces) == len(EXPECTED_INTERFACES_INFO)
    # Check if all IPv4 addresses are returned
    assert len(ips['all_ipv4_addresses']) == len(EXPECTED_IPS['all_ipv4_addresses'])
    # Check if all IPv6 addresses are returned

# Generated at 2022-06-20 17:54:14.496997
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:54:24.160754
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork

    an = AIXNetwork()

    assert an.parse_interface_line(['en0:']) == {
        'flags': [],
        'device': 'en0',
        'ipv6': [],
        'ipv4': [],
        'type': 'unknown',
        'macaddress': 'unknown',
    }


# Generated at 2022-06-20 17:54:27.323524
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    current_if = test_object.parse_interface_line(['en0:', '[UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST]', 'mtu', '1500'])
    assert current_if['device'] == 'en0'


# Generated at 2022-06-20 17:54:38.342569
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-20 17:55:44.939476
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBsdIfconfigNetwork
    from ansible.module_utils.facts.network.netbsd import NetBsdIfconfigNetwork

    class TestableAIXNetwork(AIXNetwork):
        def __init__(self, *args, **kwargs):
            self.module = args[0]

# Generated at 2022-06-20 17:55:51.118148
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    # the module.run_commands() will take care of running the commands and
    # parsing the results, thus we emulate the result of an actual run_command()
    # function by setting the rc, out, and err.
    #
    # The 'out' and 'err' variables are the result of running the command
    # 'ifconfig -a' in AIX 7.2.
    #
    # The current AIX version is irrelevant for the testing of the method
    # get_interfaces_info() : this unit test will always use this 'out' and 'err',
    # regardless of the actual version of AIX.

# Generated at 2022-06-20 17:55:53.374136
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-20 17:55:56.354695
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Constructor test of class AIXNetwork

    :raise self.failureException: If some of the tests fail.
    """
    module = None
    aix_obj = AIXNetwork(module)
    assert aix_obj.platform == 'AIX'
    assert aix_obj.version == 'AIX'

# Generated at 2022-06-20 17:55:59.839958
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert NetworkCollector._platform == 'Generic'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'
    return True



# Generated at 2022-06-20 17:56:06.957720
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_data = ['lo0:0 flags=800000<UP,LOOPBACK,RUNNING> mtu 1388 index 14',
                 'lo0:1 flags=800000<UP,LOOPBACK,RUNNING> mtu 1388 index 15',
                 'lo0:2 flags=800000<UP,LOOPBACK,RUNNING> mtu 1388 index 16',
                 'lo0:3 flags=800000<UP,LOOPBACK,RUNNING> mtu 1388 index 17',
                 'lo0: flags=800000<UP,LOOPBACK,RUNNING> mtu 1388 index 11',
                 ]


# Generated at 2022-06-20 17:56:17.945598
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:56:20.870658
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test the constructor of the AIXNetworkCollector class"""
    module = object()
    collector = AIXNetworkCollector(module)

    assert collector._fact_class is AIXNetwork
    assert collector._platform is 'AIX'
    assert collector._module is module

# Generated at 2022-06-20 17:56:26.587104
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collector = AIXNetworkCollector(module=module)
    assert collector.facts['network'] == 'AIXNetwork'
    assert collector.facts['default_ipv4']['interface'] == 'eth0'
    assert collector.facts['default_ipv4']['gateway'] == '192.48.1.1'
    assert collector.facts['default_ipv6']['interface'] == 'eth0'
    assert collector.facts['default_ipv6']['gateway'] == 'fe80::a8bb:ccff:fedd:eeff'

# Generated at 2022-06-20 17:56:30.797369
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-20 17:58:33.455202
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test the get_default_interfaces method for correct results
    """

    class ModuleTest(object):
        """
        Class to mock up an AnsibleModule.
        """
        def __init__(self):
            """
            Initialise the module.
            """
            self.params = dict()
            self.run_command = test_AIXNetwork_run_command
            self.get_bin_path = test_AIXNetwork_get_bin_path

    def test_AIXNetwork_run_command(self, commands, check_rc=True):
        """
        Mock up run_command to return some data.
        """
        paths = dict(
            netstat='/usr/bin/netstat'
        )


# Generated at 2022-06-20 17:58:41.950261
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.network.aix.ifconfig import AIXNetworkCollector
    facts = dict()     # no facts available
    net0 = dict(device='en0', ipv4=[], ipv6=[], type='ether', flags='UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST', macaddress='01:02:03:04:05:06', mtu=1500)

# Generated at 2022-06-20 17:58:50.084225
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Options(object):
        def __init__(self, path, options):
            self.path = path
            self.options = options

    class AnsibleModule(object):
        def __init__(self):
            self.params = Options

        def get_option(self, path):
            return Options(path, '-a')

        def get_bin_path(self, path, opt_dirs=None):
            return '/usr/sbin/' + path

        def run_command(self, command, check_rc=False):
            if command[1] == '-a':
                return (0, the_text, '')
            elif command[1] == '-nr':
                return (0, the_text_route, '')