

# Generated at 2022-06-20 17:49:09.464181
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-20 17:49:16.716554
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:49:24.732354
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import TestNetworkEnvironment
    from ansible.module_utils.facts.network.generic_bsd import MockNetworkEnvironment

    testenv = TestNetworkEnvironment()

# Generated at 2022-06-20 17:49:36.350454
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = NetworkCollector(dict())
    net = AIXNetwork(m)

    # set up test data
    route_path = '/usr/sbin/route'
    result_1 = dict(v4=dict(gateway='172.16.1.1', interface='en0'), v6=dict(gateway='fe80::5054:ff:fea8:6c9e', interface='en0'))
    result_2 = dict(v4=dict(gateway='172.16.1.1', interface='en0'), v6={})
    result_3 = dict(v4={}, v6=dict(gateway='fe80::5054:ff:fea8:6c9e', interface='en0'))
    result_4 = dict(v4={}, v6={})

    # set up env variable

# Generated at 2022-06-20 17:49:45.899061
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fact_class = AIXNetwork()
    # This is an example from AIX 7.1 TL3 SP8
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = fact_class.module.run_command([ifconfig_path, ifconfig_options])
    assert rc == 0, "uname command failed"
    fake_ifconfig_file = out
    interfaces, ips = fact_class.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-20 17:49:51.471225
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec={'route_path': dict(required=False)})
    net.module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    net.module.run_command = MagicMock(return_value=(0, '', ''))

    # case 0: neither v4 nor v6 interface
    net.module.run_command.return_value = (0, '', '')
    assert net.get_default_interfaces('route') == (None, None)

    # case 1: v4 interface only
    net.module.run_command.return_value = (0, 'default 10.10.10.1 UGS 0 en0', '')

# Generated at 2022-06-20 17:50:01.341771
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork constructor"""
    network_collector = AIXNetworkCollector
    mac_addr_dict = ['00:00:00:00:00:00']

# Generated at 2022-06-20 17:50:12.649370
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    os = {'distribution': 'AIX', 'distribution_release': '7.1', 'distribution_version': '7100-02-02-1543'}
    module = type('module', (), {'run_command': None})
    module.params = {'gather_network_resources': 'yes'}
    module.os = os
    module.get_bin_path = (lambda x: x)
    ans = AIXNetwork(module)
    words = "lo0: flags=80049<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 65536 index 1".split()

# Generated at 2022-06-20 17:50:19.380500
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    interfaces = AIXNetwork().get_interfaces_info('/usr/sbin/ifconfig', '-a')
    assert(interfaces == ([{'device': 'lo0', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '65536', 'ipv4': [], 'macaddress': 'unknown', 'type': 'loopback'}], [], []))

# Generated at 2022-06-20 17:50:23.801964
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(dict())
    network = AIXNetwork(module)
    v4_route, v6_route = network.get_default_interfaces('/dev/null')

    assert v4_route['interface'] == 'en0'
    assert v6_route['interface'] == 'en0'

# Generated at 2022-06-20 17:50:45.945604
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'


# Stand-alone test code for the AIXNetwork module
if __name__ == '__main__':

    # Test module AIXNetwork

    aix_network = AIXNetwork()
    print('Platform:               %s' % aix_network.platform)
    print('Distribution:           %s' % aix_network.distribution)
    print('Distribution Version:   %s' % aix_network.distribution_version)
    print('Default Interfaces:')
    print(aix_network.default_interfaces)
    print('Interfaces:')
    print(aix_network.interfaces)
    print('All IPv4 Addresses:')

# Generated at 2022-06-20 17:50:53.791208
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_net = AIXNetwork()
    words = ['lo0:', 'flags=849', 'mtu=65536', 'index=1']
    expected = dict(device='lo0', ipv4=[], ipv6=[], type='unknown', flags=['UP', 'LOOPBACK', 'RUNNING'], macaddress='unknown')
    aix_net.parse_interface_line(words)
    if aix_net.current_if != expected:
        raise AssertionError("Expected: %s but got: %s" % (expected, aix_net.current_if))


# Generated at 2022-06-20 17:51:05.306261
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class AIXNetwork
    :return:
    """
    test_class = AIXNetwork(None)

    # test case 1

# Generated at 2022-06-20 17:51:10.871694
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork_get_interfaces_info
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    new_class = AIXNetwork(None)
    GenericBsdIfconfigNetwork_get_interfaces_info(new_class, ifconfig_path, ifconfig_options)



# Generated at 2022-06-20 17:51:14.717977
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    c = AIXNetwork(module)

    assert c.get_default_interfaces('/usr/sbin/route') == ({}, {})

# Generated at 2022-06-20 17:51:25.281470
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # pylint: disable=all
    # pylint: disable=too-many-locals
    # pylint: disable=invalid-name
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-few-public-methods
    # pylint: disable=bare-except
    # pylint: disable=fixme
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-arguments
    #

# Generated at 2022-06-20 17:51:35.246617
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    platform = 'AIX'
    module = MockModule()
    # set uname -W rc and out
    rc = 0
    out = '0'
    # set lsattr -El rc and out
    lsattr_rc = 0
    lsattr_out = 'mtu   65536'
    # set entstat rc and out
    entstat_rc = 0
    entstat_out = [
        'Hardware Address: 00:11:22:33:44:55',
        'Hardware Address Type: IEEE 802.3',
        'Hardware Address Length: 6'
    ]
    # set netstat -nr rc and out
    netstat_rc = 0

# Generated at 2022-06-20 17:51:41.510065
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import AIXNetwork
    import os
    import sys

    class AnsiMock:
        def __init__(self):
            self.rc = 0

# Generated at 2022-06-20 17:51:46.248080
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert aix_network.get_interfaces_info is not None
    assert aix_network.get_default_interfaces is not None
    assert aix_network.parse_interface_line is not None

# Generated at 2022-06-20 17:51:56.224084
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    aixnetwork = AIXNetwork()
    interfaces, ips = aixnetwork.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'MULTICAST', 'NODEBUG']

# Generated at 2022-06-20 17:52:18.260375
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # initialize object
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    AIXNetworkObj = AIXNetwork(module=None)

    # define the expected result

# Generated at 2022-06-20 17:52:29.707160
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import json

    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.exit_json = lambda x: x

    ifconfig_path = ansible_module.get_bin_path('ifconfig')
    ifconfig_options=''
    uname_path = ansible_module.get_bin_path('uname')
    uname_rc, uname_out, uname_err = ansible_module.run_command([uname_path, '-W'])

    rc, out, err = ansible_module.run_command([ifconfig_path, ifconfig_options])

    for line in out.splitlines():
        words = line.split()
        # only this condition differs from GenericBsdIfconfigNetwork

# Generated at 2022-06-20 17:52:31.657618
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetworkCol = AIXNetworkCollector()
    assert aixnetworkCol.platform == 'AIX'

# Generated at 2022-06-20 17:52:34.839941
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert aix_network.get_default_interfaces is not None
    assert aix_network.get_interfaces_info is not None
    assert aix_network.parse_interface_line is not None

# Generated at 2022-06-20 17:52:45.267858
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # mock
    module = type('', (object,), {'run_command': run_command})
    module.get_bin_path = mock_get_bin_path

    network_class = AIXNetwork(module)

    # Testcase 1
    netstat_path = 'netstat'
    expected_result = dict(
        v4=dict(gateway='172.17.0.1', interface='en0'),
        v6=dict(gateway='fe80::f816:3eff:fe7b:6a2c', interface='en0')
    )
    result = network_class.get_default_interfaces(netstat_path)
    assert result == expected_result



# Generated at 2022-06-20 17:52:54.615841
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork({})

# Generated at 2022-06-20 17:53:00.975151
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    result = Network(module).populate()
    assert 'gather_subset' in result
    assert result['gather_subset'] == ['!all']
    assert result['gather_network_resources'] == ['interfaces', 'default_ipv4', 'default_ipv6']
    assert 'interfaces' in result
    assert 'default_ipv4' in result
    assert 'default_ipv6' in result
    assert 'all_ipv4_addresses' in result
    assert 'all_ipv6_addresses' in result

# Generated at 2022-06-20 17:53:07.637951
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector._create_module(params={})
    # fake_module.params = {'gather_subset': ['!all', '!min']}
    aix_network = AIXNetwork(module)
    assert aix_network.platform == 'AIX'
    assert aix_network._fact_class == AIXNetwork
    assert aix_network.get_default_interfaces.__name__ == 'get_default_interfaces'

# Generated at 2022-06-20 17:53:16.329474
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec=dict()) # Dummy AnsibleModule class
    from ansible.module_utils.facts.network.generic_bsd import GenericBsd
    generic_bsd = GenericBsd(module=mod)
    network_collector = AIXNetwork(module=mod, generic_bsd=generic_bsd)
    assert network_collector.module == mod
    assert network_collector.generic_bsd == generic_bsd
    assert network_collector.platform == 'AIX'
    assert not network_collector.interfaces
    assert not network_collector.facts
    assert network_collector.default_interface == {}
    assert network_collector.default_interface_ipv6 == {}
    assert network_collector.route


# Generated at 2022-06-20 17:53:24.402545
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    Tests cases:
    - ifconfig with different options
    - ifconfig with different number of interfaces
    """
    # create a temp dictionary to store interface information
    interface_temp = {}
    # create a test object of class AIXNetwork
    test_obj = AIXNetwork()

    ####################################################################
    # test 1: ifconfig with one interface
    ####################################################################

# Generated at 2022-06-20 17:53:55.512824
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(required=True),
    })

    test_object = AIXNetwork({}, module)
    # test_object._module = module
    # result = test_object.get_default_interfaces('/bin/netstat')
    # assert result == {'v4': {'gateway': '192.0.2.1', 'interface': 'en0'}, 'v6': {'gateway': '2001:db8:1::1', 'interface': 'en0'}}


# Generated at 2022-06-20 17:54:01.998793
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m_t = dict()
    n = AIXNetwork(m_t)

    line = "lo0: flags=0x80000849 <UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 0"
    result = n.parse_interface_line(line.split())
    assert result['device'] == 'lo0'
    assert result['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6', 'VIRTUAL']
    assert result['macaddress'] == 'unknown'
    assert result['type'] == 'unknown'
    assert 'mtu' not in result


# Generated at 2022-06-20 17:54:04.757809
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # construct AIXNetwork with empty module
    aix_network = AIXNetwork(dict(module=dict()))

    # test that platform is AIX
    assert aix_network.platform == 'AIX'



# Generated at 2022-06-20 17:54:09.253564
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector._platform == 'AIX'
    assert aix_network_collector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:54:20.492003
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    m_get_bin_path = get_bin_path()
    m_run_command = run_command()

    m_AIXNetwork = AIXNetwork(m_get_bin_path, m_run_command)
    m_AIXNetwork.get_interfaces_info = GenericBsdIfconfigNetwork.get_interfaces_info
    m_AIXNetwork.get_interfaces_info.__doc__ = "unittest_" + m_AIXNetwork.get_interfaces_info.__doc__


# Generated at 2022-06-20 17:54:24.751733
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    network_facts = collector.populate_facts()
    assert 'interfaces' in network_facts
    assert 'all_ipv4_addresses' in network_facts
    assert 'all_ipv6_addresses' in network_facts

# Unit test used by integration test on AIX with python 2.7.13

# Generated at 2022-06-20 17:54:35.720306
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix_network import AIXNetwork

    aixnet = AIXNetwork()
    result = aixnet.get_interfaces_info(aixnet.module.get_bin_path('ifconfig'))
    assert type(result) is tuple
    assert len(result) == 2
    assert type(result[0]) is dict
    assert type(result[1]) is dict
    assert type(result[0]['lo0']) is dict
    assert type(result[1]['ipv4']['all_ipv4_addresses']) is list
    assert type(result[1]['ipv6']['all_ipv6_addresses']) is list



# Generated at 2022-06-20 17:54:44.874328
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    network_info = collector.get_network_facts()
    assert network_info.get('all_ipv4_addresses')
    assert network_info.get('default_ipv4')
    assert network_info.get('all_ipv6_addresses')
    assert network_info.get('default_ipv6')
    assert network_info.get('interfaces')
    assert network_info.get('default_gateway_interface')

#required module boilerplate
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

# Generated at 2022-06-20 17:54:54.561339
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    ansible_module_mock = Mock()
    ansible_module_mock.run_command.return_value = (0, '', '')
    ansible_module_mock.get_bin_path.return_value = '/usr/bin/netstat'

    m = AIXNetwork(ansible_module_mock)

    result = m.get_default_interfaces('/etc/netstat')
    assert result == ({'gateway': '1.1.1.1', 'interface': 'en0'}, {'gateway': '20:20:20:20:20:20::1', 'interface': 'en0'})


# Generated at 2022-06-20 17:55:04.163514
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-20 17:56:13.924483
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # thanks to aaaaaaaaaaa for this
    data = """
    Destination        Gateway            Flags   Refs     Use   Mtu   Interface
    default            172.16.1.1          UG        0     719        1500         en0
    default            10.240.0.1          UG        0     701        1500         en1
    default            10.240.0.1          UG        0     701        1500         en5
    default            10.240.0.1          UG        0     701        1500         en3
    default            10.240.0.1          UG        0     701        1500         en6
    default            10.240.0.1          UG        0     701        1500         en7
    default            10.240.0.1          UG        0     701        1500         en4
    """
   

# Generated at 2022-06-20 17:56:16.454093
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test constructor for class AIXNetworkCollector."""
    network = AIXNetworkCollector()
    assert network._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:56:19.230332
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()

    assert net_collector._fact_class is AIXNetwork
    assert net_collector._platform == "AIX"


# Generated at 2022-06-20 17:56:25.104912
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()[0]
    assert network.get_default_interfaces('/usr/sbin/netstat') == (
        {'gateway': '192.168.0.1', 'interface': 'en0'},
        {'gateway': 'fe80::d7f8:4f53:3e4d:6', 'interface': 'en0'}
    )



# Generated at 2022-06-20 17:56:36.123701
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule(object):
        def run_command(self, cmd):
            if cmd[0] == '/usr/bin/netstat':
                return 0, "default 192.0.2.3 UG 1 en1\ndefault 192.0.2.3 UG 1 en1 U\ndefault 2001:db8::1 UG 1 en1", ""

        def get_bin_path(self, name):
            return '/usr/bin/netstat'

    test_module = MockModule()

    AIXNetwork_object = AIXNetwork()
    AIXNetwork_object.module = test_module
    ifconfig_path = AIXNetwork_object.module.get_bin_path('ifconfig')

    assert ifconfig_path == '/usr/bin/netstat'
    assert AIXNetwork_object.get_default_inter

# Generated at 2022-06-20 17:56:47.015078
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import socket
    import types

    o = AIXNetwork(dict(module=None))

    result = o.get_interfaces_info('/sbin/ifconfig')
    assert isinstance(result, types.TupleType), 'is tuple'
    assert len(result) == 2, 'has two elements'

    interfaces, ips = result
    assert isinstance(interfaces, types.DictType), 'interfaces is a dictionary'
    assert isinstance(ips, types.DictType), 'ips is a dictionary'

    assert len(interfaces) > 0, 'interfaces are collected'

    for name, interface in interfaces.iteritems():
        assert isinstance(name, types.StringTypes), 'interface name is a string'
        assert isinstance(interface, types.DictType), 'interface is a dictionary'

        assert 'device'

# Generated at 2022-06-20 17:56:53.161275
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create a dummy module object
    module = MockModule()

    # create a instance of AIXNetwork
    ifconfig_path = module.get_bin_path('ifconfig')
    AIX_network = AIXNetwork(module, ifconfig_path)
    # call method get_default_interfaces
    interface = AIX_network.get_default_interfaces('/usr/sbin/netstat')
    assert interface == ('172.16.0.1', 'fe80::250:56ff:fe0f:b4af')

# Generated at 2022-06-20 17:56:57.596782
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ai = AIXNetwork()
    interface_v4 = dict(v4={}, v6={})
    results = ai.get_default_interfaces('/usr/sbin/route')
    assert results == (interface_v4, interface_v4)

# Generated at 2022-06-20 17:57:09.021007
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-20 17:57:17.819956
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    aix_network = AIXNetwork()