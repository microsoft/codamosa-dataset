

# Generated at 2022-06-20 17:49:09.322378
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    t_args = dict()
    t_args['device'] = 'en0'
    t_args['type'] = 'unknown'
    t_args['macaddress'] = 'unknown'
    t_args['flags'] = ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    t_args['ipv4'] = []
    t_args['ipv6'] = []
    t_words = list()
    t_words.append('en0:')
    t_words.append('flags=8048063<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>')
    t_words.append('mtu 1500')
    t_words.append('index 5')

# Generated at 2022-06-20 17:49:16.626693
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnetwork = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})
    aixnet1 = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})
    aixnet2 = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})
    aixnet3 = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})
    aixnet4 = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})
    aixnet5 = AIXNetwork({'path': '/usr/bin:/bin:/usr/sbin:/sbin'})

# Generated at 2022-06-20 17:49:19.629632
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc.fact_class._platform == 'AIX'
    assert nc.fact_class._fact_class == AIXNetwork



# Generated at 2022-06-20 17:49:28.929227
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    result = dict(changed=False, ansible_facts=dict())
    aix_network = AIXNetwork(module)
    ifconfig_path = module.get_bin_path('ifconfig')
    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')
    netstat_path = module.get_bin_path('netstat')
    if not netstat_path:
        module.fail_json(msg='netstat not found')
    uname_path = module.get_bin_path('uname')
    if not uname_path:
        module.fail_json(msg='uname not found')

# Generated at 2022-06-20 17:49:31.787417
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    my_obj = AIXNetwork()
    assert (isinstance(my_obj, AIXNetwork))


# Generated at 2022-06-20 17:49:41.416330
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    fact_module_path = 'ansible.module_utils.facts.network.aix.AIXNetwork'
    ansible_module_mock = type('AnsibleModuleMock', (object, ), {'params': {}, 'get_bin_path': lambda x: '/usr/bin/ifconfig'})()
    ansible_module_mock.run_command = lambda x: (0, '', '')
    ansible_module_mock.check_mode = False
    facts_network_class_mock = type('AIXNetwork', (object,), {'parse_interface_line': lambda x: x, 'get_options': lambda x: []})

# Generated at 2022-06-20 17:49:44.033435
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    obj = AIXNetworkCollector(module)
    assert obj.platform == 'AIX'

# Generated at 2022-06-20 17:49:46.456485
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-20 17:49:52.243477
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:49:53.478825
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert(issubclass(AIXNetworkCollector, NetworkCollector))

# Generated at 2022-06-20 17:50:11.748244
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    args = ['en0:', 'flags=0x0<>', 'mtu', '0']
    ifconfig_output = AIXNetwork()
    result = ifconfig_output.parse_interface_line(args)
    assert result == {'ipv4': [], 'macaddress': 'unknown', 'ipv6': [], 'device': 'en0', 'type': 'unknown', 'flags': []}

# Generated at 2022-06-20 17:50:17.709365
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})
    test_AIXNetwork = AIXNetwork(test_module)

    # Hardcoding path to ifconfig
    # On AIX, ifconfig is usually in /usr/sbin
    test_ifconfig_path = '/usr/sbin/ifconfig'

    assert test_AIXNetwork.get_interfaces_info(test_ifconfig_path) != (None, None)


# Generated at 2022-06-20 17:50:27.426175
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/bin/ifconfig'
    netstat_path = '/usr/bin/netstat'
    module = FakeAnsibleModule(aix_ifconfig_path=ifconfig_path, aix_netstat_path=netstat_path)
    ifconfig_path = module.get_bin_path('ifconfig')

    # A simple netstat command output of "netstat -nr", run on AIX 7100-03-00-1716

# Generated at 2022-06-20 17:50:32.494146
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    interfaces = {
        'v4': {
            'gateway': '10.255.254.254',
            'interface': 'lo0'
        },
        'v6': {
            'gateway': 'fe80::8',
            'interface': 'lo0'
        }
    }
    class module_mock():
        def get_bin_path(self, cmd):
            return cmd
    mod_mock = module_mock()
    netif = AIXNetwork(mod_mock)
    assert interfaces == netif.get_default_interfaces('/')



# Generated at 2022-06-20 17:50:43.721992
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for the method get_interfaces_info of class AIXNetwork
    """

    from ansible.module_utils.facts.network.aix import AIXNetwork
    network = AIXNetwork()

    # test for aix: ifconfig -a

# Generated at 2022-06-20 17:50:53.169014
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_mock = AnsibleModuleMock()
    platform = 'AIX'
    network = AIXNetwork(module_mock)
    path = network.module.get_bin_path('ifconfig')
    try:
        ifconfig_output = open('data/%s_ifconfig.out' % platform, 'rb').read()
    except IOError:
        raise Exception("Failed to open ifconfig output data file for platform: %s" % platform)
    module_mock.run_command = mock.Mock(return_value=(0, ifconfig_output, ''))
    interfaces, ips = network.get_interfaces_info(path)
    assert 'en0' in interfaces

# Generated at 2022-06-20 17:51:04.534873
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=1e080863,c0', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    current_if = AIXNetwork().parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT',
                                   '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'


# Generated at 2022-06-20 17:51:11.567696
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:51:15.198746
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Method get_interfaces_info of class AIXNetwork has been tested in unit tests of module_utils/facts/network/generic_bsd.py"""
    pass


# Generated at 2022-06-20 17:51:24.283010
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    test = AIXNetwork({})
    assert test.platform == 'AIX'
    assert test.get_default_interfaces([]) == (dict(gateway=None, interface=None), dict(gateway=None, interface=None))

    interfaces, ips = test.get_interfaces_info('/sbin/ifconfig', '-a')
    assert interfaces  # the result should not be empty
    assert ips['all_ipv4_addresses']   # the result should not be empty
    assert ips['all_ipv6_addresses']   # the result should not be empty

# Generated at 2022-06-20 17:51:57.235544
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    network = AIXNetwork()
    network.module = _AnsibleMockModule()
    network.module.get_bin_path = network._get_bin_path

    interfaces = _AnsibleMockInterfaces()

    interfaces['eth0:'] = {}
    interfaces['eth1:'] = {}
    interfaces['lo0:'] = {}

    # test if an interface without options
    line = 'eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>'
    words = line.split()
    current_if = network.parse_interface_line(words)

# Generated at 2022-06-20 17:52:08.292594
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    a = AIXNetwork()

    words = 'en0:'.split()
    current_if = a.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'

    words = 'en1: flags=8a63<UP,BROADCAST,NOTRAILERS,RUNNING,ALLMULTI,SIMPLEX,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),SLAVE,MULTICAST> mtu 1500 index 2'.split()
    current_if = a.parse_interface_line(words)
    assert current_if['device'] == 'en1'

# Generated at 2022-06-20 17:52:18.037183
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test_dict = dict(
        result_interface_wpar = dict(
            device = 'en0',
            ipv4 = [],
            ipv6 = [],
            type = 'unknown'),
        result_interface_lpars = dict(
            device = 'eth0',
            ipv4 = [],
            ipv6 = [],
            type = 'unknown'),
        )

    words_wpar = ['en0:', 'flags=8903<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'lo0', 'link', '0']

# Generated at 2022-06-20 17:52:23.657266
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Unit test for constructor of class AIXNetwork
    """
    module = generic_bsd_ifconfig_module_mock()
    aix = AIXNetwork(module=module)
    # Test params
    assert aix.platform == 'AIX'



# Generated at 2022-06-20 17:52:34.278310
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = MockModule()
    test_obj = AIXNetwork(module)
    net_str = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    words = net_str.split()
    result = test_obj.parse_interface_line(words)
    assert result['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN']
    assert result['macaddress'] == 'unknown'



# Generated at 2022-06-20 17:52:38.891507
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aixnet = AIXNetwork()

    # AIX 'ifconfig -a' does not have three words in the interface line
    assert aixnet.get_interfaces_info('ifconfig', '-a')[0] == {}
    assert aixnet.get_default_interfaces('netstat') == ({}, {})

# Generated at 2022-06-20 17:52:49.887423
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['eth0:', 'flags=8c02<BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>', 'mtu=1500', 'options=6006b8<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU>']
    # words = ['eth0:', 'flags=8c02<BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>', 'mtu=1500', 'options=6006b8<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU>', 'index=0', 'address=00:2:3:4:5']

# Generated at 2022-06-20 17:52:58.478004
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    import json
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    aix_network_collector = NetworkCollector()
    aix_network_collector._platform = AIXNetwork.platform

    test_dir = os.path.dirname(__file__) + os.sep + 'lf'
    test_files = os.listdir(test_dir)

    for test_file in test_files:
        if re.match(r'.*\.input$', test_file):
            base = re.sub(r'\.input$', '', test_file)

            aix_network_collector.module = None
            aix_network_collector.module = json.loads

# Generated at 2022-06-20 17:53:09.443471
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # This is the output of netstat -rn
    #
    # Destination        Gateway            Flags    Refs    Use  Interface
    # default            192.168.240.1      UG        0      0    en4
    # default            fe80::215:5dff:fe40:9a9b      UG        0      0    en4
    #

    net_cls = AIXNetwork()
    assert net_cls.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.240.1', 'interface': 'en4'},
                                                             {'gateway': 'fe80::215:5dff:fe40:9a9b', 'interface': 'en4'})

# Generated at 2022-06-20 17:53:18.120932
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface = AIXNetwork(dict(module=None))
    line = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    words = line.split()
    current_if = interface.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'][0] == 'UP'
    assert current_if['flags'][1] == 'BROADCAST'
    assert current_if['flags'][2] == 'NOTRAILERS'
    assert current_if['flags'][3] == 'RUNNING'

# Generated at 2022-06-20 17:54:07.780769
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Just instantiate and check
    """
    collector = AIXNetworkCollector()
    assert collector is not None

# Generated at 2022-06-20 17:54:15.974234
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    test_case = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    test_case_words = test_case.split()

# Generated at 2022-06-20 17:54:23.472619
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIX = AIXNetwork()
    current_if = AIX.parse_interface_line(['en0:', 'flags=1c02<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>,'])
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:54:25.403878
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = AIXNetworkCollector(module).collect()
    assert result is not None
    assert result['interfaces'] is not None
    assert result['default_interface'] is not None

# Generated at 2022-06-20 17:54:37.290587
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # given
    test_if = AIXNetwork()
    given_line = ['en0:', 'flags=1e080863,480', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric 1', 'mtu 1500']
    expected_device = 'en0'
    expected_options = 'UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN'
    expected_macaddress = 'unknown'

    # when
    result = test_if.parse_interface_line(given_line)

    # then
    assert expected_device

# Generated at 2022-06-20 17:54:46.197799
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    import platform

    # construct AIXNetworkCollector object
    collector = AIXNetworkCollector()

    # AnsibleModule mock
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, path, required=False):
            return path


# Generated at 2022-06-20 17:54:48.277393
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork()
    assert AIXNetwork().platform == 'AIX'



# Generated at 2022-06-20 17:54:50.295769
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    assert isinstance(facts, AIXNetworkCollector)

# Generated at 2022-06-20 17:54:51.894997
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_if = AIXNetwork()
    test_if.parse_interface_line(['en0::'])

# Generated at 2022-06-20 17:55:01.081154
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ifconfig_path = None
    ifconfig_options = '-a'

    # mocked module
    class AIXModule:

        def get_bin_path(self, binary):
            return None

        def run_command(self, cmd):
            return 0, '', ''

    # mocked module
    class AIXNetwork:

        def __init__(self):
            self.module = AIXModule()

        def get_interfaces_info(self, ifconfig_path, ifconfig_options):
            return dict(), dict()

    network = AIXNetwork()
    assert network.get_interfaces_info(ifconfig_path, ifconfig_options) == (dict(), dict())

# Generated at 2022-06-20 17:56:51.167221
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork constructor"""

    module = NetworkCollector.get_platform_module('AIX')
    assert module.platform == 'AIX'
    assert module.platform_uname == 'AIX'
    assert module.platform_default_route_command == 'netstat -nr'

# Generated at 2022-06-20 17:56:53.563006
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    network_collector.collect()


# Generated at 2022-06-20 17:56:59.820403
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    words = 'ent0'.split()
    current_if = aix.parse_interface_line(words)
    assert current_if['device'] == 'ent0'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'
    assert 'UP' in current_if['flags']
    assert 'BROADCAST' in current_if['flags']

# Generated at 2022-06-20 17:57:12.179483
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # TODO: make this test work without creating a file
    ifname=open('/tmp/ifconfig-nr.txt', 'wt')

# Generated at 2022-06-20 17:57:13.586700
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    m = AIXNetwork({})
    assert m.platform == 'AIX'


# Generated at 2022-06-20 17:57:17.884902
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ansible_module = mock.Mock()
    ansible_module.run_command.return_value = (0, '', '')
    ansible_module.get_bin_path.return_value = ''

    result = AIXNetwork(ansible_module)
    assert result._platform == 'AIX'



# Generated at 2022-06-20 17:57:28.419189
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    interface = AIXNetwork()

    assert 'AIX' == interface.platform
    assert 'generic_bsd' == interface.distribution
    assert 'ifconfig' == interface.ifconfig_path
    assert isinstance(interface.interface_options, list)
    assert '/sbin/route' == interface.route_path
    assert interface.route_options == '-n get 0.0.0.0'
    assert interface.ip_path == 'ip'
    assert interface.naming_scheme == 'bsd'
    assert interface.mandatory_fields == ['device', 'type', 'flags']

# Generated at 2022-06-20 17:57:37.600772
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import ModuleTestSuite

    class test_module:
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, command):
            return 'mock_path'

        def run_command(self, command):
            return (0, '', '')

    test_suite = ModuleTestSuite('ifconfig -a')
    test_suite.add_module_tests(AIXNetwork.get_interfaces_info, test_module())
    test_suite.run()

# Generated at 2022-06-20 17:57:40.686535
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ constructor for class AIXNetworkCollector """
    AIXNetworkCollector()


# Generated at 2022-06-20 17:57:42.590944
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_class_constructor_unit_test(AIXNetworkCollector)