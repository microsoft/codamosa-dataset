

# Generated at 2022-06-20 17:49:09.323121
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # unit test for method parse_interface_line of class AIXNetwork
    # testing when we have mac address

    # create instance of class AIXNetwork
    test_instance = AIXNetwork()

    # test data
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n'
    words = line.split()
    # call function to test
    test_if = test_instance.parse_interface_line(words)
    # expected result

# Generated at 2022-06-20 17:49:16.627424
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # module is not present in the global namespace
    import ansible.module_utils.facts.network.aix as aix
    # reload the module because we just created it
    reload(aix)
    obj = aix.AIXNetwork()
    assert obj.platform == 'AIX'
    res = obj.get_interfaces_info("/sbin/ifconfig")
    assert len(res) == 2
    (res1, res2) = res
    assert isinstance(res1, dict)
    assert isinstance(res2, dict)
    res = obj.get_interfaces_info("/sbin/ifconfig", ifconfig_options='-a')
    assert len(res) == 2
    (res1, res2) = res
    assert isinstance(res1, dict)

# Generated at 2022-06-20 17:49:24.607924
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    import copy
    import re

    module = type('module', (), {})()
    module.run_command = lambda args: 1, '', ''

    a = AIXNetwork(module)

    # tests method get_interfaces_info:
    # runs with empty string out (which should be impossible, but just for testing)
    # this test also implicitly tests get_default_interfaces
    module.run_command = lambda args: 1, '', ''
    result = a.get_interfaces_info("does_not_matter")
    expected = dict(interfaces={}, default_interface_ipv4={}, default_interface_ipv6={})
    assert result == expected

    # runs with string out not containing ':'
    module.run_command = lambda args: 1, 'some random text', ''
    result = a.get_interfaces

# Generated at 2022-06-20 17:49:28.368598
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'
    assert AIXNetwork.platform_aix
    assert not AIXNetwork.platform_freebsd
    assert not AIXNetwork.platform_linux
    assert not AIXNetwork.platform_openbsd


# Generated at 2022-06-20 17:49:29.305719
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-20 17:49:34.500152
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_class = AIXNetwork()

    test_class.module = MagicMock()

    res1 = ('/usr/bin/netstat', True)
    res2 = (0, 'default 172.16.0.1 - UG en1\n', '')
    test_class.module.get_bin_path.side_effect = [res1, res1]
    test_class.module.run_command.return_value = res2

    if4, if6 = test_class.get_default_interfaces('netstat')
    assert if4 == {'gateway': '172.16.0.1', 'interface': 'en1'}
    assert if6 == {}

    res1 = ('/usr/bin/netstat', True)

# Generated at 2022-06-20 17:49:36.265255
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(), dict())


# Generated at 2022-06-20 17:49:38.198178
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec={})
    ws = AIXNetwork(mod)
    assert ws.get_interfaces_info('/bin/ifconfig')

# Generated at 2022-06-20 17:49:40.183632
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    if collector is not None:
        assert collector._platform == 'AIX'
        assert collector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:49:45.047317
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    fact_module = AIXNetworkCollector(module)
    test_interfaces, test_ips = fact_module.get_interfaces_info('ifconfig', ' -a')
    assert test_interfaces is not None


# Generated at 2022-06-20 17:50:05.562157
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class DummyModule:

        def __init__(self):
            self.params = dict(
                config='/usr/sbin/ifconfig',
                options='',
            )

        def get_bin_path(self, app):
            if app == 'netstat':
                return '/usr/sbin/netstat'
            elif app == 'uname':
                return '/usr/bin/uname'
            elif app == 'entstat':
                return '/usr/bin/entstat'
            elif app == 'lsattr':
                return '/usr/sbin/lsattr'
            else:
                return ''


# Generated at 2022-06-20 17:50:09.052572
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.base import NetworkCollector
    module = NetworkCollector._create_module()
    n = AIXNetwork(module)
    assert n.platform == 'AIX'


# Generated at 2022-06-20 17:50:17.136218
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    expected = {'v4': {'interface': 'en0', 'gateway': '10.0.1.1'}, 'v6': {}}
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=None, type='list')
        )
    )
    net = AIXNetwork(module)

    actual = net.get_default_interfaces('/tmp/test/netstat')
    assert actual == expected

# Generated at 2022-06-20 17:50:27.046840
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.aix import AIXNetwork
    aixifnet = AIXNetwork()

    # test with empty words
    current_if = aixifnet.parse_interface_line(list())
    assert {} == current_if

    # test with interface line from ifconfig -a
    words = 'lo0        Link encap:Local Loopback'.split()
    current_if = aixifnet.parse_interface_line(words)
    assert 'lo0' == current_if['device']
    assert 'Link' == current_if['flags']
    assert 'Local Loopback' == current_if['type']
    assert 'unknown' == current_if['macaddress']

    # test with interface line from ifconfig -a with

# Generated at 2022-06-20 17:50:29.812769
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    result = AIXNetwork.get_interfaces_info(AIXNetwork(), ifconfig_path='ifconfig', ifconfig_options='-a')
    assert result[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 17:50:41.907565
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule({})
    ansible_module.get_bin_path = MagicMock(return_value='/bin/ifconfig')

    current_if = {}
    current_if = AIXNetwork(ansible_module).parse_interface_line(['en0:'])
    assert current_if['device'] == 'en0' and not 'mtu' in current_if

    current_if = AIXNetwork(ansible_module).parse_interface_line(['en0:','flags=1e080863','mtu','1500'])
    assert current_if['device'] == 'en0' and not 'mtu' in current_if


# Load the shared fixtures used for basic network tests
from ansible.module_utils.facts.network.common.testing.units.compat.mock import patch, Magic

# Generated at 2022-06-20 17:50:48.092695
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for class AIXNetworkCollector
    """
    facts = dict()

    # Constructor for AIXNetworkCollector
    netobj = AIXNetworkCollector(module=None, facts=facts,
                                 command='/usr/sbin/ifconfig', condition='present')
    assert netobj._condition == 'present'
    assert netobj._command == '/usr/sbin/ifconfig'
    assert type(netobj) == AIXNetworkCollector
    assert netobj._fact_class == AIXNetwork
    assert netobj._platform == 'AIX'


# Generated at 2022-06-20 17:50:54.067827
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    fact_oaix = AIXNetwork()
    intf_name = 'en0'
    intf_flags = 'UP'
    test_words = [intf_name + ':', intf_flags]

    result = fact_oaix.parse_interface_line(test_words)

    assert result['device'] == intf_name
    assert result['flags'] == intf_flags

if __name__ == '__main__':
    import sys

    test_names = ['test_%s' % func for func in list(locals().keys()) if func.startswith('test_')]
    tests = list(map(lambda x: (x, getattr(sys.modules[__name__], x)), test_names))

# Generated at 2022-06-20 17:51:05.392087
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # This test is only for coverage, class and all methods are identical subclass of GenericBsdIfconfigNetwork
    aix = AIXNetwork()
    assert aix
    assert aix.platform == 'AIX'
    assert aix.get_default_interfaces('route') == (dict(gateway='', interface=''), dict(gateway='', interface=''))
    assert aix.get_interfaces_info('ifconfig', '') == (dict(), dict())

    assert aix.parse_interface_line(['en0:']) == dict(device='en0', ipv4=[], ipv6=[], type='unknown')
    assert aix.parse_options_line(['options=3<PERFORMNUD,ACCEPT_RTADV>'], {}, {}) == (None, None, None)
    assert aix.parse

# Generated at 2022-06-20 17:51:13.666260
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.aix import AIXNetwork
    class AIXNetwork_UT(AIXNetwork):
        def __init__(self):
            self.module = MagicMock()

# Generated at 2022-06-20 17:51:42.390795
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aixnetwork = AIXNetwork()
    words = ['en0:', 'flags=842<BROADCAST,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '1500', 'options=9b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,TSO4>', 'inet', '10.0.1.16', 'netmask', '0xffffff00', 'broadcast', '10.0.1.255']

    current_if = aixnetwork.parse_interface_line(words)

# Generated at 2022-06-20 17:51:44.068709
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector()._platform == 'AIX'



# Generated at 2022-06-20 17:51:46.363349
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_net = AIXNetwork()
    assert aix_net._fact_class.platform == 'AIX'


# Generated at 2022-06-20 17:51:48.486442
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Return the AIXNetworkCollector class object.
    :return: AIXNetworkCollector class object.
    """
    return AIXNetworkCollector()

# Generated at 2022-06-20 17:51:50.462715
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    interface = AIXNetwork(dict())
    assert interface.platform == 'AIX'



# Generated at 2022-06-20 17:51:59.467579
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-20 17:52:10.148566
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import os
    import tempfile
    write = tempfile.NamedTemporaryFile(mode='w', delete=False)
    os.chmod(write.name, 0o777)
    write.write('en0: flags=5e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>\n')
    write.close()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    mod_file = module.File('/sbin/ifconfig')
    module.params = {'module_path': 'test/units/module_utils/facts/network'}
   

# Generated at 2022-06-20 17:52:19.497665
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    result = dict(
        ansible_interfaces=[
            'eth0',
            'eth1',
            'lo'
        ],
        ansible_all_ipv4_addresses=[
            '10.23.133.166/24',
            '10.23.40.5/24',
            '127.0.0.1/8'
        ],
    )
    # for method get_interfaces_info result is in "net_result"
    net_result, ips = AIXNetwork.get_interfaces_info('ifconfig', '-a')

# Generated at 2022-06-20 17:52:30.428830
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Test for method parse_interface_line of class AIXNetwork
    """
    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_network = AIXNetwork(ansible_module)
    expected = dict(
        device='en0',
        ipv4 = [],
        ipv6 = [],
        flags = '',
        type = 'unknown',
        macaddress = 'unknown',
    )

# Generated at 2022-06-20 17:52:39.481053
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import sys

    def show_error():
        print("\n\nTest FAILED!!!\n\n")

    def compare_dicts(d1, d2):
        for k in d1:
            if k not in d2:
                print("Member ", k, " is missing in dict 2.\n", file=sys.stderr)
                return False
            if d1[k] != d2[k]:
                print("Member ", k, " differs: " + str(d1[k]) + " != " + str(d2[k]), file=sys.stderr)
                return False

# Generated at 2022-06-20 17:53:29.721938
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collected_facts = dict()
    net_collector = AIXNetworkCollector(dict(), collected_facts)
    assert net_collector
    assert isinstance(net_collector._fact_class, AIXNetwork)


# Generated at 2022-06-20 17:53:39.331619
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()[0]

    iface = network.parse_interface_line(['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric=1'])

# Generated at 2022-06-20 17:53:51.240309
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:53:54.137035
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = AIXNetwork(module=module)
    result = network_facts.populate()

    # show result of module execution
    print(module.exit_json(**result))


from ansible.module_utils.basic import *
main()

# Generated at 2022-06-20 17:54:03.237352
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix = AIXNetwork()
    # test no netstat
    interfaces = aix.get_default_interfaces('whatever')
    assert interfaces['v4'] == {}
    assert interfaces['v6'] == {}

    # test no defaults
    aix.module.run_command = lambda *args, **kwargs: (0, '', '')
    interfaces = aix.get_default_interfaces('whatever')
    assert  interfaces['v4'] == {}
    assert interfaces['v6'] == {}

    # test default route

# Generated at 2022-06-20 17:54:05.228576
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = NetworkCollector.collect()
    assert isinstance(facts, AIXNetwork)


# Generated at 2022-06-20 17:54:12.485454
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    net_collector = AIXNetwork(module)
    default_iface = net_collector.get_default_interfaces('/usr/sbin/route')

    assert default_iface['interface'] == 'en0'
    assert default_iface['gateway'] == '192.168.56.1'



# Generated at 2022-06-20 17:54:14.097676
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector.platform == 'AIX'

# Generated at 2022-06-20 17:54:23.754538
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    n = AIXNetwork()

    # test for line with option 'up'
    input_line = [
        "en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n",
    ]
    result = n.parse_interface_line(input_line[0].split())
    assert result['device'] == 'en0'
    assert result['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT',
                               'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN']

# Generated at 2022-06-20 17:54:27.298230
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # Check that AIXNetworkCollector class is in the collector.network['Linux'] list
    assert AIXNetworkCollector._platform in collector.network
    assert AIXNetworkCollector._platform in AIXNetworkCollector.collectors

# Generated at 2022-06-20 17:56:18.432948
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict()
    )

    ifconfig_path = '/usr/sbin/ifconfig'
    network = AIXNetwork(module=module, ifconfig_path=ifconfig_path)
    default_interface = dict(v4={}, v6={})
    default_interface['v4']['gateway'] = '192.168.255.254'
    default_interface['v4']['interface'] = 'en1'
    default_interface['v6']['gateway'] = 'fe80::224:6cff:fe3c:6c85'
    default_interface['v6']['interface'] = 'en1'

    result = network.get_default_interfaces('/usr/sbin/netstat')

    assert result == default_interface

# Unit

# Generated at 2022-06-20 17:56:26.145804
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    result = AIXNetwork().get_default_interfaces('/bin/netstat')
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)
    assert isinstance(result[0].get('gateway'), str) or result[0].get('gateway') is None
    assert isinstance(result[0].get('interface'), str) or result[0].get('interface') is None
    assert isinstance(result[1].get('gateway'), str) or result[1].get('gateway') is None
    assert isinstance(result[1].get('interface'), str) or result[1].get('interface') is None


# Unit tests for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:56:36.422544
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This is the unittest for checking the AIXNetwork.get_interfaces_info() method.
    It is checked whether the get_interfaces_info() method works with a text file
    which contains a real dump of an AIX ifconfig -a command.
    """
    # AIX ifconfig -a dump contains Unix line endings.
    # Python for Windows complains about these.
    # Python for Linux and Mac accept them without complaint.
    # Make sure that all universal newlines are converted to platform newlines.
    test_data = []
    with open('utils/ansible/module_utils/facts/network/test/test_AIXNetwork_get_interfaces_info.txt', 'r') as test_file:
        for line in test_file:
            test_data.append(line.rstrip('\r\n'))

# Generated at 2022-06-20 17:56:42.043563
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)

    ifc = AIXNetwork(mod)
    mod.exit_json(ansible_facts=dict(ansible_network_resources=ifc.get_device_facts()))



# Generated at 2022-06-20 17:56:51.091692
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os

    # Test with empty route file
    t = AIXNetwork({})
    stdout = ''
    rc = 0

    ifaces = dict(v4={'interface': 'lo0', 'gateway': '0.0.0.0'}, v6={'interface': 'lo0', 'gateway': '::1'})

    # check result of ifaces with empty route_path
    assert ifaces == t.get_default_interfaces('/tmp/')

    # check result of ifaces with route_path
    with open('/tmp/netstat_nr', 'w') as f:
        f.write(stdout)
    assert ifaces == t.get_default_interfaces('/tmp/')


# Generated at 2022-06-20 17:56:59.618578
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = {'get_bin_path': lambda string: './bin/'+string}
    test_object = AIXNetwork(test_module, {'params': {}})
    test_line = ['en0:']
    expected_result = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    test_result = test_object.parse_interface_line(test_line)
    assert test_result == expected_result, 'test result does not match expected result'

# Generated at 2022-06-20 17:57:11.968337
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module=module, warnings=[])
    # At present, we do not test the results of parsing ifconfig output.
    # In the future we may include a test file to compare against.
    assert 'device2' in network_collector.interfaces
    assert 'ipv4_addresses' in network_collector.interfaces['device2']
    assert network_collector.interfaces['device2']['ipv4_addresses'][0] == '10.1.1.1'
    assert 'ipv6_addresses' in network_collector.interfaces['device2']

# Generated at 2022-06-20 17:57:19.092550
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/sbin/' + name

        def run_command(self, args, check_rc=True):
            if args[0] == '/usr/sbin/netstat':
                if args[1] == '-nr':
                    return (0, "default 192.168.1.1 UG 0 10 en1\n" +
                               "default fe80::%en1 U 0 9 en1", "")
            return (-1, '', '')

    aixnet = AIXNetwork()
    aixnet.module = MockModule()
    ifconfig_path = '/usr/sbin/ifconfig'
    default_interface = a

# Generated at 2022-06-20 17:57:22.246195
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert isinstance(AIXNetwork(None), AIXNetwork)

# Generated at 2022-06-20 17:57:28.448245
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    test = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> mtu 1500 index 8"
    words = test.split()
    current_if = aix.parse_interface_line(words)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': {'1e080863,480': ''}, 'macaddress': 'unknown'}
