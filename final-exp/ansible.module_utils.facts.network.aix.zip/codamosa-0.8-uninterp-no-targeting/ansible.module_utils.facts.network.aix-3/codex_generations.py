

# Generated at 2022-06-20 17:49:01.191747
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'
    assert isinstance(AIXNetworkCollector._fact_class(), AIXNetwork)

# Generated at 2022-06-20 17:49:11.436041
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class Module:

        def get_bin_path(self, command):
            return '/usr/sbin/' + command

        def run_command(self, command):
            stdout = '''
                Kernel IP routing table
                Destination        Gateway            Flags Ref     Use     If  Exc  MTU  State      Route Component 
                default          192.168.122.1      UG        -        -        -    0     -     Active     Active    
                default          192.169.123.1      UG        -        -        -    0     -     Active     Active    
                default          192.170.123.1      UG        -        -        -    0     -     Active     Active    
            '''
            return (0, stdout, '')

    module = Module()
    network = AIXNetwork(module)
    expected = dict

# Generated at 2022-06-20 17:49:22.354064
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc = AIXNetwork()

    # Mock module
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # Mock function run_command

# Generated at 2022-06-20 17:49:29.266779
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Create object of class AIXNetwork
    ifc = AIXNetwork('/tmp')

    # Test for method parse_inet_line
    output = ifc.parse_inet_line(["inet", "10.0.0.1", "netmask", "0xffffff00", "broadcast", "10.0.0.255"],
                                 {"ipv4": []}, {})
    assert output == (
        {'ipv4': [{'address': '10.0.0.1', 'broadcast': '10.0.0.255', 'netmask': '255.255.255.0'}]},
        {})

# Generated at 2022-06-20 17:49:38.009364
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    facts = {'module_setup': True}

    m = AIXNetwork(module=None, collected_facts=facts,
                   options=None)
    result = m.populate()
    assert result['default_ipv4_interface'] == 'en0'
    assert result['default_ipv4_gateway'] == '10.176.184.1'
    assert result['default_ipv6_interface'] == 'en0'
    assert result['default_ipv6_gateway'] == 'fe80::a00:27ff:fe3d:ed0f'

# Generated at 2022-06-20 17:49:47.871321
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestModule:
        def get_bin_path(self, module):
            return '/usr/bin/{0}'.format(module)


# Generated at 2022-06-20 17:49:59.330246
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create a fake module
    config = dict(default_ipv4=dict(interface=None))
    module = dict(params=config)

    # Create a fake ansible module to be able to
    # run the code.
    # Not need to test the module.run_command(...)
    # because it is a system call
    module_mock = dict(
        get_bin_path=lambda x: '/sbin/netstat',
        run_command=lambda x: (0, None, None),
    )
    module['ansible'] = module_mock

    # Create a fake Network Collector in order to be able
    # to test the method get_default_interfaces
    # Not need to test the NetworkCollector.collect(...)
    # because it is a system call

# Generated at 2022-06-20 17:50:06.564046
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = {}
    module['run_command'] = run_command
    module['get_bin_path'] = get_bin_path
    module['ansible_facts'] = {}
    ans_ifconfig_path = '/usr/bin/ifconfig'
    ans_ifconfig_options = '-a'

    aix_network = AIXNetwork(module)
    interfaces, ips = aix_network.get_interfaces_info(ans_ifconfig_path, ans_ifconfig_options)

    print(interfaces)
    print(ips)

    print ('AIXNetwork_get_interfaces_info SUCCESSFULLY')


# Generated at 2022-06-20 17:50:11.301865
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnet = AIXNetworkCollector('aix', 'aix_ifconfig')
    assert aixnet.network_provider == 'aix'
    assert aixnet.facts_class == AIXNetwork
    assert aixnet.platform == 'AIX'


# Generated at 2022-06-20 17:50:14.821706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    o = AIXNetworkCollector()
    assert o is not None
    assert o._fact_class.platform == 'AIX'
    assert o._platform == 'AIX'
    assert o._fact_class.ifconfig_path is None


# Generated at 2022-06-20 17:50:33.214716
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    w = ['em1:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>', 'inmtu=1500', 'index=0x100001', 'mtu=1500', 'address=00:21:28:44:f0:c9', 'media:Ethernet', 'autoselect', '(100baseTX<full-duplex>)' ]
    result = AIXNetwork().parse_interface_line(w)

# Generated at 2022-06-20 17:50:44.069326
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test get_default_interfaces method of AIXNetwork class.
    """
    def mock_run_command(params):
        """
        Mocks run_command method of module UtilityModuleSite.
        """

# Generated at 2022-06-20 17:50:53.791369
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import json
    import types

    module = types.ModuleType('ansible_module_network_AIX')
    module.exit_json = lambda x: x
    module.get_bin_path = lambda x: "/usr/sbin/{0}".format(x)

    aix = AIXNetwork(module)

    assert aix.parse_interface_line(["eth0", "flags=5<UP,BROADCAST,RUNNING,MULTICAST>"]) == \
           {'device': 'eth0',
            'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'],
            'ipv4': [],
            'ipv6': [],
            'macaddress': 'unknown',
            'type': 'unknown'}

# Generated at 2022-06-20 17:50:56.226153
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIX Network Constructor"""
    fact = AIXNetwork()
    assert fact.platform == 'AIX'

# Generated at 2022-06-20 17:51:00.875193
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os

    if not os.path.isfile("/proc/net/route"):
        return False

    if not os.access("/proc/net/route", os.R_OK):
        return False

    return AIXNetwork.get_default_interfaces("/proc/net/route")


# Generated at 2022-06-20 17:51:11.014010
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ test_AIXNetwork_get_interfaces_info """
    ansible_module = MockAnsibleModule()

# Generated at 2022-06-20 17:51:13.687611
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    default = AIXNetwork(dict(module=None)).get_default_interfaces('route_path')
    assert default == ('', '')

# Generated at 2022-06-20 17:51:24.760709
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    m_module = MockModule()

# Generated at 2022-06-20 17:51:32.933990
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Run get_interfaces_info on "sample" input
    """
    module = AnsibleModule(argument_spec={})
    cc = AIXNetwork(module=module)
    interfaces, ips = cc.get_interfaces_info(ifconfig_path='/bin/ifconfig', ifconfig_options='-a')

    # test the result
    assert 'lo0' in interfaces and interfaces['lo0']['mtu'] == '65536'

    # remove unwanted variable
    del cc
    return
# end of test_AIXNetwork_get_interfaces_info()



# Generated at 2022-06-20 17:51:39.996541
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    def execute_module(module_args):
        module = AnsibleModule(
            argument_spec=module_args,
        )
        result = AIXNetwork.get_default_interfaces(module)
        module.exit_json(ansible_facts=dict(network=result))
        return module.params['ansible_facts']['network']['default_interface']

    module_args = dict(
        route_path='/usr/bin/netstat'
    )

    with open('/tmp/nexus-7010-A', 'r') as f:
        out = f.read()

    def mocked_run_command(command, check_rc=True):
        return 0, out, ''


# Generated at 2022-06-20 17:52:13.418316
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    nm = AIXNetwork(module)
    nm.get_default_interfaces('')
    nm.get_interfaces_info("", "")
    nm.parse_interface_line(["1:"])
    nm.parse_options_line(["options="], {}, {})
    nm.parse_nd6_line(["nd6"], {}, {})
    nm.parse_ether_line(["ether"], {}, {})
    nm.parse_media_line(["media:"], {}, {})
    nm.parse_status_line(["status:"], {}, {})
    nm.parse_lladdr_line(["lladdr"], {}, {})

# Generated at 2022-06-20 17:52:17.992047
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of the class AIXNetwork
    """

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = AIXNetwork(module)
    network_collector.get_default_interfaces('/usr/sbin/netstat')



# Generated at 2022-06-20 17:52:22.555280
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    handler = AIXNetwork()
    result = handler.get_default_interfaces('/sbin/route')
    print(result)
    if not result == (None, None):
        assert result[0]['interface'] == 'en0'
        assert result[0]['gateway'] == '10.10.10.1'


# Generated at 2022-06-20 17:52:26.625255
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor testing
    """
    module = AnsibleModuleMock()
    # net_collector = AIXNetworkCollector(module)
    net_collector = AnsibleNetworkCollector(module)

    # net_collector = AIXNetworkCollector(module)
    assert net_collector.platform == 'AIX'
    assert net_collector.get_network_collector() == AIXNetworkCollector

# ifconfig should be called by constructor

# Generated at 2022-06-20 17:52:35.707221
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    import os

    module = AnsibleModule(argument_spec={})

    # test parsing of interface info
    m = AIXNetwork(module)

    facts = {'ansible_os_family': 'AIX'}
    fake_path = os.path.join(os.path.dirname(__file__), 'fake_aix_output')

    # fake ifconfig output
    interfaces, ips = m.get_interfaces_info(fake_path)

    # each interface must have an IP address
    for name in interfaces:
        if len(interfaces[name]['ipv4']) == 0:
            assert False, "IP address not found"
        if len(interfaces[name]['ipv6']) == 0:
            assert False, "IPv6 address not found"


# Generated at 2022-06-20 17:52:37.901122
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'


# Generated at 2022-06-20 17:52:48.653398
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os

    if not os.path.exists('/etc/ansible/facts.d/'):
        os.makedirs('/etc/ansible/facts.d/')

    input_file = open('test_AIXNetwork_get_interfaces_info.input', 'r')
    out = input_file.read()

    rc = 0
    err = ''

    ifconfig_path = ''
    ifconfig_options = ''

    interfaces = {}
    ips = {}

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    aix_network = AIXNetwork()

    interfaces, ips

# Generated at 2022-06-20 17:52:53.396183
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnet = AIXNetwork()
    assert aixnet.get_default_interfaces('') == (
        {'gateway': '10.10.0.1', 'interface': 'ent1'},
        {'gateway': '2001:4898:d300:0:fff:fff:fff:1', 'interface': 'ent1'}
    )

# Generated at 2022-06-20 17:53:00.445708
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    my_module = AnsibleModule(argument_spec={})
    my_obj = AIXNetwork(module=my_module)
    my_ifconfig_path = "/usr/sbin/ifconfig"
    my_ifconfig_options = "-a"
    my_interfaces, my_ips = my_obj.get_interfaces_info(my_ifconfig_path, my_ifconfig_options)
    my_firstinterface_keys = sorted(my_interfaces.keys())[0]
    my_firstinterface_firstipv4_keys = sorted(my_interfaces[my_firstinterface_keys]['ipv4'][0].keys())
    my_firstinterface_firstipv6_keys = sorted(my_interfaces[my_firstinterface_keys]['ipv6'][0].keys())
    assert my_first

# Generated at 2022-06-20 17:53:00.964256
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork()

# Generated at 2022-06-20 17:53:59.262720
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        pass
    module = MockModule()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/sbin/ifconfig'
    network = AIXNetwork()
    network.module = module
    (interfaces, ips) = network.get_interfaces_info('/sbin/ifconfig', ifconfig_options='-a')

# Generated at 2022-06-20 17:54:05.692161
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    new_module = NetworkCollector._create_module()
    platform_facts = AIXNetwork(new_module).populate()
    assert platform_facts['default_ipv4']['gateway'] == '192.168.122.1'
    assert platform_facts['default_ipv4']['interface'] == 'en0'
    assert platform_facts['default_ipv6']['gateway'] == 'fe80::200:5eff:fe00:0'
    assert platform_facts['default_ipv6']['interface'] == 'en0'

# Generated at 2022-06-20 17:54:15.382459
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import os
    import tempfile
    import textwrap

    # If a script is not run in the context of running a playbook or a role,
    # the module_msg_handler won't be available, so use print instead.
    # Unfortunately, there's no good way to inform the user that the result
    # may be incorrect because of this.

# Generated at 2022-06-20 17:54:18.633812
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnet_collector = AIXNetworkCollector()
    assert aixnet_collector.platform == 'AIX'
    assert aixnet_collector._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:54:26.987301
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_module = AIXNetwork()

    # in variable out_ifconfig_a save output of ifconfig -a command

# Generated at 2022-06-20 17:54:29.417145
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network = AIXNetwork(None)
    assert network.platform == 'AIX'


# Generated at 2022-06-20 17:54:39.680534
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # call constructor of AIXNetwork
    obj = AIXNetwork()

    # On AIX, platform attribute must be "AIX"
    assert obj.platform == 'AIX'

    # On AIX, platform_word attribute must be "AIX"
    assert obj.platform_word == 'AIX'

    # On AIX, _platform attribute must be "AIX"
    assert obj._platform == 'AIX'

    # On AIX, ifconfig_path attribute must be absolute path
    uname_rc = None
    uname_out = None
    uname_err = None
    uname_path = obj.module.get_bin_path('uname')

# Generated at 2022-06-20 17:54:43.257133
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert(issubclass(AIXNetworkCollector, NetworkCollector))
    assert(AIXNetworkCollector._platform == 'AIX')
    assert(AIXNetworkCollector._fact_class == AIXNetwork)

# Generated at 2022-06-20 17:54:54.411107
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    result = AIXNetwork._parse_interface_line(AIXNetwork, ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '127.0.0.1', 'netmask', '0xff000000'])

# Generated at 2022-06-20 17:55:03.509385
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This is a unit test for method `get_default_interfaces` of class `AIXNetwork`.
    """
    # mock, a helper class to create easily mock objects and make assertions.
    class Mock(object):
        pass

    module = Mock()
    module.run_command = lambda command: (None, 'default 10.1.1.1 UG 1 0 en0', '')

    aix_network = AIXNetwork(module)
    interface_v4, interface_v6 = aix_network.get_default_interfaces({})

    assert interface_v4 == {'gateway': '10.1.1.1', 'interface': 'en0'}
    assert interface_v6 == {}


# Generated at 2022-06-20 17:56:54.459974
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # TODO: implement
    pass

# Generated at 2022-06-20 17:57:05.737692
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'.split(',')
    words2 = 'lo0: flags=e08084b,c0<UP,BROADCAST,LOOPBACK,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,LARGESEND,CHAIN>'.split(',')
    cif = AIXNetwork()
    cif_result1 = cif.parse_interface_line(words)
    cif_result2 = cif.parse_interface_line(words2)

    assert cif_result1['device'] == 'en0'
    assert c

# Generated at 2022-06-20 17:57:16.269090
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import re
    import unittest
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.aix.aix import AIXNetwork


# Generated at 2022-06-20 17:57:22.271727
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    test_words = ['en0:', 'flags=1e080863,480', 'inet', '9999::9999:9999:9999', ',ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff', 'prefixlen', '128', 'inet6', '1.2.3.4', 'prefixlen', '64', 'inet6', 'fe80::ffff:ffff:ffff:ffff%lo0', 'prefixlen', '64', 'scopeid', '0x10', 'nd6', 'options=1', '(permanent)', 'media:', 'Ethernet', '1000BaseTX', 'status:', 'active']

# Generated at 2022-06-20 17:57:24.256319
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)

# Generated at 2022-06-20 17:57:31.847852
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    inet = AIXNetwork(module)
    words = ['en0:', 'flags=1e080863,']
    expected_dict = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT'], 'macaddress': 'unknown'}
    result = inet.parse_interface_line(words)
    assert result == expected_dict, "parse_interface_line() returned '%s', expected: '%s'" % (result, expected_dict)

# Generated at 2022-06-20 17:57:37.087716
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of AIXNetworkCollector
    """
    # Test no options
    aix_net = AIXNetworkCollector()

    # Test with options
    aix_net = AIXNetworkCollector(options=dict(gather_subset='!all,!min'))

# Generated at 2022-06-20 17:57:43.474568
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    assert issubclass(AIXNetwork, GenericBsdIfconfigNetwork)
    assert issubclass(AIXNetwork, Network)


# Generated at 2022-06-20 17:57:50.801361
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ansible_module_mock = Mock()
    ansible_module_mock.get_bin_path.side_effect = lambda path: path

# Generated at 2022-06-20 17:57:56.783533
# Unit test for method get_default_interfaces of class AIXNetwork