

# Generated at 2022-06-20 17:49:00.855553
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert 'AIX' == AIXNetworkCollector().platform
    assert AIXNetwork == AIXNetworkCollector().fact_class

collector = AIXNetworkCollector()

# Generated at 2022-06-20 17:49:11.225538
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    fake_module = type("AnsibleModule", (object,), {
        "params": {"gather_subset": ["all"]},
        "get_bin_path": lambda self, x: x,
    })()

    fake_module.exit_json = lambda a: a

    AIX_Network = AIXNetwork(fake_module)
    interfaces, ips = AIX_Network.get_interfaces_info(AIX_Network.ifconfig_path, AIX_Network.ifconfig_options)

    # AIX_Network.parse_interface_line(AIX_Network.get_interfaces_info(AIX_Network.ifconfig_path, AIX_Network.ifconfig_options)[0])

    facts = AIX_Network.populate()


# Generated at 2022-06-20 17:49:15.285912
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor unit test for class AIXNetworkCollector
    """
    net_AIX = AIXNetworkCollector(None, None, None)
    assert net_AIX._platform == 'AIX'
    assert net_AIX._fact_class == AIXNetwork

# Generated at 2022-06-20 17:49:25.530612
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:49:37.414579
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    test_ansible_module = AnsibleModule(argument_spec=dict())
    test_network = AIXNetwork(test_ansible_module)

    # test with empty line
    test_words = ''
    test_result = dict(device=None, ipv4=[], ipv6=[], type='unknown')
    test_result['flags'] = test_network.get_options('')
    assert test_result == test_network.parse_interface_line(test_words)

    # test with line with correct number of words

# Generated at 2022-06-20 17:49:47.180948
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """ Unit test for the AIXNetwork parse interface line method """

    module = AnsibleModule(argument_spec={})
    nc = AIXNetwork()


# Generated at 2022-06-20 17:49:53.087177
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    ifconfig_path = module.get_bin_path('ifconfig')

    # Out of netstat (run with command -r) and ifconfig -a run, create test case
    netstat_path = module.get_bin_path('netstat')
    if netstat_path:
        rc, out, err = module.run_command([netstat_path, '-nr'])
        if rc != 0:
            module.fail_json(msg='netstat -r command failed')

        lines = out.splitlines()
        for line in lines:
            words = line.split()
            if len(words) > 1 and words[0] == 'default' and words[5] != 'lo0':
                default_ifname = words

# Generated at 2022-06-20 17:49:55.711024
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_collector = AIXNetworkCollector()
    assert my_collector._fact_class is AIXNetwork
    assert my_collector._platform is 'AIX'

# Generated at 2022-06-20 17:49:56.733555
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-20 17:50:04.509596
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This test method uses the sample ifconfig output to unit test
    the method AIXNetwork.get_interfaces_info()
    """
    module = MockModule()
    module.run_command.return_value = (0, ifconfig_out, None)
    module.get_bin_path.return_value = '/sbin/ifconfig'

    aix = AIXNetwork(module=module)
    interfaces = aix._interfaces

    assert interfaces is not None
    assert 'en0' in interfaces
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['macaddress'] == 'unknown'



# Generated at 2022-06-20 17:50:26.820563
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-20 17:50:33.234858
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en3:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>',
             'metric=1', 'mtu=1500', 'inet=10.2.2.50', 'netmask=255.255.255.255', 'broadcast=10.2.2.50',
             'tcp_sendspace=65536', 'tcp_recvspace=65536', 'nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV>']

# Generated at 2022-06-20 17:50:42.882001
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    test_network = AIXNetwork(module)
    interfaces = test_network.get_default_interfaces('netstat')

    # interfaces returned by AIXNetwork.get_default_interfaces() is a tuple
    assert len(interfaces) == 2

    # Check if the number of keys of each interface is correct
    for interface in interfaces:
        assert len(interface) == 2
        assert 'gateway' in interface
        assert 'interface' in interface

    # Check if interface 'en0' has the proper gateway
    assert interfaces[0]['gateway'] == '192.168.21.254'
    assert interfaces[0]['interface'] == 'en0'

# Generated at 2022-06-20 17:50:43.792112
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = None
    AIXNetwork(module)

# Generated at 2022-06-20 17:50:53.265495
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # create AIXNetwork object (dummy module)
    m = dict(
        params=dict(
            gather_subset=['all']
        )
    )
    a = AIXNetwork(m)

    # test interface line
    words = ['en0:', 'flags=8a63', 'metric', '0', 'mtu', '1500', 'options=69b', 'inet', '10.0.0.1',
             'netmask', '0xfffffc00', 'broadcast', '10.0.0.255', 'ether', '69:4c:dc:52:c6:41']

    current_if = a.parse_interface_line(words)

    assert current_if['device'] == 'en0'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-20 17:51:04.622251
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is used for unit test of AIXNetworkCollector class.
    """
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    import ansible.module_utils.facts.network.aix as aix


# Generated at 2022-06-20 17:51:07.892960
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'


# Generated at 2022-06-20 17:51:14.745174
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # create instance of class AIXNetwork
    my_AIXNetwork = AIXNetwork()

    # simulate a line from 'ifconfig -a' command
    line = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()

    # call method to test
    current_if = my_AIXNetwork.parse_interface_line(words)

    # test output for expected values
    assert current_if['device'] == words[0][0:-1]
    assert current_if['flags'] == words[1]
    assert current_if['ipv4'] == []
    assert current_if['ipv6']

# Generated at 2022-06-20 17:51:23.842162
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Tests `_get_default_interfaces` of AIXNetwork class.
    """
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['default_ipv4', 'default_ipv6']
    network_fact = AIXNetwork(module)
    default_interfaces = network_fact.get_default_interfaces('/tmp/does-not-exist')
    assert default_interfaces == ({'gateway': '192.168.56.3', 'interface': 'en0'}, {'gateway': 'fe80::20c:29ff:fe6a:8609%en0', 'interface': 'en0'})

# Generated at 2022-06-20 17:51:34.146901
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    import tempfile
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Create test file
    tftmpd = tempfile.mkdtemp()
    tftmpf = tempfile.NamedTemporaryFile(dir=tftmpd)

# Generated at 2022-06-20 17:52:09.030689
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # None
    words = None
    ifconfig = AIXNetwork()
    assert ifconfig.parse_interface_line(words) == {}

    # Empty string list
    words = []
    ifconfig = AIXNetwork()
    assert ifconfig.parse_interface_line(words) == {}

    # List word not ending with colon
    words = ['en0']
    ifconfig = AIXNetwork()
    assert ifconfig.parse_interface_line(words) == {}

    # List word ending with colon (bare minimum for this method)
    words = ['en0:']
    ifconfig = AIXNetwork()

# Generated at 2022-06-20 17:52:18.728221
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:52:21.695048
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj
    assert isinstance(obj, NetworkCollector)
    assert obj.platform == 'AIX'


# Generated at 2022-06-20 17:52:28.180611
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This is the test for method get_default_interfaces of class AIXNetwork.
    """
    # Create an instance of AIXNetwork
    n = AIXNetwork()

    # create a variable netstat out with the data returned by netstat -nr

# Generated at 2022-06-20 17:52:36.580578
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    an = AIXNetwork()

    # test case 1: normal case
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>']
    current_if = an.parse_interface_line(words)
    assert current_if['device'] == 'en0'

# Generated at 2022-06-20 17:52:47.572432
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:52:56.609172
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork1 = AIXNetwork()
    words = ['en0:', 'flags=8a63<UP,BROADCAST,NOTRAILERS,RUNNING,ALLMULTI,SIMPLEX,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>', 'mtu', '1500']

# Generated at 2022-06-20 17:53:02.868776
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.bin_path = dict()
            self.run_command = dict()

        def get_bin_path(self, arg, *args, **kwargs):
            return self.bin_path[arg]

        def run_command(self, cmd, *args, **kwargs):
            return self.run_command[cmd]

    aixnet = AIXNetwork(MockModule())

    # Test the case where "ifconfig -a" output is empty.
    mock_module = MockModule()
    mock_module.run_command = dict(cmd=dict(rc=0, out='', err=''))
    aixnet.module = mock_module
    interfaces, ips = aixnet.get_interfaces_info

# Generated at 2022-06-20 17:53:13.527797
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class AIXNetwork
    According to method get_interfaces_info of class AIXNetwork,
    method parse_interface_line of class AIXNetwork 
    is used to parse the interface line from ifconfig output.
    """

    my_AIXNetwork = AIXNetwork()

    # Test case 1: interface line

# Generated at 2022-06-20 17:53:19.441371
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    tst = AIXNetwork({})
    current_if = tst.parse_interface_line(('en0:', 'flags=1e080863,'))
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == {'broadcast': True, 'up': True, 'multicast': True}
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert 'mtu' not in current_if


# Generated at 2022-06-20 17:54:11.629593
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork

    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork



# Generated at 2022-06-20 17:54:17.685797
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:54:20.577167
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Create object of class AIXNetworkCollector"""
    module = None
    network_class = AIXNetworkCollector(module)
    assert isinstance(network_class, AIXNetworkCollector)


# Generated at 2022-06-20 17:54:25.309130
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()
    words = ['ent0:', 'flags=8843<UP>', 'mtu', '1500', 'index']

    current_if = network.parse_interface_line(words)

    assert current_if['device'] == 'ent0'
    assert current_if['type'] == 'unknown'
    assert current_if['flags'] == ['UP']
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:54:27.136083
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Test creation of AIXNetworkCollector instance"""

    try:
        AIXNetworkCollector()
    except Exception:
        assert False, 'AIXNetworkCollector class cannot be instantiated'

# Generated at 2022-06-20 17:54:33.359316
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert str(network_collector._fact_class).find('AIXNetwork') != -1
    assert network_collector._fact_class.platform == 'AIX'


# Generated at 2022-06-20 17:54:42.797837
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={})
    module.params = dict(
        gather_subset='!all',
        gather_network_resources='no')
    AIXNetwork = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')

    (interfaces, ips) = AIXNetwork.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'Loopback'
    assert interfaces['lo0']['active'] == True
    assert interfaces['lo0']['macaddress'] == 'unknown'

    assert 'en0' in interfaces

    assert interfaces['en0']['device'] == 'en0'

# Generated at 2022-06-20 17:54:53.124677
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():  # pylint: disable=too-many-locals
    """Unit test for constructor of class AIXNetwork"""

    from ansible.module_utils.facts.utils import get_file_content

    # test for 'ifconfig -a'
    filename = '/etc/ansible/facts.d/aix_the_hard_way.fact'
    content = get_file_content(filename)
    aix = AIXNetwork(content=content, debug=True)     # pylint: disable=undefined-variable
    aix_interfaces, aix_ips = aix.populate()     # pylint: disable=unused-variable

    assert len(aix_interfaces) == 12, 'check number of interfaces'

# Generated at 2022-06-20 17:55:03.125683
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = '/usr/bin/netstat'
    testAIXNetwork = AIXNetwork(route_path=route_path)

    fake_route_path = '/bin/fake_route'
    fakeTestAIXNetwork = AIXNetwork(route_path=fake_route_path)


# Generated at 2022-06-20 17:55:13.269330
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = AIXNetwork(dict())
    words = ['en0:', 'flags=', '842<UP,BROADCAST>', 'metric', '0',
             'mtu', '1500', 'options', '=', '3<RXCSUM,TXCSUM>', 'ether',
             '8:0:27:59:e6:82']

    current_if = m.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '<UP,BROADCAST>'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['mtu'] == '1500'
    assert not current_if['options']

# Generated at 2022-06-20 17:57:14.483732
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # This is a test of the AIXNetwork.parse_interface_line
    # method.  It will verify that the method gets the
    # correct value of dict keys even when the same
    # dict keys are used in both branches.
    my_mock_module = MockModule()
    my_network = AIXNetwork(my_mock_module)

    # Test 1: First test the 'current_if' variable holds
    # an empty dictionary.
    my_mock_module.params = {'gather_subset': '!all'}
    my_mock_module.fail_json.called = False
    my_mock_module.fail_json.side_effect = None

    # This is the list passed to parse_interface_line.
    # It is the line that begins the 'if' condition
    # at the beginning

# Generated at 2022-06-20 17:57:17.243590
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    collector = AIXNetworkCollector()
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-20 17:57:28.657505
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    test_line = [b'en1:', b'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', b'index=2']
    if_dict = test_object.parse_interface_line(test_line)
    print(if_dict)
    assert if_dict['device'] == 'en1'
    assert if_dict['type'] == 'unknown'
    assert if_dict['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:57:39.139839
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # init
    current_if = dict()

    # test data
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>', 'inet', '192.168.56.9', 'netmask', '0xffffff00', 'broadcast', '192.168.56.255']

    # run method
    current_if = AIXNetwork.parse_interface_line(None, words)

    # compare results
    assert current_if['device'] == 'en0'

# Generated at 2022-06-20 17:57:48.094904
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc = AIXNetwork()


# Generated at 2022-06-20 17:57:54.147861
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.exit_json = exit_json
    ansible_module.fail_json = fail_json
    ansible_module.run_command = run_command

    network = AIXNetwork(ansible_module)

    # for checking garbage
    line = 'a word line'
    words = line.split()
    current_if = network.parse_interface_line(line=words)
    assert current_if['device'] == 'word'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
    assert current_if['flags'] == []
    assert current_if['macaddress'] == 'unknown'

    # for checking real interface line
   

# Generated at 2022-06-20 17:57:55.557189
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-20 17:57:57.264908
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert NetworkCollector._platform == 'Network'
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-20 17:58:09.216183
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import object
    aix_network = object.__new__(AIXNetwork)
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '192.168.122.211', 'netmask', '0xffffff00', 'broadcast', '192.168.122.255']
    current_if = aix_network.parse_interface_line(words)
    assert 'en0' == current_if['device']
    assert 'unknown' == current_if['macaddress']

# Generated at 2022-06-20 17:58:21.858853
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModuleMock()
    ansible_module.run_command = run_command_mock
    ansible_module.get_bin_path = get_bin_path_mock
    aixnetwork = AIXNetwork(ansible_module)
    words = ['lo0:', 'flags=8005<UP,LOOPBACK,RUNNING>', 'mtu=65536']
    interface_line = aixnetwork.parse_interface_line(words)
    interface_line_expect = {'device': 'lo0', 'macaddress': 'unknown', 'mtu': '65536', 'flags': [u'UP', u'LOOPBACK', u'RUNNING'], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert interface_line == interface_