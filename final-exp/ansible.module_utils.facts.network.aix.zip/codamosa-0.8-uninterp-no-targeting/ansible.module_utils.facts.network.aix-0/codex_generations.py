

# Generated at 2022-06-20 17:49:09.729494
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_net = AIXNetwork()
    assert aix_net.parse_interface_line(['lo0:', 'UP', 'LOOPBACK', 'RUNNING', 'AUTO', '-', 'inet', '127.0.0.1', 'netmask', '0xff000000']) == \
           {'device': 'lo0',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown',
            'flags': aix_net.get_options('UP'),
            'macaddress': 'unknown'}

# Generated at 2022-06-20 17:49:11.901907
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test AIXNetworkCollector constructor
    """
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-20 17:49:14.140027
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:49:24.522756
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    f = AIXNetwork({})
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    # define a mocked module
    class MockModule:

        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.bin_path

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if args[0] == ifconfig_path:
                if 'inet' in args:
                    ifconfig_options = '-a'
                elif 'inet6' in args:
                    ifconfig_options = '-aIN'
                rc = 0

# Generated at 2022-06-20 17:49:31.991635
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    network = AIXNetwork()
    ifconfig_path = network.module.get_bin_path('ifconfig')
    test_cases = [
        ['ifconfig_path', 'ifconfig_options', 'result'],
        [r'/usr/sbin/ifconfig', '-a', [{'device': 'ent1', 'macaddress': 'unknown', 'type': 'unknown', 'flags': set(['BROADCAST', 'MULTICAST', 'SIMPLEX', 'UP', 'RUNNING']), 'ipv4': [], 'ipv6': []}], [{'all_ipv4_addresses': [], 'all_ipv6_addresses': []}]]
    ]
    from ansible.module_utils.facts.network.aix import AIXNetwork

# Generated at 2022-06-20 17:49:41.558623
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-20 17:49:50.194456
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    args = {
        'route_path': 'route',
    }
    network = AIXNetworkCollector(None, args, None)

    # test execution
    out_true = {
            'v4': {
                'gateway': '10.1.3.1',
                'interface': 'en0'
            },
            'v6': {
                'gateway': 'fe80::250:56ff:fe84:ca1e',
                'interface': 'en0'
            }
    }
    out = network.get_default_interfaces(args['route_path'])
    assert out == out_true, 'Default Interface test failed'

if __name__ == '__main__':
    test_AIXNetwork_get_default_interfaces()

# Generated at 2022-06-20 17:50:00.205698
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Create a test resource for module
    try:
        from ansible.module_utils.facts.network.generic_bsd import AnsibleModule
        module = AnsibleModule(argument_spec={})
    except ImportError:
        module = None

    # Create test object
    obj = AIXNetwork(module)

    # Get some variables from config file if available
    route_path = obj.module.get_bin_path('route')

    # Test default_interfaces
    default_interfaces_v4, default_interfaces_v6 = obj.get_default_interfaces(route_path)
    assert '192.168.1.1' == default_interfaces_v4.get('gateway')
    assert 'en0' == default_interfaces_v4.get('interface')

# Generated at 2022-06-20 17:50:04.637007
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    def run_module():
        module_args = dict(
            gather_subset=['!all', '!min'],
            route=dict(
                path='/usr/sbin/netstat',
            ),
        )

        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True,
        )

        # this netstat works for AIX 7.2

# Generated at 2022-06-20 17:50:11.889610
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_module = AnsibleModuleMock()
    my_module.run_command = run_command_mock
    my_module.get_bin_path = get_bin_path_mock
    my_module.params = {}
    AIXNet = AIXNetworkCollector(my_module)
    assert AIXNet._fact_class.platform == 'AIX'
    assert AIXNet._platform == 'AIX'



# Generated at 2022-06-20 17:50:31.269396
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ifc = AIXNetwork(module)

    # input
    words = ['en0:', 'flags=1e080863', 'mtu', '1500', 'inet', '192.168.88.34', 'netmask', '0xffffff00', 'broadcast', '192.168.88.255']

    # expected output
    device = 'en0'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = ifc.get_options(words[1])
    current_if['macaddress'] = 'unknown'    # will be overwritten later

    # get output
    out = ifc.parse_interface_line(words)

    # compare output

# Generated at 2022-06-20 17:50:42.839533
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestModule:
        def __init__(self, test_data):
            self.params = test_data

        def get_bin_path(self, arg1, *args, **kwargs):
            return test_data['bin_path']

        def run_command(self, arg1, *args, **kwargs):
            return test_data['rc'], test_data['out'], test_data['err']

    test_data = {
        'bin_path': '/usr/bin',
        'rc': 0,
        'out': """
default 192.168.178.1 UG     0 2     e1000g0
default fe80::a00:27ff:fecd:13d9 UG    0   2 e1000g1
            """,
        'err': ''
    }
    test_module = Test

# Generated at 2022-06-20 17:50:44.770860
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork({}, [])
    aix_network.get_default_interfaces('netstat')



# Generated at 2022-06-20 17:50:48.458765
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

    # check if platform is AIX
    assert aix_network_collector.platform == 'AIX'

    # check if fact_class is AIXNetworkCollector
    assert aix_network_collector.fact_class == AIXNetwork

# Generated at 2022-06-20 17:50:51.349890
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'


# Generated at 2022-06-20 17:50:53.345297
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork().platform == 'AIX'


# Generated at 2022-06-20 17:51:04.711422
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')),
        supports_check_mode=True)

    # AIXNetwork is a subclass of GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    net_gen_bsd = GenericBsdIfconfigNetwork(module)
    assert isinstance(net_gen_bsd, GenericBsdIfconfigNetwork), \
        "net_gen_bsd must be an instance of GenericBsdIfconfigNetwork"

    net_ifconfig = AIXNetwork(module)
    assert isinstance(net_ifconfig, AIXNetwork), \
        "net_ifconfig must be an instance of AIXNetwork"



# Generated at 2022-06-20 17:51:08.321876
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    networkCollector = AIXNetworkCollector()
    assert networkCollector.__dict__ == {
        '_fact_class': AIXNetwork,
        '_platform': 'AIX'
    }

# Generated at 2022-06-20 17:51:19.898819
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class AIXNetwork
    """
    network = AIXNetwork()
    words = ["en0:", "flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500"]
    ifc = network.parse_interface_line(words)
    assert ifc['device'] == "en0"
    assert ifc['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']
    assert ifc['macaddress'] == 'unknown'
    assert ifc['type'] == 'unknown'



# Generated at 2022-06-20 17:51:26.466406
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not os.path.exists('/etc/hosts'):
        module.fail_json(rc=256, msg='/etc/hosts does not exist')
    obj = AIXNetwork(module=module)
    interfaces, ips = obj.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    print(interfaces)
    print(ips)


# Generated at 2022-06-20 17:51:57.079664
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.generic_bsd import IfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    test_obj = AIXNetwork()

# Generated at 2022-06-20 17:52:08.211462
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_mock = Mock()
    module_mock.get_bin_path.side_effect = lambda x: '/bin/' + x

# Generated at 2022-06-20 17:52:10.858203
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    aixnetworkcollector = AIXNetworkCollector()


# Generated at 2022-06-20 17:52:13.086271
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-20 17:52:22.000228
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    uname_path = '/usr/bin/uname'
    uname_rc = 0
    uname_out = '0'
    uname_err = ''

    network_ins = AIXNetwork()


# Generated at 2022-06-20 17:52:23.654055
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod = AnsibleModule(arg_spec=dict())
    w = AIXNetworkCollector(module=mod)
    assert w.platform == 'AIX'

# Generated at 2022-06-20 17:52:34.278613
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    line = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()
    current_if = aix_network.parse_interface_line(words)

    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['1e084863', '480']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-20 17:52:40.976645
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    os = AIXNetwork()
    words = ['eth0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>', 'metric=1']
    os.parse_interface_line(words)

# Generated at 2022-06-20 17:52:50.838263
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import copy

    assert AIXNetwork.get_interfaces_info('/bin/ifconfig', '/fake/ifconfig') == ({}, {})


# Generated at 2022-06-20 17:52:54.244219
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = DummyModule()

    network = AIXNetwork(module)
    interface = network.get_default_interfaces('/test_path')

    assert interface['gateway'] == '192.0.2.1'
    assert interface['interface'] == 'en0'

# Generated at 2022-06-20 17:53:47.736379
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_route_path = '/usr/bin/'
    m = AIXNetwork(module=None)
    assert m.get_default_interfaces(fake_route_path) == (dict([('interface', 'en0'), ('gateway', '192.168.1.254')]),
                                                          dict([('interface', 'en0'), ('gateway', 'fe80::5efe:192.168.1.254')]))

# Generated at 2022-06-20 17:53:51.885066
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    aix_net = AIXNetwork()
    nc = NetworkCollector(aix_net)
    out = nc.get_interfaces_info('ifconfig')
    print(out)

# Generated at 2022-06-20 17:53:53.225460
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    AIXNetwork.get_default_interfaces(None, '/usr/sbin/route')

# Generated at 2022-06-20 17:54:02.860843
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    aix_network = AIXNetwork(module)
    (interfaces, ips) = aix_network.get_interfaces_info()

    assert interfaces is not {}
    assert 'en0' in interfaces
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['macaddress'] != 'unknown'
    assert interfaces['en0']['flags'] != []
    assert interfaces['en0']['mtu'] != ''

    assert ips is not {}
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

# Generated at 2022-06-20 17:54:04.296531
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:54:11.403021
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    The constructor of class AIXNetwork should be tested
    """

    module = dict(
        get_bin_path=lambda x: '/bin/' + x,
        run_command=lambda x: (0, 'stdout', 'stderr'),
    )

    network = AIXNetwork(module)
    assert network.platform == 'AIX'

    # assert with default parameters:
    assert network.get_interfaces_info('/bin/ifconfig') == ([], [])



# Generated at 2022-06-20 17:54:17.989577
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0', 'flags=842<UP,BROADCAST,RUNNING,MULTICAST>', 'metric:1']
    aixn = AIXNetwork()
    result = aixn.parse_interface_line(words)
    assert result['device'] == 'en0'
    assert result['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:54:26.507904
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.exit_json = None
            self.run_commands = {}

        def run_command(self, args):
            for (cmd, rc), out, err in self.run_commands[args]:
                return rc, out, err

        def get_bin_path(self, arg):
            return self.bin_path

    bin_path = '/some/path/{0}'

    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    current_if = {}
    current_if['device'] = 'en0'
    current_if['flags'] = ['UP']
    current_if['ipv4'] = []
    current_if

# Generated at 2022-06-20 17:54:38.163047
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule({})
    module.exit_json = lambda **kwargs: kwargs
    # result returned by module.exit_json()
    result = {'ansible_facts': {'ansible_network_resources': {'interfaces': {}}}}
    interface = {'device': 'dummy_device', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interface['flags'] = ['UP']
    interface['macaddress'] = 'unknown'
    # test1
    words = ['dummy_device:', 'UP', 'LOOPBACK', 'RUNNING', 'MTU:65536', 'Metric:1']
    interface1 = AIXNetwork.parse_interface_line(AIXNetwork, words)
    assert interface1 == interface
    # test2

# Generated at 2022-06-20 17:54:42.756588
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    net_cls = AIXNetwork(dict(module=MagicMock()))
    assert isinstance(net_cls, AIXNetwork)



# Generated at 2022-06-20 17:56:36.633955
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:56:47.096538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class FakeModule:
        def get_bin_path(self, executable):
            return '/sbin/netstat'


# Generated at 2022-06-20 17:56:51.717274
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    uname_path = module.get_bin_path('uname')
    if uname_path:
        rc, out, err = module.run_command([uname_path, '-W'])
        if rc == 0 and out.split()[0] == '0':
            network_module = AIXNetwork(module=module)
            assert network_module, 'Constructor of class AIXNetwork return None'

# Generated at 2022-06-20 17:56:57.504420
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    ansible_facts = dict()
    anet = AIXNetwork(module)
    anet.get_default_interfaces('')
    assert 'default_interface' in ansible_facts
    assert 'default_ipv4' in ansible_facts


# Generated at 2022-06-20 17:57:08.972081
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    sys.path.insert(0, '../../')
    from ansible.module_utils import basic


# Generated at 2022-06-20 17:57:10.604738
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    result = AIXNetwork.get_default_interfaces(route_path=None)
    assert result == ({}, {})

# Generated at 2022-06-20 17:57:18.831990
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class AIXModuleTest(object):
        def __init__(self):
            self.bin_path = {
                'netstat': '/usr/bin/netstat',
            }

        def get_bin_path(self, name):
            return self.bin_path[name]

        def run_command(self, command):
            buffer = ['default 192.168.1.1 UGS 0 0 en0',
                      'default ::/0 UGQL 0 0 en0']
            return (0, '\n'.join(buffer), '')

    module = AIXModuleTest()
    net = AIXNetwork()
    net.module = module
    gateway_v4, gateway_v6 = net.get_default_interfaces('/tmp')
    assert gateway_v4['gateway'] == '192.168.1.1'

# Generated at 2022-06-20 17:57:23.894343
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    fake_module = dict()
    net = AIXNetwork(fake_module)
    assert net.platform == 'AIX'
    assert net.module == fake_module



# Generated at 2022-06-20 17:57:32.313946
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModuleMock({})
    ifc = AIXNetwork(module)
    interfaces, ips = ifc.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-20 17:57:42.755297
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.facts import FactCollector
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    fact_collector = FactCollector()
    network_collector = NetworkCollector(fact_collector=fact_collector)
    aix_network = AIXNetwork(fact_collector=fact_collector, network_collector=network_collector)
    gbifc_network = GenericBsdIfconfigNetwork(fact_collector=fact_collector, network_collector=network_collector)