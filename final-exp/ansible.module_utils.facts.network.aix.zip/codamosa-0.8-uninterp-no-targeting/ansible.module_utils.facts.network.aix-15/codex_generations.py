

# Generated at 2022-06-20 17:49:07.978102
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    net = AIXNetwork()
    words = ['en0:', 'flags=8963<UP,BROADCAST,SMART,RUNNING,PROMISC,SIMPLEX,MULTICAST>', 'mtu', '1500']
    current_if = net.parse_interface_line(words)
    assert(current_if['device'] == 'en0')
    assert(current_if['flags'] == '8963')
    assert(current_if['type'] == 'unknown')


if __name__ == '__main__':
    test_AIXNetwork_parse_interface_line()

# Generated at 2022-06-20 17:49:20.609058
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork_parse_interface_line = AIXNetwork.parse_interface_line

    # Return value should be
    expected_retval = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['LOOPBACK']}

    # Unit test example
    words = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '65536']

    # Unit test execution
    retval = AIXNetwork_parse_interface_line(words)

    # Unit test assertion (or clean-up)
    assert retval == expected_retval
    del AIXNetwork_parse_interface_line
    del retval

# Run unit test for above test case:
test_AIXNetwork_parse_interface

# Generated at 2022-06-20 17:49:29.417953
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.tests.unit.module_utils.facts.network.aix_test_data import AIX_NETSTAT_OUTPUT
    from ansible_collections.notstdlib.moveitallout.tests.unit.module_utils.facts.network.aix_test_data import ifconfig_v4_defaultroute_interface, ifconfig_v6_defaultroute_interface

    # Test AIXNetwork.get_default_interfaces with netstat output of AIX (in AIX_NETSTAT_OUTPUT)
    aixnet = AIXNetwork()
    interface_v4, interface_v6 = aixnet.get_default_interfaces(AIX_NETSTAT_OUTPUT)
    assert interface_v4 == ifconfig_v4_defaultroute_interface
   

# Generated at 2022-06-20 17:49:40.556505
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnetwork = AIXNetwork()

    # Get the interface information from sample output of AIX netstat command
    netstat_output = '''
    Routing tables
    Internet:
    Destination        Gateway            Flags  Refs     Use   Interface
    default            10.223.253.1       UG       1       0      en0
    10.223.253.0       10.223.253.141     U        1       0      en0
    '''

    netstat_lines = netstat_output.splitlines()

    aixnetwork.get_default_interfaces(netstat_lines)

    # Calling get_default_interfaces()
    interfacev4, interfacev6 = aixnetwork.get_default_interfaces(netstat_lines)
    # Asserting the output is correct

# Generated at 2022-06-20 17:49:49.956965
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:49:53.009844
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None, None, None, None, None).collect()
    assert facts['default_ipv4']['gateway'] is not None
    assert facts['default_ipv4']['interface'] is not None
    assert facts['default_ipv6']['gateway'] is not None
    assert facts['default_ipv6']['interface'] is not None

# Generated at 2022-06-20 17:49:55.619092
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network
    assert isinstance(network.interfaces, dict)

# Generated at 2022-06-20 17:50:03.518157
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.platform == 'AIX'
    assert net.get_default_interfaces('path') == ({}, {})
    assert net.get_interfaces_info('path') == (net.interfaces, net.ips)
    assert net.parse_interface_line(['1:', 'flags', 'UP']) == {
        'device': '1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP'], 'macaddress': 'unknown'}
    assert net.parse_options_line(['options=', '3'], {}, {}) == {}


# Generated at 2022-06-20 17:50:16.340877
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import sys
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestModule(basic.AnsibleModule):
        def __init__(self):
            argument_spec = {
                'route_file': {'required': True},
                'params': {'required': True}
            }
            super(TestModule, self).__init__(argument_spec=argument_spec)


# Generated at 2022-06-20 17:50:26.310915
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    network = AIXNetwork(None)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces
    assert 'ipv4' in interfaces['en0']
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['macaddress'] == 'unknown'
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-20 17:50:41.819477
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    instance = AIXNetworkCollector()
    if instance.platform != 'AIX' or instance.fact_class.platform != 'AIX':
        raise AssertionError('AIXNetworkCollector initialization failed')


# Generated at 2022-06-20 17:50:42.712552
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

# Generated at 2022-06-20 17:50:51.485180
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # pylint: disable=protected-access

    class ModuleStub(object):
        params = {}
        options = {}
        failed = False

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            cmd_stripped = cmd[:]
            cmd_stripped[0] = re.split('[\\\\/]', cmd_stripped[0])[-1]

            if cmd_stripped == ['ifconfig', '-a']:
                return 0, ifconfig_out, ''

            if cmd_stripped == ['netstat', '-nr']:
                return 0, netstat_out, ''

            if cmd_stripped == ['uname', '-W']:
                return uname_rc, uname_out, ''


# Generated at 2022-06-20 17:50:56.398527
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = Mock(return_value=dict(
        path=dict(
            route='/usr/bin/netstat',
            bin='/usr/bin'
        )
    ))
    module.run_command = Mock(return_value=(0, 'default 192.168.1.1 UG en0\r\ndefault ff02::2 UG en0\r\ndefault fe80:3:: UG en0\r\ndefault ::1 UG lo0', None))
    router = AIXNetwork(module)

    (v4_dict, v6_dict) = router.get_default_interfaces(route_path='/usr/bin/netstat')

    assert v4_dict == dict(gateway='192.168.1.1', interface='en0')

# Generated at 2022-06-20 17:51:01.052427
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collection = AIXNetworkCollector(module=module)
    network_facts_instance = network_collection.collect()[0]
    assert isinstance(network_facts_instance, AIXNetwork)
    assert network_facts_instance.platform == 'AIX'

# Generated at 2022-06-20 17:51:05.478728
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class.
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'


# Generated at 2022-06-20 17:51:08.162862
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector.fact_class == AIXNetwork


# Generated at 2022-06-20 17:51:14.850584
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:51:25.471236
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-20 17:51:35.407167
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This test will take the output of 'ifconfig -a' command,
    process it and make a dictionnary.
    """
    module = MockModule()
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options='-a'

    test_object = AIXNetwork(module)
    (interfaces, ips) = test_object.get_interfaces_info(ifconfig_path, ifconfig_options)
    # Test if the returned dictionnary has the expected number of interfaces
    assert len(interfaces) == 6
    # Test if the returned dictionnary has the expected number of IP addresses
    assert len(ips) == 2

    # Test the first interface 'gi0'
    assert interfaces['gi0']['device'] == 'gi0'

# Generated at 2022-06-20 17:52:10.474513
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command is required but does not exist')

    network_fact = AIXNetwork(module)
    interfaces, ips = network_fact.get_interfaces_info(ifconfig_path)

    for interface in interfaces:
        # device must have mtu attribute in ODM
        assert 'mtu' in interfaces[interface]
        assert 'macaddress' in interfaces[interface]

    module.exit_json(ansible_facts=dict(network=network_fact.get_all_interfaces(interfaces, ips)))


from ansible.module_utils.basic import *


# Generated at 2022-06-20 17:52:19.832555
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_responses = []
            self.run_command_exceptions = []
            self.get_bin_path_responses = []
            self.get_bin_path_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            response = self.run_command_responses.pop(0)
            if len(response) == 4:
                return response
            else:
                raise self.run_command_exceptions.pop(0)

        def get_bin_path(self, path):
            self.get_bin_path_calls.append(path)
            return self.get_bin_path_

# Generated at 2022-06-20 17:52:26.913467
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    class AIXNetwork:
        def __init__(self):
            pass

    test = AIXNetwork()
    test.parse_interface_line(['en0:'])
    assert test.parse_interface_line(['en0:']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    test.parse_interface_line(['lo0:'])
    assert test.parse_interface_line(['lo0:']) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    test.parse_interface_line(['en0:'])

# Generated at 2022-06-20 17:52:35.903991
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifcfg_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    test_obj = AIXNetwork(None)

    assert isinstance(test_obj, AIXNetwork)

    interfaces, ips = test_obj.get_interfaces_info(ifcfg_path, ifconfig_options)

    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert 'en0' in ips['all_ipv4_addresses']
    assert '169.254.0.1' in ips['all_ipv4_addresses']

# Generated at 2022-06-20 17:52:39.481101
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    print(network_collector)
    assert network_collector.__class__.__name__ == 'AIXNetworkCollector'

# Generated at 2022-06-20 17:52:47.822405
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import os
    from ansible_collections.ansible.community.plugins.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import default_collectors
    module = DummyModule()
    facts_d = Facts({}, module)
    for fact_class in default_collectors:
        facts_d.collect(fact_class)
    if os.uname()[0] == 'AIX':
        assert isinstance(facts_d['ansible_net_gather_subset'][0], AIXNetworkCollector)



# Generated at 2022-06-20 17:52:50.298556
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class.platform == 'AIX'

# Generated at 2022-06-20 17:52:57.970945
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork = AIXNetwork()
    words = ["en10:", "flags=3c00<UP,", "BROADCAST,", "RUNNING,", "SIMPLEX,", "MULTICAST>"]

    current_if = AIXNetwork.parse_interface_line(words)

    assert current_if['device'] == 'en10'
    assert current_if['flags'] == 'UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:53:07.637716
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert bool(AIXNetworkCollector.__bases__) == True
    assert len(AIXNetworkCollector.__bases__) == 1
    for base in AIXNetworkCollector.__bases__:
        assert bool(base.__name__) == True
        assert base.__name__ == 'NetworkCollector'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'


if __name__ == '__main__':
    # Unit test for constructor of class AIXNetworkCollector
    test_AIXNetworkCollector()

# Generated at 2022-06-20 17:53:15.716230
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork()
    test_line = "lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232"
    test_words = test_line.split()
    result = test.parse_interface_line(test_words)
    assert result['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert result['mtu'] == '8232'
    assert result['device'] == 'lo0'
    assert result['type'] == 'unknown'
    assert result['ipv4'] == []
    assert result['ipv6'] == []
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-20 17:54:14.868333
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'ansible_host': dict(type='str', required=True),
    }, supports_check_mode=True)
    fact_subclass = AIXNetwork()
    route_path = fact_subclass.module.get_bin_path('route')

    assert route_path is not None, 'Path for executable route not found.'


# Generated at 2022-06-20 17:54:24.452691
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    import sys
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import remove_ext_diff
    from collections import namedtuple

    sys.modules['ansible'] = type('fake_ansible_module', (object,), {})()
    sys.modules['ansible.module_utils'] = type('fake_ansible_module_utils', (object,), {})()
    sys.modules['ansible.module_utils.facts'] = type('fake_ansible_module_utils_facts', (object,), {})()
    sys.modules['ansible.module_utils.facts.network'] = type('fake_ansible_module_utils_facts_network', (object,), {})()

# Generated at 2022-06-20 17:54:25.273597
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector is not None


# Generated at 2022-06-20 17:54:37.097762
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """ Unit test for method parse_interface_line of class AIXNetwork """
    aix_network = AIXNetwork()

    interface = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    words = interface.split()
    result = aix_network.parse_interface_line(words)

    assert 'device' in result
    assert result['device'] == 'en0'
    assert 'flags' in result
    assert result['flags'] == "1e080863"
    assert 'macaddress' in result
    assert result['macaddress'] == 'unknown'
    assert 'ipv4' in result

# Generated at 2022-06-20 17:54:41.456357
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fakeAIXNetwork = AIXNetwork()
    def_route_path = '/etc/netstat'  # a fake path, does not matter
    def_interfaces = fakeAIXNetwork.get_default_interfaces(def_route_path)
    assert def_interfaces is not None



# Generated at 2022-06-20 17:54:47.458385
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)
    module = Bunch(
        params={"gather_subset": "!all", "gather_network_resources": "no"},
        run_command=Bunch(return_value=(0, "", ""))
    )
    aix_network.module = module
    out = aix_network.get_default_interfaces("/usr/bin/netstat")
    assert out['gateway'] == '172.20.39.42'
    assert out['interface'] == 'ent0'

# Generated at 2022-06-20 17:54:55.659988
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconf = AIXNetwork()
    ifc = ifconf.parse_interface_line(['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>', 'inet', '10.103.64.196', 'netmask', '0xffffc000', 'broadcast', '10.103.127.255'])
    assert ifc['device'] == 'en0'

# Generated at 2022-06-20 17:54:58.879686
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network_test = AIXNetwork()
    assert aix_network_test.platform == 'AIX'


# Generated at 2022-06-20 17:55:00.838538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetworkObject = AIXNetwork()
    d = AIXNetworkObject.get_default_interfaces
    assert d == {}

# Generated at 2022-06-20 17:55:10.599237
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    collector = AIXNetworkCollector(module=module)
    net = collector._fact_class(module)
    import sys
    if sys.platform != 'aix6':
        module.fail_json(msg="Unit test is not supported on this platform.  Exiting.")
    classes = dict(AIXNetwork=AIXNetwork)
    # On AIX the default route is always the same
    import os
    if os.path.exists('/opt/ibm/director/bin'):
        # On AIX 7.1 default gw is 10.xxx.xxx.xxx
        # so test fails on AIX 7.1
        module.fail_json(msg="Unit test is not supported on this platform.  Exiting.")

# Generated at 2022-06-20 17:57:09.728580
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    ansible_module = FakeAnsibleModule(platform='AIX')
    aix_network = AIXNetwork(ansible_module, 'ifconfig')
    assert aix_network.get_default_interfaces('route') == (dict(gateway='10.9.8.7', interface='en0'), dict(gateway='fe80::aaa:bbb:ccc:ddd', interface='en0'))


# Generated at 2022-06-20 17:57:18.279216
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os.path
    srcdir = os.path.dirname(__file__) or '.'
    obj = AIXNetwork()
    mock_run_command_expectations = {
        'netstat -rn': (0, os.path.join(srcdir, 'files', 'netstat-rn'), None)
    }
    obj.module.run_command = mock_run_command(obj.module, mock_run_command_expectations)
    result = obj.get_default_interfaces('/sbin/route')
    assert result == ({'gateway': '172.16.47.254', 'interface': 'en2'}, {'gateway': 'fe80::21f:5bff:fe1c:fbc0', 'interface': 'en2'})


# Generated at 2022-06-20 17:57:22.673786
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    _module = AnsibleModuleMock()
    _module.params = dict()
    _module.run_command = run_command
    _modul

# Generated at 2022-06-20 17:57:30.990856
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_module.run_command = mock.Mock(return_value=(0, "default 172.16.0.1 UG 0 0 en1", None))

    test_network_collector = AIXNetworkCollector()

    default_interfaces = test_network_collector.get_default_interfaces(test_module)

    assert default_interfaces == {
        'default': { 
            'v4': { 
                'gateway': '172.16.0.1',
                'interface': 'en1'
            }
        }
    }

# Generated at 2022-06-20 17:57:39.887531
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # test without argument, without any interface
    aix_net = AIXNetworkCollector(None)
    assert 'ansible_all_ipv4_addresses' not in aix_net.facts
    assert 'ansible_all_ipv6_addresses' not in aix_net.facts
    assert 'ansible_interfaces' not in aix_net.facts

    # test with argument, and with interface
    aix_net = AIXNetworkCollector('aix_net')
    assert 'ansible_all_ipv4_addresses' in aix_net.facts
    assert 'ansible_all_ipv6_addresses' in aix_net.facts
    assert 'ansible_interfaces' in aix_net.facts
    assert 'ansible_default_ipv4' in aix_net

# Generated at 2022-06-20 17:57:49.479270
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    n = AIXNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = n.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['flags'][0] == 'UP'
    assert interfaces['en0']['flags'][1] == 'BROADCAST'
    assert interfaces['en0']['flags'][2] == 'SIMPLEX'
    assert interfaces['en0']['flags'][3]

# Generated at 2022-06-20 17:57:54.373091
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    result = AIXNetwork().parse_interface_line(['en0:'])
    assert result['device'] == 'en0'
    assert result['flags'] == ''
    assert result['macaddress'] == 'unknown'
    assert result['type'] == 'unknown'

# Generated at 2022-06-20 17:57:59.797227
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    def DictionaryContains(dict_a, dict_b):
        for key in dict_a:
            if not key in dict_b:
                return False
            if type(dict_a[key]) is dict:
                if not DictionaryContains(dict_a[key], dict_b[key]):
                    return False
            elif type(dict_a[key]) is list:
                if not set(dict_a[key]) == set(dict_b[key]):
                    return False
            else:
                if not dict_a[key] == dict_b[key]:
                    return False
        return True

    AIXNetwork_test = AIXNetwork()


# Generated at 2022-06-20 17:58:09.779954
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    result = module.params['ifconfig_path'] = module.params['route_path'] = ''
    parse_line = AIXNetwork(module).parse_interface_line
    assert parse_line(['lo0:', 'flags=1<UP,LOOPBACK>', 'mtu', '32768', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ff000000', 'groups:', 'lo,']) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK'], 'macaddress': 'unknown'}

# Generated at 2022-06-20 17:58:20.824708
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Remove the debug code when it is proven
    testAIXNetwork = AIXNetwork()
    testAIXNetwork.module.get_bin_path = lambda arg: arg
    ifconfig_path = testAIXNetwork.module.get_bin_path('ifconfig')
    testAIXNetwork.get_interfaces_info(ifconfig_path)
    for dev in testAIXNetwork.interfaces:
        print('device=' + dev)
        for key in testAIXNetwork.interfaces[dev]:
            print('  ' + key + '=' + testAIXNetwork.interfaces[dev][key])