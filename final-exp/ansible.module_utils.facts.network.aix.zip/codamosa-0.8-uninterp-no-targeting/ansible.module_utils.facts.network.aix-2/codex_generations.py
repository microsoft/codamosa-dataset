

# Generated at 2022-06-20 17:48:56.327531
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'

# Generated at 2022-06-20 17:49:08.102620
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})

    aix_if_config = AIXNetwork()

    line = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232'
    words = line.split()
    current_if = aix_if_config.parse_interface_line(words)
    assert current_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                          'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'macaddress': 'unknown'}

    line = 'lo1: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232'
    words = line.split()
   

# Generated at 2022-06-20 17:49:11.461196
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    obj = AIXNetwork()
    assert obj.platform == 'AIX'


# Generated at 2022-06-20 17:49:21.589598
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # create test data
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # create test object
    aix_network = AIXNetwork(module)

    # testing the two methods of the class
    facts = aix_network.get_facts()
    default_interfaces = aix_network.get_default_interfaces('/usr/sbin/netstat')

    # comparing with the expected results of the methods
    assert facts['interfaces']['lo0']['flags'][0] == 'UP'
    assert facts['default_ipv4']['gateway'] == '10.3.3.1'
    assert facts['default_ipv4']['interface'] == 'en0'

# Generated at 2022-06-20 17:49:30.097530
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    net = AIXNetwork()

    net.module = MockModule()

# Generated at 2022-06-20 17:49:31.975659
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    net.get_interfaces_info('')

# Generated at 2022-06-20 17:49:41.531260
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    module = NetworkCollector()
    w_found = False
    w_mtu = False
    w_type = False

    aix = AIXNetwork()
    test_interface = aix.parse_interface_line(['en2:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>',
                                               'inet', '10.10.20.141', 'netmask', '0xffffff00', 'broadcast',
                                               '10.10.20.255'])

    if test_interface['device'] == 'en2':
        w_found = True
    if test_interface['mtu'] == '1500':
        w

# Generated at 2022-06-20 17:49:46.098979
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    m = AIXNetwork()
    words = ifconfig_line.split()
    assert words[0] == 'en0:'
    result = m.parse_interface_line(words)
    assert result['device'] == 'en0'
    assert len(result['ipv4']) == 0
    assert len(result['ipv6']) == 0

# Generated at 2022-06-20 17:49:51.735907
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """This is a unit test for method get_default_interfaces of class AIXNetwork"""
    # TODO:
    # - Add exceptions and error handling to unit test
    # - Add more tests
    # - Determine if we want to test the 'else' part of the method
    # - The method uses the 'netstat' command, this test does not
    # - The method uses the 'module' object, this test does not

    # Setup
    netstat_path = '/usr/bin/netstat'
    route_path = None
    module = None

    # Prepare the expected result
    exp_gateway = '10.0.0.1'
    exp_interface = 'en0'
    exp_v4_default = {'gateway': exp_gateway, 'interface': exp_interface}

# Generated at 2022-06-20 17:49:53.309405
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix = AIXNetwork()
    print(aix)
    assert aix is not None


# Generated at 2022-06-20 17:50:12.868017
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''
    Unit test for constructor of class AIXNetworkCollector
    '''
    from .. import NetworkCollector

    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector.__doc__
    assert not AIXNetworkCollector.__init__.__doc__
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-20 17:50:23.396298
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os
    import platform
    import tempfile
    import pytest
    import json

    # For AIX, some of the network facts are gathered using configuration files
    # passed to network test runner as environment variables.
    # We need to create temporary files to run this class constructor.
    os_release_filename = tempfile.NamedTemporaryFile(delete=False)
    os_release_filename.write('6.1.0.0\n')
    os_release_filename.close()
    os.environ['NET_TEST_OS_RELEASE'] = os_release_filename.name
    aix_release_filename = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-20 17:50:31.228191
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.module_utils.facts.network.test_generic_bsd import prepare_mock_current_if, prepare_mock_ips

    current_if = prepare_mock_current_if()
    ips = prepare_mock_ips()

    m_module = MagicMock()

# Generated at 2022-06-20 17:50:42.798093
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

        ifconfig_path = None
        ifconfig_options = '-a'
        module = None


# Generated at 2022-06-20 17:50:47.862993
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = '/usr/bin/netstat'
    collector = AIXNetworkCollector(dict(module=None))
    network = collector._fact_class(dict(module=None))
    assert network.get_default_interfaces(route_path) == (dict(gateway='172.20.0.254', interface='en0'), dict(gateway='fe80::208:c4ff:fe0f:ce97', interface='en0'))

# Generated at 2022-06-20 17:50:59.117319
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixifconfig_path = '/usr/sbin/ifconfig'
    aixnetstat_path = '/usr/bin/netstat'
    aixroute_path = '/usr/sbin/route'
    anetwork = AIXNetwork(dict(module=dict(run_command=dict(return_value=(0, '', ''))),
                               params=dict(ifconfig_path=aixifconfig_path,
                                           route_path=aixroute_path)))
    rc, out, err = anetwork.module.run_command.return_value = 0, '', ''
    anetwork.module.get_bin_path.return_value = aixnetstat_path
    anetwork.get_default_interfaces(aixroute_path)

# Generated at 2022-06-20 17:51:04.864981
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import mock
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    module = mock.Mock()
    module.get_bin_path = mock.Mock(return_value=True)
    networkCollector = AIXNetworkCollector(module=module)
    assert isinstance(networkCollector, NetworkCollector)



# Generated at 2022-06-20 17:51:08.369324
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Dummy test with constructor of class AIXNetworkCollector
    """
    AIXNetworkCollector()


if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-20 17:51:20.614443
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # make an instance of AIXNetwork
    aix_net = AIXNetwork()

    # make an instance of a string, like ifconfig -a produces
    interface_line = 'en0: flags=0x8802<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'

    # make an instance of a list that is produced by .split() method on a string
    words = interface_line.split()

    # call the parse_interface_line method on AIXNetwork class instance, passing
    # it the list of split words
    current_if = aix_net.parse_interface_line(words)

    # expect it to return a dictionary with an expected interface, flags and macaddress
    assert current_if['device'] == 'en0'

# Generated at 2022-06-20 17:51:23.206384
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    result = AIXNetwork(module)
    assert result.platform == 'AIX'



# Generated at 2022-06-20 17:51:41.274542
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {'run_command': lambda x: (0, 'default 172.31.253.254   UG        0 0        en0', None),
                          'get_bin_path': lambda x: '/usr/sbin/netstat'})
    module = module()
    ans_obj = AIXNetworkCollector(module=module)
    real_ans = ans_obj._get_default_interfaces()
    assert real_ans == {'interface': 'en0', 'gateway': '172.31.253.254'}


# Generated at 2022-06-20 17:51:45.028542
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    facts = AIXNetwork()
    default_v4_interface = facts.get_default_interfaces('/usr/bin')
    assert default_v4_interface == ('en0', 'en0')

# Generated at 2022-06-20 17:51:55.022188
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    '''
    :return:
    '''
    # initialize class
    abcl = AIXNetwork()

    # interface line without nd6 options

# Generated at 2022-06-20 17:52:01.615849
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    Test to construct an object of class AIXNetwork
    '''

# Generated at 2022-06-20 17:52:11.438664
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    network_collector = AIXNetworkCollector(module=module,
                                            command={'ifconfig_path': '/usr/sbin/ifconfig',
                                                     'netstat_path': '/usr/sbin/netstat'})

    interfaces, ips = network_collector.get_interfaces_info()
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 17:52:14.164275
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    assert AIXNetwork(module).platform == AIXNetworkCollector._platform

# Generated at 2022-06-20 17:52:22.803556
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import sys
    import subprocess
    from ansible.module_utils.facts.network.aix import AIXNetwork

    out = ''

    # capture the output of 'ifconfig -a' running on AIX
    if sys.platform.startswith('aix'):
        p1 = subprocess.Popen(["ifconfig", "-a"], stdout=subprocess.PIPE)
        p2 = subprocess.Popen(["cat", "-"], stdin=p1.stdout, stdout=subprocess.PIPE)
        out = p2.communicate()[0]

    aix = AIXNetwork(dict(module=dict()))
    interfaces, ips = aix.get_interfaces_info('ifconfig', '-a')

    for device in interfaces:
        if_dict = interfaces[device]

# Generated at 2022-06-20 17:52:34.086164
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    go through all interfaces
    line looks like this:
    en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> metric 1
        mtu 1500
        options=1b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,TSO4,TSO6,VLAN_HWCSUM,VLAN_HWFILTER,VLAN_HWTSO>
        address: 00:21:28:89:f6:3c
        media: Ethernet autoselect (100baseTX full-duplex)
        status: active
    """


# Generated at 2022-06-20 17:52:36.475534
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-20 17:52:47.484880
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import os.path
    import sys

    module = sys.modules['__main__']

    # AnsibleModule is not available at module import time
    from ansible.module_utils.facts.network import AIXNetwork
    iface = AIXNetwork(module)

    # test stubs for ifconfig

# Generated at 2022-06-20 17:53:12.693232
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import get_interfaces_info
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # test on fake ifconfig output
    test_network = get_interfaces_info(None, 'aix')
    t_interfaces = test_network[0]
    t_ips = test_network[1]

    # test on real ifconfig output
    interfaces_info = AIXNetwork().get_interfaces_info()
    interfaces = interfaces_info[0]
    ips = interfaces_info[1]

    assert t_interfaces == interfaces
    assert t_ips == ips

# Generated at 2022-06-20 17:53:18.806630
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    an = AIXNetwork(module)
    ifc = an.get_interfaces_info(ifconfig_path)
    assert ifc[0]['en0']['macaddress'] == 'AA:BB:CC:DD:EE:FF'
    assert ifc[0]['en0']['device'] == 'en0'
    assert ifc[0]['en0']['type'] == 'ether'


# Generated at 2022-06-20 17:53:24.645651
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/usr/bin/netstat'
    network_collector = AIXNetwork()

    out = """
default 10.1.1.1 UG 0 0 en0
default 2001:a::1 UG 0 0 en0
default 10.2.2.2 UG 0 0 bge1
    """
    module.run_command.return_value = 0, out, ''
    assert network_collector.get_default_interfaces('dummy') == ({'gateway': '10.1.1.1', 'interface': 'en0'}, {'gateway': '2001:a::1', 'interface': 'en0'})


# Generated at 2022-06-20 17:53:33.406598
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = type('', (object,), {})
    module.get_bin_path = lambda *_: '/bin/netstat'
    facts = dict(ansible_net_interfaces={})
    aix_network = AIXNetworkCollector(module=module, facts=facts)
    assert aix_network.platform == 'AIX'
    assert aix_network.fact_class == AIXNetwork
    assert aix_network.interfaces == {}
    assert aix_network.routes == {}
    assert aix_network.ips == {}



# Generated at 2022-06-20 17:53:37.357188
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    f = AIXNetwork()
    assert f.platform == 'AIX'
    assert f.parse_interface_line(['lo0:']) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}


# Generated at 2022-06-20 17:53:38.209336
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

# Generated at 2022-06-20 17:53:43.502170
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    This function unit tests the constructor of the class AIXNetwork.
    """
    from ansible.module_utils.facts.collector import FactCollector

    module_mock = lambda: None
    module_mock.run_command = lambda x: (None, None, None)
    module_mock.get_bin_path = lambda x: None
    module_mock.exit_json = lambda x, y: None
    aixnetwork = AIXNetwork({}, module_mock, FactCollector())
    assert aixnetwork.platform == 'AIX'


# Generated at 2022-06-20 17:53:48.016729
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of the class AIXNetworkCollector
    """
    # initializing the object
    testobj = AIXNetworkCollector()
    # checking if the object is correctly initialized
    assert testobj._platform == 'AIX'
    assert testobj._fact_class.__name__ == 'AIXNetwork'

# Generated at 2022-06-20 17:53:59.220500
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append(name)
            return self.get_bin_path_results.pop(0)

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    module = TestModule()
    aix_network = AIXNetwork()
    aix_network.module = module
    ifconfig

# Generated at 2022-06-20 17:54:08.807111
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-20 17:54:47.007125
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    testobj = AIXNetwork()

    # test positive case
    words = ['ent0:', 'flags=81', '<UP,BROADCAST,RUNNING,SIMPLEX>']
    current_if = testobj.parse_interface_line(words)
    assert 'device' in current_if
    assert current_if['device'] == 'ent0'
    assert 'mtu' not in current_if
    assert 'flags' in current_if
    assert current_if['flags'] == set(['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX'])

    # test negative case for the return value
    current_if = testobj.parse_interface_line(words)
    assert 'mtu' not in current_if



# Generated at 2022-06-20 17:54:54.712543
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    pci_path = module.get_bin_path('lscfg')
    nm_path = module.get_bin_path('netstat')
    aixnet = AIXNetwork(module, ifconfig_path)
    # Test if the variables have changed to AIX
    assert aixnet.platform == 'AIX'
    assert aixnet.ifconfig_path == ifconfig_path
    assert aixnet.pci_path == pci_path
    assert aixnet.netstat_path == nm_path

# Unit tests for method get_interfaces_info

# Generated at 2022-06-20 17:54:59.962062
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = MockAnsibleModule()
    network_collection = AIXNetworkCollector(module).collect()
    # Testing that the network_collection is constructed correctly
    assert len(network_collection) == 1
    assert isinstance(network_collection[0], AIXNetwork)
    assert network_collection[0]._module == module


# Generated at 2022-06-20 17:55:09.157484
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'name': {'default': 'ansible'}})
    module.params['name'] = 'ansible'
    module.params['debug'] = True
    network_aix = AIXNetwork(module)
    default = {'name': 'ansible', 'default_ipv4': 
               {'gateway': '192.168.122.1', 'interface': 'en0'},
               'default_ipv6': {'gateway': '2001:db8:1::1', 'interface': 'en0'}}
    assert network_aix.get_default_interfaces('/etc/hostname.en0') == \
           (default['default_ipv4'], default['default_ipv6'])

# Generated at 2022-06-20 17:55:14.161777
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None, None, None, None, None).collect()
    interfaces = facts['interfaces']
    for interface in interfaces.values():
        for key in ('active', 'device', 'ipv4', 'ipv6', 'macaddress', 'type'):
            assert key in interface

# Generated at 2022-06-20 17:55:17.601821
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj._fact_class is AIXNetwork
    assert obj._platform == 'AIX'


# Generated at 2022-06-20 17:55:25.676941
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """Test parsing interfaces from AIX ifconfig -a"""

# Generated at 2022-06-20 17:55:35.410303
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '1500']

    test = AIXNetwork()
    test_if = test.parse_interface_line(words)

    assert test_if['device'] == 'en0'
    assert test_if['mtu'] == '1500'
    assert test_if['flags'] == ['1e080863']

# Generated at 2022-06-20 17:55:44.339380
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_obj = AIXNetwork()

    # netstat command find both IPv4 and IPv6 default routes
    # return value should be both IPv4 and IPv6 data

# Generated at 2022-06-20 17:55:50.769886
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Open test file with single line:
    file_name = 'test_AIXNetwork_1.txt'
    with open(file_name, 'r') as fp:
        # create and run test instance
        aix_network = AIXNetwork()
        aix_network.parse_interfaces(fp)

        # Check the results
        assert aix_network.interfaces['en0']['ipv4'] == [{'address': '169.254.219.195', 'netmask': '255.255.0.0',
                                                          'broadcast': '169.254.255.255'}]

# Generated at 2022-06-20 17:57:00.830531
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.__dict__ == {'_fact_class': AIXNetwork, '_platform': 'AIX'}

# Generated at 2022-06-20 17:57:13.166580
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Unit test for constructor of class AIXNetwork
    #
    # Args:
    #
    # Test: AIXNetwork()
    #
    # Expected result:
    #
    #     network = AIXNetwork()
    #     network.get_interfaces_info()

    network = AIXNetwork()
    interfaces, ips = network.get_interfaces_info(network.module.get_bin_path('ifconfig'))

    # Known results:
    #
    #  - interfaces['lo0']:
    #    {'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
    #     'device': 'lo0',
    #     'options': ['<LOOPBACK,UP,LOWER_UP>'],
    #     'inet': ['127.0.

# Generated at 2022-06-20 17:57:19.736754
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MockModule()
    AN = AIXNetwork(module)
    AN.get_interfaces_info('/bin/ifconfig', '-a')

# Generated at 2022-06-20 17:57:31.113902
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-20 17:57:39.929880
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = type('FakeModule', (object,), dict(run_command=lambda *_: (0, 'fakeout', 'fakeerr')))()
    net = AIXNetwork(module)
    device_name = "en0"
    words = [device_name + ":", "flags=1e0800<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>", "mtu=1500"]
    i_face = net.parse_interface_line(words)
    assert i_face['device'] == device_name
    assert i_face['type'] == 'unknown'
    assert i_face['macaddress'] == "unknown"
    assert i_face['mtu'] == "1500"


# Generated at 2022-06-20 17:57:44.514883
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module=module)
    assert network.platform == 'AIX'
    assert network.ifconfig_path == '/usr/sbin/ifconfig'
    assert network.route_path == '/usr/sbin/route'
    assert not network.use_ipv6

# Generated at 2022-06-20 17:57:46.491051
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'


# Generated at 2022-06-20 17:57:51.199711
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'


# Generated at 2022-06-20 17:57:57.143543
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict()
    )

    # netstat is not available
    netstat_path = module.get_bin_path('netstat')
    module.run_command = MagicMock(return_value=(1, '', ''))  # add rc=1, out='' and err=''
    cmd = [netstat_path, '-nr']
    module.run_command.assert_any_call(cmd)

    network_obj = AIXNetwork(module)
    interface_v4, interface_v6 = network_obj.get_default_interfaces('/tmp')
    assert interface_v4 == {}
    assert interface_v6 == {}

    # netstat is available
    netstat_path = module.get_bin_path('netstat')

# Generated at 2022-06-20 17:58:09.162653
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    ifconfig_path = network_collector.module.get_bin_path('ifconfig')
    if ifconfig_path:
        interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
        assert('lo0' in interfaces)
        assert(interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING'])
        assert('lo0' in ips['all_ipv4_addresses'])
        assert('::1' in ips['all_ipv6_addresses'])
        assert('lo0' in ips['all_ipv6_addresses']['::1']['interface'])

# Unit