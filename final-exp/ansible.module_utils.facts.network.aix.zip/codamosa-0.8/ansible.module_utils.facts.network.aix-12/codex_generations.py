

# Generated at 2022-06-11 03:04:29.863067
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    obj = AIXNetwork()
    obj.module = Mock()
    obj.module.get_bin_path.return_value = '/usr/bin/netstat'
    intf1, intf2 = obj.get_default_interfaces('/tmp')
    assert intf1['gateway'] == '10.80.52.1'
    assert intf1['interface'] == 'ent0'
    assert intf2['gateway'] == 'fe80::8e0e:c0ff:fee4:4b4b'
    assert intf2['interface'] == 'ent0'

# Unit tests for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:04:40.764719
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys


# Generated at 2022-06-11 03:04:48.680895
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command_called = False
            self.run_command_calls = []
            self.run_command_rc = 0

# Generated at 2022-06-11 03:04:59.280139
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    network = AIXNetwork(module=module)

# Generated at 2022-06-11 03:05:09.462454
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-11 03:05:18.924572
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork()

    # AIX
    network.module = FakeModule()
    netstat_path = network.module.get_bin_path('netstat')
    if Fixture.netstat:
        v4, v6 = network.get_default_interfaces(None)
        assert v4['gateway'] == '10.11.12.1'
        assert v4['interface'] == 'en0'
        assert v6['gateway'] == '2001:db8:8:4::2'
        assert v6['interface'] == 'en1'
    else:
        v4, v6 = network.get_default_interfaces(None)
        assert v4 == {}
        assert v6 == {}


# Generated at 2022-06-11 03:05:29.282868
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import os
    import sys
    import json
    import pytest
    from io import StringIO
    from ansible.module_utils.facts import ModuleFacts

    class BsdModuleFacts(ModuleFacts):

        @staticmethod
        def get_bin_path(name):
            module = modules[name]
            return module['paths'][0]

        @staticmethod
        def get_filesystem_path(name):
            return get_filesystem_path(name)

        @staticmethod
        def get_file_content(name):
            return get_file_content(name)

        @staticmethod
        def run_command(args, check_rc=True):
            module = args[0]

# Generated at 2022-06-11 03:05:39.371313
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This unit test checks AIXNetworkCollector.
    It requires you to have AIX 6.1.0.0 installed.
    """

    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import collections
    import pprint

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ansible_network_resources = AIXNetworkCollector().get_network_resources()

    if PY2:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')



# Generated at 2022-06-11 03:05:49.152041
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fact_module = NetworkCollector._platforms['AIX']()
    # ifconfig_path = fact_module.module.get_bin_path('ifconfig')
    # ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_path = './unittests/sample_outputs/ifconfig_aix.txt'


# Generated at 2022-06-11 03:05:59.831716
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Import here and not in the beginning, because it requires AIX.
    from ansible.module_utils.facts.network.aix import AIXNetwork as AIXNetworkCollector

    # example output from AIX 7.2

# Generated at 2022-06-11 03:06:17.328304
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''
    Unit test for constructor of class AIXNetworkCollector
    '''
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )
    network_collector = AIXNetworkCollector(
        module=module,
        command_loader=CommandLoader(module=module),
        platform='AIX',
        network_class=AIXNetwork
    )
    assert network_collector is not None


# Generated at 2022-06-11 03:06:25.698037
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test constructor of class AIXNetworkCollector"""

    # Call the constructor with valid arguments
    result = AIXNetworkCollector()

    # Verify the expected result
    assert type(result) == AIXNetworkCollector
    assert result._platform == 'AIX'
    assert result._fact_class == AIXNetwork
    assert not result.validate_any_option
    assert not result._default_interfaces_opts
    assert not result._default_interfaces_args


# Generated at 2022-06-11 03:06:28.147506
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net = AIXNetwork
    net.get_interfaces_info(net, ifconfig_path='bin/ifconfig',
                            ifconfig_options='-a')



# Generated at 2022-06-11 03:06:39.042669
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 03:06:48.434734
# Unit test for constructor of class AIXNetworkCollector

# Generated at 2022-06-11 03:06:49.931600
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert (result._platform == 'AIX')


# Generated at 2022-06-11 03:06:54.366288
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector, '_fact_class')
    assert AIXNetworkCollector._fact_class is AIXNetwork

    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector._platform == 'AIX'
    assert collector.fact_class is AIXNetwork


# Generated at 2022-06-11 03:07:04.591906
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from unittest.mock import Mock, patch
    from ansible.module_utils import basic

    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # Create a mock object for the basic.AnsibleModule() object
    module = Mock(spec=basic.AnsibleModule)

    # The first parameter is the platform
    # Return a mock object for the AIXNetworkCollector
    with patch('ansible.module_utils.facts.network.aix.AIXNetworkCollector', return_value=module) as mock_AIXNetworkCollector:
        # Call the collector
        AIXNetworkCollector.collect(module=module)

        # Assert that the AIXNetworkCollector class is executed correctly
        mock_AIXNetworkCollector.assert_called_with(module)

# Generated at 2022-06-11 03:07:06.587243
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()

    assert nc._fact_class == AIXNetwork
    assert nc._platform == 'AIX'

# Generated at 2022-06-11 03:07:15.774537
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockModule()
    net_collector = AIXNetwork(module=module)
    net_collector.get_default_interfaces = Mock(return_value=(
        {'gateway': '1.2.3.4', 'interface': 'en0'},
        {'gateway': 'fe80::1', 'interface': 'en0'},
    ))
    response = {'default_ipv4': {'gateway': '1.2.3.4', 'interface': 'en0'},
                'default_ipv6': {'gateway': 'fe80::1', 'interface': 'en0'}}
    assert response == net_collector.get_default_interfaces(None)
    net_collector.get_default_interfaces.assert_called_with(None)


# Generated at 2022-06-11 03:07:46.324211
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollectorManager
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils import basic
    import json

    module = basic.AnsibleModule(argument_spec=dict())

    c = NetworkCollectorManager(module=module)
    facts = c.collect(["interfaces", "default_ipv4"], gather_subset=["all"])

    module.exit_json(ansible_facts={"ansible_network_resources": facts})

# Generated at 2022-06-11 03:07:56.334845
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import sys

    aix = AIXNetwork()

    # test 1
    # set simple mock lines

# Generated at 2022-06-11 03:08:00.687690
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # create one AIXNetworkCollector object
    aix_network_collector = AIXNetworkCollector()
    # check values of attributes
    assert aix_network_collector._fact_class is AIXNetwork
    assert aix_network_collector._platform == 'AIX'



# Generated at 2022-06-11 03:08:11.409567
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ''' Unit test for method get_interfaces_info of class AIXNetwork '''

    # Initialize the class object
    aix_net = AIXNetwork()

    # Sample ifconfig output, 'ifconfig -a'

# Generated at 2022-06-11 03:08:21.465336
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork.
    """

    class AIXModule(object):
        """
        Test class AIXModule.
        """
        def __init__():
            self.tmpdir = None

        def get_bin_path(self, arg, opt_dirs=[]):
            print(arg)
            if arg == 'ifconfig':
                return '/usr/bin/ifconfig'

            return 'not_found'

        def run_command(self, arg, check_rc=True, close_fds=False, executable=None, data=None):
            """
            Test method run_command.
            """
            print('command: ', arg)

            command = arg

# Generated at 2022-06-11 03:08:28.590709
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    try:
        net_collector = AIXNetworkCollector()
    except Exception as e:
        assert False, 'AIXNetworkCollector failed: {0}'.format(e)
    assert type(net_collector) is AIXNetworkCollector
    assert type(net_collector._fact_class) is AIXNetwork
    assert net_collector._platform == 'AIX'


# Generated at 2022-06-11 03:08:35.885718
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_network_resources=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )
    my_network = AIXNetwork({'module': module})
    rc, out, err = module.run_command(['which', 'netstat'])
    if rc == 0:
        # call the method to be tested here
        default_interfaces = my_network.get_default_interfaces(out)
        # testing result here

# Generated at 2022-06-11 03:08:38.409115
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector.collect()

    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-11 03:08:47.355894
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    # These two lines create the fake class
    test_module.params = {}
    test_module.params['_ansible_verbosity'] = 1

    test_class = AIXNetwork(test_module)

    test_route_path = '/usr/sbin/route'

    test_default_interface = test_class.get_default_interfaces(test_route_path)

    assert test_default_interface[0]['gateway'] == '192.168.1.1'
    assert test_default_interface[0]['interface'] == 'en0'
    assert test_default_interface[1]['gateway'] == 'fe80::cd9c:7fff:fe6f:b8f0'
    assert test_default_interface

# Generated at 2022-06-11 03:08:56.362497
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network_instance = AIXNetwork()
    aix_network_instance.module = ansible_module_prepare()

    aix_network_instance.route_path = '/usr/bin/netstat'

    interfaces = aix_network_instance.get_default_interfaces(aix_network_instance.route_path)

    assert interfaces['v4']['gateway'] == '192.168.1.1'
    assert interfaces['v4']['interface'] == 'en0'
    assert interfaces['v6']['gateway'] == 'fd25:dcad:ca45:6a2b::1'
    assert interfaces['v6']['interface'] == 'en0'



# Generated at 2022-06-11 03:09:43.375966
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class AIXNetwork
    """
    AIXnet = AIXNetwork()
    assert AIXnet.get_default_interfaces('route') == ({'interface': 'en5', 'gateway': '10.0.0.1'}, {'interface': 'en5', 'gateway': 'fe80::21a:2bff:fe65:b1bb'})


# Generated at 2022-06-11 03:09:45.330295
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nf = AIXNetworkCollector()
    assert nf.platform == 'AIX'
    assert nf.fact_class == AIXNetwork


# Generated at 2022-06-11 03:09:47.760600
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod = AnsibleModule(argument_spec=dict())
    col = AIXNetworkCollector(mod)
    assert col.platform == 'AIX'
    assert col.fact_class == AIXNetwork

# Generated at 2022-06-11 03:09:51.530262
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """ Unit test for method get_default_interfaces of class AIXNetwork """
    AIX_netinfo = AIXNetwork()
    # no routing table defined in AIX, so expecting two empty dicts
    assert (AIX_netinfo.get_default_interfaces(route_path=None)) == ({}, {})

# Generated at 2022-06-11 03:09:52.683811
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    assert AIXNetworkCollector.get_instance() is not None

# Generated at 2022-06-11 03:10:01.201457
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_ifconfig_path = '/usr/sbin/ifconfig'


# Generated at 2022-06-11 03:10:06.363093
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    network = AIXNetwork(module)
    assert network.get_default_interfaces('/route') == ({'gateway': '195.213.242.1', 'interface': 'en0'},
                                                        {'gateway': 'fe80::aaf3:e2ff:fefe:12ed', 'interface': 'en0'})

# Generated at 2022-06-11 03:10:07.974855
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:10:16.799757
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    mod_path = module.get_bin_path('netstat')
    if mod_path:
        cmd = [mod_path, '-nr']
        (rc, out, err) = module.run_command(cmd)
        if rc != 0:
            module.fail_json(msg='Error running netstat: %s' % cmd, stdout=out, stderr=err, rc=rc)
        iface = AIXNetwork.get_default_interfaces(None, None)
        lines = out.splitlines()
        for line in lines:
            words = line.split()
            if len(words) > 1 and words[0] == 'default':
                if '.' in words[1]:
                    iface_v4 = iface[0]

# Generated at 2022-06-11 03:10:18.904419
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector.

    Test if it returns the AIXNetworkCollector object.
    """
    assert isinstance(AIXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-11 03:11:48.545929
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector
    assert isinstance(collector._fact_class, AIXNetwork)

# Generated at 2022-06-11 03:11:57.532092
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_info = dict()

    network_info['interface'] = dict()
    network_info['all_ipv4_addresses'] = []
    network_info['all_ipv6_addresses'] = []

    def retrieve_options(words):
        opts = dict()
        for tag in words:
            if '=' in tag:
                tag_value = tag.split('=')
                opts[tag_value[0]] = tag_value[1]
            elif tag.startswith('-'):
                opts[tag] = True
        return opts

    # parse_status_line
    network_info['interface']['device'] = 'en0'
    network_info['interface']['status_list'] = []

# Generated at 2022-06-11 03:12:05.182763
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    aix_network = AIXNetwork(test_module)
    aix_network.route_path = '/usr/bin/netstat'

    # test that gateway is found with full table
    assert aix_network.get_default_interfaces(aix_network.route_path) == ({}, {})

    # test that gateway is found with empty table
    assert aix_network.get_default_interfaces(aix_network.route_path) == ({}, {})

    # test that no gateway is found with missing table
    assert aix_network.get_default_interfaces(aix_network.route_path) == ({}, {})



# Generated at 2022-06-11 03:12:06.270046
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-11 03:12:10.367875
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    assert issubclass(AIXNetworkCollector._fact_class, GenericBsdIfconfigNetwork)
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-11 03:12:14.707025
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform is 'AIX'


# Generated at 2022-06-11 03:12:20.732004
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # stub the required module class variables and methods
        facts = AIXNetwork()
        facts.module = mock_module = MagicMock()

# Generated at 2022-06-11 03:12:31.123839
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import AIXNetwork

    interface = AIXNetwork()
    interface.module = FakeAnsibleModule()
    interface.module.run_command = run_command

    # netstat command
    setattr(interface.module, 'run_command', netstat_command)
    
    # ifconfig command
    rc, out, err = ifconfig_command()
    rc, out, err = interface.get_interfaces_info(ifconfig_path='fake_path')
    assert rc == 0
    assert len(out) == 5
    assert err == []

    keys = list(out.keys())
    assert 'en0' in keys
    assert 'lo0' in keys
    assert out['lo0']['device'] == 'lo0'
    assert out['en0']['device']

# Generated at 2022-06-11 03:12:41.034377
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.params = ''
            self.fail_json = ''
            self.run_command = ''
        def get_bin_path(self, path, required=False):
            return 'bin_path'

    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    module = MockModule()
    network_collector = AIXNetwork(module)


# Generated at 2022-06-11 03:12:45.433632
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is only for unit test.
    """
    m_module = MockModule()
    aix_network_collector = AIXNetworkCollector(m_module)
    assert aix_network_collector.platform == 'AIX'
    assert aix_network_collector.fact_class == AIXNetwork