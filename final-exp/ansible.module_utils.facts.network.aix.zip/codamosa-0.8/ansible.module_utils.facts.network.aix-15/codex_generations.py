

# Generated at 2022-06-11 03:04:30.812189
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    def run_command(args):
        out = ""
        if args[1] == '-nr':
            out = "default 192.0.2.1 UG  0 0 en0\n" \
                  "default fe80::1%lo0 UG  0 0 lo0"
        return 0, out, ""

    def get_bin_path(arg):
        if arg == 'netstat':
            return 'netstat'
        return None

    module = type('AnsibleModule', (object,), {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
    })()

    network = AIXNetwork(module=module)

    # Basic check

# Generated at 2022-06-11 03:04:33.449404
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork
    assert collector.config == dict()

# Generated at 2022-06-11 03:04:37.025901
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # AIX has no constructor arguments
    facts = AIXNetworkCollector()
    assert isinstance(facts, AIXNetworkCollector)
    assert isinstance(facts.facts, AIXNetwork)


# Generated at 2022-06-11 03:04:46.164382
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    sys.path.append('/root/ansible/lib/')
    from ansible.module_utils.facts.network.aix import AIXNetwork

    an = AIXNetwork()

    an.module.run_command = lambda command, check_rc: (0, LINES_AIX_IFCONFIG, '')

    interfaces, ips = an.get_interfaces_info('ifconfig', '')
    print("interfaces, ips:", interfaces, ips)

# Generated at 2022-06-11 03:04:48.208447
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:04:58.950384
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class AIXNetwork'''
    def mockmodule():
        '''Mock module'''
        return None

    mockmodule.run_command = lambda args, check_rc=True: (0, '', '')
    mockmodule.get_bin_path = lambda args, opt_dirs: ''
    aixif = AIXNetwork(mockmodule)
    # create a dictionary of mock interfaces
    interfaces_mock = {}
    # the test uses the same list of interfaces as the one used by GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:05:04.458126
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork_default_interfaces = AIXNetwork().get_default_interfaces('')
    assert AIXNetwork_default_interfaces == ('', ''), 'test_AIXNetwork_get_default_interfaces is failed'
    print('test_AIXNetwork_get_default_interfaces is passed')


# Generated at 2022-06-11 03:05:11.664834
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    def test_fixture(mocker, test_data, expected_result):
        # pylint: disable=unused-argument
        net = AIXNetwork()
        net.module = mocker.Mock()
        net.module.run_command = mocker.Mock()
        net.module.run_command.return_value = (0, test_data, '')
        net.module.get_bin_path = mocker.Mock()
        net.module.get_bin_path.return_value = '/usr/bin/netstat'
        route_path = '/usr/sbin/route'
        assert net.get_default_interfaces(route_path) == expected_result


# Generated at 2022-06-11 03:05:19.253375
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Mock module with zero return code
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = Mock(return_value=(0, '', ''))

    # Run the function under test
    result = AIXNetwork._fact_class.get_default_interfaces(module)
    print(result)

    # Test the result
    assert result == ({'gateway': '10.10.10.1', 'interface': 'lo0'}, {'gateway': 'fe80::1%lo0', 'interface': 'lo0'})


# Generated at 2022-06-11 03:05:29.626367
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestAIXNetwork():
        def __init__(self):
            self.module = None

    t = TestAIXNetwork()
    t.module = AnsibleModule(argument_spec={
        'command': {'type': 'str', 'default': 'netstat'},
        'options': {'type': 'str', 'default': '-nr'},
    })

    net = AIXNetwork(module=t.module)

    # Test route_path = 'netstat -rn'
    v4, v6 = net.get_default_interfaces('netstat -rn')

# Generated at 2022-06-11 03:05:46.779325
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_net = AIXNetwork()
    assert aix_net.get_default_interfaces('/bin/netstat') == ({'gateway': '192.168.1.1', 'interface': 'en0'},
                                                              {'gateway': 'fe80::2:1', 'interface': 'lo0'})

# Generated at 2022-06-11 03:05:51.623919
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module=module)
    assert network.get_default_interfaces('/usr/bin/netstat') == ({'gateway': u'10.50.195.1', 'interface': u'en1'},
                                                                  {'gateway': u'fe80::21a:6cff:fe46:fe6',
                                                                   'interface': u'en1'})


# Generated at 2022-06-11 03:05:53.806179
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:58.792536
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    platform_facts = dict(
        distribution=dict(
            name='AIX',
        ),
    )
    network_collector = AIXNetworkCollector(module=None, platform_facts=platform_facts)
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork

# Generated at 2022-06-11 03:06:09.540189
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This test tests the following cases:
    - if netstat outputs the gateway and interface for v4 and v6
    - if netstat outputs the gateway and interface only for v4
    - if netstat outputs the gateway and interface only for v6
    - if netstat outputs nothing
    """
    def setUp(self):
        """
        This method defines the variables used in the tests
        """
        self.netstat_path = '/usr/bin/netstat'
        self.netstat_output_path = 'tests/unittests/network/output/netstat'
        self.netstat_v4v6_output_path = os.path.join(self.netstat_output_path, 'v4+v6')

# Generated at 2022-06-11 03:06:11.302006
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    interface = net.get_default_interfaces(None)
    print("Interface (gateway, interface, macaddress): %s, %s, %s" % (interface[0]['gateway'], interface[0]['interface'], interface[0]['macaddress']))

# Generated at 2022-06-11 03:06:19.685177
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Testing for class AIXNetwork.
    Method get_interfaces_info.
    """

# Generated at 2022-06-11 03:06:30.864149
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:41.638012
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    # First line of ifconfig -a is a header
    ifconfig_output = """lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232
        index 1
        inet 127.0.0.1 netmask 0xff000000
        options=3<RXCSUM,TXCSUM>
        inet6 ::1%1/0
        inet6 fe80::1%1/10
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
"""


# Generated at 2022-06-11 03:06:49.565388
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import collector

    module = FakeAnsibleModule()

    collector._collectors['network.aix'] = AIXNetworkCollector(module)

    aixnetwork = AIXNetwork()

    class testenv():
        def __init__(self, defaultv4_interface, defaultv4_gateway, defaultv6_interface, defaultv6_gateway):
            self.defaultv4_interface = defaultv4_interface
            self.defaultv4_gateway = defaultv4_gateway
            self.defaultv6_interface = defaultv6_interface
            self.defaultv6_gateway = defaultv6_gateway

        def __enter__(self):
            aixnetwork.module.run_command = self.run_command

        def __exit__(self, *args):
            a

# Generated at 2022-06-11 03:07:16.744275
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    results = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    results['interfaces'] = dict()
    my_obj = AIXNetworkCollector(module=None, collected_facts=results)
    assert my_obj.facts == {}

# Generated at 2022-06-11 03:07:26.359967
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix.AIXNetwork import AIXNetwork


# Generated at 2022-06-11 03:07:34.245400
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    result = []

# Generated at 2022-06-11 03:07:39.328193
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class.
    """
    module = AnsibleModuleMock()
    network_module = AIXNetworkCollector(module=module)
    assert network_module.platform == 'AIX'
    assert network_module.fact_class == module.get_network_module_by_platform('AIX').__name__

# Unit tests for method get_default_interfaces

# Generated at 2022-06-11 03:07:45.565316
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    network_module = NetworkCollector.create(AIXNetworkCollector)
    ifconfig_path = network_module.module.get_bin_path('ifconfig')
    if ifconfig_path:
        interfaces, ips = network_module.get_interfaces_info(ifconfig_path)
        print(interfaces)
        print(ips)


if __name__ == '__main__':
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:07:55.169045
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:59.279945
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    test_AIXNet = AIXNetwork(test_module)

    assert_equal(test_AIXNet.get_interfaces_info('/usr/bin/ifconfig'), ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}))

# Generated at 2022-06-11 03:08:02.961643
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from collections import namedtuple
    options = namedtuple('Options', ['gather_subset', 'gather_network_resources'])
    obj = AIXNetworkCollector(None, options(gather_subset='interfaces', gather_network_resources=None))
    assert obj.platform == 'AIX'


# Generated at 2022-06-11 03:08:12.975302
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    options = dict(
        config_options='-a',
        gather_subset=[],
        gather_network_resources=[],
        filters=[],
    )


# Generated at 2022-06-11 03:08:23.228862
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:09:12.267159
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """The following test makes a test for the constructor of NetworkCollector
    """
    # Test for a valid network Collector
    network_collector = AIXNetworkCollector()
    assert network_collector.__class__.__name__ == 'AIXNetworkCollector'

# Generated at 2022-06-11 03:09:15.092301
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Create an instance of class AIXNetworkCollector
    obj = AIXNetworkCollector()

    # Check for class attributes
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'



# Generated at 2022-06-11 03:09:22.773556
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self, rc, out, err, bin_path):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = bin_path

        @staticmethod
        def run_command(args):
            return TestModule.rc, TestModule.out, TestModule.err

        @staticmethod
        def get_bin_path(path):
            return TestModule.bin_path

    class AIXNetwork_testee_for_interfaces_info(AIXNetwork):

        def __init__(self):
            self.module = TestModule(0, '', '', '/fake/bin/path')


# Generated at 2022-06-11 03:09:32.779911
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = GenericBsdIfconfigNetwork

    class MockModule_get_bin_path(object):
        """Class to mock the get_bin_path() method of the module."""
        def __init__(self, value):
            self.value = value

        def __call__(self, *args, **kwargs):
            return self.value

    module_get_bin_path = MockModule_get_bin_path('/usr/sbin/netstat')
    module.get_bin_path = module_get_bin_path

    class MockModule_run_command(object):
        """Class to mock the run_command() method of the module."""
        def __init__(self, stdout_value, rc_value):
            self.stdout_value = stdout_value
            self.rc_value = rc_value



# Generated at 2022-06-11 03:09:41.455676
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModuleMock({})

# Generated at 2022-06-11 03:09:50.485673
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
        Testing for AIXNetwork.get_default_interfaces() method
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork

    aix_network = AIXNetwork(None, None)

    # use fake output of 'netstat -nr' for testing

# Generated at 2022-06-11 03:09:53.165011
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Unit tests for get_default_interfaces method

# Generated at 2022-06-11 03:10:01.987700
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = type('test_module', (object,), dict(run_command=_run_command))()
    test_obj = AIXNetwork(test_module)

    ifconfig_options = '-a'
    test_ifconfig_invalid = '/bin/ifconfigfake'
    test_ifconfig_valid = '/bin/ifconfig'

# Generated at 2022-06-11 03:10:11.680857
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        # required for when module_utils/facts/network/generic_bsd.py is not available
        module_utils_path=['/to/not/exist']
    )
    # default: route_path='/etc/route'
    net = AIXNetwork({'module': module})
    v4, v6 = net.get_default_interfaces('/etc/route')

    expected_v4 = {
        "gateway": "192.168.1.1",
        "interface": "en0",
    }
    assert v4 == expected_v4


# Generated at 2022-06-11 03:10:16.382296
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    AIXNetwork_fact_instance = AIXNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = AIXNetwork_fact_instance.get_interfaces_info(ifconfig_path, ifconfig_options)

    print('interfaces = %s' % interfaces)
    print('ips = %s' % ips)


# Generated at 2022-06-11 03:11:53.030628
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-11 03:11:59.456217
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:05.027259
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector.get_module(params={})
    aixnet = AIXNetwork({'module': module})
    aixnet.get_default_interfaces('/path/to/route') == ({'interface': 'en0', 'gateway': '192.0.2.254'}, {}) or aixnet.get_default_interfaces('/path/to/route') == ({'interface': 'en0', 'gateway': '2001:db8::1'}, {})

# Generated at 2022-06-11 03:12:15.144151
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    aix_network.module = MockModule()
    route_bin = '/usr/sbin/route'
    aix_network.module.get_bin_path = Mock(return_value=route_bin)
    aix_network.module.run_command = Mock(return_value=(0, '', ''))
    route_path = aix_network.module.get_bin_path('route')
    assert route_path == route_bin

    out = '''
default 10.0.0.2
10.0.0.2 link#2
10.1.1.0/24 link#1
'''
    aix_network.module.run_command = Mock(return_value=(0, out, ''))

# Generated at 2022-06-11 03:12:24.813269
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:33.414053
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class Module(object):
        def __init__(self, params=None):
            self.params = params if params is not None else {}

        def run_command(self, args, check_rc=True):
            return 0, '', ''

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/' + name

    class AIXNetwork_2(AIXNetwork):
        def __init__(self, module):
            self.module = module

    module = Module()
    network_collector_aix = AIXNetwork_2(module)
    ifconfig_path = module.get_bin_path('ifconfig')
    interfaces, ips = network_collector_aix.get_interfaces_info(ifconfig_path, 'lo0')

# Generated at 2022-06-11 03:12:41.820813
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None, None, None).collect()
    facts['network'].pop('default_ipv4')
    assert facts == {
        'network': {
            'interfaces': {
                'en0': {
                    'active': True,
                    'device': 'en0',
                    'ipv4': [
                        {'address': '10.121.126.51', 'netmask': '255.255.252.0', 'broadcast': '10.121.127.255'}
                    ],
                    'ipv6': [],
                    'macaddress': 'unknown',
                    'type': 'ether'
                }
            }
        }
    }

# Generated at 2022-06-11 03:12:50.236485
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_AIXNetwork = AIXNetwork()

    rc, out, err = test_AIXNetwork.module.run_command([
        test_AIXNetwork.module.get_bin_path('netstat'), '-nr'])

    assert rc == 0

    test_output = out

    interfaces = test_AIXNetwork.get_default_interfaces('/does/not/matter')

    assert interfaces['v4']['interface'] == 'en1'
    assert interfaces['v4']['gateway'] == '192.168.0.254'
    assert interfaces['v6']['interface'] == 'en1'
    assert interfaces['v6']['gateway'] == 'fe80::1%en1'


# Generated at 2022-06-11 03:12:53.507109
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-11 03:13:00.892603
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = Facts(
        dict(
            ANSIBLE_SYSTEM_HOSTNAME='localhost',
            ANSIBLE_FACTS=dict(),
        )
    )
    result = AIXNetworkCollector(module).collect()
    assert 'ansible_facts' in result
    assert result['ansible_facts'].get('ansible_net_all_ipv4_addresses') is None