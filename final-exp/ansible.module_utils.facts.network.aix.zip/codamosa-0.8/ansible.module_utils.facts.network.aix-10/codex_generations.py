

# Generated at 2022-06-11 03:04:30.279439
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = get_faked_module(dict(default_text='default 0.0.0.0 UG 0 0 0 en0',
                                   ipv6_text='default fe80::%lo0 UG 0 0 0 lo0'))
    network = AIXNetwork(module=module)
    v4_route, v6_route = network.get_default_interfaces('/proc/net/route')
    assert v4_route['interface'] == 'en0' and v4_route['gateway'] == '0.0.0.0'
    assert v6_route['interface'] == 'lo0' and v6_route['gateway'] == 'fe80::%lo0'



# Generated at 2022-06-11 03:04:31.763237
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector is not NetworkCollector


# Generated at 2022-06-11 03:04:42.458657
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # test1
    words = ['default', '192.168.0.1', 'UGS', '0', 'en0', '8', '0']
    if_ = dict(v4={}, v6={})
    for word in words:
        if word == 'default':
            pass
        elif '.' in word:
            if_['v4']['gateway'] = word
        elif ':' in word:
            if_['v6']['gateway'] = word
        elif word.startswith('en'):
            if_['v4']['interface'] = word
        elif word.startswith('et'):
            if_['v6']['interface'] = word

# Generated at 2022-06-11 03:04:46.991108
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Return the default route interfaces.
    :return: dict(default_ipv4_interface, default_ipv6_interface)
    """
    ifconfig_path = '/sbin/ifconfig'  # test will not run if this is not present
    ifconfig_options = '-a'
    net = AIXNetwork()
    assert net.get_interfaces_info(ifconfig_path, ifconfig_options) is not (None)

# Generated at 2022-06-11 03:04:56.589057
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    # Create an AIXNetwork object
    aixnet = AIXNetwork(module)

    # Create an AIXNetworkCollector object
    aixnc = AIXNetworkCollector(module, [], aixnet)

    # Test method get_default_interfaces on AIXNetworkCollector object
    if_v4, if_v6 = aixnc.get_default_interfaces('/usr/bin/netstat')

    assert if_v4
    assert if_v6


# Generated at 2022-06-11 03:05:05.329906
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'route_path': {'required': True, 'type': 'str'}})
    network_info = AIXNetwork(module)

    route_path = module.params['route_path']
    def_v4, def_v6 = network_info.get_default_interfaces(route_path)

    assert def_v4['interface'] == 'en0'
    assert def_v4['gateway'] == '192.168.1.1'
    assert def_v6['interface'] == 'en0'
    assert def_v6['gateway'] == '2001:0db8:85a3:0000:0000:8a2e:0370:7334'


# Generated at 2022-06-11 03:05:11.288846
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    network_collector = AIXNetwork(module)
    route_path = module.get_bin_path('route')
    v4_default, v6_default = network_collector.get_default_interfaces(route_path)
    assert v4_default['interface'] == 'en0', 'method get_default_interfaces return incorrect v4_default[\'interface\']'
    assert v6_default['interface'] == 'en0', 'method get_default_interfaces return incorrect v6_default[\'interface\']'


# Generated at 2022-06-11 03:05:14.911844
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork_instance = AIXNetwork(None)
    route_path = '/usr/bin/netstat'
    assert AIXNetwork_instance.get_default_interfaces(route_path) == ({}, {})

# Generated at 2022-06-11 03:05:23.888653
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class FactsModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, binary_name, required=False):
            bin_dir = self.params['bin_dir']
            if bin_dir:
                return bin_dir + '/' + binary_name
            else:
                return None

    class FakeModule:
        def __init__(self, params):
            self.params = params
            self.facts = FactsModule(params)

        def run_command(self, cmd):
            if self.params['test_condition'] == 'command':
                return self.params['rc'], self.params['out'], self.params['err']
            else:
                return 0, '', ''

    class Network:
        def __init__(self, params):
            self

# Generated at 2022-06-11 03:05:32.659191
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:05:52.905156
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    class AIXNetworkTest(AIXNetwork):

        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 03:06:00.659708
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    import unittest
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    class TestNetworkCollector(unittest.TestCase):

        def setUp(self):
            self.network_collector = AIXNetworkCollector()

        def test_AIXNetworkCollector(self):
            self.assertEqual(self.network_collector._platform, "AIX")
            self.assertEqual(self.network_collector._fact_class.platform, "AIX")

    unittest.main()


# Generated at 2022-06-11 03:06:11.258590
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class RunModule():
        def __init__(self):
            self.check_mode = False
            self.run_command_calls = []

        def get_bin_path(self, b_path, opt_dirs=[]):
            return b_path

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return (0, 'default 0.0.0.0 UG 0 0 eth0\ndefault default UG 1 0 ue0m0', '')

    class Config():
        def __init__(self):
            self.network_debug = False

    mod = RunModule()
    config = Config()

    ifconfig_path = '/usr/sbin/ifconfig'
    f = AIXNetwork(mod, config)
   

# Generated at 2022-06-11 03:06:13.384528
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    # test whether module is my class
    assert isinstance(module, AIXNetworkCollector)


# Generated at 2022-06-11 03:06:17.391772
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=mod, params=dict())
    assert isinstance(collector, AIXNetworkCollector)
    assert isinstance(collector, NetworkCollector)
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:06:29.286406
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Fake module object
    module = type('', (), {'run_command': lambda *args: (0, out, '')})
    # Tested method
    network = AIXNetwork()
    network.module = module
    interface_info, ips = network.get_interfaces_info('/sbin/ifconfig')
    # Checksum
    checksum = 0
    for key in interface_info.keys():
        keys = interface_info[key].keys()
        keys.sort()
        values = [interface_info[key][key2] for key2 in keys]
        for v in values:
            try:
                checksum += hash(v)
            except TypeError:
                for v2 in v:
                    checksum += hash(v2)
    assert checksum == -1646644969



# Generated at 2022-06-11 03:06:32.643044
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Creates an instance of GenericBsdIfconfigNetwork for testing if the constructor works
    """
    my_obj = AIXNetworkCollector()
    assert my_obj


# Generated at 2022-06-11 03:06:43.715056
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = DummyModule()

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifc = AIXNetwork(module)

    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])

    interfaces, ips = ifc.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert(rc == 0)

    assert('en0' in interfaces)
    assert('en1' not in interfaces)
    assert('lo0' in interfaces)

    assert(interfaces['en0']['device'] == 'en0')
    assert(interfaces['en0']['ipv4'][0]['address'] == '172.16.33.133')

# Generated at 2022-06-11 03:06:50.482668
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()

    # Test 1: output of 'netstat -nr' is empty
    net.module.run_command = mock_run_command([1, '', ''])
    assert net.get_default_interfaces('/sbin/route') == (dict(), dict())

    # Test 2: output of 'netstat -nr' is valid

# Generated at 2022-06-11 03:06:53.608463
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector._platform == 'AIX'
    assert aix_network_collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:07:17.634832
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:07:27.899130
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """This only tests the AIXNetwork.get_interfaces_info() method
    that overrides GenericBsdIfconfigNetwork.get_interfaces_info()"""
    import os
    import sys

    if sys.version_info[0] < 3:
        # For Python 2
        from StringIO import StringIO
    else:
        # For Python 3
        from io import StringIO

    class TestModule(object):
        def __init__(self, fail_json):
            self.fail_json = fail_json
        def run_command(self, args, check_rc=True):
            return 0, '', ''
        def get_bin_path(self, exe, opt_dirs=[]):
            return '/usr/bin/{0}'.format(exe)


# Generated at 2022-06-11 03:07:34.799387
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    platform = 'AIX'
    import os
    import json
    import shutil

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    testdir = os.path.dirname(__file__)
    testdir = os.path.join(testdir, 'AIX_ifconfig_testdata')
    testdir = os.path.abspath(testdir)
    testdir = testdir + '/testdir'
    if not os.path.exists(testdir):
        os.makedirs(testdir)

    olddir = os.getcwd()
    os.chdir(testdir)

    module = MockModuleForNetworkFactsTests(tmpdir=testdir)


# Generated at 2022-06-11 03:07:45.315888
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()

    fake_path = '/bin/ifconfig'

# Generated at 2022-06-11 03:07:54.999878
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import re
    import os
    import tempfile
    import pytest


# Generated at 2022-06-11 03:08:02.320734
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils import facts

    # mock module
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(gather_subset=dict(required=False, default='!all,!min'),
                           gather_network_resources=dict(required=False, type='list', default=['all'])),
        supports_check_mode=True)

    # mock ifconfig
    module.run_command = lambda *_: (0, open('/etc/ansible/facts.d/network_interfaces.out').read(), '')
    module.get_bin_path = lambda *_: '/usr/sbin/ifconfig'

    # mock uname
    module.run_command = lambda *_: (0, '0 AIX', '')
    module.get_bin

# Generated at 2022-06-11 03:08:10.726467
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    import sys
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    dummy_network_collector = NetworkCollector(args={})
    assert type(dummy_network_collector) == NetworkCollector

    aix_network_collector = AIXNetworkCollector(args={})
    assert type(aix_network_collector) == AIXNetworkCollector
    assert aix_network_collector._platform == 'AIX'


# Generated at 2022-06-11 03:08:20.491148
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = 'test/library/facts/aix_ifconfig.txt'
    ifconfig_options = "test/library/facts/aix_ifconfig_options.txt"

    ansible_module = MockAIXModule(ifconfig_path, ifconfig_options)

    aix_network = AIXNetwork('ansible_module')
    interfaces_aix, ips_aix = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)
    for interface in interfaces_aix.values():
        del interface['mtu']    # AIX 'ifconfig -a' does not inform about MTU


# Generated at 2022-06-11 03:08:27.216402
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create some test data
    # data1 - ifconfig without wpars
    # data2 - ifconfig in wpar
    # data3 - ifconfig with wpars
    # data4 - ifconfig with en0 and en1
    osname = 'AIX'
    bin_path = '/sbin'

# Generated at 2022-06-11 03:08:35.672008
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class FakeModule(object):
        def run_command(self, args):
            if args[0] == '/usr/sbin/ifconfig':
                if args[1] == '-a':
                    return (0, ifconfig_a_output, '')
                elif args[1] == '-m':
                    return (0, ifconfig_m_output, '')
                elif args[1] == '-m6':
                    return (0, ifconfig_m6_output, '')
            elif args[0] == '/usr/bin/netstat' and args[1] == '-nr':
                return (0, netstat_nr_output, '')
            return (-1, '', '')

        def get_bin_path(self, arg):
            return '/usr/sbin/ifconfig'

   

# Generated at 2022-06-11 03:09:32.328458
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:09:41.110436
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, OUTPUT_AIX_IFCONFIG_A, ''))
    aix_network = AIXNetwork(mock_module)
    (interfaces, ips) = aix_network.get_interfaces_info('/usr/bin/ifconfig', '-a')
    assert interfaces == EXPECTED_INTERFACES_AIX_IFCONFIG_A
    assert ips == EXPECTED_IPS_AIX_IFCONFIG_A



# Generated at 2022-06-11 03:09:45.974465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces_info = AIXNetwork().get_interfaces_info('/usr/sbin/ifconfig')
    assert interfaces_info[0]['lo0']
    assert interfaces_info[0]['lo0']['macaddress'] == 'unknown'
    assert interfaces_info[0]['lo0']['mtu'] == '65536'
    assert interfaces_info[0]['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces_info[0]['lo0']['ipv6'][0]['netmask'] == 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'
    assert interfaces_info[0]['lo0']['ipv6'][1]['address'] == 'fe80::1%lo0'

# Generated at 2022-06-11 03:09:49.198694
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'



# Generated at 2022-06-11 03:09:56.339692
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    testmod = AIXNetwork()

# Generated at 2022-06-11 03:10:05.955720
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class AnsibleModule:
        def get_bin_path(self, arg, **kwargs):
            if arg == 'netstat':
                return '/usr/sbin/netstat'
            return None


# Generated at 2022-06-11 03:10:10.683554
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork



# Generated at 2022-06-11 03:10:18.645699
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    # This is the output of '/usr/bin/ifconfig -a' on AIX 7.2 TL2 SP2

# Generated at 2022-06-11 03:10:21.226483
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_net_collector = AIXNetworkCollector()

    assert aix_net_collector._fact_class == AIXNetwork
    assert aix_net_collector._platform == 'AIX'



# Generated at 2022-06-11 03:10:21.709522
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True

# Generated at 2022-06-11 03:12:02.515534
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_params = dict(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )

    test_obj = AIXNetwork(module=None, params=test_params)


# Generated at 2022-06-11 03:12:12.704981
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = FakeModule()

    netstat_rc = 0

# Generated at 2022-06-11 03:12:15.634871
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod = AnsibleModule(argument_spec=dict())
    mod.exit_json = lambda x: x
    obj = AIXNetworkCollector(module=mod)
    assert 'AIXNetwork' in str(obj)


# Generated at 2022-06-11 03:12:25.386506
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info('ifconfig', ifconfig_options='-a')

    # remove 'interfaces' items that differ by each system
    if 'lo0' in interfaces:
        interfaces.pop('lo0')

    # remove 'ips' items that differ by each system
    if 'all_ipv4_addresses' in ips:
        ips.pop('all_ipv4_addresses')

    if 'all_ipv6_addresses' in ips:
        ips.pop('all_ipv6_addresses')


# Generated at 2022-06-11 03:12:33.680720
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:43.858825
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class ModuleStub:
        def get_bin_path(self, name):
            return '/usr/bin/netstat'
        def run_command(self, args):
            if args[0] == '/usr/bin/netstat':
                return (0,
'''default 0.0.0.0 UG 2 0 0 en1
default 2001:db8::/64 UG 2 0 0 en1
''', '')

    class NetworkCollectorStub:
        module = ModuleStub()

    aixnetwork = AIXNetwork(NetworkCollectorStub())

    # Test IPv4 and IPv6 default gateway
    default_interface = aixnetwork.get_default_interfaces('/etc/route')

# Generated at 2022-06-11 03:12:52.934486
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    Test method AIXNetwork.get_default_interfaces
    '''
    import os
    import tempfile

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file with contents
    route_path = os.path.join(tmpdir, 'netstat-nr')
    with open(route_path, 'w') as f:
        f.write('''
default 172.20.200.1 UGS 0 803 en1
default fe80::%en1 UGS
''')

    # Create AIXNetwork collector object
    aixn = AIXNetwork(module)

    # call get_default_interfaces and check the result
    v4, v

# Generated at 2022-06-11 03:12:55.807697
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector must create a subclass of NetworkCollector
    """
    aix_network_collector = AIXNetworkCollector(None, None, None)
    assert isinstance(aix_network_collector, NetworkCollector)

# Generated at 2022-06-11 03:13:06.118842
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import yaml
    from ansible.module_utils.facts.network.aix import AIXNetwork


# Generated at 2022-06-11 03:13:14.900365
# Unit test for method get_interfaces_info of class AIXNetwork