

# Generated at 2022-06-11 03:04:30.754930
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class TestModule:
        def __init__(self):
            self.run_command_results = [
                (
                    0,
                    "default 192.168.0.1 UGZ 0 3 nge0\n"
                    "default 192.168.0.1 UGZ 0 3 en0\n"
                    "default 20aa:11bb:22cc:33ff::/64 UGZ 0 3 en0\n"
                    "default fe80::/64 UGZ 0 3 en0\n",
                    '',
                ),
            ]
            self.run_command_index = 0

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, check_rc=False):
            res = self.run_command_results[self.run_command_index]
           

# Generated at 2022-06-11 03:04:31.350468
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    return 0

# Generated at 2022-06-11 03:04:42.018045
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    network_facts.AIXNetwork.get_default_interfaces() Test
    """
    # Test 1: netstat returns empty string
    module = NetworkCollector()
    module.run_command = mock_run_command_empty_string
    interface = dict(v4={}, v6={})
    route_path = '/usr/bin/netstat'
    network = AIXNetwork()

    interface['v4'], interface['v6'] = network.get_default_interfaces(route_path)

    assert interface['v4']['gateway'] == None
    assert interface['v4']['interface'] == None
    assert interface['v6']['gateway'] == None
    assert interface['v6']['interface'] == None

    # Test 2: netstat returns line with IPV4
    module = Network

# Generated at 2022-06-11 03:04:47.202314
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_net = AIXNetwork()
    aix_net.module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            config=dict(required=False, type='list'))
    )

    ifconfig_path = aix_net.module.get_bin_path('ifconfig')

    if config_path:
        aix_net.get_interfaces_info(ifconfig_path, ifconfig_options='-a')

# Generated at 2022-06-11 03:04:51.529248
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert isinstance(AIXNetworkCollector._fact_class(), AIXNetwork)
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)


# Generated at 2022-06-11 03:04:54.817865
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-11 03:05:04.833106
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
           argument_spec=dict(
                gather_subset=dict(default=['!all'], type='list')
           )
    )

    # Create an instance of AIXNetworkCollector
    nc = AIXNetworkCollector(module=module)
    # Get default network route
    v4, v6 = nc.collect()
    # Test the gateway and interface for the IPv4 route
    for key in v4.keys():
        if key.startswith('default_ipv4'):
            assert v4[key]['gateway'] == '172.22.1.1'
            assert v4[key]['interface'] == 'en0'

    # Test the gateway and interface for the IPv6 route

# Generated at 2022-06-11 03:05:11.904388
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Object():
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    def get_bin_path(path):
        return '/usr/sbin/' + path

    def run_command(args):
        if args == ['/usr/sbin/ifconfig', '-a']:
            return 0, OUTPUT, ""
        elif args == ['/usr/sbin/uname', '-W']:
            return 0, '0', ""
        elif args == ['/usr/sbin/netstat', '-nr']:
            return 0, NETSTAT_NR, ""
        elif args == ['/usr/sbin/entstat', 'en0']:
            return 0, ENTSTAT, ""

# Generated at 2022-06-11 03:05:20.667312
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    out = '''
en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
        inet 192.168.1.99 netmask 0xffffff00 broadcast 192.168.1.255
        inet6 fe80::250:56ff:fe9f:7ce%en0 prefixlen 64 scopeid 0x4
        ether 00:50:56:9f:07:ce
        media: autoselect (100baseTX <full-duplex>)
        status: active
'''
    options_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:05:24.602840
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnet = AIXNetwork(None)

    assert aixnet.get_default_interfaces('/sbin/route') == (
        {'gateway': '10.0.2.2', 'interface': 'en0'},
        {}
    )

# Generated at 2022-06-11 03:05:37.647596
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test method for correct initialization of AIXNetworkCollector class
    """

    AIXNetworkCollector()

# Generated at 2022-06-11 03:05:48.027946
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from textwrap import dedent
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import os

    def get_default_interfaces(net, route_path):
        return net.get_default_interfaces(route_path)

    def test_get_default_interfaces(output, expected):
        # output of 'netstat -nr'
        n = AIXNetwork(AnsibleModule(
            argument_spec=dict()
        ))
        _, default = get_default_interfaces(n, None)
        assert default == expected

    output1 = dedent

# Generated at 2022-06-11 03:05:51.096199
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert collector.module == module
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:52.841513
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork()
    network.get_default_interfaces('/usr/sbin/route')

# Generated at 2022-06-11 03:05:54.239203
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.get_facts() is not None

# Generated at 2022-06-11 03:06:05.321504
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class AIXNetwork
    '''
    # initialize test class
    aixnet = AIXNetwork()

    # test IPv4 only
    aixnet.module.run_command.return_value = 0, 'default 172.16.17.1 UG 0 0 en0  ' + \
        'default 172.16.17.1 UG 0 0 en0  ', ''
    assert aixnet.get_default_interfaces('/usr/bin/netstat') == {'interface': 'en0', 'gateway': '172.16.17.1'}, \
        'IPv4 only failed'

    # test IPv6 only

# Generated at 2022-06-11 03:06:14.515321
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec={})
    m._ansible_facts = dict()
    m.params = {}
    m.params['gather_subset'] = 'all'
    m.exit_json = lambda x: x

    ifconfig_path = m.get_bin_path('ifconfig')

    m.run_command = lambda x, check_rc=True: (0, '', '')
    m.run_command.side_effect = [
        (0, '/usr/sbin/netstat', ''),
        (0, '/usr/sbin/netstat', ''),
    ]

    network = AIXNetwork(m)


# Generated at 2022-06-11 03:06:26.669756
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import tempfile
    module = AnsibleModule(argument_spec={})

    ifconfig_path = module.get_bin_path('ifconfig')
    netstat_path = module.get_bin_path('netstat')

    # Temporary directory to hold netstat output
    td = tempfile.mkdtemp()
    netstat_out = "%s/netstat.out" % td

    # Prepare output for netstat -nr
    nf = open(netstat_out, "w")

# Generated at 2022-06-11 03:06:27.904770
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    (isinstance(AIXNetworkCollector().get_network_facts(), dict))

# Generated at 2022-06-11 03:06:36.581471
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []

        def get_bin_path(self, name):
            return '/sbin/route'

        def run_command(self, cmd):
            self.run_command_args.append(cmd)
            return 0, '', ''

    module = MockModule()
    network = AIXNetwork(module)
    network.get_default_interfaces('/sbin/route')
    assert module.run_command_args == [
        ['/sbin/route', '-nr']
    ]

# Generated at 2022-06-11 03:07:04.254542
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = 'default'
    module._socket_path = '/foo'

    network = AIXNetwork(module)
    network.get_default_interfaces('/usr/sbin/route')

    out = module.run_command.call_args[0][0]
    assert out[0] == '/usr/sbin/netstat'
    assert out[1] == '-nr'



# Generated at 2022-06-11 03:07:10.948336
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Create the object
    aixnet = AIXNetwork()

    # Create the parameters
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    # Run the method
    interfaces, ips = aixnet.get_interfaces_info(ifconfig_path, ifconfig_options)

    # Print result
    print("\n\nInterfaces:\n")
    print(interfaces)
    print("\n\nIps:\n")
    print(ips)


# Generated at 2022-06-11 03:07:18.264119
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix.aix_ifconfig_network import AIXNetwork
    my_ifconfig_path = '/usr/sbin/ifconfig'
    my_route_path = '/usr/sbin/route'
    my_netstat_path = '/usr/bin/netstat'
    my_ifconfig_options = '-a'
    dut = AIXNetwork(my_ifconfig_path, my_route_path, my_netstat_path, my_ifconfig_options)


# Generated at 2022-06-11 03:07:28.590330
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:31.018244
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc = AIXNetwork(None)
    mydata = ifc.get_interfaces_info('/usr/bin/ifconfig', '-a')
    assert mydata is not None


# Generated at 2022-06-11 03:07:34.236186
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a = AIXNetworkCollector()
    assert a.platform == 'AIX'
    assert a._fact_class == AIXNetwork
    assert a._platform == 'AIX'

# Generated at 2022-06-11 03:07:44.247752
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    check default gateway output of method get_default_interfaces
    when there is default IPv4 gateway and no default IPv6 gateway
    """
    module = get_module_mock()
    module.run_command = get_run_command_mock(out=open("test/unit/resources/AIX_netstat.txt").read())
    network_collector = AIXNetworkCollector(module)

    net4, net6 = network_collector.get_default_interfaces('AIX_netstat.txt')

    assert net4['gateway'] == '172.17.0.1'
    assert net4['interface'] == 'en0'
    assert net6['gateway'] == None
    assert net6['interface'] == None



# Generated at 2022-06-11 03:07:50.921406
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = NetworkCollector()
    obj = AIXNetwork(module)
    # AIX 'ifconfig -a' does not have three words in the interface line
    ifconfig_path = '/sbin/ifconfig'
    interfaces, ips = obj.get_interfaces_info(ifconfig_path, ifconfig_options='-a')

    assert len(interfaces) > 0
    assert len(interfaces) == len(ips['all_ipv4_addresses']) + len(ips['all_ipv6_addresses'])
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0

    for key in interfaces.keys():
        interface = interfaces[key]
        assert 'device' in interface
        assert 'flags' in interface

# Generated at 2022-06-11 03:07:53.675193
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnet = AIXNetworkCollector(None)
    assert aixnet.platform == 'AIX'
    assert isinstance(aixnet.network, AIXNetwork)

# Generated at 2022-06-11 03:08:00.630842
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    assert 'lo0' in network_data['interfaces']
    assert 'eth0' in network_data['interfaces']
    assert 'eth1' in network_data['interfaces']
    assert 'eth2' in network_data['interfaces']
    assert 'eth3' in network_data['interfaces']
    assert 'eth4' in network_data['interfaces']
    assert 'Fibre' in network_data['interfaces']
    assert 'lo0' in network_data['default_interface']['ipv4']
    assert 'lo0' in network_data['default_interface']['ipv6']


# Generated at 2022-06-11 03:08:45.411755
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    AIXNetwork get_default_interfaces()
    """
    module = NetworkCollector()
    net = AIXNetwork(module)
    route_path = '/usr/bin/netstat'
    net.get_default_interfaces(route_path)



# Generated at 2022-06-11 03:08:55.312036
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Initialize a network object
    network_object = AIXNetwork()

    # Test with route -n
    test_route_path = '/usr/sbin/route'
    test_default_gateway = ('172.16.1.1', 'fe80::21a:89ff:fe08:d835')
    test_default_interface = ('eth0', 'eth0')
    result_default_gateway, result_default_interface = network_object.get_default_interfaces(test_route_path)
    print(result_default_gateway, result_default_interface)

    assert(result_default_gateway == test_default_gateway)
    assert(result_default_interface == test_default_interface)

    # Test with no route

# Generated at 2022-06-11 03:09:03.374991
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = NetworkCollector()

    sys.modules['ansible.module_utils.facts.network.generic_bsd'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.network.generic_bsd'].GenericBsdIfconfigNetwork = mock.Mock()

    sys.modules['ansible.module_utils.facts.network.generic_bsd'].GenericBsdIfconfigNetwork.parse_interface_line = \
        mock.Mock(autospec=True, side_effect=AIXNetwork.parse_interface_line)

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = test_module.run_command([ifconfig_path, ifconfig_options])

    aix_network = AIXNetwork

# Generated at 2022-06-11 03:09:11.466911
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import sys
    import os

    class AnsibleModuleMock:

        def __init__(self, platform, executablePath):
            self.check_mode = False
            self.platform = platform
            self.executablePath = executablePath

        def get_bin_path(self, path):
            return self.executablePath

        def run_command(self, command):
            if isinstance(command, list):
                if command[0] == self.executablePath:
                    if self.platform == 'AIX':
                        return _AIX_netstat_default_interface_test(command)
                    else:
                        return _Linux_netstat_default_interface_test(command)



# Generated at 2022-06-11 03:09:18.887753
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector
    """
    aixcollector = AIXNetworkCollector()
    assert aixcollector.platform == 'AIX'
    assert aixcollector._fact_class.platform == 'AIX'
    assert aixcollector.config == (None, None, None)
    assert aixcollector._config == (None, None, None)
    assert aixcollector.facts == {}
    assert aixcollector._facts == {}
    assert aixcollector._module == None
    assert aixcollector._cache_location == '/dev/null'

# Unit tests for constructor of class AIXNetwork

# Generated at 2022-06-11 03:09:25.069297
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:09:27.554344
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'

# Generated at 2022-06-11 03:09:29.615842
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor test case
    """
    network = AIXNetworkCollector()
    assert network.platform == 'AIX'

# Generated at 2022-06-11 03:09:38.716485
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:09:42.450040
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = None
    result = Collector(module=module, platform='AIX').get_all_facts()

    network_info = result['ansible_net_interfaces']
    for ifname, ifinfo in network_info.items():
        # Check if ifname and ifinfo are strings
        assert isinstance(ifname, str)
        assert isinstance(ifinfo, dict)

        # Check if all keys of ifinfo are strings
        for k, v in ifinfo.items():
            assert isinstance(k, str)


# Generated at 2022-06-11 03:11:07.891552
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test to ensure the constructor for AIXNetworkCollector
    works properly.  It does this by making sure that the platform is
    properly set and it is a subclass of NetworkCollector.
    """
    test_collector = AIXNetworkCollector()
    assert(test_collector.platform == 'AIX')
    assert(issubclass(test_collector.__class__, NetworkCollector))

# Generated at 2022-06-11 03:11:17.297319
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifnet_path = '/usr/sbin/ifconfig'

    ifconfig_options = '-a'
    module = MockModule()
    module.run_command = mock.Mock(return_value=(0, AIX_NETSTAT_OUTPUT, None))
    module.get_bin_path = mock.Mock(return_value=ifnet_path)

# Generated at 2022-06-11 03:11:26.714680
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:11:34.652944
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    print("test_AIXNetwork_get_interfaces_info")

# Generated at 2022-06-11 03:11:37.514509
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    expected_res = {'default_ipv4': {}, 'default_ipv6': {}, 'interfaces': {},
                    'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    assert AIXNetworkCollector()

# Generated at 2022-06-11 03:11:41.786948
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    fake_module = FakeModule({})
    fake_module.run_command = run_command

    aix_network = AIXNetwork(fake_module)
    default_interface  = aix_network.get_default_interfaces('/sbin/route')

    assert default_interface == {'gateway': '10.1.1.1', 'interface': 'en0'}



# Generated at 2022-06-11 03:11:45.427419
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    modmock = AnsibleModuleMock()
    net = AIXNetworkCollector(modmock)
    assert net.platform == 'AIX'
    assert type(net._fact_class) == AIXNetwork
    assert net.module == modmock


# Generated at 2022-06-11 03:11:55.537942
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, command, check_rc=True):
            if command[0] == 'ifconfig':
                if self.params['ifconfig_out'] == 'ifconfig_a_out':
                    out = ifconfig_a_out
                elif self.params['ifconfig_out'] == 'ifconfig_a_out2':
                    out = ifconfig_a_out2
                elif self.params['ifconfig_out'] == 'ifconfig_a_out_no_psuedo_ipv6':
                    out = ifconfig_a_out_no_psuedo_ipv6

# Generated at 2022-06-11 03:11:59.257088
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetworkcollector_obj = AIXNetworkCollector()
    assert aixnetworkcollector_obj
    assert aixnetworkcollector_obj._platform == 'AIX'
    assert aixnetworkcollector_obj._fact_class == AIXNetwork


# Generated at 2022-06-11 03:12:08.186488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Without network interfaces/config, aix.get_interfaces_info() should return an empty list
    def test_no_interfaces():
        # GIVEN
        module = FakeModule(
            params=dict(gather_subset=['all'])
        )
        network_module = AIXNetwork(module)
        # WHEN
        interfaces, _ips = network_module.get_interfaces_info('/sbin/ifconfig')
        # THEN
        assert not interfaces
    test_no_interfaces()

    # With a working network interface, aix.get_interfaces_info() should return a list with the interface
    def test_with_interface():
        # GIVEN
        module = FakeModule(
            params=dict(gather_subset=['all'])
        )
        network_module = AIX