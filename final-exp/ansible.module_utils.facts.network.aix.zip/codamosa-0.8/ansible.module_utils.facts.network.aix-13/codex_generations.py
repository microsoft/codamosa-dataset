

# Generated at 2022-06-11 03:04:26.316877
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert result.platform == 'AIX'
    assert result._fact_class is AIXNetwork

# Generated at 2022-06-11 03:04:36.705925
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    net_collector = NetworkCollector()
    net_collector.module = module
    network = AIXNetwork()
    network.module = module
    interfaces, routes = network.get_interfaces_and_routes()
    assert 'default' in routes.keys()
    assert 'destination' in routes['default'].keys()
    assert 'gateway' in routes['default'].keys()
    assert routes['default']['destination'] == '0.0.0.0'
    assert 'default' in interfaces.keys()
    assert 'gateway' in interfaces['default'].keys()
    assert interfaces['default']['gateway'] == routes['default']['gateway']


# Generated at 2022-06-11 03:04:42.372820
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test constructor of class AIXNetworkCollector
    """
    module = AnsibleModule(
        argument_spec=dict(),
    )

    collector = AIXNetworkCollector(module)

    # Test _fact_class attribute of class AIXNetworkCollector
    assert collector.fact_class.platform == 'AIX'
    # Test _platform attribute of class AIXNetworkCollector
    assert collector.platform == 'AIX'

# Generated at 2022-06-11 03:04:49.495318
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:04:56.386953
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert hasattr(result, 'fact_class')
    assert hasattr(result, 'platform')
    assert hasattr(result, 'config')
    assert hasattr(result, 'facts')

    # The following assertions are used only to distinguish the result
    # of test_NetworkCollector() (which should be tested first).
    assert result.fact_class == AIXNetwork
    assert result.platform == 'AIX'


# Generated at 2022-06-11 03:04:57.752792
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)



# Generated at 2022-06-11 03:04:59.103053
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert 'AIXNetwork' in str(network_collector._fact_class)

# Generated at 2022-06-11 03:05:09.247761
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = list()

# Generated at 2022-06-11 03:05:11.030452
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-11 03:05:20.161407
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_file_dir = os.path.dirname(os.path.abspath(__file__))
    test_fixtures_dir = os.path.join(test_file_dir, 'fixtures')
    result_file = os.path.join(test_fixtures_dir, 'ansible_ifconfig_aix.txt')
    expected_result_file = os.path.join(test_fixtures_dir, 'expected_ansible_ifconfig_aix.txt')

    ifconfig_path = '/usr/sbin/ifconfig'

    ifconfig_out = ''
    if os.path.isfile(result_file):
        with open(result_file) as fr:
            for line in fr.readlines():
                ifconfig_out += line

# Generated at 2022-06-11 03:05:42.377267
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class When(object):
        def __init__(self):
            self.module = When
            self.module.run_command = When.run_command
            self.module.get_bin_path = When.get_bin_path
            self.facts = {}
            self.network = AIXNetwork.get_instance(self.module)
            self.route_path = '/usr/bin/netstat'


# Generated at 2022-06-11 03:05:51.562348
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    obj = AIXNetwork({}, module)

    search_str1 = '^en0: flags=a8963<UP,BROADCAST,NOTRAILERS,RUNNING,PROMISC,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN> mtu 1500 index 1'
    search_str2 = '^en9: flags=a8963<UP,BROADCAST,NOTRAILERS,RUNNING,PROMISC,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN> mtu 1500 index 2'

# Generated at 2022-06-11 03:05:53.365294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a = AIXNetworkCollector()
    assert a._platform == 'AIX'


# Generated at 2022-06-11 03:05:55.121421
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector is not None


# Generated at 2022-06-11 03:06:03.918806
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_network = AIXNetworkCollector.collect()

    assert 'ansible_facts' in fact_network and\
        fact_network['ansible_facts']['ansible_net_interfaces'] == fact_network['ansible_facts']['ansible_all_ipv4_addresses'].keys()

    assert 'ansible_facts' in fact_network and\
        fact_network['ansible_facts']['ansible_default_ipv4'] == fact_network['ansible_facts']['ansible_default_ipv6']

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-11 03:06:07.829133
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Unit test for contructor of class AIXNetworkCollector"""

    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-11 03:06:09.445831
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'

# Generated at 2022-06-11 03:06:16.892562
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # create instances of class AIXNetwork
    aixNetwork = AIXNetwork()

    # save the real popen object before mocking it
    real_popen = aixNetwork.module.popen

    # mock the module.popen object

# Generated at 2022-06-11 03:06:22.080157
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fact_class = AIXNetwork()
    (interface_v4, interface_v6) = fact_class.get_default_interfaces('/usr/sbin/route')
    # just test that returned objects are dicts
    assert isinstance(interface_v4, dict)
    assert isinstance(interface_v6, dict)


# Generated at 2022-06-11 03:06:30.551996
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', required=False),
        'gather_network_resources': dict(type='list', required=False),
    })
    aix_network = AIXNetwork(test_module)
    v4_default, v6_default = aix_network.get_default_interfaces('/some/path')
    assert 'gateway' in v4_default
    assert 'interface' in v4_default
    assert 'gateway' in v6_default
    assert 'interface' in v6_default

# Generated at 2022-06-11 03:06:55.398302
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'
    assert AIXNetworkCollector._fact_class(None).platform == 'AIX'

# Generated at 2022-06-11 03:07:05.550987
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    test_module = {
        'get_bin_path': lambda x: '/usr/sbin/netstat'
    }

    test_lines = [
        'Routing tables',
        '',
        'Internet:',
        'default         172.20.233.1      UG        2 174525 en0',
        '127             127.0.0.1         UH        1       0 lo0',
        '169.254          link#6            UC       0        0 en0       ',
        '172.20          link#8            UC       4 3276835 en0       ',
        '172.20.233.0    00:10:5a:40:c3:58 U         3 174525 en0        ',
    ]

    test_out = '\n'.join(test_lines)

    test_AIX

# Generated at 2022-06-11 03:07:13.991583
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    return_value = dict()
    return_value['ansible_facts'] = dict()
    return_value['ansible_facts']['ansible_net_interfaces'] = dict()

    network = AIXNetwork()
    network.get_default_interfaces("/usr/sbin/route")
    interface = network.default_interface
    return_value['ansible_facts']['ansible_net_interfaces']['en1'] = interface['v4']

    assert return_value == {'ansible_facts': {'ansible_net_interfaces': {'en1': {'gateway': '192.168.56.1', 'interface': 'en1'}}}}


# Generated at 2022-06-11 03:07:14.637215
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)


# Generated at 2022-06-11 03:07:18.239113
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    result = AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    assert result != None
    result = AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig', '-a en0')
    assert result != None
    result = AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig', '-a lo0')
    assert result != None

# Generated at 2022-06-11 03:07:21.572815
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    result = repr(aix_network_collector)
    assert result == "AIXNetworkCollector:{'_fact_class': 'AIXNetwork', '_platform': 'AIX'}"


# Generated at 2022-06-11 03:07:28.022494
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be invoked without exception.
    """
    AIXNetworkCollector()

# Instantiate the network subclass to make it easier to test
_aix_subclass_instance = AIXNetworkCollector()._fact_class(dict(ansible_facts={'ansible_module': 'mock_a'},
                                                                module='mock_b'))


# Generated at 2022-06-11 03:07:34.857635
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, 'default 192.168.1.1 UG 0 0 0 en0\ndefault 2001:db8::1 UG 0 0 0 en0', '')
    module_mock.get_bin_path.return_value = '/usr/bin/netstat'
    module_mock.params = dict(
        route_path = "/usr/bin/route",
        ifconfig_path = "/usr/sbin/ifconfig"
    )

    network = AIXNetwork(module_mock)
    v4, v6 = network.get_default_interfaces(module_mock.params['route_path'])
    assert {'interface': 'en0', 'gateway': '192.168.1.1'}

# Generated at 2022-06-11 03:07:45.358753
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    print("*** Testing AIXNetwork.get_default_interfaces")
    if_out = open('/tmp/netstat.out', 'w')

# Generated at 2022-06-11 03:07:55.084907
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:08:44.180375
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    (interface_ipv4, interface_ipv6) = AIXNetwork().get_default_interfaces('/sbin/route')
    assert 'interface' in interface_ipv4
    assert 'gateway' in interface_ipv4
    assert 'interface' in interface_ipv6
    assert 'gateway' in interface_ipv6

# Generated at 2022-06-11 03:08:46.497845
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_obj = AIXNetwork(module)
    network_obj.get_default_interfaces('')


# Generated at 2022-06-11 03:08:51.212020
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('/bin/netstat') == ({'interface': 'en0',
                                                                    'gateway': '10.10.10.1'},
                                                                    {'interface': 'en0',
                                                                    'gateway': 'fe80::21f:8aff:fe4d:9d63'})

# Generated at 2022-06-11 03:09:00.459191
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''Test for AIXNetwork.get_interfaces_info()'''
    module = DummyModule()
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

    aix_network = AIXNetwork()

    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)

    current_if = {}
    for line in out.splitlines():
        words = line.split()
        if line and re.match(r'^\w*\d*:', line):
            current_if = aix_network.parse_interface_line(words)
            assert (current_if['device'] in interfaces)
           

# Generated at 2022-06-11 03:09:08.405474
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    out_good1 = """
     Destination       Gateway            Flags   Refs   Use  If  Pmtu   Window  IRTT
     default           192.168.1.1        UG        0  31939 en0   -      -      -
     default           xxxx:xxxx:xxxx::1 UG        0  31939 en0   -      -      -
    """
    out_good2 = """
     Destination       Gateway            Flags   Refs   Use  If  Pmtu   Window  IRTT
     default           192.168.1.1        UG        0  31939 xxxxxx   -      -      -
     default           xxxx:xxxx:xxxx::1 UG        0  31939 yyyyyyy   -      -      -
    """

# Generated at 2022-06-11 03:09:13.826384
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import test_AIXNetworking
    m = test_AIXNetworking()
    an = AIXNetwork()
    interfaces, ips = an.get_interfaces_info(m.ifconfig_path, m.ifconfig_options)
    m.assertEqual(m.interfaces, interfaces)
    m.assertEqual(m.ips, ips)

# Generated at 2022-06-11 03:09:19.179099
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os.path

    mock_module = MockModule({'PATH': os.path.curdir})
    aixnetwork = AIXNetwork(mock_module)

    route_path = '/usr/bin/route'
    mock_module.run_command = Mock(return_value=(0, '', ''))
    v4, v6 = aixnetwork.get_default_interfaces(route_path)
    assert v4 is not None
    assert v6 is not None

# Generated at 2022-06-11 03:09:27.834252
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:09:30.191986
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnet = AIXNetworkCollector()
    assert aixnet.platform == 'AIX'
    assert aixnet._fact_class.platform == 'AIX'

# Generated at 2022-06-11 03:09:34.416170
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is used as a constructor test. It tests the instantiation
    of the AIXNetworkCollector object
    """
    network_collector_obj = AIXNetworkCollector()
    assert network_collector_obj.platform == 'AIX'

# Unit test get_interfaces_info function 

# Generated at 2022-06-11 03:11:08.356602
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec = dict())
    net_os = dict()
    net_os['distribution'] = dict()
    net.module.params['gather_subset'] = ['!all']
    net_os['distribution']['name'] = 'AIX'
    net.module._socket_path = '/path/to/socket'
    net.get_default_interfaces(route_path)

# Generated at 2022-06-11 03:11:17.713385
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = get_module_mock()

    route_path = '/usr/sbin/router'
    net.module.path_exists.return_value = True

    # Default netstat output.
    # In this case, there is no default interface
    net.module.run_command.return_value = 0, 'test', None
    assert net.get_default_interfaces(route_path) == ({}, {})

    # Check for IPv4 and IPv6 interfaces
    net.module.run_command.return_value = 0, 'test\ndefault 1.2.3.1 UG rl0\n', None

# Generated at 2022-06-11 03:11:20.280471
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    aixnetwork = AIXNetwork(module)
    aixnetwork.get_interfaces_info(module.get_bin_path('ifconfig'))



# Generated at 2022-06-11 03:11:28.802465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.utils import get_sys_info, parse_sys_info
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os

    # read sample 'ifconfig -a' output
    filename = os.path.join(os.path.dirname(__file__), 'ifconfig_a.txt')
    fd = open(filename, 'r')
    out = fd.read()
    fd.close()
    rc = 0

    module = get_sys_info(platform='AIX', network_class='AIXNetwork')
    an = AIXNetwork(module)
    interfaces, ips = an.get_interfaces_info(None, None)


# Generated at 2022-06-11 03:11:34.184075
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This unit test tests the constructor of the class AIXNetworkCollector.
    """
    results = {}
    results['interfaces'] = {}
    results['default_ipv4'] = {}
    results['default_ipv6'] = {}

    # instantiate NetworkCollector with the new class AIXNetworkCollector:
    network_collector_aix = NetworkCollector(module=None, collected_facts=results, fact_class=AIXNetwork)

    # results should be:
    print()
    print(sys.modules[__name__])
    print(network_collector_aix.__dict__)
    print()

# Generated at 2022-06-11 03:11:41.998565
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MagicMock()
    network = AIXNetwork(module)
    network.module.run_command = MagicMock(return_value=(0, '', ''))

    file_name = 'ifconfig_aix_example'
    file_path = 'ansible/module_utils/facts/network/{}'.format(file_name)
    with open(file_path, 'r') as f:
        output = f.read()

    network.module.run_command.return_value=(0, output, '')
    interfaces, ips = network.get_interfaces_info(network.module.get_bin_path('ifconfig'), network.get_ifconfig_options)

# Generated at 2022-06-11 03:11:48.589842
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockModule()
    config = dict()
    config['route_path'] = '/usr/sbin/route'
    ansible_net_gather_network_resources = AIXNetwork(module)
    default_interfaces = ansible_net_gather_network_resources.get_default_interfaces(config['route_path'])
    assert default_interfaces == ('192.168.1.1', '192.168.2.1')


# Mock class to simulate AnsibleModule

# Generated at 2022-06-11 03:11:49.972497
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector

# Generated at 2022-06-11 03:11:51.547885
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.get_default_interfaces('/sbin/route')

# Generated at 2022-06-11 03:11:58.940282
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module)