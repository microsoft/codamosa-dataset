

# Generated at 2022-06-11 03:04:30.484374
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # dict with customized values for module arguments
    module_args = dict(
        config_dir='/etc/ansible',
        remote_tmp='/tmp/ansible',
        unique_facts=True,
        gather_subset=['!all', '!min'],
        fact_path=['/path1', '/path2']
    )

    # generate dummy ansible result from the given module arguments
    module_ret = dict(
        ansible_facts={},
        ansible_facts_d={},
        changed=False,
        skipped=False
    )

    # dummy path for ifconfig
    ifconfig_path = '/usr/sbin/ifconfig'

    # dummy output for ifconfig

# Generated at 2022-06-11 03:04:41.197115
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import os
    import ctypes
    from ansible.module_utils.facts.network.aix.aix_ifconfig import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import NetworkCollector

    libc = ctypes.CDLL(None)
    open_func = libc.open
    open_func.argtypes = [ctypes.c_char_p, ctypes.c_int]
    open_func.restype = ctypes.c_int

    read_func = libc.read
    read_func.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
    read_func.restype = ctypes.c_int

    close_func = libc.close

# Generated at 2022-06-11 03:04:45.005237
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('/usr/sbin/netstat') == ({'gateway': '172.30.240.1', 'interface': 'en0'},
                                                                       {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-11 03:04:55.588808
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    Return facts we would expect from parsing the output of
    'ifconfig -a' on AIX 6.1 TL8 with
    'unaame -W' output "0".
    '''
    test_obj = AIXNetwork()
    res = test_obj.get_interfaces_info(ifconfig_path='/usr/bin/ifconfig',
                                       ifconfig_options='-a')
    interfaces = res[0]
    ips = res[1]
    test_obj.set_interfaces_info(interfaces, ips)
    # we want to avoid including this dictionary in the test
    s = interfaces['lo0']
    del(s['number'])
    del(s['flags'])
    del(s['mtu'])

# Generated at 2022-06-11 03:05:05.251992
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create fake module and some variables
    fake_module = type('module', (object,), {'get_bin_path': lambda *args: '/usr/bin/netstat'})
    interface = {'v4': {}, 'v6': {}}

    # Create fake AnsibleModule object
    fake_am = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, 'default  192.168.0.1  UG        1       0   en0\ndefault  192.168.0.1  UG        1       0   en1\ndefault  192.168.0.1  UG        1       0   en2\n', ''), 'get_bin_path': lambda *args: '/usr/bin/netstat'})

# Generated at 2022-06-11 03:05:07.971055
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()

    net._module = None
    net._module.run_command = lambda args, check_rc=None, close_fds=None: (0, '', '')

    net.get_default_interfaces('a')

# Generated at 2022-06-11 03:05:14.384877
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={})

    test_data = {}

# Generated at 2022-06-11 03:05:16.113163
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:25.667166
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_args = []
    test_Network = AIXNetwork(test_module, test_args)
    interface = dict(v4={}, v6={})

    interface['v4']['gateway'] = '131.158.0.1'
    interface['v4']['interface'] = 'en0'
    assert test_Network.get_default_interfaces('/usr/sbin/route') == (interface['v4'], interface['v6'])

    interface['v6']['gateway'] = 'fe80::250:56ff:feb3:d713'
    interface['v6']['interface'] = 'lo0'

# Generated at 2022-06-11 03:05:33.473399
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This test of AIXNetwork.get_interfaces_info passes in a very simplistic
    AIX command output and asserts that the expected interfaces are returned.
    """
    import os.path
    from ansible.module_utils.facts.network.base import NetworkCollector

    # create the test fixture - an ansible module to pass to the AIXNetwork.get_interfaces_info method
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, prog):
            if prog == 'ifconfig':
                return os.path.join('/', 'usr', 'sbin', 'ifconfig')
            else:
                return None


# Generated at 2022-06-11 03:05:53.456031
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:05:58.379744
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    ValueError exception is expected with route_path.
    """
    net_collector = AIXNetwork('module')
    try:
        net_collector.get_default_interfaces(route_path='route')
    except ValueError as err:
        assert err.message == 'AIXNetwork: we do not support route command.'


# Generated at 2022-06-11 03:06:00.118448
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    facts.populate()
    facts.get_facts()

# Generated at 2022-06-11 03:06:02.919476
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-11 03:06:12.974517
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import platform
    import json
    import fake_data

    if platform.system() != 'AIX':
        exit('These tests are only applicable on AIX')

    module = fake_data.get_fake_module(platform, os.getcwd())

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    current_if = dict(v4={}, v6={})

    # AIX 'ifconfig -a' does not contain 'options=' line
    words = ['options=1400']
    AIXNetwork.parse_options_line(AIXNetwork(), words, current_if, ips)

# Generated at 2022-06-11 03:06:24.120389
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # build dummy module and class
    module = AnsibleModule({})
    class AIXNetwork_test(AIXNetwork):
        def __init__(self, module):
            self.module = module
    aixnetwork = AIXNetwork_test(module)

    # build instance of NetworkInterface
    route_path = 'netstat'
    result_v4 = {'gateway': '10.10.10.1', 'interface': 'en0'}
    result_v6 = {'gateway': 'fe80::21f:f3ff:fe37:f7de', 'interface': 'en1'}

    netstat_path = module.get_bin_path('netstat')
    if netstat_path:
        rc, out, err = module.run_command([netstat_path, '-nr'])


# Generated at 2022-06-11 03:06:32.508947
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_AIXNetwork = AIXNetwork(None)
    route_path = '/sbin/route'
    interface = test_AIXNetwork.get_default_interfaces(route_path)

    assert 'gateway' in interface['v4']
    assert 'interface' in interface['v4']
    assert 'gateway' in interface['v6']
    assert 'interface' in interface['v6']
    assert interface['v4']['gateway'] == '10.57.3.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::16:c4ff:fe1a:13'
    assert interface['v6']['interface'] == 'ent0'

# Generated at 2022-06-11 03:06:34.861233
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    assert aix_network.get_default_interfaces("doesn't matter") == ({}, {})

# Generated at 2022-06-11 03:06:45.513420
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (object,), {})()
    network_resource = AIXNetwork()
    network_resource.module = module

    # test case 1: route_path = /usr/bin/route
    route_path = '/usr/bin/route'
    module.run_command = mock_run_command
    rc = 0
    out = 'default 192.168.0.1 UG 8 0 0 en0\ndefault 2001:0db8::1 UG 10 0 0 utun0'
    err = ''
    interfaces = {'v4': {'gateway': '192.168.0.1', 'interface': 'en0'}, 'v6': {'gateway': '2001:0db8::1', 'interface': 'utun0'}}

# Generated at 2022-06-11 03:06:54.605218
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:29.128427
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    aix_network_collector.get_device_to_ip_addresses_mappings()
    aix_network_collector.get_device_to_ipv6_addresses_mappings()
    aix_network_collector.get_device_to_ipv6_link_local_mappings()
    aix_network_collector.get_default_interfaces()
    aix_network_collector.get_interfaces_info()
    aix_network_collector.get_interfaces()
    aix_network_collector.get_all_ipv4_addresses()
    aix_network_collector.get_all_ipv6_addresses()
    aix_network_collector.get_ipv4_

# Generated at 2022-06-11 03:07:29.686364
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True

# Generated at 2022-06-11 03:07:37.797011
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class ModuleStub:
        def get_bin_path(self, name):
            return '/usr/bin/netstat'

        def run_command(self, args):
            pass
    class FactsStub:
        def __init__(self, module_stub):
            self.ansible_net_ifconfig = AIXNetwork(module_stub)

    class PlayStub:
        def __init__(self, facts_stub):
            self.set_variable('ansible_facts', facts_stub)

    module_stub = ModuleStub()

    ifconfig_path = module_stub.get_bin_path('ifconfig')
    facts_stub = FactsStub(module_stub)
    play_stub = PlayStub(facts_stub)

    route_path = module_stub

# Generated at 2022-06-11 03:07:42.320473
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This unit test creates an instance of  AIXNetworkCollector,
    and tests whether the _fact_class and _platform attributes have the correct
    value.
    """
    collector = AIXNetworkCollector()
    assert collector._fact_class.platform == 'AIX'
    assert collector._platform == 'AIX'

# Generated at 2022-06-11 03:07:50.135868
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import io


# Generated at 2022-06-11 03:08:00.086523
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.params = {
        'gather_subset': ['all'],
        'gather_network_resources': ['all']
    }
    ifconfig_path = module.get_bin_path('ifconfig')
    collector = AIXNetwork(module)
    interfaces, ips = collector.get_interfaces_info(ifconfig_path)
    assert interfaces['en0']['inet'][0]['address'] == '172.17.1.150'
    assert 'mtu' not in interfaces['en0']
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']

# Generated at 2022-06-11 03:08:10.766963
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    def get_bin_path(path):
        return path  # noop

    module = type('module', (object,), {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
        'params': {'gather_network_resources': 'all'},
    })()
    ifaces = AIXNetworkCollector(module).collect()
    assert ifaces['lo0']['macaddress'] == '00:00:00:00:00:00'
    assert ifaces['lo0']['type'] == 'loopback'
    # ifconfig -a output was faked, so the MAC address must be wrong
    assert ifaces['eno0']['macaddress'] != 'bc:5f:f4:56:3d:b1'



# Generated at 2022-06-11 03:08:12.341530
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class._platform == 'AIX'

# Generated at 2022-06-11 03:08:14.500335
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the AIXNetworkCollector constructor
    """
    # If the object is created then no exception should be thrown
    AIXNetworkCollector()

# Generated at 2022-06-11 03:08:24.248779
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts import FactCollector

    result = AIXNetwork().get_default_interfaces(None)
    assert result == ('', '')

    result = AIXNetwork().get_interfaces_info(None)[0]
    assert result == {}

    # ifconfig -a output from AIX 7.2

# Generated at 2022-06-11 03:09:19.457338
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    uname_path = '/usr/bin/uname'


# Generated at 2022-06-11 03:09:24.172925
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {"run_command": lambda self, cmd, check_rc=True: (0, 'default 10.0.2.2 UG 0 0 en12 en12'
                                                                                'default fe80::8:27ff:fe9b:e909 UG 0 0 en12 en12', '')})()
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/bin/netstat')

# Generated at 2022-06-11 03:09:34.238318
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:09:43.198627
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create mock module
    import ansible.module_utils.facts.network.aix.test_aix_module as AixModule

    test_module = AixModule.AixModule()

    # create NetworkCollector object
    net_collector = AIXNetworkCollector(module=test_module,
                                        runtime={'paths': {'route': '/usr/sbin/netstat'}})

    # create AIXNetwork object
    aix_net = net_collector.get_network_collector()

    # create interface dictionaries
    v4_interface = {}
    v6_interface = {}
    # test_route_path is some nonexisting value
    (v4_interface, v6_interface) = aix_net.get_default_interfaces(test_module.test_route_path)

# Generated at 2022-06-11 03:09:44.662415
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:09:53.129703
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec=dict())
    # prepare netstat output simulating the result of running 'netstat -nr'
    # here we need to simulate IPv4 and optionally IPv6 default gateways
    out = "default %s %s UGS\n" % ('1.1.1.1', 'eth0')
    if net.has_ipv6:
        out += "default %s %s UGS\n" % ('2001:0db8::0001', 'eth0')
    net.module.run_command = lambda args: ('', out, '')

# Generated at 2022-06-11 03:10:01.948874
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class AIXNetwork
    """

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            bin_path = {
                'netstat': '/usr/bin/netstat',
            }
            return bin_path[executable]

        def run_command(self, cmd):
            out = ''
            err = ''
            rc = 0
            return rc, out, err

    module = MockModule(params={})
    aix_network = AIXNetwork(module)

# Generated at 2022-06-11 03:10:11.633250
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork.

    This unit test is using a real output of command 'ifconfig -a' running on AIX 7.1.
    The interface device name is changed to 'en0'

    :return: None
    """

    class FakeModule:
        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            return 0, ifconfig_a_aix_7_1, None

    #
    # Example output of command 'ifconfig -a' on AIX 7.1
    #

# Generated at 2022-06-11 03:10:12.931003
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:10:14.481195
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should be callable
    """
    assert AIXNetworkCollector

# Generated at 2022-06-11 03:11:58.894335
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test = AIXNetwork()


# Generated at 2022-06-11 03:12:07.791347
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:17.177849
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = DummyAnsibleModule()
    network_facts = AIXNetwork(module)

    # create mock 'netstat -rn' output

# Generated at 2022-06-11 03:12:26.664986
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    def test_run_command(cmd, **kwargs):
        try:
            if 'test_ifconfig' in cmd:
                out = file('test/unittests/test_utils/facts/network/test_ifconfig_aix.txt').read()
                return 0, out, ''
            else:
                return 0, '0', ''
        except Exception as e:
            raise Exception(str(e))

    test_module = type('obj', (object,), {'run_command': test_run_command})()
    test_module.get_bin_path = lambda self, x: '/bin/' + x
    test_net = AIXNetwork(test_module)

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )

   

# Generated at 2022-06-11 03:12:29.792813
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    network_collector = AIXNetwork()
    interfaces, ips = network_collector.get_interfaces_info("/usr/sbin/ifconfig", "-a")

    assert interfaces is not None
    assert interfaces
    assert ips is not None
    assert ips

# Generated at 2022-06-11 03:12:34.703620
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    m = AIXNetwork()
    m.module.fail_json = lambda *args, **kwargs: False
    m.module.run_command = lambda *args, **kwargs: (
        123, '', 'fake message'
    )
    m.module.get_bin_path = lambda *args, **kwargs: '/bin/' + args[0]
    result = m.get_interfaces_info('/bin/ifconfig', '-a')[0]
    assert result == {}


# Generated at 2022-06-11 03:12:36.324304
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    inst = AIXNetworkCollector()
    assert isinstance(inst, NetworkCollector)


# Generated at 2022-06-11 03:12:41.189573
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test for constructor of class AIXNetworkCollector
    """

    # test for legacy configuration 'network_gather_subset' - AIX specific
    test_obj = AIXNetworkCollector(dict(network_gather_subset=['!all', '!min']), None)
    assert test_obj._valid_subsets == set()

    # test for legacy configuration 'network_gather_subset' - common
    test_obj = AIXNetworkCollector(dict(network_gather_subset=['!all', '!min', '!interfaces']), None)
    assert test_obj._valid_subsets == set()

    # test for present and valid configuration 'gather_subset' - AIX specific

# Generated at 2022-06-11 03:12:50.243145
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mod = AnsibleModule(argument_spec={})
    net = AIXNetwork(module=mod)
    rc, out, err = mod.run_command([net._module.get_bin_path('ifconfig', True), '-a'])
    interfaces, ips = net.get_interfaces_info(net._module.get_bin_path('ifconfig', True), ifconfig_options='-a')
    assert len(interfaces) > 0
    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert len(ips['all_ipv4_addresses']) > 1
    assert len(ips['all_ipv6_addresses']) > 1

# Generated at 2022-06-11 03:12:53.544905
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector.__doc__
