

# Generated at 2022-06-11 03:04:28.395728
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('/sbin/route') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::5054:ff:fe15:b8e1%en0', 'interface': 'en0'})

# Generated at 2022-06-11 03:04:33.697066
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import os
    os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
    import ansible.utils.platform as platform
    if platform.system() == 'AIX':
        aix_network_collector = AIXNetworkCollector()
        assert aix_network_collector._platform == 'AIX'



# Generated at 2022-06-11 03:04:44.190123
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    # these constants are used in the mocked _module_run_command
    RUN_COMMAND_RC_MAP = dict(
        ifconfig=[0, '', ''],
        netstat=[0, 'default 192.168.1.1        UG        0 0 en0\ndefault         ::1                   UGTS    0 0 lo0\ndefault fe80::%en0  UG        0 0 en0', ''],
        uname=[0, '0', ''],
    )

# Generated at 2022-06-11 03:04:54.531704
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_subclass_object = AIXNetworkCollector()
    assert fact_subclass_object._fact_class == AIXNetwork
    assert fact_subclass_object._platform == 'AIX'

# Generated at 2022-06-11 03:04:59.884038
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, "default 172.20.166.1 UGS 0 1500 en2", "")
    network = AIXNetwork(mock_module)
    assert network.get_default_interfaces('route_path') == ({'gateway': '172.20.166.1', 'interface': 'en2'}, {})

# Generated at 2022-06-11 03:05:00.903584
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network = AIXNetworkCollector()


# Generated at 2022-06-11 03:05:06.777251
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts import collect_subset
    # Get information about all interfaces
    fact_subset = collect_subset(['network'])
    facts = Collector(fact_subset=fact_subset).get_facts()
    assert ('ansible_net_interfaces' in facts)

# Generated at 2022-06-11 03:05:13.773508
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MockModule()
    ifconfig_path = module.get_bin_path('ifconfig')
    uname_path = module.get_bin_path('uname')
    netstat_path = module.get_bin_path('netstat')
    lsattr_path = module.get_bin_path('lsattr')
    if not ifconfig_path or not uname_path or not netstat_path or not lsattr_path:
        module.fail_json(msg="unit test for AIXNetwork class failed - can't find required executables")

    aix = AIXNetwork(module)
    interfaces, ips = aix.get_interfaces_info(ifconfig_path)

    # check number of interfaces
    assert len(interfaces) == 6

    # check first interface
    assert 'device' in interfaces['en0']

# Generated at 2022-06-11 03:05:15.105645
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network = AIXNetworkCollector()
    assert aix_network is not None


# Generated at 2022-06-11 03:05:18.085655
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test for constructor of class AIXNetworkCollector"""
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:50.362018
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # build a mock module
    module = Mock(name='module')
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value=None)
    # build a AIXNetwork instance
    obj = AIXNetwork(module)
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = obj.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces == {}
    assert ips == dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-11 03:05:54.979763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector constructor"""

    collector = AIXNetworkCollector()
    assert collector.__class__.__name__ == 'AIXNetworkCollector'
    assert hasattr(collector, '_config')
    assert hasattr(collector, '_interfaces')
    assert hasattr(collector, '_subnets')


# Generated at 2022-06-11 03:06:04.839798
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_module = AnsibleModuleStub()
    # We run a constructor of parent class
    nc = AIXNetworkCollector(ansible_module)
    assert isinstance(nc, NetworkCollector)
    assert isinstance(nc, AIXNetworkCollector)
    assert isinstance(nc.facts['default_ipv4'], dict)
    assert isinstance(nc.facts['default_ipv6'], dict)
    assert isinstance(nc.facts['interfaces'], dict)
    assert isinstance(nc.facts['all_ipv4_addresses'], list)
    assert isinstance(nc.facts['all_ipv6_addresses'], list)


# Generated at 2022-06-11 03:06:07.783082
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This test instantiates class AIXNetworkCollector
    """
    my_obj = AIXNetworkCollector()
    assert isinstance(my_obj, AIXNetworkCollector)


# Generated at 2022-06-11 03:06:11.924562
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('/some/route/path') == ({'gateway': '10.0.2.2', 'interface': 'en0'}, {'gateway': 'fe80::21a:9dff:fe54:4b4', 'interface': 'en0'})

# Generated at 2022-06-11 03:06:18.097672
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    res = network_collector.get_default_interfaces('/usr/bin/netstat')
    assert len(res) == 2
    assert res[0]['interface'] == 'en0'
    assert res[1]['interface'] == 'en0'
    assert res[0]['gateway'] == '172.16.111.1'

# Generated at 2022-06-11 03:06:29.812370
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network_test = AIXNetwork()
    aix_network_test.module = AnsibleModuleMock()
    aix_network_test.module.run_command.return_value = (0, 'fd00:100:53::53/64 fd00:100:53::1 UGSe - - en0\n', '')
    aix_network_test.module.get_bin_path.return_value = None
    (interfaces, ips) = aix_network_test.get_interfaces_info('does not matter')
    assert interfaces['en0']['flags'] == ['up']
    assert interfaces['en0']['macaddress'] == 'unknown'
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-11 03:06:40.722559
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX', 'Value of platform should be AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX', 'Value of _fact_class.platform should be AIX'
    assert AIXNetworkCollector._platform == 'AIX', 'Value of _platform should be AIX'

    # Test instantiation of class AIXNetworkCollector
    aix_network_fact_class = AIXNetworkCollector()

    assert aix_network_fact_class.platform == 'AIX', 'Value of aix_network_fact_class.platform should be AIX'
    assert aix_network_fact_class._fact_class.platform == 'AIX', 'Value of aix_network_fact_class._fact_class.platform should be AIX'
    assert aix_network_

# Generated at 2022-06-11 03:06:44.406350
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    network_collector = AIXNetworkCollector(None)
    assert isinstance(network_collector.fact_class, AIXNetwork)


# Generated at 2022-06-11 03:06:50.432165
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net_aix = AIXNetwork()
    net_aix.module = MagicMock()
    net_aix.module.run_command = MagicMock(return_value=(0, 'default 10.0.0.1 UGS 0 8 en0\ndefault 2001::1 UGS 0 8 en1', ''))
    assert net_aix.get_default_interfaces('') == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': '2001::1', 'interface': 'en1'})


# Generated at 2022-06-11 03:07:39.763146
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)

# Generated at 2022-06-11 03:07:46.905921
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class AIXNetwork
    '''
    import os
    os.environ['ANSIBLE_NET_ROUTE_PATH'] = '/usr/sbin/netstat'

    obj = AIXNetwork()
    route_path = obj.module.get_bin_path('netstat')
    interface = obj.get_default_interfaces(route_path)
    assert interface[0] == {'gateway': '10.0.2.2', 'interface': 'en0'}

# Generated at 2022-06-11 03:07:50.457833
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    from ansible.module_utils.facts.network.collector import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # AIXNetworkCollector is a subclass of NetworkCollector
    assert issubclass(AIXNetworkCollector, NetworkCollector)


# Generated at 2022-06-11 03:08:00.258023
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []

        def get_bin_path(self, arg1):
            self.run_command_args = []
            if arg1 == 'uname':
                return arg1

        def run_command(self, args):
            self.run_command_args = args
            if args[0] == 'uname' and args[1] == '-W':
                return 0, '0', ''
            elif args[0] == 'ifconfig':
                return 0, '', ''
            elif args[0] == 'entstat':
                return 0, 'Hardware Address: AA:BB:CC:DD:EE:FF', ''
            elif args[0] == 'lsattr':
                return 0, 'mtu 1500',

# Generated at 2022-06-11 03:08:10.963298
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    interface = dict(v4={}, v6={})
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, 'default 0.0.0.0 UG 1 en0\ndefault 0.0.0.0 UG 1024 en1\ndefault ::1 UG 1 lo0\ndefault dead:beef::1 !G 1 lo0\n', ''))
    collector = AixNetwork()
    interface = collector.get_default_interfaces('/sbin/route')
    assert interface['v4']['gateway'] == '0.0.0.0'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == '::1'

# Generated at 2022-06-11 03:08:20.850840
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for get_interfaces_info of class AIXNetwork
    """
    aixnet = AIXNetwork()
    ifconfig_path = 'test/aix_ifconfig_sample'
    expected_interface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'mtu': '65536', 'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'macaddress': 'unknown'}
    expected_ips = {'all_ipv4_addresses': ['127.0.0.1'], 'all_ipv6_addresses': ['::1']}
    assert expected_interface == aixnet.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-11 03:08:25.403764
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork

    assert issubclass(AIXNetworkCollector, BaseFactCollector)
    assert AIXNetworkCollector._platform == "AIX"
    assert AIXNetworkCollector._fact_class == AIXNetwork



# Generated at 2022-06-11 03:08:34.550480
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from collections import namedtuple
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import DummyModule
    from ansible.module_utils.facts.network.base import NetworkCollector

    route_one_interface = namedtuple('route_one_interface', ['network', 'gateway', 'interface'])
    route_one_interface_one_line = namedtuple('route_one_interface_one_line', ['network', 'gateway'])
    route_one_interface_one_line_with_default = namedtuple('route_one_interface_one_line_with_default', ['gateway', 'interface'])

# Generated at 2022-06-11 03:08:43.875407
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod_args = dict(
        config_file="/etc/ansible/facts.d/ansible_net_config.json",
        gather_subset=[
            'all'
        ],
        filter=dict(
            **dict(
                interfaces="?"
            )
        )
    )
    aix_net = AIXNetworkCollector(module=MockModule(**mod_args))
    assert aix_net.__class__.__name__ == "AIXNetworkCollector"
    assert aix_net.__class__.__bases__[0].__name__ == "NetworkCollector"
    assert aix_net.fact_subclass == AIXNetwork

# Generated at 2022-06-11 03:08:46.213733
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork
    assert collector.options == []

# Generated at 2022-06-11 03:09:36.290911
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert type(AIXNetworkCollector()) == AIXNetworkCollector


# Generated at 2022-06-11 03:09:37.466406
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'

# Generated at 2022-06-11 03:09:46.227722
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    # ifconfig_path = '../../module_utils/facts/network/aix/tests/data/ifconfig'
    # ifconfig_path = '../../module_utils/facts/network/aix/tests/data/ifcongif_a_without_wpar'
    # ifconfig_path = '../../module_utils/facts/network/aix/tests/data/ifcongif_a_with_wpar'

    test_class = AIXNetwork()
    interfaces, ips = test_class.get_interfaces_info(ifconfig_path, ifconfig_options)

    print(interfaces)
    print(ips)

if __name__ == '__main__':
    test_AIXNetwork_get

# Generated at 2022-06-11 03:09:54.522438
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create the test class instance
    an = AIXNetwork()

    # Mock module to return some test data
    from ansible.module_utils.facts.network.aix import AIXNetwork
    an.module = AIXNetwork._get_module_mock()

    # Set the module defaults
    an.module.params = dict(config=None,
                            verbose=None,
                            cache=None,
                            persist=None)

    # Define test input data
    #
    # AIX ifconfig output
    # root@node:/root # ifconfig -a
    # lo0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>

# Generated at 2022-06-11 03:10:03.382006
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:10:13.236952
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # constructor of class NetworkCollector is not accessible
    # therefore we test indirectly through its subclasses
    fact = AIXNetworkCollector().get_facts()
    assert isinstance(fact, dict)
    assert 'default_ipv4' in fact
    assert 'default_ipv6' in fact
    assert 'interfaces' in fact
    assert 'all_ipv4_addresses' in fact
    assert 'all_ipv6_addresses' in fact
    assert isinstance(fact['interfaces'], list)
    assert isinstance(fact['all_ipv4_addresses'], list)
    assert isinstance(fact['all_ipv6_addresses'], list)



# Generated at 2022-06-11 03:10:20.182153
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list'),
    })


# Generated at 2022-06-11 03:10:28.682596
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    uname_path = None
    lsattr_path = None
    entstat_path = None

    # uname_path, lsattr_path and entstat_path must be defined
    if uname_path is None or lsattr_path is None or entstat_path is None:
        return False

    class MyModule:
        def __init__(self, bin_paths):
            self.bin_paths = bin_paths
            self.params = dict(
                gather_subset=['!all', 'min'],
            )

        def get_bin_path(self, arg, default=None):
            if arg in self.bin_paths:
                return self.bin_paths[arg]
            else:
                return default

        def run_command(self, args, check_rc=False):
            return

# Generated at 2022-06-11 03:10:38.041151
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module_args = dict(
        default_ipv4=dict(address="192.168.0.2", mask="255.255.255.0"),
        default_ipv6=dict(address="dead:beef::2", mask="64"),
    )
    module = FakeModule(**module_args)
    AIXNetworkCollector(module).populate()
    assert module.ansible_facts['ansible_default_ipv4']['address'] == module_args['default_ipv4']['address']
    assert module.ansible_facts['ansible_default_ipv4']['gateway'] == '192.168.0.1'
    assert module.ansible_facts['ansible_default_ipv4']['interface'] == 'en0'

# Generated at 2022-06-11 03:10:45.741872
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Testing with just the generic uname
    module = Mock()
    module.run_command.return_value = (0, "IBM,8233-ETA\n2.6.32.9-1.c01.9530.0.4.4.4.0.0.20.1", "")
    module.get_bin_path.return_value = "/usr/bin/uname"
    module.exit_json.return_value = 0
    tmp_AIX = AIXNetworkCollector(module)
    assert tmp_AIX.get_facts()['network']['default_ipv4'] == {'gateway': None, 'interface': None}

# Generated at 2022-06-11 03:12:23.700683
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:12:32.618800
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeModule()
    ifnet = FakeInterface()
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    # mock run_command
    module.run_command = Mock(return_value=(0, ifnet.AIX_OUTPUT, None))

    an = AIXNetwork(module)
    (interfaces, ips) = an.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert len(interfaces) == 2
    assert 'lo0' in interfaces
    assert 'en0' in interfaces

    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']
    assert len(interfaces['lo0']['ipv4']) == 1

# Generated at 2022-06-11 03:12:38.455836
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule()

    net_tools = AIXNetwork(module)

    net_tools.module.params['gather_network_resources'] = ['interfaces', 'default_ipv4', 'default_ipv6']

    route_path = net_tools.module.get_bin_path('netstat')

    net_tools.get_default_interfaces(route_path)

    assert net_tools.facts['default_ipv4'] is not None

# Generated at 2022-06-11 03:12:48.423148
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = None
    ansible_module_get_bin_path = NetworkCollector.ansible_module_get_bin_path

    NetworkCollector.ansible_module_get_bin_path = lambda self, filename: '/usr/bin/' + filename

    o = AIXNetwork(module)
    o.run({})

# Generated at 2022-06-11 03:12:57.517011
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class AIXNetwork
    """
    network = AIXNetwork()
    rc = ''

# Generated at 2022-06-11 03:13:07.060476
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule:
        def __init__(self):
            self.params = dict()
            self.run_command_result = dict()
            self.run_command_result[0] = (0, '', '')

        def get_bin_path(self, arg, required=False):
            return arg

        def run_command(self, arg):
            key = arg[0]
            if key == 'uname':
                return (0, '0', '')
            return self.run_command_result[key]

    class MockFactCollector:
        def __init__(self):
            self.driver = 'ansible.module_utils.facts.hardware.osx.OSXNetwork'
            self.model = dict()

        def populate(self):
            pass


# Generated at 2022-06-11 03:13:08.905068
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector._platform == 'AIX'

# Generated at 2022-06-11 03:13:11.934051
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    options = dict(
        route_path='/usr/sbin/route'
        )

    AIXNetwork.get_default_interfaces(None, options)  # returns v4, v6

# Generated at 2022-06-11 03:13:16.071024
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_net = AIXNetwork()
    result = test_net.get_default_interfaces(test_net.route_path)
    assert len(result) == 2
    assert result[0]
    assert result[0]['gateway']
    assert result[0]['interface']
    assert result[1]
    assert result[1]['gateway']
    assert result[1]['interface']

# Generated at 2022-06-11 03:13:17.622111
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    assert AIXNetworkCollector(module, None) is not None
