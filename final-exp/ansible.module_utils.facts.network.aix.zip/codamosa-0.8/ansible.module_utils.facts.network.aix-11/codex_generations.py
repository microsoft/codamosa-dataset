

# Generated at 2022-06-11 03:04:28.801902
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is called in test_network.py
    """
    module = object()
    platform = 'AIX'
    ifconfig_path = '/usr/sbin/ifconfig'
    network_collector = AIXNetworkCollector(module=module, platform=platform, ifconfig_path=ifconfig_path)
    assert network_collector.platform == 'AIX'
    assert network_collector.ifconfig_path == '/usr/sbin/ifconfig'

# Generated at 2022-06-11 03:04:39.942352
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    uname_path = 'uname'
    uname_rc, uname_out, uname_err = 0, '0', None


# Generated at 2022-06-11 03:04:47.708989
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    expected_interface = dict(
        v4=dict(gateway='9.222.160.81', interface='en0'),
        v6=dict(gateway='fc00:bdcc:bdcc:bdcc:bdcc:bdcc:bdcc:bdcc', interface='en0'),
    )

    netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-11 03:04:58.428520
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    result = {'default_ipv4': {'gateway': '192.168.1.1', 'interface': 'en0'},
              'default_ipv6': {'gateway': 'fe80::5054:ff:fe12:3456', 'interface': 'en0'}}

    netstat_result = ('default 192.168.1.1 UG 1 0 en0\n'
                      'fe80::5054:ff:fe12:3456%en0 fe80::5054:ff:fe12:3456 UGc 1 0 en0\n'
                      'default 192.168.1.1 UG 1 0 en0\n'
                      'default 192.168.1.1 UG 1 0 en0\n')

    uname_rc = None
    uname_out = None
    uname_err

# Generated at 2022-06-11 03:05:08.269983
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from io import StringIO
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test = AIXNetwork()

    test_out = '''
    default 192.168.1.1 UG     2    51 en0
    default fe80::%utun0   UGcI      1     5 utun0
    default link#10      UGcI      5   873 en0
    '''

    test_out = StringIO(test_out)
    test.module.run_command = lambda *args, **kwargs: (0, test_out.read(), '')

    interface_v4, interface_v6 = test.get_default_interfaces('route')
    assert interface_v4['gateway'] == '192.168.1.1'

# Generated at 2022-06-11 03:05:11.058847
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    my_net = AIXNetwork()
    assert my_net.get_default_interfaces('/usr/bin/netstat') == ({'gateway': '192.168.42.1', 'interface': 'en0'}, None)

# Generated at 2022-06-11 03:05:16.982252
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mod_args = dict(
        gather_subset=['all'],
    )
    ans_instance = AIXNetworkCollector(module=AnsibleModule(argument_spec={}),
                                       params=mod_args)
    assert ans_instance.params['gather_subset'] == ['all']
    assert AIXNetworkCollector._platform == 'AIX'
    assert type(ans_instance) == AIXNetworkCollector


# Generated at 2022-06-11 03:05:26.940366
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:05:32.297245
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    import ansible.module_utils.facts.network.interfaces
    obj = ansible.module_utils.facts.network.interfaces.NetworkCollector().get_network_collector('AIX')
    assert isinstance(obj, AIXNetworkCollector), \
        "AIXNetworkCollector() returns {0}, but it should be {1}".format(type(obj), type(AIXNetworkCollector()))


# Generated at 2022-06-11 03:05:37.649100
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    test = AIXNetwork()
    test.module = DummyAnsibleModule()
    result = test.get_default_interfaces('/path/to/route')

    assert result == ({'interface': None, 'gateway': None}, {'interface': None, 'gateway': None})


# Unit test class for testing ifconfig output of method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:04.786706
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    test method get_interfaces_info of class AIXNetwork
    '''
    # arrange
    my_module = AnsibleModuleMock('AIXNetwork_get_interfaces_info')
    my_network = AIXNetworkCollector.load_collector(my_module)

    # act
    interfaces, ips = my_network.get_interfaces_info()

    # assert
    my_assertions(interfaces, ips, my_module)


# Generated at 2022-06-11 03:06:14.145701
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network.aix.collector import AIXNetworkCollector
    import os
    import pprint
    import pytest
    import sys

    if not os.path.isfile('/etc/hosts'):
        pytest.skip('tests can only be run on filesystems with /etc/hosts')

    if sys.platform.startswith('linux'):
        pytest.skip('tests can only be run on AIX')

    class MockModule(object):
        def __init__(self):
            self._debug = False
            self._verbosity = 0

        def get_bin_path(self, app, opt_dirs=[]):
            return app


# Generated at 2022-06-11 03:06:24.452414
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_AIXNetwork = AIXNetworkCollector('/sbin/ifconfig', '/usr/sbin/netstat')
    test_if = dict(v4={}, v6={})
    test_if['v4']['gateway'] = b'10.20.30.1'
    test_if['v4']['interface'] = b'en0'
    test_if['v6']['gateway'] = b'fe80::5054:ff:fe32:1d9'
    test_if['v6']['interface'] = b'en0'
    assert test_AIXNetwork.get_default_interfaces('/usr/sbin/netstat') == test_if

# Generated at 2022-06-11 03:06:32.242096
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, 'default 172.17.0.1 UG 1 106 en0', ''))
    fact_collector = AIXNetwork(test_module)
    (interface_v4, interface_v6) = fact_collector.get_default_interfaces('')

    test_module.run_command.assert_called_with(['/usr/bin/netstat', '-nr'])

    assert interface_v4 == {'gateway': '172.17.0.1', 'interface': 'en0'}
    assert interface_v6 == {}



# Generated at 2022-06-11 03:06:43.259526
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test whether method get_interfaces_info of class AIXNetwork
    works as expected
    """

    import unittest
    from ansible.module_utils.facts.network.aix import AIXNetwork

    class TestAIXNetwork(unittest.TestCase):

        def setUp(self):
            self.net = AIXNetwork()
            self.net.get_interfaces_info = AIXNetwork.get_interfaces_info.__func__

        def test_ipv4(self):
            """
            Test the presence of an IPv4 address
            """

# Generated at 2022-06-11 03:06:50.276728
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:53.723665
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})

    network_collector = AIXNetworkCollector(module, platform='AIX')

    assert network_collector.facts_class._platform == 'AIX'



# Generated at 2022-06-11 03:07:00.282038
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    module = None

    aix_network = AIXNetwork(module)
    interfaces_info = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert len(interfaces_info[0]) > 1
    for interface in interfaces_info[0].keys():
        assert len(interface) > 1

# Generated at 2022-06-11 03:07:10.600001
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.aix import FakeModule, FakeOut
    r"""
    This test is based on a real output of the command ' ifconfig -a' on aix 7.1
    """
    ifc = AIXNetwork(FakeModule(ansible_facts={}))

    # Fake ifconfig output

# Generated at 2022-06-11 03:07:16.575310
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector.get_platform_module({})
    net_class = module.Network()

    result = net_class.get_default_interfaces('route -n')
    assert result['ipv4']['interface'] == 'en0'
    assert result['ipv4']['gateway'] == '10.110.10.1'
    assert result['ipv6']['interface'] == 'en0'
    assert result['ipv6']['gateway'] == 'fe80::21f:fcff:fe53:f991'

# Generated at 2022-06-11 03:07:49.865985
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    #
    # good test data
    #
    good_test1_out_lines = [
        "0.0.0.0             0         UG        0 0          0 en0",
        "10.1.1.0            10        U         0 0          0 en1",
        "192.168.1.0         192       U         0 0          0 en3",
    ]

    good_test1_dict = {
        'v4': {'gateway': '0.0.0.0', 'interface': 'en0'},
        'v6': {'gateway': None, 'interface': None}
    }

    #
    # bad test data
    #

# Generated at 2022-06-11 03:07:59.823844
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class test_module:

        def __init__(self, *args):
            self.params = args[0]
            self.run_command_args = None

        def get_bin_path(self, *args):
            return '/usr/bin/netstat'

        def run_command(self, args):
            self.run_command_args = args
            return (0,
                    'default XXX.XXX.XXX.XXX UG 3 0 en0\n'
                    'default XXX:XXX:XXX:XXX:XXX:XXX:XXX:XXX UGDA 16 0 en0',
                    None)

    tm = test_module(dict(gather_timeout=10))

    expected_args = ['/usr/bin/netstat', '-nr']

    net = AIXNetwork()
    net.module = tm

    net

# Generated at 2022-06-11 03:08:10.484015
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test if AIX network interface facts are parsed correctly"""

# Generated at 2022-06-11 03:08:11.252825
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:08:21.216332
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_module_class = AIXNetwork()

    mod_name = 'ansible.module_utils.facts.network.aix.AIXNetwork'
    filename = "{}.get_default_interfaces".format(mod_name)
    with patch(filename) as mock_method:
        out = dict(
            v4=dict(
                gateway='10.10.10.1',
                interface='bge0',
            ),
            v6=dict(
                gateway='fe80::2',
                interface='bge0',
            )
        )
        mock_method.return_value = out
        out = network_module_class.get_default_interfaces('route_path')
        assert out == (out['v4'], out['v6'])




# Generated at 2022-06-11 03:08:24.955311
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    class MockModule():
        def run_command(self, args):
            return 255, '', 'No such file or directory'
    collect_network_ifconfig = AIXNetworkCollector()
    collect_network_ifconfig.module = MockModule()
    for _ in  collect_network_ifconfig.collect():
        pass


# Generated at 2022-06-11 03:08:34.221692
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class mock_module:
        def __init__(self, uname, ifconfig):
            self.uname = uname
            self.ifconfig = ifconfig

        def get_bin_path(self, arg):
            if arg == 'uname':
                return self.uname
            elif arg == 'ifconfig':
                return self.ifconfig
            else:
                return None

        def run_command(self, arg):
            if arg == [self.uname, '-W']:
                if self.uname == 'uname':
                    return (0, '0', 'uname_err')
                else:
                    return (0, '1', 'uname_err')

# Generated at 2022-06-11 03:08:34.998382
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:08:44.385501
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix = AIXNetwork()

    netstat_path = aix.module.get_bin_path('netstat')
    if netstat_path:
        rc, out, err = aix.module.run_command([netstat_path, '-nr'])
    else:
        out = """
        Kernel IP routing table
        Destination     Gateway         Genmask         Flags   MSS Window  irtt Iface
        10.0.2.0        0.0.0.0         255.255.255.0   U         0 0          0 eth0
        0.0.0.0         10.0.2.2        0.0.0.0         UG        0 0          0 eth0
        """

    interface = aix.get_default_interfaces(netstat_path)

# Generated at 2022-06-11 03:08:53.959590
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    module.params = {'gather_subset': [], 'gather_network_resources': 'no'}
    network = AIXNetwork()

    # a test string:
    # default 192.0.2.9 UG 0 0 en0
    # default 2001:db8::1 UG 0 0 en0
    out = "default 192.0.2.9 UG 0 0 en0\ndefault 2001:db8::1 UG 0 0 en0"

    # empty route_path should not raise exception
    network.get_default_interfaces('')

    # netstat_path exists
    module.run_command.return_value = (0, out,"")
    result = network.get_default_interfaces(network.module.get_bin_path('netstat'))


# Generated at 2022-06-11 03:09:31.195901
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class AIXNetwork"""

    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:09:40.127430
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """check parsing of facts from 'ifconfig -a' in class AIXNetwork"""


# Generated at 2022-06-11 03:09:41.490417
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Constructor AIXNetworkCollector() should not raise any exception
    AIXNetworkCollector()

# Generated at 2022-06-11 03:09:44.187447
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mod = MockModule()
    n = AIXNetwork(mod)
    n.get_interfaces_info(None, '/tmp/ansible_ifconfig_file')



# Generated at 2022-06-11 03:09:52.645703
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create a AIXNetwork object from file aix_netstat_nr.txt which contains the result of 'netstat -nr' ifconfig command
    network_collector = AIXNetworkCollector(None, None, None)
    aw = network_collector.get_network_facts_from_text_files(
        None,
        ['ansible/module_utils/facts/network/aix_ifconfig.txt', 'ansible/module_utils/facts/network/aix_netstat_nr.txt'],
        None
    )
    data_from_file = aw._facts['ansible_default_ipv4']
    aw.netstat_path = '/usr/bin/netstat'
    data_from_method = aw.get_default_interfaces(None)
    assert data_from_file == data_from_method

# Generated at 2022-06-11 03:09:53.721239
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'

# Generated at 2022-06-11 03:09:55.034410
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetwork_collector = AIXNetworkCollector()
    assert aixnetwork_collector.platform == 'AIX'

# Generated at 2022-06-11 03:10:04.176246
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys

    # Python 2.6 (RHEL6) does not have unittest2 available in the standard library.  As such,
    # we'll use the backport from pypi.
    # python3 will import this from the standard library
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    # a simple class for module.run_command with static return values
    class AnsibleModule:
        def __init__(self):
            self.params = None
            self.check_mode = None

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)


# Generated at 2022-06-11 03:10:13.795376
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockNetworkModule:
        def __init__(self, platform):
            self.platform = platform
            self.run_command = MockNetworkModule.get_run_command(platform)

        @staticmethod
        def get_run_command(platform):
            if platform == 'AIX':
                return lambda x: (0, 'default 192.0.2.1 UG 1 en0', '')
            else:
                return lambda x: (1, '', 'Error')

    # intended to give the correct platform to the generic class, here AIX
    class MockNetworkCollector(NetworkCollector):
        _fact_class = AIXNetwork
        _platform = 'AIX'

    mock_module = MockNetworkModule('AIX')

# Generated at 2022-06-11 03:10:19.098066
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    new_AIXNetwork = AIXNetwork()
    new_AIXNetwork.module = AnsibleModule({})
    new_AIXNetwork.module.get_bin_path = get_bin_path
    ifconfig_path = new_AIXNetwork.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    result1, result2 = new_AIXNetwork.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-11 03:11:19.636369
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import sys
    import inspect
    my_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    sys.path.append(os.path.join(my_path, "../"))
    import ansible.module_utils.facts.network.aix
    sys.modules['ansible.module_utils.facts.network.aix'] = ansible.module_utils.facts.network.aix
    import ansible.module_utils.facts.network.aix
    import ansible.module_utils.basic
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.network.base



# Generated at 2022-06-11 03:11:28.423138
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, arg, *args, **kwargs):
            return arg


# Generated at 2022-06-11 03:11:34.438456
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')

    if not ifconfig_path or not route_path:
        module.fail_json(msg='cannot find required commands')

    network = AIXNetwork(module)
    default_routes = network.get_default_interfaces(route_path)
    assert default_routes == ({'gateway': '10.66.111.254', 'interface': 'en1'},
                              {'gateway': 'fe80::20c:29ff:fe7a:e523', 'interface': 'en1'})


# Generated at 2022-06-11 03:11:40.820968
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collect = AIXNetworkCollector()
    assert(net_collect._platform == 'AIX')
    assert(issubclass(net_collect._fact_class, AIXNetwork))
    assert(issubclass(net_collect.fact_class(), AIXNetwork))
    assert(issubclass(net_collect._fact_class, NetworkCollector))
    assert(issubclass(net_collect.fact_class(), NetworkCollector))
    assert(issubclass(net_collect._fact_class, GenericBsdIfconfigNetwork))
    assert(issubclass(net_collect.fact_class(), GenericBsdIfconfigNetwork))

# Generated at 2022-06-11 03:11:50.684720
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Method get_interfaces_info of class AIXNetwork returns a tuple
    # whose first element is a dictionary of interfaces of AIX
    # and second element is a dictionary of IPs of AIX.

    # This method is supposed to be called by method get_interfaces_info
    # of class Network(BaseNetwork) of module facts.network.base.
    # see also https://docs.ansible.com/ansible/latest/network/network_debug_troub...

    # In this test, we check that the method returns the expected data
    # for a given output of the ifconfig command.
    # see also https://www.ibm.com/support/knowledgecenter/en/ssw_aix_71/com.ibm.aix.c...

    from ansible.module_utils.facts.network.aix import AIX

# Generated at 2022-06-11 03:11:58.513762
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()

    # No netstat
    module_name = 'ansible.module_utils.facts.network.aix'
    shell = FakeShell(bin_paths={'netstat': None})
    module.set_module_name(module_name)
    module.set_shell(shell)

    iface = AIXNetwork(module)
    ipv4, ipv6 = iface.get_default_interfaces('')

    assert ipv4 == {}
    assert ipv6 == {}

    # Example 1. Default interface with IPv4 only
    module_name = 'ansible.module_utils.facts.network.aix'
    shell = FakeShell(bin_paths={'netstat': None})
    module.set_module_name(module_name)
    module.set_shell(shell)

# Generated at 2022-06-11 03:12:06.959148
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_network_resources=dict(default=False, type='bool'),
        ),
    )

    # ifconfig_path is in the PATH
    # this is the expected result

# Generated at 2022-06-11 03:12:16.905154
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # temporary testcase
    class module_mock:
        def __init__(self):
            self.run_command = None
    aix = AIXNetwork(module_mock())

    # temporary testcase
    class run_command_mock:
        def __init__(self):
            self.rc = 0
            self.out = 'default 192.168.0.1 UG eth0\ndefault fe80::8ec4:7aff:fe20:33a1%en0 UG en0\ndefault ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff UG en0'
            self.err = ''
    aix.module.run_command = run_command_mock()
    v4, v6 = aix.get_default_interfaces('/usr/bin/route')


# Generated at 2022-06-11 03:12:18.026087
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector(None)


# Generated at 2022-06-11 03:12:27.555048
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda app_name: '/usr/sbin/' + app_name
    aix_network = AIXNetwork(module)

    aix_network.module.run_command = lambda args: (0, OUTPUT_IFCONFIG_A_ALL, '')
    interfaces, ips = aix_network.get_interfaces_info('ifconfig', '-a')
    assert(interfaces['en0']['mtu'] == '1500')
    assert(interfaces['en0']['type'] == 'ether')
    assert(interfaces['en0']['flags'] == [ 'UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST' ])