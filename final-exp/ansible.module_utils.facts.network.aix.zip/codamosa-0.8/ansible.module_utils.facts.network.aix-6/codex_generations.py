

# Generated at 2022-06-11 03:04:30.546270
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    A = dict(
        aws_default_ipv4={}, aws_default_ipv6={}, default_ipv4={}, default_ipv6={}, interfaces={},
        test_default_ipv4={}, test_default_ipv6={}, test_interfaces={},
        test_networks={}, test_uname_path='/bin/uname', test_netstat_path='/bin/netstat', test_route_path='/bin/netstat'
    )
    AIXNetwork_get_default_interfaces_input = ['/bin/netstat', '-nr']

# Generated at 2022-06-11 03:04:41.234169
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test the get_interfaces_info() method of class AIXNetwork
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ifconfig_path = module.get_bin_path("ifconfig", True)

    # Creating the AIXNetwork object
    aix_network = AIXNetwork(module)

    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')

    # Testing the get_interfaces_info method of AIXNetwork class
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options='-a')

    data = {
        'interfaces': interfaces,
        'network': ips,
    }

# Generated at 2022-06-11 03:04:48.853870
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    def make_module(*args, **kwargs):
        module = Mock(**kwargs)
        module.run_command = Mock(return_value=(0, args[0]))
        return module

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from io import StringIO
    # output from ifconfig -a

# Generated at 2022-06-11 03:04:53.258769
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

    assert aix_network_collector._platform == 'AIX'
    assert isinstance(aix_network_collector._fact_class, AIXNetwork)
    assert aix_network_collector._fact_class.platform == 'AIX'

# Generated at 2022-06-11 03:05:03.670079
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.utils import mock_module
    from ansible.module_utils.facts.network.utils import Lsattr
    from ansible.module_utils.facts.network.utils import Entstat

    test_module = mock_module(name=__name__)

    # mock the module
    test_module.run_command = lambda x: (0, '', '')
    test_module.get_bin_path = lambda x: '/usr/bin/netstat'

    # Mock commands
    test_module.run_command = lambda x: (0, '00:a9fe033de7f2', '') # MAC address
    test_module.run_command = lambda x: (0, 'Ethernet', '') # device type

# Generated at 2022-06-11 03:05:11.400860
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('FakeModule', (object,), dict())
    module.run_command = lambda args: (0, 'default 192.0.2.0 UG en0 192.0.2.1\n' +
                                           'default :: UG en0 1\n' +
                                           'default :: UG en0 2\n' +
                                           'default 2001:: UG en0 2001::1', '')
    m = AIXNetwork(module)
    result = m.get_default_interfaces('/sbin/route')
    assert result == ({'gateway': '192.0.2.1', 'interface': 'en0'},
                      {'gateway': '2001::1', 'interface': 'en0'})


# Generated at 2022-06-11 03:05:20.368367
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = 0
            self.params = {
                'ansible_net_gather_subset': ['interfaces', 'defaults'],
            }

        def get_bin_path(self, arg, opt_dirs=None):
            self.get_bin_path_calls += 1
            if arg == 'netstat':
                return '/usr/bin/netstat'
            return None

        def run_command(self, cmd, check_rc=True, close_fds=True):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-11 03:05:30.685054
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    my_module = 'ansible.module_utils.facts.network.aix.AIXNetwork'
    my_file = 'ansible/module_utils/facts/network/aix/AIXNetwork.py'
    test_module = importlib.import_module(my_module)
    test_module.uname_path = 'uname'
    test_module.ifconfig_path = 'ifconfig'
    test_module.netstat_path = 'netstat'
    test_module.lsattr_path = 'lsattr -El'
    test_module.entstat_path = 'entstat -d'
    test_module.run_command = lambda *args, **kwargs: (1, args[1], None)

# Generated at 2022-06-11 03:05:40.613867
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value="/usr/sbin/lsdev")

# Generated at 2022-06-11 03:05:50.192846
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    local_module = type('module', (object, ), dict(run_command=lambda args, check_rc=False: (0, '', '')))

    m = local_module()
    fact = AIXNetwork(m, '/sbin/ifconfig')

    o = "default 172.16.10.254 UGH0 10.0.1.1 UGHD0 default 172.16.10.254 UGH0 10.0.1.1 UGHD0"
    out = o.splitlines()

    r = fact.get_default_interfaces(out)

    assert r[0]['gateway'] == '172.16.10.254'
    assert r[0]['interface'] == 'UGH0'
    assert r[1]['gateway'] == ''
    assert r[1]['interface'] == ''


# Unit

# Generated at 2022-06-11 03:06:08.971737
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fake_module = NetworkCollector._create_fake_module('AIX')
    collector = AIXNetworkCollector(fake_module)
    assert(isinstance(collector._fact_class, AIXNetwork))
    assert(collector._fact_class.platform == 'AIX')
    assert(collector._platform == 'AIX')
    assert(isinstance(collector._fact_class._module, NetworkCollector._FakeModule))
    assert(collector._fact_class._module.platform == 'AIX')

# Generated at 2022-06-11 03:06:16.709060
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/bin/ifconfig'
    x = AIXNetwork()
    interfaces, ips = x.get_interfaces_info(ifconfig_path)
    assert 'en0' in interfaces
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['macaddress'] == '00:00:5a:9c:5a:77'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['ipv4'][0]['address'] == '10.119.128.58'
    assert interfaces['en0']['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:06:27.414779
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    cmd = AnsibleCmdCollecNetwork(module)
    default_interfaces = cmd.get_default_interfaces('/usr/bin/route')
    assert len(default_interfaces) == 2
    assert default_interfaces['v4']['gateway'] == '172.17.0.1'
    assert default_interfaces['v4']['interface'] == 'en0'
    assert default_interfaces['v6']['gateway'] == 'fe80::250:56ff:fe84:3865'
    assert default_interfaces['v6']['interface'] == 'en0'

# Generated at 2022-06-11 03:06:31.505153
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:06:42.278779
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # pylint: disable=import-error,no-member,no-name-in-module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.aix import AIXNetwork

    net = AIXNetwork(AnsibleModule(argument_spec={}))

    interfaces = net.get_default_interfaces(route_path=None)
    assert type(interfaces) == tuple
    assert len(interfaces) == 2
    assert type(interfaces[0]) == dict
    assert type(interfaces[1]) == dict

    assert type(interfaces[0]['gateway']) == str
    assert type(interfaces[0]['interface']) == str

    assert type(interfaces[1]['gateway']) == str

# Generated at 2022-06-11 03:06:49.870000
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Tests if AIXNetwork.get_interfaces_info() doesn't fail."""

    from io import StringIO

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines

    # First run with real file
    aix_net = AIXNetwork(ansible_collector)
    aix_net.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

    # Second run with fake file
    aix_net = AIXNetwork(ansible_collector)
    fake_file = StringIO(get_file_lines('/usr/sbin/ifconfig', module=aix_net.module))
    aix

# Generated at 2022-06-11 03:06:59.464322
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()

    uname_rc = None
    uname_out = None
    uname_err = None
    uname_path = module.get_bin_path('uname')
    if uname_path:
        uname_rc, uname_out, uname_err = module.run_command([uname_path, '-W'])

    # AIX LPAR netstat output
    if uname_rc or uname_out.split()[0] != '0':
        rc, out, err = module.run_command(['/usr/bin/netstat', '-nr'])
        print(out)

# Generated at 2022-06-11 03:07:01.907762
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    res = AIXNetwork.get_default_interfaces(None)
    assert len(res) == 2

# Generated at 2022-06-11 03:07:06.752494
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''Unit test of class AIXNetworkCollector'''

    ansible_module_mock = AnsibleModuleMock()
    ansible_module_mock.param = {}
    network_collector = AIXNetworkCollector(ansible_module_mock)
    assert isinstance(network_collector.fact_class, AIXNetwork)
    assert network_collector.platform == 'AIX'


# Generated at 2022-06-11 03:07:15.883001
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    uname_out = '0\n'
    uname_err = ''
    uname_rc = 0
    import ansible.module_utils.facts.network.generic_bsd
    ansible.module_utils.facts.network.generic_bsd.uname_out = uname_out
    ansible.module_utils.facts.network.generic_bsd.uname_err = uname_err
    ansible.module_utils.facts.network.generic_bsd.uname_rc = uname_rc

    import ansible.module_utils.facts.network.aix
    ansible.module_utils.facts.network.aix.uname_out = uname_out
    ansible.module_utils.facts.network.aix.uname_err = uname_err
    ansible.module_

# Generated at 2022-06-11 03:07:47.093773
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.run_command.return_value = (0, 'default 192.168.122.1 UG 1 192.168.122.5 en0\ndefault 192.168.122.1 UG 2 192.168.122.5 en1', None)
    aixnet = AIXNetwork(module)
    i = aixnet.get_default_interfaces(None)
    assert i == ({'gateway': '192.168.122.1', 'interface': 'en0'}, None)


# Generated at 2022-06-11 03:07:48.132975
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)



# Generated at 2022-06-11 03:07:53.483124
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    collector = AIXNetworkCollector()
    net_facts = collector.get_network_facts()
    network = net_facts['ansible_network_resources']
    interface_info = network['default_ipv4'], network['default_ipv6']
    assert interface_info == ({'gateway': '172.16.20.1', 'interface': 'en0'}, {})

# Generated at 2022-06-11 03:08:01.603827
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:08:12.191720
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        route_path='/usr/bin/netstat'
    )
    network_collector = AIXNetworkCollector(module, list(), dict())
    network = network_collector._fact_class(network_collector)

    # no gateway
    module.params = dict(
        route_path=None
    )
    ifmod = network.get_default_interfaces(module.params['route_path'])
    assert ifmod == dict(v4=dict(), v6=dict())

    # with gateway
    module.params = dict(
        route_path='/usr/bin/netstat'
    )
    ifmod = network.get_default_interfaces(module.params['route_path'])

# Generated at 2022-06-11 03:08:22.411619
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class Options:
        def __init__(self):
            self.bin_path = {'uname': '/usr/bin/uname'}

        def get_bin_path(self, name, required=False):
            return self.bin_path[name]

    class Module:
        def __init__(self):
            self.options = Options()

        def run_command(self, cmd):
            if cmd[0].endswith('uname'):
                return 0, '0', None
            elif cmd[0].endswith('netstat') and cmd[1] == '-nr':
                return 0, 'default 172.28.128.1 UG 0 en0 default fe80::%eth0 UG 0 en0', None

# Generated at 2022-06-11 03:08:32.398172
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Options:
        def __init__(self):
            def run_command(cmd):
                if cmd[0] == '/usr/sbin/ifconfig' and cmd[1] == '-a':
                    return (0, test_output_ifconfig_a, "")
                if cmd[0] == '/usr/bin/uname':
                    return (0, "0 WPAR", "")
                if cmd[0] == '/usr/sbin/entstat' and cmd[1] == 'en0':
                    return (0, test_output_entstat, "")
                if cmd[0] == '/usr/bin/lsattr' and cmd[1] == '-El' and cmd[2] == 'en0':
                    return (0, test_output_lsattr, "")

# Generated at 2022-06-11 03:08:40.478153
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    network_collector = AIXNetworkCollector(module=module)

    network_collector.FACT_SUBSETS = dict(default='interfaces', custom='!all')
    network_collector.GATHER_SUBSET = '!all'

    result = network_collector.get_default_interfaces('/sbin/route')
    assert result['interface4'] == 'en0'
    assert result['gateway4'] == '172.20.10.1'

    assert result['interface6'] == 'en0'
    assert result['gateway6'] == 'fe80::200:5eff:fe00:2b21'

# Generated at 2022-06-11 03:08:49.780011
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    l = AIXNetwork()

# Generated at 2022-06-11 03:08:52.098947
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._fact_class is AIXNetwork
    assert collector._platform is 'AIX'

# Generated at 2022-06-11 03:09:41.181684
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert isinstance(collector._platform, str)
    assert isinstance(collector._fact_class, AIXNetwork)
    assert collector._platform == 'AIX'


# Generated at 2022-06-11 03:09:46.023158
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes


# Generated at 2022-06-11 03:09:54.364684
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class Module:
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'ifconfig':
                return '/usr/sbin/ifconfig'
            if args[0] == 'netstat':
                return '/usr/bin/netstat'
            if args[0] == 'uname':
                return '/usr/bin/uname'
            if args[0] == 'entstat':
                return '/usr/bin/entstat'
            if args[0] == 'lsattr':
                return '/usr/sbin/lsattr'


# Generated at 2022-06-11 03:10:03.201350
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    an = AIXNetwork(None)

    interfaces, ips = an.get_interfaces_info(ifconfig_path='/bin/ifconfig', ifconfig_options='-a')

    assert interfaces
    assert ips

    assert interfaces['lo0']['macaddress']
    assert interfaces['lo0']['ipv4']
    assert interfaces['lo0']['ipv6']
    assert interfaces['lo0']['type']
    assert interfaces['lo0']['flags']
    assert interfaces['lo0']['device']

    assert 'en0' in interfaces
    assert 'en1' in interfaces
    assert 'en2' in interfaces
    assert 'en3' in interfaces


# Generated at 2022-06-11 03:10:13.073324
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    def run_generic_bsd_ifconfig_network_fun(module, ifconfig_path, ifconfig_options='-a'):
        """
        Method to run the GenericBsdIfconfigNetwork._get_interfaces_info() with unittest.mock
        """
        network = GenericBsdIfconfigNetwork()
        return network.get_interfaces_info(module, ifconfig_path, ifconfig_options)

    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    from unittest.mock import patch


# Generated at 2022-06-11 03:10:18.541995
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = type('Module', (object,), {})
    test_AIXNetwork = AIXNetwork(test_module)

    ifconfig_path = test_module.get_bin_path('ifconfig')
    if config_path:
        rc, out, err = test_module.run_command([ifconfig_path, '-a'])
        interfaces, ips = test_AIXNetwork.get_interfaces_info(ifconfig_path, ifconfig_options='-a')
        assertTrue(interfaces)
        assertTrue(ips)


# Generated at 2022-06-11 03:10:26.557248
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ AIXNetwork - get_interfaces_info() """

    AIXN = AIXNetwork({})
    ifconfig_path = '/etc/ansible/facts/ifconfig.aix.file'
    ifconfig_options = '-a'

    # Unit test: default
    interfaces, ips = AIXN.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-11 03:10:29.690684
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import sys
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    if sys.version_info[0] < 3:
        assert issubclass(AIXNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:10:31.815194
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert result.platform == 'AIX'
    assert result.fact_class == AIXNetwork


# Generated at 2022-06-11 03:10:39.320692
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    module.run_command.fake_returns = [0,
                                       "netstat: -a is not supported",
                                       '']
    net = AIXNetwork(module)
    expected_v4 = {'gateway': '192.168.0.1',
                   'interface': 'en1'}
    expected_v6 = {'gateway': 'fe80::5054:ff:fe32:46e',
                   'interface': 'en1'}
    v4, v6 = net.get_default_interfaces("")
    assert v4 == expected_v4
    assert v6 == expected_v6



# Generated at 2022-06-11 03:12:14.092222
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    aixNetworkCollector = AIXNetworkCollector()

    assert aixNetworkCollector._fact_class == AIXNetwork
    assert aixNetworkCollector._platform == 'AIX'


# Generated at 2022-06-11 03:12:20.411428
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()

    net.module = Mock(return_value=Mock())
    net.module.get_bin_path = Mock(return_value='/usr/bin/netstat')
    net.module.run_command = Mock(return_value=(0, netstat_out, ''))

    # IPv4 gateway
    net.module.run_command.return_value = (0, netstat_out, '')
    interface, ipv6_interface = net.get_default_interfaces('/usr/bin/netstat')
    assert interface['gateway'] == '10.1.1.1'
    assert interface['interface'] == 'en0'

    # IPv6 gateway
    net.module.run_command.return_value = (0, netstat_ipv6_out, '')
    interface, ip

# Generated at 2022-06-11 03:12:30.898998
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    import sys
    import os.path
    test_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, test_dir)

    from test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    # Create the AIXNetwork instance
    network_collector = NetworkCollector()
    network_fact_class = AIXNetwork(network_collector)

    # create the test_class instance
    aix_network = AIXNetworkCollector(network_fact_class).get_network_facts()[0]

    # create the module
    module = AnsibleModule({})

    # create the result
    test_gateway_v4 = '123.123.123.123'

# Generated at 2022-06-11 03:12:40.706160
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    params = {
        'path': '/usr/sbin/ifconfig',
        'route': '/usr/sbin/route'
    }

    test_module = NetworkCollectorTestModule([params])
    test_AIXNetwork = AIXNetwork(test_module)

    # set test data for the method
    test_module.set_command_response(DICT_AIX_NETSTAT_NR_OUT, rc=0)

    # run method
    test_AIXNetwork.get_default_interfaces('/usr/sbin/route')

    # check results
    assert test_AIXNetwork._default_ipv4_network['gateway'] == '172.17.1.1'
    assert test_AIXNetwork._default_ipv4_network['interface'] == 'en0'
    assert test_AIXNetwork._default

# Generated at 2022-06-11 03:12:44.847077
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Unit test for constructor of class AIXNetworkCollector."""
    network_collector = AIXNetworkCollector()

    assert isinstance(network_collector, NetworkCollector)
    assert isinstance(network_collector.facts, AIXNetwork)
    assert network_collector.platform == 'AIX'


# Generated at 2022-06-11 03:12:49.371776
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    _module = AnsibleModule(argument_spec=dict())    # just for testing - no params
    _module.run_command = MagicMock(return_value=(0, "", ""))
    _module.exit_json = MagicMock()

    _network = AIXNetwork(_module)

    assert _network.get_default_interfaces(None) == ({}, {})



# Generated at 2022-06-11 03:12:50.763013
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.__class__.__name__ == 'AIXNetworkCollector'

# Generated at 2022-06-11 03:12:59.656381
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    m = AIXNetwork()

    # Test with an empty string
    output = ""
    expected = {"v4": {}, "v6": {}}
    result = m.get_default_interfaces(output)
    assert result == expected

    # Test with empty lines
    output = "\n\n"
    expected = {"v4": {}, "v6": {}}
    result = m.get_default_interfaces(output)
    assert result == expected

    # Test with a v4 default gateway
    output = "default        10.10.10.1 \t UG \t\t 0 0    en0\n"

# Generated at 2022-06-11 03:13:02.669235
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    an = AIXNetwork()
    an.get_default_interfaces('route -n')



# Generated at 2022-06-11 03:13:04.894399
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts_object = AIXNetworkCollector(None)
    assert facts_object._fact_class == AIXNetwork
    assert facts_object.platform == 'AIX'