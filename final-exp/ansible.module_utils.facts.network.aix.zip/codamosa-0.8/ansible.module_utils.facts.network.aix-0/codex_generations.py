

# Generated at 2022-06-11 03:04:30.784342
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork()
    netstat_path = network.module.get_bin_path('netstat')

    rc, out, err = network.module.run_command([netstat_path, '-nr'])

    ref_out = """Routing tables

Internet:
Destination        Gateway            Flags  Ref  Use  If  Exp  Groups
default            192.168.1.1         UG        0        1  en0
192.168.1          link#4             UC        0        -  en0
192.168.1.1        00-00-00-00-00-00  UHLc       0        -  en0
127.0.0.1          127.0.0.1          UH        0        -  lo0
"""

    assert out == ref_out


# Generated at 2022-06-11 03:04:41.157830
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network import NetworkCollector
    nc = NetworkCollector()
    netmod = nc.collect()[0]

    # if default interfaces are not empty, return them
    # otherwise, return an empty dict
    def_ipv4, def_ipv6 = netmod.get_default_interfaces('/sbin/route')
    if def_ipv4:
        assert def_ipv4['gateway']
        assert def_ipv4['interface']
    else:
        assert def_ipv4 == {}
    if def_ipv6:
        assert def_ipv6['gateway']
        assert def_ipv6['interface']
    else:
        assert def_ipv6 == {}



# Generated at 2022-06-11 03:04:42.141375
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-11 03:04:49.348839
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Results of running /usr/bin/netstat -nr
    default_gateway_dict = {'v6': {'gateway': 'fe80::223:6cff:fea3:3bf3%en1', 'interface': 'en1'}, 'v4': {'gateway': '10.1.1.1', 'interface': 'en0'}}
    default_gateway = default_gateway_dict.get('v4')
    default_gateway_6 = default_gateway_dict.get('v6')

    # Results of running /usr/bin/netstat -nr

# Generated at 2022-06-11 03:05:00.024903
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network_collector = AIXNetworkCollector()
    aix_network = aix_network_collector._fact_class
    aix_network.module = module
    route_path = '/usr/bin/route'
    route_output = '''
default        192.168.1.1        UG        0 0        en0
default        fe80::%utun2      UGHS        0    0    utun2
'''
    aix_network.module.run_command = mock.Mock(return_value=(0, route_output, ""))
    v4, v6 = aix_network.get_default_interfaces(route_path)
    assert v4['interface'] == 'en0'
    assert v4['gateway'] == '192.168.1.1'
    assert v6

# Generated at 2022-06-11 03:05:09.225976
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create test class instance
    class TestInstance(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            for param in self.args:
                if param == args[0]:
                    return param
            for key in self.kwargs:
                if key == args[0]:
                    return args[0]

        def run_command(self, *args, **kwargs):
            if args[0][0] == 'netstat':
                if '-nr' in args[0]:
                    return 0, 'default 216.58.212.174 UG 0 0 en0', ''
            return 0, '', ''
    module = TestInstance('netstat')

# Generated at 2022-06-11 03:05:11.713893
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    assert facts.platform == "AIX"


# Generated at 2022-06-11 03:05:20.562510
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestModule:
        def __init__(self):
            self.params = dict()
            self.debugmsg = list()
            self.fail_json = dict()
            self.exit_json = dict()
            self.run_command = dict()

        def get_bin_path(self, name, required=False):
            cmd = None
            if name == 'netstat':
                cmd = '/usr/bin/netstat'
            return cmd

        def run_command(self, cmd):
            output = dict()
            output['cmd'] = ' '.join(cmd)

# Generated at 2022-06-11 03:05:26.647316
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json
    import sys

    my_obj = AIXNetwork()
    interfaces, ips = my_obj.get_interfaces_info('/usr/bin/ifconfig', '-a')
    print(json.dumps(interfaces, sort_keys=True, indent=4))
    print(json.dumps(ips, sort_keys=True, indent=4))


# Generated at 2022-06-11 03:05:29.833903
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork(dict(module=None))
    interface = dict(v4={}, v6={})
    assert network.get_default_interfaces('/sbin/route') == (interface['v4'], interface['v6'])

# Generated at 2022-06-11 03:05:51.563401
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.utils import get_ifconfig_path
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils._text import to_bytes
    import os

    ifconfig_path = get_ifconfig_path()
    test_data_file = os.path.join(os.path.dirname(__file__), 'test_data.interfaces_aix')
    with open(test_data_file, 'rb') as f:
        test_data = to_bytes(f.read())

    class MockModule(object):
        class MockRunCommand(object):
            def __init__(self, module):
                self.module = module

            def __call__(self, *args, **kwargs):
                return 0, test_

# Generated at 2022-06-11 03:06:02.281167
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_obj = AIXNetwork()

    # ifconfig_path = "/test/bin/ifconfig"
    test_obj.module.params['ifconfig_path'] = '/test/bin/ifconfig'

    # ifconfig_options = "-a"
    test_obj.module.params['ifconfig_options'] = '-a'

    interfaces_info_res = test_obj.get_interfaces_info('/test/bin/ifconfig', '-a')

# Generated at 2022-06-11 03:06:12.495243
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    from os import path
    from argparse import Namespace

    fake_module = Namespace()
    fake_module.run_command = run_command

    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from ansible.module_utils.facts.network.aix import AIXNetwork

    ansible_aix = AIXNetwork(fake_module)
    interfaces, ips = ansible_aix.get_interfaces_info('ifconfig')
    assert len(interfaces) == 3
    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert 'en1' in interfaces
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['en0']['device'] == 'en0'
   

# Generated at 2022-06-11 03:06:15.608642
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of AIXNetworkCollector class
    """
    am = AIXNetworkCollector()
    assert am is not None
    assert isinstance(am, NetworkCollector)
    assert am._fact_class == AIXNetwork


# Generated at 2022-06-11 03:06:27.621311
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:30.240294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector != ''
    collector = AIXNetworkCollector()
    assert collector != ''


# Generated at 2022-06-11 03:06:34.294499
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.collector.network.base import NetworkCollector
    aix_net = NetworkCollector()
    assert aix_net is not None
    assert aix_net.facts == aix_net.get_all_facts()


# Generated at 2022-06-11 03:06:37.281922
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'path': dict(required=True),
    })

    net = AIXNetwork()

    net.get_default_interfaces(module.params['path'])

# Generated at 2022-06-11 03:06:47.265579
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test function for get_interfaces_info of class AIXNetwork
    """

    def mock_run_cmd(cmd):
        """
        Mock function for module.run_command
        """

        if cmd == ['/usr/bin/uname', '-W']:
            return 0, "0", None

        if cmd == ['/usr/bin/ifconfig', '-a']:
            return 0, ifconfig_out, None

        if cmd == ['/usr/bin/netstat', '-nr']:
            return 0, netstat_out, None

        if cmd == ['/usr/sbin/lsattr', '-El', 'en0']:
            return 0, "mtu    65536\n", None


# Generated at 2022-06-11 03:06:56.836930
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import NetworkFactsParams
    from ansible.module_utils.facts.network.generic_bsd import NetworkConfigParams
    from ansible.module_utils.facts.network import Network
    from ansible.module_utils.facts.network.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import b
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', default=['all']),
            'gather_network_resources': dict(type='list', default=['all']),
        },
        supports_check_mode=True)

# Generated at 2022-06-11 03:07:30.534841
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # test for class constructor
    assert issubclass(AIXNetworkCollector, NetworkCollector)



# Generated at 2022-06-11 03:07:38.544155
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not MODULE_UTILS_PATH:
        return module.fail_json(msg="module.utils required for this module")

    # dummy arguments
    tmpdir = tempfile.mkdtemp()
    route_path = os.path.join(tmpdir, "route")
    route_file = open(route_path, "w")
    route_file.write("default   10.10.10.1        UG     1       0        en0\n")
    route_file.write("default   fd00::1          UGDA256 1       0        en0\n")
    route_file.close()

   

# Generated at 2022-06-11 03:07:48.217834
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:58.588844
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    """
    Network module class AIXNetwork method get_interfaces_info tests
    """
    class Tester(object):
        def __init__(self):
            self.bin_path = None
        def get_bin_path(self, arg):
            return self.bin_path

    class TestModule(object):
        def __init__(self):
            self.exit_json = None
            self.fail_json = None
        def run_command(self, arg):
            return self.rc, self.out, self.err

    test_module = TestModule()
    tester = Tester()
    test_obj = AIXNetwork(test_module, tester)

    # test valid network output
    test_module.rc = 0

# Generated at 2022-06-11 03:08:08.378078
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-11 03:08:15.708695
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Setup a test module and its associated Network class
    import ansible.module_utils.facts.network.aix
    import os
    file_path = os.path.dirname(__file__)
    dummy_ansible_module = type('DummyAnsibleModule', (object,), {'_load_params': lambda *args, **kwargs: None,
                                                                  'exit_json': lambda *args, **kwargs: None,
                                                                  'fail_json': lambda *args, **kwargs: None,
                                                                  'run_command': lambda *args, **kwargs: (0, '', ''),
                                                                  'get_bin_path': lambda *args, **kwargs: file_path + '/fake_netstat',
                                                                  'params': dict(group='')})
   

# Generated at 2022-06-11 03:08:24.753803
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:08:25.902757
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)


# Generated at 2022-06-11 03:08:34.836220
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-11 03:08:37.214320
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    assert facts._fact_class == AIXNetwork
    assert facts._platform == 'AIX'


# Generated at 2022-06-11 03:09:33.827688
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    ArgumentSpec = basic.AnsibleModule.argument_spec
    FactsParams = collector.Params


# Generated at 2022-06-11 03:09:40.927464
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class ModuleStub:
        def run_command(self, cmd):
            with open("/tmp/aix-ifconfig-a", "r") as f:
                out = f.read()
            return 0, out, ""
        def get_bin_path(name):
            return "/usr/sbin/%s" % name
    
    m = ModuleStub()
    a = AIXNetwork(m)
    a.get_interfaces_info("/usr/sbin/ifconfig")
    print(a.interfaces_info)
    print(a.default_interfaces)
    print(a.interfaces)

# Generated at 2022-06-11 03:09:45.838169
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ansible_module_mock = lambda: None
    ansible_module_mock.get_bin_path = lambda x: '/usr/bin/path/' + x
    ansible_module_mock.run_command = lambda x: (0, '/usr/bin/path/netstat -nr\n\
default      10.0.0.1 UGS         0        10 en11\n\
default      ::/96     UGRS                0 en11\n\
', 'error')
    network_collector = AIXNetwork(ansible_module_mock)
    interface = network_collector.get_default_interfaces(None)
    assert interface != {'interface': 'en1', 'gateway': '10.0.0.1'}

# Generated at 2022-06-11 03:09:54.194620
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ANE = AIXNetwork(module)

    route_path = '/usr/bin/route'
    v4, v6 = ANE.get_default_interfaces(route_path)

    # Check v4 and v6 are empty dict
    assert v4 == {}
    assert v6 == {}

    # Check v4 and v6 are populated
    out = '''
default 192.168.1.1 UG 0 0 en0
default 192.168.1.1 UG 0 0 en0
default 192.168.1.1 UG 0 0 en0
    '''
    ANE.module.run_command = Mock(return_value=(0, out, ''))
    v4, v6 = ANE.get_default_interfaces(route_path)
    assert v

# Generated at 2022-06-11 03:10:03.053838
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    from ansible.module_utils.facts.network.generic_bsd import NetworkModuleTestCase
    test_group1 = NetworkModuleTestCase.NetworkTestGroup('Default Interfaces')
    test_group1.add_test(NetworkModuleTestCase.ModuleTest('Should find all interfaces.', {
        'default_ipv4_interface': 'en0',
        'default_ipv6_interface': 'en0'
    }, {
        'route_path': os.path.join('..', '..', '..', 'test', 'network', 'route.linux')
    }))

# Generated at 2022-06-11 03:10:08.584314
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_fact = AIXNetwork(dict(module=None))
    test_params = {'route_path': None}
    test_result = AIXNetwork.get_default_interfaces(test_fact, **test_params)
    assert isinstance(test_result, tuple) and len(test_result) == 2
    assert isinstance(test_result[0], dict) and isinstance(test_result[1], dict)


# Generated at 2022-06-11 03:10:17.242223
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import Collector

    import os
    from ansible.module_utils.facts.network.aix import AIXNetwork

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )

    # capture the netstat command output
    test_file = os.path.join(os.path.dirname(__file__), 'netstat_aix.out')
    with open(test_file, 'rb') as netstat_output:
        netstat_out = to_bytes(netstat_output.read())

    #

# Generated at 2022-06-11 03:10:23.138639
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    filename = 'aix_netstat_nr'
    mock_module = get_mock_module(filename)
    network = AIXNetwork(mock_module, filename)
    default_interfaces = network.get_default_interfaces(None)
    assert len(default_interfaces) == 2
    assert default_interfaces[0] == {'interface': 'en0', 'gateway': '192.0.2.2'}
    assert default_interfaces[1] == {'interface': 'en0', 'gateway': '2001:db8:1::1'}


# Generated at 2022-06-11 03:10:32.040163
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class ModuleStub(object):
        @staticmethod
        def get_bin_path(a):
            return a

        @staticmethod
        def run_command(a):
            if 'netstat' in a:
                return 0, 'default 0.0.0.0 UG 0 0 en0\ndefault ::1 UG 0 0 en0', None
            else:
                return 0, '+1 +2 +3', None

    class AIXNetworkStub(AIXNetwork):
        def __init__(self, module):
            self.module = module

    r = AIXNetworkStub(ModuleStub)

# Generated at 2022-06-11 03:10:40.153726
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # If a network collector returns 'None' for its platform,
    # the generic network collector will be used instead.
    if not AIXNetwork.platform:
        assert False, "Platform should not be 'None'"

    # We use the 'GenericBsdIfconfigNetwork' class as an example,
    # but other classes may be used as well.
    assert AIXNetwork.__bases__[0] == GenericBsdIfconfigNetwork, "AIXNetwork does not inherit from GenericBsdIfconfigNetwork"

    # Test for version 7.1

# Generated at 2022-06-11 03:12:15.673567
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_class = AIXNetworkCollector.get_fact_class()
    assert fact_class == AIXNetwork

# Generated at 2022-06-11 03:12:19.187412
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net = AIXNetworkCollector()

    assert type(net) is AIXNetworkCollector
    assert net.platform == 'AIX'
    assert net._platform == 'AIX'
    assert type(net._fact_class) is AIXNetwork



# Generated at 2022-06-11 03:12:20.186235
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:12:30.661051
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self, module_name):
            self.module_name = module_name
            self.bin_path = {}

        def get_bin_path(self, name):
            if name in self.bin_path:
                return self.bin_path[name]
            return None

        def run_command(self, cmd):
            if cmd[0] == self.bin_path['ifconfig']:
                if out_str is not None:
                    return self.rc, out_str, err_str
                else:
                    return self.rc, out, err
            elif cmd[0] == self.bin_path['uname']:
                if name_out_str is not None:
                    return self.name_rc, name_out_str, name_err_str
               

# Generated at 2022-06-11 03:12:40.349726
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    if sys.version_info[0] < 3:
        raise Exception('Python 3 required.')

    # AIX 6.1

# Generated at 2022-06-11 03:12:43.616706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor name test.
    Is an instance of NetworkCollector.
    """
    aixnc = AIXNetworkCollector(None)
    assert isinstance(aixnc, NetworkCollector)


# Generated at 2022-06-11 03:12:51.828011
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    import ansible.module_utils.facts.network.aix as sut

    def mocked_run_command(cmd, check_rc=True):
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        test_dir = os.path.join(base_dir, 'network/aix/test_netstat_command_output')
        netstat_test_file = os.path.join(test_dir, 'netstat_test_file')

        return (0, netstat_test_file, '')

    sut.run_command = mocked_run_command

    obj = sut.AIXNetwork()

    obj.get_default_interfaces('route')


# Generated at 2022-06-11 03:12:52.303706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector

# Generated at 2022-06-11 03:13:00.294293
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    import sys

    class MockModule(object):

        class ModuleFailException(Exception):
            pass

        class RunCommandException(Exception):
            pass

        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.run_command_exceptions = []

        def fail_json(self, **kwargs):
            raise self.ModuleFailException(kwargs)

        def get_bin_path(self, *args, **kwargs):
            return '/bin/netstat'


# Generated at 2022-06-11 03:13:09.617748
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    m = AIXNetwork()

    config = '''
lo0: flags=8c02 <loopback> mtu 8232
        index 1
        inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
en0: flags=8802 <broadcast,simplex,multicast> mtu 1500
        index 2
        lladdr 08:00:27:86:8b:f1
        media: Ethernet autoselect
en1: flags=8802 <broadcast,simplex,multicast> mtu 1500
        index 3
        lladdr 08:00:27:6e:28:e5
        media: Ethernet autoselect
'''

    # 1. v4 and v6 not supported
    ifconfig_path = "/bin/ifconfig"
    interfaces, ips = m.get_