

# Generated at 2022-06-11 03:04:30.784352
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    module.run_command.side_effect = [
        (0, 'default 169.254.0.1 UG 2 0 en0', ''),
        (0, 'default ::1 UGSc 2 0 lo0', '')
    ]

    network = AIXNetwork(module)

    default_v4, default_v6 = network.get_default_interfaces('/sbin/route')

    assert default_v4 == dict(gateway='169.254.0.1', interface='en0')
    assert default_v6 == dict(gateway='::1', interface='lo0')


from ansible.module_utils.facts.collector import BaseFactCollector



# Generated at 2022-06-11 03:04:41.460143
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/bin/ifconfig'

    ifconfig_rc, ifconfig_out, ifconfig_err = (1, "", "text")
    netstat_path = '/usr/bin/netstat'

    netstat_rc, netstat_out, netstat_err = (0, "default            192.168.1.1        UGS         en1\n", "text")

    #
    # This is the test of the old AIX method with netstat output
    #
    def run_command(self, command, check_rc=True, close_fds=True):
        if command[0] == ifconfig_path:
            return ifconfig_rc, ifconfig_out, ifconfig_err
        if command[0] == netstat_path:
            return netstat_rc, netstat_out,

# Generated at 2022-06-11 03:04:44.351550
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == "AIX"
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert isinstance(AIXNetworkCollector._fact_class, object)

# Generated at 2022-06-11 03:04:54.725605
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Simple test to check if we get at least one interface
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils._text import to_bytes

    def get_bin_path(module_name):
        # return path of a 'bin' module
        return module_name


# Generated at 2022-06-11 03:04:55.946433
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:05:05.471557
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    net = AIXNetwork()
    net.module.run_command = mock_run_command

    result = net.get_interfaces_info('/sbin/ifconfig', '-a')

# Generated at 2022-06-11 03:05:07.425398
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:09.225613
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:05:14.389526
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # Create a AIXNetworkCollector without parameters
    ans = AIXNetworkCollector()

    # check name of the class
    assert ans.__class__.__name__ == 'AIXNetworkCollector'

    # check _platform
    assert ans._platform == 'AIX'

# Generated at 2022-06-11 03:05:19.782555
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    network_collector = AIXNetworkCollector(module, [ifconfig_path])
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['ansible_facts']['ansible_net_interfaces']
    assert facts['ansible_facts']['ansible_net_all_ipv4_addresses']


# Generated at 2022-06-11 03:05:36.259695
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    res = dict(
        v4=dict(gateway='192.0.0.254', interface='en0'),
        v6=dict(gateway='fe80::21a:4aff:fe2c:8b3', interface='en0'),
    )
    ans = AIXNetwork.get_default_interfaces('/usr/bin/netstat -nr')

    assert ans == res

# Generated at 2022-06-11 03:05:40.230668
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork
    """
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-11 03:05:49.868128
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:00.705719
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    test_default_interfaces_line verifies that the default interface is
    properly parsed from the output of 'netstat -nr'.
    """

    # test data 1

# Generated at 2022-06-11 03:06:11.257231
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    def run(expected, out):
        mod = get_module_mock(params={'gather_default_info': True})
        mod.run_command.return_value = (0, out, '')
        net = AIXNetwork(mod)
        result = net.get_default_interfaces('')
        if result != expected:
            print("FAIL: result=%s expected=%s" % (result, expected))
        else:
            print("OK")

    run({'interface': 'en0', 'gateway': '10.1.1.1'}, "default 10.1.1.1 UG en0")
    run({'interface': 'en0', 'gateway': '10.1.1.1'}, "default 10.1.1.1  UG en0")

# Generated at 2022-06-11 03:06:19.590853
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:21.928208
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_nc = AIXNetworkCollector()
    assert aix_nc.get_facts() == None

# Generated at 2022-06-11 03:06:24.070559
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), object)

# Generated at 2022-06-11 03:06:32.489999
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from . import aix_ifconfig_a
    from ansible.module_utils.facts.network.aix import AIXNetwork

    network_ob = AIXNetwork()
    network_ob.module = type('', (), {'run_command': run_command})
    network_ob.module.get_bin_path = get_bin_path
    ifconfig_path = network_ob.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

    interfaces, ips = network_ob.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces == aix_ifconfig_a.AIX_INTERFACES
    assert ips == aix_ifconfig_a.AIX_IPS



# Generated at 2022-06-11 03:06:43.512486
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        import subprocess
    except ImportError:
        return

    output = subprocess.check_output(['netstat', '-nr']).decode('utf-8')
    lines = output.splitlines()
    def_found = False
    gateway_found = False
    device_found = False
    for line in lines:
        words = line.split()
        if len(words) > 1 and words[0] == 'default' and words[1] == '192.168.1.1':
            def_found = True
        if len(words) > 1 and words[0] == 'default' and words[1] == '192.168.1.1':
            gateway_found = True

# Generated at 2022-06-11 03:07:11.961407
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    network_collector = AIXNetworkCollector(module)
    network = network_collector.get_network_instance()
    route_path = network.module.get_bin_path('route')
    iv4, iv6 = network.get_default_interfaces(route_path)

    assert isinstance(iv4, dict)
    assert isinstance(iv6, dict)


# -------------------- AIX Ifconfig Class Tests ----------------------------------------

# Generated at 2022-06-11 03:07:12.856683
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:07:19.161690
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''Unit test for class AIXNetworkCollector'''
    # 'AIXNetworkCollector' inherits from superclass 'NetworkCollector'
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    # Create an object of class 'AIXNetworkCollector'
    aix_net_coll = AIXNetworkCollector()
    # Check that the object is an instance of class 'AIXNetworkCollector'
    assert isinstance(aix_net_coll, AIXNetworkCollector)
    # Check that the attribute 'platform' of 'AIXNetworkCollector' has the value 'AIX'
    assert aix_net_coll._platform == 'AIX'
    # Check that the attribute 'fact_class' of 'AIXNetworkCollector' has the value 'AIXNetwork'
    assert aix_net_coll._fact

# Generated at 2022-06-11 03:07:22.144756
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    nc = AIXNetworkCollector()
    assert nc
    assert nc.get_device_to_ip_linktype_mappings()

# Generated at 2022-06-11 03:07:28.304493
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'network_facts': {'default': 'n'}})
    network_facts_obj = AIXNetwork(module)

    result_dict = network_facts_obj.get_default_interfaces('/netstat')
    assert result_dict == {}, "get_default_interfaces returned " + str(result_dict) +\
        " on AIX instead of {}"



# Generated at 2022-06-11 03:07:30.181037
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector.fact_class == AIXNetwork


# Generated at 2022-06-11 03:07:38.299924
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-11 03:07:39.596424
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)


# Generated at 2022-06-11 03:07:42.601666
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = {}
    net = AIXNetworkCollector(facts, None)
    assert net.facts is facts
    assert AIXNetworkCollector.platform is 'AIX'

# Generated at 2022-06-11 03:07:50.281544
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    aix_network = AIXNetwork(dict(module=None))

    aix_network.module.run_command = fake_run_command


# Generated at 2022-06-11 03:08:38.005521
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Unit test for constructor of class AIXNetworkCollector"""
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:08:45.650608
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class AIXNetwork.
    """
    test = {
        'v4': {
            'gateway': '10.1.1.1',
            'interface': 'en0'
        },
        'v6': {
        }
    }
    module = NetworkCollector._get_module(platform='AIX')
    facts_network = AIXNetwork(module)

    actual_result = facts_network.get_default_interfaces('/usr/bin/netstat')
    assert actual_result['v4'] == test['v4']
    assert actual_result['v6'] == test['v6']



# Generated at 2022-06-11 03:08:49.105783
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert NetworkCollector is not None
    collector = AIXNetworkCollector()
    assert collector is not None
    assert collector._fact_class is not None
    assert collector._platform == "AIX"

# Unit tests for AIXNetworkCollector:get_default_interfaces()

# Generated at 2022-06-11 03:08:58.572384
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class AIXNetwork'''
    # This code is based on AIX7.2 output of 'ifconfig -a', it covers all different
    # lines parsed by 'parse_*' methods and also several different lines after
    # 'ifconfig -a' in out.splitlines():
    # some fake interfaces to prevent errors
    p = re.compile('^en([0-9]+[A-Z]*[0-9]*)s[0-9]+$')
    ifaces = {}
    for m in p.finditer('en1 en2s0 en3s0 en2s1 en3s1'):
        ifaces[m.group(0)] = {}

# Generated at 2022-06-11 03:09:01.498426
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    my_obj = AIXNetworkCollector()

    assert my_obj is not None
    assert my_obj._platform == 'AIX'


# Generated at 2022-06-11 03:09:05.408255
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    NETWORK_COLLECTOR = AIXNetworkCollector()
    assert NETWORK_COLLECTOR.platform == 'AIX'
    assert NETWORK_COLLECTOR._cache_expiration == 3600
    assert NETWORK_COLLECTOR._cache_file == '/opt/ansible/facts/ansible_local.fact'
    assert NETWORK_COLLECTOR._fact_class == AIXNetwork


# Generated at 2022-06-11 03:09:08.404852
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.get_device_name(
        '/etc/hostname.eno59') == 'eno59'
    assert AIXNetworkCollector.get_device_name(
        '/etc/hostname.eno59:1') == 'eno59:1'

# Generated at 2022-06-11 03:09:16.809930
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    facts_dict = dict(default_interfaces=dict())
    module = FakeModule(facts_dict, dict())
    m_condition = 'ansible_net_version_major == 7'
    module.conditional = [m_condition]
    aix_network = AIXNetwork(module)
    interfaces = dict(v4={'gateway': '192.168.100.1', 'interface': 'en0'}, v6={'gateway': '::', 'interface': 'en0'})
    assert aix_network.get_default_interfaces() == interfaces

    facts_dict = dict(default_interfaces=dict())
    module = FakeModule(facts_dict, dict())
    m_condition = 'ansible_net_version_major == 6'
    module.conditional = [m_condition]
    aix_network

# Generated at 2022-06-11 03:09:20.461359
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import FakeModule
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    assert isinstance(AIXNetworkCollector(FakeModule()), AIXNetworkCollector)


# Also test the get_interfaces_info function

# Generated at 2022-06-11 03:09:25.950383
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # let's prepare module_utils.facts.network.generic_bsd.GenericBsdIfconfigNetwork
    # to be inherited by class AIXNetwork
    module_utils_facts_network_base = NetworkCollector(None, None)
    module_utils_facts_network_generic_bsd = GenericBsdIfconfigNetwork(None, None)
    for name, method in module_utils_facts_network_generic_bsd.__dict__.items():
        if name in ['get_default_interfaces', 'get_interfaces_info']:
            continue
        setattr(module_utils_facts_network_base, name, method)
    for name, method in module_utils_facts_network_base.__dict__.items():
        setattr(module_utils_facts_network_generic_bsd, name, method)
    #

# Generated at 2022-06-11 03:10:59.593008
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import io
    from ansible.module_utils.facts.network.aix import AIXNetwork


# Generated at 2022-06-11 03:11:06.965807
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    result = AIXNetwork.get_default_interfaces(None, './')
    interface_v4 = result[0]
    interface_v6 = result[1]
    assert 'gateway' in interface_v4 and interface_v4['gateway'] == '192.168.56.1'
    assert 'interface' in interface_v4 and interface_v4['interface'] == 'p6p1'
    assert 'gateway' in interface_v6 and interface_v6['gateway'] == 'fe80::5054:ff:fe71:4539%p6p1'
    assert 'interface' in interface_v6 and interface_v6['interface'] == 'p6p1'


# Generated at 2022-06-11 03:11:16.479343
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # fixture
    class AIXNetwork_test_fixture:
        def __init__(self):
            self.test = AIXNetwork()
            self.test.module = dict()  # mimic AnsibleModule() object
            self.test.run_command = self.test_run_command
            self.test.get_bin_path = self.test_get_bin_path
            self.test.run_command_environ_update = self.test_run_command_environ_update
            self.test._check_for_no_call = False
            self.test._check_for_no_call_args = None

# Generated at 2022-06-11 03:11:18.773002
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector.platform == 'AIX'
    assert net_collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:11:28.033205
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    test for method get_default_interfaces
    '''

    m_module = type('', (object,), {})()
    m_module.run_command = type('', (object,), {})()
    m_module.run_command.side_effect = [
        (0, 'default 192.168.1.1 UG 1 0 en0', ''),
        (0, 'default fe80::%utun0 UG 13 0 utun0', ''),
        (0, 'default ::1 UG 2 0 lo0\n', ''),
    ]

    network_collector = AIXNetworkCollector()
    network_collector.module = m_module

    interface_v4, interface_v6 = network_collector.get_default_interfaces('route')


# Generated at 2022-06-11 03:11:34.828365
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fake_module = FakeModule()
    fake_module.params = dict(
        gather_subset=[],
        gather_network_resources=[],
    )

    # Example of ifconfig output

# Generated at 2022-06-11 03:11:36.471312
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-11 03:11:38.224475
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network = AIXNetwork()
    network_collector = AIXNetworkCollector(network)
    assert network_collector.platform == 'AIX'

# Generated at 2022-06-11 03:11:42.489603
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Verify constructor of AIXNetworkCollector is working properly"""

    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._option_map == {
        'command': 'command',
        'use_ipv6': 'use_ipv6'
    }

# Generated at 2022-06-11 03:11:46.514235
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    net_aix = AIXNetwork(module)
    assert net_aix.get_default_interfaces('/usr/bin/netstat') == ({}, {})
