

# Generated at 2022-06-11 03:04:31.357212
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:04:37.515954
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class FakeModule(object):
        def __init__(self, result=None, bin_path=None):
            self.run_command = result
            self.get_bin_path = bin_path

    result = (0, '', '')
    module = FakeModule(result)
    x = AIXNetwork(module)
    x.get_interfaces_info('ifconfig')
    assert 1 == 2

# Generated at 2022-06-11 03:04:46.430241
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:04:57.135312
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os
    import copy

    test_file = os.path.join(os.path.dirname(__file__), '../../fixtures/get_interfaces_info_aix.txt')
    f = open(test_file, 'r')
    test_out = f.read()

    class TestModule(object):
        def run_command(self, args, check_rc=True):
            return (0, test_out, '')

        def get_bin_path(self, arg):
            return 'ifconfig'

    test_module = TestModule()

    test_AIX_ifconfig_path = 'ifconfig'
    test_AIX_ifconfig_options = '-a'
    test_AIX_ifconfig_

# Generated at 2022-06-11 03:05:02.362111
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = NetworkCollector()
    aix = m._collector_classes['AIX']['network'](m)

    assert aix.get_default_interfaces('/etc/route') == {'gateway': '10.10.10.1', 'interface': 'lan0'}, "check that get_default_interfaces returns the correct IPv4 default route"

# Generated at 2022-06-11 03:05:04.537329
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix = AIXNetworkCollector()
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-11 03:05:07.505430
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert issubclass(AIXNetworkCollector._fact_class, AIXNetwork)
    assert issubclass(AIXNetworkCollector._fact_class, NetworkCollector)


# Generated at 2022-06-11 03:05:10.527059
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX', "AIXNetworkCollector._platform should be AIX"
    assert AIXNetworkCollector._fact_class == AIXNetwork, "AI-XNetworkCollector._fact_class should be AIXNetwork"

# Generated at 2022-06-11 03:05:13.436820
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector()._platform == 'AIX'
    assert AIXNetworkCollector()._fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:21.003078
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test for AIX - ifconfig -a
    test_module = AnsibleModule(argument_spec={})
    test_obj = AIXNetwork(module=test_module)
    test_str = test_obj.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

# Generated at 2022-06-11 03:05:44.059314
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        )
    )

    interfaces, ips = AIXNetwork().get_interfaces_info(module.get_bin_path('ifconfig'))
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses'][0]['interface']
    assert 'lo0' in ips['all_ipv6_addresses'][0]['interface']
    assert 'en0' in interfaces
    assert 'en0' in ips['all_ipv4_addresses'][1]['interface']

# Generated at 2022-06-11 03:05:52.337488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test with data for AIX 7.2
    # 1. Create an AIXNetwork object
    test_object = AIXNetwork()
    # 2. Create a dictionary containing the output of ifconfig -a with the following
    # interfaces: en0, en1, fcs0, vl0, g2

# Generated at 2022-06-11 03:06:03.089135
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    network = AIXNetwork()
    ifconfig_path = network.module.get_bin_path('ifconfig')


# Generated at 2022-06-11 03:06:08.292346
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_fact_class = AIXNetworkCollector().get_network_gather_subclass()
    assert net_fact_class == AIXNetwork, \
        'AIXNetworkCollector.get_network_gather_subclass != AIXNetwork'
    assert net_fact_class.platform == 'AIX', \
        'net_fact_class.platform != AIX'

# Generated at 2022-06-11 03:06:10.272302
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = None
    nc = AIXNetworkCollector(module)
    assert nc.platform == 'AIX'

# Generated at 2022-06-11 03:06:17.317460
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    fact_class = AIXNetwork(module)

    # interface, ipv4 and ipv6 configuration test on AIX

# Generated at 2022-06-11 03:06:19.238355
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector.fact_class == AIXNetwork

# Generated at 2022-06-11 03:06:30.546724
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json
    import logging
    import os
    import shlex
    import subprocess
    import sys
    import tempfile
    import unittest

    import ansible.module_utils.basic

    from ansible.module_utils.facts.network.generic_bsd import TESTDATA_DIR as OBSDATA_DIR

    class AnsibleFailJson(object):
        def __init__(self, kwargs):
            pass

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('ANSIBLE_MODULE_EXIT')


# Generated at 2022-06-11 03:06:33.525778
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector(dict(), dict())._fact_class == AIXNetwork
    assert AIXNetworkCollector(dict(), dict())._platform == 'AIX'


# Generated at 2022-06-11 03:06:35.499925
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-11 03:07:04.621397
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    p = AIXNetwork()
    print('#' * 80)
    print('# Unit test: AIXNetwork.get_interfaces_info()')
    print('#' * 80)
    print(p.get_interfaces_info())


if __name__ == '__main__':
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:07:14.031754
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net = AIXNetwork()

    net.module = FakeModule('/usr/sbin/ifconfig')


# Generated at 2022-06-11 03:07:14.827412
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    conf = AIXNetworkCollector()

    assert conf.platform == 'AIX'


# Generated at 2022-06-11 03:07:24.181873
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule:
        def __init__(self):
            self.params = dict()
            self.run_command_args = None
            self.run_command_rc = 0

        def get_bin_path(self, arg):
            if arg == 'uname':
                return '/bin/uname'
            elif arg == 'entstat':
                return '/usr/sbin/entstat'
            elif arg == 'lsattr':
                return '/usr/sbin/lsattr'
            elif arg == 'ifconfig':
                return '/usr/sbin/ifconfig'
            else:
                return None

        def run_command(self, args):
            self.run_command_args = args
            return self.run_command_rc, '', ''

    # define cases

# Generated at 2022-06-11 03:07:28.344048
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == "AIXNetworkCollector"
    assert AIXNetworkCollector._platform == "AIX"
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:07:31.392188
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for AIXNetworkCollector.
    """
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-11 03:07:34.392786
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    an = AIXNetwork()
    an.get_default_interfaces(route_path=None)

# Generated at 2022-06-11 03:07:37.701285
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    'Test the method get_default_interfaces of class AIXNetwork'
    net_obj = AIXNetwork()
    assert net_obj.get_default_interfaces('test') == ('test', 'test')



# Generated at 2022-06-11 03:07:47.641517
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.params = {}

    if_aix = AIXNetwork(mock_module)
    ifconfig_path = mock_module.get_bin_path('ifconfig')
    (interfaces, ips) = if_aix.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['flags'] == ['UP', 'BROADCAST', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['lo0']['type'] == 'Loopback'
    assert interfaces['lo0']['ipv4'] == []
   

# Generated at 2022-06-11 03:07:57.990819
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fake_module = type('', (), {'run_command': lambda *args, **kwargs: (0, 'ifconfig output', '')})()
    fake_ifconfig = AIXNetwork(fake_module)


# Generated at 2022-06-11 03:08:53.949805
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import Interface

    test_obj = AIXNetwork()
    test_obj.module = FakeAnsibleModule()

    test_interface = Interface(device='en0', mtu='1500', type='ether', macaddress='00:1f:12:b7:d6:be', flags=['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'])
    test_interfaces = {'en0': test_interface}

    test_obj.interfaces = test_interfaces

    assert test_obj.get_default_interfaces('route') is (None, None)
    test_obj.module.run_command = mock_run_command

# Generated at 2022-06-11 03:08:55.628321
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector is not None

# Generated at 2022-06-11 03:08:58.049570
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    assert AIXNetworkCollector.platform == 'AIX'
    assert isinstance(AIXNetworkCollector(module)._fact_class(module), AIXNetwork)

# Generated at 2022-06-11 03:09:06.132631
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetworkClass = AIXNetwork(None)
    AIXNetworkClass.module.run_command = lambda args: (0, '', '')
    AIXNetworkClass.module.get_bin_path = lambda args: '/bin/netstat'
    route_path = None
    result = AIXNetworkClass.get_default_interfaces(route_path)
    v4result = result[0]
    assert 'gateway' in v4result
    assert v4result['gateway'] == '192.168.1.1'
    assert 'interface' in v4result
    assert v4result['interface'] == 'en0'
    v6result = result[1]
    assert 'gateway' in v6result
    assert v6result['gateway'] == 'fe80::1'
    assert 'interface' in v6result

# Generated at 2022-06-11 03:09:14.380103
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (object,), {})
    net = AIXNetwork(module)

    class MockBytes(bytes):
        def decode(self, *args):
            return self

    class MockString(str):
        def encode(self, *args):
            return self

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)

# Generated at 2022-06-11 03:09:19.107769
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """This is to test defined class - AnsibleModuleUtilsNetworkAIX"""
    obj = AIXNetworkCollector()

    # test for class attribute _fact_class
    assert hasattr(obj, '_fact_class')
    assert obj._fact_class == AIXNetwork

    # test for class attribute _platform
    assert hasattr(obj, '_platform')
    assert obj._platform == 'AIX'

# Generated at 2022-06-11 03:09:23.610022
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector, '_platform')
    assert AIXNetworkCollector._platform == 'AIX'
    assert hasattr(AIXNetworkCollector, '_fact_class')
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert hasattr(AIXNetworkCollector, 'platform')
    assert AIXNetworkCollector.platform == 'AIX'
    assert hasattr(AIXNetworkCollector, 'fact_class')
    assert AIXNetworkCollector.fact_class == AIXNetwork

# Generated at 2022-06-11 03:09:33.672612
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Get ansible param
    params = dict(
        ansible_command_timeout=10,
        ansible_facts={},
        ansible_module_name='test_AIXNetwork_get_interfaces_info',
        ansible_version={
            'string': '2.9.6',
            'full': '2.9.6',
            'major': 2,
            'minor': 9,
            'revision': 6,
            'build': 0,
        },
        ansible_version_date='2020-06-01',
    )

    # Get test platform (AIX)
    test_platform = AIXNetworkCollector(params=params, module=FakeAnsibleModule(params=params))

    # Get interface info
    (interfaces, ips) = test_platform.get_interfaces_info

# Generated at 2022-06-11 03:09:42.439132
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    module = None
    route_path = 'route_path'

    aixNetwork = AIXNetwork(module, route_path)

    interface = {}

    rc, out, err = aixNetwork.module.run_command(['netstat', '-nr'])

    for line in out.splitlines():
        words = line.split()
        if len(words) > 1 and words[0] == 'default':
            if '.' in words[1]:
                interface['v4'] = {'gateway': words[1], 'interface': words[5]}
            elif ':' in words[1]:
                interface['v6'] = {'gateway': words[1], 'interface': words[5]}

    # Test get_default_interfaces()

# Generated at 2022-06-11 03:09:47.107826
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for AIXNetworkCollector
    """
    # test for default value of argument platform
    assert AIXNetworkCollector._platform == 'AIX'

    # test for default value of argument fact_class
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'



# Generated at 2022-06-11 03:11:29.082149
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec=dict())
    test_AIXNetwork = AIXNetwork(test_module)

    def run_command(self, args, check_rc=True):
        class Results():
            def __init__(self, out, err, rc):
                self.stdout = out
                self.stderr = err
                self.rc = rc


# Generated at 2022-06-11 03:11:31.381956
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_class = AIXNetworkCollector()
    assert fact_class._fact_class == AIXNetwork
    assert fact_class._platform == 'AIX'


# Generated at 2022-06-11 03:11:34.736685
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test AIXNetworkCollector class.
    """
    try:
        from ansible.module_utils.facts.network.aix.collector import AIXNetworkCollector
        c = AIXNetworkCollector()
        assert c is not None
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-11 03:11:42.525590
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Mock class module
    class ModuleMock(object):
        def __init__(self):
            self.run_command_result = (0, TEST_AIX_IFCONFIG_OUT, '')
            self.run_command_result_entstat = (0, TEST_AIX_ENTSTAT_OUT, '')

        def get_bin_path(self, name, opt_dirs=[]):
            return {
                'ifconfig': '/usr/sbin/ifconfig',
                'netstat': '/usr/bin/netstat',
                'uname': '/usr/bin/uname',
                'lsattr': '/usr/sbin/lsattr',
                'entstat': '/usr/sbin/entstat',
                'dbx': '/usr/bin/dbx'
            }.get(name, None)

# Generated at 2022-06-11 03:11:48.797160
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class AIXNetwork
    '''

    # Load the test sample data
    test_data = load_fixture('interfaces_aix')

    # The test object
    aix_network = AIXNetwork(None)

    # The test method
    result = aix_network.get_interfaces_info('/usr/sbin/ifconfig', '-a')

    # Assert the result
    assert result == test_data

# Generated at 2022-06-11 03:11:53.072569
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None, None, None).collect()
    assert facts['default_ipv4']['interface'] == 'en0'
    assert facts['default_ipv4']['gateway'] == '192.168.1.1'

# Generated at 2022-06-11 03:11:55.537205
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector

    # check if AIXNetwork is the correct fact class
    assert collector._fact_class == AIXNetwork
    # check if _platform is correct
    assert collector._platform == 'AIX'

# Generated at 2022-06-11 03:12:04.672556
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    ifconfig_path = network.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)

    facts = {
        'all_ipv4_addresses': ips['all_ipv4_addresses'],
        'all_ipv6_addresses': ips['all_ipv6_addresses'],
        'interfaces': interfaces,
    }

    # For debug
    # print(json.dumps(facts))

    assert 'lo0' in facts['interfaces']
    assert 'en0' in facts['interfaces']

# Generated at 2022-06-11 03:12:06.674216
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:12:09.647199
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Unit tests for constructor of class AIXNetwork