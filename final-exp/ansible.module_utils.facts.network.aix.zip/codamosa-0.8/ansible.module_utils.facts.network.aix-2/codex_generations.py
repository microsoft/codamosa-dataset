

# Generated at 2022-06-11 03:04:24.180730
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc.get_facts() is not None
    assert nc.get_network_facts() is not None

# Generated at 2022-06-11 03:04:27.804843
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for class AIXNetworkCollector
    """
    module = DummyAnsibleModule()
    _ = AIXNetworkCollector(module)

    # test if the resulting object class is AIXNetwork
    assert isinstance(_._fact_class(module), AIXNetwork)



# Generated at 2022-06-11 03:04:39.026801
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = "/usr/sbin/ifconfig"
    ifconfig_options = "-a"
    aixnetwork = AIXNetwork(ifconfig_path, ifconfig_options)

    # Example ifconfig output on AIX:
    #     en0: flags=1e084863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
    #         inet 10.10.10.39 netmask 0xffffff00 broadcast 10.10.10.255
    #         inet6 fe80::2c0:4aff:fe01:1%en0 prefixlen 64 scopeid 0x1
    #         ether 2c:0:4a:01:01:01


# Generated at 2022-06-11 03:04:43.431823
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    ansible_facts = {}
    ansible_facts['ansible_network_resources'] = {}
    ansible_facts['ansible_devices'] = {}
    ansible_facts['ansible_mounts'] = []

    # Test collector
    assert isinstance(AIXNetworkCollector(module).get_facts(), dict)

# Generated at 2022-06-11 03:04:49.029855
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # get instance of AIXNetworkCollector
    aix_network_collector = AIXNetworkCollector()
    # get instance of AIXNetwork
    aix_network = aix_network_collector.get_network_collector()

    # assert _fact_class
    assert aix_network_collector._fact_class == AIXNetwork
    # assert _platform
    assert aix_network_collector._platform == 'AIX'
    # assert instance of AIXNetwork
    assert isinstance(aix_network, AIXNetwork)
    # assert platform
    assert aix_network.platform == 'AIX'



# Generated at 2022-06-11 03:04:59.646968
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # create mock fact module, otherwise module_utils.facts.network.generic_bsd.GenericBsdIfconfigNetwork.os is False
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    class MockGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        _platform = 'AIX'
        os = 'AIX'
    GenericBsdIfconfigNetwork = MockGenericBsdIfconfigNetwork


# Generated at 2022-06-11 03:05:09.763598
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import re
    import subprocess
    import tempfile

    def run(module_args):
        module_path = '%s/../../library/network/aix.py' % os.path.dirname(__file__)
        module = AnsibleModule(argument_spec=dict())
        module.params = module_args
        sys.path.insert(0, module_path)
        exec(open(module_path).read())
        aixnetwork = AIXNetwork(module)
        interfaces, ips = aixnetwork.get_interfaces_info('/usr/sbin/ifconfig')
        if interfaces:
            return interfaces
        else:
            return None, None

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

# Generated at 2022-06-11 03:05:11.856615
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
# TODO: write unit tests for AIXNetworkCollector
    assert AIXNetworkCollector is not None

# Generated at 2022-06-11 03:05:14.031360
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)

# Generated at 2022-06-11 03:05:18.121312
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = dict(all_ipv4_addresses=[],
                  all_ipv6_addresses=[],
                  default_ipv4=dict(gateway=None,
                                    interface=None),
                  default_ipv6=dict(gateway=None,
                                    interface=None),
                  interfaces={})

    assert AIXNetworkCollector().collect() == result

# Generated at 2022-06-11 03:05:37.150703
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """AIXNetwork get_default_interfaces() test stub"""

    network = AIXNetwork()
    network.module = NetworkCollector
    network.module.run_command = run_command_test_stub

    ifconfig_path = network.module.get_bin_path('ifconfig')
    route_path = network.module.get_bin_path('route')

    default_interfaces = network.get_default_interfaces(route_path)
    assert default_interfaces['gateway'] == '192.168.0.1'
    assert default_interfaces['interface'] == 'en0'



# Generated at 2022-06-11 03:05:44.921409
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test = AIXNetwork()
    test.module = AnsibleModule(argument_spec={'route_path': {'type': 'str', 'required': True}})
    test.module.params.update({'route_path': '/bin/netstat'})
    result = test.get_default_interfaces(test.module.params['route_path'])
    assert result == ({'gateway': '10.100.100.1', 'interface': 'en0'}, {'gateway': 'fe80::8', 'interface': 'en0'})



# Generated at 2022-06-11 03:05:47.904135
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.fail_json = lambda x: x
    n = AIXNetwork(module)
    n.get_default_interfaces('/sbin/route')

# Generated at 2022-06-11 03:05:57.817598
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # aix_network_module_output_opt_a.txt is a copy of the lines of the output of the command:
    # ansible hpux -m setup -a 'filter=ansible_eth*' > aix_network_module_output_opt_a.txt
    # with removed ethernet devices en0 and en1.
    #
    # The goal of this unit test is to test every line of aix_network_module_output_opt_a.txt
    # to check it is processed by AIXNetwork.get_interfaces_info as expected.

    network = AIXNetwork(dict())
    path_to_test_file = os.path.join(os.path.dirname(__file__), 'aix_network_module_output_opt_a.txt')

# Generated at 2022-06-11 03:06:05.530665
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = ''
    route_path = '/usr/sbin/routeadm'
    config = AIXNetworkCollector(module=None, ifconfig_path=ifconfig_path, ifconfig_options=ifconfig_options, route_path=route_path)

    assert config.platform == 'AIX'
    assert config.ifconfig_path == ifconfig_path
    assert config.route_path == '/usr/sbin/routeadm'



# Generated at 2022-06-11 03:06:14.661560
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    net_collector = AIXNetwork(module)
    v4, v6 = net_collector.get_default_interfaces('/sbin/route')

    assert v4 == {'interface': 'en5', 'gateway': '192.168.4.1'}
    assert v6 == {'interface': 'en5', 'gateway': 'dead:beef::1'}

# from ansible.module_utils.facts import ansible_collections.community.general.plugins.module_utils.network.aix.aix
#from ansible_collections.community.general.plugins.module_utils.network.aix.aix import AIXNetwork
#from ansible_collections.community.general.plugins.module_utils.network.aix.aix

# Generated at 2022-06-11 03:06:26.810167
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    argument_spec = dict(
        gather_subset=dict(default=['!all', '!min'], type='list')
    )
    module = NetworkCollector(argument_spec=argument_spec)
    aix_network = AIXNetwork(module)

    # test case 1
    aix_network.get_default_interfaces('/usr/bin/netstat')
    assert '192.168.0.1' == aix_network.default_gateway
    assert 'en0' == aix_network.default_interface

    # test case 2
    aix_network.get_default_interfaces('not_exist_path')
    assert '192.168.0.1' == aix_network.default_gateway
    assert 'en0' == aix_network.default_interface


# Generated at 2022-06-11 03:06:27.750583
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.get_default_interfaces('/route')

# Generated at 2022-06-11 03:06:38.906178
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_result = []
            self.run_command_result.append(0)
            self.run_command_result.append('      default         192.168.10.1     UG        0        0        ens33')
            self.get_bin_path_result = '/usr/bin/netstat'

        def get_bin_path(self, arg):
            return self.get_bin_path_result

        def run_command(self, arg):
            return self.run_command_result

    def_v4 = dict(gateway='192.168.10.1', interface='ens33')
    def_v6 = dict()

    test_module = TestModule()

# Generated at 2022-06-11 03:06:48.374168
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # input data
    hostname_path = '/bin/hostname'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:07:16.332507
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True,
    )
    # This is necessary for the decorators to work
    module.params['gather_subset'] = ['!all']
    module.exit_json(ansible_facts=dict(ansible_net_interfaces=NetworkCollector._get_interfaces(module)))



# Generated at 2022-06-11 03:07:25.551025
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/sbin/ifconfig'
    route_path = '/usr/sbin/route'
    interfaces = dict(v4={}, v6={})

    netstat_path = '/usr/sbin/netstat'
    rc, out, err = 0, '', ''
    rc, out, err = dict(stdout='', stderr=''), '', ''
    real_rc = 0

    class Module(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args):
            return self.rc, self.out, self.err

        def get_bin_path(self, name, required=False):
            return netstat_path


# Generated at 2022-06-11 03:07:33.924497
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:44.295539
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    import tempfile
    import shutil

    # create a temp directory
    tmpdir = tempfile.mkdtemp()
    module = 'ansible/module_utils/facts/network/aix.py'
    tmpname = tmpdir + '/' + os.path.basename(module)
    shutil.copy(module, tmpname)

    aix = AIXNetworkCollector.load_module(tmpname)
    network = aix.get_network_facts()



# Generated at 2022-06-11 03:07:50.942629
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:07:53.674771
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class.platform == 'AIX'


# Generated at 2022-06-11 03:08:01.678074
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test get_interfaces_info method of class AIXNetwork
    """
    test_AIXNetwork = AIXNetwork()
    test_ifconfig_path = '/usr/bin/ifconfig'
    test_ifconfig_options = '-a'
    """
    Test result with input shown on file 'test_output_AIX_ifconfig_a'.
    For this test it is necessary to create the file 'test_output_AIX_ifconfig_a',
    copy the lsattr output (ifconfig -a) on this file,
    run the script from the folder where this file was copied,
    and check the result.
    """
    with open('test_output_AIX_ifconfig_a', 'r') as file:
        test_output = file.read()
        test_rc = 0

# Generated at 2022-06-11 03:08:04.114823
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc._fact_class == AIXNetwork
    assert nc._platform == 'AIX'

# Generated at 2022-06-11 03:08:11.299218
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec={})
    interface = net.get_default_interfaces('route')
    assert interface[0]['gateway'] == '172.16.0.1'
    assert interface[0]['interface'] == 'en0'
    assert interface[1]['gateway'] == 'fe80::2c0:cfff:fe29:f671'
    assert interface[1]['interface'] == 'en0'


# Generated at 2022-06-11 03:08:15.716649
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    aix = AIXNetworkCollector()
    assert aix.get_default_interfaces('/sbin/route') is not None
    assert aix.get_interfaces_info('/sbin/ifconfig', ifconfig_options='-a') is not None

# Generated at 2022-06-11 03:09:05.258187
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    net = AIXNetwork(module=module)
    default_interface = net.get_default_interfaces('/bin/netstat')
    assert default_interface[0]['gateway'] == '192.168.56.1'
    assert default_interface[0]['interface'] == 'en0'
    assert default_interface[1]['gateway'] == 'fe80::a00:27ff:fec9:1c3f'
    assert default_interface[1]['interface'] == 'en0'



# Generated at 2022-06-11 03:09:13.447258
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class MockAIXNetwork(object):
        def __init__(self, module, platform):
            self.module = module


# Generated at 2022-06-11 03:09:15.997116
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    nc = AIXNetworkCollector(dict(module=None), '')
    assert nc._platform == 'AIX'

# Generated at 2022-06-11 03:09:23.369539
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class DummyModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/netstat'

        def run_command(self, command):
            rc = 0

# Generated at 2022-06-11 03:09:33.478364
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # aix_network is a new AIXNetwork object.
    aix_network = AIXNetwork()

    # ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_path = '/usr/sbin/ifconfig'

    # call_rc is a integer. This is the return code of Run_command function.
    # call_out is a string. This is the output of Run_command function.
    # call_err is a string. This is the error of Run_command function.
    # call_rc, call_out, call_err = aix_network.module.run_command([ifconfig_path])
    call_rc, call_out, call_err = aix_network.module.run_command([ifconfig_path, '-a'])

    # interfaces is a dictionary.
    # This dictionary stores the

# Generated at 2022-06-11 03:09:37.159720
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # create object AIXNetworkCollector
    my_obj = AIXNetworkCollector()

    # check if _fact_class is 'AIXNetwork'
    assert my_obj._fact_class == 'AIXNetwork'

    # check if _platform is 'AIX'
    assert my_obj._platform == 'AIX'

# Generated at 2022-06-11 03:09:45.932508
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test get_interfaces_info of AIXNetwork"""

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'


# Generated at 2022-06-11 03:09:54.298351
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = NetworkModule()
    fact_class = AIXNetwork(module)

    import StringIO
    my_string = StringIO.StringIO()
    my_string.write("Name:lo0\n")
    my_string.write("Type:IP\n")
    my_string.write("State:unknown\n")
    my_string.write("Media:Software Loopback\n")
    my_string.write("Frame Type:Ethernet II\n")
    my_string.write("Address:00:00:00:00:00:00\n")
    my_string.write("inet 127.0.0.1 netmask 0xffffff00 broadcast 127.255.255.255\n")
    my_string.write("inet6 ::1/0\n")

# Generated at 2022-06-11 03:10:03.164354
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class FakeModule(object):
        def __init__(self):
            self._ansible_tmpdir = 'tmpdir'

        def get_bin_path(self, name, optional=False):
            if name == 'netstat':
                return 'netstat'


# Generated at 2022-06-11 03:10:13.035498
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork_obj = AIXNetwork({}, [])

    # Create a list with lines of netstat -nr command output
    netstat_lines = []
    netstat_lines.append("Routing tables")
    netstat_lines.append("Internet:")
    netstat_lines.append("Destination        Gateway            Flags  Refs   Use   Mtu   Interface")
    netstat_lines.append("default            172.30.0.1          UG        0    590 192608 en0")
    netstat_lines.append("default            192.168.0.1        UG        1   1015   1500  lo0")
    netstat_lines.append("default            192.168.54.1       UG        0    590    -    en1")

# Generated at 2022-06-11 03:11:42.453739
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:11:53.115672
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # prepare
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_collector = AIXNetworkCollector(module=module)
    network_facts = network_collector.collect()
    network_getter = network_collector.get_network_gather_subset(all_subsets=network_facts.gather_subset)
    network = network_getter.get_network_facts(network_facts)

    # test if there is only one gateway
    if len(network['default_ipv4']['gateway'].split()) > 1:
        module.fail_json(msg="Error: There is more than one IPv4 gateway.")
    if len(network['default_ipv6']['gateway'].split()) > 1:
        module

# Generated at 2022-06-11 03:11:59.492135
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        add_file_common_args=True,
    )

    # Change to test directory
    import os
    test_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(test_dir)

    n_collector = AIXNetworkCollector(module=module)
    n_collector.get_default_interfaces(route_path='/test/netstat.txt')
    assert n_collector.interfaces['v4']['gateway'] == '10.1.1.1'
    assert n_collector.interfaces['v4']['interface'] == 'en1'

# Generated at 2022-06-11 03:12:01.549645
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:12:11.040656
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:19.116341
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.community.plugins.modules import network_facts
    import sys

    module = network_facts.Network(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if module._name == 'network_facts':
        module.deprecate("The 'network_facts' module has been renamed to 'net_facts'", version="2.13")

    if not sys.executable.endswith('python'):
        iface = 'toto0:'
    else:
        iface = 'lo0:'

    ifconfig_path = module.get_bin_path('ifconfig')

# Generated at 2022-06-11 03:12:28.743550
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Arguments(object):
        pass

    class Module(object):
        def __init__(self):
            self.argument_spec = {}
            self.params = {}

        def get_bin_path(self, name, required=False):
            if name == 'ifconfig':
                ifconfig_path = "/usr/sbin/ifconfig"
            if name == 'netstat':
                netstat_path = "/usr/bin/netstat"
            if name == 'uname':
                uname_path = "/usr/bin/uname"
            if name == 'entstat':
                entstat_path = "/usr/bin/entstat"
            if name == 'lsattr':
                lsattr_path = "/usr/sbin/lsattr"

            return locals()[name+"_path"]


# Generated at 2022-06-11 03:12:35.547661
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # test input data
    ifconfig_path = './TEST_AIX_ifconfig'
    ifconfig_options = '-a'

    # expected output data

# Generated at 2022-06-11 03:12:40.731738
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils._text import to_bytes

    # Example data as provided by ifconfig -a on AIX

# Generated at 2022-06-11 03:12:43.110958
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    obj = AIXNetwork()
    interfaces, ips = obj.get_interfaces_info(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )
    print(interfaces)
    print(ips)

if __name__ == '__main__':
    test_AIXNetwork_get_interfaces_info()