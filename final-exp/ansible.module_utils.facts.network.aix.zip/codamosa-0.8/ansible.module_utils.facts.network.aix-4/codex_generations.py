

# Generated at 2022-06-11 03:04:30.840283
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ipv4_gateway = '10.0.0.1'
    ipv4_interface = 'lo0'
    ipv6_gateway = 'fe80::d6e1:27ff:fea5:7b28'
    ipv6_interface = 'lo0'
    out = []
    out.append('Internet6:')
    out.append('Destination        Gateway            Flags   Refs     Use  Netif Expire')
    out.append('::1                ::1                UHl        0       0   lo0')
    out.append('10.0.0.0           10.0.0.1           UGS        0 11495989 lo0')
    out.append('10.0.0.0           10.0.0.1           UGS        0 11495989 en0')
   

# Generated at 2022-06-11 03:04:37.870294
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork({})

    assert net.get_default_interfaces('/bin/netstat') == ({'gateway': '10.0.2.2', 'interface': 'ens160'},
                                                          {'gateway': 'fe80::f816:3eff:fe09:8d9f', 'interface': 'ens160'})
    assert net.get_default_interfaces('/bin/netstat_dummy') == ({}, {})


# Generated at 2022-06-11 03:04:39.317393
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork(None).get_default_interfaces(None)

# Generated at 2022-06-11 03:04:47.236138
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:04:56.787949
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'foo', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector._validate_platform = MagicMock()
    default_interfaces = network_collector.get_default_interfaces('/etc/defaultrouter')
    assert default_interfaces == ({'gateway': '10.0.0.1', 'interface': 'en0'},
                                  {'gateway': 'fe80::1', 'interface': 'en0'})
    module.run_command.assert_called_with(["netstat", "-nr"])


# Generated at 2022-06-11 03:05:00.803429
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function returns an AIXNetworkCollector object for testing purpose.

    :return: AIXNetworkCollector object
    :rtype: AIXNetworkCollector
    """

    from ansible.module_utils.facts.network.aix.aix import AIXNetworkCollector

    return AIXNetworkCollector

# Generated at 2022-06-11 03:05:10.478505
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test of method get_interfaces_info of class AIXNetwork.
    """

    class ModuleTest(object):
        """
        Class for replace the module in method get_interfaces_info.
        """
        def __init__(self):
            """
            Constructor
            """
            self.params = {}
            self.exit_json = {'ansible_facts': {}}
            self.exit_json['ansible_facts']['ansible_eth0'] = {}

        def run_command(self, args):
            """
            Method for replace the module.run_command in method get_interfaces_info.
            """
            # recreate sample output for aix network

# Generated at 2022-06-11 03:05:19.796342
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    print('Testing AIXNetwork_get_default_interfaces')

    class MockModule(object):
        def __init__(self, out, err, rc):
            self.out = out
            self.err = err
            self.rc = rc

        def run_command(self, command):
            return self.rc, self.out, self.err

        def get_bin_path(self, name):
            # return the path - it does not matter what it is for our tests
            return name

    netdev = AIXNetwork()

    # return from netstat -nr

# Generated at 2022-06-11 03:05:27.217827
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test the AIX Network Collector"""

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # test to see if it is an instance of the right class
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)
    # test to see if it creates the right class
    assert isinstance(AIXNetworkCollector().get_all_network_interfaces(), GenericBsdIfconfigNetwork)

# Generated at 2022-06-11 03:05:33.961676
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class TestModule:
        """Stub class for AnsibleModule"""
        def __init__(self):
            self.params = {}
            self.exit_json = None

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, check_rc=True):
            test_data = open('test_data/AIX_ifconfig_en0_1').read()
            return 0, test_data, ''

    test_module = TestModule()

    # Test with default parameters
    aix_network_collector = AIXNetwork(test_module)
    interfaces = dict(en0=dict())
    ips = dict()
    aix_network_collector.get_interfaces_info('ifconfig', interfaces, ips)

# Generated at 2022-06-11 03:05:55.025660
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    obj = AIXNetwork(module)
    netstat_path = module.get_bin_path('netstat')
    if not netstat_path:
        return_msg = "Cannot find netstat binary.\n"
        module.fail_json(msg=return_msg)
    route_path = module.get_bin_path('route')
    if not route_path:
        return_msg = "Cannot find route binary.\n"
        module.fail_json(msg=return_msg)
    v4, v6 = obj.get_default_interfaces(route_path)
    return v4


# Generated at 2022-06-11 03:06:06.105056
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:07.068186
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector

# Generated at 2022-06-11 03:06:14.651401
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class _module_mock:
        class run_command_mock:
            class communicate_mock:
                def communicate(self):
                    return None, '2.3', None

        def run_command(self, command_parts, check_rc=True, close_fds=True):
            return self.run_command_mock(), 'out', 'err'

    class _AIXNetwork:

        def __init__(self, module):
            self.module = module

    test_network = _AIXNetwork(_module_mock())
    test_interfaces, test_ips = test_network.get_interfaces_info('')



# Generated at 2022-06-11 03:06:26.809803
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test if get_interfaces_info of class AIXNetwork works as expected.
    """

    # test AIX ifconfig -a output with only one interface
    ifconfig_output = """
en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
        inet 10.0.2.16 netmask 0xffff0000 broadcast 10.0.255.255
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
        media: Ethernet autoselect (1000baseT <full-duplex>)
        status: active
"""

# Generated at 2022-06-11 03:06:33.914797
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # input data for test
    ifconfig_path = "ifconfig"

# Generated at 2022-06-11 03:06:44.797537
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:53.800726
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test the method get_interfaces_info of class AIXNetwork"""


# Generated at 2022-06-11 03:07:03.957145
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import sys
    sys.path.append('/tmp/pycharm_project_123/ansible_collections/ansible/community/plugins/module_utils/network/common/')
    sys.path.append('/tmp/pycharm_project_123/ansible_collections/ansible/community/plugins/module_utils/network/aix/')

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    device1 = 'fcs0'
    device2 = 'ent0'
    device3 = 'ent9'
    device4 = 'ent10'

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    test_network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:07:13.378169
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork

# Generated at 2022-06-11 03:07:34.350491
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Create the module object
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()

    # Create the object to be tested
    aixnetwork = AIXNetwork(module)

    # Get the paths of the commands used to gather network facts
    route_path = aixnetwork.module.get_bin_path('route', True)

    # Set the command output of netstat -nr
    netstat_interface = 'ent0'
    netstat_inet_ip = '10.17.104.1'
    netstat_inet6_ip = 'fe80::4c4b:84ff:fe00:0'

# Generated at 2022-06-11 03:07:37.626633
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector"""

    network_AIX=AIXNetworkCollector()
    assert isinstance(network_AIX._fact_class, AIXNetwork)
    assert network_AIX._platform == 'AIX'



# Generated at 2022-06-11 03:07:47.533218
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = DummyModule()
    ifconfig_path = module.get_bin_path('ifconfig')
    uname_path = module.get_bin_path('uname')
    entstat_path = module.get_bin_path('entstat')
    lsattr_path = module.get_bin_path('lsattr')
    if not ifconfig_path or not uname_path or not entstat_path or not lsattr_path:
        print("WARNING: cannot test AIXNetwork.get_interfaces_info, binary is missing")
        return True

    current_if = dict()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    net = AIXNetwork(module)

    # test parsing interface line 1

# Generated at 2022-06-11 03:07:49.552385
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_gdi = AIXNetwork({})
    assert aix_gdi.get_default_interfaces('/') == ({}, {})

# Generated at 2022-06-11 03:07:59.557038
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Input data for test_AIXNetwork_get_default_interfaces
    """
    # * route -n *
    #   Destination        Gateway            Flags Refs Use  Interface
    #   default            10.15.9.1          UG         0     0  en0
    #   default           2001:0db8::1       UG         0     0  en0
    #   default           2001:0db8::2       UG         0     0  lo0
    #   127.0.0.1          127.0.0.1          UH                6  lo0

    # expected result
    interface = dict(v4={}, v6={})
    interface['v4']['gateway'] = '10.15.9.1'
    interface['v4']['interface'] = 'en0'
   

# Generated at 2022-06-11 03:08:10.050906
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mocked_module = Mock()

# Generated at 2022-06-11 03:08:20.068276
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    aix_network = AIXNetwork()

    # set test network interface

# Generated at 2022-06-11 03:08:27.046004
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys

    # dummy module
    class MyModule():
        def get_bin_path(self, arg):
            return '/usr/sbin/'+arg

        def run_command(self, arg):
            # returns lsattr -El en0 output
            if arg == ['/usr/sbin/lsattr', '-El', 'en5']:
                return 0, 'mtu 1500 True', None
            # returns lsattr -El en1 output
            elif arg == ['/usr/sbin/lsattr', '-El', 'en6']:
                return 0, 'key_len 11 True mtu 9000 True', None
            # returns lsattr -El en2 output
            elif arg == ['/usr/sbin/lsattr', '-El', 'en7']:
                return 0, '', None

            # returns ent

# Generated at 2022-06-11 03:08:31.058006
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    n = AIXNetwork()
    n.module = module
    n.get_default_interfaces('route_path')


# Generated at 2022-06-11 03:08:32.241434
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector is not None


# Generated at 2022-06-11 03:09:06.227595
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    test_ifconfig_path = 'ifconfig'
    interfaces, _ips = test_module.get_interfaces_info(test_ifconfig_path)
    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4'] == [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}]
    assert interfaces['lo0']['ipv6'] == [{'address': '::1', 'prefix': '128', 'scope': 'host'}]
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-11 03:09:14.457087
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Dummy class for testing AIXNetwork
    class MockedAIXNetwork(AIXNetwork):
        def __init__(self, module):
            self.module = module
            self.interfaces = {}
            self.ips = dict(
                all_ipv4_addresses=[],
                all_ipv6_addresses=[],
            )

        def get_interfaces_info(self, ifconfig_path, ifconfig_options='-a'):
            self.ifconfig_path = ifconfig_path
            self.ifconfig_options = ifconfig_options
            return self.interfaces, self.ips

    # Some test cases

# Generated at 2022-06-11 03:09:16.037495
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'


# Generated at 2022-06-11 03:09:23.423309
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ansible_facts = dict(
        interfaces=['en0', 'en1', 'lo0'],
        all_ipv4_addresses=['10.68.40.88', '10.68.40.89', '127.0.0.1'],
        all_ipv6_addresses=['fe80::a00:27ff:fe56:f8c3', 'fe80::a00:27ff:fe56:f8c1', '::1']
    )
    ansible_facts['default_ipv4'] = dict(
        gateway='10.68.40.1',
        interface='en0'
    )

# Generated at 2022-06-11 03:09:31.819375
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    inet = AIXNetwork(module)
    fact_value = inet.get_default_interfaces('')
    expected_value = ({'interface': 'en0', 'gateway': '172.18.0.1'}, {'interface': 'en0', 'gateway': 'fe80::250:56ff:fe9e:edb4%en0'})
    assert fact_value == expected_value
    module.exit_json(changed=False, ansible_facts=dict(ansible_network_resources=dict(interfaces=fact_value)))


# Generated at 2022-06-11 03:09:33.710398
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert str(AIXNetworkCollector) == 'ansible.module_utils.facts.network.aix.aix.AIXNetworkCollector'

# Generated at 2022-06-11 03:09:42.474936
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.args = {}

        def get_bin_path(self, arg):
            return arg

    class AIXNetworkModule:
        platform = "AIX"

        def __init__(self):
            self.module = AnsibleModule()

        def get_bin_path(self, arg):
            return arg

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    x = AIXNetwork()
    x.module = AIXNetworkModule()
    x._platform = "AIX"

# Generated at 2022-06-11 03:09:44.979252
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_col = AIXNetworkCollector()
    assert network_col._fact_class._platform == 'AIX'
    assert network_col._platform == 'AIX'


# Generated at 2022-06-11 03:09:51.950777
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork.
    """
    import os
    from ansible.module_utils.facts.network.aix.test_aix_data import TEST_DATA

    i = AIXNetwork(None)
    path = os.path.join(os.path.dirname(__file__), 'test_data', 'ifconfig')
    r = i.get_interfaces_info(path)
    assert r == (TEST_DATA['interfaces'], TEST_DATA['ips'])


# Unit tests for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-11 03:09:57.978697
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    test_data = dict(
        ks0=dict(
            expected_ips_dict={'device': 'ks0', 'options': ['lan'], 'macaddress': 'unknown', 'type': 'unknown', 'ipv4': [], 'ipv6': [], 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']},
            expected_interfaces_info=dict(
                ks0=dict(
                    device='ks0',
                    macaddress='unknown',
                    type='unknown',
                    ipv4=[],
                    ipv6=[],
                    options=['lan'],
                    flags=['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'],
                ),
            ),
        ),
    )


# Generated at 2022-06-11 03:10:56.889554
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class TestModule(object):

        def __init__(self):
            self.params = dict()
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'uname':
                return '/usr/bin/uname'
            elif arg == 'ifconfig':
                return '/usr/bin/ifconfig'
            elif arg == 'lsattr':
                return '/usr/sbin/lsattr'
            elif arg == 'entstat':
                return '/usr/sbin/entstat'
            else:
                return None

        def run_command(self, args, *kwargs):
            self.run_command_calls.append(args)
            return self.run_command_

# Generated at 2022-06-11 03:11:05.228217
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    collector = AIXNetworkCollector(module=module)
    assert collector.platform == 'AIX'
    assert isinstance(collector.facts['default_ipv4'], dict)
    assert isinstance(collector.facts['default_ipv6'], dict)
    assert isinstance(collector.facts['interfaces'], dict)
    assert isinstance(collector.facts['all_ipv4_addresses'], list)
    assert isinstance(collector.facts['all_ipv6_addresses'], list)
    assert collector.facts['local4'] is None
    assert collector.facts['local6'] is None

# Generated at 2022-06-11 03:11:14.797979
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    m_run_command = module.run_command
    m_get_bin_path = module.get_bin_path
    m_debug = module.debug


# Generated at 2022-06-11 03:11:20.553198
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces = """en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
        inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
        inet6 ::1%1/0
        options=80000<LINKSTATE>
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
        media: Ethernet autoselect (none)
        status: active"""

# Generated at 2022-06-11 03:11:28.921479
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Unit test for AIXNetwork.get_default_interfaces.
    """

    # When 'route' command is found.

    uname_path = '/usr/bin/uname'
    netstat_path = '/usr/bin/netstat'
    route_path = '/usr/bin/route'

    module = FakeModule({
        'netstat_path': netstat_path,
        'route_path': route_path,
        'uname_path': uname_path,
    })

    network_collector = AIXNetworkCollector
    network_class = network_collector._fact_class(module)


# Generated at 2022-06-11 03:11:31.077234
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    # obj._fact_class should be 'AIXNetwork'
    assert obj._fact_class == AIXNetwork

# Generated at 2022-06-11 03:11:33.068050
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class._platform == 'AIX'
    assert obj._platform == 'AIX'


# Generated at 2022-06-11 03:11:41.015989
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class AIXNetwork """
    class DummyModule(object):
        @staticmethod
        def fail_json(*args, **kwargs):
            raise Exception(args, kwargs)

        @staticmethod
        def get_bin_path(arg, *args, **kwargs):
            if arg == 'ifconfig':
                return '/usr/bin/ifconfig'
            elif arg == 'uname':
                return '/bin/uname'
            elif arg == 'entstat':
                return '/usr/bin/entstat'
            elif arg == 'lsattr':
                return '/usr/sbin/lsattr'


# Generated at 2022-06-11 03:11:43.807973
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    default_interfaces = AIXNetwork.get_default_interfaces(['/usr/bin/netstat', '-nr'])
    assert default_interfaces['v4']['gateway'] == '192.168.1.1'

# Generated at 2022-06-11 03:11:54.395512
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts import Network
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # initialize module, that will be passed to method get_default_interfaces
    module = Network()

    # initialize Network class
    network = AIXNetwork(module)

    # initialize test data
    route_path = '/usr/bin/netstat'

# Generated at 2022-06-11 03:13:39.136007
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = AIXNetwork()
    fake_route = '/usr/sbin/route'
    expected = {
        'interface': 'en0',
        'gateway': '172.16.1.1',
    }
    actual = m.get_default_interfaces(fake_route)
    assert expected == actual[0]

# Generated at 2022-06-11 03:13:41.077445
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:13:45.206840
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_facts = AIXNetworkCollector()
    # Test case 1: No parameter
    assert aix_facts is not None, 'Failed to create object of class AIXNetworkCollector.'
    # Test case 2: Wrong parameter
    assert aix_facts.get_device() == None, 'Failed to create object of class AIXNetworkCollector.'

# Generated at 2022-06-11 03:13:51.693025
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ifconfig_path = 'ifconfig_path_test'
    route_path = 'route_path_test'
    collector = AIXNetworkCollector()
    assert collector
    assert collector.fact_class._platform == 'AIX'
    assert collector.fact_class.ifconfig_path == 'ifconfig'
    assert collector.fact_class.route_path == 'route'
    collector = AIXNetworkCollector(ifconfig_path, route_path)
    assert collector.fact_class.ifconfig_path == ifconfig_path
    assert collector.fact_class.route_path == route_path



# Generated at 2022-06-11 03:13:59.622019
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:14:02.157987
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    print("AIXNetworkCollector")
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    print("end")


# Generated at 2022-06-11 03:14:09.876648
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net_cls = AIXNetwork({})