

# Generated at 2022-06-11 03:04:31.601386
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()
    ifconfig_options = '-a'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:04:42.287239
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork, GenericBsdNetwork

    network_collector = AIXNetworkCollector()
    
    # test whether object is of class AIXNetworkCollector
    assert isinstance(network_collector, AIXNetworkCollector)
    
    # test instance variables of class AIXNetworkCollector:
    # _fact_class, _platform
    assert isinstance(network_collector._fact_class, AIXNetwork)
    assert network_collector._platform == 'AIX'
    
    # test whether the _fact_class is a subclass of NetworkBase
    assert issubclass(network_collector._fact_class, GenericBsdNetwork)
    
    # test whether the _fact_class is a subclass of GenericBsdIfconfigNetwork
    assert iss

# Generated at 2022-06-11 03:04:44.350601
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    m = AIXNetworkCollector
    assert m._platform == 'AIX'
    assert m._fact_class == AIXNetwork


# Generated at 2022-06-11 03:04:54.725275
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # Variables from the ansible host to be tested

# Generated at 2022-06-11 03:05:01.411860
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule
    module.run_command = MagicMock(return_value=(0, "default 192.168.1.1 UGS 0 0 en0\n192.168.1.0/24 link#4 UC 1 0 en4", ""))
    ans_obj = AIXNetwork(module)
    assert ans_obj.get_default_interfaces('') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {})

# Generated at 2022-06-11 03:05:04.058645
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    x = AIXNetworkCollector(module)
    assert x.platform == 'AIX'
    assert x.fact_class == AIXNetwork


# Generated at 2022-06-11 03:05:10.636729
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # no options
    result = AIXNetwork.get_default_interfaces(None)
    assert result['interface'] == 'en0'
    assert result['gateway'] == '10.0.5.254'

    # wrong option
    result = AIXNetwork.get_default_interfaces('non_existing_path')
    assert result['interface'] == 'en0'
    assert result['gateway'] == '10.0.5.254'

    # mising output
    result = AIXNetwork.get_default_interfaces('/tmp')
    assert result['interface'] == 'en0'
    assert result['gateway'] == '10.0.5.254'



# Generated at 2022-06-11 03:05:17.549969
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    a = AIXNetwork()
    interfaces = a.get_default_interfaces('/sbin/route')
    assert interfaces[0]['gateway'] == '192.168.122.254'
    assert interfaces[0]['interface'] == 'en0'
    assert interfaces[1]['gateway'] == 'fe80::e192:68ff:fe74:f5a5%3'
    assert interfaces[1]['interface'] == 'en3'


# Generated at 2022-06-11 03:05:27.578428
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import os
    import sys
    import doctest
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class FakeModule():
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_msg = ''

        def get_bin_path(self, arg, required=False):
            self.run_command_calls += 1
            return os.path.join(os.path.dirname(__file__), 'testdata', 'bin')

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls += 1

# Generated at 2022-06-11 03:05:30.266773
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MockModule()
    distro = AIXNetwork(module)
    interfaces = distro.get_interfaces_info('/usr/bin/ifconfig', '-a')[0]
    print(interfaces)

# Generated at 2022-06-11 03:05:48.353393
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork({"module_setup": True}, "/dev/null")
    default_interfaces = net.get_default_interfaces("")
    assert default_interfaces == ({"gateway": "10.21.170.1", "interface": "en0"}, {"gateway": "fe80::21c:4eff:fe26:ad50", "interface": "en0"})

# Generated at 2022-06-11 03:05:58.694495
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:01.492313
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    p = AIXNetworkCollector()
    assert isinstance(p.fact_class, AIXNetwork)
    assert p.platform == 'AIX'


# Generated at 2022-06-11 03:06:11.802215
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    import tempfile

    # example output of netstat -nr command

# Generated at 2022-06-11 03:06:15.001441
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    aixNetworkCollector = AIXNetworkCollector()
    assert repr(aixNetworkCollector) == '<ansible.module_utils.facts.network.aix.AIXNetworkCollector>'


# Generated at 2022-06-11 03:06:27.161697
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class AIXIfconfigNetwork(AIXNetwork):
        def __init__(self):
            self.routes = {'v4': {}, 'v6': {}}

    class Module:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, required=False):
            if required:
                assert name in self.bin_path, 'The binary {0} is required to test AIXNetworkCollector'.format(name)
            return self.bin_path.get(name, None)

        def run_command(self, cmd):
            assert cmd[0] == self.bin_path.get('netstat'), 'cmd {0} do not start with netstat'.format(cmd)
            return 0, 'a dummy output', 'not empty'

# Generated at 2022-06-11 03:06:34.099465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # This module_utils is in tests.module_utils.network.ios.test_ios_network.py
    from ..module_utils.network.ios.test_ios_network import MockNetworkModule
    from ..module_utils.network.ios.test_ios_network import TEST_COMMANDS

    # This module_utils is in tests.module_utils.facts.network.generic_bsd.test_generic_bsd.py
    from ..module_utils.facts.network.generic_bsd.test_generic_bsd import TEST_INTERFACES_DATA

    # This module_utils is in tests.module_utils.facts.network.generic_bsd.test_generic_bsd.py
    from ..module_utils.facts.network.generic_bsd.test_generic_bsd import TEST_ALL_IP_ADDRESSES

# Generated at 2022-06-11 03:06:44.963057
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class ModuleStub:
        def get_bin_path(self, arg):
            pass
        def run_command(self, arg):
            out = '''
                default 192.168.1.1 UG 2 0
                default ::1 UG
                default fe80::1%1 UG
                '''
            return 0, out, ''

    netif = AIXNetwork()
    netif.module = ModuleStub()

    interfaces = netif.get_default_interfaces('no matter what')

    assert interfaces['v4']['gateway'] == '192.168.1.1'
    assert interfaces['v4']['interface'] == '2'

    assert interfaces['v6']['gateway'] == '::1'
    assert interfaces['v6']['interface'] == ''



# Generated at 2022-06-11 03:06:54.014776
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['all'], type='list')))


# Generated at 2022-06-11 03:07:04.170449
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class AIXNetwork.
    Create an instance of class AIXNetwork and test
    method get_interfaces_info.
    """

    # parameters for method parse_interface_line of class AIXNetwork
    test_line1 = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '32768']

# Generated at 2022-06-11 03:07:32.091924
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    c = AIXNetworkCollector()
    assert isinstance(c, NetworkCollector)
    assert c.platform == 'AIX'
    assert isinstance(c.facts, GenericBsdIfconfigNetwork)



# Generated at 2022-06-11 03:07:38.880991
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This is the AIXNetwork.get_default_interfaces unit test
    It checks if the method get_default_interfaces of class AIXNetwork returns the default gateway and interface.
    """
    fact_collector = AIXNetwork()
    v4_interface, v6_interface = fact_collector.get_default_interfaces('/usr/bin/netstat -nr')
    if v4_interface:
        if 'gateway' in v4_interface and 'interface' in v4_interface:
            print('The IPv4 default gateway and interface are: ' + v4_interface['gateway'] + ", " + v4_interface['interface'])

# Generated at 2022-06-11 03:07:48.494266
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    AIXNetwork.get_interfaces_info()
    """
    # test module

# Generated at 2022-06-11 03:07:58.890427
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = GenericBsdIfconfigNetwork(dict())
    network = AIXNetwork(module)
    routes = [
        'default 192.168.0.1 UG 0 0 en2',
        'default fe80::%eth0 UG 0 0 eth0',
        'default 192.168.1.1 UGSc 0 0 en1',
        'default 192.168.2.1 UH 0 0 en0',
        'default 192.168.3.1 UGHS 0 0 en0',
    ]

    assert network.get_default_interfaces(lines=routes) == (
        {'gateway': '192.168.0.1', 'interface': 'en2'},
        {'gateway': 'fe80::%eth0', 'interface': 'eth0'},
    )



# Generated at 2022-06-11 03:08:07.373741
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            route_path=dict(default='/sbin/route', type='str'),
        ),
    )

    net = AIXNetwork(module)
    v4 = net.get_default_interfaces(module.params['route_path'])
    v6 = net.get_default_interfaces(module.params['route_path'])
    assert v4['gateway'] == '10.254.254.254'
    assert v4['interface'] == 'en1'
    assert v6['gateway'] == '2001:0000:0000:0000:0000:0000:0000:0001'
    assert v6['interface'] == 'en1'


# Generated at 2022-06-11 03:08:15.320687
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class Module(object):
        def __init__(self):
            self.params = {}
            self.binary_path = {}
            self.binary_path['netstat'] = '/usr/bin/netstat'

        def get_bin_path(self, binary, required=False):
            return self.binary_path[binary]


# Generated at 2022-06-11 03:08:24.491154
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils._text import to_bytes

    # Test fixture
    #
    # AIX 7.2 TL3 SP3
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:08:33.915510
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class options:
        def __init__(self):
            self.connection = 'network_cli'
            self.module_path = None

    class module:
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.options = options()

        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'netstat':
                return os.path.abspath('test/unit/module_utils/facts/network/aix_netstat')
            return '/bin'

        def run_command(self, arg, *args, **kwargs):
            cmd = arg[0]
            rc = 0
            out = ''
            err = ''
            if cmd == 'netstat':
                rc = 0

# Generated at 2022-06-11 03:08:42.978113
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = [ "!all", "min" ]
            self.params['filter'] = ['']

        def run_command(self, cmd):

            if cmd[0] == '/usr/bin/uname':
                return 0, '0', ''

# Generated at 2022-06-11 03:08:52.615549
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import tempfile

    # Create file containing interfaces info
    temp = tempfile.TemporaryFile()


# Generated at 2022-06-11 03:09:49.122500
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Options():
        def __init__(self, bin_path):
            self.bin_path = bin_path

    class Module():
        def __init__(self):
            self.options = Options(dict(ifconfig='/etc/pathto/ifconfig'))
            self.run_command_calls = 0

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'ifconfig':
                return self.options.bin_path[arg]
            else:
                return ''

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 03:09:56.290041
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:10:05.955950
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    collector = AIXNetworkCollector(module=module)
    fc = collector.get_network_facts()

    # Sample interface names from AIX 7.2
    for iface2use in fc.interfaces.keys():
        if iface2use in ['lo0', 'en0', 'en0:0', 'en1', 'en1:0']:
            break

    # Sample data from AIX 7.2 with en0 configured as DHCP, en1 as manual IPv4 with IPv6 ND

# Generated at 2022-06-11 03:10:07.254968
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(None), AIXNetworkCollector)

# Generated at 2022-06-11 03:10:16.241275
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default  192.168.100.100  UGS        0        1500    en0    default  fe80::c8de:daff:fea5:f451%2  UGS        0        1500    en0', None))
    obj = AIXNetworkCollector(module=module)
    real_output = obj.fact_class.get_default_interfaces(route_path=None)
    expected_output = ({'interface': 'en0', 'gateway': '192.168.100.100'}, {'interface': 'en0', 'gateway': 'fe80::c8de:daff:fea5:f451%2'})
    assert real_output == expected_output

# Unit test

# Generated at 2022-06-11 03:10:23.381852
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # our test class
    class TestModule(object):
        def __init__(self, rc, out, err, path):
            self.rc = rc
            self.out = out
            self.err = err
            self.path = path

        def get_bin_path(self, arg):
            if self.path:
                return self.path
            return None

        def run_command(self, arg):
            out = self.out
            if arg[0] == 'netstat' and arg[1] == '-nr':
                out = self.out
            elif arg[0] == 'ifconfig' and arg[1] == '-a':
                out = self.out
            return self.rc, out, self.err

    # our test dictionary
    test_dic = dict()

    # netstat output


# Generated at 2022-06-11 03:10:32.336972
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, command):
            if 'uname' == command:
                return '/bin/uname'
            else:
                return '/usr/sbin/ifconfig'

        def run_command(self, command):
            if 'ifconfig' == command[0]:
                return self.rc, self.out, self.err
            else:
                return self.rc, '0', self.err


# Generated at 2022-06-11 03:10:34.473021
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_facts = {}
    aix_network_collector = AIXNetworkCollector(ansible_facts)
    assert aix_network_collector._fact_class == AIXNetwork

# Generated at 2022-06-11 03:10:41.649793
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # this is executed only here locally
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../utils/')
    from ansible_module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], required=False),
            gather_network_resources=dict(default=[], required=False)
        )
    )

    # set some fake values
    module.params['gather_subset'] = ['min']
    module.params['gather_network_resources'] = ['all']

    network_facts = AIXNetwork(module)

# Generated at 2022-06-11 03:10:50.588325
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:26.907455
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    x = AIXNetworkCollector()
    assert x is not None

# Generated at 2022-06-11 03:12:29.719099
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    try:
        module = AnsibleModule(argument_spec=dict())
        network_collector = AIXNetworkCollector(module=module, platform='AIX')
    except Exception:
        pytest.fail("AIXNetworkCollector init failed")

# Generated at 2022-06-11 03:12:31.801519
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    expected = AIXNetworkCollector
    result = AIXNetworkCollector()
    assert result.__class__ == expected


# Generated at 2022-06-11 03:12:33.616483
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('/does/not/exist') == ({}, {})


# Generated at 2022-06-11 03:12:43.822720
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from unittest import TestCase
    import sys, os
    from ansible.module_utils.facts.network.base import NetworkCollector

    class MyNetCollector(NetworkCollector):
        network_resource_module = AIXNetwork
        network_resource_class = AIXNetwork
        network_resource_facts = AIXNetwork
        def __init__(self):
            self.__dict__ = sys.modules[__name__].__dict__
            self.module = TestCase()

    nc = MyNetCollector()
    nc.network_resource_class.module.run_command = TestCase().run_command

    # create dummy ifconfig output

# Generated at 2022-06-11 03:12:52.933987
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    network_instance = AIXNetwork(module)

    out = '''default 172.16.0.1 UG 1 0 en1
'''
    assert network_instance.get_default_interfaces(out) == ({'gateway': '172.16.0.1', 'interface': 'en1'}, {})

    out = '''default 172.16.0.1 UG 1 0 en1
default fe80::1 UG 2 0 en1
'''
    assert network_instance.get_default_interfaces(out) == ({'gateway': '172.16.0.1', 'interface': 'en1'}, {'gateway': 'fe80::1', 'interface': 'en1'})


# Generated at 2022-06-11 03:12:56.161333
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector(), '_fact_class')
    assert hasattr(AIXNetworkCollector(), '_platform')
    assert AIXNetworkCollector()._platform == 'AIX'
    assert AIXNetworkCollector()._fact_class == AIXNetwork


# Generated at 2022-06-11 03:12:57.714295
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-11 03:13:07.193084
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = None

    netstat_path = '/usr/bin/netstat'
    ifconfig_path = '/usr/sbin/ifconfig'

    def run_command(self, commands, check_rc=True):
        if commands[0] == netstat_path:
            if commands[1] == '-nr':
                if commands[2] == '-f':
                    return (0, 'default 96.0.0.1 UG 1 0 en0', None)
                else:
                    return (0, 'default 96.0.0.1 UG 1 0 en0\ndefault fe80:: UG 1 0 en0', None)

    setattr(module, 'run_command', run_command)
    setattr(module, 'get_bin_path', lambda self, x: x)

    # Test no IPv4 gateway

# Generated at 2022-06-11 03:13:15.906287
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import platform
    import doctest

    m_platform = platform.system