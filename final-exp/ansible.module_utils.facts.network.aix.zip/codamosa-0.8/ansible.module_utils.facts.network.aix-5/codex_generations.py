

# Generated at 2022-06-11 03:04:30.546962
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIX_get_default_interfaces = AIXNetwork(dict(module=None))

    # test first the case of a line starting with 'default'
    route_path = '/usr/sbin'
    line = 'default 192.168.7.1 UG      0 0 0 en0'
    words = line.split()
    assert len(words) == 6

    # This is the expected output
    expected_interface = {'v4': {'gateway': '192.168.7.1', 'interface': 'en0'}, 'v6': {}}

    # The tested method
    interface = AIX_get_default_interfaces.get_default_interfaces(route_path)

    assert interface == expected_interface

    # Test the case of a line not starting with 'default'

# Generated at 2022-06-11 03:04:41.275466
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    unittest.TestCase.maxDiff = None
    test_ifconfig_path = '/sbin/ifconfig'
    test_ifconfig_options = '-a'

# Generated at 2022-06-11 03:04:48.882713
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # create a temporary working directory
    tmp_dir = tempfile.mkdtemp()

    # create a temporary file with interface information
    f, ifconfig_path = tempfile.mkstemp(dir=tmp_dir)
    os.close(f)

    # the file with ifconfig output

# Generated at 2022-06-11 03:04:59.457906
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # create a dummy module for testing
    from ansible.compat.tests import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class AIXNetworkCollectorTest(unittest.TestCase):
        def setUp(self):
            self.module = basic.AnsibleModule(argument_spec={})
            self.module.params = {}
            self.module.exit_json = exit_json
            self.module.fail_json = fail_json

            self.module.run_command = run_command
            self.module.get_bin_path = get_bin_path

    unit_test_obj = AIXNetworkCollectorTest()

    unit_test_obj.setUp()


# Generated at 2022-06-11 03:05:09.666261
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class MockModule():
        def __init__(self, fail_json_bool=False):
            self.params = dict(gather_subset=[])
            self.fail_json = Mock(side_effect=NetworkError) if fail_json_bool else Mock()

        def get_bin_path(self, executable, required=False):
            return executable

    class MockCollection():
        def __init__(self, fail_json_bool=False):
            self.module = MockModule(fail_json_bool=fail_json_bool)


# Generated at 2022-06-11 03:05:19.537761
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class AIXNetwork
    Run 'nosetests -v' on root folder to run the test.
    """
    import os
    import sys
    import json
    import unittest
    import pkgutil
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    # get sample output from file
    stream = StringIO(pkgutil.get_data(__name__,
                                       os.path.join('tests', 'data', 'aix_ifconfig.txt')))

    # create a module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    # assign stream to module.run_command

# Generated at 2022-06-11 03:05:29.917533
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-11 03:05:40.448802
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    n = AIXNetwork(module)

    n.module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 1 0 en0\ndefault fe80::%en0 UG 1 0 en0\ndefault link#4 UG 0 0 vlan5', ''))

    assert n.get_default_interfaces('') == ({'interface': 'en0', 'gateway': '192.168.1.1'}, {'interface': 'en0', 'gateway': 'fe80::%en0'})

    n.module.run_command = MagicMock(return_value=(1, '', ''))


# Generated at 2022-06-11 03:05:50.050656
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:06:01.207583
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule:
        def __init__(self):
            self.run_command_calls = 0
            self.uname_path = '/usr/bin/uname'
            self.netstat_path = '/usr/bin/netstat'

        def run_command(self, command, check_rc=False):
            self.run_command_calls += 1
            if command[0] == self.uname_path:
                if self.run_command_calls == 1:
                    return 0, normal_uname_out, ""
                else:
                    return 1, "", ""
            elif command[0] == self.netstat_path:
                return 0, normal_netstat_out, ""
            else:
                return 1, "", ""


# Generated at 2022-06-11 03:06:24.265771
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = DG.AnsibleModule(
    argument_spec=dict(
        gather_subset=dict(default=['!all'], type='list'),
        gather_network_resources=dict(default=['all'], type='list')
    ),
    supports_check_mode=False
    )
    hostname = 'PC'
    mock_paths = {'bin/ifconfig': ''}

# Generated at 2022-06-11 03:06:32.835226
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class FakeModule(object):
        def __init__(self):
            self.bin_path = '/usr/bin'
            self.debug = True

        def get_bin_path(self, arg):
            return self.bin_path + '/' + arg

        def run_command(self, args, check_rc=True):
            cmd = args[0]
            arg = args[1] if len(args) > 1 else ''

# Generated at 2022-06-11 03:06:43.863406
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class AIXNetwork
    '''

    # The following is the output of 'ifconfig -a' on a AIX 7.2 TL2
    # box. It shows all possible cases of output line.

# Generated at 2022-06-11 03:06:50.543546
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()

    rc = 0

# Generated at 2022-06-11 03:07:00.282967
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:08.650138
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    route_path = module.get_bin_path('netstat')

    net_cls = AIXNetwork(module=module)
    ipv4_default, ipv6_default = net_cls.get_default_interfaces(route_path)

    if ipv4_default == {} and ipv6_default == {}:
        module.exit_json(msg="No default gateway found", **ipv4_default)
    else:
        module.exit_json(msg="Default IPv4 gateway found", **ipv4_default)



# Generated at 2022-06-11 03:07:17.064985
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:07:24.325814
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_net = AIXNetwork({'ANSIBLE_MODULE_ARGS': {'gather_subset': ['!all', '!min', '!hardware'], 'filter': 'en*'}})

    interfaces = {
        'v4': {
            'gateway': '10.33.252.1',
            'interface': 'en0'
        },
        'v6': {
            'gateway': '10.33.252.1',
            'interface': 'en0'
        },
    }

    route_path = ''

    assert interfaces == aix_net.get_default_interfaces(route_path)

# Generated at 2022-06-11 03:07:33.374688
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    net_dev = AIXNetwork(module)

    net_dev._default_gateway = None
    net_dev._default_interface_ipv4 = None
    net_dev._default_interface_ipv6 = None

    def_ipv4, def_ipv6 = net_dev.get_default_interfaces()

    assert net_dev._default_interface_ipv4['interface'] == 'bond0'
    assert net_dev._default_interface_ipv4['gateway'] == '192.168.2.2'
    assert net_dev._default_interface_ipv6['interface'] == 'bond0'
    assert net_dev._default_interface_ipv6['gateway'] == 'fe80::11'


# Generated at 2022-06-11 03:07:38.121552
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    obj = AIXNetworkCollector()
    assert obj._platform == 'AIX'
    assert obj._fact_class.platform == 'AIX'
    assert obj._fact_class.get_default_interfaces
    assert obj._fact_class.get_interfaces_info
    assert obj._fact_class.parse_interface_line


# Generated at 2022-06-11 03:08:10.847147
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    defs = dict(
        route_path='/usr/sbin/netstat'
    )
    module = FakeAnsibleModule(**defs)

    network = AIXNetwork(module=module)
    interface = dict(v4={}, v6={})
    interface['v4']['gateway'] = '192.168.1.2'
    interface['v4']['interface'] = 'ent1'
    interface['v6']['gateway'] = 'fe80::21c:42ff:fe2d:d28e%ent1'
    interface['v6']['interface'] = 'ent1'

    assert interface == network.get_default_interfaces('/usr/sbin/netstat')


# Generated at 2022-06-11 03:08:12.182336
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-11 03:08:15.757861
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    result = AIXNetwork.get_default_interfaces("anypath")
    print("test_AIXNetwork_get_default_interfaces:")
    print("  result='" + str(result) + "'")
    print("")



# Generated at 2022-06-11 03:08:18.138451
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _fact_class = AIXNetwork
    _platform = 'AIX'
    obj = AIXNetworkCollector(_fact_class, _platform)
    assert obj

# Generated at 2022-06-11 03:08:26.208773
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json
    test_module = type('module', (object,), dict(run_command=run_command))()

    def run_command(args, check_rc=True):
        # args[0] is always the command to execute
        if args[0] == '/sbin/uname':
            return 0, '0', ''

# Generated at 2022-06-11 03:08:31.094106
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector
    """

    # Create instances of required classes by mocked constructor
    network_module = NetworkCollector(load_on_init=False)

    assert network_module
    assert network_module.network == AIXNetworkCollector
    assert network_module.network.platform == 'AIX'

# Generated at 2022-06-11 03:08:33.283817
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'
    assert obj.fact_class.__name__ == 'AIXNetwork'


# Generated at 2022-06-11 03:08:42.135621
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # I need to create a mock object
    ifconfig_path = module.get_bin_path('ifconfig')
    # read help from 'ifconfig -a'
    process = subprocess.Popen([ifconfig_path, '-a'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    help_out, err = process.communicate()
    # read help from 'netstat -nr'
    netstat_path = module.get_bin_path('netstat')
    process = subprocess.Popen([netstat_path, '-nr'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    nr_out,

# Generated at 2022-06-11 03:08:46.412488
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = MockModule()

    # Constructor
    network_collector1 = AIXNetworkCollector()

    # Check if assignment was done correctly
    assert network_collector1.platform == 'AIX'
    assert network_collector1.module == module
    assert isinstance(network_collector1.fact_class, AIXNetwork)



# Generated at 2022-06-11 03:08:56.361203
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # create an instance of AIXNetwork
    aix_network = AIXNetwork()

    # create fake module
    aix_network.module = FakeAnsibleModule()

    # set default values for variables route_path and ifconfig_path
    aix_net = AIXNetwork()
    aix_net.route_path = '/usr/sbin/netstat'
    aix_net.ifconfig_path = '/usr/sbin/ifconfig'

    # test route_path which is /usr/sbin/netstat
    # test first_match which is True
    v4, v6 = aix_network.get_default_interfaces('/usr/sbin/netstat')
    assert v4['gateway'] == '172.16.7.1'
    assert v4['interface'] == 'en0'
   

# Generated at 2022-06-11 03:09:45.569690
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:09:46.471584
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-11 03:09:52.219751
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_AIXNet = AIXNetwork({})
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options='-a'
    assert test_AIXNet.get_interfaces_info(ifconfig_path, ifconfig_options)[0]['lo0'] == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK'], 'macaddress': 'unknown'}


# Generated at 2022-06-11 03:09:58.095737
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    test_AIXNetwork = AIXNetwork()
    test_AIXNetwork.module = NetworkCollector()

# Generated at 2022-06-11 03:10:00.648984
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    an = AIXNetwork()
    assert an.get_default_interfaces('/sbin/route') == ({}, {})

# Generated at 2022-06-11 03:10:10.725199
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork
    """
    class module:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, cmd):
            return "/usr/bin/%s" % cmd


# Generated at 2022-06-11 03:10:18.676449
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockModule()
    facts = dict(
        default_ipv4={},
        default_ipv6={},
    )

    # Module Run Command function will return:
    #   rc=0
    #   out = 'default 192.168.0.254 UG en0
    #          default 192:0:0:0:0:0:0:1 UG lo0
    #          default ...'
    #   err = ''
    def mock_run_command_netstat(netstat_path, options):
        return (0, 'default 192.168.0.254 UG en0\ndefault 192:0:0:0:0:0:0:1 UG lo0\ndefault ...', '')

    module.run_command = mock_run_command_netstat

    network = AIXNetwork

# Generated at 2022-06-11 03:10:25.847232
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    facts = AIXNetwork()
    test_facts = dict(
        route_path='/usr/sbin/route',
    )
    facts.populate_facts(None, test_facts)
    rc, out, err = facts.module.run_command(['echo', '-e', 'default 172.18.17.254 UGS en1\ndefault fe80::%en1 UGHS lo0'])
    assert facts.get_default_interfaces(test_facts['route_path']) == ({'gateway': '172.18.17.254', 'interface': 'en1'}, {'gateway': 'fe80::%en1', 'interface': 'lo0'})


# Generated at 2022-06-11 03:10:27.905158
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(None, None, None).collect()

    # test uname_W
    assert not facts.get('uname_W')

# Generated at 2022-06-11 03:10:37.447448
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class AIXNetwork."""

    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.get_bin_path = mock.Mock(return_value='/usr/sbin/ifconfig')

    nw = AIXNetwork({}, module)
    nw.get_interfaces_info()

    # This file does not contain route command output
    nw.get_default_interfaces()


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import mock

    # Unit test for method get_interfaces_info of class AIXNetwork
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-11 03:12:13.044275
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net_collector = AIXNetwork()
    ifc_v4, ifc_v6 = net_collector.get_default_interfaces()
    assert ifc_v4['gateway']    == '172.16.66.1'
    assert ifc_v4['interface']  == 'en5'
    assert ifc_v6['gateway']    == 'fe80::250:d0ff:fe3a:bce0'
    assert ifc_v6['interface']  == 'en5'

# Generated at 2022-06-11 03:12:19.883398
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )

    aix = AIXNetwork(module)

# Generated at 2022-06-11 03:12:30.207985
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork
    """
    # Create an instance of class AIXNetwork
    aixnet = AIXNetwork(dict(ansible_facts=dict()))

    # Test 1: No interface
    interfaces_info = aixnet.get_interfaces_info(
        '/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )
    assert len(interfaces_info) == 0

    # Test 2: One interface
    interfaces_info = aixnet.get_interfaces_info(
        'test/unit/module_utils/facts/network/test_data/AIX/ifconfig_one_interface',
        ifconfig_options='-a'
    )
    assert len(interfaces_info) == 1

# Generated at 2022-06-11 03:12:36.263680
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = ''


# Generated at 2022-06-11 03:12:41.157896
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-11 03:12:50.237202
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value="/usr/bin/netstat")

    netstat_rc = 0
    netstat_out = '''
Routing tables

Internet:
Destination        Gateway            Flags  Refs Use          If Name
default            192.168.2.254      UG        1    0 en6
default            192.168.2.254      UG        1    0 en6
'''
    netstat_err = ''
    module.run_command = MagicMock(return_value=(netstat_rc, netstat_out, netstat_err))



# Generated at 2022-06-11 03:12:52.893477
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # _platform is an attribute of class NetworkCollector
    aix_network = AIXNetworkCollector()
    assert aix_network._platform == 'AIX'

# Generated at 2022-06-11 03:13:00.575759
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = 'test_module'
    ipv4_interface = dict(gateway='9.9.9.9', interface='eno1')
    ipv6_interface = dict(gateway='aa:bb:cc:dd:ee:ff:11:22', interface='eno2')

    # create a correct AIXNetwork object
    aix_network = AIXNetwork(module)
    aix_network.default_interfaces = dict(v4=ipv4_interface, v6=ipv6_interface)

    # test the get method for v4_interface
    assert aix_network.get_default_interfaces('route_path')['v4_interface'] == 'eno1'
    # test the get method for v6_interface

# Generated at 2022-06-11 03:13:10.242428
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'

    # Test inherited method without changes
    fc = AIXNetworkCollector()

    # Test inherited method without changes
    assert fc.get_device_to_mac() == {}

    # Test inherited method without changes
    assert fc.get_route_to_local() == {}

    # Test inherited method without changes
    assert fc.get_route_to_gateway() == {}

    # Test inherited method without changes
    assert fc.get_default_gateway_interface() == {}

    # Test inherited method without changes
    assert fc.get_interfaces() == {}

    # Test inherited method without changes
    assert fc.get_all_ipv4_addresses() == []

    # Test inherited method without changes
    assert fc.get_all_ipv

# Generated at 2022-06-11 03:13:12.264051
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    s = AIXNetworkCollector()
    assert s._fact_class.platform == 'AIX'
    assert s._platform == 'AIX'