

# Generated at 2022-06-17 00:32:43.375690
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:32:47.809620
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:51.129259
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:00.929514
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    test_module.get_bin_path = lambda x: '/usr/sbin/' + x
    test_module.run_command = lambda x: (0, '', '')

# Generated at 2022-06-17 00:33:09.289588
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork

# Generated at 2022-06-17 00:33:11.830719
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:22.150907
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']

    # Create an instance of AIXNetwork
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()

    # Get the default interfaces
    default_interfaces = network_collector.get_default_interfaces()

    # Check if the default interfaces are correct
    assert default_interfaces['default_gateway_ipv4']['interface'] == 'en0'
    assert default_interfaces['default_gateway_ipv4']['gateway'] == '10.0.2.2'

# Generated at 2022-06-17 00:33:32.998488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import NetworkConfig
    from ansible.module_utils.facts.network.generic_bsd import NetworkParams
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaces
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterface
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaceIPv6

   

# Generated at 2022-06-17 00:33:35.770705
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-17 00:33:38.841662
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:55.701096
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:34:00.006049
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class.
    """
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector


# Generated at 2022-06-17 00:34:02.379603
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:13.309094
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # create a fake module
    class FakeModule:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['gather_network_resources'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = None
            self.params['config'] = None
            self.params['debug'] = False

# Generated at 2022-06-17 00:34:21.921613
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    default_interfaces = network_facts['default_ipv4'], network_facts['default_ipv6']

    assert default_interfaces == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::21e:c9ff:fea0:1', 'interface': 'en0'})


# Generated at 2022-06-17 00:34:32.995138
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::21f:5bff:fe2c:b8d0'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:34:35.760361
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')



# Generated at 2022-06-17 00:34:47.459612
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkInterface
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkInterfaceCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkInterfaces

# Generated at 2022-06-17 00:34:50.718730
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:34:53.918032
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:35:22.688897
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.0.2.2'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:35:25.017586
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-17 00:35:34.446490
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 00:35:43.099462
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create a AIXNetwork object
    aix_network = AIXNetwork()

    # Create a dictionary with the expected result

# Generated at 2022-06-17 00:35:54.060815
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:35:57.714037
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')



# Generated at 2022-06-17 00:36:00.994354
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:03.553662
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:06.177586
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:09.272113
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path=None)

# Generated at 2022-06-17 00:36:59.165744
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-lines

    # Create a class object
    aix_network = AIXNetwork()

    # Create a test module

# Generated at 2022-06-17 00:37:06.083413
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork.
    """
    # create an instance of AIXNetwork
    aix_network = AIXNetwork()

    # create a mock module
    mock_module = type('AnsibleModule', (object,), dict(
        params=dict(
            gather_subset=['all'],
            gather_network_resources=['all']
        ),
        get_bin_path=lambda *args, **kwargs: '/sbin/ifconfig'
    ))

    # set the instance's module to the mock module
    aix_network.module = mock_module

    # create a mock module

# Generated at 2022-06-17 00:37:16.349103
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 00:37:19.311998
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')

# Generated at 2022-06-17 00:37:29.429157
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:37:30.784345
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:37:43.238434
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 1 0 en0\ndefault :: UG 1 0 en0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == '::'

# Generated at 2022-06-17 00:37:45.221611
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:37:47.518153
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:50.235176
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:39:28.710842
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:39:36.718394
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-17 00:39:42.201844
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    network_collector.get_default_interfaces('/usr/sbin/netstat')


# Generated at 2022-06-17 00:39:45.855857
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of the class AIXNetworkCollector
    """
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.platform == 'AIX'
    assert aix_network_collector.fact_class == AIXNetwork

# Generated at 2022-06-17 00:39:54.698330
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacy
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacyCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoIfconfig
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoIfconfigCollector


# Generated at 2022-06-17 00:39:58.927912
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:40:08.556401
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value=True)
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_AIXNetwork = AIXNetwork(test_module)
    test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig')
    test_module.run_command.assert_called_with(['/usr/sbin/ifconfig', '-a'])


# Generated at 2022-06-17 00:40:10.413108
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:40:13.284743
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:23.473348
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_collector.get_default_interfaces('/usr/sbin/route')
    facts = network_collector.get_facts()
    assert facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert facts['default_ipv4']['interface'] == 'en0'
    assert facts['default_ipv6']['gateway'] == 'fe80::1%en0'