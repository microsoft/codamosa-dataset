

# Generated at 2022-06-17 00:32:44.003232
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:48.356161
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:59.529578
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork

# Generated at 2022-06-17 00:33:04.041985
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:33:07.481379
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector.
    It tests the creation of an object of the AIXNetworkCollector class.
    """
    AIXNetworkCollector()

# Generated at 2022-06-17 00:33:16.402502
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value=True)
    test_network = AIXNetwork(test_module)
    test_network.get_interfaces_info('/usr/sbin/ifconfig')
    assert test_network.interfaces
    assert test_network.ipv4_addresses
    assert test_network.ipv6_addresses


# Generated at 2022-06-17 00:33:27.392754
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # create a test object
    test_obj = AIXNetwork()

    # create a test module
    test_module = type('test_module', (object,), {'run_command': test_obj.run_command})

    # set module.run_command to a mock function
    test_module.run_command = test_obj.run_command

    # set module.get_bin_path to a mock function
    test_module.get_bin_path = test_obj.get_bin_path

    # set module.exit_json to a mock function
    test_module.exit_json = test_obj.exit_json

    # set module.fail_json to a mock function

# Generated at 2022-06-17 00:33:35.542862
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # Create a test object
    aix_network = AIXNetwork()

    # Create a test object
    aix_network_collector = AIXNetworkCollector()

    # Create a test object
    aix_network_collector._fact_class = aix_network

    # Create a test object
    aix_network_collector._platform = 'AIX'

    # Create a test object
    aix_network_collector._fact_class._module = aix_network_collector._module

    # Create a test object
    aix_network_collector._fact_class._module.get_bin_path = lambda x: '/sbin/'

# Generated at 2022-06-17 00:33:41.747524
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    default_interfaces = network.get_default_interfaces('/sbin/route')
    assert default_interfaces == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})



# Generated at 2022-06-17 00:33:45.116407
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:33:59.698825
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None, None, None)

# Generated at 2022-06-17 00:34:01.636360
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:12.109725
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

# Generated at 2022-06-17 00:34:20.150254
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_collector.get_default_interfaces()
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::1'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:34:22.831472
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)


# Generated at 2022-06-17 00:34:30.298296
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_module.run_command = MagicMock(return_value=(0, '', ''))

    test_module.get_bin_path = MagicMock(return_value='/usr/sbin/ifconfig')

    test_AIXNetwork = AIXNetwork(test_module)

    test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig')

    test_module.run_command.assert_called_with(['/usr/sbin/ifconfig', '-a'])



# Generated at 2022-06-17 00:34:32.220707
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:37.355758
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:43.555135
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:34:44.931094
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:18.132404
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data

# Generated at 2022-06-17 00:35:22.478109
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:34.244994
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of class AIXNetwork.
    """
    # Create an instance of class AIXNetwork
    aix_network = AIXNetwork()

    # Create a dictionary with the output of the command 'ifconfig -a'

# Generated at 2022-06-17 00:35:43.092878
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert 'en0' in interfaces
    assert 'en0' in ips['all_ipv4_addresses']
    assert '10.0.2.15' in ips

# Generated at 2022-06-17 00:35:54.061204
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector

    # set up test environment
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:36:05.532055
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')
    assert network_collector.facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::1'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:36:09.798787
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:15.518481
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4, v6 = network.get_default_interfaces('/sbin/route')
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-17 00:36:25.491447
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.10.10.1'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::21f:5bff:fea2:a8e6'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:36:28.396722
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:37:16.245409
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:20.287351
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    collector = AIXNetworkCollector(None, None, None, None)
    assert collector
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-17 00:37:24.445326
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:37:27.431466
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:37:38.390453
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['default_gateway_ipv4']['interface'] == 'en0'
    assert facts['default_gateway_ipv4']['gateway'] == '10.0.0.1'
    assert facts['default_gateway_ipv6']['interface'] == 'en0'

# Generated at 2022-06-17 00:37:40.721811
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:44.556201
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:37:50.218220
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    interface = network.get_default_interfaces(route_path)
    assert interface == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::21e:c9ff:fea8:d9a0', 'interface': 'en0'})

# Generated at 2022-06-17 00:37:53.740159
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class
    """
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:57.466061
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:39:50.602365
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import Linux

# Generated at 2022-06-17 00:39:52.463504
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:01.785487
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ansible_facts']['ansible_default_ipv4']['interface'] == 'en0'
    assert module.exit_json.call_args[0][0]['ansible_facts']['ansible_default_ipv4']['gateway'] == '10.0.2.2'
    assert module.exit_json.call_args[0][0]['ansible_facts']['ansible_default_ipv6']['interface'] == 'en0'

# Generated at 2022-06-17 00:40:07.529655
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interface = network.get_default_interfaces('/sbin/route')
    assert interface == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::21f:5bff:fe2e:8b2c%en0', 'interface': 'en0'})


# Generated at 2022-06-17 00:40:18.778465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacy
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacyCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoIfconfig

# Generated at 2022-06-17 00:40:20.367801
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:31.873252
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetwork
    from ansible.module_utils.facts.network.solaris import SolarisNetwork

# Generated at 2022-06-17 00:40:34.820099
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:40:44.620633
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-17 00:40:49.893117
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault :: UG 0 0 en0', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    network = AIXNetwork(module)
    assert network.get_default_interfaces('/usr/bin/netstat') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': '::', 'interface': 'en0'})
