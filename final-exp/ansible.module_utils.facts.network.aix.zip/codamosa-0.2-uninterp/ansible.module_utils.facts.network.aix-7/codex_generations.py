

# Generated at 2022-06-17 00:32:50.457129
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4, v6 = network.get_default_interfaces('/usr/sbin/route')
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1'
    assert v6['interface'] == 'en0'



# Generated at 2022-06-17 00:32:54.120643
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/netstat')

# Generated at 2022-06-17 00:32:57.797176
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:08.811827
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'

# Generated at 2022-06-17 00:33:12.964256
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'


# Generated at 2022-06-17 00:33:22.229382
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:24.871038
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:34.693343
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg):
            return self.params['bin_path']

        def run_command(self, arg):
            return self.params['run_command']


# Generated at 2022-06-17 00:33:39.517289
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:33:43.850013
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:05.885785
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    # create a AIXNetwork object
    aix_network = AIXNetwork()

    # create a GenericBsdIfconfigNetwork object
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # create a AIXNetworkCollector object
    aix_network_collect

# Generated at 2022-06-17 00:34:18.227038
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:20.689533
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:26.374450
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:34:28.663947
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:30.412749
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:31.956133
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()

# Generated at 2022-06-17 00:34:36.922957
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollect

# Generated at 2022-06-17 00:34:39.062716
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:47.680488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-17 00:35:22.649333
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    # create a mock module
    module = MockModule()

    # create a mock NetworkCollector
    network_collector = NetworkCollector(module=module)

    # create a mock AIXNetwork
    aix_network = AIXNetwork(module=module, network_collector=network_collector)

    # create a mock GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:35:34.279301
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-17 00:35:43.094279
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacy
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacyCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoifaddrs
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoifaddrsCollect

# Generated at 2022-06-17 00:35:54.060795
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    # pylint: disable=attribute-defined-outside-init
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-instance

# Generated at 2022-06-17 00:35:57.324441
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_interfaces_info()



# Generated at 2022-06-17 00:36:03.287420
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    collector = AIXNetworkCollector(None, None, None, None)
    assert collector
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-17 00:36:10.006221
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4, v6 = network.get_default_interfaces('/sbin/route')
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-17 00:36:16.127108
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:36:21.425496
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:36:29.084457
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces is required for this module')

    if not HAS_PYTHON_NETIFACES:
        module.fail_json(msg='python-netifaces is required for this module')

    if not HAS_NETADDR:
        module.fail_json(msg='netaddr is required for this module')

    if not HAS_PYTHON_NETADDR:
        module.fail_json(msg='python-netaddr is required for this module')


# Generated at 2022-06-17 00:37:20.587602
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:24.486565
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:37:35.615351
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AI

# Generated at 2022-06-17 00:37:47.126564
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # create a test class
    class TestAIXNetwork(AIXNetwork):
        def __init__(self, module):
            self.module = module

    # create a test class
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            self.module = module

    # create a test class

# Generated at 2022-06-17 00:37:59.030579
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import json
    import sys
    import tempfile
    import unittest
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if cmd[0] == '/usr/bin/uname':
                return 0, '0', ''
            if cmd[0] == '/usr/sbin/ifconfig':
                return 0, self.params['ifconfig_out'], ''

# Generated at 2022-06-17 00:38:09.093786
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UGS 0 0 en0\ndefault ::1 UH lo0\n', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == '::1'
    assert network_collector.interfaces['v6']['interface'] == 'lo0'

#

# Generated at 2022-06-17 00:38:19.277892
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:38:23.368270
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:38:25.594480
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:34.023237
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    network = AIXNetwork(module)
    network.get_interfaces_info('/usr/sbin/ifconfig')
    module.run_command.assert_called_once_with(['/usr/sbin/ifconfig', '-a'])
    module.get_bin_path.assert_called_once_with('uname')

# Generated at 2022-06-17 00:40:26.554641
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')
    aix_network = AIXNetwork(module)
    v4, v6 = aix_network.get_default_interfaces(route_path)
    assert v4['gateway'] == '172.17.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1%en0'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-17 00:40:32.641755
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # test with no route_path
    interface = network.get_default_interfaces(None)
    assert interface == ({}, {})

    # test with route_path
    interface = network.get_default_interfaces('/usr/sbin/route')
    assert interface == ({}, {})



# Generated at 2022-06-17 00:40:41.370304
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:40:44.850313
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:55.298527
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin

# Generated at 2022-06-17 00:41:04.207718
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is used to test the constructor of the class AIXNetworkCollector.
    """
    # Test with no argument
    test_obj = AIXNetworkCollector()
    assert test_obj._fact_class == AIXNetwork
    assert test_obj._platform == 'AIX'
    assert test_obj._network_class == AIXNetwork
    assert test_obj._fallback_class == GenericBsdIfconfigNetwork
    assert test_obj._fallback_platform == 'Generic_BSD_ifconfig'
    assert test_obj._fallback_network_class == GenericBsdIfconfigNetwork
    assert test_obj._fallback_network_platform == 'Generic_BSD_ifconfig'
    assert test_obj._fallback_network_class == GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:41:11.237747
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.0.0.1'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::21e:c9ff:fe3d:6c3a'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:41:21.538960
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector

    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/sbin/ifconfig',
    })()

    # Create a mock module
    module_un

# Generated at 2022-06-17 00:41:25.225259
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:41:28.166651
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
