

# Generated at 2022-06-17 00:32:43.309738
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:53.143556
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.2.2'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:33:03.860262
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-17 00:33:15.603040
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:17.943411
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:33:23.748781
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:33:33.886093
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # Create a route_path
    route_path = '/usr/sbin/route'

    # Call the method get_default_interfaces
    v4_default, v6_default = aix_network.get_default_interfaces(route_path)

    # Assert the result
    assert v4_default == {'gateway': '10.0.0.1', 'interface': 'en0'}

# Generated at 2022-06-17 00:33:36.759074
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:40.799082
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:33:48.365336
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::1'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:34:01.873366
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:06.721957
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:09.224706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:34:20.980540
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    import os
    import sys
    import unittest

    class MockModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-17 00:34:26.273247
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path=None)

# Generated at 2022-06-17 00:34:28.576292
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:31.995889
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:36.938858
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # test with a valid route file
    route_path = '/etc/route'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '10.0.0.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::1'
    assert interface['v6']['interface'] == 'en0'

    # test with a non-existing route file
    route_path = '/etc/route_does_not_exist'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4'] == {}
    assert interface['v6']

# Generated at 2022-06-17 00:34:39.103342
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:49.079062
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/ifconfig')
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_interfaces_info()
    assert network_collector.interfaces == {}
    assert network_collector.all_ipv4_addresses == []
    assert network_collector.all_ipv6_addresses == []


# Generated at 2022-06-17 00:35:15.898807
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:35:18.037763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:28.624039
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # test with aix 7.2

# Generated at 2022-06-17 00:35:36.333653
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network.get_default_interfaces('/usr/sbin/netstat') == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:35:44.698618
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # test with ifconfig -a output
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])
    interfaces, ips = AIXNetwork(module).get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-17 00:35:52.446758
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDIfconfigNetwork
    from ansible.module_utils.facts.network.dragonfly import DragonflyBSDIfconfigNetwork

# Generated at 2022-06-17 00:35:56.985946
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    aix_network_collector = AIXNetworkCollector(None)
    assert aix_network_collector
    assert aix_network_collector._fact_class == AIXNetwork
    assert aix_network_collector._platform == 'AIX'

# Generated at 2022-06-17 00:36:09.171684
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork

# Generated at 2022-06-17 00:36:19.869711
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector

# Generated at 2022-06-17 00:36:29.590762
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network_collector = AIXNetwork(module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['type']

# Generated at 2022-06-17 00:37:18.204738
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network.get_default_interfaces('/usr/sbin/route') == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:37:22.355351
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    network_collector = AIXNetworkCollector(None, None, None, None)
    assert network_collector
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-17 00:37:29.828238
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4, v6 = network.get_default_interfaces('/sbin/route')
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1%en0'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-17 00:37:31.691834
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:35.143033
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:37.930411
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:48.051186
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/netstat')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == 'fe80::21e:c9ff:fe7d:f8b0'
    assert network_collector.interfaces['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:37:58.946826
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    module.params['gather_timeout'] = 10
    module.params['filter'] = '*'

    # Create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # Create a AIXNetworkCollector object
    aix_network_collector = AIXNetworkCollector(module=module, facts=aix_network)

    # Create a route_path
    route_path = '/usr/sbin/route'

    # Call method get_default_interfaces of class AIXNetwork
    default_interfaces = aix_network.get_default_interfaces(route_path)

# Generated at 2022-06-17 00:38:06.942087
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    net = AIXNetwork(module)
    assert net.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': '::1', 'interface': 'lo0'})


# Generated at 2022-06-17 00:38:10.400812
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:39:59.146750
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:09.863739
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-17 00:40:12.179759
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:18.868947
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'route_path': {'type': 'str', 'required': True}})
    net = AIXNetwork(module)
    assert net.get_default_interfaces(module.params['route_path']) == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:40:22.149317
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:40:25.262555
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:36.198908
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))

    # create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # create a file with the ifconfig output
    f = open('/tmp/ifconfig_aix.txt', 'w')

# Generated at 2022-06-17 00:40:38.422702
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:42.141634
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    network_collector.get_default_interfaces('/sbin/route')



# Generated at 2022-06-17 00:40:50.413413
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_interfaces_info()
    assert network_collector.interfaces['lo0']['device'] == 'lo0'
    assert network_collector.interfaces['lo0']['type'] == 'loopback'
    assert network_collector.interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert network_collector.interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert network_collector.interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'