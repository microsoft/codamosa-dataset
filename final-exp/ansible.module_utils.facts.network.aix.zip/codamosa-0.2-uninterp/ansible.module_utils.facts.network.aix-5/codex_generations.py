

# Generated at 2022-06-17 00:32:46.880298
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/bin/netstat'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '10.0.0.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::1'
    assert interface['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:32:51.956578
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:32:54.466593
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:56.694483
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:07.381986
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'en0' in interfaces
    assert 'en0' in ips['all_ipv4_addresses']
    assert 'en0' in ips['all_ipv6_addresses']
    assert 'en1' in interfaces

# Generated at 2022-06-17 00:33:18.070411
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParser
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParserError
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParserWarning
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkPlatform

# Generated at 2022-06-17 00:33:24.032560
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:33:34.073769
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:36.586642
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:33:40.658113
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:34:03.368609
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['ipv4'][0]['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:34:05.053694
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:17.022334
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:19.340671
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:22.191161
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:30.249595
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    default_interfaces = network.get_default_interfaces('/usr/sbin/route')
    assert default_interfaces == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::21e:c9ff:fea6:c1d0%en0', 'interface': 'en0'})


# Generated at 2022-06-17 00:34:37.456640
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['mtu'] == '65536'
    assert interfaces['lo0']['macaddress'] == 'unknown'

# Generated at 2022-06-17 00:34:42.571202
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:51.802058
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector.
    It tests the creation of an object of the AIXNetworkCollector class.
    """
    # create an object of the AIXNetworkCollector class
    aix_network_collector_object = AIXNetworkCollector()
    # check if the object is an object of the AIXNetworkCollector class
    assert isinstance(aix_network_collector_object, AIXNetworkCollector)
    # check if the object is an object of the NetworkCollector class
    assert isinstance(aix_network_collector_object, NetworkCollector)


# Generated at 2022-06-17 00:34:54.962256
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:35:22.510605
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None, None, None)

# Generated at 2022-06-17 00:35:28.809758
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:35:40.884162
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # Create a class object
    aix_network = AIXNetwork()

    # Create a test string

# Generated at 2022-06-17 00:35:46.649718
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:35:51.889680
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = MockModule()
    net.module.run_command = Mock(return_value=(0, 'default 192.168.1.1 UG 1 0 en0\ndefault ::1 UG 1 0 lo0', ''))
    assert net.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': '::1', 'interface': 'lo0'})


# Generated at 2022-06-17 00:35:55.595693
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:08.000429
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['macaddress'] == '00:1a:a0:16:01:c0'
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-17 00:36:18.542871
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    network = AIXNetwork(module)
    default_gateways = network.get_default_interfaces('/usr/sbin/netstat')
    assert default_gateways['default_gateway_ipv4'] == '10.0.0.1'
    assert default_gateways['default_gateway_ipv6'] == 'fe80::1'
    assert default_gateways['default_gateway_interface_ipv4'] == 'en0'
    assert default_gateways['default_gateway_interface_ipv6'] == 'en0'



# Generated at 2022-06-17 00:36:27.746923
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:36:31.548899
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:37:26.286441
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:28.311614
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:30.204414
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:34.679705
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/bin/netstat'
    interface = network.get_default_interfaces(route_path)
    assert interface == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:37:46.255439
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == '::1'

# Generated at 2022-06-17 00:37:51.543213
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector.
    It tests the creation of an object of the AIXNetworkCollector class.
    """
    # Create an object of the AIXNetworkCollector class
    aix_network_collector_object = AIXNetworkCollector()

    # Check if the object is an object of the AIXNetworkCollector class
    assert isinstance(aix_network_collector_object, AIXNetworkCollector)


# Generated at 2022-06-17 00:38:01.876933
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert 'default_gateway' in facts['ansible_default_ipv4']
    assert 'default_gateway' in facts['ansible_default_ipv6']
    assert 'interface' in facts['ansible_default_ipv4']
    assert 'interface' in facts['ansible_default_ipv6']


# Generated at 2022-06-17 00:38:03.481347
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:11.559854
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '10.0.0.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == 'fe80::21a:92ff:fe0e:c9a0'
    assert network_collector.interfaces['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:38:18.690357
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:40:11.141876
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4, v6 = network.get_default_interfaces('/sbin/route')
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::1'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-17 00:40:14.240841
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:16.550424
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:25.654712
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork

# Generated at 2022-06-17 00:40:36.897459
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # create a test object
    test_obj = AIXNetwork()

    # create a test string

# Generated at 2022-06-17 00:40:39.116054
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    net = AIXNetwork(module)
    net.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:40:40.478703
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:40:43.419934
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:40:46.531875
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:56.630540
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-boolean-expressions

    # create a class object
    aix_network = AIXNetwork()

    # create a test object
    test_object = dict()
    test_object['module'] = dict()
    test_object['module']['run_command'] = dict()