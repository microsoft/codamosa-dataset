

# Generated at 2022-06-17 00:32:54.081154
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create a mock module
    module = MockModule()

    # create a mock ifconfig output

# Generated at 2022-06-17 00:32:59.960968
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:33:09.017171
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create a mock module

# Generated at 2022-06-17 00:33:10.945137
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None, None, None)

# Generated at 2022-06-17 00:33:19.053816
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:23.265313
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:26.903937
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:35.347733
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.freebsd import FreeBsdIfconfigNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBsdNetworkCollector

# Generated at 2022-06-17 00:33:43.579629
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is used to test the constructor of class AIXNetworkCollector
    """
    # Create an instance of class AIXNetworkCollector
    aix_network_collector = AIXNetworkCollector()
    # Check if the instance is created successfully
    assert aix_network_collector is not None
    # Check the value of attribute _fact_class
    assert aix_network_collector._fact_class == AIXNetwork
    # Check the value of attribute _platform
    assert aix_network_collector._platform == 'AIX'


# Generated at 2022-06-17 00:33:51.992598
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = AIXNetwork(module)
    route_path = module.get_bin_path('netstat')
    interface = network.get_default_interfaces(route_path)
    assert interface == {'gateway': '172.16.1.1', 'interface': 'en0'}


# Generated at 2022-06-17 00:34:08.357672
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:34:20.235110
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:23.225114
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:30.857770
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4_interface, v6_interface = network.get_default_interfaces('/usr/sbin/route')
    assert v4_interface['gateway'] == '10.0.0.1'
    assert v4_interface['interface'] == 'en0'
    assert v6_interface['gateway'] == 'fe80::1'
    assert v6_interface['interface'] == 'en0'


# Generated at 2022-06-17 00:34:41.643552
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This is a unit test for method get_interfaces_info of class AIXNetwork.
    """
    # Create a test object of class AIXNetwork
    test_obj = AIXNetwork()

    # Create a test string for ifconfig_path
    ifconfig_path = '/usr/sbin/ifconfig'

    # Create a test string for ifconfig_options
    ifconfig_options = '-a'

    # Call method get_interfaces_info of class AIXNetwork
    result = test_obj.get_interfaces_info(ifconfig_path, ifconfig_options)

    # Check result
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)

# Generated at 2022-06-17 00:34:46.087687
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:34:55.947623
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='')
    module.params = {}
    module.params['gather_subset'] = ['!all']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources']

# Generated at 2022-06-17 00:34:58.797623
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None, None, None)

# Generated at 2022-06-17 00:35:09.885192
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 00:35:20.714619
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacy
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacyCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoIfconfig
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNoIfconfigCollector


# Generated at 2022-06-17 00:35:46.542165
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:53.021480
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert network_facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_facts['default_ipv4']['interface'] == 'en0'
    assert network_facts['default_ipv6']['gateway'] == 'fe80::1'
    assert network_facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:36:05.922236
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    class ModuleStub:
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_network_resources'] = ['all']

# Generated at 2022-06-17 00:36:16.890621
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # Test with a real AIX system
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    aix_network = AIXNetwork()
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-17 00:36:20.848145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:24.712792
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    collector = AIXNetworkCollector(None, None, None, None)
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-17 00:36:32.001076
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/ifconfig')
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info('/usr/sbin/ifconfig')
    assert interfaces['en0']['macaddress'] == 'unknown'
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']

# Generated at 2022-06-17 00:36:33.895540
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:43.778656
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Test data

# Generated at 2022-06-17 00:36:45.542620
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:40.916641
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetwork(module)
    interfaces, ips = network_collector.get_interfaces_info('/usr/sbin/ifconfig')
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['ipv4'][0]['address'] == '10.0.2.15'
    assert interfaces['en0']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert interfaces['en0']['ipv4'][0]['broadcast'] == '10.0.2.255'
    assert interfaces['en0']['ipv4'][0]['network']

# Generated at 2022-06-17 00:37:44.779535
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/netstat')



# Generated at 2022-06-17 00:37:50.074273
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.run_command = run_command
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    interface = network.get_default_interfaces(route_path)
    assert interface == {'gateway': '10.0.0.1', 'interface': 'en0'}



# Generated at 2022-06-17 00:37:59.560363
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault fe80::%en0 UG 0 0 en0', ''))
    network_collector = AIXNetwork(module)
    v4, v6 = network_collector.get_default_interfaces('/sbin/route')
    assert v4 == {'gateway': '192.168.1.1', 'interface': 'en0'}
    assert v6 == {'gateway': 'fe80::%en0', 'interface': 'en0'}


# Generated at 2022-06-17 00:38:03.763952
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:38:06.440276
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:17.612253
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['macaddress'] == 'unknown'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['ipv4'][0]['address'] == '10.0.0.1'
    assert interfaces['en0']['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:38:28.367857
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector

    # create a class instance
    aix_network = AIXNetwork()

    # create a class instance of parent class
    generic_bsd_network = GenericBsdNetwork()

    # create a class instance of grandparent class
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # create a class instance of great-grandparent class
    generic_bsd_network_collector = GenericBsdNetworkCollector()

    #

# Generated at 2022-06-17 00:38:33.181818
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:38:35.821510
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:34.613794
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollect

# Generated at 2022-06-17 00:40:44.594050
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock ifconfig command output
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:40:46.994897
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:40:49.465511
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()


# Generated at 2022-06-17 00:40:51.831763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:00.705446
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:41:04.392875
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:41:15.377713
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Create a fake module
    set_module_args(dict(gather_subset=['network']))
    network_facts = AIXNetwork()
    network_facts.get_default_interfaces('/usr/bin/netstat')
    result = network_facts.get_facts()
    assert result['default_ipv4']['gateway'] == '192.168.1.1'
    assert result['default_ipv4']['interface'] == 'en0'
    assert result['default_ipv6']['gateway'] == 'fe80::1'

# Generated at 2022-06-17 00:41:16.948070
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:25.407744
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'