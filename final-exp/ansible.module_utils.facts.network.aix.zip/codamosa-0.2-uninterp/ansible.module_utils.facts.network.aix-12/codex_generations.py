

# Generated at 2022-06-17 00:32:48.357467
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    v4_interface, v6_interface = network.get_default_interfaces(route_path)
    assert v4_interface['gateway'] == '10.0.2.2'
    assert v4_interface['interface'] == 'en0'
    assert v6_interface['gateway'] == 'fe80::a00:27ff:fea9:c8d8'
    assert v6_interface['interface'] == 'en0'


# Generated at 2022-06-17 00:32:59.567979
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:02.284994
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:05.712226
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:33:08.018268
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:15.483180
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 172.16.0.1 UG 0 0 en0', ''))
    network_collector = AIXNetwork(module)
    default_interfaces = network_collector.get_default_interfaces('/sbin/route')
    assert default_interfaces == ({'gateway': '172.16.0.1', 'interface': 'en0'}, {})


# Generated at 2022-06-17 00:33:26.501584
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 00:33:28.555318
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:38.031606
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    # Create a class object of class AIXNetwork
    aix_network = AIXNetwork()

    # Create a class object of class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # Create a class object of class NetworkCollector
    network_collector = NetworkCollector()

    # Get the path of ifconfig
    ifconfig_path = network_collector.module.get_bin_path('ifconfig')

    # Get the path of uname
    uname_path = network_collector.module.get

# Generated at 2022-06-17 00:33:45.687104
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = module.get_bin_path('route')
    assert network.get_default_interfaces(route_path) == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::21e:c9ff:fea5:e8a0', 'interface': 'en0'})


# Generated at 2022-06-17 00:34:07.118837
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # create a fake module
    module = AnsibleModule(argument_spec={})

    # create a fake ifconfig output
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:19.597740
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    network = AIXNetwork(module)
    network.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-17 00:34:25.701186
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-17 00:34:33.943292
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

# Generated at 2022-06-17 00:34:37.510443
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:39.180179
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:51.095736
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkInterface
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkInterfaceCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParser

# Generated at 2022-06-17 00:35:02.725447
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    # create a test instance of AIXNetwork
    aix_network = AIXNetwork()

    # create a test instance of AIXNetworkCollector
    aix_network_collector = AIXNetworkCollector()

    # create a test instance of GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # create a

# Generated at 2022-06-17 00:35:12.050217
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_responses = []

        def get_bin_path(self, arg):
            return '/usr/bin/' + arg

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_responses.pop(0)

    class MockNetwork(AIXNetwork):
        def __init__(self, module):
            self.module = module

    module = MockModule()

# Generated at 2022-06-17 00:35:16.723347
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:44.678988
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:55.417626
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=too-many-lines

    # Create a class object
    aix_network = AIXNetwork()

    # Create

# Generated at 2022-06-17 00:36:01.916830
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interface = network.get_default_interfaces('/sbin/route')
    assert interface == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:36:05.916430
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-17 00:36:08.196917
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:18.754434
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces is required for this module')

    if not HAS_PYTHON_NETIFACES:
        module.fail_json(msg='python-netifaces is required for this module')

    # create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # get the interfaces_info
    interfaces_info = aix_network.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

    # get the interfaces
    interfaces = interfaces_info[0]

    # get

# Generated at 2022-06-17 00:36:22.465231
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function is used to test the constructor of class AIXNetworkCollector
    """
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-17 00:36:24.747184
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:32.034243
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network

# Generated at 2022-06-17 00:36:41.378850
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.0.0.1'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::21e:67ff:fe0a:a0d1'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:37:39.624200
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:37:42.047473
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:51.417828
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a AIXNetwork object
    obj = AIXNetwork(module)

    # Create a AIXNetwork object
    obj = AIXNetwork(module)

    # Get the interfaces_info
    interfaces_info = obj.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

    # Check if the interfaces_info is a dictionary
    assert isinstance(interfaces_info, dict)

    # Check if the interfaces_info has the following keys
    assert 'interfaces' in interfaces_info
    assert 'all_ipv4_addresses' in interfaces_info
    assert 'all_ipv6_addresses' in interfaces_info

    # Check if the interfaces_info['interfaces'] is

# Generated at 2022-06-17 00:37:59.120931
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:38:09.122670
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
   

# Generated at 2022-06-17 00:38:18.537021
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_get_interfaces_info as test_get_interfaces_info

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:38:20.722808
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:27.395830
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and _platform to 'AIX'.
    """
    aix_network_collector = AIXNetworkCollector(None, None, None)
    assert aix_network_collector
    assert aix_network_collector._fact_class == AIXNetwork
    assert aix_network_collector._platform == 'AIX'

# Generated at 2022-06-17 00:38:31.388509
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:40.885401
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

# Generated at 2022-06-17 00:40:42.736472
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    import os
    import sys
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = sys.exit
            self.fail_json = sys.exit


# Generated at 2022-06-17 00:40:46.685191
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:40:56.746003
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollect

# Generated at 2022-06-17 00:40:59.430689
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:41:04.831737
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class.
    """
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector._platform == 'AIX'
    assert aix_network_collector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:07.011507
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:13.359394
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/bin/netstat'
    interfaces = network.get_default_interfaces(route_path)
    assert interfaces == {'v4': {'gateway': '10.0.0.1', 'interface': 'en0'}, 'v6': {'gateway': 'fe80::21a:4aff:fe2a:c9b', 'interface': 'en0'}}


# Generated at 2022-06-17 00:41:16.242355
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:17.437500
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()

# Generated at 2022-06-17 00:41:24.779591
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'