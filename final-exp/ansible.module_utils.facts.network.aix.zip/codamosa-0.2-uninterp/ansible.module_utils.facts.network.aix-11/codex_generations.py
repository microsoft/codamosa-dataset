

# Generated at 2022-06-17 00:32:41.553354
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:32:52.984032
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class AIXNetworkCollector(NetworkCollector):
        _fact_class = AIXNetwork
        _platform = 'AIX'

    class AIXNetwork(GenericBsdIfconfigNetwork):
        platform = 'AIX'

    def get_default_interfaces(self, route_path):
        interface = dict(v4={}, v6={})

        netstat_path = self.module.get_bin_path('netstat')


# Generated at 2022-06-17 00:33:00.573951
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network.get_default_interfaces(None) == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:33:09.076208
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!all', 'network']
    module.params['gather_network_resources'] = ['default_ipv4', 'default_ipv6']
    module.params['gather_timeout'] = 10
    module.params['filter'] = 'en*'
    module.params['config'] = '/etc/ansible/facts.d/network.fact'
    module.params['fact_path'] = '/etc/ansible/facts.d'
    module.params['fact_basename'] = 'network.fact'
    module.params['_ansible_check_mode'] = True
    module.params['_ansible_debug'] = True
    module.params['_ansible_diff'] = True

# Generated at 2022-06-17 00:33:15.093646
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create a mock module
    module = NetworkCollector()

    # create a mock ifconfig_path
    ifconfig_path = '/usr/sbin/ifconfig'

    # create a mock ifconfig_options
    ifconfig_options = '-a'

    # create a mock interfaces
    interfaces = {}

    # create a mock current_if
    current_if = {}

    # create a mock ips

# Generated at 2022-06-17 00:33:17.407437
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')



# Generated at 2022-06-17 00:33:18.464166
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:23.180103
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:33.373954
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:33:44.695481
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces is required for this module')

    if not HAS_NETADDR:
        module.fail_json(msg='netaddr is required for this module')

    if not HAS_NETSTAT:
        module.fail_json(msg='netstat is required for this module')

    if not HAS_UNAME:
        module.fail_json(msg='uname is required for this module')

    if not HAS_LSATTR:
        module.fail_json(msg='lsattr is required for this module')


# Generated at 2022-06-17 00:34:05.676754
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module=module)
    ifconfig_path = network.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces
    assert 'en0' in ips['all_ipv4_addresses']
    assert 'en0' in ips['all_ipv6_addresses']
    assert 'en1' in interfaces
    assert 'en1' in ips['all_ipv4_addresses']
    assert 'en1' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces

# Generated at 2022-06-17 00:34:14.655179
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '192.168.1.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::1%en0'
    assert interface['v6']['interface'] == 'en0'

# Generated at 2022-06-17 00:34:25.579901
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, executable, required=False):
            return executable

        def run_command(self, args, check_rc=True):
            if args[0] == 'ifconfig':
                return 0, open(os.path.join(self.params['test_dir'], 'ifconfig.out')).read(), ''
            elif args[0] == 'netstat':
                return 0, open(os.path.join(self.params['test_dir'], 'netstat.out')).read(), ''
            elif args[0] == 'uname':
                return 0,

# Generated at 2022-06-17 00:34:27.977773
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:32.385256
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:41.847376
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/netstat')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::21e:c9ff:fe8f:a8e0'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:34:53.063788
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['/usr/sbin/route', '-nr']

# Generated at 2022-06-17 00:34:58.090362
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:35:02.226256
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:35:06.177870
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:35:40.805315
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:35:44.302774
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()


# Generated at 2022-06-17 00:35:48.830753
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:35:57.810006
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDNetwork

# Generated at 2022-06-17 00:36:09.961486
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_get_default_interfaces
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_parse_interface_line
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_parse_options_line
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_parse_nd6_line

# Generated at 2022-06-17 00:36:16.426119
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    # Create a class object
    an = AIXNetwork()

    # Create a dictionary with the output of the command 'ifconfig -a'

# Generated at 2022-06-17 00:36:27.582038
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import NetworkConfig
    from ansible.module_utils.facts.network.generic_bsd import NetworkParams
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaces
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfacesInfo
    from ansible.module_utils.facts.network.generic_bsd import NetworkIPs
    from ansible.module_utils.facts.network.generic_bsd import NetworkIP

# Generated at 2022-06-17 00:36:32.088066
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:43.729526
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # create a test object
    test_obj = AIXNetwork()

    # create a test string

# Generated at 2022-06-17 00:36:45.504110
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:35.369893
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:46.927410
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:37:56.772980
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.0.2.2'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:38:00.475929
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:38:11.358898
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This is a test for method get_interfaces_info of class AIXNetwork.
    """

    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:38:20.643458
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # test with ifconfig_path = /usr/sbin/ifconfig
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert len(interfaces) == 4
    assert len(ips['all_ipv4_addresses']) == 2
    assert len(ips['all_ipv6_addresses']) == 2
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-17 00:38:23.573662
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:27.556367
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-17 00:38:30.542786
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:34.358882
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:24.233548
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # create a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, arg):
            return arg

    # create a fake module
    fake_module = FakeModule()

    # create a fake class

# Generated at 2022-06-17 00:40:27.516101
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:38.233756
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:40:48.904064
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    net = AIXNetwork(module)
    net.get_interfaces_info(ifconfig_path='ifconfig', ifconfig_options='-a')

# Generated at 2022-06-17 00:40:52.417538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:41:00.765130
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == '::1'
    assert network_collector.interfaces['v6']['interface'] == 'lo0'



# Generated at 2022-06-17 00:41:04.491103
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:41:15.378522
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 00:41:22.664611
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data
    # ifconfig -a output

# Generated at 2022-06-17 00:41:34.143487
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None