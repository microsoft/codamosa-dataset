

# Generated at 2022-06-17 00:32:54.295789
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # Create a route_path
    route_path = '/usr/sbin/route'

    # Call method get_default_interfaces
    v4, v6 = aix_network.get_default_interfaces(route_path)

    # Assertions
    assert v4['gateway'] == '10.0.0.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::21c:42ff:fea9:b9c0'
    assert v6['interface'] == 'en0'



# Generated at 2022-06-17 00:32:56.144723
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()

# Generated at 2022-06-17 00:33:06.053440
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::1'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:33:16.924306
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_NETIFACES:
        module.fail_json(msg="the python netifaces module is required")

    if not HAS_NETADDR:
        module.fail_json(msg="the python netaddr module is required")

    if not HAS_IPADDR:
        module.fail_json(msg="the python ipaddr module is required")

    if not HAS_IFADMIN:
        module.fail_json(msg="the python ifadmin module is required")

    if not HAS_IFPARSER:
        module.fail_json(msg="the python ifparser module is required")


# Generated at 2022-06-17 00:33:18.546536
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:23.180992
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:26.422458
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:35.114959
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command not found')
    ifconfig_path = module.get_bin_path('ifconfig')
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command not found')
    aix_network = AIXNetwork(module)
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-17 00:33:43.868185
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    default_interfaces = network.get_default_interfaces('/usr/sbin/netstat')
    assert default_interfaces[0]['interface'] == 'en0'
    assert default_interfaces[0]['gateway'] == '10.0.0.1'
    assert default_interfaces[1]['interface'] == 'en0'
    assert default_interfaces[1]['gateway'] == 'fe80::21e:67ff:fe1a:f8e0'


# Generated at 2022-06-17 00:33:54.752926
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:18.963906
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:34:21.875347
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:26.182497
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:29.233259
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:34:32.483485
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-17 00:34:36.846170
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module)
    assert network.get_default_interfaces('/sbin/route') == ({'gateway': '10.0.0.1', 'interface': 'en0'},
                                                             {'gateway': 'fe80::1', 'interface': 'en0'})



# Generated at 2022-06-17 00:34:38.848347
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:43.883949
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = module.get_bin_path('netstat')
    interface = network.get_default_interfaces(route_path)
    assert interface == ({}, {})



# Generated at 2022-06-17 00:34:45.179458
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:54.911439
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-17 00:35:23.315570
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:34.313329
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Create a test object
    aix_network = AIXNetwork()

    # Create a test object of class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # Get the test data
    test_data = generic_bsd_ifconfig_network.get_test_data()

    # Get the test data for AIX
    test_data_aix = aix_network.get_test_data()

    # Get the interfaces info

# Generated at 2022-06-17 00:35:43.080869
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:35:52.185559
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault fe80::%en0 U 0 0 en0', ''))
    aix_network = AIXNetwork(module)
    assert aix_network.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::%en0', 'interface': 'en0'})


# Generated at 2022-06-17 00:36:05.704810
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 1 0 en0\ndefault ::1 UG 1 0 lo0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == '::1'
    assert network_collector.interfaces['v6']['interface'] == 'lo0'


#

# Generated at 2022-06-17 00:36:09.487626
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-17 00:36:19.369032
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:36:28.150178
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkPlatform
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkRaw
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkUnix
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkUnixLike

# Generated at 2022-06-17 00:36:32.168145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:43.572297
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.freebsd import FreeBSDIfconfigNetwork
    from ansible.module_utils.facts.network.hpux import HPUXNetwork

# Generated at 2022-06-17 00:37:44.110322
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    network_collector = AIXNetworkCollector(module)
    network_collector.get_interfaces_info(ifconfig_path, ifconfig_options)
    interfaces = network_collector.interfaces
    ips = network_collector.ips
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']

# Generated at 2022-06-17 00:37:51.682867
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    network_collector = AIXNetwork(module)
    assert network_collector.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': '::1', 'interface': 'lo0'})


# Generated at 2022-06-17 00:37:54.262122
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:57.675531
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:01.854399
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:05.809760
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:38:08.904372
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:38:19.103665
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network = AIXNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['en0']['mtu'] == '1500'


# Generated at 2022-06-17 00:38:30.263270
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert network_collector.interfaces['lo0']['device'] == 'lo0'
    assert network_collector.interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert network_collector.interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 00:38:34.321544
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:26.531785
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:40:30.793823
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:40:32.651251
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:35.027841
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:39.190363
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:40:44.064311
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    interface = network.get_default_interfaces(route_path)
    assert interface == ({'gateway': '172.17.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:40:50.531477
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

# Generated at 2022-06-17 00:40:55.515933
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/netstat')



# Generated at 2022-06-17 00:40:57.939360
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:41:04.009382
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake file in the temporary directory
    tmpdir = tempfile.mkdtemp()
    route_path = os.path.join(tmpdir, 'netstat')
    with open(route_path, 'w') as f:
        f.write("""
default 192.168.1.1 UG 1 0 en0
default fe80::%utun0 UG 1 0 utun0
default fe80::%utun1 UG 1 0 utun1
""")

    # Create an instance of AIXNetwork
    network_collector = AIXNetwork(module)

    # Call the method get_default_interfaces
    interface = network_collector.get_default_interfaces(route_path)

    #