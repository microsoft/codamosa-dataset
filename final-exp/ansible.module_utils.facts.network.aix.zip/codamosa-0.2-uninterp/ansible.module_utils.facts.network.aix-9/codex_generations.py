

# Generated at 2022-06-17 00:32:47.811863
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.0.2.2'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:32:51.129036
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:00.929252
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 00:33:09.075451
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault ::1 UG 0 0 lo0', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    aix_network = AIXNetwork(module)
    v4, v6 = aix_network.get_default_interfaces('/usr/bin/netstat')
    assert v4 == {'gateway': '192.168.1.1', 'interface': 'en0'}
    assert v6 == {'gateway': '::1', 'interface': 'lo0'}


# Generated at 2022-06-17 00:33:11.422845
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor test of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:14.418140
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:33:17.236446
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:23.460295
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    # create a mock module
    module = MockModule()

    # create a mock ifconfig output
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:33.651026
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # Test with netstat -nr
    route_path = '/usr/sbin/netstat'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '10.0.2.2'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert interface['v6']['interface'] == 'en0'

    # Test with no netstat -nr
    route_path = '/usr/sbin/netstat_not_exist'
    interface = network.get_default_interfaces(route_path)
    assert interface

# Generated at 2022-06-17 00:33:44.948986
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:00.495701
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-17 00:34:07.417975
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:19.597316
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    module.params['gather_timeout'] = 10
    module.params['filter'] = ''
    module.params['config'] = ''
    module.params['persistent_connection'] = ''
    module.params['network_debug'] = False
    module.params['network_ignore_errors'] = False
    module.params['network_gather_timeout'] = 10
    module.params['network_gather_subset'] = ['!all', '!min']
    module.params['network_group_commands'] = False
    module.params['network_group_command_pattern'] = ''
    module.params

# Generated at 2022-06-17 00:34:31.856331
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollect

# Generated at 2022-06-17 00:34:33.168787
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:36.387254
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')



# Generated at 2022-06-17 00:34:44.290540
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            return self.bin_path[name]

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err

    class MockNetwork(AIXNetwork):
        def __init__(self, module):
            self.module = module

    bin_path = dict(
        ifconfig='/usr/sbin/ifconfig',
        netstat='/usr/bin/netstat',
        uname='/usr/bin/uname',
        entstat='/usr/bin/entstat',
        lsattr='/usr/bin/lsattr',
    )



# Generated at 2022-06-17 00:34:54.140599
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:34:58.951503
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 00:35:03.054556
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/netstat')


# Generated at 2022-06-17 00:35:28.769555
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:38.537530
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/bin/netstat'
    interface = network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '192.168.1.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::21f:5bff:fea6:c1f0'
    assert interface['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:35:44.726695
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 172.16.1.1 UG 0 0 en0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.default_interface['v4']['gateway'] == '172.16.1.1'
    assert network_collector.default_interface['v4']['interface'] == 'en0'


# Generated at 2022-06-17 00:35:52.446448
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of the AIXNetworkCollector class.
    """
    # Test with no argument
    collector = AIXNetworkCollector()
    assert collector
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork
    assert collector.fact_class._platform == 'AIX'
    assert collector.fact_class._fact_class == AIXNetwork
    assert collector.fact_class.platform == 'AIX'
    assert collector.fact_class.get_interfaces_info
    assert collector.fact_class.get_default_interfaces
    assert collector.fact_class.get_interfaces_info
    assert collector.fact_class.get_default_interfaces
    assert collector.fact_class.parse_interface_line
    assert collector.fact_class.parse_options_line
   

# Generated at 2022-06-17 00:36:05.704070
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:36:09.799193
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:36:18.029581
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module)
    route_path = '/usr/sbin/route'
    interface = network.get_default_interfaces(route_path)
    assert interface == ({'gateway': '10.0.2.2', 'interface': 'en0'}, {'gateway': 'fe80::a00:27ff:fe4b:8c4c', 'interface': 'en0'})

# Generated at 2022-06-17 00:36:28.358762
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector

    # Test data
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:36:37.360874
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:36:42.441540
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:37:36.668578
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 00:37:39.360988
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:41.761179
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:45.548782
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:37:48.194078
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces()

# Generated at 2022-06-17 00:37:57.464350
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert facts['default_ipv4']['interface'] == 'en0'
    assert facts['default_ipv6']['gateway'] == 'fe80::1'
    assert facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:38:00.951038
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/sbin/route')


# Generated at 2022-06-17 00:38:05.739273
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:38:10.448310
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')


# Generated at 2022-06-17 00:38:18.602772
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.bsd import BSDNetwork
    from ansible.module_utils.facts.network.bsd import BSDNetworkCollector

# Generated at 2022-06-17 00:40:09.990528
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

# Generated at 2022-06-17 00:40:12.284943
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:16.602749
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-17 00:40:25.680997
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    module.params['gather_timeout'] = 10
    module.params['filter'] = 'lo0'
    module.params['config'] = '/etc/ansible/facts.d/network.fact'
    module.params['fact_path'] = '/etc/ansible/facts.d'
    module.params['fact_basename'] = 'network'
    module.params['cache'] = '/tmp/ansible_network_resources.cache'
    module.params['timeout'] = 10
    module.params['verbosity'] = 0
    module.params['collect_timeout'] = 10

# Generated at 2022-06-17 00:40:36.932483
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 1 0 en0\ndefault :: UG 1 0 en0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')
    assert network_collector.default_interface['v4']['gateway'] == '192.168.1.1'
    assert network_collector.default_interface['v4']['interface'] == 'en0'
    assert network_collector.default_interface['v6']['gateway'] == '::'

# Generated at 2022-06-17 00:40:39.732858
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/route')



# Generated at 2022-06-17 00:40:45.724763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the AIXNetworkCollector class.
    """
    # Create a AIXNetworkCollector object
    collector = AIXNetworkCollector()

    # Check if the object is an instance of NetworkCollector
    assert isinstance(collector, NetworkCollector)

    # Check if the object is an instance of AIXNetworkCollector
    assert isinstance(collector, AIXNetworkCollector)

    # Check if the object is an instance of AIXNetwork
    assert isinstance(collector.get_facts(), AIXNetwork)

    # Check if the object is an instance of AIXNetwork
    assert isinstance(collector.get_network_facts(), AIXNetwork)

# Generated at 2022-06-17 00:40:52.668430
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacy
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkLegacyCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNew
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkNewCollector

# Generated at 2022-06-17 00:40:55.866618
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/usr/sbin/netstat')


# Generated at 2022-06-17 00:41:04.237566
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    import unittest

    class TestAIXNetwork(unittest.TestCase):

        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_file = os.path.join(self.test_dir, 'ifconfig_aix.txt')
            self.test_file_wpar = os.path.join(self.test_dir, 'ifconfig_aix_wpar.txt')

            self.test_file_fh = open(self.test_file, 'r')
            self.test_file_wpar_fh = open(self.test_file_wpar, 'r')

            self.test_file_content = self.test_file_fh.read()
           