

# Generated at 2022-06-17 00:32:49.468494
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    v4_interface, v6_interface = network.get_default_interfaces('/sbin/route')
    assert v4_interface['gateway'] == '10.0.0.1'
    assert v4_interface['interface'] == 'en0'
    assert v6_interface['gateway'] == 'fe80::21e:67ff:fe0a:f7d0'
    assert v6_interface['interface'] == 'en0'


# Generated at 2022-06-17 00:32:53.406209
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:32:56.993945
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interfaces = network.get_default_interfaces('/sbin/route')
    assert interfaces['v4']['gateway'] == '10.0.0.1'
    assert interfaces['v4']['interface'] == 'en0'
    assert interfaces['v6']['gateway'] == 'fe80::21e:c9ff:fe8f:7f1c'
    assert interfaces['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:33:04.364945
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.facts['default_ipv4']['gateway'] == '10.10.10.1'
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'
    assert network_collector.facts['default_ipv6']['gateway'] == 'fe80::21e:c9ff:fea3:f3e'
    assert network_collector.facts['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:33:15.997159
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UG 0 0 en0\ndefault :: UG 0 0 en0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '192.168.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'
    assert network_collector.interfaces['v6']['gateway'] == '::'

# Generated at 2022-06-17 00:33:22.625274
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-17 00:33:24.919292
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:28.672497
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    import os
    import sys
    import re
    import tempfile
    import shutil
    import pytest

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    # create temporary directory
    tmpdir = tempfile.mkdtemp()

    # create temporary file with ifconfig output
    ifconfig_file = os.path.join(tmpdir, 'ifconfig_aix')

# Generated at 2022-06-17 00:33:30.670560
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:32.773518
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:33:54.870584
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:33:59.213414
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:08.157393
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create a mock module
    module = MockModule()

    # create a mock ifconfig output

# Generated at 2022-06-17 00:34:20.035812
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['default_gateway']
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    facts = network_collector.get_facts()
    assert facts['default_gateway_ipv4']['interface'] == 'en0'
    assert facts['default_gateway_ipv4']['gateway'] == '10.0.0.1'
    assert facts['default_gateway_ipv6']['interface'] == 'en0'

# Generated at 2022-06-17 00:34:22.550075
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None, None, None)

# Generated at 2022-06-17 00:34:31.379823
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    interface = network.get_default_interfaces('/usr/sbin/route')
    assert interface['v4']['gateway'] == '172.16.1.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::21c:42ff:fea2:d8d2'
    assert interface['v6']['interface'] == 'en0'


# Generated at 2022-06-17 00:34:36.275069
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:38.003675
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:40.450920
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:34:43.717981
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:09.987555
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:17.897002
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector.
    It tests the creation of an object of the AIXNetworkCollector class.
    """
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    assert collector.__class__.__name__ == 'AIXNetworkCollector'
    assert collector._fact_class.__name__ == 'AIXNetwork'
    assert collector._platform == 'AIX'


# Generated at 2022-06-17 00:35:28.624737
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParser
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParserError
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParserUnknownLine
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkParserUnknownLineError

# Generated at 2022-06-17 00:35:40.842495
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Create a mock module
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork


# Generated at 2022-06-17 00:35:46.235530
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:35:48.485614
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:50.694919
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:54.337190
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:35:58.032643
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')


# Generated at 2022-06-17 00:36:10.131938
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-17 00:37:09.221799
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces(route_path='/usr/bin/netstat')
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ansible_facts']['default_ipv4']['gateway'] == '10.0.0.1'
    assert module.exit_json.call_args[0][0]['ansible_facts']['default_ipv4']['interface'] == 'en0'
    assert module.exit_json.call_args[0][0]['ansible_facts']['default_ipv6']['gateway'] == 'fe80::1'
    assert module

# Generated at 2022-06-17 00:37:11.127619
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()


# Generated at 2022-06-17 00:37:20.938957
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDNetworkCollector

# Generated at 2022-06-17 00:37:30.873061
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources']

# Generated at 2022-06-17 00:37:34.167067
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:36.619991
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:37:43.291138
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = '/usr/sbin/netstat'
    interface = network.get_default_interfaces(route_path)
    assert interface == ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-17 00:37:50.531343
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector.collect()
    assert network['default_ipv4']['gateway'] == '10.0.2.2'
    assert network['default_ipv4']['interface'] == 'en0'
    assert network['default_ipv6']['gateway'] == 'fe80::5054:ff:fe12:3456'
    assert network['default_ipv6']['interface'] == 'en0'


# Generated at 2022-06-17 00:38:01.635861
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    aix_network = AIXNetwork(dict(module=None))
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-17 00:38:04.488648
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:04.463432
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )

    # Create a AIXNetwork object
    aix_network = AIXNetwork(module)

    # Test the method get_default_interfaces
    route_path = '/usr/sbin/route'
    interface = aix_network.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '10.0.0.1'
    assert interface['v4']['interface'] == 'en0'
    assert interface['v6']['gateway'] == 'fe80::21e:67ff:fe10:7c0'

# Generated at 2022-06-17 00:40:16.053283
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import NetworkConfig
    from ansible.module_utils.facts.network.generic_bsd import NetworkParams
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaces
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterface
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.generic_bsd import NetworkInterfaceIPv6
   

# Generated at 2022-06-17 00:40:18.206448
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:19.729573
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:27.087468
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This is the test for method get_interfaces_info of class AIXNetwork
    """
    # Test data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    # Expected result

# Generated at 2022-06-17 00:40:29.955613
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:39.829195
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-17 00:40:41.421551
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-17 00:40:50.953910
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'default 172.16.1.1 UG 0 0 en0', ''))
    network_collector = AIXNetworkCollector(module=module)
    network_collector.get_default_interfaces('/sbin/route')
    assert network_collector.interfaces['v4']['gateway'] == '172.16.1.1'
    assert network_collector.interfaces['v4']['interface'] == 'en0'


# Generated at 2022-06-17 00:41:00.143629
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkPlatform
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkRaw
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkUnix
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkUnixLike