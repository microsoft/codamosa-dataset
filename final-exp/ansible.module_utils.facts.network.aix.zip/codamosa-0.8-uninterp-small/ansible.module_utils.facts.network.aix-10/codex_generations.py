

# Generated at 2022-06-24 22:30:02.258315
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test get_interfaces_info method of the AIXNetwork class"""

    test_file_path = 'ansi_test/facts/network/aix_ifconfig.txt'

    with open(test_file_path) as test_file:
        test_data = test_file.read()
    test_a_i_x_network_0 = AIXNetwork(dict(module=None, params={}), out=test_data, err='')

    test_interfaces_info = test_a_i_x_network_0.get_interfaces_info('/usr/sbin/ifconfig', '-a')


# Generated at 2022-06-24 22:30:04.479803
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert '192.168.1.1' in AIXNetwork.get_default_interfaces({})

# Generated at 2022-06-24 22:30:14.022854
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    out0 = {'v6': {'interface': 'en0', 'gateway': 'fe80::e8e:d6ff:fe3b:3e29'}, 'v4': {'interface': 'en0', 'gateway': '192.168.0.1'}}
    out1 = {}
    out2 = {'v6': {'interface': 'lo0', 'gateway': '::1'}, 'v4': {'interface': 'lo0', 'gateway': '127.0.0.1'}}

# Generated at 2022-06-24 22:30:15.623394
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:16.711609
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:30:27.764479
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    info = AIXNetwork().get_interfaces_info(__file__)

# Generated at 2022-06-24 22:30:35.444954
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:30:42.750626
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_1 = AIXNetwork()
    assert a_i_x_network_0.get_interfaces_info(ifconfig_path='ifconfig') == a_i_x_network_1.get_interfaces_info(ifconfig_path='ifconfig'), 'The returned value of method get_interfaces_info of class AIXNetwork is not equal to the given value'


# Generated at 2022-06-24 22:30:46.891567
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path = '/sbin/route'
    a_i_x_network_0.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:30:48.408206
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    result = isinstance(AIXNetworkCollector(), AIXNetworkCollector)
    assert result is True


# Generated at 2022-06-24 22:31:06.389168
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()

    # test case with string as function parameter
    result = AIXNetwork.get_interfaces_info(
        ifconfig_path='string',
        ifconfig_options='string',
    )
    assert isinstance(result, tuple)



# Generated at 2022-06-24 22:31:15.273834
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-24 22:31:17.075619
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert a_i_x_network_collector_0.__class__ == AIXNetworkCollector


# Generated at 2022-06-24 22:31:18.076238
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector



# Generated at 2022-06-24 22:31:20.887485
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:26.365578
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()

    assert a_i_x_network_0.get_default_interfaces('route_path') == ({'gateway': '0.0.0.0', 'interface': 'lo0'}, {})


# Generated at 2022-06-24 22:31:30.946494
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:31:31.829636
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    assert True == True


# Generated at 2022-06-24 22:31:36.580965
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test get_interfaces_info function of class AIXNetwork."""
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    # Test for exceptions

# Generated at 2022-06-24 22:31:42.810380
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.aix import AIXNetwork
    a_i_x_network_collector_1 = AIXNetworkCollector(
        Facts(dict(), dict(), dict()), AIXNetwork())


# Generated at 2022-06-24 22:32:03.951856
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    int_0 = 4911
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    # assert var_0 == (None, None)
    assert var_0[0] == {}
    assert var_0[1] == {}


# Generated at 2022-06-24 22:32:10.191323
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    try:
        assert test_case_0() == 0
    except AssertionError as e:
        print(e)
        return 1
    return 0


# Generated at 2022-06-24 22:32:14.103358
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            route_path=dict(type='str', required=False)
        )
    )
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_default_interfaces(module.params['route_path'])


# Generated at 2022-06-24 22:32:16.922740
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aiX_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:32:18.833439
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_0 = AIXNetworkCollector()
    # boolean param
    test_0 = False
    net_1 = AIXNetworkCollector(test_0)

# Generated at 2022-06-24 22:32:23.681448
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 1738
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:32:26.212589
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_class = AIXNetwork
    platform = 'AIX'
    aix_network_collector_0 = AIXNetworkCollector(fact_class, platform)


# Generated at 2022-06-24 22:32:29.625301
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:32:30.570128
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:32:33.356706
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4496
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)

    with pytest.raises(AnsibleConnectionFailure):
        a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:33:11.387074
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)
    assert isinstance(a_i_x_network_collector_0, NetworkCollector) or \
        print("Expected: NetworkCollector. Actual: ", type(a_i_x_network_collector_0))
    assert a_i_x_network_collector_0._platform == "AIX" or \
           print("AIXNetworkCollector._platform: Expected: AIX. Actual: ",
                 a_i_x_network_collector_0._platform)

# Unit tests for other functions in class AIXNetwork

# Generated at 2022-06-24 22:33:13.937082
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj_0 = AIXNetworkCollector()
    # Check for attributes '_fact_class' and '_platform'
    assert hasattr(obj_0, '_fact_class') and hasattr(obj_0, '_platform')


# Generated at 2022-06-24 22:33:18.112141
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 6125
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    assert var_0[0] == {}
    assert var_0[1] == {}


# Generated at 2022-06-24 22:33:19.124336
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:33:21.976716
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    assert a_i_x_network_0.get_interfaces_info(int_0) == (var_0, var_1)


# Generated at 2022-06-24 22:33:27.733879
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:33:34.299963
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    assert a_i_x_network_0.get_interfaces_info(int_0) == (None, None)


# Generated at 2022-06-24 22:33:37.101859
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_1 = 806
    bool_1 = False
    a_i_x_network_1 = AIXNetwork(bool_1)
    var_1 = a_i_x_network_1.get_interfaces_info(int_1)


# Generated at 2022-06-24 22:33:38.499937
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

# Generated at 2022-06-24 22:33:48.673407
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    assert var_0[0]['en0']['type'] == 'ether'
    assert isinstance(var_0[0], dict)
    assert var_0[0]['en0']['ipv4'][0]['broadcast'] == '172.16.4.255'
    assert var_0[0]['en0']['ipv4'][0]['address'] == '172.16.4.36'

# Generated at 2022-06-24 22:34:46.885671
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    int_0 = 4911
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:34:53.021247
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    class AIXNetworkCollector_0:

        def collect(self):
            this_1 = AIXNetworkCollector(bool_0)
            int_0 = bool_0
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector_0()

# Generated at 2022-06-24 22:34:58.052799
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    var_1 = a_i_x_network_0.get_default_interfaces(int_0)



# Generated at 2022-06-24 22:35:00.153532
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:35:02.145087
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    assert not isinstance(AIXNetwork.get_interfaces_info, object)


# Generated at 2022-06-24 22:35:06.241074
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:35:09.727725
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_collector_0 = AIXNetworkCollector(bool_0, a_i_x_network_0)
    var_1 = a_i_x_network_collector_0.get_device_data(int_0)

# Generated at 2022-06-24 22:35:17.840401
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 4912
    int_1 = 4912
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0, var_1 = a_i_x_network_0.get_default_interfaces(int_0, int_1)
    assert var_1 == 1, "get_default_interfaces did not return an instance of GatewayInfo."
    assert var_0 == 1, "get_default_interfaces did not return an instance of GatewayInfo."


# Generated at 2022-06-24 22:35:22.577316
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_1 = 4918
    bool_1 = True
    a_i_x_network_1 = AIXNetwork(bool_1)
    var_1 = a_i_x_network_1.get_interfaces_info(int_1)


# Generated at 2022-06-24 22:35:25.935277
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:37:20.742786
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 4911
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:37:22.191449
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-24 22:37:23.835082
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:37:26.222816
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Initializes the object
    a_i_x_network_0 = AIXNetwork(True)
    # Invoke method
    a_i_x_network_0.get_default_interfaces(4911)

# Generated at 2022-06-24 22:37:26.944145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass


# Generated at 2022-06-24 22:37:29.416752
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = None
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:37:31.536291
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 0
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)

    var_0 = a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:37:35.187350
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 5365
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0, var_1 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:37:40.416066
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # setup
    int_1 = 2
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_default_interfaces(int_1)
    # exercise
    int_0 = 4
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    # verify
    assert False is True


# Generated at 2022-06-24 22:37:45.572232
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)
    assert isinstance(a_i_x_network_collector_0, NetworkCollector)