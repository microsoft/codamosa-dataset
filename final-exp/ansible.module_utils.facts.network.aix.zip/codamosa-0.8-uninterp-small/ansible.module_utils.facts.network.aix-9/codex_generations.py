

# Generated at 2022-06-24 22:29:59.977179
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork_instance_0 = AIXNetwork('module_0')
    ifconfig_path_0 = '/sbin/ifconfig'
    ifconfig_options_0 = '-a'
    return_value_0 = AIXNetwork_instance_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)
    assert return_value_0 == (None, None)
    route_path_0 = '/sbin/route'
    return_value_1 = AIXNetwork_instance_0.get_default_interfaces(route_path_0)
    assert return_value_1 == (None, None)


# Generated at 2022-06-24 22:30:05.298562
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

    pass

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:30:11.776667
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector = AIXNetworkCollector()
    a_i_x_network = a_i_x_network_collector._fact_class(dict(module=dict()), dict())
    assert a_i_x_network.get_default_interfaces(route_path='route_path/to/linux') == (None, None)


# Generated at 2022-06-24 22:30:13.725226
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()



# Generated at 2022-06-24 22:30:16.034446
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    hamlet_as_you_like_it = AIXNetworkCollector()
    assert type(hamlet_as_you_like_it) == AIXNetworkCollector


# Generated at 2022-06-24 22:30:18.140365
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert a_i_x_network_collector_0.__class__.__name__ == 'AIXNetworkCollector'

# Generated at 2022-06-24 22:30:21.172217
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork({})
    a_i_x_network_0.get_interfaces_info('/usr/sbin/ifconfig -a')


# Generated at 2022-06-24 22:30:23.182990
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    assert a_i_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:30:25.186698
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-24 22:30:31.322342
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert_equal(a_i_x_network_collector_0._platform, 'AIX')
    assert_equal(a_i_x_network_collector_0._fact_class.platform, 'AIX')
    assert_true(isinstance(a_i_x_network_collector_0._fact_class, AIXNetwork))


# Generated at 2022-06-24 22:30:47.468626
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)

    str_1 = 'nT'
    str_2 = 'tC'
    var_0 = a_i_x_network_0.get_interfaces_info(str_1, str_2)

# Generated at 2022-06-24 22:30:55.266819
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'dU'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)
    assert var_0[1] == dict(gateway=None, interface=None)
    assert var_0[0] == dict(gateway=None, interface=None)



# Generated at 2022-06-24 22:30:57.400493
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:31:03.751051
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = '2'
    a_i_x_network_0 = AIXNetwork(str_0)
    str_0 = '{}'
    var_0 = a_i_x_network_0.get_interfaces_info(a_i_x_network_collector_0, str_0)


# Generated at 2022-06-24 22:31:13.164113
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector = AIXNetworkCollector()
    # Make sure we're running on a AIX machine
    if a_i_x_network_collector.get_platform() == 'AIX':
        a_i_x_network = AIXNetwork()
        # This would cause the method to call get_default_interfaces()
        a_i_x_network.populate()
        # We will use these variables to store the output of get_default_interfaces()
        ipv4_default_interface = {}
        ipv6_default_interface = {}
        # Run the test
        ipv4_default_interface, ipv6_default_interface = a_i_x_network.get_default_interfaces(a_i_x_network_collector)


# Generated at 2022-06-24 22:31:18.581213
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    str_1 = 'R'
    str_2 = '1'
    str_3 = '2'
    str_4 = '3'
    str_5 = '4'
    str_6 = '5'
    str_7 = '6'
    str_8 = '7'
    str_9 = '8'
    str_10 = '9'
    str_11 = '10'
    str_12 = '11'
    str_13 = '12'
    str_14 = '13'
    str_15 = '14'
    str_16 = '15'
    str_17 = '16'
    str_18 = '17'

# Generated at 2022-06-24 22:31:25.255929
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:31:33.766106
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:31:36.669850
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert False



# Generated at 2022-06-24 22:31:47.299618
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork('F')
    str_0 = '.'
    str_1 = '#'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert var_0 == (None, None)

    a_i_x_network_0 = AIXNetwork('T')
    str_0 = '%'
    str_1 = ')'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert var_0 == (None, None)

    a_i_x_network_0 = AIXNetwork('9')
    str_0 = ';'
    str_1 = '='
    var_0 = a_i

# Generated at 2022-06-24 22:32:10.029740
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Test when constructor is called without parameters
    assert type(test_case_0()).__name__ == 'NoneType'


# Generated at 2022-06-24 22:32:16.646925
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_collector_0._platform = 'AIX'
    a_i_x_network_collector_0._fact_class = AIXNetwork
    var_0 = a_i_x_network_collector_0.collect()
    assert isinstance(var_0, dict) == True
    assert len(var_0) == 2
    assert 'all_ipv4_addresses' in var_0
    assert 'all_ipv6_addresses' in var_0
    assert 'interfaces' in var_0
    assert len(var_0['interfaces']) > 0

# Generated at 2022-06-24 22:32:27.184324
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    var_0 = 'gi'
    var_1 = 'AIXNetwork'
    var_2 = AIXNetwork(var_0)
    var_3 = 'AIXNetworkCollector'
    var_4 = AIXNetworkCollector()
    var_5 = var_2.get_interfaces_info(var_1, var_3, var_4)
    assert var_2.interfaces['gi0'] == 'gi0:\tflags=842<UP,BROADCAST,RUNNING,MULTICAST>\n'
    assert var_2.interfaces['gi2'] == 'gi2:\tflags=842<UP,BROADCAST,RUNNING,MULTICAST>\n'

# Generated at 2022-06-24 22:32:31.403053
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'Z<'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_interfaces_info(a_i_x_network_collector_0, '-a')


# Generated at 2022-06-24 22:32:37.123322
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()

    a_i_x_network_0 = AIXNetwork('GMo')
    # expected_0 = ['4967', '49hl', '49TN', '49j3', '49jA', '49Vk', '49fQ', '49gT', '49gQ', '49g7', '49gY', '49gF', '49gu', '49gE', '49gN', '49gH', '49gK', '49gM', '49gI', '49gJ', '49gR', '49h4', '49h5', '49h2', '49h8', '49h3', '49h6', '49h7', '49hX', '49h1', '49hW', '49hU', '49

# Generated at 2022-06-24 22:32:38.537334
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:32:44.211621
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector()
    str_0 = 'XG'
    assert AIXNetworkCollector(str_0)
    var_0 = AIXNetworkCollector()
    assert var_0.platform == 'AIX'



# Generated at 2022-06-24 22:32:45.185154
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_1 = AIXNetworkCollector()


# Generated at 2022-06-24 22:32:49.087750
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
  pass


# Generated at 2022-06-24 22:32:51.645850
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = '<k~4'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:33:39.153932
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.facts == {}
    assert aix_network_collector.platform == 'AIX'


# Generated at 2022-06-24 22:33:45.797765
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:33:50.272850
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert a_i_x_network_collector._platform == 'AIX'
    assert a_i_x_network_collector._fact_class == AIXNetwork


# Generated at 2022-06-24 22:33:51.035268
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass


# Generated at 2022-06-24 22:33:54.219560
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:34:00.687703
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'VfW'
    a_i_x_network_0.get_interfaces_info(str_0, a_i_x_network_collector_0)

# Generated at 2022-06-24 22:34:07.521497
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    str_1 = 'ZR'
    str_2 = 'ZR'
    a_i_x_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:34:11.813171
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector


# Generated at 2022-06-24 22:34:16.386195
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = AIXNetwork()
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)



# Generated at 2022-06-24 22:34:20.597677
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    assert a_i_x_network_collector_0._fact_class is AIXNetwork
    assert a_i_x_network_collector_0._platform is 'AIX'


# Generated at 2022-06-24 22:35:50.826365
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)

    # AIX 'ifconfig -a' does not contain three words in the interface line
    regex_0 = r'^\w*\d*:*'

    # device must have mtu attribute in ODM
    if 'mtu' not in current_if:
        lsattr_path = self.module.get_bin_path('lsattr')
        if lsattr_path:
            rc, out, err = self.module.run_command([lsattr_path, '-El', current_if['device']])
            if rc != 0:
                break

# Generated at 2022-06-24 22:35:54.994377
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(a_i_x_network_collector_0, 'PATH')


# Generated at 2022-06-24 22:35:59.302516
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:36:03.245109
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)

# Generated at 2022-06-24 22:36:07.631433
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_2 = AIXNetwork('ZR')
    str_1 = '/usr/bin/i_f_config'
    str_2 = '-a'
    var_2 = a_i_x_network_2.get_interfaces_info(str_1, str_2)
    var_1 = a_i_x_network_2.get_interfaces_info(str_1)


# Generated at 2022-06-24 22:36:11.853066
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    print('Testing get_default_interfaces')
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)

# Generated at 2022-06-24 22:36:14.954291
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    str_0 = ']"T'
    a_i_x_network_0 = AIXNetwork(str_0)
    str_1 = 't'
    str_2 = ']"T'
    var_0 = a_i_x_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:36:17.716142
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork('ZR')
    a_i_x_network_collector = AIXNetworkCollector()
    
    a_i_x_network.get_default_interfaces(a_i_x_network_collector)


# Generated at 2022-06-24 22:36:26.651248
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    if a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0) is not None:
        raise AssertionError("get_default_interfaces returned unexpected result ('{}', expected None)".format(a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)))


# Generated at 2022-06-24 22:36:28.817233
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:39:13.650118
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:39:20.423807
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZR'
    a_i_x_network_0 = AIXNetwork(str_0)
    # Output the result of the method: get_interfaces_info
    var_0 = a_i_x_network_0.get_interfaces_info(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:39:20.886122
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass

# Generated at 2022-06-24 22:39:21.971944
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()


# Generated at 2022-06-24 22:39:24.098054
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork(str_0)
    str_0 = 'MN'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:39:26.070197
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork('ZR')
    # No need to test this method


# Generated at 2022-06-24 22:39:31.188364
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = 'ZE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:39:32.979616
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:39:41.831823
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = '<'
    a_i_x_network_0 = AIXNetwork(str_0)
    list_0 = ['d', '"']