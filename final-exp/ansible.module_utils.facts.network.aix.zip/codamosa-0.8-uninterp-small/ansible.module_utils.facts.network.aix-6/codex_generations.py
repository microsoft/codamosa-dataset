

# Generated at 2022-06-24 22:29:51.990061
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)


# Generated at 2022-06-24 22:29:59.214041
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    route_path = './ansible_facts.modules.network.aix.test_case_0'
    v4_0, v6_0 = a_i_x_network_0.get_default_interfaces(route_path)
    assert v4_0 == {}
    assert v6_0 == {}



# Generated at 2022-06-24 22:30:05.943009
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    assert a_i_x_network_0.get_default_interfaces('route_path') == ('interface', 'v6')


# Generated at 2022-06-24 22:30:15.450812
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)

    # Test with invalid path to ifconfig
    fa_se_interfaces_0, fa_se_ips_0 = a_i_x_network_0.get_interfaces_info('fake')
    #
    assert not fa_se_interfaces_0
    assert not fa_se_ips_0

    # Test with valid path to ifconfig
    ifconfig_path = a_i_x_network_0.module.get_bin_path('ifconfig')
    true_interfaces_0, true_ips_0 = a_i_x_network_0.get_interfaces_info(ifconfig_path)
    #
    assert true_interfaces_0
    assert true_ips_0


#

# Generated at 2022-06-24 22:30:18.721455
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    print('AIXNetworkCollector successfully imported')



# Generated at 2022-06-24 22:30:22.793210
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # -a
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:30:23.822702
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:30:30.860301
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = a_i_x_network_0.get_default_interfaces('d/p')
    assert type(str_0) == tuple
    assert len(str_0) == 2
    assert type(str_0[0]) == dict
    assert 'gateway' in str_0[0]
    assert 'interface' in str_0[0]

# Generated at 2022-06-24 22:30:36.859310
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_1 = AIXNetwork({"device": "eth0", "ipv4": [], "ipv6": [], "type": "unknown"})
    assert a_i_x_network_1.get_interfaces_info() == ()


# Generated at 2022-06-24 22:30:39.466022
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:31:02.295814
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    
    # get_default_interfaces of AIXNetwork object instantiated with dummy
    # module is called
    a_i_x_network_0 = AIXNetwork(dummy)

    # AIX-specific command netstat is run with parameter '-nr' and output is
    # set to out_0
    rc_0, out_0, err_0 = a_i_x_network_0.module.run_command(['netstat', '-nr'])
    a_i_x_network_0.module.fail_json.assert_called_with(
        rc=rc_0,
        msg='Command netstat -nr failed',
        stderr=err_0,
        stdout=out_0
    )

    # Assertion to check if a_i_x_network_0.default_interface is

# Generated at 2022-06-24 22:31:09.090057
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module.run_command = MagicMock(return_value=(0, 'fake_rc, fake_out, fake_err'))
    a_i_x_network_0.get_interfaces_info(ifconfig_path='fake_ifconfig_path', ifconfig_options='fake_ifconfig_options')


# Generated at 2022-06-24 22:31:10.152353
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:19.859290
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )
    # create instance of AIXNetwork
    test_instance = AIXNetwork(test_module)
    # execute test method
    result_expected = {}
    result_actual = test_instance.get_interfaces_info(test_module.get_bin_path('ifconfig'), '-a')[0]
    assert result_actual == result_expected

if __name__ == '__main__':
    from test import *
    test_case_0()
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:31:28.893146
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    # a_i_x = AIXNetwork()

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    interfaces, ips = get_interfaces_info(AIXNetwork, ifconfig_path, ifconfig_options)

    for iface in interfaces.values():
        for field in ('device', 'flags', 'mtu', 'type', 'macaddress'):
            if field not in iface:
                raise AssertionError("Field %s not in %s" % (field, iface))



# Generated at 2022-06-24 22:31:37.721181
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class DummyModule(object):
        def __init__(self, n_path, n_opt):
            self.n_path = n_path
            self.n_opt = n_opt

        def get_bin_path(self, path, required=False):
            del required
            if path == 'ifconfig':
                if self.n_path == 'ifconfig_0':
                    return 'ifconfig_0'
                if self.n_path == 'ifconfig_1':
                    return 'ifconfig_1'
                if self.n_path == 'ifconfig_2':
                    return 'ifconfig_2'
            if self.n_path == 'uname':
                return 'uname'
            if path == 'entstat':
                return 'entstat'

# Generated at 2022-06-24 22:31:40.043948
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 22:31:48.831269
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = '/usr/bin/netstat'
    a_i_x_network_0 = AIXNetwork(dict(module=dict()))
    a_i_x_network_1 = AIXNetwork(dict(module=dict(run_command=\
        lambda cmd: (0, 'default 172.17.0.1 UGSc 0 0 en0 \ndefault ::1 UGRS 0 0 lo0\n' +\
        'default fe80::%lo0 UGScI 0 0 lo0', ''))))

# Generated at 2022-06-24 22:31:51.771635
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    my_route_path = '/usr/sbin/route'
    my_default_interfaces = a_i_x_network_collector_0._fact_class.get_default_interfaces(my_route_path)
    assert my_default_interfaces is not None


# Generated at 2022-06-24 22:31:53.882986
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_1 = AIXNetworkCollector()
    assert a_i_x_network_collector_1._fact_class == AIXNetwork


# Generated at 2022-06-24 22:32:09.384010
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 're'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:12.142453
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 'n'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:19.029042
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    print(a_i_x_network_collector_0.platform)
    print(a_i_x_network_collector_0._platform)

if __name__ == "__main__":
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:24.243954
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'op'
    dict_0 = dict()
    a_i_x_network_0 = AIXNetwork(dict_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:33.057861
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'en2s0: flags=0x80000863,999999 mtu 1500'
    str_1 = 'options=3<rxcsum,txcsum,rxcsum_ipv6,txcsum_ipv6>'
    str_2 = 'ether 8c:dc:d4:8a:39:63 media: Ethernet autoselect (1000baseT <full-duplex>) status: active'
    str_3 = 'lladdr 8c:dc:d4:8a:39:63'
    str_4 = 'inet6 fe80::8edc:d4ff:fe8a:3963%en2s0 prefixlen 64 scopeid 0x1'
    str_5 = 'inet 149.119.134.176 netmask 0xffffffff broadcast 149.119.134.176'


# Generated at 2022-06-24 22:32:37.089737
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    assert type(a_i_x_network_0.get_interfaces_info(str_0)) == tuple


# Generated at 2022-06-24 22:32:43.527989
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 'r'
    str_1 = 'r'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:32:54.634068
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    os_path_exists = Mock(return_value = True)
    run_command = Mock(return_value = (0, '', ''))
    setattr(AIXNetwork, '_get_interfaces_info', test_AIXNetwork_get_interfaces_info.run_command)
    setattr(AIXNetwork, 'os.path.exists', test_AIXNetwork_get_interfaces_info.os_path_exists)
    a_i_x_network_0 = AIXNetwork(set())
    a_i_x_network_0.os.path.exists = os_path_exists
    a_i_x_network_0._get_interfaces_info = run_command

# Generated at 2022-06-24 22:32:56.717330
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.get_interfaces_info(set_0, set_0)


# Generated at 2022-06-24 22:32:59.656051
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Create object of class AIXNetworkCollector without parameter

    # Create object of class AIXNetworkCollector with parameter
    set_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)

# Generated at 2022-06-24 22:33:28.257396
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str())
    assert var_0 == None


# Generated at 2022-06-24 22:33:34.673954
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'l'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:33:42.889665
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:33:46.558417
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = 're'
    a_i_x_network_0 = AIXNetwork(set_0)
    str_1 = 'st'
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(str_1, str_0)

# Generated at 2022-06-24 22:33:50.551807
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 'a'
    # Testing if 'a' should be set to None
    assert a_i_x_network_0.get_interfaces_info(str_0) == None, "Unexpected result for AIXNetwork.get_interfaces_info(a)"


# Generated at 2022-06-24 22:33:55.078436
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    force_set = set()
    result = AIXNetworkCollector(force_set)
    print(result)


# Generated at 2022-06-24 22:33:58.454089
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'a1'
    set_0 = set(str_0)
    a_i_x_network_0 = AIXNetwork(set_0)
    str_1 = 'a1'
    var_1 = a_i_x_network_0.get_default_interfaces(str_1)



# Generated at 2022-06-24 22:33:58.962082
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True is True

# Generated at 2022-06-24 22:34:04.135215
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork('DGt')
    
    assert(a_i_x_network_0.get_interfaces_info('P') == ('t', 'r'))
    assert(a_i_x_network_0.get_interfaces_info('e') == ('R', 'i'))
    assert(a_i_x_network_0.get_interfaces_info('w') == ('Q', 'e'))
    assert(a_i_x_network_0.get_interfaces_info('w') == ('Q', 'e'))
    assert(a_i_x_network_0.get_interfaces_info('T') == ('c', 'C'))
    
    

# Generated at 2022-06-24 22:34:11.746696
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Case 1: Passed Argument is not a set
    set_0 = 'a set'
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    # Case 2: Passed Argument is a set of subclass of AIXNetwork
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    set_0.add(a_i_x_network_0)
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    # Case 3: Passed Argument is a set of not subclass of AIXNetwork
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    # Case 4: No Argument Passed
    a_i

# Generated at 2022-06-24 22:35:09.022339
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = 'ifconfig'

    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])

    for line in out.splitlines():
        words = line.split()

        # only this condition differs from GenericBsdIfconfigNetwork
        if re.match(r'^\w*\d*:', line):
            current_if = self.parse_interface_line(words)
            interfaces[current_if['device']] = current_if
        elif words[0].startswith('options='):
            self.parse_options_line(words, current_if, ips)
        el

# Generated at 2022-06-24 22:35:11.870944
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    assert not a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:35:17.676004
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:35:19.496989
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
  _fact_class = AIXNetwork
  _platform = 'AIX'
  # call AIXNetworkCollector constructor
  obj = AIXNetworkCollector(_fact_class, _platform)

# Generated at 2022-06-24 22:35:29.752665
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    with open('./data/ifconfig.aix.out', 'r') as f:
        data = f.read()

    aix_net = AIXNetwork({})
    interfaces, ips = aix_net.get_interfaces_info(data)

    # validate interfaces
    assert 'en0' in interfaces
    en0 = interfaces['en0']
    assert 'device' in en0
    assert en0['device'] == 'en0'
    assert 'type' in en0
    assert en0['type'] == 'ether'
    assert 'flags' in en0
    assert 'UP' in en0['flags']
    assert 'BROADCAST' in en0['flags']
    assert 'SIMPLEX' in en0['flags']
    assert 'MULTICAST' in en0['flags']

# Generated at 2022-06-24 22:35:36.086071
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    result = None
    # TEST CASE ID: 0 - get_interfaces_info(self, ifconfig_path, ifconfig_options='-a')
    str_0 = '0'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0)
    assert var_0 == result


# Generated at 2022-06-24 22:35:39.718347
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    # Tests if get_default_interface_name(...) returns empty string
    assert a_i_x_network_collector_0.get_default_interface_name() == ''
    # Tests if get_default_network_name(...) returns empty string
    assert a_i_x_network_collector_0.get_default_network_name() == ''

# Generated at 2022-06-24 22:35:49.719620
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # AIX 'ifconfig -a' does not have three words in the interface line
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.parse_interface_line = Mock(return_value=1)
    a_i_x_network_0.parse_interface_line = Mock(return_value=1)
    a_i_x_network_0.parse_ether_line = Mock(return_value=1)
    a_i_x_network_0.parse_status_line = Mock(return_value=1)
    a_i_x_network_0.parse_nd6_line = Mock(return_value=1)

# Generated at 2022-06-24 22:35:58.619551
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:36:01.683389
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # Constructor for class AIXNetworkCollector
    AIXNetworkCollector()

# Generated at 2022-06-24 22:37:41.145208
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)

# Generated at 2022-06-24 22:37:50.481831
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 'lk'
    # Calling the method call_v6 with args (1, set_0, str_0)
    #raise NotImplementedError()
    # Calling the method call_v6 with args (1, set_0, str_0)
    #raise NotImplementedError()
    # Calling the method call_v6 with args (1, set_0, str_0)
    #raise NotImplementedError()
    # Calling the method call_v4 with args (1, set_0, str_0)
    #raise NotImplementedError()
    # Calling the method call_v6 with args (1, str_0, set_0)
    #raise NotImple

# Generated at 2022-06-24 22:37:57.022404
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = 're'
    str_1 = 'a'
    str_2 = '-a'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1, str_2)

# Generated at 2022-06-24 22:37:58.041308
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-24 22:38:01.613416
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass

if __name__ == '__main__':
    # Unit test constructor of class AIXNetwork
    print("Unit test for constructor of class AIXNetwork")
    test_case_0()

    # Unit test for constructor of class AIXNetworkCollector
    print("Unit test for constructor of class AIXNetworkCollector")
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:38:09.371143
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # aix_1.json
    str_1 = ' ent0'
    str_2 = ' flags=18c<BROADCAST,MULTICAST,ALIAS>'
    str_3 = ' media: i82559 <BNC>'
    str_4 = ' status: active'
    str_5 = ' lladdr '
    str_6 = ' inet 127.0.0.1 netmask 0xff000000'
    str_7 = ' lo0'
    str_8 = ' flags=e08084<UP,BROADCAST,LOOPBACK,MULTICAST,IPv4>'
    str_9 = ' options=3<RXCSUM,TXCSUM>'
    str_10 = ' media: Ethernet autoselect (100baseTX full-duplex)'

# Generated at 2022-06-24 22:38:13.497260
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:38:16.868137
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:38:20.216334
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0.facts == {}, 'Failed to construct AIXNetworkCollector'


# Generated at 2022-06-24 22:38:23.516044
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Str_0
    str_0 = 're'
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    assert isinstance(var_0, tuple)
