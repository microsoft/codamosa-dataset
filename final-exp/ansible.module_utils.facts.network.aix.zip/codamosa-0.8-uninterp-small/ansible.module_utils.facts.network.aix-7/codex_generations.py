

# Generated at 2022-06-24 22:29:51.261154
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()
    route_path = 'route_path'
    a_i_x_network_get_default_interfaces = a_i_x_network.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:29:58.948288
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_1 = AIXNetworkCollector()
    a_i_x_network_0 = AIXNetwork(module=a_i_x_network_collector_1.module)
    assert a_i_x_network_0.get_interfaces_info('/sbin/ifconfig', '-a') == (a_i_x_network_0.interfaces, a_i_x_network_0.ips)


# Generated at 2022-06-24 22:30:02.276595
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-24 22:30:04.613508
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    for test_case in [test_case_0]:
        test_case()

if __name__ == '__main__':
    for test_case in [test_AIXNetworkCollector]:
        test_case()

# Generated at 2022-06-24 22:30:14.145613
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # interface = dict(v4={}, v6={})
    a_i_x_network_0 = AIXNetwork()
    route_path = '/usr/sbin/netstat'
    a_i_x_network_0.module = MagicMock()
    a_i_x_network_0.module.get_bin_path = MagicMock(side_effect=[route_path, None])
    a_i_x_network_0.module.run_command = MagicMock(return_value=[0,
                                                                 'default 172.16.1.1 UG 12     en1',
                                                          'default 2001:db8::1 UG 1024  en2'])
    # invoke the method being tested. It should return a tuple of two dictionaries

# Generated at 2022-06-24 22:30:17.348903
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector
    """
    a_i_x_network_collector = AIXNetworkCollector()
    assert a_i_x_network_collector._fact_class == AIXNetwork


# Generated at 2022-06-24 22:30:19.473664
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:27.201397
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mock_AIXNetwork = AIXNetwork()

    a_i_x_network_collector_0 = AIXNetworkCollector()

    # try to get ipv4 gateway
    mock_AIXNetwork.default_v4_gw, mock_AIXNetwork.default_v6_gw = mock_AIXNetwork.get_default_interfaces('/usr/bin/netstat')
    assert mock_AIXNetwork.default_v4_gw is not None
    assert mock_AIXNetwork.default_v6_gw is not None

# Generated at 2022-06-24 22:30:32.221481
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    s_0 = a_i_x_network_0.get_interfaces_info(ifconfig_path='/sbin/ifconfig', ifconfig_options='-a')
    assert s_0[0] == {}
    assert s_0[1] == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}



# Generated at 2022-06-24 22:30:37.148702
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()
    aIXNetwork_0 = AIXNetwork()
    route_path_0 = []
    return_value_0 = aIXNetwork_0.get_default_interfaces(route_path_0)
    assert return_value_0 == (None, None)


# Generated at 2022-06-24 22:30:51.411377
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)
    pass


# Generated at 2022-06-24 22:30:52.991915
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # No test yet
    pass


# Generated at 2022-06-24 22:30:56.228341
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    str_0 = ""
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:30:57.794610
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:31:06.475123
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    list_1 = ['options', "options='1'", '2', '3']
    list_2 = ['nd6', 'options', "nd6_options='1'"]
    list_3 = ['media:', 'Ethernet', '1000baseT', 'mediaopt', 'mediaopt']
    list_4 = ['ether', 'AA:BB:CC:DD:EE:FF']
    list_5 = ['status:', 'active']
    list_6 = ['lladdr', 'AA:BB:CC:DD:EE:FF']
    list_7 = ['inet', '00.00.000.00']
    list_8 = ['inet6', 'CC01:0000:0000:0000:0000:0000:0000:0000']

# Generated at 2022-06-24 22:31:15.298445
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    var_0 = AIXNetwork(bool_0)

# Generated at 2022-06-24 22:31:19.113128
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(var_0, )


# Generated at 2022-06-24 22:31:25.677430
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert (isinstance(AIXNetworkCollector._platform, str)), 'AIXNetworkCollector._platform is not a string'
    assert (isinstance(AIXNetworkCollector._fact_class, NetworkCollector)), 'AIXNetworkCollector._fact_class is not a ' \
           'NetworkCollector'

test_AIXNetworkCollector()


# Generated at 2022-06-24 22:31:34.063097
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network_0 = AIXNetwork()

    # mock module
    mock_module_0 = MagicMock()
    mock_module_0.get_bin_path.return_value = '/usr/bin/netstat'

    mock_module_1 = MagicMock()
    # mock module function side_effect to simulate the run_command

# Generated at 2022-06-24 22:31:35.697181
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = ''
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)

# Generated at 2022-06-24 22:32:00.657140
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector_0 = AIXNetworkCollector()
    var_0 = aix_network_collector_0.platform
    var_0 = aix_network_collector_0._fact_class

# Generated at 2022-06-24 22:32:03.732369
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:07.598233
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = get_random_string()
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    assert_is_instance(var_0, tuple)


# Generated at 2022-06-24 22:32:11.021956
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for the method AIXNetwork.get_interfaces_info"""
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_interfaces_info(list_0)

# Generated at 2022-06-24 22:32:17.320205
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = ['aix', 'iscsi0:', 'flags=ee00', '<up,broadcast,loopback,nonvlan>', 'mtu', '1500']
    list_1 = ['aix', 'ib0', '0x2', 'up', 'inherit', 'mtu', '65520', 'index', '3', 'address', '00:00:00:00:00:00', 'ipalias', '192.168.6.60']
    list_2 = ['aix', 'ib0', '0x4000002', 'up', 'inherit', 'mtu', '65520', 'index', '3', 'address', '<MAC', 'Address:', '00:00:00:00:00:00>', 'ipalias', '192.168.6.60']

# Generated at 2022-06-24 22:32:28.104608
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Build an instance of Network with a an interface list to feed parse_interface_line and test if returned value matches
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    list_0 = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '192.0.2.1', 'netmask', '0xffffff00', 'broadcast', '192.0.2.255']
    var_0 = a_i_x_network_0.parse_interface_line(list_0)
    # Build an instance of Network with a an interface list to feed parse

# Generated at 2022-06-24 22:32:35.357698
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    str_0 = 'nYMj'
    str_1 = 'W:n'
    list_1 = []
    str_2 = 'b;\x0eax'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    assert a_i_x_network_0.get_interfaces_info(str_0, str_1) == (list_0, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert a_i_x_network_0.get_interfaces_info(str_2) == (list_1, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})



# Generated at 2022-06-24 22:32:41.688900
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = ['/bin/ifconfig', '-a']
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(list_0[0], list_0[1])


# Generated at 2022-06-24 22:32:45.333966
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:32:49.399199
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    i_fconfig_path_0 = None
    i_fconfig_options_0 = None
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    # Passing i_fconfig_path_0, i_fconfig_options_0=None to function get_interfaces_info
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(i_fconfig_path_0, i_fconfig_options_0)
    # var_0 should be None
    # var_1 should be None
    assert var_0 is None
    assert var_1 is None

# Generated at 2022-06-24 22:33:37.930188
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Test for constructor
    assert not AIXNetworkCollector(_NetworkCollector__supported_facts)._collected_facts


# Generated at 2022-06-24 22:33:38.857191
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj_1 = AIXNetworkCollector()

# Generated at 2022-06-24 22:33:44.301473
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:33:53.536277
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    check = AIXNetwork(True)

    ifconfig_path = check.module.get_bin_path('ifconfig')
    route_path = check.module.get_bin_path('route')
    if not ifconfig_path or not route_path:
        assert None, "ifconfig or route command not found"

    try:
        if_v4, if_v6 = check.get_default_interfaces(route_path)

        # check for default route, usually there is only ipv4 or ipv6
        assert "192.168.1.254" in if_v4.values(), "Default route not found"

    except IOError as e:
        assert None, "Unable to execute command {0}: {1}".format(e.filename, e.strerror)



# Generated at 2022-06-24 22:33:55.573863
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # print('\n\nParse default_interface\n')
    line_list = 'default 10.0.0.1 UG 8 0 en0'.split()
    a_i_x_network_0 = AIXNetwork(True)
    var_0 = a_i_x_network_0.get_default_interfaces(line_list)



# Generated at 2022-06-24 22:33:58.884812
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    dict_0 = a_i_x_network_0.get_default_interfaces(list_0)
    return dict_0['v4'], dict_0['v6']


# Generated at 2022-06-24 22:34:00.881830
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:34:04.612861
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:34:06.026113
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:34:09.357726
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    list_1 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0, var_1 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:35:37.367692
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

# Generated at 2022-06-24 22:35:39.546760
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_default_interfaces('')


# Generated at 2022-06-24 22:35:44.965255
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.parse_interface_line(list_0)
    var_1 = a_i_x_network_0.get_default_interfaces('route_path')
    assert var_1 is None


# Generated at 2022-06-24 22:35:46.809691
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

# Generated at 2022-06-24 22:35:50.278939
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # default fact class (see __init__)
    assert AIXNetworkCollector._fact_class == AIXNetwork
    # default platform (see __init__)
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-24 22:35:52.239452
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:35:56.353275
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    list_0 = ['aix7_1', '-a']
    str_0 = a_i_x_network_0.get_interfaces_info(str_0, list_0)
    assert str_0 == str_0


# Generated at 2022-06-24 22:36:02.637873
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = "ifconfig"
    str_1 = "-a"
    a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:36:04.040062
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Test parse_interface_line() for 0 values

# Generated at 2022-06-24 22:36:11.786706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert type(AIXNetworkCollector._fact_class) is type(AIXNetwork), 'member "_fact_class" is not type "AIXNetwork"'
    assert AIXNetworkCollector._platform is 'AIX', 'member "_platform" is not "AIX"'


###############################################################################
#
# Output from 'ifconfig -a'
#
###############################################################################

#
# Output from 'netstat -rn'
#

# default 192.168.10.1 UG 0 0 en0
# default 192.168.1.1  UG 0 0 en0
# default 192.168.20.1 UG 0 0 en3
# default 192.168.30.1 UG 0 0 en4
# default 192.168.40.1 UG 0 0 en5
# default 192.168.50.1 UG 0

# Generated at 2022-06-24 22:39:11.907991
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = ''
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    assert var_0 == (dict(), dict())


# Generated at 2022-06-24 22:39:15.860101
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    # netstat_path is a dummy path to netstat
    assert a_i_x_network_0.get_default_interfaces('/usr/bin/netstat') == ((), ())


# Generated at 2022-06-24 22:39:19.899187
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    list_0 = []
    bool_0 = True
    AIXNetworkCollector(list_0, bool_0)


# Generated at 2022-06-24 22:39:20.846738
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

# Generated at 2022-06-24 22:39:21.510844
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    out = AIXNetworkCollector()


# Generated at 2022-06-24 22:39:23.878472
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:39:26.792749
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = ['']
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    result = a_i_x_network_0.get_default_interfaces(list_0)
    assert(result == ('interface', 'default'))


# Generated at 2022-06-24 22:39:29.422482
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = "route_path"
    boolean_0 = True
    a_i_x_network = AIXNetwork(boolean_0)
    test_method = a_i_x_network.get_default_interfaces(route_path)
    assert test_method is None


# Generated at 2022-06-24 22:39:30.722650
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:39:40.245212
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    str_0 = 'quick'
    str_1 = 'echo'
    a_i_x_network_0 = AIXNetwork(bool_0)
    # a_i_x_network_0.interfaces = {}
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert var_0['lo0']['device'] == 'lo0'
    assert var_0['en0']['mtu'] == '1500'
    assert var_0['en0']['type'] == 'ether'
    assert var_0['en0']['macaddress'] == '00:05:93:00:00:00'