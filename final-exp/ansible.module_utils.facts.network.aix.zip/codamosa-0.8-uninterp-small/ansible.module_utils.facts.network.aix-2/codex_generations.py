

# Generated at 2022-06-24 22:29:49.431624
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert a_i_x_network_collector_0.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-24 22:29:51.891036
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    assert True # TODO: implement your test here



# Generated at 2022-06-24 22:29:55.354173
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    test_case_0()


# Generated at 2022-06-24 22:30:03.880468
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    string_0 = 'lL]vEK~O[p' # Variable name is module_utils_facts_network_aix_AIXNetwork_string_0
    string_1 = ' ' # Variable name is module_utils_facts_network_aix_AIXNetwork_string_1
    string_2 = 'r' # Variable name is module_utils_facts_network_aix_AIXNetwork_string_2
    string_3 = 'c' # Variable name is module_utils_facts_network_aix_AIXNetwork_string_3
    string_4 = 'c' # Variable name is module_utils_facts_network_aix_AIXNetwork_string_4
    string_5 = 'I' # Variable name is module_utils

# Generated at 2022-06-24 22:30:08.515255
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path_0 = '/etc/hosts'
    v_0, v_1 = a_i_x_network_0.get_default_interfaces(route_path_0)
    assert(v_0 == {})
    assert(v_1 == {})


# Generated at 2022-06-24 22:30:18.626026
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    str_0 = 'hR'
    str_1 = 'e>@}r'
    dict_0 = dict(qg='e?hfVG', zr=str_0, zt='2_*h&', jx='9cZ+&', jh=str_0, rw='p7vfO')

# Generated at 2022-06-24 22:30:23.833064
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()
    route_path = '/usr/bin/netstat'
    v4, v6 = a_i_x_network.get_default_interfaces(route_path)
    if v4['gateway'] != '10.65.32.1' or v4['interface'] != 'en1':
        raise Exception("Return values for interface IPv4 test case 0 don't match")
    if v6['gateway'] != 'fe80::5efe:10.65.32.1%en1' or v6['interface'] != 'en1':
        raise Exception("Return values for interface IPv6 test case 0 don't match")


# Generated at 2022-06-24 22:30:33.657323
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()
    route_path = './unit/module_utils/facts/network/fixtures/'
    output = a_i_x_network.get_default_interfaces(route_path)
    assert isinstance(output, dict)
    assert 'v4' in output
    assert isinstance(output['v4'], dict)
    assert 'gateway' in output['v4']
    assert isinstance(output['v4']['gateway'], str)
    assert 'interface' in output['v4']
    assert isinstance(output['v4']['interface'], str)
    assert 'v6' in output
    assert isinstance(output['v6'], dict)
    assert 'gateway' in output['v6']

# Generated at 2022-06-24 22:30:35.785196
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:40.568374
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = a_i_x_network_collector_0._platform
    str_0 = a_i_x_network_collector_0._fact_class


# Generated at 2022-06-24 22:31:02.331330
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    bytes_0 = b'\x8e\xae\x1a\xb1\xdf\xda\xed\xec\xba\x06\xe8\x9b\x9b\x98\x0f\x00\x06\x00\x00\xec\xed\xda\xdf\xb1\x1a\xae\x8e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    set_0.add(bytes_0)
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.get_interfaces_info(bytes_0)


# Generated at 2022-06-24 22:31:05.060342
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    assert a_i_x_network_collector_0._fact_class._platform == 'AIX'

# Generated at 2022-06-24 22:31:14.305039
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    bytes_1 = b'\x9f\x04\xda\x0c\xb4C\x8f\xe2\x84\x9b\x90\x88\x04\x13\x81\xd1'
    set_1 = {bytes_1}
    bytes_2 = b'\x93\x0c\x87\xe2\x0bwa\xa3\x9b\x0b\xaa\x1f\x11\xa1Y\x83\x8b'
    set_2 = {bytes_2}
    a_i_x_network_collect

# Generated at 2022-06-24 22:31:16.340634
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector(bytes_0)
    assert not hasattr(a_i_x_network_collector_0, 'a_i_x_network')


# Generated at 2022-06-24 22:31:23.767112
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\x04\x13\x0c\x0f\x10\x01\xe2\x9a\x81\xe2\x96\x86\xe2\x97\x8b'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    int_0 = a_i_x_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 22:31:32.572888
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'_\xed\xae\x1c\x8bq\xe4\x9a\xdd\xa0\xb5\xc7\x90\xccz\xad\xcc\xee\xcb\x88\xce\x8b\x07\x0e\xa1\x13\x0b\x84'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.parse_interface_line(bytes_0)
    var_1 = a_i_x_network_0.get_default_interfaces(var_0)


# Generated at 2022-06-24 22:31:41.691469
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import tempfile

    empty_set = set()
    byte_0 = b'\x0b\xec\x8b\xf1`\x91v\xda\xfa\xe9\x87\xef\xf4b\xad\xd7\xbf\xf8\xd3\x1a\xaa\x87\xb8f\xe6]Z\x89\x0cR'

# Generated at 2022-06-24 22:31:47.407406
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    cmd_0 = {'rc': 0, 'stdout': '192.168.1.1', 'stdout_lines': ['192.168.1.1']}
    method_0 = AIXNetwork.get_default_interfaces(cmd_0)
    assert_0 = {'stdout': '192.168.1.1', 'stdout_lines': ['192.168.1.1']}
    assert method_0 == assert_0


# Generated at 2022-06-24 22:31:53.506388
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces = {'en0': {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'macaddress': 'unknown'}}
    ips = {}
    set_0 = {interfaces}
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bytes_0)
    return var_0


# Generated at 2022-06-24 22:32:00.548024
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(None)
    print (var_0)



# Generated at 2022-06-24 22:32:33.657498
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:32:44.717127
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # src/ansible/module_utils/facts/network/aix/aix_ifconfig.py
    bytes_0 = b'\x8b\x04\xda\xab\x0b\xc9Y\x1a\xf2\xae\xee\xba\x1c\xfe\x05\x9f\xf7\xe6\xad\xdb+\x8e\xbe\xea\xab\xf1\x9b'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 22:32:46.921359
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bytes_0)


# Generated at 2022-06-24 22:32:51.982397
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.parse_interface_line(bytes_0)


# Generated at 2022-06-24 22:32:56.776741
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 22:32:59.953265
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork(bytes_0)
    var_1 = a_i_x_network_0.get_interfaces_info(bytes_0, bytes_0)
    assert var_1 == (bytes_0, bytes_0)


# Generated at 2022-06-24 22:33:05.154367
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 22:33:15.191757
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ###################################################################################################
    # Constructor: def __init__(self):
    ###################################################################################################
    # Case 0: No fact_class passed
    print("Case: No fact_class passed")
    set_0 = {1}
    # Expectation 0: AIXNetworkCollector.fact_class = None
    expected_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    actual_0 = a_i_x_network_collector_0.fact_class
    if expected_0 != actual_0:
        print("Test Case 0: FAILED")
        print("Expected: " + str(expected_0))
        print("Actual: " + str(actual_0))
        sys.exit(1)

# Generated at 2022-06-24 22:33:18.504982
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = {'a', 'b', 'c'}
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:33:19.841795
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    #if [ "$PYTHON" ]; then
    test_case_0()
    #fi

# Generated at 2022-06-24 22:34:09.000676
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    _fact_class = AIXNetwork
    _platform = 'AIX'

    obj = AIXNetworkCollector(_fact_class, _platform)

    assert type(obj) == AIXNetworkCollector

# Generated at 2022-06-24 22:34:11.229506
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 22:34:14.188555
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)

    assert callable(getattr(a_i_x_network_0, "get_default_interfaces", None))


# Generated at 2022-06-24 22:34:18.373886
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    modules = set()
    modules.add(fake_module)
    a_i_x_network_0 = AIXNetwork(modules)
    a_i_x_network_0.get_interfaces_info(fake_module)



# Generated at 2022-06-24 22:34:26.029208
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:34:28.946386
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)

# Generated at 2022-06-24 22:34:32.983958
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info({0}, {5})



# Generated at 2022-06-24 22:34:38.542392
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    str_0 = a_i_x_network_0.get_interfaces_info(bytes_0)
    assert str_0 == (None, None)

# Generated at 2022-06-24 22:34:47.489066
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = {b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'}
    # instantiate a object named a_i_x_network_collector_0 of class AIXNetworkCollector
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0)

    # test get_facts() method of class AIXNetworkCollector
    a_i_x_network_0 = a_i_x_network_collector_0.get_facts()

# Generated at 2022-06-24 22:34:54.025942
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(set_0)
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    dict_var_0 = a_i_x_network_0.get_interfaces_info(bytes_0)

test_case_0()
test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:36:29.278619
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _fact_class = AIXNetwork
    _platform = 'AIX'
    a_i_x_network_collector_0 = AIXNetworkCollector(_fact_class, _platform)

# Generated at 2022-06-24 22:36:34.048404
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # create a AIXNetwork instance
    a_i_x_network_0 = AIXNetwork()
    # call method get_interfaces_info
    a_i_x_network_0.get_interfaces_info()


if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-24 22:36:43.887128
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    data = """en1: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
        inet 192.168.10.111 netmask 0xfffffc00 broadcast 192.168.11.255
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
        media: Ethernet autoselect (100baseTX full-duplex,flowcontrol,rxpause,txpause)
        status: active
        lladdr 00:18:39:c2:a4:45"""
    set_0 = {data}

# Generated at 2022-06-24 22:36:48.739394
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.parse_interface_line(bytes_0)
    int_0 = a_i_x_network_0.get_interfaces_info(bytes_0)

# Generated at 2022-06-24 22:36:58.415013
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    bytes_1 = b'\x97\xfe~\x8aN\xd3\x14\x9d\xee\x1b'
    bytes_1 = b'D\x96\xcc\x0b\x90\x94\x88\x9f1'
    dict_0 = {}
    dict_1 = {}
    dict_1['ipv4'] = []
    dict_1['ipv6'] = []
    dict_1['device'] = 'lo0'
    dict_1['flags']

# Generated at 2022-06-24 22:37:03.997248
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xde\x8b\x8b\x80\xc5\x12\xd5\x8b/\x16\x01\xed\x11\x8b\x9f\xad\x11\x8b\x00\x0c\x29\xde\x8c\x80\xc5\x12\xf7\x8c'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_1 = a_i_x_network_0.get_default_interfaces(bytes_0)
    assert var_1 != set_0


# Generated at 2022-06-24 22:37:13.525677
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    bytes_1 = b'/usr/sbin/netstat'
    bytes_2 = b'netstat -nr'
    bytes_3 = b'\x00\x00\x00\x00'
    bytes_4 = b'rural-gw'
    bytes_5 = b'en0'
    bytes_6 = b'192.168.1.1'
    bytes_7 = b'255.255.255.0'
    bytes_

# Generated at 2022-06-24 22:37:17.890370
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:37:22.979773
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = {' \x92\xd2\xfd\x8d\x9b\x81\xec\xe1\x80\x1a\xf3\x91\xd3\xdd\xfb\xfc\x10m\x0e^n\xe7\x01\xd4\x02\xbdg\x05\xd6\x12\xeb`'}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(None)


# Generated at 2022-06-24 22:37:30.509610
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bytes_0 = b'\xb3QP\xdcd%\xc5\xd8\xd5A\xe3,\xf6{\xc85'
    set_0 = {bytes_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.__dict__

    # Testing if the dictionary 'var_0' is empty or not.
    # If the dictionary 'var_0' is empty, it means that the method get_default_interfaces has not been implemented.
    assert (var_0 != {}), "Method get_default_interfaces is not implemented."

    # Calling method get_default_interfaces of class AIXNetwork
    var_1 = a_i_x_network_0.get_default_interfaces(bytes_0)