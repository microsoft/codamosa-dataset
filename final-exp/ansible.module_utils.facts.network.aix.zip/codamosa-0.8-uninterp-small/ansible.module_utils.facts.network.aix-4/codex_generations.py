

# Generated at 2022-06-24 22:29:51.683824
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collect_aix = AIXNetworkCollector(set())
    print(type(collect_aix))
    print(type({}))
    print(type(set()))

test = AIXNetworkCollector.test_case_0
test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:29:56.803127
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    a_i_x_network_collector.collect()

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:29:57.942551
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 22:30:00.191553
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:07.504808
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = None
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0)
    route_path_0 = None
    v4_default_dict_0, v6_default_dict_0 = a_i_x_network_1.get_default_interfaces(route_path_0)


# Generated at 2022-06-24 22:30:17.118772
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork(None)

    # Test using uname and netstat
    rc, out, err = a_i_x_network_0.module.run_command(['uname', '-W'])
    if not rc:
        if out == '0':
            # Not in WPAR
            rc, out, err = a_i_x_network_0.module.run_command(['netstat', '-nr'])
            if not rc:
                a_i_x_network_0.get_default_interfaces("/etc/route")

    # Test using only netstat
    rc, out, err = a_i_x_network_0.module.run_command(['netstat', '-nr'])
    if not rc:
        a_i_x_

# Generated at 2022-06-24 22:30:23.822946
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = None
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0)

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ansible_facts_0 = a_i_x_network_1.get_interfaces_info(ifconfig_path, ifconfig_options)
    pprint.pprint(ansible_facts_0)


# Generated at 2022-06-24 22:30:33.623848
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class AIXNetwork
    '''
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0)
    a_i_x_network_2 = AIXNetwork(a_i_x_network_1)
    a_i_x_network_3 = AIXNetwork(a_i_x_network_2)
    a_i_x_network_4 = AIXNetwork(a_i_x_network_3)
    a_i_x_network_5 = AIXNetwork(a_i_x_network_4)
    a_i_x_network_6 = AIXNetwork(a_i_x_network_5)
    a

# Generated at 2022-06-24 22:30:35.737552
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # Unit test for constructor
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'

# Generated at 2022-06-24 22:30:37.447982
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:53.213324
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_case_AIXNetwork_get_interfaces_info_1()
    test_case_AIXNetwork_get_interfaces_info_2()

# Test case 1 for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:30:54.699359
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    a_i_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:30:58.560483
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    def_route_path_0 = '/sbin/route'
    a_i_x_network_0 = AIXNetwork()
    v4_0, v6_0 = a_i_x_network_0.get_default_interfaces(def_route_path_0)


# Generated at 2022-06-24 22:31:05.081577
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path = ''
    result = a_i_x_network_0.get_default_interfaces(route_path)
    assert result['6']['gateway'] == '::'
    assert result['6']['interface'] == 'lo0'
    assert result['4']['gateway'] == '10.0.2.2'
    assert result['4']['interface'] == 'en0'


# Generated at 2022-06-24 22:31:08.681161
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    if isinstance(a_i_x_network_collector_0, NetworkCollector):
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:31:11.967565
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._fact_class == AIXNetwork
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:31:15.297947
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    a_i_x_network.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:31:18.550582
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    try:
        test_case_0()
    except Exception as e:
        raise AssertionError("Caught exception %s" % e)

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:29.908379
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test get_default_interfaces
    """
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = a_i_x_network_collector_0.get_platform_facts()[0]

    rc, out, err = a_i_x_network_0.module.run_command(["/usr/bin/ls", "/fake/path/foooooo"])
    if rc != 0:
        v4_default_interface, v6_default_interface = a_i_x_network_0.get_default_interfaces("/fake/path/foooooo")
        assert v4_default_interface is None
        assert v6_default_interface is None
    else:
        assert False


# Generated at 2022-06-24 22:31:36.965617
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = 'test_value_1'
    ifconfig_options = 'test_value_2'
    interfaces_info = a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces_info == None


# Generated at 2022-06-24 22:31:51.890211
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector, AIXNetworkCollector)


# Generated at 2022-06-24 22:31:56.220666
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    result = a_i_x_network_0.get_default_interfaces({})

###


# Generated at 2022-06-24 22:32:00.184616
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert isinstance(aix_network_collector, AIXNetworkCollector)


test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:08.819052
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    a_i_x_network.module = MockModule()

# Generated at 2022-06-24 22:32:11.131906
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:32:17.416024
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    interfaces = {}
    ips = {}
    current_if = {}
    ifconfig_path = r'/usr/bin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = a_i_x_network.module.run_command([ifconfig_path, ifconfig_options])
    lines = out.splitlines()
    line = lines[0]
    interface_line = line.split()
    current_if = a_i_x_network.parse_interface_line(interface_line)
    interfaces[current_if['device']] = current_if
    words = 'options=8<VLAN_MTU'.split()
    a_i_x_network.parse_options_line(words, current_if, ips)


# Generated at 2022-06-24 22:32:24.107265
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module.run_command = MagicMock(return_value=(0, 'default 192.168.2.1 UGS 0 32 en0', ''))
    assert a_i_x_network_0.get_default_interfaces('route_path') == ({'gateway': '192.168.2.1', 'interface': 'en0'}, {})

# Generated at 2022-06-24 22:32:31.749715
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0._module.run_command = MagicMock(return_value=(1, 'out_data', 'err_data'))
    a_i_x_network_0.get_interfaces_info = MagicMock(return_value=(1, 'out_data', 'err_data'))
    a_i_x_network_0._module.params = {}

    # Call get_interfaces_info
    # assert raises
    with pytest.raises(Exception):
        a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:32:38.440107
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    if isinstance(a_i_x_network_collector_0, AIXNetworkCollector):
        test_case_0()
    else:
        assert False

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:44.715477
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix_network import AIXNetwork

    a_i_x_network = AIXNetwork(module)
    result = a_i_x_network.get_default_interfaces(route_path)
    assert result == {}


# Generated at 2022-06-24 22:33:15.071136
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    a_i_x_network.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    assert a_i_x_network.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:33:18.113166
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    A_I_X_network_0 = AIXNetwork()
    route_path_0 = '/sbin/route'
    result_0 = A_I_X_network_0.get_default_interfaces(route_path_0)


# Generated at 2022-06-24 22:33:22.063624
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetworkCollector()._fact_class()

    a_i_x_network_get_interfaces_info_0 = a_i_x_network.get_interfaces_info(
        ifconfig_path='tests/runner/ansible_module_utils/facts/network/aix_netstat/aix_ifconfig_a',
        ifconfig_options='-a')


# Generated at 2022-06-24 22:33:24.163725
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork({})
    a_i_x_network.get_interfaces_info(
        '/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )


# Generated at 2022-06-24 22:33:28.762664
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    a_i_x_network.module.params = {'gather_network_resources': 'yes'}
    a_i_x_network.module.run_command = run_command_mock
    a_i_x_network.module.get_bin_path = get_bin_path_mock
    a_i_x_network.get_interfaces_info('ifconfig', '-a')


# Generated at 2022-06-24 22:33:36.187018
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    myAIXNetwork = AIXNetwork()
    assert myAIXNetwork.get_default_interfaces(route_path='fixtures/aix/route') is not None
    assert myAIXNetwork.get_default_interfaces(route_path='fixtures/aix/route') == ({'interface': 'en0', 'gateway': '172.20.96.254'}, {'interface': 'en0', 'gateway': 'fe80::20c:29ff:fe7d:8700'})


# Generated at 2022-06-24 22:33:42.973690
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_1 = AIXNetwork()
    a_i_x_network_2 = AIXNetwork()
    a_i_x_network_3 = AIXNetwork()


# Generated at 2022-06-24 22:33:45.631272
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    a_i_x_network_get_interfaces_info_result = a_i_x_network.get_interfaces_info()


# Generated at 2022-06-24 22:33:49.351204
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()
    print(a_i_x_network.get_default_interfaces('/usr/bin/netstat'))


# Generated at 2022-06-24 22:33:59.966551
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ifconfig_path = '/tmp/fake_dir/fake_ifconfig'
    module = None
    ifconfig_path = 'fake_ifconfig'
    ifconfig_options = '-a'

    ifconfig_path = '/tmp/fake_dir/fake_ifconfig'
    module = None
    ifconfig_path = 'fake_ifconfig'
    ifconfig_options = '-a'
    out = '''fake_line
lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1
    inet 127.0.0.1 netmask 0xff000000
fake_line'''
    rc = 0
    module = None
    interfaces = {}
    current_if = {}

# Generated at 2022-06-24 22:34:50.341704
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True == True


# Generated at 2022-06-24 22:34:55.475949
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module = MagicMock()
    mock_route_path = '/etc/resolv.conf'
    a_i_x_network_0.module.get_bin_path.return_value = '/usr/bin/netstat'
    a_i_x_network_0.module.run_command.return_value = (1, 'out', 'err')
    a_i_x_network_0.get_default_interfaces(mock_route_path)

# Generated at 2022-06-24 22:35:01.827062
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    assert a_i_x_network_0.get_interfaces_info('') == (dict(), dict())


# Generated at 2022-06-24 22:35:02.477939
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass



# Generated at 2022-06-24 22:35:05.664714
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert a_i_x_network_collector


# Generated at 2022-06-24 22:35:07.882904
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert a_i_x_network_collector_0.platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class == AIXNetwork


# Generated at 2022-06-24 22:35:14.343344
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = AIXNetwork()
    test_collector = a_i_x_network_collector_0
    test_class = a_i_x_network_0
    test_path = '/usr/sbin/ifconfig'
    test_options = '-a'
    a_i_x_network_0.get_interfaces_info(test_path, test_options)


# Generated at 2022-06-24 22:35:20.366209
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    interface_v4 = dict(gateway='192.168.1.1', interface='en0')
    interface_v6 = dict(gateway='2001:0db8:0a0b:12f0:0000:0000:0000:0001', interface='en0')
    a_i_x_network_0 = AIXNetwork()
    rc = a_i_x_network_0.get_default_interfaces('/sbin/route')
    assert interface_v4 == rc[0]
    assert interface_v6 == rc[1]


# Generated at 2022-06-24 22:35:22.911709
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:35:30.923353
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    uname_path = AIXNetwork.module.get_bin_path('uname')
    uname_rc = None
    uname_out = None
    uname_err = None
    if uname_path:
        uname_rc, uname_out, uname_err = AIXNetwork.module.run_command([uname_path, '-W'])

    ifconfig_path = AIXNetwork.module.get_bin_path('ifconfig')
    ifconfig_rc = None
    ifconfig_out = None
    ifconfig_err = None

# Generated at 2022-06-24 22:36:31.379554
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-24 22:36:39.572160
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = {}
    tuple_0 = (dict_0,)
    bytes_0 = b'A\xce% \x93\xbe\xc7\x8dt\xe9\x87\xdb\xe6\xe1\x9b\xcf\xd65'
    a_i_x_network_0 = AIXNetwork(bytes_0)
    var_0 = a_i_x_network_0.get_default_interfaces(tuple_0)


# Generated at 2022-06-24 22:36:47.983029
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module_arg_spec = dict()
    module_arg_spec['_ansible_version'] = '2.5.5'
    module_arg_spec['_ansible_module_name'] = 'get_facts'
    module_arg_spec['_ansible_syslog_facility'] = 'LOG_USER'
    module_arg_spec['_ansible_modlib'] = 'ansible.module_utils.facts.network'
    module_arg_spec['_ansible_no_log'] = False
    module_arg_spec['_ansible_debug'] = True
    body_0 = list()
    request_0 = AnsibleModule(argument_spec=module_arg_spec, body=body_0)
    set_module_args(request_0)

# Generated at 2022-06-24 22:36:53.708059
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = {}
    tuple_0 = (dict_0,)
    bytes_0 = b'\xcd\xe4+m\xc4\xa8\x08\xcb\x9b4\x8f\x0b\xac\x19\xca\x8d\x14'
    a_i_x_network_0 = AIXNetwork(bytes_0)
    var_0 = a_i_x_network_0.get_default_interfaces(tuple_0)
    assert var_0 == (None, None)


# Generated at 2022-06-24 22:36:58.939406
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = {}
    tuple_0 = (dict_0,)
    bytes_0 = b'\xe3\x1d\x7f\xc4"\xe4\x89\xd0\x94\xfd\xec\x14\x8b\x95\xbb\xf0\x0e'
    a_i_x_network_0 = AIXNetwork(bytes_0)
    var_0 = a_i_x_network_0.get_default_interfaces(tuple_0)


# Generated at 2022-06-24 22:37:03.312302
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = {}
    tuple_0 = (dict_0,)
    bytes_0 = b"\x03'\xcb\xba\xc2\x01\xe0\x96\x9e\x1b\xbb\x7f\xa6\xf0\xcf\x16\xfb"
    a_i_x_network_0 = AIXNetwork(bytes_0)
    var_0 = a_i_x_network_0.get_default_interfaces(tuple_0)


# Generated at 2022-06-24 22:37:09.894942
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    tuple_3 = (b'/usr/sbin/ifconfig',)
    bytes_8 = b'A\xce% \x93\xbe\xc7\x8dt\xe9\x87\xdb\xe6\xe1\x9b\xcf\xd65'
    a_i_x_network_0 = AIXNetwork(bytes_8)
    a_i_x_network_0.get_interfaces_info(tuple_3)


# Generated at 2022-06-24 22:37:14.080798
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bytes_0 = b'A\xce% \x93\xbe\xc7\x8dt\xe9\x87\xdb\xe6\xe1\x9b\xcf\xd65'
    a_i_x_network_collector_0 = AIXNetworkCollector(bytes_0)
    assert a_i_x_network_collector_0._platform == 'AIX'

# Generated at 2022-06-24 22:37:24.975633
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = {}
    bytes_0 = b'\x0e\xf9\x1e\x8f\x81\xbf\x08l\x8f\xb6\xc4\x95\xec\x8c\x14\x10\x1f\xdd\x1a\xb9\xc9\x9f\x07\x15\x1c@\x19\x1f{\x8e\x99\x9c\x19\x10\x0c\xc2\x1e\x1b'
    a_i_x_network_0 = AIXNetwork(bytes_0)
    a_i_x_network_0.get_default_interfaces(dict_0)

# Generated at 2022-06-24 22:37:25.869203
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()



# Generated at 2022-06-24 22:39:20.976651
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = {'device': 'en0', 'type': 'ether', 'macaddress': 'unknown', 'ipv4': [], 'ipv6': [], 'flags': set()}
    tuple_0 = (dict_0,)
    tuple_1 = ('en0', 'en0', 'en0:', 'flags=8802<BROADCAST,SIMPLEX,MULTICAST>', 'lladdr', '08:00:27:6c:19:f5', 'media:', 'autoselect', 'status:', 'active', 'nd6', 'options=1<PERFORMNUD>', 'mem', '0xc2260000-c2262fff', 'groups:', 'en', 'ether')

# Generated at 2022-06-24 22:39:27.236323
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # create a test AIXNetwork object
    test_obj = AIXNetwork(b'module_utils/facts/fake_libc.so')

    # This test is for AIX only (because of path to ifconfig, netstat and lsattr binaries)
    if test_obj.module.get_bin_path('ifconfig'):
        result = test_obj.get_interfaces_info('/usr/sbin/ifconfig', '-a')
        assert result is not None
        assert result[0] is not None
        assert result[1] is not None
        assert result[0]['lo0'] is not None
        assert result[0]['lo0']['device'] == 'lo0'
        assert result[0]['lo0']['type'] == 'loopback'

# Generated at 2022-06-24 22:39:31.720240
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_args_0 = {}
    module_args_0['gather_subset'] = []
    module_args_0['filter'] = u'test_filter'
    module_args_0['gather_network_resources'] = 'True'
    module_args_0['config'] = {}
    module_args_0['_ansible_check_mode'] = 'False'
    module_args_0['gather_network_resources'] = 'False'
    module_args_0['_ansible_debug'] = 'False'
    module_args_0['_ansible_diff'] = 'False'
    module_args_0['_ansible_verbosity'] = '0'
    module_args_0['_ansible_version'] = '2.4.2'

# Generated at 2022-06-24 22:39:39.252816
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = {}
    str_0 = ''
    dict_1 = {}
    dict_2 = {}
    bytes_0 = b'A\xce% \x93\xbe\xc7\x8dt\xe9\x87\xdb\xe6\xe1\x9b\xcf\xd65'
    a_i_x_network_0 = AIXNetwork(bytes_0)
    str_1 = a_i_x_network_0.get_interfaces_info(str_0, dict_0)
