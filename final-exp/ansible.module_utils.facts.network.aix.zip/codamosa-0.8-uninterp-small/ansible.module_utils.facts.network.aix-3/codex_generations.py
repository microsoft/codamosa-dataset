

# Generated at 2022-06-24 22:30:00.950145
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Input data for the testcase
    """
    test_input = dict(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )
    """
    Expected output of the testcase
    """

# Generated at 2022-06-24 22:30:02.276686
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:30:04.613238
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:30:13.904233
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces, ips = AIXNetwork().get_interfaces_info()

# Generated at 2022-06-24 22:30:23.924894
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    a_i_x_network_0 = AIXNetwork()

# Generated at 2022-06-24 22:30:33.688443
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()

# Generated at 2022-06-24 22:30:44.910224
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector = AIXNetworkCollector()
    a_i_x_network = AIXNetwork(a_i_x_network_collector.module)

    # Set up mock_route with side_effects
    mock_route = a_i_x_network_collector.module.run_command
    mock_route.side_effect = [('0', 'default 0.0.0.0 UG 0 0 0 ib0', ''),
                              ('0', 'default 2001:db8:a0b:12f0:: UG 0 0 0 ib0', '')]

    a_i_x_network.route_path = 'route'

    result_0 = a_i_x_network.get_default_interfaces('route')

# Generated at 2022-06-24 22:30:53.730284
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module = MockModule()
    a_i_x_network_0.module.run_command = Mock(return_value=(0, 'default 10.0.0.1 10.0.0.2 UG 30 0 en0\ndefault 192.0.2.1 192.0.2.2 UG 30 1 en1\ndefault 192.168.0.1 192.168.0.2 UG 30 2 en2', ''))
    route_path_0 = a_i_x_network_0.module.get_bin_path('route')

# Generated at 2022-06-24 22:30:58.351144
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()
    route_path = ""
    assert a_i_x_network.get_default_interfaces(route_path) is not None


# Generated at 2022-06-24 22:31:01.337389
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

# unit test for get_interfaces_info in AIX network module

# Generated at 2022-06-24 22:31:18.859352
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network = AIXNetwork()

    a_i_x_network.module = object()
    a_i_x_network.module.run_command = object()
    a_i_x_network.module.run_command.return_value = [0, 'default 172.20.0.1 UGd xl0', '']
    a_i_x_network.module.get_bin_path = object()
    a_i_x_network.module.get_bin_path.return_value = '/usr/bin/netstat'

    result = a_i_x_network.get_default_interfaces('/sbin/route')

    assert result == ({'gateway': '172.20.0.1', 'interface': 'xl0'}, {})



# Generated at 2022-06-24 22:31:30.026461
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    config_block_0 = 'an1: flags=8802<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'
    config_block_1 = 'an2: flags=8803<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'
    config_block_2 = 'an3: flags=8803<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'
    config_block_3 = 'an4: flags=8803<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'
    config_block_4 = 'an5: flags=8803<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'
    config_block_5 = 'agpgart0: mtu 1500'

# Generated at 2022-06-24 22:31:32.430924
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AIXNetworkCollector()

    test_module.get_interfaces_info('/sbin/ifconfig', '-a')


# Generated at 2022-06-24 22:31:36.717645
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector_0 = AIXNetworkCollector()
    if not isinstance(aix_network_collector_0, AIXNetworkCollector):
        raise AssertionError(
            f'Failed: Did not create a AIXNetworkCollector instance')
    assert aix_network_collector_0._platform == 'AIX'
    assert isinstance(aix_network_collector_0._fact_class, AIXNetwork)



# Generated at 2022-06-24 22:31:47.336289
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # First test, empty output
    test_i_f_c_output = ''
    test_i_f_c_path = 'a_path'
    test_i_f_c_options = '-a'
    a_i_x_network_0 = AIXNetwork()
    (test_result_1, test_result_2) = a_i_x_network_0.get_interfaces_info(test_i_f_c_path, test_i_f_c_options)
    assert test_result_1 == {}
    assert test_result_2 == dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    # Second test, valid output

# Generated at 2022-06-24 22:31:53.660041
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    i_face = dict(v4={}, v6={})


# Generated at 2022-06-24 22:31:55.808082
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()



# Generated at 2022-06-24 22:32:03.978213
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test case for method get_default_interfaces
    of class AIXNetwork
    """

    netstat_path = '/usr/sbin/netstat'
    route_path = ''
    a_i_x_network_0 = AIXNetwork(netstat_path, route_path)
    a_i_x_network_0.module.run_command = run_command
    a_i_x_network_0._interfaces = {'en0': {}, 'en1': {}}

    a_i_x_network_0.get_default_interfaces(route_path)



# Generated at 2022-06-24 22:32:06.344113
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    aix_network = AIXNetwork()
    ifconfig_path = aix_network.module.get_bin_path('ifconfig')
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path)

test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:32:10.065386
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module.run_command = run_command_test
    result = a_i_x_network_0.get_interfaces_info('/sbin/ifconfig','')
    assert result[0] ==  {}
    assert result[1] ==  {}



# Generated at 2022-06-24 22:32:38.116486
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert a_i_x_network_collector._fact_class == AIXNetwork
    assert a_i_x_network_collector._platform == 'AIX'


# Generated at 2022-06-24 22:32:44.687764
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    result = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert result is not None # if you got None - it is bad result of this test


# Generated at 2022-06-24 22:32:49.038684
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()


# Generated at 2022-06-24 22:32:53.267434
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-24 22:32:59.584593
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = a_i_x_network_collector_0.get_network_facts()
    v4, v6 = a_i_x_network_0.get_default_interfaces('/usr/sbin/route')


# Generated at 2022-06-24 22:33:00.789063
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass


# Generated at 2022-06-24 22:33:03.461962
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    a_i_x = AIXNetwork()

    assert a_i_x.get_interfaces_info('test') == ({}, {})



# Generated at 2022-06-24 22:33:04.767489
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-24 22:33:05.587185
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    assert True


# Generated at 2022-06-24 22:33:11.273388
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    interface, interface_v6 = a_i_x_network_collector_0._fact_class.get_default_interfaces(route_path = 'route')
    print('interface: {0}'.format(interface))
    assert interface == {'gateway': '172.16.0.1', 'interface': 'en1'}



# Generated at 2022-06-24 22:33:43.150844
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_interfaces_info(int_0)


# Generated at 2022-06-24 22:33:46.497435
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:33:49.221285
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:33:55.414601
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'J8UNb+XHv@h'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)


# Generated at 2022-06-24 22:33:58.753444
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ro_0 = '|'
    a_i_x_network_0 = AIXNetwork(ro_0)
    str_0 = 'j'
    str_1 = '\x9d'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0, str_1)


# Generated at 2022-06-24 22:34:07.723105
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        int_0 = -4196
        str_0 = 'c?<X{7f)RE'
        a_i_x_network_0 = AIXNetwork(str_0)
        var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    except systemd.error.ProcessLookupError as var_3:
        var_1 = None
    except systemd.error.InvalidArgumentError as var_9:
        var_2 = None
    except systemd.Error as var_11:
        var_4 = None
    except SystemExit as var_13:
        var_5 = None
    except Exception as var_15:
        var_6 = None
    finally:
        return var_0


# Generated at 2022-06-24 22:34:10.476529
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:34:14.087043
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:34:17.372374
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    c = AIXNetworkCollector()
    if c is not None:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-24 22:34:22.085011
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    print(var_0) #var_0

test_case_0()
test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:35:19.179362
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -14225
    str_0 = '9{(3+c]P'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)

# Generated at 2022-06-24 22:35:23.617426
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork('test')
    var_0 = a_i_x_network_0.get_interfaces_info(-9)


# Generated at 2022-06-24 22:35:25.861269
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 757
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.get_interfaces_info(int_0)

# Generated at 2022-06-24 22:35:30.056366
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 14604
    str_0 = '8Wg3Tq'
    a_i_x_network_0 = AIXNetwork(str_0)
    int_1 = -6406
    dict_0 = {
    }
    dict_1 = a_i_x_network_0.get_interfaces_info(int_0, dict_0)


# Generated at 2022-06-24 22:35:32.466759
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'Cl<Bf+V7.D'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)
    assert a_i_x_network_collector_0._platform == 'AIX'

# Generated at 2022-06-24 22:35:35.594976
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = '&$n#'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)
    return a_i_x_network_collector_0

if __name__ == '__main__':
    print(test_AIXNetworkCollector())

# Generated at 2022-06-24 22:35:39.049671
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)
    var_0 = a_i_x_network_collector_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:35:43.097149
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    var_1 = AIXNetworkCollector()
    assert var_1.platform == 'AIX'
    assert var_1._fact_class == AIXNetwork
    assert var_1._platform == 'AIX'


# Generated at 2022-06-24 22:35:48.553692
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 12063
    str_0 = 'F(1xQ_'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)

if __name__ == "__main__":
    test_case_0()
    test_AIXNetwork_get_default_interfaces()

# Generated at 2022-06-24 22:35:52.604178
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, int_0)


# Generated at 2022-06-24 22:37:36.316461
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 3
    str_0 = 'H}b+{cgq|y'
    str_1 = ';D!X}K'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_1 = a_i_x_network_0.get_interfaces_info(int_0, str_1)
    for var_2 in var_1:
        print(var_2)
    

# Generated at 2022-06-24 22:37:41.234163
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = '::o&'
    str_1 = '-a'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    str_0 = 'w>~'
    str_1 = '0M'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    str_0 = 'w>~'
    str_1 = '-4P+'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network

# Generated at 2022-06-24 22:37:50.532537
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_1 = 5231771
    str_1 = '!o"&"('
    a_i_x_network_1 = AIXNetwork(str_1)
    var_1 = a_i_x_network_1.get_default_interfaces(int_1)
    var_2 = AIXNetwork.get_default_interfaces(a_i_x_network_1, int_1)
    int_2 = -1522362743
    str_2 = '0B|'
    a_i_x_network_2 = AIXNetwork(str_2)
    var_3 = a_i_x_network_2.get_default_interfaces(int_2)

# Generated at 2022-06-24 22:37:58.104919
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'M4Qt$:F'
    int_0 = -13576
    str_1 = 'D'
    a_i_x_network_0 = AIXNetwork(str_1)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, int_0)
    assert var_0[0] == {}
    assert var_0[1] == {}


# Generated at 2022-06-24 22:38:01.005759
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -14112
    str_0 = 'd![0r0'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)

# Generated at 2022-06-24 22:38:05.852752
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path_0 = '$n0Ij+V7'
    int_0 = -47678
    str_0 = '\x1d\x1a'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_interfaces_info(ifconfig_path_0, int_0)
    print("HI")


# Generated at 2022-06-24 22:38:06.737893
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True


# Generated at 2022-06-24 22:38:11.068211
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -4196
    str_0 = 'c?<X{7f)RE'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_default_interfaces(int_0)
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(int_0)

# Generated at 2022-06-24 22:38:20.802142
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Testing the methods
    int_0 = -7204
    str_0 = 'V'
    str_1 = 'sRXC~'
    str_2 = 'm.\r'
    str_3 = 'sqq3'
    str_4 = 'M*<x'
    str_5 = '%Y\x01'
    # Testing the options
    a_i_x_network_0 = AIXNetworkCollector(str_1)
    a_i_x_network_0.get_interfaces_info(str_0, str_2)

    # Testing the options
    a_i_x_network_0 = AIXNetworkCollector(str_1)
    a_i_x_network_0.get_interfaces_info(str_0, str_3)

    # Testing the

# Generated at 2022-06-24 22:38:23.779742
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -3745
    str_0 = 'b(9KWY|P<R'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_interfaces_info(int_0)
