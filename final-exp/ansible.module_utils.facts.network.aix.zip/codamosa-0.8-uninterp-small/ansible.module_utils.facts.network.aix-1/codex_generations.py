

# Generated at 2022-06-24 22:29:57.189228
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    is_it_true = 0
    try:
        float_0 = AIXNetworkCollector._fact_class
        float_0 = AIXNetworkCollector._platform
        float_0 = AIXNetworkCollector._facts
        float_0 = AIXNetworkCollector._get_facts
        is_it_true += 1
    except:
        is_it_true = 0
    finally:
        print(is_it_true)


# Generated at 2022-06-24 22:30:00.872314
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    float_0 = 2309.0
    a_i_x_network_collector_0 = AIXNetworkCollector(float_0)
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:30:05.073743
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork(0)
    a_i_x_network_0.get_interfaces_info('ifconfig')


# Generated at 2022-06-24 22:30:09.379119
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    float_0 = 2309.0
    a_i_x_network_0 = AIXNetwork(float_0)
    a_i_x_network_0.module.run_command = lambda string: ['', '', '']
    assert a_i_x_network_0.get_default_interfaces('') == (None, None)


# Generated at 2022-06-24 22:30:11.026312
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector.__bases__[0].__name__
    assert result == 'NetworkCollector'


# Generated at 2022-06-24 22:30:21.911413
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Setup:

    # Setup: mock to return
    from ansible.module_utils.facts.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    mock_ifconfig_path = "ansible_facts.network.base.NetworkCollector.get_bin_path.return_value"
    mock_ifconfig_options = "ansible_facts.network.aix.AIXNetwork.get_interfaces_info.ifconfig_options"
    mock_ifconfig_options_value = "-a"
    mock_get_bin_path = "ansible_facts.network.base.NetworkCollector.get_bin_path"
    mock_get_bin_path_return_value = "/usr/sbin/sbin/ifconfig"
    mock_get_bin_path.return_value = mock_get_bin_path

# Generated at 2022-06-24 22:30:26.777162
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'netstat'
    float_0 = 2309.0
    a_i_x_network_0 = AIXNetwork(float_0)
    dict_0, dict_1 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:30:30.970100
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    float_0 = 2309.0
    a_i_x_network_0 = AIXNetwork(float_0)
    # assert a_i_x_network_0.get_default_interfaces(route_path) == (interface['v4'], interface['v6'])


# Generated at 2022-06-24 22:30:38.748205
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    float_0 = 2309.0
    a_i_x_network_0 = AIXNetwork(float_0)
    route_path = '1'
    assert_equal(a_i_x_network_0.get_default_interfaces(route_path), (None, None))
    assert a_i_x_network_0.get_default_interfaces(route_path) is None



# Generated at 2022-06-24 22:30:39.819662
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True


# Generated at 2022-06-24 22:31:01.209765
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_interfaces_info(list_1)
    assert var_0 == (None, None)


# Generated at 2022-06-24 22:31:05.719015
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector('foo')

# Generated at 2022-06-24 22:31:09.221827
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test code here

    aix_network_0 = AIXNetwork("wW)VuR'x")

    result = aix_network_0.parse_status_line(list(), dict(), dict())

    assert result is None

# Generated at 2022-06-24 22:31:15.675783
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_2)
    var_0 = a_i_x_network_collector_0.get_device_data(list_1, set_0)

# Generated at 2022-06-24 22:31:18.117145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'vn\x1f2'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)


# Generated at 2022-06-24 22:31:21.364255
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _platform = 'AIX'
    _fact_class = AIXNetwork
    fact_collector = AIXNetworkCollector(_platform, _fact_class)

# Generated at 2022-06-24 22:31:23.206889
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:31:32.682141
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '9^j.'
    str_2 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_2]
    set_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector(list_0, list_1, set_0)
    str_3 = 'BB6eoKw"~9F+'
    str_4 = '9^j.'
    str_5 = '`A:$n,C^:N&xQ_dI\t'

# Generated at 2022-06-24 22:31:38.569898
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = ['127.0.0.1', '::1']
    tuple_0 = (list_0, None)
    a_i_x_network_0 = AIXNetwork('0')
    var_0 = a_i_x_network_0.get_interfaces_info(tuple_0)


# Generated at 2022-06-24 22:31:49.239214
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'd'
    str_1 = '&Y?Z_v3q0)^]5*#\x0c'
    str_1 = '_>'
    str_2 = '\x00\x7f\x18t\x19\x1d\x0e\x1e,'
    list_0 = [str_0, str_1, str_1]
    list_0 = [str_2, str_1, str_0]
    list_1 = [list_0, str_0]
    a_i_x_network_0 = AIXNetwork(str_1)
    str_0 = 'k=Oy@I$\x0c'
    str_1 = str()
    str_1 = str(str_0)
    var_0 = a_

# Generated at 2022-06-24 22:32:19.811727
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
  str_0 = '^`~j'
  str_1 = '9IaLI'
  a_i_x_network_0 = AIXNetwork('Y#0-ye')
  var_0 = a_i_x_network_0.get_default_interfaces(str_0)
  assert var_0 == (str_1, 'j2\u0016<\u001b\u001a\u000fN\x1b\x0b')


# Generated at 2022-06-24 22:32:22.832529
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:32:31.824774
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = ''
    str_1 = 'w$1'
    str_2 = 'Z7e'
    list_0 = [str_1, str_2]
    set_0 = set(list_0)
    tuple_0 = (str_2, set_0)
    a_i_x_network_0 = AIXNetwork(tuple_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    var_1 = a_i_x_network_0.get_default_interfaces(str_0)
    var_2 = a_i_x_network_0.get_default_interfaces(str_0)
    var_3 = a_i_x_network_0.get_default_interfaces(str_0)

# Generated at 2022-06-24 22:32:38.492166
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'J|Z0>Uds$M<n:h'
    list_0 = [str_0]
    str_1 = '4D&`Es'
    a_i_x_network_0 = AIXNetwork(str_1)
    tuple_0 = (list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(tuple_0)


# Generated at 2022-06-24 22:32:44.173002
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'ppH[9X'
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0.get_interfaces_info([], [])


# Generated at 2022-06-24 22:32:51.724422
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_6 = 'm>8DyPV$LH}/v7'
    list_5 = [str_6, str_6, str_6]
    str_7 = 'd4.s!DKa?b_'
    list_6 = [list_5, str_7]
    a_i_x_network_2 = AIXNetworkCollector(list_6)


# Generated at 2022-06-24 22:33:02.443799
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:33:10.852639
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = '"1Oe'
    str_1 = '|Eq>O^7D_!n\t<'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = 'TdTb'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_default_interfaces(list_1)


# Generated at 2022-06-24 22:33:17.299504
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_interfaces_info(list_1, set_0)


# Generated at 2022-06-24 22:33:19.859264
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:34:11.477413
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_class = AIXNetworkCollector._fact_class
    fact_platform = AIXNetworkCollector._platform
    kwargs = {}
    ansible_module_0 = AnsibleModule(argument_spec=kwargs)
    a_i_x_network_collector_0 = AIXNetworkCollector(ansible_module_0)
    ansible_module_0.exit_json(ansible_facts={'ansible_network_resources': a_i_x_network_collector_0.get_facts()})

# Generated at 2022-06-24 22:34:19.419349
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'xkQ\tS^2G'
    str_1 = 'q3X|l'
    list_0 = [str_0, str_1, str_1]
    list_1 = [str_1, str_0, list_0]
    a_i_x_network_0 = AIXNetwork(list_1)
    str_2 = '*W0+0'
    str_3 = '6h'
    set_0 = None
    var_0 = a_i_x_network_0.get_interfaces_info(str_2, set_0)


# Generated at 2022-06-24 22:34:25.969214
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = 'HAv#R0]^@Y}/'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_interfaces_info(list_1, set_0)
    a_i_x_network_0.get_default_interfaces(list_1)

# Generated at 2022-06-24 22:34:27.875076
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    print(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:34:32.691140
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = '~'
    str_1 = 'Ef_#'
    list_0 = [str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = 'vU8G'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_default_interfaces(list_1)


# Generated at 2022-06-24 22:34:40.125013
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # This test is not complete.
    # Add this line to run this test:
    # ansible.module_utils.facts.network.aix.test_AIXNetworkCollector()
    # However, this test passes
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_collector_0._collect()

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:34:46.214050
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = '8W~ '
    str_1 = '#<:6'
    list_0 = [str_0, str_1]
    str_2 = '6u1FQ,m<:Id\\mF'
    a_i_x_network_0 = AIXNetwork(str_2)
    tuple_0 = a_i_x_network_0.get_default_interfaces(list_0)
    str_3 = 'KP`|:M>'
    str_4 = 'B5F*)}'
    list_1 = [str_3, str_4]
    str_5 = 'yH1'
    a_i_x_network_1 = AIXNetwork(str_5)
    tuple_1 = a_i_x_network_1.get_default_

# Generated at 2022-06-24 22:34:55.447279
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'lo'
    str_1 = '127.0.0.1'
    str_2 = '255.0.0.0'
    str_3 = 'lo'
    str_4 = 'Ethernet0'
    str_5 = '172.17.0.3'
    str_6 = '172.17.0.1'
    str_7 = '172.17.0.2'
    str_8 = '2001:0db8:85a3:0000:0000:8a2e:0370:7334'
    str_9 = 'en0'
    str_10 = 'en0'
    str_11 = 'fe80::a00:27ff:fe8a:2570'

# Generated at 2022-06-24 22:35:01.082770
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'S2$\''
    str_1 = '.'
    list_0 = [str_0, str_1]
    set_0 = None
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0, var_1 = a_i_x_network_0.get_default_interfaces(list_0)
    assert a_i_x_network_0._fact_class == 'AIX'


# Generated at 2022-06-24 22:35:01.944692
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # prepare the test environment
    test_case_0()


# Generated at 2022-06-24 22:36:32.570294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Test empty constructor
    assert (AIXNetworkCollector())
    print ("test_AIXNetworkCollector(): PASSED")


# Generated at 2022-06-24 22:36:43.132299
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = '<~A/QW['
    a_i_x_network_collector_0 = AIXNetworkCollector()
    var_0 = a_i_x_network_collector_0.get_facts()
    assert var_0['all_ipv6_addresses'] == []
    var_1 = a_i_x_network_collector_0.get_facts()
    assert var_1['ansible_net_all_ipv4_addresses'] == ['127.0.0.1']
    var_2 = a_i_x_network_collector_0.get_facts()
    assert var_2['all_ipv4_addresses'] == ['127.0.0.1']
    var_3 = a_i_x_network_collector_0.get_

# Generated at 2022-06-24 22:36:51.067493
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_0)
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    str_2 = 'BB6eoKw"~9F+'
    list_0 = [str_1, str_2, str_2]

# Generated at 2022-06-24 22:36:55.877839
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    str_3 = 'v'
    str_4 = 'l'
    a_i_x_network_0.get_interfaces_info(list_1, set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_4)

# Generated at 2022-06-24 22:37:01.976405
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Calling AIXNetwork(<args>) creates the network object
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    # Call get_interfaces_info to get the dictionary of interfaces
    var_0 = a_i_x_network_0.get_interfaces_info(list_1, set_0)
    print(var_0)


# Generated at 2022-06-24 22:37:02.441283
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True

# Generated at 2022-06-24 22:37:08.465236
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = [None, None]
    str_0 = '`=%S\'53S%2'
    a_i_x_network_0 = AIXNetwork(str_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:37:14.397322
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # The following two lines might be needed if a particular condition is not satisfied
    # in the above test_case_0 function
    #a_i_x_network_0 = AIXNetwork('9^j.')
    #a_i_x_network_0.get_interfaces_info([['BB6eoKw"~9F+', 'BB6eoKw"~9F+', '`A:$n,C^:N&xQ_dI\t'], '`A:$n,C^:N&xQ_dI\t'], None)
    assert False


# Generated at 2022-06-24 22:37:22.642726
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    str_3 = '\{-T#W^B'
    var_0 = a_i_x_network_0.get_default_interfaces(str_3)


# Generated at 2022-06-24 22:37:29.065328
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'BB6eoKw"~9F+'
    str_1 = '`A:$n,C^:N&xQ_dI\t'
    list_0 = [str_0, str_0, str_1]
    list_1 = [list_0, str_1]
    set_0 = None
    str_2 = '9^j.'
    a_i_x_network_0 = AIXNetwork(str_2)
    var_0 = a_i_x_network_0.get_interfaces_info(list_1, set_0)
