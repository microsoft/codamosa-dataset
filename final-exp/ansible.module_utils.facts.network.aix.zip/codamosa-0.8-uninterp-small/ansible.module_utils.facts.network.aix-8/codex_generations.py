

# Generated at 2022-06-24 22:29:50.184215
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass

# Generated at 2022-06-24 22:30:00.398450
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module = MagicMock(name='module')
    a_i_x_network_0.module.get_bin_path = MagicMock(return_value=None)
    type(a_i_x_network_0).platform = PropertyMock(return_value='AIX')

    try:
        a_i_x_network_0.get_default_interfaces('route_path')
    except TypeError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-24 22:30:11.501920
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

    rc, out, err = a_i_x_network_0.module.run_command([ifconfig_path, ifconfig_options])
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    for line in out.splitlines():

        if line:
            words = line.split()

            # only this condition differs from GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:30:17.350973
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # A minimal test that the AIXNetwork class is present and has the correct get_interfaces_info method
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_get_interfaces_info_0 = a_i_x_network_0.get_interfaces_info('/usr/sbin/ifconfig')
    print(a_i_x_network_get_interfaces_info_0)

# Generated at 2022-06-24 22:30:19.473623
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:23.048829
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = ''
    ifconfig_options = '-a'
    assert a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-24 22:30:24.122939
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:30:26.223662
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert callable(AIXNetworkCollector)


# Generated at 2022-06-24 22:30:26.876483
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True

# Generated at 2022-06-24 22:30:35.282429
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    a_i_x_network = AIXNetwork()

    # empty (AIX 7.1)
    out = '''
     lo0: flags=8008<loopback,mcast_pmtu> mtu 8232 index 10
           inet 127.0.0.1 netmask 0xff000000
    '''

    interfaces, ips = a_i_x_network.get_interfaces_info('ifconfig', ifconfig_options='')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.255.0.0'

    # empty (AIX 6.1)

# Generated at 2022-06-24 22:30:52.785678
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set)


# Generated at 2022-06-24 22:30:58.257718
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Set up mock
    a_i_x_network_0 = AIXNetworkCollector()
    a_i_x_network_0.get_default_interfaces(arg_1=None)


# Generated at 2022-06-24 22:31:06.808188
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # check that get_interfaces_info works as expected
    ifconfig_path = '/usr/sbin/ifconfig' # TODO: check that this exists in the testing environment
    ifconfig_options = '-a'

    # ifconfig output example
    # lo0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
    #     inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
    #     nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    # en0: flags=1e080863,480<UP,BROAD

# Generated at 2022-06-24 22:31:09.799512
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    list_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(set_0, list_0)


# Generated at 2022-06-24 22:31:13.042878
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_1 = set()
    list_1 = []
    a_i_x_network_1 = AIXNetwork(list_1)
    var_1 = a_i_x_network_1.get_default_interfaces(set_1)


# Generated at 2022-06-24 22:31:19.044517
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)


# Generated at 2022-06-24 22:31:24.061832
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = set()
    var_1 = a_i_x_network_0.get_default_interfaces(var_0)
    assert isinstance(var_1, tuple)

# Generated at 2022-06-24 22:31:30.333972
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # pass
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    assert(var_0 == {"v4": {"gateway": "172.17.7.1", "interface": "lem0"}, "v6": {"gateway": "fe80::7cad:b6ff:feab:8b2a", "interface": "lem0"}})


# Generated at 2022-06-24 22:31:32.765130
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    result = a_i_x_network_0.get_interfaces_info([])



# Generated at 2022-06-24 22:31:35.245453
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_interfaces_info(set_0)

# Generated at 2022-06-24 22:32:00.918935
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert (isinstance(AIXNetworkCollector(), AIXNetworkCollector))


# Generated at 2022-06-24 22:32:02.583683
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert(isinstance(a_i_x_network_collector_0, AIXNetworkCollector))


# Generated at 2022-06-24 22:32:07.288274
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    list_0 = []
    set_0 = set()
    collector_0 = AIXNetworkCollector(set_0)
    collector_0.get_default_interfaces(list_0)
    dict_0 = dict()
    dict_1 = dict()
    var_0 = collector_0.populate(dict_0, dict_1)


# Generated at 2022-06-24 22:32:14.358749
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test case 1
    set_1 = set()
    list_1 = []
    a_i_x_network_1 = AIXNetwork(list_1)
    var_1 = a_i_x_network_1.get_interfaces_info(set_1)
    # Test case 2
    set_2 = set()
    list_2 = []
    a_i_x_network_2 = AIXNetwork(list_2)
    var_2 = a_i_x_network_2.get_interfaces_info(set_2)
    # Test case 3
    set_3 = set()
    list_3 = []
    a_i_x_network_3 = AIXNetwork(list_3)

# Generated at 2022-06-24 22:32:18.162885
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)

# Generated at 2022-06-24 22:32:23.761117
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_1 = set()
    list_1 = []
    a_i_x_network_1 = AIXNetwork(list_1)
    var_1 = a_i_x_network_1.get_default_interfaces(set_1)
    assert var_1 == ({}, {})


# Generated at 2022-06-24 22:32:26.728811
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_1 = a_i_x_network_0.get_interfaces_info(list_0)

# Generated at 2022-06-24 22:32:30.024996
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)


# Generated at 2022-06-24 22:32:32.623455
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    list_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(list_0)
    var_0 = a_i_x_network_collector_0.parse_interfaces(set_0)

# Generated at 2022-06-24 22:32:36.518951
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True


# Generated at 2022-06-24 22:33:25.483572
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector_0 = AIXNetworkCollector()
    assert isinstance(collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:33:27.263381
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    return obj

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:33:29.830619
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    list_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(list_0)
    var_0 = a_i_x_network_collector_0._platform


# Generated at 2022-06-24 22:33:34.054711
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_ = AIXNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:33:38.454403
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    list_0 = []
    AIXNetworkCollector(list_0)


main()

# Generated at 2022-06-24 22:33:44.193133
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    list_1 = []
    a_i_x_network_0 = AIXNetwork(list_1)
    var_0 = a_i_x_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 22:33:50.692229
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    list_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(list_0)
    var_0 = a_i_x_network_collector_0.get_default_interfaces(set_0)

if __name__ == '__main__':
    test_case_0()
    # test_AIXNetworkCollector()

# Generated at 2022-06-24 22:33:53.191381
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)


# Generated at 2022-06-24 22:34:00.052889
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:34:03.546562
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        set_0 = set()
        list_0 = []
        a_i_x_network_0 = AIXNetwork(list_0)
        var_0 = a_i_x_network_0.get_default_interfaces(set_0)
    except Exception as e_0:
        f_0 = open('/tmp/test_AIXNetwork_get_default_interfaces.log', 'w')
        f_0.write(str(e_0))
        f_0.close()


# Generated at 2022-06-24 22:35:43.447971
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)


# Generated at 2022-06-24 22:35:46.345120
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    list_1 = []
    a_i_x_network_0 = AIXNetwork(list_1)
    a_i_x_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 22:35:51.739420
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    target_res = a_i_x_network_0.get_interfaces_info(set_0)
    if target_res == (None, None):
        print('PASS')
        pass
    else:
        print('FAIL')
        pass


# Generated at 2022-06-24 22:35:55.948754
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    set_0 = set()
    a_i_x_network_0 = AIXNetwork(list_0)
    # Verify that this test case can be run independently, and will not
    # automatically run when the other tests are run
    var_0 = a_i_x_network_0.get_interfaces_info(set_0, '-a')


# Generated at 2022-06-24 22:36:01.452607
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    set_0 = set()
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    var_0 = a_i_x_network_0.get_default_interfaces(set_0)


# Generated at 2022-06-24 22:36:04.187377
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    list_0 = []

    obj = AIXNetworkCollector(list_0)

    # Test __init__ method for the class AIXNetworkCollector
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'



# Generated at 2022-06-24 22:36:10.836959
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    rc, out, err = a_i_x_network_0.module.run_command(['ifconfig', '-a'])
    if not rc:
        interfaces = a_i_x_network_0.get_interfaces_info(out)



# Generated at 2022-06-24 22:36:13.415768
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    set_1 = set()
    list_1 = []
    a_i_x_network_1 = AIXNetwork(list_1)
    a_i_x_network_1.get_interfaces_info(set_1)


# Generated at 2022-06-24 22:36:20.135167
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    cmd1 = ['ifconfig', '-a']
    rc = 0 # 0 is the return code for success

# Generated at 2022-06-24 22:36:22.175670
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    set_0 = set()
    list_0 = []
    a_i_x_network_collector_0 = AIXNetworkCollector(list_0)
    var_0 = a_i_x_network_collector_0.get_default_interfaces(set_0)