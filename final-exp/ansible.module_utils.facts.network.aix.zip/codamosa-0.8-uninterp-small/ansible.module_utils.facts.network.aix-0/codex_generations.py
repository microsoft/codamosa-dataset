

# Generated at 2022-06-24 22:30:02.228703
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    assert a_i_x_network_0.get_default_interfaces(route_path='route') == ( {'gateway': '10.17.124.254', 'interface': 'en0'}, {'gateway': 'fe80::216:3eff:fe12:8', 'interface': 'en0'})
    assert a_i_x_network_0.get_default_interfaces(route_path='route') == ( {'gateway': '10.17.124.254', 'interface': 'en0'}, {'gateway': 'fe80::216:3eff:fe12:8', 'interface': 'en0'})

# Generated at 2022-06-24 22:30:11.352948
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net_obj = AIXNetwork()
    a_i_x_network_collector_0 = AIXNetworkCollector()
    net_obj.module = a_i_x_network_collector_0.module
    route_path = '/usr/sbin/route'
    expected_result_0 = ({'gateway': '10.11.12.1', 'interface': 'en0'}, {'gateway': 'fe80::1%en0', 'interface': 'en0'})
    result_0 = net_obj.get_default_interfaces(route_path)
    assert result_0 == expected_result_0


# Generated at 2022-06-24 22:30:14.698963
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = NetworkModule()
    a_i_x_network_0 = AIXNetwork(module)
    a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:30:17.206208
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ai_x_network_0 = AIXNetwork()
    assert isinstance(ai_x_network_0.get_default_interfaces(None), tuple)


# Generated at 2022-06-24 22:30:18.527930
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 22:30:29.334094
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector, ansible_module_instance = get_a_i_x_network_collector()
    set_module_args(dict(gather_subset=['!all', '!min']), ansible_module_instance)
    a_i_x_network_collector.collect()
    assert a_i_x_network_collector._fact_class.get_default_interfaces('/sbin/route') is not None
    # Answer is:
    # v4 = {'gateway': '192.168.1.254', 'interface': 'en0'}
    # v6 = {'gateway': 'fe80::21e:52ff:fe6b:e611%en1', 'interface': 'en1'}


# Generated at 2022-06-24 22:30:32.745425
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/etc/ifconfig'
    ifconfig_options = '-a'
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-24 22:30:34.698732
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:30:38.666689
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector_0, NetworkCollector)


# Generated at 2022-06-24 22:30:40.137223
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network = AIXNetwork()
    assert a_i_x_network.get_interfaces_info(ifconfig_path="ifconfig")


# Generated at 2022-06-24 22:30:56.892052
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True


# Generated at 2022-06-24 22:31:02.841399
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:31:07.502440
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'l`s\x0b'
    float_0 = 986.01
    # bool_0 = False
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    # ai_1 = a_i_x_network_0.__init__()
    pass

# Generated at 2022-06-24 22:31:14.697094
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Initialize instance of class with name var_0
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)

    # Initialize bool var_0 with value False
    bool_0 = False

    # Call method get_interfaces_info of class AIXNetwork with arguments bool_0
    result = a_i_x_network_0.get_interfaces_info(bool_0)

    # Check for equality of var_0 return type bool
    assert type(result) is dict


# Generated at 2022-06-24 22:31:25.500206
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = 'zH\x1e\x07\x1a\x08\x00@\x0c\x03\x11\x06\x10\x00\x0b\x0b\x1a\x0f\x08\x00@\x0c\x03\x11\x06\x10\x00\x0b\x0b\x1a\x0f'
    float_0 = 841.4
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:31:30.220183
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = 'H\x7fWI\x1d\x1b]5\x15'
    float_0 = 727.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:31:34.926732
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:31:36.100552
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Create an object as follows
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:31:40.068319
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    str_0 = 'sV"Rl?wE1\x0c\x1b,7+u'
    float_0 = 0.6796865380769379
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:31:49.328808
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Define a class
    class AIXNetwork_get_default_interfacesImpl:
        def __init__(self):
            self.var = None
        def get_default_interfaces(self, param_0):
            str_0 = '\x0cD"vxT-Bp={6<vj'
            float_0 = 877.0
            a_i_x_network_0 = AIXNetwork(str_0, float_0)
            return a_i_x_network_0.get_interfaces_info(param_0)

    # Create object of class
    obj = AIXNetwork_get_default_interfacesImpl()

    # Test execution
    param_0 = 0
    obj.get_default_interfaces(param_0)


# Generated at 2022-06-24 22:32:23.452918
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
  # Define a test input
  float_0 = 3.1415

# Generated at 2022-06-24 22:32:29.187118
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    str_0 = 'a_i_x_network_0'
    float_0 = 522.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    a_i_x_network_collector_0 = AIXNetworkCollector(a_i_x_network_0)
    a_i_x_network_collector_0.get_facts()


# Generated at 2022-06-24 22:32:33.903602
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:32:36.243376
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net_0 = AIXNetwork("abcde", 7.0)
    net_0.get_default_interfaces("abc123")


# Generated at 2022-06-24 22:32:45.000796
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    print(a_i_x_network_collector_0)


# Generated at 2022-06-24 22:32:48.028304
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = '\xffv\x95\xbc>\x8d\xde\xea\xcd\xf0e'
    float_0 = 784.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:54.997367
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    bool_0 = False
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    assert var_0[0]['lo0']['macaddress'] == '00:00:00:00:00:00'
    assert var_0[0]['lo0']['device'] == 'lo0'
    assert var_0[0]['lo0']['type'] == 'Loopback'

# Generated at 2022-06-24 22:33:01.832808
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = 'a\n"\x13|\x7f\x1b\x7f\x02\x04\t\x0c'
    float_0 = 0.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    var_1 = a_i_x_network_0.get_interfaces_info(str_0)
    var_2 = a_i_x_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 22:33:04.201993
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert callable(AIXNetworkCollector)
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)


# Generated at 2022-06-24 22:33:10.924598
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    assert isinstance(var_0, tuple)


# Generated at 2022-06-24 22:34:02.030163
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    assert str(var_0) == "('', {})"


# Generated at 2022-06-24 22:34:11.395324
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    #
    # Setup testcase
    #
    if_cmd = '/bin/ifconfig'
    if_options = '-a'
    a_i_x_network_1 = AIXNetwork(if_cmd, if_options)
    #
    # Execute testcase
    #
    output = a_i_x_network_1.get_interfaces_info(if_cmd, if_options)
    #
    # Assertion that expected result matches actual result
    #

# Generated at 2022-06-24 22:34:17.013810
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    str_0 = "5'5}t)^\x1a"
    float_0 = 588.603348251481
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:34:21.236078
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:34:26.028706
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = 'Z'
    float_0 = 2095.893
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    a_i_x_network_0.get_interfaces_info(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)
    assert 'gateway' in var_0[0]

# Generated at 2022-06-24 22:34:29.708504
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)

# Generated at 2022-06-24 22:34:33.729779
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)
    assert not var_0


# Generated at 2022-06-24 22:34:38.268657
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)



# Generated at 2022-06-24 22:34:41.300546
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test for method get_default_interfaces (line 88) of class AIXNetwork
    assert True # TODO: implement your test here


# Generated at 2022-06-24 22:34:43.535467
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)


# Generated at 2022-06-24 22:36:17.672159
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 22:36:20.636807
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'Y3hG'
    float_0 = 8078.59
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    int_0 = 5272
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    assert var_0 == None


# Generated at 2022-06-24 22:36:30.659421
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Don't run on non-AIX systems
    if AIXNetwork._platform != 'AIX':
        return

    not_a_string_collection = [
        (1, None),
        ({}, None),
        ([], None),
        (1.1, None),
    ]
    for not_a_string_str_0, expected_var_0 in not_a_string_collection:
        a_i_x_network_collector_0 = AIXNetworkCollector(not_a_string_str_0)
        var_0 = isinstance(a_i_x_network_collector_0, AIXNetworkCollector)
        assert var_0 == expected_var_0


# Generated at 2022-06-24 22:36:36.799085
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    # AIXNetworkCollector.__init__()
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:36:40.932440
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        assert (AIXNetwork.get_default_interfaces('route_path') == ('V4', 'V6'))
    except AssertionError as e:
        print(e)


# Generated at 2022-06-24 22:36:46.584003
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    return None


# Generated at 2022-06-24 22:36:49.617834
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # This method raises an exception that it should not raise.
    try:
        AIXNetwork.get_interfaces_info
    except Exception as err:
        assert False, "AIXNetwork.get_interfaces_info raised an exception."


# Generated at 2022-06-24 22:36:56.033401
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = '\x0cD"vxT-Bp={6<vj'
    float_0 = 877.0
    a_i_x_network_0 = AIXNetwork(str_0, float_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:36:57.173751
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_case_0()


# Generated at 2022-06-24 22:37:01.741469
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    str_0 = '\x0e\x15\x0cJ;\x13\x1d\x0bac:Q9)'
    str_1 = '\x0f\x0a\x1bwUE\x12\x02V7\x0b\x07\x0c'
    float_0 = 44.0
    a_i_x_network_0 = AIXNetwork(str_0, str_1, float_0)
    (var_0, var_1) = a_i_x_network_0.get_default_interfaces(bool_0)
