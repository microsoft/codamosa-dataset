

# Generated at 2022-06-24 22:29:59.170897
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'qaE\x16\xeb\x06m\x14\x8d\x1f'
    a_i_x_network_0 = AIXNetwork(str_0)

    str_0 = 'E|s\xf6[Tb\xc1\x8c'
    str_1 = 'p\x1fI\xf6\x05\x84\x01\xaf0\x05\xaf\x1a\x11\xee8'

# Generated at 2022-06-24 22:30:04.845008
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    if _platform_ in ('AIX', 'Darwin'):
        test_case_0()

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:30:14.040863
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    str_0 = 'nR\x14\x11S\x0f.\x1b\x1c!{'
    x_value_0 = ['\x17\x0f\x14\x1c\x0b\x17\x07', '\x1f\x0c\x0e\x1c\x11\x17\x07']
    a_i_x_network_0 = AIXNetwork(str_0)
    a_i_x_network_0._module = PropertyMock(return_value=True)
    a_i_x_network_0.get_bin_path = MagicMock(return_value=True)
    a_i_x_network_0.module.run_command = MagicMock(return_value=x_value_0)
    a

# Generated at 2022-06-24 22:30:19.775397
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fact_network_0 = AIXNetwork(None)
    str_0 = 'en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500\n	ether 98:90:96:e2:a2:ec\n	media: autoselect ()\n	status: active\n'
    ifconfig_path_0 = '/sbin/ifconfig'
    ifconfig_options_0 = '-a'
    __retval_0, __retval_1 = fact_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)
    print(__retval_0)
    print(__retval_1)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-24 22:30:22.312760
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()

    # Try to obtain interface details.
    a_i_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:30:32.450347
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'Y}:j)`K,tjvR\x0c]a6\rf*'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)
    str_0 = '}'
    str_1 = 'D'
    str_2 = '5'
    str_3 = '"'
    str_4 = '!'
    str_5 = 'v'
    str_6 = '\x1a'
    str_7 = '`'
    str_8 = '\x0c'
    str_9 = '2'
    dict_0 = {}
    dict_0['device'] = str_4
    dict_0['ipv4'] = [str_6, str_7, str_0, str_2, str_1]


# Generated at 2022-06-24 22:30:36.602486
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'G@n;jL-H}m8W_g$m#r\x0f@'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)

    return


# Generated at 2022-06-24 22:30:47.299314
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:30:50.089603
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0


# Generated at 2022-06-24 22:30:50.930754
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:31:12.353973
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:31:13.870847
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass    # TODO: Implement test_AIXNetwork_get_interfaces_info


# Generated at 2022-06-24 22:31:14.696646
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    assert True


# Generated at 2022-06-24 22:31:20.769903
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Test for 'AIX' in platform
    a_i_x_network_0 = AIXNetwork()
    assert a_i_x_network_0.platform == 'AIX'

    # Test for 'default' in line

    # Test for '' in line
    a_i_x_network_0.get_interfaces_info(ifconfig_path='/sbin/ifconfig')


# Generated at 2022-06-24 22:31:28.919235
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = "/usr/sbin/ifconfig"
    ifconfig_options = "-a"
    result = a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)
    print("AIXNetwork.get_interfaces_info(/" + ifconfig_path + "/,/" + ifconfig_options + "/) = " + str(result))
    assert result == (('lo0', 'en0', 'en1', 'en2', 'p7p1'), (), (), ())



# Generated at 2022-06-24 22:31:30.720021
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()
    aix_network.get_interfaces_info('/usr/bin/ifconfig')

# Generated at 2022-06-24 22:31:39.166152
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    print("default_interfaces v4 = ", a_i_x_network_0.get_default_interfaces('/sbin/route')[0])
    print("default_interfaces v6 = ", a_i_x_network_0.get_default_interfaces('/sbin/route')[1])

# Unit test - run module as a standalone Python script
if __name__ == "__main__":
    from ansible.module_utils.facts.network.aix import test_case_0
    test_case_0()
    test_AIXNetwork_get_default_interfaces()

# Generated at 2022-06-24 22:31:43.042291
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    return a_i_x_network_collector


# Generated at 2022-06-24 22:31:47.383864
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path_0 = "gxKjZpHqAd"
    assert a_i_x_network_0.get_default_interfaces(route_path_0) == (
        {'gateway': '172.17.0.1'}, {'gateway': 'fe80::5', 'interface': 'lo0'})


# Generated at 2022-06-24 22:31:49.127028
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc_0 = AIXNetwork()
    ans_0 = ifc_0.get_interfaces_info('/usr/sbin/ifconfig')
    print(ans_0)

# Generated at 2022-06-24 22:32:07.560950
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = ""
    str_1 = " -a"
    a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert not hasattr(a_i_x_network_0, '_AIXNetwork__unknown_options')
    str_2 = ""
    str_3 = " -a"
    a_i_x_network_0.get_interfaces_info(str_2, str_3)
    assert hasattr(a_i_x_network_0, '_AIXNetwork__unknown_options')

if __name__ == '__main__':
    test_case_0()
    test_AIXNetwork_get_interfaces

# Generated at 2022-06-24 22:32:11.582412
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = '/usr/sbin/ifconfig'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0)
    print('Unit test variable "var_0": {0}'.format(var_0))


# Generated at 2022-06-24 22:32:17.000226
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:32:27.712919
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = None
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    a_i_x_network_1 = AIXNetwork(bool_0)
    var_1 = a_i_x_network_1.get_default_interfaces(int_0)
    bool_2 = bool(var_1)
    bool_3 = bool(var_0)
    bool_4 = bool_2 and bool_3
    var_3 = (var_1 and var_0)
    bool_5 = bool(var_3)
    bool_6 = bool_4 and bool_5
    bool_7 = bool_

# Generated at 2022-06-24 22:32:31.247965
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = '-'
    int_0 = None
    var_0 = a_i_x_network_0.get_interfaces_info(int_0, str_0)


# Generated at 2022-06-24 22:32:33.729692
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_interfaces_info('/sbin/ifconfig', '-a')

# Generated at 2022-06-24 22:32:45.081884
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'ifconfig'
    str_1 = '-a'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert len(var_0) == 2
    assert var_0[0]['ens0'] == {'macaddress': '02:42:ac:11:00:01', 'type': 'ether', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'device': 'ens0', 'mtu': '1500', 'ipv6': [], 'ipv4': []}


# Generated at 2022-06-24 22:32:48.840072
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    int_0 = None
    int_1 = 1
    int_2 = 2
    # Add your code here
    #
    # I need a real aix setup to make this work.
    #
    a_i_x_network_0.get_interfaces_info(int_0, int_1, int_2)
    a_i_x_network_1 = AIXNetwork(bool_0)

# Generated at 2022-06-24 22:32:49.604909
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:32:50.179549
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # No test implemented
    assert True


# Generated at 2022-06-24 22:33:20.273421
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = '-a'
    str_1 = 'ifconfig'
    a_i_x_network_0.get_interfaces_info(str_0, str_0)
    a_i_x_network_0.get_interfaces_info(str_1, str_0)
    a_i_x_network_0.get_interfaces_info(str_1, str_1)


# Generated at 2022-06-24 22:33:23.150488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_interfaces_info(str())
    a_i_x_network_1 = AIXNetwork(bool_0)


# Generated at 2022-06-24 22:33:25.722607
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

test_AIXNetworkCollector()
test_case_0()

# Ignore PycodestyleBear (W605)
# W605 invalid escape sequence '\.'
# W605 invalid escape sequence '\:'

# Generated at 2022-06-24 22:33:35.643579
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Set up mock for get_interfaces_info(ifconfig_path, ifconfig_options='-a'):
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils.get_file_content') as mock_get_file_content:
        mock_get_file_content.side_effect = [
            'en0: flags=AC28321c1 mtu 1500',
            'nd6 options=3',
            'ether 0060a26a9d9f',
            'lladdr <incomplete>',
            'media: autoselect (100baseTX <full-duplex>)'
        ]

        a_i_x_network_0 = AIXNetwork(True)

# Generated at 2022-06-24 22:33:39.883384
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module_path_vars = []
    if 'VIRTUAL_ENV' in os.environ:
        module_path_vars.append(os.environ['VIRTUAL_ENV'] + '/lib/python2.7/site-packages')
        module_path_vars.append(os.environ['VIRTUAL_ENV'] + '/lib/python3.5/site-packages')
    if 'VIRTUAL_ENV' not in os.environ:
        module_path_vars.append('/usr/lib/python2.7/site-packages')
        module_path_vars.append('/usr/lib64/python2.7/site-packages')
        module_path_vars.append('/usr/local/lib/python2.7/site-packages')
        module_path

# Generated at 2022-06-24 22:33:43.511036
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    assert True # constructed


# Generated at 2022-06-24 22:33:48.358191
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:33:51.936741
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = None
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    a_i_x_network_1 = AIXNetwork(bool_0)


# Generated at 2022-06-24 22:33:57.527013
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector = AIXNetworkCollector(bool_0)
    assert isinstance(a_i_x_network_collector, AIXNetworkCollector)
    assert isinstance(a_i_x_network_collector.fact_class, AIXNetwork)


# Generated at 2022-06-24 22:34:02.219155
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    
    # Verify that the method returns a dictionary of interfaces when called with
    # correct arguments
    bool_0 = True
    int_0 = None
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_1 = AIXNetwork(bool_0)
    str_0 = a_i_x_network_0.get_interfaces_info(int_0, int_0)[0]
    assert type(str_0) == dict
    assert not False if str_0 else False


# Generated at 2022-06-24 22:34:53.866186
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._fact_class is not None

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-24 22:34:58.821910
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = '/usr/sbin/ifconfig'
    str_1 = '-a'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:35:07.115502
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    bool_1 = False

    list_0 = ['non-existing-command', '-a']
    list_1 = ['ifconfig', '-a']

    # create temporary file for testing
    with open('/tmp/ansible_file_sample_3.txt', 'w') as f:
        f.write('\n')
        f.write('en1: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>\n')
        f.write('        mtu 1500 index 1\n')

# Generated at 2022-06-24 22:35:10.397117
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = None
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    a_i_x_network_1 = AIXNetwork(bool_0)


# Generated at 2022-06-24 22:35:17.265784
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = None
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)
    a_i_x_network_1 = AIXNetwork(bool_0)


# Generated at 2022-06-24 22:35:19.174606
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

if __name__ == "__main__":
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:35:25.111246
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector_0 = AIXNetworkCollector(False)
    # AssertionError: _racoon_socket failed: [Errno 2] No such file or directory: '/var/etc/racoon/racoon.sock'
    assert (aix_network_collector_0 != None)


# Generated at 2022-06-24 22:35:31.652332
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    int_0 = None
    bool_1 = False

    a_i_x_network_0 = AIXNetwork(bool_1)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    a_i_x_network_1 = AIXNetwork(bool_0)
    var_1 = a_i_x_network_1.get_interfaces_info(int_0)

    if var_0[1]['all_ipv4_addresses'].__len__() != var_1[1]['all_ipv4_addresses'].__len__():
        assert False


# Generated at 2022-06-24 22:35:33.687334
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)

test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:35:34.359496
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    p = AIXNetworkCollector()

# Generated at 2022-06-24 22:37:11.010616
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:37:13.668797
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    a_i_x_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 22:37:20.563488
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    int_0 = 0
    str_0 = ''
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(str_0, int_0)
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 22:37:23.723011
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = False
    int_0 = 0        # null
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:37:30.463124
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/bin/ifconfig'
    route_path = '/usr/bin/netstat'
    a_i_x_network_0 = AIXNetwork(True)
    var_0 = a_i_x_network_0.get_default_interfaces(route_path)
    print(var_0)


# Generated at 2022-06-24 22:37:31.673785
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:37:32.369525
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-24 22:37:34.944010
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:37:39.179880
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = None
    bool_1 = False
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_collector_0.populate()
    a_i_x_network_collector_1 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:37:49.248214
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = False
    bool_1 = False
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'Test String'
    str_1 = ''
    str_2 = 'Test String'
    str_3 = 'E$:QP'
    a_i_x_network_0.module.run_command = (lambda str_0, str_1: (0, str_2, str_3))
    str_4 = 'Test String'
    str_5 = ''
    str_6 = 'Test String'
    str_7 = 'E$:QP'
    a_i_x_network_0.module.run_command = (lambda str_0, str_1: (0, str_6, str_7))