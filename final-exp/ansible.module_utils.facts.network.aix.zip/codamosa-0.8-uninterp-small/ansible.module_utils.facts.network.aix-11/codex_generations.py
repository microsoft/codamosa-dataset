

# Generated at 2022-06-24 22:29:52.883870
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()



# Generated at 2022-06-24 22:29:57.732291
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test for getting default interfaces
    """
    a_i_x_network_0 = AIXNetwork()

    a_i_x_network_0.get_default_interfaces('route_path')


# Generated at 2022-06-24 22:30:02.094352
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert a_i_x_network_collector_0.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-24 22:30:04.544636
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork_instance = AIXNetwork()
    result = AIXNetwork_instance.get_default_interfaces('/usr/sbin/route')
    assert isinstance(result, tuple)


# Generated at 2022-06-24 22:30:13.860560
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()

    # Testing for correct return value with correct parameters
    f = open('data/aix/ifconfig_-a.txt', 'r')
    in_data = f.read()
    a_i_x_network_0.module.run_command.return_value = (0, in_data, None) 
    out_data_1, out_data_2 = a_i_x_network_0.get_interfaces_info('/usr/sbin/ifconfig')
    f.close()
    f = open('data/aix/get_interfaces_info_output.txt', 'r')
    out_data_3 = f.read()
    f.close()
    assert out_data_1 == eval(out_data_3)
    assert out

# Generated at 2022-06-24 22:30:22.354610
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_1 = AIXNetworkCollector()
    a_i_x_network_0 = AIXNetwork()
    method_call_result_0 = a_i_x_network_0.get_default_interfaces('route_path')
    assert method_call_result_0[0] == 'gateway4', "Expected `'gateway4'`, got {0}".format(method_call_result_0[0])
    assert method_call_result_0[1] == 'gateway6', "Expected `'gateway6'`, got {0}".format(method_call_result_0[1])


# Generated at 2022-06-24 22:30:26.866076
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path = '/usr/sbin/route'
    assert isinstance(a_i_x_network_0.get_default_interfaces(route_path), tuple)


# Generated at 2022-06-24 22:30:29.374663
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:30:30.900860
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:33.194077
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    print('\n<==== test_AIXNetwork_get_interfaces_info ====')
    ai_x_network_collector = AIXNetworkCollector()
    ai_x_network_collector.get_interfaces_info()


# Generated at 2022-06-24 22:30:47.676661
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:30:58.340453
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = '/sbin/ifconfig'
    str_1 = '-a'
    str_2 = '=[Mk6Ux;6'
    str_3 = 'NbX8*sih'
    str_4 = 'ekj=e8x'
    long_0 = 0
    str_5 = '0'
    long_1 = 0
    bytearray_0 = bytearray(str_4, 'utf-8')
    str_6 = 'e'
    a_i_x_network_0 = AIXNetwork(str_5)
    var_2 = a_i_x_network_0.get_interfaces_info(str_0, str_1, str_2, str_3, long_0, long_1, str_6)

# Generated at 2022-06-24 22:31:06.844930
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'x1nRmRz{H.`Gp'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'iwm5'
    str_2 = 'g1'
    str_3 = 'Fyda'
    var_0 = a_i_x_network_0.get_default_interfaces(str_3)
    str_4 = '8@W9gTt$sR'
    str_5 = '-a'
    str_6 = '1'
    str_7 = 'pEiOqo%c~'
    str_8 = ':'
    str_9 = 'U6P_'
    str_10 = '`G'
    dict_0 = dict()


# Generated at 2022-06-24 22:31:09.027242
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 22:31:11.552756
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'

if __name__ == '__main__':
    test_case_0()
    # Unit test for constructor of class AIXNetworkCollector
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:15.729291
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    str_0 = 'cSeries'
    a_i_x_network_0 = AIXNetwork(bool_0, str_0)
    a_i_x_network_collector_0 = AIXNetworkCollector(a_i_x_network_0)


if __name__ == '__main__':
#    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:24.230459
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'Mk[J'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    var_0 = a_i_x_network_1.get_default_interfaces(str_0)
    var_1 = a_i_x_network_1.get_default_interfaces(str_0)
    assert var_0 == var_1


# Generated at 2022-06-24 22:31:26.964858
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        test_case_0()
    except Exception as inst:
        print(inst)
        pass

# Generated at 2022-06-24 22:31:33.032814
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = False
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0)
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


test_case_0()

# Generated at 2022-06-24 22:31:41.283015
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 0
    str_0 = 'fpc'
    str_1 = 'p^H3M{Tyl5'
    str_2 = ':='
    str_3 = '=^2uVw#'
    str_4 = '/'
    str_5 = 'cJ(1Xa$0'
    str_6 = 'z'
    str_7 = '?'
    str_8 = 'DBD6/C8W'
    str_9 = 'N"TQeU^'
    str_10 = ':&D|XR'
    str_11 = 'q3~%K#;'
    str_12 = '2'
    str_13 = '$'
    str_14 = ':'
    str_15 = 'nwjK5mY'
   

# Generated at 2022-06-24 22:32:09.992859
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    str_2 = 'no-carrier'
    int_0 = a_i_x_network_1.get_interfaces_info(str_0, str_2)
    print(int_0)


# Generated at 2022-06-24 22:32:11.627592
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    return a_i_x_network_collector_0


# Generated at 2022-06-24 22:32:19.596478
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_collector_0.data_from_lspci()
    a_i_x_network_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    # test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:26.773728
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    int_0 = 0
    int_1 = 0
    str_0 = 'AIX'
    str_1 = 'AIX'
    var_0 = a_i_x_network_0.get_interfaces_info(int_0, int_1, str_0, str_1)


# Generated at 2022-06-24 22:32:31.053507
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    arg_0 = 'a'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = ''
    str_1 = str(a_i_x_network_0.get_default_interfaces(arg_0, str_0))
    assert str_1 is not None


# Generated at 2022-06-24 22:32:36.835901
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module_0 = None
    bool_0 = True
    a_i_x_network_1 = AIXNetworkCollector(module_0, bool_0)
    assert a_i_x_network_1._fact_class == AIXNetwork
    assert a_i_x_network_1._platform == 'AIX'
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'ppcpseries'
    a_i_x_network_2 = AIXNetwork(a_i_x_network_0, str_0)
    module_1 = None
    a_i_x_network_3 = AIXNetworkCollector(module_1, a_i_x_network_2)
    assert a_i_x_network_3._fact_class == AIXNetwork

# Generated at 2022-06-24 22:32:44.639362
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    var_0 = a_i_x_network_1.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:32:51.497934
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)


# Generated at 2022-06-24 22:32:58.046105
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Case when no parameter is passed
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:33:04.124752
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    if_config_path = "/usr/sbin/ifconfig"
    route_path = "/usr/sbin/route"
    flag_1 = True
    a_i_x_network_1 = AIXNetwork(flag_1)
    a_i_x_network_1.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:33:57.413227
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.utilities.tools import convert
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'pen0'
    bool_1 = True
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, bool_1)
    var_1 = a_i_x_network_0.get_interfaces_info(str_0)
    str_1 = 'en0'
    bool_2 = False
    var_2 = a_i_x_network_0.get_interfaces_info(str_1, bool_2)
    str_2 = 'en0'
    bool_3 = True
    var_3 = a_i_x_network

# Generated at 2022-06-24 22:34:02.999538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'u'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    str_2 = '8\t'
    var_0 = a_i_x_network_1.get_default_interfaces(str_2)
    assert not var_0


# Generated at 2022-06-24 22:34:11.450796
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Init
    str_0 = '164JFaD_+'
    str_1 = '0'
    str_2 = '{+t4J4-h'  # /usr/sbin/ifconfig -a
    str_3 = 'l|&Jc5^5'  # 2.2.1
    str_4 = '>j8Svb+|'  # unknown
    str_5 = 'I#+-Lo]p'  # down
    str_6 = 'l*eTpZ0z'  # ether
    str_7 = 'j!yq&rxQ'
    str_8 = '%_u#_)U6'  # /usr/sbin/netstat -nr
    str_9 = '9'
    str_10 = 'pdK7VpH)'

# Generated at 2022-06-24 22:34:16.192223
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'UH0e#n>f\x7f'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:34:18.162736
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    print('Testing get_default_interfaces()')
    test_case_0()

test_AIXNetwork_get_default_interfaces()

# Generated at 2022-06-24 22:34:25.816400
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test case 1
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    var_0 = a_i_x_network_1.get_default_interfaces(str_0)
    # Check that the result is not empty
    assert var_0 is not None
    # Check that the result is a dictionary
    assert type(var_0) == type({})
    # Check that the result is a dictionary having the right keys

# Generated at 2022-06-24 22:34:33.060348
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    if_0 = 'btbb'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_0)
    a_i_x_network_2 = AIXNetwork(bool_0)
    str_1 = 'ac'
    a_i_x_network_3 = AIXNetwork(a_i_x_network_2, str_1)
    str_2 = '0'
    bool_1 = True
    a_i_x_network_4 = AIXNetwork(bool_1)
    str_3 = 'loopback'

# Generated at 2022-06-24 22:34:35.645099
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

test_AIXNetworkCollector()
test_case_0()

# Generated at 2022-06-24 22:34:42.539460
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    var_0 = a_i_x_network_1.get_default_interfaces(str_0)



# Generated at 2022-06-24 22:34:47.873211
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    str_2 = 'n|'
    a_i_x_network_1.get_interfaces_info(str_0, str_2)

test_case_0()
test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:36:26.994281
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    print('Starting test_AIXNetwork_get_default_interfaces...')
    test_case_0()
    print('Completed test_AIXNetwork_get_default_interfaces')


# Generated at 2022-06-24 22:36:32.378319
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = '/usr/sbin/ifconfig'
    bool_0 = True
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0, bool_0)
    assert a_i_x_network_collector_0.fact_class.platform == 'AIX'
    assert a_i_x_network_collector_0._platform == 'AIX'
    a_i_x_network_collector_1 = AIXNetworkCollector(a_i_x_network_collector_0)
    assert a_i_x_network_collector_1.fact_class.platform == 'AIX'
    assert a_i_x_network_collector_1.fact_class._platform == 'AIX'
    assert a_i_x_network_collector_1

# Generated at 2022-06-24 22:36:38.756607
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork(False)
    str_0 = 'fZDqIMh2b'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:36:40.896282
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    domain_0 = 'c4k'
    a_i_x_network_collector_0 = AIXNetworkCollector(domain_0)


# Generated at 2022-06-24 22:36:42.986491
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:36:50.707523
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_3 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_4 = AIXNetwork(a_i_x_network_3, str_1)
    str_2 = 'UL8I$k,m5'
    a_i_x_network_5 = AIXNetwork(a_i_x_network_4, str_2)
    str_3 = 'w^0_r/q[~='
    a_i_x_network_5.get_interfaces_info(str_3)


# Generated at 2022-06-24 22:36:52.019922
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:36:57.273701
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'p^H3M{Tyl5'
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_1 = 'ppcpseries'
    a_i_x_network_1 = AIXNetwork(a_i_x_network_0, str_1)
    str_2 = 'ifconfig'
    var_0 = a_i_x_network_1.get_interfaces_info(str_2)


# Generated at 2022-06-24 22:36:58.627521
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert True


# Generated at 2022-06-24 22:37:01.936356
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    str_0 = 'z@}L0^qO|'
    a_i_x_network_collector_0 = AIXNetworkCollector(str_0)

if __name__ == '__main__':
    # Unit tests for all classes
    test_case_0()
    test_AIXNetworkCollector()