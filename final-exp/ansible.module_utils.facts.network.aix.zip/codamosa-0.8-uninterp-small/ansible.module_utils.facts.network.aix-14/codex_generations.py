

# Generated at 2022-06-24 22:29:47.806818
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert result != None


# Generated at 2022-06-24 22:29:48.930658
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:29:56.470366
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = 'default'
    str_1 = 'default'
    str_2 = 'default'
    str_3 = 'default'
    interface_0, interface_1 = a_i_x_network_0.get_default_interfaces(str_0, str_1, str_2, str_3)


# Generated at 2022-06-24 22:29:58.476761
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector, (NetworkCollector, object))



# Generated at 2022-06-24 22:30:00.948813
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    a_i_x_network_collector = AIXNetworkCollector(bool_0)


# Generated at 2022-06-24 22:30:04.698392
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetworkcollector_0 = AIXNetworkCollector()
    assert aixnetworkcollector_0.platform == 'AIX'


# Generated at 2022-06-24 22:30:08.712833
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = '6e.U'
    tuple_0 = a_i_x_network_0.get_default_interfaces(str_0)
    print(tuple_0)


# Generated at 2022-06-24 22:30:10.663262
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector(None)
    assert a_i_x_network_collector_0 is not None


# Generated at 2022-06-24 22:30:15.356434
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    a_i_x_network_0 = AIXNetwork(bool_0)
    str_0 = "ifconfig"
    str_1 = "-a"
    a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:30:16.300569
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-24 22:30:31.028883
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:30:34.981714
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = a_i_x_network_collector_0.get_network_facts()

    for interface_name, iface in a_i_x_network_0.items():
        buff = ''
        for k, v in iface.items():
            buff = buff + '\ninterface_name: {} k: {} v: {}'.format(interface_name, k, v)
        print(buff)



# Generated at 2022-06-24 22:30:39.216349
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    assert a_i_x_network_0.get_default_interfaces('/sbin/route') == ([], [])


# Generated at 2022-06-24 22:30:43.616741
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_net = AIXNetwork()
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    res = a_i_x_net.get_interfaces_info(ifconfig_path, ifconfig_options)
    print(res)



# Generated at 2022-06-24 22:30:47.678986
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    _ifconfig_path = '/usr/sbin/ifconfig'
    _ifconfig_options = '-a'
    a_i_x_network_0._get_interfaces_info(_ifconfig_path, _ifconfig_options)


# Generated at 2022-06-24 22:30:55.688303
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    # Set up mock
    route_path_0 = 'route_path_0'
    with patch('ansible.module_utils.facts.network.aix.AIXNetwork.module') as mock_module_0:
        route_path_1 = 'route_path_1'
        a_i_x_network_0.module.get_bin_path = MagicMock(side_effect=[route_path_0, route_path_1])

# Generated at 2022-06-24 22:30:59.062419
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    # failed because it needs to run on AIX
    # so, not a real test
    a_i_x_network_0.get_interfaces_info(None)

# Generated at 2022-06-24 22:31:10.058665
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-24 22:31:18.342636
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ans_if = {'v4': {'gateway': '10.0.0.1', 'interface': 'en0'}, 'v6': {'gateway': 'fe80::200:ff:fe00:1', 'interface': 'en0'}}
    a_i_x_network_0 = AIXNetwork(module=None)
    assert ans_if == a_i_x_network_0.get_default_interfaces('route_path')


# Generated at 2022-06-24 22:31:19.577370
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:31:37.337644
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnetwork_collector_0 = AIXNetworkCollector()
    assert aixnetwork_collector_0 is not None


# Generated at 2022-06-24 22:31:47.981524
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    uname_rc = None
    uname_out = None
    uname_err =  None
    uname_path = None
    if uname_path:
        uname_rc, uname_out, uname_err = None
    rc, out, err = None
    for line in out.splitlines():
        words = line.split()

        # only this condition differs from GenericBsdIfconfigNetwork
        if re.match(r'^\w*\d*:', line):
            current_if = None
            interfaces['device'] = current_if

# Generated at 2022-06-24 22:31:48.668776
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
  test_case_0()


# Generated at 2022-06-24 22:31:49.878316
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert isinstance(AIXNetwork.get_default_interfaces(AIXNetwork()), tuple)


# Generated at 2022-06-24 22:31:55.521243
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    assert a_i_x_network_0.get_default_interfaces(list_0) is not None


# Generated at 2022-06-24 22:31:59.350139
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    # assertIsInstance(AIXNetworkCollector(), AIXNetworkCollector)


# Generated at 2022-06-24 22:32:02.913940
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    a_i_x_network_0.get_default_interfaces(['', '', '', '', ''])
    assert_equal(a_i_x_network_0.interfaces, a_i_x_network_0.interfaces)


# Generated at 2022-06-24 22:32:06.367777
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    obj.get_network_facts()
    obj.get_default_interfaces()
    obj.get_interfaces_info()
    obj.get_interfaces_info()



# Generated at 2022-06-24 22:32:07.985324
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _fact_class = AIXNetwork
    _platform = 'AIX'
    test_case_0()



# Generated at 2022-06-24 22:32:10.010342
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector, AIXNetworkCollector)


# Generated at 2022-06-24 22:32:38.451333
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    list_0 = [a_i_x_network_0, a_i_x_network_0, a_i_x_network_0]
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:32:43.138332
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_collect_network = AIXNetworkCollector()
    assert ansible_collect_network._fact_class is AIXNetwork


test_case_0()

# Generated at 2022-06-24 22:32:54.126584
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # assert not isinstance(AIXNetwork, object)
    assert 'method' in dir(AIXNetwork)
    a_i_x_network = AIXNetwork({AIXNetworkCollector()})
    list_0 = [a_i_x_network, a_i_x_network, a_i_x_network, a_i_x_network]
    assert a_i_x_network.get_default_interfaces(list_0) == (
        {'interface': 'en0', 'gateway': '10.10.10.21'},
        {'interface': 'en0', 'gateway': 'fe80::2c6e:e6ff:fed6:d60f'}
    )



# Generated at 2022-06-24 22:33:02.588560
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(list_0)
    # var_0 is a tuple of var_0[0] and var_0[1]
    # var_0[0] is dict of dicts
    #

# Generated at 2022-06-24 22:33:11.823103
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:33:18.900084
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)
    assert var_0 is None


# Generated at 2022-06-24 22:33:21.015883
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    options = {}
    a_i_x_network_collector_0 = AIXNetworkCollector(options)
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:33:22.188562
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()

if __name__ == "__main__":
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:33:24.648936
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class._platform == 'AIX'


# Generated at 2022-06-24 22:33:31.312685
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    set_0 = {a_i_x_network_collector, a_i_x_network_collector, a_i_x_network_collector, a_i_x_network_collector,
             a_i_x_network_collector, a_i_x_network_collector, a_i_x_network_collector, a_i_x_network_collector}
    a_i_x_network = AIXNetwork(set_0)

# Generated at 2022-06-24 22:34:28.164284
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    uname_path = '/usr/bin/uname'
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(list_0)
    print(var_0)

# Generated at 2022-06-24 22:34:30.366872
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    str_0 = 'x'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_0)


# Generated at 2022-06-24 22:34:32.905410
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_1 = AIXNetwork(set_0)
    var_2 = a_i_x_network_1.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:34:35.412052
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:34:39.828711
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_1 = AIXNetwork()
    set_0 = a_i_x_network_1.get_interfaces_info('str_0', 'str_1')
    assert set_0[0]['str_0']['device'] == 'str_1'
    assert set_0[0]['str_0']['type'] == 'unknown'
    assert set_0[0]['str_0']['ipv6'] == ['str_0']
    assert set_0[1]['all_ipv6_addresses'] == ['str_0']
    assert set_0[0]['str_0']['macaddress'] == 'unknown'
    assert set_0[0]['str_0']['ipv4'] == ['str_0']
    assert set_0

# Generated at 2022-06-24 22:34:44.570933
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    try:
        test_case_0()
    except SystemExit:
        pass



# Generated at 2022-06-24 22:34:46.277074
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert a_i_x_network_collector_0 != None
    assert list_0 != None
    assert set_0 != None
    assert a_i_x_network_0 != None
    assert var_0 != None


# Generated at 2022-06-24 22:34:55.470711
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_3 = AIXNetwork()

    # Test with a list of netstat outputs

# Generated at 2022-06-24 22:35:06.770476
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.aix.aix_network import AIXNetwork

    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.get_interfaces_info(list_0)

# Unit test

# Generated at 2022-06-24 22:35:10.589087
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    set_0 = {a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info([])
    print(var_0)


# Generated at 2022-06-24 22:36:56.070194
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_default_interfaces(list_0)
    assert var_0 == (None, None), "Incorrect return value for method get_default_interfaces"
    return var_0 == (None, None)



# Generated at 2022-06-24 22:37:02.112975
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_2 = AIXNetworkCollector()
    list_1 = [a_i_x_network_collector_2, a_i_x_network_collector_2, a_i_x_network_collector_2, a_i_x_network_collector_2]
    set_1 = {a_i_x_network_collector_2, a_i_x_network_collector_2}
    a_i_x_network_1 = AIXNetwork(set_1)
    list_0 = list_1[:-1]
    set_0 = {a_i_x_network_collector_2, a_i_x_network_1}
    a_i_x_network_2 = AIXNetwork(set_0)
    var_

# Generated at 2022-06-24 22:37:11.012137
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i_x_network_0.get_interfaces_info(list_0)

# Generated at 2022-06-24 22:37:13.980948
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork({AIXNetworkCollector()})
    var_0 = a_i_x_network_0.get_default_interfaces({GenericBsdIfconfigNetwork()})
    assert var_0 == (None, None)


# Generated at 2022-06-24 22:37:21.700045
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    set_0 = set()
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector) == True
    assert a_i_x_network_collector_0.routes == ()
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0.interfaces == ()
    assert a_i_x_network_collector_0._fact_class == AIXNetwork
    assert isinstance(a_i_x_network_collector_0.facts, dict) == True
    assert len(a_i_x_network_collector_0.facts) == 0


# Generated at 2022-06-24 22:37:29.384458
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = 'bin/ifconfig'
    route_path = 'bin/route'
    ifconfig_options = '-a'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    rc, out, err = 'rc', 'out', 'err'
    lines = 'lines'
    words = ['words']
    entstat_path = 'bin/entstat'
    lsattr_path = 'bin/lsattr'
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    var_0 = a_i

# Generated at 2022-06-24 22:37:30.848553
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    try:
        a_i_x_network_collector_0 = AIXNetworkCollector()
    except:
        assert False


# Generated at 2022-06-24 22:37:36.047266
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    assert not a_i_x_network_0.get_default_interfaces(list_0)



# Generated at 2022-06-24 22:37:38.432665
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
  list_0 = [AIXNetworkCollector(), AIXNetworkCollector(), AIXNetworkCollector()]
  a_i_x_network_0 = AIXNetwork(set(list_0))
  var_0 = a_i_x_network_0.get_default_interfaces(list_0)


# Generated at 2022-06-24 22:37:47.831251
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    list_0 = [a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0, a_i_x_network_collector_0]
    set_0 = {a_i_x_network_collector_0, a_i_x_network_collector_0}
    a_i_x_network_0 = AIXNetwork(set_0)
    a_i_x_network_0.get_default_interfaces(list_0)
