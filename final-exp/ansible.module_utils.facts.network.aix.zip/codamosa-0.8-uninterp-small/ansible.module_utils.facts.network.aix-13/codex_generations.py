

# Generated at 2022-06-24 22:29:57.632828
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    my_file_0 = open('/tmp/ansible_AIXNetwork_payload', 'r')
    my_object_0 = FilePayload(my_file_0)
    my_list_0 = list(my_object_0)

    my_file_1 = open('/tmp/ansible_AIXNetwork_payload', 'r')
    my_object_1 = FilePayload(my_file_1)
    my_list_1 = list(my_object_1)

    my_file_2 = open('/tmp/ansible_AIXNetwork_payload', 'r')
    my_object_2 = FilePayload(my_file_2)
    my_list_2 = list(my_object_2)

    # Save the currently running config to disk

# Generated at 2022-06-24 22:30:01.676777
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:04.747276
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class == AIXNetwork


# Generated at 2022-06-24 22:30:06.341294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:10.145771
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # There is no need to test this method.
    # It is identical to the one in GenericBsdIfconfigNetwork
    pass



# Generated at 2022-06-24 22:30:11.548328
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()
    aix_network.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-24 22:30:14.020565
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    # initialize instance for AIXNetworkCollector


# Generated at 2022-06-24 22:30:24.073294
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_collector = AIXNetwork()
    interfaces, ips = test_collector.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

    assert len(interfaces) > 0
    assert 'el0' in interfaces
    assert interfaces['el0']['type'] == 'ether'
    assert interfaces['el0']['mtu'] == '1500'
    assert interfaces['el0']['macaddress'] == '01:23:45:67:89:AB'
    assert interfaces['el0']['status'] == 'active'
    assert interfaces['el0']['ipv4'] == ['192.168.2.10/21']
    assert interfaces['el0']['flags'] == ['BROADCAST', 'UP', 'NOTRAILERS', 'SIMPLEX']


# Generated at 2022-06-24 22:30:28.420420
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path = '/usr/sbin/route'

    # try:
    # except Exception as e:
    #     raise AssertionError(e) from None


# Generated at 2022-06-24 22:30:33.054201
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # 1) Test if gateway is returned and interface name is not changed
    a_i_x_network_0 = AIXNetwork()
    assert a_i_x_network_0.get_default_interfaces(route_path='route')[0] == {'interface': 'en0', 'gateway': '10.22.0.1'}
    assert a_i_x_network_0.get_default_interfaces(route_path='route')[1] == {'interface': 'en0', 'gateway': 'fe80::1'}


# Generated at 2022-06-24 22:30:44.769211
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:45.714603
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass


# Generated at 2022-06-24 22:30:49.036635
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:30:56.644317
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_1 = a_i_x_network_0.get_interfaces_info(str_0)
    if 'en0' in var_1:
        assert var_1['en0']['mtu'] == '1500'
    if 'en0' in var_1:
        assert var_1['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'AUTOCONFIGURED']

# Generated at 2022-06-24 22:31:02.640610
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -1719
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = 'lCf)fcI[x'
    str_1 = '@c%GY'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:31:06.796088
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -1365
    str_0 = 'environ'
    str_1 = 'ifconfig'
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:31:16.177552
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -63330
    str_0 = '*-^T?$P'
    str_1 = '*&QG?'
    str_2 = '.'
    str_3 = '\x7f\x81\x8a\x92\x96\x9a\xa1\xa7\xae\xb4\xb9\xbd\xc4\xca\xd0\xd4'
    str_4 = 'mS'
    str_5 = 'Q'
    str_6 = '\x91\x9a\xa3\xaa\xb2\xba\xc1\xc9\xd0\xd8\xe0\xe7\xef\xf6'

# Generated at 2022-06-24 22:31:17.118332
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()

# Generated at 2022-06-24 22:31:21.529354
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork(1337)
    str_0 = 'environ'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:31:29.501407
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)

    # Test case 0
    assert(a_i_x_network_0.get_interfaces_info('ifconfig')[0])
    # Test case 1
    assert(a_i_x_network_0.get_interfaces_info(str_0)[1])
    # Test case 2
    assert(a_i_x_network_0.get_interfaces_info(str_0, str_0)[0])


# Generated at 2022-06-24 22:31:53.091076
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Test for method get_default_interfaces
    if isinstance(test_case_0(), tuple):
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:31:59.323617
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -1883
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = 'xn8W_Pd'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)



# Generated at 2022-06-24 22:32:01.393680
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert callable(getattr(AIXNetworkCollector, '_fact_class')), "_fact_class is not a method of AIXNetworkCollector"
    assert isinstance(AIXNetworkCollector._fact_class, type), "_fact_class is not a type of AIXNetworkCollector"


# Generated at 2022-06-24 22:32:04.672661
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'jK=C'
    int_0 = -74524
    a_i_x_network_0 = AIXNetwork(int_0)
    str_1 = 'MGwSJ'
    str_2 = 'tLF8x'
    a_i_x_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:32:13.776599
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -32
    str_0 = 'f'
    str_1 = 'p'
    str_2 = 'vif'
    str_3 = '<'
    list_0 = list()
    list_0.append(str_3)

    a_i_x_network_0 = AIXNetwork(int_0)
    a_i_x_network_0.module = MagicMock()
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert len(var_0) == 2
    assert len(var_0[0]) == 4

# Generated at 2022-06-24 22:32:22.304447
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -1
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = '<WRAPPER>'
    str_1 = '<WRAPPER>'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert 'str_0' in var_0
    assert 'str_1' in var_0
    assert 'str_0' in var_0
    assert 'str_1' in var_0


# Generated at 2022-06-24 22:32:24.612588
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector._fact_class is AIXNetwork
    assert net_collector._platform is 'AIX'


# Generated at 2022-06-24 22:32:28.305874
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:31.518435
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:34.590624
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = 'ifconfig_path'
    ifconfig_options = 'ifconfig_options'
    int_0 = -1366
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-24 22:33:22.133895
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = '/usr/bin/ifconfig'
    str_1 = '-a'
    int_0 = 795
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0, var_1 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:33:24.399436
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:33:25.020462
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    cnt = AIXNetworkCollector()
    assert cnt._platform == 'AIX'

# Generated at 2022-06-24 22:33:31.036495
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'mtu'
    str_1 = ':'
    str_2 = '/'
    str_3 = 'nd6'
    str_4 = 'ether'
    str_5 = 'media'
    str_6 = 'status'
    str_7 = 'options'
    str_8 = 'lladdr'
    str_9 = 'inet'
    str_10 = 'inet6'
    int_0 = 6561
    int_1 = -7456
    int_2 = 16003
    a_i_x_network_0 = AIXNetwork(int_2)
    var_0 = a_i_x_network_0.get_interfaces_info(str_9, str_0)


# Generated at 2022-06-24 22:33:35.279724
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _platform = AIXNetworkCollector._platform
    _fact_class = AIXNetworkCollector._fact_class
    var_0 = AIXNetworkCollector(int(_platform), int(_fact_class))
    return var_0

if __name__ == '__main__':
    test_AIXNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 22:33:36.882200
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'n'
    int_0 = -917
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:33:43.767123
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    str_1 = 'ifconfig'
    str_2 = '-a'
    var_0 = a_i_x_network_0.get_interfaces_info(str_1, str_2)

# Generated at 2022-06-24 22:33:53.359713
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    str_1 = 'ifconfig_path'
    str_2 = 'ifconfig_options'
    str_3 = 'ifconfig_path'
    str_4 = 'ifconfig_options'
    str_5 = 'environ'
    int_1 = -1365
    a_i_x_network_1 = AIXNetwork(int_1)
    var_1 = a_i_x_network_1.get_interfaces_info(str_3, str_4)
    str_6 = 'environ'

# Generated at 2022-06-24 22:33:55.833122
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -1368
    str_0 = 'diam'
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:34:00.881015
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = -1365
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)


# Generated at 2022-06-24 22:35:29.095176
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._fact_class == AIXNetwork
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class._platform == 'AIX'

test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:35:30.449284
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector('environ')


# Generated at 2022-06-24 22:35:35.092706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module_1 = None
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_collector_0 = AIXNetworkCollector(module_1)
    var_0 = a_i_x_network_collector_0.get_default_interfaces(str_0)

# Generated at 2022-06-24 22:35:40.229350
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    str_1 = '-a'
    int_0 = -1132
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)
    assert var_0[0] == {}
    assert var_0[1] == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}



# Generated at 2022-06-24 22:35:41.660328
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert callable(AIXNetworkCollector)


# Generated at 2022-06-24 22:35:45.295333
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class == AIXNetwork


# Generated at 2022-06-24 22:35:49.009734
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:35:54.348445
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = -1414
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = '--'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:35:59.638549
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    int_0 = -1365
    str_0 = '3$c0'
    str_1 = '&.'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0,str_1)

if __name__ == '__main__':
    test_case_0()
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:36:03.874787
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'xvwcqpff'
    str_1 = 'yhvit'
    int_0 = -1746
    a_i_x_network_0 = AIXNetwork(int_0)
    var_1 = a_i_x_network_0.get_interfaces_info(str_0, str_1)

# Generated at 2022-06-24 22:38:58.324029
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = './test/files/aix_ifconfig.txt'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0)

if __name__ == '__main__':
    test_case_0()
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:38:59.016747
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()



# Generated at 2022-06-24 22:39:04.674441
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    str_1 = 'path'
    str_2 = 'options'
    var_0 = a_i_x_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:39:06.357514
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # print('ENTERING test_AIXNetworkCollector')
    var_0 = AIXNetworkCollector()
    # print('LEAVING test_AIXNetworkCollector')


# Generated at 2022-06-24 22:39:09.017766
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'environ'
    int_0 = -1365
    a_i_x_network_0 = AIXNetwork(int_0)
    str_1 = 'ifconfig'
    str_2 = '-a'
    var_0 = a_i_x_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:39:15.326079
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Unit test for method get_default_interfaces of class AIXNetwork
    # TODO: Update testcase after aiossh fix
    return

    str_1 = 'environ'
    int_1 = -1242
    a_i_x_network_1 = AIXNetwork(int_1)
    var_1 = a_i_x_network_1.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:39:21.296200
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    str_0 = 'a'
    int_0 = -2133
    a_i_x_network_0 = AIXNetwork(int_0)
    str_1 = 'Tq{J'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:39:23.672672
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = -1264
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:39:26.243135
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_collector_0 = AIXNetworkCollector()
    var_0 = aix_collector_0._fact_class

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:39:31.206768
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test case 0

    # Create an instance of AIXNetwork
    a_i_x_network_0 = AIXNetwork(int())
    str_0 = 'environ'

    # Call method: get_default_interfaces with argument environ
    a_i_x_network_0.get_default_interfaces(str_0)
