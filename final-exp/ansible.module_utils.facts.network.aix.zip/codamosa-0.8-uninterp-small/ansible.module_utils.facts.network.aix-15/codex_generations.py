

# Generated at 2022-06-24 22:29:49.148128
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    assert AIXNetwork(None).get_interfaces_info('/bin/ls')



# Generated at 2022-06-24 22:29:51.531942
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:02.567842
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-24 22:30:12.627021
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    a_i_x_network_0.module = list()
    str_0 = 'netstat'
    a_i_x_network_0.module.get_bin_path = lambda str_1: None
    str_1 = 'ifconfig'
    a_i_x_network_0.module.run_command = lambda list_1: (None, None, None)
    str_2 = '-a'
    result = a_i_x_network_0.get_interfaces_info(str_0, str_1, str_2)
    assert result[0] == {}
    assert result[1]['all_ipv4_addresses'] == []

# Generated at 2022-06-24 22:30:14.911235
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    list_0 = []
    a_i_x_network_collector = AIXNetworkCollector(list_0)


# Generated at 2022-06-24 22:30:23.511674
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    config_lines = [
        '#!/usr/bin/python',
        '# -*- coding: utf-8 -*-',
        'msg = "hello world"',
        'print(msg)',
        '#comment'
    ]
    expected_output = [
        '#!/usr/bin/python',
        '# -*- coding: utf-8 -*-',
        'msg = "hello world"',
        'print(msg)',
        ''
    ]
    a_i_x_network_0 = AIXNetwork(config_lines)
    a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:30:25.439202
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
  # Replace 'pass' for your unit test
  assert(True)


# Generated at 2022-06-24 22:30:28.798746
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
   assert isinstance(AIXNetworkCollector, object)

# Generated at 2022-06-24 22:30:30.028454
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:30:35.714051
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    list_0 = []
    a_i_x_network_0 = AIXNetwork(list_0)
    assert isinstance(a_i_x_network_0, AIXNetwork)
    str_0 = a_i_x_network_0.get_interfaces_info('/usr/local/bin/ifconfig -a')
    assert isinstance(str_0, tuple)
    assert len(str_0) == 2
    assert not hasattr(str_0, '__call__')
    assert len(str_0[0]) == 7
    assert len(str_0[1]) == 2
    str_1 = a_i_x_network_0.get_interfaces_info('/usr/local/bin/ifconfig -a')
    assert str_0 == str_1
    str_2 = a_

# Generated at 2022-06-24 22:30:50.559799
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 2642
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = 'SvS1y+'
    int_1 = 2633
    a_i_x_network_0.get_interfaces_info(str_0, int_1)


# Generated at 2022-06-24 22:30:53.850136
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
  aix_network_collector_0 = AIXNetworkCollector()
  var_0 = aix_network_collector_0.get_all_facts()

test_case_0()
test_AIXNetworkCollector()

# Generated at 2022-06-24 22:30:56.727475
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = 2444
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)
    print(a_i_x_network_collector_0._platform)

if __name__ == "__main__":
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:01.049413
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 918
    aix_network_0 = AIXNetwork(int_0)
    var_0 = aix_network_0.get_interfaces_info('/usr/sbin/ifconfig', '-a')


# Generated at 2022-06-24 22:31:09.270930
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        int_1 = 2644
        a_i_x_network_1 = AIXNetwork(int_1)
        bool_1 = True
        assert a_i_x_network_1.get_default_interfaces(bool_1) == (None, None)
    except AssertionError as e: print(e)
    try:
        int_1 = 2644
        a_i_x_network_1 = AIXNetwork(int_1)
        bool_1 = True
        assert a_i_x_network_1.get_default_interfaces(bool_1) == (None, None)
    except AssertionError as e: print(e)


# Generated at 2022-06-24 22:31:12.291358
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 4978
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)
    assert (str(type(var_0)) == "<class 'tuple'>")


# Generated at 2022-06-24 22:31:14.767165
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = 2644
    fact_network_collector_0 = AIXNetworkCollector(int_0)
    var_0 = fact_network_collector_0.get_defaults()

# Generated at 2022-06-24 22:31:17.951447
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 661
    a_i_x_network_0 = AIXNetwork(int_0)
    a_i_x_network_0.get_default_interfaces(bool_0)



# Generated at 2022-06-24 22:31:22.810126
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:31:25.622450
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_collector_0 = AIXNetworkCollector(bool_0, int_0)
    assert isinstance(a_i_x_network_collector_0, NetworkCollector)

if __name__ == "__main__":
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:31:51.304673
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)
    bool_1 = True
    int_1 = 0
    var_0 = a_i_x_network_collector_0.get_interfaces_info(bool_0, int_1)


# Generated at 2022-06-24 22:31:53.184498
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = 8756
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)

# Generated at 2022-06-24 22:32:04.692481
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    cmd = ['ifconfig', '-a']

# Generated at 2022-06-24 22:32:07.597638
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ai_x_network_0 = AIXNetwork(829)
    str_0 = 'ySzLFnQnD'
    var_0 = ai_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:12.557533
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = 2644
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)
    var_0 = a_i_x_network_collector_0.get_network_interfaces()
    print(var_0)

if __name__ == "__main__":
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:32:18.299392
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_3 = a_i_x_network_0.get_interfaces_info(X_0=None, int_0=None)


# Generated at 2022-06-24 22:32:22.900257
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    try:
        test_case_0()
        if False:
            raise Exception('Test failed')
    except:
        raise Exception('Test failed')

test_case_0()

# Generated at 2022-06-24 22:32:26.539833
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = -118
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)
    var_0 = a_i_x_network_collector_0.fetch_facts(bool_0)

# Generated at 2022-06-24 22:32:29.863445
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 1882
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:32:36.026159
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces('g')
    assert a_i_x_network_0.interface['v4']['interface'] == 'en5'
    assert a_i_x_network_0.interface['v4']['gateway'] == '172.20.0.1'
    assert not a_i_x_network_0.interface['v6']
    assert a_i_x_network_0.interface['v4']['interface'] == 'en5'
    assert var_0[0]['interface'] == 'en5'

# Generated at 2022-06-24 22:33:20.068901
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    obj.populate()
    assert obj.facts == dict()


# Generated at 2022-06-24 22:33:22.754156
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 610
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = '13/'
    str_1 = '-g'
    a_i_x_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:33:24.854471
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test with default values for all parameters
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)
    assert var_0[0] == {}
    assert var_0[1] == {}


# Generated at 2022-06-24 22:33:31.334444
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    entstat_path = '/usr/sbin/entstat'
    lsattr_path = '/usr/sbin/lsattr'
    netstat_path = '/usr/sbin/netstat'
    test_file_0 = 'output_0.txt'

    # the output of ifconfig -a
    with open(test_file_0, 'r') as r:
        output = r.read()

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Test case 0:
    # get_interfaces_info() without wpar (uname -W 0)
    #
    # Test case 0.1:
    # get_interfaces_info() without wpar (uname -W 0)
    # with working entstat and lsattr
    #
    # Test case

# Generated at 2022-06-24 22:33:33.331473
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert a_i_x_network_collector_0._platform == 'AIX'
    assert a_i_x_network_collector_0._fact_class == AIXNetwork


# Generated at 2022-06-24 22:33:35.908065
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:33:36.610814
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()

# Generated at 2022-06-24 22:33:37.904643
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert test_case_0() == None


# Generated at 2022-06-24 22:33:38.809844
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 22:33:44.265346
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    bool_0 = True
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)



# Generated at 2022-06-24 22:35:07.450080
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    case_0 = """

    """

    test_AIXNetwork_get_default_interfaces.__doc__ = case_0



# Generated at 2022-06-24 22:35:09.905084
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    int_0 = 1
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)
    var_0 = a_i_x_network_collector_0.get_device_name()


# Generated at 2022-06-24 22:35:13.926495
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0, bool_0)


# Generated at 2022-06-24 22:35:17.863562
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()


# Generated at 2022-06-24 22:35:23.104868
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    int_0 = 120
    a_i_x_network_0 = AIXNetwork(int_0)
    assert isinstance(a_i_x_network_0.get_interfaces_info('/etc/', '-a'), tuple)


# Generated at 2022-06-24 22:35:26.335393
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_interfaces_info(bool_0, bool_0)


# Generated at 2022-06-24 22:35:31.480560
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # {u'mtu': 9001, 'ipv6': [], u'macaddress': u'66:a3:b5:5b:43:b5', u'flags': ['UP', 'BROADCAST', 'ALLMULTI', 'DEBUG'], u'device': u'eth0', u'ipv4': [], u'type': u'unknown'}
    a_i_x_network_0 = AIXNetwork(int_0)
    a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:35:34.548475
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'

if __name__ == '__main__':
    test_case_0()
    test_AIXNetworkCollector()

# Generated at 2022-06-24 22:35:37.284048
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    u_t_bool_0 = True
    u_t_int_0 = 2644
    u_t_a_i_x_network_collector_0 = AIXNetworkCollector(u_t_int_0)


# Generated at 2022-06-24 22:35:43.426814
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_collector_0 = AIXNetworkCollector(int_0)


# Generated at 2022-06-24 22:38:33.429033
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    bool_0 = True
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)



# Generated at 2022-06-24 22:38:35.999702
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    str_0 = 'command'
    res = a_i_x_network_0.get_interfaces_info(str_0)
    assert(res)


# Generated at 2022-06-24 22:38:36.904357
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert False


# Generated at 2022-06-24 22:38:43.111666
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = 'test/aix/ifconfig_path'
    ifconfig_options = 'test/aix/ifconfig_options'
    a_i_x_network_0 = AIXNetwork()
    var_0 = a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-24 22:38:45.773582
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 1061
    a_i_x_network_0 = AIXNetwork(int_0)
    var_0 = a_i_x_network_0.get_default_interfaces(bool_0)



# Generated at 2022-06-24 22:38:48.970921
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork(None)
    bool_0 = a_i_x_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:38:50.073783
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
	test_case_0()

test_AIXNetworkCollector()

# Generated at 2022-06-24 22:38:51.624493
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_0 = AIXNetworkCollector()
    assert isinstance(aix_network_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:38:53.938593
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    int_0 = 2644
    a_i_x_network_0 = AIXNetwork(int_0)
    # TODO: Fix test
    #assert a_i_x_network_0.get_default_interfaces() ==


# Generated at 2022-06-24 22:38:55.820248
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    int_1 = 3164
    a_i_x_network_1 = AIXNetwork(int_1)
    a_i_x_network_1.get_interfaces_info(str_1, str_2)

