

# Generated at 2022-06-24 22:29:57.832943
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    assert a_i_x_network_collector.__class__.__name__ == 'AIXNetworkCollector'
    assert a_i_x_network_collector._fact_class.__name__ == 'AIXNetwork'
    assert a_i_x_network_collector._platform == 'AIX'


# Generated at 2022-06-24 22:30:00.107193
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    pass


# Unit test of method parse_interface_line from module GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:30:05.653836
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork
    a_i_x_network_0.get_interfaces_info(ifconfig_path='string_0', ifconfig_options='string_1')


# Generated at 2022-06-24 22:30:11.577104
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    a_i_x_network_0 = AIXNetwork()
    route_path_0 = '/sbin/route'
    result_0 = a_i_x_network_0.get_default_interfaces(route_path_0)
    # Test if command returned valid data
    return len(result_0) > 0


# Generated at 2022-06-24 22:30:15.167433
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0 = a_i_x_network_collector_0.get_facts()
    a_i_x_network_1 = a_i_x_network_collector_0.get_interfaces_info()

    # Check whether the result is a list
    assert isinstance(a_i_x_network_1, tuple), \
        'Expected tuple, but got %s instead' % type(a_i_x_network_1)

# Generated at 2022-06-24 22:30:21.221954
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # create instance of AIXNetwork class
    a_i_x_network_0 = AIXNetwork()

    # create test string
    ifconfig_path = '/usr/bin/ifconfig'
    # call method get_interfaces_info with test args
    str = a_i_x_network_0.get_interfaces_info(ifconfig_path)

    # check if result is int
    assert isinstance(str, dict)


# Generated at 2022-06-24 22:30:23.671536
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = a_i_x_network_collector_0
    a_i_x_network_collector = AIXNetworkCollector()

# Generated at 2022-06-24 22:30:26.633197
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector = AIXNetworkCollector()
    a_i_x_network_collector.collect()

# Generated at 2022-06-24 22:30:30.939448
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    a_i_x_network_0 = AIXNetwork()
    ifconfig_path = 'faux_ifconfig_path'
    ifconfig_options = '-a'
    a_i_x_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:30:40.777721
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class AIXNetwork
    '''
    a_i_x_network_0 = AIXNetwork(
        module=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=False,
        )
    )

    # Testing with path ending with 'netstat'
    # path exists
    # netstat is not executable
    with patch('os.path.exists') as mock_path_exists, patch('os.access') as mock_access:
        mock_path_exists.return_value = True
        mock_access.side_effect = lambda p,x: False if x & os.X_OK else True
        actual = a_i_x_network_0.get_default_interfaces('/usr/bin/netstat')


# Generated at 2022-06-24 22:30:55.465032
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_1 = None
    a_i_x_network_collector_1 = AIXNetworkCollector(dict_1, dict_1)

test_AIXNetworkCollector()
test_case_0()

# Generated at 2022-06-24 22:31:01.431893
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces = None
    ips = None
    ifconfig_path = None
    ifconfig_options = None
    a_i_x_network_collector_0 = AIXNetwork(interfaces, ips)
    var_0 = a_i_x_network_collector_0.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:31:04.446309
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = 32601
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)

# Generated at 2022-06-24 22:31:11.073520
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = -4707959222854354613
    int_1 = 3644643
    int_2 = 1640405840
    int_3 = -8745011656929955750
    var_0 = a_i_x_network_0.get_interfaces_info(int_0, int_1, int_2, int_3)
    print(var_0)


# Generated at 2022-06-24 22:31:14.619059
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector(dict_0, dict_0)
    print('Unit test for AIXNetworkCollector.__init__(dict_0, dict_0) is completed!!!')    
    

# Generated at 2022-06-24 22:31:16.992972
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector(dict_0, dict_0)


# Generated at 2022-06-24 22:31:22.615855
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector_0, AIXNetworkCollector)


# Generated at 2022-06-24 22:31:27.690015
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    assert isinstance(a_i_x_network_0, AIXNetwork)
    assert isinstance(a_i_x_network_0.get_default_interfaces(dict_0), tuple)


# Generated at 2022-06-24 22:31:32.677152
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_1 = None
    a_i_x_network_1 = AIXNetwork(dict_1, dict_1)
    str_0 = get_default_interfaces()


# Generated at 2022-06-24 22:31:36.945446
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = 26853
    var_0 = a_i_x_network_0.get_interfaces_info(int_0)

if __name__ == "__main__":
    test_AIXNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:32:03.614200
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    bool_0 = a_i_x_network_0.get_interfaces_info()


# Generated at 2022-06-24 22:32:11.336637
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = dict(aix_default_iface={})
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    a_i_x_network_0.module = Mock(**{'get_bin_path.return_value': '/sbin/netstat'})
    a_i_x_network_0.module.run_command = Mock(**{'return_value': (1, 'default  192.168.1.1        UG        0        0        en0', '')})
    dict_1 = a_i_x_network_0.get_default_interfaces('/usr/bin')

# Generated at 2022-06-24 22:32:16.967218
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = 32601
    var_0 = a_i_x_network_0.parse_interface_line(int_0)
    list_0 = ['ifconfig']
    list_1 = ['-a']
    tuple_0 = ('ifconfig', ['-a'])
    var_1 = a_i_x_network_0.get_interfaces_info(list_0, list_1)
    assert var_1[0] == var_0
    assert var_1[1]['all_ipv6_addresses'] == []


# Generated at 2022-06-24 22:32:23.546585
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = None
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = 28264
    var_0 = a_i_x_network_collector_0.get_network_config(int_0)
    int_1 = -11803
    var_1 = a_i_x_network_collector_0.get_network_config(int_1)

# Generated at 2022-06-24 22:32:28.269067
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = 32601
    var_1 = a_i_x_network_0.get_interfaces_info(int_0)
    assert var_1 != None, "get_interfaces_info of AIXNetwork did not return"


# Generated at 2022-06-24 22:32:29.039706
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:32:35.105813
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = 32601
    var_0 = a_i_x_network_0.parse_interface_line(int_0)
    int_1 = 0
    str_0 = a_i_x_network_collector_0.get_default_interfaces(int_1)
    int_2 = 0
    str_0 = a_i_x_network_collector_0.get_default_interfaces(int_2)


# Generated at 2022-06-24 22:32:37.930563
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector()._fact_class == AIXNetwork, 'Failed to create AIXNetworkCollector'
    assert AIXNetworkCollector()._platform == 'AIX', 'Failed to find _platform'


# Generated at 2022-06-24 22:32:44.535594
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:32:51.469470
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = -1939637498
    var_0 = a_i_x_network_0.get_default_interfaces(int_0)


# Generated at 2022-06-24 22:33:43.980817
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    var_0 = a_i_x_network_0.get_default_interfaces('/usr/local/bin/gcc')


# Generated at 2022-06-24 22:33:49.884346
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # unit test with valid parameters
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    str_0 = 'r'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:33:54.212291
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:33:59.197307
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = {'device': '1:2:3:4:5:6:7:8:9:0:1:2:3:4:5:6'}
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    str_0 = '2:3:4:5:6:7:8:9:0:1:2:3:4:5:6:7'
    var_0 = a_i_x_network_0.get_interfaces_info(str_0, str_0)


# Generated at 2022-06-24 22:34:03.948548
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_facts = dict()
    a_i_x_network_collector = AIXNetworkCollector(ansible_facts, dict())
    assert a_i_x_network_collector._fact_class == AIXNetwork
    assert a_i_x_network_collector._platform == 'AIX'
    assert a_i_x_network_collector._config == dict()

# Generated at 2022-06-24 22:34:11.833640
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = 32601
    var_0 = a_i_x_network_0.parse_interface_line(int_0)
    int_1 = 32601
    var_1 = a_i_x_network_0.parse_interface_line(int_1)
    int_2 = 32601
    var_2 = a_i_x_network_0.parse_interface_line(int_2)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_3 = 32601
    var_3 = a_i_x_network_0.parse_interface_line(int_3)
    dict_1 = None
    dict_2

# Generated at 2022-06-24 22:34:16.978748
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    str_0 = a_i_x_network_collector_0._fact_class.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:34:19.467687
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector_0, NetworkCollector)


# Generated at 2022-06-24 22:34:22.153308
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    int_0 = a_i_x_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:34:24.731322
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:36:04.225167
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = 32601
    var_0 = a_i_x_network_0.parse_interface_line(int_0)


# Generated at 2022-06-24 22:36:08.677182
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    str_0 = 'Test string, 42'
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)
    assert var_0 is None


# Generated at 2022-06-24 22:36:11.887015
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    str_0 = None
    var_0 = a_i_x_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:36:18.741619
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

#     def parse_lladdr_line(self, words, current_if, ips):
#         if current_if['type'] == 'ether':
#             current_if['macaddress'] = words[1]
#             current_if['type'] = 'ether'
#         elif current_if['type'] == 'ether':
#             current_if['macaddress'] = words[1]
#
#     def parse_ether_line(self, words, current_if, ips):
#         if current_if['type'] == 'ether':
#             current_if['macaddress'] = words[1]
#             current_if['type'] = 'ether'
#         else:
#             current_if['macaddress'] = words[1]

#     def parse_ether_line(self

# Generated at 2022-06-24 22:36:21.989651
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict = None
    a_i_x_network = AIXNetwork(dict, dict)
    # constructor test
    a_i_x_network_collector = AIXNetworkCollector()
    assert hasattr(a_i_x_network_collector, '_fact_class')
    assert isinstance(a_i_x_network_collector._fact_class, AIXNetwork)


# Generated at 2022-06-24 22:36:28.209395
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    a_i_x_network_collector_0 = AIXNetworkCollector()
    assert isinstance(a_i_x_network_collector_0._fact_class, AIXNetwork)
    assert a_i_x_network_collector_0._platform == 'AIX'


# Generated at 2022-06-24 22:36:37.394361
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict_0 = {}
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    str_0 = 'h'
    str_1 = 'P'
    str_2 = 'M'
    str_3 = 'g'
    str_4 = 'v'
    str_5 = 'R'
    str_6 = '6'
    str_7 = 'O'
    str_8 = 'Z'
    str_9 = 'W'
    str_10 = 'w'
    str_11 = 'D'
    str_12 = 'X'
    str_13 = 'G'
    str_14 = 'l'
    str_15 = 'Q'
    str_16 = 't'
    str_17 = 'A'

# Generated at 2022-06-24 22:36:44.380763
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    dict0 = dict(
        bin_path=dict(
            ifconfig='/usr/bin/ifconfig',
            netstat='/usr/bin/netstat',
            uname='/usr/bin/uname',
            lsattr='/usr/sbin/lsattr',
            entstat='/usr/sbin/entstat'),
        get_bin_path=lambda self, arg0: dict0['bin_path'][arg0])
    dict1 = dict(
        run_command=lambda self, arg0: dict0[arg0])
    dict0.update(dict1)
    dict1 = dict0
    dict0 = None
    a_i_x_network = AIXNetwork(dict1, dict1)
    int0 = 638
    dict0 = a_i_x_network.get_interfaces_

# Generated at 2022-06-24 22:36:47.843692
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    a_i_x_network_collector_0 = AIXNetworkCollector()
    int_0 = 32601
    var_0 = a_i_x_network_0.parse_interface_line(int_0)



# Generated at 2022-06-24 22:36:50.880992
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    dict_0 = None
    a_i_x_network_0 = AIXNetwork(dict_0, dict_0)
    var_0 = a_i_x_network_0.get_default_interfaces()
