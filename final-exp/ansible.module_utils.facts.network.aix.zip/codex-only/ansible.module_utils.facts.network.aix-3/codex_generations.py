

# Generated at 2022-06-22 23:35:28.697719
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    platform_mock = 'AIX'
    bin_path_mock = 'some/path/aix-netstat'
    module_mock = dict(
        get_bin_path=dict(
            return_value=bin_path_mock,
        ),
        run_command=dict(
            return_value=(
                0,
                'default 192.168.0.1 UG FOO0\ndefault 2002:abcd::1 UG FOO1',
                '',
            ),
        ),
    )

    net_facts = AIXNetwork()
    net_facts.module = type('ansible_mock', (object,), module_mock)
    net_facts.platform = platform_mock
    net_facts.config = {'gather_subset': []}

    interface = net_

# Generated at 2022-06-22 23:35:40.636168
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/sbin/ifconfig'
    route_path = '/usr/sbin/route'
    an = AIXNetwork(ifconfig_path, route_path)
    an.facts['default_ipv4_interface'], an.facts['default_ipv6_interface'] = an.get_default_interfaces(route_path)
    assert an.facts['default_ipv4_interface']['gateway'] == '10.10.8.1'
    assert an.facts['default_ipv4_interface']['interface'] == 'en0'
    assert an.facts['default_ipv6_interface']['gateway'] == 'fe80::20c:29ff:fe9b:c8d0%1'

# Generated at 2022-06-22 23:35:49.513600
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_lines = [
        'default 172.16.101.1 UG        0 16 en2',
        'default ::/0               UG        0   0  en2'
    ]

    test_module = type('FakeModule', (object,), {})
    test_class = AIXNetwork(test_module)

    result_v4, result_v6 = test_class.get_default_interfaces(test_lines)

    assert result_v4 == {'gateway': '172.16.101.1', 'interface': 'en2'}
    assert result_v6 == {'gateway': '::/0', 'interface': 'en2'}

# Generated at 2022-06-22 23:35:58.378920
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # initialize instance of class AIXNetwork
    network = AIXNetwork()
    # set variable of class AIXNetwork
    network.module = dict(run_command=dict(return_value=(0, mock_run_command_results['ifconfig -a'], '')))
    # initialize variable of function get_interfaces_info
    interfaces, ips = network.get_interfaces_info(ifconfig_path='ifconfig', ifconfig_options='-a')
    # check if result is from mock_run_command_results
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-22 23:36:02.655612
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aixnetwork = AIXNetwork()
    words = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST>'.split()
    current_if = aixnetwork.parse_interface_line(words)
    device = 'lo0'
    # check device
    assert current_if['device'] == device
    # check flags
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    # check MTU
    assert 'mtu' not in current_if
    # check type
    assert current_if['type'] == 'unknown'
    # check macaddress
    assert current_if['macaddress'] == 'unknown'



# Generated at 2022-06-22 23:36:06.590566
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Unit test for AIXNetworkCollector() class """

    my_obj = AIXNetworkCollector()
    assert my_obj.__class__.__name__ == 'AIXNetworkCollector'
    assert my_obj.platform == 'AIX'


# Generated at 2022-06-22 23:36:15.283078
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test case to check that AIX-specific method get_interfaces_info
    behaves correctly.
    """
    module = AnsibleModuleMock()
    net_device = AIXNetwork(module)
    interface_infos = net_device.get_interfaces_info(ifconfig_path='ifconfig')
    assert interface_infos['lo0'] == {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': [
            'UP',
            'LOOPBACK',
            'RUNNING'
        ],
        'macaddress': 'unknown'
    }

# Generated at 2022-06-22 23:36:25.276630
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, binary, opt_dirs=[]):
            return self.params['get_bin_path']

        def run_command(self, args):
            return self.params['run_command'][args[0]]

    from ansible.module_utils.facts.network.aix import AIXNetwork


# Generated at 2022-06-22 23:36:32.676319
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    test_AIXNetwork_get_default_interfaces
    unit test for method get_default_interfaces of class AIXNetwork
    '''
    # Ensure we do not get IPv6 default route
    netstat_out = '''
      Routing tables

      Internet:
      Destination               Gateway           Flags   Refs     Use    Interface
      default                   *                UG        0   643404     en0
      127.0.0.1                 127.0.0.1         UH        1  1258800     lo0
    '''
    fake_module = FakModule(params={
        'route_path': '/usr/bin/netstat',
        'bin_path': {'netstat': '/usr/bin/netstat'},
    })

# Generated at 2022-06-22 23:36:37.365753
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    test_network = AIXNetwork(test_module)
    test_network.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-22 23:36:44.909780
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    result = AIXNetwork(module).parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu=65536'])
    assert result == {
        'device': 'lo0',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        'macaddress': 'unknown',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
    }


# Generated at 2022-06-22 23:36:49.705245
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()

    assert aix_network_collector._fact_class is AIXNetwork
    assert aix_network_collector._platform == 'AIX'


# Generated at 2022-06-22 23:36:58.963065
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    interface = dict(v4={}, v6={})
    interface['v4']['interface'] = 'en0'
    interface['v4']['macaddress'] = 'unknown'
    interface['v4']['mtu'] = '1500'
    interface['v4']['type'] = 'ether'
    interface['v4']['flags'] = ['BROADCAST', 'MULTICAST', 'UP', 'AUTOMEDIA']
    interface['v4']['ipv4'] = []
    interface['v4']['ipv6'] = []

    test_class = AIXNetwork()


# Generated at 2022-06-22 23:37:08.698284
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # mock module input data (check mode)
    test_module.params['gather_subset'] = ['all']

    net_collector = AIXNetworkCollector(test_module)
    net_collector.get_network_facts()
    interfaces = net_collector.get_interfaces()

    # test if first interface has IPv4 gateway
    if 'default_ipv4' in interfaces:
        assert interfaces['default_ipv4']['gateway'] != ''
        assert interfaces['default_ipv4']['interface'] != ''

# Generated at 2022-06-22 23:37:12.280425
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """AIXNetwork class should be initialized for the given platform"""
    assert AIXNetwork(dict(), 'AIX').collect() is not None, \
        'AIXNetwork should be initialized'



# Generated at 2022-06-22 23:37:16.736843
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    AIXNetwork = module.collect()[0].__class__()
    route_path = '/usr/bin/netstat'
    assert AIXNetwork.get_default_interfaces(route_path) == ({}, {})

# Generated at 2022-06-22 23:37:27.859302
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())

    # read in the test data files
    with open("unit/modules/network/unit/test_data/aix/ifconfig_a_1.out") as ifconfig_a_1_f:
        ifconfig_a_1 = ifconfig_a_1_f.read()
    with open("unit/modules/network/unit/test_data/aix/entstat_en0_1.out") as entstat_en0_1_f:
        entstat_en0_1 = entstat_en0_1_f.read()
    with open("unit/modules/network/unit/test_data/aix/lsattr_El_en0_1.out") as lsattr_El_en0_1_f:
        lsattr_El_en0_

# Generated at 2022-06-22 23:37:38.679658
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Create a dummy class for testing:
    class DummyAIXNetwork:
        def __init__(self):
            class DummyModule:
                def get_bin_path(self, arg):
                    if arg == "ifconfig":
                        return "/usr/sbin/ifconfig"
                    elif arg == "entstat":
                        return "/usr/sbin/entstat"
                    elif arg == "lsattr":
                        return "/usr/sbin/lsattr"
                    else:
                        return None

                def run_command(self, arg):
                    if arg == ["/usr/sbin/ifconfig", "-a"]:

                        # Output from AIX 'ifconfig -a' command
                        return 0, out, err


# Generated at 2022-06-22 23:37:43.543123
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = "en0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500".split()
    current_if = AIXNetwork.parse_interface_line(words)
    assert current_if == {'device': 'en0',
                          'ipv4': [],
                          'ipv6': [],
                          'type': 'unknown',
                          'flags': '4163<UP,BROADCAST,RUNNING,MULTICAST>',
                          'macaddress': 'unknown'}


# Generated at 2022-06-22 23:37:54.745740
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """Return a two-tuple of IPv4 and IPv6 default interface and gateway information."""

    module = AnsibleModule(argument_spec={})
    mocker = Mocker()

    # Create mocks
    module.get_bin_path = mocker.Mock()
    module.get_bin_path('netstat')
    mocker.result('/usr/bin/netstat')
    module.run_command = mocker.Mock()
    module.run_command(['/usr/bin/netstat', '-nr'])
    mocker.result((0, "default 192.168.55.1 UGHD 0 192.168.55.2\ndefault 192.168.55.1 UGHD 1 10.0.0.1", ""))

    # Replay the mocks and assert
    mocker.replay()

# Generated at 2022-06-22 23:38:05.538336
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class network_return(object):
        def __init__(self, **kwargs):
            self.rc = kwargs['rc']
            self.out = kwargs['out']
            self.err = kwargs['err']

    class module_return(object):
        def __init__(self, **kwargs):
            self.bin_path = kwargs['bin_path']
            self.run_command = kwargs['run_command']

    class object(object):
        pass
    module = object()
    module.params = {}
    module.bin_path = lambda _: None

# Generated at 2022-06-22 23:38:08.010431
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetwork(module=module)
    assert collector.platform == 'AIX'


# Generated at 2022-06-22 23:38:18.924665
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = dict()
    module['run_command'] = dict()

    test_if = dict(device='eth0', ipv4=[], ipv6=[], type='unknown', flags=[], macaddress='unknown')
    test_words = ['ens132:', 'flags=4163<UP,BROADCAST,RUNNING,MULTICAST>', 'mtu=1500']

    my_if = AIXNetwork()
    my_if.module = module

    my_if.parse_interface_line(test_words)

    assert test_if['device'] == my_if.current_if['device']
    assert test_if['ipv4'] == my_if.current_if['ipv4']
    assert test_if['ipv6'] == my_if.current_if['ipv6']
    assert test_if

# Generated at 2022-06-22 23:38:21.329714
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.is_platform()
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:38:33.180856
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
        )
    )

    current_if = dict(v4={}, v6={})
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    ifconfig_path = os.path.join(os.getcwd(), 'test_files', 'ifconfig.txt')
    # While ifconfig_path is a file, ifconfig_options is not used so no need to mock a file
    ifconfig_options = '-a'

    aixnetwork = AIXNetwork(module)

# Generated at 2022-06-22 23:38:40.989624
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_path = None
    ifconfig_options = '-a'
    eth0_words = ['eth0:','flags=89','<UP,BROADCAST,NOTRAILERS,RUNNING,NOARP,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,BIG_PKTS>','options=3','<RXCSUM,TXCSUM,VLAN_MTU>','mtu=1500','index=0','inet','10.0.2.15','netmask','0xffffff00','broadcast','10.0.2.255','tcp_sendspace','131072','(131072)','tcp_recvspace','262144','(262144)']

# Generated at 2022-06-22 23:38:46.449752
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import Network
    from ansible.module_utils.facts.network.bsd import BaseBsdNetwork

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = Mock()

        def get_bin_path(self, path, required=True):
            return './netstat'

        def run_command(self, cmd):
            if cmd[0] == './netstat':
                return 0, 'default 192.168.61.1 UG 1  en0', ''
            else:
                return 0, '', ''

    class MockNetwork(AIXNetwork):
        def __init__(self, module):
            self.facts = {}
            self.module = module

    mod = Mock

# Generated at 2022-06-22 23:38:57.947694
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # dummy output for netstat command
    out_netstat_0 = "default 192.168.1.1 UGS 705 0 en1"
    out_netstat_1 = "default fe80::%en0 UGS 705 0 en0"
    out_netstat_2 = "default 192.168.1.1 UGS en1"
    out_netstat_3 = "default 192.168.1.1 UGS 705 0 en1\ndefault fe80::%en0 UGS 705 0 en0"

    out_netstat_list = [out_netstat_0, out_netstat_1, out_netstat_2, out_netstat_3]

    m = AIXNetwork()     # dummy module object

    # unit test for out_netstat_0

# Generated at 2022-06-22 23:39:07.559776
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # test of AIX 'ifconfig -a' output
    test_line = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = re.split(r'[:<>]', test_line)
    assert words[0] == 'en0'
    assert words[1] == ' flags=1e084863'
    assert words[2] == '480'
    assert words[3] == 'UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN'
    current_if

# Generated at 2022-06-22 23:39:16.445617
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = NetworkCollector()
    net = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'

    interfaces, ips = net.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)

    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert isinstance(interface['flags'], list)
        assert 'icmp_req' in interface['flags']
        assert isinstance(interface['ipv4'], list)
        assert len(interface['ipv4']) > 0
        assert isinstance(interface['ipv6'], list)
        assert len(interface['ipv6']) > 0
       

# Generated at 2022-06-22 23:39:28.706080
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:39:40.731477
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    def run_command_mock(command, module):
        # do not get output from command, but from files instead
        if command == ['ifconfig', '-a']:
            with open('test_AIX_ifconfig_a.txt', 'r') as f:
                return 0, f.read(), ''
        elif command == ['ifconfig', 'en1']:
            with open('test_AIX_ifconfig_en1.txt', 'r') as f:
                return 0, f.read(), ''
        elif command == ['ifconfig', 'en2']:
            with open('test_AIX_ifconfig_en2.txt', 'r') as f:
                return 0, f.read(), ''

# Generated at 2022-06-22 23:39:46.851065
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test = AIXNetwork()

# Generated at 2022-06-22 23:39:58.015244
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_network_resources'] = ['all']
            self.params['gather_subset'] = ['']
            self.params['filter'] = ['']
            self.run_command = self.mock_run_command
        def mock_run_command(self, command):
            if command == ['lsdev', '-Cc', 'if']:
                output = '''lo0                Available
                            lo0                Available
                            en0                Available
                            en1                Available
                            en2                Available'''
                return 0, output, ''

# Generated at 2022-06-22 23:40:09.546908
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class module():
        def get_bin_path(self, arg):
            if arg == 'uname':
                return 'uname'
            elif arg == 'ifconfig':
                return 'ifconfig'
            elif arg == 'entstat':
                return 'entstat'
            elif arg == 'lsattr':
                return 'lsattr'
            else:
                return None

        def run_command(self, arg):
            if arg == ['uname', '-W']:
                return 0, '0', ''

# Generated at 2022-06-22 23:40:16.552949
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetworkCollector()
    iface_v4, iface_v6 = net._fact_class.get_default_interfaces('/sbin/route')
    assert iface_v4 == {'gateway': '192.168.56.2', 'interface': 'en0'}
    assert iface_v6 == {'gateway': '::1', 'interface': 'lo0'}

# Generated at 2022-06-22 23:40:17.681431
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # AIXNetwork is an abstract class,
    # no unittest possible
    pass

# Generated at 2022-06-22 23:40:18.676541
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    AIXNetwork().get_default_interfaces('route')


# Generated at 2022-06-22 23:40:20.822148
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert(isinstance(AIXNetworkCollector(), NetworkCollector))

# Generated at 2022-06-22 23:40:31.892916
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    facts = {
        'default_ipv4': {'gateway': '8.8.0.1', 'interface': 'en0'},
        'default_ipv6': {'gateway': '2a00:1450:4002:803::100e', 'interface': 'en0'},
    }

    paths = {
        'netstat': '/usr/bin/netstat',
    }

    module = FakeAnsibleModule(
        facts=facts,
        paths=paths
    )

    network_collector = AIXNetworkCollector(module)
    actual = network_collector.get_default_interfaces('/sbin/route')

    assert actual['default_ipv4'] == facts['default_ipv4']

# Generated at 2022-06-22 23:40:42.529008
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    if module.get_bin_path('uname'):
        rc, out, err = module.run_command([module.get_bin_path('uname'), '-W'])
        if rc != 0:
            module.fail_json(msg='uname failed')
        if out.split()[0] == '0':
            network_collector = AIXNetworkCollector(module=module)
            network_collector.collect()
            facts = network_collector.get_facts()
            for interface in facts['interfaces'].itervalues():
                assert interface['device']
                assert interface['ipv4'] or interface['ipv6']
                assert interface['type']
            assert facts

# Generated at 2022-06-22 23:40:45.914501
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector, '_fact_class')
    assert hasattr(AIXNetworkCollector, '_platform')
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-22 23:40:47.851630
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_object = AIXNetworkCollector()
    assert test_object._platform == 'AIX'
    assert test_object._fact_class.platform == 'AIX'


# Generated at 2022-06-22 23:40:52.948504
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = MockAnsibleModule()

    aix_network = AIXNetwork(module)

    # words is from ifconfig -a output
    words = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '12', 'inet', '192.168.1.100', 'netmask', '0xffffff00']
    current_if = aix_network.parse_interface_line(words)
    module.assertEqual(current_if['device'], 'en0')
    module.assertEqual(current_if['flags'], '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>')

# Generated at 2022-06-22 23:41:04.816176
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fact_module = get_module_mock()
    fact_network = AIXNetwork(fact_module)
    # Create AIX output for 'ifconfig -a' (standard)

# Generated at 2022-06-22 23:41:07.411664
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixnc = AIXNetworkCollector(dict(module=dict()))
    assert aixnc._fact_class.platform == 'AIX'

# Generated at 2022-06-22 23:41:18.657956
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.posix_linux import GenericPosixNetwork

    m = GenericPosixNetwork()

    m.get_bin_path = lambda *args: '/usr/bin/' + args[0]

# Generated at 2022-06-22 23:41:30.350414
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # class under test
    class_under_test = AIXNetwork

    # mocks
    class_under_test.module.get_bin_path = Mock(return_value='/usr/bin/netstat')

# Generated at 2022-06-22 23:41:32.402443
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    testmodule = NetworkCollector()
    testmodule.get_default_interfaces('/usr/bin/netstat')
    assert True



# Generated at 2022-06-22 23:41:37.341852
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = MagicMock()
    net.module.get_bin_path.return_value = '/usr/bin/netstat'
    route_path = '/etc/rc.d/rc.inet1'
    net.get_default_interfaces(route_path)
    expected_output = dict(gateway='1.1.1.1', interface='en0')
    assert net.default_ipv4_interface == expected_output
    expected_output = dict(gateway='2001:db8:85a3::8a2e:370:7334', interface='en0')
    assert net.default_ipv6_interface == expected_output

# Generated at 2022-06-22 23:41:44.337130
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
        ),
    )
    myTest = AIXNetwork()
    module.exit_json(ansible_facts=dict(ansible_net_interfaces=myTest.get_default_interfaces('/etc/routes')))


# Generated at 2022-06-22 23:41:53.174757
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # input values
    line = 'en0: flags=8903<UP,BROADCAST,PROMISC,SIMPLEX,MULTICAST> metric 0 mtu 1500'
    words = line.split()

    # initialize AIXNetwork object
    obj = AIXNetwork()

    # call the method
    current_if = obj.parse_interface_line(words)

    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'PROMISC', 'SIMPLEX', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['mtu'] == 1500
    assert current_if['type'] == 'unknown'


# Generated at 2022-06-22 23:42:04.698729
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:13.141987
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
   t = AIXNetwork()

   # only for testing purpose: the module is initialized by AnsibleModule without the parameter route_path
   t.module = ''
   t.route_path = '/usr/bin/netstat'

   v4, v6 = t.get_default_interfaces(t.route_path)
   assert (v4['gateway'] == '192.168.137.1') and (v4['interface'] == 'en3')
   assert (v6['gateway'] == 'fe80::1') and (v6['interface'] == 'en4')


# Generated at 2022-06-22 23:42:16.468167
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork({})
    return network.get_default_interfaces('/etc/route.netstat')

if __name__ == '__main__':
    print(test_AIXNetwork_get_default_interfaces())

# Generated at 2022-06-22 23:42:27.882177
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    network = AIXNetwork()


# Generated at 2022-06-22 23:42:35.483661
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mod = AnsibleModule(argument_spec=dict())
    net = AIXNetwork(module=mod)
    expected_v4 = {'interface': 'en0', 'gateway': '10.10.10.1'}
    expected_v6 = {'interface': 'en0', 'gateway': 'fe80::f816:3eff:fe3b:3f7a'}
    data = (
        'default 10.10.10.1 UG 1 0 en0\n'
        'default fe80::f816:3eff:fe3b:3f7a%en0 UGDAf 25 0 en0'
    )

# Generated at 2022-06-22 23:42:47.104259
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_module = Fakemodule()
    aix_network = AIXNetwork(fake_module)
    command = {'rc': 0, 'stdout': 'default 192.168.1.1 UG 0 0 en0\ndefault fe80:1:2:3:4:5:6:7 UG 0 0 en0', 'stderr': ''}
    fake_module.run_command.return_value = command
    assert aix_network.get_default_interfaces('/sbin/route') == {'v4': {'gateway': '192.168.1.1', 'interface': 'en0'},
                                                                 'v6': {'gateway': 'fe80:1:2:3:4:5:6:7', 'interface': 'en0'}}


# Generated at 2022-06-22 23:42:59.204987
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class ModuleStub():
        def get_bin_path(self, arg1):
            pass

        def run_command(self, arg1):
            pass

    class AIXNetworkStub(AIXNetwork):
        interfaces = {}
        ips = {}
        current_if = {}
        module = ModuleStub()


    network_obj = AIXNetworkStub()

    # test with pci device
    # test with device without type
    # test with device with type ndis

# Generated at 2022-06-22 23:43:07.914297
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = type("ansible_module", (object,), {})()

    test_module.run_command = lambda x: (0, 'default        192.0.2.1 UG        0 0        en0', '')

    fact_class = AIXNetwork(test_module)

    default_interfaces = fact_class.get_default_interfaces("/bin/route")

    assert default_interfaces['v4']['gateway'] == '192.0.2.1'
    assert default_interfaces['v4']['interface'] == 'en0'


# Generated at 2022-06-22 23:43:17.049004
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    n = AIXNetworkCollector(module=module)
    assert n.platform == 'AIX'

# Read the 'uname' command output and set the return rc, out and err
uname_path = module.get_bin_path('uname', True)
uname_rc, uname_out, uname_err = module.run_command([uname_path, '-W'])

if uname_rc != 0 or uname_out.split()[0] != '0':
    module.fail_json(msg='uname -W command failed')
else:
    interfaces = n.get_interfaces()
    for interface in interfaces:
        for key, value in interface.items():
            print(key, ': ', value)

# Generated at 2022-06-22 23:43:29.384123
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:43:31.039261
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """ This is used to test constructor of class AIXNetwork"""
    aix_network = AIXNetwork()


# Generated at 2022-06-22 23:43:33.696500
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    o = AIXNetworkCollector()
    assert o.platform == 'AIX'
    assert o._fact_class == AIXNetwork


# Generated at 2022-06-22 23:43:45.906895
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This test will verify if AIX can collect default gateways correctly.
    """
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    net = AIXNetwork(module)

    # sanity check
    if net.default_gw != "10.10.10.1":
        module.fail_json(msg="ERROR: AIX_Network_get_default_interfaces test 1: "
                             "sanity check failed - default gateway is wrong")

# Generated at 2022-06-22 23:43:55.130997
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:05.496279
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    import textwrap
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO


# Generated at 2022-06-22 23:44:13.507930
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    class A:
        def __init__(self):
            self.name = 'ansible.module_utils.facts.network.aix'
            self.run_command = 'ansible.module_utils.facts.network.aix'
            self.get_bin_path = 'ansible.module_utils.facts.network.aix'
    a = A()
    aix_network = AIXNetwork(a)
    assert aix_network.module.name == 'ansible.module_utils.facts.network.aix'
    assert aix_network.module.run_command == 'ansible.module_utils.facts.network.aix'
    assert aix_network.module.get_bin_path == 'ansible.module_utils.facts.network.aix'

# Generated at 2022-06-22 23:44:24.879188
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    x = AIXNetworkCollector()
    assert x._platform == 'AIX'
    assert x._fact_class == AIXNetwork
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    lsattr_path = '/usr/sbin/lsattr'
    uname_path = '/usr/bin/uname'
    assert x.get_interfaces_info(ifconfig_path, ifconfig_options) == (x.get_interfaces_info(ifconfig_path, ifconfig_options))
    assert x.get_default_interfaces(lsattr_path) == (x.get_default_interfaces(lsattr_path))
    assert x.get_default_interfaces(lsattr_path) == x.get_default_interfaces(lsattr_path)


# Generated at 2022-06-22 23:44:29.524658
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    results = AIXNetworkCollector.collect()

    assert 'default_interface' in results
    assert 'interfaces' in results
    assert 'all_ipv4_addresses' in results
    assert 'all_ipv6_addresses' in results

# Generated at 2022-06-22 23:44:31.044134
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert isinstance(net, AIXNetwork)

# Generated at 2022-06-22 23:44:39.438885
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    params = {
        'PATH': 'some',
        'config': 'some',
        'gather_subset': 'some',
        'filter': 'some',
    }
    module = AnsibleModuleMock(params)

    network = AIXNetwork(module)
    network.module.run_command = run_command
    v4, v6 = network.get_default_interfaces('some')

    assert v4['gateway'] == '10.1.1.1'
    assert v4['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::200:5eff:fe00:0'
    assert v6['interface'] == 'en0'



# Generated at 2022-06-22 23:44:51.775005
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Units test AIXNetwork_get_interfaces_info
    # Testing class AIXNetwork
    #
    # Preconditions
    #
    #   1. os.path.exists('AIX_ifconfig_help.txt') MUST be true
    #   2. 'AIX_ifconfig_help.txt' MUST have the ifconfig help output from AIX 7 TL3

    test_class = AIXNetwork()
    class_name = 'AIXNetwork'

    # We have to set this to True or the test chokes
    test_class.module.check_mode = True

    try:
        file_object = open('AIX_ifconfig_help.txt', 'r')
    except IOError:
        print(class_name + ': Cannot open file "AIX_ifconfig_help.txt"')

# Generated at 2022-06-22 23:44:56.350140
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector class should create
    object of AIXNetworkCollector class & assign
    _fact_class of this object to 'AIXNetwork'
    """
    obj = AIXNetworkCollector()
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'

# Generated at 2022-06-22 23:45:06.377332
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test that AIXNetwork.get_interfaces_info returns expected result
    when simulating ifconfig command output.
    """

# Generated at 2022-06-22 23:45:18.196933
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # test_interface_line is the text line after "ifconfig -a" command
    test_interface_line = 'en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>'

    aix_network = AIXNetwork()
    # result is a dict, that must be compared to expected_result
    result = aix_network.parse_interface_line(test_interface_line.split())