

# Generated at 2022-06-22 23:35:20.270918
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network_module = AIXNetwork({})
    assert network_module.facts['default_ipv4'], 'default_ipv4 not found'
    assert network_module.facts['default_ipv6'], 'default_ipv6 not found'
    assert network_module.facts['all_ipv4_addresses'], 'all_ipv4_addresses not found'
    assert network_module.facts['all_ipv6_addresses'], 'all_ipv6_addresses not found'
    assert network_module.facts['interfaces'], 'interfaces not found'


# Generated at 2022-06-22 23:35:32.523180
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:35:44.071465
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:35:55.101933
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import sys
    import unittest
    import io

    # Create a fake module
    class TestModule(object):
        def __init__(self):
            self.run_command_lines = []
            self.run_command_rcs = []
            self.run_command_results = []
            self.fail_json_lines = []
            self.fail_json_rcs = []


        def get_bin_path(self, s, required=False):
            if s == 'netstat':
                return '/usr/bin/netstat'


        def run_command(self, args, check_rc=True):
            self.run_command_lines.append(args)
            r = self.run_command_results.pop(0)

# Generated at 2022-06-22 23:36:00.668453
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Create a AIXNetworkCollector object
    my_obj = AIXNetworkCollector(None)

    # Compare _fact_class
    assert my_obj._fact_class.__name__ == 'AIXNetwork'

    # Compare _platform
    assert my_obj._platform == 'AIX'

# Generated at 2022-06-22 23:36:04.093577
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # we should ideally test all the code here, but at least check the API
    network = AIXNetwork()
    assert network.platform == 'AIX'

# Generated at 2022-06-22 23:36:06.505873
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    aixnet = AIXNetwork()
    assert aixnet._platform == 'AIX'
    assert aixnet._fact_class == AIXNetwork


# Generated at 2022-06-22 23:36:08.948521
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network_collector = AIXNetworkCollector()
    assert network_collector.facts['default_ipv4']['interface'] == 'en0'

# Generated at 2022-06-22 23:36:10.245718
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector

# Generated at 2022-06-22 23:36:22.197471
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Correct output from command 'netstat -rn' for AIX
    lines = [
        '',
        'Routing tables',
        '',
        'default          9.0.0.2          UGS        0 4338   en0',
        '9.0.0.0         9.0.0.0          U           0 4338   en0',
        'default         2001:1111:2222:3333::1 UGS        0 2461   en4',
        '9.0.0.0         9.0.0.0          U           0 4338   en0',
        '9.0.0.0         9.0.0.0          U           0 4338   en0',
    ]

    interface = dict(v4={}, v6={})

    # should set default gateway and interface

# Generated at 2022-06-22 23:36:30.327634
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # note: a lot of values are not tested because they are the same as
    # GenericBsdIfconfigNetwork
    module = AnsibleModule(argument_spec={})

    # skip this test if ifconfig is not installed
    if not module.get_bin_path('ifconfig'):
        module.exit_json(changed=False)

    # generate the test data from AIX 'ifconfig -a'
    rc, out, err = module.run_command(['ifconfig', '-a'])

    result = {'ansible_facts': {'ansible_network_resources': {}}, 'changed': False}

    # remove data after "Common media types"
    lines = out.splitlines()
    for line in lines:
        if 'Common media types' in line:
            break

# Generated at 2022-06-22 23:36:32.505102
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    x = AIXNetworkCollector()
    assert type(x) == AIXNetworkCollector

# Generated at 2022-06-22 23:36:43.243669
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    me = AIXNetwork()

    # verify that a correctly formatted route -n output can be parsed
    def_interfaces = {'v4': {'gateway': '10.0.0.1', 'interface': 'en0'}, 'v6': {'gateway': 'fe80::1', 'interface': 'en0'}}
    route_out = '''
Kernel IP routing table
Destination     Gateway         Flags    Refs    Use     Mtu    Interface
default         10.0.0.1        UG       1       0       1500   en0
::/96           ::1             UGRS        0       0       1500   lo0
::1             ::1             UH        62   37573       -     lo0
    '''
    result = me.get_default_interfaces(route_out)
    assert def_interfaces

# Generated at 2022-06-22 23:36:52.305701
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_module = type('ansible.module_utils.basic.AnsibleModule', (object,), dict(
    ))()

    fake_module.run_command = lambda *args: (0, 'default 192.168.1.1 UGS en1', '')

    aix_network = AIXNetwork(fake_module)
    interface = aix_network.get_default_interfaces('netstat')

    assert interface == {'interface': 'en1', 'gateway': '192.168.1.1'}


# Generated at 2022-06-22 23:36:55.563341
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    net = AIXNetwork(module, ifconfig_path=ifconfig_path)
    assert isinstance(net, AIXNetwork)


# Generated at 2022-06-22 23:36:57.751179
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-22 23:37:07.832815
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:37:19.282354
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:37:30.296365
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )

    ifconfig_path = module.get_bin_path('ifconfig')


# Generated at 2022-06-22 23:37:40.812980
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import sys
    import inspect
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    fc = AIXNetworkCollector()

    # Test for class variables of class AIXNetworkCollector.
    assert fc._platform == 'AIX'
    assert fc._fact_class._platform == 'AIX'
    assert fc._fact_class.platform == 'AIX'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'
    assert AIXNetworkCollector.platform == 'AIX'

# Generated at 2022-06-22 23:37:48.261373
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    """
    Module argument_spec
    """

    ifconfig_path = module.get_bin_path('ifconfig')

    m1 = AIXNetwork()
    m1.module = module
    out = m1.get_interfaces_info(ifconfig_path)

    module.exit_json(msg=out)


# Generated at 2022-06-22 23:37:59.176536
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec=dict())

    class MockNetworkModule:
        def __init__(self):
            self.run_command = mock.MagicMock(return_value=(0, '', ''))
            self.get_bin_path = mock.MagicMock(return_value='ifconfig')
            self.params = None

    net_module = MockNetworkModule()
    net = AIXNetwork(module=net_module)

    net.get_default_interfaces = mock.MagicMock(return_value=('0.0.0.0', '::/0'))

    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'


# Generated at 2022-06-22 23:38:03.324563
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_module = AIXNetwork(module)
    assert network_module.platform == 'AIX'
    assert network_module.module == module


# Unit tests for function get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:38:07.004448
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    facts = AIXNetwork()
    data = facts.parse_interface_line(["en0:", "flags=1e080863,", "mtu", "1500"])
    assert data['device'] == 'en0'
    assert 'flags' in data
    assert 'mtu' in data
    assert 'macaddress' in data

# Generated at 2022-06-22 23:38:08.226162
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-22 23:38:16.901414
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    assert AIXNetwork().parse_interface_line(['en2:','flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>','mtu','1500']) == {'device': 'en2', 'flags': ('1e080863', '480'), 'mtu': '1500', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:38:21.223217
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    facts = AIXNetworkCollector()
    # print(facts.collect())

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-22 23:38:33.097820
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # set input
    module = AnsibleModule(argument_spec={})
    path_to_cmd = 'bin/ifconfig'
    # create expected output

# Generated at 2022-06-22 23:38:40.935895
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import types

    # this test is based on netifaces Python module (BSD compatible) with
    # some modifications

    # empty lines are not consumed at all
    # empty lines at the end are not consumed at all
    # empty lines in front are consumed by the first line
    # the 'no' flag is not added to the flags if the interface does not have it
    # the flags are removed from the end of the line until 'flags=' is found
    # lines are always added at the end of the current list
    # media: in the middle is not supported by this class
    # inet is always added to the beginning of the list
    # inet6 is always added to the beginning of the list
    # missing spaces are not added at the end of the flags
    # lladdr is always added in the end of the line
    # the first letter of the flags is always lower

# Generated at 2022-06-22 23:38:45.302519
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
        Unit test for method get_interfaces_info of class AIXNetwork
        :param self: instance of class AIXNetwork
    """
    # Create instance of API class
    aix_network = AIXNetwork()
    # Use method get_interfaces_info
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')
    # Check interfaces and ips
    assert len(interfaces) == 3
    assert len(ips['all_ipv4_addresses']) == 2
    assert len(ips['all_ipv6_addresses']) == 2


# Generated at 2022-06-22 23:38:49.420338
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = '/usr/bin/netstat'
    test = AIXNetwork(dict(module=None))
    gateway, interface = test.get_default_interfaces(route_path)
    assert interface == 'en0'
    assert gateway == '172.16.1.1'


# Generated at 2022-06-22 23:39:00.469933
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork()
    test_words = ['test0:', 'flags=800000000011<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,GRPPROM>', 'media:', 'Ethernet', '10/100', 'base', 'T', 'auto']
    test_current_if = test.parse_interface_line(test_words)

    assert(test_current_if['device'] == 'test0')
    assert(test_current_if['flags'] == ['UP', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GRPPROM'])
    assert(test_current_if['macaddress'] == 'unknown')
    assert(test_current_if['type'] == 'unknown')



# Generated at 2022-06-22 23:39:10.524007
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule(
            argument_spec = dict(
            ),
            supports_check_mode=True
    )

    network_collector = AIXNetworkCollector(ansible_module)
    network_info = network_collector.collect()

    for ifname, interface in network_info['interfaces'].iteritems():
        if interface['type'] == 'unknown':
            output = parse_interface_line(['en0:', 'flags=1e080863,c0', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'], ansible_module)
            assert output['device'] == 'en0'
            assert 'mtu' not in output


# Generated at 2022-06-22 23:39:17.950940
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class ModuleStub(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'netstat':
                return "/usr/bin/netstat"

        def run_command(self, arg, opt_dirs=[]):
            out = "default  10.10.254.254 UGS   0  135912 en0\n" \
                  "127.0.0.1        127.0.0.1          UH        13  135782 lo0\n" \
                  "10.10.0.0/16     10.10.0.15        UGS        0  135912 en1\n"

            return 0, out, ""

    test_module = ModuleStub()


# Generated at 2022-06-22 23:39:29.568341
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    inet_lines = [
        '      inet 10.11.12.13 netmask 0xffc00000 broadcast 10.15.255.255',
        '      inet6 ::1/0',
        '      inet6 fe80::1%1/10',
    ]

    # testing with multiple 'inet6' lines

# Generated at 2022-06-22 23:39:40.932436
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import platform
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    p = AIXNetwork()


# Generated at 2022-06-22 23:39:52.405055
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    objs = []
    for idx in range(8):
        obj = AIXNetwork(module)
        objs.append(obj)
    module.get_bin_path = lambda x: '/usr/sbin/' + x

# Generated at 2022-06-22 23:40:03.528649
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    aix_net = AIXNetwork()

    # test with an empty text
    result = aix_net.get_default_interfaces('')
    assert result[0] == {}
    assert result[1] == {}

    # test with netstat command output with default routes
    result = aix_net.get_default_interfaces('netstat output with default routes')
    assert result[0] == {'gateway': '192.168.122.1', 'interface': 'en0'}
    assert result[1] == {'gateway': 'fe80::7c9f:dbff:fe07:50d4', 'interface': 'en0'}

    # test with netstat command output without default routes
    result = aix_net.get_default_interfaces('netstat output without default routes')

# Generated at 2022-06-22 23:40:06.806264
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_net = AIXNetwork()
    assert aix_net.platform == 'AIX'
    assert aix_net.get_default_interfaces(route_path=None) == (None, None)

# Generated at 2022-06-22 23:40:17.676029
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:28.392954
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    assert(
        AIXNetwork().parse_interface_line(['en1:']) ==
        {'device': 'en1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'}
    )
    assert(
        AIXNetwork().parse_interface_line(['en1:', 'flags=1e080863,']) ==
        {'device': 'en1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['1e080863', ''], 'macaddress': 'unknown'}
    )

# Generated at 2022-06-22 23:40:39.405506
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import GenericBsdIfconfigNetwork

    aix_if = AIXNetwork()
    gbn_if = GenericBsdIfconfigNetwork()
    ans_if = AIXNetwork()

    # only this condition differs from GenericBsdIfconfigNetwork
    if re.match(r'^\w*\d*:', 'en0: flags=104800<UP,BROADCAST,NOAUTOCONFIG>'):
        test_if = aix_if.parse_interface_line('en0: flags=104800<UP,BROADCAST,NOAUTOCONFIG>'.split())

# Generated at 2022-06-22 23:40:48.492967
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    an = AIXNetwork()
    expected_result = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST']}
    # change the mac address to the unknown value
    expected_result['macaddress'] = 'unknown'
    # change the mtu to the unknown value
    if 'mtu' in expected_result:
        del expected_result['mtu']
    line = 'en0: flags=0x43e<BROADCAST,SIMPLEX,MULTICAST>'
    words = line.split()
    # return current_if but do not change itself
    current_if = an.parse_interface_line(words)
    assert current_if == expected_result
    # change the m

# Generated at 2022-06-22 23:40:58.810052
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    assert aix_network.parse_interface_line(['en0:']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'}
    assert aix_network.parse_interface_line(['en0:', 'flags=2<BROADCAST,MULTICAST>']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['BROADCAST', 'MULTICAST'], 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:41:10.389340
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:41:20.383909
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    network_module = AIXNetwork(module)
    words = ['ent6:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric', '1']

# Generated at 2022-06-22 23:41:30.295549
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network_collector = AIXNetworkCollector()
    network = network_collector._fact_class()
    words = ['en0:', 'flags=1e080863', 'mtu', '1500']
    result = network.parse_interface_line(words)
    expected_result = {
        'device': 'en0',
        'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'],
        'ipv6': [],
        'ipv4': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }
    assert sorted(result) == sorted(expected_result)

# Generated at 2022-06-22 23:41:33.023865
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of class AIXNetworkCollector.
    It tests whether it can be called without any error.
    """
    net_collector = AIXNetworkCollector()

# Generated at 2022-06-22 23:41:40.035901
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    network = AIXNetwork(module)

# Generated at 2022-06-22 23:41:44.825288
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    test_platform = 'AIX'
    test_network = AIXNetwork(module=module)

    assert test_network.platform == test_platform
    assert test_network.fact_class == AIXNetwork


# Generated at 2022-06-22 23:41:55.024311
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # AIXNetwork instance
    aixnet = AIXNetwork()

    # For testing:
    #  - aixnet.facts
    #  - aixnet.get_facts()

    assert(isinstance(aixnet, AIXNetwork))
    assert(isinstance(aixnet.facts, dict))

    print("aixnet.facts:")
    print(aixnet.facts)
    print("aixnet.facts['all_ipv4_addresses']:")
    print(aixnet.facts['all_ipv4_addresses'])
    print("aixnet.facts['all_ipv6_addresses']:")
    print(aixnet.facts['all_ipv6_addresses'])
    print("aixnet.facts['default_ipv4']:")
    print

# Generated at 2022-06-22 23:42:02.556472
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork()
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> mtu 1500 index 2'
    words = line.split()
    current_if = test.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '1e080863'

# Generated at 2022-06-22 23:42:03.126802
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert True

# Generated at 2022-06-22 23:42:14.553319
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork
    ansible_ifconfig_path = '/usr/sbin/ifconfig'
    net = AIXNetwork(dict(module=None, params=dict(gather_subset=[])))
    ifconfig_path, ifconfig_options = net.get_bin_path()
    assert ifconfig_path == ansible_ifconfig_path
    assert ifconfig_options == '-av'
    interfaces, ips = net.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'lo0' in interfaces
    lo0 = interfaces['lo0']
    assert lo0['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'LOOPBACK', 'MULTICAST']

# Generated at 2022-06-22 23:42:26.766055
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:42:32.103513
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork_obj = AIXNetwork()
    words = ['en0:','flags=8963']
    current_if = AIXNetwork_obj.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '8963'
    assert current_if['type'] == 'unknown'
    assert current_if['mtu'] == 1500
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-22 23:42:33.298856
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    result = AIXNetwork()
    assert result.platform == 'AIX'

# Generated at 2022-06-22 23:42:39.088602
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    network_module = AIXNetwork(test_module)
    (default_v4_interface, default_v6_interface) = network_module.get_default_interfaces('/usr/sbin/route')
    assert default_v4_interface['interface'] == 'en2'
    assert default_v4_interface['gateway'] == '10.3.1.1'
    assert not default_v6_interface


# Generated at 2022-06-22 23:42:45.620840
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    uname_path = '/usr/bin/uname'
    module = type('', (object,), {'get_bin_path': lambda self, _: uname_path, 'run_command': lambda self, _: (0, '0 foo', '')})
    test = AIXNetwork(module)
    assert test.default_interfaces['v4']['interface'] == 'foo0'

# Generated at 2022-06-22 23:42:51.843778
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    words = ['en0:', 'flags=1e080863', 'mtu', '1500', 'index', '10']
    current_if = aix_network.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['1e080863']



# Generated at 2022-06-22 23:43:02.392706
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:43:14.642265
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    if_name = 'en0'

    class MyModule:
        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, args):
            if args[0] == '/bin/ifconfig':
                return 0, ifconfig_out, ''
            elif args[0] == '/bin/lsattr':
                return 0, lsattr_out, ''
            elif args[0] == '/bin/entstat':
                return 0, entstat_out, ''
            else:
                return 0, '', ''
    class AnsibleModule:
        def __init__(self):
            self.module = MyModule()

    fact_class = AIXNetwork(AnsibleModule())

# Generated at 2022-06-22 23:43:26.441335
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = None
    ifconfig_path = '/usr/sbin/ifconfig'

    # Expected result

# Generated at 2022-06-22 23:43:38.132372
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))

    # Mock ifconfig path
    ifconfig_path = 'bin/ifconfig'
    module.get_bin_path = Mock(return_value=ifconfig_path)

    # Mock uname path
    uname_path = 'bin/uname'
    module.get_bin_path = Mock(side_effect=[ifconfig_path, uname_path])

    # Mock entstat path
    entstat_path = 'bin/entstat'
    module.get_bin_path = Mock(side_effect=[ifconfig_path, uname_path, entstat_path])

    # Mock lsattr path
    lsattr_path = 'bin/lsattr'

# Generated at 2022-06-22 23:43:47.801869
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_class = AIXNetwork()
    test_string = 'en0: flags=16003<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST> mtu 1500'
    test_result = test_class.parse_interface_line(test_string.split())
    assert test_result['device'] == 'en0'
    assert test_result['flags'] == 'UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST'
    assert test_result['macaddress'] == 'unknown'
    assert 'mtu' not in test_result

# Generated at 2022-06-22 23:43:56.015231
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if not C.HAS_AIX:
        pytest.skip("Facts requires AIX package.")

    nc = AIXNetwork()
    ips = nc.get_interfaces_info("ifconfig", "-a")

    assert len(ips) == 2
    assert len(ips[0]) > 0
    assert len(ips[1]) > 0

    for iface, data in ips[0].items():
        assert iface == data['device']
        for k in ['mtu', 'macaddress', 'type']:
            assert k in data
    for iface, data in ips[1].items():
        assert iface == data['device']

# Generated at 2022-06-22 23:44:05.617295
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import Network, NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils._text import to_bytes

    network = Network()
    network.module = AnsibleModuleMock()
    network.module.run_command = run_command
    ifconfig = network.module.get_bin_path = get_bin_path
    network.module.run_command = run_command

# Generated at 2022-06-22 23:44:10.285015
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    nm = AIXNetwork(module)
    facts = dict()

    # get tags
    facts['gather_subset'] = ['all']

    # call parse_interfaces
    nm.parse_interfaces(facts)

    # check it works
    assert 'default_ipv4' in facts['ansible_network_resources']
    assert 'default_ipv6' in facts['ansible_network_resources']

# unit test constructor

# Generated at 2022-06-22 23:44:11.769461
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-22 23:44:17.797610
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = type('', (), {})()

    test_module.run_command = lambda x: (0, 'default 0.0.0.0 UG 0 0 en1\n', '')
    network_module = AIXNetwork(test_module)
    interface = network_module.get_default_interfaces('/sbin/route')

    assert interface['interface'] == 'en1'

# Generated at 2022-06-22 23:44:24.811898
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Unit test for AIXNetwork class constructor.

    Tests __init__ method only.

    Expected Results:
    uname_path is set to the path of uname
    ifconfig_path is set to the path of ifconfig
    """
    module = NetworkCollector.get_platform_module(platform='AIX')
    assert module
    assert module.uname_path == '/usr/bin/uname'
    assert module.ifconfig_path == '/usr/sbin/ifconfig'



# Generated at 2022-06-22 23:44:36.601738
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    ANI = AIXNetwork(module)

    # Good default
    default_route_path = '/etc/defaultrouter'
    route_fh = open(default_route_path, 'w')
    route_fh.write('192.168.1.1')
    route_fh.close()

    (ipv4_interface, ipv6_interface) = ANI.get_default_interfaces(default_route_path)
    assert ipv4_interface['gateway'] == '192.168.1.1'
    assert 'interface' not in ipv4_interface

    # Bad default
    route_fh = open(default_route_path, 'w')
    route_fh

# Generated at 2022-06-22 23:44:41.938235
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkModule(argument_spec=dict(gather_subset=dict(default=['!all', '!min'])))
    obj = AIXNetwork(module)
    ret_v4, ret_v6 = obj.get_default_interfaces('/etc/route')
    assert(ret_v4['interface'] == 'en0')
    assert(ret_v6['interface'] == 'en0')

# Generated at 2022-06-22 23:44:53.796255
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:45:04.075574
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork(module=None)
    out = dict()

    # test 1: interface with alias
    words = ['en0:','flags=','2d','<BROADCAST,NOTRAILERS,MULTICAST,'
             'NOARP>']
    out = test.parse_interface_line(words)
    assert out['device'] == 'en0'
    assert out['type'] == 'unknown'
    assert out['flags'] == ['BROADCAST', 'NOTRAILERS', 'MULTICAST',
                            'NOARP']
    assert out['macaddress'] == 'unknown'

    # test 2: interface without alias
    words = ['en0', 'flags=', '2d', '<BROADCAST,NOTRAILERS,MULTICAST,'
             'NOARP>']
    out = test.parse

# Generated at 2022-06-22 23:45:16.311658
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Unit Test Variables
    ifconfig_path = "/usr/sbin/ifconfig"
    ifconfig_options = '-a'