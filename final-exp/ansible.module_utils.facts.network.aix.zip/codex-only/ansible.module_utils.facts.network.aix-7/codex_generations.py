

# Generated at 2022-06-22 23:35:29.078315
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class MockModule(object):
        @staticmethod
        def run_command(command):
            class MockPopen(object):
                def communicate(data):
                    return ('', '', 0)
            return ('', '', 0)

        @staticmethod
        def get_bin_path(binary):
            return '/usr/bin/netstat'

    m = MockModule()
    n = AIXNetwork(m)
    assert n.get_default_interfaces(None) == ({'gateway': '8.8.8.8', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})



# Generated at 2022-06-22 23:35:40.869042
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_test_arguments = {
        'gather_subset': [],
        'gather_network_resources': "all",
        'filter': [],
        'config': [],
        'ansible_facts': {},
        'ansible_check_mode': False,
        'ansible_module_args': {}
    }

    my_test_instance = AIXNetworkCollector()
    assert my_test_instance.platform == 'AIX'
    assert my_test_instance.gather_subset == []
    assert my_test_instance.gather_network_resources == "all"
    assert my_test_instance.filter == []
    assert my_test_instance.config == []
    assert my_test_instance.ansible_facts == {}
    assert my_test_instance.ansible_check

# Generated at 2022-06-22 23:35:45.003737
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # initialize class
    AN = AIXNetwork()

    # mock route table
    AN.route_content = '''

'''

    AN.route6_content = '''

'''

    # run method
    assert AN.get_default_interfaces(AN.route_path) == ({}, {})


# Generated at 2022-06-22 23:35:55.662384
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    ansible_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True,
    )

    # Init object
    aix_network = AIXNetwork(ansible_module)

    # Check attributes
    assert aix_network.get_default_interfaces.__doc__ == """Get Default Interfaces Dict"""
    assert aix_network.get_interfaces_info.__doc__ == """Get interfaces info from ifconfig"""
    assert aix_network.get_route_info.__doc__ == """Get route info"""

    # Check if AIXNetwork class raise NotImplementedError
    with pytest.raises(NotImplementedError):
        aix_network.parse_ipv6

# Generated at 2022-06-22 23:36:02.308987
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork(None)

    # test if the right platform is set
    assert aix_network.platform == 'AIX'

    # test if the right facts class is available
    assert AIXNetworkCollector._fact_class == AIXNetwork

    # test if the right platform is set
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-22 23:36:06.078368
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    net = AIXNetwork()
    net.get_default_interfaces('route_path')

# Generated at 2022-06-22 23:36:07.846238
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork({})
    assert aix_network is not None


# Generated at 2022-06-22 23:36:12.177050
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_facts = AIXNetworkCollector()
    assert aix_facts.facts['default_ipv4']['gateway'] == '10.0.2.2'
    assert aix_facts.facts['default_ipv6']['gateway'] == '::'
    assert aix_facts.facts['interfaces']['hme0']['mtu'] == '1500'
    assert aix_facts.facts['interfaces']['lo0']['mtu'] == '65536'
    assert aix_facts.facts['interfaces']['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-22 23:36:21.704603
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network_module = AIXNetwork()
    words = ['en1:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    current_if = network_module.parse_interface_line(words)
    assert current_if == {'device': 'en1', 'ipv4': [], 'ipv6': [], 'flags': ['1e080863', '480'], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:36:30.858886
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork class"""

    # Note:
    #   - If you modify this test, please also add similar tests to
    #     network_generic_bsd.py.
    #   - Example of AIX ifconfig output is in aix_ifconfig_test.output
    #     Use this output file to test with:
    #     > uname -W 0;ifconfig -a > ifconfig.out
    #     > more  aix_ifconfig_test.output | head -n10
    #     > python test_net_generic_bsd.py ifconfig.out


# Generated at 2022-06-22 23:36:42.594820
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    current_if = module.get_bin_path('ifconfig')
    if not current_if:
        module.fail_json(msg='ifconfig command not found')
    obj = AIXNetwork(module)

    words = ['en0:', 'flags=5e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT>', 'mtu', '1500', 'index', '8']
    actual_result = obj.parse_interface_line(words)

# Generated at 2022-06-22 23:36:45.176614
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    c = AIXNetworkCollector()
    assert c.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-22 23:36:56.167207
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    test_AIXNetwork = AIXNetwork()
    test_AIXNetwork.module = AnsibleModuleMock()
    test_AIXNetwork.module.run_command = run_command_mock

    interfaces, ips = test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig')

    assert 2 == len(interfaces)
    assert 'eth1' in interfaces
    assert 'lo0' in interfaces

    assert 'type' in interfaces['eth1']
    assert 'ether' == interfaces['eth1']['type']

    assert 'type' in interfaces['lo0']
    assert 'loopback' == interfaces['lo0']['type']

    assert 'ipv4' in interfaces['eth1']
    assert [] == interfaces['eth1']['ipv4']

    assert 'ipv6'

# Generated at 2022-06-22 23:37:06.990998
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os, tempfile
    fake_route = '''
    Routing tables

    Internet:
    Destination        Gateway            Flags   Refs      Use   If
    default            192.168.1.1        UG         1       0 en0
    '''
    fake_netstat = '''
    Routing tables

    Internet:
    Destination        Gateway            Flags   Refs      Use   If
    default            192.168.1.1        UG         1       0 en0
    '''
    fake_route_fd, fake_route_path = tempfile.mkstemp()
    with os.fdopen(fake_route_fd, 'w') as fake_route_file:
        fake_route_file.write(fake_route)

    fake_netstat_fd, fake_netstat_path = tempfile.mkstemp()

# Generated at 2022-06-22 23:37:18.676682
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    network = AIXNetwork(None)

    # line without : should return None
    line = 'hi'
    assert network.parse_interface_line(line) is None

    # line with : should return a dict
    line = 'hi:'
    assert isinstance(network.parse_interface_line(line), dict)

    # line with more than one : should return None
    line = 'hi::'
    assert network.parse_interface_line(line) is None

    # line with interfaces details should return a dict
    line = 'en0: flags=8a63<UP,BROADCAST,NOTRAILERS,RUNNING,ALLMULTI,SIMPLEX,MULTICAST> mtu 1500 index 1'

# Generated at 2022-06-22 23:37:29.653083
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:37:40.013858
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork as t_AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as t_GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:37:52.240704
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # check behavior of method get_default_interfaces with output from 'netstat -nr'
    m = AIXNetwork()

# Generated at 2022-06-22 23:38:03.419333
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>',
        'metric=1', 'mtu=1500', 'options=80000<VLAN_MTU>', 'group:ether', 'media:Ethernet', 'autoselect', 'status:active']
    result = AIXNetwork().parse_interface_line(words)
    assert result['device'] == 'en0'
    assert result['flags'] == ['RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', 'CHECKSUM_OFFLOAD', 'LARGESEND', 'CHAIN']
   

# Generated at 2022-06-22 23:38:10.603457
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    aixnet = AIXNetwork(module)
    result = aixnet.parse_interface_line(['en0:', 'flags=8a63<UP,BROADCAST,NOTRAILERS,RUNNING,'
                                                'ALLMULTI,SIMPLEX,MULTICAST>',
                                          'mtu', '1500'])
    assert result['device'] == 'en0'



# Generated at 2022-06-22 23:38:19.766013
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module_args = dict(
        gather_subset=['!all', '!min'],
    )
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)
    module_params = module.params

    async_facts = AIXNetwork()

    result = async_facts.get_facts(module_params, module)
    assert result['ansible_facts']['ansible_default_ipv4'] == dict(gateway='172.16.102.254', interface='en0')
    assert result['ansible_facts']['ansible_default_ipv6'] == dict(gateway='fe80::21d:66ff:fe4a:b8f8', interface='en0')

# Generated at 2022-06-22 23:38:27.035113
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {})()
    module.run_command = lambda cmd: (0, 'default 192.168.1.1 US.en1', '')
    ans = AIXNetwork.get_default_interfaces(module, '/sbin/route')
    expected = {'interface': 'en1', 'gateway': '192.168.1.1'}
    assert ans['v4'] == expected



# Generated at 2022-06-22 23:38:28.097290
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(module=None))

# Generated at 2022-06-22 23:38:36.716692
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class AIXNetwork_test(AIXNetwork):
        def __init__(self, module, route_path):
            self.module = module
            self.route_path = route_path

    test_if = AIXNetwork_test({}, '/etc/route')

    rc, out, err = test_if.module.run_command(["cat", "tests/facts/network/AIX/netstat.txt"])
    assert rc == 0
    assert len(out.splitlines()) == 1
    assert test_if.get_default_interfaces(test_if.route_path) == ({'gateway': '10.64.16.1', 'interface': 'en0'},)

# Generated at 2022-06-22 23:38:42.967409
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})

    net = AIXNetworkCollector(module=module)
    assert net.facts['default_ipv4'].get('interface') == 'en0'
    assert 'ipv6' in net.facts['default_ipv6']
    assert 'interface' in net.facts['default_ipv6']

# Generated at 2022-06-22 23:38:47.044167
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeModule()
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    AIXNetwork.get_interfaces_info(module, ifconfig_path, ifconfig_options)


# Generated at 2022-06-22 23:38:47.644746
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    NetworkCollector()

# Generated at 2022-06-22 23:38:57.658634
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    module.exists = lambda path: True
    module.get_bin_path = lambda command: "/sbin/netstat"
    module.run_command = lambda *cmd, **kwargs: (0, 'default 192.168.1.1 UG 0 0 en0', '')
    network_class = AIXNetwork(module=module)
    v4_interface, v6_interface = network_class.get_default_interfaces('/tmp')
    assert v4_interface['gateway'] == '192.168.1.1'
    assert v4_interface['interface'] == 'en0'
    assert not v6_interface


# Generated at 2022-06-22 23:39:07.321298
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    class TestClass:
        module = None

    test_instance = TestClass()

    aix_network = AIXNetwork(test_instance)
    words = ['en1:', 'flags=22008a43', 'metric=1', 'groups=1']
    if_dict = aix_network.parse_interface_line(words)
    assert if_dict['device'] == 'en1'

# Generated at 2022-06-22 23:39:16.280038
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_module = Network(module)
    aix_network_module = AIXNetwork(module)
    def mock_run_command(command, check_rc=True):
        rc = 0

# Generated at 2022-06-22 23:39:21.936876
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.__class__.__name__ == 'AIXNetworkCollector'
    assert isinstance(collector._fact_class, AIXNetwork)
    assert collector._fact_class.__class__.__name__ == 'AIXNetwork'
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:39:29.685793
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class module:
        def __init__(self):
            self.params = {}
            self.run_command = run_command

    my_aix_network = AIXNetwork(module)
    assert my_aix_network.get_default_interfaces('/usr/sbin/route') == ({'gateway': '172.16.1.1', 'interface': 'en0'}, {'interface': 'en0', 'gateway': 'fe80::5054:ff:fe32:5b64'})



# Generated at 2022-06-22 23:39:40.970146
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Test data
    test_data = """en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
        inet 10.0.0.1 netmask 0xffffff00 broadcast 10.0.0.255
        inet6 fe80::20c:29ff:fea2:fc00%en0 prefixlen 64 scopeid 0x6 
        ether 00:0c:29:a2:0f:c0
        """

    assert AIXNetwork.get_interfaces_info('ifconfig', '') == ({}, {})


# Generated at 2022-06-22 23:39:45.222256
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule
    module.get_bin_path = lambda x: '/usr/bin/' + x
    module.run_command = lambda x: [0, '', '']

    network_collector = AIXNetworkCollector(module)
    assert network_collector.facts == {}



# Generated at 2022-06-22 23:39:50.942124
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()

    assert net_collector is not None
    assert net_collector._fact_class.__name__ == 'AIXNetwork'
    assert net_collector._fact_class.platform == 'AIX'
    assert net_collector._platform == 'AIX'


# Generated at 2022-06-22 23:39:53.319906
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.fact_class == AIXNetwork
    assert collector.platform == 'AIX'


# Generated at 2022-06-22 23:40:04.342747
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Dummy module and network collector object required for this unit test
    """
    from ansible.module_utils.facts import ModuleDummy
    from ansible.module_utils.facts.network import NetworkDummy

    # Dummy module and network collector object
    mod = ModuleDummy()
    mod.run_command = lambda x, y: [0, '', '']
    net = NetworkDummy(module=mod)

    # sample output of the command 'ifconfig -a'

# Generated at 2022-06-22 23:40:06.464707
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = {}
    p = AIXNetwork(facts, None)
    assert p.platform == 'AIX'

# Generated at 2022-06-22 23:40:17.546523
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:25.233099
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork as ifconfig
    aix = ifconfig()

    class DummyModule(object):
        def get_bin_path(self, arg):
            if arg == 'uname':
                return arg
            else:
                return 'ifconfig'

        def run_command(self, args):
            output = ''
            if args[0] == 'uname':
                output = '0 other'

# Generated at 2022-06-22 23:40:36.183164
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test AIXNetwork
    aixnetwork = AIXNetwork()

    # Test get_default_interfaces method
    class ModuleMock:
        def get_bin_path(self, arg):
            return '/usr/sbin/netstat'


# Generated at 2022-06-22 23:40:38.375297
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'

# Generated at 2022-06-22 23:40:47.857284
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:40:49.948167
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''Test constructor of AIXNetwork'''
    obj = AIXNetwork()
    assert obj

# Generated at 2022-06-22 23:40:58.059637
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    this_obj = AIXNetwork(
        dict(module_name='my_module_name')
    )
    assert this_obj.module_name == 'my_module_name'
    assert this_obj.platform == 'AIX'
    assert this_obj.facts == dict()
    assert this_obj.routes == dict()
    assert this_obj.interfaces == dict()
    assert this_obj.default_ipv4 == dict()
    assert this_obj.default_ipv6 == dict()

# Generated at 2022-06-22 23:41:01.160608
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Basic unit test for constructor of class AIXNetwork
    """
    m = AIXNetwork(dict())
    assert isinstance(m, AIXNetwork)

# Constructor unit test for class AIXNetwork

# Generated at 2022-06-22 23:41:12.158648
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # the output of 'netstat -nr' is
    output = """
    Kernel IP routing table
    Destination        Gateway    Flags Refs Use If Expires
    default            10.178.0.1   UGS     1     0 en0
    10/8               10.178.0.0  U       1     0 en0
    10.178.0/22        10.178.0.0  U       1     0 en0
    127/8              127.0.0.1   UGS     0     0 lo0
    """

    # expect that the default interface for IPv4 is en0
    assert AIXNetwork().get_default_interfaces('')[0]['interface'] == 'en0'

# Generated at 2022-06-22 23:41:20.673858
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = MagicMock()
    module_mock.run_command.return_value = (0, 'default 172.16.60.2 UG 0 0 en0', '')
    module_mock.get_bin_path = MagicMock()
    module_mock.get_bin_path.return_value = '/usr/sbin/netstat'
    aix_network = AIXNetwork(module_mock)
    defaults = aix_network.get_default_interfaces('/usr/sbin/route')
    assert defaults[0] == {'gateway': '172.16.60.2', 'interface': 'en0'}


# Generated at 2022-06-22 23:41:31.679409
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''This test will check if the AIXNetworkCollector class is initialized correctly'''
    std_input_mock = [
# FreeBSD
'''config_value1
config_value2
config_value3''',
# AIX
'''config_value1
config_value2
config_value3''',
# Other
'''config_value1
config_value2
config_value3''']
    module_mock = MockModule(params={})

    # Create the AIXNetworkCollector object
    fact_obj = AIXNetworkCollector(module_mock)

    # Test attribute fact_class
    assert fact_obj.fact_class == AIXNetwork
    # Test attribute platform
    assert fact_obj.platform == 'AIX'


# Generated at 2022-06-22 23:41:37.445627
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:41:48.554648
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    data = '''en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
        inet 10.16.124.168 netmask 0xfffffff0 broadcast 10.16.124.175
        inet6 fe80::215:5dff:fe00:10b8%en0 prefixlen 64 scopeid 0x2
        nd6 options=1<PERFORMNUD>
        media: Ethernet autoselect (100baseTX full-duplex)
        status: active
    '''
    c = AIXNetwork()
    current_if = c.parse_interface_line(data.split())

# Generated at 2022-06-22 23:42:00.166233
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    net.module.params['gather_subset'] = ['!all']

    # test 1
    net.module.run_command = lambda args: (0,
'''default
    192.168.1.1        UG        2 0 en0
default
    192.168.1.1/24     UG        2 0 en0
''', '')
    v4, v6 = net.get_default_interfaces('/sbin/route')

    assert v4['gateway'] == '192.168.1.1' and v4['interface'] == 'en0'

    # test 2

# Generated at 2022-06-22 23:42:10.952921
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ''' Unit test with mock facts
    '''
    # All known options and suboptions together
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    set_module_args(dict(
        gather_subset=['!all', '!min'],
    ))

    # get the network_facts
    net_getter = AIXNetwork(module)

    # get the default interfaces
    v4, v6 = net_getter.get_default_interfaces('/usr/sbin/route')

    # verify the default interface
    assert v4['interface'] == 'en0'
    assert v6['interface'] == 'en0'

    # cleanup
    module = None



# Generated at 2022-06-22 23:42:13.960575
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc = AIXNetwork()
    interfaces, ips = ifc.get_interfaces_info('/usr/bin/ifconfig')
    # device en0 must have mtu attribute
    assert interfaces['en0']['mtu'] is not None

# Generated at 2022-06-22 23:42:26.086223
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # This test requires aix machine
    import os

    if os.uname()[0] != 'AIX':
        return None

    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.plugins.module_utils.network.common.utils import dict_to_set

    module = Mock()
    module.run_command.return_value = (0, ifconfig_output, '')
    module.get_bin_path.return_value = '/usr/bin/ifconfig'

    net = AIXNetwork(module)

    def _run_commands():
        pass

    net.run_commands = _run_commands


# Generated at 2022-06-22 23:42:29.516252
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    net = AIXNetwork(module)
    for attr in dir(net):
        if not attr.startswith('_'):
            assert getattr(net, attr) is not None

# Generated at 2022-06-22 23:42:38.713603
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    # Create a test AIXNetwork object
    aixnetwork_obj = AIXNetwork(module)


# Generated at 2022-06-22 23:42:50.824318
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:52.581293
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork
    assert network_collector._platform == 'AIX'
    assert isinstance(network_collector._fact_class(), AIXNetwork)


# Generated at 2022-06-22 23:43:00.323167
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    testNetwork = AIXNetwork()
    default_v4, default_v6 = testNetwork.get_default_interfaces('/usr/sbin/route')

    assert default_v4['gateway'] == '9.188.30.1'
    assert default_v4['interface'] == 'en2'
    assert default_v6['gateway'] == 'fe80::21a:4aff:feb3:1a23'
    assert default_v6['interface'] == 'en2'

# Generated at 2022-06-22 23:43:12.433538
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    line1 = "lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232         "
    line2 = "        inet 127.0.0.1 netmask 0xff000000          "
    line3 = "        inet6 ::1/128                              "
    line4 = "en0: flags=8963<UP,BROADCAST,SMART,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500          "
    line5 = "        lladdr 00:11:22:33:44:55                   "
    line6 = "        media: autoselect (1000baseT ) status: active "
    line7 = "        inet 10.33.44.55 netmask 0xffffff00 broadcast 10.33.44.255 "

# Generated at 2022-06-22 23:43:13.219594
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aixnetwork=AIXNetwork()

    assert aixnetwork.platform == 'AIX'

# Generated at 2022-06-22 23:43:23.121601
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    with open('/tmp/ansible_get_default_interfaces_test', 'w') as f:
        f.write('default 192.0.2.1 UG    0 0        en0\n')

    AIX_network = AIXNetwork()
    AIX_network.module.get_bin_path = lambda path: '/tmp/ansible_get_default_interfaces_test'
    assert AIX_network.get_default_interfaces('/tmp/ansible_get_default_interfaces_test') == (
        {'gateway': '192.0.2.1', 'interface': 'en0'},
        {},
        )

# Generated at 2022-06-22 23:43:24.141425
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

# Generated at 2022-06-22 23:43:36.052173
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route = dict(
        default_interface_v4=dict(),
        default_interface_v6=dict()
    )

# Generated at 2022-06-22 23:43:39.692140
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.__class__.__name__ == 'AIXNetworkCollector'
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class.__name__ == 'AIXNetwork'

# Generated at 2022-06-22 23:43:51.543333
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:00.667259
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
  import unittest
  from ansible.module_utils.facts.network.aix import AIXNetwork

  net = AIXNetwork()

  tc_in = list(('lo0 up',))
  tc_out = list((dict(device='lo0', ipv4=[], ipv6=[], type='unknown', flags='up', macaddress='unknown'),))
  for x in range(len(tc_in)):
    out = net.parse_interface_line(tc_in[x].split())
    assert(out == tc_out[x])
    print('Test case ' + str(x + 1) + ' passed')
  print('Test of method parse_interface_line passed')

# Generated at 2022-06-22 23:44:03.422306
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    '''unit test for constructor of class AIXNetworkCollector'''
    aix_network_coll = AIXNetworkCollector()
    assert aix_network_coll.platform == 'AIX'

# Generated at 2022-06-22 23:44:07.247432
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test AIXNetworkCollector constructor.
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:44:14.169968
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_AIXNetwork = AIXNetwork({})
    test_string = 'en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 1'
    test_words = test_string.split()
    test_current_if = test_AIXNetwork.parse_interface_line(test_words)
    assert test_current_if['device'] == 'en0'
    assert test_current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']
    assert test_current_if['type'] == 'unknown'
    assert 'mtu' not  in test_current_if

# Generated at 2022-06-22 23:44:25.097533
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_AIXNetwork = AIXNetwork()

# Generated at 2022-06-22 23:44:36.681070
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class Options:
        def __init__(self, module):
            self.module = module
            self.bin_path = {}
            self.bin_path['ifconfig'] = '/usr/sbin/ifconfig'
            self.bin_path['netstat'] = '/usr/bin/netstat'
            self.bin_path['uname'] = '/bin/uname'
            self.bin_path['entstat'] = '/usr/sbin/entstat'
            self.bin_path['lsattr'] = '/usr/bin/lsattr'

    class Module:
        def __init__(self):
            self.options = Options(self)
            self.params = {'gather_subset': ['!all', 'network']}

        def get_bin_path(self, name):
            return self.options.bin_

# Generated at 2022-06-22 23:44:45.482240
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_class = AIXNetwork()
    line = 'lo0: flags=1e080863,480<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    words = line.split()
    expected = {'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'VIRTUAL'], 'device': 'lo0', 'ipv6': [], 'ipv4': [],
                'type': 'unknown', 'macaddress': 'unkown'}
    assert test_class.parse_interface_line(words) == expected



# Generated at 2022-06-22 23:44:53.254275
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec=dict())
    ifc = AIXNetwork(module=mod)
    res = dict(**ifc.get_interfaces_facts())
    assert res['ansible_facts']['ansible_net_interfaces'] is not None
    assert res['ansible_facts']['ansible_net_all_ipv4_addresses'] is not None
    assert res['ansible_facts']['ansible_net_all_ipv6_addresses'] is not None

# Generated at 2022-06-22 23:45:03.691733
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''Unit test for get_default_interfaces'''
    module = FakeModule()
    mock_open = mock.mock_open()

# Generated at 2022-06-22 23:45:15.928956
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # create instance of class AIXNetwork
    ansible_class = AIXNetwork()

    # create a dict of return values of methods
    # without these values the unittests fail

# Generated at 2022-06-22 23:45:21.056509
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Unit test for constructor of class AIXNetwork
    """
    module = AnsibleModule(argument_spec=dict())
    result = AIXNetwork(module)
    assert result.platform == 'AIX'
    assert result.default_options == '-a'
    assert result.ifconfig_options == '-a'
