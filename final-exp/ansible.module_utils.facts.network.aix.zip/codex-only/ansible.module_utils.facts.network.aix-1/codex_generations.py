

# Generated at 2022-06-22 23:35:26.370384
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test data:
    # test_default_interfaces_raw contains "test_default_interfaces" command output
    test_default_interfaces = dict(
        v4=dict(
            gateway='192.168.0.254',
            interface='lo0',
        ),
        v6=dict(
            gateway='fe80::5400:1ff:fe83:7e0e',
            interface='en0',
        ),
    )

# Generated at 2022-06-22 23:35:34.362235
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_line = 'en0: flags=0x80a0810c<BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),DHCP,IPv6> mtu 1500 index 5'
    words = ifconfig_line.split()
    current_if = dict(device='en0', flags=list(set(['BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD', 'DHCP', 'IPv6'])), mtu='1500', index='5', macaddress='unknown')
    test_if = AIXNetwork().parse_interface_line(words)
    assert test_if == current_if

# Generated at 2022-06-22 23:35:45.624599
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    class MockModule(object):
        def get_bin_path(self, path, opt_dirs=None, required=False):
            if path == 'netstat':
                return path
            if path == 'uname':
                return path
            if path == 'lsattr':
                return path
            if path == 'entstat':
                return path
            return None

    class MockNetwork(object):
        def __init__(self):
            pass

        def run_command(self, args):
            if args[0] == 'netstat':
                return (0, "default 192.168.1.1 UG 1 0 en0\ndefault ::1 UG 1 0 en0", None)
            if args[0] == 'uname':
                return (0, "0 AIX\n", None)

# Generated at 2022-06-22 23:35:51.503487
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork(dict())

    assert net.get_default_interfaces('/etc/my_route.txt') == ({}, {})

    assert net.get_default_interfaces('/etc/route.txt') == ({'gateway': '10.10.10.1', 'interface': 'en0'}, {'gateway': 'ff00::1', 'interface': 'en1'})



# Generated at 2022-06-22 23:35:57.579459
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Check if AIXNetwork exists and it is an instance of Network"""

    assert ('ansible.module_utils.facts.network.aix.AIXNetwork' in globals()),\
        "AIX network class not defined"
    aix_net = AIXNetwork(None)
    assert isinstance(aix_net, NetworkCollector),\
        "AIX network class not instance of Network"

# Generated at 2022-06-22 23:36:04.566926
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    fake_module = NetworkCollector
    fake_module.run_command = lambda *args: (0, '', '')
    AIXNetwork(fake_module)
    assert AIXNetwork._platform == 'AIX'
    assert AIXNetwork.platform == 'AIX'
    assert AIXNetwork._fact_class == AIXNetwork
    AIXNetwork.__init__(fake_module)

# Generated at 2022-06-22 23:36:14.060244
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = type('DummyModule', (object,), {'params': {}, 'run_command': lambda self, args, check_rc=True: (0, '', '')})()
    ansible_facts = dict()
    network = AIXNetwork(module, ansible_facts)


# Generated at 2022-06-22 23:36:24.648126
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:36:32.248670
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    Run a test to verify that method get_default_interfaces
    of class AIXNetwork returns the correct output.
    '''

    module = AnsibleModule(argument_spec={})
    net = AIXNetworkCollector(module=module).collect()
    assert net[0]['default_interface']['v4']['gateway'] == '172.31.255.254'
    assert net[0]['default_interface']['v4']['interface'] == 'lo0'
    assert net[0]['default_interface']['v6']['gateway'] == 'fe80::2bf1:b5ff:fe3f:52c9%lo0'
    assert net[0]['default_interface']['v6']['interface'] == 'lo0'

# Generated at 2022-06-22 23:36:34.538487
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:36:44.634200
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig = AIXNetwork()
    line = 'lo0: flags=e080863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,LARGESEND,CHAIN> inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255 inet6 ::1%1/0 tcp_sendspace 131072 tcp_recvspace 131072 rfc1323 1 nd6 options=3<PERFORMNUD,ACCEPT_RTADV>'
    words = line.split()
    expected_result = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    expected_result['flags'] = ifconfig.get_options(words[1])


# Generated at 2022-06-22 23:36:55.795218
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    cls = AIXNetwork(module)
    import os
    if os.path.exists('/etc/ibm/sysmgt/dmi/defaults/mac'):
        os.rename('/etc/ibm/sysmgt/dmi/defaults/mac', '/etc/ibm/sysmgt/dmi/defaults/mac.bak')

# Generated at 2022-06-22 23:37:03.966958
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()
    current_if = network.parse_interface_line(['en0:', 'flags=842<BROADCAST,RUNNING,MULTICAST>'])
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:37:09.804799
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    facts = dict()
    facts_network_result = dict(interfaces={}, all_ipv4_addresses=[], all_ipv6_addresses=[])

    fact_network = AIXNetworkCollector(facts, '/sbin')
    assert fact_network.platform == 'AIX', 'Incorrect platform returned'
    assert fact_network.facts == facts, 'Incorrect facts dictionary passed'
    assert fact_network.bin_path == '/sbin', 'Incorrect binary path'
    assert fact_network.get_facts() == facts_network_result, 'Incorrect facts returned'

# Generated at 2022-06-22 23:37:13.981161
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork


# Generated at 2022-06-22 23:37:16.273548
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_net = AIXNetwork()
    assert aix_net.platform == 'AIX'



# Generated at 2022-06-22 23:37:19.976845
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__class__.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'



# Generated at 2022-06-22 23:37:30.633947
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Create a test class
    class testclass():

        def __init__(self):
            pass

        def get_bin_path(self, res):
            return False

    # Instantiate the test class
    mod = testclass()

    # Instantiate the class under test
    nc = AIXNetwork(mod)

    # Test with empty input
    input = ""
    output = nc.parse_interface_line(input.split())
    assert output == {'device': '', 'ipv4': [], 'ipv6': []}

    # Test with a valid input
    input = "en0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST> mtu 1500"
    output = nc.parse_interface_line(input.split())

# Generated at 2022-06-22 23:37:41.160851
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ Check output of get_interfaces_info of AIXNetwork """
    facts_aix = AIXNetwork()

    # ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_path = './test/unit/module_utils/facts/network/test_AIX_ifconfig.txt'

    actual = facts_aix.get_interfaces_info(ifconfig_path)
    assert actual[0]['lo0']['mtu'] == 65536
    assert actual[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert actual[0]['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-22 23:37:53.057387
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ifconfig_path = module.get_bin_path('ifconfig')

    if not ifconfig_path:
        module.fail_json(msg='ifconfig is required but does not exist')

    facts = dict(
        default_ipv4={},
        default_ipv6={},
    )

    # Create AIXNetwork object
    network_collector = AIXNetwork(module)

    # Test method get_default_interfaces
    # Test 1
    interface = network_collector.get_default_interfaces('netstat -nr')


# Generated at 2022-06-22 23:38:04.109440
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    mac = 'unknown'
    flags = ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    aix_network = AIXNetwork(module)
    aix_network.parse_interface_line(['en0:', 'flags=0x863<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>'])
    assert aix_network.current_if['device'] == 'en0'
    assert aix_network.current_if['ipv4'] == []
    assert aix_network.current_if['ipv6'] == []
    assert aix_network.current_if['type'] == 'unknown'
    assert aix_network.current_if['mtu'] == ''
   

# Generated at 2022-06-22 23:38:15.562727
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import tempfile
    temp_out = tempfile.TemporaryFile()

    test_out = '''
name0: flags=40000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 1
        inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
        lladdr 00:00:00:00:00:00
othername: flags=40000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 1
        inet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255
        lladdr 00:11:22:33:44:55 media: Ethernet autoselect (1000baseT) status: active
    '''

# Generated at 2022-06-22 23:38:22.970299
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """This test function tests method get_interfaces_info of class AIXNetwork."""

    module_mock = NetworkCollector.get_module_mock()

# Generated at 2022-06-22 23:38:32.816209
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = type('AnsibleModule', (object,), dict(params=dict()))
    my_aixnetwork = AIXNetwork(module)
    assert my_aixnetwork.platform == 'AIX'
    assert my_aixnetwork.interfaces is None
    assert my_aixnetwork.interfaces_ipv4 is None
    assert my_aixnetwork.interfaces_ipv6 is None
    assert my_aixnetwork.default_ipv4 is None
    assert my_aixnetwork.default_ipv6 is None
    assert my_aixnetwork.netmask is None
    assert my_aixnetwork.netmask_ipv6 is None



# Generated at 2022-06-22 23:38:33.795538
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork()


# Generated at 2022-06-22 23:38:34.576516
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network_facts = AIXNetwork()
    assert network_facts.platform == 'AIX'


# Generated at 2022-06-22 23:38:43.363456
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_network = AIXNetworkCollector()._fact_class()
    line = 'ent0: flags=8c03<UP,BROADCAST,RUNNING,OACTIVE,SIMPLEX,MULTICAST>'
    verbose = True
    words = line.split()
    result = ifconfig_network.parse_interface_line(words)
    assert result == dict(
        device='ent0',
        flags=['UP', 'BROADCAST', 'RUNNING', 'OACTIVE', 'SIMPLEX', 'MULTICAST'],
        ipv4=[],
        ipv6=[],
        macaddress='unknown',
        type='unknown')

# Generated at 2022-06-22 23:38:47.815847
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    net = AIXNetwork(module)
    rc, out, err = module.run_command.call_args[0][0]
    assert rc == 0
    assert out in ['netstat -nr\n', 'netstat -nr\n\n']


# Generated at 2022-06-22 23:38:59.312342
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    current_if = {}
    line1 = 'en1      links up'
    words = line1.split()
    current_if = AIXNetwork.parse_interface_line(AIXNetwork, words)
    interfaces[current_if['device']] = current_if

    current_if = {}
    line2 = '    nd6 options=3<PERFORMNUD,ACCEPT_RTADV>'
    words = line2.split()
    AIXNetwork.parse_options_line(AIXNetwork, words, current_if, ips)

    current_if = {}

# Generated at 2022-06-22 23:39:09.258847
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ansible_facts = {}
    facts={}

    # create a mock of module
    ansible_facts_module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # create a mock of class AIXNetwork and its method get_interfaces_info
    class AIXNetwork:
        def get_interfaces_info(self, ifconfig_path, ifconfig_options):

            # create a mock of command run by get_interfaces_info
            rc = 0

# Generated at 2022-06-22 23:39:11.169093
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.get_interfaces_info('ifconfig')[0] == {}

# Generated at 2022-06-22 23:39:18.316828
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {})()
    module.run_command = type('', (), {})()
    module.run_command.return_value = (0, '''default 192.168.0.1 UG 1 1 en0
default fe80::%en0 U 0 1 2
''', None)

    module.get_bin_path = type('', (), {})()
    module.get_bin_path.return_value = '/bin/netstat'

    network = type('', (), {})()
    module.network_resources = type('', (), {})()
    module.network_resources.AIX = network

    interfaces = AIXNetwork()
    interfaces.module = module

# Generated at 2022-06-22 23:39:22.509367
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    net_collector = AIXNetworkCollector(module=module)
    assert isinstance(net_collector._fact_class, AIXNetwork)
    assert net_collector._platform == 'AIX'


# Generated at 2022-06-22 23:39:32.110976
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'route_path': {'type': 'path', 'required': True},
                                          'ifconfig_path': {'type': 'path', 'required': True}})
    network = AIXNetwork(module)
    interface_v4, interface_v6 = network.get_default_interfaces(module.params['route_path'])

# Generated at 2022-06-22 23:39:35.707298
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    n = AIXNetwork(module)
    v4_gw, v6_gw = n.get_default_interfaces('/bin/netstat')
    assert v4_gw == {'gateway': '10.1.1.1', 'interface': 'en3'}
    assert v6_gw == {'gateway': 'fe80::1', 'interface': 'en2'}


# Generated at 2022-06-22 23:39:43.915426
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    Test is based on aix_ifconfig_a.txt file that contains output of ifconfig -a
    command from AIX 6.1 TL7 SP7.
    """
    ansible_module = MockAnsibleModule()
    ansible_module.params = dict()
    ansible_module.run_command = MockAnsibleModule.run_command


# Generated at 2022-06-22 23:39:48.347424
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    
    net_collector = AIXNetworkCollector()
    assert net_collector._platform == 'AIX'
    assert net_collector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:39:59.558571
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # test when the module has been imported
    module = type('module', (object,), dict())()
    module.params = dict(
        gather_subset=['all'],
        config=dict(),
    )

    c = AIXNetworkCollector(module)
    assert c.__class__.__name__ == 'AIXNetworkCollector'
    assert hasattr(c, '_fact_class')
    assert c._fact_class.__class__ == AIXNetwork

    # test when the module has not been imported
    module = type('module', (object,), dict())()
    module.params = dict(
        gather_subset=['all'],
        config=dict(),
    )

    c = AIXNetworkCollector(module, platform='AIX')

# Generated at 2022-06-22 23:40:11.865559
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockNetworkModule()
    obj = AIXNetwork(module=module)

    netstat = module.get_bin_path('netstat')

    # AIX default route for IPv4
    cmd = [netstat, '-nr']
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    assert out == 'default 192.0.2.1 UG 1 2 en0\n'

    v4, v6 = obj.get_default_interfaces(netstat)
    assert v4['gateway'] == '192.0.2.1'
    assert v4['interface'] == 'en0'

    # AIX default route for IPv6
    cmd = [netstat, '-nr']
    rc, out, err = module.run_command(cmd)
    assert rc == 0


# Generated at 2022-06-22 23:40:20.823285
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Possible interface name equals to 20 chars
    iface = dict(
        name='eth0                 ',
        ipv4=[],
        ipv6=[],
        islagg={},
        macaddress='unknown',
        type='unknown',
        flags=['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST', 'IPv4'],
        mtu='65535',
        media='1000baseT <Full-duplex>',
        status='active',
        lladdr='52:54:00:12:35:12'
    )

    # Creating a fake module and loading some of its methods
    class Module:
        def __init__(self):
            pass

        def get_bin_path(self, arg):
            return None


# Generated at 2022-06-22 23:40:27.653398
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    This testcase tests the constructor of class AIXNetwork
    '''

    # Testcase 1:
    # Constructor should create default attribute values
    # for valid input

# Generated at 2022-06-22 23:40:36.137495
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fact_class = AIXNetwork(dict(module=None))
    fact_class.get_default_interfaces(route_path=None)
    assert fact_class.default_interface['v4']['gateway'] == '192.168.1.1'
    assert fact_class.default_interface['v4']['interface'] == 'en0'
    assert fact_class.default_interface['v6']['gateway'] == 'fe80::218:e7ff:fe4b:4b65'
    assert fact_class.default_interface['v6']['interface'] == 'en0'

# Generated at 2022-06-22 23:40:46.158037
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # class instance
    c = AIXNetwork(dict())

    # arguments to parse_interface_line
    words = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '32768', 'index', '1']

    # expected result
    expected = dict(
        device = 'lo0',
        flags = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        mtu = '32768',
        index = '1',
        ipv4 = [],
        ipv6 = [],
        type = 'unknown',
        macaddress = 'unknown',    # will be overwritten later
    )

    result = c.parse_interface_line(words)

    # check result
    assert result == expected

# Generated at 2022-06-22 23:40:55.731611
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    modules = dict(
        ifconfig_path='/bin/ifconfig',
        route_path='/sbin/route',
        platform='AIX',
    )
    ansible_module_mock = MockAnsibleModule(params=modules)
    aix_network_test = AIXNetwork(ansible_module_mock)

    assert_equal(aix_network_test.platform, 'AIX')
    assert_equal(aix_network_test.ifconfig_path, '/bin/ifconfig')
    assert_equal(aix_network_test.route_path, '/sbin/route')
    assert_equal(aix_network_test.module, ansible_module_mock)



# Generated at 2022-06-22 23:41:03.630172
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    v4_route, v6_route = aix_network.get_default_interfaces('/my/route/path')
    assert v4_route['gateway'] == '192.168.1.1'
    assert v4_route['interface'] == 'en0'
    assert v6_route['gateway'] == 'fe80::60b9:e7ff:fe9a:b1f8%en0'
    assert v6_route['interface'] == 'en0'



# Generated at 2022-06-22 23:41:16.022432
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule:
        def get_bin_path(self, arg):
            return '/usr/sbin/' + arg
        def run_command(self, arg):
            if re.match(r'^\[' + re.escape('/usr/sbin/uname'), arg[0]):
                return 0, '0' + '\n', ''
            elif re.match(r'^\[' + re.escape('/usr/sbin/ifconfig'), arg[0]):
                return 0, ifconfig_out, ''

# Generated at 2022-06-22 23:41:21.586918
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    rc, out, err = AIXNetwork.module.run_command([ifconfig_path, ifconfig_options])

    ifs = out.split('\n\n')

    anet = AIXNetwork(module=AIXNetwork.module)

    for iface in ifs:
        words = iface.split()
        current_if = anet.parse_interface_line(words)
        assert current_if['device'] == words[0][0:-1]

# Generated at 2022-06-22 23:41:32.652594
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['all'])})
    result = dict(
        changed=False,
        ansible_facts=dict(
            ansible_default_ipv4=dict(
                gateway='10.0.2.2',
                interface='eth0',
            ),
            ansible_default_ipv6=dict(
                gateway='fe80::200:ff:fe00:28',
                interface='wlan1',
            )
        )
    )
    assert AIXNetwork(module).get_default_interfaces() == result['ansible_facts']['ansible_default_ipv4'], \
        result['ansible_facts']['ansible_default_ipv6']


# Generated at 2022-06-22 23:41:39.834625
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    network = AIXNetwork()

    def run_command(cmd, *args, **kwargs):
        """Mock for ansible module run_command"""

# Generated at 2022-06-22 23:41:42.280791
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    testobj = AIXNetwork()
    assert isinstance(testobj, AIXNetwork)


# Generated at 2022-06-22 23:41:51.947043
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts import collector

    # version 1: empty line in output
    expected = dict(v4=dict(gateway='172.16.10.254', interface='en0'), v6=dict(gateway='xxxx:xxxx::xxxx:xxxx', interface='en0'))
    network_collector = collector.get_network_collector(dict(), 'AIX')
    actual = network_collector._get_default_interfaces(None)
    assert expected == actual

    # version 2: without empty line in output
    expected = dict(v4=dict(gateway='172.16.10.254', interface='en0'), v6=dict(gateway='xxxx:xxxx::xxxx:xxxx', interface='en0'))
    network_collector = collector.get_network_collector(dict(), 'AIX')

# Generated at 2022-06-22 23:42:03.202511
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # test data
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()

    # create AIXNetwork object
    test_object = AIXNetwork()

    # provide input and assert output

# Generated at 2022-06-22 23:42:14.553071
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec=dict())

    result = {}
    result["failed"] = False
    load_platform_subclass(NetworkCollector, 'AIX', result)
    assert 'fact_class' in result
    assert result['fact_class'] == 'ansible.module_utils.facts.aix.network.AIXNetwork'
    facts = result['ansible_network_resources']
    assert facts['bond0']['device'] == 'bond0'
    assert facts['bond0']['macaddress'] == '80:2a:a8:42:c1:41'
    assert facts['bond0']['mtu'] == '65536'
    assert facts['bond0']['type'] == 'bond'

# Generated at 2022-06-22 23:42:18.708615
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec={})
    network_module = AIXNetwork(mod)

    assert network_module._platform == 'AIX'
    assert network_module._fact_class == AIXNetwork

# Generated at 2022-06-22 23:42:22.657873
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    o = AIXNetwork({})
    assert o.platform == 'AIX'
    assert o.default_interfaces == {'v4': {}, 'v6': {}}

# Generated at 2022-06-22 23:42:28.886692
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    a = AIXNetwork()
    words = 'en0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500'.split()
    current_if = a.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:42:38.649730
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    "Unit test for method parse_interface_line of class AIXNetwork"

    # Initialize class
    aix_network = AIXNetwork(dict())

    # my_words variable represents output from: ifconfig en3
    my_words = ["en3:", "flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>",
                "inet", "10.0.0.11", "netmask", "0xffffff00", "broadcast", "10.0.0.255"]

    # parse_interface_line() should return

# Generated at 2022-06-22 23:42:45.913316
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    facter = AIXNetwork()
    words = "ent0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 6".split()
    current_if = facter.parse_interface_line(words)
    assert current_if['device'].startswith("ent")

# Note: this is not a robust test.  It only tests that the methods exist,
# not if they work properly.

# Generated at 2022-06-22 23:42:51.749897
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector, '_fact_class')
    assert hasattr(AIXNetworkCollector, '_platform')
    try:
        aix = AIXNetworkCollector()
    except Exception:
        aix = None
    assert aix._fact_class is not None
    assert aix._platform == 'AIX'


# Generated at 2022-06-22 23:42:59.643373
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    _route_path = '/etc/hosts'
    _net = AIXNetwork()
    _v4, _v6 = _net.get_default_interfaces(_route_path)
    assert _v4['gateway'] == '192.168.0.1'
    assert _v4['interface'] == 'en0'
    assert _v6['gateway'] == '2001:db8::ff00:42:8329'
    assert _v6['interface'] == 'en1'


# Generated at 2022-06-22 23:43:11.584458
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible.module_utils import basic

    import ansible_collections.ansible.netcommon.plugins.module_utils.network.aix.facts.network as aix_network

    class TestAIXNetworkGetDefaultInterfaces(unittest.TestCase):

        def setUp(self):
            self.module = basic.AnsibleModule(
                argument_spec=aix_network.AIXXNetwork.argument_spec,
            )

            self.module.params = {
                'gather_subset': ['!all', '!min'],
            }


# Generated at 2022-06-22 23:43:18.623632
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # In this test, we mock the methods run_command() and
    # get_bin_path() in the base class NetworkCollector.

    import os
    import tempfile

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = tempfile.mkdtemp()

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            if self.params.get('command_failures', {}).get(args[0]):
                rc = 1
                out = b''
                err = b'Error'
            else:
                dir = self.params.get('command_results', {}).get(args[0], '')

# Generated at 2022-06-22 23:43:21.750054
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collectorname = 'AIXNetworkCollector'
    AIXNetworkCollector('test', 'AIX')


# Generated at 2022-06-22 23:43:33.201318
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    i1 = dict(v4={'gateway': '1.1.1.1', 'interface': 'eth0'},
              v6={'gateway': '2001:f00::1', 'interface': 'eth1'})
    m1 = dict(run_command=lambda x: (0, '''Internet:
Destination        Gateway            Flags     Refs      Use   Mtu  Interface
default            1.1.1.1            UG         36     94554     -    en0
default            2001:f00::1        UG         10     94554     -    en1''', ''))

    i2 = dict(v4={'gateway': '1.1.1.1', 'interface': 'eth0'},
              v6={'gateway': '2001:f00::1', 'interface': None})
   

# Generated at 2022-06-22 23:43:44.737235
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This method tests the get_interfaces_info method of the AIXNetwork class
    against empty input and checks that it does not fail.
    """
    network = AIXNetwork()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    facts = dict(
        ansible_interfaces=[],
        ansible_all_ipv4_addresses=[],
        ansible_all_ipv6_addresses=[],
    )
    (interfaces, ips) = network.get_interfaces_info('')
    network.populate(facts, interfaces, ips)

# Generated at 2022-06-22 23:43:54.818204
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test with the default file: it should return the interface en0
    ifconfig_path = '/usr/sbin/ifconfig'
    route_path = '/etc/route'
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module=module, ifconfig_path=ifconfig_path, route_path=route_path)
    interface = {}
    interface['v4'], interface['v6'] = network_collector.get_default_interfaces(route_path)

    assert interface['v4']['gateway'] == '192.168.2.1'
    assert interface['v4']['interface'] == 'en0'
    # On AIX, gateway cannot be set for IPv6
    assert interface['v6'] == {}



# Generated at 2022-06-22 23:43:56.162950
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:44:02.211548
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    if not module.check_mode:
        # run_command() is mocked and module.run_command() is called
        AIXNetwork(module)
    pass

from ansible.module_utils.basic import *
main = AnsibleModule(argument_spec={})
if not main.check_mode:
    AIXNetworkCollector.collect(main)
    print(json.dumps(main.ansible_facts, indent=4))

# Generated at 2022-06-22 23:44:05.208255
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector constructor"""
    collector = AIXNetworkCollector(None, None, None)
    assert collector is not None
    assert collector._platform == 'AIX'
    assert collector._fact_class is AIXNetwork


# Generated at 2022-06-22 23:44:06.041296
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork()



# Generated at 2022-06-22 23:44:13.811587
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork class"""

    aix_net = AIXNetwork()
    assert aix_net.platform == 'AIX'
    assert aix_net.platform_version == None
    assert aix_net.flags == None
    assert aix_net.name == None
    assert aix_net.interface == None
    assert aix_net.state == None
    assert aix_net.address == None
    assert aix_net.netmask == None
    assert aix_net.broadcast == None
    assert aix_net.macaddress == None
    assert aix_net.device == None
    assert aix_net.mtu == None
    assert aix_net.alias == False
    assert isinstance(aix_net, AIXNetwork)

# Generated at 2022-06-22 23:44:23.105934
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    aixObj = AIXNetwork(module)
    defaults = dict(v4=dict(interface='lo0', gateway='127.0.0.1'),
                     v6=dict(interface='lo0', gateway='::1'))

    aixObj.module.run_command = FakeRunCommand

    ipv4_default, ipv6_default = aixObj.get_default_interfaces(route_path)

    assert ipv4_default == defaults['v4']
    assert ipv6_default == defaults['v6']



# Generated at 2022-06-22 23:44:24.503342
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aixnetwork = AIXNetwork()
    assert aixnetwork.platform == 'AIX'


# Generated at 2022-06-22 23:44:35.868105
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'path': dict(required=True)})
    module.run_command = MagicMock(return_value=(0, 'default 192.0.2.1 UGSc 0 192.0.2.190 en0\ndefault 2001:db8:a0b:12f0::1 UGSc 0 2001:db8:a0b:12f0::c8 en0', ''))
    aix_network = AIXNetwork(module)
    actual_result = aix_network.get_default_interfaces('test_path')
    assert actual_result == {'gateway': '192.0.2.1', 'interface': 'en0'}, actual_result


# Generated at 2022-06-22 23:44:41.465909
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc.platform == 'AIX'
    assert nc.paths == ['/etc/networks', '/etc/sysconfig/network', '/usr/sbin/ifconfig']
    assert nc.platform_sort_order == 15
    assert nc.interfaces_class == AIXNetwork
    assert nc.interfaces_fact_class == AIXNetwork


# Generated at 2022-06-22 23:44:53.487180
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class Options(object):
        def __init__(self, path, options):
            self.path = path
            self.options = options

    test_obj = AIXNetwork()
    test_obj.module = Options('/usr/sbin/ifconfig', '-a')

    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.aix_test_output import AIX_IFCONFIG_PATH_AAS_OUT
    print('Testing AIXNetwork.get_interfaces_info() with ifconfig_path=/usr/sbin/ifconfig, ifconfig_options="-a" and ifconfig -a output:')
    print(AIX_IFCONFIG_PATH_AAS_OUT)


# Generated at 2022-06-22 23:45:03.857413
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface = AIXNetwork()
    aix_if = interface.parse_interface_line(['en1:', 'flags=8b43<UP,BROADCAST,RUNNING,PROMISC,ALLMULTI,SIMPLEX,GROUPRT,MULTICAST>', 'mtu', '1500'])
    assert aix_if['device'] == 'en1'
    assert aix_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'ALLMULTI', 'SIMPLEX', 'GROUPRT', 'MULTICAST']
    assert aix_if['macaddress'] == 'unknown'
    assert aix_if['type'] == 'unknown'
    assert len(aix_if['ipv4']) == 0

# Generated at 2022-06-22 23:45:06.627072
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()

    network_module = AIXNetwork(module)

    assert network_module.default_ipv4_interface



# Generated at 2022-06-22 23:45:09.272277
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform is 'AIX'


# Generated at 2022-06-22 23:45:21.105550
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    f = AIXNetwork()
    # f.module.run_command is mocked here to run the command passed to it, and returns the stdout of the command as a string
    # f.module.get_bin_path is mocked here to return the command sent as a string
    # f.module.run_command(['/bin/uname', '-W']) will return (0, '0', '')
    # f.module.get_bin_path('uname') will return 'uname'
    # f.module.run_command(['uname', '-W']) will return (0, '0', '')
    f.module.run_command = lambda cmd, *args, **kwargs: (0, cmd[0], '')
    f.module.get_bin_path = lambda x, *args, **kwargs: x