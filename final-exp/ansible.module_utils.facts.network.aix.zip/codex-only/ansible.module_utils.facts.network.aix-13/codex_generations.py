

# Generated at 2022-06-22 23:35:30.857132
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class Module:
        def get_bin_path(self, arg):
            return '/usr/sbin/netstat'

        def run_command(self, args):
            if args[0] == '/usr/sbin/netstat':
                return 0, 'default 192.168.0.1 UGS 0 15004 en0\ndefault fe80::%en0 UGHL 0 15004 en0\ndefault ::1 UH lo0\n', ''
            return 1, '', 'command not found'

    class Network_Class:
        platform = 'AIX'

    module = Module()
    net_class = Network_Class()
    result = AIXNetwork.get_default_interfaces(net_class, module, '')

# Generated at 2022-06-22 23:35:42.766714
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:35:53.822457
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    '''test_AIXNetwork_parse_interface_line - Test AIXNetwork.parse_interface_line'''
    test_module = 'ansible.module_utils.facts.network.aix.AIXNetwork'
    test_class = 'AIXNetwork'
    test_function = 'parse_interface_line'

    # Relative import of AIXNetwork class
    module = __import__(test_module, fromlist=[test_class])
    classobj = getattr(module, test_class)
    funcobj = getattr(classobj, test_function)

    # Create an instance of AIXNetwork
    obj = classobj()


# Generated at 2022-06-22 23:35:57.288906
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Testing if constructor of AIXNetwork is working as expected
    network_aix_test = AIXNetwork({})

    assert network_aix_test is not None

# Generated at 2022-06-22 23:36:09.034687
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    runner = CliRunner()
    result = runner.invoke(module.ansible_module)

    default_interfaces = AIXNetwork(module).get_default_interfaces('/sbin/route')

    assert result.exit_code == 0, 'non-zero exit code'
    assert isinstance(default_interfaces, tuple), 'should be a tuple'
    assert len(default_interfaces) == 2, 'tuple should have 2 items'
    assert isinstance(default_interfaces[0], dict), 'first item should be a dictionary'
    assert isinstance(default_interfaces[1], dict), 'second item should be a dictionary'
    assert 'gateway' in default_interfaces[0], 'first item should have gateways'

# Generated at 2022-06-22 23:36:10.701476
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork({})
    assert net.platform == 'AIX'


# Generated at 2022-06-22 23:36:18.327058
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = AIXNetwork(None, None)
    words = ['en0:', 'flags=80c80000,c0100', '10:00:00:02:ac:00']
    current_if = m.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['80c80000', 'c0100']
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-22 23:36:27.561762
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:36:39.307007
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Unit test for finding facts of type AIXNetwork"""
    ansible_module = get_module_mock()

    ifconfig_path = ansible_module.get_bin_path('ifconfig')
    netstat_path = ansible_module.get_bin_path('netstat')
    lsattr_path = ansible_module.get_bin_path('lsattr')
    entstat_path = ansible_module.get_bin_path('entstat')
    uname_path = ansible_module.get_bin_path('uname')

    ansible_module.run_command.assert_any_call([uname_path, '-W'])
    ansible_module.run_command.assert_any_call([ifconfig_path, '-a'])
    ansible_module.run_command.assert_

# Generated at 2022-06-22 23:36:46.983756
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_module = FakeModule(ansible_facts={})
    aix_network = AIXNetwork(fake_module)
    aix_network.route_path = '/usr/bin/netstat'
    route_path = aix_network.route_path
    result = aix_network.get_default_interfaces(route_path)
    print('result={}'.format(result))
    assert result == ({'gateway': '1.2.3.4', 'interface': 'lo0'},
                      {'gateway': 'fe80::', 'interface': 'lo0'})

    fake_module = FakeModule(ansible_facts={})
    aix_network = AIXNetwork(fake_module)
    aix_network.route_path = '/usr/bin/netstat'
    route_path = aix_

# Generated at 2022-06-22 23:36:53.395783
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Test AIXNetwork constructor.
    """
    my_io = NetworkCollector()
    my_net = AIXNetwork(my_io)

    assert my_net.platform == 'AIX'
    assert my_net._custom_fact_names == ['all_ipv6_interfaces', 'default_ipv4', 'default_ipv6', 'interfaces',
                                         'interface_ip']



# Generated at 2022-06-22 23:37:01.139831
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test case to check if parsing of output of AIX ifconfig -a command
    works as expected.
    """

    test_input = """\
lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1
        inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
        inet6 ::1/0
        ether 00:00:00:00:00:00
        options=3<PERFORMNUD,ACCEPT_RTADV>
en0: flags=0<>
        options=3<RXCSUM,TXCSUM>
        media: Ethernet autoselect (1000baseT <full-duplex>)
        status: inactive
"""

# Generated at 2022-06-22 23:37:09.056857
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    AIX: test method get_default_interfaces
    """
    ifname_expected = {'gateway': '10.70.110.1', 'interface': 'ent3'}
    address_family_expected = 'v4'
    route_path = '/home/mauro/container/container_install/bin/netstat'

    instantiation_test_object = AIXNetwork()
    methods_info_test_object = instantiation_test_object.get_default_interfaces(route_path)

    assert (methods_info_test_object == ifname_expected), "Data from method get_default_interfaces is not correct"



# Generated at 2022-06-22 23:37:17.530267
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_class = AIXNetwork()
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['en0', 'UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'MTU:1500', 'metric:1']
    test_class.parse_interface_line(words, current_if)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'mtu': '1500'}

# Generated at 2022-06-22 23:37:22.911069
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert hasattr(AIXNetworkCollector, '_fact_class'), \
        "_fact_class not found in AIXNetworkCollector"
    assert AIXNetworkCollector._fact_class == AIXNetwork, \
        "_fact_class should be AIXNetwork"
    assert AIXNetworkCollector._platform == 'AIX', \
        "_platform should be AIX"


# Generated at 2022-06-22 23:37:32.787791
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:37:35.809328
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    out = AIXNetwork(module)
    assert out.platform == 'AIX'
    assert out.get_interfaces_info == out.get_interfaces_info

# Generated at 2022-06-22 23:37:39.135460
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network=AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert aix_network.get_default_interfaces(None) == ({}, {})

# Generated at 2022-06-22 23:37:40.554763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aixfact = AIXNetworkCollector()
    assert aixfact.facts == 'AIX'

# Generated at 2022-06-22 23:37:52.405803
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class AIXNetwork:
        def __init__(self):
            self.module = None
    # input for get_interfaces_info
    ifconfig_path = None
    ifconfig_options = '-a'
    # Results from real AIX system.

# Generated at 2022-06-22 23:38:03.505390
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class TestModule:
        def get_bin_path(name, *args, **kwargs):
            return '/usr/bin/' + name

        def run_command(cmd, *args, **kwargs):
            if cmd[0] == '/usr/bin/netstat':
                rc = 0
                # emulate output of 'netstat -nr'
                out = '''
default 192.168.99.1 UG 1 0 en0
default fe80::%en0 U 1 0 en0
'''
                err = ''
            return rc, out, err

    # create instance of class
    net = AIXNetwork(TestModule())

    # get interfaces
    v4, v6 = net.get_default_interfaces('route_path')

    # validate result on IPv4

# Generated at 2022-06-22 23:38:15.126597
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    import sys
    import os
    import json

    # prepend parent directory to allow import of module
    sys.path.insert(1, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    # Create a mock class for module
    class MockModule(object):

        def __init__(self, facts_dict=None):
            # Define some default values for module parameters
            self.params = dict(
                gather_subset=(),
                gather_network_resources=(),
            )

            # Populate some other common members of module object
            self.exit_json = exit_json
            self.fail_json = fail_json

            # Populate facts that are normally are gathered from the

# Generated at 2022-06-22 23:38:19.659359
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector should set
    _fact_class to AIXNetwork and
    _platform to 'AIX'
    """
    aix_network_collector_object = AIXNetworkCollector()
    assert aix_network_collector_object._fact_class == AIXNetwork
    assert aix_network_collector_object._platform == 'AIX'

# Generated at 2022-06-22 23:38:30.618166
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    fake_module = type('obj', (object,), {'get_bin_path': lambda self, arg: None, 'run_command': lambda self, arg: (0, '', '')})
    aix_network_object = AIXNetwork(fake_module)
    fake_words = ['en0:', 'flags=', '1000842', 'mtu', '2080', 'index', '1']
    current_if = aix_network_object.parse_interface_line(fake_words)
    assert current_if['device'] == 'en0'
    assert current_if['mtu'] == '2080'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'



# Generated at 2022-06-22 23:38:37.408574
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['e0:', 'UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'PROMISC']
    ifn = AIXNetwork()
    current_if = ifn.parse_interface_line(words)
    assert current_if['device'] == 'e0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'PROMISC']
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:38:43.343895
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import sys

    class MockAIXModule(object):
        # This class can be used to mock a module

        def __init__(self):
            self.run_command_patcher = None

        def get_bin_path(self, app, opt_dirs=[]):
            return '/usr/sbin/' + app


# Generated at 2022-06-22 23:38:44.061952
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)



# Generated at 2022-06-22 23:38:46.138105
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector can be called without arguments
    """
    AIXNetworkCollector()



# Generated at 2022-06-22 23:38:57.609863
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>',
                  'inet', '10.74.14.16', 'netmask', '0xffff0000', 'broadcast', '10.255.255.255']

    test_class = AIXNetwork()
    test_obj = test_class.parse_interface_line(test_words)
    assert test_obj['device'] == 'en0'

# Generated at 2022-06-22 23:39:07.282890
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # init
    testobj = AIXNetwork()
    # do the test
    test_result = testobj.parse_interface_line(['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric=1', 'mtu=1500', 'index=5', 'inet', 'a.b.c.d', 'netmask', '0xffffff00', 'broadcast', 'a.b.c.255', 'ether', '0:a:95:53:55:58', 'media:', 'autoselect', '(none)'])
    # assert

# Generated at 2022-06-22 23:39:12.308001
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    tested_class = AIXNetwork()
    tested_class.module = AnsibleModule(argument_spec=dict())
    tested_class.module.exit_json = my_exit_json
    tested_class.gather_subset = ['!all']
    tested_class.get_default_interfaces(route_path='/usr/sbin/netstat')


# Generated at 2022-06-22 23:39:18.961588
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_data = [
        # words, expected result
        (['en0:'],'unknown'),
        (['en0:', 'flags=8c02<BROADCAST,OACTIVE,SIMPLEX,NOARP>', 'mtu', '1500'],'unknown'),
        (['ent0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500'], 'ether'),
    ]
    for words, macaddress in test_data:
        current_if = AIXNetwork.parse_interface_line(words)
        assert current_if['macaddress'] == macaddress, "words %s, macaddress %s, expected %s" % (words, current_if['macaddress'], macaddress)



# Generated at 2022-06-22 23:39:30.063742
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    def get_default_interfaces_from_netstat_output(lines):
        interface = dict(v4={}, v6={})

        for line in lines:
            words = line.split()
            if len(words) > 1 and words[0] == 'default':
                if '.' in words[1]:
                    interface['v4']['gateway'] = words[1]
                    interface['v4']['interface'] = words[5]
                elif ':' in words[1]:
                    interface['v6']['gateway'] = words[1]
                    interface['v6']['interface'] = words[5]

        return interface['v4'], interface['v6']

    #
    # Test the method get_default_interfaces of the class AIXNetwork
    #

    #
    # Scenario 1

# Generated at 2022-06-22 23:39:41.160915
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!config'], type='list')
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-22 23:39:47.134852
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')
    })

    if not HAS_NETIFACES:
        module.fail_json(msg="There were problems importing Python 'netifaces' module. Check version of Python. It must be >= 2.6.")
    if not HAS_NETADDR:
        module.fail_json(msg="There were problems importing Python 'netaddr' module. Check version of Python. It must be >= 0.7.12.")

    if platform.system() != 'AIX':
        module.fail_json(msg="This module only works on AIX.")

    network_collector = AIXNetworkCollector(module=module)
    facts = network_collector.get_facts()


# Generated at 2022-06-22 23:39:58.263780
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    test_module = type('test_module', (object,), {'run_command': dummy_run_command})
    test_module.get_bin_path = lambda self, arg: arg
    test_network = AIXNetwork(test_module)
    assert test_network.module == test_module
    assert test_network.platform == 'AIX'


# Generated at 2022-06-22 23:40:09.749705
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Create AIXNetwork object
    my_obj = AIXNetwork()

    # Methods parameters
    words = ['en0:', 'flags=842<BROADCAST,NOTRAILERS,SIMPLEX,MULTICAST>', 'metric=0']
    words2 = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']
    words3 = ['ether', '1c:75:08:38:ba:52']
    words4 = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex,flow-control>)']
    words5 = ['status:', 'active']
    words6 = ['lladdr', '1c:75:08:38:ba:52']

# Generated at 2022-06-22 23:40:20.224681
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if NetworkCollector not in sys.modules:
        sys.modules[NetworkCollector.__module__] = NetworkCollector
        sys.modules[NetworkCollector.__name__] = NetworkCollector
    if GenericBsdIfconfigNetwork not in sys.modules:
        sys.modules[GenericBsdIfconfigNetwork.__module__] = GenericBsdIfconfigNetwork
        sys.modules[GenericBsdIfconfigNetwork.__name__] = GenericBsdIfconfigNetwork

    network = AIXNetwork(module)
    network.populate()
    facts = network.get_facts()
    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts
    assert 'interfaces' in facts


# Generated at 2022-06-22 23:40:23.790642
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.platform == 'AIX'
    assert aix_network_collector.fact_class == AIXNetwork


# Generated at 2022-06-22 23:40:28.980797
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    if_net = AIXNetwork()

    line = 'en0: flags=1000842<BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 1'
    words = line.split()
    current_if = if_net.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:40:32.112919
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector.platform == 'AIX'

# Generated at 2022-06-22 23:40:33.887300
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = AIXNetwork()
    assert facts.platform == AIXNetwork.platform

# Generated at 2022-06-22 23:40:40.635390
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock the fact class
    fact_class = AIXNetwork(module)

    # Run get_default_interfaces
    ifconfig_path = '/sbin/ifconfig'
    route_path = '/usr/sbin/route'
    assert fact_class.get_default_interfaces(route_path) == (dict(), dict())


# Generated at 2022-06-22 23:40:48.387326
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    tst_module = type('module', (object,), {'run_command': run_command})
    tst_module.get_bin_path = lambda name: '/usr/bin/%s' % name

    net = AIXNetwork(tst_module)
    v4, v6 = net.get_default_interfaces('/usr/bin/netstat')
    assert v4['gateway'] == '192.168.122.1'
    assert v4['interface'] == 'en2'
    assert v6['gateway'] == 'fe80::9beb:c4ff:fe50:8a30%en0'
    assert v6['interface'] == 'en0'


# Generated at 2022-06-22 23:40:49.124990
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:41:00.948759
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # create a fake module that can have facts assigned to it
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # create an instance of the AIXNetwork class
    network_if = AIXNetwork(module)

    # test output with job1:
    words = ['en0:', 'flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>', 'mtu', '1500', '', 'lladdr', '00:05:85:a6:2c:44', 'index', '8']
    interface_test = network_if.parse_interface_line(words)
    assert interface_test['device'] == 'en0'
    assert 'UP' in interface_test['flags']

# Generated at 2022-06-22 23:41:13.213790
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-22 23:41:16.609670
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_module_mock = AnsibleModuleMock({}, {})
    network_collector = AIXNetworkCollector(ansible_module_mock)
    assert network_collector is not None


# Generated at 2022-06-22 23:41:19.735572
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    platform = 'AIX'
    module = None
    network_collector = AIXNetworkCollector(module)
    if network_collector._platform != platform:
        assert False
    if network_collector._fact_class.platform != platform:
        assert False



# Generated at 2022-06-22 23:41:31.110738
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network_module = AIXNetwork({})
    assert network_module.platform == 'AIX'
    platform, iface = network_module.get_default_interfaces('/sbin/route')
    assert platform == 'AIX'
    assert iface == {}
    file_path, file_name = network_module.get_file_path('/bin/ifconfig')
    assert file_path == '/bin/'
    assert file_name == 'ifconfig'
    file_path, file_name = network_module.get_file_path('/sbin')
    assert file_path == ''
    assert file_name == 'ifconfig'
    file_path, file_name = network_module.get_file_path('ifconfig')
    assert file_path == ''
    assert file_name == 'ifconfig'

# Generated at 2022-06-22 23:41:32.733932
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:41:36.126329
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Setup the module object
    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(gather_subset='!all'))

    # Set up the class instance
    net = AIXNetwork(module)
    result = net.get_default_interfaces('route')

    assert result == ('172.16.0.1', 'fe80::21f:5bff:fecd:d378')

# Generated at 2022-06-22 23:41:42.523761
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.common.removed import removed_module
    removed_module("Module for Ansible AIX_Network has been moved to the "
                   "ansible.module_utils.facts.network.aix_network module.")

# Generated at 2022-06-22 23:41:48.627387
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ans = AIXNetwork(ifconfig_path, ifconfig_options)
    assert ans.module.get_bin_path.__name__ == 'get_bin_path'
    assert ans.module.run_command.__name__ == 'run_command'
    assert ans.platform == 'AIX'
    assert ans.ifconfig_path == '/usr/sbin/ifconfig'
    assert ans.ifconfig_options == '-a'

# Generated at 2022-06-22 23:41:51.429298
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector.platform == 'AIX'
    assert net_collector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:42:02.952626
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_string = 'en1: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>'
    words = test_string.split(' ')
    current_if = AIXNetwork().parse_interface_line(words)

    if current_if['device'] != 'en1':
        raise AssertionError('device name should be en1, got {0}'.format(current_if['device']))


# Generated at 2022-06-22 23:42:08.223567
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    module = GenericBsdIfconfigNetwork.module
    aixnetwork = AIXNetwork(module)
    aixnetwork.get_interfaces_info(module.get_bin_path('ifconfig'))


# Generated at 2022-06-22 23:42:17.378970
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifc = AIXNetwork(dict(module=None, params=None))
    device = "en0"
    word_list = [  device, "flags=8c07<UP,BROADCAST,LOOPBACK,RUNNING,MULTICAST,IPv6>",
            "metric=1" ]
    returned_dict = ifc.parse_interface_line(word_list)
    assert returned_dict == {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': {'BROADCAST': 'BROADCAST', 'LOOPBACK': 'LOOPBACK', 'RUNNING': 'RUNNING', 'MULTICAST': 'MULTICAST', 'IPv6': 'IPv6', 'UP': 'UP'}, 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:42:28.290513
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:38.615742
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    check_for_platform('AIX')
    # uname_rc, uname_out, uname_err = module.run_command(['uname', '-W'])
    # if uname_rc:
    #     module.fail_json(msg="platform is not AIX")
    # if uname_out.split()[0] != '0':
    #     module.fail_json(msg="WPAR is not supported")
    ifconfig_path = module.get_bin_path("ifconfig")
    if not ifconfig_path:
        module.fail_json(msg="ifconfig executable not found")
    network_class = AIXNetwork(module, ifconfig_path)
    interfaces = network_class.get_interfaces_info(ifconfig_path)
    gateway = network_class.get_default_inter

# Generated at 2022-06-22 23:42:41.043996
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.platform == 'AIX'



# Generated at 2022-06-22 23:42:43.605323
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    unittest.TestCase.assertEqual(AIXNetwork.get_default_interfaces(None), (None, None))


# Generated at 2022-06-22 23:42:45.859060
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    network_facts = AIXNetwork(module)
    assert network_facts.platform == 'AIX'


# Generated at 2022-06-22 23:42:48.323006
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Creates object of class AIXNetworkCollector,
    but does not start the object's get_facts() method
    """
    AIXNetworkCollector()

# Generated at 2022-06-22 23:43:00.608872
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    device_dict = {'p1p1': {'device': 'p1p1', 'type': 'unknown', 'macaddress': 'unknown',
                            'ipv4': [], 'ipv6': [], 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']},
                   'lo0': {'device': 'lo0', 'type': 'unknown', 'macaddress': 'unknown', 'ipv4': [], 'ipv6': [],
                           'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}}


# Generated at 2022-06-22 23:43:02.280625
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = dict()
    c = AIXNetworkCollector(None, facts, None)
    assert c.get_facts() == facts

# Generated at 2022-06-22 23:43:14.526851
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    f = AIXNetworkCollector()
    assert f.network is not None
    assert f._fact_class == AIXNetwork
    assert f._platform == 'AIX'
    assert f.interfaces is not None
    assert f.interfaces == {'eth0': {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'},
        'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'}}

# Generated at 2022-06-22 23:43:17.406778
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_obj = AIXNetworkCollector()
    assert type(test_obj._fact_class) == AIXNetwork
    assert test_obj._platform == 'AIX'


# Generated at 2022-06-22 23:43:21.557694
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector._fact_class == 'AIXNetwork'
    assert collector._platform == 'AIX'



# Generated at 2022-06-22 23:43:24.704621
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_object = AIXNetworkCollector()
    assert test_object
    assert test_object._fact_class is AIXNetwork
    assert test_object._platform == 'AIX'


# Generated at 2022-06-22 23:43:34.204235
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface_string = 'ent0: flags=0x849b<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = interface_string.split()

    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_AIXNetwork = AIXNetwork(module=None)
    result = test_AIXNetwork.parse_interface_line(words)

    # interface must have one attribute: 'device' which has value 'ent0'
    assert len(result) == 1
    assert result['device'] == 'ent0'

# Generated at 2022-06-22 23:43:46.444903
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = type('module', (), {})()
    test_module.module = type('module', (), {})()
    test_module.module.run_command = lambda self, command: (0, '', '')
    test_module.get_bin_path = lambda self, name: '/usr/bin/' + name
    test_module.run_command = lambda self, command: (0, '', '')
    test_module.get_options = lambda self, line: line

    test_module_AIXNetwork = AIXNetwork(test_module)
    result = test_module_AIXNetwork.parse_interface_line(['lo0:'])

    assert result['device'] == 'lo0'
    assert result['flags'] == 'lo0:'
    assert result['mtu'] is None

# Generated at 2022-06-22 23:43:55.409489
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Test case 1: AIX 7.1 with 4 interfaces
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    uname_path = '/usr/bin/uname'
    netstat_path = '/usr/bin/netstat'


# Generated at 2022-06-22 23:44:01.031838
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector

    # When
    platform_fact_collector = AIXNetworkCollector()

    # Then
    assert isinstance(platform_fact_collector, AIXNetworkCollector)
    assert isinstance(platform_fact_collector, NetworkCollector)
    assert platform_fact_collector._platform == 'AIX'

# Generated at 2022-06-22 23:44:03.422919
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert 'default' in aix_network.collected_facts


# Generated at 2022-06-22 23:44:10.788037
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork(module=None)
    interface = dict(v4={}, v6={})

# Generated at 2022-06-22 23:44:15.795171
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ''' Unit test for method get_default_interfaces of class AIXNetwork '''

    # Create a class object
    aix_network = AIXNetwork()

    # Call method get_default_interfaces of AIXNetwork class
    # The command 'netstat -nr' fail, so the default interfaces will be v4: {}, v6: {}
    default_interfaces_v4, default_interfaces_v6 = aix_network.get_default_interfaces('/etc/route')

    # Verify
    assert default_interfaces_v4 == {}
    assert default_interfaces_v6 == {}


# Generated at 2022-06-22 23:44:17.649490
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork(None)
    assert aix_network is not None


# Generated at 2022-06-22 23:44:26.639402
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = AIXNetwork()
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()
    # 'en0' from words[0]
    r = m.parse_interface_line(words)
    assert r['device'] == 'en0'
    assert r['macaddress'] == 'unknown'
    assert r['type'] == 'unknown'

# Generated at 2022-06-22 23:44:37.736244
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net_collector = AIXNetworkCollector()
    net = AIXNetwork(net_collector.module)

    def get_default_interfaces(route_path):
        return net.get_default_interfaces(route_path)

    route_path = '/bin/netstat'

    rc, out, err = net.module.run_command([route_path, '-nr'])

    num = out.count('\n')
    net.module.exit_json(msg='Input file has {} lines.'.format(num))

    # IPv4 gateway, Ethernet interface
    net.module.exit_json(msg='Test IPv4 Ethernet is OK.', changed=False, ansible_facts=dict(default_interface_v4=dict(gateway='192.168.33.1', interface='en0')))
    # IPv6

# Generated at 2022-06-22 23:44:40.919474
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    if_class = AIXNetwork(module)
    assert 'AIX' == if_class.platform



# Generated at 2022-06-22 23:44:44.619375
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    collector = AIXNetworkCollector()
    assert collector is not None, "Failed to instantiate AIXNetworkCollector"

# Generated at 2022-06-22 23:44:56.350010
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_AIXNetwork = AIXNetwork()
    type_dict_interface = dict(device=None, type=None, flags=None, macaddress=None, ipv4=None, ipv6=None)

    # Test - input line is empty and expected output from function is empty dict
    expected_result = dict(device=None, type=None, flags=None, macaddress=None, ipv4=None, ipv6=None)
    input_line = []
    result = test_AIXNetwork.parse_interface_line(input_line)
    assert(result == expected_result), 'Wrong result from parse_interface_line!'

    # Test - input line has one word and expected output from function is empty dict

# Generated at 2022-06-22 23:45:04.344341
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector._create_module()
    def get_bin_path(name, opt_dirs=[]):
        return 'bin'

    module.get_bin_path = get_bin_path
    module.run_command = lambda *args, **kwargs: (0, "default xxxxxx 1   UG        0 0          0 en0", '')

    network = AIXNetwork(module=module)
    ipv4, ipv6 = network.get_default_interfaces('route')

    assert ipv4.get('interface') == "en0"
    assert ipv4.get('gateway') == "xxxxxx"



# Generated at 2022-06-22 23:45:08.944419
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    output_line = 'ent0: flags=e1000UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD,CHAIN>'
    device = 'ent0'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = 'e1000UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD,CHAIN'
    current_if['macaddress'] = 'unknown'    # will be overwritten later

    words = output_line.split()
    aixnet = AIXNetwork()

# Generated at 2022-06-22 23:45:16.264700
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )

    network = AIXNetwork(module)

    interfaces = network.get_interfaces_info(module.get_bin_path('ifconfig'))

    print(interfaces)

    module.exit_json(changed=False)



# Generated at 2022-06-22 23:45:26.301700
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')

    if AIX in module.get_platform() and ifconfig_path:
        an = AIXNetwork(module=module)
        rc, out, err = module.run_command([ifconfig_path, '-a'])
        for iface in out.split('\n\n'):
            for line in iface.splitlines():
                words = line.split()
                # interface line
                if re.match(r'^\w*\d*:', line) and len(words) == 2:
                    current_if = an.parse_interface_line(words)
                    assert re.match(r'^\w*\d*:', words[0])
                    assert len(words[1]) == 3