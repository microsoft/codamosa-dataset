

# Generated at 2022-06-22 23:35:28.654454
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    network_module = AIXNetwork(module)

    network_module.out = '''
default 192.168.1.1 UG      4   0  en0
default 2001:0db8:dead:beaf::1 UG     2     0     en0
    '''

    expected = ({'gateway': '192.168.1.1', 'interface': 'en0'}, {'gateway': '2001:0db8:dead:beaf::1', 'interface': 'en0'})
    result = network_module.get_default_interfaces(None)

    assert expected == result



# Generated at 2022-06-22 23:35:35.995860
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module)
    ifconfig_path = network_collector.module.get_bin_path('ifconfig')
    if ifconfig_path:
        interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
        v4_default_interface, v6_default_interface = network_collector.get_default_interfaces(None)

# Generated at 2022-06-22 23:35:47.241838
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_ModuleUtil = _MockModuleUtil()
    test_AIXNetwork = AIXNetwork(test_ModuleUtil)
    test_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '192.168.2.2', 'netmask', '0xffffff00', 'broadcast', '192.168.2.255']
    result = test_AIXNetwork.parse_interface_line(test_words)
    assert result['device'] == 'en0'

# Generated at 2022-06-22 23:35:49.272722
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    nm = AIXNetwork(module)
    # test constructor

# Generated at 2022-06-22 23:35:58.274779
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import ModuleArgsParser

    # test_fixture_1 contains an AIX ifconfig -a output like the following:
    # en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>
    #     options=c0800<VLAN_MTU,LLC>
    #     inet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255
    #     media: Ethernet autoselect (100baseTX <full-duplex>)
    #     status: active inet6 fe80::20c:29ff:fe41:a7b0%en0 prefixlen 64 scopeid 0xa
    # en1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv

# Generated at 2022-06-22 23:36:09.927276
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class TestModule(object):
        def run_command(self, args):
            path = args[0]
            # ifconfig

# Generated at 2022-06-22 23:36:21.804896
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:36:30.049808
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Local variables that can be used for testing
    class FakeModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.params['bin_path']

        def run_command(self, cmd):
            return self.params['run_command']

    # Specific AIXNetwork instance is used to test
    my_network = AIXNetwork()

    # Here is the test data
    # test_data[0] - input data on one line
    # test_data[1] - expected output

# Generated at 2022-06-22 23:36:41.596022
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import inspect
    import json
    import ansible.module_utils.facts.facts as ansible_facts

    # read test data (route information)
    dirname = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    filename = os.path.join(dirname, 'test_data/AIXNetwork_netstat.txt')
    f = open(filename)
    netstat_in = json.load(f)

    # list of all data, which should be merged into the facts

# Generated at 2022-06-22 23:36:51.659689
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    ansible_module = AnsibleModule(argument_spec=dict())
    network_module = AIXNetwork(ansible_module)
    assert network_module.platform == 'AIX'
    assert network_module.facts == {}

    if not hasattr(network_module, '_fact_class'):
        assert False, "_fact_class not present"
    assert network_module._fact_class == AIXNetwork
    assert network_module._platform == "AIX"

    if not hasattr(network_module, '_cache'):
        assert False, "_cache not present"
    assert network_module._cache == {}



# Generated at 2022-06-22 23:36:55.327042
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    test_module = 'ansible.module_utils.facts.network.aix.AIXNetwork'
    test_module = __import__(test_module, fromlist=['AIXNetwork'])
    instance = test_module.AIXNetwork()
    assert instance.platform == 'AIX'



# Generated at 2022-06-22 23:37:06.249870
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net._module = ModuleStub()


# Generated at 2022-06-22 23:37:17.790054
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    mod = FakeModule()
    # mod.run_command returns a Bytes object
    mod.run_command_answers = [     # netstat -nr
        (0, 'default 10.0.0.5 UG 1 en0', '', None),
        (0, 'default :: gateway ::1 U 0 en0', '', None),
        (0, 'default 10.0.0.1 UG 0 en1', '', None),
    ]

    n = AIXNetwork(mod)

    # Testing if get_default_interfaces() returns results for both IPv4 and IPv6
    interfaces = n.get_default_interfaces('/usr/bin/netstat')
    if interfaces[0]['interface'] != 'en0' or interfaces[1]['interface'] != 'en0':
        raise Exception('Wrong interfaces returned')

# Generated at 2022-06-22 23:37:29.030175
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_net = AIXNetwork()
    words = ['en1:', 'flags=842<BROADCAST,RUNNING,MULTICAST>', 'mtu=9000']
    current_if = aix_net.parse_interface_line(words)
    assert current_if['device'] == 'en1'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    words = ['tr0:', 'flags=842<BROADCAST,RUNNING,MULTICAST>', 'mtu=9000']

# Generated at 2022-06-22 23:37:32.655522
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'


# Generated at 2022-06-22 23:37:39.893242
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = None
    network = AIXNetwork(module)
    route_path = network.module.get_bin_path('netstat')
    v4, v6 = network.get_default_interfaces(route_path)
    print(str(v4) + '\n' + str(v6))



# Generated at 2022-06-22 23:37:45.717755
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    m_run_command = 'ansible.module_utils.facts.network.generic_bsd.run_command'
    m_bin_path = 'ansible.module_utils.facts.network.generic_bsd.NetworkCollector.bin_path'
    m_get_default_interfaces = 'ansible.module_utils.facts.network.aix.AIXNetwork.get_default_interfaces'
    m_get_interfaces_info = 'ansible.module_utils.facts.network.aix.AIXNetwork.get_interfaces_info'

    m_uname_rc = 0
    m_uname_out = '1'
    m_uname_err = ''
    m_rc = 0

# Generated at 2022-06-22 23:37:49.478175
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for AIXNetworkCollector
    """
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'


# Generated at 2022-06-22 23:38:00.295800
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    sample_interfaces = dict(
        lo0=dict(
            device='lo0',
            ipv4=[],
            ipv6=[],
            type='unknown',
            flags=dict(
                broadcast=False,
                multicast=True,
                running=True,
                loopback=True,
            ),
            macaddress='unknown',   # will be overwritten later
        ),
        en0=dict(
            device='en0',
            ipv4=[],
            ipv6=[],
            type='unknown',
            flags=dict(
                broadcast=True,
                multicast=False,
                running=True,
                loopback=False,
            ),
            macaddress='unknown',   # will be overwritten later
        ),
    )

    an = AIXNetwork()


# Generated at 2022-06-22 23:38:08.833972
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class Options:
        def __init__(self):
            self.gather_subset = ['!all', '!min']
            self.gather_network_resources = ['all']
            self.filter = None
            self.retries = 1
            self.interval = 0.1
            self.timeout = 5

    class Module(object):

        def __init__(self):
            self.exit_json = None

        def run_command(self, args):
            if args[1] == '-a':
                return 0, data_out_for_aix_ifconfig, None

            if args[0] == '/usr/bin/netstat':
                return 0, data_out_for_netstat, None

            if args[0] == '/usr/sbin/uname':
                return 0, data_out

# Generated at 2022-06-22 23:38:19.516552
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    collector = AIXNetworkCollector(module=module)

    # AIX's netstat command output

# Generated at 2022-06-22 23:38:27.996396
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "default 172.18.3.7 UG 0 0 en0 ", ''))
    aix_network = AIXNetwork(module)
    aix_network.get_default_interfaces(route_path=None)
    assert aix_network.interfaces['v4']['gateway'] == '172.18.3.7'
    assert aix_network.interfaces['v4']['interface'] == 'en0'

# Generated at 2022-06-22 23:38:37.931966
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # input data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    ifconfig_options_used = ifconfig_options

# Generated at 2022-06-22 23:38:40.826016
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = get_platform_subclass(AIXNetwork)(dict(), dict())
    assert module.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-22 23:38:43.952756
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'


# Generated at 2022-06-22 23:38:49.953145
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    net = AIXNetwork(module=test_module)
    gateway, interface = net.get_default_interfaces('/tmp')
    assert gateway == '10.0.2.2', 'incorrect gateway'
    assert interface == 'en0', 'incorrect interface'

# Generated at 2022-06-22 23:38:54.486303
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:38:58.509599
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert isinstance(obj, AIXNetworkCollector)
    assert isinstance(obj.platform, str)
    assert isinstance(obj._fact_class, AIXNetwork)


# Generated at 2022-06-22 23:39:01.697075
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    assert isinstance(network_collector.get_network_facts(), dict)

# Generated at 2022-06-22 23:39:07.598070
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ai = AIXNetwork()
    ai_dict = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ai_dict['flags'] = ai.get_options(['UP'])
    ai_dict['macaddress'] = 'unknown'

    assert ai.parse_interface_line(['en0:', 'UP', 'LOOPBACK', 'RUNNING']) == ai_dict


# Generated at 2022-06-22 23:39:14.840509
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = FakeAnsibleModule()
    net.module.run_command = fake_run_command
    interfaces_v4, interfaces_v6 = net.get_default_interfaces('/sbin/route')
    assert interfaces_v4['gateway'] == '192.168.2.1'
    assert interfaces_v4['interface'] == 'en0'
    assert interfaces_v6['gateway'] == 'fe80::4f:70ff:fe01:d9e1'
    assert interfaces_v6['interface'] == 'en0'



# Generated at 2022-06-22 23:39:21.842755
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    net_obj = AIXNetwork(module)
    v4_default_interface, v6_default_interface = net_obj.get_default_interfaces('/usr/sbin/route')
    assert v4_default_interface['gateway'] == '10.130.126.1'
    assert v4_default_interface['interface'] == 'en0'
    assert v6_default_interface['gateway'] == 'fe80::210:9fff:fe4c:b2ad'
    assert v6_default_interface['interface'] == 'en0'

# Generated at 2022-06-22 23:39:22.882548
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:39:32.232444
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.legacy import ifconfig_a_output

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    aix_n = AIXNetwork()
    interfaces, ips = aix_n.get_interfaces_info(ifconfig_path, ifconfig_options)
    # check interfaces
    assert len(interfaces) == 10
    assert interfaces["en0"]["device"] == "en0"
    assert interfaces["en0"]["flags"] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interfaces["en0"]["mtu"] == "1500"
    assert interfaces["en0"]["type"] == "ether"


# Generated at 2022-06-22 23:39:40.192298
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    expected_result = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'MULTICAST']}
    instance = AIXNetwork()
    result = instance.parse_interface_line(['lo0:', 'flags=8049<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST>', 'mtu', '32768'])
    assert result == expected_result, "Expected %s, got %s" % (expected_result, result)

# Generated at 2022-06-22 23:39:46.547532
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # dummy class to simulate module.run_command
    class IfconfigMock(object):
        def __init__(self):
            self.rc = 0

# Generated at 2022-06-22 23:39:47.581790
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork


# Generated at 2022-06-22 23:39:58.662480
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:03.381240
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.platform == 'AIX'
    assert aix_network_collector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:40:04.823365
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__repr__()

# Generated at 2022-06-22 23:40:16.150227
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

    class MockIfconfigModule(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return "/sbin/%s" % name


# Generated at 2022-06-22 23:40:23.990178
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:34.096954
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=8', 'UP', 'BROADCAST', 'NOTRAILERS', 'IEEE80211', 'ADHOC', 'MODE', 'INVALID']
    network = AIXNetwork()
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'IEEE80211', 'ADHOC', 'MODE', 'INVALID']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert 'mtu' not in current_if

# Generated at 2022-06-22 23:40:43.915709
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Test case with empty line
    words = []
    current_if = AIXNetwork().parse_interface_line(words)
    assert current_if == {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # Test case with real line
    words = 'en2: flags=0x8802<BROADCAST,SIMPLEX,MULTICAST> mtu 1500'.split()
    current_if = AIXNetwork().parse_interface_line(words)
    assert current_if == {'device': 'en2', 'ipv4': [], 'ipv6': [], 'flags': '0x8802<BROADCAST,SIMPLEX,MULTICAST>', 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:40:45.811500
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_collector = AIXNetworkCollector()
    assert aix_collector.__class__.__name__ is 'AIXNetworkCollector'



# Generated at 2022-06-22 23:40:47.856909
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.platform == 'AIX'
    assert network_collector.fact_class == AIXNetwork

# Generated at 2022-06-22 23:40:54.923426
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ["en0:", "flags=0x8600<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>"]
    iface = AIXNetwork().parse_interface_line(words)
    assert iface['device'] == "en0"
    assert iface['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']

# Generated at 2022-06-22 23:41:06.752788
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_obj = AIXNetwork('module')

    # test 1
    ifconfig_path = 'tests/unit/module_utils/facts/network/aix_ifconfig.txt'
    test_obj.module.run_command = lambda x: (0, open(ifconfig_path).read(), '')

# Generated at 2022-06-22 23:41:11.165242
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create instance of class AIXNetwork
    net_platform = AIXNetwork()
    ifconfig_path = net_platform.module.get_bin_path('ifconfig')

    net_platform.get_interfaces_info(ifconfig_path)



# Generated at 2022-06-22 23:41:13.408193
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:41:21.511324
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    current_if = AIXNetwork().parse_interface_line(['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>',
                                                    'metric=0', 'mtu=65536', 'index=1', 'groups=', 'inets=127.0.0.1', 'inet6s=fe80::1'])
    assert current_if == {'device': 'lo0', 'mtu': '65536', 'macaddress': 'unknown', 'type': 'unknown', 'flags': {'UP': True, 'LOOPBACK': True, 'RUNNING': True, 'MULTICAST': True}, 'index': '1', 'ipv4': [], 'ipv6': []}


# Generated at 2022-06-22 23:41:30.871711
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()
    words = ['en1:','flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv6>','inet','192.168.0.5','netmask','0xffffff00','broadcast','192.168.0.255']
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en1'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'DHCP', 'IPv6']
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:41:38.790092
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os
    interface_info_file = os.sep.join([os.path.dirname(os.path.realpath(__file__)), 'ifconfig_info.pkl'])
    if os.path.isfile(interface_info_file):
        if PY2:
            with open(interface_info_file) as f:
                interface_info_data = cPickle.load(f)

# Generated at 2022-06-22 23:41:48.921349
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Test case 1: success
    # Data
    icfg_path='/usr/sbin/ifconfig'
    icfg_options='-a'
    mock_out_1 = ''
    mock_out_1 += 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>\n'
    mock_out_1 += '        inet 10.0.0.10 netmask 0xffffff00 broadcast 10.0.0.255\n'

# Generated at 2022-06-22 23:42:00.499792
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:02.781029
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)
    assert isinstance(AIXNetworkCollector().get_facts(), dict)

# Generated at 2022-06-22 23:42:04.552575
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), NetworkCollector)

# Generated at 2022-06-22 23:42:08.263057
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    Unit test for constructor of class AIXNetwork
    '''
    module = AnsibleModule(argument_spec={})
    aix_net = AIXNetwork(module)


# Generated at 2022-06-22 23:42:17.405945
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:42:28.296273
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    def fake_module_run_command(self, *cmd):
        fake_run_command_out = '''
Kernel IP routing table
Destination        Gateway    Flags Refs Use  Mtu  Interface
default        192.168.239.1  U         0   976  en1 
default       fe80::3a2a:51: UGH         0   812  en1 
localhost     127.0.0.1       UH        16  9704
    '''
        return 0, fake_run_command_out, ""

    aix_network = AIXNetwork()
    aix_network.module.run_command = fake_module_run_command


# Generated at 2022-06-22 23:42:32.958686
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Test the constructor of AIXNetwork.
    """
    facts = AIXNetwork()
    assert isinstance(facts, AIXNetwork)
    assert isinstance(facts, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:42:45.106832
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import tempfile
    import platform
    import sys

    if sys.version_info.major < 3:
        from mock import Mock
    else:
        from unittest.mock import Mock

    settings = dict(
        ANSIBLE_MODULE_ARGS='network_debug=yes',
        ansible_facts=dict(
            ansible_net_all_ipv4_addresses=['192.168.222.5'],
            ansible_net_all_ipv6_addresses=[],
        ),
    )

    fake_fname = os.path.join(tempfile.mkdtemp(), 'netstat')

# Generated at 2022-06-22 23:42:57.145507
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class AIXNetwork_get_interfaces_info_TestModule(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json called')

        def run_command(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            return [0, 'AIXNetwork_get_interfaces_info_TestModule', 'AIXNetwork_get_interfaces_info_TestModule']

        def get_bin_path(self, *args, **kwargs):
            self.args = args

# Generated at 2022-06-22 23:43:00.238498
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = MockModule()
    net = AIXNetwork(module)
    assert net.platform == "AIX"
    assert net.ifconfig_path == "/usr/bin/ifconfig"


# Generated at 2022-06-22 23:43:12.350601
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import module_utils_facts

    mock_module = module_utils_facts.MockModule()

# Generated at 2022-06-22 23:43:19.039106
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # create a cls of class AIXNetwork
    cls = AIXNetwork()
    # create a dict for all_interfaces_info
    all_interfaces_info = {}
    # create a dict for interface_info
    interface_info = {}
    # create interface_info
    interface_info['ipv4'] = dict()
    interface_info['ipv4']['route'] = "1.2.3.4"
    interface_info['ipv4']['interface'] = "en0"
    interface_info['ipv6'] = dict()
    interface_info['ipv6']['route'] = "1::2"
    interface_info['ipv6']['interface'] = "en0"
    # add interface_info to all_interfaces_info

# Generated at 2022-06-22 23:43:30.738602
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_AIXNetwork = AIXNetwork()

    # test 1
    words = ['lo1:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric=1']
    result = test_AIXNetwork.parse_interface_line(words)
    assert result['device'] == 'lo1'
    assert result['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert result['macaddress'] == 'unknown'

    # test 2
    words = ['lo0:', 'flags=201004843<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'metric=1']
    result = test_AIXNetwork.parse_interface_line(words)
    assert result['device']

# Generated at 2022-06-22 23:43:42.530969
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This is the unit test for method get_default_interfaces of class AIXNetwork
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork({})
    aix_network.module.run_command = lambda x: (0, 'default  10.10.10.1 UG	0 0	en2', None)
    assert aix_network.get_default_interfaces('/usr/sbin/netstat') == ({'gateway': '10.10.10.1', 'interface': 'en2'}, {})
    aix_network.module.run_command = lambda x: (0, 'default  10.10.10.2 UG	0 0	en3', None)
    assert aix_network.get_default_inter

# Generated at 2022-06-22 23:43:53.264498
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    '''
    unit test for method get_default_interfaces of class AIXNetwork
    '''
    class FakeModule:
        '''
        class FakeModule
        '''
        def __init__(self):
            '''
            constructor
            '''
            # do nothing
            self.params = dict()

        def get_bin_path(self, app, *args, **kwargs):
            '''
            mock get_bin_path
            '''
            return 'netstat'

        def run_command(self, cmd, *args, **kwargs):
            '''
            mock run_command for netstat -nr
            '''

# Generated at 2022-06-22 23:43:54.896611
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(NetworkCollector.get_network_collector(None, 'AIX'), AIXNetworkCollector)

# Generated at 2022-06-22 23:43:56.806514
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector


# Generated at 2022-06-22 23:44:03.816459
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule({})
    obj = AIXNetwork(module)

    # route_path is not used here
    expected_result = {'v4': {'gateway': '10.0.2.2', 'interface': 'en0'}, 'v6': {'gateway': 'fe80:0:0:0:0:abba:deaf:beef%en0', 'interface': 'en0'}}

    result = obj.get_default_interfaces(route_path='/etc/route')

    assert result == expected_result


# Generated at 2022-06-22 23:44:08.882456
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)

    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:44:10.396868
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == "AIX"
    assert AIXNetworkCollector.fact_class == AIXNetwork


# Generated at 2022-06-22 23:44:22.079522
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class AIXNetwork'''

    # obtain ifconfig_path
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    ifconfig_path = module.get_bin_path('ifconfig')

    # create AIXNetwork object and call get_interfaces_info
    c = AIXNetwork()
    c.module = module
    interfaces_info = c.get_interfaces_info(ifconfig_path)
    # print(json.dumps(interfaces_info, indent=4))

    # check result
    assert len(interfaces_info) == 2
    interfaces = interfaces_info[0]
    assert len(interfaces) == 2

    ips = interfaces_info[1]

# Generated at 2022-06-22 23:44:23.380869
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix = AIXNetwork()
    assert aix.platform == 'AIX'


# Generated at 2022-06-22 23:44:35.297628
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    tst_infos = AIXNetwork()
    tst_infos.parse_interface_line = tst_infos.parse_interface_line_AIX

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces_info = tst_infos.get_interfaces_info(ifconfig_path, ifconfig_options)
    #this print can be used to generate the test values for the interface_info_AIX list
    #print(interfaces_info)


# Generated at 2022-06-22 23:44:46.024431
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Tests get_default_interfaces()
    """
    collector = AIXNetworkCollector()
    module = MagicMock()
    collector.module = module
    module.get_bin_path.return_value = '/usr/sbin/netstat'
    module.run_command.return_value = (0, "default 10.99.80.1 UG 0 0 0 en0 10.99.80.1 default UGSc 0 0 0 en0 default 10.99.80.1 UG 0 0 0 en0 10.99.80.1", "")
    v4, v6 = collector.get_default_interfaces('/usr/bin/netstat')
    assert v4 == {'gateway': '10.99.80.1', 'interface': 'en0'}
    assert v6 == {}

# Unit

# Generated at 2022-06-22 23:44:56.146840
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Definition of the test data to be used by the test case

    """
    expected_result = {
        'device': 'en0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    }
    test_data = {
        'words': ['en0:', 'flags=e080863,3c01', 'groups=']
    }

    result = AIXNetwork().parse_interface_line(test_data['words'])

    assert result == expected_result

# Generated at 2022-06-22 23:45:02.603363
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    net = AIXNetwork(module)
    words = ['ent0:', 'flags=1e080863', 'mtu', '1500', 'index', '7']
    interfaces_dict = net.parse_interface_line(words)
    assert interfaces_dict['device'] == 'ent0'
    assert interfaces_dict['flags'] == '1e080863'
    assert interfaces_dict['mtu'] == '1500'



# Generated at 2022-06-22 23:45:15.028366
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test1 = AIXNetwork()

# Generated at 2022-06-22 23:45:21.804456
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This method is intended for testing the get_interfaces_if of AIXNetwork.
    """

    # test case 1: aix 7.2
    # ifconfig -a
    # en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
    #     options=80000<VLAN_MTU>
    #     inet 10.1.1.10 netmask 0xffffff00 broadcast 10.1.1.255
    #     inet6 fe80::20c:29ff:fe37:b6a3%en0 prefixlen 64 scopeid 0x2
    #     nd6 options=1<PERFORMNUD>