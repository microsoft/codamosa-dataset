

# Generated at 2022-06-22 23:35:30.310459
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    results = dict(
        ansible_facts=dict(
            ansible_net_interfaces=dict()
        )
    )
    network = AIXNetwork(module)
    results = network.populate()
    assert 'ansible_net_interfaces' in results['ansible_facts'], 'there is no ansible_net_interfaces fact'
    assert len(results['ansible_facts']['ansible_net_interfaces']) >= 1, 'no interface found'

    # check if some mandatory keys are present
    assert 'ipv4' in results['ansible_facts']['ansible_net_interfaces']['lo0'], 'no ipv4 key in lo0 interface'

# Generated at 2022-06-22 23:35:35.207638
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # create an object of AIXNetworkCollector
    net_collector = AIXNetworkCollector()
    assert net_collector._platform == 'AIX', 'platform is not AIX'
    assert net_collector._fact_class == AIXNetwork, 'fact class is not AIXNetwork'


# Generated at 2022-06-22 23:35:46.537899
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class TestAIXNetwork():
        def __init__(self, module):
            self.module = module

        def run_command(self, command):
            if command[0] == '/usr/sbin/netstat':
                rc = 0

# Generated at 2022-06-22 23:35:55.463878
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    net_dict = dict(
        interfaces={
        },
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # all_ipv6_addresses and all_ipv4_addresses have nested dictionaries inside like:
    #    [{name: 'lo0', iface: 0}, {name:'eth0', iface: 1}]
    assert net.get_interfaces_info('/usr/sbin/ifconfig') == net_dict

    # test_get_default_interfaces
    assert net.get_default_interfaces('/sbin/route') == {}, {}

# Generated at 2022-06-22 23:36:07.716801
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_text
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from io import StringIO

    data = """en0:flags=8963<UP,BROADCAST,NOTRAILERS,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500
    inet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255
    inet6 fe80::a59b:b1ff:fe80:2c07%en0 prefixlen 64 scopeid 0x1
    ether 0:9b:b1:80:2c:07
    media: autoselect
    status: active
    """

# Generated at 2022-06-22 23:36:12.055600
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    words = ['ensa:', 'flags=sniff2,']

    # make sure device is ensa without :
    assert 'ensa' == aix.parse_interface_line(words)['device']
    # make sure device does not have mtu attribute
    assert 'mtu' not in aix.parse_interface_line(words)
    # make sure device is unknown
    assert aix.parse_interface_line(words)['type'] == 'unknown'

    # add something to make sure mtu is not there
    words.append('mtu')
    words.append('1500')
    words.append('groups:')
    words.append('p2p')

    # make sure device is ensa without :

# Generated at 2022-06-22 23:36:16.689973
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aixif = AIXNetwork()
    aixif.parse_interface_line(['en0:','flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>','mtu','1500','index','5'])

# Generated at 2022-06-22 23:36:26.332108
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:36:37.510792
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_AIXNetwork = dict(name='AIX', module=dict(run_command=dict()))
    ifconfig_path = "ifconfig"
    ifconfig_options = "-a"

    # 1) ifconfig: ok
    # 2) uname: ok
    # 3) entstat: ok
    # 4) lsattr -E: ok

# Generated at 2022-06-22 23:36:43.926841
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={
        'net_type': dict(default='AIX'),
    })
    ansible_module = AIXNetwork(module=module)
    if_data = ['lo0:']
    result = ansible_module.parse_interface_line(if_data)
    assert result == {'device': 'lo0', 'macaddress': 'unknown', 'type': 'unknown', 'ipv6': [], 'ipv4': [], 'flags': []}



# Generated at 2022-06-22 23:36:55.563371
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = MockAnsibleModule({})

    original_if = {'device': 'device', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    original_if['flags'] = module.get_options('options')
    original_if['macaddress'] = 'unknown'

    aixnet = AIXNetwork(module)

# The only difference between AIX 'ifconfig -a' and standard BSD 'ifconfig -a'
# is in the first line of the interface section, that contains only two words.
    words = ['device:', 'flags=']

    processed_if = aixnet.parse_interface_line(words)

    assert processed_if['device'] == original_if['device']
    assert processed_if['flags'] == original_if['flags']

# Generated at 2022-06-22 23:36:56.925294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:37:03.824674
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    obj = AIXNetwork(module, 'ifconfig')
    result = obj.get_default_interfaces('netstat')
    assert result[0]['gateway'] == '192.168.1.1'
    assert result[0]['interface'] == 'en3'
    assert result[1]['gateway'] == 'fe80::d218:9eff:fe39:9699'
    assert result[1]['interface'] == 'lo0'


# Generated at 2022-06-22 23:37:09.952242
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test get_default_interfaces returns correct values
    """
    module = AnsibleModule(
        argument_spec = dict(
            route_path=dict(default='/usr/sbin/route'),
        )
    )

    test_if = AIXNetwork(module)
    v4, v6 = test_if.get_default_interfaces(module.params['route_path'])

    module.exit_json(ansible_facts={'ansible_facts': {'network_default_ipv4': v4, 'network_default_ipv6': v6}})



# Generated at 2022-06-22 23:37:15.161570
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    my_obj = AIXNetwork()

    # execute the method -- it uses the module variable 'module'
    interfaces, ips = my_obj.get_interfaces_info(module.get_bin_path('ifconfig'), '-a')

    print(interfaces)

# Generated at 2022-06-22 23:37:26.270487
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

    # Here we have to create (fake/mock) module.run_command(), which would return desired 'out', 'err' and 'rc'.
    # This is to test happy flow.
    module.run_command = lambda x, environ_update=None, check_rc=True, close_fds=True, executable=None: [0, 'fake data', '']

    # This is the dictionary we want to test get_interfaces_info() with:
    interfaces = dict(
        en0=dict(
            IPv4='192.168.1.2',
            IPv6='dead:beef::a00:0:0:1',
            MAC='12:34:56:78:9a:bc',
            MTU='1500'
        )
    )

    #

# Generated at 2022-06-22 23:37:37.791217
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    platforms_support = ['AIX']
    found = True
    try:
        from ansible.module_utils.facts.network.aix import AIXNetwork
    except:
        platforms_support = []
        found = False

    if not found:
        return platforms_support

    AN = AIXNetwork()

    for route_path in ['/etc/wtf', '/etc/wtf_not']:
        default_ipv4, default_ipv6 = AN.get_default_interfaces(route_path)
        if route_path == '/etc/wtf':
            assert default_ipv4['gateway'] == '10.28.3.1'
            assert default_ipv4['interface'] == 'en0'
            assert default_ipv6['gateway'] == '2001:db8::1'

# Generated at 2022-06-22 23:37:42.126693
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # get the object for the class AIXNetwork
    aixnet = AIXNetwork()

    device = 'en0'
    words = [device + ':', 'UP']

    # do the test
    result = aixnet.parse_interface_line(words)

    # check if all values are correct
    assert result['device'] == device
    assert result['mtu'] == '1500'
    assert result['type'] == 'ether'

# Generated at 2022-06-22 23:37:47.242355
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    collector = AIXNetworkCollector(module=module)
    facts = collector.collect()
    assert facts['network']['interfaces']['en0']['macaddress'] != 'unknown'

# Generated at 2022-06-22 23:37:48.536022
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    aix_network = AIXNetwork(test_module)
    assert aix_network.platform == 'AIX'

# Generated at 2022-06-22 23:37:59.411713
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    uname_path = 'tests/unittests/module_utils/facts/network/uname'
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    ifconfig_path = 'tests/unittests/module_utils/facts/network/ifconfig'
    facts = AIXNetwork(module, ifconfig_path, uname_path, '-a')
    interfaces, ips = facts.get_interfaces_info('faux')
    # correct number of interfaces found
    assert len(interfaces.keys()) == 3
    # correct number of ipv4 and ipv6 found
    assert len(ips['all_ipv4_addresses']) == 6
    assert len(ips['all_ipv6_addresses']) == 4
   

# Generated at 2022-06-22 23:38:08.320277
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en10:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']

    current_if = AIXNetwork.parse_interface_line(words)

    assert current_if['device'] == 'en10'

# Generated at 2022-06-22 23:38:19.186414
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fake_module = FakeModule()
    fake_module.run_command = fake_run_command

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    network_cls = AIXNetwork(fake_module)
    interfaces, ips = network_cls.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert len(interfaces) == 3
    assert 'eth0' in interfaces
    assert 'en1' in interfaces
    assert 'lo0' in interfaces
    assert 'ipv4' not in interfaces['eth0']
    assert 'ipv6' not in interfaces['eth0']
    assert 'macaddress' in interfaces['eth0']

    assert len(interfaces['eth0']['ipv4']) == 1

# Generated at 2022-06-22 23:38:23.951494
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'



# Generated at 2022-06-22 23:38:34.736232
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    words = ['en0:', 'flags=1e080863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '10.24.58.141', 'netmask', '0xffffff00', 'broadcast', '10.24.58.255']

# Generated at 2022-06-22 23:38:44.256661
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    aix = AIXNetwork()
    aix.module = None

    route_path = '/usr/bin/netstat'
    v4, v6 = aix.get_default_interfaces(route_path)
    if v4['interface'] == 'en1' and v4['gateway'] == '192.168.1.1':
        print('AIXNetwork.get_default_interfaces() works fine')
    else:
        print('AIXNetwork.get_default_interfaces() does not work as expected: %s %s' % (v4, v6))



# Generated at 2022-06-22 23:38:45.627545
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector() is not None


# Generated at 2022-06-22 23:38:57.072609
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.aix import AIXNetwork
    class DummyModule(object):
        def __init__(self, **kwargs):
            self.params = {
                "sysroot": ""
            }
            for k, v in kwargs.items():
                self.params[k] = v
        def get_bin_path(self, arg):
            if arg == 'netstat':
                return 'netstat'
            elif arg == 'uname':
                return 'uname'
            else:
                return None

# Generated at 2022-06-22 23:38:58.041799
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-22 23:39:07.637651
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Here you can put some unit tests for AIXNetwork module
    act_dev_v4 = None
    act_gw_v4 = None
    act_dev_v6 = None
    act_gw_v6 = None

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        if args[0] == '/usr/sbin/netstat':
            rc = 0

# Generated at 2022-06-22 23:39:10.915994
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    n = AIXNetwork(module)
    n.get_default_interfaces('/sbin/route') == {'v4': {}, 'v6': {}}

# Generated at 2022-06-22 23:39:17.975580
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork({})
    route_path = '/usr/sbin/route'
    default_ipv4_int_dict, default_ipv6_int_dict = aix_network.get_default_interfaces(route_path)
    assert(default_ipv4_int_dict['interface'] == 'lo0')
    assert(default_ipv4_int_dict['gateway'] == '127.0.0.1')
    assert(default_ipv6_int_dict['interface'] == 'lo0')
    assert(default_ipv6_int_dict['gateway'] == '::1')
    # TODO: call get_default_interfaces with invalid path to route_path and check error message


# Generated at 2022-06-22 23:39:19.309439
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()


# Generated at 2022-06-22 23:39:25.300911
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module)
    module.exit_json(ansible_facts={'ansible_network_resources': network_collector.get_facts()})


from ansible.module_utils.basic import *
main = test_AIXNetwork

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:39:28.286458
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    result = AIXNetwork(module)
    assert result.get_default_interfaces('netstat') == (None, None)

# Generated at 2022-06-22 23:39:40.485760
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    platform_module = type('module', (object,), {'vals': {}})
    mock_module = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', ''),
                                                    'params': {},
                                                    'check_mode': False,
                                                    'get_bin_path': lambda *args, **kwargs: ('/usr/bin/netstat', '', ''),
                                                    'log': lambda *args, **kwargs: None})
    platform_module.AnsibleModule = mock_module
    config = AIXNetwork.get_default_interfaces(platform_module, '/sbin/route')

# Generated at 2022-06-22 23:39:46.715728
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:39:57.874642
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = FakeModule()
    network_facts = AIXNetwork(module=mod)
    netstat_path = mod.get_bin_path('netstat')

    route_path = mod.get_bin_path('route')
    default_interfaces_v4, default_interfaces_v6 = network_facts.get_default_interfaces(route_path)
    assert not (default_interfaces_v4 is None and default_interfaces_v6 is None)

    ifconfig_path = mod.get_bin_path('ifconfig')
    if not ifconfig_path:
        return
    interfaces, ipv4_addresses, ipv6_addresses = network_facts.get_interfaces_info(ifconfig_path, '-a')
    assert len(interfaces) >= 1

# Generated at 2022-06-22 23:40:09.417182
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.generic_bsd import Interfaces
    from ansible.module_utils.facts.network.generic_bsd import IPs

    aix = AIXNetwork()

    assert aix.platform == 'AIX'
    # 1.0.0 is IPv4
    assert aix.network_prefix == 1.0
    # 1.0.0 is IPv4
    assert aix.network_prefix6 == 1.0
    assert aix._fact_class is AIXNetwork
    assert aix._platform is 'AIX'
    assert aix.interfaces.__class__ is Interfaces
    assert aix.ipaddresses.__class__ is IPs
    assert aix.all_ipv4_addresses == []
    assert aix.all_ipv6_addresses == []

# Generated at 2022-06-22 23:40:17.759351
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import test_AIXNetwork_parse_interface_line

    aix_network = AIXNetwork()

    # method test_AIXNetwork_parse_interface_line uses
    # method parse_interface_line of class AIXNetwork
    # to test if the returned value is equal to the expected value
    test_AIXNetwork_parse_interface_line(aix_network)


# Generated at 2022-06-22 23:40:28.472997
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    test_module = type('module', (object,), dict(run_command=lambda x, check_rc=True: (0, '', '')))
    test_module.get_bin_path = lambda x: '/bin/' + x
    def test_fail_json(*args, **kwargs):
        raise Exception()

    test_module.fail_json = test_fail_json
    test_module.params = dict()
    test_module.params['gather_subset'] = ['all']

    an = AIXNetwork(test_module)
    an._fact_class = AIXNetwork
    an._platform = 'AIX'
    an._interfaces = dict()

    found_facts = an.populate()

# Generated at 2022-06-22 23:40:33.384895
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})

    network = AIXNetwork(module)

    assert network.platform == 'AIX'
    assert network.get_default_interfaces == AIXNetwork.get_default_interfaces
    assert network.get_interfaces_info == AIXNetwork.get_interfaces_info

# Generated at 2022-06-22 23:40:43.739288
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    current_if = dict()
    line = "en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN> mtu 1500 index 8"
    words = line.split()
    AIXNetwork.parse_interface_line(current_if, words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '1e084863,480'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    # MTU is not present in this line, and this is the main difference from GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:40:53.092434
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    import re
    import sys

    sys.path.insert(0, '.')

    from ansible.module_utils.facts.network.aix import AIXNetwork

    an = AIXNetwork()

    line = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST>'
    words = line.split()
    current_if = an.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert re.match('^.*:.*:.*:.*:.*:.*', current_if['macaddress']) is None


# Generated at 2022-06-22 23:41:02.819031
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconf = AIXNetwork()
    assert ifconf.platform == 'AIX'
    assert ifconf.get_default_interfaces('/sbin/route -n') == ({}, {})
    assert ifconf.get_interfaces_info('/usr/sbin/ifconfig', '-a') == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert ifconf.parse_interface_line(['eth0:']) == {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown'}



# Generated at 2022-06-22 23:41:07.512239
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Unit test for AIXNetworkCollector class constructor."""
    my_network = AIXNetworkCollector()
    assert isinstance(my_network, AIXNetworkCollector)
    assert isinstance(my_network.fact_class, AIXNetwork)


# Generated at 2022-06-22 23:41:18.775115
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    network = AIXNetwork()
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces
    assert len(interfaces['en0']['ipv4']) == 1
    assert 'inet' in interfaces['en0']['ipv4'][0]
    assert 'netmask' in interfaces['en0']['ipv4'][0]
    assert 'broadcast' in interfaces['en0']['ipv4'][0]
    assert 'inet6' in interfaces['en0']['ipv6'][0]

# Generated at 2022-06-22 23:41:30.344935
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Test case for AIXNetwork method parse_interface_line
    """
    AIXNetwork = AIXNetworkCollector._fact_class(dict())

# Generated at 2022-06-22 23:41:31.719774
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = dict()
    facts['kernel'] = 'Linux'
    aix_net = AIXNetworkCollector(facts, None)
    assert aix_net.get_default_interfaces('/sbin/route')

# Generated at 2022-06-22 23:41:33.596125
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    # no failure shall occur
    aix_network = AIXNetwork(module)


# Generated at 2022-06-22 23:41:34.793882
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Constructor creates an object of class AIXNetwork
    obj = AIXNetwork()
    assert isinstance(obj, AIXNetwork)


# Generated at 2022-06-22 23:41:41.385070
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_module = AnsibleModuleMock()
    aix_network = AIXNetwork(aix_module)
    assert aix_network.module == aix_module
    assert aix_network.platform == 'AIX'
    assert aix_network.facts == {}


# Generated at 2022-06-22 23:41:50.603117
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec={
            'filter': dict(default='', type='str'),
            'gather_subset': dict(default=['!all'], type='list'),
            'gather_network_resources': dict(default=['all'], type='list'),
        },
        supports_check_mode=True
    )

    test_obj = AIXNetwork(test_module)
    test_default_interfaces = test_obj.get_default_interfaces(test_module.get_bin_path('route'))

# Generated at 2022-06-22 23:41:57.274038
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test_input = 'lo0:2 flags=849 mtu 8232 index 2'

    words = test_input.split()
    network = AIXNetwork()
    current_if = network.parse_interface_line(words)

    assert current_if['device'] == 'lo0:2'
    assert current_if['flags'] == ['849']
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:41:59.462564
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Execute the constructor of class AIXNetworkCollector
    fa = AIXNetworkCollector()

# Generated at 2022-06-22 23:42:11.000550
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_platform = 'AIX'
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json

    test_words = ['ent0', 'flags=5e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric', '1']

    obj = AIXNetwork(module)
    current_if = obj.parse_interface_line(test_words)

    assert current_if['device'] == 'ent0'

# Generated at 2022-06-22 23:42:13.394167
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.linux.interfaces import AIXNetwork
    aix_network = AIXNetwork()
    assert aix_network is not None

# Generated at 2022-06-22 23:42:14.520828
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork('/sbin/ifconfig')


# Generated at 2022-06-22 23:42:24.347424
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.test_suite_data.aix import test_aix_ifconfig_data
    import sys

    try:
        reload(sys)
        sys.setdefaultencoding('utf8')
    except NameError:
        pass

    try:
        reload(AIXNetwork)
    except NameError:
        pass

    aix = AIXNetwork()
    aix.get_interfaces_info(test_aix_ifconfig_data)

# Generated at 2022-06-22 23:42:31.777752
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test if get_interfaces_info method of class AIXNetwork works properly
    """

    # normal case
    ifconfig_path = "/path/to/ifconfig"
    ifconfig_options = "-a"

# Generated at 2022-06-22 23:42:39.635071
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class NetworkModule:
        def get_bin_path(self, arg):
            return './'

        def run_command(self, cmd):
            out = ['default 192.0.2.1 UG 2 0 en0', 'default 192.0.2.2 UG 0 0 en1', 'default 192.0.2.3 UG 0 0 en4',
                   'default 2001:db8::1 UG 6 0 en0', 'default 2001:db8::2 UG 1 0 en2',
                   'default 2001:db8::3 UG 5 0 en3', 'default 2001:db8::4 UG 0 0 en4']
            return 0, out, ''

    N = AIXNetwork(NetworkModule())

    v4_interface, v6_interface = N.get_default_interfaces(None)
    assert v4_

# Generated at 2022-06-22 23:42:44.594019
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'route_path': {'type': 'str', 'default': '/usr/sbin/route'},
    })
    net = AIXNetwork(module)
    net.get_default_interfaces(module.params['route_path'])

# Generated at 2022-06-22 23:42:46.247826
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-22 23:42:52.555870
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module)

    interfaces, ips = network_collector.get_interfaces_info()

    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0

# Generated at 2022-06-22 23:43:01.520730
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_aixnetwork = AIXNetwork()
    words_aix = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '1']
    if_aix = test_aixnetwork.parse_interface_line(words_aix)
    expected_aix = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}
    assert if_aix == expected_aix

# Generated at 2022-06-22 23:43:09.908783
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mod = AnsibleModule(
        argument_spec=dict(
            gather_network_resources=dict(default=False, type='bool')
        )
    )

    collector = AIXNetworkCollector(module=mod)
    interfaces_info = collector.collect_network_resources()
    assert interfaces_info['interfaces']['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-22 23:43:17.738458
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # Arrange - create class object
    test_module = NetworkCollector()
    test_AIXNetwork = AIXNetwork(test_module)

    # Arrange - create test data
    test_ifconfig_path = '/usr/sbin/ifconfig'
    test_ifconfig_options  = '-a'

# Generated at 2022-06-22 23:43:30.109470
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # mocked output of AIX ifconfig -a command

# Generated at 2022-06-22 23:43:36.496864
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network_common import get_collector_instance
    from ansible.module_utils.facts.network.aix import AIXNetwork
    # TODO: Test with valid network data
    module = None
    collector_instance = get_collector_instance(module, AIXNetworkCollector)
    assert isinstance(collector_instance.get_facts(), AIXNetwork)


# Generated at 2022-06-22 23:43:48.444425
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command = Mock()
            self.get_bin_path = Mock()

        class run_command(object):
            def __init__(self, module):
                self.module = module

            def __call__(self, command, check_rc=True):
                self.command = command
                return None, '', ''

    class MockAIXNetwork(AIXNetwork):
        def __init__(self):
            self.module = MockModule()

    network_instance = MockAIXNetwork()
    words = ['en0:', 'flags=1e080863,480', 'mtu', '1500']

# Generated at 2022-06-22 23:43:49.313356
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(dict())
    assert AIXNetwork(module) is not None

# Generated at 2022-06-22 23:43:51.656242
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    network_class = AIXNetwork()
    assert network_class.platform == 'AIX'

# Generated at 2022-06-22 23:43:53.209629
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    obj = AIXNetwork()
    assert obj.platform == 'AIX'



# Generated at 2022-06-22 23:43:54.886145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()

# Generated at 2022-06-22 23:44:05.330729
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:44:13.687017
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    fact_object = AIXNetwork()
    ifconfig_path = fact_object.module.get_bin_path('ifconfig')
    actual_interfaces_and_ips = fact_object.get_interfaces_info(ifconfig_path)

    # check that both expected results of get_interfaces_info (interfaces, ips)
    # are dicts in the returned value
    assert isinstance(actual_interfaces_and_ips[0], dict)
    assert isinstance(actual_interfaces_and_ips[1], dict)

    # check that the returned dicts are not empty
    assert actual_interfaces_and_ips[0] != {}
    assert actual_interfaces_and_ips[1] != {}

    first_interface = 'en0'
    # check that the first interface is as expected
    assert first_interface

# Generated at 2022-06-22 23:44:17.108359
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # This constructor will not throw an exception, but it is more interesting
    # to inspect the newly created object:
    aix = AIXNetwork(dict(module=None))


# Generated at 2022-06-22 23:44:26.260096
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    if_struct = aix.parse_interface_line(['et0:'])
    assert 'device' in if_struct
    assert if_struct['device'] == 'et0'
    assert 'flags' in if_struct
    assert if_struct['flags'] == []
    assert 'macaddress' in if_struct
    assert if_struct['macaddress'] == 'unknown'
    assert 'mtu' not in if_struct
    assert 'type' in if_struct
    assert if_struct['type'] == 'unknown'
    assert 'ipv4' in if_struct
    assert if_struct['ipv4'] == []
    assert 'ipv6' in if_struct
    assert if_struct['ipv6'] == []

# Generated at 2022-06-22 23:44:37.617895
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:41.420970
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert isinstance(network_collector._fact_class(dict(), dict()), AIXNetwork)
    assert network_collector._platform == 'AIX'



# Generated at 2022-06-22 23:44:48.318956
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = 'ansible.module_utils.facts.network.aix.AIXNetworkCollector'
    m_instance = AIXNetworkCollector()
    assert m_instance.__class__.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.__name__ == 'AIXNetwork'



# Generated at 2022-06-22 23:45:00.012940
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # create instance of AIXNetwork
    aix_network = AIXNetwork()

    # create input string for testing
    input_string = 'en0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>'

    # split input string by spaces
    words = input_string.split()

    # call method parse_interface_line of class AIXNetwork
    current_if = aix_network.parse_interface_line(words)

    # test that device is set
    assert current_if['device'] == 'en0'

    # test that flags are set
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']

    # test that type is set
    assert current_if['type'] == 'unknown'

    # test that MTU is not

# Generated at 2022-06-22 23:45:12.272811
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    uname_path = '/usr/bin/uname'

    module = NetworkCollector()
    module.get_bin_path = lambda x: {'ifconfig': ifconfig_path, 'uname': uname_path}.get(x)
    module.run_command = lambda x: (0, '', '')

    a = AIXNetwork(module)

    # test of get_interfaces_info
    interfaces, ips = a.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-22 23:45:23.087394
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_class = AIXNetwork()
    test_interfaces = {}
    test_interfaces['en0'] = {'device': 'en0', 'ipv4': [{'address': '172.16.10.20', 'broadcast': '172.16.10.255', 'netmask': '255.255.255.0'}], 'ipv6': [], 'macaddress': 'c0:a0:bb:cc:dd:ee', 'type': 'ether', 'flags': ['Up', 'Broadcast', 'Running', 'Multicast', 'Trailer:Built-in', 'Simplex', 'PortSelect', 'Auto', '10BaseT/UTP']}