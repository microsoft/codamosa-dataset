

# Generated at 2022-06-22 23:35:25.410864
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork(dict(module=dict(run_command=lambda *args, **kwargs: (256, "", "")), ansible_facts=dict(kernel="AIX")))
    if4, if6 = net.get_default_interfaces('')
    assert if4 == {}
    assert if6 == {}

    net.module.run_command = lambda *args, **kwargs: (0, "default 172.31.192.1 UG 0 0 en0 en0", "")
    if4, if6 = net.get_default_interfaces('')
    assert if4 == {"gateway": "172.31.192.1", "interface": "en0"}
    assert if6 == {}


# Generated at 2022-06-22 23:35:36.552618
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    net_collector = AIXNetwork(module)

    with open('/proc/net/route') as f:
        data = f.read()
    results = re.findall(r'^\w*\d*\s*00000000\s*([0-9A-F]{8}).*\s*(\w*\d*)\s*$', data, re.MULTILINE)

    if results[0][0] == '0000000A':
        v4_results = ('192.168.1.1', 'eth0')
    elif results[0][0] == '00000000':
        v4_results = ('127.0.0.1', 'lo')
    else:
        assert False, "no test data for ifconfig"

    assert net_collector.get

# Generated at 2022-06-22 23:35:43.243271
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ansible_facts = dict(ansible_net_interfaces=dict())
    network = AIXNetwork(module)
    network.get_default_interfaces()
    ansible_facts['ansible_net_interfaces'] = network.get_interfaces()
    module.exit_json(ansible_facts=ansible_facts)



# Generated at 2022-06-22 23:35:54.308581
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector._get_module_mock(params=dict(gather_subset=['!all', '!min']))
    net = AIXNetwork(module)
    assert net
    assert net.get_default_interfaces('route')
    assert net.get_interfaces_info('ifconfig', '-a')
    assert net.parse_interface_line(['en0:', 'flags=', '0x842<UP,BROADCAST,RUNNING,MULTICAST,DHCP,NONSTOP>', 'metric=1', 'mtu=1500'])
    assert net.parse_options_line(['options=3<RXCSUM,TXCSUM>'], {}, {})
    assert net.parse_nd6_line(['nd6'], {}, {})
    assert net

# Generated at 2022-06-22 23:36:03.370606
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    line = "lo0: flags=8008<LOOPBACK,MULTICAST> inet 127.0.0.1 netmask 0xff000000"
    words = line.split()
    ifconfig_module = AIXNetwork()
    assert ifconfig_module.parse_interface_line(words) == {'device': 'lo0', 'flags': ['LOOPBACK', 'MULTICAST'], 'ipv4': [], 'ipv6': [], 'macaddress': 'unknown', 'type': 'unknown'}


# Generated at 2022-06-22 23:36:13.505743
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    netstat_path = '/usr/bin/netstat'
    uname_path = '/usr/bin/uname'
    route_path = '/usr/bin/route'

    module = FakeModule()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    net = AIXNetwork(module)
    v4_interface, v6_interface = net.get_default_interfaces(route_path)
    assert v4_interface == {'gateway': '10.0.0.1', 'interface': 'ent0'}
    assert v6_interface == {'gateway': 'fd00::1', 'interface': 'en0'}



# Generated at 2022-06-22 23:36:24.289361
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    obj = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')

# Generated at 2022-06-22 23:36:26.826559
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = dict()
    nm = AIXNetworkCollector(facts, None)
    assert nm._platform == 'AIX'
    assert nm._fact_class == AIXNetwork


# Generated at 2022-06-22 23:36:33.670922
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Test constructor of class AIXNetwork
    """

    ifconfig_path = None
    ifconfig_options = '-a'
    route_path = None

    # Test constructor with all args
    network = AIXNetwork(module=None, ifconfig_path=ifconfig_path, ifconfig_options=ifconfig_options, route_path=route_path)

    assert network.ifconfig_path == ifconfig_path, 'Ifconfig path should be ' + ifconfig_path + ' and not ' + network.ifconfig_path
    assert network.ifconfig_options == ifconfig_options, 'Ifconfig options should be ' + ifconfig_options + ' and not ' + network.ifconfig_options
    assert network.route_path == route_path, 'Route path should be ' + route_path + ' and not ' + network.route_

# Generated at 2022-06-22 23:36:44.066516
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Mocking input parameters
    module = MagicMock(return_value={'run_command': 'some_return_value', 'get_bin_path': 'some_return_value'})
    ifconfig_path = 'some_path'
    ifconfig_options = 'some_options'
    netstat_path = '/usr/bin/netstat'

    # Create instance of class AIXNetwork
    aix_network = AIXNetwork(module)

    # Remove netstat_path file to test if netstat_path is executable
    os.remove(netstat_path)

    # Create variables needed for test
    interface = dict(v4={}, v6={})
    rc_value = 0

# Generated at 2022-06-22 23:36:49.579877
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector is not None
    assert net_collector.__class__.__name__ == 'AIXNetworkCollector'
    assert net_collector._fact_class.__name__ == 'AIXNetwork'

# Generated at 2022-06-22 23:36:51.656946
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network is not None


# Generated at 2022-06-22 23:36:54.973811
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:37:06.011351
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:37:08.883239
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector('module')
    assert nc.module == 'module'
    assert nc._platform == 'AIX'


# Generated at 2022-06-22 23:37:20.450852
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """ Unit test for method get_default_interfaces of class AIXNetwork. """
    ansible_module_mock = AnsibleModuleMock()

    network_collector = AIXNetworkCollector(ansible_module_mock)
    network_collector.default_interfaces = dict(v4=dict(), v6=dict())

    network_collector._fact_class.get_default_interfaces = get_default_interfaces_mock
    network_collector._fact_class.get_interfaces_info = get_interfaces_info_mock

    # Set up mock for method ansible_module.run_command
    ansible_module_mock.run_command = [True, '', '']


# Generated at 2022-06-22 23:37:30.023679
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = dict()
    ansible_module = dict()
    ansible_module['run_command'] = mock_command
    ansible_module['get_bin_path'] = _get_bin_path
    inet4_network = AIXNetworkCollector(ansible_module, facts)
    if inet4_network.platform != 'AIX':
        raise AssertionError('AIXNetworkCollector: platform should be <AIX>')
    if inet4_network.facts != facts:
        raise AssertionError('AIXNetworkCollector: facts are not set correctly')
    if inet4_network.module != ansible_module:
        raise AssertionError('AIXNetworkCollector: module is not set correctly')


# Generated at 2022-06-22 23:37:32.409361
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXNetwork


# Generated at 2022-06-22 23:37:35.022940
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_AIXNetwork = AIXNetwork()
    test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig')



# Generated at 2022-06-22 23:37:38.724204
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    Network = AIXNetwork(dict(
        module=dict(
        )),
    )

    assert Network
    assert Network.platform == 'AIX'


# Generated at 2022-06-22 23:37:45.733741
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    fact_subclass = AIXNetworkCollector()
    assert fact_subclass._platform == 'AIX'
    assert fact_subclass.platform == 'AIX'
    assert fact_subclass.get_device_data('/sbin/ifconfig', '-a') is not None
    assert fact_subclass.get_interface_definitions('/sbin/ifconfig', '-a') is not None


# Generated at 2022-06-22 23:37:56.991345
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create a fake module (AnsibleModule object)
    fake_module = FakeAnsibleModule()

    # Create the AIXNetwork object with the fake Ansible module
    aix_network = AIXNetwork(fake_module)

    # run the method get_default_interfaces (network.py)
    ipv4, ipv6 = aix_network.get_default_interfaces(route_path='/usr/sbin/netstat')

    # Assertions
    assert ipv4['gateway'] == '172.16.0.1'
    assert ipv4['interface'] == 'en0'
    assert ipv6['gateway'] == 'fe80::21f:5bff:fe9b:4dd4'
    assert ipv6['interface'] == 'en0'



# Generated at 2022-06-22 23:38:06.481347
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, '', '')
    ifconfig_path = mock_module.get_bin_path.return_value

    aix_network = AIXNetwork(mock_module)
    interfaces, ips = aix_network.get_interfaces_info(ifconfig_path)

    assert interfaces['en0'] == {
        'device': 'en0',
        'flags': ['UP'],
        'ipv4': [],
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'unknown'
    }

    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []

# Generated at 2022-06-22 23:38:17.514619
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ["en1:","flags=1e080863,","<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>",
             "mtu 1500","index 9","address 00:1a:64:c5:eb:c4","flags=","<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>",
             "media:","Ethernet","autoselect","(100baseTX)","status:","active"]

# Generated at 2022-06-22 23:38:26.240256
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod_path = '/usr/bin/ifconfig'
    mod_opt = ''
    module = AnsibleModule(argument_spec=dict())
    aix_network = AIXNetwork(module)
    words = ['em0:', 'flags=1e080863', 'mtu', '1500']
    res = aix_network.parse_interface_line(words)
    assert res['device'] == 'em0'
    assert res['flags'] == aix_network.get_options(words[1])
    assert res['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:38:27.857063
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    assert facts.platform == 'AIX'
    assert facts.fact_class == AIXNetwork

# Generated at 2022-06-22 23:38:28.498981
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass

# Generated at 2022-06-22 23:38:29.633720
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork(None)

# Generated at 2022-06-22 23:38:33.797179
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    n = AIXNetwork()

    # test with not existing route command
    res = n.get_default_interfaces('/tmp')
    assert res == ({}, {}), "Default interface detection failed, error: %s" % res

    return True



# Generated at 2022-06-22 23:38:35.761774
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    n = AIXNetworkCollector()
    # Check if platform attribute is AIX
    assert n._platform == 'AIX'


# Generated at 2022-06-22 23:38:36.962239
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj_dummy = AIXNetworkCollector()
    assert obj_dummy is not None

# Generated at 2022-06-22 23:38:48.745792
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network_object = AIXNetwork()
    line = 'en0: flags=5e080863,c0&lt;UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN&gt;'
    words = line.split()
    current_if = aix_network_object.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'
    assert not current_if['mtu']
    assert 'UP' in current_if['flags']

# Generated at 2022-06-22 23:38:49.952773
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

# Generated at 2022-06-22 23:39:01.648584
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = dict(
        ansible_facts=dict(
            ansible_net_interfaces=dict(
                en0=dict(
                    device='en0',
                    ipv4=[],
                    ipv6=[],
                    type='unknown',
                    flags='UP,BROADCAST,NOTRAILERS,SIMPLEX,MULTICAST',
                    macaddress='unknown'
                )
            )
        )
    )

    words = ['en0:', 'UP,BROADCAST,NOTRAILERS,SIMPLEX,MULTICAST']
    net = AIXNetwork()
    net.parse_interface_line(words)
    assert ansible_module['ansible_facts']['ansible_net_interfaces'] == net.interfaces

# test for aixfacts.py

# Generated at 2022-06-22 23:39:08.598923
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    network = AIXNetwork({}, {}, {})
    route_path = '/usr/sbin/route'
    expected_interface_v4 = {'gateway': '10.0.0.1', 'interface': 'en0'}
    expected_interface_v6 = {'gateway': 'fe80::1', 'interface': 'en0'}

    interface_v4, interface_v6 = network.get_default_interfaces(route_path)
    assert interface_v4 == expected_interface_v4
    assert interface_v6 == expected_interface_v6

# Generated at 2022-06-22 23:39:16.968364
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    Interfaces = dict()
    current_if = dict()

    # Interface 'en5: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    test_words = 'en5: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'.split()
    current_if = AIXNetwork.parse_interface_line(AIXNetwork, test_words)
    assert current_if['device'] == 'en5'

# Generated at 2022-06-22 23:39:28.242884
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = AIXNetwork()
    # test case words list:
    words = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'metric', '0']
    # test case want dictionary:
    want = {'device': 'en0', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'],
            'ipv4': [], 'ipv6': [], 'macaddress': 'unknown', 'type': 'unknown'}
    # test case
    got = test_module.parse_interface_line(words)
    assert got == want
    # print(got)

# Generated at 2022-06-22 23:39:33.276145
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test_flag = False
    try:
        obj = AIXNetworkCollector()
        test_flag = True
    except ImportError:
        pass
    assert test_flag


# Generated at 2022-06-22 23:39:42.649112
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_AIXNetwork = AIXNetwork(dict(module=None, params=None))
    test_interfaces, test_ips = test_AIXNetwork.get_interfaces_info('/usr/sbin/ifconfig', ifconfig_options='en0')

# Generated at 2022-06-22 23:39:54.595918
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts import FactCollector


# Generated at 2022-06-22 23:40:05.515203
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.linux import ansible_facts
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # inherit classes
    class TestCollector(AIXNetworkCollector, ansible_facts.AIXNetworkCollector):
        pass

    class TestIfconfigNetwork(AIXNetwork, GenericBsdIfconfigNetwork, ansible_facts.DefaultNetwork, Network):
        platform = 'AIX'

    class TestNetwork(ansible_facts.Network, Network):
        _collectors = [TestCollector]
        _fact_class = TestIfconfigNetwork


# Generated at 2022-06-22 23:40:16.909785
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'index=2', 'inet=10.1.1.119', 'netmask=255.255.255.192', 'broadcast=10.1.1.255', 'metric=1', 'nd6=', 'options=1<PERFORMNUD>', 'media:Ethernet', 'autoselect', '(1000baseT<full-duplex>)', 'status:active']
    test_object = AIXNetwork()
    current_if = test_object.parse

# Generated at 2022-06-22 23:40:27.300584
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class AIXNetwork
    Note: this test simulates the output of 'ifconfig -a'
    """

    class AIXNetworkTest(AIXNetwork):
        def __init__(self):
            self.module = None


# Generated at 2022-06-22 23:40:36.538054
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    AIXNetwork.get_default_interfaces() Method Test
    """
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # On AIX, this is the output of netstat -nr (only the default interface is shown)
    netstat_path = module.get_bin_path('netstat')
    rc, out, err = module.run_command([netstat_path, '-nr'])
    default1 = dict(interface='en0', gateway='10.0.0.1')

    assert(default1 == network.get_default_interfaces('/etc/route.cfg'))


# Generated at 2022-06-22 23:40:46.465678
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork.
    For this test I do not run any commands, so the method's output
    is based on the content in 'rc' and 'out'. This content is
    simulating the output of 'ifconfig -a'.
    """

    class ModuleStub:

        def __init__(self):
            self.rc = 0

# Generated at 2022-06-22 23:40:54.971668
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    class_object = AIXNetworkCollector()
    assert(class_object.source_file == 'ansible.module_utils.facts.network.aix.AIXNetwork')
    assert(class_object.platform == 'AIX')
    assert(class_object.fact_class == AIXNetwork)
    assert(class_object.fact_source_class == AIXNetwork)
    assert(class_object.exact_match == False)
    assert(class_object.fact_source_types == ['Route', 'Interface'])
    assert(class_object.required_facts == [])


# Generated at 2022-06-22 23:41:06.820675
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = None
    net.module.run_command = test_run_command
    net.module.get_bin_path = test_get_bin_path
# Test 1 with 'netstat' command
    (interface_v4, interface_v6) = net.get_default_interfaces('route_path')
    assert interface_v4['interface'] == 'en3', 'interface name for IPv4 failed'
    assert interface_v4['gateway'] == '10.0.0.1', 'gateway for IPv4 failed'
    assert interface_v6['interface'] == 'en3', 'interface name for IPv6 failed'
    assert interface_v6['gateway'] == '2001:db8::1', 'gateway for IPv6 failed'
# Test 2 with fake 'netstat' command

# Generated at 2022-06-22 23:41:08.620277
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork({}, None)
    aix_network.get_facts()

# Generated at 2022-06-22 23:41:18.002628
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list')
    })

    network_collector = AIXNetworkCollector(test_module)
    network_collector.collect()
    interface = network_collector.get_fact_class().get_default_interfaces(network_collector.get_fact_class().route_path)
    assert interface == ({'gateway': '172.31.255.254', 'interface': 'en0'}, {'gateway': 'fe80::2', 'interface': 'lo0'})


# Generated at 2022-06-22 23:41:29.619387
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    obj = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')

    interfaces, ips = obj.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces.keys()
    assert len(interfaces.keys()) == 17
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'Loopback'
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['macaddress'] == '00:11:32:34:56:78'

# Generated at 2022-06-22 23:41:33.831862
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """Should return dictionary for interface line"""
    network_AIX = AIXNetwork()
    line = 'lo0: flags=1e080863,c0<UP,BROADCAST,LOOPBACK,MULTICAST,DEPRECATED,IPv6,NOFAILOVER>'
    words = line.split()
    result = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'LOOPBACK', 'MULTICAST', 'DEPRECATED', 'IPv6', 'NOFAILOVER']}
    assert network_AIX.parse_interface_line(words) == result

# Generated at 2022-06-22 23:41:45.883502
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    m = AIXNetwork()

    # Replace calls to module.get_bin_path to return any string
    def my_get_bin_path(name, **kwargs):
        return "path_to_" + name

    m.module.get_bin_path = my_get_bin_path

    # Replace calls to module.run_command to return a fixed set of data
    rc_value = 0

# Generated at 2022-06-22 23:41:48.652475
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    ansible_aix_network = AIXNetwork(dict())
    assert ansible_aix_network is not None


# Generated at 2022-06-22 23:41:50.140456
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(), 'could not instantiate AIXNetwork'

# Generated at 2022-06-22 23:41:53.602722
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor test of class AIXNetworkCollector
    """

    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class is AIXNetwork



# Generated at 2022-06-22 23:42:05.478111
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class DummyModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_old_rc = 0
            self.run_command_old_out = ''
            self.run_command_old_err = ''

        def run_command(self, args, check_rc=False):
            self.run_command_calls += 1
            if self.run_command_calls == 1:
                # ifconfig
                return (0, ifconfig_output, '')
            elif self.run_command_calls == 2:
                # uname
                return (0, '0', '')
            elif self.run_command_calls == 3:
                # entstat
                return (0, entstat_output, '')

# Generated at 2022-06-22 23:42:15.803322
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils import basic

    my_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    get_bin_path_orig = my_module.get_bin_path


# Generated at 2022-06-22 23:42:21.479182
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = None
    nm = AIXNetwork(module)

    # Impossible to set up a different route file
    route_path = None
    interface = nm.get_default_interfaces(route_path)
    assert interface == {'gateway': '172.16.14.254', 'interface': 'net0'}, interface


# Generated at 2022-06-22 23:42:30.544769
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts import collector

    # try constructor of class AIXNetwork
    facts = collector.get_network_collector('AIX', 'Network').get_facts()
    assert facts['all_ipv4_addresses']
    assert facts['all_ipv6_addresses']
    assert facts['default_ipv4']['address']
    assert facts['default_ipv4']['gateway']
    assert facts['default_ipv4']['interface']
    assert facts['default_ipv6']['address']
    assert facts['default_ipv6']['gateway']
    assert facts['default_ipv6']['interface']
    assert facts['interfaces']
    assert facts['local']['hostname']
    assert facts['local']['domain']

# Generated at 2022-06-22 23:42:32.190783
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import doctest
    failed, tested = doctest.testmod(AIXNetwork, optionflags=doctest.ELLIPSIS)
    if failed == 0:
        print('PASSED')

# Generated at 2022-06-22 23:42:40.470784
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    result = {}
    this_class = AIXNetwork()
    line_data = ['en0:', 'flags=842<BROADCAST,NOTRAILERS,RUNNING,MULTICAST>', 'mtu=1500']
    result = this_class.parse_interface_line(line_data)
    if result['device'] == 'en0' and result['flags'] == ['BROADCAST', 'NOTRAILERS', 'RUNNING', 'MULTICAST'] and result['macaddress'] == 'unknown':
        return True
    else:
        return False



# Generated at 2022-06-22 23:42:52.053972
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network = AIXNetwork()
    d = {'device': 'lo0', 'type': 'loopback', 'macaddress': 'unknown', 'flags': ['UP'], 'ipv4': [], 'ipv6': []}

    def run_cmd(cmd, paths):
        return (0, """lo0: flags=8c03<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1
    inet 127.0.0.1 netmask 0xff000000
    inet6 ::1/128
    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>""", '')
    aix_network.module.run_command = run_cmd
    d2, ips = aix_network.get_interfaces_info('')

# Generated at 2022-06-22 23:43:02.515849
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # Create a subclass of class AIXNetworkCollector
    class Module(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_network_resources'] = ['interfaces']

    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_network_resources'] = ['interfaces']

        def get_bin_path(self, arg, *args, **kwargs):
            rc = 0
            out = '/usr/sbin/ifconfig'
            err = ''
            return rc, out, err


# Generated at 2022-06-22 23:43:05.043775
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector

# Generated at 2022-06-22 23:43:15.476961
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = None
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])
    current_if = []
    words = []
    for line in out.splitlines():
        if re.match(r'^\w*\d*:', line):
            words = line.split()
            current_if = AIXNetwork.parse_interface_line(AIXNetwork, words)
            break
    assert current_if == {'flags:': [],
                          'ipv4': [],
                          'ipv6': [],
                          'macaddress': 'unknown',
                          'device': 'en0',
                          'type': 'unknown'}

# Generated at 2022-06-22 23:43:20.860747
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    _fact_class = AIXNetwork
    _platform = 'AIX'
    assert AIXNetworkCollector._fact_class == _fact_class
    assert AIXNetworkCollector._platform == _platform

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-22 23:43:32.004497
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = dict()
    module = MockModule()

    ifconfig_path = module.get_bin_path('ifconfig')
    uname_path = module.get_bin_path('uname')
    netstat_path = module.get_bin_path('netstat')

    if not ifconfig_path or not uname_path or not netstat_path:
        module.fail_json(msg="require either 'ifconfig', 'uname' and 'netstat' on AIX system")

    interfaces, ips = AIXNetwork(module).get_interfaces_info(ifconfig_path)
    default_interfaces = AIXNetwork(module).get_default_interfaces(netstat_path)

    facts['interfaces'] = interfaces
    facts['default_interface'] = default_interfaces

# Generated at 2022-06-22 23:43:39.007448
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.get_device_info('bge0')['type'] == 'ether'
    assert aix_network_collector.get_device_info('bge0')['macaddress'] == '40:9c:28:cf:dc:20'
    assert aix_network_collector.get_device_info('bge0')['mtu'] == '1500'


# Generated at 2022-06-22 23:43:40.283189
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork().platform == 'AIX'


# Generated at 2022-06-22 23:43:52.135911
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Create a dummy module
    module = type('',(), {})()
    module.run_command = lambda x, **y: (0, '', '')
    module.get_bin_path = lambda x: x
    module.fail_json = lambda x: None
    
    # get an AIXNetwork fact collector
    fact_collector = AIXNetwork(module)

    # Prepare a dummy interface line
    ifconfig_line = 'en0: flags=0x8a43<UP,BROADCAST,NOTRAILERS,RUNNING,ALLMULTI,SIMPLEX,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN> mtu 1500 index 1'
    words = ifconfig_line.split()

    # Parse the line and build an interface structure
    interface

# Generated at 2022-06-22 23:44:00.350496
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = MockModule()
    net = AIXNetwork(module)

    net.route_path = None
    interface = net.get_default_interfaces(None)
    assert interface == ('', '')

    net.route_path = './test/unit/utils/facts/network/aix/netstat_nr'
    interface = net.get_default_interfaces('./test/unit/utils/facts/network/aix/netstat_nr')
    assert interface == ('192.168.1.1', 'fe80::1')


# Generated at 2022-06-22 23:44:08.704700
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:44:15.671499
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Mock class module
    class TestModule:
        def __init__(self):
            self.check_mode = False
            self.run_command_checks = [dict(path=True, module_utils=True, msg="", rc=None, out="", err="")]
            self.run_command_cnt = 0

        def get_bin_path(self, arg):
            return arg

        def run_command(self, command):
            if self.run_command_cnt >= len(self.run_command_checks):
                return 1, "", "Test_error"
            self.run_command_cnt += 1

# Generated at 2022-06-22 23:44:25.638705
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # Create AIXNetwork object
    n = AIXNetwork(dict(module=None, facts=dict()))

    # Ifconfig output example, taken from ifconfig -a on AIX 7.2,
    # with 2 interfaces (en1 and en2) configured:
    #
    # en1: flags=5e0841<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
            # inet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255
            # inet6 fe80::5054:ff:fe46:3b6d%en1 prefixlen 64 scopeid 0x6
            # ether 52:54:

# Generated at 2022-06-22 23:44:31.862662
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_facts = AIXNetworkCollector(module)

    assert network_facts.get_default_interfaces("route_path") is not None
    assert network_facts.get_interfaces_info("ifconfig_path", "ifconfig_options") is not None

# Generated at 2022-06-22 23:44:40.714259
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Test if netstat exists
    module = MagicMock(params={})
    module.get_bin_path.return_value = '/usr/bin/netstat'
    # Test if default IPv4 route exists
    module.run_command.return_value = (0, "default 192.168.0.1 UG 7 5 en0", '')
    actual = AIXNetwork(module).get_default_interfaces('route_path')
    assert actual == (dict(gateway='192.168.0.1', interface='en0'), {})
    # Test if default IPv6 route exists
    module.run_command.return_value = (0, "default ::1 UG 7 5 en0", '')
    actual = AIXNetwork(module).get_default_interfaces('route_path')

# Generated at 2022-06-22 23:44:50.230042
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    iface = 'lo0'
    words = [iface, 'UP,BROADCAST,LOOPBACK,RUNNING,MULTICAST,IPv6']

    aix = AIXNetwork()
    current_if = aix.parse_interface_line(words)

    assert current_if['device'] == iface
    assert current_if['flags'] == ['UP', 'BROADCAST', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['mtu'] not in current_if



# Generated at 2022-06-22 23:45:01.801884
# Unit test for constructor of class AIXNetworkCollector

# Generated at 2022-06-22 23:45:04.053734
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_facts = AIXNetworkCollector(None, None, None)
    assert network_facts.platform == 'AIX'


# Generated at 2022-06-22 23:45:06.426662
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    net = AIXNetwork(module)
    assert 'AIX' == net.platform

# Generated at 2022-06-22 23:45:18.621589
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    # prepare object
    n = AIXNetwork(module=module)

    # prepare test data
    words = [
        'en1:',
        'flags=842<BROADCAST,RUNNING,MULTICAST>',
    ]

    result = {
        'device': 'en1',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
    }

    result['mtu'] = ''
    result['flags'] = n.get_options(words[1])
    result['macaddress'] = 'unknown'    # will be overwritten later

    # run test
    current_if = n.parse_interface_line(words)

    # assert result