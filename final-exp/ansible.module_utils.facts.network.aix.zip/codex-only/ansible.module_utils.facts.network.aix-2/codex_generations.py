

# Generated at 2022-06-22 23:35:31.043526
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = type("TestModule", (), dict(run_command=lambda x, **kw: [0, '', ''], get_bin_path=lambda x:''))()
    test_AIX_network = AIXNetwork(module=test_module)
    current_if = test_AIX_network.parse_interface_line('en1: flags=19084863<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 9000 index 2.10.0 inet 192.168.1.2 netmask 0xffffff00 broadcast 192.168.1.255'.split())
    assert current_if['device'] == 'en1'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:35:42.983923
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module=dict(
        run_command=lambda x: ('', '\n'.join(test_data) ,''))
    module['run_command'] = lambda x: ('', '\n'.join(test_data), '')
    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'
    network_class = AIXNetwork(module)
    interfaces, ips = network_class.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert len(interfaces) == 3
    assert 'lo0' in interfaces
    assert 'en1' in interfaces
    assert 'en2' in interfaces
    assert len(ips['all_ipv4_addresses']) == 1
    assert 'inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255'

# Generated at 2022-06-22 23:35:50.561724
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    collector = AIXNetworkCollector(module=module)
    network = collector.get_network_facts()
    assert network['default_ipv4']['gateway'] is not None
    assert network['default_ipv6']['gateway'] is not None
    assert network['default_ipv4']['interface'] is not None
    assert network['default_ipv6']['interface'] is not None
    assert len(network['interfaces'].keys()) > 0

# Generated at 2022-06-22 23:36:00.537276
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aixnetwork = AIXNetwork()
    aixnetwork.networks = {}
    aixnetwork.options = {}
    aixnetwork.defaults = {}
    aixnetwork.module = FakeModule()
    aixnetwork.get_interfaces_info('ifconfig')
    assert aixnetwork.networks['en0'] == {'device': 'en0', 'ipv4': ['10.0.2.15'], 'ipv6': ['fe80::250:56ff:fea9:d770'],
                                          'macaddress': '00:50:56:a9:d7:70', 'mtu': '1500', 'type': 'ether',
                                          'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']}

# Class to emulate AnsibleModule

# Generated at 2022-06-22 23:36:11.751145
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    test_AIXNetwork = AIXNetwork()
    assert test_AIXNetwork.parse_interface_line(['en0:']) == {'ipv4': [], 'ipv6': [], 'device': 'en0', 'flags': [], 'macaddress': 'unknown', 'type': 'unknown'}
    assert test_AIXNetwork.parse_interface_line(['en0:','UP','LOOPBACK','RUNNING','MULTICAST']) == {'ipv4': [], 'ipv6': [], 'device': 'en0', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'macaddress': 'unknown', 'type': 'unknown'}

# Generated at 2022-06-22 23:36:16.641921
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert isinstance(collector, AIXNetworkCollector)
    assert collector.platform == 'AIX'
    assert isinstance(collector.fact_class, AIXNetwork)


# Generated at 2022-06-22 23:36:22.244933
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = Mock()
    mock_aix_network = Mock()
    with patch.object(AIXNetwork, '__init__', return_value=None):
        aix_network_collector = AIXNetworkCollector(module, mock_aix_network)
        assert aix_network_collector._fact_class == AIXNetwork
        assert aix_network_collector._platform == 'AIX'

# Generated at 2022-06-22 23:36:24.832451
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    # This is test for AIXNetworkCollector constructor
    # Create a class AIXNetworkCollector
    ans = AIXNetworkCollector()
    assert ans.platform == 'AIX'

# Generated at 2022-06-22 23:36:32.365036
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetwork(module=module)

    fhandle = open("/tmp/test.txt", "r")
    # Mock module.run_command, it returns the output of our test file
    module.run_command = Mock(return_value=(0, fhandle.read(), ''))

    # Call tested method
    result = network_collector.get_default_interfaces("test")

    # Assert result has expected value
    assert result == ({'gateway': '192.168.1.1', 'interface': 'en0'},
                      {'gateway': 'fe80::1', 'interface': 'en0'})
    # Assert module was called with expected parameter

# Generated at 2022-06-22 23:36:42.082070
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    fake_module = FakeAnsibleModule()
    aix_network = AIXNetwork(fake_module)
    words = ['en0:', 'flags=5<UP,BROADCAST,RUNNING,MULTICAST>', 'mtu', '1500', 'index', '3',
             'inet', '192.168.1.1', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255',
             'nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>']
    result = aix_network.parse_interface_line(words)
    assert result['device'] == 'en0'

# Generated at 2022-06-22 23:36:49.538497
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    answers = dict(
        v4=dict(gateway='192.168.42.2', interface='en0'),
        v6=dict(gateway='fe80::21e:c9ff:fee1:c8f5', interface='en0')
    )
    assert aix_network.get_default_interfaces('route') == (answers['v4'], answers['v6'])

# Generated at 2022-06-22 23:37:01.044428
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))))

    from ansible.module_utils._text import to_bytes, to_native

    from ansible.module_utils.facts import get_module_path
    sys.path.insert(0, get_module_path())

    from ansible.module_utils.facts import ansible_collections

    aix_network = ansible_collections.ansible.misc.plugins.module_utils.network.aix.AIXNetwork()


# Generated at 2022-06-22 23:37:09.951576
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod = AnsibleModule(argument_spec={})
    ifc = AIXNetwork(mod)

    #test interface line
    line = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33136 index 1'
    words = line.split()
    # print(words)
    result = ifc.parse_interface_line(words)
    # print(result)
    assert ('ipv4', []) in result.items()
    assert ('ipv6', []) in result.items()
    assert ('device', 'lo0') in result.items()
    assert ('macaddress', 'unknown') in result.items()
    assert ('type', 'unknown') in result.items()

# Generated at 2022-06-22 23:37:16.412904
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test Constructor of AIXNetwork()."""

    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    aix_network = AIXNetwork(module=module, network_collector=network_collector)

    assert aix_network.module is not None
    assert aix_network.network_collector is not None



# Generated at 2022-06-22 23:37:27.511689
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self):
            self.module = None
            self.fail_json = None
            self.run_command = None

    class MockFailJson(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True

    class MockRunCommand(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True
            return 0, '', ''

    def mock_get_bin_path(name, *args, **kwargs):
        if name == 'uname':
            return '/usr/bin/uname'
        elif name == 'lsattr':
            return

# Generated at 2022-06-22 23:37:31.074088
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():

    net_fact_cls = AIXNetworkCollector(None, '/tmp', None)
    assert net_fact_cls._platform == 'AIX'



# Generated at 2022-06-22 23:37:41.554480
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:37:47.047037
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector

    aix_collector = AIXNetworkCollector()

    assert isinstance(aix_collector, NetworkCollector)
    assert aix_collector._fact_class.platform == 'AIX'



# Generated at 2022-06-22 23:37:58.155972
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'route_path': {'type': 'str', 'choices': ['/usr/sbin/netstat', '/tmp/dummy_netstat']}})
    ansible_facts = dict()
    ansible_facts['ansible_net_interfaces'] = dict(
        dummy_interface=dict(
            ipv4=dict(
                address='192.168.0.1',
                netmask='255.255.255.0',
                network='192.168.0.0',
            ),
            ipv6=dict(
                address='fe80::1',
                netmask='ffff:ffff:ffff:ffff::',
                network='fe80::',
            ),
            type='dummy',
        ),
    )

# Generated at 2022-06-22 23:38:07.616641
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Output of uname -W command is used to determine wpars or not.
    so we need to mock it.
    """

    # prepare mocking of module.run_command
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collector

    module = AnsibleModule(argument_spec=dict())

    # prepare mocks
    module.run_command = MockRunCommand
    default_collector.module = module

    # run test
    collector = default_collector.get_network_collector('AIX', module)
    assert collector._platform == 'AIX'

    # Uncomment following two lines to show collected network facts.
    #fact_dict = collector.collect()
    #from ansible.module_utils.facts.utils import ansible_facts_to

# Generated at 2022-06-22 23:38:11.043634
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    x = AIXNetworkCollector()
    assert x.platform == 'AIX'

# Generated at 2022-06-22 23:38:20.617060
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Prepare test data
    netstat_path = '/usr/bin/netstat'
    netstat_command = [netstat_path, '-nr']

# Generated at 2022-06-22 23:38:32.358645
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    netstuff = dict(
        cmdline=dict(
            chdir='/tmp',
            close_fds=True,
            encoding=None,
            errors=None,
            executable=None,
            preexec_fn=None,
            shell=False,
            universal_newlines=False
        ),
        rc=0,
        stderr=None,
        stdout=u'  Routing tables\n  Internet: \n    Destination        Gateway            Flags Refs Use Netif Expire\n    default            172.17.1.1        UG        0 0     en0\n    127                127.0.0.1         UH        1 4897 lo0\n'
    )
    interface = dict(v4={}, v6={})
    interface['v4']['interface'] = 'en0'

# Generated at 2022-06-22 23:38:38.460516
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import Collector

    ifconfig_path = '/bin/ifconfig'
    route_path = '/usr/bin/netstat'
    test_obj = AIXNetworkCollector(dict(ifconfig_path=ifconfig_path, route_path=route_path), {})
    assert test_obj is not None
    assert isinstance(test_obj.fact_class, AIXNetwork)
    assert test_obj.platform == 'AIX'
    assert isinstance(test_obj, Collector)


# Generated at 2022-06-22 23:38:40.119817
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    m = AIXNetwork()


# Generated at 2022-06-22 23:38:44.276123
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    MODULE_UTILS_PATH = 'ansible/module_utils/network/'
    module = 'AIXNetwork.py'
    module_path = MODULE_UTILS_PATH + module
    exec(open(module_path).read())

    net_obj = AIXNetwork()
    words = ['lo0:', 'flags=1', 'pkt_chk_error_concealment']
    current_if = net_obj.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['1']
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:38:44.613398
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork()

# Generated at 2022-06-22 23:38:55.487635
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    from ansible.module_utils.facts.network.aix import AIXNetwork

    class MockModule():
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, opt_dirs=[]):
            return os.path.join(self.params['mock_path'], name)

        def run_command(self, cmd):
            rc, out, err = self.params['mock_run_command'](cmd)

            return rc, out, err

    test_path = os.path.dirname(os.path.abspath(__file__))

    class IfconfigPath():
        def __init__(self):
            self.count = 0

        def __call__(self, cmd):
            rc = 1
           

# Generated at 2022-06-22 23:39:05.852472
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    net = AIXNetwork()
    net.module = MockModule()
    net.module.run_command = mock_run_command


# Generated at 2022-06-22 23:39:10.196760
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class module:
        def get_bin_path(self, cmd):
            return cmd

        def run_command(cmd):
            if cmd == 'netstat -nr':
                return (0, "default 172.16.1.1 UG en0\ndefault fd01:234:56::1 UG en1", "")
            else:
                return (0, "", "")

    AIXNetwork_test_object = AIXNetwork(module)

    assert AIXNetwork_test_object.get_default_interfaces('path') == ({'gateway': '172.16.1.1',
                                                                      'interface': 'en0'},
                                                                     {'gateway': 'fd01:234:56::1',
                                                                      'interface': 'en1'})

# Generated at 2022-06-22 23:39:13.860598
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:39:22.743225
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mod = AnsibleModule(argument_spec={'route_path': dict(type='str', default='/usr/sbin/netstat')})
    fct = AIXNetwork(module=mod)

    # Test with a valid interface
    interfaces_v4, interfaces_v6 = fct.get_default_interfaces(mod.params['route_path'])
    assert interfaces_v4['interface'] == 'net0'
    assert interfaces_v6['interface'] == 'net0'
    assert interfaces_v4['gateway'] == '10.48.64.1'
    assert interfaces_v6['gateway'] == 'fe80::21a:a0ff:fe03:b400%net0'

    # Test with a invalid interface

# Generated at 2022-06-22 23:39:28.018901
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_module = AIXNetwork(module)
    network_module.populate()
    keys = ['default_ipv4_interface', 'interfaces']
    for key in keys:
        assert key in network_module.data



# Generated at 2022-06-22 23:39:40.364801
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test AIXNetworkCollector class constructor"""

    # Test with "ansible_test_switch" set to "true"
    facts = dict(
        ansible_test_switch=True,
    )
    network_collector = AIXNetworkCollector(facts, None)
    assert isinstance(network_collector, NetworkCollector)
    assert not network_collector.ignore_interface('eth0')
    assert network_collector.ignore_interface('lo')
    assert not network_collector.ignore_interface('virbr0')

    # Test with "ansible_test_switch" not set
    facts = dict()
    network_collector = AIXNetworkCollector(facts, None)
    assert isinstance(network_collector, NetworkCollector)
    assert not network_collector.ignore_interface('eth0')
   

# Generated at 2022-06-22 23:39:44.513467
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aixnetwork = AIXNetwork()
    words = ['wl0:', 'flags=8c02', 'mtu=4500']
    current_if = aixnetwork.parse_interface_line(words)

    assert current_if['device'] == 'wl0'
    assert current_if['flags'] == ['8c02']
    assert 'mtu' not in current_if



# Generated at 2022-06-22 23:39:52.798455
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()

    words = ['en0:', 'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,FIXEDMTU>', 'mtu=1500']
    current_if = aix_network.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['mtu'] == '1500'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:39:57.773805
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This test checks the constructor of class AIXNetworkCollector
    """
    # Check that the _fact_class is AIXNetwork
    assert AIXNetworkCollector._fact_class == AIXNetwork

    # Check that the _platform is AIX
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-22 23:40:03.219462
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector.__dict__['_platform'] == 'AIX'
    assert network_collector.__class__.__name__ == 'AIXNetworkCollector'
    assert isinstance(network_collector._fact_class, AIXNetwork)



# Generated at 2022-06-22 23:40:04.336961
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    p = AIXNetwork()


# Generated at 2022-06-22 23:40:10.281403
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all']
    network = AIXNetwork(module)
    route_path = network.get_bin_path('route', required=False)
    if route_path:
        interfaces = network.get_default_interfaces(route_path)
        assert isinstance(interfaces, dict)


# Generated at 2022-06-22 23:40:16.396269
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # Unit test for AIXNetworkCollector.__init__()
    _fact_class = AIXNetwork
    _platform = 'AIX'
    network = NetworkCollector.fetch_fact_class(_fact_class, _platform)()
    assert network.platform == 'AIX'
    assert isinstance(network, AIXNetwork)


# Generated at 2022-06-22 23:40:26.714602
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import copy
    from ansible.module_utils.facts.network.base import NetworkCollector

    def test_object():
        module_mock = AnsibleModuleMock()


# Generated at 2022-06-22 23:40:28.490669
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)


# Generated at 2022-06-22 23:40:29.120931
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'


# Generated at 2022-06-22 23:40:40.309681
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # test1
    module = AnsibleModule(
        argument_spec=dict(),
    )

    aix_network = AIXNetwork(module)

    rcv4, rcv6 = aix_network.get_default_interfaces('/sbin/route')

    assert rcv4 == {'interface': 'en0', 'gateway': '192.168.1.1'}, "test1 failed"
    assert rcv6 == {'interface': 'en0', 'gateway': 'fe80::21e:c0ff:fe4a:4d99'}, "test1 failed"

    # test2


# Generated at 2022-06-22 23:40:47.395308
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:40:53.529057
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    test_module.module.run_command = lambda *args, **kwargs: (0, 'default 172.16.0.1 UGS 0 0 en1', '')

    assert AIXNetwork(test_module).get_default_interfaces('netstat') == ({'interface': 'en1', 'gateway': '172.16.0.1'}, {})

# Generated at 2022-06-22 23:41:05.310362
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # we need to mock the function run_command since this is platform dependent
    # and we are testing the function of class AIXNetwork in a platform independent way
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-22 23:41:17.275282
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # example of 'ifconfig -a' output, from AIX 7.1
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'

    # parse line and get the dictionary
    network = AIXNetwork()
    current_if = network.parse_interface_line(line.split())

    # build expected dictionary

# Generated at 2022-06-22 23:41:19.284665
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Constructor method test"""
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'


# Generated at 2022-06-22 23:41:30.964242
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # test input
    ifconfig_path = '/usr/sbin/ifconfig' # dummy
    ifconfig_options = '-a' # dummy
    # AIX 'ifconfig -a' does not have three words in the interface line

# Generated at 2022-06-22 23:41:38.849889
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = None
    ifconfig_path = "/usr/sbin/ifconfig"
    ifconfig_options = '-a'
    ifconfig_rc = 0

# Generated at 2022-06-22 23:41:48.957699
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    src = AIXNetwork()
    interfaces, ips = src.get_interfaces_info('./fake_bin/bsd_ifconfig', '-a')

# Generated at 2022-06-22 23:41:52.262943
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    collector = AIXNetworkCollector(module=module)
    assert collector.platform == 'AIX'
    assert collector.fact_class._platform == 'AIX'


# Generated at 2022-06-22 23:41:55.128648
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    for_test = AIXNetwork(None)
    if for_test.platform != 'AIX':
        raise Exception('Unexpected test result')

# Generated at 2022-06-22 23:42:03.462457
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_words = ['ent0:', 'flags=0x8800<BROADCAST,SIMPLEX,MULTICAST>', 'mtu', '14944']
    network = AIXNetwork()
    current_if = network.parse_interface_line(test_words)
    assert current_if['device'] == 'ent0'
    assert current_if['flags'] == ['BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'


if __name__ == '__main__':
    test_AIXNetwork_parse_interface_line()

# Generated at 2022-06-22 23:42:14.785343
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Returns the default IPv4 and IPv6 interface and their respective gateways
    - If default IPv4 interface gateway found, return
        default_interface_v4['interface'] = interface_name
        default_interface_v4['gateway'] = default_gateway
    - If default IPv6 interface gateway found, return
        default_interface_v6['interface'] = interface_name
        default_interface_v6['gateway'] = default_gateway
    """

    from ansible.module_utils import basic

    test_object = AIXNetwork(basic.AnsibleModule(
    ))

    route_path = test_object.module.get_bin_path('netstat')

    def_interface_v4, def_interface_v6 = test_object.get_default_interfaces(route_path)

    assert def_interface_

# Generated at 2022-06-22 23:42:27.001464
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aixnet = AIXNetwork()

    # AIX 6 (similar for AIX 7)

# Generated at 2022-06-22 23:42:31.294467
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_obj = AIXNetworkCollector()
    current_if = test_obj.fact_class._platform_facts['ansible_network_resources']['interfaces']\
        ['lo0']
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:42:33.001307
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor for class AIXNetworkCollector
    """
    network_obj = AIXNetworkCollector()
    assert network_obj._platform == 'AIX'



# Generated at 2022-06-22 23:42:45.150380
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    tests parse_interface_line of class AIXNetwork through setup_module
    :return:
    """
    if os.name == "nt":
        pytest.skip("Running on windows")
    test_dict = dict(device='en0', flags='UP,BROADCAST,NOTRAILERS,RUNNING', macaddress='00:11:22:33:44:55', mtu='1500')
    assert setup_module.test_class.parse_interface_line(test_dict) == test_dict

    test_dict = dict(device='en1', flags='UP,BROADCAST,NOTRAILERS,RUNNING', macaddress='00:11:22:33:44:55', mtu='1500')
    assert setup_module.test_class.parse_interface_line(test_dict) == test_dict



# Generated at 2022-06-22 23:42:57.189918
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )
    testobj = AIXNetwork()
    testobj.module = test_module
    testobj.module.warn = mock.Mock()
    testobj.get_bin_path = mock.Mock()

    testobj.get_bin_path.side_effect = lambda x: x

    testargs = []

    testwords = ['en0:', 'flags=800843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    testres = testobj.parse_interface_line(testwords)
    assert testres['device'] == testwords[0][0:-1]

# Generated at 2022-06-22 23:43:06.108701
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    test_instance = AIXNetwork()
    test_instance.get_interfaces_info = GenericBsdIfconfigNetwork.get_interfaces_info
    test_instance.get_configured_interfaces = GenericBsdNetwork.get_configured_interfaces
    test_instance.get_default_interfaces = AIXNetwork.get_default_interfaces

    test_instance.module = {}
    test_instance.module.run_command = run_command_for_test

# Generated at 2022-06-22 23:43:07.264851
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

# Generated at 2022-06-22 23:43:16.616406
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class ModuleStub():
        def get_bin_path(self, arg):
            return '/usr/bin/netstat'

        def run_command(self, arg):
            return 0, '/usr/bin/netstat -nr\n\n' + \
                'default 192.168.1.1 UG 0 0 en0\n' + \
                'default fe80::8a2e:1fff:fe93:28b0%en0 UGDArio 0 0 en0\n', ''

    result = dict(v4=dict(), v6=dict())
    result['v4']['gateway'] = '192.168.1.1'
    result['v4']['interface'] = 'en0'

# Generated at 2022-06-22 23:43:26.040078
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    gbn = AIXNetwork()
    ifconfig_path = None
    route_path = None
    default_gateway_v4, default_gateway_v6 = gbn.get_default_interfaces(route_path)
    assert default_gateway_v4['gateway'] == '10.0.0.1'
    assert default_gateway_v4['interface'] == 'en0'
    assert default_gateway_v6['gateway'] == 'fe80::250:56ff:fe8a:e31a'
    assert default_gateway_v6['interface'] == 'en0'

# Generated at 2022-06-22 23:43:36.167262
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = "en1: flags=2E084863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>".split(',')
    words = "".join(words).split()
    current_if = AIXNetwork.parse_interface_line(words)
    assert current_if['device'] == 'en1'
    assert current_if['flags'] == '2E084863,c0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:43:41.256261
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    net_collector = AIXNetworkCollector
    assert net_collector.get_network_collector() == AIXNetworkCollector
    net_collector.platform = 'AIX'
    assert net_collector.get_network_collector() == AIXNetworkCollector


# Generated at 2022-06-22 23:43:50.945010
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "default 0.0.0.0 UG 1 en0", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/netstat")
    facts = AIXNetwork(module)
    rc, v4, v6 = facts.get_default_interfaces("/sbin/route")

    assert v4['interface'] == 'en0'
    assert v4['gateway'] == '0.0.0.0'
    assert v6 is None


# Generated at 2022-06-22 23:43:57.641516
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ansible_module = get_module_mock()

    obj = AIXNetwork(ansible_module)

    netstat_path = '/usr/bin/netstat'
    route_path = ''

    ansible_module.run_command.return_value = (0,
'''
default          10.10.10.1          UGS         0        28674 en0
default          192.168.1.1         UGS         0        28674 en1
default          ::1/128             UGS         0   571458444460 lo0
default          fe80::1/128         UGS         0   571458444460 lo0
''', '')

    ret = obj.get_default_interfaces(route_path)

# Generated at 2022-06-22 23:44:05.770701
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # Empty constructor
    network = AIXNetwork()

    # Check the default values
    if network.interface:
        assert False

    if network.interfaces:
        assert False

    if network.ipv4:
        assert False

    if network.ipv6:
        assert False

    if network.interfaces_ipv4:
        assert False

    if network.interfaces_ipv6:
        assert False

    if network.default_ipv4:
        assert False

    if network.default_ipv6:
        assert False

    # Check the default values
    if not network.network_packages:
        assert False

    if not network.config:
        assert False



# Generated at 2022-06-22 23:44:11.151262
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleMock(
        params=dict(
            gather_network_resources=dict(default_gateway=True)
        ),
    )
    net = AIXNetwork(module)
    test_route = '/usr/bin/netstat'
    v4, v6 = net.get_default_interfaces(test_route)
    assert v4['interface'] == 'en0'
    assert v4['gateway'] == '192.168.1.1'
    assert v6['interface'] == 'en0'
    assert v6['gateway'] == 'fe80::a00:27ff:fe2a:9c7e'

# Generated at 2022-06-22 23:44:22.867409
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    module = None
    ifconfig_path = '/bin/ifconfig'
    ifconfig_options = '-a'


# Generated at 2022-06-22 23:44:24.276169
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    x = AIXNetwork({}, {}, {}, {})
    assert x.platform == 'AIX'

# Generated at 2022-06-22 23:44:36.302142
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import sys
    import unittest
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    # make an AIXNetwork Collector instance
    networkCollector = NetworkCollector()
    networkCollector._platform = 'AIX'
    networkCollector._fact_class = AIXNetwork

    # make an AIXNetwork instance
    aix_network = AIXNetwork()

    # get the ifconfig_path
    ifconfig_path = aix_network.module.get_bin_path('ifconfig')

    # create a temporary test file simulating the output of 'ifconfig -a'
    #     ifconfig_path = /usr/bin/ifconfig
    #     ifconfig -a >/tmp/test_A

# Generated at 2022-06-22 23:44:41.755442
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class Args:
        def __init__(self):
            self.route_path = '/usr/sbin/netstat'
            self.bin_path = ''
    module = Args()
    ifconfig = AIXNetwork()
    (i4, i6) = ifconfig.get_default_interfaces(module)
    assert i6['interface'] == 'en0'


# Generated at 2022-06-22 23:44:52.614956
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    m = get_network_collector_mock(AIXNetwork)
    expected_v4 = {'gateway': '172.16.1.1', 'interface': 'en0'}
    expected_v6 = {'gateway': 'fe80:1:2::3', 'interface': 'en1'}
    # default_gateway_v4 and default_gateway_v6 are the values
    # returned by method get_default_interfaces
    default_gateway_v4, default_gateway_v6 = m.get_default_interfaces("")
    assert (expected_v4 == default_gateway_v4)
    assert (expected_v6 == default_gateway_v6)



# Generated at 2022-06-22 23:45:03.241288
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # test for empty words
    words = ''
    current_if = AIXNetwork.parse_interface_line(words)
    assert current_if['macaddress'] == 'unknown'
    assert current_if['mtu'] == ''
    assert current_if['type'] == 'unknown'

    # test for words
    words = ['test0:', 'flags=0x3', '<flags>']
    current_if = AIXNetwork.parse_interface_line(words)
    assert current_if['device'] == 'test0'
    assert current_if['flags'] == '0x3'

    # test for words without <flags>
    words = ['test0:', 'flags=0x3']
    current_if = AIXNetwork.parse_interface_line(words)

# Generated at 2022-06-22 23:45:15.445274
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # initialize a module
    import ansible.module_utils.facts.network.aix.aix as aix_mod
    aix_mod.load_platform_subclass = lambda self, group, param='*': None
    module = aix_mod.AixFactsModule()

    # create the object
    aix_network = AIXNetwork(module)

    # get output of ifconfig -a
    rc, out, err = module.run_command(['/usr/sbin/ifconfig', '-a'])

    # create expected results
    expected_interfaces = {}

# Generated at 2022-06-22 23:45:21.856793
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This is a unit test for the constructor of the class AIXNetworkCollector.
    It will fail if the constructor does not return an object of the
    class AIXNetworkCollector.
    """
    network_collector = AIXNetworkCollector()
    assert isinstance(network_collector, AIXNetworkCollector)

if __name__ == '__main__':
    # Unit test
    test_AIXNetworkCollector()
    print('Unit test failed.')