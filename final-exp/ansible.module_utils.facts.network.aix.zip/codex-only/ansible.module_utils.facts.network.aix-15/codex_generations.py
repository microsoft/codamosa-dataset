

# Generated at 2022-06-22 23:35:21.270390
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    # Test for assert, should not raise AssertionError
    assert (network)


# Generated at 2022-06-22 23:35:24.892726
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix = AIXNetwork()
    assert aix.platform == 'AIX'
    assert aix_an.module == mock_module

# Generated at 2022-06-22 23:35:33.823185
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix.test_fixture import test_class_get_interfaces_info

    AIXNetwork.get_interfaces_info = test_class_get_interfaces_info.get_interfaces_info
    aix = AIXNetwork()
    aix.module = FakeAnsibleModule()
    fake_data_dir = test_class_get_interfaces_info.get_data_dir()
    fake_ifconfig_path = fake_data_dir + '/ifconfig'
    aix.get_interfaces_info(fake_ifconfig_path)



# Generated at 2022-06-22 23:35:45.066751
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class Options(object):
        def __init__(self):
            self.module_path = None

    class Module(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    def get_bin_path(bin):
        if bin == 'netstat':
            return bin
        assert 0


# Generated at 2022-06-22 23:35:55.737913
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method :meth:`get_interfaces_info <ansible.module_utils.facts.network.aix.AIXNetwork.get_interfaces_info>` of class :class:`AIXNetwork <ansible.module_utils.facts.network.aix.AIXNetwork>`.

    This test is based on AIX plugin unit test framework
    (test_aix_plugin.py)

    :return: None
    """

    # Some values to be tested
    eth1_ipv4 = {'address': '10.0.0.2', 'netmask': '255.255.255.0', 'broadcast': '10.0.0.255'}

# Generated at 2022-06-22 23:35:58.073247
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:36:09.927359
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    i = AIXNetwork()

    # Test 1: no output
    out = ''
    interfaces, ips = i.get_interfaces_info(out)
    assert len(interfaces) == 0
    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []

    # Test 2: only 2 interfaces

# Generated at 2022-06-22 23:36:11.602912
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:36:17.054854
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    platform = 'AIX'
    module = AnsibleModule(argument_spec={})
    module.params = {}
    network = AIXNetwork(module=module)
    interfaces = network.get_interfaces_info()
    assert(interfaces)


# Generated at 2022-06-22 23:36:26.664544
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class ModuleStub(object):
        '''Module stub'''
        def __init__(self):
            self.params = {'gather_subset': 'all'}

        def get_bin_path(self, key, required=False):
            if key == 'ifconfig':
                return 'ifconfig'

    class TestAIXNetwork(AIXNetwork):

        '''Specific class for tests'''

        def __init__(self, module):
            self.module = module
            self.facts = {}

        def populate(self):
            self.get_network_facts()
            return self.facts

    # Expected result
    ifconfig_path = TestAIXNetwork(ModuleStub()).module.get_bin_path('ifconfig')
    rc, out, err = TestAIXNetwork(ModuleStub()).module

# Generated at 2022-06-22 23:36:38.000407
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    if mod._name == 'setup':
        ansible_network = AIXNetworkCollector(module=mod)
        facts = ansible_network.get_facts()
        interfaces = facts['ansible_interfaces']
        assert 'ansible_all_ipv4_addresses' in facts
        assert 'ansible_all_ipv6_addresses' in facts
        assert 'ansible_default_ipv4' in facts
        assert 'ansible_default_ipv6' in facts

        for iface in interfaces:
            assert 'device' in iface
            assert 'mtu' in iface
            assert 'macaddress' in iface
            assert 'type'

# Generated at 2022-06-22 23:36:46.437757
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Test the output of parse_interface_line with the following values:
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '1500']
    """
    obj = AIXNetwork()
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '1500']
    result = obj.parse_interface_line(words)

# Generated at 2022-06-22 23:36:56.525979
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fixture = {
        'netstat_path': '/bin/netstat',
        'run_command_stdout': (
            'Route Table\n'
            '   Destination           Gateway           Interface    Flags   Refs   Use   Mtu     Prio\n'
            'default                  192.0.2.33        en0             UG       0      0  1500      0\n'
            'default                  2001:db8:100::33  en1             UG       0      0  1500      0\n'
        ),
    }

    network = AIXNetwork(None)

# Generated at 2022-06-22 23:37:00.603746
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Testing AIXNetworkCollector.__init__() """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector)

# Generated at 2022-06-22 23:37:01.528672
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork(None)

# Generated at 2022-06-22 23:37:10.240623
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    obj = AIXNetwork(module=module)

    module.run_command = MagicMock(return_value=(0, 'default  192.168.0.1 UG   1 12    en0', ''))
    assert obj.get_default_interfaces('/bin/netstat') == ({'gateway': '192.168.0.1', 'interface': 'en0'}, {})

    module.run_command = MagicMock(return_value=(0, 'default  192.168.0.1 UG   1 12   en0', ''))

# Generated at 2022-06-22 23:37:11.504060
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork({})


# Generated at 2022-06-22 23:37:15.059172
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    fact_class = AIXNetworkCollector(None, None, 'aix', None).collect()
    assert fact_class is not None

# Generated at 2022-06-22 23:37:26.116048
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Sample output of 'netstat -nr' when route exists
    sample_netstat_content1 = """
        Destination        Gateway           Flags   Refs     Use     Interface
        default            10.0.2.2         UG        0          0         en0
        127                127.0.0.1        UGS       0       1968     lo0
        127.0.0.1          127.0.0.1        UH        5       8761     lo0
        10.0.2.0/24        10.0.2.2         U         0          0         en0
        10.0.2.2           10:00:27:fb:38:d0 UHLWI     0          2         en0
    """

    # Sample output of 'netstat -nr' when route does not exist
    sample_netstat_content2

# Generated at 2022-06-22 23:37:29.911410
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    Args = namedtuple('Args', ['module', 'run_command'])
    module = Args(None, None)
    result = AIXNetwork(module).get_interfaces_info('/usr/sbin/ifconfig')
    assert result[1] != {}

# Generated at 2022-06-22 23:37:33.547298
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    assert network.platform == 'AIX'
    assert network._platform == 'AIX'
    assert network.module == module



# Generated at 2022-06-22 23:37:39.969883
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(route_path=dict(type='str')))
    route_path = module.params['route_path']
    collector = AIXNetworkCollector(module=module)
    netinfo = collector.get_default_interfaces(route_path)
    assert netinfo is not None


# Generated at 2022-06-22 23:37:42.793905
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_net = NetworkCollector.factory('AIX')
    assert isinstance(aix_net, AIXNetworkCollector)

# Generated at 2022-06-22 23:37:48.261681
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec={})
    ifac=AIXNetwork(mod)
    assert ifac.platform == 'AIX'
    assert ifac.use_module == False
    assert isinstance(ifac,NetworkCollector)
    assert ifac.facts == {}


# Generated at 2022-06-22 23:37:59.125788
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    fake_AIXNetwork = type('fake_AIXNetwork', (AIXNetwork, ), dict())()
    fake_AIXNetwork.module = type('fake_module', (), dict())()

    fake_AIXNetwork.module.run_command = type('fake_run_command', (), dict())()

# Generated at 2022-06-22 23:38:08.144853
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    class AixModuleFake:
        def get_bin_path(self, path):
            return '/usr/sbin/' + path

        def run_command(self, args):
            return (0, '', '')

    class AixNetworkFake(AIXNetwork):
        def __init__(self):
            self.module = AixModuleFake()

    aix_network_fake = AixNetworkFake()

    interfaces = dict()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    current_if = dict()

# Generated at 2022-06-22 23:38:16.816503
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # create an instance of class AIXNetwork
    x = AIXNetwork()

    # create a test line
    words = ['en0:', 'flags=', '842<BROADCAST,NOTRAILERS,SIMPLEX,MULTICAST>']

    # call method parse_interface_line to extract the device name
    result = x.parse_interface_line(words)

    # test the result of method parse_interface_line
    assert result['device'] == words[0][0:-1]
    assert result['flags'] == 842
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:38:21.117680
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_clct = AIXNetworkCollector('/path/to/module', '/path/to/module/arg', '/path/to/module/ansible_facts')
    assert net_clct._fact_class == AIXNetwork


# Generated at 2022-06-22 23:38:29.412795
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnet = AIXNetwork()
    aixnet.module = mock.Mock()
    aixnet.module.run_command.return_value = [0, 'default 172.21.1.1 UG 12 2 en1', None]
    aixnet.route_path = os.path.dirname(os.path.dirname(__file__)) + '/fixtures/route'

    assert aixnet.get_default_interfaces(aixnet.route_path) == ('en1', 'en1')



# Generated at 2022-06-22 23:38:38.854242
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """Test AIXNetwork.parse_interface_line."""
    net = AIXNetwork()
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT>', 'inet', '172.22.0.11', 'netmask', '0xffffff00', 'broadcast', '172.22.0.255']
    current_if = net.parse_interface_line(words)

# Generated at 2022-06-22 23:38:50.630618
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:38:54.061908
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    This function tests the constructor of class AIXNetworkCollector
    """
    collector = AIXNetworkCollector(None)
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:39:05.069003
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:39:09.438032
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import platform
    platform.system = lambda: 'AIX'
    platform.release = lambda: '7.2.0.0'
    platform.version = lambda: '1'

    from ansible.module_utils.facts.network.aix import AIXNetwork


# Generated at 2022-06-22 23:39:17.481623
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import tempfile
    from ansible_collections.community.general.tests.unit.compat.mock import Mock, patch
    module = Mock()
    module.run_command.side_effect = [
        (0, 'default 192.168.0.254 UGS 0 237 en0', ''),
        (0, 'destination    gateway        flags    refs  use  interface', ''),
        (0, 'default        2001:db8::1    UGS        0    0    en1', ''),
    ]
    # module.get_bin_path.side_effect = ['netstat']
    ifconfig_collector = AIXNetworkCollector(module=module)
    v4_defaults, v6_defaults = ifconfig_collector.get_default_interfaces('route')

# Generated at 2022-06-22 23:39:29.329102
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = get_platform_module('A')
    network = AIXNetwork(module, [], [])
    netstat_path = network.module.get_bin_path('netstat')
    route_path = network.module.get_bin_path('route')
    # aix6.1 route does not work correctly
    if re.match('^6\.1', network.module.get_distribution_version()):
        route_path = None
    # aix7.2 route does not work correctly
    if re.match('^7\.2', network.module.get_distribution_version()):
        route_path = None

    if netstat_path:
        if route_path:
            assert network.get_default_interfaces(route_path)

# Generated at 2022-06-22 23:39:38.878013
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = importlib.import_module('ansible.module_utils.facts.network.aix.network')
    ifconfig_test_input = "en0: flags=e10003<UP,BROADCAST,NOTRAILERS> mtu 1432"
    test_result = module.AIXNetwork.parse_interface_line(module.AIXNetwork, ifconfig_test_input.split())
    assert test_result['device'] == 'en0'
    assert test_result['macaddress'] == 'unknown'
    assert test_result['flags'] == ['e10003']
    assert 'mtu' not in test_result

# Generated at 2022-06-22 23:39:40.445294
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:39:41.268123
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    assert AIXNetwork().platform == 'AIX'

# Generated at 2022-06-22 23:39:44.529952
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network_module = AIXNetwork(module=module)
    assert network_module.get_default_interfaces('test') == ({}, {})

# Generated at 2022-06-22 23:39:48.624454
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Test case #1 of valid AIXNetwork
    aix_network = AIXNetwork()
    assert isinstance(aix_network, AIXNetwork)
    assert aix_network.platform == 'AIX'



# Generated at 2022-06-22 23:39:59.804915
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_core_collector_network = NetworkCollector()
    module_core_collector_network._platform = 'AIX'
    module_core_collector_network.shared = True

    network_collector = module_core_collector_network._collector[0]

    ifconfig_path = 'i/do/not/exist'
    ifconfig_options = '-a'
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces.keys() == []

    ifconfig_path = './test_data/aix_ifconfig_a.txt'
    ifconfig_options = '-a'
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-22 23:40:01.040689
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(module=dict())).platform == 'AIX'

# Generated at 2022-06-22 23:40:13.181101
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # Unit test for method get_default_interfaces of class AIXNetwork
    # pylint: disable=too-few-public-methods
    class AIXNetworkModule:
        """
        This is a class to mock a module in the AnsibleModule.
        It is needed if you want to test with AnsibleModule methods
        like get_bin_path or run_command.
        """
        def __init__(self):
            self.params = None

        def get_bin_path(self, cmd, required=False):
            """
            Return full path to a command, used by AIXNetwork.
            """
            if cmd == 'netstat':
                return cmd

            return None


# Generated at 2022-06-22 23:40:21.176278
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    aixnet = AIXNetwork()

    # Normal device
    words = ['en0:', 'flags=842<BROADCAST,RUNNING,MULTICAST>']
    current_if = aixnet.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

    # Name of device with a digit at its end
    words = ['en0b1:', 'flags=842<BROADCAST,RUNNING,MULTICAST>']
    current_if = aixnet.parse_interface_line(words)

# Generated at 2022-06-22 23:40:27.874378
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:38.669924
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:41.051116
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_class = AIXNetwork()
    test_class.module = AnsibleModuleMock()
    test_interfaces, test_ips = test_class.get_interfaces_info('ifconfig')
    assert test_interfaces  is not None
    assert test_ips  is not None



# Generated at 2022-06-22 23:40:48.612124
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:52.945579
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Create an instance of AIXNetwork
    aix_network = AIXNetwork()

    # Test _platform variable
    assert aix_network._platform == 'AIX'

    # Test platform variable
    assert aix_network.platform == 'AIX'

# Generated at 2022-06-22 23:41:02.720598
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()
    interface_line = 'en0: flags=5e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = interface_line.split()
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '5e080863,c0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:41:14.853762
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:41:18.696496
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import collection
    from ansible.module_utils.facts.collector.network.aix import AIXNetworkCollector

    results = collection.collect(AIXNetworkCollector)
    assert 'device_type_facts' in results



# Generated at 2022-06-22 23:41:30.350714
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # AIX uname -W command output is known to be 0 in this case
    module = FakeAnsibleModule(
        {
            'platform': 'AIX',
            'run_command': FakeRunCommand({'uname -W': '0'})
        }
    )
    aix_network = AIXNetwork(module)

    ifconfig_options = '-a'
    ifconfig_path = '/usr/sbin/ifconfig'

    # Test get_interfaces_info()
    expected_interfaces, expected_ips = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)

    # remove all but three interfaces
    expected_interfaces.pop('lo0', None)
    expected_interfaces.pop('lo1', None)

# Generated at 2022-06-22 23:41:35.852415
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    method AIXNetwork.get_interfaces_info() parses output of /sbin/ifconfig -a
    '''

    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-22 23:41:48.371612
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    Test unit for class AIXNetwork constructor
    Test parsing 'ifconfig -a' with 0 (not in wpar) uname -W command.
    Test parsing 'ifconfig -a' with non-zero (in wpar) uname -W command.
    '''
    import os

    modules_path = os.path.dirname(os.path.realpath(__file__))

    aix_network = AIXNetwork(modules_path=modules_path)

    aix_network_interfaces, aix_network_ips = aix_network.get_interfaces_info(aix_network.module.get_bin_path('ifconfig'), ifconfig_options='-a')

    assert sorted(aix_network_interfaces.keys()) == [u'en0', u'en1']

# Generated at 2022-06-22 23:41:54.544543
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os

    class ModuleMock(object):

        def __init__(self, argument_spec, check_invalid_arguments=None,
                     bypass_checks=False, no_log=False,
                     run_command_environ_update=None):
            self.argument_spec = argument_spec
            self.params = dict()
            self.params['filter'] = ''
            self.params['gather_subset'] = []
            self.check_invalid_arguments = check_invalid_arguments
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.run_command_environ_update = run_command_environ_update


# Generated at 2022-06-22 23:41:56.834888
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    class_AIXNetwork = None
    class_AIXNetwork = AIXNetwork()
    assert class_AIXNetwork is not None


# Generated at 2022-06-22 23:42:08.483075
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()

    # test without words
    assert network.parse_interface_line([]) == {}

    # test with words
    words = ['en0:','flags=5008<RXPOLL,NOTE,LINK0,BROADCAST>','mtu','1500','index','8','range','10','priority','0']
    assert network.parse_interface_line(words) == {}

    words = ['en0:','flags=5008<RXPOLL,NOTE,LINK0,BROADCAST>']
    assert network.parse_interface_line(words) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': '5008<RXPOLL,NOTE,LINK0,BROADCAST>', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:42:16.570322
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = {}
    network = AIXNetwork({'gather_subset': '!all', 'gather_network_resources': ['all'], 'ansible_module_args': {'gather_subset': '!all', 'gather_network_resources': ['all']}}, facts, [])
    interfaces = network.get_interfaces_info(network.module.get_bin_path('ifconfig'), '-a')

    assert 'default' in interfaces[0]['lo0']['options']

    assert 'gateway' in network.get_default_interfaces('dummy')[0]
    assert 'interface' in network.get_default_interfaces('dummy')[0]

# Generated at 2022-06-22 23:42:24.652350
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    line = 'en0: flags=4163 mtu 1500'
    words = line.split()
    aixnet = AIXNetwork()
    current_if = aixnet.parse_interface_line(words)

    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '4163'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'


# Generated at 2022-06-22 23:42:30.515388
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ansible_module = MockAnsibleModule(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-au'
    )
    aix_network = AIXNetwork(ansible_module)
    assert aix_network.ifconfig_path == '/usr/sbin/ifconfig'
    assert aix_network.ifconfig_options == '-au'
    assert aix_network.platform == 'AIX'
    assert repr(aix_network) == '<aix_network.AIXNetwork object at 0x7fb1787e6790>'


# Generated at 2022-06-22 23:42:37.904359
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ifconfig_path = module.get_bin_path('ifconfig')
    network = AIXNetwork(module)

    words = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST>'.split()
    c_if = network.parse_interface_line(words)
    assert c_if['device'] == 'lo0'
    assert c_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert c_if['macaddress'] == 'unknown'



# Generated at 2022-06-22 23:42:49.739884
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'])})
    net.module.params = {
        'gather_subset': '!all',
    }
    net.route_path = '/test/path/netstat'

    net.get_default_interfaces = Mock(return_value=(
        {'gateway': '192.168.1.1', 'interface': 'en0'},
        {'gateway': 'fd00:1::1', 'interface': 'en1'}))

    result = net.populate()
    assert result['default_ipv4']['gateway'] == '192.168.1.1'
    assert result['default_ipv4']['interface'] == 'en0'

# Generated at 2022-06-22 23:42:57.145538
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_args = dict(route_path='/usr/sbin/netstat')
    net = AIXNetwork()
    returned_gateway = net.get_default_interfaces(**test_args)[0]['gateway']
    returned_interface = net.get_default_interfaces(**test_args)[0]['interface']
    assert returned_gateway == '10.20.30.1'
    assert returned_interface == 'en4'

# Generated at 2022-06-22 23:43:02.515613
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    current_if = {'v4': {'gateway': '192.168.1.1', 'interface': 'en0'}, 'v6': {'gateway': 'fe80::28f9:a7ff:fe91:18f7', 'interface': 'en0'}}
    route_path = ''
    ansible_network = AIXNetwork()
    assert current_if == ansible_network.get_default_interfaces(route_path)



# Generated at 2022-06-22 23:43:10.398046
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    b = AIXNetwork()
    d = {'v4': {'gateway': '10.0.0.254', 'interface': 'lo0'}, 'v6': {'gateway': '::', 'interface': 'lo0'}}
    assert b.get_default_interfaces('/bin/netstat') == (d['v4'], d['v6'])

# Generated at 2022-06-22 23:43:16.866980
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class TestModule:
        def __init__(self):
            self.params = None

        def get_bin_path(self, command):
            return command

        def run_command(self, command):
            return 0, "default 10.10.10.1 UG 0 0 en3\ndefault :: U 1 0 en3", ""

    module = TestModule()
    test_network = AIXNetwork()
    test_network.module = module
    result = test_network.get_default_interfaces('/sbin/route')
    assert result == {'interface': 'en3', 'gateway': '10.10.10.1'}

# Generated at 2022-06-22 23:43:29.245731
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    uname_path = '/usr/bin/uname'
    uname_out = '0 AIX'

    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()
    current_if = AIXNetwork().parse_interface_line(words)

# Generated at 2022-06-22 23:43:34.606349
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    tests = [(AIXNetworkCollector(dict(module=None, params=None)), AIXNetwork)]
    for test_data in tests:
        assert isinstance(test_data[0], AIXNetworkCollector)
        if hasattr(test_data[0], "_fact_class"):
            assert test_data[0]._fact_class == test_data[1]

# Generated at 2022-06-22 23:43:46.838583
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test_network_collector = AIXNetworkCollector()
    test_network_collector.module.run_command = lambda cmd: (0, '', '')

    test_network = test_network_collector.get_network_facts()
    test_network = test_network['ansible_network_resources']

    assert len(test_network) > 0

    test_network = test_network['interfaces']

    assert len(test_network) > 0

    for key in test_network:
        assert key == test_network[key]['device']
        assert test_network[key]['device'] == test_network[key]['device']
        assert test_network[key]['macaddress'] == 'unknown'
        assert test_network[key]['type'] == 'unknown'

# Generated at 2022-06-22 23:43:55.164244
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()

    net.netmask = {}
    net.netmask['192.168.0.1'] = '255.255.255.0'

    net.module = type('module', (), dict(run_command=run_command_test_AIXNetwork_get_default_interfaces))
    net.module.get_bin_path = lambda x: 'netstat_test'

    net.default_ipv4, net.default_ipv6 = net.get_default_interfaces('route_path')

    assert net.default_ipv4['gateway'] == '192.168.0.1'
    assert net.default_ipv4['interface'] == 'lo0'

    assert not net.default_ipv6


# Generated at 2022-06-22 23:44:05.641955
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    # Module must run with AIX facts collection context
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_timeout'] = 0

    # Set module.run_command() to be mocked
    module.run_command = mock.Mock(return_value= (0, 'default    172.20.44.1 UG        2        0 en0',''))

    # create dummy network collector instance
    network_collector = AIXNetworkCollector(module=module)

    # create dummy AIX network instance
    aix_network_class = AIXNetwork(module)

    # create dummy facts from the AIX network instance
    facts = dict()
    facts['default_ipv4'], facts['default_ipv6']

# Generated at 2022-06-22 23:44:07.342442
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    test = AIXNetworkCollector()
    assert test._fact_class == AIXNetwork
    assert test._platform == 'AIX'

# Generated at 2022-06-22 23:44:07.940106
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    AIXNetwork()

# Generated at 2022-06-22 23:44:15.250367
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:44:25.455531
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:30.427492
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test if AIXNetworkCollector instantiates properly"""
    import ansible.module_utils.facts.network.aix
    base_class_instantiation_check(ansible.module_utils.facts.network.aix.AIXNetworkCollector)



# Generated at 2022-06-22 23:44:39.872303
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # mock module
    module = AnsibleModuleMock()

    # Create mock object of class AIXNetwork
    aix_network = AIXNetwork(module)

    # create lines with response of ifconfig -a

# Generated at 2022-06-22 23:44:52.249594
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:45:02.943508
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = generic_bsd_module_mock()
    network_module = AIXNetwork(module)

    routetable_path_mock = ['/usr/sbin/netstat', '-nr']
    module.get_bin_path.return_value = '/usr/sbin/netstat'

# Generated at 2022-06-22 23:45:05.255441
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AIXNetwork()
    assert module.platform == 'AIX'


# Generated at 2022-06-22 23:45:16.892073
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test all parts of the get_interfaces_info method, except the parsing of the
    'options=' line, because that is tested with get_options().
    """
    m_mod = MagicMock()

    # Mock the 'get_bin_path()', 'run_command()' and 'is_ipv6_enabled()'
    # methods of the module 'm_mod'
    m_mod.get_bin_path.side_effect = lambda x: x
    m_run_command = m_mod.run_command
    m_mod.is_ipv6_enabled.return_value = False
    m_AIXNetwork = AIXNetwork(m_mod)

    # Mock the output of a 'ifconfig -a' command

# Generated at 2022-06-22 23:45:26.658355
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test get_interfaces_info"""
    #
    # unit test for AIXNetwork.get_interfaces_info method
    #

    #
    # unit test data
    #

    # ifconfig -a output for AIX 7.1 (AIX 7.1 does not have en1d1):