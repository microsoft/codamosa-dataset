

# Generated at 2022-06-22 23:35:30.508062
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value='/usr/bin/netstat')
    module.run_command.return_value = (0, 'default 127.0.0.1 UG 0 lo0\ndefault ::1 UG 0 lo0', '')

    aix_network = AIXNetwork(module)

    # run the method
    interface = aix_network.get_default_interfaces('/usr/bin/netstat')

    # assert that the interface v4 has the state 'gateway' and 'interface'
    assert interface[0]['gateway'] == '127.0.0.1'
    assert interface[0]['interface'] == 'lo0'

    # assert that the interface

# Generated at 2022-06-22 23:35:34.294515
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == "AIX"

# Generated at 2022-06-22 23:35:45.573390
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_netw = AIXNetwork(dict())
    assert aix_netw.parse_interface_line(['en0:', 'flags=1e080863,']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert aix_netw.parse_interface_line(['ent0:', 'flags=1e080863,']) == {'device': 'ent0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert aix_netw.parse_interface_line(['en1:', 'flags=80000303,']) == {'device': 'en1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert aix_netw

# Generated at 2022-06-22 23:35:47.323795
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Test the AIXNetworkClass constructor
    """
    m_open = None
    m_platform = None
    m_module = None
    aixnet = AIXNetwork(m_open, m_platform, m_module)



# Generated at 2022-06-22 23:35:57.192465
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test the AIXNetwork class."""

    # pylint: disable=protected-access, unused-argument
    aix_network = AIXNetwork(None)

    # fake_parse_interface_line is used to test the AIXNetwork parse_interface_line method
    def fake_parse_interface_line(words):
        return {'device': words[0][0:-1], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # fake_parse_options_line is used to test the AIXNetwork parse_options_line method
    def fake_parse_options_line(words, current_if, ips):
        return ips

    # fake_parse_nd6_line is used to test the AIXNetwork parse_nd6_line method

# Generated at 2022-06-22 23:36:03.414855
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )
    test_obj = AIXNetwork()
    test_obj.module = test_module
    test_obj.get_default_interfaces(None)
    assert True



# Generated at 2022-06-22 23:36:04.833441
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class == AIXNetwork

# unit test for method AIXNetworkCollector.collect()

# Generated at 2022-06-22 23:36:06.517350
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be invoked without arguments
    """
    AIXNetworkCollector()

# Generated at 2022-06-22 23:36:08.243803
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.collect() == {}

# Generated at 2022-06-22 23:36:09.752599
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    aix_network = AIXNetwork()

    print(aix_network)

# Generated at 2022-06-22 23:36:17.179416
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import json
    import collections

    fixture = open(os.path.join(os.path.dirname(__file__), '../fixtures/aix_ifconfig_a.txt'), 'r').read()
    fixture_json = json.loads(fixture)
    fixture_json_odict = collections.OrderedDict(fixture_json)

    module = AnsibleModule(argument_spec={'gather_subset':dict(default='!all,!min'),'gather_network_resources':dict(required=False)})

    interfaces = {}

    ifconfig_path = module.get_bin_path('ifconfig')
    if_info, _ = AIXNetwork.get_interfaces_info(AIXNetwork(), ifconfig_path, ifconfig_options='-a')

    device_number = 0



# Generated at 2022-06-22 23:36:18.271920
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector


# Generated at 2022-06-22 23:36:22.558154
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    import module_utils.facts.network.aix as aix
    aix_network = aix.AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert aix_network._fact_class == 'AIXNetwork'
    assert aix_network.platform == 'AIX'

# Generated at 2022-06-22 23:36:25.112762
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    platform = aix_network.platform
    assert platform == 'AIX'
    assert isinstance(aix_network, GenericBsdIfconfigNetwork) is True


# Generated at 2022-06-22 23:36:32.592876
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = AIXNetwork()
    words = ['en0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'index', '1', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '10.117.0.255', 'nd6', 'options=1<PERFORMNUD>']
    res = m.parse_interface_line(words)
    assert res['device'] == 'en0'
    assert res['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert 'mtu' not in res
    assert res['macaddress'] == 'unknown'
    assert res['ipv4'] == []
    assert res

# Generated at 2022-06-22 23:36:43.318948
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE), CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>'.split()
    r = AIXNetwork()
    dev = r.parse_interface_line(words)

# Generated at 2022-06-22 23:36:44.832803
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:36:48.022922
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert aix_network_collector.platform == 'AIX'

# Generated at 2022-06-22 23:36:53.994015
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec={})
    ifc = AIXNetwork(mod)
    mod.exit_json(**{'ansible_facts': {'ansible_network_resources': ifc.get_facts()}})


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:37:00.450948
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    class_ = AIXNetwork
    ifconfig_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = ifconfig_line.split()
    current_if = class_.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == '2001000849'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert current_if['mtu'] == '8232'

# Generated at 2022-06-22 23:37:05.317667
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # mocked input to method get_interfaces_info
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-22 23:37:07.830127
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test for constructor of class AIXNetworkCollector."""
    assert AIXNetworkCollector.__name__ == 'AIXNetworkCollector'
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-22 23:37:19.282551
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """The method parse_interface_line of AIXNetwork was tested.
    """
    AIXNetwork = AIXNetwork()
    words = ['en0:', 'flags=1e080863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '10.10.10.10', 'netmask', '0xffffff00', 'broadcast', '10.10.10.255']

# Generated at 2022-06-22 23:37:22.586467
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    result = aix_network.get_default_interfaces('/etc/netstat')
    expected = {'default': {'gateway': '192.168.122.1', 'interface': 'en0'},
                'default6': {'gateway': 'fe80::8', 'interface': 'en0'}}

    assert expected == result

# Generated at 2022-06-22 23:37:32.570620
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network = AIXNetwork()

    fd = open('test_AIXNetwork_get_interfaces_info.txt', 'r')
    lines = fd.read()
    fd.close()

    rc = 0
    err = ''
    out = lines

    for line in out.splitlines():

        if line:
            words = line.split()

            if re.match(r'^\w*\d*:', line):
                current_if = network.parse_interface_line(words)

# Generated at 2022-06-22 23:37:37.714042
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_net = AIXNetwork(None)
    assert aix_net.get_interfaces_info.__name__ == 'get_interfaces_info'
    assert aix_net.get_default_interfaces.__name__ == 'get_default_interfaces'
    assert aix_net.parse_interface_line.__name__ == 'parse_interface_line'

# Generated at 2022-06-22 23:37:44.552077
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = NetworkCollector()
    test_class = AIXNetwork()
    test_class.module = test_module
    test_int_dict, test_ip_dict = test_class.get_interfaces_info('/usr/sbin/ifconfig')
    assert type(test_int_dict) == dict
    assert type(test_ip_dict) == dict
    assert 'en0' in test_int_dict
    assert 'en1' in test_int_dict
    assert len(test_int_dict) == 2
    assert len(test_int_dict['en0']['ipv4']) == 2
    assert len(test_int_dict['en0']['ipv6']) == 1
    assert len(test_int_dict['en1']['ipv4']) == 0


# Generated at 2022-06-22 23:37:55.551508
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_AIXNetwork = AIXNetwork()
    # test_if is current_if in AIXNetwork.parse_interface_line
    test_if = {}

    # test for line, 'en0: flags=4E084863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    # it is inside AIXNetwork.get_interfaces_info
    words = 'en0: flags=4E084863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'.split()
    test_if = test_AIXNetwork.parse_

# Generated at 2022-06-22 23:37:58.252765
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:38:03.677808
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ipv4_default, ipv6_default = AIXNetwork(module).get_default_interfaces('')
    assert isinstance(ipv4_default, dict)
    assert isinstance(ipv6_default, dict)



# Generated at 2022-06-22 23:38:10.369366
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

    class Test_module:
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return (0, '', '')

    test_module = Test_module()


# Generated at 2022-06-22 23:38:18.470466
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    interfaces, ipv4, ipv6, vlan, bond = AIXNetwork.collect(None, None)
    #print("interfaces=", interfaces)
    #print("ipv4=", ipv4)
    #print("ipv6=", ipv6)
    #print("vlan=", vlan)
    #print("bond=", bond)
    assert interfaces is not None
    assert ipv4 is not None
    assert ipv6 is not None
    assert vlan is not None
    assert bond is not None

if __name__ == '__main__':
    test_AIXNetwork()

# Generated at 2022-06-22 23:38:21.796177
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_facts = AIXNetworkCollector()
    assert net_facts.platform == 'AIX'
    assert len(net_facts.collected_facts) == 0


# Generated at 2022-06-22 23:38:25.353567
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aixnetwork = AIXNetwork()
    aixnetwork.get_default_interfaces('/sbin/route')
    return aixnetwork


# Generated at 2022-06-22 23:38:35.802400
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix = AIXNetwork()
    words = ['en0:', 'flags=1e080863,']
    current_if = aix.parse_interface_line(words)
    assert current_if == {
        'device': 'en0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
        'flags': [
            'UP',
            'BROADCAST',
            'NOTRAILERS',
            'RUNNING',
            'SIMPLEX',
            'MULTICAST',
            'GROUPRT',
            '64BIT',
            'CHECKSUM_OFFLOAD',
            'LARGESEND',
            'CHAIN',
            'AUTO_MTU',
            ]
        }


# Generated at 2022-06-22 23:38:42.750534
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module_mock = MockModule()
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    ifconfig_rc, ifconfig_out, ifconfig_err = module_mock.run_command([ifconfig_path, ifconfig_options])
    interfaces_info = AIXNetwork.get_interfaces_info(module_mock, ifconfig_path, ifconfig_options)
    return True if interfaces_info else False

# Generated at 2022-06-22 23:38:50.670974
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=mod)
    network_collector.get_facts()
    facts = network_collector.get_facts()
    expected_result = dict(
        name='en0',
        device='en0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        flags=dict(broadcast='', inet='', pointopoint=''),
        macaddress='unknown',
    )
    assert facts['interfaces']['en0'] == expected_result


# Generated at 2022-06-22 23:39:02.432946
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    test_module = AnsibleModule(
        argument_spec=dict(
            route_path=dict(type='str', required=True)
        ),
        supports_check_mode=False
    )

    if test_module.params['route_path'] == 'route.good':
        # Sample output of command 'netstat -nr' in AIX
        netstat_out = '''
        default            192.168.122.1     UG        0 0          en0
        default            ::1               UG        0 0          lo0
        default            fe80::2f0e:c4ff:fe0b:1fec UG        0 0          en0
        '''

# Generated at 2022-06-22 23:39:09.338294
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = type('module', (object,), {})

# Generated at 2022-06-22 23:39:17.426791
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = AIXNetwork({})
    line0 = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 65536'
    line1 = 'en0: flags=8963<UP,BROADCAST,NOTRAILERS,PROMISC,SIMPLEX,MULTICAST> mtu 1500'
    line2 = 'ent1: flags=80d0<BROADCAST,NOTRAILERS,MULTICAST,CONNFAILED> mtu 1500'

    res0 = m.parse_interface_line(line0.split())
    res1 = m.parse_interface_line(line1.split())
    res2 = m.parse_interface_line(line2.split())

    assert res0['device'] == 'lo0'

# Generated at 2022-06-22 23:39:23.732279
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible_collections.notmintest.not_a_real_collection.plugins.mock.init import create_filesystem_structure_for_platform

    create_filesystem_structure_for_platform('AIX')
    host = NetworkCollector()
    host.get_facts()
    assert host.get_all_facts().get('interfaces')

# Generated at 2022-06-22 23:39:32.487123
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mac_addr = 'unknown'
    test1_words = list(['en0', 'UP', 'BROADCAST', 'MULTICAST', 'MTU', '1500', 'metric', '1', 'RX', 'packets:0', 'errors:0', 'dropped:0', 'overruns:0', 'frame:0', 'TX', 'packets:0', 'errors:0', 'dropped:0', 'overruns:0', 'carrier:0', 'collisions:0', 'txqueuelen:1000', 'RX', 'bytes:0', '(0.0', 'B)', 'TX', 'bytes:0', '(0.0', 'B)', 'interrupt:18', 'memory:90000000-9001ffff', 'memory:a0000000-a00fffff'])
    current_if = AIXNetwork

# Generated at 2022-06-22 23:39:39.349050
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for constructor of class AIXNetworkCollector
    """
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    collector = AIXNetworkCollector()
    assert isinstance(collector, NetworkCollector)
    assert isinstance(collector._fact_class, GenericBsdIfconfigNetwork)
    assert collector._platform == 'AIX'


# Generated at 2022-06-22 23:39:44.139344
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    facts = AIXNetwork()
    words = ['en0:', 'flags=1e080863,480]', 'mtu', '1500', 'index', '7']
    current_if = facts.parse_interface_line(words)
    assert current_if == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'flags': '1e080863', 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:39:46.306183
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:39:53.939520
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    an = AIXNetwork(module)

    interfaces = an.get_default_interfaces("/sbin/route")
    assert interfaces[0]['interface'] == 'en0'
    assert interfaces[0]['gateway'] == '172.16.1.1'
    assert interfaces[1]['interface'] == 'en0'
    assert interfaces[1]['gateway'] == 'fe80::2c0:4dff:fe1b:e66e'



# Generated at 2022-06-22 23:40:04.872281
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:06.214040
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(dict(module=dict()))

# Generated at 2022-06-22 23:40:09.945459
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    result = AIXNetworkCollector()
    assert result.__class__.__name__ == 'AIXNetworkCollector'
    assert result._fact_class.__name__ == 'AIXNetwork'
    assert result._platform == 'AIX'

# Generated at 2022-06-22 23:40:20.369981
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    aixnetwork = AIXNetwork(ansible_module)
    aixnetwork.get_interfaces_info('ifconfig')
    device = 'en0'
    line = 'en0: flags=5e080863,0100cc14,c0a80001,cc140000,c0a80001,0100c0a8,c0a80001,c0a80001 mtu 1500 index 1'
    words = line.split()
    result = aixnetwork.parse_interface_line(words)

# Generated at 2022-06-22 23:40:27.363493
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    import os
    import subprocess
    import difflib
    f, fn = tempfile.mkstemp()

    # default_text is the expected text when no option is passed
    # to get_interfaces_info()
    default_text = subprocess.check_output([os.path.join(os.path.dirname(__file__), 'get_interfaces_info.default.txt')])

    # options_text is the expected text when options=['-a'] is passed
    # to get_interfaces_info()
    options_text = subprocess.check_output([os.path.join(os.path.dirname(__file__), 'get_interfaces_info.options.txt')])

    network = AIXNetwork()


# Generated at 2022-06-22 23:40:33.993432
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork({})
    interface = aix_network.parse_interface_line(['en0:'])
    assert interface['device'] == 'en0'
    assert type(interface['flags']) is list
    assert interface['macaddress'] == 'unknown'
    assert interface['mtu'] == 1500
    assert interface['type'] == 'unknown'

# Generated at 2022-06-22 23:40:44.142139
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = MockModule()
    path = module.get_bin_path('ifconfig')
    if path:
        test = AIXNetwork(module)
        #
        # get_interfaces_info parameters are:
        # ifconfig_path - where ifconfig command is,
        # ifconfig_options - options for ifconfig command,
        #
        # Note: The change of the current directory to "/" is because
        # the AIX ifconfig does not work under the /tmp directory.
        #
        test.module.run_command.cwd = '/'
        test.module.run_command.return_value = 0, '', ''
        test.module.run_command.commands = [path + ' -a']
        (interfaces, ips) = test.get_interfaces_info(path, '-a')

       

# Generated at 2022-06-22 23:40:53.758622
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'params': dict(gather_subset='min'),
    })

    # Create a mock module object
    setattr(module, 'run_command', lambda *args, **kwargs:
            ([0, '', ''] if args == (['ls', '-t'],) or args == (['ls', '-t', '--sort=time'],) else
             [0, 'default 0.0.0.0 UG 0 0 en0', 'default ::1 UG 0 0 lo0']))

    # Create a mock ansible module object
    setattr(module, 'get_bin_path', lambda *args: '/usr/bin/ls')


# Generated at 2022-06-22 23:40:58.772596
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Unit test for constructor of class AIXNetwork."""
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork

    an = AIXNetwork()
    assert an.__class__.__name__ == 'AIXNetwork'


# Generated at 2022-06-22 23:41:10.341883
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    # words is list of strings from 'ifconfig -a':
    #   ['lo0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    words = ['lo0:',
             'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']


# Generated at 2022-06-22 23:41:20.327713
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Construct the object
    try:
        obj = AIXNetwork()
    except Exception:
        assert False, "Construction of AIXNetwork failed"

    # Test the platform property
    assert obj.platform == 'AIX', "AIXNetwork platform property failed"

    # Test the get_default_interfaces method
    v4_if, v6_if = obj.get_default_interfaces("path")
    if v4_if:
        assert v4_if['gateway']
        assert v4_if['interface']
    else:
        assert v4_if == {}

    if v6_if:
        assert v6_if['gateway']
        assert v6_if['interface']
    else:
        assert v6_if == {}

    # Test the parse_interface_line method

# Generated at 2022-06-22 23:41:25.092651
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix.aix import AIXNetworkCollector
    collector = AIXNetworkCollector()
    result = collector.get_facts()
    assert 'ansible_net_interfaces' in result


# Generated at 2022-06-22 23:41:30.259685
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import TestGenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import TestNetworkCollector
    from importlib import import_module
    from tempfile import NamedTemporaryFile

    fixture_file = 'ansible_test_aix.txt'
    fixture_path = 'fixtures/network/%s' % fixture_file

    with NamedTemporaryFile() as fixture_handle:
        with open(fixture_path, 'r') as fixture_data:
            fixture_handle.write(fixture_data.read().encode('utf-8'))
            fixture_handle.flush()

            TestNetworkCollector.add_network_data(fixture_file, fixture_path)
            TestGenericBsdIfconfigNetwork.add_network_data

# Generated at 2022-06-22 23:41:38.381611
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    mod_args = dict()
    mod_args['path'] = dict()
    mod_args['path']['ifconfig'] = '/usr/sbin/ifconfig'
    module = AnsibleModule(argument_spec=mod_args, supports_check_mode=False)
    aixnet = AIXNetwork(module=module)

# Generated at 2022-06-22 23:41:40.541005
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    facts = dict()
    ansible_module = MockAnsibleModule()
    aix_network = AIXNetwork(ansible_module)

    aix_network.populate()

    assert 'default_ipv4' in facts
    assert 'default_ipv6' in facts



# Generated at 2022-06-22 23:41:50.254755
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = AnsibleModule(argument_spec={})
    nc = AIXNetwork(module=test_module)

# Generated at 2022-06-22 23:41:52.389947
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'

# Generated at 2022-06-22 23:42:03.795463
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    # class AIXNetwork inherits from GenericBsdIfconfigNetwork and we need to test it
    class test_GenericBSDIfconfigNetwork_interface(GenericBsdIfconfigNetwork):
        platform = 'GenericBSDIfconfigNetwork'

        def parse_interface_line(self, words):
            device = words[0][0:-1]
            current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
            current_if['flags'] = self.get_options(words[1])

# Generated at 2022-06-22 23:42:15.012940
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = None
    test_object = AIXNetwork(module)

    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    current_if = test_object.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['type'] == 'unknown'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN']
    assert current

# Generated at 2022-06-22 23:42:24.958315
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    # test_module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['*'], type='list')))
    test_module.params['gather_subset'] = ['!all']
    test_instance = AIXNetwork(test_module)
    test_out = test_instance.get_default_interfaces('netstat path')
    print(test_out)
    assert True



# Generated at 2022-06-22 23:42:32.191141
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    interfaces = AIXNetwork()

    out1 = ("""
    AIX eth01 1 7 00004C761234
    Internet Address Physical Address Type
    192.168.1.2 00-04-C7-6B-12-34 dynamic
    default 192.168.1.1 - local
    """)

    out2 = ("""
    AIX eth01 1 7 00004C761234
    Internet Address Physical Address Type
    ::ffff:192.168.1.2 00-04-C7-6B-12-34 dynamic
    default ::ffff:192.168.1.1 - local
    """)


# Generated at 2022-06-22 23:42:43.968259
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.test_facts.test_network import AIXIfconfigNetwork
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.test_facts.test_network import AIXIfconfigOptionsNetwork
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.test_facts.test_network import AIXIfconfigDhcpNetwork
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.test_facts.test_network import AIXIfconfigLinkNetwork
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.test_facts.test_network import AIXIfconfigOptionsDhcpNetwork


# Generated at 2022-06-22 23:42:55.768329
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['min'], type='list')})
    module.run_command = Mock(return_value=(0, '', ''))
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'

    # all lines of ifconfig -a are not needed
    # show only the lines needed by the method

# Generated at 2022-06-22 23:43:03.940800
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_AIXNetwork = AIXNetwork()

    words = ['lo0:', 'flags=100000000<UP,LOOPBACK,']
    result = {
        'device'    : 'lo0',
        'ipv4'      : [],
        'ipv6'      : [],
        'type'      : 'unknown',
        'flags'     : ['UP', 'LOOPBACK'],
        'macaddress': 'unknown'    # will be overwritten later
    }
    assert(result == test_AIXNetwork.parse_interface_line(words))


# Generated at 2022-06-22 23:43:10.541191
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.__name__ is "AIXNetworkCollector"
    assert AIXNetworkCollector.__doc__ is None
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform is "AIX"

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-22 23:43:18.083116
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class AIXNetwork
    """

    import sys
    import json
    import oci_utils

    # load JSON test data
    with open('test/facts/test_AIX_Network_data.json') as f:
        aix_network_data = json.load(f)

    # run get_interfaces_info()
    aix_network_obj = AIXNetwork()
    test_interfaces, test_ips = aix_network_obj.get_interfaces_info(
        ifconfig_path=aix_network_data['ifconfig_path'],
        ifconfig_options=aix_network_data['ifconfig_options']
    )

    # Compare the result from get_interfaces_info() with the test data
    assert test_interfaces == aix

# Generated at 2022-06-22 23:43:22.529067
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Check for the constructor.
    """
    aix_network = AIXNetworkCollector()
    assert aix_network.platform == 'AIX'
    assert aix_network.fact_class == AIXNetwork

# Generated at 2022-06-22 23:43:27.299155
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network_facts = AIXNetwork()
    assert aix_network_facts.platform == 'AIX'
    assert aix_network_facts.facts['all_ipv4_addresses'] == []
    assert aix_network_facts.facts['all_ipv6_addresses'] == []


# Generated at 2022-06-22 23:43:39.007415
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    device_line = 'en0             1'
    device_words = device_line.split()

    ifconfig_line = 'inet 192.168.122.145 netmask 0xfffff800 broadcast 192.168.123.255'
    ifconfig_words = ifconfig_line.split()

    options_line = 'options=9b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>'
    options_words = options_line.split()

    nd6_line = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'
    nd6_words = nd6_line.split()

    ether_line = 'ether 08:00:27:b7:e2:97'


# Generated at 2022-06-22 23:43:44.046764
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    a = AIXNetwork()
    out = a.get_interfaces_info('/usr/sbin/ifconfig', '-a')
    for i in out[0].keys():
        print(i)
    for i in out[1].keys():
        print(i)


# Generated at 2022-06-22 23:43:54.320289
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    test_path = 'tests/unit/utils/facts/network/test_data/aix_network_collector'
    test_module.exit_json = lambda **kwargs: kwargs
    test_module.run_command = lambda *args, **kwargs: (0, '', '')

    for files in (
        'ifconfig_a',
        'netstat_nr',
        'entstat',
        'lsattr_ent0',
        'uname_a'
    ):
        file_path = os.path.join(test_path, files)
        test_module.run_command = lambda *args, **kwargs: (0, open(file_path).read(), '')

# Generated at 2022-06-22 23:43:58.555505
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    AIXNetwork - constructor test.
    """

    # set up object
    aix_obj = AIXNetwork({}, {}, {}, {})

    # check attribute values
    assert aix_obj.platform == 'AIX'

# Generated at 2022-06-22 23:44:04.627815
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    w = ['en0:', 'flags=1e080863,']
    iface = AIXNetwork({}).parse_interface_line(w)
    assert iface['device'] == 'en0'
    assert iface['flags'] == ['broadcast', 'multicast', 'up', 'running']
    assert iface['macaddress'] == 'unknown'
    assert iface['ipv6'] == []
    assert iface['ipv4'] == []
    assert iface['type'] == 'unknown'

# Generated at 2022-06-22 23:44:13.545027
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    hostname_rc = None
    hostname_out = None
    hostname_err = None
    hostname_path = '/usr/bin/hostname'
    uname_rc = None
    uname_out = None
    uname_err = None
    uname_path = '/usr/bin/uname'
    who_rc = None
    who_out = None
    who_err = None
    who_path = '/usr/bin/who'

# Generated at 2022-06-22 23:44:24.911991
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    aix_network = AIXNetwork()

    # en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
    words = line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'.split()
    current_if = aix_network.parse

# Generated at 2022-06-22 23:44:33.264177
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Prepare a testcase
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    ifconfig_path = collector.get_file_content('/usr/sbin/ifconfig', module)
    network_collector = AIXNetwork(module=module, ifconfig_path=ifconfig_path)

    assert network_collector.platform == 'AIX'


# Generated at 2022-06-22 23:44:41.231038
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    aix_network_test = AIXNetwork()

    interfaces, ips = aix_network_test.get_interfaces_info('/bin/ifconfig -a')

    assert interfaces['lo0']['type'] == 'Loopback', 'AIXNetwork.get_interfaces_info does not work'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1', 'AIXNetwork.get_interfaces_info does not work'
    assert interfaces['en0']['type'] == 'ether', 'AIXNetwork.get_interfaces_info does not work'
    assert interfaces['en0']['ipv4'][0]['broadcast'] == '192.168.x.x', 'AIXNetwork.get_interfaces_info does not work'
    assert interfaces

# Generated at 2022-06-22 23:44:53.254601
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class TestAIXNetwork(AIXNetwork):
        def __init__(self):
            self.module = AnsibleModule(
                argument_spec=dict(),
                supports_check_mode=True
            )

    test_network = TestAIXNetwork()
    test_network.module.run_command = run_command_mockup
    test_network.module.get_bin_path = get_bin_path_mockup

    # method get_interfaces_info must return a tuple of two dicts.
    # The first dict contains all the interfaces info,
    # the second dict contains info about all the IP addresses
    interfaces, ips = test_network.get_interfaces_info('ifconfig', '-a')

    assert_interfaces_correct(interfaces)
    assert_ips_correct(ips)

    # test for

# Generated at 2022-06-22 23:45:03.692064
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {})()
    module.run_command = type('', (), {})()

    aixnet = AIXNetwork(module)

    module.run_command.return_value = 0, 'default 127.0.0.1 UG 0 0 en0\
        10.1.1.0/24 10.1.1.1 UG 0 0 en1\
        default fe80::a%1 UG 0 0 en0\
        default fe80::a%2 UG 0 0 en1\
        default ::1 UG 0 0 lo0', ''

# Generated at 2022-06-22 23:45:15.928526
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    words = ['en0:',
             'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    interface = test_object.parse_interface_line(words)
    assert interface == {'device': 'en0', 'type': 'unknown', 'ipv4': [], 'ipv6': [], 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN'], 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:45:22.033151
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ifconfig_path = module.get_bin_path('ifconfig')
    network_collector = AIXNetworkCollector(module=module)

    network = network_collector.collect(
        ifconfig_path=ifconfig_path,
        route_path='/bin/netstat',
        pager_path='/bin/more'
    )

    result = module.exit_json(ansible_facts=dict(network=network))
    return result


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()