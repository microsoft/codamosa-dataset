

# Generated at 2022-06-22 23:35:28.513590
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    current_if = dict(ipv4=[], ipv6=[], type='unknown')
    words = ['en0:', 'flags=8', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'options=180',
             '<RXCSUM,TXCSUM,VLAN_MTU,TSO4,TSO6,LRO>', 'inet', '10.0.2.15', 'netmask', '0xffffff00', 'broadcast', '10.0.2.255']
    aix_network = AIXNetwork()
    current_if = aix_network.parse_interface_line(words)

    assert current_if['device'] == 'en0'
    assert current_if['flags'] == '8'


# Generated at 2022-06-22 23:35:35.880432
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, "default 192.168.178.1 UG 0 0 en0 \n"
                                               "default 192.168.50.1 UG 0 0 en0 \n"
                                               "default 2001:db8:aaaa:bbbb:cccc::1 UG 0 0 en1 \n"
                                               "default 2001:db8:aaaa:bbbb:cccc::2 UG 0 0 en1 \n"
                                               "169.254 link#7 UCS 0 0 en0 \n"
                                               "2001:db8:aaaa:bbbb:cccc::/64 link#2 UCS 3 0 en1 \n",
                                               '')

# Generated at 2022-06-22 23:35:46.388824
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    test_module = type('test_module', (object,), dict(
        run_command=lambda self, cmd: (
            0, '', ''
        )
    ))

    test_platform = 'AIX'
    test_path = '/usr/sbin/ifconfig'
    test_opt = '-a'

    test_network_object = AIXNetwork(test_module)

    test_interfaces, test_addresses = test_network_object.get_interfaces_info(test_path, test_opt)

    assert test_interfaces == {}
    assert test_addresses == dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )


# Generated at 2022-06-22 23:35:48.650118
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:35:57.993006
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class MockModule(object):
        def __init__(self):
            self.params = {'route': {'path': '/sbin/route'}}
        def get_bin_path(self, name, required=False):
            return '/usr/bin/' + name
        def run_command(self, args, check_rc=True, close_fds=None, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
            if data:
                return '', data, ''
            else:
                retval = '0', 'default 0.0.0.0 UG 1 0 en0', '0'
                return retval

    m = MockModule()
    aix = AI

# Generated at 2022-06-22 23:36:09.878902
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:36:16.590724
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hostvars = dict()

    aix_network_collector = AIXNetworkCollector(module=module, hostvars=hostvars)
    aix_network = aix_network_collector.collect()[0]

    # run method get_default_interfaces
    v4_facts, v6_facts = aix_network.get_default_interfaces(route_path=None)

    assert v4_facts['gateway'] == '10.0.0.1'
    assert v4_facts['interface'] == 'en0'

    assert v6_facts['gateway'] == 'fe80::2'
    assert v6_facts['interface'] == 'ent0'



# Generated at 2022-06-22 23:36:26.246872
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:36:37.408728
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector(dict(), dict()).collect()
    keys = ['interfaces', 'default_ipv4', 'default_ipv6']
    added_keys = facts.keys()
    for key in keys:
        assert key in added_keys
    assert isinstance(facts['interfaces'], dict)
    assert isinstance(facts['default_ipv4'], dict)
    assert isinstance(facts['default_ipv6'], dict)
    assert 'gateway' in list(facts['default_ipv4'].keys())
    assert 'interface' in list(facts['default_ipv4'].keys())
    assert 'gateway' in list(facts['default_ipv6'].keys())
    assert 'interface' in list(facts['default_ipv6'].keys())


# Generated at 2022-06-22 23:36:39.874826
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-22 23:36:47.237270
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
        test_object = AIXNetwork()
        test_args = list()
        test_args.extend(['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ffffff00'])
        test_result = test_object.parse_interface_line(test_args)
        assert test_result['device'] == 'lo0'
        assert test_result['flags'] == {'UP': None, 'LOOPBACK': None, 'RUNNING': None, 'MULTICAST': None}
        assert 'mtu' not in test_result
        assert test_result['macaddress'] == 'unknown'



# Generated at 2022-06-22 23:36:54.963625
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Create an instance of AIXNetworkCollector"""

    # Constructor AIXNetworkCollector() should create an object with
    # all fields set to defaults
    o = AIXNetworkCollector()

    # Each field should have a default value
    assert o.name == 'network'
    assert o.options == None
    assert o.facts == {}
    assert o.gather_subset == ['!all', '!min']
    assert o.gather_network_resources == ['all']
    assert o.check_conditions == 'network'
    assert o.cache == {}

# Generated at 2022-06-22 23:37:05.962845
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.facts.network.aix import AIXNetwork

    rc = 0

# Generated at 2022-06-22 23:37:13.119055
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = get_module_mock()
    net = AIXNetwork(module)

    result = net.get_default_interfaces(None)
    assert result == {'v4': {'gateway': '10.10.10.254', 'interface': 'en3'},
                      'v6': {'gateway': 'fe80::a00:27ff:fe5c:9b9c%2', 'interface': 'en2'}}


# Generated at 2022-06-22 23:37:20.410035
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = get_module_mock()
    module.run_command.return_value = (0, "default 10.65.199.1 UG 0 0 - en0", "")
    network_facts = AIXNetwork(module=module)

    v4default, v6default = network_facts.get_default_interfaces('netstat')

    assert v4default == {'gateway': '10.65.199.1', 'interface': 'en0'}
    assert v6default == {}

# Generated at 2022-06-22 23:37:31.023606
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector()
    network = AIXNetwork(module=module)

    # this test will not work on AIX:
    # ifconfig_path = network.module.get_bin_path('ifconfig')

    route_path = network.module.get_bin_path('route')
    assert route_path

    interfaces = network.get_default_interfaces(route_path)

    assert isinstance(interfaces, dict)
    assert 'v4' in interfaces
    assert isinstance(interfaces['v4'], dict)
    assert 'gateway' in interfaces['v4']
    assert isinstance(interfaces['v4']['gateway'], str)
    assert 'interface' in interfaces['v4']
    assert isinstance(interfaces['v4']['interface'], str)


# Generated at 2022-06-22 23:37:41.501982
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class Module(object):
        def __init__(self):
            self._result = dict(
                ansible_facts=dict(network=dict(interfaces=dict(), default_ipv4=dict(), default_ipv6=dict())),
                ansible_module_calls=[]
            )
            self.run_command = self._run_command

        def _run_command(self, command):
            self._result['ansible_module_calls'].append(command)
            if command[0] == 'uname':
                return (0, '0', '')
            elif command[0] == 'entstat':
                return (0, 'Hardware Address: 11:22:33:44:55:66', '')

# Generated at 2022-06-22 23:37:50.695237
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork({'system': "", 'path': "", 'module_utils': ""})
    (expected_interface_v4, expected_interface_v6) = net.get_default_interfaces('/usr/sbin/route')
    assert expected_interface_v4['interface'] == 'en0'
    assert expected_interface_v4['gateway'] == '10.10.10.1'
    assert expected_interface_v6['interface'] == 'lo0'
    assert expected_interface_v6['gateway'] == 'fe80::1'

# Generated at 2022-06-22 23:37:54.450603
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])

    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if re.match(r'^\w*\d*:', line):
            current_if = aix_network.parse_interface_line(words)
            break
    assert current_if['device'] == 'ent1'
    assert current_if['flags'] == 'UP'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'



# Generated at 2022-06-22 23:38:05.302107
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # To make it easier to test without a module, we mock a module object
    # this is not needed in a normal execution of a module
    class MockModule:
        def get_bin_path(self, executable, required=True):
            return "/usr/bin/%s" % (executable)


# Generated at 2022-06-22 23:38:11.357565
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.aix import AIXNetwork

    class TestAIXNetwork(AIXNetwork):
        def __init__(self, module):
            self.module = module
            self.interfaces = {}
            self.addresses = {}
            self.default_interface = {'v4': {}, 'v6': {}}

        def get_default_interfaces(self, route_path):
            return {}, {}


# Generated at 2022-06-22 23:38:13.730530
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Unit test for class AIXNetworkCollector.
    """

    assert not AIXNetworkCollector.__dict__['_platform']

# Generated at 2022-06-22 23:38:22.134157
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # init data
    platform = 'AIX'
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    # init AIXNetwork instance
    network = AIXNetwork(None)
    # execute get_interfaces_info method
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    # check if result is not empty
    assert interfaces
    assert ips
    # check all interfaces
    for interface in interfaces.values():
        # check if interface has device and type
        assert 'device' in interface
        assert 'type' in interface
        # check device name
        assert re.match(r'^\w*\d*$', interface['device'])
        # check if interface has ipv4 and ipv6 addresses
       

# Generated at 2022-06-22 23:38:25.924515
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._platform == 'AIX'
    assert network_collector._fact_class.platform == 'AIX'


# Generated at 2022-06-22 23:38:28.848587
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    netinfo = AIXNetworkCollector(None)
    assert netinfo.platform == 'AIX'
    assert isinstance(netinfo._interface_facts, AIXNetwork)

# Generated at 2022-06-22 23:38:31.730819
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    assert AIXNetwork().get_default_interfaces('routepath')[0] == {'gateway': '172.16.212.2', 'interface': 'eth0'}


# Generated at 2022-06-22 23:38:34.313767
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:38:41.689815
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """ Test constructor of class AIXNetwork """

    module = AnsibleModule(argument_spec={})
    ip_dict = {}

    # create a pseudo ifconfig_path, so we can test it
    import tempfile
    tmpdir = tempfile.mkdtemp()

    from ansible.module_utils.facts.network.base import NetworkCollector
    ifconfig_path = os.path.join(tmpdir, 'ifconfig')
    NetworkCollector.ifconfig_path = ifconfig_path

    # create a pseudo file ifconfig_path

# Generated at 2022-06-22 23:38:52.259083
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    test = AIXNetwork({})

    # aix ifconfig output is different, will test only the AIX specific stuff
    words = 'df0: flags=df03d843<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 1500 index 1'.split()
    current_if = test.parse_interface_line(words)
    assert current_if['device'] == 'df0'
    assert 'UP' in current_if['flags']
    assert 'BROADCAST' in current_if['flags']
    assert 'NOTRAILERS' in current_if['flags']
    assert 'RUNNING' in current_if['flags']
    assert 'MULTICAST' in current_if['flags']
    assert 'IPv4' in current_if['flags']

# Generated at 2022-06-22 23:39:03.890053
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    input_words = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '32768', 'index', '1', 'groups', ':inet:4:inet:4:inet:4', 'options=3<RXCSUM,TXCSUM>']
    expected_current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': ['849<UP', 'LOOPBACK', 'RUNNING', 'MULTICAST>'],
        'macaddress': 'unknown',
        'mtu': '32768'
    }
    ans = AIXNetwork()

# Generated at 2022-06-22 23:39:13.373128
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class test():
        def get_bin_path(self, path):
            return '/usr/bin/' + path

    class test_module():
        def __init__(self):
            self.run_command = test_run_command
            self.get_bin_path = test.get_bin_path

    class test_network():
        def __init__(self):
            self.module = test_module()


# Generated at 2022-06-22 23:39:21.476758
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric=1', 'mtu=1500', 'inet=193.238.232.13', 'netmask=fffff800', 'broadcast=193.238.239.255']

    an = AIXNetwork()
    current_if = an.parse_interface_line(words)

    assert current_if['device'] == 'en0'

# Generated at 2022-06-22 23:39:26.292591
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Make sure we are initializing a subclass of NetworkCollector class."""
    collector = AIXNetworkCollector()
    assert isinstance(collector, NetworkCollector)
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:39:33.502201
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    # test network_collector
    network = AIXNetwork()

    # test method get_default_interfaces of class AIXNetwork
    # test get_default_interfaces return value for FreeBSD

# Generated at 2022-06-22 23:39:40.137024
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    test_module.run_command = mock.Mock(return_value=(0, '', ''))
    aix_network = AIXNetwork(module=test_module)
    current_if = aix_network.parse_interface_line(['en5:'])
    assert current_if['device'] == 'en5'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-22 23:39:46.521964
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # pylint: disable=protected-access
    from ansible.module_utils.facts.network.base import NetworkCollector
    net_collector = NetworkCollector('AIX')
    # ifconfig -a

# Generated at 2022-06-22 23:39:52.142014
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_AIXNetwork = AIXNetwork({})
    test_AIXNetwork.module.run_command = fancy_command
    default_v4_interface = test_AIXNetwork.get_default_interfaces('/usr/sbin/route')
    assert default_v4_interface == ('10.1.1.1', 'en0')



# Generated at 2022-06-22 23:40:03.171210
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = "/sbin/ifconfig"
    ifconfig_options = "-a"
    ansible_facts = AIXNetworkCollector(None, None, None).collect(None, None)

# Generated at 2022-06-22 23:40:14.590146
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = type('module', (object,), dict(run_command=run_command))

    def get_bin_path(name):
        return '/usr/sbin/' + name

    module.get_bin_path = get_bin_path
    o = AIXNetwork(module)

    # initialize with ifconfig command output
    o.is_netstat_default_route_available = True
    o.is_uname_W_available = True
    o.is_entstat_available = True
    o.is_lsattr_E_available = True

    o.get_interfaces_info('ifconfig')


# Generated at 2022-06-22 23:40:16.081716
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    mock_module = MockModule()
    assert AIXNetworkCollector(mock_module).platform == 'AIX'

# Generated at 2022-06-22 23:40:22.313505
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    m = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = m.split()
    current_if = AIXNetwork.parse_interface_line(AIXNetwork(), words)
    assert(current_if['device'] == 'en0')
    assert(current_if['type'] == 'unknown')
    assert(current_if['macaddress'] == 'unknown')
    assert(current_if['mtu'] == 'unknown')

# Generated at 2022-06-22 23:40:28.409331
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    facts = dict()

    facts['ansible_processor'] = dict()
    facts['ansible_processor']['count'] = 2
    facts['ansible_processor']['vcpus'] = 2
    facts['ansible_system'] = 'AIX'
    facts['ansible_system_vendor'] = 'IBM'
    facts['ansible_lsb'] = dict()
    facts['ansible_lsb']['major_release'] = 7
    facts['ansible_lsb']['minor_release'] = 2
    facts['ansible_lsb']['release'] = '7.2.0.0'
    facts['ansible_lsb']['codename'] = 'Unknown'
    facts['ansible_lsb']['description'] = 'AIX 7.2'

# Generated at 2022-06-22 23:40:30.845670
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of AIXNetworkCollector can be called.
    """
    AIXNetworkCollector(None)

# Generated at 2022-06-22 23:40:33.248885
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector._fact_class is not None
    assert net_collector._platform is not None

# Generated at 2022-06-22 23:40:35.155709
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:40:44.888607
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Test 1: no gateway for IPv4
    ifconfig_path = '/usr/bin/ifconfig'
    rc, out, err = run_command([ifconfig_path, '-a'])
    route_path = '/usr/bin/netstat'
    module = get_platform_module()
    aix_network = AIXNetwork(module)
    default_interfaces = aix_network.get_default_interfaces(route_path)
    assert default_interfaces[0] == {}

    # Test 2: nonexistent path
    nonexistent_path = '/ifconfig'
    aix_network = AIXNetwork(module)
    default_interfaces = aix_network.get_default_interfaces(nonexistent_path)
    assert default_interfaces[0] == {}


# Generated at 2022-06-22 23:40:51.470553
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector

    # defines test case with expected results

# Generated at 2022-06-22 23:40:52.939258
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    a = AIXNetwork()
    assert a.platform == 'AIX'

# Generated at 2022-06-22 23:40:54.826450
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(),NetworkCollector)

# Generated at 2022-06-22 23:41:06.282769
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    results = {
        'default_interface': {'v4': {
            'gateway': '192.168.0.1',
            'interface': 'en2'},
            'v6': {
                'gateway': 'fe80::423:ffff:fe9f:8188%en0',
                'interface': 'en2'}},
        'default_ipv4': {'gateway': '192.168.0.1',
                         'interface': 'en2'},
        'default_ipv6': {'gateway': 'fe80::423:ffff:fe9f:8188%en0',
                         'interface': 'en2'}
    }
    network_collector = AIXNetworkCollector(dict(), '/usr/bin/ansible')

# Generated at 2022-06-22 23:41:17.961170
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    network_collector = AIXNetworkCollector(module=module)
    interface_line = "en0: flags=5e080863,c0<BROADCAST,MULTICAST,NOTRAILERS,UP,LOWER_UP,SIMPLEX,RUNNING,NOARP,M-DOWN>\n"
    words = interface_line.split()
    network_collector._fact_class.parse_interface_line(words)
    assert words[0] == "en0:"
    assert words[1] == "flags=5e080863,c0<BROADCAST,MULTICAST,NOTRAILERS,UP,LOWER_UP,SIMPLEX,RUNNING,NOARP,M-DOWN>"
    assert words[2] == "en0:"
    assert words

# Generated at 2022-06-22 23:41:29.574744
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('FakeModule', (object,), {
        'run_command': lambda self, command: (
            0,
            'default 172.17.0.1 UG 1 0 en0\n'
            'default fe80::%eth0 U 1 0 en0\n'
            'default fe80::%en1 U 1 0 en1\ndefault ff02::%en0 U 1 0 en0\n'
            'default ff02::%en1 U 1 0 en1\n',
            '')
    })()
    module.get_bin_path = lambda name: '/bin/' + name
    test = AIXNetwork()
    test.module = module
    v4, v6 = test.get_default_interfaces(route_path='route')

# Generated at 2022-06-22 23:41:38.027485
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork()
    # test if the output from 'ifconfig -a' is correctly parsed
    test_line = 'en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 3'
    test_words = test_line.split()
    test_dict = aix_network.parse_interface_line(test_words)
    assert test_dict['device'] == 'en0'
    assert test_dict['flags'] == {'UP': True, 'BROADCAST': True, 'RUNNING': True, 'MULTICAST': True, 'IPv4': True}
    assert test_dict['macaddress'] == 'unknown'
    assert test_

# Generated at 2022-06-22 23:41:41.141293
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc._fact_class == AIXNetwork


# Generated at 2022-06-22 23:41:50.409999
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    AIXNetwork = AIXNetwork()

# Generated at 2022-06-22 23:42:02.216884
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            if arg == 'netstat':
                return arg


# Generated at 2022-06-22 23:42:09.176771
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts import Network

    network = Network()
    ifconfig_path = network.module.get_bin_path('ifconfig')

    aix_network = AIXNetwork(network.module)
    aix_network.get_interfaces_info(ifconfig_path)
    aix_network.get_interfaces_info(ifconfig_path, ifconfig_options='')



# Generated at 2022-06-22 23:42:10.196972
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector is not None

# Generated at 2022-06-22 23:42:18.245508
# Unit test for method get_default_interfaces of class AIXNetwork

# Generated at 2022-06-22 23:42:20.421413
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    collector = AIXNetworkCollector(module)
    assert collector is not None


# Generated at 2022-06-22 23:42:22.819298
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'

# Generated at 2022-06-22 23:42:30.847051
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import textwrap
    from . import PlatformFacts
    from . import Facts
    from . import Network

    # Fake module for testing
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_network_resources'] = ['all']

            self.config = {}
            self.config['ansible_facts'] = {}
            self.config['ansible_facts']['ansible_net_gather_timeout'] = 120

        def get_bin_path(self, name):
            return '/sbin/' + name


# Generated at 2022-06-22 23:42:39.148687
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    x = AIXNetwork()
    a = x.parse_interface_line(['en0:', 'flags=5e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric:1', 'mtu:1500', 'options=9b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM>', 'address:00:50:56:8a:4b:dc', 'inet:192.168.0.2', 'netmask:0xffffff00', 'broadcast:192.168.0.255', 'nd6:'])
    assert a

# Generated at 2022-06-22 23:42:51.281989
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface_line_01 = "en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    interface_line_02 = "lo0: flags=e08084b,c0<UP,BROADCAST,LOOPBACK,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,LARGESEND,CHAIN>\n"

    result = AIXNetwork.parse_interface_line(words = interface_line_01.split())
    print(result)
    assert result['device'] == 'en0'

# Generated at 2022-06-22 23:43:02.009718
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class AIX_Network:
        def __init__(self):
            class module:
                def run_command(self, args):
                    test_netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-22 23:43:11.623581
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = {}
    collected_facts = AIXNetworkCollector(None, facts).collect()
    # collected_facts must be dict
    assert isinstance(collected_facts, dict)
    # collected_facts['ansible_network_resources'] must be dict
    assert isinstance(collected_facts['ansible_network_resources'], dict)
    # check keys of dict
    assert list(collected_facts['ansible_network_resources'].keys()) == ['interfaces', 'default_ipv4_interface', 'default_ipv6_interface']

# Generated at 2022-06-22 23:43:13.471092
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Constructor sets '_platform' correctly"""
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:43:17.765519
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    collector = AIXNetworkCollector(module=module)
    assert collector.module == module
    assert collector.fact_class.platform == 'AIX'
    assert collector.fact_class._platform == 'AIX'
    assert collector.fact_class.__module__ == AIXNetwork.__module__


# Generated at 2022-06-22 23:43:29.424437
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    tests = [
        {
            'input': 'lo0:',
            'output': {
                'device': 'lo0',
                'ipv4': [],
                'ipv6': [],
                'macaddress': 'unknown',
                'type': 'unknown',
                'flags': [],
            },
        },
    ]

    aix = AIXNetwork()
    for test in tests:
        if_dict = aix.parse_interface_line(test['input'].split())
        assert if_dict == test['output'], 'Failed to assert "%s" == "%s"' % (str(if_dict), str(test['output']))

# Generated at 2022-06-22 23:43:40.241868
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # read AIX ifconfig -a output file corresponding to OS level 7.1 TL6 SP1
    # and put it in a string
    file = open("test_file_ifconfig_71_TL6_SP1", "r")
    string_test_file = file.read()

    # test the code on the string
    interfaces, ips = AIXNetwork().get_interfaces_info("/usr/sbin/ifconfig", string_test_file)

    # test the length of results
    if len(interfaces) != 9:
        print("Error: AIXNetwork().get_interfaces_info(): len(interfaces) not equal to 9")
        assert 0

# Generated at 2022-06-22 23:43:52.139398
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    A fake AnsibleModule object is created for unit testing
    """

    class AnsibleModuleFake:

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            if 'ifconfig -a' in cmd:
                return 0, ifconfig_a_output, ''
            elif 'entstat em1' in cmd:
                return 0, entstat_output, ''
            elif 'lsattr -El em1' in cmd:
                return 0, lsattr_output, ''
            else:
                return 0, '', ''

    # input data

# Generated at 2022-06-22 23:44:02.888337
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Calling method get_default_interfaces of class AIXNetwork
    with a testfile as input.
    """
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=invalid-name


    #############################################################################
    #
    # Input data for testing
    #
    #############################################################################

    # input: actual output of ifconfig -a on AIX 7.2
    # in some lines the output is truncated

# Generated at 2022-06-22 23:44:10.506375
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class ModuleStub(object):
        def __init__(self, bin_paths):
            self._uname_path = None
            self._ifconfig_path = None
            self._bin_paths = bin_paths

        def get_bin_path(self, name):
            return self._bin_paths[name]

        def run_command(self, cmd):
            if cmd[0] == self._uname_path:
                return (0, '0', '')  # not in wpar
            if cmd[0] == self._ifconfig_path:
                return (0, test_AIXNetwork_get_interfaces_info.ifconfig_out, '')

    # ifconfig -a output for test, interface tu0 and no ipv6

# Generated at 2022-06-22 23:44:16.084836
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    instance_of_NetworkCollector = isinstance(AIXNetworkCollector(), NetworkCollector)
    assert instance_of_NetworkCollector is True, 'AIXNetworkCollector() is not instance of NetworkCollector'


# Generated at 2022-06-22 23:44:25.834174
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('Module', (), {})()

    ifconfig_path = '/bin/ifconfig'
    module.get_bin_path = lambda _: ifconfig_path

    module.run_command = lambda args: (0, '', '')
    ifconfig = AIXNetwork(module)
    assert ifconfig.get_default_interfaces(route_path='/sbin/route') == (dict(gateway='', interface=''), dict(gateway='', interface=''))

    module.run_command = lambda args: (0, 'default 172.16.0.1 UG  0 0 0 eth0', '')
    ifconfig = AIXNetwork(module)

# Generated at 2022-06-22 23:44:37.293856
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:49.169504
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:58.418647
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # import dummies for function parameters
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create an instance of class AIXNetwork to use this method of it
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(Network())
    aix_network = AIXNetwork(generic_bsd_ifconfig_network)

    # create dummies for all function parameters
    route_path = True

    # test itself
    aix_network.get_default_interfaces(route_path)

# Generated at 2022-06-22 23:45:05.984281
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    # To test the function, we construct a mocked module
    module = MockNetworkModule(platform='AIX')

    # Construct fixture for the netstat command
    fixture = dict(
        rc=0,
        stdout=textwrap.dedent('''
        Routing tables
        -------------------------------------------------------------------
        default            192.0.2.129      UG     0      0        en0
        default            2001:db8:feed:: UGDAe  0      0        en0
        -------------------------------------------------------------------
        Internet6:
        Destination        Gateway           Flags   Refs     Use     MTU      Interface
        '''),
        stderr='',
    )

    module.run_command = Mock(return_value=(fixture['rc'], fixture['stdout'], fixture['stderr']))

    # Construct an object of the AIXNetwork class


# Generated at 2022-06-22 23:45:17.817264
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '192.168.1.43', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    current_if = AIXNetwork().parse_interface_line(words)