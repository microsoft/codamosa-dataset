

# Generated at 2022-06-22 23:35:18.920564
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:35:30.971249
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:35:34.920592
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    net_collector = NetworkCollector()
    assert isinstance(net_collector.get_network_facts(None, None), dict)

# Generated at 2022-06-22 23:35:46.242745
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    test if method get_interfaces_info of class AIXNetwork
    stores the right values in the right parameters
    '''

    # get_interfaces_info output

# Generated at 2022-06-22 23:35:56.448101
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Get a single interface of device type ether and known mac address with AIX-specific entries.
    """

# Generated at 2022-06-22 23:36:01.973757
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    aix_network_collector = AIXNetworkCollector()
    assert isinstance(aix_network_collector._fact_class, AIXNetwork)
    assert aix_network_collector._platform == 'AIX'
    assert aix_network_collector._ifconfig_path is None


# Generated at 2022-06-22 23:36:12.345186
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = type(os)('module')
    module.run_command = lambda x, y=None: ([0, aix_interfaces_info_cmd_output, ''], 0)
    module.get_bin_path = lambda x: x
    uname_path = type(os)('os')
    uname_path.split = lambda x: ['0']
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, y=None: ([0, uname_path, ''], 0)
    n = AIXNetwork(module)
    result = n.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')
    assert result == aix_interfaces_info_cmd_output


# Generated at 2022-06-22 23:36:15.849003
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = AIXNetwork(module)
    assert isinstance(network, AIXNetwork)
    assert network.platform == 'AIX'

# Generated at 2022-06-22 23:36:23.024386
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    nm = AIXNetwork(module=module)
    nm.populate()

# Generated at 2022-06-22 23:36:25.355032
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'
    assert collector.fact_class == AIXNetwork

# Generated at 2022-06-22 23:36:26.247280
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:36:28.592459
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    x = AIXNetworkCollector()
    assert x.platform == 'AIX'
    assert x._fact_class
    assert x._fact_class.platform == 'AIX'


# Generated at 2022-06-22 23:36:34.749733
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_iface = AIXNetwork()
    words = ["en0:", "flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>",
             "metric 0", "mtu 1500", "options=9<RXCSUM,VLAN_MTU,", "inet6",
             "fe80::ba27:ebff:feb0:9e0%en0", "prefixlen", "64", "scopeid", "0x4"]

# Generated at 2022-06-22 23:36:38.248631
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructing an instance of AIXNetworkCollector should always work.
    """
    AIXNetworkCollector()

# Unit tests for method AIXNetwork.get_default_interfaces

# Generated at 2022-06-22 23:36:40.255433
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    my_obj = AIXNetwork()
    platform = 'AIX'
    assert my_obj.platform == platform

# Generated at 2022-06-22 23:36:47.375085
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork(dict(module=None))
    module_result = dict()

    class Netstat_class:
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/netstat'


# Generated at 2022-06-22 23:36:57.665473
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:37:06.862121
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = '/usr/bin/netstat'
    default_interfaces = AIXNetwork(None).get_default_interfaces(route_path)
    assert 'gateway' in default_interfaces
    assert 'interface' in default_interfaces
    assert default_interfaces['gateway'] == '127.0.0.1'
    assert default_interfaces['interface'] == 'lo0'
    assert 'gateway' in default_interfaces['v6']
    assert 'interface' in default_interfaces['v6']
    assert default_interfaces['v6']['gateway'] == '::1'
    assert default_interfaces['v6']['interface'] == 'lo0'

# Generated at 2022-06-22 23:37:09.449777
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj._fact_class == AIXNetwork
    assert obj._platform == 'AIX'


# Generated at 2022-06-22 23:37:11.793744
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._fact_class is AIXNetwork
    assert AIXNetworkCollector._platform is 'AIX'

# Generated at 2022-06-22 23:37:22.817135
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    AIXNetwork_object = AIXNetwork(module=None)

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = AIXNetwork_object.get_interfaces_info(ifconfig_path, ifconfig_options)

    # example of interfaces and ips dictionary
    # interfaces['lo0'] = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'mtu': 65536, 'macaddress': 'unknown', 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING']}
    # interfaces['en0'] = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'mtu': 1500, 'macaddress': 'unknown', 'type': 'unknown

# Generated at 2022-06-22 23:37:32.736797
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # Create a temporary module for testing the code in AIXNetwork.get_default_interfaces()
    from ansible.module_utils.facts.network.aix.aix import AIXNetwork
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a temporary network object for testing the code in get_default_interfaces()
    aix_network = AIXNetwork(module)

    # Read the content of the netstat example output file
    route_path = '../ansible_collections/ansible/community/files/aix_netstat_nr.txt'
    with open(route_path) as f:
        netstat_nr_out = f.read()



# Generated at 2022-06-22 23:37:37.331785
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    o = AIXNetworkCollector()
    assert o._fact_class == AIXNetwork
    assert o._platform == 'AIX'

# Generated at 2022-06-22 23:37:44.511245
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    aix_network = AIXNetwork(module)
    out = aix_network.get_interfaces_info('/usr/bin/ifconfig')
    assert out[0]['lo0']['device'][0] == 'l'
    assert out[0]['lo0']['flags'][0] == 'U'
    assert out[0]['lo0']['mtu'] == '65536'
    assert out[0]['lo0']['macaddress'] == 'unknown'
    assert out[0]['lo0']['type'] == 'unknown'
    assert out[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-22 23:37:54.600151
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module=module)
    assert network_collector.parse_interface_line(['en7:', 'flags=0x1c43<UP,BROADCAST,RUNNING,ALLMULTI,SIMPLEX,MULTICAST>', 'metric=1']) == \
           {'device': 'en7', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': {'UP': True, 'BROADCAST': True, 'RUNNING': True, 'ALLMULTI': True, 'SIMPLEX': True, 'MULTICAST': True}, 'macaddress': 'unknown'}


# Generated at 2022-06-22 23:38:05.459718
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import json
    import os
    import tempfile


# Generated at 2022-06-22 23:38:16.732908
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    ifc = AIXNetwork()
    line = "en0: flags=1e080863,c0&lt;UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN> mtu 1500 index 2"
    words = line.split()
    current_if = ifc.parse_interface_line(words)

# Generated at 2022-06-22 23:38:29.239401
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # mock module class
    class module_mock:
        def __init__(self):
            self.get_bin_path_called = 0
            self.run_command_called = 0
            self.run_command_called_with_args = []

        def get_bin_path(self, name):
            if name == 'uname':
                return '/bin/uname'
            elif name == 'lsattr':
                return '/usr/sbin/lsattr'
            elif name == 'entstat':
                return '/usr/sbin/entstat'
            elif name == 'ifconfig':
                return '/usr/sbin/ifconfig'
            elif name == 'netstat':
                return '/usr/bin/netstat'
            self.get_bin_path_called += 1
            return None


# Generated at 2022-06-22 23:38:36.232240
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    current_if = {}
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    current_if = aix_network.parse_interface_line(words)
    assert current_if['mtu'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:38:38.601571
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collectornet = AIXNetworkCollector()
    assert collectornet.__class__._fact_class is AIXNetwork
    assert collectornet.__class__._platform == AIXNetwork.platform

# Generated at 2022-06-22 23:38:50.548983
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, msg):
            raise AssertionError(msg)

        def get_bin_path(self, arg, required=False):
            return '/sbin/ifconfig'

        def run_command(self, cmd, check_rc=False):
            mock_cmd = [
                ['ifconfig', '-a'],
                ['uname', '-W'],
                ['netstat', '-nr'],
                ['entstat', 'ent0'],
                ['lsattr', '-El', 'ent0']
            ]

# Generated at 2022-06-22 23:38:58.907180
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    network = AIXNetwork()
    network.module = MagicMock()
    network.module.run_command = MagicMock()
    network.module.run_command.return_value = 1, '', ''
    test_args = ['/fake_binary']
    result = network.get_default_interfaces('/fake_binary')
    assert result == ('', '')
    network.module.run_command.assert_called_with(test_args)

# Generated at 2022-06-22 23:39:08.842106
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from collections import namedtuple
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import os

    class MockModule():
        def __init__(self, name=None):
            self.params = {}

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'netstat':
                return os.path.join('/', 'usr', 'bin', 'netstat')
            return None


# Generated at 2022-06-22 23:39:17.113021
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    class FakeAnsibleModule:
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, '', '')
            self.get_bin_path = lambda *args, **kwargs: '/usr/bin'

    class FakeAIXNetwork:
        def __init__(self):
            self.module = FakeAnsibleModule()

    an = FakeAIXNetwork()

    assert an.ifconfig_path == '/usr/bin/ifconfig'  # from super class in GenericBsdIfconfigNetwork

    words = ['lo0:', 'flags=1e080863,480<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    res = an.parse

# Generated at 2022-06-22 23:39:24.079995
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = AIXNetworkCollector(ansible_module=ansible_module)

    if network_collector.__class__.__name__ != 'AIXNetworkCollector':
        raise AssertionError("Constructor does not return AIXNetworkCollector instance")



# Generated at 2022-06-22 23:39:31.902416
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    collector = AIXNetworkCollector(dict(module=dict(run_command=lambda *_: (0, 'default 192.168.111.1 UG 1 600 en0\ndefault fe80::%en0 UG 1 136 en0', ''))))
    interfaces = collector.get_facts('fake_facts')['default_ipv4']
    assert interfaces['interface'] == 'en0'
    assert interfaces['gateway'] == '192.168.111.1'
    interfaces = collector.get_facts('fake_facts')['default_ipv6']
    assert interfaces['interface'] == 'en0'
    assert interfaces['gateway'] == 'fe80::%en0'

# Generated at 2022-06-22 23:39:41.904557
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!'], type='list'))
    )

    ansible_net_gather_subset = mod.params['gather_subset']
    platform = 'AIX'
    module = AnsibleModule(argument_spec=dict())

    # test for generic instance and direct instance of class with parameter platform
    generic = GenericIfconfigNetwork(module)
    direct = NetworkCollector.get_network_provider(platform, module)
    assert generic
    assert direct

    # test for fact class definition
    assert isinstance(generic, GenericBsdIfconfigNetwork)
    assert isinstance(direct, AIXNetwork)

    # get_interface_definitions; generic and direct should have common dict
    generic_ifaces = generic.get_interface_

# Generated at 2022-06-22 23:39:44.649758
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-22 23:39:56.397761
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # unit test requires mocker and assert
    from ansible.module_utils.facts.network.aix import AIXNetwork
    import unittest
    unittest.TestCase()

    # define a ifconfig-like output for AIX

# Generated at 2022-06-22 23:40:02.113565
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    platform = AIXNetwork.platform
    module = AIXNetwork.module

    # pylint: disable=protected-access
    assert module == AIXNetwork._module
    assert platform == AIXNetwork._platform
    assert platform == AIXNetwork.platform
    assert 'AIXNetwork' == AIXNetwork.__name__
    assert 'ansible.module_utils.facts.network.aix.AIXNetwork' == AIXNetwork.__module__

# Generated at 2022-06-22 23:40:04.193836
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert issubclass(AIXNetworkCollector, NetworkCollector)

# Generated at 2022-06-22 23:40:15.108567
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # set up test data
    module.run_command = MagicMock(return_value=(0, AIX_IFCONFIG_A_OUTPUT, ""))

    # set up test object
    test_object = AIXNetwork(module)

    # run the code to be tested
    test_interfaces, test_ips = test_object.get_interfaces_info("/sbin/ifconfig")

    assert test_interfaces == AIX_IFCONFIG_A_EXPECTED_INTERFACES

    assert test_ips == AIX_IFCONFIG_A_EXPECTED_IPS

    module.fail_json.assert_not_called()


# Generated at 2022-06-22 23:40:23.000174
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en1:', 'flags=e1000843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>',
             'metric=0', 'mtu=1500', 'options=2017<RXCSUM,TXCSUM>', 'addr=10.1.1.1', 'netmask=255.255.255.0', 'broadcast=10.1.1.255']
    test_AIXNet = AIXNetwork()
    result_if = test_AIXNet.parse_interface_line(words)
    assert result_if['device'] == 'en1'

# Generated at 2022-06-22 23:40:25.511673
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.__class__.__name__ == 'AIXNetworkCollector'


# Generated at 2022-06-22 23:40:31.265073
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Test for class AIXNetwork.

    Test for a constructor of class AIXNetwork.
    """

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    AIXNetwork(module)



# Generated at 2022-06-22 23:40:39.259079
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    input = 'en0: flags=0x8802<BROADCAST,SIMPLEX,MULTICAST> mtu 1500\n'
    words = input.split()
    current_if = AIXNetwork().parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert 'mtu' not in current_if


# Generated at 2022-06-22 23:40:40.278472
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Unit test for constructor of class AIXNetworkCollector
    """
    assert AIXNetworkCollector.collect() is not None

# Generated at 2022-06-22 23:40:41.652985
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    aix_network = AIXNetwork()
    result = aix_network.get_default_interfaces('')
    assert result == ({}, {})


# Generated at 2022-06-22 23:40:50.145212
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    AIXNetwork = class_to_test.AIXNetwork

# Generated at 2022-06-22 23:40:56.505713
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    net = AIXNetwork()
    net.module.run_command = mock_run_command
    assert net.get_default_interfaces('/sbin/route -n get default') == (
        {'interface': 'lo0',
         'gateway': '127.0.0.1'},
        {'interface': 'lo0',
         'gateway': '::1'}
    )



# Generated at 2022-06-22 23:41:00.650045
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix = AIXNetwork()

    assert aix.get_default_interfaces(route_path=None) == ({}, {})



# Generated at 2022-06-22 23:41:12.873322
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # test_words come from 'ifconfig -a' output on AIX of test machine 'aix72-07'
    test_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    network = AIXNetwork()
    current_if = network.parse_interface_line(test_words)

# Generated at 2022-06-22 23:41:15.881456
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    obj = AIXNetworkCollector()
    print(obj.__dict__)



# Generated at 2022-06-22 23:41:22.710051
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # class AIXNetwork extends class GenericBsdIfconfigNetwork
    class AIXNetwork_test(AIXNetwork):

        def __init__(self, module):
            self.module = module
            self.return_value = (None, None)

        def run(self, **kwargs):
            return self.return_value

    # class AIXNetwork_test will be called with two parameters
    # ifconfig_path and ifconfig_options
    # we will test now with those values
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    # class AIXNetwork_test will be called with two parameters
    # ifconfig_path and ifconfig_options
    # we will test now with those values

# Generated at 2022-06-22 23:41:33.269713
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # empty dict for now
    options_dict = dict()
    # init object
    aixNet = AIXNetwork()
    # words from ifconfig -a
    words = ['en5:','flags=1e080863','mtu','1500','index','8','inet','172.17.10.1','netmask','0xffff0000','broadcast','172.17.255.255',
             'tcp_sendspace','262144','tcp_recvspace','262144','rfc1323','1']
    # expected dict
    expected_res = {'device': 'en5', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': options_dict, 'macaddress': 'unknown'}
    # checked dict (result of function parse_interface_line)
    checked_res = a

# Generated at 2022-06-22 23:41:38.684543
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    This test is for method get_interfaces_info of class AIXNetwork
    """

# Generated at 2022-06-22 23:41:44.381431
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_module = AnsibleMock()
    ansible_module.run_command = AnsibleRunCommandMock()
    facts_network = AIXNetworkCollector(ansible_module)
    assert(facts_network.platform == 'AIX')
    assert(facts_network._fact_class.platform == 'AIX')


# Generated at 2022-06-22 23:41:54.483764
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Run get_interfaces_info (private method) of class AIXNetwork
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_collector = AIXNetworkCollector(module=module)
    fact_network = AIXNetwork(module=module)
    interfaces, ips = fact_network.get_interfaces_info(ifconfig_path=fact_network.module.get_bin_path('ifconfig'))
    for interface in interfaces:
        for key in interfaces[interface]:
            module.fail_json(msg="%s: %s" % (key, interfaces[interface][key]))
        module.exit_json(changed=False)


# import module snippets
from ansible.module_utils.basic import *


# Generated at 2022-06-22 23:42:05.847476
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    module = NetworkCollector()
    module.get_bin_path = lambda *args, **kwargs: ifconfig_path

# Generated at 2022-06-22 23:42:16.097658
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    mocked_module = Mock()
    mocked_module.run_command.return_value = 0, AIX_IFCFG_WITH_GATEWAY, ''

    network = AIXNetwork(mocked_module)

    mocked_module.get_bin_path.return_value = 'ifconfig'

    interfaces, ips = network.get_interfaces_info(network.module.get_bin_path('ifconfig'))

    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['macaddress'] == '00:11:22:33:44:55'
    assert interfaces['en0']['pciid'] == '127e/0'
    assert interfaces['en0']['ipv4'][0]['address'] == '10.11.121.116'

# Generated at 2022-06-22 23:42:27.654605
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:28.300466
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ai = AIXNetworkCollector()
    assert ai


# Generated at 2022-06-22 23:42:32.199394
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork class"""
    instance = AIXNetwork({})

    assert isinstance(instance, AIXNetwork)



# Generated at 2022-06-22 23:42:33.829891
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(NetworkCollector.collector['AIXNetworkCollector'](None, None), AIXNetworkCollector)


# Generated at 2022-06-22 23:42:46.081210
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={})
    test_AIXNetwork = AIXNetwork(test_module)

    interfaces = test_AIXNetwork.get_default_interfaces('/bin/netstat')
    assert type(interfaces) == tuple
    assert len(interfaces) == 2
    assert type(interfaces[0]) == dict
    assert type(interfaces[1]) == dict
    assert len(interfaces[0]) == 2
    assert len(interfaces[1]) == 2
    assert 'gateway' in interfaces[0]
    assert 'interface' in interfaces[0]
    assert 'gateway' in interfaces[1]
    assert 'interface' in interfaces[1]
    assert '.' in interfaces[0]['gateway']
    assert ':' in interfaces[1]['gateway']
    assert len

# Generated at 2022-06-22 23:42:48.194598
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:43:00.489635
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    line = 'en5: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words = line.split()

    m = AIXNetwork()
    current_if = m.parse_interface_line(words)

    assert current_if['device'] == 'en5'
    assert 'UP' in current_if['flags']
    assert 'BROADCAST' in current_if['flags']
    assert 'NOTRAILERS' in current_if['flags']
    assert 'RUNNING' in current_if['flags']
    assert 'SIMPLEX' in current_if['flags']

# Generated at 2022-06-22 23:43:09.670135
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = NetworkCollector._create_module()
    module.run_command = NetworkCollector._create_module_run_command('netstat_AIX')
    module.get_bin_path = NetworkCollector._get_bin_path
    net = AIXNetwork(module=module)
    assert net.get_default_interfaces('route_path') == ({'interface': 'en0', 'gateway': '192.0.2.254'},
                                                        {'interface': 'en0', 'gateway': '2001:db8::1'})

# Generated at 2022-06-22 23:43:17.661086
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    import os
    import tempfile
    import textwrap

    inet6_sample_line = [
        "inet6 2001:db8:3c4d:15::1%1 prefixlen 128  scopeid 0x1  ",
        "inet6 fe80::250:56ff:fea7:b5c1%2 prefixlen 64  scopeid 0x2  ",
    ]

    inet6_sample_line_continue = [
        "inet6 fe80::5054:ff:fe7d:5f8e%en9 prefixlen 64  scopeid 0x4  ",
        "inet6 fe80::5054:ff:fe7d:5f8e%en10 prefixlen 64  scopeid 0x5  ",
    ]


# Generated at 2022-06-22 23:43:30.020564
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.255.255.255']

    ifconfig_aix = AIXNetwork()
    current_if = ifconfig_aix.parse_interface_line(words)

# Generated at 2022-06-22 23:43:31.398796
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Constructor of class AIXNetworkCollector"""
    assert AIXNetworkCollector

# Generated at 2022-06-22 23:43:33.593111
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = MockModule()
    obj = AIXNetwork(module)
    assert obj.module == module



# Generated at 2022-06-22 23:43:45.168517
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test AIXNetwork class constructor"""

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Test if AIX has uname command for AIX 6.1/7.1/7.2
    uname_path = module.get_bin_path('uname')
    if uname_path:
        rc, out, err = module.run_command([uname_path, '-W'])

    if rc == 0:
        # AIX Network class constructor
        AIX_network_ins = AIXNetwork(module)
        # Test if AIX has ifconfig command

# Generated at 2022-06-22 23:43:54.960514
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Unit test for constructor of class AIXNetwork"""


# Generated at 2022-06-22 23:44:02.667438
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    m = AIXNetwork()

    aix_ifconfig_path = m.module.get_bin_path('ifconfig')
    if not aix_ifconfig_path:
        print("ERROR: ifconfig not found")
        return

    o = m.get_interfaces_info(aix_ifconfig_path)
    print("INTERFACES: %s" % o[0])
    print("IPS: %s" % o[1])



# Generated at 2022-06-22 23:44:03.274510
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # ToDo
    pass


# Generated at 2022-06-22 23:44:07.055938
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork

    ansible_module = AnsibleModule(
        argument_spec=dict(),
    )

    AIXNetwork = AIXNetwork(ansible_module)

    AIXNetwork.get_default_interfaces('route_path')

    assert True is True

# Generated at 2022-06-22 23:44:10.842584
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    with open('/tmp/ansible_facts_aix_ifconfig.out', 'r') as f:
        out = f.read()

    aix = AIXNetwork()
    res = aix.get_interfaces_info('/tmp/ansible_facts_aix_ifconfig.out', '-a')
    assert res

# Generated at 2022-06-22 23:44:22.501372
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():


    interface_file = 'test/test_AIXNetwork_get_interfaces_info'
    ifconfig_path = 'test/test_AIXNetwork_get_interfaces_info'
    ifconfig_options = '-a'
    module = MockModule()
    ifconfig = AIXNetwork(module, ifconfig_path)
    ifconfig.get_interfaces_info = Mock(return_value=('', ''))
    ifconfig.module.run_command = Mock(return_value=[0, interface_file, ''])

    interfaces, ips = ifconfig.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-22 23:44:30.068141
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    assert network_collector.facts['default_ipv4']['gateway']
    assert network_collector.facts['default_ipv4']['interface']
    assert network_collector.facts['default_ipv6']['gateway']
    assert network_collector.facts['default_ipv6']['interface']

# Generated at 2022-06-22 23:44:39.612788
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a AIXNetwork object
    network_class = AIXNetwork(module)

    # Get an interface to use for testing
    interfaces = network_class.get_interfaces()
    if len(interfaces) == 0:
        raise ValueError("Cannot find interface for test")

    interface = interfaces[0]

    # Unit test add_ip_address()
    ip_address = '192.168.1.1'
    network_class.add_ip_address(interface, ip_address)

    # Make sure that the ip_address was added
    if ip_address not in network_class.interfaces[interface]['ipv4']:
        raise AssertionError("Failed to add IPv4 address")



# Generated at 2022-06-22 23:44:48.758050
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    word1 = 'ent0:'
    word2 = 'UP'
    words = [word1, word2]
    current_if = {'device': word1[0:-1], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = word2.split(':')[0].split(',')
    current_if['macaddress'] = 'unknown'    # will be overwritten later
    result = AIXNetwork(None, None).parse_interface_line(words)
    assert result == current_if


# Generated at 2022-06-22 23:45:00.432224
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    import pprint

    mac = {
        'en0': 'f0:d5:bf:01:8d:2e',
        'en1': 'f0:d5:bf:01:8d:2d',
    }

    ifconfig_path = '/etc/ansible/facts.d/ifconfig.aix'

# Generated at 2022-06-22 23:45:02.676962
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector.fact_class == AIXNetwork


# Generated at 2022-06-22 23:45:11.521176
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    aix_network = AIXNetwork()
    line1 = 'en0:'
    words1 = line1.split()
    current_if = aix_network.parse_interface_line(words1)
    assert current_if['device'] == 'en0'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['type'] is 'unknown'
    assert current_if['flags'] == []
    assert current_if['macaddress'] is 'unknown'

# Generated at 2022-06-22 23:45:22.142876
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    class Options(object):
        def __init__(self):
            self.bin_path = {
                'netstat': '/usr/bin/netstat',
            }

    class Module(object):
        def __init__(self):
            self.options = Options()

        def get_bin_path(self, arg):
            return self.options.bin_path.get(arg)

    aix = AIXNetwork()
    aix.module = Module()


    with open('/proc/net/route') as f:
        lines = f.read().splitlines()
    header = lines.pop(0).split()
    routes = {}
    for line in lines:
        fields = line.split()
        route = dict(list(zip(header, fields)))
        routes[route['Iface']] = route

    route