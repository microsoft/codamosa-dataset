

# Generated at 2022-06-22 23:35:28.697350
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = MockAnsibleModule()
    obj = AIXNetwork(module=module)

    # Parse interface line and remove mtus, test already pass on AIX
    assert obj.parse_interface_line(['en0:', 'flags=4163<UP,BROADCAST,RUNNING,MULTICAST>', 'mtu', '1500']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']}



# Generated at 2022-06-22 23:35:36.023711
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})
    aix_obj = AIXNetwork(module)

    # Test interfaces_info collection
    ifconfig_path = aix_obj.module.get_bin_path('ifconfig')
    interfaces_info, ips = aix_obj.get_interfaces_info(ifconfig_path)

    assert aix_obj.platform == 'AIX'
    assert interfaces_info['lo0']['device'] == 'lo0'
    assert interfaces_info['lo0']['type'] == 'ether'
    assert interfaces_info['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-22 23:35:42.936850
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ansible_module = AnsibleModule
    ansible_module.run_command = lambda *args: [0, 'default 192.0.2.1 UGS 0 0 en0', '']
    collect_network = AIXNetworkCollector(ansible_module)
    result = collect_network.get_default_interfaces('')

    assert result[0] == '192.0.2.1'
    assert result[1] == 'en0'



# Generated at 2022-06-22 23:35:52.017460
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )

    network_collector = AIXNetworkCollector(module=module)
    default_interfaces_v4, default_interfaces_v6 = network_collector.get_default_interfaces('/usr/bin/netstat')

    module.exit_json(changed=False, ansible_facts={'ansible_default_ipv4': default_interfaces_v4,
                                                   'ansible_default_ipv6': default_interfaces_v6})



# Generated at 2022-06-22 23:35:55.308310
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix.ifconfig import AIXNetwork
    AIXNet = AIXNetwork()
    assert AIXNet
    assert AIXNet._platform == 'AIX'


# Generated at 2022-06-22 23:36:07.671729
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # this test uses the module_utils/facts/network/aix_sample_outputs.txt file
    # to check the results
    #
    # aix_sample_outputs.txt contains sample output of the AIX netstat
    # and ifconfig commands. The file is used in the test.

    c = AIXNetwork()

    class TestModule:

        def __init__(self):
            self.t = AIXNetwork()

        def get_bin_path(self, name):
            if name == 'ifconfig':
                return '/usr/sbin/ifconfig'
            elif name == 'netstat':
                return '/usr/sbin/netstat'

        def run_command(self, command):
            if command[0:2] == ['/usr/sbin/ifconfig', '-a']:
                out

# Generated at 2022-06-22 23:36:15.808214
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test for method get_interfaces_info of class AIXNetwork.
    """

    # get_interfaces_info is a static method, so create a 'Mock' class and call it from there
    class MockAIXNetwork(AIXNetwork):
        """
        Mock class to be able to easily call a static method and test it.
        """
        @staticmethod
        def get_interfaces_info(ifconfig_path, ifconfig_options='-a'):
            """
            Runs ifconfig on *nix systems and returns a dictionary with the interface
            details.
            """
            module = MockModule()
            (interfaces, ips) = AIXNetwork.get_interfaces_info(module, ifconfig_path, ifconfig_options)
            return (interfaces, ips)


# Generated at 2022-06-22 23:36:25.662722
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Prepare the test data for run_command()
    cmd_rc = 0
    cmd_out = '''
em0: flags=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST> mtu 1500
        lladdr e0:69:95:bb:22:d5
        index 1
        inet 10.0.0.1 netmask ffffff00 broadcast 10.0.0.255
        nd6 options=1<PERFORMNUD>
        media: Ethernet autoselect (100baseTX <full-duplex>)
        status: active
'''
    cmd_err = ''

    # Prepare the test data for method parse_interface_line()

# Generated at 2022-06-22 23:36:31.742083
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '32768', 'index', '8']
    current_if = AIXNetwork.parse_interface_line(AIXNetwork(), words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    # MTU must not be in the dictionary
    assert 'mtu' not in current_if

# Generated at 2022-06-22 23:36:42.807335
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_obj = AIXNetwork()
    test_interface_line = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '3', 'inet', '172.16.1.1', 'netmask', '0xffff0000', 'broadcast', '172.16.255.255', 'ether', 'e4:1f:13:10:f9:ec']
    test_result = test_obj.parse_interface_line(test_interface_line)
    assert test_result['device'] == 'en0'
    assert test_result['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']

# Generated at 2022-06-22 23:36:43.740221
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()

# Generated at 2022-06-22 23:36:53.148454
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    route_path = "tests/unit/module_utils/facts/network/data/netstat-nr-aix"
    ansible_network = AIXNetwork(route_path)
    v4, v6 = ansible_network.get_default_interfaces(route_path)
    assert v4['gateway'] == '9.195.96.1'
    assert v4['interface'] == 'en3'
    assert v6['gateway'] == 'fe80:1:1:1:1::1'
    assert v6['interface'] == 'en3'




# Generated at 2022-06-22 23:36:59.132837
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fake_module = dict(
        run_command=lambda path, args: (0, 'default 10.0.0.1 UG 0 0 en0 default 10.0.0.1 UG 0 0 en0', ''),
    )
    network = AIXNetwork(module=fake_module)
    assert network.get_default_interfaces('') == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': '10.0.0.1', 'interface': 'en0'})

# Generated at 2022-06-22 23:37:08.835509
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module_mock = '''
    import re
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass
        class Parameters(object):
            def __init__(self, *args, **kwargs):
                self.ansible_facts = {
                    'ansible_net_interfaces': {},
                }
    '''
    exec(module_mock)
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args: (0, '', '')
    module.get_bin_path = lambda *args: True

    net = AIXNetwork(module)
    words = ['eth0:']
    result = net.parse_interface_line(words)

# Generated at 2022-06-22 23:37:15.793414
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = ['en0:', 'flags=4163', 'mtu', '1500', 'group', 'default']
    expected = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': '4163', 'macaddress': 'unknown'}
    parse_test = AIXNetwork(None)
    actual = parse_test.parse_interface_line(words)
    assert actual == expected

# Generated at 2022-06-22 23:37:20.323833
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    f = AIXNetwork().parse_interface_line(['en0:'])
    assert f['device'] == 'en0'
    assert f['type'] == 'unknown'
    assert f['flags'] == ['BROADCAST', 'MULTICAST']
    assert f['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:37:22.578213
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork


# Generated at 2022-06-22 23:37:32.570557
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    _module = AnsibleModule(argument_spec={})
    n = AIXNetwork()
    n.module = _module
    assert n.parse_interface_line(['en0:']) == {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP']}

# Generated at 2022-06-22 23:37:35.591802
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector

# Generated at 2022-06-22 23:37:38.332706
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork({})
    assert aix_network.platform == 'AIX'


# Generated at 2022-06-22 23:37:39.235424
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector.get_facts()



# Generated at 2022-06-22 23:37:40.896949
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.interfaces is None
    assert net.defaults is None
    assert net.facts is None

# Generated at 2022-06-22 23:37:52.772779
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    uname_rc = None
    uname_out = None
    uname_err = None
    uname_path = '/usr/bin/uname'
    if uname_path:
        uname_rc, uname_out, uname_err = 0, '0', ''
    netstat_path = '/usr/bin/netstat'

# Generated at 2022-06-22 23:37:55.285120
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    A test for the AIXNetwork class get_interfaces_info method.
    """
    result = AIXNetwork.get_interfaces_info(AIXNetwork, '/usr/sbin/ifconfig', ifconfig_options='-a')
    assert type(result) is tuple
    assert len(result) is 2
    assert type(result[0]) is dict
    assert type(result[1]) is dict
    assert len(result[0].keys()) > 0
    assert len(result[1].keys()) > 0

# Generated at 2022-06-22 23:38:05.889254
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    platform_out = {}

# Generated at 2022-06-22 23:38:14.290268
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    net_collector = AIXNetwork(module)
    (ipv4_if, ipv6_if) = net_collector.get_default_interfaces('/sbin/netstat')
    assert ipv4_if == {'gateway': '172.16.0.6', 'interface': 'en0'}
    assert ipv6_if == {'gateway': 'fe80::21a:92ff:fe2f:7b8f', 'interface': 'en0'}


# Generated at 2022-06-22 23:38:22.446620
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import os
    import sys
    import unittest
    import tempfile

    class UnitTestModule(object):
        def __init__(self):
            # get_bin_path is expected to return netstat_path /usr/sbin/netstat
            self.params = {
                'uname_path': '/usr/bin/uname',
                'netstat_path': '/usr/sbin/netstat',
                'ifconfig_path': '/sbin/ifconfig',
                'route_path': '/usr/sbin/route',
            }

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg in self.params:
                return self.params[arg]
            else:
                return None


# Generated at 2022-06-22 23:38:24.987040
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''
    Constructor for class AIXNetwork
    '''
    network_collector = AIXNetwork()

# Generated at 2022-06-22 23:38:35.494042
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:38:40.715108
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    AIXNetworkCollector - constructor
    """
    # It is a subclass of NetworkCollector.
    # Pass 'a_platform' as a mock
    a_platform = 'AIX'
    a_collector = AIXNetworkCollector(a_platform)
    assert isinstance(a_collector, NetworkCollector)
    assert a_collector.platform == a_platform
    assert isinstance(a_collector.facts, AIXNetwork)

# Generated at 2022-06-22 23:38:48.168544
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector

    net_collector = NetworkCollector()
    aix_net_collector = AIXNetworkCollector()
    assert isinstance(aix_net_collector, NetworkCollector)
    assert aix_net_collector.__class__.__bases__[0] == NetworkCollector


# Generated at 2022-06-22 23:38:55.796347
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Basic test for AIXNetwork class."""
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork

    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert isinstance(aix_network, GenericBsdIfconfigNetwork)

if __name__ == '__main__':
    test_AIXNetwork()

# Generated at 2022-06-22 23:38:57.705000
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    my_test = AIXNetwork()
    assert my_test is not None

# Generated at 2022-06-22 23:39:01.312392
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    o = AIXNetwork()

    # test for empty (rc > 0) output
    class Ifconfig:
        def __init__(self, rc, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err
        def run_command(self, args):
            return self.rc, self.out, self.err
    class Module:
        def __init__(self):
            pass
        def get_bin_path(self, binary, opt_dirs=[]):
            return binary
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            o = Ifconfig(3, 'ifconfig_out', 'ifconfig_err')
            if args[0] == 'ifconfig':
                return o

# Generated at 2022-06-22 23:39:05.600096
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    module = AIXNetwork()
    assert isinstance(module, AIXNetwork)
    assert isinstance(module, GenericBsdIfconfigNetwork)


# Generated at 2022-06-22 23:39:08.072702
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    assert isinstance(AIXNetworkCollector()._fact_class, GenericBsdNetwork)
    assert AIXNetworkCollector()._platform == 'AIX'

# Generated at 2022-06-22 23:39:15.029613
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test = AIXNetwork()
    test.module = True
    test.module.run_command = True
    test.module.run_command.return_value = (0, 'default          10.0.0.254      UG        0 0          en0      default          10.0.0.254      UG        0 0          en0', '')
    test.get_default_interfaces(None)
    for i in range(4):
        test.module.run_command.assert_called_with([test.module.get_bin_path('netstat'), '-nr'])


# Generated at 2022-06-22 23:39:15.840211
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector.platform == 'AIX'

# Generated at 2022-06-22 23:39:27.656973
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)

    rc, out, err = module.run_command(['ifconfig', '-a'])
    interfaces, ips = network.get_interfaces_info('ifconfig', '-a')

    assert interfaces['en0']['mtu'] == '1500'
    assert interfaces['en0']['type'] == 'ether'
    assert interfaces['en0']['flags'] == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interfaces['en0']['ipv4'][0]['address'] == '10.1.1.1'

# Generated at 2022-06-22 23:39:40.281774
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class AIXNetwork"""

    class Module:
        def __init__(self):
            pass

        def get_bin_path(self, arg, *args, **kwargs):
            return '/usr/bin/netstat'

        def run_command(self, arg, *args, **kwargs):
            return 0, 'default 1.1.1.1 UGS 0 25 en1\ndefault 2.2.2.2 UGRS 0 66325 en2', ''

    # 1 IPv4, 1 IPv6
    module = Module()
    network = AIXNetwork(module)
    interface = network.get_default_interfaces('/not_used')

# Generated at 2022-06-22 23:39:43.310820
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    test_object = AIXNetwork()
    assert test_object
    assert test_object.platform == 'AIX'
    assert test_object.route_path == '/usr/bin/netstat'
    assert test_object.ifconfig_path == '/usr/sbin/ifconfig'


# Generated at 2022-06-22 23:39:54.978726
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    words = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'.split(',')
    words[0] = words[0] + ':'
    expected_interface = {'device': 'en0', 'flags': '1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'ipv4': [], 'ipv6': [], 'macaddress': 'unknown', 'type': 'unknown'}
    aix_network = AIXNetwork()
    result_interface

# Generated at 2022-06-22 23:40:05.512475
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    input = """
    default          10.0.0.10          UG        0 0          en0
    default 172.16.4.254 U         0        0 en1
    default            fe80::%en0        UGc       0 0          en0
    default            ::1               UGRS      0 0          lo0
    default            fe80::1%lo0       UGRS      0 0          lo0
    """

    expected_output = {'interface': 'en0', 'gateway': '10.0.0.10'}, {'interface': 'en1', 'gateway': '172.16.4.254'}

    real_output = AIXNetwork.get_default_interfaces(input)
    assert real_output == expected_output

# Generated at 2022-06-22 23:40:16.909839
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ''' Unit test for method get_interfaces_infor of class AIXNetwork '''
    class Module(object):
        def __init__(self):
            self.params = {}
            self.exit_args = {}
            self.fail_json = None
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd[0])
            i = self.run_command_calls.count(cmd[0]) - 1
            if i >= len(self.run_command_rcs):
                rc = 0
            else:
                rc = self.run_command_

# Generated at 2022-06-22 23:40:21.929401
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Unit test for constructor of class AIXNetworkCollector"""
    module = NetworkCollector._create_module_mock()
    fact_class = NetworkCollector._create_fact_class_mock()

    collector = AIXNetworkCollector(module, fact_class)
    assert collector._platform == 'AIX'
    assert collector._fact_class == AIXNetwork
    assert collector._module == module


# Generated at 2022-06-22 23:40:24.897597
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    route_path = module.get_bin_path('route')
    assert network.get_default_interfaces(route_path) == ({}, {})


# Generated at 2022-06-22 23:40:33.201219
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')
    network_collector = AIXNetworkCollector(module=module)
    network = network_collector._fact_class(module, ifconfig_path, route_path)
    v4, v6 = network.get_default_interfaces(route_path)
    assert isinstance(v4, dict)
    assert isinstance(v6, dict)


# Generated at 2022-06-22 23:40:35.110999
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector()._fact_class, AIXNetwork)


# Generated at 2022-06-22 23:40:45.185556
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifconfig_path = '/bin/ifconfig'
    ifconfig_options = '-a'


# Generated at 2022-06-22 23:40:55.543728
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    # pylint: disable=missing-docstring
    mock_module = MockModule()

    file_get_interfaces_in = open(os.path.join(os.path.dirname(__file__), 'ifconfig.out'), 'r')
    file_get_interfaces_out = open(os.path.join(os.path.dirname(__file__), 'interfaces_info.out'), 'r')
    file_get_interfaces_err = open(os.path.join(os.path.dirname(__file__), 'ifconfig.err'), 'r')

    file_get_interfaces_in.read()

    network_collector = AIXNetwork(mock_module)

    interfaces, ips = network_collector.get_interfaces_info('/usr/sbin/ifconfig')

   

# Generated at 2022-06-22 23:41:07.412577
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('', (), {})()
    module.run_command = lambda x, use_unsafe_shell=True: \
        (0, ' default 192.0.2.2 UG 0 0 en0\n default 192.0.2.1 U 0 0 en0\n', '')
    class_instance = AIXNetwork(module)
    interface = class_instance.get_default_interfaces('route_path')
    assert interface == ('192.0.2.2', 'en0')
    module.run_command = lambda x, use_unsafe_shell=True: \
        (0, ' default 2001:db8:1::1 UG 0 0 en0\n default 2001:db8:1::2 U 0 0 en0\n', '')

# Generated at 2022-06-22 23:41:10.071928
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network = AIXNetworkCollector(dict())
    assert network.platform == AIXNetwork.platform
# Unit test: AIXNetworkCollector.platform

# Generated at 2022-06-22 23:41:20.182660
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """Test of AIXNetwork."""

    aix_facts = AIXNetwork()

    assert aix_facts.get_default_interfaces('test') == ({'gateway': '10.0.0.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})


# Generated at 2022-06-22 23:41:27.051108
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    interfaces, ips = AIXNetwork(module).get_interfaces_info()
    print(interfaces)
    for interface in interfaces:
        print(interface)
        for key in interfaces[interface]:
            print(key, interfaces[interface][key])
    print(ips)
    for key in ips:
        print(key, ips[key])


# Generated at 2022-06-22 23:41:36.291197
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import mock

    class TestAIXNetwork(object):
        def __init__(self):
            self.module = mock.MagicMock()

    test_obj = TestAIXNetwork()
    test_obj.module.get_bin_path.return_value = "/bin/true"
    test_obj.module.run_command.return_value = (0, "output", "err")
    test_network = AIXNetwork()

    class TestAIXNetworkCollector(unittest.TestCase):

        def test_get_interfaces_info(self):
            interfaces, ips = test_network.get_

# Generated at 2022-06-22 23:41:42.523924
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = NetworkCollector()
    # AIXNetwork class is used on AIX platform
    assert isinstance(mod.get_network_instance('AIX'), AIXNetwork), \
        'class AIXNetwork should be used on AIX platform'

# Generated at 2022-06-22 23:41:44.477487
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # AIX network parser is the same as the generic BSD parser, but with additional MAC address lookup
    # This test tests that using the constructor of AIXNetwork does not raise an exception
    AIXNetwork()

# Generated at 2022-06-22 23:41:54.589896
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    expected_attributes = {
        'default_gateway_ipv4': None,
        'default_gateway_ipv6': None,
        'dhcp_ipv4_leasetime': None,
        'dhcp_ipv6_leasetime': None,
        'interface_ipv4': {},
        'interface_ipv6': {},
        'interface_list': [],
        'macaddress': 'unknown',
        'mtu': None,
        'type': 'unknown',
    }

    test_object = None
    test_object = AIXNetwork({}, None, None)

    assert test_object is not None

    for item in expected_attributes:
        assert expected_attributes[item] == getattr(test_object, item)



# Generated at 2022-06-22 23:42:02.909313
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_iface = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']

    aix_network = AIXNetwork(dict())
    current_if = aix_network.parse_interface_line(words)

    assert current_if == test_iface

# Generated at 2022-06-22 23:42:06.186203
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    assert issubclass(AIXNetworkCollector, NetworkCollector)


# Generated at 2022-06-22 23:42:16.332254
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModuleMock({'PATH': '.:/usr/sbin:/usr/bin:/usr/bin/X11:/sbin:/etc:/usr/etc:/usr/sbin:/usr/ucb:/usr/bin/X11:/usr/local/bin:/usr/bin/X11:/bin:/usr/xpg4/bin:/usr/ccs/bin:/usr/bin/X11:.:/usr/sbin:/usr/bin:/sbin:/bin'})
    aw = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_rc = None
    ifconfig_out = None
    ifconfig_err = None

# Generated at 2022-06-22 23:42:27.845285
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    import tempfile
    import os

    # Test 1
    # Test for ipv4 and ipv6
    route_path = tempfile.mkstemp()[1]
    f = open(route_path, 'w')
    _str = 'default 127.0.0.1 UG 1 0 1 lo0\n'
    _str += 'default ::1 UG 1 0 1 lo0\n'
    _str += 'default 172.16.112.1 UG 1 0 1 en0\n'
    _str += 'default2 ::2 UG 1 0 1 en0\n'
    f.write(_str)
    f.close()


# Generated at 2022-06-22 23:42:35.483775
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.generic_bsd import Interface
    # ifconfig -a output (AIX 7.2 TL2 SP2)

# Generated at 2022-06-22 23:42:47.104073
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:54.776366
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = type('ModuleInterface', (), {'get_bin_path': lambda *args: 'netstat'})()
    d = AIXNetwork(module=module)
    assert d._get_default_interfaces('route') == ({'gateway': '10.0.2.2', 'interface': 'en0'}, {'gateway': 'fe80::a00:27ff:fe7e:6a09', 'interface': 'en0'})

# Generated at 2022-06-22 23:43:03.273367
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = None
    test_class = AIXNetwork
    current_if = test_class.parse_interface_line(test_class(), module, ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'index=1', 'metric=0', 'mtu=65536'])

    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4']
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:43:15.100284
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:43:21.092576
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    AIXNetwork - constructor test
    """
    _network_collector = AIXNetworkCollector()
    assert _network_collector.platform == 'AIX'
    assert _network_collector.fact_class is AIXNetwork

    _network = _network_collector.fact_class()
    assert _network.platform == 'AIX'

# Generated at 2022-06-22 23:43:32.378895
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    _test_line = 'en0: flags=1e084863,4843<UP,BROADCAST,NOTRAILERS,RUNNING,' \
                 'SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    _words = _test_line.split()
    _current_if = {'device': 'en0', 'ipv4': [], 'ipv6': []}
    _current_if['flags'] = '1e084863'
    _expected_current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                            'flags': '1e084863', 'macaddress': 'unknown'}
    _result = AIXNetwork().parse_

# Generated at 2022-06-22 23:43:33.947483
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert(AIXNetwork(module).platform == 'AIX')


# Generated at 2022-06-22 23:43:40.367787
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    test_aix_net = AIXNetwork()

    test_aix_net.module.run_command = my_run_command

    test_aix_net.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')

    print(result_interfaces_info)

    print('\n')
    print(result_ips)


# Generated at 2022-06-22 23:43:52.217889
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    mac0 = '01:23:45:67:8a:bc'
    mac1 = '0a:b1:ce:d6:f7:89'
    ip0 = '192.168.0.1'
    ip1 = '192.168.0.2'
    ip2 = '192.168.0.3'
    ip3 = '192.168.0.4'
    ip6_0 = '2620:106:700::100'
    ip6_1 = '2620:106:700::101'
    ip6_2 = '2620:106:700::102'
    ip6_3 = '2620:106:700::103'
    ip6_4 = '2620:106:700::104'
    ip6_5 = '2620:106:700::105'


# Generated at 2022-06-22 23:43:58.246961
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from io import StringIO

# Generated at 2022-06-22 23:44:04.670639
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    # Instance of class AIXNetwork
    aix_network_instance = AIXNetwork()
    # Check if route_path returns the correct path
    assert '/usr/sbin/route' == aix_network_instance.route_path
    # Check if route6_path returns the correct path
    assert '/usr/sbin/route' == aix_network_instance.route6_path
    # Check if platform returns the correct value
    assert 'AIX' == aix_network_instance.platform


# Test case for ifconfig line parser in AIXNetwork

# Generated at 2022-06-22 23:44:10.527386
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    ifc_test = AIXNetwork()

    ifconfig_path = ifc_test.module.get_bin_path('ifconfig')

    (interfaces, ips) = ifc_test.get_interfaces_info(ifconfig_path)

    assert isinstance(interfaces, dict)

    for i in interfaces:
        for j in interfaces[i]:
            assert isinstance(interfaces[i][j], (str, list))
            if isinstance(interfaces[i][j], list):
                for k in interfaces[i][j]:
                    assert isinstance(k, str)
    assert isinstance(ips, dict)

# Generated at 2022-06-22 23:44:11.914679
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    expected = 'AIX'
    result = AIXNetworkCollector._platform
    assert result == expected

# Generated at 2022-06-22 23:44:18.311632
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    ipv4, ipv6 = AIXNetwork(module).get_default_interfaces("path")
    assert ipv4['gateway'] == '192.168.1.1'
    assert ipv4['interface'] == 'en0'
    assert ipv6['gateway'] == 'fe80::2'
    assert ipv6['interface'] == 'en3'



# Generated at 2022-06-22 23:44:22.786741
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_facts = AIXNetworkCollector()
    _fact_class = network_facts._fact_class
    _platform = network_facts._platform
    assert _fact_class == AIXNetwork
    assert _platform == 'AIX'

# Generated at 2022-06-22 23:44:34.472256
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    def test_get_default_interfaces_gateway_for_ipv4_exists():
        collector = AIXNetwork()

        route_path = '/usr/sbin/route'
        expected_result = {'gateway': '172.17.0.1', 'interface': 'en0'}

        result = collector.get_default_interfaces(route_path)

        assert expected_result is result[0], "test_get_default_interfaces_gateway_for_ipv4_exists() has failed!"

    def test_get_default_interfaces_gateway_for_ipv4_not_exists():
        collector = AIXNetwork()

        route_path = '/usr/sbin/netstat'

# Generated at 2022-06-22 23:44:44.526207
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = dict()
    AIXNetworkCollector(ansible_module).populate()

    assert isinstance(ansible_module.params['network'], dict) is True
    assert 'all_ipv4_addresses' in ansible_module.params['network']
    assert 'all_ipv6_addresses' in ansible_module.params['network']


try:
    from ansible.module_utils.ansible_nios_module import AnsibleModule
except ImportError:
    AnsibleModule = None

if __name__ == '__main__':
    test_AIXNetworkCollector()

# Generated at 2022-06-22 23:44:45.525763
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    AIXNetworkCollector()



# Generated at 2022-06-22 23:44:48.547448
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class.platform == 'AIX'



# Generated at 2022-06-22 23:44:49.865287
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert isinstance(AIXNetwork(), AIXNetwork)


# Generated at 2022-06-22 23:45:01.479796
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:45:09.807481
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    '''Unit test for constructor of class AIXNetwork'''
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetworkCollector(module)
    network_collector.collect()
    # print network_collector.get_device_to_ip_type()
    # print network_collector.get_device_to_ip()
    # print network_collector.get_interfaces()


from ansible.module_utils.basic import *  # noqa

if __name__ == '__main__':
    test_AIXNetwork()

# Generated at 2022-06-22 23:45:16.720740
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    module.params = {}
    test_object = AIXNetwork(module)
    assert test_object.parse_interface_line(['en0:']) == {
        'device': 'en0',
        'flags': [],
        'ipv4': [],
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'unknown'}



# Generated at 2022-06-22 23:45:26.566910
# Unit test for constructor of class AIXNetwork