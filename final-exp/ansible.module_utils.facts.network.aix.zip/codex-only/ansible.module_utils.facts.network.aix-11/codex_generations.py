

# Generated at 2022-06-22 23:35:24.235665
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = DummyModule()
    network_collector = AIXNetworkCollector(module=module)
    network_collector.facts['virtualization'] = None

    route_path = network_collector.module.get_bin_path('route')

    ifconfig_path = network_collector.module.get_bin_path('ifconfig')

    # Use ifconfig not found.
    ifconfig_path = None

    # Use netstat not found.
    netstat_path = None

    if config_present_AIX_netstat_route(network_collector, route_path, ifconfig_path):
        interfaces_v4, interfaces_v6 = network_collector.facts.get('default_ipv4'), network_collector.facts.get('default_ipv6')

# Generated at 2022-06-22 23:35:29.534179
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the constructor of AIXNetworkCollector class
    """
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector

    aixnc = AIXNetworkCollector()
    assert isinstance(aixnc, NetworkCollector)


# Generated at 2022-06-22 23:35:36.605929
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    AIXNetworkCollector.set_module(module)

    # initialize
    results = dict(
        ansible_facts=dict(
            ansible_net_interfaces={},
            ansible_net_all_ipv4_addresses=[],
            ansible_net_all_ipv6_addresses=[],
            ansible_net_default_ipv4={},
            ansible_net_default_ipv6={},
            ansible_net_default_interface_ipv4={},
            ansible_net_default_interface_ipv6={},
            ansible_net_gather_subset=['default'],
        )
    )

    interface, interface6 = AIXNetworkCollect

# Generated at 2022-06-22 23:35:39.625732
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetwork(module)
    assert network_collector.platform == 'AIX'



# Generated at 2022-06-22 23:35:46.399993
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    interface_words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '10.65.30.122', 'netmask', '0xffffff00', 'broadcast', '10.65.30.255']
    returned_interface = AIXNetwork().parse_interface_line(interface_words)
    assert returned_interface['device'] == interface_words[0][0:-1]
    assert returned_interface['type'] == 'unknown'

# Generated at 2022-06-22 23:35:56.589155
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:36:08.511714
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test the base class constructor __init__()
    """
    # Test with default arguments
    nc = AIXNetworkCollector()
    assert nc

    # Test with provided arguments
    nc = AIXNetworkCollector(gather_subset=None,
                             gather_network_resources=None,
                             min_platform_version=None,
                             min_network_platform_version=None,
                             localhost_facts=None,
                             transform_func=None,
                             valid_func=None,
                             config_func=None,
                             fact_class=AIXNetwork,
                             platform=None)
    assert nc

    # Test with provided arguments

# Generated at 2022-06-22 23:36:11.420149
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class == AIXNetwork
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:36:16.430780
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork()
    assert aix_network.platform == 'AIX'
    assert isinstance(aix_network, AIXNetwork)
    assert isinstance(aix_network, GenericBsdIfconfigNetwork)

# Generated at 2022-06-22 23:36:26.122565
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})

    # test get_interfaces_info
    cmd1 = module.params['ifconfig_path'] = "/usr/bin/ifconfig"
    cmd2 = module.params['route_path'] = "/usr/bin/route"
    module.run_command = MagicMock(return_value=(0, AIX_IFACE_SUCCESS, ""))
    ifc = AIXNetwork(module)

    assert len(ifc.interfaces) == 5
    ifc.get_interfaces_info(cmd1)
    assert ifc.interfaces['en2']['ipv4'][0]['address'] == '192.168.246.21'
    assert ifc.interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-22 23:36:28.777340
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    collector = AIXNetworkCollector()
    assert collector is not None
    assert collector._fact_class == AIXNetwork
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:36:40.505951
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts import FactCollector
    import sys
    mynetwork = AIXNetwork()
    output=mynetwork.get_interfaces_info('/usr/sbin/ifconfig','-a')
    for interface in output[0].keys():
        if interface == 'lo0':
            assert output[0][interface]['device'] == 'lo0'
            assert output[0][interface]['ipv4'] == ['127.0.0.1']
            assert output[0][interface]['ipv6'] == ['::1']
            assert output[0][interface]['type'] == 'Loopback'
            assert output[0][interface]['flags'] == ['UP', 'RUNNING', 'LOOPBACK', 'MULTICAST']

# Generated at 2022-06-22 23:36:46.132267
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_class = AIXNetwork()
    test_line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    output = test_class.parse_interface_line(test_line.split())
    assert 'device' in output
    assert 'flags' in output
    assert 'mtu' not in output
    assert 'macaddress' in output
    assert 'type' in output

# Generated at 2022-06-22 23:36:54.474617
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    current_if = dict()
    network = AIXNetwork()
    words = ['en0:','flags=842<BROADCAST,RUNNING,MULTICAST>','mtu','1492']
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert 'mtu' not in current_if


# Generated at 2022-06-22 23:37:05.488799
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class AIXNetwork
    """
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
    )
    collector = NetworkCollector(module=module, platform='AIX')
    interfaces, ips = collector.get_interfaces_info('/bin/ifconfig')
    assert interfaces['en0']['flags'] == ['BROADCAST', 'UP', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'AUTOMEDIA']
    assert interfaces['en0']['mtu'] == '1500'

# Generated at 2022-06-22 23:37:17.357772
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )

    aix_network_collector = AIXNetworkCollector(test_module)
    aix_network_collector.collect()
    interfaces = aix_network_collector.collector.interfaces
    if 'default_ipv4' in interfaces and 'default_ipv6' in interfaces:
        assert interfaces['default_ipv4']['interface'] == 'en0'
        assert interfaces['default_ipv4']['gateway'] == '10.10.10.1'
        assert interfaces['default_ipv6']['interface'] == 'en0'

# Generated at 2022-06-22 23:37:23.829938
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    fixture = AIXNetwork(dict(module=None, params=None))

    result = fixture.get_default_interfaces('/usr/sbin/netstat')

    assert result == (
        {'interface': 'en0', 'gateway': '192.168.1.1'},
        {'interface': 'en1', 'gateway': 'fe80::202:e3ff:fe14:1102'},
    )


# Generated at 2022-06-22 23:37:33.130108
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    iface = AIXNetwork()
    current_if = iface.parse_interface_line(['lo0:'])
    assert(current_if['device'] == 'lo0')
    assert(current_if['flags'] == [])
    assert(current_if['macaddress'] == 'unknown')
    assert(current_if['type'] == 'unknown')

    current_if = iface.parse_interface_line(['lo0:', 'flags=849c3'])
    assert(current_if['device'] == 'lo0')
    assert(current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING'])
    assert(current_if['macaddress'] == 'unknown')
    assert(current_if['type'] == 'unknown')


# Generated at 2022-06-22 23:37:43.381110
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    # Prepare the object to test
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    o = AIXNetwork(module)

    # Prepare test data; this is what ifconfig reports

# Generated at 2022-06-22 23:37:54.601546
# Unit test for method parse_interface_line of class AIXNetwork

# Generated at 2022-06-22 23:37:56.642033
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    n = AIXNetwork()

    assert n.platform == 'AIX'

# Generated at 2022-06-22 23:38:05.653977
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    ifconfig_path = '/usr/sbin/ifconfig'
    route_path = '/usr/bin/netstat'
    facts = AIXNetworkCollector(None, ifconfig_path, route_path).collect()

    assert facts['default_ipv4']['interface'] is not None, 'Interface for default IPv4 route not found'
    assert facts['default_ipv4']['gateway'] is not None, 'Gateway for default IPv4 route not found'
    assert facts['default_ipv6']['interface'] is not None, 'Interface for default IPv6 route not found'
    assert facts['default_ipv6']['gateway'] is not None, 'Gateway for default IPv6 route not found'

# Generated at 2022-06-22 23:38:16.943000
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = 'fake'
    cmd = ['/bin/ifconfig', '-a']
    test_obj = AIXNetwork(module)
    words = 'en0: flags=0x10008d<BROADCAST,RUNNING,MULTICAST,POINTOPOINT,IPv4>'.split()
    current_if = test_obj.parse_interface_line(words)
    expected = {
        'device': 'en0',
        'mtu': 0,
        'flags': ['BROADCAST', 'RUNNING', 'MULTICAST', 'POINTOPOINT', 'IPv4'],
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }
    assert(current_if == expected)

# Generated at 2022-06-22 23:38:29.326971
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    fakemodule = AnsibleModule(argument_spec={})
    fakeensure_dir_path = '/fake/path'
    fakemodule.get_bin_path = MagicMock(return_value=fakeensure_dir_path)
    aix_network = AIXNetwork(fakemodule)

    # test an interface line from AIX
    #  lo0: flags=8001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 7
    words = ['lo0:', 'flags=8001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '7']
    current_if = aix_network.parse_interface_line(words)

# Generated at 2022-06-22 23:38:38.783208
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import os
    import random
    import string
    import tempfile

    test_data_path = os.path.join(os.path.dirname(__file__), 'test_data')
    ifconfig_path = os.path.join(test_data_path, 'ifconfig_a.AIX.test.txt')
    if not os.path.isfile(ifconfig_path):
        ifconfig_path = os.path.join(test_data_path, 'ifconfig_a.AIX.txt')
    if not os.path.isfile(ifconfig_path):
        ifconfig_path = os.path.join(test_data_path, 'ifconfig_a.test.txt')

# Generated at 2022-06-22 23:38:41.880701
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    facts = AIXNetworkCollector()
    result = type(facts.get_facts())
    assert result == dict

# Generated at 2022-06-22 23:38:52.308721
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Constructor test of class AIXNetwork
    """

    import io

    interface_output = '''
en0: flags=5e080863,c0<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN>
        inet 10.10.10.10 netmask 0xffffff00 broadcast 10.10.10.255
        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
        media: Ethernet autoselect (100baseTX <full-duplex>)
        status: active
        lladdr 00:11:22:33:44:55
'''


# Generated at 2022-06-22 23:38:55.059296
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork()
    assert net.get_default_interfaces('route') == ({}, {})

# Generated at 2022-06-22 23:39:05.558238
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mock_module = Mock()
    mock_module.get_bin_path.return_value = '/usr/sbin/netstat'

    mock_rc = Mock()
    mock_out = Mock()
    mock_err = Mock()
    mock_module.run_command.return_value = (mock_rc, mock_out, mock_err)


# Generated at 2022-06-22 23:39:09.956356
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec=dict(
            route_path=dict(
                type='str',
                default='/usr/sbin/route'
            )
        )
    )

    test_network = AIXNetwork(test_module)
    results = test_network.get_default_interfaces(route_path='/usr/sbin/route')
    assert len(results) == 2

    test_module = AnsibleModule(
        argument_spec=dict(
            route_path=dict(
                type='str',
                default='/usr/sbin/route'    # no route executable in Ansible test environment
            )
        )
    )

    test_network = AIXNetwork(test_module)

# Generated at 2022-06-22 23:39:13.812333
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.aix import AIXNetwork

    aix = AIXNetwork()
    aix.get_interfaces_info(ifconfig_path='/usr/bin/ifconfig')


# Generated at 2022-06-22 23:39:15.494827
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector().platform == 'AIX'
    assert AIXNetworkCollector()._fact_class == AIXNetwork


# Generated at 2022-06-22 23:39:20.799538
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    ifc_path = '/usr/sbin/ifconfig'
    ifc_options = '-a'
    module = type('AnsibleModule', (object, ), {'params': dict(), 'run_command': type('RC', (object, ), {'returncode': 0})(), 'get_bin_path': lambda x: ifc_path})

    collector = AIXNetworkCollector(module=module)
    interface_info, ips = collector.collect()

    assert interface_info['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interface_info['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-22 23:39:23.432457
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModuleMock()
    network_module = AIXNetworkCollector(module)
    assert network_module.platform == 'AIX'

# Generated at 2022-06-22 23:39:31.956011
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = NetworkCollector._create_ansible_module()

    an = AIXNetwork(module)

    # testing with the following input
    words = ['en0:', 'flags=20100000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'metric', '0']

    current_if = an.parse_interface_line(words)

    # now test the results
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4', 'CoS']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:39:41.940756
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    test_object = AIXNetwork
    test_ifconfig_path = '/usr/sbin/ifconfig'
    test_ifconfig_options = '-a'
    test_string_line1 = "en0: flags=1e080863,401<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>\n"
    test_string_line2 = "        inet 10.10.10.11 netmask 0xffffff00 broadcast 10.10.10.255\n"

    interfaces_dict_expected = {}
    ips_dict_expected = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    interface

# Generated at 2022-06-22 23:39:53.694100
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import os
    import socket
    
    class MockModule(object):
        def __init__(self, params):
            pass
        def get_bin_path(self, path):
            return os.path.join('aix', 'bin', path)
        def run_command(self, command):
            if command[0] == os.path.join('aix', 'bin', 'ifconfig'):
                return (0, file('aix/ifconfig.aix7.2').read(), None)

# Generated at 2022-06-22 23:40:04.626292
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():

    network = AIXNetwork()
    words = ['en1:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500', 'index=2']
    expected = {'device': 'en1', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'macaddress': 'unknown'}
    returned = network.parse_interface_line(words)
    assert returned == expected

    # without flags in line
    words = ['en1:', 'mtu=1500', 'index=2']

# Generated at 2022-06-22 23:40:15.997429
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    """
    Test if the parse_interface_line of AIXNetwork works properly
    """

    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.exit_json = exit_json

    network_collector = AIXNetworkCollector(ansible_module=ansible_module)

    ifnetwork = AIXNetwork(ansible_module=ansible_module)
    words = ["en0:", "UP", "BROADCAST,", "NOTRAILERS,", "RUNNING,", "SIMPLEX,", "MULTICAST,", "Addr:192.168.1.1"]


# Generated at 2022-06-22 23:40:23.826837
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork()

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # test generic_bsd_ifconfig_network
    words = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384'
    current_if = generic_bsd_ifconfig_network.parse_interface_line(words.split())

# Generated at 2022-06-22 23:40:35.468609
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:40:45.517608
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    class DummyModule(object):

        def __init__(self):
            self.params = dict()

            self.params['ansible_module_generated'] = dict()
            self.params['ansible_module_generated']['command'] = '/usr/bin/env'
            self.params['ansible_module_generated']['options'] = dict()
            self.params['ansible_module_generated']['options']['chdir'] = '/tmp'
            self.params['ansible_module_generated']['options']['creates'] = None
            self.params['ansible_module_generated']['options']['executable'] = None
            self.params['ansible_module_generated']['options']['removes'] = None

# Generated at 2022-06-22 23:40:55.592042
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = object
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')

    aixnetwork = AIXNetwork(module)

    current_if = aixnetwork.parse_interface_line(['en0:', 'flags=', '842<UP,BROADCAST,RUNNING,MULTICAST>', 'metric=1', 'mtu=1500', 'ether', 'f0:e2:82:52:8a:a3'])
    assert current_if['device'] == 'en0'
    assert current_if['macaddress'] == 'f0:e2:82:52:8a:a3'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-22 23:41:07.464326
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit test for method AIXNetwork.get_interfaces_info"""

    # Test on AIX Network class
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    # Create a AIXNetwork object to run unit tests on method get_interfaces_info
    myAIXNetwork = AIXNetwork(None)
    myAIXNetwork.module.run_command = run_command_mock

    # Test when 'rc' is 0 for command 'ifconfig -a'

# Generated at 2022-06-22 23:41:18.736615
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils.facts.network.aix import AIXNetwork


    class TestGetDefaultInterfaces(unittest.TestCase):
        def setUp(self):
            self.aix_network = AIXNetwork()
            self.aix_network.module = MagicMock()

            self.aix_network.module.get_bin_path.return_value = '/usr/bin/netstat'

# Generated at 2022-06-22 23:41:24.098940
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    network_collector = NetworkCollector()
    aix_network_collector = AIXNetworkCollector()
    assert isinstance(aix_network_collector, NetworkCollector)

# Generated at 2022-06-22 23:41:32.734783
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    # When AIXNetworkCollector is instantiated with no facts,
    # it should have no facts yet.
    assert not AIXNetworkCollector().facts
    # It should also have no facts when it is instantiated with
    # a dict with a key that is not platform.
    assert not AIXNetworkCollector(dict(not_platform='AIX')).facts
    # It should have a dict of facts when it is instantiated with
    # a dict with a key platform and a value of AIX
    platform_facts = dict(platform='AIX', ansible_facts={})
    assert AIXNetworkCollector(platform_facts).facts == {}

# Generated at 2022-06-22 23:41:38.312978
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    class AIXNetworkMock(AIXNetwork):
        def __init__(self, module):
            super(AIXNetworkMock, self).__init__(module)

            def run_command(self, command):
                return 0, "default    0.0.0.0          UG        0 0          en1\ndefault    192.168.122.1      UG        0 0          en0\ndefault    fe80::%en1      UG        0 0          en1\ndefault    fe80::%en0      UG        0 0          en0", ""


# Generated at 2022-06-22 23:41:48.736038
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = {}
    result['ansible_facts'] = {}
    result['ansible_facts']['ansible_network_resources'] = {}
    result['ansible_facts']['ansible_network_resources']['interfaces'] = {}
    result['ansible_facts']['ansible_network_resources']['default_interface'] = {}
    result['ansible_facts']['ansible_network_resources']['default_ipv4'] = {}
    result['ansible_facts']['ansible_network_resources']['default_ipv6'] = {}
    net = AIXNetwork(module)

# Generated at 2022-06-22 23:42:00.403494
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_class = AIXNetwork()
    test_input = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>']
    test_output = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN'], 'macaddress': 'unknown'}


# Generated at 2022-06-22 23:42:08.438830
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()
    assert obj.platform == 'AIX'
    assert obj.facts is None
    assert obj.fact_class._platform == 'AIX'
    assert obj.fact_class.platform == 'AIX'
    assert obj.fact_class.__module__ == 'ansible_collections.ansible.community.plugins.module_utils.facts.network.aix.AIXNetwork'
    assert obj.fact_class.__name__ == 'AIXNetwork'
    assert obj.conditions == []

# Generated at 2022-06-22 23:42:17.509698
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_obj = AIXNetwork({})
    test_obj.module = MagicMock()

# Generated at 2022-06-22 23:42:19.848219
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec={})
    network = AIXNetwork(module)
    assert network.platform == 'AIX'

# Generated at 2022-06-22 23:42:20.475487
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    pass

# Generated at 2022-06-22 23:42:24.821227
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Unit test for constructor of class AIXNetwork
    """
    ifc = AIXNetwork({}, {}, {})
    assert ifc.platform == 'AIX'


# Generated at 2022-06-22 23:42:25.811671
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    mod = AnsibleModule(argument_spec=dict())

    net = AIXNetwork(mod)
    assert net.platform == 'AIX'


# Generated at 2022-06-22 23:42:32.843455
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    my_obj = AIXNetworkCollector()
    assert my_obj
    assert isinstance(my_obj, NetworkCollector)
    assert isinstance(my_obj._fact_class, AIXNetwork)
    assert my_obj._platform == 'AIX'
    assert my_obj.legacy_facts == dict()
    assert my_obj.facts == dict()

# Unit tests for methods of class AIXNetwork

# Generated at 2022-06-22 23:42:34.682285
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert isinstance(AIXNetworkCollector(), AIXNetworkCollector), 'test failed: constructor of class AIXNetworkCollector'


# Generated at 2022-06-22 23:42:42.592590
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    assert module.facts['default_ipv4']['interface'] == 'en0'
    assert module.facts['default_ipv6']['interface'] == 'en0'
    assert module.facts['default_ipv4']['gateway'] == '172.17.2.1'
    assert module.facts['default_ipv6']['gateway'] == 'fe80::21e:67fff:fe74:57d0%en0'

# Generated at 2022-06-22 23:42:45.357644
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    fact_subclass = AIXNetwork()
    assert fact_subclass
    assert fact_subclass.platform == 'AIX'

# Generated at 2022-06-22 23:42:57.446769
# Unit test for constructor of class AIXNetwork

# Generated at 2022-06-22 23:43:04.937294
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    class Options: pass
    class Module:
        def __init__(self):
            self.options = Options()

        def fail_json(self, *args, **kwargs):
            raise RuntimeError(args[0])

        def get_bin_path(self, arg):
            return '/usr/bin/' + arg

        def run_command(self, arg):
            if arg[0] == '/usr/bin/netstat':
                return 0, "route to:default\n10.0.0.0         10.0.0.100        UG        0 3     1  ent0\n::/0        ::1        UGRS        0 1      32768 lo0\n", ''
            else:
                return 255, "command not found", ''
    module = Module()
    iface = AIXNetwork(module)


# Generated at 2022-06-22 23:43:15.438880
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''
    This function tests the method get_interfaces_info of class AIXNetwork
    '''

    # Initialize data
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

    # Initialize test object
    aix_network = AIXNetwork()

    # Test first run case
    interfaces, _ = aix_network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces.keys()
    assert 'en1' in interfaces.keys()
    assert 'lo0' in interfaces.keys()
    assert 'app0' in interfaces.keys()
    assert 'app1' in interfaces.keys()
    assert 'ct0' in interfaces.keys()
    assert 'ct1' in interfaces.keys()

# Generated at 2022-06-22 23:43:27.022478
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.aix import AIXNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # create object of class AIXNetworkCollector
    obj = AIXNetworkCollector()

    # check object type
    assert isinstance(obj, AIXNetworkCollector)

    # check bases of object
    assert issubclass(AIXNetworkCollector, NetworkCollector)
    assert issubclass(AIXNetworkCollector, GenericBsdIfconfigNetwork)

    # check attributes of object
    assert obj._platform == 'AIX'
    assert obj._fact_class == AIXNetwork


# Generated at 2022-06-22 23:43:38.784090
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    words = ['en0: flags=8e0842<UP,BROADCAST,RUNNING,MULTICAST,IPv6,NOINET6>','metric 2','family inet mtu 1500']
    an = AIXNetwork({})
    current_if = an.parse_interface_line(words)
    assert current_if['macaddress'] == 'unknown'
    assert current_if['flags'] == 'UP,BROADCAST,RUNNING,MULTICAST,IPv6,NOINET6'
    assert current_if['device'] == 'en0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
   

# Generated at 2022-06-22 23:43:50.677517
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True)

    # create ifconfig path
    ifconfig_path = os.path.join(os.path.dirname(__file__), '../../fixtures/sample_ifconfig_aix')
    shutil.copyfile(os.path.join(os.path.dirname(__file__), '../../fixtures/sample_ifconfig_aix'), ifconfig_path)

    # create netstat path
    netstat_path = os.path.join(os.path.dirname(__file__), '../../fixtures/sample_netstat_aix')

# Generated at 2022-06-22 23:43:52.259290
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector.get_platform_module('AIX')
    assert module.platform == 'AIX'


# Generated at 2022-06-22 23:43:53.520732
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    a = AIXNetwork()



# Generated at 2022-06-22 23:43:57.210589
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test AIXNetworkCollector.
    """
    assert AIXNetworkCollector._platform == 'AIX'
    assert AIXNetworkCollector._fact_class is AIXNetwork



# Generated at 2022-06-22 23:44:05.455268
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # initialise with fake module (nonexisting ifconfig -a)
    aix_network = AIXNetwork(dict(ANSIBLE_MODULE_ARGS=''))
    words = 'lo0: flags=2001000849 mtu 8232 index 1'.split()
    current_if = aix_network.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['2', '0', '0', '1', '0', '0', '0', '849']
    assert current_if['mtu'] is None
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:44:13.749167
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork(module=None)

    words = [
        'en0:',
        'flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>',
        'inet 10.0.131.66 netmask 0xfffff800 broadcast 10.0.143.255',
        'ether 00:1a:a0:52:c0:00'
    ]

    current_if = aix_network.parse_interface_line(words)

# Generated at 2022-06-22 23:44:23.646441
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    modules = 'ansible.module_utils.facts.network.generic_bsd'
    with AnsibleRunnerMock({modules: {}}):
        network = AIXNetwork()
        current_if = network.parse_interface_line(['en0:'])
        assert set(current_if.keys()) == set(['device', 'ipv4', 'ipv6', 'macaddress', 'type', 'flags'])
        assert current_if['device'] == 'en0'
        assert current_if['type'] == 'unknown'
        assert current_if['macaddress'] == 'unknown'
        assert current_if['flags'] == ['']



# Generated at 2022-06-22 23:44:35.612997
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    # utility function
    def flatten(d, parent_key='', sep='.'):
        items = []
        for k, v in d.items():
            new_key = parent_key + sep + k if parent_key else k
            if isinstance(v, collections.MutableMapping):
                items.extend(flatten(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)

    # utility function

# Generated at 2022-06-22 23:44:46.069718
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        "gather_subset": dict(default=['!all'], type='list')
    })

    aix_network = AIXNetwork(module)
    aix_network.get_interfaces_info('/usr/sbin/ifconfig', ifconfig_options='-a')

# Generated at 2022-06-22 23:44:56.197434
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = FakeModule()
    plugin = AIXNetwork(module=module)
    module.run_command = fake_run_command
    module.params = {}
    result = plugin.get_default_interfaces()
    # test with output from fake_run_command
    assert result == ({'gateway': '192.168.250.1', 'interface': 'en0'}, {'gateway': 'fe80::1', 'interface': 'en0'})
    # test with output from fake_run_command_empty
    module.run_command = fake_run_command_empty
    result = plugin.get_default_interfaces()
    assert result == ({}, {})


# Generated at 2022-06-22 23:44:59.080065
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Constructor of class AIXNetworkCollector can be called.
    """
    AIXNetworkCollector()
    assert True

# Generated at 2022-06-22 23:45:05.839792
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    interface_name = 'lo'
    module = AnsibleModuleMock()

    # Test constructor of class AIXNetwork with existing interface
    assert AIXNetwork(module, interface_name) is not None

    # Test constructor of class AIXNetwork with missing interface
    interface_name = 'foobar'
    try:
        AIXNetwork(module, interface_name)
        assert False
    except:
        assert True

# Generated at 2022-06-22 23:45:09.663107
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Unit test for constructor of class AIXNetworkCollector """
    fact_class = AIXNetworkCollector()
    assert fact_class._fact_class == AIXNetwork
    assert fact_class._platform == 'AIX'


# Generated at 2022-06-22 23:45:21.403742
# Unit test for method parse_interface_line of class AIXNetwork