

# Generated at 2022-06-22 23:35:22.140497
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    obj = AIXNetworkCollector()

    assert obj._platform == 'AIX'
    assert hasattr(obj, '_fact_class')
    assert obj._fact_class == AIXNetwork


# Generated at 2022-06-22 23:35:34.294586
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    class TestAIXNetwork(unittest.TestCase):
        def setUp(self):
            self.mock_module = basic.AnsibleModule(
                argument_spec={}
            )
            self.test_object = AIXNetwork(self.mock_module)

        def tearDown(self):
            pass

        def test_get_interfaces_info(self):
            test_val = self.test_object.get_interfaces_info

# Generated at 2022-06-22 23:35:45.572735
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_module = AIXNetwork(module)

    words = ['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500',
             'index', '2', 'inet', '192.168.0.2', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    if_dict = dict(device='en0', ipv4=[], ipv6=[], type='unknown')
    if_dict['flags'] = network_module.get_options(words[1])
    if_dict['macaddress'] = 'unknown'
    assert network_module.parse_interface_line

# Generated at 2022-06-22 23:35:55.962243
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    ''' unit test for method get_default_interfaces of class AIXNetwork '''

    test_class = AIXNetworkCollector


# Generated at 2022-06-22 23:36:04.613027
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test = AIXNetwork(None)
    line = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>'
    words = line.split()
    current_if = test.parse_interface_line(words)
    assert current_if['device'] == 'en0'



# Generated at 2022-06-22 23:36:14.088591
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # test1
    routes = [['default','10.0.3.254','UG','0','0','en1'],
              ['default','10.0.0.1','UG','0','0','en1'],
              ['10.0.3.0','10.0.3.254','UH','0','0','en1'],
              ['10.0.0/24','10.0.0.1','UG','0','0','en0'],
              ['default','fe80::%lo0/64','U','0','0','lo0']]
    expected = {'v4': {'gateway': '10.0.3.254', 'interface': 'en1'},
                'v6': {'gateway': 'fe80::%lo0/64', 'interface': 'lo0'}}
    net

# Generated at 2022-06-22 23:36:24.686463
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Test of method get_interfaces_info of class AIXNetwork"""
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    ifc = AIXNetwork(module)

    ifconfig_path = ifc.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = ifc.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert 'en0' in interfaces
    assert 'en0' in ips['all_ipv4_addresses']
    assert 'en0' in ips['all_ipv4_interfaces']
    assert interfaces['en0']['device'] == 'en0'
    assert interfaces['en0']['ipv4'][0]['address']

# Generated at 2022-06-22 23:36:27.522461
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    """
    Unit test for class AIXNetwork.
    :return:
    """
    network_collector = AIXNetworkCollector()
    fact_class = network_collector.collect()
    assert isinstance(fact_class, AIXNetwork)

# Generated at 2022-06-22 23:36:32.648328
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork.platform == 'AIX'

    net_facts = AIXNetwork()
    assert net_facts.platform == 'AIX'

    res = net_facts.get_default_interfaces('/sbin/route')
    assert 'gateway' in res[0] and res[0]['gateway']
    assert 'interface' in res[0] and res[0]['interface']
    assert 'gateway' in res[1] and res[1]['gateway']
    assert 'interface' in res[1] and res[1]['interface']

# Generated at 2022-06-22 23:36:43.402779
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    from mock import MagicMock
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import os

    # Define mock inputs
    module = MagicMock()
    module.run_command.return_value = (0, get_file_lines(os.path.join(os.path.dirname(__file__), 'aix_ifconfig_a.txt')), None)
    module.get_bin_path.return_value = '/usr/sbin/ifconfig'
    module.exit_json.return_value = None
    module.fail_json.return_value = None

    # Define return values for the method get_interfaces_info

# Generated at 2022-06-22 23:36:55.206349
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    fake_ifconfig_path = '/tmp/ifconfig.AIX'

# Generated at 2022-06-22 23:36:59.465298
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    assert AIXNetwork(True).platform == 'AIX'
    assert AIXNetwork(True)._fact_class == AIXNetwork
    assert AIXNetworkCollector(True)._platform == 'AIX'
    assert AIXNetworkCollector(True)._fact_class == AIXNetwork

# Generated at 2022-06-22 23:37:02.106207
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = NetworkCollector()
    obj = AIXNetwork(module)
    assert obj.platform == 'AIX'
    assert isinstance(obj.interfaces, dict)

# Generated at 2022-06-22 23:37:04.783906
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    collector = AIXNetworkCollector()
    assert collector._platform == 'AIX'
    assert collector._fact_class.platform == 'AIX'

# Generated at 2022-06-22 23:37:10.433381
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces python module required for this module')

    if not HAS_PYROUTE2:
        module.fail_json(msg='pyroute2 python module required for this module')

    if not HAS_NETADDR:
        module.fail_json(msg='netaddr python module required for this module')

    collector = AIXNetworkCollector(module)
    assert collector._fact_class == AIXNetwork



# Generated at 2022-06-22 23:37:21.567445
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    m = dict(
        ANSIBLE_MODULE_ARGS=dict(
            gather_subset='all',
            gather_timeout=10
        )
    )

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, msg, **kwargs):
            self.exit_args = dict(msg=msg, **kwargs)
            self.exit_called = True

        def exit_json(self, **kwargs):
            self.exit_args = dict(**kwargs)
            self.exit_called = True

        def run_command(self, cmd):
            cmd_string = ' '.join(cmd)
            self.commands.append(cmd_string)

# Generated at 2022-06-22 23:37:27.211047
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    result = AIXNetwork().parse_interface_line(['en0','flags=39','UP','BROADCAST'])
    assert result['device'] == 'en0'
    assert result['flags'][0] == 'UP'
    assert result['flags'][1] == 'BROADCAST'
    assert result['macaddress'] == 'unknown'
    assert result['type'] == 'unknown'

# Generated at 2022-06-22 23:37:32.576538
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    target_obj = AIXNetwork()
    target_str = 'en0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500'
    words = target_str.split()
    current_if = target_obj.parse_interface_line(words)
    assert current_if['device'] == 'en0'


if __name__ == '__main__':
    test_AIXNetwork_parse_interface_line()

# Generated at 2022-06-22 23:37:40.161677
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """ Unit test for constructor of class AIXNetworkCollector. """

    collector = AIXNetworkCollector()
    assert collector
    assert isinstance(collector, NetworkCollector)
    assert hasattr(collector, '_fact_class')
    assert collector._fact_class is AIXNetwork
    assert hasattr(collector, '_platform')
    assert collector._platform == 'AIX'

# Generated at 2022-06-22 23:37:41.750811
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    n = AIXNetwork()
    assert(n.platform == 'AIX')


# Generated at 2022-06-22 23:37:53.645498
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Default interfaces is the one that has the default gateway

    When IPv6 is enabled and IPv6 interface exists, the IPv6 interface is selected
    as default interface.
    """


# Generated at 2022-06-22 23:38:04.616565
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command = self._run_command


# Generated at 2022-06-22 23:38:06.497126
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    NetworkCollector._platform = 'AIX'
    AIXNetworkCollector()

# Generated at 2022-06-22 23:38:10.603940
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = None
    aix_network = AIXNetwork(module)
    assert aix_network.platform == 'AIX'
    assert aix_network.ifconfig_path == '/usr/sbin/ifconfig'
    assert aix_network._facts == dict()


# Generated at 2022-06-22 23:38:20.470684
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    input_line = 'en0: flags=ee0a863<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),PSEG,LARGESEND,CHAIN> mtu 1500 index 2'
    input_words = input_line.split()
    current_if = AIXNetwork().parse_interface_line(input_words)

# Generated at 2022-06-22 23:38:29.948464
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork

    aix_net = AIXNetwork()
    current_if = aix_net.parse_interface_line(["en0:"], 'aix', 'AIX_7.2.0.0')

    assert current_if['device'] == 'en0'
    # flags are inherited from method get_options in class GenericBsdNetwork
    assert current_if['flags'] == list(GenericBsdNetwork.options)
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'


# Generated at 2022-06-22 23:38:38.421010
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_subject = AIXNetwork()
    test_words = ["en0:", "flags=1e084863,", "mtu", "1500"]
    test_result = test_subject.parse_interface_line(test_words)
    expected_result = {
        'device': "en0",
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
        'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST', 'GROUPRT', 'RUNNING', 'NOTRAILERS', 'INET6']
    }
    assert test_result == expected_result


# Generated at 2022-06-22 23:38:45.394985
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix.facts import AIXNetwork
    from ansible.module_utils.facts.network.aix.collector import AIXNetworkCollector

    # Check that we get back the class we expect
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._fact_class is AIXNetwork

# Generated at 2022-06-22 23:38:48.875405
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """
    Test AIXNetworkCollector by instantiating an object and check for attributes existence
    """
    my_obj = AIXNetworkCollector()
    assert my_obj._platform == 'AIX'
    assert my_obj._fact_class == AIXNetwork


# Generated at 2022-06-22 23:38:53.643617
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    # _factory_infos(command, platform, interface_options=None, ip_path=None, route_path=None, linux_distribution=None,
    #               ifconfig_path=None, static_routes=None, static_interfaces=None, use_ipv6=None, validate_ipv6_addresses=None,
    #               interface_driver=None, ignore_interfaces=None, netmask_format=None)

    test1 = AIXNetwork._factory_infos("", "AIX")

    assert test1.get_default_interfaces("netstat -nr") == ({'gateway': '10.0.0.1', 'interface': 'en0'},
                                                            {'gateway': 'fe80::1%lo0', 'interface': 'lo0'})

    test2

# Generated at 2022-06-22 23:39:04.753056
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    get_interfaces_info function
    """
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, name, required=False):
            return name


# Generated at 2022-06-22 23:39:14.131575
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    fact_class = AIXNetwork()

    # don't work in wpar
    uname_rc = None
    uname_out = None
    uname_err = None
    uname_path = fact_class.module.get_bin_path('uname')
    if uname_path:
        uname_rc, uname_out, uname_err = fact_class.module.run_command([uname_path, '-W'])

    if uname_rc:
        assert False
    else:
        if uname_out.split()[0] != '0':
            assert False

    interfaces, ips = fact_class.get_interfaces_info( fact_class.module.get_bin_path('ifconfig') )
    if not interfaces:
        assert False

# Generated at 2022-06-22 23:39:14.913651
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'


# Generated at 2022-06-22 23:39:25.405332
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    import sys
    import os
    import re
    import platform
    import pwd
    if platform.system() == 'AIX' and int(platform.release()) > 5:
        # check if we run with root privileges
        if os.getuid() != 0:
            print("need root privileges")
            sys.exit(1)
        # get the user's name
        username = pwd.getpwuid(os.getuid())[0]
        # check if user is root
        if username != 'root':
            print("need root privileges")
            sys.exit(1)
        # check if python version is 2 or 3
        if sys.version_info[0] < 3:
            import commands as subprocess
        else:
            import subprocess

# Generated at 2022-06-22 23:39:28.705590
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    """Test the constructor of the class AIXNetworkCollector"""
    aix_network_collector = AIXNetworkCollector(None, None)

    assert aix_network_collector is not None

# Generated at 2022-06-22 23:39:32.278969
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector.platform == 'AIX'
    assert AIXNetworkCollector._platform == 'AIX'

# Generated at 2022-06-22 23:39:37.783403
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # create a AIXNetwork object without fail
    net_collector = AIXNetwork(module)

    # the module.get_bin_path should have been called
    assert module.get_bin_path.call_count == 1


# Generated at 2022-06-22 23:39:39.582397
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    network = AIXNetwork()
    assert network.platform == 'AIX'


# Generated at 2022-06-22 23:39:47.893903
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    Test aix_network module: get_default_interfaces method
    """
    from ansible.module_utils.facts.network.aix import AIXNetwork

    net = AIXNetwork()
    net.module = DummyAnsibleModule()
    net.module.run_command = dummy_run_command
    defaults = net.get_default_interfaces('netstat')

    assert defaults == {'v4': {'gateway': '1.1.1.1', 'interface': 'lo0'},
                        'v6': {'gateway': '1:1:1:1:1:1:1:1', 'interface': 'lo0'}}



# Generated at 2022-06-22 23:39:52.234490
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    test_object = AIXNetwork()
    assert test_object.parse_interface_line(['en0:']) == {'device': 'en0', 'type': 'unknown', 'ipv4': [], 'ipv6': [], 'macaddress': 'unknown', 'flags': ['UP']}

# Generated at 2022-06-22 23:39:55.286927
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_collector = AIXNetwork(module)
    assert network_collector.platform == 'AIX'


# Generated at 2022-06-22 23:40:06.367357
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # testing AIXNetwork.get_interfaces_info()
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork

    class MockModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

        def get_bin_path(self, arg, opt_dirs=[]):
            return 'ifconfig'

        def run_command(self, args, check_rc=True, close_fds=False, executable=None, use_unsafe_shell=False, encoding=None):
            if 'netstat -nr' in args:
                return 0, 'default 172.17.0.1 UGSc 4 0 en8', ''

# Generated at 2022-06-22 23:40:17.474334
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    """
    This method is used to test get_default_interfaces() with the following input:
    netstat -nr output:
    """
    test_netstat_out = "default 192.168.1.1 UG 0 0 en0" + "\n"\
                       "default ::1 UG 32768 0 lo0" + "\n"\
                       "default fe80::%en0 UG en0" + "\n"\
                       "127.0.0.1 127.0.0.1 UH 1 1883 lo0" + "\n"\
                       "::1 ::1 UH 1 177 lo0"
    test_interface = dict(v4={}, v6={})
    test_interface['v4']['gateway'] = '192.168.1.1'
    test_interface['v4']['interface']

# Generated at 2022-06-22 23:40:19.313379
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module)
    assert network_collector._fact_class == AIXNetwork

# Generated at 2022-06-22 23:40:22.552083
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector()
    assert nc.platform == 'AIX'
    assert nc.fact_class == AIXNetwork

# Generated at 2022-06-22 23:40:25.386484
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    network_collector = AIXNetworkCollector()
    assert network_collector._fact_class is AIXNetwork
    assert network_collector._platform is 'AIX'

# Generated at 2022-06-22 23:40:32.249572
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_nw = AIXNetwork()
    current_if_dev1 = aix_nw.parse_interface_line(['en0:'])
    assert current_if_dev1['device'] == 'en0'
    assert current_if_dev1['flags'] == 'UP BROADCAST RUNNING MULTICAST'
    assert 'mtu' not in current_if_dev1

# Generated at 2022-06-22 23:40:34.834086
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # empty constructor of class AIXNetwork
    aix = AIXNetwork()
    assert aix.platform == 'AIX'



# Generated at 2022-06-22 23:40:42.751448
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    line='en0: flags=1e084863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>'
    words=line.split()
    aix=AIXNetwork()
    res = aix.parse_interface_line(words)
    assert res['device'] == 'en0'
    assert res['type'] == 'unknown'
    assert res['flags'] == ['1e084863', '480']
    assert res['macaddress'] == 'unknown'

# Generated at 2022-06-22 23:40:44.800573
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    assert AIXNetworkCollector._platform == 'AIX'
    assert type(AIXNetworkCollector._fact_class()) is AIXNetwork


# Generated at 2022-06-22 23:40:51.428125
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    class TestModule:
        def get_bin_path(self, arg):
            return ''
        def run_command(self, arg):
            return 0, '', ''

    # Test interface with no IP address

# Generated at 2022-06-22 23:41:00.077264
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(route_path=dict(default='/usr/sbin/route')))

    network = AIXNetwork({}, module)
    route_path = '/dev/null'

    module.run_command = lambda *args, **kwargs: (0, 'default 192.0.2.1 UGS 0 en0', '')

    result = {'interface': 'en0', 'gateway': '192.0.2.1'}
    assert network.get_default_interfaces(route_path) == result


# Generated at 2022-06-22 23:41:08.000806
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    mod = AnsibleModule(argument_spec={})
    platform = 'AIX'
    route_path = None
    an = AIXNetwork(mod, platform)
    interface = an.get_default_interfaces(route_path)
    assert interface['v4']['gateway'] == '172.20.0.1'
    assert interface['v4']['interface'] == 'lag0'
    assert interface['v6']['gateway'] == '::1'
    assert interface['v6']['interface'] == 'lag0'

# Generated at 2022-06-22 23:41:19.139857
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # The test verifies that value of 'mtu' is removed from current_if dict
    current_if = dict(
        device='en0',
        ipv4=[],
        ipv6=[],
        flags=['UP', 'BROADCAST', 'SIMPLEX'],
        macaddress='unknown',
        mtu=1000,
    )
    aix_network = AIXNetwork()

# Generated at 2022-06-22 23:41:30.829985
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """ Method get_interfaces_info of class AIXNetwork: Test 1 """
    # Test for AIX v7.1 TL3 SP3
    # (root@cebu:) # ifconfig -a
    # en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>
        # inet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
        # inet 131.123.0.1 netmask 0xffffff00 broadcast 131.123.0.255
        # inet6 ::1/128
        # inet6 fe80::218:f3ff:fef2:ca21/10
        # n

# Generated at 2022-06-22 23:41:38.758594
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    network = AIXNetwork()
    # test1
    words = 'en0: flags=890063 mtu 1500'.split()
    current_if = network.parse_interface_line(words)
    assert current_if['device'] == 'en0', 'Device name was not parsed correctly in AIXNetwork.parse_interface_line'
    assert current_if['type'] == 'unknown', 'Device type was not parsed correctly in AIXNetwork.parse_interface_line'
    assert current_if['flags'] == 890063, 'Flags were not parsed correctly in AIXNetwork.parse_interface_line'
    assert current_if['mtu'] == 1500, 'MTU was not parsed correctly in AIXNetwork.parse_interface_line'

# Generated at 2022-06-22 23:41:41.079185
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Getting of default interfaces should work in any directory
    os.chdir('/')

    net = AIXNetwork()

    net.module = module

    net.get_default_interfaces('')



# Unit test class for class AIXNetwork

# Generated at 2022-06-22 23:41:50.062037
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    class AIXNetwork(GenericBsdIfconfigNetwork):
        platform = 'AIX'
    # init AIXNetwork class
    aix_network = AIXNetwork()
    # word is a string of the line containing only the interface
    word = 'en3: flags='
    # for AIX, method parse_interface_line does not set MTU, so set it to None
    result = aix_network.parse_interface_line(word)
    assert result == {'device': 'en3', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': '', 'macaddress': 'unknown'}


if __name__ == '__main__':
    # run unit test for AIXNetwork class
    test_AIXNetwork_parse_interface_line()

# Generated at 2022-06-22 23:42:01.567789
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    '''Unit test for AIXNetwork#get_interfaces_info'''


# Generated at 2022-06-22 23:42:04.649591
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    nc = AIXNetworkCollector(None)
    assert isinstance(nc._fact_class, AIXNetwork)
    assert nc._platform == 'AIX'

# Generated at 2022-06-22 23:42:08.331296
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():

    module = Mock()

    n = AIXNetwork(module)

    module.get_bin_path.return_value = '/bin/netstat'
    module.run_command.return_value = (0, 'default 192.168.0.1 UG 1 0 en0', '')
    assert n.get_default_interfaces('/sbin/route') == ({'gateway': '192.168.0.1', 'interface': 'en0'}, {})

    module.run_command.return_value = (0, 'default fe80::1%lo0 UG 1 0 lo0', '')
    assert n.get_default_interfaces('/sbin/route') == ({}, {'gateway': 'fe80::1%lo0', 'interface': 'lo0'})


# Generated at 2022-06-22 23:42:17.433820
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Input data
    ifc_line = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'
    words = ifc_line.split()

    # Expected output
    exp_ifc_dict = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    exp_ifc_dict['flags'] = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    exp_ifc_dict['macaddress'] = 'unknown'

    # Real output
    obj = AIXNetwork()
    real_ifc_dict = obj.parse_interface_line(words)

    assert real_ifc_dict == exp_ifc_dict

# Generated at 2022-06-22 23:42:28.293150
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:42:32.132251
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    network = AIXNetwork(module=module)

    # route not found
    module.run_command = lambda cmd, check_rc=True: (1, b'', b'')
    assert network.get_default_interfaces('/usr/bin/route') == (None, None)

    # route found, but default not found
    module.run_command = lambda cmd, check_rc=True: (0, to_bytes('192.168.0.0/24\t10.0.0.1\tUG\ten0\n10.0.0.0/24\t*\t\ten0'), b'')
   

# Generated at 2022-06-22 23:42:43.650331
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from collections import namedtuple

    # Create a named tuple object MockModule with fields 'params' and '_socket_path'
    module = namedtuple('MockModule', ['params', '_socket_path'])

    # Create an object of class AIXNetworkCollector
    objNetworkCollector = AIXNetworkCollector(module(params=None, _socket_path=None))

    # Unit test for method get_facts
    assert isinstance(objNetworkCollector.get_facts(), dict)

    # Unit test for method get_interfaces
    assert isinstance(objNetworkCollector.get_interfaces(), list)

    # Unit test for method get_default_interfaces


# Generated at 2022-06-22 23:42:48.793443
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():

    # initialise instance
    aixnet = AIXNetwork()

    # test return value of get_default_interfaces()
    myexp_interfaces_v4, myexp_interfaces_v6 = {'gateway': '10.0.0.1', 'interface': 'en3'}, {}
    myexp_interfaces = (myexp_interfaces_v4, myexp_interfaces_v6)
    mystr = "AIXNetwork.get_default_interfaces(): default gateway: %s, default interface: %s" % (myexp_interfaces_v4["gateway"], myexp_interfaces_v4["interface"])
    assert aixnet.get_default_interfaces(route_path=None) == myexp_interfaces, mystr

    # test return value of get_interfaces_info(args)

# Generated at 2022-06-22 23:43:00.759535
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.ios import IOSNetwork
    # Create an AIX Network object
    aix = AIXNetwork([])
    # Create some input

# Generated at 2022-06-22 23:43:12.879524
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    obj = AIXNetwork()
    assert obj.platform == 'AIX'
    assert obj.ipv4_interface_regex == r'^\w*\d*:.*$'
    assert obj.ipv4_interface_regex_2 == r'^\w*\d*:.*$'
    assert obj.ipv4_address_regex == r'^\s*inet \d+\.\d+\.\d+\.\d+.*$'
    assert obj.ipv6_interface_regex == r'^\w*\d*:.*$'
    assert obj.ipv6_interface_regex_2 == r'^\w*\d*:.*$'
    assert obj.ipv6_address_regex == r'^\s*inet6 .*$'

# Generated at 2022-06-22 23:43:19.311335
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """
    Test the method get_interfaces_info of class AIXNetwork
    """
    module = AnsibleModule(argument_spec={})
    network_collector = AIXNetworkCollector(module=module)
    network = AIXNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')

    result = network.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-22 23:43:30.781496
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    module = type('TestModule', (object,), {'get_bin_path': lambda x: os.path.join(os.getcwd(), 'AIX')})
    obj = AIXNetwork(module)
    words = ['en0:', 'flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'inet', '10.1.2.3', 'netmask', '0xffff0000', 'broadcast', '10.1.255.255']

# Generated at 2022-06-22 23:43:35.301300
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    test_module = NetworkCollector()
    module_path = test_module.module.get_bin_path('netstat')
    test_AIXNetwork = AIXNetwork(module=test_module)
    test_AIXNetwork.get_default_interfaces(module_path)

# Generated at 2022-06-22 23:43:47.555027
# Unit test for method parse_interface_line of class AIXNetwork
def test_AIXNetwork_parse_interface_line():
    # Test: parse output of ifconfig -a
    words = 'en0: flags=1e080863,480<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>'.split()
    current_if = {}
    current_if['device'] = words[0].rstrip(':')
    current_if['flags'] = words[1].lstrip('flags=')
    current_if['macaddress'] = 'unknown'
    current_if['type'] = 'unknown'

    expected = current_if

    from ansible.module_utils.facts.network.aix import AIXNetwork
    aix_network = AIXNetwork()

# Generated at 2022-06-22 23:43:55.910179
# Unit test for method get_default_interfaces of class AIXNetwork
def test_AIXNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_collector = AIXNetworkCollector(module=module)
    network_collector.collect()
    default_interfaces = network_collector.get_default_interfaces()
    print (default_interfaces[0]['gateway'])
    print (default_interfaces[0]['interface'])
    print (default_interfaces[1]['gateway'])
    print (default_interfaces[1]['interface'])

# Generated at 2022-06-22 23:43:57.649113
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    net = AIXNetwork({})
    assert(net.platform == 'AIX')

# Generated at 2022-06-22 23:44:06.728344
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.aix import AIXNetwork
    AN = AIXNetwork(None)
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = AN.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert(interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1')
    assert(interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0')
    assert(interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255')

# Generated at 2022-06-22 23:44:14.514632
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(),
    )

    aix_network = AIXNetwork(module)


# Generated at 2022-06-22 23:44:25.126441
# Unit test for method get_interfaces_info of class AIXNetwork

# Generated at 2022-06-22 23:44:28.457022
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    from ansible.module_utils.facts.network.aix import AIXNetwork

    network = AIXNetwork()
    assert network.platform == 'AIX'


# Generated at 2022-06-22 23:44:37.813942
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    if config.get_config_value('network', 'collect_default_gateway', module):
        module.run_command = lambda x: (0, '', '')
    interfaces, ips = AIXNetwork(module).get_interfaces_info('/usr/sbin/ifconfig', '-a')

    assert interfaces['un0']['ipv4'] == [{'address': '172.31.40.112',
                                          'broadcast': '172.31.40.127',
                                          'netmask': '255.255.255.240'}]
    assert len(ips['all_ipv4_addresses']) == 2

# Generated at 2022-06-22 23:44:49.720882
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.network.aix import NetworkCollector
    from ansible.module_utils.facts.network.aix import AIXNetwork
    # Create the object of AIXNetworkCollector
    aix_network_collector_obj=AIXNetworkCollector()
    assert isinstance(aix_network_collector_obj._cache, cache.FactCache) == True
    assert issubclass(aix_network_collector_obj._fact_class, AIXNetwork) == True
    assert aix_network_collector_obj._platform == 'AIX'
    assert aix_network_collector_obj.platform == 'AIX'
    assert aix_network_collector_obj.optional_facts == []
    assert aix_network_collect

# Generated at 2022-06-22 23:44:57.190329
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    taken_input = dict(
        gather_subset=['!all', '!min'],
        gather_network_resources=dict(interfaces='eth0')
    )
    expected_output = dict(
        custom_facts={},
        network={},
        network_resources={'interfaces': ['eth0']}
    )
    test_object = AIXNetworkCollector(taken_input, './tests/unit/output/')
    output = test_object.get_facts()
    assert output == expected_output

# Generated at 2022-06-22 23:44:59.658492
# Unit test for constructor of class AIXNetworkCollector
def test_AIXNetworkCollector():
    net_collector = AIXNetworkCollector()
    assert net_collector._platform == 'AIX'

# Generated at 2022-06-22 23:45:12.272258
# Unit test for method get_interfaces_info of class AIXNetwork
def test_AIXNetwork_get_interfaces_info():
    """Unit testing for `get_interfaces_info` method"""

    # Expected input and output

# Generated at 2022-06-22 23:45:14.384956
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    module = AIXNetwork()

    # check for inherited vars and methods
    methods_and_vars = dir(GenericBsdIfconfigNetwork)
    for var in methods_and_vars:
        assert var in dir(AIXNetwork)

    # ifconfig = None
    assert module.get_default_interfaces(None) == ({}, {})
    assert module.get_interfaces_info(None, None) == ({}, {})

# Generated at 2022-06-22 23:45:19.884634
# Unit test for constructor of class AIXNetwork
def test_AIXNetwork():
    aix_network = AIXNetwork('/sbin/ifconfig', '/sbin/route', '/usr/bin/uname')
    assert aix_network
    assert aix_network.route_path == '/sbin/route'
    assert aix_network.uname_path == '/usr/bin/uname'
