

# Generated at 2022-06-11 18:42:36.994071
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    # load empty string
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}, "load_extra_vars with empty string failed"

    # load @jsonfile where jsonfile is empty
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}, "load_extra_vars with empty jsonfile failed"

    # load json object
    loader = DataLoader()
    val = {"a": {"b": "c"}}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == val, "load_extra_vars with json object failed"

    # load multiple json objects
   

# Generated at 2022-06-11 18:42:48.242029
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    yaml_yes = "yaml_data:\n  foo: bar"
    assert load_extra_vars(loader) == {}

    assert load_extra_vars(loader=loader, extra_vars=["@/dev/null"]) == {}

    assert load_extra_vars(loader=loader, extra_vars=[yaml_yes]) == {'yaml_data': {'foo': 'bar'}}

    # duplicate key in yaml data
    yaml_no = "foo: bar\nfoo: bar"

# Generated at 2022-06-11 18:42:56.699740
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    extra_vars_cmd_opt = [
        '@/path/to/vars.yaml',
        '{ "foo":"bar" }',
        '/path/to/json',
        'foo=bar',
        'foo=bar baz=foobar'
    ]
    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-11 18:43:06.728348
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader

    test_string = "@/test/path {\"a\": \"1\", \"b\": \"2\"} @test/path2"
    expected = [{'a': '1', 'b': '2'}, 'test/path2']
    loader = DataLoader()

    results = load_extra_vars(loader)

    assert(type(results) is dict)
    assert(expected == context.CLIARGS.get('extra_vars', []))
    assert(results == {'a': '1', 'b': '2'})


# Generated at 2022-06-11 18:43:15.296005
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    v = VariableManager()
    loader = DataLoader()

    def load_extra_vars(loader):
        extra_vars = {}
        for extra_vars_opt in [u"@/Users/awsh/git/blog-code/ansible/test.yml", u"/Users/awsh/git/blog-code/ansible/test.yml"]:
            data = None
            if extra_vars_opt.startswith(u"@"):
                # Argument is a YAML file (JSON is a subset of YAML)
                data = loader.load_from_file(extra_vars_opt[1:])

# Generated at 2022-06-11 18:43:25.752190
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager())

    def test_entry(input, expected):
        # Test with prefixed "@"
        extra_vars = {"ansible_version": "2.0.0.0"}
        variable_manager.extra_vars = extra_vars
        variable_manager.options_vars = {"ansible_version": "2.0.0.0"}
        extra_vars = load_extra_vars(loader)
        assert extra_vars == expected

        # Test with no prefixed "@"

# Generated at 2022-06-11 18:43:35.016311
# Unit test for function load_extra_vars
def test_load_extra_vars():
    """
    Test function load_extra_vars from ansible.module_utils.common.vars_prompt
    """
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    import sys

    # We need to add in the test plugins to the paths since we don't use the
    # standard plugin load path, which is usually automatically setup.
    test_loader = DataLoader()
    sys.path.insert(0, C.DEFAULT_MODULE_PATH[0])
    add_all_plugin_dirs()
    sys.path.pop(0)

    # Create a config manager object
    config_manager = ConfigManager()

    # test invalid extra_vars

# Generated at 2022-06-11 18:43:43.053875
# Unit test for function combine_vars
def test_combine_vars():
    for list_merge in ('replace', 'keep', 'append', 'prepend', 'append_rp', 'prepend_rp'):
        for recursive in (True, False):
            print("    ---- recursive = %s, list_merge = %s ----" % (recursive, list_merge))
            d1 = {'a': 1, 'b': 2, 'c': {'c1': {'cc1': 1, 'cc2': 2}, 'c2': 2}, 'd': [1,2,3], 'e': {'ee1': 1, 'ee2': 2}}
            d2 = {'a': 2, 'b': {'bb1': 1, 'bb2': 2}, 'c': 3, 'd': [4,5], 'e': 3}

# Generated at 2022-06-11 18:43:47.507688
# Unit test for function merge_hash
def test_merge_hash():
    def myassert(result, result_expected, msg=""):
        if isinstance(result, dict):
            merge_hash_result = dict_not_equal(result, result_expected)
            assert len(merge_hash_result) == 0, "%s: %s vs. %s" % (msg, result, result_expected)
        else:
            assert result == result_expected, "%s: %s vs. %s" % (msg, result, result_expected)

    def dict_not_equal(dict1, dict2):
        if set(dict1) != set(dict2):
            print(dict1, "and", dict2, "have different keys")
            return dict1


# Generated at 2022-06-11 18:43:58.437566
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible import constants as C
    C.HASH_BEHAVIOUR = 'merge'
    play_context = {}
    loader = DictDataLoader({
        "default_var.yml": """
        ---
        foo: 10
        """
    })
    assert load_extra_vars(loader) == {
        "foo": 10
    }
    play_context['extra_vars'] = [
        "bar=20",
        "@default_var.yml",
        "#ansible_check_mode=on"
    ]
    assert load_extra_vars(loader) == {
        "foo": 10,
        "bar": 20,
        "ansible_check_mode": False
    }
    C.HASH_BEHAVIOUR = 'replace'
    assert load_extra_vars

# Generated at 2022-06-11 18:44:21.027870
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # YAML file
    try:
        extra_vars = load_extra_vars(loader)
    except AnsibleOptionsError as e:
        assert(extra_vars == {})
    assert(extra_vars == {})

    # JSON file
    try:
        extra_vars = load_extra_vars(loader)
    except AnsibleOptionsError as e:
        assert(extra_vars == {})
    assert(extra_vars == {})

    # TODO: YAML with newlines

    # Invalid file
    try:
        extra_vars = load_extra_vars(loader).keys()
    except AnsibleOptionsError as e:
        assert(extra_vars == {})

# Generated at 2022-06-11 18:44:33.686002
# Unit test for function isidentifier
def test_isidentifier():
    from nose.tools import assert_true, assert_false
    assert_true(isidentifier('identifier'))
    assert_true(isidentifier('identifier_with_underscore'))
    assert_true(isidentifier('identifier-with-dash'))
    assert_false(isidentifier('identifier with space'))
    assert_false(isidentifier('identifier\nnewline'))
    assert_false(isidentifier('identifier\ttab'))
    assert_false(isidentifier('1identifier'))
    assert_false(isidentifier('identifier!'))
    assert_false(isidentifier('@identifier'))
    assert_false(isidentifier('identifier%'))
    assert_false(isidentifier('identifier*'))

# Generated at 2022-06-11 18:44:47.874425
# Unit test for function merge_hash
def test_merge_hash():
    def deep_assert(a, b):
        """
        This function test if a is deeply equal to b
        """
        # a and b are string (or other, nevermind)
        if not isinstance(a, MutableMapping) or not isinstance(b, MutableMapping):
            assert a == b
        else:
            # a and b are dict
            # we need to loop over all elements of a, and each element of a
            # (that is a dict) must be equal to element of b with same key
            # and vise-versa
            for key, value in iteritems(a):
                # recursively check if a[key] == b[key]
                deep_assert(value, b[key])

# Generated at 2022-06-11 18:44:59.937312
# Unit test for function merge_hash
def test_merge_hash():
    # Note: all dict keys are sorted() to ease comparison since dicts don't
    #       keep track of the order of their keys.

    # test empty dicts
    assert merge_hash({}, {}) == {}

    # test flat dicts
    assert merge_hash({'one': 1}, {'two': 2}) == {'one': 1, 'two': 2}
    assert merge_hash({'one': 1}, {'one': 2}) == {'one': 2}

    # test nested dicts
    assert merge_hash({'one': {'one': 1}}, {'two': {'two': 2}}) == {'one': {'one': 1}, 'two': {'two': 2}}

# Generated at 2022-06-11 18:45:11.126802
# Unit test for function merge_hash
def test_merge_hash():
    # first we need to create a test dict
    def rundict(dic):
        # recursive function to copy a dict
        if isinstance(dic, MutableMapping):
            return {k: rundict(v) for k, v in dic.items()}
        if isinstance(dic, MutableSequence):
            return list([rundict(v) for v in dic])
        return dic

    def testdict():
        # a dict to be used for testing
        return {
            'a': 0,
            'b': [1, 2],
            'c': {
                'd': 3,
                'e': 4
            }
        }


# Generated at 2022-06-11 18:45:22.042133
# Unit test for function merge_hash
def test_merge_hash():
    assert(merge_hash({},{}) == {})
    assert(merge_hash({'a': 1},{'a': 2}) == {'a': 2})
    assert(merge_hash({'a': 1},{'b': 2}) == {'a': 1, 'b': 2})
    assert(merge_hash({'a': {'b': 1}},{'a': {'c': 2}}) == {'a': {'b': 1, 'c': 2}})
    assert(merge_hash({'a': 1},{'a': {'b': 2}}) == {'a': {'b': 2}})

# Generated at 2022-06-11 18:45:35.729037
# Unit test for function merge_hash
def test_merge_hash():
    # -*- Merge tests -*-

    print("test_merge_hash: Testing 'merge'")

    x = {
        "a": {
            "b": 1,
            "c": 2,
        },
        "d": 3,
        "e": [1, 2, 3],
    }

    y = {
        "g": [{
            "h": 1,
            "i": 2,
        }],
        "j": 4,
        "a": {
            "b": 10,
            "d": 20,
        },
        "e": [5, 6],
    }


# Generated at 2022-06-11 18:45:47.556014
# Unit test for function merge_hash
def test_merge_hash():
    # test for non-recursive merge
    assert {
        "foo": "bar",
        "bing": "cheese",
        "zoo": "boo"
    }, merge_hash({
        "foo": "bar",
        "bing": "chang"
    }, {
        "bing": "cheese",
        "zoo": "boo"
    }, False)

    # test for recursive merge on dict

# Generated at 2022-06-11 18:45:58.882086
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext


    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_src =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World!')))
         ]
    )


# Generated at 2022-06-11 18:46:10.809481
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = DictDataLoader({
        u"empty": u"",
        u"empty_dict": u"{}",
        u"empty_dict_whitespace": u"{ }",
        u"empty_list": u"[]",
        u"empty_list_whitespace": u"[ ]",
        u"dict": u"{\"a\": 1}",
        u"dict_whitespace": u"{ \"a\": 1 }",
        u"kv": u"a=1",
        u"kv_whitespace": u"a = 1",
    })
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == load_extra_vars(loader)


# Generated at 2022-06-11 18:46:27.758501
# Unit test for function load_extra_vars
def test_load_extra_vars():
    '''
    unit tests for load_extra_vars
    '''
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    my_args = ['foo=stuff', '@myvars.yml', '@myvars.json']
    extra_vars = load_extra_vars(loader)
    for extra_vars_opt in context.CLIARGS.get('extra_vars', tuple()):
        data = None
        extra_vars_opt = to_text(extra_vars_opt, errors='surrogate_or_strict')
        if extra_vars_opt is None or not extra_vars_opt:
            continue


# Generated at 2022-06-11 18:46:34.781307
# Unit test for function load_options_vars
def test_load_options_vars():
    context.CLIARGS = {'check': True}
    version = "2.0"
    loaded_vars = load_options_vars(version)
    expected_vars = {'ansible_version': '2.0', 'ansible_check_mode': True}
    assert loaded_vars == expected_vars

# Generated at 2022-06-11 18:46:45.171270
# Unit test for function combine_vars
def test_combine_vars():
    import random
    import string

    def make_dict():
        # This function creates a dictionary with random values
        # as more values are added to a dictionary the more tests
        # are done on the created dictionary
        d = {'a': 'A', 'b': 'B'}
        vals = string.ascii_letters
        num_vals = random.randint(0, 100)
        for i in range(1, num_vals):
            d[vals[i]] = vals[i]
        return d

    def check_dict(d, n):
        # This function is used to check the results of combine_vars
        # It checks that all values exist and that no new values were added
        # or lost
        if len(d) != n:
            return False

# Generated at 2022-06-11 18:46:51.029227
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    extra_vars = "{\"test1\": 1, \"test2\": 2}"
    loader = AnsibleLoader(extra_vars, None)
    load_extra_vars(loader)


# Generated at 2022-06-11 18:46:57.832993
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars_opt=["@test.json"]
    results = load_extra_vars(loader)
    assert results == {'first': {'all': 'dogs', 'dogs': ['Labrador', 'Poodle']}, 'second': 'value'}

# Generated at 2022-06-11 18:47:06.880972
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.parsing import DataLoader

    loader = DataLoader()

    (fd, fname) = tempfile.mkstemp(dir='.')
    os.write(fd, to_bytes("""
foo: bar
a: 123
""", errors='surrogate_or_strict'))
    os.close(fd)

    testdict = dict(foo='baz', a=456, b='789')


# Generated at 2022-06-11 18:47:17.037745
# Unit test for function load_extra_vars
def test_load_extra_vars():
    """
    Ensure that load_extra_vars returns expected results
    """
    import ansible.plugins.loader
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleOptionsError, AnsibleError

    # Fake context and args to triger correct code path
    context.CLIARGS = {'module_path': None, 'extra_vars': []}

    # Create a fake loader
    class MyDataLoader(DataLoader):
        def __init__(self):
            pass

        def load(self, data, file_name='<string>', show_content=True):
            return ansible.parsing.yaml.objects.AnsibleBaseYAM

# Generated at 2022-06-11 18:47:25.518602
# Unit test for function merge_hash

# Generated at 2022-06-11 18:47:29.686603
# Unit test for function load_extra_vars
def test_load_extra_vars():
    context.CLIARGS = {'extra_vars': ["{\"a\": \"b\"}"]}
    loader = DictDataLoader({})
    assert load_extra_vars(loader) == {'a': 'b'}
    assert load_extra_vars(loader) != {'a': 'c'}



# Generated at 2022-06-11 18:47:40.811458
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, MutableMapping)
    assert len(extra_vars) == 0

    result = load_extra_vars(loader)
    assert isinstance(result, MutableMapping)
    assert len(result) == 0
    assert extra_vars == result

    result = load_extra_vars(loader)
    assert isinstance(result, MutableMapping)
    assert len(result) == 0
    assert extra_vars == result

    assert '@' + TEST_FILE_1 in context.CLIARGS['extra_vars']
    result = load_extra_vars(loader)

# Generated at 2022-06-11 18:47:54.771005
# Unit test for function merge_hash
def test_merge_hash():
    def chk(x, y, r, recursive=True, list_merge='replace'):
        assert merge_hash(x, y, recursive, list_merge) == r

    # simple case
    chk({}, {}, {})
    chk({}, dict(a=1), dict(a=1))
    chk(dict(a=1), dict(b=2), dict(a=1, b=2))

    # override
    chk(dict(a=1), dict(a=2), dict(a=2))

    # recursive / non-recursive
    chk(dict(a=dict(b=1)), dict(a=dict(c=2)), dict(a=dict(b=1, c=2)), recursive=False)

# Generated at 2022-06-11 18:48:05.642325
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()

    # file
    extra_vars = load_extra_vars(dl)
    assert extra_vars == {}

    extra_vars = load_extra_vars(dl, (u"@tests/support/debug_me.yml",))
    assert extra_vars == {"a": "b", "c": "d"}

    # yaml
    extra_vars = load_extra_vars(dl, (u"a: b",))
    assert extra_vars == {"a": "b"}

    extra_vars = load_extra_vars(dl, (u"a: b", u"c: d"))
    assert extra_vars == {"a": "b", "c": "d"}

   

# Generated at 2022-06-11 18:48:14.950587
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    def assert_extra_vars_variables(loader, extra_vars_argument, expected_extra_vars):
        extra_vars = load_extra_vars(loader, extra_vars_argument)
        assert extra_vars == expected_extra_vars

    with DataLoader() as loader:
        assert_extra_vars_variables(loader, None, {})
        assert_extra_vars_variables(loader, [], {})
        assert_extra_vars_variables(loader, [u"foo=bar"], {u"foo": u"bar"})

        foo_bar = u"""
        foo:
          bar: 1
        """

# Generated at 2022-06-11 18:48:22.523358
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test with empty extra vars
    empty_extra_vars = load_extra_vars(loader)
    assert empty_extra_vars == {}

    # Test with valid extra vars
    with_extra_vars = load_extra_vars(loader)
    assert isinstance(with_extra_vars, dict) == True

    # Test with invalid extra vars
    fake_extra_vars = '/fake/path'
    try:
        context.CLIARGS['extra_vars'] = [fake_extra_vars]
        load_extra_vars(loader)
    except AnsibleOptionsError:
        assert True
    except:
        assert False

# Generated at 2022-06-11 18:48:34.746365
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

# Generated at 2022-06-11 18:48:46.716337
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader, None)
    assert {} == load_extra_vars(loader)

    # Test with empty contents
    input = [ "@", "@{}", "@[]", "''", "\"\"", "[]", "{}", "{\"\" : \"\"}", "[\"\"]", "[ \"\", \"\" ]" ]
    expected = {}
    for extra_vars_opt in input:
        extra_vars = load_extra_vars(loader, extra_vars_opt=extra_vars_opt)
        assert expected == extra_vars

    # Test with normal contents

# Generated at 2022-06-11 18:48:59.117637
# Unit test for function load_extra_vars
def test_load_extra_vars():

    def test_loader_object():
        class TestLoader(object):
            def load_from_file(self, filename):
                return dict(a=42)
            def load(self, text):
                return dict(b=42)

        loader = TestLoader()
        extra_vars = load_extra_vars(loader)
        assert isinstance(extra_vars, dict)
        assert extra_vars['a'] == 42
        assert extra_vars['b'] == 42

    def test_loader_class():
        class TestLoader(object):
            def load_from_file(self, filename):
                return dict(a=42)
            def load(self, text):
                return dict(b=42)

        extra_vars = load_extra_vars(TestLoader())

# Generated at 2022-06-11 18:49:10.184047
# Unit test for function merge_hash
def test_merge_hash():
    def assert_merge_hash(result, first, second, optional_keyword_arguments={}):
        assert merge_hash(**dict({"first": first, "second": second}, **optional_keyword_arguments)) == result
    assert_merge_hash(
        result={"a": 1},
        first={},
        second={"a": 1},
    )
    assert_merge_hash(
        result={"a": 1},
        first={"a": 1},
        second={},
    )
    assert_merge_hash(
        result={"a": 1},
        first={"a": 1},
        second={"a": 1},
    )

# Generated at 2022-06-11 18:49:21.449360
# Unit test for function combine_vars
def test_combine_vars():
    x = {'a': {'b': 1}, 'c': 2, 'd': ['e', 'f']}
    y = {'a': {'g': 2}, 'd': [1], 'h': 'i'}
    z = {'a': 1}
    k = {}
    assert(combine_vars(x, y, merge=True) == {'a': {'b': 1, 'g': 2}, 'c': 2, 'd': [1], 'h': 'i'})
    assert(combine_vars(x, y, merge=False) == {'a': {'g': 2}, 'c': 2, 'd': [1], 'h': 'i'})
    assert(combine_vars(x, z) == {'a': 1})

# Generated at 2022-06-11 18:49:33.994231
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    extra_vars = {}

    extra_vars_opt1 = "var1=foo var2=bar"
    data = parse_kv(extra_vars_opt1)
    assert isinstance(data, AnsibleBaseYAMLObject)
    extra_vars = combine_vars(extra_vars, data)

    extra_vars_opt2 = "{var3: 'baz', var4: 'quux'}"
    yaml_data = AnsibleLoader(extra_vars_opt2).get_single_data()
    assert isinstance(yaml_data, AnsibleBaseYAMLObject)
    data = yaml_data
   

# Generated at 2022-06-11 18:49:49.595139
# Unit test for function load_extra_vars

# Generated at 2022-06-11 18:50:01.363635
# Unit test for function merge_hash
def test_merge_hash():
    # test that merging two dicts with the same key and different values
    # override x value by y's one as it has higher priority
    x = {'k1': 'v1', 'k2': 'v2'}
    y = {'k2': 'v3'}
    assert merge_hash(x, y) == {'k1': 'v1', 'k2': 'v3'}, "failed to merge two dicts with the same key and different values"

    # test that merging two dicts with the same key and at least one dict
    # as value for that key recursively merge the dicts
    x = {'k1': 'v1', 'k2': {'k2.1': 'v2.1', 'k2.2': 'v2.2'}}

# Generated at 2022-06-11 18:50:14.387582
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # test extra_vars with keys not in the default
    from ansible.parsing.dataloader import DataLoader
    ansible_vars = {'test1': 'test1', 'test3': {'test4': 'test4'}}
    more_vars = {'test2': 'test2', 'test3': {'test5': 'test5'}}
    opts = {'extra_vars': [more_vars, '@%s' % "/tmp/vars"]}
    context.CLIARGS = lambda: opts
    loader = DataLoader()
    assert load_extra_vars(loader) == ansible_vars

    # test extra_vars with keys in the default

# Generated at 2022-06-11 18:50:26.259901
# Unit test for function load_extra_vars
def test_load_extra_vars():

    extra_vars = {
        'item1': 'value 1',
        'item2': 'value 2',
        'item3': {
            'item4': {
                'item5': 'value 5',
                'item6': 'value 6',
            },
        },
    }

    print("testing load_extra_vars()")
    print("1. extra_vars no argument (value is an empty dict)")
    print("2. extra_vars argument is not a mapping type (value is an empty dict)")
    print("3. extra_vars argument is not a list of 6 mapping types (value is an empty dict)")
    print("4. extra_vars argument is a list of 6 mapping types (value is a dict)")


# Generated at 2022-06-11 18:50:36.140419
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml = AnsibleLoader(None, dict_type='unsafe')
    yaml.set_allow_duplicates(True)

    def test_yaml_str():
        return yaml.dump(dict(a=1, b=2))

    assert load_extra_vars(yaml) == {
        'a': 1,
        'b': 2,
        'a': 1,
        'b': 2,
    }

# Generated at 2022-06-11 18:50:45.817965
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # TODO: extend test scenarios
    import ansible.playbook
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = Inventory(host_list=[])
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    pb = PlayBook(
        playbook='/etc/ansible/roles/common/tests/test_load_extra_vars.yml',
        module_path=None,
        inventory=inv,
        variable_manager=variable_manager,
        loader=loader,
        options=Options(),
        passwords={},
    )
    pb.run()

# Generated at 2022-06-11 18:50:58.024541
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = DictDataLoader({
        'file1.yml': """
            foo: bar
            bar:
              - 1
              - 2
        """,
        'file2.json': """
            {
                "foo": "baz",
                "spam": "eggs"
            }
        """
    })

    cases = [(('@file1.yml', '@file2.json'), {
        'foo': 'baz',
        'bar': [1, 2],
        'spam': 'eggs'
    }), (('@file1.yml', 'foo=one', 'bar=two'), {
        'foo': 'one',
        'bar': 'two',
        'bar': [1, 2]
    })]


# Generated at 2022-06-11 18:51:09.509117
# Unit test for function load_extra_vars
def test_load_extra_vars():

    import contextlib

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO

    class FakeLoader(object):
        def __init__(self, data):
            self.data = data

        def load_from_file(self, filename):
            return self.data.pop()

        def load(self, data):
            return self.data.pop()

    @contextlib.contextmanager
    def temporary_context(context_name, context_value):
        old_value = getattr(context, context_name)
        setattr(context, context_name, context_value)
        yield
        setattr(context, context_name, old_value)


# Generated at 2022-06-11 18:51:20.968251
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = dict(a=dict(b=1, c=2))
    arr = [1, 2]
    arr.insert(0, arr[:])


# Generated at 2022-06-11 18:51:28.498028
# Unit test for function load_options_vars
def test_load_options_vars():

    import sys
    from ansible.utils.display import Display

    display = Display()

    # Method that return the content of a file
    def file_content( path):
        # Open the file as f.
        # The function readlines() reads the file.
        with open(path) as f:
            content = f.readlines()
        # Show the file contents line by line.
        # We added the comma to print single newlines and not double newlines.
        # This is because the lines contain the newline character '\n'.
        for line in content:
            print(line)

    for cli_arg in sys.argv:
        if 'test_' in cli_arg:
            display.verbosity = 4
        else:
            display.verbosity = 0


# Generated at 2022-06-11 18:51:46.847150
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.splitter import parse_kv
    from ansible.plugins.loader import load_plugins
    #from ansible.module_utils.common.collections import MutableMapping
    from ansible.vars import combine_vars
    global load_extra_vars

    load_plugins()

    loader = DataLoader()

    # none
    extra_vars = load_extra_vars(loader)

    assert extra_vars == {}

    # empty string
    extra_vars = load_extra_vars(loader, [''])

    assert extra_vars == {}

    # kv string
    extra_vars = load_extra_vars(loader, ['foo=bar,baz=bat,aa=bb'])


# Generated at 2022-06-11 18:51:59.200286
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = [{}]
    assert load_extra_vars(loader) == extra_vars[0]
    extra_vars = [u"[{'test': 1}]"]
    assert load_extra_vars(loader) == extra_vars[0]
    extra_vars = [u"test=1"]
    assert load_extra_vars(loader) == extra_vars[0]
    extra_vars = [u"@/dev/null"]
    assert load_extra_vars(loader) == extra_vars[0]
    loader = DataLoader()
    extra_vars = [u"@/dev/null", u"@/dev/null"]
    assert load_extra