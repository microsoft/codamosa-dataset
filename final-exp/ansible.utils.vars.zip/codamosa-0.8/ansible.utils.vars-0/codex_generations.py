

# Generated at 2022-06-11 18:42:25.584968
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = DictDataLoader({})
    # Test for @ file loading behavior
    dummy_vars_file = dict(
        bee = 'majesty'
    )

    with open('test_filename', 'w') as dummy_vars_file_fd:
        dump(dummy_vars_file, dummy_vars_file_fd)
        pass

        # Test for string-as-dict json loading behavior
        dummy_vars_json = dict(
            bee = 'majesty'
        )

    with open('test_json', 'w') as dummy_vars_json_fd:
        dump(dummy_vars_json, dummy_vars_json_fd)
        pass

        # Test for string-as-dict yaml loading behavior

# Generated at 2022-06-11 18:42:36.606197
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import combine_vars, merge_hash

    load = DataLoader()
    # load from kv string
    data = load_extra_vars(load)
    assert data == {}

    # load from kv string
    data = load_extra_vars(load)
    assert data == {}

    # load from kv string
    data = load_extra_vars(load)
    assert data == {}

    # load from kv string
    data = load_extra_vars(load)
    assert data == {}

    # load from kv string
    data = load_extra_vars(load)
    assert data == {}

    # load from kv string
    data = load_extra_vars(load)

# Generated at 2022-06-11 18:42:47.962137
# Unit test for function load_extra_vars

# Generated at 2022-06-11 18:42:59.949204
# Unit test for function merge_hash
def test_merge_hash():
    from ansible.utils import merge_hash
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY2

    # Test Unicode (unicode on Python 2 is str on Python 3)
    assert merge_hash({u'test': u'value'}, {u'othertest': u'othervalue'}) == {
        u'othertest': u'othervalue',
        u'test': u'value',
    }

    # Test unicode_literals (unicode on Python 2 is str on Python 3)
    assert merge_hash({'test': 'value'}, {'othertest': 'othervalue'}) == {
        'othertest': 'othervalue',
        'test': 'value',
    }

    # Test non-unicode with non-unicode (

# Generated at 2022-06-11 18:43:11.670195
# Unit test for function merge_hash
def test_merge_hash():
    x = {
        "a": {
            "b": {
                "c": 1,
                "d": 2,
                "e": 3,
            }
        }
    }
    y = {
        "a": {
            "b": {
                "c": 1,
                "d": 3,
                "f": {
                    "g": 4
                }
            },
            "h": 5
        },
        "i": 6
    }
    expected = {
        "a": {
            "b": {
                "c": 1,
                "d": 3,
                "e": 3,
                "f": {
                    "g": 4
                }
            },
            "h": 5
        },
        "i": 6
    }

# Generated at 2022-06-11 18:43:24.020029
# Unit test for function load_extra_vars
def test_load_extra_vars():

    class MockLoader:

        def load_from_file(self, path):

            if path == "file.yml":
                return {"foo": "bar"}
            # else if path == "file.json":
            #    return {"foo": "bar"}
            else:
                raise Exception

        def load(self, string):

            if string == "{'foo':'bar'}":
                return {"foo": "bar"}
            # else if string == "{\"foo\":\"bar\"}":
            #    return {"foo": "bar"}
            else:
                raise Exception

    # init mock
    loader = MockLoader()

    # init empty context
    context.CLIARGS = {}

    # test
    assert load_extra_vars(loader) == {}

    # test

# Generated at 2022-06-11 18:43:34.380629
# Unit test for function merge_hash
def test_merge_hash():
    # test with empty dicts
    x = {}
    y = {}
    assert merge_hash(x, y) == {}

    # test with one empty dict
    x = {}
    y = {'k': 1}
    assert merge_hash(x, y) == y

    # test with non-empty dicts
    x = {'k1': 1}
    y = {'k2': 2}
    assert merge_hash(x, y) == {'k1': 1, 'k2': 2}

    # test with non-empty dicts and shared keys
    x = {'k1': 1}
    y = {'k1': 2}
    assert merge_hash(x, y) == {'k1': 2}

    # test with non-empty dicts and nested shared keys

# Generated at 2022-06-11 18:43:45.326942
# Unit test for function merge_hash
def test_merge_hash():
    """
    Test merge_hash function.
    """

    # We test merge_hash with following dicts:
    # a: {'a': 1, 'b': {'b1': 2, 'b2': 3}, 'c': 4}
    # b: {'d': 5, 'e': {'e1': 6}, 'b': {'b1': 10, 'b3': 13}}
    #
    # expected results are:
    # merge_hash(a, b, list_merge='replace') =
    # {'a': 1, 'b': {'b1': 10, 'b3': 13}, 'c': 4, 'd': 5, 'e': {'e1': 6}}
    #
    # merge_hash(a, b, recursive=False, list_merge='replace') =
    # {

# Generated at 2022-06-11 18:43:57.150211
# Unit test for function merge_hash
def test_merge_hash():
    def assert_equal_dicts(d1, d2):
        assert d1 == d2, "Dictionaries differ: %s != %s" % (d1, d2)

    def merge(x, y, recursive=True, list_merge='replace'):
        z = merge_hash(x, y, recursive, list_merge)
        check = merge_hash(x, y)
        assert z == check, ("merge_hash function differs with "
                            "and without recursive option")
        return z

    # Testing simple cases
    assert_equal_dicts(merge({}, {}), {})
    assert_equal_dicts(merge({}, {'foo': 'bar'}), {'foo': 'bar'})

# Generated at 2022-06-11 18:44:04.968123
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    options_data = {'extra_vars': ['{"is_option": true}', '@./test_load_extra_vars.json']}
    loader = DataLoader()
    vm = VariableManager(loader=loader)
    result = load_extra_vars(loader)
    assert {"is_option": True, "is_file": True} == result

# Generated at 2022-06-11 18:44:17.470920
# Unit test for function isidentifier
def test_isidentifier():
    pass

# Generated at 2022-06-11 18:44:28.970438
# Unit test for function merge_hash
def test_merge_hash():
    import copy

    # simple hash with string values
    a = {'a': 'a', 'b': 'b', 'c': 'c'}
    b = {'c': 'c', 'b': 'b', 'd': 'd', 'e': 'e'}
    # Test merge
    ab = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}
    ab_m = merge_hash(a, b)
    assert ab == ab_m
    # Test merge with recursive
    abr = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}
    abr_m = merge_hash(a, b, recursive=True)
    assert abr == abr

# Generated at 2022-06-11 18:44:35.003775
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.module_utils.six import PY3

    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes, to_text

    def test(loader, extravars_str, expected=None, expected_type=None, expected_result=None):
        extravars_opt = to_text(extravars_str, errors='surrogate_or_strict')
        actual = load_extra_vars(loader)
        expected = expected
        if expected is None:
            expected = {'extra_var': 'value'}
        elif expected is False:
            expected = {}
        assert actual == expected
        if expected_type is not None:
            assert type(actual) is expected_type

# Generated at 2022-06-11 18:44:47.783962
# Unit test for function isidentifier
def test_isidentifier():
    invalid_identifiers = [
        '',
        'a b',
        '42',
        '`a',
        '$a',
        '_a',
        '!a',
        # This is a valid identifier in Python 2, but not Python 3.
        u'\u03B1',
        'True',
        'False',
        'None'
    ]
    for ident in invalid_identifiers:
        assert not isidentifier(ident)

    valid_identifiers = [
        'a',
        'a_b',
        'a_b42',
        '_',
        '_42'
    ]
    for ident in valid_identifiers:
        assert isidentifier(ident)

# Generated at 2022-06-11 18:44:59.863030
# Unit test for function merge_hash
def test_merge_hash():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import copy


# Generated at 2022-06-11 18:45:02.152541
# Unit test for function load_options_vars
def test_load_options_vars():
    context.CLIARGS = dict(forks=5, verbosity=1, listtags=True)
    assert load_options_vars(None) == dict(ansible_forks=5,
                                           ansible_verbosity=1,
                                           ansible_version='Unknown')



# Generated at 2022-06-11 18:45:12.859290
# Unit test for function merge_hash
def test_merge_hash():
    def eq(x, y):
        if str(x) != str(y):
            print("'%s' != '%s'" % (x, y))
            return False
        return True

    def test_one(x, y, expected, **kwargs):
        if not eq(merge_hash(x, y, **kwargs), expected):
            raise Exception("merge_hash(%s, %s) != %s" % (x, y, expected))

    test_one(
        {},
        {},
        {},
    )
    test_one(
        {},
        {'a': 1},
        {'a': 1},
    )
    test_one(
        {'a': 1},
        {'a': 1},
        {'a': 1},
    )
    test

# Generated at 2022-06-11 18:45:13.494715
# Unit test for function load_extra_vars
def test_load_extra_vars():
    pass

# Generated at 2022-06-11 18:45:23.389679
# Unit test for function isidentifier
def test_isidentifier():
    # here are some identifiers that should be validated
    valid_identifiers = (
        '_', '_0', '_a_', '_a0_', '__', 'a', 'a0', 'a_', 'a0_', 'abc',
        'abc_def_ghi_jkl_mno_pqr_stu_vwx_yz',  # max length for identifiers on Python is 33
        'A', 'aB', 'Ab', 'aBc', 'aB0', 'aB_',
    )

    # here are some of things that are not identifiers and shouldn't be validated

# Generated at 2022-06-11 18:45:36.795455
# Unit test for function isidentifier

# Generated at 2022-06-11 18:45:47.549726
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = DictDataLoader({
        'test.yml': """
            foo: bar
            baz: qux
        """
    })

    extra_vars = load_extra_vars(loader)

    assert extra_vars == {'foo': 'bar', 'baz': 'qux'}



# Generated at 2022-06-11 18:45:58.882160
# Unit test for function load_extra_vars
def test_load_extra_vars():

    # Create a dictionary of test yaml and json files and their equivalent
    # dictionary of variables

    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    def create_temp_file(key, data, ext):
        ''' Create a temporary file and write data to it '''
        _, fn = tempfile.mkstemp(prefix='%s.' % key, suffix='.%s' % ext)
        with open(fn, 'w') as f:
            f.write(data)
        return fn


# Generated at 2022-06-11 18:46:10.809012
# Unit test for function load_extra_vars
def test_load_extra_vars():
    """
    Test function load_extra_vars
    """
    import sys
    import io
    from ansible.parsing.yaml.loader import AnsibleLoader

    def _get_stdin():
        """
        Return stdin as text

        This returns an empty string if there is no stdin (e.g. when running on Windows).
        """
        if sys.stdin.isatty():
            return u''
        else:
            return sys.stdin.read()

    # test with extra_vars
    fake_stdin_content = u'''name: Joe\nfoo: bar'''
    with mock.patch('sys.stdin', new=io.StringIO(fake_stdin_content)):
        extra_vars_1 = load_extra_vars(AnsibleLoader)

# Generated at 2022-06-11 18:46:18.659041
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    # test empty argument list
    extra_vars = load_extra_vars(DataLoader())
    assert extra_vars == {}
    # test empty argument
    extra_vars = load_extra_vars(DataLoader()).update({u'extra_vars': u''})
    assert extra_vars == {}
    # test invalid argument
    extra_vars = load_extra_vars(DataLoader()).update({u'extra_vars': [u'@']})
    assert extra_vars == {}
    # test key-value arguments

# Generated at 2022-06-11 18:46:26.428289
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars_list = [u'{"list1":["val1"],"list2":["val2"]}', u'{"list3":["val3"],"list4":["val4"]}']
    extra_vars = load_extra_vars(loader)

    if extra_vars == {}:
        assert 0, "extra_vars is empty, failed."
    else:
        assert 1, "extra_vars is not empty, passed."

# Generated at 2022-06-11 18:46:39.940770
# Unit test for function merge_hash

# Generated at 2022-06-11 18:46:52.279834
# Unit test for function combine_vars
def test_combine_vars():
    assert combine_vars({'a': 1}, {'b': 2, 'a': 2}) == {'a': 2, 'b': 2}
    assert combine_vars({'a': {'b': 1}}, {'a': {'c': 2}}) == {'a': {'c': 2, 'b': 1}}
    assert combine_vars({'a': {'b': 1}}, {'a': {'b': 2}}) == {'a': {'b': 2}}
    assert combine_vars({'a': {'b': 1}}, {'a': {'b': 2}}, merge=False) == {'a': {'b': 2}}



# Generated at 2022-06-11 18:47:04.756405
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

    # test empty extra_vars
    assert len(extra_vars) == 0

    extra_vars = load_extra_vars(loader, [])
    assert isinstance(extra_vars, dict)

    # test empty extra_vars
    assert len(extra_vars) == 0

    foo_json = '{"foo":"bar"}'
    extra_vars = load_extra_vars(loader, [foo_json])
    assert isinstance(extra_vars, dict)
    assert len(extra_vars) == 1
    assert extra_vars['foo'] == 'bar'



# Generated at 2022-06-11 18:47:11.902636
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # setup
    class TestLoader(object):
        def load_from_file(self,filename):
            if filename == "good.yml":
                return {"a":1}
            else:
                return "bad.yml"
    loader = TestLoader()
    # test
    extra_vars = load_extra_vars(loader)
    # Verify
    assert extra_vars == {"a":1}, "test_load_extra_vars failed"


# Generated at 2022-06-11 18:47:24.878990
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    options = {
        'connection': 'local', 'forks': 100, 'remote_user': 'username', 'ask_pass': False, 'private_key_file': 'testkey',
        'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '',
        'scp_extra_args': '', 'become': True, 'become_method': 'sudo', 'become_user': 'root', 'verbosity': 0,
        'check': False}

# Generated at 2022-06-11 18:47:41.193539
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('a')
    assert isidentifier('a1')
    assert isidentifier('_a')
    assert isidentifier('_a1')
    assert not isidentifier('1')
    assert not isidentifier('1a')
    assert not isidentifier('a.b')
    assert not isidentifier('a b')
    assert not isidentifier('a\x0b')

# Generated at 2022-06-11 18:47:47.936243
# Unit test for function combine_vars
def test_combine_vars():
    x = {u'foo': [1, 2]}
    y = {u'foo': [2, 3]}
    combine_vars(x, y, merge=True)
    assert x[u'foo'] == [1, 2, 2, 3]

    x = {u'foo': [1, 2]}
    y = {u'foo': [2, 3]}
    combine_vars(x, y, merge=False)
    assert x[u'foo'] == [2, 3]

    x = {u'foo': {u'bar': u'baz'}}
    y = {u'foo': {u'bar': u'baz2'}}
    combine_vars(x, y, merge=True)
    assert x[u'foo'][u'bar'] == u'baz2'

    x

# Generated at 2022-06-11 18:47:59.307454
# Unit test for function merge_hash
def test_merge_hash():
    x = {"a":1, "b":2, "c":3}
    y = {"c":4, "d":5}
    assert merge_hash(x,y) == {"a":1, "b":2, "c":4, "d":5}
    x = {"a":1, "b":2, "c":3}
    y = {"c":4, "d":5}
    assert merge_hash(x,y, recursive=False) == {"a":1, "b":2, "c":4, "d":5}
    x = {"a":1, "b":2, "c":3}
    y = {"c":[1,2,3], "d":5}

# Generated at 2022-06-11 18:48:09.299870
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier("foo")
    assert not isidentifier("1foo")
    assert isidentifier("_foo")
    assert isidentifier("foo_")
    assert isidentifier("foo1")
    assert isidentifier("foo_1")
    assert isidentifier("_")

    assert not isidentifier("")
    assert not isidentifier("-foo")
    assert not isidentifier("foo-")
    assert not isidentifier("foo-bar")
    assert not isidentifier("foo.bar")
    assert not isidentifier(u"\u2603")
    assert not isidentifier("foo%bar")
    assert not isidentifier("foo*bar")

    assert not isidentifier("True")
    assert not isidentifier("False")
    assert not isidentifier("None")

# Generated at 2022-06-11 18:48:21.302783
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = {'key1': 'value1',
                  'key2': 'value2',
                  'key3': {'key3-1': 'value3-1',
                           'key3-2': 'value3-2'}
                  }
    extra_vars_str = "'key1=value1 key2=value2 key3='{'key3-1':'value3-1','key3-2':'value3-2'}'"
    extra_vars_file = """key1: value1
key2: value2
key3:
  key3-1: value3-1
  key3-2: value3-2
"""

# Generated at 2022-06-11 18:48:23.730706
# Unit test for function load_extra_vars
def test_load_extra_vars():
   # Tests a case where '''somevar''' is an empty string.
   # This should be handled gracefully and should not raise an exception
   assert not load_extra_vars({'somevar': ''})

# Generated at 2022-06-11 18:48:27.797653
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, type({}))

# Generated at 2022-06-11 18:48:38.705051
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test load_extra_vars
    # Test empty extra_vars
    assert {} == load_extra_vars(AnsibleLoader)

    # Test extra_vars with valid YAML
    # Define YAML strings
    yamls = [
        '@test_vars/vars_empty.yml',
        '@test_vars/vars_basic.yml',
        '@test_vars/vars_nested.yml',
        '@test_vars/vars_plain.yml',
    ]
    for yaml in yamls:
        vars = load_extra_vars(AnsibleLoader, yaml)

# Generated at 2022-06-11 18:48:45.889682
# Unit test for function isidentifier
def test_isidentifier():

    assert isidentifier('ident')
    assert isidentifier('ident_1')
    assert not isidentifier('1_ident')
    assert not isidentifier('ident!')
    assert not isidentifier('ident-1')
    assert not isidentifier('ident-1-1')
    assert not isidentifier('if')
    assert not isidentifier('ifelse')
    assert not isidentifier('ident-if')

    # New changes for this function
    assert not isidentifier('\xab')
    assert not isidentifier('True')
    assert not isidentifier('None')

# Generated at 2022-06-11 18:48:58.670784
# Unit test for function merge_hash

# Generated at 2022-06-11 18:49:13.107474
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    test_extra_vars = [
        u"@path",
        u"/path",
        u"{'test':''}",
        u"test"
    ]
    success = [loader.load_from_file(u"path"), {}, {u'test': u''}, {u'test': u''}]
    for i, (var, success) in enumerate(zip(test_extra_vars, success)):
        result = load_extra_vars(loader=loader, extra_vars=[])
        assert result == {}
        result = load_extra_vars(loader=loader, extra_vars=[var])
        assert result == success



# Generated at 2022-06-11 18:49:22.736948
# Unit test for function isidentifier
def test_isidentifier():
    '''
    isidentifier() unit tests
    '''
    # Valid identifiers
    # Python 2
    valid_py2 = [
        u'True',
        u'None',
        u'False',
        u'abc',
        u'abc_123',
        u'abc123',
        u'MyClass',
        u'_',
        u'_abc',
        u'_123',
    ]
    # Python 3

# Generated at 2022-06-11 18:49:24.826916
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict) is True

# Generated at 2022-06-11 18:49:35.895080
# Unit test for function merge_hash
def test_merge_hash():
    import unittest

    class TestMergeHash(unittest.TestCase):
        def test_base(self):
            d1 = {'a': 1, 'b': 2, 'c': 3}
            d2 = {'d': 4, 'e': 5}
            expected_output = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

            self.assertEqual(merge_hash(d1, d2), expected_output)
            self.assertEqual(merge_hash(d2, d1), expected_output)

        def test_override(self):
            d1 = {'a': 1, 'b': 2, 'c': 3}
            d2 = {'a': 4, 'e': 5}

# Generated at 2022-06-11 18:49:43.195812
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    extra_vars['ansible_version'] = 'Default'
    assert extra_vars == {'ansible_version': 'Default', 'some_host': {'host1': 'host_value'}, 'some_var': 'a_value'}

# Generated at 2022-06-11 18:49:53.590510
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    with open('test_load_extra_vars.json', 'w') as f:
        f.write('{"foo"  : "bar"}')
    with open('test_load_extra_vars.yaml', 'w') as f:
        f.write('foo: bar')

    opts = {'extra_vars': ['@test_load_extra_vars.yaml', 'foo=baz']}
    global_args = {
        'extra_vars': [
            '@test_load_extra_vars.yaml',
            '@test_load_extra_vars.json',
            'foo=baz'
        ],
    }

# Generated at 2022-06-11 18:50:03.373151
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({}, {}) == {}
    assert merge_hash({1: 1}, {}) == {1: 1}
    assert merge_hash({}, {1: 1}) == {1: 1}
    assert merge_hash({1: 1, 2: 2}, {}) == {1: 1, 2: 2}
    assert merge_hash({}, {1: 1, 2: 2}) == {1: 1, 2: 2}
    assert merge_hash({1: 1}, {2: 2}) == {1: 1, 2: 2}
    assert merge_hash({1: 1, 2: 2}, {3: 3}) == {1: 1, 2: 2, 3: 3}

# Generated at 2022-06-11 18:50:14.942176
# Unit test for function combine_vars
def test_combine_vars():
    def make_combine_vars_test(a, b, expected, merge):
        mix_result = combine_vars(a, b, merge=merge)
        assert mix_result == expected

    a = dict(x='x', y='y')
    b = dict(x='x2', z='z')
    c = dict(x='x', y='y', z='z')
    make_combine_vars_test(a, b, c, merge=True)
    make_combine_vars_test(a, b, b, merge=False)
    a = dict(x='x', y=dict(z='z'))
    b = dict(x='x2', y=dict(z='z2'), z=dict(z2='z2'))

# Generated at 2022-06-11 18:50:26.549059
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # pylint: disable=import-error
    import sys
    import os
    # pylint: enable=import-error

    # Load current file into sys.modules
    _, filename, _, _, _, _ = inspect.getmoduleinfo(__file__)
    module_name = os.path.splitext(os.path.basename(filename))[0]
    sys.modules[module_name] = sys.modules[__name__]

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    loader = DataLoader()
    vault_secrets = VaultLib({'ask_vault_pass': False, 'vault_password_file': None})

    assert load_extra_vars(loader) == {}
    assert load_extra

# Generated at 2022-06-11 18:50:39.479123
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import ansible.module_utils.common.loader as loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    example1 = {'var1': 'foo',
                'var2': 2,
                'var3': 'foo',
                'var4': 2,
                'var5': 'foo',
                'var6': False,
                'var7': 3}

    example2 = {'var1': 'foo',
                'var2': 2,
                'var3': 'foo',
                'var4': 2,
                'var5': 'foo',
                'var6': False,
                'var7': 3}


# Generated at 2022-06-11 18:51:01.161540
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(ImmutableDict({}), 'test', 'test', True)
    data = loader.load('''
    @test.yml
    {}
    1
    ''')

    extra_vars, unknown_vars = load_extra_vars(loader)
    assert extra_vars == {}
    assert unknown_vars == ['1']

# Generated at 2022-06-11 18:51:10.936938
# Unit test for function load_extra_vars
def test_load_extra_vars():
    class FakeLoader(object):
        pass
    class FakeOptions(object):
        pass

    fake_loader = FakeLoader()
    fake_loader.load_from_file = lambda s: s
    fake_loader.load = lambda s: s

    options = FakeOptions()

    def test_load_extra_vars(extra_vars, expected):
        options.extra_vars = extra_vars
        result = load_extra_vars(fake_loader)
        if result != expected:
            raise AssertionError("result didn't match expected value, "
                                 "got '%s' expected '%s'" % (result, expected))

    test_load_extra_vars(None, {})
    test_load_extra_vars([], {})

# Generated at 2022-06-11 18:51:21.734434
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({}, {}) == {}
    assert merge_hash({'a':1}, {}) == {'a':1}
    assert merge_hash({}, {'a':1}) == {'a':1}

    assert merge_hash({'a':1}, {'a':2}) == {'a':2}

    assert merge_hash({'a':{'b':1}}, {'a':{'c':2}}) == {'a':{'c':2}}
    assert merge_hash({'a':{'b':1}}, {'a':{'c':2}}, recursive=True) == {'a':{'b':1, 'c':2}}

    assert merge_hash({'a':['b']}, {'a':['c']}) == {'a':['c']}

# Generated at 2022-06-11 18:51:32.021093
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars_data = {'atest1': '123', 'btest2': 'abc'}
    extra_vars_file = './test/unit/utils/test_extra_vars.yml'
    # test loading extra vars from file
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'atest1': '123', 'btest2': 'abc', 'c': {'test1': 123, 'test2': 'abc'}}
    # test override variable
    extra_vars = []
    extra_vars.append('c.test2=def')
    extra_vars.append(extra_vars_file)

# Generated at 2022-06-11 18:51:43.452652
# Unit test for function merge_hash
def test_merge_hash():
    def assert_merge_hash(x, y, expected_z, recursive, list_merge, msg):
        z = merge_hash(x, y, recursive, list_merge)
        assert z == expected_z, msg + \
            "\n>>> merge_hash({}, {}, {}, {})\n  actual  : {}\n  expected: {}".format(
            x, y, recursive, list_merge, z, expected_z)


# Generated at 2022-06-11 18:51:48.301557
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = DictDataLoader(dict())
    assert load_extra_vars(loader) == {}, "load_extra_vars should return empty dict when args are empty"
    assert load_extra_vars(loader) == {}, "load_extra_vars should return empty dict when args are empty"

# Generated at 2022-06-11 18:52:00.901691
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    simple_yaml_vars_str = b"""
---
string_var: "foo"
int_var: 42
bool_var: True
list_var:
  - item1
  - item2
dict_var:
    key: value
"""

    simple_yaml_vars_file = b"""{"string_var": "foo", "int_var": 42, "bool_var": true, "list_var": ["item1", "item2"], "dict_var": {"key": "value"}}"""
