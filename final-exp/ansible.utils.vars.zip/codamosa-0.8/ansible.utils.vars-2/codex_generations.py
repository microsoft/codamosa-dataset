

# Generated at 2022-06-11 18:42:36.163139
# Unit test for function isidentifier
def test_isidentifier():
    # assertTrue / assertFalse with Python < 2.7 unittest
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class IsIdentifierTest(unittest.TestCase):
        def test_identifier(self):
            self.assertTrue(isidentifier('a'))
            self.assertTrue(isidentifier('_'))
            self.assertTrue(isidentifier('a_'))
            self.assertTrue(isidentifier('_a'))
            self.assertTrue(isidentifier('__a_'))

            # x509 commonName
            self.assertTrue(isidentifier('foo.example.org'))

# Generated at 2022-06-11 18:42:47.675586
# Unit test for function isidentifier
def test_isidentifier():

    # This test unifies the Python 2 and Python 3 behavior of isidentifier. The
    # following are the rules checked.
    #
    # - a valid identifier is not None, '' or empty length
    # - a valid identifier does not contain non-ascii characters and is not a
    #   keyword
    # - a valid identifier does not contain invalid characters
    # - True, False and None are reserved identifiers
    #
    # The test below is comprehensive and ported from Python 3.

    assert isidentifier('foo')
    assert isidentifier('FOO')
    assert isidentifier('_Foo')
    assert isidentifier('foo_123')
    assert not isidentifier('foo_')
    assert not isidentifier('1st')
    assert not isidentifier('True')
    assert not isidentifier('False')

# Generated at 2022-06-11 18:42:59.668395
# Unit test for function isidentifier
def test_isidentifier():
    assert(isidentifier('foo') is True)
    assert(isidentifier('_foo') is True)
    assert(isidentifier('_bar') is True)
    assert(isidentifier('foo_bar') is True)
    assert(isidentifier('Foo') is True)
    assert(isidentifier('Foo_bar') is True)
    assert(isidentifier('1foo') is False)
    assert(isidentifier('føø') is False)
    assert(isidentifier(u'føø') is False)
    assert(isidentifier(u'f\xf8\xf8') is False)
    assert(isidentifier(True) is False)
    assert(isidentifier(False) is False)
    assert(isidentifier(None) is False)

# Generated at 2022-06-11 18:43:07.738008
# Unit test for function load_extra_vars
def test_load_extra_vars():
    """
    Testcase:

    | - hosts: all
    |   vars:
    |     test: "{{ hostvars[inventory_hostname]['extra_var_a'] }}"
    |     test2: "{{ hostvars[inventory_hostname]['extra_var_b'] }}"
    |
    |   tasks:
    |     - debug:
    |         msg: "{{ test }} {{ test2 }}"
    |
    |   post_tasks:
    |     - debug:
    |         msg: "{{ test }} {{ test2 }}"

    Process:
        1. run above playbook with -e '{ "extra_var_a" : "a", "extra_var_b" : "b" }'
        2. make sure extra vars are loaded globally and merged correctly
    """
   

# Generated at 2022-06-11 18:43:20.240104
# Unit test for function merge_hash
def test_merge_hash():

    # give to each function call a name
    # to simplify the understanding of the assert statements
    def f(a, b, rec, lst):
        return merge_hash(a, b, recursive=rec, list_merge=lst)

    # hash
    assert f({'a': 1},                   # input a
             {'a': 2},                   # input b
             False,                      # recursive
             'replace') == {'a': 2}      # expected

    assert f({'a': 1},                   # input a
             {'a': 2},                   # input b
             True,                       # recursive
             'replace') == {'a': 2}      # expected


# Generated at 2022-06-11 18:43:27.369172
# Unit test for function load_extra_vars
def test_load_extra_vars():
    '''test load extra vars'''
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None)

    # Check if the function works when no extra vars are passed.
    assert load_extra_vars(loader) == {}

    # Check if the function works when extra vars are passed in a file.
    assert load_extra_vars(loader) == {}

# Generated at 2022-06-11 18:43:36.171194
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test if dict parameter is being passed correctly
    context.CLIARGS = {'extra_vars': [dict(a=1, b=2, c=3)]}
    result = load_extra_vars(loader)
    assert result == {'a': 1, 'b': 2, 'c': 3}

    # Test if param is empty
    context.CLIARGS = {'extra_vars': [[]]}
    result = load_extra_vars(loader)
    assert result == {}

    # Test if param value is YAML
    context.CLIARGS = {'extra_vars': ['a: 1\n b: 2']}
    result = load_extra_vars(loader)
   

# Generated at 2022-06-11 18:43:47.920642
# Unit test for function load_extra_vars
def test_load_extra_vars():
    class TestCLIARGS(object):
        def get(self, key):
            val = {
                'extra_vars': ['@test/test_dict'],
                'diff': True,
                'check': True,
                'forks': 10,
                'inventory': ['test/test_inv'],
                'skip_tags': ['tag1', 'tag2'],
                'subset': ['host1', 'host2'],
                'tags': ['tag3', 'tag4'],
                'verbosity': 4
            }.get(key)

            return val

    class TestLoader(object):
        def load_from_file(self, filename):
            return {'extra_var1': 'test'}

        def load(self, text):
            return {'extra_var2': 'test'}



# Generated at 2022-06-11 18:43:58.578285
# Unit test for function isidentifier

# Generated at 2022-06-11 18:44:09.035960
# Unit test for function combine_vars
def test_combine_vars():
    # basic test
    x = {'a': 1, 'b': 2}
    y = {'b': 3, 'd': 4}
    z = combine_vars(x, y)
    assert z == {'a': 1, 'b': 3, 'd': 4}

    # order is important
    z = combine_vars(y, x)
    assert z == {'a': 1, 'b': 2, 'd': 4}

    # test recursive
    x = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    y = {'b': {'d': 4}, 'e': {'f': 4}}
    z = combine_vars(x, y)

# Generated at 2022-06-11 18:44:25.706200
# Unit test for function merge_hash
def test_merge_hash():

    assert(merge_hash({}, {}) == {})
    assert(merge_hash({}, {'a': 1}) == {'a': 1})
    assert(merge_hash({'a': 1}, {}) == {'a': 1})
    assert(merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2})
    assert(merge_hash({'a': 1}, {'a': 2}) == {'a': 2})

    # recursive merge
    assert(merge_hash({'a': {'b': 1, 'c': 2}},
                      {'a': {'d': 3}},
                      recursive=True) ==
                      {'a': {'b': 1, 'c': 2, 'd': 3}})

# Generated at 2022-06-11 18:44:37.422057
# Unit test for function merge_hash
def test_merge_hash():
    '''
    Tests for merge_hash function

    This test is not exhaustive. It is intended to serve as a regression test.
    If new problems appear later that should be solved by an addition to this
    test.

    The test covers the following situations:
        - recursive merging
        - no recursive merging
        - higher priority to low priority list merging
        - low priority to high priority list merging (same thing)
        - list double element removal during merges
    '''

    # Test recursive merging
    d1 = {'a': {'A': 1, 'B': 2}, 'b': {'C': 3, 'D': 4}, 'c': {'E': 5, 'F': 6}}
    d2 = {'a': {'G': 7}, 'b': {'H': 8}, 'd': {'I': 9, 'J': 10}}

# Generated at 2022-06-11 18:44:49.333906
# Unit test for function merge_hash
def test_merge_hash():
    """
    Unit test for merge_hash
    """
    from collections import OrderedDict

    def get(opts, key, default=None):
        return opts[key] if key in opts else default

    def check(result, *args, **kwargs):
        for arg in args:
            if not isinstance(result, MutableMapping) or not isinstance(arg, MutableMapping):
                assert result == arg
                continue
            for key, value in iteritems(arg):
                if isinstance(value, MutableMapping):
                    check(result[key], value, **kwargs)
                else:
                    assert result[key] == value

    def ordereddict(**kwargs):
        return OrderedDict(kwargs)

    # Basic tests
    x = {'a' : 1}
    y

# Generated at 2022-06-11 18:45:00.690837
# Unit test for function load_extra_vars
def test_load_extra_vars():
    ''' test_load_extra_vars
    Tests load_extra_vars function
    '''
    # unit test for function load_extra_vars
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    try:
        from unittest import mock
    except ImportError:
        import mock

    # mock and patch the functions called by load_extra_vars
    # mock loader class
    mock_loader = mock.MagicMock(spec=AnsibleLoader)
    mock_loader.load_from_file.side_effect = ['data_from_file']
    mock_loader.load.side_effect = ['data_from_str']
    # mock and patch parse_kv

# Generated at 2022-06-11 18:45:11.196517
# Unit test for function merge_hash

# Generated at 2022-06-11 18:45:14.729641
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'x': 'y'}, "Failed to load extra vars."

if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-11 18:45:23.989619
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test empty extra var
    extra_vars = {'a':'1', 'b':'2'}
    context.CLIARGS = {'extra_vars': ''}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test no extra vars
    extra_vars = {'a':'1', 'b':'2'}
    context.CLIARGS = {}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test single extra var
    context.CLIARGS = {'extra_vars': 'c=3'}
    extra_vars = load_extra_v

# Generated at 2022-06-11 18:45:26.999692
# Unit test for function load_extra_vars
def test_load_extra_vars():
    #TODO: Add unit tests for function load_extra_vars
    pass


# Generated at 2022-06-11 18:45:38.273589
# Unit test for function merge_hash
def test_merge_hash():
    a = dict(
        A=1,
        B=dict(
            B1=[1, 2, 3],
            B2=dict(
                B2_1='a',
                B2_2='b',
            ),
        ),
        C=[1, 2, 3, 4],
    )

    b = dict(
        A=dict(
            A1=dict(
                A1_1=True,
                A1_2=None,
            ),
        ),
        B=dict(
            B1=[4, 5, 6],
            B2=dict(
                B2_2='c',
                B2_3='d',
            ),
        ),
        C=[5, 6, 7, 1],
        D='foo',
    )

    # When recursive is True, merge subdicts


# Generated at 2022-06-11 18:45:49.983823
# Unit test for function merge_hash

# Generated at 2022-06-11 18:46:02.858080
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    # test with recursive merge
    expected_result = {'a': {'b': '1', 'c': '2'}, 'b': '2'}
    extra_vars = load_extra_vars(loader)
    # test with non-recursive merge
    expected_result = {'a': {'b': '1', 'c': '2'}, 'b': '2'}
    extra_vars = load_extra_vars(loader, merge=False)

# Generated at 2022-06-11 18:46:03.831436
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert load_extra_vars({}) == {}

# Generated at 2022-06-11 18:46:14.933384
# Unit test for function load_options_vars
def test_load_options_vars():
    # With no options set
    opt = load_options_vars('2.3.0.0')
    assert opt == {'ansible_version': '2.3.0.0',
                   'ansible_check_mode': False,
                   'ansible_diff_mode': False,
                   'ansible_forks': 5,
                   'ansible_inventory_sources': None,
                   'ansible_skip_tags': [],
                   'ansible_limit': None,
                   'ansible_run_tags': [],
                   'ansible_verbosity': 0}

    # With some options set
    opt = load_options_vars('2.4.0.0')

# Generated at 2022-06-11 18:46:26.733876
# Unit test for function merge_hash
def test_merge_hash():

    # assert merge_hash({}, {}) == {}
    assert merge_hash(x={'a': 1, 'b': 2, 'c': 3}, y={}) == {'a': 1, 'b': 2, 'c': 3}
    assert merge_hash(x={}, y={'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}
    assert merge_hash(x={'a': 1}, y={'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash(x={'a': 1}, y={'a': 2}) == {'a': 2}

    x = {'a': 1, 'b': {'c': 2, 'd': 3, 'e': 4}}

# Generated at 2022-06-11 18:46:33.731603
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # empty string should return an empty dict
    assert load_extra_vars(None) == {}

    # an empty dict should return an empty dict
    assert load_extra_vars(None) == {}

    # test multiple vars
    assert load_extra_vars(None) == {}

    # test multiple vars with ansible options
    assert load_extra_vars(None) == {}

# Generated at 2022-06-11 18:46:44.648344
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import os
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    current_dir = os.path.dirname(os.path.realpath(__file__))
    vault_password = tempfile.NamedTemporaryFile(dir=current_dir)

    loader = AnsibleLoader(VaultLib([], vault_password.name))

    try:
        # Test that an empty string returns an empty dict
        load_extra_vars(loader)
    except AnsibleOptionsError:
        raise AssertionError

    # Test that a string which is not a JSON or a YAML is parsed with parse_kv
    test_kv = 'test=a random string'


# Generated at 2022-06-11 18:46:56.803726
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # Test if load_extra_vars fail if extra_vars has invalid YAML syntax
    test_input = '[{a: b}'
    try:
        load_extra_vars(test_input)
        assert False
    except AnsibleError:
        pass
    # Test if load_extra_vars fail if extra_vars has non-JSON syntax
    test_input = 'a : b'
    try:
        load_extra_vars(test_input)
        assert False
    except AnsibleError:
        pass
    # Test if load_extra_vars fail if extra_vars has valid JSON syntax, but
    # incorrect structure
    test_input = '[1,2,3]'

# Generated at 2022-06-11 18:47:05.670070
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    # test load_extra_vars
    loader = DataLoader()
    def load_from_file(path):
        return {}
    def load(data):
        return {}
    loader.load_from_file = load_from_file
    loader.load = load
    class MockCLIArgs():
        def __init__(self):
            self.extra_vars=['@x.yml', '@z.yml', 'a=b c=d']

    context.CLIARGS = MockCLIArgs()
    extra_vars = load_extra_vars(loader)
    assert len(extra_vars) == 2

# Generated at 2022-06-11 18:47:16.132756
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader

    # Short-circuit DataLoader for testing
    class CustomDataLoader(DataLoader):
        def __init__(self, *args, **kwargs):
            pass
        def get_basedir(self, *args, **kwargs):
            return '/tmp'
        def load_from_file(self, *args, **kwargs):
            return {'@/tmp/a': {'b': 2}}
        def load(self, *args, **kwargs):
            return {'{b: 2}': {'b': 3}}

    # Make sure YAML files are loaded
    assert load_extra_vars(CustomDataLoader()) == {'b': 3}

    # Make sure YAML data is loaded

# Generated at 2022-06-11 18:47:24.833600
# Unit test for function merge_hash
def test_merge_hash():
    # some tests
    assert merge_hash({}, {}) == {}
    assert merge_hash({}, {'a':'b'}) == {'a': 'b'}
    assert merge_hash({'a':'b'}, {}) == {'a': 'b'}
    assert merge_hash({'a':'b'}, {'a':'c'}) == {'a': 'c'}
    assert merge_hash({'a':'b'}, {'a':'c'}, recursive=False) == {'a': 'c'}
    assert merge_hash({'a':'b'}, {'a':'c'}, list_merge='keep') == {'a': 'b'}
    assert merge_hash({'a':'b'}, {'a':'c'}, list_merge='append')

# Generated at 2022-06-11 18:47:34.377472
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    

# Generated at 2022-06-11 18:47:45.119177
# Unit test for function load_extra_vars
def test_load_extra_vars():
    """
    Utility function to run tests on load_extra_vars()
    """
    import os
    from ansible.parsing.dataloader import DataLoader

    # Prepare the environment
    os.environ['ANSIBLE_ROLES_PATH'] = '../../../../'

    cur_dir = os.getcwd()

    # FIXME: We are missing tests for the case where extra_vars_opt
    # is missing or empty

    # Test for YAML file
    extra_vars_opt = '@'+ cur_dir + '/../../../../test/utils/test_load_extra_vars.yml'
    data = load_extra_vars(DataLoader())[0]
    assert(data.get('test_inline') == 'test_inline')

# Generated at 2022-06-11 18:47:58.048826
# Unit test for function load_extra_vars
def test_load_extra_vars():

    # Python 2 and 3 compatible syntax
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class Loader:
        def load_from_file(self, name):
            if name == 'dict':
                return {"a": "b", "c": "d"}
            if name == 'file_empty':
                return {}
            if name == 'dict_single_key':
                return {"a": "b"}
            if name == 'dict_single_value':
                return {"a": "b"}
            if name == 'dict_flat':
                return {"a": "b", "c": "d"}
            if name == 'dict_dict':
                return {"a": {"b": "c", "d": "e"}, "f": {"g": "h"}}

# Generated at 2022-06-11 18:47:59.205183
# Unit test for function load_extra_vars
def test_load_extra_vars():
    utils.load_extra_vars(loader)

# Generated at 2022-06-11 18:48:00.995837
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert load_extra_vars({}) == {}

# Generated at 2022-06-11 18:48:10.798701
# Unit test for function merge_hash
def test_merge_hash():
    # test the 'replace' list_merge behavior
    assert {} == merge_hash(
        {'a': 1, 'b': 2},
        {'b': 3, 'c': 4},
        recursive=True,
        list_merge='replace'
    )
    assert {'a': 1, 'b': [1, 2, 3], 'c': 4, 'd': 5, 'e': [1, 2,3]} == merge_hash(
        {'a': 1, 'b': [1, 2], 'd': 5, 'e': [1, 2]},
        {'b': [1, 2, 3], 'c': 4, 'e': [1, 2, 3]},
        recursive=True,
        list_merge='replace'
    )

# Generated at 2022-06-11 18:48:18.031214
# Unit test for function merge_hash
def test_merge_hash():
    print(__name__ + ": test_merge_hash()")

    def _test_merge_hash(x, y, recursive=True, list_merge='replace'):
        return to_text(merge_hash(x, y, recursive, list_merge))

    assert _test_merge_hash({}, {}, True, 'replace') == "{}"
    assert _test_merge_hash({}, {"a": "b"}, True, 'replace') == '{"a": "b"}'
    assert _test_merge_hash({}, {"a": "{}"}, True, 'replace') == '{"a": "{}"}'
    assert _test_merge_hash({}, {"a": "[]"}, True, 'replace') == '{"a": "[]"}'

# Generated at 2022-06-11 18:48:26.370305
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    # Note: InventoryManager is used because it will set module_name and forks
    # which load_extra_vars uses.
    inventory_manager = InventoryManager(loader=loader, sources='localhost,')
    inventory = inventory_manager.get_inventory_object('localhost')

    assert load_extra_vars(loader) == {}

    extra_vars = {'hello': 'world'}
    assert load_extra_vars(loader) == {}

    assert load_extra_vars(loader) == {}

    assert load_extra_vars(loader) == {}

    extra_vars = {'hello': 'world'}
    assert load_extra_vars(loader) == {}

# Generated at 2022-06-11 18:48:37.997577
# Unit test for function merge_hash
def test_merge_hash():
    from ansible.compat.tests import unittest

    class MergeHashAnsible(unittest.TestCase):
        def test_empty_dict(self):
            self.assertEqual(merge_hash({}, {}), {})
            self.assertEqual(merge_hash({}, {1: 1}), {1: 1})
            self.assertEqual(merge_hash({1: 1}, {}), {1: 1})

        def test_replace(self):
            # dicts
            self.assertEqual(merge_hash({'A': {'A1': 1}}, {'A': 2}), {'A': 2})

# Generated at 2022-06-11 18:48:48.166080
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml import DataLoader
    loader = DataLoader()
    # Test that the dicts have been merged
    extra_vars_1 = {'ansible_ssh_port': 1234}
    extra_vars_2 = {'ansible_ssh_host': 'example.org'}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == dict()
    extra_vars = load_extra_vars(loader, extra_vars_1)
    assert extra_vars == extra_vars_1
    extra_vars = load_extra_vars(loader, extra_vars_2)
    assert extra_vars == extra_vars_2

# Generated at 2022-06-11 18:49:03.333683
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import vars_loader

    vars_manager = vars_loader.VarsModule()
    loader = DataLoader()
    extra_vars = {}

    # Empty strings not added
    # extra_vars is unchanged
    extra_vars_opt = ''
    extra_vars = load_extra_vars(extra_vars, loader, extra_vars_opt)
    assert extra_vars == {}

    # None not added
    # extra_vars is unchanged
    extra_vars_opt = None
    extra_vars = load_extra_vars(extra_vars, loader, extra_vars_opt)
    assert extra_vars == {}

    # Test file reference ('/some/path.yml')

# Generated at 2022-06-11 18:49:12.633404
# Unit test for function merge_hash
def test_merge_hash():
    from ansible.module_utils.six import PY2, PY3
    from collections import OrderedDict

    assert merge_hash({}, {}) == {}

    assert merge_hash({1: 2}, {1: 3}) == {1: 3}

    assert merge_hash({1: 'a'}, {2: 'b'}) == {1: 'a', 2: 'b'}

    assert merge_hash({'a': 'a', 'b': 'b'}, {'a': 'c'}) == {'a': 'c', 'b': 'b'}

    assert merge_hash({1: 'a', 2: 'b'}, {1: 'c'}) == {1: 'c', 2: 'b'}

    assert merge_hash({1: {2: 3}}, {1: {4: 5}})

# Generated at 2022-06-11 18:49:14.144280
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert load_extra_vars() == {}


# Generated at 2022-06-11 18:49:17.021823
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # Always use the same loader instance for testing, as some loaders
    # have state that can mutate the results (ie: vault secret loading)
    loader = DataLoader()
    assert load_extra_vars(loader) == {}

# Generated at 2022-06-11 18:49:24.522961
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    mock_loader = AnsibleLoader(None, False)

    assert load_extra_vars(mock_loader) == {}

    assert load_extra_vars(mock_loader, ['-e', '@/etc/ansible/vars.yml']) == {'var1': 'example.com', 'var2': 'secret.com'}


# Generated at 2022-06-11 18:49:35.861744
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    assert load_extra_vars(None) == {}

    assert load_extra_vars(None, ("")) == {}
    assert load_extra_vars(None, ("", "", "")) == {}

    if PY3:
        assert load_extra_vars(None, ("key=value",)) == {"key": AnsibleUnicode("value")}
        assert load_extra_vars(None, ("key=value", "key2=value2")) == \
            {"key": AnsibleUnicode("value"), "key2": AnsibleUnicode("value2")}

# Generated at 2022-06-11 18:49:38.575511
# Unit test for function load_extra_vars
def test_load_extra_vars():
    extra_vars = load_extra_vars(None) # type: ignore
    assert extra_vars == {}

# Generated at 2022-06-11 18:49:48.743284
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    # load_extra_vars() is called by AnsibleCLI with a DataLoader instance
    # To successfully load a YAML file, a DataLoader instance with a current
    # directory must exist.
    dl = DataLoader()
    dl.set_basedir(".")
    extra_vars_list = ['a=1', '@my_yaml_file.yaml', '@my_json_file.json',
                       '@my_nonexistent_file', '', '    ', '{}']

# Generated at 2022-06-11 18:50:00.702048
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('_foo')
    assert isidentifier('_foo_1')
    assert isidentifier('foo_bar')
    assert isidentifier('_foo_bar_1')
    assert isidentifier('__foo')
    assert isidentifier('_foo__bar')
    assert isidentifier('__foo__bar__')
    assert isidentifier('_1')
    assert isidentifier('__1234')
    assert not isidentifier('1foo')
    assert not isidentifier('foo!')
    assert not isidentifier('$foo')
    assert not isidentifier('foo bar')
    assert not isidentifier('foo\\')
    assert not isidentifier('True')
    assert not isidentifier('False')
    assert not isidentifier('None')

# Generated at 2022-06-11 18:50:14.134276
# Unit test for function merge_hash
def test_merge_hash():
    from ansible.module_utils._text import to_text

    import unittest

    class MergeHashTestCase(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(merge_hash({}, {}), {})
            self.assertEqual(merge_hash({'a': 1}, {}), {'a': 1})
            self.assertEqual(merge_hash({}, {'a': 1}), {'a': 1})

        def test_non_recursive_merge_dict(self):
            self.assertEqual(
                merge_hash({'a': {'b': 1}}, {'a': {'c': 2}}, recursive=False),
                {'a': {'c': 2}},
            )


# Generated at 2022-06-11 18:50:28.337096
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    vars = load_extra_vars(loader)
    assert vars == {}

    vars = load_extra_vars(loader)
    assert vars == {}

    context.CLIARGS['extra_vars'] = [u"@test/test_1.yaml"]
    vars = load_extra_vars(loader)
    assert vars == {u"a": u"b"}

    context.CLIARGS['extra_vars'] = [u"@test/test_1.json"]
    vars = load_extra_vars(loader)
    assert vars == {u"a": u"b"}


# Generated at 2022-06-11 18:50:38.526444
# Unit test for function isidentifier
def test_isidentifier():
    valid_identifiers = {
        "f",
        "fo",
        "foo",
        "foo_bar",
        "fooBar",
    }

    invalid_identifiers = {
        "1f",
        "-foo",
        "foo!",
        "",
        None,
        False,
        True,
        None,
        "foo bar",
        "True",
        "False",
        "None",
    }

    for ident in valid_identifiers:
        assert isidentifier(ident)

    for ident in invalid_identifiers:
        assert not isidentifier(ident)



# Generated at 2022-06-11 18:50:48.192125
# Unit test for function load_extra_vars
def test_load_extra_vars():
    ''' test_load_extra_vars
    This will test the load_extra_vars function for positive and negative cases.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = load_extra_vars(loader)
    assert variable_manager._extra_vars == {'foo': 'bar', 'xyz': '123'}

# Generated at 2022-06-11 18:50:59.093400
# Unit test for function load_extra_vars
def test_load_extra_vars():

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # test no extra vars
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # test extra vars as file
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # test extra vars as yaml string
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # test extra vars as json string
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # test extra vars as key-value string
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}



# Generated at 2022-06-11 18:51:03.931986
# Unit test for function load_options_vars
def test_load_options_vars():
    version = "1.2.3.4"
    assertion_data = {
        'ansible_version': version
    }
    options_vars = load_options_vars(version)
    assert options_vars == assertion_data, "ansible_version is not 1.2.3.4"

# Generated at 2022-06-11 18:51:15.830132
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash(
        {'a': 1, 'd': {'a': 3, 'b': 4}, 'e': 5, 'g': {'a': 6}, 'l': 7},
        {'b': 2, 'd': {'c': 9, 'b': 10}, 'f': 5, 'g': {'a': 8, 'f': 9}, 'l': {'a': 'x'}}
    ) == {
        'a': 1, 'b': 2, 'd': {'c': 9, 'b': 10, 'a': 3}, 'e': 5, 'f': 5, 'g': {'a': 8, 'f': 9}, 'l': {'a': 'x'}
    }

# Generated at 2022-06-11 18:51:24.073683
# Unit test for function load_extra_vars
def test_load_extra_vars():
    ''' test_load_extra_vars()
        Unit test for function : load_extra_vars()
    '''
    context.CLIARGS = {'extra_vars': tuple()}
    assert load_extra_vars(None) == {}

    context.CLIARGS = {'extra_vars': ('{}', )}
    assert load_extra_vars(None) == {}

    context.CLIARGS = {'extra_vars': ('@x', )}
    assert load_extra_vars(None) == {}

    context.CLIARGS = {'extra_vars': ('x=1', )}
    assert load_extra_vars(None) == {"x": "1"}


# Generated at 2022-06-11 18:51:32.864182
# Unit test for function load_extra_vars
def test_load_extra_vars():
    ''' load_extra_vars should return a copy of a given dictionary '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import combine_vars, load_extra_vars

    context.CLIARGS = {}
    loader = DataLoader()
    a = {'a': 1, 'b': 2}
    b = {'c': 3, 'd': 4}
    context.CLIARGS['extra_vars'] = ['@test_vars1.yaml', '@test_vars2.yaml', '{a: 1, b: 2}']
    context.CLIARGS = dict(context.CLIARGS)
    vars = load_extra_vars(loader)
    for key in vars:
        assert vars[key]

# Generated at 2022-06-11 18:51:40.091396
# Unit test for function load_options_vars
def test_load_options_vars():
    # Test that version and check_mode works

    version='2.2.0'
    cliargs = dict()
    cliargs['check'] = True

    options_vars = load_options_vars(version)

    assert(options_vars['ansible_version'] == version)
    assert(options_vars['ansible_check_mode'] == True)
    assert(options_vars['ansible_diff_mode'] == False)



# Generated at 2022-06-11 18:51:47.999676
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    import os

    options_vars = {'ansible_version': '2.9.6', 'ansible_check_mode': True, 'ansible_forks': 2}

    if os.path.isfile('examples/test_extra_vars.yml'):
        loader = DataLoader()
        results = load_extra_vars(loader)
        assert results == options_vars, results

# Generated at 2022-06-11 18:52:04.413251
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = [
        "@" + os.path.join(os.path.dirname(__file__), "../tests/units/ansible/testdata/vars.yaml"),
        "foo=bar",
        "'{\"my_var\": \"my_value\"}'",
        "{\"my_var\": \"my_value\"}",
        "{\"my_list\": [\"item1\", \"item2\"]}",
        "{'my_list': ['item1', 'item2']}"
    ]

    result = load_extra_vars(loader)