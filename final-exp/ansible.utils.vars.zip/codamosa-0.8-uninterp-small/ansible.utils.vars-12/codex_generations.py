

# Generated at 2022-06-25 13:44:52.424824
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = None
    assert False # TODO implement your test here


# Generated at 2022-06-25 13:45:02.662273
# Unit test for function combine_vars

# Generated at 2022-06-25 13:45:13.392350
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible import constants as C
    from ansible.plugins.loader import connection_loader, module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars, load_extra_vars
    import os
    import pytest
    test_dir = os.path.dirname(os.path.realpath(__file__))
    fixture_dir = os.path.join(test_dir, "fixtures")
    yaml_path = os.path.join(fixture_dir, 'test_load_extra_vars.yml')
    # fmt: off

# Generated at 2022-06-25 13:45:23.860391
# Unit test for function merge_hash
def test_merge_hash():
    mydict1 = {
        "x": "y",
        "my": {"name": "toto", "surname": "titi"},
        "mylist": [1, 2, 3, 4]
    }

    mydict2 = {
        "x": "z",
        "my": {"name": "tata", "age": 10},
        "mylist": [5, 6, 7, 8, 9]
    }

    mydict3 = {
        "x": "z",
        "my": {
            "name": "tata",
            "surname": "titi",
            "age": 10
        },
        "mylist": [1, 2, 3, 4, 5, 6, 7, 8, 9]
    }


# Generated at 2022-06-25 13:45:35.734581
# Unit test for function merge_hash
def test_merge_hash():
    a = {'a': '1', 'b': '2', 'c': {'d': '3', 'e': '4'}, 'f': ['5', '6']}
    b = {'a': '7', 'b': '8', 'c': {'d': '9', 'e': '10'}, 'g': ['11', '12']}
    c = {'a': '7', 'b': '8', 'c': {'d': '9', 'e': '10'}, 'f': ['5', '6', '11', '12']}
    d = {'a': '7', 'b': '8', 'c': {'d': '9', 'e': '10'}, 'f': ['11', '12', '5', '6']}


# Generated at 2022-06-25 13:45:41.962115
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # Load stubs
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    extra_vars = '-e var_1=1 -e var_2=2 -e var_3=3'
    expected_result = {"var_3": 3, "var_2": 2, "var_1": 1}
    result = load_extra_vars(loader)
    assert result == expected_result

# Generated at 2022-06-25 13:45:53.496688
# Unit test for function merge_hash
def test_merge_hash():
    from collections import OrderedDict

    a = OrderedDict([('a',1), ('b',2), ('d',4)])
    b = OrderedDict([('b',20), ('c',3), ('d',40)])
    assert merge_hash(a, b) == OrderedDict([('a', 1), ('b', 20), ('d', 40), ('c', 3)])

    a = OrderedDict([('a',1), ('b',2), ('d',4)])
    b = OrderedDict([('b',20), ('c',3), ('d',40)])
    assert merge_hash(a, b, recursive=False) == OrderedDict([('a', 1), ('b', 20), ('d', 40), ('c', 3)])


# Generated at 2022-06-25 13:46:00.966610
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({}, {}) == {}
    assert merge_hash({'a': 1}, {}) == {'a': 1}
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': {'b': 1}}, {'a': {'b': 2}}) == {'a': {'b': 2}}
    assert merge_hash({'a': {'b': 1, 'c': 1}}, {'a': {'b': 2}}) == {'a': {'b': 2, 'c': 1}}

# Generated at 2022-06-25 13:46:10.882795
# Unit test for function merge_hash
def test_merge_hash():
    a = {"a": 1}
    b = {"a": 2, "b": 3}
    assert merge_hash(a, b) == {"a": 2, "b": 3}
    assert merge_hash(a, b, recursive=False) == {"a": 2, "b": 3}
    assert merge_hash(a, b, False, 'replace') == {"a": 2, "b": 3}
    assert merge_hash(a, b, True, 'replace') == {"a": 2, "b": 3}
    assert merge_hash(a, b, True, 'keep') == {"a": 1, "b": 3}
    assert merge_hash(a, b, True, 'append') == {"a": 1, "b": 3}

# Generated at 2022-06-25 13:46:11.709577
# Unit test for function merge_hash
def test_merge_hash():
    assert False



# Generated at 2022-06-25 13:46:26.807243
# Unit test for function isidentifier
def test_isidentifier():
    assert (
        isidentifier('test')
    )

    assert (
        isidentifier('_test')
    )

    if PY3:
        assert (
            isidentifier('_987')
        )

    assert (
        not isidentifier('987')
    )

    assert (
        not isidentifier('9test')
    )

    assert (
        not isidentifier('test-test')
    )

    assert (
        not isidentifier('')
    )

    assert (
        not isidentifier('-test')
    )

    assert (
        not isidentifier('if')
    )

    assert (
        not isidentifier('_if')
    )

    assert (
        not isidentifier('True')
    )


# Generated at 2022-06-25 13:46:27.416859
# Unit test for function load_extra_vars
def test_load_extra_vars():
    test_case_0()

# Generated at 2022-06-25 13:46:30.114790
# Unit test for function merge_hash
def test_merge_hash():
    x = {'a': 5}
    y = {'b': 6}
    assert merge_hash(x, y) == {'a': 5, 'b': 6}
    assert merge_hash(y, x) == {'a': 5, 'b': 6}
    assert merge_hash(x, x) == {'a': 5}


# Generated at 2022-06-25 13:46:36.731195
# Unit test for function merge_hash
def test_merge_hash():
    # Test case for the merge_hash function
    dict_0 = dict(zip(range(0,3), range(0,3)))
    dict_1 = dict(zip(range(3,6), range(3,6)))
    dict_2 = dict(zip(range(0,6), range(0,6)))
    dict_3 = dict(zip(range(0,3), range(3,6)))
    dict_4 = dict(zip(range(0,6), range(6,12)))
    dict_5 = dict(zip(range(0,6), range(12,18)))
    dict_6 = dict(zip(range(0,6), range(6,12)))
    dict_7 = dict(zip(range(6,12), range(6,12)))

# Generated at 2022-06-25 13:46:37.822241
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # iterators.cycle
    test_case_0()



# Generated at 2022-06-25 13:46:38.795896
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert 1 == 1


# Generated at 2022-06-25 13:46:47.220188
# Unit test for function merge_hash
def test_merge_hash():

    # test: merge_hash(x, y, recursive=True, list_merge='replace')
    x = {'a': [1, 2, 3], 'b': {'c': 'C', 'd': 'D'}}
    y = {'a': ['a'], 'z': 'Z'}
    expected = {'a': ['a'], 'b': {'c': 'C', 'd': 'D'}, 'z': 'Z'}
    actual = merge_hash(x, y)
    assert expected == actual

    # test: merge_hash(x, y, recursive=False, list_merge='replace')
    x = {'a': [1, 2, 3], 'b': {'c': 'C', 'd': 'D'}}

# Generated at 2022-06-25 13:46:51.794638
# Unit test for function combine_vars
def test_combine_vars():
    a = dict(foo=1,bar=2)
    b = dict(foo=2,baz=3)
    expected_result = dict(foo=2, bar=2, baz=3)
    assert combine_vars(a,b, merge=True) == expected_result


# Generated at 2022-06-25 13:46:53.915377
# Unit test for function load_options_vars
def test_load_options_vars():
    version = b'1.0'
    var_0 = load_options_vars(version)


# Generated at 2022-06-25 13:46:57.430968
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)


# Generated at 2022-06-25 13:47:11.876924
# Unit test for function isidentifier
def test_isidentifier():
    def test_identifier(identifier):
        if isidentifier(identifier) != True:
            raise Exception("Invalid identifier: '%s'" % identifier)

    def test_not_identifier(identifier):
        if isidentifier(identifier) != False:
            raise Exception("Invalid identifier: '%s'" % identifier)

    good_identifiers = [
        'a',
        'abc',
        'abc123',
        'abc_123',
        '_abc',
    ]
    for good_identifier in good_identifiers:
        test_identifier(good_identifier)

    bad_identifiers = [
        '',
        '123',
        'a b',
        'A',
        'a\xfd',
        'true',
        'def',
    ]

# Generated at 2022-06-25 13:47:14.183977
# Unit test for function load_extra_vars
def test_load_extra_vars():
  bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
  assert False
#}

# Generated at 2022-06-25 13:47:19.584230
# Unit test for function combine_vars
def test_combine_vars():
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert None in ['', '', '']
    assert "a" in "b"

# Generated at 2022-06-25 13:47:20.516688
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert True


# Generated at 2022-06-25 13:47:28.963756
# Unit test for function combine_vars
def test_combine_vars():
    # Test if the given dicts are same
    assert combine_vars(
        {'a': 1, 'c': {'f': {'h': 'hi', 'i': 1}}},
        {'b': 2, 'c': {'f': {'g': 'go', 'i': 2}}}) == \
        {'a': 1, 'c': {'f': {'h': 'hi', 'g': 'go', 'i': 2}}, 'b': 2}
    # Test if the given dicts are same

# Generated at 2022-06-25 13:47:38.681903
# Unit test for function load_extra_vars
def test_load_extra_vars():
    new_loader = AnsibleLoader()
    new_extra_vars_opt = '@/home/runner/work/ansible-base/ansible-base/test/units/loader/source_dir/test/test_data/test_vars/json/var.json'
    new_extra_vars_opt_2 = '@/home/runner/work/ansible-base/ansible-base/test/units/loader/source_dir/test/test_data/test_vars/json/var_2.json'
    var_0 = load_extra_vars(new_loader)(new_extra_vars_opt, (new_extra_vars_opt_2))
    assert len(var_0) == 2

# Generated at 2022-06-25 13:47:48.112550
# Unit test for function merge_hash
def test_merge_hash():
    # Start with two dicts
    dict1 = {"a": 1, "b": 2, "d": 4}
    dict2 = {"b": "BBB", "c": 3}

    # Start with two dicts
    list1 = [1, 2, 4]
    list2 = [5, 2, "BBB"]

    dict_with_list1 = {"a": 1, "b": 2, "c": [4, 1, 2]}
    dict_with_list2 = {"b": "BBB", "c": [1, 2, 3]}

    dict_with_nested_dict1 = {"a": 1, "b": 2, "c": {"d": 4, "e": 1}}

# Generated at 2022-06-25 13:47:50.427316
# Unit test for function load_extra_vars
def test_load_extra_vars():
    print('Function load_extra_vars, testing if bugs are fixed..')
    test_case_0()

if __name__ == '__main__':
    test_load_extra_vars()

# Generated at 2022-06-25 13:47:54.359168
# Unit test for function merge_hash
def test_merge_hash():
    try:
        merge_hash({}, {}, recursive=True, list_merge='replace')
        assert False, 'failed to assert merge_hash with bad list_merge'
    except AnsibleError as e:
        assert "merge_hash: 'list_merge' argument can only be equal to 'replace', 'keep', 'append', 'prepend', 'append_rp' or 'prepend_rp'" in str(e)



# Generated at 2022-06-25 13:48:00.420903
# Unit test for function load_extra_vars
def test_load_extra_vars():
    list_0 = []
    bytes_0 = b'\xaf\xe1\x94\x8d\xe9\x90\x15\x85\x80\xa2\x1a'
    opt = ""
    extra_vars_opt = ""
    data = ""
    attr = ""
    alias = ""
    opt = None
    extra_vars_opt = None
    data = None
    attr = None
    alias = None
# Tests:
    # Test of call to function merge_hash
    extra_vars = {}
    for list_0 in [to_text(context.CLIARGS.get('extra_vars', ))]:
        if list_0 is None or not list_0:
            continue
        if list_0.startswith(u"@"):
            data

# Generated at 2022-06-25 13:48:11.010420
# Unit test for function combine_vars
def test_combine_vars():
    a = {"a":"a"}
    b = {"b":"b"}
    results = combine_vars(a,b)
    assert set(results.keys()) == {"a","b"}
    assert results["a"] == "a"
    assert results["b"] == "b"
    assert id(results) != id(a)

# Generated at 2022-06-25 13:48:13.796099
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)
    return var_0

# Generated at 2022-06-25 13:48:23.039180
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-25 13:48:31.388584
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(bytes_0, bytes_0, False, None)

    assert(loader.get_single_data() == {})
    assert(loader.get_basedir() == bytes_0)

    # Load from a YAML file.
    content = b"name: foo\nkey: value\nlist: [1, 2, 3]\n"
    filename = bytes_0
    loader = AnsibleLoader(content, filename, False, None)

    assert(loader.get_single_data() == {'name': 'foo', 'key': 'value', 'list': [1, 2, 3]})
    assert(loader.get_basedir() == filename)

    # Load from a YAML string.
    content = ""
   

# Generated at 2022-06-25 13:48:32.710409
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # TODO: Python 3 specific test
    pass


# Generated at 2022-06-25 13:48:33.236617
# Unit test for function load_extra_vars
def test_load_extra_vars():
    pass

# Generated at 2022-06-25 13:48:44.203628
# Unit test for function load_extra_vars

# Generated at 2022-06-25 13:48:52.032373
# Unit test for function load_extra_vars
def test_load_extra_vars():
    try:
        test = load_extra_vars
        assert test.__doc__
        assert test.__doc__.strip() is not None
        assert test.__doc__.strip() != ""
        test_0 = []
        for i in range(20):
            test_0.append(random.randint(0, 10))
        test_1 = random.randint(0, 10)
        test_2 = random.randint(0, 10)
        test_3 = random.randint(0, 10)
        res_0 = test(test_0, test_1, test_2, test_3)
        assert res_0 is None or type(res_0) == type({})
        assert res_0 is not None
    except Exception as e:
        assert False



# Generated at 2022-06-25 13:48:52.843705
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert 1 == 0
    return

# Generated at 2022-06-25 13:48:54.348264
# Unit test for function combine_vars
def test_combine_vars():
    assert combine_vars({1:'1'},{2:'2'}) == {1:'1', 2:'2'}

# Generated at 2022-06-25 13:49:01.138420
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert True

# Generated at 2022-06-25 13:49:03.341577
# Unit test for function load_extra_vars
def test_load_extra_vars():
    result = load_extra_vars('')
    assert result == {}
    # assert False # TODO: implement your test here


# Generated at 2022-06-25 13:49:10.194879
# Unit test for function merge_hash
def test_merge_hash():
    d1 = { 'a': 1, 'b': 2 }
    d2 = { 'b': 3, 'c': 4 }
    assert(merge_hash(d1, d2) == { 'a': 1, 'b': 3, 'c': 4 })
    assert(merge_hash(d2, d1) == { 'b': 2, 'c': 4, 'a': 1 })
    d3 = { 'a': {'x': 5, 'y': 6} }
    assert(merge_hash(d1, d3) == { 'a': {'x': 5, 'y': 6}, 'b': 2 })
    assert(merge_hash(d3, d1) == { 'a': 1, 'b': 2 })
    d4 = { 'a': {'x': 7} }

# Generated at 2022-06-25 13:49:13.677924
# Unit test for function load_extra_vars
def test_load_extra_vars():
    print('Testing load_extra_vars()')
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)
    print('Expect var_0 to be {}')
    print('Actual var_0 is {}')

# Generated at 2022-06-25 13:49:16.173359
# Unit test for function load_extra_vars
def test_load_extra_vars():
    data1 = {'a': 1, 'b': 2}
    data2 = {'a': 3, 'c': 4}

    # Test replace HASH_BEHAVIOUR
    assert load_extra_vars(data1, data2) == data2

    # Test merge HASH_BEHAVIOUR
    assert load_extra_vars(data1, data2, merge=True) == {'a': 3, 'b': 2, 'c': 4}

# Generated at 2022-06-25 13:49:23.867757
# Unit test for function merge_hash
def test_merge_hash():
    x = {'a': {'b': {'c': {'d': 'test'}}}}
    y = {'a': {'b': 'hello'}}

    assert merge_hash(x, y)['a']['b'] == 'hello'
    assert merge_hash(x, y, recursive=False)['a']['b'] == 'hello'
    assert merge_hash(x, y, recursive=True)['a']['b'] == {'c': {'d': 'test'}}
    assert merge_hash(x, y, recursive=True)['a']['b'] != 'hello'
    assert merge_hash(x, y, recursive=True)['a']['b'] == {'c': {'d': 'test'}}


# Generated at 2022-06-25 13:49:30.292217
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # verify that load_extra_vars unwraps vars correctly
    # and doesn't just return the last list of vars
    # also verify vars are in the right order
    # first loaded vars should take precedence
    source_vars = [dict(a=1, b=2), dict(a=3, c=4)]
    expected_vars = dict(a=1, b=2, c=4)
    actual_vars = load_extra_vars(source_vars)
    assert actual_vars == expected_vars


# Generated at 2022-06-25 13:49:31.029072
# Unit test for function load_extra_vars
def test_load_extra_vars():
	test_case_0()

# Generated at 2022-06-25 13:49:39.437078
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({'A': 1}, {'B': 2}) == {'A': 1, 'B': 2}
    assert merge_hash({'A': 1, 'B': 1}, {'B': 2}) == {'A': 1, 'B': 2}
    assert merge_hash({'A': 1, 'B': {'C': 2}}, {'B': {'C': 3}}) == {'A': 1, 'B': {'C': 2}}
    assert merge_hash({'A': 1, 'B': {'C': 2}}, {'B': {'C': 3}}, recursive=True) == {'A': 1, 'B': {'C': 3}}

# Generated at 2022-06-25 13:49:45.312624
# Unit test for function load_options_vars
def test_load_options_vars():
    version = '0.0.0'

    options_vars = {'ansible_version': '0.0.0'}
    attrs = {'check': 'check_mode',
             'diff': 'diff_mode',
             'forks': 'forks',
             'inventory': 'inventory_sources',
             'skip_tags': 'skip_tags',
             'subset': 'limit',
             'tags': 'run_tags',
             'verbosity': 'verbosity'}

    for attr, alias in attrs.items():
        opt = 'opt'
        options_vars['ansible_%s' % alias] = opt

    for attr, alias in attrs.items():
        opt = 'opt'
        options_vars['ansible_%s' % alias] = opt

# Unit

# Generated at 2022-06-25 13:49:59.972473
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert load_extra_vars('A=B') == {u'A': 'B'}, "Failed to parse KV string"
    assert load_extra_vars('@data.json') == {u'foo': 'bar'}, "Failed to load json file"
    assert load_extra_vars('{"foo": "bar"}') == {u'foo': 'bar'}, "Failed to parse json string"
    assert load_extra_vars('[foo, "bar"]') == {u'foo': 'bar'}, "Failed to parse json list"
    assert load_extra_vars('[]') == {}, "Failed to parse empty json list"
    assert load_extra_vars('{}') == {}, "Failed to parse empty json object"

# Generated at 2022-06-25 13:50:00.828459
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert True


# Generated at 2022-06-25 13:50:02.259212
# Unit test for function load_extra_vars
def test_load_extra_vars():
    var = load_extra_vars()
    assert type(var) == dict
    assert var != {}


# Generated at 2022-06-25 13:50:11.735858
# Unit test for function merge_hash

# Generated at 2022-06-25 13:50:13.456669
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # Arguments:
    loader = None

    # Return type: dict
    return load_extra_vars(loader)


# Generated at 2022-06-25 13:50:18.262684
# Unit test for function combine_vars
def test_combine_vars():
    a = { u'foo': u'bar', u'test': 5, u'ansible_version': u'2.9.9' }
    b = { u'foo': u'qux', u'foo2': u'bar2' }
    c = combine_vars(a, b)
    assert c == {u'foo': u'qux', u'test': 5, u'ansible_version': u'2.9.9', u'foo2': u'bar2'}


# Generated at 2022-06-25 13:50:22.548425
# Unit test for function load_extra_vars
def test_load_extra_vars():
    extra_vars_0 = [b'\xcb\x90\xad\x9c\x0f\x9d\xb0\x8a\x07\xa0\xcf\x9e\x9e\xeb\x91\x99\xa7']
    extra_vars_1 = [b'\xcb\x90\xad\x9c\x0f\x9d\xb0\x8a\x07\xa0\xcf\x9e\x9e\xeb\x91\x99\xa7']
    var_0 = load_extra_vars(extra_vars_0, extra_vars_1)

# Generated at 2022-06-25 13:50:29.690972
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({},{}) == {}
    assert merge_hash({"a":1,"b":2,"c":3}, {"d":4}) == {"a":1,"b":2,"c":3,"d":4}
    assert merge_hash({"a":1,"b":2,"c":3}, {"a":4}) == {"a":4,"b":2,"c":3}
    assert merge_hash({"a":1,"b":2,"c":3}, {"a":4,"b":5,"c":6}) == {"a":4,"b":5,"c":6}

# Generated at 2022-06-25 13:50:30.513431
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert True, "Bogus unit test"



# Generated at 2022-06-25 13:50:31.896795
# Unit test for function merge_hash
def test_merge_hash():
    # merge_hash is not a function
    pass


# Generated at 2022-06-25 13:50:43.686004
# Unit test for function combine_vars
def test_combine_vars():
    var_0 = {'a':{'b':2}}
    var_1 = {'a':{'c':5}}
    output = combine_vars(var_0, var_1, True)
    output2 = combine_vars(var_0, var_1)
    expected_output = {'a':{'b':2, 'c':5}}
    assert output == expected_output
    assert output2 == expected_output



# Generated at 2022-06-25 13:50:44.530302
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert True


# Generated at 2022-06-25 13:50:52.272276
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({}, {"a": 1}) == {"a": 1}
    assert merge_hash({"a": 1}, {"a": 2}) == {"a": 2}
    assert merge_hash({"a": 1, "b": 2}, {"b": 3, "c": 4}) == {"a": 1, "b": 3, "c": 4}
    assert merge_hash({"a": {"b": 1}}, {"a": {"b": 2}}) == {"a": {"b": 2}}
    assert merge_hash({"a": [1]}, {"a": [2]}) == {"a": [2]}
    assert merge_hash({"a": [1]}, {"a": {"b": 2}}) == {"a": {"b": 2}}

# Generated at 2022-06-25 13:51:03.325677
# Unit test for function load_extra_vars

# Generated at 2022-06-25 13:51:05.084092
# Unit test for function load_extra_vars
def test_load_extra_vars():
    test_case_0()




# Generated at 2022-06-25 13:51:06.287871
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert callable(load_extra_vars)


# Generated at 2022-06-25 13:51:07.516257
# Unit test for function combine_vars
def test_combine_vars():
    assert combine_vars({"a": "b"}, {"c": "d"}) == {"a": "b", "c": "d"}



# Generated at 2022-06-25 13:51:12.195797
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('valid_identifier')
    assert isidentifier('valid_1dentifier')
    assert not isidentifier('invalid-identifier')
    assert not isidentifier('invalid identifier')
    assert not isidentifier('')
    assert not isidentifier('1')
    assert not isidentifier('a-1')
    assert not isidentifier('1-a')


# Generated at 2022-06-25 13:51:15.485759
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)
    if not isinstance(var_0, dict):
        raise Exception()


# Generated at 2022-06-25 13:51:25.610853
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'\x8a\x9e\x94\x11T\x8b\x90\xbc<\x18\x02\x8a\xa9\xb6\xe2\x98\x8bH\xdf\xd7\x06y'

# Generated at 2022-06-25 13:51:40.400844
# Unit test for function load_extra_vars

# Generated at 2022-06-25 13:51:45.869992
# Unit test for function load_extra_vars
def test_load_extra_vars():
    cur_test = 0
    #test_case_0
    cur_test += 1
    bytes_0 = b"\x00\x00\x00"
    result = load_extra_vars(bytes_0)
    assert result == {"extra_vars_opt": ["\x00\x00\x00"], "merge": True, "replace": False}

# Generated at 2022-06-25 13:51:54.845537
# Unit test for function load_extra_vars

# Generated at 2022-06-25 13:51:57.424850
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)



# Generated at 2022-06-25 13:52:07.425384
# Unit test for function load_options_vars
def test_load_options_vars():
    version = '2.0.2.0-1.el7.ansible_1.0.0.dev.rnd'
    expected_result = {'ansible_check_mode': False,
                       'ansible_diff_mode': False,
                       'ansible_forks': 5,
                       'ansible_inventory_sources': [
                           u'/usr/share/ansible/hosts'],
                       'ansible_skip_tags': set([]),
                       'ansible_limit': u'all',
                       'ansible_run_tags': set([]),
                       'ansible_verbosity': 0,
                       'ansible_version': u'2.0.2.0-1.el7.ansible_1.0.0.dev.rnd'}


# Generated at 2022-06-25 13:52:08.738718
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # dict
    assert isinstance(load_extra_vars('test'), dict)


# Generated at 2022-06-25 13:52:11.085141
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)



# Generated at 2022-06-25 13:52:13.347400
# Unit test for function load_extra_vars
def test_load_extra_vars():
    output = load_extra_vars(None)
    assert output is not None

if __name__ == '__main__':
    test_load_extra_vars()
    test_case_0()

# Generated at 2022-06-25 13:52:20.169327
# Unit test for function load_extra_vars
def test_load_extra_vars():
    b = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    r = context.CLIARGS.get('extra_vars')
    try:
        context.CLIARGS['extra_vars'] = b 
        result = load_extra_vars(b)
        context.CLIARGS['extra_vars'] = r
        assert True
    except Exception as e:
        context.CLIARGS['extra_vars'] = r
        assert False, "Raised exception: {}".format(e)


# Generated at 2022-06-25 13:52:21.617907
# Unit test for function load_extra_vars
def test_load_extra_vars():
    # Call function load_extra_vars with argument bytes_0
    assert False


# Generated at 2022-06-25 13:52:30.134650
# Unit test for function load_extra_vars
def test_load_extra_vars():

    # AnsibleOptionsError
    # Calls load_extra_vars
    assert isinstance(load_extra_vars(), {})


# Generated at 2022-06-25 13:52:38.264982
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import os
    import tempfile
    import pytest
    import json

    # Create a temporary file and write some test json data to it
    text = b'{"test": "data"}'
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as fo:
        fo.write(text)

    # Normal JSON loading should work with the test data
    data = json.loads(text)
    assert data == {u"test": u"data"}

    # test load_extra_vars with test data
    assert load_extra_vars(path) == {u"test": u"data"}

    # We are done with the tempfile, delete it
    os.remove(path)

# Generated at 2022-06-25 13:52:47.789556
# Unit test for function merge_hash
def test_merge_hash():
    data1={'a':1,'b':{'b1':'myb1','b2':'myb2'},'c':['c1','c2'],'d':'myd'}
    data2={'a':2,'b':{'b1':'newb1','b3':'myb3'},'c':['c2','c3'],'e':'mye'}

    # print(merge_hash(data1,data2,recursive=False))
    # print(merge_hash(data1,data2,recursive=True))
    # print(merge_hash(data1,data2,recursive=False,list_merge='append'))
    # print(merge_hash(data1,data2,recursive=False,list_merge='prepend'))


# Generated at 2022-06-25 13:52:51.524370
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'E\x94Y\xe1r\x83y\xa1\xfc\xa9i&\xda'
    var_0 = load_extra_vars(bytes_0)
    assert isinstance(var_0, dict)
    assert var_0 == {}


# Generated at 2022-06-25 13:52:52.420536
# Unit test for function load_extra_vars
def test_load_extra_vars():
    test_case_0()



# Generated at 2022-06-25 13:52:55.444975
# Unit test for function load_extra_vars
def test_load_extra_vars():
    bytes_0 = b'\xa5\xb7\x8c\x82"\x1f\xeb\xea\x8a\xaf\xd2\xfc'
    var_0 = load_extra_vars(bytes_0)



# Generated at 2022-06-25 13:52:57.899428
# Unit test for function load_extra_vars
def test_load_extra_vars():
    var_2 = load_extra_vars(var_1)
    assert var_2 == [('t_var', 't_val')]
var_1 = b'@my_vars.yaml\n'


# Generated at 2022-06-25 13:53:04.243362
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('_foo')
    assert isidentifier('_foo_')
    assert isidentifier('_')
    assert isidentifier('foo_bar')
    assert isidentifier('foo1')
    assert not isidentifier('')
    assert not isidentifier('1foo')
    assert not isidentifier('foo bar')
    assert not isidentifier('foo\x7fbaz')
    assert not isidentifier('True')
    assert not isidentifier('False')
    assert not isidentifier('None')
    # Python 2 does not consider these keywords
    assert isidentifier('True', python2=True)
    assert isidentifier('False', python2=True)
    assert isidentifier('None', python2=True)

    # check that passing the wrong argument produces an

# Generated at 2022-06-25 13:53:14.511216
# Unit test for function merge_hash
def test_merge_hash():
    # Define some initial data
    var_a = {'a':1, 'b':2, 'c':{'d':3, 'e':4}, 'f':[1,2,3], 'z':[5,5]}
    var_b = {'g':5, 'c':{'d':6, 't':8}, 'f':[4,5,6], 'z':[5,5]}

    # An empty hash should return without changing the source hash
    var_c = merge_hash(var_a, {}, recursive=True)
    if var_a != var_c:
        raise AssertionError('Merging an empty hash into %s did not return %s' % (var_a, var_a))

    # Try merging an empty hash with a non-empty hash
    var_c = merge_hash

# Generated at 2022-06-25 13:53:23.534155
# Unit test for function merge_hash
def test_merge_hash():
    dict1_0 = {}
    dict2_0 = {}
    assert merge_hash(dict1_0, dict2_0, list_merge='append_rp') == {}
    dict1_1 = {}
    dict2_1 = {'1': {'2': '2'}, '2': ['2', '2']}
    assert merge_hash(dict1_1, dict2_1, list_merge='append_rp') == dict2_1
    dict1_2 = {'1': {'2': '2'}, '2': ['2', '2']}
    dict2_2 = {'1': {'2': '2'}, '2': ['2', '2']}

# Generated at 2022-06-25 13:53:39.437971
# Unit test for function combine_vars
def test_combine_vars():
    myvar = {'foo': 'bar', 'spam': 'eggs'}
    myvar2 = {'foo': 'bar', 'spam': 'eggs', 'baz': 'quux'}
    myvar3 = {'foo': 'bar', 'spam': 'eggs', 'baz': 'quux', 'one': 1}
    myvar4 = {'foo': 'bar', 'spam': 'eggs', 'baz': 'quux', 'one': 1, 'list': [1, 2, 3, 4]}
    myvar5 = {'foo': 'bar', 'spam': 'eggs', 'baz': 'quux', 'one': 1, 'list': [1, 2, 3, 4], 'dict': {'foo': 'bar'}}

# Generated at 2022-06-25 13:53:39.959877
# Unit test for function load_extra_vars
def test_load_extra_vars():
    pass

# Generated at 2022-06-25 13:53:41.577279
# Unit test for function load_extra_vars
def test_load_extra_vars():
    loader = MockLoader()
    data = 'str'
    value = load_extra_vars(loader)
    assert value == data


# Generated at 2022-06-25 13:53:48.604838
# Unit test for function load_extra_vars
def test_load_extra_vars():
    host_vars = {
            'name': 'foo',
            'mnt_mnt': 'bar',
    }

    # Example with existing key
    result = load_extra_vars(host_vars)
    assert 'name' in result
    assert 'mnt_mnt' in result
    assert 'foo' == result['name']
    assert 'bar' == result['mnt_mnt']

    # Example with auto-generated key
    result = load_extra_vars({})
    assert 'foo' in result
    assert 'mnt_mnt' in result
    assert 'foo' == result['name']
    assert 'bar' == result['mnt_mnt']



# Generated at 2022-06-25 13:53:56.903433
# Unit test for function load_options_vars
def test_load_options_vars():
    # assign
    version = 'Unknown'

    # invoke
    options_vars = load_options_vars(version)

    # assert
    assert isinstance(options_vars, dict)
    assert 'ansible_version' in options_vars
    assert 'ansible_check_mode' in options_vars
    assert 'ansible_diff_mode' in options_vars
    assert 'ansible_forks' in options_vars
    assert 'ansible_inventory_sources' in options_vars
    assert 'ansible_skip_tags' in options_vars
    assert 'ansible_limit' in options_vars
    assert 'ansible_run_tags' in options_vars
    assert 'ansible_verbosity' in options_vars

# Generated at 2022-06-25 13:54:05.168946
# Unit test for function isidentifier

# Generated at 2022-06-25 13:54:09.328506
# Unit test for function isidentifier
def test_isidentifier():
    # These should be okay
    for ident in u'spam', u'spam42', u's_pam', u'_spam', u'_42spam' :
        assert isidentifier(ident)

    # These should not be okay
    for ident in u'spam^', u'spam-', u'spam$', u'spam#' :
        assert not isidentifier(ident)

# Generated at 2022-06-25 13:54:18.015084
# Unit test for function load_extra_vars

# Generated at 2022-06-25 13:54:27.538842
# Unit test for function isidentifier
def test_isidentifier():
    # Test cases:
    # Should return True
    assert(isidentifier('valid_identifier'))
    assert(isidentifier('foo1'))
    # Should return False
    assert(not isidentifier('invalid identifier'))
    assert(not isidentifier('1invalid'))
    assert(not isidentifier('invalid-identifier'))
    assert(not isidentifier('if'))
    # Use in grammar check
    assert(isidentifier(u'\u00f4ne'))
    assert(isidentifier(u'\u16a0'))
    assert(not isidentifier(u'\x09'))
    assert(not isidentifier(u'\uffef'))
    assert(not isidentifier('🐍'))

# Generated at 2022-06-25 13:54:34.628178
# Unit test for function merge_hash
def test_merge_hash():
    assert_1 = {'a': 1, 'b': 2}
    assert_2 = {1: 'a', 'a': 2, 4: 'c'}
    assert_3 = {'a': None, 1: 'a', 'b': 2}
    assert_4 = {'b': 2, 'a': 1}
    assert_5 = {'a': 1, 'b': 3}
    assert_6 = {1: 'a'}
    assert_7 = {1: 'a'}
    assert_8 = {1: 'a', 'b': 3}
    assert_9 = {'a': 1, 'b': None}
    assert_10 = {'a': 1, 'b': 2}
    assert_11 = {'a': 1, 'b': 2}