

# Generated at 2022-06-17 15:46:01.724808
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:46:11.810450
# Unit test for function merge_hash

# Generated at 2022-06-17 15:46:18.848427
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, [u"@/tmp/test.yml"])
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, [u"@/tmp/test.yml", u"@/tmp/test2.yml"])
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}


# Generated at 2022-06-17 15:46:23.025742
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:46:32.654810
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    assert merge_hash(x, y) == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 5, 'd': 6}
    assert merge_hash(x, y, recursive=True) == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 5, 'd': 6}

# Generated at 2022-06-17 15:46:44.813259
# Unit test for function merge_hash
def test_merge_hash():
    # test basic merge
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'b': 4, 'c': 5, 'd': 6}
    z = {'a': 1, 'b': 4, 'c': 5, 'd': 6}
    assert merge_hash(x, y) == z

    # test merge with list
    x = {'a': 1, 'b': 2, 'c': 3, 'd': [1, 2, 3]}
    y = {'b': 4, 'c': 5, 'd': [4, 5, 6], 'e': 7}
    z = {'a': 1, 'b': 4, 'c': 5, 'd': [4, 5, 6], 'e': 7}
    assert merge_hash(x, y) == z



# Generated at 2022-06-17 15:46:52.927627
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    z = merge_hash(x, y)
    assert z == {'a': 4, 'b': 5, 'c': 3, 'd': 6}

    # test with lists
    x = {'a': [1, 2, 3], 'b': [4, 5, 6]}
    y = {'a': [7, 8, 9], 'b': [10, 11, 12]}
    z = merge_hash(x, y)
    assert z == {'a': [7, 8, 9], 'b': [10, 11, 12]}

    # test with dicts and lists

# Generated at 2022-06-17 15:47:05.237611
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test with empty extra_vars
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with extra_vars as a string
    extra_vars = load_extra_vars(loader, extra_vars=['foo=bar'])
    assert extra_vars == {'foo': 'bar'}

    # Test with extra_vars as a list
    extra_vars = load_extra_vars(loader, extra_vars=['foo=bar', 'baz=qux'])
    assert extra_vars == {'foo': 'bar', 'baz': 'qux'}

    # Test with extra_vars as a dict
    extra_

# Generated at 2022-06-17 15:47:15.399382
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [1, 2, 3], 'f': [1, 2, 3]}
    y = {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': [1, 2, 3, 4], 'f': [4, 5, 6]}
    z = merge_hash(x, y)
    assert z == {'a': 1, 'b': {'c': 2, 'd': 4}, 'e': [1, 2, 3, 4], 'f': [4, 5, 6]}

    # test with lists
    x = [1, 2, 3]
    y = [4, 5, 6]
    z = merge_hash(x, y)
    assert z

# Generated at 2022-06-17 15:47:23.692670
# Unit test for function merge_hash
def test_merge_hash():
    # test merge_hash with different values of recursive and list_merge
    # and with different types of values
    # (dicts, lists, strings, ints, booleans, None)
    # and with different types of keys
    # (strings, ints, booleans)
    # and with different types of dicts
    # (dict, OrderedDict)

    # dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'd': 5}
    assert merge_hash(x, y) == {'a': 4, 'b': 2, 'c': 3, 'd': 5}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 2, 'c': 3, 'd': 5}


# Generated at 2022-06-17 15:47:41.806843
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('_foo_bar_baz_')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('_foo_bar_baz_1_')
    assert isidentifier('foo_bar_baz_1_2')

# Generated at 2022-06-17 15:47:54.721369
# Unit test for function combine_vars
def test_combine_vars():
    # Test for dicts
    a = {'a': 1, 'b': 2, 'c': 3}
    b = {'a': 2, 'b': 3, 'd': 4}
    c = {'a': 2, 'b': 3, 'd': 4}
    d = {'a': 2, 'b': 3, 'd': 4}
    e = {'a': 2, 'b': 3, 'd': 4}
    f = {'a': 2, 'b': 3, 'd': 4}
    g = {'a': 2, 'b': 3, 'd': 4}
    h = {'a': 2, 'b': 3, 'd': 4}
    i = {'a': 2, 'b': 3, 'd': 4}

# Generated at 2022-06-17 15:48:04.688570
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('_foo')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('_foo_bar_baz_1_')
    assert not isidentifier('foo bar')
    assert not isidentifier('foo-bar')
    assert not isidentifier('foo.bar')
    assert not isidentifier('foo$bar')
    assert not isidentifier('foo!bar')
    assert not isidentifier('foo@bar')
    assert not isidentifier('foo#bar')

# Generated at 2022-06-17 15:48:14.267473
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('_foo_bar_baz_')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('_foo_bar_baz_1_')
    assert isidentifier('foo_bar_baz_1_2')

# Generated at 2022-06-17 15:48:19.456328
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('foo_bar_')
    assert isidentifier('_')
    assert isidentifier('foo1')
    assert isidentifier('foo1_bar')
    assert isidentifier('foo1_bar1')
    assert isidentifier('foo1_bar1_')
    assert isidentifier('_foo1')
    assert isidentifier('_foo1_bar')
    assert isidentifier('_foo1_bar1')
    assert isidentifier('_foo1_bar1_')
    assert isidentifier('foo_bar1')
    assert isidentifier('_foo_bar1')

# Generated at 2022-06-17 15:48:28.309686
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@test.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {u'foo': u'bar'}

    context.CLIARGS = {'extra_vars': [u'@test.yml', u'@test2.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {u'foo': u'bar', u'baz': u'qux'}


# Generated at 2022-06-17 15:48:38.257830
# Unit test for function isidentifier
def test_isidentifier():
    # Test valid identifiers
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('_foo_bar_baz_')
    assert isidentifier('_')
    assert isidentifier('__')
    assert isidentifier('__foo')
    assert isidentifier('__foo__')
    assert isidentifier('__foo__bar')
    assert isidentifier('__foo__bar__')
    assert isidentifier('__foo__bar__baz')

# Generated at 2022-06-17 15:48:42.296667
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:48:51.181125
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test empty extra_vars
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    # Test extra_vars with empty string
    assert load_extra_vars(loader) == {}

    #

# Generated at 2022-06-17 15:48:55.371296
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:49:17.429336
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('_foo_bar_baz_1_')
    assert isidentifier('_')
    assert isidentifier('_1')
    assert isidentifier('_1_')
    assert isidentifier('_1_2')
    assert isidentifier('_1_2_')
    assert isidentifier

# Generated at 2022-06-17 15:49:21.375875
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

# Generated at 2022-06-17 15:49:29.835015
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader) == {}
    assert load_extra_vars(loader)

# Generated at 2022-06-17 15:49:37.977796
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}
    extra_vars = load_extra_vars(loader, extra_vars=['@/tmp/test_load_extra_vars.yml'])
    assert isinstance(extra_vars, dict)
    assert extra_vars == {'test': 'test'}

# Generated at 2022-06-17 15:49:42.867703
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:49:47.060822
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:49:55.621724
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    # Test that extra_vars can be loaded from a file
    context.CLIARGS = {'extra_vars': ['@test/unit/utils/test_load_extra_vars.yml']}
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {'test_key': 'test_value'}

    # Test that extra_vars can be loaded from a string

# Generated at 2022-06-17 15:50:07.954712
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = [u'@/tmp/test.yml']
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = [u'@/tmp/test.yml', u'@/tmp/test2.yml']
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}


# Generated at 2022-06-17 15:50:15.537509
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml']}

# Generated at 2022-06-17 15:50:19.061981
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:50:55.156595
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/dev/null']}
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/dev/null', u'@/dev/null']}
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

   

# Generated at 2022-06-17 15:50:58.704675
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:02.127933
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:14.786920
# Unit test for function isidentifier
def test_isidentifier():
    # Test valid identifiers
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_1')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('foo_bar_baz_1_2')
    assert isidentifier('_1_')

# Generated at 2022-06-17 15:51:17.762255
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:51:20.358978
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:22.880518
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

# Generated at 2022-06-17 15:51:35.657689
# Unit test for function merge_hash
def test_merge_hash():
    """
    Unit test for function merge_hash
    """
    import unittest

    class TestMergeHash(unittest.TestCase):
        def test_merge_hash(self):
            """
            Test merge_hash function
            """
            # test merge_hash with recursive=False
            x = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}}
            y = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}}
            self.assertEqual(merge_hash(x, y, recursive=False), y)

            x = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}}
            y

# Generated at 2022-06-17 15:51:45.348502
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_42')
    assert isidentifier('_')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_42')
    assert isidentifier('foo_bar_42')
    assert isidentifier('foo_bar_42_')
    assert isidentifier('_foo_bar_42_')
    assert isidentifier('__')
    assert isidentifier('__foo')
    assert isidentifier('__foo__')
    assert isidentifier('__foo__bar')
    assert isidentifier('__foo__bar__')
    assert isidentifier('__foo__bar__42')

# Generated at 2022-06-17 15:51:56.826736
# Unit test for function merge_hash
def test_merge_hash():
    # test with empty dicts
    assert merge_hash({}, {}) == {}

    # test with empty dict and non-empty dict
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}

    # test with non-empty dicts
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1, 'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}

# Generated at 2022-06-17 15:52:52.616668
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:55.928849
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}
    # TODO: add more tests

# Generated at 2022-06-17 15:52:59.722578
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:53:09.465201
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_2')
    assert isidentifier('foo_bar_baz_1_2_3')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('_foo_bar_baz_1_2')
    assert isidentifier('_foo_bar_baz_1_2_3')

# Generated at 2022-06-17 15:53:19.446012
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('_foo_bar_baz_')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('_foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('_foo_bar_baz_1_')
    assert isidentifier('foo_bar_baz_1_2')

# Generated at 2022-06-17 15:53:23.099251
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:31.888798
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('_foo')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('_')
    assert isidentifier('_foo_bar_baz_')
    assert isidentifier('_1')
    assert isidentifier('_1_')
    assert isidentifier('_1foo')
    assert isidentifier('_1foo_')
    assert isidentifier('_foo1')
    assert isidentifier('_foo1_')
    assert isidentifier('_1foo1')
    assert isidentifier('_1foo1_')
    assert isidentifier('foo1')
    assert isidentifier('foo1_')

# Generated at 2022-06-17 15:53:35.251930
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:46.824180
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, '@/tmp/file')
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, '@/tmp/file', '@/tmp/file2')
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, '@/tmp/file', '@/tmp/file2', '@/tmp/file3')


# Generated at 2022-06-17 15:53:58.578737
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import os
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 15:54:56.569179
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:55:04.869658
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = ['@/dev/null']
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = ['@/dev/null', '@/dev/null']
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}


# Generated at 2022-06-17 15:55:16.311556
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    assert merge_hash(x, y) == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 5, 'd': 6}
    assert merge_hash(x, y, recursive=True) == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 5, 'd': 6}

# Generated at 2022-06-17 15:55:20.375476
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:55:30.982955
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': ['@test.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test': 'test'}

    context.CLIARGS = {'extra_vars': ['@test.yml', '@test2.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test': 'test', 'test2': 'test2'}


# Generated at 2022-06-17 15:55:41.565365
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = ['@/tmp/test.yml']
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS['extra_vars'] = ['@/tmp/test.yml', '@/tmp/test2.yml']
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}
