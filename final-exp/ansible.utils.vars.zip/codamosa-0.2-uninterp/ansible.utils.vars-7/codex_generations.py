

# Generated at 2022-06-17 15:46:04.086619
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test empty extra_vars
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test extra_vars with a single value
    context.CLIARGS = {'extra_vars': [u'key=value']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {u'key': u'value'}

    # Test extra_vars with multiple values
    context.CLIARGS = {'extra_vars': [u'key=value', u'key2=value2']}
    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-17 15:46:14.297690
# Unit test for function combine_vars
def test_combine_vars():
    # test with empty dicts
    assert combine_vars({}, {}) == {}
    # test with empty dict and non-empty dict
    assert combine_vars({}, {'a': 1}) == {'a': 1}
    assert combine_vars({'a': 1}, {}) == {'a': 1}
    # test with non-empty dicts
    assert combine_vars({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert combine_vars({'a': 1}, {'a': 2}) == {'a': 2}
    assert combine_vars({'a': 1, 'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}

# Generated at 2022-06-17 15:46:26.925510
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('foo')
    assert isidentifier('foo_bar')
    assert isidentifier('foo_bar_baz')
    assert isidentifier('_')
    assert isidentifier('_foo')
    assert isidentifier('_foo_bar')
    assert isidentifier('_foo_bar_baz')
    assert isidentifier('foo_bar_baz_')
    assert isidentifier('foo_bar_baz_1')
    assert isidentifier('foo_bar_baz_1_')
    assert isidentifier('foo_bar_baz_1_2')
    assert isidentifier('foo_bar_baz_1_2_')
    assert isidentifier('foo_bar_baz_1_2_3')

# Generated at 2022-06-17 15:46:36.349190
# Unit test for function merge_hash
def test_merge_hash():
    # test with empty dicts
    assert merge_hash({}, {}) == {}

    # test with empty dict and non-empty dict
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}

    # test with non-empty dicts
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1, 'b': 2}, {'a': 3}) == {'a': 3, 'b': 2}
    assert merge_hash({'a': 1, 'b': 2}, {'a': 3, 'b': 4}) == {'a': 3, 'b': 4}

    # test with non-empty dicts and

# Generated at 2022-06-17 15:46:39.579178
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:46:42.945086
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:46:51.981088
# Unit test for function isidentifier
def test_isidentifier():
    # Python 3
    assert isidentifier('a')
    assert isidentifier('a1')
    assert isidentifier('a_1')
    assert isidentifier('_a')
    assert isidentifier('_1')
    assert not isidentifier('1')
    assert not isidentifier('1a')
    assert not isidentifier('a-1')
    assert not isidentifier('a 1')
    assert not isidentifier('a\xfc')
    assert not isidentifier('True')
    assert not isidentifier('False')
    assert not isidentifier('None')
    assert not isidentifier('if')
    assert not isidentifier('a.b')
    assert not isidentifier('a.1')
    assert not isidentifier('a.b.c')

# Generated at 2022-06-17 15:47:03.327585
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, extra_vars=['@/tmp/test.yml'])
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, extra_vars=['@/tmp/test.yml', '@/tmp/test2.yml'])
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader, extra_vars=['@/tmp/test.yml', '@/tmp/test2.yml', 'key=value'])
    assert extra_vars == {}



# Generated at 2022-06-17 15:47:07.910246
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

# Generated at 2022-06-17 15:47:16.792339
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'b': 4, 'c': 5, 'd': 6}
    z = {'c': 7, 'd': 8, 'e': 9}
    assert merge_hash(x, y) == {'a': 1, 'b': 4, 'c': 5, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 1, 'b': 4, 'c': 5, 'd': 6}
    assert merge_hash(x, y, recursive=True) == {'a': 1, 'b': 4, 'c': 5, 'd': 6}

# Generated at 2022-06-17 15:47:29.047961
# Unit test for function merge_hash

# Generated at 2022-06-17 15:47:36.234110
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    y = {'a': 7, 'b': 8, 'c': {'d': 9, 'e': 10, 'f': {'g': 11, 'h': 12}}}
    z = {'a': 7, 'b': 8, 'c': {'d': 9, 'e': 10, 'f': {'g': 11, 'h': 12}}}
    assert merge_hash(x, y) == z
    assert merge_hash(y, x) == z
    assert merge_hash(x, y, recursive=False) == z
    assert merge_hash(y, x, recursive=False) == z

    # test

# Generated at 2022-06-17 15:47:48.997865
# Unit test for function merge_hash

# Generated at 2022-06-17 15:47:51.871422
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:48:01.827631
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    y = {'a': 5, 'c': {'f': 6}}
    z = merge_hash(x, y)
    assert z == {'a': 5, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 6}}

    # test with lists
    x = {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    y = {'a': 5, 'c': [4, 5, 6]}
    z = merge_hash(x, y)
    assert z == {'a': 5, 'b': 2, 'c': [4, 5, 6]}

    # test with lists and list_

# Generated at 2022-06-17 15:48:13.160560
# Unit test for function merge_hash
def test_merge_hash():
    def assert_merge_hash(x, y, recursive, list_merge, expected):
        assert merge_hash(x, y, recursive, list_merge) == expected

    # test merge_hash with recursive=True and list_merge='replace'
    assert_merge_hash({}, {}, True, 'replace', {})
    assert_merge_hash({'a': 1}, {}, True, 'replace', {'a': 1})
    assert_merge_hash({}, {'a': 1}, True, 'replace', {'a': 1})
    assert_merge_hash({'a': 1}, {'a': 2}, True, 'replace', {'a': 2})

# Generated at 2022-06-17 15:48:15.379373
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:48:25.219069
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 15:48:33.666816
# Unit test for function merge_hash
def test_merge_hash():
    # test simple cases
    assert merge_hash({}, {}) == {}
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2, 'b': 2}) == {'a': 2, 'b': 2}
    assert merge_hash({'a': 1, 'b': 2}, {'a': 2}) == {'a': 2, 'b': 2}

# Generated at 2022-06-17 15:48:36.261911
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:48:46.126075
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:48:58.091361
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Test with empty string
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with empty list
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with empty dict
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with empty dict
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with empty dict
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with empty dict
    extra_vars = load_

# Generated at 2022-06-17 15:49:09.327817
# Unit test for function load_options_vars
def test_load_options_vars():
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    loader = DataLoader()
    vault_secrets = VaultLib([])
    vault_secrets.secrets = ['test']
    loader.set_vault_secrets(vault_secrets)

    # Test that extra_vars are loaded correctly
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test that extra_v

# Generated at 2022-06-17 15:49:16.018511
# Unit test for function merge_hash
def test_merge_hash():
    assert merge_hash({}, {}) == {}
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2, 'b': 2}) == {'a': 2, 'b': 2}
    assert merge_hash({'a': 1, 'b': 1}, {'a': 2, 'b': 2}) == {'a': 2, 'b': 2}

# Generated at 2022-06-17 15:49:26.235603
# Unit test for function merge_hash
def test_merge_hash():
    # test basic merge
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    z = merge_hash(x, y)
    assert z == {'a': 4, 'b': 5, 'c': 3, 'd': 6}

    # test recursive merge
    x = {'a': {'b': 1, 'c': 2}, 'd': 3}
    y = {'a': {'b': 4, 'd': 5}, 'e': 6}
    z = merge_hash(x, y)
    assert z == {'a': {'b': 4, 'c': 2, 'd': 5}, 'd': 3, 'e': 6}

    # test non-recursive merge

# Generated at 2022-06-17 15:49:31.256841
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-17 15:49:35.219539
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': ['@/tmp/test_load_extra_vars.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test_load_extra_vars': 'test_load_extra_vars'}

# Generated at 2022-06-17 15:49:49.482854
# Unit test for function merge_hash
def test_merge_hash():
    # test with simple dicts
    x = {'a': 1, 'b': 2}
    y = {'b': 3, 'c': 4}
    z = merge_hash(x, y)
    assert z == {'a': 1, 'b': 3, 'c': 4}
    z = merge_hash(y, x)
    assert z == {'b': 2, 'c': 4, 'a': 1}

    # test with simple dicts and non-recursive merge
    x = {'a': 1, 'b': 2}
    y = {'b': 3, 'c': 4}
    z = merge_hash(x, y, recursive=False)
    assert z == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-17 15:49:57.331878
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test extra_vars with @
    extra_vars_opt = '@/tmp/test_extra_vars.yml'
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test_extra_vars': 'test_extra_vars'}

    # Test extra_vars with [
    extra_vars_opt = '[test_extra_vars]'
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test_extra_vars': 'test_extra_vars'}

    # Test extra_vars with {

# Generated at 2022-06-17 15:50:09.297604
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{foo}} {{bar}}')))
            ]
        )

# Generated at 2022-06-17 15:50:18.099036
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:50:26.063164
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/extra_vars.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/extra_vars.yml', u'@/tmp/extra_vars2.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}


# Generated at 2022-06-17 15:50:37.402304
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{foo}} {{bar}}')))
            ]
        )

# Generated at 2022-06-17 15:50:39.960081
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:50:51.936408
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml', u'@/tmp/test2.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}


# Generated at 2022-06-17 15:51:04.277275
# Unit test for function merge_hash
def test_merge_hash():
    x = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': 5}, 'g': [1, 2, 3], 'h': [4, 5, 6]}
    y = {'a': 10, 'c': {'d': 30, 'e': 40, 'f': 50, 'g': 60}, 'g': [10, 20, 30, 40], 'h': [50, 60, 70]}
    z = {'a': 10, 'b': 2, 'c': {'d': 30, 'e': 40, 'f': 50, 'g': 60}, 'g': [10, 20, 30, 40], 'h': [50, 60, 70]}
    assert merge_hash(x, y) == z

# Generated at 2022-06-17 15:51:07.587509
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:51:11.183790
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:15.356366
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:18.292982
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:35.927603
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 15:51:37.948589
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:51:43.692143
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}, "load_extra_vars() should return an empty dict when no extra vars are passed"

# Generated at 2022-06-17 15:51:52.360945
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    y = {'a': 10, 'c': {'d': 30, 'e': 40, 'f': {'g': 50, 'h': 60}}, 'i': 7}
    z = merge_hash(x, y)
    assert z == {'a': 10, 'b': 2, 'c': {'d': 30, 'e': 40, 'f': {'g': 50, 'h': 60}}, 'i': 7}

    # test with lists

# Generated at 2022-06-17 15:52:01.525465
# Unit test for function combine_vars

# Generated at 2022-06-17 15:52:05.663171
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:09.230791
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:12.748954
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:15.949265
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:18.230290
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:52:27.119842
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:52:34.759660
# Unit test for function load_options_vars
def test_load_options_vars():
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import combine_vars

    # Test with no options
    options_vars = load_options_vars('2.2.0.0')
    assert options_vars == {'ansible_version': '2.2.0.0'}

    # Test with options
    context.CLIARGS = {'check': True, 'diff': True, 'forks': 10, 'inventory': 'hosts', 'skip_tags': 'tag1,tag2', 'subset': 'host1', 'tags': 'tag3,tag4', 'verbosity': 3}
    options_vars = load_options_vars('2.2.0.0')

# Generated at 2022-06-17 15:52:49.120747
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-17 15:52:52.361995
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:00.145584
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    z = merge_hash(x, y)
    assert z == {'a': 4, 'b': 5, 'c': 3, 'd': 6}

    # test with lists
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': [5, 6], 'd': 6}
    z = merge_hash(x, y)
    assert z == {'a': 4, 'b': [5, 6], 'c': 3, 'd': 6}

    # test with dicts in lists

# Generated at 2022-06-17 15:53:03.008872
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

# Generated at 2022-06-17 15:53:06.597608
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:18.800623
# Unit test for function merge_hash
def test_merge_hash():
    # test merge_hash with recursive=False
    x = {'a': 1, 'b': 2, 'c': 3}
    y = {'a': 4, 'b': 5, 'd': 6}
    assert merge_hash(x, y, recursive=False) == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False, list_merge='replace') == {'a': 4, 'b': 5, 'c': 3, 'd': 6}
    assert merge_hash(x, y, recursive=False, list_merge='keep') == {'a': 4, 'b': 5, 'c': 3, 'd': 6}

# Generated at 2022-06-17 15:53:29.995897
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-17 15:53:33.678068
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:44.269473
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:53:51.052880
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    # Test with a single extra_vars
    context.CLIARGS = {'extra_vars': [u"@/tmp/test_load_extra_vars.yml"]}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {u'foo': u'bar'}

    # Test with multiple extra_vars
    context.CLIARGS = {'extra_vars': [u"@/tmp/test_load_extra_vars.yml", u"@/tmp/test_load_extra_vars.yml"]}
    extra_vars

# Generated at 2022-06-17 15:54:01.835113
# Unit test for function combine_vars
def test_combine_vars():
    # test with non-recursive merge
    x = {'a': {'b': 1, 'c': 2}, 'd': 3}
    y = {'a': {'b': 2, 'd': 4}, 'e': 5}
    z = combine_vars(x, y, recursive=False)
    assert z == {'a': {'d': 4}, 'd': 3, 'e': 5}

    # test with recursive merge
    x = {'a': {'b': 1, 'c': 2}, 'd': 3}
    y = {'a': {'b': 2, 'd': 4}, 'e': 5}
    z = combine_vars(x, y, recursive=True)

# Generated at 2022-06-17 15:54:10.543252
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test_load_extra_vars.yml']}
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'test': 'test'}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test_load_extra_vars.yml', u'@/tmp/test_load_extra_vars.yml']}
    extra_vars = load_extra_vars(loader)

# Generated at 2022-06-17 15:54:22.102410
# Unit test for function combine_vars
def test_combine_vars():
    from ansible.module_utils.six import PY3
    if PY3:
        from collections import UserDict
        MutableMapping = UserDict
    else:
        from collections import MutableMapping

    # Test merge_hash
    # Test simple dicts
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'a': 2}, recursive=False) == {'a': 2}
    assert merge_hash({'a': 1}, {'a': 2}, recursive=True) == {'a': 2}

# Generated at 2022-06-17 15:54:25.363785
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

# Generated at 2022-06-17 15:54:33.271386
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [1, 2, 3]}
    y = {'a': 2, 'b': {'c': 3, 'e': 4}, 'f': [4, 5, 6]}
    z = merge_hash(x, y)
    assert z == {'a': 2, 'b': {'c': 3, 'd': 3, 'e': 4}, 'e': [1, 2, 3], 'f': [4, 5, 6]}

    # test with lists
    x = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [1, 2, 3]}

# Generated at 2022-06-17 15:54:43.511107
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml']}
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)
    assert extra_vars == {}

    context.CLIARGS = {'extra_vars': [u'@/tmp/test.yml', u'@/tmp/test2.yml']}
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)


# Generated at 2022-06-17 15:54:53.800839
# Unit test for function merge_hash
def test_merge_hash():
    # test for dicts
    assert merge_hash({}, {}) == {}
    assert merge_hash({'a': 1}, {}) == {'a': 1}
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1, 'b': 2}, {'b': 3}) == {'a': 1, 'b': 3}
    assert merge_hash({'a': 1, 'b': 2}, {'b': 3, 'c': 4}) == {'a': 1, 'b': 3, 'c': 4}
    assert merge

# Generated at 2022-06-17 15:54:58.845551
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert isinstance(extra_vars, dict)

# Generated at 2022-06-17 15:55:21.293245
# Unit test for function merge_hash
def test_merge_hash():
    # test with dicts
    x = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    y = {'a': 5, 'c': {'f': 6, 'g': 7}}
    z = {'a': 5, 'b': 2, 'c': {'f': 6, 'g': 7}}
    assert merge_hash(x, y) == z

    # test with lists
    x = {'a': [1, 2, 3], 'b': 2, 'c': {'d': 3, 'e': 4}}
    y = {'a': [4, 5, 6], 'c': {'f': 6, 'g': 7}}

# Generated at 2022-06-17 15:55:24.773487
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    extra_vars = load_extra_vars(loader)
    assert extra_vars == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-17 15:55:33.800463
# Unit test for function merge_hash

# Generated at 2022-06-17 15:55:43.473053
# Unit test for function merge_hash
def test_merge_hash():
    # test with empty dicts
    assert merge_hash({}, {}) == {}

    # test with empty dict and non-empty dict
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}

    # test with non-empty dicts
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'a': 1}) == {'a': 1}

    # test with non-empty dicts and non-empty dicts with lists