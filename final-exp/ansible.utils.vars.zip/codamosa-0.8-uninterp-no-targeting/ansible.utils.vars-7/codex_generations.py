

# Generated at 2022-06-21 09:06:37.888581
# Unit test for function merge_hash
def test_merge_hash():
    print("Ansible-test: test_merge_hash")

    def compare(x, y):
        # compare hash x and y (recursively)
        # if they are identical, return True
        # else return False and the different elements
        # (i.e. a diff of the 2 hashes)

        # quick test: if x or y are not dict, check if they are equal
        # and return None if they are equal
        # (None is used as "no error" by this function)
        if not isinstance(x, MutableMapping) or not isinstance(y, MutableMapping):
            if x == y:
                return None
            else:
                return {'x': x, 'y': y}

        # keys present in x but not in y

# Generated at 2022-06-21 09:06:44.551729
# Unit test for function merge_hash
def test_merge_hash():
    d1 = dict(
        x=1,
        y=dict(
            a=2,
            b=5,
            c=9,
        ),
        z=[],
    )
    d2 = dict(
        x=1,
        y=dict(
            a=2,
            b=3,
            d=8,
        ),
        z=[1, 4],
    )
    d1_tmp = d1.copy()
    d2_tmp = d2.copy()
    d1_tmp['y']['b'] = 3
    d1_tmp['y']['d'] = 8
    d1_tmp['z'] = [1, 4]
    d2_tmp['y']['c'] = 9
    d2_tmp['y']['d'] = 8
   

# Generated at 2022-06-21 09:06:52.729791
# Unit test for function isidentifier

# Generated at 2022-06-21 09:07:02.083786
# Unit test for function load_options_vars
def test_load_options_vars():
    from ansible import context
    import ansible.constants as C
    import sys

    class _Options(object):
        pass
    context.CLIARGS = _Options()
    context.CLIARGS.check_mode = 'True'
    context.CLIARGS.diff_mode = 'False'
    context.CLIARGS.forks = '5'
    context.CLIARGS.inventory_sources = 'hosts'
    context.CLIARGS.skip_tags = 'test'
    context.CLIARGS.limit = 'test'
    context.CLIARGS.run_tags = 'test'
    context.CLIARGS.verbosity = '1'

    # Test with version as int
    test_version = C.__version__


# Generated at 2022-06-21 09:07:10.453875
# Unit test for function load_options_vars
def test_load_options_vars():
    from ansible import context

    context.CLIARGS = {'verbosity' : 5, 'check' : True, 'inventory' : '/tmp/foo'}
    options_vars = load_options_vars('2.2.0')
    assert options_vars['ansible_verbosity'] == 5
    assert options_vars['ansible_check_mode'] is True
    assert options_vars['ansible_inventory_sources'] == ['/tmp/foo']
    assert options_vars['ansible_version'] == '2.2.0'



# Generated at 2022-06-21 09:07:20.438476
# Unit test for function combine_vars
def test_combine_vars():

    # Tests of 'replace' mode
    hash_behaviour = 'replace'
    a, b = {'a': 1, 'b': 2, 'c': 3}, {'d': 4, 'e': 5, 'f': 6}
    result = combine_vars(a, b, merge=hash_behaviour)
    assert result == {'d': 4, 'e': 5, 'f': 6}
    a, b = {'a': [1, 2, 3], 'b': [4, 5, 6]}, {'a': [7, 8, 9], 'b': [10, 11, 12]}
    result = combine_vars(a, b, merge=hash_behaviour)
    assert result == {'a': [7, 8, 9], 'b': [10, 11, 12]}

# Generated at 2022-06-21 09:07:33.429269
# Unit test for function load_extra_vars
def test_load_extra_vars():

    import ansible.parsing.yaml.objects as objects
    import ansible.parsing.yaml.loader as loader
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib

    class MockVaultLib(VaultLib):
        def __init__(self):
            pass

        def decrypt(self, value):
            return '__VAULT__' + value

        def encrypt(self, value):
            return '__VAULT__' + value

    vault.VaultLib = MockVaultLib
    class MockLoader(loader.DataLoader):
        def get_basedir(self):
            return '.'

    ld = MockLoader()

    # Test basic JSON
    assert load_extra_vars(ld) == {}, 'JSON not loaded'

# Generated at 2022-06-21 09:07:39.617758
# Unit test for function get_unique_id
def test_get_unique_id():
    uuid_list = []
    for x in range(0, 100):
        unique_id = get_unique_id()
        uuid_list.append(unique_id)

        assert unique_id.count('-') == 4

        # verify no duplicate uuids
        assert uuid_list.count(unique_id) == 1

# Generated at 2022-06-21 09:07:43.022963
# Unit test for function get_unique_id
def test_get_unique_id():
    global cur_id
    mylist = []
    cur_id = 0
    for i in range(0, 1000):
        mylist.append(get_unique_id())
    assert(len(set(mylist)) == len(mylist))

# Generated at 2022-06-21 09:07:50.697084
# Unit test for function merge_hash
def test_merge_hash():
    def assert_equal(x, y, msg=None):
        if x != y:
            msg = msg or "Assertion error: %r != %r" % (x, y)
            raise AssertionError(msg)

    # 1st case: scalars
    x = {u"a": u"A", u"b": u"B"}
    y = {u"a": u"a", u"c": u"C"}
    z = {u"a": u"a", u"b": u"B", u"c": u"C"}
    assert_equal(merge_hash(x, y), z)

    # 2nd case: lists
    x = {u"a": u"A", u"b": [1, 2, 3]}

# Generated at 2022-06-21 09:08:08.538149
# Unit test for function load_options_vars
def test_load_options_vars():
    from ansible.utils.display import Display
    display = Display()

    options_vars = load_options_vars('1.1.1')
    assert 'ansible_version' in options_vars
    assert 'ansible_check_mode' not in options_vars

    from ansible.cli import CLI
    import sys
    cli = CLI(args=[], display=display)
    cli.parse()
    context.CLIARGS = cli.options

    options_vars = load_options_vars('1.1.1')
    assert 'ansible_version' in options_vars
    assert 'ansible_check_mode' in options_vars


# Generated at 2022-06-21 09:08:13.896232
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import os
    import random
    import shutil
    import tempfile
    import yaml

    from ansible.parsing.dataloader import DataLoader

    def _write_file(data, path):
        with open(path, 'w') as f:
            f.write(data)

    base_tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-21 09:08:25.385878
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.context import CLIARGS
    import os

    # example of a json file
    extra_vars_json = """{"key1": ["val1a", "val1b"]}"""
    # example of a vars file with '@' char
    extra_vars_at = """
key2: val2a
@key3: val3a
@key3: val3b
"""
    # example of a yaml file
    extra_vars_yaml = """---
key4:
    - val4a
    - val4b
"""
    # example of a vars file with '@' char

# Generated at 2022-06-21 09:08:37.592173
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('a')
    assert isidentifier('_a')
    assert isidentifier('a1')
    assert isidentifier('unique_id')
    assert isidentifier('unique_id1')
    assert isidentifier('unique_id_1')
    assert not isidentifier('')
    assert not isidentifier('1')
    assert not isidentifier('1a')
    assert not isidentifier('a-1')
    assert not isidentifier('a b')
    assert not isidentifier('a.b')
    assert not isidentifier('a/b')
    assert not isidentifier('a/b')
    assert not isidentifier('a\b')
    assert not isidentifier('a\\b')
    assert not isidentifier('a#b')

# Generated at 2022-06-21 09:08:47.394563
# Unit test for function combine_vars
def test_combine_vars():
    a = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }

    b = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
            },
            'g': 'h',
        },
        'i': 'j',
    }

    print("a=b ? %s" % (a == b))

# Generated at 2022-06-21 09:08:56.178519
# Unit test for function merge_hash
def test_merge_hash():
    from collections import OrderedDict

    # a base dict
    x = {
        'a': 'a',
        'b': 'b',
        'c': 'c',
        'd': {
            'x': 'x',
            'y': 'y',
            'z': 'z',
        },
        'e': [1, 2],
    }

    # test simple merge
    assert merge_hash({}, {}) == {}
    assert merge_hash(x, {}) == x
    assert merge_hash({}, x) == x

    # simple dict, same keys

# Generated at 2022-06-21 09:09:07.368330
# Unit test for function load_extra_vars
def test_load_extra_vars():

    class FakeLoader(object):
        def __init__(self):
            self.fake_results = []
            self.fake_status = []
            self.file_name = None

        def load_from_file(self, file_name):
            self.file_name = file_name
            return self.fake_results.pop(0)

        def load(self, text):
            return self.fake_results.pop(0)

    def fake_get_option(key):
        if key == 'extra_vars':
            return self.fake_args.pop(0)
        else:
            raise AnsibleError('Invalid option key')

    def check_result(result, expected):
        assert result == expected

    test = FakeLoader()

# Generated at 2022-06-21 09:09:19.981587
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier("underscore_")
    assert isidentifier("CAPITAL")
    assert isidentifier("lowercase")
    assert isidentifier("CAPITALS_and_UNDERSCORES")
    assert isidentifier("CamelCase")
    assert isidentifier("_underscore")
    assert isidentifier("_")
    assert not isidentifier("2NO")
    assert not isidentifier("")
    assert not isidentifier("no spaces")
    assert not isidentifier("no.dots")
    assert not isidentifier("no$dollarsigns")
    assert not isidentifier("no^carets")
    assert not isidentifier("no*stars")
    assert not isidentifier("no(parens")
    assert not isidentifier("no)parens")

# Generated at 2022-06-21 09:09:28.487759
# Unit test for function load_extra_vars
def test_load_extra_vars():
    import ansible.constants as C
    import ansible.utils as utils

    # Inject a temporary configuration to use for the test

# Generated at 2022-06-21 09:09:40.505617
# Unit test for function isidentifier
def test_isidentifier():

    # The following test cases are taken from http://www.pythontutor.com/visualize.html#mode=edit

    # Valid identifiers
    assert isidentifier("this_is_also_a_valid_identifier")
    assert isidentifier("_")
    assert isidentifier("__")
    assert isidentifier("__init__")
    assert isidentifier("_hello")

    # Invalid identifiers
    assert not isidentifier("")
    assert not isidentifier("42")
    assert not isidentifier("this is an invalid identifier")
    assert not isidentifier("this_is_an_invalid_identifier!")
    assert not isidentifier("this_is_an_invalid_identifier?")
    assert not isidentifier("$")
    assert not isidentifier("@")
    assert not isidentifier

# Generated at 2022-06-21 09:09:58.611303
# Unit test for function merge_hash
def test_merge_hash():
    # initialize dictionarys
    x = {
        'a': {
            'f': '0',
            'e': '0'
        },
        'b': '0',
        'c': [
            'a', 'b'
        ],
        'd': '0'
    }

    y = {
        'a': {
            'e': '1',
            'f': '1'
        },
        'b': '1',
        'c': [
            'b', 'c'
        ],
        'z': '1',
        'd': '1'
    }

    z = {'a': '1', 'b': '1', 'c': '1', 'z': '1', 'd': '1'}

    # expected result

# Generated at 2022-06-21 09:10:01.793146
# Unit test for function load_options_vars
def test_load_options_vars():
    import ansible.constants as C
    C.CLIARGS = {'forks': 5, 'verbosity': 0}
    assert load_options_vars('1.2.3') == {'ansible_forks': 5, 'ansible_verbosity': 0, 'ansible_version': '1.2.3'}

# Generated at 2022-06-21 09:10:03.805679
# Unit test for function get_unique_id
def test_get_unique_id():
    assert get_unique_id() is not None
    assert len(get_unique_id()) == 36

# Generated at 2022-06-21 09:10:11.536956
# Unit test for function merge_hash
def test_merge_hash():
    h1 = dict(a=1, b=2, d=5, bk=["3", "4", {"5":"5", "6":"6"}])
    h2 = dict(c=3, b=5, d=3, bk=["5", "6", {"7":"7", "8":"8"}])
    h3 = dict(c=3, b=5, d=3, bk=["5", "6", {"7":"7", "8":"8"}, {"6":"6", "5":"5"}])
    h4 = dict(a=1, b=2, d=5, bk={"5":"5", "6":"6"})
    h5 = dict(a=1, b=2, d=5, bk={"5":"5", "5":"5", "6":"6"})
   

# Generated at 2022-06-21 09:10:24.396146
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    vars_manager = VariableManager()
    vars_manager.extra_vars = {'foo': 'bar'}
    vars_manager.update_vars(load_extra_vars(loader))
    assert vars_manager.extra_vars['foo'] == 'bar'

    # Try multiple extra_vars args, ensure they're merged
    vars_manager = VariableManager()
    vars_manager.extra_vars = {'foo': 'bar', 'boo': 'baz'}
    vars_manager.update_vars(load_extra_vars(loader))
    assert vars_manager.extra_vars['foo'] == 'bar'

# Generated at 2022-06-21 09:10:25.655342
# Unit test for function get_unique_id
def test_get_unique_id():
    assert(get_unique_id().count('-') == 4)

# Generated at 2022-06-21 09:10:37.895619
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier("") is False
    assert isidentifier(" ") is False
    assert isidentifier("good") is True
    assert isidentifier("good_var") is True
    assert isidentifier("_good") is True
    assert isidentifier("_good123") is True
    assert isidentifier("_123") is True
    assert isidentifier("123") is False
    assert isidentifier("12var") is False
    assert isidentifier("goodvar-bad") is False
    assert isidentifier("True") is False
    assert isidentifier("None") is False
    assert isidentifier("False") is False
    assert isidentifier(u"good_unicode") is False
    assert isidentifier("bad variable") is False

# Generated at 2022-06-21 09:10:45.123379
# Unit test for function combine_vars
def test_combine_vars():

    class D(dict):
        pass

    # run the function
    # and check the result
    def run_test(x, y, r, list_merge='replace', merge=None, kwargs={}):
        if merge == None:
            merge = C.DEFAULT_HASH_BEHAVIOUR == 'merge'
        result = combine_vars(x, y, merge, list_merge, **kwargs)
        assert result == r, "Result: %s Expected: %s" % (result, r)

    # x and y are dicts (lists) to merge
    # r is the expected result
    # k is the keyword arguments to pass to combine_vars (if any)
    # merge is the expected hash_behaviour for this test
    # list_merge is the expected list_merge for this

# Generated at 2022-06-21 09:10:55.351329
# Unit test for function isidentifier
def test_isidentifier():
    # Following identifiers should pass
    assert isidentifier("_")
    assert isidentifier("visa")
    assert isidentifier("VISA")
    assert isidentifier("ansible_managed")

    # Following identifiers should fail
    assert not isidentifier("")
    assert not isidentifier("9")
    assert not isidentifier("visa@")
    assert not isidentifier("vis-a")
    assert not isidentifier("ansible-managed")
    assert not isidentifier("True")
    assert not isidentifier("None")
    assert not isidentifier("False")
    assert not isidentifier("巴布亚新几内亚")

# Generated at 2022-06-21 09:11:00.624612
# Unit test for function get_unique_id
def test_get_unique_id():
    ids = set()
    for i in range(0, 1000):
        id1 = get_unique_id()
        id2 = get_unique_id()
        assert id1 != id2
        ids.add(id1)
        assert id1 in ids
    assert len(ids) == 1000

# Generated at 2022-06-21 09:11:20.291246
# Unit test for function isidentifier
def test_isidentifier():
    """Verify isidentifier always returns a boolean for all defined strings."""

# Generated at 2022-06-21 09:11:28.940982
# Unit test for function combine_vars
def test_combine_vars():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)

    # Test different type of init
    myvars = loader.load('[1, 2, 3]')
    result = combine_vars(myvars, myvars)
    assert result == myvars

    myvars = loader.load('{"a": 1, "b": 2, "c": 3}')
    result = combine_vars(myvars, myvars)
    assert result == myvars

    # Test append_rp list_merge
    x = loader.load('[1, 2, 3]')
    y = loader.load('[4, 5, 6]')
   

# Generated at 2022-06-21 09:11:31.636666
# Unit test for function get_unique_id
def test_get_unique_id():
    ids = set()
    for i in range(0, 100):
        ids.add(get_unique_id())
    assert len(ids) == 100

# Generated at 2022-06-21 09:11:39.934550
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.parsing.dataloader import DataLoader

    options = dict(
        connection='local',
        module_path=None,
        forks=5,
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        extra_vars=[
            "{'foo': '{{bar}}', 'baz': 'quux'}"
        ],
        private_key_file='test_key',
        host_key_checking=False,
        listhosts=False,
        listtasks=False,
        listtags=False,
        syntax=False,
        start_at_task=None,
        step=False,
        diff=False,
        verbosity=0,
    )

    loader = DataLoader()
    variables

# Generated at 2022-06-21 09:11:47.639401
# Unit test for function get_unique_id
def test_get_unique_id():
    global cur_id
    ids = []
    cur_id = 0
    for i in range(0,3):
        ids.append(get_unique_id())
    assert len(ids[0]) == 36
    assert len(ids[1]) == 36
    assert len(ids[2]) == 36
    assert ids[0] != ids[1]
    assert ids[0] != ids[2]
    assert ids[1] != ids[2]
    assert ids[0].split("-")[-1] == ids[1].split("-")[-1]
    assert ids[0].split("-")[-1] != ids[2].split("-")[-1]

# Generated at 2022-06-21 09:11:54.450140
# Unit test for function isidentifier
def test_isidentifier():
    if PY3:
        assert isidentifier('_foo')
        assert isidentifier('_foo_1')
        assert isidentifier('bar')
        assert isidentifier('Bar')
        assert isidentifier('BAR')

        assert not isidentifier('1')
        assert not isidentifier('1foo')
        assert not isidentifier('foo!')
        assert not isidentifier('True')
        assert not isidentifier('None')
        assert not isidentifier('Foó')
    else:
        assert isidentifier('_foo')
        assert isidentifier('_foo_1')
        assert isidentifier('bar')
        assert isidentifier('Bar')
        assert isidentifier('BAR')
        assert isidentifier('1')
        assert isidentifier('1foo')
        assert isidentifier

# Generated at 2022-06-21 09:11:58.585209
# Unit test for function get_unique_id
def test_get_unique_id():
    id_set = set()
    for i in range(100000):
        id = get_unique_id()
        assert id not in id_set
        id_set.add(id)

# Generated at 2022-06-21 09:12:11.089514
# Unit test for function merge_hash
def test_merge_hash():

    import pytest

    def _assert(x, y, result, error_message):
        assert merge_hash(x, y) == result, error_message

    merge_hash({}, {}, recursive=False)
    merge_hash({}, {}, recursive=True)

    _assert({'a': 1}, {'b': 2}, {'a': 1, 'b': 2}, "failed to merge two dicts")


# Generated at 2022-06-21 09:12:22.498712
# Unit test for function merge_hash
def test_merge_hash():
    # merge_hash(x, y, recursive) -> z
    # merge_hash(x, y, recursive=True) -> z
    # check that x.update(y) == z
    # (basic test, `x` and `y` have only "simple" values)

    x = {'a': 0, 'b': 1, 'c': 2, 'd': [], 'e': {}, 'f': None,
         'h': ['a', 'b'], 'i': set(['a', 'b']), 'k': {'a': 0, 'b': 1},
         'l': {0, 1}, 'm': 'a', 'n': 'b'}

# Generated at 2022-06-21 09:12:34.149737
# Unit test for function merge_hash
def test_merge_hash():
    print("\n=== START OF UNIT TEST ===\n")
    print("These are the answers to the merge_hash functions in ansible:\n")
    x = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
                'e': {
                    'f': 1,
                },
            },
            'b1': 2,
            'b2': 2,
            'b3': 2,
        },
        'a1': 1,
        'a2': 1,
        'a3': 1,
    }

# Generated at 2022-06-21 09:13:01.221467
# Unit test for function load_options_vars
def test_load_options_vars():
    ''' test load_options_vars '''
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.common.json
    import ansible.module_utils.common.process
    import ansible.module_utils.common.text
    import ansible.module_utils.parsing.convert_bool

    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.six

    import ansible.plugins.loader
    import ansible.playbook.play

    import ansible.playbook.task
    import ansible.utils.display
    import ansible.vars.hostvars

    import ansible.constants as C
    import ansible.module_utils.common as common_utils
    import ansible

# Generated at 2022-06-21 09:13:13.050124
# Unit test for function isidentifier
def test_isidentifier():
    assert(isidentifier("a"))
    assert(isidentifier("a1"))
    assert(isidentifier("a_b"))
    assert(isidentifier("_a"))
    assert(isidentifier("__a__"))
    assert(isidentifier("_a_b_"))
    assert(isidentifier("__a_b__"))
    assert(isidentifier("a_b_c"))
    assert(isidentifier("___a_b_c___"))
    assert(isidentifier("a_b_c_"))

    assert(not isidentifier("1a"))
    assert(not isidentifier("a.b"))
    assert(not isidentifier("-a"))
    assert(not isidentifier("!a"))
    assert(not isidentifier("@a"))

# Generated at 2022-06-21 09:13:20.162501
# Unit test for function combine_vars
def test_combine_vars():
    d1 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    d2 = {'b': -2, 'c': {'e': -5}}
    d3 = combine_vars(d1, d2)
    assert d1 == {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    assert d2 == {'b': -2, 'c': {'e': -5}}
    assert d3 == {'a': 1, 'b': -2, 'c': {'d': 4, 'e': -5}}
    # Specific test for Issue #23789
    d1 = {'NOZEROCONF': 'true'}

# Generated at 2022-06-21 09:13:31.574056
# Unit test for function merge_hash

# Generated at 2022-06-21 09:13:43.039740
# Unit test for function merge_hash
def test_merge_hash():
    from nose.plugins.skip import SkipTest
    if PY3:
        raise SkipTest("No need to test merge_hash under Python 3")

    assert merge_hash({}, {}) == {}
    assert merge_hash({}, {'a': 1}) == {'a': 1}
    assert merge_hash({'a': 1}, {}) == {'a': 1}
    assert merge_hash({'a': 1}, {'a': 2}) == {'a': 2}
    assert merge_hash({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}
    assert merge_hash({'a': 1}, {'a': 2, 'b': 3}) == {'a': 2, 'b': 3}

# Generated at 2022-06-21 09:13:54.490314
# Unit test for function load_options_vars
def test_load_options_vars():
    context.CLIARGS = {
        'check': 'True',
        'diff': 'True',
        'forks': 'True',
        'inventory': 'True',
        'skip_tags': 'True',
        'subset': 'True',
        'tags': 'True',
        'verbosity': 'True',
    }

# Generated at 2022-06-21 09:13:58.987318
# Unit test for function get_unique_id
def test_get_unique_id():
    previous = {}
    for x in range(0, 1000):
        current = get_unique_id()
        if current not in previous:
            previous[current] = 1
        else:
            previous[current] += 1

        assert(previous[current] == 1)

# Generated at 2022-06-21 09:14:06.970950
# Unit test for function load_extra_vars
def test_load_extra_vars():

    import ansible.plugins.loader

    class FakeLoader(object):
        def __init__(self, data_str):
            self.data_str = data_str
            self.data = None

        def load(self, args):
            if args == "@missing":
                raise AnsibleOptionsError("File not found")
            self.data = args
            return args

        def load_from_file(self, args):
            if args == "missing":
                raise AnsibleOptionsError("File not found")
            self.data = self.data_str
            return self.data_str

    class FakeCLIArgs(object):
        def __init__(self, data_list):
            self.data = data_list

        def __contains__(self, key):
            return key in ('extra_vars',)


# Generated at 2022-06-21 09:14:19.192556
# Unit test for function combine_vars
def test_combine_vars():
    """
    Test for function combine_vars
    """

    import sys
    import pytest

    # These tests are designed to cover the main potential failure modes
    # of the combine_vars() function. More specific functional tests are
    # available in test/integration/targets/hash_behaviour.

    if sys.version_info[0] == 3:
        # NOTE: 'True' exists as a keyword in Python 3, but it is not a literal,
        # it is only a name.
        TRUE = 'True'
        FALSE = 'False'
        NONE = 'None'
        EXCEPTION_MESSAGE = "unsupported operand type(s) for +: '{0}' and '{1}'"
    else:
        TRUE = True
        FALSE = False
        NONE = None
        EXCEPT

# Generated at 2022-06-21 09:14:28.357738
# Unit test for function load_extra_vars
def test_load_extra_vars():
    assert load_extra_vars('@extra_vars.yml') == {'test': True, 'content': 'Hello World'}
    assert load_extra_vars('@extra_vars.yaml') == {'test': True, 'content': 'Hello World'}
    assert load_extra_vars('@extra_vars.json') == {'test': True, 'content': 'Hello World'}
    assert load_extra_vars('{"test":true,"content":"Hello World"}') == {'test': True, 'content': 'Hello World'}
    assert load_extra_vars('[foo, bar]') == ['foo', 'bar']

# Generated at 2022-06-21 09:14:57.622353
# Unit test for function merge_hash
def test_merge_hash():

    # convenience function to compare real dict values and not dict object
    # comparison
    def dict_compare(x, y):
        return y == x

    def dict_compare_with_list(x, y):
        return dict_compare(x, y) or dict_compare(x, list(y)) or dict_compare(x, tuple(y)) or dict_compare(x, set(y)) or dict_compare(x, frozenset(y))


# Generated at 2022-06-21 09:15:06.156086
# Unit test for function merge_hash

# Generated at 2022-06-21 09:15:14.865241
# Unit test for function merge_hash
def test_merge_hash():
    def deep_equal(a, b):
        if isinstance(a, MutableMapping) and isinstance(b, MutableMapping):
            if len(a) != len(b):
                return False
            for key, val in iteritems(a):
                if key not in b:
                    return False
                if not deep_equal(val, b[key]):
                    return False
            return True
        if isinstance(a, MutableSequence) and isinstance(b, MutableSequence):
            if len(a) != len(b):
                return False
            for i in range(len(a)):
                if not deep_equal(a[i], b[i]):
                    return False
            return True
        return a == b


# Generated at 2022-06-21 09:15:26.111616
# Unit test for function isidentifier
def test_isidentifier():
    assert isidentifier('a') == True
    assert isidentifier(u'a') == True
    assert isidentifier('\u2713') == False
    assert isidentifier('foo1') == True
    assert isidentifier('foo-bar') == False
    assert isidentifier('while') == False
    assert isidentifier('True') == False
    assert isidentifier('1foo') == False
    assert isidentifier('foo.bar') == False
    assert isidentifier('_bar') == True
    assert isidentifier('__bar') == True
    assert isidentifier('foo_bar') == True
    assert isidentifier('foo__bar') == True
    assert isidentifier('foo__bar__') == True
    assert isidentifier('__') == False

# Generated at 2022-06-21 09:15:36.308416
# Unit test for function combine_vars
def test_combine_vars():
    import copy
    import json

    a = dict(
        A=1,
        B="B-string",
        C=dict(
            C1="C1-string",
            C2=dict(
                C21="C21-string",
                C22=22,
            ),
        ),
        D=dict(
            D1=dict(
                D11="D11-string",
            )
        ),
        F=[
            1,
            2,
            3,
            dict(F42="F42-string"),
        ],
        G=[
            "G-string",
        ],
    )

    # Test "a.update(b)"

# Generated at 2022-06-21 09:15:45.270890
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader

    # create a mock cli options dict to use
    test_options = dict()
    test_options['extra_vars'] = list()

    # create the cli tool
    cli = CLI(args=[''], options=test_options)

    # create the data loader
    loader = DataLoader()

    # run the test
    extra_vars = load_extra_vars(loader)

    assert extra_vars == dict()



# Generated at 2022-06-21 09:15:54.345507
# Unit test for function load_options_vars
def test_load_options_vars():
    argv = ['-vvvvv', '-f', '5', '--limit', 'localhost', '--tags', 'debug,sample', '--skip-tags', 'daemon', '--inventory', './hosts', '--diff', '--check']
    context.CLIARGS = {'verbosity': 5, 'forks': 5, 'limit': 'localhost', 'run_tags': ['debug', 'sample'], 'skip_tags': ['daemon'], 'inventory_sources': ['./hosts'], 'diff_mode': True, 'check_mode': True}

    #Test loading the option variables.
    actual_vals = load_options_vars('1.9.99')

# Generated at 2022-06-21 09:16:04.427853
# Unit test for function load_extra_vars
def test_load_extra_vars():
    from ansible.release import __version__ as version
    from ansible.parsing import vault

    from ansible.parsing.vault import VaultLib

    # Set up the vault secret and password file

# Generated at 2022-06-21 09:16:12.858905
# Unit test for function merge_hash
def test_merge_hash():
    # define 3 dicts to used as input
    x = {'a': 'first_value',
         'b': {'b_1': '1st_value',
               'b_2': '2nd_value'},
         'c': ['a', 'b', 'c'],
         'd': ['d', 'e'],
         }
    y = {'a': 'b',
         'b': {'b_2': '2nd_value_bis',
               'b_3': '3rd_value'},
         'c': ['d', 'e', 'f'],
         'e': 'y',
         }

    # prepare the expected results

# Generated at 2022-06-21 09:16:23.537796
# Unit test for function isidentifier
def test_isidentifier():
    import sys

    # NOTE Python 3.7 offers str.isascii() so switch over to using it once
    # we stop supporting 3.5 and 3.6 on the controller
    try:
        # Python 2 does not allow non-ascii characters in identifiers so unify
        # the behavior for Python 3
        'abc\N{SNOWMAN}xyz'.encode('ascii')
    except UnicodeEncodeError:
        ascii_fail_expect = True
    else:
        ascii_fail_expect = False

    # Python 3
    if sys.version_info[0] >= 3:
        assert isidentifier("identifier")
        assert not isidentifier("1identifier")
        assert not isidentifier("identifier1.2")
        assert not isidentifier("while")