

# Generated at 2022-06-23 18:37:26.393070
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'bearer' not in choices

# Generated at 2022-06-23 18:37:37.953786
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [auth_type for auth_type in _AuthTypeLazyChoices()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())
AUTHTYPE_CHOICES = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:37:44.292746
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert sorted(
        plugin_manager.get_auth_plugin_mapping()
    ) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_plugin',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Built-in types: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# The --auth-type and --auth options are a bit of a mess.
#
# The --auth option needs to be given a value, but:
#
# 1. The value may be empty, in which case the user will be prompted for
#    both the username

# Generated at 2022-06-23 18:37:55.232356
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Default: {DEFAULT_AUTH_PLUGIN_NAME}

    ''',
)
for _auth_type, _auth_module in plugin_manager.get_auth_plugin_mapping().items():
    if '://' not in _auth_type:
        _auth_type = '<scheme>://' + _auth_type

# Generated at 2022-06-23 18:37:58.223385
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert 'digest' in a
    assert 'foobar' not in a


# Generated at 2022-06-23 18:38:02.695320
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Default: {default}.
    If a custom auth plugin is available for this auth type,
    then it is invoked instead of the builtin ones.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN,
    )
)



# Generated at 2022-06-23 18:38:04.803133
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'not_valid_auth' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:14.297400
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use this authentication type.

    If not specified, the auth plugin is guessed from the --auth option.

    The currently available auth plugins are:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)


# Generated at 2022-06-23 18:38:23.572732
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for i in _AuthTypeLazyChoices():
        assert i in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:
    {auth_types}.

    '''
)
auth.add_argument(
    '--auth-prefix', default='', metavar='PREFIX',
    help='''
    If the API requires that auth credentials are sent as URL prefix
    (e.g., "Bearer" in https://$BEARER_TOKEN@domain.tld), use this option
    to set the prefix.

    '''
)

# Generated at 2022-06-23 18:38:34.195950
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    type(b'', (_AuthTypeLazyChoices,), {})()

# Plugin keyword arguments.
auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The HTTPie plugin that provides the authentication type. If not specified,
    HTTPie will guess it based on the --auth username, if possible.
    '''
)

# Generated at 2022-06-23 18:38:36.409364
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('AuthTypeLazyChoices')


# Generated at 2022-06-23 18:38:48.227283
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """ _AuthTypeLazyChoices(object) """
    type(_AuthTypeLazyChoices)()

auth.add_argument(
    '--auth-type',
    type=str,
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin module. The plugin can be a Python
    class or function that receives a requests.Session instance and returns
    a session object with authentication prepared. See the documentation at
    {PLUGINS_DOC_URL} for more information.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Send without waiting for an HTTP challenge (Basic auth only).

    '''
)



# Generated at 2022-06-23 18:38:51.291769
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'NonExistentAuthPlugin' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:53.315087
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:02.707318
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth type to be used. By default, an appropriate one
    is automatically selected based on the provided credentials and the response.

    '''
)
auth.add_argument(
    '--auth-server',
    default=None,
    help='''
    Provide an alternative server for Basic and Digest auth. By default, the
    request's host is used.

    '''
)


#######################################################################
# Compatibility with curl
#######################################################################


# Generated at 2022-06-23 18:39:06.218721
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:39:16.908830
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices, choices
    assert 'digest' in choices, choices
    assert 'hmac' in choices, choices

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used: "basic", "digest", "hmac".
    If "auto", then the "best" method is used (default).

    See the full list of supported auth types with `http --help-auth'.

    '''
)

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
auth_plugin_choices = sorted(auth_plugin_mapping.keys())

auth_plugin_

# Generated at 2022-06-23 18:39:22.637064
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. Currently supported auth types are: {', '.join(
        sorted(_AuthTypeLazyChoices()))}
    '''
)


# Generated at 2022-06-23 18:39:31.827435
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance, expected = _AuthTypeLazyChoices(), set(plugin_manager.get_auth_plugin_mapping().keys())
    actual = set(instance)
    assert actual == expected



# Generated at 2022-06-23 18:39:44.461031
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import unittest
    from httpie.plugins import plugin_manager
    class _AuthTypeLazyChoicesTestCase(unittest.TestCase):
        def test___iter__(self):
            auth_type_lazy_choices = _AuthTypeLazyChoices()
            self.assertEqual(
                list(auth_type_lazy_choices),
                list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
            )
    unittest.main()


# Generated at 2022-06-23 18:39:57.182704
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    assert 'jwt' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    type=plugin_manager.make_auth_type_validator(),
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin that HTTPie should use. Default is "auto" which means
    basic for URIs containing a username, and none otherwise.

    '''
)

# Generated at 2022-06-23 18:40:01.393982
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """ Unit tests for method __contains__ of class _AuthTypeLazyChoices """
    # pylint: disable=protected-access
    choice_iterable = _AuthTypeLazyChoices()
    assert 'name' in choice_iterable
    assert 'not_name' not in choice_iterable

# Generated at 2022-06-23 18:40:13.044695
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method used to perform programs with. Currently, the
    following methods are supported:

        ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())) + '''

    '''
)

auth_type.completer = ChoicesCompleter(auth_type.choices)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:40:15.183100
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:25.471489
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices

    assert sorted(choices) == sorted(['basic', 'digest'])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='Auth plugin to use.'
)


# Generated at 2022-06-23 18:40:27.901392
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()] == [
        auth_type
        for auth_type in plugin_manager.get_auth_plugin_mapping().keys()
    ]


# Generated at 2022-06-23 18:40:34.050518
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(
        list(a))

auth.add_argument(
    '--auth-type',
    type=str.lower,
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used for the --auth option.
    Defaults to Basic. Other choices are Digest, Hawk, and aws.

    '''
)

#######################################################################
# HTTP related
#######################################################################

http = parser.add_argument_group(title='HTTP')


# Generated at 2022-06-23 18:40:35.952962
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'fake']



# Generated at 2022-06-23 18:40:38.899673
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'aws', 'basic', 'digest', 'hawk', 'jwt', 'netrc', 'ntlm', 'oauth1',
        'oauth2'
    ]

# Generated at 2022-06-23 18:40:41.258167
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:49.802891
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    Which authentication method to use.
    The default is "{auth.default}", which is suitable for most HTTP servers.
    Available choices depend on plugins.
    Use --show-auth-plugin-help command line option to show help for available
    auth plugins.

    Alternatively set the environment variable HTTPIE_AUTH_TYPE.

    '''
)


# Generated at 2022-06-23 18:41:02.635608
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, an appropriate
    one is selected automatically, based on the provided credentials.

    Currently supported mechanisms:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                width=60
            )
        ).strip()
    )
)

#######################################################################
# SSL
####################################################################

# Generated at 2022-06-23 18:41:12.739886
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# ``requests.auth.HTTPBasicAuth`` and ``.HTTPDigestAuth`` keyword arguments.
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The backend to use for authentication.

    Available choices:
    {choices}

    '''.format(
        choices='\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Custom headers
#######################################################################

headers = parser.add_argument_group(title='Custom headers')

# Generated at 2022-06-23 18:41:16.918254
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin to use.

    ''',
)

auth.add_argument(
    '--auth-type',
    type=plugin_manager.get_auth_plugin_mapping(),
    dest='auth_plugin',
    help=argparse.SUPPRESS,
)
#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-23 18:41:28.603135
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    from httpie.core import plugin_manager
    plugin_manager.setup()
    plugin_manager.register(BasicAuthPlugin())
    plugin_manager.register(DigestAuthPlugin())
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(['basic', 'digest'])
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify which auth plugin to use.

    '''
)

# Generated at 2022-06-23 18:41:31.778330
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'Basic' not in choices
    assert 'nonExistingAuthType' not in choices


# Generated at 2022-06-23 18:41:43.391752
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='TYPE',
    choices=_auth_type_choices,
    help='''
    The authentication mechanism. For further information, see:
    https://httpie.org/docs#authentication

    The {0} plugin is currently installed.

    '''.format(
        ', '.join(iter(_auth_type_choices))
    )
)

# Generated at 2022-06-23 18:41:47.945008
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__('basic') == True
    assert _AuthTypeLazyChoices().__contains__('plugin_auth_type') == True
    assert _AuthTypeLazyChoices().__contains__('not_existing') == False


# Generated at 2022-06-23 18:41:53.042683
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices_iter = _AuthTypeLazyChoices()
    choices_list = list(lazy_choices_iter)
    assert choices_list == ['digest', 'hmac', 'jwt', 'oauth1', 'basic', 'aws4-hmac']



# Generated at 2022-06-23 18:41:54.616428
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:41:57.886027
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:06.812326
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom-plugin' not in  _AuthTypeLazyChoices()
    assert sorted(list(_AuthTypeLazyChoices())) == \
        ['basic', 'digest']
auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the auth type to be used for the request, e.g.,
    "digest" or "basic".

    See http://httpie.org/plugins for more info about plugins.

    ''',
)

# Generated at 2022-06-23 18:42:07.893455
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:18.645474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'Authentication type ({", ".join(sorted(_AuthTypeLazyChoices()))}).',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    When specified, no initial challenge request will be made and basic HTTP
    auth will be used.

    For example, when communicating with an IIS server that is configured
    to use Windows Integrated Authentication, which doesn't support
    initial challenge requests, use this option.

    '''
)



# Generated at 2022-06-23 18:42:29.656269
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect it based on the supplied credentials and
    "401 Unauthorized" responses from the server.

    The available mechanisms are: {0}

    '''.format(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)


# Generated at 2022-06-23 18:42:31.120685
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())[:2] == ['basic', 'digest']


# Generated at 2022-06-23 18:42:38.043379
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class DummyPlugin:
        auth_type = 'DummyPlugin'

    plugin_manager = PluginManager('httpie.plugins.auth', api_name='http')
    plugin_manager.plug_in(DummyPlugin())

    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'DummyPlugin' in auth_type_lazy_choices
    assert 'Basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices
    # Case insensetive.
    assert 'dummyplugin' not in auth_type_lazy_choices
    assert 'basic' not in auth_type_lazy_choices
    assert 'digest' not in auth_type_lazy_choices
    assert 'InvalidPlugin' not in auth_type

# Generated at 2022-06-23 18:42:47.373328
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Method __contains__ of class _AuthTypeLazyChoices.

    Unit test for method __contains__ of class _AuthTypeLazyChoices.

    """

    # Test if __contains__(self, item) of class _AuthTypeLazyChoices is
    # correctly implemented.
    assert sorted(['aws-hmac', 'digest', 'hawk',
                   'http', 'netrc', 'oauth', 'oauth1']) == \
        sorted(_AuthTypeLazyChoices())

auth.add_argument('--auth-type', type=str, choices=_AuthTypeLazyChoices(),
                  help='''
    Authentication mechanism to be used.

    The default mechanism is "auto" which causes HTTPie to auto-detect the
    authentication method.

    ''')

# Generated at 2022-06-23 18:42:58.185205
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The method used to authenticate. The default (and built-in)
    method is "basic".

    '''
)


#######################################################################
# SSL
#######################################################################


ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:43:00.950260
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:43:12.252183
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import io
    from httpie.plugins import builtin
    from httpie.plugins.manager import PluginManager
    from httpie.plugins import basic_auth
    from httpie.plugins.manager import builtin_plugins_mapping
    from httpie.plugins.manager import builtin_plugins
    from httpie.plugins.manager import plugin_manager

    # backup
    builtin_plugins_mapping_backup = dict(builtin_plugins_mapping)
    builtin_plugins_backup = list(builtin_plugins)
    plugin_manager_backup = plugin_manager
    httpie.plugins = builtin

    # initialize
    builtin_plugins_mapping.clear()
    builtin_plugins.clear()
    plugin_manager = PluginManager()

    # setup
    builtin_plugins.insert(0, basic_auth)



# Generated at 2022-06-23 18:43:17.901142
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Tell HTTPie to use the specified HTTP auth type. The default (if this
    option isn't specified) is to automatically detect the auth type
    (Basic/Digest).

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='no_challenge',
    action='store_true',
    help='''
    Don't send an initial challenge for Basic/Digest
    auth. See: https://tools.ietf.org/html/rfc7235#section-3.1

    ''',
)

# Generated at 2022-06-23 18:43:20.469459
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
    ]


# Generated at 2022-06-23 18:43:23.313109
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'oauth2' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:25.971302
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:43:27.317088
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    l = _AuthTypeLazyChoices()
    assert 'basic' in l


# Generated at 2022-06-23 18:43:29.873751
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(['foo', 'bar'])) == list(sorted(_AuthTypeLazyChoices()))


# Generated at 2022-06-23 18:43:38.934571
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    type=AuthPluginType(plugin_manager),
    help='''
    Auth plugintype to use. Available choices:

        {available_auth_parsers}

    If not specified, then HTTPie determines the auth plugin based
    on the auth credentials specified.

    '''.format(
        available_auth_parsers=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)


#######################################################################
# Other
#######################################################################

# Generated at 2022-06-23 18:43:43.687337
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return list(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.
    When not provided, the plugin is chosen automatically based on provided
    credentials.
    This can be used to force a plugin or to use a plugin if credentials are not
    provided, e.g. to use OAuth without providing any credentials.
    '''
)

auth.add_argument(
    '--auth-plugin',
    dest='auth_plugin',
    default=None,
    help=argparse.SUPPRESS,
)


# Generated at 2022-06-23 18:43:53.767466
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import sys
    import httpie.plugins.builtin
    import httpie.plugins.sample
    sys.modules['httpie.plugins'] = httpie.plugins.sample
    try:
        choices = _AuthTypeLazyChoices()
        assert 'httpie.plugins.sample.basic_auth' in choices
        assert 'httpie.plugins.builtin.BasicAuthPlugin' not in choices
    finally:
        del sys.modules['httpie.plugins']

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to integrate with for authentication.

    ''',
)

# Generated at 2022-06-23 18:43:57.710858
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:09.565502
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    plugin_manager = plugin.PluginManager('httpie.plugins.auth')
    plugin_manager.discover()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    for authtype in auth_plugin_mapping.keys():
        assert authtype in auth_type


auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help='''
    Use the specified HTTP authentication type (digest or basic).

    '''
)

# Generated at 2022-06-23 18:44:21.815635
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. The following mechanisms are
    built-in:

        {auth_type_choices}

    You can dynamically discover and load other plugins that provide
    additional mechanisms.

    '''.format(
         auth_type_choices='\n'.join(
             (8 * ' ') + line.strip() for line in wrap(
                 ', '.join(plugin_manager.get_auth_plugin_mapping()), 60)
         ).strip()
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_

# Generated at 2022-06-23 18:44:26.054342
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select a specific authentication plugin. Auto-select if not provided.
    Plugins include:

        {plugins}

    '''.format(
        plugins=get_auth_plugins_doc()
    ),
)


# Generated at 2022-06-23 18:44:38.711727
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    assert 'digest' in lazy
    assert 'Basic' in lazy
    assert sorted(lazy) == sorted(['basic', 'digest'])
    assert sorted(iter(lazy)) == sorted(['basic', 'digest'])


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism. By default, HTTPie guesses the auth mechanism
    from the --auth option.

    If the server supports multiple auth mechanisms and the most
    secure one is preferred, then you can force the specific
    authentication method by using this option.

    '''
)

# Generated at 2022-06-23 18:44:45.355702
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'plugin' in choices
    assert 'Bearer' in choices
    assert 'hoge' not in choices

    assert 'basic' == next(iter(choices))


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the type of the provided credentials.
    Currently supported:

    {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}
    '''
)

# Generated at 2022-06-23 18:44:53.761209
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert not hasattr(lazy_choices, '_choices')
    assert 'Basic' in lazy_choices
    assert hasattr(lazy_choices, '_choices')
    assert list(lazy_choices) == ['Basic', 'Digest']
auth.add_argument(
    '--auth-type',
    default='auto',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. By default, HTTPie looks at the
    URL and tries to find the authentication mechanism (Basic, Digest, or
    Bearer), and then selects the plugin automatically.

    ''',
)


# Generated at 2022-06-23 18:45:04.857476
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(_AuthTypeLazyChoices())) ==\
        sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type = auth.add_mutually_exclusive_group(required=False)

auth_type.add_argument(
    '--auth-type',
    type=str.lower,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the authentication mechanism. Currently supported options:

    ''' + '\n'.join(
        (8 * ' ') + '{0}'.format(line.strip())
        for line in wrap(
            ', '.join(
                sorted(plugin_manager.get_auth_plugin_mapping().keys())
            ), 60)
    ).strip()
)
auth_type

# Generated at 2022-06-23 18:45:18.232580
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    class FakePluginManager:

        def get_auth_plugin_mapping(self):
            return {
                'fake': None,
                'basic': None,
                'digest': None
            }

    fake_plugin_manager = FakePluginManager()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'fake' in auth_type_lazy_choices
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'oh_no' not in auth_type_lazy_choices
    assert sorted(list(auth_type_lazy_choices)) == [
        'basic', 'digest', 'fake']



# Generated at 2022-06-23 18:45:29.341908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['basic', 'digest', 'hawk']) == \
        sorted(_AuthTypeLazyChoices())

# Uncomment the following line to disable plugins during unit testing:
#_AuthTypeLazyChoices = list

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication type to use. By default (type=auto), HTTPie
    will try to guess the most secure one based on the server response.
    It currently supports: {', '.join(sorted(_AuthTypeLazyChoices()))}.
    If a plugin is not found, the type is assumed to be for Basic auth.

    '''
)



# Generated at 2022-06-23 18:45:42.140477
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


_AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH,
    metavar='TYPE',
    choices=_AUTH_TYPE_CHOICES,
    help='''
    The authentication mechanism to be used.
    The default is '%(default)s'.

    The following mechanisms are supported:

        {0}

    '''.format('\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(map(str, _AUTH_TYPE_CHOICES)), 60)
    ).strip()),
)


# Generated at 2022-06-23 18:45:50.191148
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Mock plugin manager and test if constructor works properly."""
    import unittest
    from mock import MagicMock as Mock

    plugin_manager.AuthPluginManager = Mock()
    plugin_manager.AuthPluginManager.get_auth_plugin_mapping.return_value = {
        'first': 'first_plugin',
        'second': 'second_plugin',
    }

    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['first', 'second']
    assert 'second' in choices



# Generated at 2022-06-23 18:46:00.672099
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'fake' not in auth_type



# Generated at 2022-06-23 18:46:11.747397
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'ntlm' in choices
    assert 'oauth1' in choices
    assert 'bearer' in choices
    assert 'oauth2' in choices


auth.add_argument(
    '--auth-type',
    default=None,
    help='''
    The type of the credentials used for authentication (e.g., 'basic').
    The default is inferred from the --auth option.

    '''
)


# Generated at 2022-06-23 18:46:14.714124
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:16.669917
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert ('Basic' in choices) is True
    assert ('Digest' in choices) is False

# Generated at 2022-06-23 18:46:29.725430
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    for _ in lazy_choices:
        pass
    assert 'basic' in lazy_choices
    assert 'ignored' not in lazy_choices

auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:46:33.291518
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert ('basic' in choices) == ('basic' in plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-23 18:46:43.779856
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Instance of _AuthTypeLazyChoices has no items in __iter__ until we
    # call it.
    _AuthTypeLazyChoices()
_AUTH_CHOICES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AUTH_CHOICES,
    help='''
    Specify a custom authentication plugin.

    '''
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    metavar='PLUGIN',
    help='''
    Specify an external authentication plugin module.
    This gets used for the --auth-type option.

    '''
)

# Generated at 2022-06-23 18:46:54.979514
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert len(choices) > 0
    for choice in choices:
        assert choice in choices
    for choice in ['basic', 'foo']:
        assert (choice in choices) is (choice in plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-23 18:47:05.788068
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'multipart' not in choices
    assert 'bearer' in choices
    assert 'hawk' in choices
    assert 'netrc' in choices

auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='AUTHTYPE',
    default=None,
    choices=(_AuthTypeLazyChoices()),
    help='''
    Specify an auth plugin that should be used for authentication.

    ''',
)


#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-23 18:47:18.404985
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices_object = _AuthTypeLazyChoices()
    assert 'basic' in choices_object
    assert 'digest' in choices_object
    assert 'foo' not in choices_object
    assert list(choices_object) == ['basic', 'digest']



# Generated at 2022-06-23 18:47:25.225850
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_lazy_choices = _AuthTypeLazyChoices()
        assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    except AssertionError:
        raise AssertionError

auth.add_argument(
    '--auth-type',
    type=parse_auth_type_value,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin. The default is `auto'.

    Set to `auto' to let HTTPie try to guess the auth plugin.

    Set to `none' to completely disable authentication.

    ''',
)
