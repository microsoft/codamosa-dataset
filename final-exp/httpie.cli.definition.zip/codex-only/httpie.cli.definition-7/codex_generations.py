

# Generated at 2022-06-23 18:37:33.776845
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Make sure that choices are lazily evaluated at runtime.
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    type=str.lower,
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial auth challenge. This is useful when the auth
    credentials are sent as cookies with the first request.

    ''',
)


# Generated at 2022-06-23 18:37:43.612975
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # must be equal to sorted list of plugins
    assert set(auth_type_lazy_choices) == set(plugin_manager.get_auth_plugin_mapping())
    # check some items
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'whatever' not in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Use --auth-type=help to list the available
    options.

    ''',
)


#######################################################################
# Verbosity

# Generated at 2022-06-23 18:37:46.615217
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bogus' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:37:48.311229
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices()['digest']


# Generated at 2022-06-23 18:37:54.682281
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for choice in _AuthTypeLazyChoices():
        assert choice in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=''
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='AUTHHOST',
    help='''
    The host to authenticate to. Defaults to the host of the
    URL being requested.

    '''
)

#######################################################################
# HTTP and HTTPS
#######################################################################

http = parser.add_argument_group(title='HTTP')

# Generated at 2022-06-23 18:37:59.140041
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'fake' not in auth_type_lazy_choices

# Generated at 2022-06-23 18:38:10.212555
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism
    ({choices}).
    This option is required only when multiple auth plugins are available.
    Otherwise, the plugin is automatically detected from the --auth option.

    '''.format(
        choices=', '.join(sorted(_AuthTypeLazyChoices()))
    )
)

# Generated at 2022-06-23 18:38:21.270208
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'basic' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic", which is the standard HTTP authentication
    using Base64-encoded credentials.

    ''',
)


# Generated at 2022-06-23 18:38:32.733746
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices


# Generated at 2022-06-23 18:38:36.655938
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "basic" in _AuthTypeLazyChoices()
    assert "digest" in _AuthTypeLazyChoices()
    assert "custom" not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:38:48.453733
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()


# Generated at 2022-06-23 18:38:59.944413
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:39:06.331319
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    def_auth_type = 'basic'
    assert def_auth_type in auth_type_lazy_choices
    assert 'non-existed-type' not in auth_type_lazy_choices


# Generated at 2022-06-23 18:39:07.966397
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:10.466069
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AuthTypeLazyChoices() == _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:18.819117
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(plugin_manager.get_auth_plugin_mapping().keys())) == list(_AuthTypeLazyChoices())

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=auth_type_lazy_choices,
    help='''
    The authentication mechanism to be used. Run `http --auth-type=help` to
    list the available types.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Disable sending HTTP authentication challenges (401 responses)
    to the server. This disables sending the Authorization header.

    '''
)

#######################################################################

# Generated at 2022-06-23 18:39:24.213332
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

_auth_type_choices = _AuthTypeLazyChoices()
_auth_type_choices_str = ', '.join(
    f'"{name}"' for name in _auth_type_choices
)
auth.add_argument(
    '--auth-type',
    choices=_auth_type_choices,
    help=f'''
    The authentication mechanism to be used.

    Currently supported: {_auth_type_choices_str}.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Ignore the .netrc file.

    '''
)

# Generated at 2022-06-23 18:39:32.797282
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices



# Generated at 2022-06-23 18:39:45.281315
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type = _AuthTypeLazyChoices()
    assert ['basic', 'digest'] == list(auth_type)

# Pinning the lazy choices to a name allows them to be referred to in the
# help with the name, as opposed to by the default class name.
AUTH_TYPE_CHOICES_LAZY = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=AUTH_TYPE_CHOICES_LAZY,
    help=f'''
    The authentication mechanism to be used.

        {', '.join(sorted(AUTH_TYPE_CHOICES_LAZY))}

    Default is 'basic'.
    For details, see the builtin docstring.

    ''',
)

# Generated at 2022-06-23 18:39:47.339251
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:50.249890
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('InvalidArg')


auth_type_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:01.718100
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""

    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

    assert 'does-not-exist' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:02.933878
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "basic" in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:05.866912
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(['basic','digest','hawk','jwt','oauth1','plugin']) == set(list((_AuthTypeLazyChoices())))

# Generated at 2022-06-23 18:40:12.790470
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    foo_plugin = loaders.plugin_loader()('foo', _AuthPlugin())
    plugin_manager.add_plugin(foo_plugin)
    assert 'foo' in _AuthTypeLazyChoices()
    plugin_manager.remove_plugin(foo_plugin)



# Generated at 2022-06-23 18:40:21.036427
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert "basic" in auth_type_lazy_choices
    assert "digest" in auth_type_lazy_choices
    assert "custom" not in auth_type_lazy_choices
    assert "custom_plugin1" in auth_type_lazy_choices
    assert sorted(auth_type_lazy_choices) == sorted(["basic", "custom_plugin1", "digest"])


# Generated at 2022-06-23 18:40:23.261299
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    result = _AuthTypeLazyChoices()

    assert list(result) == ['basic', 'digest', 'hawk']



# Generated at 2022-06-23 18:40:31.209222
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for _, m in plugin_manager.get_auth_plugin_mapping().items():
        m.load()
    assert list(_AuthTypeLazyChoices()) == [
        'digest', 'hawk', 'basic', 'aws4'
    ]

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    default=utils.auth.AuthCredentials.DEFAULT_TYPE,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)


#######################################################################
# Config file and default options
#######################################################################

config = parser.add_argument_group(title='Config File and Default Options')

# Generated at 2022-06-23 18:40:33.488003
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert set(_AuthTypeLazyChoices()) == set(['Basic', 'Digest'])
    assert 'Unknown' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:36.798199
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # No error -> OK
    list(_AuthTypeLazyChoices())


auth_type_validator = ChoiceValidator(
    'auth type',
    _AuthTypeLazyChoices()
)



# Generated at 2022-06-23 18:40:48.879741
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'kakao' in _AuthTypeLazyChoices()
    assert 'invalid' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default, HTTPie
    determines the authentication type automatically.
    If you specify an authentication type, it is passed to `requests`
    as is.

    '''
)

# Generated at 2022-06-23 18:41:01.178585
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    Specify an authentication type to be used.
    Defaults to the most secure method supported by the server.
    Currently available options:

    {auth_types}

    '''.format(auth_types=_AuthTypeLazyChoices()),
)



#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-23 18:41:11.908554
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins.builtin import HTTPDigestAuth
    mapping = plugin_manager.get_auth_plugin_mapping()
    mapping.pop('digest', None)
    try:
        assert list(_AuthTypeLazyChoices()) == ['basic']
    finally:
        mapping['digest'] = HTTPDigestAuth

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    # We hide the custom auth plugins from the argument parser help.
    help=SUPPRESS,
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Specify a custom endpoint to use for authentication e.g. `/login'.
    '''
)

#######################################################################
# HTTP method


# Generated at 2022-06-23 18:41:16.453448
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.compat import is_py23
    from httpie.input import AuthCredentials
    from httpie import ExitStatus

    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

    if is_py23:
        assert set(list(_AuthTypeLazyChoices())) == set(auth_plugin_mapping.keys())
    else:
        assert set(_AuthTypeLazyChoices()) == set(auth_plugin_mapping.keys())



# Generated at 2022-06-23 18:41:18.412516
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    instance = _AuthTypeLazyChoices()
    assert list(instance) == \
           ['basic', 'digest', 'hawk', 'ntlm']


auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:30.155175
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# ``requests.auth.HTTPBasicAuth``, ``requests_ntlm.HttpNtlmAuth``,
# ``requests_negotiate_sspi.HttpNegotiateAuth`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    How to perform HTTP authentication. Plugin key

    Available built-in plugins: {plugins}

    '''.format(
        plugins=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)
# ``requests_kerberos.HTTPKerberos

# Generated at 2022-06-23 18:41:35.218786
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic') == True
    assert choices.__contains__('bearer') == True
    assert choices.__contains__('digest') == True
    assert choices.__contains__('not_exist_auth') == False


# Generated at 2022-06-23 18:41:36.344509
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:38.065335
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:44.478545
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class MockAuthPlugin:
        auth_type = 'mock-auth'
        auth_type_label = 'mock-auth'

    def register(name, plugin):
        plugin_manager._plugins[name] = plugin

    try:
        register('plugin-a', MockAuthPlugin)
        register('plugin-b', MockAuthPlugin)
        if set(iter(_AuthTypeLazyChoices())) != {'mock-auth'}:
            raise AssertionError
        raise AssertionError
    except AssertionError:
        pass
    finally:
        for name in ('plugin-a', 'plugin-b'):
            del plugin_manager._plugins[name]



# Generated at 2022-06-23 18:41:55.906500
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    ''',
)

auth.add_argument(
    '--auth-type-off',
    action='store_true',
    help='''
    Disable default authentication plugin based on Auth-Type header.

    '''
)


# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:42:06.066658
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    choices=_auth_type_lazy_choices,
    help='''
    Specify a custom authentication plugin to use.
    Current choices are: {0},

    Use '{0}' to see the list of all.

    '''.format(', '.join(_auth_type_lazy_choices))
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-23 18:42:17.440523
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    If ``auto,`` HTTPie tries to guess the mechanism based on the supplied URL
    and credentials.

    ''',
)
auth.add_argument(
    '--auth-type',
    action='append',
    help=SUPPRESS
)

# Generated at 2022-06-23 18:42:29.060450
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest_not' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:42:41.984803
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth mechanism used by the server. If a plugin exists for the
    specified auth type, it will be used. Otherwise, it will default to basic
    auth.

    ''',
)
auth.add_argument(
    '--auth-type-force-plugin',
    action='store_true',
    default=False,
    help='''
    Force the use of an auth plugin, even if basic auth would otherwise
    suffice.

    ''',
)


#######################################################################


# Generated at 2022-06-23 18:42:53.717409
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:01.639467
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AUTH_PLUGIN_KEY in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin.

    Use `{prog} plugins` to list the supported auth plugins
    and `{prog} plugin-info` to print information about a plugin.

    '''.format(prog=os.path.basename(sys.argv[0]))
)

# ``requests.request`` keyword arguments.
auth_plugin_arguments = parser.add_argument_group(
    title='Authentication Plugin Options'
).add_mutually_exclusive_group(required=False)

auth

# Generated at 2022-06-23 18:43:07.023308
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Use --debug flag to see a list of supported
    auth types.

    '''
)


# Generated at 2022-06-23 18:43:14.710929
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-A',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# Miscellaneous
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous')
misc.add_argument(
    '--output-help', '-O',
    action='store_true',
    help='''
    Print the output options help and exit.

    '''
)

# Generated at 2022-06-23 18:43:20.702608
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert('auto' in auth_type_lazy_choices)
    assert('basic' in auth_type_lazy_choices)
    assert('digest' in auth_type_lazy_choices)
    assert('some' not in auth_type_lazy_choices)

# Generated at 2022-06-23 18:43:32.718228
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import KeyValueAuthPlugin
    from httpie.test_app import httpbin
    plugin_manager.load_installed_plugins()
    httpbin.start()
    try:
        plugin_manager.register(KeyValueAuthPlugin)
        assert sorted(list(_AuthTypeLazyChoices())) == ['key-value']
    finally:
        httpbin.stop()
        plugin_manager.unregister(KeyValueAuthPlugin)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an HTTPie auth plugin. Run "http --debug" to see a list of builtin
    plugins. By default, basic HTTP auth is used when a username is provided.

    '''
)

# Generated at 2022-06-23 18:43:35.163724
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())[0] == 'basic'

    # Unit test for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:43:45.239914
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'echo' in _AuthTypeLazyChoices()
    assert 'basicauth' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin to use.
    Default is '{DEFAULT_AUTH_PLUGIN}'.

    Plugins bundled with HTTPie:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-23 18:43:55.281574
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'netrc' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()
    assert 'gssnegotiate' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()

    assert 'digest' in sorted(_AuthTypeLazyChoices())
    assert 'hmac' in sorted(_AuthTypeLazyChoices())
    assert 'hawk' in sorted(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:44:01.800415
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices())) == []

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The final auth plugin to use for authentication. If not specified,
    HTTPie chooses the best plugin for the job.

    '''
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify', '-k',
    action='store_true',
    help='''
    (default: {default})
    Bypass SSL certificate verification.

    '''.format(
        default=True
    )
)

# Generated at 2022-06-23 18:44:12.754269
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


try:
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
except plugin.PluginError as e:
    auth_plugin_mapping = None
    parser.error(e)

# Generated at 2022-06-23 18:44:16.720002
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert all(
        plugin in AuthTypeLazyChoices for plugin in
        plugin_manager.get_auth_plugin_mapping().keys()
    )


# Generated at 2022-06-23 18:44:26.427209
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager._load_plugins()
    choices = _AuthTypeLazyChoices()
    for value in choices:
        if value not in choices:
            raise AssertionError(value)



# Generated at 2022-06-23 18:44:34.540965
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()
    plugin_manager.deregister_plugin_classes()
    plugin_manager.register_plugin_classes(
        [DummyAuthPlugin, DummyAuthPluginWithoutHelp]
    )
    assert list(_AuthTypeLazyChoices().__iter__()) == ['dummy', 'dummy2']
    plugin_manager.deregister_plugin_classes()
    _AuthTypeLazyChoices().__iter__()


# Generated at 2022-06-23 18:44:38.668165
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'NonExistingNotListed' not in choices
    assert list(choices) == sorted(['Basic', 'Digest'])


# Generated at 2022-06-23 18:44:50.793034
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert list(auth_types) == \
        list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use. Overrides the auth plugin set in config for a
    particular host.

    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    By default, HTTPie reads credentials for a host from the ~/.netrc file,
    if the --auth option is not used. Use this flag to disable netrc usage.

    '''
)

####################################################################

# Generated at 2022-06-23 18:44:52.121413
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:44:54.020294
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:05.079728
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(str(t) for t in _AuthTypeLazyChoices()) == set(str(t) for t in AUTH_PLUGIN_MAPPING.keys())

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_auth_type_choices,
    help='''
    The authentication method.

    '''
)

auth.add_argument(
    '--auth-type=digest',
    dest='auth_plugin',
    action='store_const',
    const='digest',
    help='''
    Use Digest authentication. This is the default when -a is used.

    '''
)


# Generated at 2022-06-23 18:45:18.505347
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    l = [i for i in a]
    assert l


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth plugin. Currently supported plugins:

    {format_choices(plugin_manager.get_auth_plugin_mapping())}

    Check out the plugin repository to write your own:
    {PluginManager.PLUGIN_REPOSITORY_URL}

    '''
)


#######################################################################
# HTTP method
#######################################################################
method = parser.add_argument_group(title='Method').add_mutually_exclusive_group(
    required=False)


# Generated at 2022-06-23 18:45:23.149663
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'CustomPlugin' in lazy_choices
    assert 'NonExistentAuth' not in lazy_choices

# Generated at 2022-06-23 18:45:30.804664
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert(iter(auth_type_lazy_choices) == sorted(_AuthTypeLazyChoices()))
    assert('basic' in auth_type_lazy_choices)
    assert('digest' in auth_type_lazy_choices)
    assert('hawk' in auth_type_lazy_choices)

# auth plugins

# Generated at 2022-06-23 18:45:43.084762
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(DEFAULT_AUTH_PLUGINS)

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used. The default, "auto", first tries
    "Basic". If that fails and the --auth option is given, it then tries "Digest".
    This is a fallback mechanism that works in most cases.

    ''',
)
auth.add_argument(
    '--auth-verify',
    dest='auth_verify_ssl',
    action='store_true',
    default=None,
    help='''
    Verify the server's TLS certificate. This is the default.

    '''
)
auth.add

# Generated at 2022-06-23 18:45:56.457778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # The __iter__ method must return a sorted list of auth types
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=auth_type_choices,
    help='''
    Specify a custom auth type.

    To list all the available auth types, run `http --auth-type=`.

    '''
)


# Generated at 2022-06-23 18:45:59.134944
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'non_existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:10.901010
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism
    to be used. Available values are:

        ''' + '\n        '.join(plugin_manager.get_auth_plugin_mapping().keys()) + '''

    ''',
)

#######################################################################
# Timeouts
#######################################################################

timeout = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:46:13.390833
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:46:21.642115
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for auth_type in choices:
        assert auth_type in choices
    assert 'non-existent' not in choices


# Generated at 2022-06-23 18:46:35.031560
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # - We can't use `assert` in the module global scope (prior to function def)
    # - We can't easily use `unittest` for this
    # - There's nothing wrong with this approach – it's just a simple test
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'jwt' in choices
    assert 'hawk' in choices
    assert 'ntlm' in choices
    assert 'aws4-hmac-sha256' in choices


# Generated at 2022-06-23 18:46:40.111346
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin-does-not-exist' not in _AuthTypeLazyChoices()
test__AuthTypeLazyChoices___contains__()


# Generated at 2022-06-23 18:46:42.952391
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    sorted(_AuthTypeLazyChoices())
test__AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:54.499466
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authorization mechanism to use. The following mechanisms
    are supported out of the box:

        * basic
        * digest

    You can also use a custom mechanism by installing an auth plugin.
    Enter ``http --help-auth`` to get a list of available auth plugins.

    '''
)
auth.add_argument(
    '--auth-type=basic',
    action='store_const',
    const='basic',
    dest='auth_type',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:46:56.019505
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:59.059863
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(_AuthTypeLazyChoices, '__iter__')
    assert iter(_AuthTypeLazyChoices()) == iter(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-23 18:47:09.474523
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # mock.patch(target, **kwargs)
    # `target` can be anything that lnk provide in the format
    # module_name.attribute_name
    # target='httpie.cli.argtypes._AuthTypeLazyChoices.__contains__'
    with mock.patch('httpie.cli.argtypes._AuthTypeLazyChoices.__iter__',
                    return_value=['foo', 'bar']):
        auth_type_lazy_choices = _AuthTypeLazyChoices()
        assert 'foo' in auth_type_lazy_choices



# Generated at 2022-06-23 18:47:12.489978
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()  # noqa: F821
    assert 'foo' not in _AuthTypeLazyChoices()  # noqa: F821

# Generated at 2022-06-23 18:47:18.173731
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    items = list(a)
    for item in items:
        assert item in a
        assert item in a
    for item in items:
        assert item in a
        assert item in a
assert 'test__AuthTypeLazyChoices___contains__()' in _AuthTypeLazyChoices.__doc__

# Generated at 2022-06-23 18:47:26.652223
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'awsv4' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'awsv4' in auth_type_lazy_choices
