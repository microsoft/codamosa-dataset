

# Generated at 2022-06-23 18:37:35.375737
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    together = itertools.chain(
        plugin_manager.get_auth_plugin_mapping().keys(),
        ['no such auth']
    )
    assert sorted(together) == sorted(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:37:37.952236
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert 'digest' in obj
    assert 'no_such_type' not in obj



# Generated at 2022-06-23 18:37:44.390379
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.builtin import AuthBasicPlugin, AuthDigestPlugin
    auth_plugin_mapping = {
        'basic': AuthBasicPlugin,
        'digest': AuthDigestPlugin,
    }
    with patch.object(plugin_manager, 'get_auth_plugin_mapping') as mock:
        mock.return_value = auth_plugin_mapping
        assert 'basic' in _AuthTypeLazyChoices()
        assert 'digest' in _AuthTypeLazyChoices()
        assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:46.375571
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:37:48.468786
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices


# Generated at 2022-06-23 18:37:58.100691
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. It can be one of:

        {auth_types}

    The default is to autodetect the authentication type based on the provided
    credentials.
    '''.format(
        auth_types=textwrap.fill(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            initial_indent=' ' * 4,
            subsequent_indent=' ' * 4,
        )
    )
)

# Generated at 2022-06-23 18:38:09.134692
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'noauth' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:17.689999
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Verify that it is iterable
    assert len(_AuthTypeLazyChoices()) > 0

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin. Default is "auto", which means that the
    plugin is determined from the --auth option value.

    '''
)

# Generated at 2022-06-23 18:38:19.028906
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:38:26.340254
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    i = iter(_AuthTypeLazyChoices())
    assert isinstance(i, types.GeneratorType)
    assert hasattr(i, '__iter__')
    assert hasattr(i, '__next__')
    # list(a) == a.__iter__()
    assert list(i) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used.
    Use --debug to see a list of available auth types.

    '''
)

# Generated at 2022-06-23 18:38:36.753474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class AuthTypeLazyChoicesStub:
        def __init__(self):
            from ._auth import BasicAuth
            from ._auth import DigestAuth
            from ._auth import HawkAuth
            from ._auth import OAuth1
            from ._auth import OAuth2
            from ._auth import MultiDict
            self.auth_plugin_mapping = MultiDict({
                'basic': BasicAuth,
                'digest': DigestAuth,
                'hawk': HawkAuth,
                'oauth1': OAuth1,
                'oauth2': OAuth2
            })

        def get_auth_plugin_mapping(self):
            return self.auth_plugin_mapping

    auth_plugin_mapping_stub = AuthTypeLazyChoicesStub()
    auth_type_lazy_choices = _AuthTypeLazyCho

# Generated at 2022-06-23 18:38:48.542896
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Only relevant when --auth
    is also set.

    Specify a value of 'auto' to let HTTPie guess the scheme,
    or 'off' to disable authentication.

    '''.format(
    )
)

# Generated at 2022-06-23 18:39:00.030976
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    # Disabled until we have support for `multiple providers`:
    # nargs='+',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    # XXX: This help is displayed only when no auth type is available.
    help='''
    The auth provider to use.
    Currently supported providers are:

    '''
)

# Generated at 2022-06-23 18:39:13.709408
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter([]) == iter(_AuthTypeLazyChoices())


# Keep in sync with docstring of httpie.auth.plugin_manager.AuthPluginManager.
auth_plugin_mapping = {
    'basic': 'Basic HTTP',
    'digest': 'Digest HTTP',
    'digest-ie': 'Digest HTTP for IIS',
    'awsv4': 'AWS v4',
    'kv': 'Custom Key-Value',
    'ntlm': 'NTLM',
    'oauth1': 'OAuth 1.0',
}



# Generated at 2022-06-23 18:39:25.294707
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. If not specified, "auto" is used which
    means the client will try to determine the auth type based on the
    server response.

    The following auth types are supported: {0}.

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-23 18:39:35.001586
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['basic', 'digest']) == sorted(_AuthTypeLazyChoices())


auth_type_validator = ChoicesValidator(
    'Invalid value for --auth-type.',
    choices=_AuthTypeLazyChoices(),
)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=auth_type_validator,
    default='basic',
    help='''
    Type of the authentication mechanism to use, e.g. basic, digest.

    '''
)


#######################################################################
# Security
#######################################################################
security = parser.add_argument_group(title='Security')

# When using HTTPS with the requests library, we need to check if the cert
# is valid. If it isn't, we should warn the user.

# Generated at 2022-06-23 18:39:46.742582
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(),  list)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    All authentication types:
    %(choices)s
    ''',
)

auth.add_argument(
    '--auth-type-set-auth-header',
    default=False,
    action='store_true',
    help='If to set the Authorization header for for the session.',
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:39:49.957638
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:39:54.331184
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class_ = _AuthTypeLazyChoices()
    assert 'basic' in class_
    assert 'digest' in class_
    assert 'FooBar' not in class_

# Generated at 2022-06-23 18:40:03.843690
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    s = set(_AuthTypeLazyChoices())
    assert 'digest' in s
    assert 'jwt' in s
    assert not any(c.upper() in s for c in 'digest jwt')


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    When set to "auto", the auth type is detected by looking for specific
    headers or cookies in the server's response.

    Otherwise, the following auth types are available:

        {auth_types}

    '''.format(auth_types=plugin_manager.get_available_auth_types_help())
)

# Generated at 2022-06-23 18:40:15.025043
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(auth_type_choices) == sorted(['digest', 'jwt', 'basic'])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Currently supported values are:

        {auth_types}

    '''.format(
        auth_types=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

# ``requests.Session.auth`` keyword arguments.

# Generated at 2022-06-23 18:40:21.046790
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '_AuthTypeLazyChoices.__contains__() behaves as expected'

    assert 'bearer' not in _AuthTypeLazyChoices()

    class MockPluginManager:
        auth_plugins = {'bearer': None}

    with plugin_manager_context(MockPluginManager):
        assert 'bearer' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:40:23.949588
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'OAuth 2' in choices
    assert 'This one is not an existing auth type' not in choices


# Generated at 2022-06-23 18:40:31.701474
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'some_unknown' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=AUTH_PLUGIN_MAP['basic'].name,
    help='''
    Choose an authentication mechanism. The default is Basic, which is generally
    the only one supported by servers.

    '''
)


# Generated at 2022-06-23 18:40:41.693680
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert 'digest' in choices
    assert 'bearer' in choices
    assert 'jwt' in choices
    assert 'basic' in choices
    for i in choices:
        assert i in ['digest', 'bearer', 'jwt', 'basic']


# Generated at 2022-06-23 18:40:50.248854
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:02.727755
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert(list(_AuthTypeLazyChoices()) == ['digest', 'hawk'])


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='Authentication plugin to use.'
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

ssl.add_argument(
    '--verify',
    default=ssl_config.verify,
    action='store_true',
    help='Verify the server SSL certificate.'
)

ssl.add_argument(
    '--verify=no',
    action='store_false',
    dest='verify',
    help='Do not verify the server SSL certificate.'
)

ssl.add_argument

# Generated at 2022-06-23 18:41:12.792985
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass
auth_plugin_mapping = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_plugin_mapping,
    help='''
    The authentication mechanism to be used.
    Available choices:

        {auth_types}

    '''.format(
        auth_types=', '.join(sorted(auth_plugin_mapping))
    )
)


#######################################################################
# Timeouts
#######################################################################

timeout = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:41:20.492719
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. It may be set to any of the values
    supported by the keyring backend (see --help-auth-plugin).

    {plugin_manager.get_auth_plugin_help()}

    '''.strip()
)

# Generated at 2022-06-23 18:41:30.018564
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import json
    import httpie.plugins
    plugin_manager.ignore_directories = [
        os.path.abspath(os.path.join(os.path.dirname(__file__), 'plugins')),
    ]
    for auth_type in _AuthTypeLazyChoices():
        auth_plugin = plugin_manager.get_auth_plugin_mapping()[auth_type]
        auth_plugin.load()
        auth_plugin.update_auth_argument_parser(parser)
        config = Config(
            defaults=dict(colors=256, default_options=dict())
        )

# Generated at 2022-06-23 18:41:37.856210
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(['basic', 'digest', 'custom', 'aws']))


# Generated at 2022-06-23 18:41:44.323336
# Unit test for method __iter__ of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:41:46.832764
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-23 18:41:49.884724
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    assert list(x) == [
        'basic',
        'digest',
        'hawk'
    ]

# Generated at 2022-06-23 18:41:51.682472
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:01.920776
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    For Basic and Digest authentication, the username and password
    are read from --auth. The same username and password are used
    for all requests. For other mechanisms, consult the documentation
    of the corresponding plugin.

    The following types are available (case-insensitive):
    {', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)



# Generated at 2022-06-23 18:42:09.428996
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())  # TODO: remove when pep-0484 (https://www.python.org/dev/peps/pep-0484/#id12) comes out

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default, HTTPie
    tries to guess this from --auth and the URL. Available choices:

    ''' + '\n'.join(
        [''] +
        ['\t{0}\t\t{1}'.format(name, plugin.description)
         for name, plugin in plugin_manager.get_auth_plugin_mapping().items()]
    )
)

#######################################################################
#

# Generated at 2022-06-23 18:42:19.278897
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Ignored if --auth is not specified.

    Currently supported:

    {auth_plugin_help}

    '''.format(auth_plugin_help=build_auth_help(
        plugin_manager.get_auth_plugin_mapping()))
)

#######################################################################
# Config
#######################################################################

config = parser.add_argument_group(title='Config')

# Generated at 2022-06-23 18:42:30.200628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(AUTH_PLUGIN_MAP.keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used for all requests.

    ''',
)
auth.add_argument(
    '--auth-host', '-H',
    default=None,
    metavar='HOST',
    help='''
    Specify a host for which the specified authentication credentials
    are meant. This is useful when multiple hosts require the same credentials,
    e.g., to access a proxy.

    ''',
)


#######################################################################
# HTTP(S) Proxy support.
#######################################################################

proxy = parser.add

# Generated at 2022-06-23 18:42:33.439107
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # An empty set of choices means the auth type is unknown.
    assert len(set(_AuthTypeLazyChoices())) == 0

# Generated at 2022-06-23 18:42:45.029835
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    type=str,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth type. The value can be one of:
        {0}
    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping().keys()))
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    An alternative HTTPie-specific endpoint for auth plugins to use.
    '''
)

# Generated at 2022-06-23 18:42:47.027605
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:42:53.665133
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'bearer' in choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'aws4' in choices
    assert 'aws4_test' in choices
    assert 'aws_sigv4' in choices
    assert 'netrc' in choices
    assert len(set(choices)) == len(choices)


# Generated at 2022-06-23 18:43:06.153238
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    for i in a:
        assert i in a


auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    type=plugin_function,
    help='''
    The authentication plugin to be used.

    ''',
)

#######################################################################
# Tunnels
#######################################################################

tunnel = parser.add_argument_group(title='Tunnels')

# Generated at 2022-06-23 18:43:14.545309
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(_AuthTypeLazyChoices())
    assert choices
    assert 'basic' in choices
    assert choices[-1] in ('aws', 'digest')


# Generated at 2022-06-23 18:43:17.701753
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'non-existing' not in choices


# Generated at 2022-06-23 18:43:29.116847
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(_AuthTypeLazyChoices()) > 0

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an authentication type to be used.

    {plugin_manager.get_auth_plugin_list_formatted()}

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Prevent automatic HTTP Basic/Digest auth with proper auth headers.

    '''
)

# Generated at 2022-06-23 18:43:38.463939
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used if --auth is provided. The value
    can be one of:

        'basic'
        'digest'
        'auto'

    '''
)

#######################################################################
# SSL
#######################################################################
ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:43:40.562792
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:48.252507
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping()['foo'] = 'bar'
    assert 'foo' in choices
    assert 'baz' not in choices
    del plugin_manager.get_auth_plugin_mapping()['foo']
    plugin_manager.get_auth_plugin_mapping()['baz'] = 'qux'
    assert 'baz' in choices


# Generated at 2022-06-23 18:43:57.136465
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'gssnegotiate' not in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-A',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Auth plugins are available for: {choices}.

    Unless you know what you're doing, you'll want to use the default
    (which is "basic" and what you were probably expecting).

    '''.format(choices=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))

)

auth

# Generated at 2022-06-23 18:43:58.491549
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert '' in choices # default choice
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices


# Generated at 2022-06-23 18:44:10.472564
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices())) == [
        'basic', 'digest', 'hawk'
    ]


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth protocol to use. Available choices are:

        {auth_type_choices}

    If no auth type is specified, Basic authentication is used.

    '''.format(auth_type_choices=',\n    '.join(
        [
            '{0} ({1})'.format(name, plugin.auth_type)
            for name, plugin in plugin_manager.get_auth_plugin_mapping().items()
        ]
    )).rstrip()
)

# Generated at 2022-06-23 18:44:22.803056
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Test that the constructor of class _AuthTypeLazyChoices works."""
    auth_type_choices = _AuthTypeLazyChoices()
    for auth_type in auth_type_choices:
        if auth_type == "basic":
            break
    else:
        assert False, "could not find basic auth type"
auth.add_argument(
    '--auth-type',
    default="basic",
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    You can use a custom plugin that supports any auth mechanism.
    See: https://httpie.org/docs#plugins

    '''
)


#######################################################################
# misc
#######################################################################


# Generated at 2022-06-23 18:44:35.457351
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    for auth_type in auth_types:
        assert len(auth_type) > 0


# Generated at 2022-06-23 18:44:38.350479
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()).__eq__(['digest', 'hmac', 'jwt', 'oauth1', 'oauth2'])

# Generated at 2022-06-23 18:44:50.656470
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(iter(_AuthTypeLazyChoices())) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )
    plugin_manager.load_builtin_plugins()
    assert set(iter(_AuthTypeLazyChoices())) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )



# Generated at 2022-06-23 18:45:02.800375
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
    ]


# Generated at 2022-06-23 18:45:15.494211
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices).sort() == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    Available options depend on the installed plugins.
    To see available options, run:

        $ http --debug

    The default value is: {DEFAULT_AUTH_PLUGIN}.

    '''
)

# Generated at 2022-06-23 18:45:27.886529
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin to use. Available plugins are:

    {plugins}

    '''.format(
        plugins='\n'.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)
auth.add_argument(
    '--auth-nonce-count',
    type=int,
    default=None,
    help='''
    The nc (nonce count) value to use in the Authorization header of
    each Digest auth request. It defaults to 1.

    '''
)
auth.add_argument

# Generated at 2022-06-23 18:45:29.051069
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'keyring' in plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 18:45:33.646292
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    instance = _AuthTypeLazyChoices()
    assert list(instance) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:45:44.653130
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Allows for choosing an auth plugin other than the built-in ones:
    basic, digest.

    You can list all auth plugins registered with HTTPie by
    running: `{HTTPIE} plugin debug auth`.

    '''
)

auth.add_argument(
    '--auth-type-help',
    metavar='AUTH_PLUGIN',
    help=f'''
    Show help message for a custom auth plugin. Example:

        {HTTPIE} --auth-type-help oauth2

    '''
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add

# Generated at 2022-06-23 18:45:57.794475
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_lazy_choices,
    help='''
    The type of auth credentials provided with --auth. If the type is not
    specified, HTTPie tries to guess that based on the structure of the
    --auth value.

    Currently supported types:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(auth_type_lazy_choices)), 60)
        ).strip(),
    )
)
auth.add_

# Generated at 2022-06-23 18:46:09.936208
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class TestPlugin(AuthPlugin):
        name = 'test'
        auth_type = 'test-type'
    with replace_plugins(TestPlugin()):
        auth_type_lazy_choices = _AuthTypeLazyChoices()
        assert 'test' in auth_type_lazy_choices
        assert 'test-type' in auth_type_lazy_choices
        assert len(list(auth_type_lazy_choices)) == 1

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default value is guessed from the provided --auth
    value and the server's challenges.

    ''',
)

####################################################################

# Generated at 2022-06-23 18:46:19.334512
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for item in list(_AuthTypeLazyChoices()):
        assert item in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    If not provided, HTTPie tries to guess the most suitable one based on the
    provided --auth credentials.

    ''',
)
auth.add_argument(
    '--auth-send',
    dest='auth_send',
    action='store_true',
    help='''
    Send the HTTP Basic authentication header even for follows
    (status code 30x).

    (The default is to only send the header for host of the original
    request, i.e., not for follows.)

    '''
)
auth

# Generated at 2022-06-23 18:46:21.066871
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:34.390026
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from subprocess import CalledProcessError
    from tempfile import NamedTemporaryFile
    import pytest
    from httpie import plugin_manager, __main__ as main
    from httpie.plugins.builtin import HTTPBasicAuth
    with NamedTemporaryFile('w') as f:
        f.write('''
            from httpie.plugins import AuthPlugin

            class PasswdAuth(AuthPlugin):
                auth_type = 'passwd'

                def get_auth(self, username=None, password=None):
                    assert ':' not in username
                    return username, password or getpass.getpass()
        ''')
        f.flush()

# Generated at 2022-06-23 18:46:35.754429
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'git' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:45.709647
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        'basic',
        'digest',
        'extra',

    ] == list(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:46:56.506263
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()  # built-in auth
    assert 'custom' in _AuthTypeLazyChoices()  # 3rd party plugin


auth.add_argument(
    '--auth-type', '-t',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Use `http --debug --auth-type=custom ...` to have HTTPie print
    the challenge sent by the server.

    '''
)

# Generated at 2022-06-23 18:47:07.433167
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.clear_auth_plugin_mapping()
    # Should give empty list
    assert list(_AuthTypeLazyChoices()) == []
    # Should give sorted list of plugins
    plugin_manager.update_auth_plugin_mapping({'a': '', 'b': ''})
    assert list(_AuthTypeLazyChoices()) == ['a', 'b']

# For argparse choices.
auth_type_choices = _AuthTypeLazyChoices()
auth_type_choices_string = '|'.join(auth_type_choices)


# Generated at 2022-06-23 18:47:11.856778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:47:21.398320
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(_AuthTypeLazyChoices())
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    The default value is "basic" (i.e., base64-encoded
    "username:password" string).

    You can use "digest" to use HTTP Digest Authentication.
    The digest auth implementation supports the Quality of
    Protection "auth" and "auth-int" (e.g., qop=auth).

    Use --auth-type=help to see a list of all supported types.

    ''',
)



# Generated at 2022-06-23 18:47:22.692816
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()