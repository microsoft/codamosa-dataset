

# Generated at 2022-06-23 18:37:22.069212
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    assert 'basic' in _AuthTypeLazyChoices()
    assert 'gssnegotiate' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:35.160598
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:37:44.631246
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Run `http --help-auth`
    to print the list of available mechanisms.

    '''
)


# Generated at 2022-06-23 18:37:55.586494
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import AuthBasicPlugin

    @plugin_manager.register
    class AuthTestPlugin(AuthBasicPlugin):
        auth_type = 'foo'

    assert list(_AuthTypeLazyChoices()) == ['foo', 'basic', 'digest']

    plugin_manager.unregister(AuthTestPlugin)


auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:38:05.928800
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for auth_type in _AuthTypeLazyChoices():
        assert len(auth_type) > 0


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Currently supported mechanisms:
    %(choices)s

    ''',
)
auth.add_argument(
    '--auth-plugin',
    action=plugin_manager.LoadPluginAction
)
auth.add_argument(
    '--auth-host',
    default=AUTH_HOST
)
auth.add_argument(
    '--auth-timeout',
    default=AUTH_TIMEOUT
)



# Generated at 2022-06-23 18:38:07.625710
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): assert 'basic' in _AuthTypeLazyChoices() # noqa: E501

# Generated at 2022-06-23 18:38:17.875544
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Needed for plugin testing
    assert len(list(_AuthTypeLazyChoices())) > 1

auth_type = auth.add_mutually_exclusive_group() \
    .add_argument(
        '--auth-type',
        metavar='TYPE',
        choices=_AuthTypeLazyChoices(),
        help='''
        Force usage of a specific authentication mechanism.

        By default HTTPie tries to determine the right mechanism and/or
        type automatically.

        Types:

        ''' + indent(get_auth_help(), 8 * ' ').rstrip(),
    )

# Check that the default value of --auth-type is contained in --auth-type help.

# Generated at 2022-06-23 18:38:19.142705
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-23 18:38:26.395029
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'bearer' in choices
    assert 'digest' in choices
    assert 'hmac' in choices
    assert 'basic' in choices
    assert 'hawk' in choices

    assert sorted(choices) == sorted(('bearer', 'digest', 'hmac', 'basic', 'hawk'))


# Generated at 2022-06-23 18:38:31.714029
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method (digest or basic). Default: basic.

    '''
)



# Generated at 2022-06-23 18:38:38.783714
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert len(set(auth_type_choices)) == len(set(auth_type_choices))
    assert set(['digest', 'jwt', 'basic', 'hawk']) == set(auth_type_choices)  # noqa


# Generated at 2022-06-23 18:38:40.816327
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()

    for choice in choices:
        pass


# Generated at 2022-06-23 18:38:53.205225
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Note: This is an example unit test for _AuthTypeLazyChoices.__iter__.
    # Since _AuthTypeLazyChoices.__iter__ is a function of
    # auth_plugin_manager.plugin_manager, the test is located here and not in
    # auth_plugin_manager_test.py
    atlc = _AuthTypeLazyChoices()
    assert list(atlc) == ['basic', 'digest', 'multi-digest']
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    type=lambda x: x.lower(),
    default='basic',
    help=''
)
auth.add_argument(
    '--auth-plugin',
    action=plugin_action(plugin_manager, 'auth'),
    help=''
)


# Generated at 2022-06-23 18:38:59.719692
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Digest' in _AuthTypeLazyChoices()  # nosec
    assert 'Basic' in _AuthTypeLazyChoices()  # nosec
    assert 'digest' in _AuthTypeLazyChoices()  # nosec
    assert 'basic' in _AuthTypeLazyChoices()  # nosec
    assert 'Foo' not in _AuthTypeLazyChoices()  # nosec
    assert 'FooBar' not in _AuthTypeLazyChoices()  # nosec

# Generated at 2022-06-23 18:39:13.352272
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    If no scheme is provided in the URL, this option determines the
    authentication method to use. The auto setting detects the scheme
    based on the HTTP response from the server (default).

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_challenge',
    default=True,
    action='store_false',
    help='''
    Don't send an initial, empty unauthorized request.

    '''
)

# Generated at 2022-06-23 18:39:25.201200
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default,
    the authentication mechanism is guessed based on the provided credentials and
    the HTTP traits of the server, such as which authentication methods it
    supports and whether the realm is specified. {plugin_list}

    '''.format(
        plugin_list=plugin_manager.get_plugin_listing('auth')
    )
)

# Generated at 2022-06-23 18:39:29.194056
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['Baz', 'Bar', 'Foo', 'Same']) == sorted(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:39:31.315223
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    tester = _AuthTypeLazyChoices()
    assert 'basic' in tester
    assert not 'asd' in tester

# Generated at 2022-06-23 18:39:38.407228
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'postman', 'simple']

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default='simple',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to use. Available choices: {0}.
    The "simple" method is the default.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping()))
)

# Generated at 2022-06-23 18:39:48.422748
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    available_auth_types = _AuthTypeLazyChoices()
    assert 'basic' in available_auth_types
    assert 'digest' in available_auth_types
    assert len(list(available_auth_types)) > 0

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Force usage of a certain auth plugin. Available plugins: {0} and your own
    plugins. Use --debug flag to show details.

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-23 18:39:53.691166
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    mocker = Mocker()
    fake_choices = {'foo', 'bar', 'baz'}
    fake_manager = mocker.mock()
    manager_get_auth_plugin_mapping_mock = fake_manager.get_auth_plugin_mapping
    manager_get_auth_plugin_mapping_mock.return_value = fake_choices
    fake_module = mocker.replace(plugin_manager, fake_manager)
    with mocker:
        lazy_choices = _AuthTypeLazyChoices()
        assert_equal(sorted(list(lazy_choices)), sorted(list(fake_choices)))


# Generated at 2022-06-23 18:40:03.777850
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices() == [
            'basic', 'digest', 'jwt'
        ]

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Force the specified HTTP authentication type to be used.
    The supported types are:

        'basic', 'digest', 'jwt'

    The default is 'basic' or 'digest' (if the --auth option
    contains a colon, indicating a password).

    '''
)

# Generated at 2022-06-23 18:40:06.693828
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    AUTH_TYPE_CHOICES.append('OBJ_INVALID')
    assert 'OBJ_INVALID' in _AuthTypeLazyChoices()
    del AUTH_TYPE_CHOICES[-1]
    assert 'OBJ_INVALID' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:11.773417
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin. The {AUTO_AUTH_PLUGIN_ALIAS} (default)
    will try to detect the auth type and use the most suitable plugin.
    Available plugins: {', '.join(plugin_manager.get_auth_plugin_mapping())}

    '''
)


# Generated at 2022-06-23 18:40:23.467999
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(_AuthTypeLazyChoices(), '__contains__')
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used with the provided credentials.
    '''
)
auth.add_argument(
    '--auth-types',
    action='store_true',
    help='''
    Display supported authentication types and exit.
    '''
)


#######################################################################
# Proxies
#######################################################################

proxies = parser.add_argument_group(title='Proxies')

# Generated at 2022-06-23 18:40:24.999282
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']


# Generated at 2022-06-23 18:40:27.415579
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:40:38.367382
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    The authentication mechanism to be used.

    Request plugins can define custom authentication mechanisms.
    The following methods are supported by default:

    ''' + textwrap.dedent('''\
        basic
        digest

        The default is "basic".
    ''') + '''

    ''',
    choices=_AuthTypeLazyChoices(),
)


# Generated at 2022-06-23 18:40:49.958589
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.get_auth_plugin_class,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    Send authentication information without first verifying the
    server's credentials.

    With this option, authentication is always attempted, even when the
    server is known to be unauthorized.

    '''
)

# Generated at 2022-06-23 18:41:02.635441
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Given
    choices = _AuthTypeLazyChoices()
    plugin_manager.discover_auth_plugins()

    # When
    result = list(choices)

    # Then
    assert result == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use.

    The default is to automatically detect the auth type based on the
    presence of certain headers or body parameters (such as "access_token").
    This flag can be handy when automatic detection fails.
    '''
)


# Generated at 2022-06-23 18:41:12.711966
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    Specify the authentication type (default: {default}). Valid choices
    depend on currently installed plugins. In most cases, you will have
    "basic" and "digest".

    '''.format(default=DEFAULT_AUTH_PLUGIN),
    default=DEFAULT_AUTH_PLUGIN,
    type=AuthTypeValidator(),
    choices=_AuthTypeLazyChoices(),  # Needed for plugin testing
)


# Generated at 2022-06-23 18:41:20.460578
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'bearer' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'aws4-hmac-sha256' in choices
    assert 'oauth2' in choices
    assert 'spnego' in choices
    assert 'ntlm' in choices
    assert 'negotiate' in choices

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.

    ''',
)


# Generated at 2022-06-23 18:41:29.981287
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # make sure that iterating over _AuthTypeLazyChoices yields all the
    # registered auth plugin types (and only the registered ones).
    auth_plugin_mappings = set(plugin_manager.get_auth_plugin_mapping())
    assert set(iter(_AuthTypeLazyChoices())) == auth_plugin_mappings


# Generated at 2022-06-23 18:41:42.028010
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'bearer' in lazy_choices
    assert 'custom' in lazy_choices
    assert 'foo' not in lazy_choices


auth_type_validator = AuthPluginTypeValidator(
    # Needed for plugin testing
    lazy_choices=_AuthTypeLazyChoices()
)



# Generated at 2022-06-23 18:41:54.306599
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



auth_type = auth.add_mutually_exclusive_group(required=False) \
    .add_argument(
        '--auth-type',
        default='auto',
        metavar='TYPE',
        choices=_AuthTypeLazyChoices(),
        help='''
        The type of HTTP authentication to use.

        This can be specified as a separate argument from --auth, in
        case both basic and digest auth are needed.

        The default is 'auto', which means that the auth type is
        guessed based on the presence of a password, and HTTPie's
        ability to use it without prompting.

    '''
    )

# Generated at 2022-06-23 18:41:57.933177
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert isinstance(iter(auth_types), Iterator)
    # Make sure that plugins is initialized.
    list(iter(auth_types))
    assert 'basic' in auth_types



# Generated at 2022-06-23 18:42:00.055779
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:42:08.536893
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for key in _AuthTypeLazyChoices():
        assert key in plugin_manager.get_auth_plugin_mapping()


# XXX: Alternatively, we could use the `type` keyword argument to
#      ``add_argument``.
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication method (plugin) to use. By default,
    the appropriate one is guessed.

    Plugins:

        {plugin_list}

    '''
)


# Generated at 2022-06-23 18:42:12.631173
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert [
        'basic', 'digest', 'fake', 'test-plugin'
    ] == list(auth_type_lazy_choices)


# Generated at 2022-06-23 18:42:22.862170
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),  # see test__AuthTypeLazyChoices
    help='''
    Plugin used for handling the authentication.
    The default plugin is '{default}'.

    Available plugins are:

        {available_plugins}

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        available_plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-23 18:42:26.602973
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == (
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
    )

# Generated at 2022-06-23 18:42:35.188969
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Defaults to "basic".
    The following mechanisms are supported:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(_AuthTypeLazyChoices()), 60)
        ).strip()
    )
)

# Generated at 2022-06-23 18:42:46.215596
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lst = ['a', 'b', 'c']
    class _MockAuthPluginManager(object):
        @staticmethod
        def get_auth_plugin_mapping():
            return {c: None for c in lst}
    with patch.object(plugin_manager, 'get_auth_plugin_mapping',
                      new=_MockAuthPluginManager.get_auth_plugin_mapping):
        assert [c for c in _AuthTypeLazyChoices()] == lst

# Generated at 2022-06-23 18:42:57.497590
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices() # noqa: F841



# Generated at 2022-06-23 18:43:10.465433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert auth_type_lazy_choices
    assert list(auth_type_lazy_choices)


# Generated at 2022-06-23 18:43:14.654779
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'ignore' in choices
    assert 'fake' not in choices

# Generated at 2022-06-23 18:43:24.795009
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    Unit test for method __contains__ of class _AuthTypeLazyChoices
    """
    authTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'basic' in authTypeLazyChoices

_auth_types = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_auth_types,
    help='''
    Choose an authentication implementation (the default is Basic).

    Available types:

    {types}

    '''.format(
        types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_auth_types)), 60)
        ).strip(),
    )
)

# Generated at 2022-06-23 18:43:26.516278
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:36.780259
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    Test class _AuthTypeLazyChoices.
    See also class _AuthTypeLazyChoices.
    """
    if 'digest' in _AuthTypeLazyChoices():
        auth_digest_type = True
    else:
        auth_digest_type = False
    if 'hawk' in _AuthTypeLazyChoices():
        auth_hawk_type = True
    else:
        auth_hawk_type = False

    if (auth_digest_type and auth_hawk_type):
        return True
    else:
        return False


# Generated at 2022-06-23 18:43:38.848823
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'awk' not in choices

# Generated at 2022-06-23 18:43:41.486281
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Test if contains method of class return false on bad value."""
    assert 'test_' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:53.346886
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # constructor of class _AuthTypeLazyChoices
    assert set(_AuthTypeLazyChoices()) == \
        set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies which method to use for authentication. If this option is not
    given, HTTPie tries to infer the authentication method from the --auth
    option. If --auth contains ':' then Basic authentication is assumed,
    otherwise Digest authentication.
    ''',
)

# Generated at 2022-06-23 18:44:00.778074
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism.

    Use `http --auth-type=help all` to list the available authentication types.

    '''
)
auth.add_argument(
    '--auth-type=help',
    choices=['help'],
    action=_AuthTypeHelpAction,
    help=argparse.SUPPRESS
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxies = parser.add_argument_group(title='HTTP(S) Proxy')

# Generated at 2022-06-23 18:44:11.927697
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted([
        'Basic', 'Digest', 'Www-Authenticate', 'Foo'
    ]) == sorted(_AuthTypeLazyChoices())


auth_type_validator = AuthTypeValidator(
    'Unsupported authentication method. '
    'For available methods, use "http --help-auth".'
)


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    type=auth_type_validator,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. Use "http --help-auth" for a list of
    available methods. If "auto" is used, the authentication method is
    determined based on the response content.

    '''
)

# Generated at 2022-06-23 18:44:19.491051
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    items = []
    for item in _AuthTypeLazyChoices():
        items.append(item)
    assert 'basic' in items
    assert 'bearer' in items
    assert 'digest' in items
    assert 'hawk' in items
    assert 'netrc' in items



# Generated at 2022-06-23 18:44:28.179345
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication plugin to use plugin.
    Available in this version of HTTPie:

        {plugin_manager.show_plugin_names('Auth')}

    Use `--debug` flag to see the full plugin list.

    '''
)

auth_help = f'''
    Specify HTTP authentication method to be used. This is useful if the
    server uses some non-standard HTTP authentication method.

    Available types:

        {plugin_manager.show_plugin_names('Auth')}
'''

# Generated at 2022-06-23 18:44:39.898766
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(_AuthTypeLazyChoices(), '__contains__')
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')

auth_plugin = auth.add_mutually_exclusive_group()
auth_plugin.add_argument(
    '--auth-type',
    metavar='NAME',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin. Defaults to ``auto``, which selects the
    appropriate plugin based on the provided credentials (--auth).
    '''
)

# Generated at 2022-06-23 18:44:51.575495
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'redacted' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:44:53.424562
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:04.635580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert next(choices.__iter__()) == 'aws-sigv4'

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used. Supported plugins:

    {supported_auth_types}

    '''.format(
        supported_auth_types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(
                ', '.join(sorted(
                    plugin_manager.get_auth_plugin_mapping().keys()
                )), 60)
        ).strip()
    )
)

# Generated at 2022-06-23 18:45:06.022276
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:11.904134
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()

    assert 'basic' in auth_types
    assert 'digest' in auth_types
    assert 'CustomAuth' in auth_types
    assert 'Custom_Auth' not in auth_types
    assert 'customauth' not in auth_types



# Generated at 2022-06-23 18:45:24.833712
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
auth_plugin_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=auth_plugin_choices,
    help='''
    The authentication mechanism to be used.

    Currently supported authentication types are:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(auth_plugin_choices)), 60)
        ).strip()
    )
)

# Generated at 2022-06-23 18:45:26.021727
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:33.128267
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import FormAuthPlugin
    from httpie.plugins import plugin_manager
    @plugin_manager.auth_plugin
    class FooBarAuthPlugin(FormAuthPlugin):
        auth_type = 'foobar'
        pass

    actual = sorted(iter(_AuthTypeLazyChoices()))
    expected = ['basic', 'digest', 'foobar', 'jwt', 'netrc']
    assert actual == expected

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    Use `http --debug` to display the list of available plugins.

    '''
)


# Generated at 2022-06-23 18:45:38.085192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit tests for _AuthTypeLazyChoices.__contains__
    """
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-23 18:45:47.274701
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth plugin to use.
    The value corresponds to the name of the module in the `httpie_plugins`
    package (e.g. `myplugin`) or the path to the module file (e.g.
    `/path/to/myplugin.py`).
    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_type',
    help=SUPPRESS
)

# Generated at 2022-06-23 18:45:48.974068
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'custom' in auth_types



# Generated at 2022-06-23 18:45:50.637323
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:46:00.732342
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices.__iter__(None))
auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use. Currently available:

        {plugins}

    '''.format(
        plugins=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys()))
        )
)

#######################################################################
# Custom headers
#######################################################################


# Generated at 2022-06-23 18:46:11.793985
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(('basic', 'digest')) <= _AuthTypeLazyChoices()

auth_plugin = auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. HTTPie supports several mechanisms,
    the most common ones being: "basic" and "digest".

    The default depends on the --auth argument. If no --auth argument is
    provided it defaults to "basic".

    Some plugins support extra arguments that can be passed in via the
    --auth-type option, e.g. "ntlm domain\\username:password".

    '''
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:46:15.869498
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:23.238656
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    def get_mapping():
        return {
            item: 1
            for item in ['a', 'b', 'c']
        }

    class MockPluginManager:
        @staticmethod
        def get_auth_plugin_mapping():
            return get_mapping()

    plugin_manager = MockPluginManager()

    auth_type = _AuthTypeLazyChoices()
    list(auth_type) == ['a', 'b', 'c']

    get_mapping().pop('c')

    list(auth_type) == ['a', 'b']



# Generated at 2022-06-23 18:46:25.263525
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'multipart' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:28.157819
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        'basic',
        'digest',
        'hawk',
    ] == list(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:46:29.918279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:41.664019
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Choose an auth plugin for making an authenticated request.
    TYPE is a string that identifies an auth plugin.
    Use --auth-type=auto to select a plugin automatically.
    Use --debug to list all plugins and how they are selected.

    ''',
)

# Generated at 2022-06-23 18:46:53.880352
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, an appropriate
    one is guessed from the --auth option or from the hostname.

    '''
)

# Overrides ``requests.request`` keyword arguments.
auth_plugin = auth.add_mutually_exclusive_group(required=False)


# Generated at 2022-06-23 18:47:05.239880
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_set = _AuthTypeLazyChoices()
    assert 'basic' in lazy_set
    assert 'digest' in lazy_set
    assert 'jwt' in lazy_set

    assert 'not-there' not in lazy_set


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    Specify the authentication type to use.

    Specify a value from: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    The default is basic.

    '''
)


# Generated at 2022-06-23 18:47:07.237669
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:47:19.428956
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    actual_choices = [choice for choice in _AuthTypeLazyChoices()]
    actual_choices.sort()
    expected_choices = list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    assert actual_choices == expected_choices

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication method.

    '''
)

#######################################################################
# Proxies
#######################################################################

proxies = parser.add_argument_group(title='Proxy')
