

# Generated at 2022-06-23 18:37:35.160946
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN,
    help='''
    The authentication type to be used for the request.
    '''
)

auth.add_argument(
    '--auth-plugin',
    dest='auth_type',  # Alias for backwards compatibility.
    choices=_AuthTypeLazyChoices(),
    help='''
    Alias for --auth-type. Do not use this argument in new code!

    ''',
    **DOC_HIDE
)


# Generated at 2022-06-23 18:37:37.768146
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'dummy' in choices
    assert 'not_existing' not in choices


# Generated at 2022-06-23 18:37:46.371618
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to use.
    For a list of built-in plugins run: `http --help-auth`.
    To see the list of available plugins from PyPI run: `http --debug
    2>&1 | grep httpie-auth-`.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not perform challenge-response authentication even if server
    appears to support it.

    '''
)

auth_configuration = parser.add_argument_group(title='Authentication Configuration')
auth

# Generated at 2022-06-23 18:37:47.636415
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """it should work"""
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:54.106004
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified auth type. By default, HTTPie will try to detect the
    auth type by examining the provided credentials.

    '''
)

auth.add_argument(
    '--auth-schemes',
    metavar='SCHEME_NAMES',
    help='''
    List of auth schemes to enable. By default all auth schemes are enabled.

    '''
)


# Generated at 2022-06-23 18:38:05.564551
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth2', 'basic']

#: Choices for the --auth-type CLI option.
AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=AUTH_TYPE_CHOICES,
    help=f'''
    Force HTTPie to use the specified authentication plugin.

    To use a custom authentication plugin, install it and pass
    the plugin name as the --auth-type option.

    The list of currently installed plugins:
    {list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''.replace("'", '')
)


#######################################################################
# Input options

# Generated at 2022-06-23 18:38:14.834550
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'ntlm' in choices

    assert list(choices) == ['basic', 'digest', 'hawk', 'ntlm']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    For more information, try: http --auth-type=TYPE --help.

    ''',
)


# Generated at 2022-06-23 18:38:23.901770
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices
    assert 'jwt' in auth_type_lazy_choices


# Generated at 2022-06-23 18:38:34.390363
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(auth_type_choices) != []
    assert list(auth_type_choices) == sorted(list(auth_type_choices))


# Generated at 2022-06-23 18:38:36.991178
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:38:48.764517
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'Digest' in choices
    assert 'UnknownAuthType' not in choices

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication type: {0}.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping().keys()))
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-23 18:39:00.245914
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin.

    To see the list of plugins, run:

        $ http --debug

    It is also possible to use built-in authentication schemes:

        $ http --auth-type=basic URL
        $ http --auth-type=digest URL

    '''
)


# Generated at 2022-06-23 18:39:07.342472
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:17.531118
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'jwt', 'oauth1']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication type. HTTPie will guess based on the supplied
    data and preferences.

    '''
)

# Generated at 2022-06-23 18:39:19.179021
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:24.375731
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = []
    for item in _AuthTypeLazyChoices():
        items.append(item)
    items.sort()
    assert items == [
        'Basic', 'Bearer', 'Digest', 'Flex', 'Hawk', 'Negotiate', 'OAuth1',
        'SPNEGO'
    ]

# Generated at 2022-06-23 18:39:31.289027
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basicauth' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    (default: "auto")

    Currently, the following auth types are available:
        {0}

    '''.format(
        ''.join('\n        {0}'.format(name)
                for name in keys_sorted_by_value(
                    plugin_manager.get_auth_plugin_mapping())),
    )
)



# Generated at 2022-06-23 18:39:34.605468
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hmac', 'jwt', 'netrc', 'oauth1', 'oauth2']

# Generated at 2022-06-23 18:39:44.414242
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # type: () -> None
    '''
    >>> ('basic' in _AuthTypeLazyChoices())
    True
    >>> ('non-existing' in _AuthTypeLazyChoices())
    False
    '''
    pass


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an authentication plugin.
    The following are available:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)



# Generated at 2022-06-23 18:39:57.101654
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help='Authentication type (plugin).'
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help='Authentication plugin.'
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='Resend the credentials when challenged by the server.'
)
auth.add_argument(
    '--auth-timeout',
    type=float,
    default=None,
    help='Connection timeout for retrieving the authentication response'
)



# Generated at 2022-06-23 18:40:00.691890
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Plugin manager provides options.

    If plugin manager provides options, variant __contains__ is available.
    """
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices


# Generated at 2022-06-23 18:40:07.850305
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert sorted(choices) == sorted(['Basic', 'Digest'])

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices()
)
auth.add_argument(
    '--proxy-auth',
    default=None,
    metavar='USER[:PASS]',
    help='''
    If only the username is provided (-a username), HTTPie will prompt
    for the password.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:40:18.289822
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == plugin_manager.get_auth_plugin_mapping().keys()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    If a custom authentication plugin is installed, use it instead of the
    built-in basic and digest authentication mechanisms.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Don't perform a challenge-response authentication even if the server
    requests one.

    '''
)

#######################################################################
# SSL/TLS
#######################################################################


ssl = parser.add_argument_

# Generated at 2022-06-23 18:40:27.008396
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-23 18:40:38.066616
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert len(list(auth_type_lazy_choices)) > 0

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the auth plugin to use.

    ''',
)

# ``requests.request`` keyword arguments.
auth_plugin_options = parser.add_argument_group(
    title='Authentication Options',
)
auth_plugin_options.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:40:49.765184
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [elem for elem in _AuthTypeLazyChoices()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())
_auth_type_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:52.884632
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:57.669929
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(['basic', 'digest']))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism. 
    Possible values:
        {auth_types}

    '''.format(auth_types='\n'.join(
        [8 * ' ' + line.strip() for line in wrap(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            60
        )]
    ).strip()),
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-23 18:41:07.302573
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:
    {0}.'''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

auth.add_argument(
    '--proxy-auth',
    action='append',
    metavar='USER[:PASS]',
    help='''
    HTTP Basic authentication for a proxy server, if required.
    This is an alias for --auth (for consistency with cURL).

    ''',
)

# Generated at 2022-06-23 18:41:10.964791
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(iter(_AuthTypeLazyChoices()), types.GeneratorType)
    assert isinstance(list(_AuthTypeLazyChoices()), list)

auth_plugin_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:41:17.589818
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication method for the request.
    The following authentication types are available:

        {plugin_manager.get_plugin_help().strip()}
    '''
)



# Generated at 2022-06-23 18:41:22.859673
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices

    assert list(choices) == ['basic', 'digest']

# XXX: Once AuthPluginManager is a constructor argument, we can use ``type=``
#      instead of ``choices=`` and get rid of this class.

# Generated at 2022-06-23 18:41:32.816131
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(
        plugin_manager.get_auth_plugin_mapping()
    )

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, if not otherwise specified by the
    provided credentials.

    The following mechanisms are currently supported:
    {auth_plugins}

    '''
)
auth.add_argument(
    '--auth-plugin',
    nargs='?',
    help=argparse.SUPPRESS
)

auth_plugin_options = parser.add_argument_group(title='Authentication plugin options')

# Generated at 2022-06-23 18:41:34.488911
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'foobar' not in choices


# Generated at 2022-06-23 18:41:41.797828
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    def test_contains(name):
        assert name in _AuthTypeLazyChoices()

    test_contains('basic')
    test_contains('digest')
    test_contains('hawk')
    test_contains('ntlm')
    test_contains('oauth1')
    test_contains('bearer')

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=sorted(plugin_manager.get_auth_plugin_mapping().keys()),
    help='''
    The authentication mechanism to be used. If not provided, it is
    auto-detected from --auth value, if possible.
    '''
)


# Generated at 2022-06-23 18:41:44.737055
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    expected = ('Basic', 'Digest')
    assert all(x in _AuthTypeLazyChoices() for x in expected)
    return


# Generated at 2022-06-23 18:41:56.091028
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'kerberos' in _AuthTypeLazyChoices()  # Must raise AttributeError
_AuthTypeLazyChoices.__test__ = False

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism to be used.
    The default authentication depends on the --auth option.

    The default authentication mechanism is "basic".
    Only the subclasses of AuthPlugin need to be specified.
    For example, to perform NTLM authentication use "ntlm".
    The other values are aliases for existing auth types:
    "digest" for DigestAuth, "ntlm" for NTLM.

    '''
)

# Generated at 2022-06-23 18:41:58.755715
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'plugin' in choices
    assert 'unknown' not in choices

# Generated at 2022-06-23 18:42:07.928756
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication plugin to be used.
    Only relevant if --auth is also specified.

    ''',
)


#######################################################################
# Other
#######################################################################

other = parser.add_argument_group(title='Other')
other.add_argument(
    '--timeout', '-t',
    default=5,
    type=float,
    metavar='SECONDS',
    help='''
    Timeout in seconds for the connection attempt.
    A value of 0 disables the timeout.

    ''',
)

# Generated at 2022-06-23 18:42:10.069765
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:19.670857
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=choices,
    help='The authentication mechanism.'
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='Do not perform auth challenge.'
)
auth.add_argument(
    '--ignore-netrc',
    default=False,
    action='store_true',
    help='Do not attempt to read .netrc.'
)

# Generated at 2022-06-23 18:42:30.553770
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'netrc-file',
        'netrc-machine',
        'oauth1',
        'oauth2',
        'multipart',
        'query-string',
    ]

auth_type = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    The authentication implementation.
    One of: {auth_types}

    The default (if --auth is also specified) is "{default}".

    '''.format(
        auth_types=', '.join(sorted(_AuthTypeLazyChoices())),
        default='guess_from_url'
    )
)
auth_type.completer = ChoicesComple

# Generated at 2022-06-23 18:42:43.525422
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication method to use.

    Supported custom auth types (the "--auth-type=" prefix can be omitted):
    {0}

    '''.format('\n'.join(
        '{0}{1}'.format(8 * ' ', type_)
        for type_ in sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ))
)

# Generated at 2022-06-23 18:42:54.416711
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import pytest
    from httpie.plugins.builtin import BasicAuth
    mapping = {'basic': BasicAuth}
    with pytest.raises(Exception):
        assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    'auto' (default): select the auth type by inspecting the given
    credentials. The credentials are inspected in the order specified.

    '''
)

# ``requests.auth`` keyword arguments.
auth.add_argument(
    '--auth-host',
    metavar='HOST',
    help='''
    Hostname to use for HTTP authentication.

    ''',
)

# Generated at 2022-06-23 18:43:06.782592
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iterator = iter(_AuthTypeLazyChoices())
    assert next(iterator) == 'basic'
    assert next(iterator) == 'digest'

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use.

    Defaults to "basic". Supported types include:

        {auth_plugins}

    '''.format(
        auth_plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        ).strip()
    )
)

# Generated at 2022-06-23 18:43:18.801396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, if not otherwise
    specified by the provided credentials.

      - For basic authentication, it is 'basic'.

      - For digest authentication, it is 'digest'.

    ''',
)

auth.add_argument(
    '--auth-verify',
    default=None,
    action='store_const',
    const=True,
    help='''
    This flag is equivalent to --auth-type=basic --verify.
    '''
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-23 18:43:26.601804
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for item in _AuthTypeLazyChoices():
        pass

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '--auth-type=',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Currently supported:

        {auth_types}

    The default auth plugin is HTTP Basic. Other auth types need to be
    explicitly specified.

    '''.format(auth_types=describe_auth_plugins(AUTH_PLUGIN_MAP))
)

# Generated at 2022-06-23 18:43:33.261455
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    # An empty list of plugins
    with patch('httpie.cli.plugin_manager.get_auth_plugin_mapping',
               return_value={}):
        assert list(_AuthTypeLazyChoices()) == []

    # A list of plugins
    with patch('httpie.cli.plugin_manager.get_auth_plugin_mapping',
               return_value={'my_auth': PluginAuth()}):
        assert list(_AuthTypeLazyChoices()) == ['my_auth']


# Generated at 2022-06-23 18:43:43.597281
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(
        plugin_manager.get_auth_plugin_mapping()
    )
# End unit test for method __iter__ of class _AuthTypeLazyChoices

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use.

    {auth_plugin_list}

    '''.format(
        auth_plugin_list='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(
                ', '.join(
                    sorted(
                        plugin_manager.get_auth_plugin_mapping().keys()
                    )
                ), 60)
        )
    ),
)


# Generated at 2022-06-23 18:43:47.059098
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foobar' not in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:52.193812
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    expected = {
        'basic',
        'digest',
        'hawk',
        'aws',
        'aws-s3',
        'aws-sigv4',
        'kerberos',
        'ntlm'
    }
    assert(expected == set(choices))

# Generated at 2022-06-23 18:44:00.104090
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Which authentication method to use.

    The default "auto" tries to infer the method from the --auth option. But it
    can be set to either "basic" or "digest".

    '''
)


# Generated at 2022-06-23 18:44:01.274711
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:12.363823
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()  # noqa: S001
    assert 'bearer' in _AuthTypeLazyChoices()  # noqa: S001
    assert 'digest' in _AuthTypeLazyChoices()  # noqa: S001
    assert 'hawk' in _AuthTypeLazyChoices()  # noqa: S001
    assert 'test-auth' in _AuthTypeLazyChoices()  # noqa: S001
    # We should not be using the _AuthTypeLazyChoices when we are installing
    # the actual plugin.
    temp_plugin_config_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:44:14.639703
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-23 18:44:21.716259
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()

    def mock_get_auth_plugin_mapping(self):
        return {'mock_plugin1234': 'mock_plugin_class1234'}

    with mock.patch.object(plugin_manager, 'get_auth_plugin_mapping', mock_get_auth_plugin_mapping):
        assert 'mock_plugin1234' in choices
        assert 'mock_plugin5678' not in choices


# Generated at 2022-06-23 18:44:23.844128
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) \
        == set(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:44:25.740553
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert set(_AuthTypeLazyChoices()) == set(
        'basic digest digest-ie kerberos'.split())


# Generated at 2022-06-23 18:44:38.668502
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'jwt']


# Generated at 2022-06-23 18:44:50.793458
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method.

    This is useful to force basic authentication, e.g. when accessing a
    URL that sometimes redirects to a different host.

    Use "help" to get a list of the available auth types, but be warned that
    the list is different for every URL, depending on the auth types the
    server supports.

    '''
)

auth_plugin_group = auth.add_argument_group(
    title='Authentication plugin options'
)


# Generated at 2022-06-23 18:45:02.995699
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert iter(choices) == iter(sorted(choices))

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=auth_type_choices,
    help=f'''
    Specify an authentication type.
    By default, the authentication type is guessed based on the
    presence of certain parameters, e.g., --auth, --krb etc.

    Available choices: {', '.join(sorted(auth_type_choices))}

    '''
)


# Generated at 2022-06-23 18:45:15.657614
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'negotiate' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    help=f'''
    Override the automatic auth plugin selection by explicitly specifying
    one of:

    {", ".join(plugin_manager.get_auth_plugin_mapping().keys())}

    The default is '{DEFAULT_AUTH_PLUGIN}'.

    '''
)


# Generated at 2022-06-23 18:45:19.843529
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Unit test for method __iter__ of class _AuthTypeLazyChoices
    """
    assert [elem for elem in _AuthTypeLazyChoices()] == ['basic', 'digest']

# Generated at 2022-06-23 18:45:21.881327
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-23 18:45:30.015845
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
  assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices()
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Inhibit sending the initial authentication challenge.
    Useful for testing broken/missing authentication challenges.

    '''
)
auth.add_argument(
    '--auth-type=basic',
    dest='auth_type',
    action='store_const',
    const='basic',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:45:34.542809
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:45:45.508670
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Plugin is needed to check if basic plugin installed
    from httpie.plugins.auth.basic import BasicAuthPlugin
    assert "basic" in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Supported types include "basic"
    and "digest". Custom types can be defined using plugins (see
    https://github.com/jakubroztocil/httpie/wiki/Plugins).

    ''',
)
auth.add_argument(
    '--auth-type-help',
    action='help',
    help='''
    Print help for the given authentication mechanism and exit.

    '''
)

# Generated at 2022-06-23 18:45:58.360473
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_auth_type_lazy_choices,
    default=None,
    type=AuthCredentials.from_auth_type,
    help=f'''
    The authentication type to be used.
    This is currently only relevant for plugins.

    Available:
        {', '.join(_auth_type_lazy_choices)}

    ''',
)


# ``requests.request`` keyword argument.

# Generated at 2022-06-23 18:46:10.464491
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Tests if constructor of __AuthTypeLazyChoices works and returns the correct choices."""
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__("basic")
    assert choices.__contains__("digest")
    assert sorted(choices.__iter__()) == ["basic", "digest"]

auth.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication type. For example, the default
    "basic" auth will be forced to use Digest auth (if available):

        http --auth myuser:mypassword --auth-type=digest example.org

    By default, the first supported, preferred auth type is picked.

    '''
)

auth.add

# Generated at 2022-06-23 18:46:19.789057
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-23 18:46:33.149060
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # TODO: Make the assertion more meaningful.
    assert not bool(_AuthTypeLazyChoices())

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_auth_type_choices,
    help='''
    The type of the provided credentials. The default (None) is to
    try all available types.

    The following auth types are available:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(_auth_type_choices), 60)
        ).strip()
    )
)


# Generated at 2022-06-23 18:46:38.291722
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_choices = _AuthTypeLazyChoices()
        assert 'basic' in auth_type_choices
        assert 'digest' in auth_type_choices
        assert list(auth_type_choices) == ['basic', 'digest']
    except Exception:
        print_traceback(file=sys.stderr)
        sys.exit(1)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin. Default: basic.
    \n'''
)


# Generated at 2022-06-23 18:46:41.019778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-23 18:46:45.058070
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk', 'jwt', 'netrc', 'oauth1', 'ntlm']


# Generated at 2022-06-23 18:46:56.039546
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='Authentication type (default: auto).',
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-verify',
    default=True,
    action='store_true',
    help='Verify the server certificate for HTTPS requests.',
)

# Generated at 2022-06-23 18:46:58.055336
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:47:08.598889
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices

auth_type = auth.add_mutually_exclusive_group(required=False)

auth_type.add_argument(
    '--auth-type', '-A',
    default=DEFAULT_AUTH_TYPE,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to use, if --auth is provided.
    One of:

        {auth_type_choices}

    '''.format(
        auth_type_choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)


# Generated at 2022-06-23 18:47:18.127127
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    # Unit test for method __contains__ of class _AuthTypeLazyChoices
    # __contains__(self, item)
    # --
    # Return True if item is in the container.
    # (to run: python -m unittest httpie.cli.argtypes.test__AuthTypeLazyChoices___contains__)
    # Expected: True, True, False
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'not_exist' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:47:23.061117
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()