

# Generated at 2022-06-23 18:37:35.536953
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Supported types:

        {plugin_list}

    '''.format(
        plugin_list='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-23 18:37:44.900571
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == ['basic', 'digest']


# Generated at 2022-06-23 18:37:47.995752
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    :return:
    """
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:37:57.775181
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
   
    assert len(list(_AuthTypeLazyChoices())) == 2



AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    help=f'''
    Specify an authentication handler.

    To see the list of available auth handlers and their description,
    use: http --auth-type=help <URL>.

    Note: The following auth handlers are builtin, and don't need
    to be specified explicitly:

        {', '.join(AUTH_PLUGIN_MAP.keys())}

    ''',
    choices=AUTH_TYPE_CHOICES
)


# Generated at 2022-06-23 18:37:59.907938
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping()) == list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:38:10.878927
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an authentication plugin.

    Available plugins: {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}.

    '''
)

auth.add_argument(
    '--auth-send-empty-password',
    action='store_true',
    default=False,
    help='''
    By default, an empty password is not sent. Check your auth handler
    documentation to see if it supports credentials without a password.
    '''
)

################################

# Generated at 2022-06-23 18:38:21.785041
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


authentication_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:38:33.183167
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(
        _AuthTypeLazyChoices()
    ) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


# Generated at 2022-06-23 18:38:45.667062
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    '''
    Method __iter__ of class _AuthTypeLazyChoices returns sorted list of
    available auth types. It also works if at least one plugin is loaded.
    '''
    with mock.patch('httpie.plugins.manager._load_plugins',
                    return_value=[]):
        lazy_choices = _AuthTypeLazyChoices()
        assert list(lazy_choices) == ['digest', 'jwt', 'negotiate',
                                      'oauth1', 'signature' ]

    with mock.patch('httpie.plugins.manager._load_plugins',
                    return_value=[_test_auth_plugin_]):
        lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:38:47.185152
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    print(_AuthTypeLazyChoices.__contains__('basic'))

# Generated at 2022-06-23 18:38:50.272684
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:01.265348
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Needs to be a function to avoid NameError when testing the arguments
    # parser in plugin_load_checker.
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.

    If the plugin is not built-in, it needs to be installed via
    `python -m pip install httpie-<name>-auth`.

    '''.strip()
)

# Generated at 2022-06-23 18:39:03.411009
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:39:04.357679
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass

# Generated at 2022-06-23 18:39:15.809753
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin_a' in _AuthTypeLazyChoices()
    assert 'plugin_b' in _AuthTypeLazyChoices()
    assert 'plugin_c' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'plugin_a',
        'plugin_b',
        'plugin_c',
    ]

auth_plugin = parser.add_argument_group(title='Authentication plugin')

# Generated at 2022-06-23 18:39:19.190084
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'krb_negotiate', 'krb_spnego']

# Generated at 2022-06-23 18:39:24.160447
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an HTTPie authentication plugin.
    See https://httpie.org/plugins#authentication
    for more information.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=None,
    help='''
    Do not send an initial request to challenge the server for
    authentication (the default is to send the initial request).

    '''
)

#######################################################################
# Data options
#######################################################################


# Generated at 2022-06-23 18:39:32.766542
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(sorted(iter(_AuthTypeLazyChoices()))) == list(sorted(_AuthTypeLazyChoices()))


# Generated at 2022-06-23 18:39:45.282158
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert plugin_manager.get_auth_plugin_mapping().keys() == _AuthTypeLazyChoices()

AUTH_TYPES = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:58.430287
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    dest='auth_plugin',
    help='''
    Explicitly specify a supported HTTP authentication mechanism.

    The following mechanisms are supported:

        {auth_plugins}

    '''.format(
        auth_plugins='\n'.join(
            (4 * ' ') + plugin for plugin in _AuthTypeLazyChoices()
        )
    )
)
auth_type.add_argument(
    '--no-auth-type',
    dest='auth_plugin',
    action='store_const',
    const=None,
    help='''
    Disable any explicitly specified HTTP authentication mechanism.

    '''
)



# Generated at 2022-06-23 18:40:03.101684
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


_auth_type_validator = AuthPluginValidator(
    'Unsupported auth type %s. Please use one of: %s.',
    valid_values=_AuthTypeLazyChoices(),
)
_auth_kwargs_validator = AuthKwargsValidator()



# Generated at 2022-06-23 18:40:04.490982
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'jwt' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:15.556477
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' not in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. TYPE can be 'basic' or 'digest'.

    ''',
)
auth.add_argument(
    '--auth-digest-hmac',
    default='auto',
    metavar='ALG',
    choices=['auto', 'MD5', 'SHA'],
    help='''
    Digest auth message integrity algorithm. ALG can be 'MD5' or 'SHA'.

    ''',
)
#######################################################################
# Ignore invalid and/or insecure SSL certificates


# Generated at 2022-06-23 18:40:25.692257
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force usage of a specific authentication type.
    Default is to automatically detect the type.

    The following types are available:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-23 18:40:32.834313
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

_AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=_AUTH_TYPE_CHOICES,
    default=None,
    help=f'''
    The authentication mechanism.

    The default is "basic" unless the --auth option is provided, in
    which case it's set to the first mechanism supported by the server
    that's also supported by HTTPie.

    Available mechanisms are:
        {_AUTH_TYPE_CHOICES}
    ''',
)

#######################################################################
# Input
####################################################################

# Generated at 2022-06-23 18:40:41.962785
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    c=_AuthTypeLazyChoices()
    assert list(c) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices()
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Prevent automatic handling of 401 responses.

    ''',
)

#######################################################################
# Conditions
#######################################################################

conditions = parser.add_argument_group(title='Conditional requests')

# Generated at 2022-06-23 18:40:51.198945
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
           sorted(_AuthTypeLazyChoices())  # noqa

_auth_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:40:56.461931
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.constants import BASIC_AUTH

    with mock.patch.dict(plugin_manager.get_auth_plugin_mapping(), {
        BASIC_AUTH: mock.Mock()
    }):
        assert [BASIC_AUTH] == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type', '-t',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=(
        'The auth mechanism. The default is "basic", which '
        'corresponds to HTTP Basic Auth. Other valid values are '
        'implemented by plugins.'
    )
)


# Generated at 2022-06-23 18:41:07.204517
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    for item in [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'negotiate',
    ]:
        assert item in choices


# Generated at 2022-06-23 18:41:17.544652
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    empty_argparser = argparse.ArgumentParser()
    empty_argparser.add_argument(
        '--auth-type', '--auth-type',
        dest='auth_type',
        metavar='TYPE',
        choices=_AuthTypeLazyChoices()
    )
    args = empty_argparser.parse_args(args=[])
    assert args.auth_type is None

    some_argparser = argparse.ArgumentParser()
    some_argparser.add_argument(
        '--auth-type', '--auth-type',
        dest='auth_type',
        metavar='TYPE',
        choices=_AuthTypeLazyChoices()
    )
    args = some_argparser.parse_args(args=['--auth-type', 'digest'])
    assert args.auth_type

# Generated at 2022-06-23 18:41:29.381874
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test for method __iter__ of class _AuthTypeLazyChoices
    """
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import AuthPlugin
    plugin_manager.get_auth_plugin_mapping()['builtin'] = AuthPlugin
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for choice in auth_type_lazy_choices:
        assert choice == 'builtin'
    plugin_manager.get_auth_plugin_mapping()['builtin'] = None


# Generated at 2022-06-23 18:41:30.450137
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:41:42.451170
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom authentication plugin. The plugin name may be fully
    qualified, such as: "httpie_digest.DigestAuthPlugin", or it may be
    unqualified, such as: "digest".

    If unqualified, the "httpie_" plugin namespace prefix is assumed.

    See https://httpie.org/docs#plugins for more info.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeout = parser.add_argument_group

# Generated at 2022-06-23 18:41:50.971161
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_mapping = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_mapping
    assert 'digest' in auth_type_mapping
    assert 'jwt' not in auth_type_mapping
    assert sorted(auth_type_mapping) == ['basic', 'digest', 'ntlm']



# Generated at 2022-06-23 18:41:54.176789
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:41:55.561875
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices



# Generated at 2022-06-23 18:42:05.185849
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []
    plugin_manager.get_auth_plugin_mapping()['test'] = object()
    assert list(_AuthTypeLazyChoices()) == ['test']
test__AuthTypeLazyChoices___iter__()  # Not production.
_AUTH_TYPES_LAZY_CHOICES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AUTH_TYPES_LAZY_CHOICES,
    metavar='TYPE',
    help='''
    Default: "basic".

    Use this option to select an authentication plugin.

    This option is ignored if --auth/--auth-type is specified.

    Use --auth-type=help to list all available plugins.

    '''
)



# Generated at 2022-06-23 18:42:16.787222
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """HTTPie: Auth plugin: Lazy and dynamic choices."""

    from tests import httpie

    # Monkey patch a fake plugin here.
    def fake_plugin_init():
        pass

    import sys
    sys.modules[__name__].fake_plugin_init = fake_plugin_init

    args = [
        # Take care not to add this file to the test package, or the plugin
        # discovery may pick it up and create a fake plugin out of it.
        str(httpie / 'tests/data/fake-auth-plugin.py')
    ]
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_external_plugins(args)

    # We won't test the exact output.
    # It is enough to prove that the plugin was loaded, by making sure that
    # its name is part of the choices.

# Generated at 2022-06-23 18:42:28.447945
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'http' in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism.
    HTTPie tries to detect it from the URL and from the provided data.

    '''
)
auth_type.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Prevent HTTPie from sending preliminary HTTP OPTIONS
    request to determine the authentication type.

    ''',
)

# Generated at 2022-06-23 18:42:40.968472
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert sorted(plugin_mapping.keys()) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='NAME',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The Auth plugin to use. It defaults to "basic" if no --auth option is
    specified, otherwise it defaults to "auto".

    '''
)

# Generated at 2022-06-23 18:42:48.704881
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(_AuthTypeLazyChoices())
    assert choices, 'No auth plugins found. {}'.format(
        plugin_manager.get_auth_plugin_mapping()
    )
    for choice in choices:
        assert choice in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Auth type to use. Valid values depend on the installed plugins.
    Run `http --auth-type=help` to see a list of supported plugins.

    Example values: "basic", "digest", "jwt", etc.

    ''',
)


#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-23 18:42:58.709769
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for auth_type in _AuthTypeLazyChoices():
        assert auth_type in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    metavar='type',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    help=f'''
    The authentication mechanism (plugin) used.
    Plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default is {DEFAULT_AUTH_PLUGIN_NAME}.

    Note that when using an auth plugin, the --auth option is used
    to specify the credentials, not the username and password
    separately.
    '''
).completer = AuthTypeCompleter


# Generated at 2022-06-23 18:43:01.621617
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:12.647033
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help="""
    Specify the authentication mechanism to be used. By default, HTTPie will
    try to detect the authentication type based on the provided credentials.
    The available options are:

    * ``basic``: HTTP Basic Auth
    * ``digest``: HTTP Digest Auth
    * ``auto``: HTTP Digest first, Basic second (default)

    Or a plugin name. Use ``--debug`` for a list of available plugins.
    """,
)


# Generated at 2022-06-23 18:43:13.634583
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:24.336002
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = tuple(_AuthTypeLazyChoices())
    assert choices == plugin_manager.get_auth_plugin_mapping().keys()
    assert sorted(list(choices)) == list(choices)

auth.add_argument(
    '--auth-type', '-t',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. It can be One of:

    {auth_plugin_help}

    The default is {DEFAULT_AUTH_PLUGIN}.

    '''
)

# Basic and Digest auth types

# Generated at 2022-06-23 18:43:35.083618
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(_AuthTypeLazyChoices().__iter__()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    type=str.lower,
    default=AUTH_PLUGIN_MAP['basic'],
    choices=_AuthTypeLazyChoices(),
    help='Auth plugin name. Default: basic'
)

#######################################################################
# Input options
#######################################################################

input_options = parser.add_argument_group(title='Input Options')

input_options.add_argument(
    '--ignore-stdin',
    action='store_true',
    help='Do not read stdin.'
)


# Generated at 2022-06-23 18:43:45.156405
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    By default, HTTPie tries to guess the auth type (Basic, Digest),
    but it can also be manually specified.

    WARNING: specifying auth type is a hack that might not work with all servers.

    ''',
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-23 18:43:47.296853
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-23 18:43:48.766177
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:43:58.043445
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    '''_AuthTypeLazyChoices() = <_AuthTypeLazyChoices object>'''
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices == auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism. By default (i.e., when this option is not
    set), HTTPie tries to detect the scheme based on the --auth option
    value. This auto-detection can be overridden.

    Only the following types are available by default:

        basic
        digest

    You can enable additional types by installing plugins.

    '''
)

# Generated at 2022-06-23 18:43:59.538324
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:11.286924
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices and 'oauth2' in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type to be used. Available types can be listed via
    "http --debug" or "http --help-auth".

    The default is inferred from the --auth option value (if present).
    If the default type is not suitable, you can specify it explicitly.

    '''
)

#######################################################################
# CA Bundle
#######################################################################

# http://

# Generated at 2022-06-23 18:44:13.147961
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(iter(_AuthTypeLazyChoices())) == set(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-23 18:44:24.028394
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(_AuthTypeLazyChoices())
    assert iter(it) == it
    # Just make sure that it's iterable:
    for auth_type in it:
        pass

auth_type = auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    '''
)

auth.add_argument('--auth-no-challenge',
    action='store_true',
    dest='auth_no_challenge',
    default=False,
    help='''
    Do not obtain the challenge from the server to perform the authentication.

    '''
)

#######################################################################
# Redirects
#######################################################################
redirects = parser.add_argument

# Generated at 2022-06-23 18:44:37.635226
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The HTTP authentication mechanism. By default, HTTPie will attempt to figure
    out the right authentication method to use.
    Supplying the `--auth-type` parameter will prevent HTTPie from doing
    so.

    You can set this option to `digest` to use Digest auth, or to `auto` to
    let HTTPie guess the auth type.

    To define a custom auth mechanism, use a custom auth plugin (see ``--help`` for
    more details).

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl

# Generated at 2022-06-23 18:44:49.775868
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices() == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify an auth plugin.

    Available plugins: {', '.join(_AuthTypeLazyChoices())}.

    '''
)

# Generated at 2022-06-23 18:44:52.310662
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:58.931529
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    def _test_choice(choice):
        assert choice in _AuthTypeLazyChoices()

    _test_choice('basic')
    _test_choice('digest')
    _test_choice('multifactor')
    _test_choice('aws-sigv4')
    #  It's the default, so it must exist
    _test_choice('auto')


# Generated at 2022-06-23 18:45:00.546034
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:02.008603
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AUTH_PLUGIN_NAME in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:04.727427
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.helpers import is_iterable_and_not_string
    assert is_iterable_and_not_string(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:45:18.071786
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # _AuthTypeLazyChoices().__iter__() returns generator
    iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The plugin to use for sending credentials. By default, HTTPie
    performs an interactive exchange with the server to obtain
    a token, which is then used for auth.

    The value can be any of:

        {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:45:20.782686
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:45:29.764370
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    mock_pm = mock.MagicMock(spec=PluginManager)
    mock_pm.get_auth_plugin_mapping.return_value = {'foo': 'bar', 'spam': 'eggs'}
    with mock.patch('httpie.cli.plugin_manager', mock_pm):
        choices = list(_AuthTypeLazyChoices())
    assert choices == ['foo', 'spam']


auth.add_argument(
    '--auth-type',
    action='append',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth plugin to be used.

    Available plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-23 18:45:40.954416
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    action=SetHeader,
    metavar='TYPE',
    help='''
    The auth mechanism to be used.
    The available options are:

    {auth_type_help}

    '''.format(
        auth_type_help='\n'.join(
            '{0} {1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    ),
    choices=_AuthTypeLazyChoices(),
)

# Generated at 2022-06-23 18:45:45.394759
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:45:47.603976
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

# Generated at 2022-06-23 18:45:59.695129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    assert 'awssigv4' in auth_type_lazy_choices
    assert 'oauthenticate' in auth_type_lazy_choices
    assert 'jwt' in auth_type_lazy_choices
    assert 'authbasic' in auth_type_lazy_choices
    assert 'authdigest' in auth_type_lazy_choices
    assert 'baseauth' in auth_type_lazy_choices

# Generated at 2022-06-23 18:46:11.070871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used:

        auto
        basic
        digest
        {' '.join(str(type_) for type_ in plugin_manager.get_auth_plugin_mapping().keys())}

    The ``--auth-type=auto`` is the default when --auth is used and
    it will attempt to guess the type (Basic by default).

    ''',
)

# Generated at 2022-06-23 18:46:17.347989
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    expected_value = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert list(_AuthTypeLazyChoices()) == expected_value

auth.add_argument(
    '--auth-type',
    type=parse_auth_type,
    default=parse_auth_type(),
    help='''
    The authentication mechanism to be used.
    Default is "auto", which means it tries to detect the scheme.

    ''',
    choices=_AuthTypeLazyChoices()
)



# Generated at 2022-06-23 18:46:30.720716
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    By default, HTTPie tries to detect the type by examining the provided
    credentials and the server's response.

    '''
)

#######################################################################
# HTTP and HTTPS proxy
#######################################################################
proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-23 18:46:42.313099
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import inspect
    from httpie.core import main
    from httpie.core import plugin_manager
    plugin_manager.load_installed_plugins()
    auth_type_choices = _AuthTypeLazyChoices()
    if inspect.ismethod(auth_type_choices.__contains__):
        assert 'basic' in auth_type_choices
        assert 'digest' in auth_type_choices
        assert 'aws' in auth_type_choices
    else:
        for auth_type in ['basic', 'digest', 'aws']:
            assert not callable(getattr(auth_type_choices, '__contains__')(auth_type))
            assert callable(getattr(auth_type_choices, '__contains__')('example.com'))


# Generated at 2022-06-23 18:46:53.971121
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(AuthCredentialsValidator._AuthTypeLazyChoices()) == sorted(['bearer', 'digest'])

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Tell HTTPie which authentication method to use. In most cases, HTTPie
    figures it out by itself.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL', description='''
    {ok_note}

    The SSL verification options allow you to control the certificates
    that HTTPie verifies when using HTTPS.
    '''.format(ok_note=ssl_config.OK_NOTE)
)
ssl.add_argument

# Generated at 2022-06-23 18:47:05.289997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())
auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '-t',
    metavar='',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin (default: {default}).

    The following authentication plugins are available:

        {auth_types}

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)



# Generated at 2022-06-23 18:47:11.007104
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices"""
    test_choices = _AuthTypeLazyChoices()

    for choice in plugin_manager.get_auth_plugin_mapping():
        assert choice in test_choices

# Generated at 2022-06-23 18:47:17.623630
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choice_object = _AuthTypeLazyChoices()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    for auth_type, auth_handler_class in auth_plugin_mapping.items():
        assert auth_type in lazy_choice_object
        auth_handler = auth_handler_class()
        assert auth_handler.auth_type in lazy_choice_object

# Generated at 2022-06-23 18:47:29.266508
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # We have to create the instance in order for the plugins to be loaded.
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'bearer' in auth_type_choices
    assert 'digest' in auth_type_choices


auth_type = auth.add_mutually_exclusive_group(required=False)