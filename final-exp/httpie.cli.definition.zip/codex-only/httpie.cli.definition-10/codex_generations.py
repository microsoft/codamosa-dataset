

# Generated at 2022-06-23 18:37:35.548480
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert set(choices) == set(plugin_manager.get_auth_plugin_mapping().keys())
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert iter(choices) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))




# Generated at 2022-06-23 18:37:41.575398
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    if 'basic' not in choices:
        raise AssertionError('Test 1: Expected "basic" in choices.')
    if 'digest' not in choices:
        raise AssertionError('Test 2: Expected "digest" in choices.')
    if 'does-not-exist' in choices:
        raise AssertionError('Test 3: Expected "does-not-exist" not in choices.')


# Generated at 2022-06-23 18:37:52.410566
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.

    If not specified, HTTPie attempts to infer the auth type from the provided
    credentials.

    '''
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Specify an endpoint from which to fetch auth credentials.

    If not specified, HTTPie attempts to infer the auth endpoint from the
    provided credentials.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:37:54.503251
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'jwt' in choices


# Generated at 2022-06-23 18:37:58.277708
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    assert AUTH_TYPES_DEFAULT[0] in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

    # Unit test for method __iter__ of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:38:03.818428
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    Test if iterating over the auth types is same as iterating over plugin mapping
    """
    auth_types = _AuthTypeLazyChoices()
    plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert(len(auth_types) == len(plugin_mapping))
    # Use sets to check that all items are contained
    assert(set(auth_types) == set(plugin_mapping))

# Generated at 2022-06-23 18:38:05.823130
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic')



# Generated at 2022-06-23 18:38:08.260899
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:38:13.401381
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Override the default authentication plugin.

    {legacy_plugin_warning}

    '''
)

# Generated at 2022-06-23 18:38:21.824809
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # hack for lazy choices for plugins
    # http://bugs.python.org/issue23057
    class _AuthTypeChoices(argparse.Action):

        def __init__(self, **kwargs):
            kwargs['choices'] = _AuthTypeLazyChoices()
            super().__init__(**kwargs)

    auth.add_argument(
        '--auth-type',
        action=_AuthTypeChoices,
        default=None,
        metavar='{' + ','.join(_AuthTypeLazyChoices()) + '}',
        help='''
        Plugin used to perform authentication.

        '''
    )

# Generated at 2022-06-23 18:38:33.221094
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Currently supported values: {0}

    '''.format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

# Generated at 2022-06-23 18:38:45.724271
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # There are four hardcoded AUTH_PLUGIN_MODULE_NAMES.
    # And tests create two plugins in tests/data/plugins/auth.
    # Therefore, this test ensures that 7 'choices' are present.
    assert len(list(_AuthTypeLazyChoices())) == 7

auth_type = auth.add_argument(
   '--auth-type',
    dest='auth_plugin_name',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism which HTTPie uses to authenticate
    against the server.
    You can install additional plugins with ` http --debug plugins install
    '.
    '''
)

#######################################################################
# Follow
#######################################################################

follow = parser.add_argument_group(title='Redirects')
follow.add_argument

# Generated at 2022-06-23 18:38:48.317525
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

# Generated at 2022-06-23 18:38:53.535236
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''
    >>> auth_type_lazy_choices = _AuthTypeLazyChoices()
    >>> 'basic' in auth_type_lazy_choices
    True
    >>> 'digest' in auth_type_lazy_choices
    True
    >>> 'bearer' in auth_type_lazy_choices
    False
    >>> 'myfakeauthtype' in auth_type_lazy_choices
    False
    '''
    pass


# Generated at 2022-06-23 18:38:55.964164
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'foo' not in choices


# Generated at 2022-06-23 18:39:06.892237
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Implicitly tested:
    # - that there are no remaining __doc__ references
    # - todo: test for each auth type that parsing works in `plugin_manager.load_plugins`
    # pylint: disable=protected-access
    items = plugin_manager.get_auth_plugin_mapping().keys()

    assert 'basic' in items
    assert 'digest' in items
    assert 'hawk' in items
    assert 'ntlm' in items
    assert 'aws4-hmac-sha256' in items


# Generated at 2022-06-23 18:39:08.585354
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')

# Generated at 2022-06-23 18:39:18.132572
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:20.254123
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']  # noqa

# Generated at 2022-06-23 18:39:21.363628
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:26.288091
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.make_plugin_choices_callback(
        'auth',
        'auth plugin'
    ),
    help=f'''
    The authentication type to use.

    Valid choices: {list(_AuthTypeLazyChoices())}

    Type "{DEFAULT_AUTH_TYPE}" uses Basic Authentication.
    Type "{DEFAULT_AUTH_TYPE_V2}" uses Basic Authentication with JWT verification.
    Type "{DEFAULT_AUTH_TYPE_V3}" uses Basic Authentication with API key verification.

    ''',
)

# Generated at 2022-06-23 18:39:35.261528
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use for requests.
    The default is based on the --auth option value.

    '''
)


# Generated at 2022-06-23 18:39:46.882902
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'awsv4',
        'basic',
        'digest',
        'jwt',
        'oauth1',
        'ntlm'
    ]


# List of resolved ``requests.request`` keyword arguments.
# These will be passed iff ``authentication`` is not specified.
authentication = parser.add_argument_group(title='Authentication')

# Generated at 2022-06-23 18:39:59.733974
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iterator = _AuthTypeLazyChoices()
    iterated = []
    for i in iterator:
        iterated.append(i)
    return iterated
auth_type_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:02.488397
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-23 18:40:14.109781
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. If not set, an appropriate one is
    chosen automatically based on the provided credentials.

    '''
)

#######################################################################
# Ignored options
#######################################################################

ignored = parser.add_argument_group(title='Ignored options')
ignored.add_argument(
    '--http1.1',
    action='store_true',
    default=False,
    dest='http1_1',
    help=argparse.SUPPRESS
)


# Generated at 2022-06-23 18:40:24.964005
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices
    assert 'basic' in choices

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=auth_type_choices,
    default=None,
    type=str,
    help='''
    Specify an authentication handler plugin.
    If not specified, it is autodetected based on --auth credentials.

    '''
)


# Generated at 2022-06-23 18:40:37.178654
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert len(list(auth_types)) > 0

auth.add_argument(
    '--auth-type',
    default='auto',
    help='''
    The name of the auth plugin to use. By default, HTTPie looks into each
    HTTP request made whether it was successful, and if it wasn't, it tries all
    available plugins, with Basic authentication tried first, then digest, and
    finally netrc. The "auto" option is equivalent to this default behaviour.

    Plugins do not need to be explicitly activated when using this option.

    '''
).completer = ChoicesCompleter(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:40:40.401213
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = list(_AuthTypeLazyChoices())
    assert choices == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:40:50.589397
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(iter(_AuthTypeLazyChoices())) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default='auto',
    choices=_auth_type_lazy_choices,
    help='''
    Force Basic, Digest or Digest with IIS-specific quirks. If auto
    (default), HTTPie will try to detect the type automatically.

    ''',
)


# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:41:03.081391
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the authentication plugin to use.
    Available plugins: {', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=None,
    action='store_true',
    help='''
    Do not send an authorization header when the server responds with a
    (401) HTTPBasicAuth or HTTPDigestAuth challenge. This way, you can
    still use the --auth option to set up a custom request headers.

    '''
)


# Generated at 2022-06-23 18:41:05.147488
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:08.141279
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert len(list(choices)) == len(choices)

# Generated at 2022-06-23 18:41:10.442041
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'auth-signer', 'basic', 'digest'
    ]

# Generated at 2022-06-23 18:41:13.673375
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom_auth' in choices
    assert 'missing_plugin' not in choices

# Generated at 2022-06-23 18:41:15.548395
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():  # noqa
    assert tuple(_AuthTypeLazyChoices()) == tuple(sorted(plugin_manager.get_auth_plugin_mapping().keys()))



# Generated at 2022-06-23 18:41:26.419393
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
    assert list(_AuthTypeLazyChoices()) == sorted(list(plugin_manager.get_auth_plugin_mapping()))



auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Default: {default}.

    The name is usually the plugin name without the "AuthPlugin"
    suffix and in lower case.

    Available plugins:
    {plugins}

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        plugins='\n'.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-23 18:41:31.961551
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'any' in _AuthTypeLazyChoices()
    assert 'noauth' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'no such thing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:43.531056
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert BasicAuthPlugin.name in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. 'basic' is the default.
    You can use this option to set it to 'digest' or any other mechanism supported
    by the installed plugins.

    '''
)
auth.add_argument(
    '--auth-scheme',
    default=DEFAULT_AUTH_SCHEME,
    choices=['basic', 'digest'],
    help='''
    The HTTP authorization scheme. 'basic' is the default.
    Set it to 'digest' for entering a digest password.

    '''
)

# Generated at 2022-06-23 18:41:55.025528
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    list(auth_type_choices)

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified strategy for doing authentication. Available strategies:

    {plugin_manager.get_auth_plugin_help()}

    For example, to use the auth plugin for "FooAuth":

        --auth-type=foo

    The plugin is expected to be already installed and entrypoint named
    "httpie_foo_auth".

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:42:04.739229
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices,
    default='basic',
    help='''
    Which method to use for authentication. This can be a plugin name, or
    one of the built-in methods, 'basic' and 'digest'.

    '''
)

# Generated at 2022-06-23 18:42:09.852014
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    choices = list(choices)
    assert isinstance(choices, list)

    if choices:
        assert choices.__contains__(choices[0])


# Generated at 2022-06-23 18:42:19.542088
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'missing' not in auth_type_lazy_choices
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism.
    This can be one of the following:
    basic, digest, aws, hawk.

    '''
)

# Generated at 2022-06-23 18:42:30.421705
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(_AuthTypeLazyChoices())

# ``requests.auth.HTTPBasicAuth`` or ``requests_ntlm.HttpNtlmAuth``
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Implementations: basic, digest, oauth1.
    Chooses the auth mechanism. Default to "basic" if --auth provided.

    '''
)

#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:42:43.394154
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'basic'] # pylint: disable=no-member


# Generated at 2022-06-23 18:42:54.311395
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass

auth.add_argument(
    '--auth-type',
    metavar='{auth_plugin_names}',
    type=plugin_manager.get_auth_plugin_from_name,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    By default, the plugin is guessed from --auth credentials.

    '''
)

# XXX: Deprecated as of v0.9.9.
auth.add_argument(
    '--digest',
    action='store_true',
    dest='auth_digest',
    help='''
    Use HTTP Digest Authentication.
    (Deprecated, use the --auth-type=digest flag instead.)

    ''',
)
# XXX: Deprecated as of v0.9.9.
auth.add_

# Generated at 2022-06-23 18:43:01.890440
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'basic' in lazy_choices
    assert len(list(lazy_choices)) >= 2

auth.add_argument(
    '--auth-type',
    default='auto',
    help='''
    The authentication mechanism to be used. The default is "auto",
    which tries to determine the auth mechanism based on the HTTP
    URL prefix. Other supported values are:

        {auth_types}

    '''.format(
        auth_types=wrap(
            text_type(', '.join(sorted(_AuthTypeLazyChoices()))),
            initial_indent=8,
            subsequent_indent=8
        )
    ),
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-23 18:43:05.410359
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _iter = _AuthTypeLazyChoices().__iter__()
    assert isinstance(_iter, Iterator)
    assert list(_iter) == ['basic']


# Generated at 2022-06-23 18:43:15.816982
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['basic', 'digest', 'jwt']


auth.add_argument(
    '--auth-type',
    metavar='authentication_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. The value must be one of: {0}

    You can use this option to force Basic authentication even when the
    server accepts several authentication types, but only some of them are
    insecure.

    '''.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

# Generated at 2022-06-23 18:43:16.975752
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    return


# Generated at 2022-06-23 18:43:25.939088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default=None,
    help='''
    Specify the authentication mechanism.

    The ``netrc`` auth type is not supported.
    Use ``file`` type to load the credentials from ``~/.netrc``.

    '''
)



# Generated at 2022-06-23 18:43:36.146500
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # This test is needed for plugin testing
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Which authentication method to use. By default, the appropriate one is
    guessed. This option currently supports the following values:

        {choices_list}

    '''
)
auth.add_argument(
    '--auth-endpoint',
    help='''
    The endpoint to authenticate at. It is only used for some auth
    plugin types. Defaults to the URL of the request being authenticated.

    ''',
)

# Generated at 2022-06-23 18:43:46.456276
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:43:52.749415
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import httpie.plugins
    with MockRawInput(''):
        assert 'basic' in _AuthTypeLazyChoices()
    with MockRawInput(''):
        assert 'bearer' not in _AuthTypeLazyChoices()
    try:
        httpie.plugins.load_plugin('bearer-auth')
        with MockRawInput(''):
            assert 'bearer' in _AuthTypeLazyChoices()
    except ImportError:
        pass

# Generated at 2022-06-23 18:44:00.448506
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(('Basic', 'Digest')) == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism.

    ''',
)
auth.add_argument(
    '--auth-nonce',
    default=None,
    help=argparse.SUPPRESS
)
auth.add_argument(
    '--auth-opaque',
    default=None,
    help=argparse.SUPPRESS
)
auth.add_argument(
    '--auth-nc',
    default=None,
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:44:11.724300
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    pass
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTHHANDLER,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication mechanism.

    Available types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    Example:

        $ http --auth=user --auth-type=digest GET httpbin.org/basic-auth/user/passwd

    '''
)


# Generated at 2022-06-23 18:44:13.008177
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-23 18:44:23.894023
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'myplugin' not in _AuthTypeLazyChoices()
    assert 'myplugin' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The "auto", default, selects the best plugin for the given URL.

    ''',
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='''
    Show help for available auth plugins.

    '''
)

#######################################################################
#
#######################################################################


# Generated at 2022-06-23 18:44:26.468154
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:38.798603
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    if 'basic' not in choices:
        raise AssertionError()
    if 'digest' not in choices:
        raise AssertionError()
    if 'doesnotexist' in choices:
        raise AssertionError()



# Generated at 2022-06-23 18:44:50.825671
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help="Specify an auth plugin to use, such as 'basic'. If not specified, HTTPie will try to guess the auth type based on the request."
)

# Generated at 2022-06-23 18:44:53.364770
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'bearer' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices



# Generated at 2022-06-23 18:45:04.597995
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Digest' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default=None,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of HTTP auth to use. Can be one of:

        {', '.join(_AuthTypeLazyChoices())}

    If not specified, the auth type will be automatically determined
    based on the supplied credentials.

    ''',
)


#######################################################################
# Parsers
#######################################################################

parser_type_choice = ','.join(sorted(parser_plugins))

parsers = parser.add_mutually_exclusive_group(required=False)
p

# Generated at 2022-06-23 18:45:17.904553
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices
    assert sorted(choices) == sorted(['basic', 'digest'])
    assert sorted(list(choices)) == sorted(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH,
    choices=_AuthTypeLazyChoices(),
    help='''
    Default: {default}.

    '''.format(default=DEFAULT_AUTH)
)


# Generated at 2022-06-23 18:45:23.387397
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types_iter = iter(_AuthTypeLazyChoices())
    auth_types = list(auth_types_iter)
    expected_auth_types = ['digest', 'hmac', 'jwt', 'netrc', 'oauth1', 'basic']
    assert auth_types == expected_auth_types


# Generated at 2022-06-23 18:45:31.026684
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert BASIC_AUTH in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an HTTP auth type to be used, for example "digest".
    Defaults to "basic".

    '''
)

auth.add_argument(
    '--auth-type-force',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force using the specified auth type. This is useful when the server
    requires NTLM authentication and the server-specified sequence of
    challenges doesn't work with the --auth option.

    Currently, HTTPie supports only Basic and Digest auth.

    '''
)
auth.add_

# Generated at 2022-06-23 18:45:43.124704
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie import auth
    from httpie.auth import kwargs as auth_kwargs
    from httpie.auth import plugin_manager

    auth_kwargs.register_auth_plugin('AUTH', lambda *args, **kwargs: None)

    def setUp():
        plugin_manager.clear_auth_plugins()

    def tearDown():
        plugin_manager.clear_auth_plugins()

    auth_kwargs.AuthTypeLazyChoices()  # Shouldn't raise exception

    # Make sure that AuthTypeLazyChoices is lazy
    setUp()
    assert 'AUTH' not in auth.AuthTypeLazyChoices()
    auth_kwargs.register_auth_plugin('AUTH', lambda *args, **kwargs: None)
    assert 'AUTH' in auth.AuthTypeLazyChoices()
    tear

# Generated at 2022-06-23 18:45:56.522350
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert set(a) >= {'basic', 'digest'}



# Generated at 2022-06-23 18:46:08.895977
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'Bearer' in auth_types
    assert 'Digest' in auth_types
    assert 'Basic' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types
    assert 'AWS4-HMAC-SHA256' in auth_types


# Generated at 2022-06-23 18:46:18.390027
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help='''
    Force the specified auth plugin (Basic, Digest, Hawk, ...).

    '''
)

# Generated at 2022-06-23 18:46:31.013061
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'custom' in auth_type_lazy_choices
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'auto' in auth_type_lazy_choices
    assert 'aws4-hmac-sha256' in auth_type_lazy_choices
    assert 'gss-client' in auth_type_lazy_choices
    assert 'gss-server' in auth_type_lazy_choices
    assert 'gss-client-server' in auth_type_lazy_choices
    assert 'custom-secret' in auth_type_lazy_choices
    assert 'custom-secret-secret2' in auth_type

# Generated at 2022-06-23 18:46:42.575764
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class _AuthTypeLazyChoices:

        def __iter__(self):
            return iter(['abc'])

    def test():
        return 'abc' in  _AuthTypeLazyChoices()
    assert test()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth type (plugin) used for authentication.
    If not provided and --auth is given, it is guessed.
    Available choices depend on the installed plugins.

    '''
)

# Generated at 2022-06-23 18:46:54.194428
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:47:05.378077
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for choice in _AuthTypeLazyChoices():
        assert callable(plugin_manager.get_auth_plugin_mapping()[choice])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication method (Basic or Digest). If no type
    is given and HTTPie detects that the password contains non-ASCII characters
    then Digest is used; otherwise Basic.

    Use `http --debug` to see the negotiation.
    ''',
)

auth.add_argument(
    '--auth-type=basic',
    action='store_const',
    const=AUTH_BASIC,
    dest='auth_type',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:47:18.268538
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert next(_AuthTypeLazyChoices()) == 'basic'
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. Builtin choices are basic and
    digest. Other choices can be added through plugins.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Disable HTTP authentication challenge. By default, challenge
    is supported and even required, when using Digest or OAuth1.

    '''
)

#######################################################################
# SSL

# Generated at 2022-06-23 18:47:29.619488
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth._AuthTypeLazyChoices().__iter__()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help='''
    Specify a custom auth plugin to use. The plugin must be available
    through httpie-auth-<NAME>/httpie_auth_<NAME>
    Package. See https://github.com/jakubroztocil/httpie-auth-oauth
    for an example.

    '''
)
