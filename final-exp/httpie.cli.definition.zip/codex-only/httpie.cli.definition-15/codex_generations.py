

# Generated at 2022-06-23 18:37:30.636402
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. Plugins are available for
    Digest, Hawk and OAuth1.

    ''',
)


# Generated at 2022-06-23 18:37:40.932832
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class AuthPlugin:
        auth_type = 'AuthType'
    plugin_manager.register(AuthPlugin)
    try:
        assert 'AuthType' in _AuthTypeLazyChoices()
    finally:
        plugin_manager.unregister(AuthPlugin)


auth_type_validator = AuthTypeValidator(
    'Unknown auth type. Available auth types are: {0}'.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    ))

# Generated at 2022-06-23 18:37:51.384347
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin type.
    Available built-in plugin types:

        {', '.join(auth_plugin_loader)}

    Alternatively, you can use the name of a custom plugin class.
    For example:

        --auth-type=my_package.my_module.MyAuthPlugin

    '''
)

# Generated at 2022-06-23 18:38:00.526140
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'custom-plugin' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an alternative authentication type.

    '''
)

# Generated at 2022-06-23 18:38:11.391126
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism, e.g. "digest" or "jwt".
    Use "httpie --debug" to get a list of all available options.

    ''',
)
auth.add_argument(
    '--auth-type-keyword',
    default=None,
    help='''
    Specify the corresponding keyword used to pass the credential to the
    auth plugin. Defaults to "password".

    '''
)

# Generated at 2022-06-23 18:38:13.309418
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'authtype' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:22.955605
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Specify a custom auth plugin.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl_verify = parser.add_argument_group(title='SSL')
ssl_verify.add_argument(
    '--verify', '-k',
    default=True,
    action='store_true',
    help='''
    Explicitly trust the host's SSL certificate.

    If you want to disable certificate verification, use --verify=no.

    '''
)

# Generated at 2022-06-23 18:38:25.642669
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('digest')


# Generated at 2022-06-23 18:38:35.883602
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(HTTPBasicAuth()) == ['basic']

auth_type_choices = 'auth type. One of: {0}'.format(
    ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)
auth.add_argument(
    '--auth-type',
    default=None,
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=auth_type_choices,
)
auth.add_argument(
    '--auth-type=basic',
    action=DeprecatedPluginAliasAction,
    alias='--auth-type',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:38:47.761943
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'custom' not in choices


_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    choices=_auth_type_choices,
    help='''
    The authentication mechanism used for the request. You can use
    the {plugin_option} option to specify a custom mechanism.

    '''.format(plugin_option=cli_helpers.format_option('--auth-plugin'))
)

# Generated at 2022-06-23 18:38:55.729921
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert sorted(['basic', 'digest']) == \
        sorted(_AuthTypeLazyChoices())

auth_plugin = auth.add_mutually_exclusive_group()
auth_plugin.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported: {0}.

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)


# Generated at 2022-06-23 18:38:57.619739
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'bearer' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'hawk' in lazy_choices



# Generated at 2022-06-23 18:38:58.918421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'spnego']
#

# Generated at 2022-06-23 18:39:12.363087
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def assert_choices_equal(choices):
        assert choices == sorted(plugin_manager.get_auth_plugin_mapping().keys())

    auth_type_choices = _AuthTypeLazyChoices()
    assert_choices_equal([*auth_type_choices])
    assert_choices_equal([*_AuthTypeLazyChoices()])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used.

    A custom auth plugin can be specified by the import path to its
    AuthPlugin subclass (Python 3.4+).

    ''',
)


# Generated at 2022-06-23 18:39:14.238635
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('unknown_plugin' not in _AuthTypeLazyChoices())


# Generated at 2022-06-23 18:39:25.989407
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    a = _AuthTypeLazyChoices().__contains__('DigestAuth')
    a = _AuthTypeLazyChoices().__iter__()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=AuthCredentials.validate_and_create_auth,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    Examples: Basic, Digest, OAuth1

    Advanced:

    An auth plugin can have arguments. For example, to pass `key-value` pair to
    the OAuth1 auth plugin use: -a username:password --auth-type="OAuth1(key=value)"

    '''
)


# Generated at 2022-06-23 18:39:35.060935
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    c = _AuthTypeLazyChoices()
    assert 'basic' in c
    assert 'digest' in c
    assert 'apiKeyAuth' in c
    assert list(c) == sorted(['basic', 'digest', 'apiKeyAuth'])


# Generated at 2022-06-23 18:39:46.779565
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=str.lower,
    help='''
    Specify a custom authentication plugin. See also:

        {auth_plugins_docs_url}

    '''.format(
        auth_plugins_docs_url=AUTH_PLUGINS_DOCS_URL
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:39:59.688826
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class MyPlugin(plugin.AuthPlugin):
        name = 'myplugin'
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert sorted(list(auth_type_lazy_choices)) == sorted(
        auth_type_lazy_choices
    )
    plugin_manager.register(MyPlugin)
    assert MyPlugin.name in auth_type_lazy_choices
    assert sorted(list(auth_type_lazy_choices)) == [
        MyPlugin.name, 'basic', 'digest', 'hawk',
        'netrc', 'ntlm', 'oauth1', 'threaded'
    ]


# Generated at 2022-06-23 18:40:11.869997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): # noqa: E302
    auth_types = _AuthTypeLazyChoices()
    assert len(auth_types) > 1
    assert 'basic' in auth_types
    assert 'digest' in auth_types

    auth_types_list = list(auth_types)
    assert len(auth_types_list) == len(auth_types)
    assert 'basic' in auth_types_list
    assert 'digest' in auth_types_list


# Generated at 2022-06-23 18:40:16.101726
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(['basic', 'digest']))


auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an auth type to use for a request. Defaults to "basic", but
    must be set when using digest auth.

    '''
)
auth.add_argument(
    '--auth-type=bearer',
    action='append',
    dest='auth_bearer',
    metavar='[TOKEN]',
    help='''
    Adds a Bearer authorization header to the request. If a TOKEN is not
    provided, then the authentication plugin will prompt for it.

    '''
)


# Generated at 2022-06-23 18:40:26.042372
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())


auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:40:37.575822
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hmac', 'jwt', 'multipart']

auth_type_help = '''
    What authentication method to use for requests.

    If not specified, HTTPie attempts to guess it based on the --auth option.

    The following methods are supported:
{methods}

'''
auth_type_help = auth_type_help.format(
    methods='\n'.join(
        '    {0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(
            ', '.join(plugin_manager.get_auth_plugin_mapping().keys()), 60)
    ).strip()
)

# Generated at 2022-06-23 18:40:49.395224
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'hawk' in auth_type
    assert 'ntlm' in auth_type
    assert 'oauth' in auth_type
    assert 'oauth1' in auth_type
    assert 'foo' not in auth_type

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Explicitly specify authentication mechanism.

    If no --auth-type is provided, HTTPie tries to auto-detect the auth type
    from the --auth value, and then from the server response.

    ''',
)


# Generated at 2022-06-23 18:41:02.223078
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.utils.core import get_auth_plugin_mapping
    from httpie.plugins import plugin_manager

    with patch.dict(plugin_manager.__dict__, get_auth_plugin_mapping()):
        assert list(_AuthTypeLazyChoices()) == sorted(get_auth_plugin_mapping())

with_count()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specifies the authentication mechanism: basic, digest, or a plugin.

    Plugins have precedence over builtin mechanisms.

    Use `--debug' to show the auth plugin calls and their arguments.

    '''
)

# Generated at 2022-06-23 18:41:08.902110
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager._load_auth_plugins()
    print(list(plugin_manager.get_auth_plugin_mapping().keys()))
    assert 'kerberos' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'aws4_sign_v4' in _AuthTypeLazyChoices()
    assert 'non_existing' not in _AuthTypeLazyChoices()
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-23 18:41:19.006376
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in [item for item in _AuthTypeLazyChoices()]

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism, either Basic (default) or Digest.

    The Digest auth implementation is provided by a plugin, so this option is
    available only if the plugin is installed.

    Use `--auth-type=help` to see a list of all supported auth type plugins.
    '''
)

#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:41:30.823053
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, tuple)
    assert _AuthTypeLazyChoices().__class__ == _AuthTypeLazyChoices
    assert '__contains__' in dir(_AuthTypeLazyChoices)
    assert '__iter__' in dir(_AuthTypeLazyChoices)
    assert hasattr(plugin_manager.get_auth_plugin_mapping(), 'keys')

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use. The value is the plugin's name
    as it is registered with HTTPie. Use `http --debug` to see a list
    of all registered plugins.

    '''
)

# Generated at 2022-06-23 18:41:33.545469
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:41:35.166013
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'BearerTokenAuth' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:46.067987
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():  # noqa
    assert AVAILABLE_AUTH_TYPES == (
        ','.join(_AuthTypeLazyChoices())
    )
test__AuthTypeLazyChoices___iter__()  # noqa


# Generated at 2022-06-23 18:41:52.155501
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
    with mock.patch.dict('httpie.plugins.manager.PLUGINS', {'foo': {}}):
        assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'foo']
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-23 18:41:58.025448
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'custom' not in lazy_choices

    plugin_manager.get_auth_plugin_mapping()['custom'] = object()
    assert 'custom' in lazy_choices

    del plugin_manager.get_auth_plugin_mapping()['custom']
    assert 'custom' not in lazy_choices


# Generated at 2022-06-23 18:42:07.462692
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.load_auth_plugin,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism to be used.
    Supported types:

        {auth_plugins}

    '''.format(
        auth_plugins='\n        '.join(
            wrap(' '.join(
                sorted(plugin_manager.get_auth_plugin_mapping().keys())
            ))
        )
    )
)

# Generated at 2022-06-23 18:42:17.803411
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    During digest authentication, a preliminary request without credentials
    is made. If this preliminary request is redirected, authentication
    will fail.

    This option can be used to activate the more secure digest authentication
    type (the default is basic authentication).

    The following authentication types are available:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)


# Generated at 2022-06-23 18:42:19.586700
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:22.757543
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'oauth' not in auth_types


# Generated at 2022-06-23 18:42:32.631613
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Bearer' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-type',
    type=str,
    choices=auth_type_choices,
    help='''
    Force the HTTP client to use this authentication method.

    This option is useful when the server uses a non-standard
    authentication scheme, or when the server is not sending the
    correct WWW-Authenticate header.

    ''',
)

# Generated at 2022-06-23 18:42:36.091925
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        item for item in _AuthTypeLazyChoices()
    ] == plugin_manager.get_auth_plugin_mapping().keys()

# Generated at 2022-06-23 18:42:46.525458
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    l = _AuthTypeLazyChoices()
    l.__iter__()


auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    By default, HTTPie attempts to guess the authentication scheme.
    This option allows explicitly setting the scheme.

    '''
)

#######################################################################
# Trust/certificates
#######################################################################

trust = parser.add_argument_group(title='Trust/certificates')

trust.add_argument(
    '--verify',
    action='store_true',
    help='''
    By default, HTTPS requests do not verify the server's certificate.
    With this option enabled, HTTPie will do all the necessary certificate
    verification.

    '''
)

# Generated at 2022-06-23 18:42:57.747801
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


auth_type = auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. Currently supported:

        {', '.join(_AuthTypeLazyChoices())}

    The "auto" choice (default) is HTTP Basic Auth if no password is
    provided. Otherwise, it will be token-based authentication (e.g., OAuth
    and Digest) or a plugin.

    '''
)
auth_type.completer = AuthTypeCompleter()


# Generated at 2022-06-23 18:42:59.756581
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'basic' in instance



# Generated at 2022-06-23 18:43:03.542997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
    ]


# Generated at 2022-06-23 18:43:08.739551
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    find_item_in_iterable = gen_find_item_in_iterable()
    assert find_item_in_iterable(
        lambda: _AuthTypeLazyChoices(),
        "plugin_manager.get_auth_plugin_mapping().keys()"
    )


# Generated at 2022-06-23 18:43:12.597217
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-23 18:43:23.698081
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom' not in choices
    # register a plugin
    from tests.mock import mock_plugins
    mock_plugins.install(
        'tests.mock.MockAuthPlugin',
        name='custom'
    )
    assert 'custom' in choices

AUTH_TYPES = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:34.712797
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(_AuthTypeLazyChoices())) == \
        ['basic', 'digest', 'hawk', 'ntlm']

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    action=StoreOnlyOneValue,
    choices=_AuthTypeLazyChoices(),
    help=argparse.SUPPRESS
)


#######################################################################
# SSL/TLS client-side options
#######################################################################

ssl = parser.add_argument_group(title='SSL/TLS Options')
ssl.add_argument(
    '--verify',
    action='store_true',
    default=True,
    help='''
    (default) Verify SSL certificates.
    Use --no-verify to disable.

    '''
)

# Generated at 2022-06-23 18:43:35.922535
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:43:46.001229
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == sorted(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. Currently supported: 'basic' and 'digest'.

    ''',
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:43:55.843419
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len([x for x in _AuthTypeLazyChoices()]) > 0

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    Specify the authentication mechanism to be used. Valid values depend on
    the installed plugins. By default, the "auto" plugin is used and it
    chooses the strongest authentication method offered by the server.
    The list of supported plugin names can be obtained by running:

        $ http --help-auth

    ''',
    choices=_AuthTypeLazyChoices()
)
auth.add_argument(
    '--auth-plugin',
    help=SUPPRESS,
)

#######################################################################
# Configuration
#######################################################################

configuration = parser.add_argument_group(title='Configuration')

# Generated at 2022-06-23 18:44:08.399162
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:44:09.843511
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:14.503505
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Unit test for method __iter__ of class _AuthTypeLazyChoices
    """
    pass # placeholder

    def __contains__(self, item):
        return item in plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 18:44:25.215752
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    # For backwards compatibility.
    # See: https://github.com/jakubroztocil/httpie/issues/362
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication plugin to use.

    ''',
)

auth.add_argument(
    '--auth-plugin',
    metavar='MODULE',
    default=None,
    help=SUPPRESS
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-23 18:44:38.395260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(
        _AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help='''
    Specify a custom authentication mechanism.

    Use `http --debug` to see a list of available authentication plugins.
    To use an authentication plugin, you must also install its extra
    dependencies by running e.g. `pip install httpie-oauth`.

    The default auth plugin, if --auth is used, depends on the URL protocol.
    For example, Digest auth is used for URLs like http://example.org.

    '''
)

#######################################################################
# Proxy
#######################################################################

# Generated at 2022-06-23 18:44:50.061047
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_plugin_kwargs = dict(
    nargs='?',
    dest='auth_plugin_params',
    metavar='auth-plugin-param=value',
    help='''
    Optional auth plugin parameters. Using '@' instead of '=' for specifying
    parameter values is also supported.

    For example, for an OAuth 2.0 plugin (installed separately)
    you'd specify your access token like this:

        --auth-type=oauth2 access-token:636ef0b22f0b4a4e95a08c869077ea42

    '''
)
# Unit tests for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:44:54.489051
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for item, item_in in (
        ('Basic', True),
        ('Digest', True),
        ('Some Random Keyword', False)
    ):
        assert item_in == (item in _AuthTypeLazyChoices())


# Generated at 2022-06-23 18:45:05.187115
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.

    Use the --debug flag to see a list of available authentication plugins.

    '''
)

# ``requests.request`` keyword arguments.
auth_plugins = parser.add_argument_group(title='Authentication Plugins')
auth_plugins.add_argument(
    '--auth-type',
    help=SUPPRESS,
)

#######################################################################
# JSON Input
#######################################################################


# Generated at 2022-06-23 18:45:18.612256
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())


auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:45:29.559884
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'my-plugin' not in lazy_choices

auth.add_argument(
    '--auth-type',
    default='auto',
    choices='auto ' + _AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified,
    it's guessed from the --auth option (if present).

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:45:42.311349
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(iter(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Defaults to trying them all in the order
    specified.

    '''
)

#######################################################################
# Default options
#######################################################################

# Generated at 2022-06-23 18:45:43.659208
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:51.127903
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'x-auth-plugin'
        auth_require = False

    plugin_manager.register(MyAuthPlugin)

    auth_type_choices = _AuthTypeLazyChoices()
    assert 'x-auth-plugin' in auth_type_choices
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert sorted(auth_type_choices) == sorted(['basic', 'digest', 'x-auth-plugin'])

    plugin_manager.unregister(MyAuthPlugin)


# Generated at 2022-06-23 18:45:51.881446
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iter(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:45:58.514577
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'jwt' in choices
    assert 'kv-storage' in choices
    assert 'oauth1' in choices
    assert 'ntlm' in choices
    assert 'aws-sigv4' in choices


# Generated at 2022-06-23 18:46:10.636879
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''The name of a plugin to use for authentication.

    Available plugins:
        {plugins}

    '''.format(
        plugins=', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''Do not allow the server to prompt for authentication.
        Under this mode all requests will fail if 401 status code is returned.
        '''
)


# Generated at 2022-06-23 18:46:12.303922
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:20.920464
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), Sequence)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to be used for authentication in the request.
    The default value is auto, which lets HTTPie try to auto-detect the
    authentication type.

    '''
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Specify a URL to the auth endpoint to be used by the auth plugin to
    obtain the tokens necessary for the request.

    '''
)

# Generated at 2022-06-23 18:46:22.725639
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:28.690949
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'foo' not in auth_type_lazy_choices

# Generated at 2022-06-23 18:46:30.164199
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:32.884810
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert next(iter(choices))

# Generated at 2022-06-23 18:46:38.019400
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies which method to use for authentication.
    It can be one of the following:

        {0}

    If not specified, the authentication method will be guessed from
    the provided credentials or from the URL.

    ''' .format(', '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())
    )).strip())


# Generated at 2022-06-23 18:46:49.828516
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:46:58.430174
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(_AuthTypeLazyChoices()))


# Generated at 2022-06-23 18:47:01.819958
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:47:11.357931
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication method:

    %(choices)s

    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help=f'''
    Ignore netrc file

    '''
)

auth.add_argument(
    '--netrc-path',
    dest='netrc_path',
    metavar='NETRC_PATH',
    help=f'''
    Specify path of netrc file

    '''
)

#######################################################################
# General options
####################################################################

# Generated at 2022-06-23 18:47:21.651025
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

auth.add_argument(
    '--auth-type',
    help='''
    Override the authentication method used by the auth plugin.
    Defaults to inferred from the --auth option.

    ''',
    choices=_AuthTypeLazyChoices()
)
auth_plugin_help = '''
    Load an authentication plugin. Custome authentication helpers can be

'''
auth.add_argument(
    '--auth-plugin',
    help=auth_plugin_help,
    action='append',
    dest='auth_plugins',
    metavar='PLUGIN'
)

# Generated at 2022-06-23 18:47:27.131241
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    assert iter(x) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    dest='auth_type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type (default is "auto"):

        {'|'.join(_AuthTypeLazyChoices())}

    Type "auto" means that HTTPie will guess the type by inspecting the URL.

    '''
)

#######################################################################
# Undocumented
#######################################################################

hidden = parser.add_argument_group('misc')