

# Generated at 2022-06-23 18:37:27.118038
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():_AuthTypeLazyChoices().__contains__('dummy')

# Generated at 2022-06-23 18:37:38.484636
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): # noqa
    assert set(iter(_AuthTypeLazyChoices())) == {'basic', 'digest'}

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type. Available types depend on the plugins available
    on your system.

    The default and currently only built-in type is "basic".

    '''
)

# Generated at 2022-06-23 18:37:40.849978
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:37:51.338924
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(set(['basic', 'digest', 'hawk']).intersection(choices)) == ['basic', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-send',
    default=False,
    action='store_true',
    help='''
    Send authentication credentials even for a request that does not require
    authentication.

    '''
)

#######################################################################
# Custom headers
#######################################################################
headers = parser.add_argument_group(title='Custom Headers')

# Generated at 2022-06-23 18:37:52.354008
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:53.729183
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic'.upper() in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:55.065832
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic']



# Generated at 2022-06-23 18:38:06.654577
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:38:18.484922
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='type',
    choices=_AuthTypeLazyChoices(),
    default='Basic',
    help='''
    The authentication mechanism to be used for requests.

    The default is Basic.

    '''
)


#######################################################################
# Connection Options
#######################################################################

connection = parser.add_argument_group(title='Connection Options')


# Generated at 2022-06-23 18:38:29.872745
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices


auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. The available options depend on
    the installed plugins. Run `http --debug` to see the list of
    available plugins and their names, which you can use with this
    option.

    Example: --auth-type digest

    '''
)

# A mapping of the ``--auth-type`` option to the ``auth`` option.
auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

#######################################################################
# Pretty formats
#######################################################################



# Generated at 2022-06-23 18:38:41.200819
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    By default, HTTPie will try to use the most secure mechanism available.
    You may use this option to explicitly choose one, for example, to force
    sending credentials in the Authorization header for Basic auth.

    This option is only relevant when the --auth option is also used.
    The available types are:

        basic, digest, jwt, netrc, oauth1

    '''
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')
ssl

# Generated at 2022-06-23 18:38:53.570129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['digest', 'hawk'] == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    The authentication mechanism to be used. If set, overrides the default
    mechanism which is "basic" for the HTTP and None for HTTPS.

    The currently available auth types are: {list(_AuthTypeLazyChoices())}.

    For more details, see the extended documentation at:
    {AUTH_TYPES_DOCUMENTATION_URL}

    '''
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:38:55.503289
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    list(auth_type_lazy_choices)

# Generated at 2022-06-23 18:39:01.806835
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. Currently supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)



# Generated at 2022-06-23 18:39:04.245542
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:06.517365
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(['digest', 'basic'])


# Generated at 2022-06-23 18:39:08.135482
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-23 18:39:10.132572
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-23 18:39:13.352248
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic-auth' in _AuthTypeLazyChoices()
    assert 'non-existing-auth-type' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:25.200622
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Configure the authentication method (when a username is present).

    If "auto" (default), then the, the most secure method will be used.

    Otherwise, one of:

        {auth_choices}
    '''.format(
        auth_choices='\n'.join(
            (8 * ' ') + line.strip() for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        ).strip()
    )

)

#######################################################################
# Custom headers
#######################################################################

headers

# Generated at 2022-06-23 18:39:33.407865
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. If left out, HTTPie will attempt to
    auto-detect what type of auth is required.

    '''

)

auth.add_argument(
    '--auth-all',
    action='store_true',
    help='''
    Automatically send credentials for any followed HTTP 401 Unauthorized
    response.

    '''
)

#######################################################################
# HTTPS
#######################################################################

tls = parser.add_argument_group(title='HTTPS')

# Generated at 2022-06-23 18:39:45.580657
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify the auth mechanism to use. Currently supported:

        basic, digest, aws, hawk, oauth1, netrc.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Ignore the netrc file
    (usually located at ``~/.netrc`` or ``%USERPROFILE%/_netrc``).
    '''
)


# Generated at 2022-06-23 18:39:48.418411
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:00.777671
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    help='''
    The type of authentication to use for the request. The supported types are
    the keys of the following mapping. You need to have the corresponding
    plugin installed.

        {0}

    '''.format(
        ', '.join(
            '{0!r}'.format(type)
            for type in sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    ),
    choices=_AuthTypeLazyChoices()
)


#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:40:12.831661
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()

    assert 'digest' in choices
    assert 'basic' in choices
    assert 'my_dummy_auth' in choices

    assert sorted(choices) == sorted(['basic', 'digest', 'my_dummy_auth'])

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used:
        {auth_type_choices}

    '''
)


# Generated at 2022-06-23 18:40:24.247085
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for item in _AuthTypeLazyChoices():
        pass


# Generated at 2022-06-23 18:40:28.509377
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""

    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:39.586913
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'aws-s3' in choices
    assert 'jwt' in choices
    assert sorted(choices) == ['aws-s3', 'basic', 'digest', 'jwt']
    assert 'foo' not in choices

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='NAME',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth scheme to use, one of 'basic', 'digest', 'aws-s3', 'jwt'.
    Default is inferred from --auth credentials.

    '''
)

# Generated at 2022-06-23 18:40:42.091346
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    return 'digest' in choices

# Generated at 2022-06-23 18:40:50.702537
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import pytest
    iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom HTTPie authentication plugin.

    The plugin is assumed to be installed via the Python package manager
    (eg. `pip install myplugin').

    If the plugin is a part of the httpie source distribution,
    the Python path needs to be set to include the httpie package directory,
    e.g.:

        export PYTHONPATH=path/to/httpie

    ''',
)


# Generated at 2022-06-23 18:41:03.081850
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from auth import HTTPBasicAuth

    class FooPlugin(BasePlugin):
        name = 'foo'
        auth_types = [HTTPBasicAuth]

    class BarPlugin(BasePlugin):
        name = 'bar'
        auth_types = [HTTPBasicAuth]

    class BazPlugin(BasePlugin):
        name = 'baz'
        auth_types = [HTTPBasicAuth]

    p = plugin_manager.PluginManager()

    p.add_plugin(FooPlugin())
    p.add_plugin(BarPlugin())

    assert 'foo' in _AuthTypeLazyChoices()

    p.add_plugin(BazPlugin())

    assert 'baz' in _AuthTypeLazyChoices()
    assert 'bar' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:06.850985
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert [
        'Basic',
        'Digest',
        # 'Hawk',
        # 'OAuth1',
    ] == list(auth_type_choices)



# Generated at 2022-06-23 18:41:10.121651
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Invalid' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:17.453899
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    >>> list(_AuthTypeLazyChoices())
    ['aws', 'digest', 'hawk']
    """
    assert len(list(_AuthTypeLazyChoices())) > 2

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '--auth-type=',
    choices=_AuthTypeLazyChoices(),
    default=AUTH_PLUGIN_MAP.get(None),
    help=f'''
    The mechanism to use for authentication. Supported types:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    The default is: {AUTH_PLUGIN_MAP.get(None)}

    ''',
)

# Generated at 2022-06-23 18:41:29.271316
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used. The supported authentication types are:

    {plugins_list}

    If not provided, the authentication type will be guessed based
    on the --auth option value.

    '''.format(
        plugins_list='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(
                    plugin_manager.get_auth_plugin_mapping().keys()
                )),
                width=60
            )
        ).strip(),
    )
)

#

# Generated at 2022-06-23 18:41:35.270646
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(AuthPlugin)

auth_type_validator = AuthPluginValidator()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=auth_type_validator,
    help='''
    The authentication mechanism.

    If not specified, it's guessed from --auth parameter.

    For Digest auth, the username and password are optional,
    and if needed, you will be prompted for the missing credentials.

    The values are case-insensitive and they are:

        {choices}

    '''.format(
        choices='\n        '.join(sorted(AuthPlugin))
    )
)


# Generated at 2022-06-23 18:41:46.156324
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    supported_auth_types = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for auth_type in supported_auth_types:
        assert auth_type in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='AUTHTYPE',
    help=f'''
    Override the default auth plugin used with --auth.
    For example, to use the "Basic" auth plugin:

        --auth-type=basic

    The available auth types are:

    {supported_auth_types_list}

    '''
)


# ``requests.request`` keyword arguments.
proxy = parser.add_argument

# Generated at 2022-06-23 18:41:56.955703
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockAuthPluginManager:
        def get_auth_plugin_mapping(self):
            return {'basic': None, 'digest': None}
    global plugin_manager
    plugin_manager = MockAuthPluginManager()
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:42:06.797888
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(
        _AuthTypeLazyChoices()
    )

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism to be used. Available mechanisms are:
    {auth_types}.
    Some of them can be further configured with the --auth-type-param (-T)
    option. The default mechanism is "basic".

    '''.format(
        auth_types='\n'.join(
            '        {0}{1}'.format(8 * ' ', name)
            for name in plugin_manager.get_auth_plugin_mapping().keys()
        ).strip()
    )
)

# Generated at 2022-06-23 18:42:11.896803
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert set(lazy_choices) == {
        'basic',
        'digest',
        'hawk',
        'netrc',
        'ntlm',
        'oauth1'
    }

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force the specified HTTP authentication method.

    Available values: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    ''',
)


# Generated at 2022-06-23 18:42:21.048665
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'foo' not in set(_AuthTypeLazyChoices())

_auth_type_validator = AuthTypeValidator(
    'Auth type contains invalid characters.',
    _AuthTypeLazyChoices()
)


# Generated at 2022-06-23 18:42:23.423905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_choices


# Generated at 2022-06-23 18:42:33.135345
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(AuthTypeLazyChoices, '__contains__')
    assert hasattr(AuthTypeLazyChoices, '__iter__')
    assert len(AuthTypeLazyChoices) > 0


# Generated at 2022-06-23 18:42:44.877179
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Plugin keyword arguments.
_auth_plugins = auth.add_argument_group(title='Authentication Plugins')
_auth_plugins.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Choose an authentication plugin. Currently available plugins:

    {plugins}

    See also: https://github.com/jkbrzt/httpie-auth-plugins

    '''.format(
        plugins=plugin_manager.format_auth_plugin_help()
    )
)


#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')


# Generated at 2022-06-23 18:42:48.634775
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
# Unit testing for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:42:58.668643
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom authentication plugin.

    Use "--auth-type=help" to list all available plugins.

    For example, you can add an authentication plugin to HTTPie by
    exporting the HTTPIE_AUTH_PLUGINS env variable:

        export HTTPIE_AUTH_PLUGINS="$HOME/my_auth_plugin.py"
        http --auth-type=myplugin example.org

    '''
)

# Generated at 2022-06-23 18:43:11.069514
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    type=plugin_manager.validate_auth_plugin,
    choices=_auth_type_choices,
    help='''
    The authentication mechanism to use: {choices}.

    '''.format(
        choices=', '.join(sorted(_auth_type_choices)),
    )
)

# Generated at 2022-06-23 18:43:23.084001
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'aws-sigv4' in auth_type_lazy_choices



# Generated at 2022-06-23 18:43:34.078190
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:43:36.213796
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'digest' in list(_AuthTypeLazyChoices())
    assert 'hmac' in list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:43:39.775122
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    return (
        'basic-auth' in auth_type and
        'bearer-token' in auth_type
    )


# Generated at 2022-06-23 18:43:51.786439
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == ['basic', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    Select authentication type. Available options: {options}.
    '''.format(
        options=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    ),
    choices=_AuthTypeLazyChoices()
)

auth.add_argument(
    '--auth-type-force-http-10',
    action='store_true',
    default=False,
    help='''
    If set, forces HTTP 1.0 for all requests with
    `Authorization` header.

    ''',
)


#######################################################################
# HTTPS
################################################################

# Generated at 2022-06-23 18:43:59.005338
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of auth scheme used, may be one of the following:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add_argument(
    '--auth-verify',
    default='yes',
    choices=('yes', 'no'),
    help=f'''
    Set to 'no' if certificate validation should be skipped.
    The default is 'yes'.

    '''
)

# Generated at 2022-06-23 18:44:10.895129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iter(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    help='''
    Use the specified auth plugin.

    ''',
    choices=_AuthTypeLazyChoices()
)

auth.add_argument(
    '--auth-host',
    help='''
    The host to use for looking up the auth plugin. By default,
    the hostname of the URL is used.

    ''',
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Don't use netrc for authentication.

    ''',
)


# Generated at 2022-06-23 18:44:14.412598
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-23 18:44:18.614750
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices

    assert '__contains__' not in choices
    assert '__iter__' not in choices

# Generated at 2022-06-23 18:44:25.740954
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    type=lambda x: x.lower(),
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='{%(choices)s}',
    help='''
    Specify an auth plugin to be used. If the auth plugin can not be found,
    an error is raised.

    To see a list of available plugins, type:

        $ http --auth-type

    To see detailed help for a specific plugin, type:

        $ http --auth-type=<plugin-name> --help

    Available plugins: {%(choices)s}

    '''.strip()
)

auth

# Generated at 2022-06-23 18:44:38.668112
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Given

    # When
    choices = list(_AuthTypeLazyChoices())

    # Then
    assert choices == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth_type_validator = AuthTypeValidator(
    'Auth type must be one of: {0}; got {{value}}.'.format(
        ', '.join(_AuthTypeLazyChoices() or ['(none loaded)'])
    )
)



# Generated at 2022-06-23 18:44:50.792778
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authorization mechanism.
    {plugin_manager.get_auth_plugin_mapping().get_help(cols=get_terminal_width())}

    If no --auth-type is given, then HTTPie attempts to guess it from the
    provided --auth credentials, if any. If no --auth is given, or the
    credentials can't be parsed, then the default auth type is Basic.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_

# Generated at 2022-06-23 18:45:02.935159
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'negotiate' in auth_types
    assert 'aws4-hmac-sha256' in auth_types
    assert 'aws4-hmac-sha256' in auth_types
    assert 'aws4-hmac-sha256' in auth_types
    assert 'not-exist-type' not in auth_types


# Generated at 2022-06-23 18:45:15.551120
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

auth.add_argument(
    '--auth-type',
    action=HTTPHeaderArgument,
    metavar='HEADER:VALUE',
    help=argparse.SUPPRESS)

auth.add_argument(
    '--ignore-netrc',
    default=False,
    action='store_true',
    help='''
    Do not use netrc for loading credentials from the .netrc file.

    '''
)

# ``requests.request`` keyword arguments.
auth.add

# Generated at 2022-06-23 18:45:19.728996
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-23 18:45:30.046601
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type (default: "basic").

    The available types are:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-23 18:45:42.394846
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Type of HTTP authentication to use.

    The default is Basic.

    '''
)

auth.add_argument(
    '--auth-host', default=AUTH_HOST,
    help='Host to use for authentication (default: "{0}")'.format(
        AUTH_HOST
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:45:55.688321
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(_AuthTypeLazyChoices())
    next(it)
_AuthTypeLazyChoices.__name__ = 'AuthTypeLazyChoices'

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    help=f'''\
    The authentication mechanism used. Defaults to `auto`, which will auto
    detect basic and digest auth mechanisms. The following types are available:

        {', '.join(_AuthTypeLazyChoices())}

    '''
)

auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=False,
    help='''
    Verify HTTP authentication credentials.
    This is a no-op for the Basic authentication type.

    '''
)

auth.add_

# Generated at 2022-06-23 18:46:03.171606
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type to be used. It corresponds to the
    "auth" key in the requests library. See documentation at
    http://docs.python-requests.org/en/master/user/authentication/.

    You can also install plugins to extend HTTPie functionality with custom
    types.

    '''
)


# Generated at 2022-06-23 18:46:05.969291
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert not ('fake' in _AuthTypeLazyChoices())



# Generated at 2022-06-23 18:46:11.364963
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert len(choices) > 0
    assert 'oauth1' in choices
    assert 'tests.auth.AuthPluginTest' not in choices

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    AUTH_TYPE is the name of an auth plugin to use for the request.
    By default, HTTPie picks the first plugin that is able to handle the
    request. To see the list of available auth plugins, run:

        $ http --debug | grep httpie.plugins.auth

    You can also see this list online:
    https://httpie.org/docs/authentication/

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-23 18:46:14.367566
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    actual = list(auth_type_lazy_choices)
    assert actual == ['basic', 'digest']



# Generated at 2022-06-23 18:46:22.412861
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['basic', 'digest']) == sorted(_AuthTypeLazyChoices())


auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=auth_type_choices,
    help='''
    The authentication method to be used. HTTPie currently supports the
    following methods:

        basic
        digest

    ''',
)
auth.add_argument(
    '--auth-type-help',
    action=PrintAuthPluginHelp(auth_type_choices),
    nargs='?',
    const='',
    metavar='AUTH_TYPE',
    help='Print help for a given auth type (e.g., --auth-type-help=basic).',
)
#######################################################################


# Generated at 2022-06-23 18:46:24.762005
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices

# Generated at 2022-06-23 18:46:36.885894
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism.

    Available mechanisms:

        {plugin_manager.get_auth_plugin_keys_description()}


    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--ssl', '--verify',
    default=None,
    action='store_true',
    help='''
    (default: enabled) Verify SSL certificate.
    Pass --ssl=false to disable.

    '''
)

ssl.add

# Generated at 2022-06-23 18:46:46.321101
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert True

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
        The authentication mechanism, usually one of "basic" or "digest"
        (case-insensitive). Defaults to "basic".

        You can also specify the name of a plugin from {0}
        (but without the 'httpie_' prefix).

        '''.format(plugin_manager.get_plugin_dir())
)
auth_type.add_argument(
    '--auth-plugin',
    dest='auth_type',
    metavar='PLUGIN_NAME',
    help=SUPPRESS,
)


# Generated at 2022-06-23 18:46:56.897220
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) \
        == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. By default, the authentication mechanism is
    auto-detected based on the provided credentials.

    Available mechanisms:
        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-23 18:47:07.800930
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for item in auth_type_lazy_choices:
        assert item in plugin_manager.get_auth_plugin_mapping()
    assert 'foo' not in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth plugin to use.

    If this option is omitted and ``--auth`` looks like a path to a file,
    the built-in ``file`` auth plugin is used.

    Otherwise, if this option is omitted, the ``http`` auth plugin is used by
    default.

    '''
)

# Generated at 2022-06-23 18:47:12.676334
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import pytest
    from collections.abc import Iterable

    assert isinstance(iter(_AuthTypeLazyChoices()), Iterable)
    assert next(iter(_AuthTypeLazyChoices())) == 'basic'


# Generated at 2022-06-23 18:47:22.838215
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices



# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the auth plugin to use.

    If not specified, then the auth type is determined by the URL.
    Otherwise, the most appropriate auth type is auto-selected.

    Available auth types:

    {auth_types}

    '''
)

#######################################################################
# HTTP(S)
#######################################################################

http = parser.add_argument_group(title='HTTP')

# Generated at 2022-06-23 18:47:24.879009
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-23 18:47:31.609140
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choice_help = '\n'.join(
        '    {0}{1}'.format(
            8 * ' ',
            # line.strip() needed for generate the help command for each line
            line.strip()
        ) for line in wrap(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            60
        )
    ).strip()
    assert choice_help == '''
    basic          Basic HTTP auth
    digest         Digest HTTP auth
    hawk           Hawk auth
    ntlm           NTLM auth
    oauth1         OAuth 1.0
    oauth2         OAuth 2.0
    oidc           OpenID Connect
    '''
