

# Generated at 2022-06-23 18:37:35.509144
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hmac' not in choices

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authorization plugin to use. By default (auto), the plugin is auto-detected
    from the URL. It is also possible to specify a specific plugin:

        http --auth-type=digest GET httpbin.org/digest-auth/user/passwd

    Available plugins:

        {', '.join(sorted(_AuthTypeLazyChoices()))}

    '''
)


# Generated at 2022-06-23 18:37:37.671540
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:37:46.280310
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))  # noqa: E501


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    Limit basic/digest auth to a custom domain.

    '''
)

# Generated at 2022-06-23 18:37:56.491604
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _lst = list(_AuthTypeLazyChoices())
    assert _lst == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:38:07.843827
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert list(auth_types) == []

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication plugin to use ({DEFAULT_AUTH_PLUGIN} by default).

    Available plugins:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    You can also specify a fully-qualified auth plugin name, such as
    `httpie_myplugin_auth'.

    '''
)


# Generated at 2022-06-23 18:38:09.223117
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

# Generated at 2022-06-23 18:38:17.723174
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type.

    '''
)

#######################################################################
# Non-HTTPie
#######################################################################
parser.add_argument(
    '--debug',
    action='store_true',
    default=False,
    help='''
    Show the full exception traceback when a command fails.
    Note that this can expose your credentials.

    '''
)

# Generated at 2022-06-23 18:38:19.239033
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    testInstance = _AuthTypeLazyChoices()
    assert 'digest' in testInstance
    assert 'kerberos' not in testInstance


# Generated at 2022-06-23 18:38:27.072690
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=AuthCredentials.from_auth_type,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin to be used.

    For a list of available plugins, use `http --help-auth`.

    '''
)

auth_plugins = plugin_manager.get_auth_help()

# Generated at 2022-06-23 18:38:37.491819
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    '''Make sure _AuthTypeLazyChoices() can be called w/o arguments.'''
    _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:49.165530
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert('digest' in auth_type_lazy_choices)
    assert(len(list(auth_type_lazy_choices)) > 0)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    default=None,
    help='''
    Specify an authentication type to be used.

    The following types are supported:

        {supported_types}

    '''.format(supported_types=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

#######################################################################
# Cookies
#######################################################################


# Generated at 2022-06-23 18:38:51.066138
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:38:58.454481
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    type=partial(lookup_by_values, mapping=plugin_manager.get_auth_plugin_mapping()),
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Currently supported:

        {auth_types}

    Use `--help-auth=<TYPE>` to get help for the AUTH type.

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-23 18:39:06.180051
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    help='''
    Select the authentication plugin to use.

    The following authentication plugins are available:
        {auth_types}
    Use `--auth-type help <name>` to view detailed help.

    '''.format(
        auth_types=', '.join(plugin_manager.get_auth_plugin_mapping())
    ),
    choices=_AuthTypeLazyChoices(),
    default=None
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:39:16.877465
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    assert list(iter(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication type. By default (auto),
    HTTPie tries all authentication types and always uses the strongest one.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Forces sending the Basic authentication header even when the server
    responds with a 401 status (normally, HTTPie would then try to use
    Digest auth).

    ''',
)

################################

# Generated at 2022-06-23 18:39:27.772591
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # If this test fails, see
    # http://click.pocoo.org/5/python3/#python-3-surrogate-handling
    #
    # Note that PluginManager.get_auth_plugin_mapping() must return the
    # same dictionary (or one with the same keys) on both Python 2 and 3.
    # This requirement is assumed in _AuthTypeLazyChoices
    assert {'basic', 'digest', 'hawk'}.issubset(auth_type_lazy_choices)


# Generated at 2022-06-23 18:39:34.884259
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types


AUTH_PLUGIN_HELP_MSG = '''
    You can install third-party plugins that add more auth types.
    Use `http --debug` to see a list of all loaded plugins.
    '''

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Chooses which HTTPie plugin should implement the authentication.
    The default is to select a plugin based on the --auth option value.

    ''' + AUTH_PLUGIN_HELP_MSG
)

# Generated at 2022-06-23 18:39:46.668659
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'kerberos',
        'oauth1',
        'ntlm',
        'netrc',
    ]
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    Possible values depend on the installed plugins. The auth plugin is
    registered through the entry point name httpie.auth.{NAME}

    ''',
)

# Generated at 2022-06-23 18:39:59.643006
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic' if 'basic' in _AuthTypeLazyChoices() else None,
    metavar='TYPE',
    help='''
    The type of auth to use (default is "{default}").

    Available types:

    {choices}

    '''.format(
        choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).lstrip(),
        default='basic' if 'basic' in _AuthTypeLazyChoices() else None
    )
)
auth.add_

# Generated at 2022-06-23 18:40:11.868422
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'digest' in choices

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The last part of the plugin name, e.g. "digest" in "httpie-digest-auth".

    ''',
)


# Generated at 2022-06-23 18:40:23.468076
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == [
        'digest',
        'hawk',
        'oauth1',
        'oauth1a',
        'oauth2',
    ]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to use.

    If omitted, HTTPie will attempt to auto-detect the auth type by the
    accessing the URL. If auto-detection fails, authentication is disabled.
    '''
)

# --auth-type=oauth2
oauth2_token_validator = OAuth2TokenValidator()

# Generated at 2022-06-23 18:40:30.550554
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    import httpie.plugins.auth
    plugin_manager.get_auth_plugin_mapping()['test'] = httpie.plugins.auth.BasicAuth
    assert 'test' in choices
    del httpie.plugins.auth.BasicAuth
    assert 'test' not in choices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin.

    Plugins:
    '''.strip() + '\n'.join(
        plugin_manager.format_plugin_listing('auth', 'auth-type')
    )
)

# Generated at 2022-06-23 18:40:41.245955
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert len([x for x in _AuthTypeLazyChoices()]) > 0

auth.add_argument(
    '--auth-type',
    default=None,
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help=f"The authentication mechanism. Supported are: {', '.join(_AuthTypeLazyChoices())}."
)

#######################################################################
# Wget-like Options
#######################################################################

wget_like = parser.add_argument_group(title='Wget-like Options')

# Generated at 2022-06-23 18:40:50.982575
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def assert_equal(expected, actual):
        assert list(actual) == expected
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert_equal(
        ['bearer', 'basic', 'digest', 'hawk', 'ntlm'],
        auth_type_lazy_choices
    )
    assert 'basic' in auth_type_lazy_choices



# Generated at 2022-06-23 18:40:54.488396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
    ]


# Generated at 2022-06-23 18:41:02.030100
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert not ('custom_auth' in choices)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=(
        "The authentication type (plugin) and defaults for "
        f"the --auth option. Choose from: {', '.join(sorted(_AuthTypeLazyChoices()))}"
    )
)



# Generated at 2022-06-23 18:41:12.323056
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices


# Generated at 2022-06-23 18:41:22.842754
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'custom' in choices

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin. If not set, the plugin is guessed from --auth
    value.

    The available auth plugins are:

        {auth_types}

    The "{default}" plugin corresponds to the auth value
    (e.g., --auth user:password).

    '''.format(
        auth_types='\n'.join(
            (8 * ' ') + plugin
            for plugin in plugin_manager.get_auth_plugin_mapping()),
        default='auto',
    )
)

#######################################################################

# Generated at 2022-06-23 18:41:35.059520
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type to use.
    Currently supported types are:

    {auth_types}

    This is an advanced feature. Please consult Plugin's documentation
    for detailed usage instructions.

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)


# Generated at 2022-06-23 18:41:45.981172
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test-auth'

    class TestClass(object):
        AUTH_PLUGIN_CLASS = TestAuthPlugin

    for _plugin in [HTTPBasicAuth, HTTPDigestAuth, TestClass]:
        plugin_manager.register_plugin(_plugin)

    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'test-auth' in _AuthTypeLazyChoices()
    assert 'test-not-existing' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:41:56.840501
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth plugin by name. It must be one of:
    {sorted(plugin_manager.get_auth_plugin_mapping().keys())}
    '''
)

# Generated at 2022-06-23 18:42:06.689151
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Unit test for method __iter__ of class _AuthTypeLazyChoices
    def test__AuthTypeLazyChoices___iter__():
        assert iter(_AuthTypeLazyChoices())

    auth.add_argument(
        '--auth-type',
        choices=_AuthTypeLazyChoices(),
        dest='auth_type',
        help='''

        '''
    )

#######################################################################
# Cookies
#######################################################################


cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-23 18:42:17.658858
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    '''
    Unit test for method __iter__ of class _AuthTypeLazyChoices
    '''
    assert sorted(_AuthTypeLazyChoices()) == sorted(('basic', 'digest', 'hawk', 'netrc', 'ntlm', 'oath', 'spnego'))

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

# Generated at 2022-06-23 18:42:25.575310
# Unit test for constructor of class _AuthTypeLazyChoices

# Generated at 2022-06-23 18:42:34.585520
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    for i in a:
        assert i in a

auth.add_argument(
    '--auth-type',
    metavar='PLUGIN_NAME',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='Authentication plugin to use.'
)

auth.add_argument(
    '--auth-plugin',
    metavar='PLUGIN_NAME',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=argparse.SUPPRESS
)

# Plugins
auth_plugins = auth.add_argument_group(title='Authentication plugins')

# Generated at 2022-06-23 18:42:37.647405
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:47.249787
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' not in auth_type_choices

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    help='''
    Choose an authentication plugin. Default is to auto-detect
    the authentication type.

    The following authentication plugins are available:
    {plugin_list}

    '''.format(plugin_list='\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(
            (sorted(_AuthTypeLazyChoices()))), 60)
    ).strip()),
    choices=_AuthTypeLazyChoices(),
)


# Generated at 2022-06-23 18:42:54.067750
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'never-heard-of' not in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-23 18:43:01.752082
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication mechanism.

    The default is "{DEFAULT_AUTH_PLUGIN_NAME}".

    The available choices are different depending on whether any HTTPie
    Auth plugins are installed.

    '''
)

#######################################################################
# Multiple Requests
#######################################################################

multiple_requests = parser.add_argument_group(title='Multiple Requests')


# Generated at 2022-06-23 18:43:07.102636
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        'asn1', 'base', 'digest', 'gssapi', 'http', 'kerberos', 'multi',
        'ntlm', 'oauth1', 'oauth2', 'spnego', 'type3'
    ] == sorted(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:43:11.690380
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import AuthBasicPlugin
    plugin_manager.unload_plugin_modules()
    plugin_manager.register_plugin(AuthBasicPlugin)
    assert list(_AuthTypeLazyChoices()) == ['basic']
    plugin_manager.unload_plugin_modules()

# Generated at 2022-06-23 18:43:23.212283
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set an authentication type to be used. Possible values are {auth_types}.

    '''.format(auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use the netrc file, even if it exists.

    '''
)

# Generated at 2022-06-23 18:43:34.213697
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    assert 'hawk' in auth_types
    assert '1' not in auth_types


# Generated at 2022-06-23 18:43:35.478058
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:45.630762
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert '__test_auth__' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    # We use our own reusable class to have a lazy choices that include plugins
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. It can be one of:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default is 'auto', which means HTTPie chooses the most secure
    one based on the challenge sent by the server.

    '''
)


# Generated at 2022-06-23 18:43:48.083153
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'doesntexist' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:57.044852
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'custom' in _AuthTypeLazyChoices()

auth_type = parser.add_argument_group(title='Authentication Plugins')
auth_type.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to use, e.g. `digest', `basic', `aws', etc.
    The default is `auto', which means the authentication method will be guessed
    based on provided credentials.

    '''
)

auth_plugins = plugin_manager.get_auth_plugin_mapping()
for name, plugin in auth_plugins.items():
    arg_group = auth_type.add_argument_group(title=name)

# Generated at 2022-06-23 18:44:09.075148
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    def _key(s):
        """Convert 'type_1' to '1'."""
        assert s.startswith('type_')
        return int(s[5:])

# Generated at 2022-06-23 18:44:21.330082
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    a = _AuthTypeLazyChoices()

    set(list(a)) == set(['bearer', 'digest', 'hawk', 'multi', 'netrc'])

auth_plugin_mapping = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=auth_plugin_mapping,
    help='''
    Authentication type to be used for this request.

    Currently supported auth types: {auth_types}

    '''.format(
        auth_types=', '.join(auth_plugin_mapping)
    )
)


# Generated at 2022-06-23 18:44:22.802695
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for i in _AuthTypeLazyChoices():
        pass



# Generated at 2022-06-23 18:44:29.900032
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    You can use any third-party or built-in plugins that are
    installed into the current environment.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:44:33.296901
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    return 'HTTPBasicAuth' in auth_type_lazy_choices


# Generated at 2022-06-23 18:44:42.567791
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()


auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    The authentication mechanism.

    '''
)

auth.add_argument(
    '--auth-type-force-http-10',
    action='store_true',
    default=False,
    help='''
    If set, force HTTP 1.0 for auth-type-negotiated schemes (see --auth-type).
    This works around servers that do not support "100 Continue".

    '''
)

#######################################################################
# Ignore
#######################################################################


# Generated at 2022-06-23 18:44:50.556854
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices


# Generated at 2022-06-23 18:44:57.268460
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices

    assert sorted(list(iter(auth_type_lazy_choices))) == [
        'basic', 'digest'
    ]

# Generated at 2022-06-23 18:45:09.702034
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(iter(choices)) == list(iter(sorted(plugin_manager.get_auth_plugin_mapping().keys())))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism. Some sites implement
    authentication in different ways and require a manual override to
    select the correct one, e.g. --auth-type=digest or --auth-type=basic.
    By default HTTPie attempts to auto-detect the type of the auth
    mechanism.

    '''
)

# Generated at 2022-06-23 18:45:23.247385
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def to_set(obj):
        return set(obj)

    assert to_set(_AuthTypeLazyChoices()) == to_set(plugin_manager.get_auth_plugin_mapping())


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    help='''
    The type of auth scheme to use.
    This is determined automatically unless you have installed third-party
    plugins.
    Available auth types: {0}

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping().keys()))

)
auth.add_argument(
    '--auth-verify',
    default=None,
    help='''
    Reserved for future use.

    '''
)

# Generated at 2022-06-23 18:45:30.901410
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert not 'some-unknown-auth-type' in _AuthTypeLazyChoices()


auth_type_validator = ChoiceValidator(
    '{name}: unsupported authentication plugin "{value}"'
    '(choose one of {choices})',
    _AuthTypeLazyChoices()
)

# Generated at 2022-06-23 18:45:35.103185
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:45:45.952553
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The default is "basic".

    '''
)
auth.add_argument(
    '--auth-suffix',
    help='''
    The suffix to append to the username when sending the username/password
    credentials. The default value is '@'.

    ''',
)
auth.add_argument(
    '--auth-prefix',
    help='''
    The prefix to prepend to the username when sending the username/password
    credentials. The default is an empty string.

    ''',
)

#######################################################################
# Custom headers
####################################################################

# Generated at 2022-06-23 18:45:48.425674
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Custom' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:52.532358
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'fake' not in choices



# Generated at 2022-06-23 18:45:54.778853
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices



# Generated at 2022-06-23 18:45:56.939622
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert all(x in _AuthTypeLazyChoices() for x in ('basic', 'digest'))

# Generated at 2022-06-23 18:46:09.031940
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

_auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=_auth_type_choices,
    help=f'''
    The authentication mechanism to be used. The default is "basic".
    HTTPie includes plugins for the following mechanisms:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-23 18:46:10.740859
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:20.008233
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert sorted(choices) == sorted(['basic', 'digest', 'aws'])


# Encourage the use of the more explicit --auth-type
# since this option is more error-prone to typos.

# Generated at 2022-06-23 18:46:33.341936
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'netrc' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to be used.
    By default, the "Basic" method is used.

    '''
)
auth.add_argument(
    '--auth-type-force-http',
    action='store_true',
    default=False,
    dest='auth_type_force_http',
    help='''
    Force the use of Basic Authentication over HTTP (e.g., when connecting to
    an HTTP proxy).

    '''
)
auth.add_

# Generated at 2022-06-23 18:46:35.486060
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:45.518990
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    assert list(_AuthTypeLazyChoices()) == []

_LAZY_CONTAINER = _AuthTypeLazyChoices()


auth_type = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.load_plugin,
    choices=_LAZY_CONTAINER,
    help='''
    Override the default authentication handler.

    You can use the alias 'auto' to tell HTTPie to infer the authentication
    type from the URL. It will use the same authentication type for all
    subsequent requests to the same host or domain.

    ''',
)

# Generated at 2022-06-23 18:46:49.438315
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping()
    assert list(auth_types) == ['basic', 'digest']



# Generated at 2022-06-23 18:46:51.214465
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bar' not in  _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:59.136988
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    # This line causes the constructor to execute
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices


auth.add_argument(
    '--auth-type', '--auth-types',
    metavar='',
    default=None,
    choices=list(_AuthTypeLazyChoices()),
    help='''
    The authentication mechanism to be used.

    Some commonly available authentication mechanisms beyond the defaults include:

        jwt, oauth2, oauth1, awsauth

    '''
)

# Generated at 2022-06-23 18:47:09.128374
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted('digest') == sorted(list(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Which kind of HTTP auth to use.

    ''',
)


#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

proxy.add_argument(
    '--proxy',
    metavar='PROTOCOL://USER:PASS@HOST:PORT',
    help='''
    Proxy to be used for making requests.

    ''',
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

cookies.add_

# Generated at 2022-06-23 18:47:20.683221
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism (plugin) used to
    handle authentication, e.g. "digest".

    The default is to auto-detect the correct plugin based on the
    provided credentials.

    Use "http --debug" flag to see the list of plugins and their
    configuration.

    You can also see the list of plugins by invoking the "http" command
    without any arguments.

    '''
)

# Generated at 2022-06-23 18:47:21.665668
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:47:30.608167
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert not isinstance(_AuthTypeLazyChoices(), list)
    assert sorted(_AuthTypeLazyChoices()) == sorted([
        'basic', 'digest', 'hawk', 'ntlm', 'aws-s3'])

