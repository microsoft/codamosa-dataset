

# Generated at 2022-06-23 18:37:32.720232
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_plugin_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    dest='auth_plugins',
    default=None,
    metavar='REDIRECTED|BASIC|DIGEST|AWS|AWS4',
    choices=auth_plugin_choices,
    action=parser_utils.AppendUniqueChoicesAction,
    help='''
    Specify an HTTP authentication type for the preceding --auth option.
    (The default is "basic.")

    ''',
)


#######################################################################
# Auth plugins
#######################################################################


# Generated at 2022-06-23 18:37:42.676528
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class Namespace:

        pass

    try:
        class DummyPlugin:

            name = 'dummy'

        plugin_manager._plugin_classes = {'auth': DummyPlugin}

        parser = argparse.ArgumentParser()
        parser.add_argument(
            '--auth-type',
            action='store',
            default=None,
            choices=_AuthTypeLazyChoices()
        )
        ns = Namespace()
        parser.parse_args(['--auth-type', 'dummy'], namespace=ns)

        assert ns.auth_type == 'dummy'

    finally:
        plugin_manager._plugin_classes = {}



# Generated at 2022-06-23 18:37:43.812552
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:37:48.935198
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    a = list(auth_type_lazy_choices)
    assert a == sorted(plugin_manager.get_auth_plugin_mapping().keys())
test__AuthTypeLazyChoices___iter__()


# Generated at 2022-06-23 18:37:51.079275
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    __contains__ = _AuthTypeLazyChoices.__contains__
    assert 'basic' in __contains__
    assert 'abc' not in __contains__

# Generated at 2022-06-23 18:37:55.276161
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices"""
    assert "basic" in _AuthTypeLazyChoices()
    assert "digest" in _AuthTypeLazyChoices()
    assert "aws" in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:02.696359
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # pragma: no cover
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin' not in _AuthTypeLazyChoices()
    # plugins will register themselves



# Generated at 2022-06-23 18:38:12.956599
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Force the specified authentication mechanism. By default, the authentication
    mechanism is automatically determined based on the provided credentials.
    By specifying this option, you can force HTTPie to not auto-detect.

    The available authentication mechanisms are:

    {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-23 18:38:22.714149
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass


# Generated at 2022-06-23 18:38:33.546950
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    plugin_manager.deactivate_all_auth_plugins()
    assert list(choices) == []



# Generated at 2022-06-23 18:38:45.878749
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        list(_AuthTypeLazyChoices())
    except Exception:
        assert False  # pragma: nocover
        return
    assert True

auth_type_help = (
    f'\nThe authentication type to be used.\n'
    f'Available choices: {list(_AuthTypeLazyChoices())}\n\n'
    f'If the `http` or `https` schemes are used,'
    f' Basic and Digest auth are used.\n'
    f'If other schemes are used, such as `{DEFAULT_SOCKET_PROTOCOL}`, '
    f'the appropriate auth plugin is used.\n'
)

# Generated at 2022-06-23 18:38:54.860281
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type to be used with the
    provided credentials (e.g. "digest").

    If not specified, HTTPie will first try Digest authentication. If the server
    challenge is malformed, it will fall back to Basic.

    Use --auth-type=basic to force Basic authentication.

    Multiple plugin hooks implementing custom auth types are supported.
    Run `http --auth-type=help` to list the available types.

    '''
)

# Generated at 2022-06-23 18:38:56.086997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    iter(choices)
    assert True

# Generated at 2022-06-23 18:38:57.140486
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-23 18:38:59.264685
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert PLUGIN_NAME in auth_type_choices


# Generated at 2022-06-23 18:39:08.145518
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(_AuthTypeLazyChoices()) > 1

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use. Choose from the following:

    {choices}

    '''.format(
        choices='\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    ),
)


# Generated at 2022-06-23 18:39:13.987422
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 18:39:19.012375
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    'test__AuthTypeLazyChoices___contains__'
    from .authplugins import load_auth_plugins
    with load_auth_plugins(['non_existent']), load_auth_plugins([]):
        choices = _AuthTypeLazyChoices()

    assert 'non_existent' in choices


# Generated at 2022-06-23 18:39:29.379388
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Bearer' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force HTTPie to use a different type of authentication.
    By default (--auth-type=auto), HTTPie determines the type based on the
    presence of special options, such as --auth-type=digest --auth="user:pass".

    Possible types of authentication are: %(choices)s

    '''
)

# Basic auth username and password.
auth.add_argument(
    '--auth-user',
    default=None,
    help=argparse.SUPPRESS
)

# Generated at 2022-06-23 18:39:35.760956
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.auth import AuthPlugin, AuthPluginManager
    from httpie.plugins.auth.utils import AuthCredentials
    plugin_manager = AuthPluginManager()

    class TestAuthPlugin(AuthPlugin):
        auth_type = 'test'

        def get_auth(self, username=None, password=None):
            return AuthCredentials(username, password)

    plugin_manager.register(TestAuthPlugin)
    auth_choices = _AuthTypeLazyChoices()
    assert 'test' in auth_choices
    plugin_manager.unregister(TestAuthPlugin)

AuthTypeLazyChoices = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:47.075633
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert AuthTypeLazyChoices in _AuthTypeLazyChoices.__bases__

_auth_type = auth.add_mutually_exclusive_group()
_auth_type.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=AuthTypeLazyChoices(),
    help='''
    Explicitly specify authentication type. Supported types:

    {types}

    '''.format(
        types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        ).strip()
    )
)

#######################################################################
# SSL
####################################################################

# Generated at 2022-06-23 18:39:49.354041
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = iter(_AuthTypeLazyChoices)
    assert next(choices) == 'basic'
    assert next(choices) == 'digest'
    assert next(choices) == 'hawk'
    assert next(choices) == 'ntlm'
    with pytest.raises(StopIteration):
        next(choices)

# Generated at 2022-06-23 18:40:00.127519
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'abc' not in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    Specify a custom auth plugin to be used.

    Available plugins:
    {plugins}
    '''.format(
        plugins='\n'.join(
            ' * {0}'.format(name)
            for name in plugin_manager.get_auth_plugin_mapping()
        )
    )
)



# Generated at 2022-06-23 18:40:07.491732
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    How to apply the provided credentials. Specify one of:

        "auto" (default) - use the most secure method
        "{AUTO_AUTH_PLUGIN}" - use the most secure method among these
        "basic" - HTTP Basic Authentication
        "digest" - HTTP Digest Authentication
        "jwt" - JSON Web Token Authentication
        "hawkey" - Hawk Authentication
        "netrc" - use credentials given in `~/.netrc`

    ''',
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add

# Generated at 2022-06-23 18:40:18.158839
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:26.955822
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for a in _AuthTypeLazyChoices():
        pass

auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin by giving a fully qualified name
    of its class. See 'http --help-auth' for a list of included plugins.

    '''
)

# Generated at 2022-06-23 18:40:29.380084
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices


# Generated at 2022-06-23 18:40:38.631561
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert len(list(auth_types)) == len(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Only relevant when --auth is used.
    The following authentication types are supported. Run `http --help-auth` to
    see the list of available auth types.

    '''
)


# Generated at 2022-06-23 18:40:50.115335
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = set(_AuthTypeLazyChoices())
    assert auth_type_choices == set(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'digest' in auth_type_choices


# Generated at 2022-06-23 18:40:51.985590
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:03.383005
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    builtin_auth_types = 'basic digest'
    choices = list(_AuthTypeLazyChoices())
    assert choices == builtin_auth_types.split()
    assert all(
        auth_type in choices for auth_type in builtin_auth_types.split()
    )
    assert choices == list(sorted(choices))
    assert sorted(choices) == [sorted(auth_type) for auth_type in choices]


# Generated at 2022-06-23 18:41:13.071515
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()
AuthTypeLazyChoices = _AuthTypeLazyChoices()

# ``requests.request`` **kwargs.
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    choices=AuthTypeLazyChoices,
    default='auto',
    help='''
    The plugin used to perform the authentication. HTTPie will auto-detect
    if this option is not specified.

    The following plugins are supported and can be selected by their names:

        {auth_plugins}

    '''.strip()
)
auth.add_argument(
    '--auth-type=',
    dest='auth_type',
    action='store_const',
    const=None,
    help=argparse.SUPPRESS
)
#

# Generated at 2022-06-23 18:41:20.829912
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Supported types:
    {auth_type_help}
    '''.format(
        auth_type_help='\n'.join(
            '    {0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:41:21.943263
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:41:34.369533
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'noauth' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'awsv4' in _AuthTypeLazyChoices()
# some auth plugins have dependencies that may not be installed,
# so we defer obtaining possible choices until the program is running.

# Generated at 2022-06-23 18:41:41.710422
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
basic_auth_help = '''
    Clear text string used by HTTP Basic Authentication.
'''
digest_auth_help = '''
    Clear text string used by HTTP Digest Authentication.
'''
hawk_auth_help = '''
    Username and password used by HTTP Hawk Authentication.
    Optionally include `id` and `algorithm` parameters.

    See: https://github.com/hueniverse/hawk#usage-examples
'''
mutual_tls_auth_help = '''
    Path to a client key and client certificate in
    PEM format used by HTTP Mutual (mTLS) Authentication.
'''

# Generated at 2022-06-23 18:41:45.967201
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['digest', 'hawk', 'jwt-auth', 'oauth2']) == sorted(list(_AuthTypeLazyChoices()))
test__AuthTypeLazyChoices___iter__()


# Generated at 2022-06-23 18:41:56.838978
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    try:
        list(choices)
    except Exception as e:
        pytest.fail('Iteration failed: {e}'.format(e=e))


# ``requests.auth.AuthBase`` class name or ``requests-toolbelt`` class name

# Generated at 2022-06-23 18:42:06.700698
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=AUTH_TYPES.BASIC,
    help='''

    ''',
)

# Generated at 2022-06-23 18:42:17.658442
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the use of a specific authentication type, auto-detection of the
    authentication type is normally done by HTTPie.

    '''
)
auth.add_argument(
    '--auth-type=digest',
    dest='auth_type',
    action='store_const',
    const='digest',
    help='''
    --auth-type=digest is the same as --auth-type digest.

    '''
)

# Generated at 2022-06-23 18:42:25.574332
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = _AuthTypeLazyChoices().__iter__()
    assert next(it) == 'digest'
    assert next(it) == 'jwt'
    assert next(it) == 'keyring'
    assert next(it) == 'netrc'
    assert next(it) == 'oauth1'


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.
    Available choices are: {choices}

    '''.format(
        choices=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-23 18:42:36.740553
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:42:46.848551
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for i in auth_type_lazy_choices:
        pass

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. If not specified, an appropriate one is
    guessed.

    If a plugin implementing this mechanism is not installed,
    you will get an error. To install all optional plugins at once:

        $ pip install httpie[plugins]

    ''',
)

# Generated at 2022-06-23 18:42:49.729150
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'digest' in auth_type

# Generated at 2022-06-23 18:42:50.991281
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic')



# Generated at 2022-06-23 18:43:00.110183
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'kerberos' in auth_type_choices
    assert hasattr(auth_type_choices, '__contains__')
    assert hasattr(auth_type_choices, '__iter__')
    assert sorted(auth_type_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    # Test if choice 'kerberos' is present in its __iter__
    assert 'kerberos' in list(auth_type_choices)



# Generated at 2022-06-23 18:43:02.240627
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'oauth1' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:43:12.840884
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # If it contains and raises no exception, then it's probably fine
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    dest='auth_plugin',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used (if any).
    One of: {0}

    '''.format(' '.join(sorted(plugin_manager.get_auth_plugin_mapping()))),
)

# Generated at 2022-06-23 18:43:23.840668
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    How the credentials are sent to the server. By default, the credentials are
    sent on the first request to the server.

    The following values are currently supported:

    {auth_plugin_help()}

    '''
)

# Generated at 2022-06-23 18:43:34.885098
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert 'invalid' not in a

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    # choices=sorted(plugin_manager.get_auth_plugin_mapping().keys()),
    help='''
    The type of authentication credentials provided with --auth.
    By default, HTTPie tries to detect this from the given value.

    ''',
)

# Generated at 2022-06-23 18:43:36.663154
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'plugin 1' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:38.402626
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices


# Generated at 2022-06-23 18:43:42.721265
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        _AuthTypeLazyChoices().__contains__('digest')
    except AttributeError:
        pytest.fail(
            msg='_AuthTypeLazyChoices().__contains__() does not work'
        )


# Generated at 2022-06-23 18:43:54.560406
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'https' in _AuthTypeLazyChoices()
    assert 'custom-scheme' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type', '--auth-type',
    default='http',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Which HTTP authentication mechanism to use. Available schemes are:

        {plugin_manager.get_auth_plugin_listing()}

    The default is 'http'.

    Note that this is different from the `--auth` option,
    where you can use arbitrary schemes.

    '''
)

# Generated at 2022-06-23 18:44:07.485960
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    You may specify multiple auth types by repeating the --auth-type=TYPE argument
    as many times as needed. For example, to use both basic and digest authentication:

        http --auth-type=basic --auth-type=digest example.org

    '''
)
# auth.add_argument(
#     '--auth-include',
#     action='store_true',
#     help='''
#     Include the `Authorization` header in HTTPie output.
#
#     '''
# )


#######################################################################
#

# Generated at 2022-06-23 18:44:09.557840
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-23 18:44:21.815596
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom' in choices
    assert 'banana' not in choices


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    This can be any of:

        {auth_types}

    The default is 'basic'.

    For example, --auth-type=digest.

    '''
        .format(
            auth_types=', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping()
            ))
        )
)
#######################################################################
# Persistence
#######################################################################

persistence = parser.add_argument

# Generated at 2022-06-23 18:44:27.662806
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    >>> atlc = _AuthTypeLazyChoices()
    >>> 'basic' in atlc
    True
    >>> for i in atlc: print(i)
    basic
    digest
    """

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Default is "basic". Other built-in types are:
    {0}

    Plugins can provide additional types.
    See the "Authentication Plugins" section in the HTTPie docs.

    '''.format(', '.join(sorted(BUILTIN_AUTH_PLUGINS)))
)


#######################################################################
# Authentication plugin options.
#######################################################################


# Generated at 2022-06-23 18:44:30.063192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _ = _AuthTypeLazyChoices()
    # Should not raise
    assert 'Basic' in _

# Generated at 2022-06-23 18:44:32.017015
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:41.917033
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    set(_AuthTypeLazyChoices()) # maybe should use list()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Force HTTPie to use a specific authentication method.
    By default, HTTPie tries Basic, Digest, then other methods, in that
    order.

    ''',
)
auth.add_argument(
    '--auth-methods',
    metavar='METHOD',
    action='append',
    help='''
    Space separated list of authentication methods to try when using
    `--auth` option.

    The default auth methods are Basic, Digest.

    To see a list of installed auth methods, do:

        $ http --list-auths


    '''
)

#######################################################################


# Generated at 2022-06-23 18:44:47.230986
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'foo' not in auth_type_lazy_choices

# Generated at 2022-06-23 18:45:00.155870
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['basic', 'digest'] == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism (plugin) used for the request.
    Plugins are JSON files containing the implementation details.
    The default is "basic".

    See {0} for the built-in plugins.
    To implement a custom plugin, get the path to the plugins directory via
    `http --plugins-dir`, create a plugin file there, and restart HTTPie.
    Examine the built-in plugins for examples.

    '''.format(BUILTIN_AUTH_PLUGINS_HELP)
)

# Generated at 2022-06-23 18:45:02.441756
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(AUTH_PLUGIN_MAP.keys()))



# Generated at 2022-06-23 18:45:03.823606
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:45:08.725205
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    '''The method __iter__ of class _AuthTypeLazyChoices should return an iterator.'''
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert iter(auth_type_lazy_choices) == auth_type_lazy_choices.__iter__()

# Generated at 2022-06-23 18:45:22.851308
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(AUTHPLUGIN_MAP)


auth_plugin = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-23 18:45:30.609038
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [AUTH_PLUGIN_NAME]


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='Authentication plugin to use.'
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Do not do an HTTP Authentication Challenge first.
    Instead, just present the credentials on the first request.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP Method').add_mutually_exclusive_group(required=True)


# Generated at 2022-06-23 18:45:33.312483
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')


# Generated at 2022-06-23 18:45:44.233768
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)


auth.add_argument(
    '--auth-type', '-t',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to use.
    The default plugin is "{auth_plugin_default}".
    This can be one of:

    {auth_plugins_list}
    '''.format(
        auth_plugin_default=DEFAULT_AUTH_PLUGIN,
        auth_plugins_list=indent(
            '\n'.join(
                plugin_manager.get_auth_plugin_mapping().keys()
            )
        ).lstrip()
    ),
)

# ``requests.auth.HTTPBasicAuth`` keyword arguments.

# Generated at 2022-06-23 18:45:48.875509
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    plugin_manager._auth_plugin_mapping = {'foo': 'bar'}
    assert 'foo' in auth_type_lazy_choices


# Generated at 2022-06-23 18:45:51.534038
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for item in _AuthTypeLazyChoices():
        pass

# Generated at 2022-06-23 18:45:53.086469
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:01.910782
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['digest', 'hawk', 'ntlm']


# Generated at 2022-06-23 18:46:12.849927
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices
    assert 'new_auth_type' not in auth_type_lazy_choices

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use:

    '''.lstrip() + f'''
    basic  HTTP Basic Authentication
    digest HTTP Digest Authentication (default)
    {plugin_manager.get_auth_plugin_help()}

    '''
)

# Generated at 2022-06-23 18:46:20.923685
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'custom' in auth_type_lazy_choices
    assert 'basic1' not in auth_type_lazy_choices
    assert 'digest1' not in auth_type_lazy_choices
    assert 'hawk1' not in auth_type_lazy_choices
    assert 'custom1' not in auth_type_lazy_choices

# Generated at 2022-06-23 18:46:34.206210
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(_AuthTypeLazyChoices()) > 2

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),  # TODO: Drop after 1.0.
    help='''
    Specify an authentication plugin to use instead of the default.
    This can be useful to implement various authorization schemes that
    require signing a request -- see the source code of the
    Keybase auth plugin (contrib/auth/keybase.py) for an example.

    ''',
)

#######################################################################
# HTTP and HTTPS Proxy
#######################################################################

_http_proxy_help = '''
    Set HTTP proxy to use for the request.

    '''
_https_proxy_help = '''
    Set HTTPS proxy to use for the request.

    '''


# Generated at 2022-06-23 18:46:44.528544
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == ['basic', 'digest', 'hawk', 'netrc']


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The auth mechanism to be used. HTTPie supports Basic and Digest auth out of
    the box. The following plugins have been enabled:

        {plugins}

    Use the --auth-type=auto option to let HTTPie detect the auth type from
    the server's response headers.

    '''.format(
        plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-23 18:46:55.579475
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''\
    Set authentication type used for parsing the credentials provided with
    --auth.

    If not specified, HTTPie will try to guess the type.

    The following authentication types are available:

    {plugin_manager.get_auth_help_items(AuthPluginManager.AUTH_PARSERS)}
    '''
)

#######################################################################
# Proxy
#######################################################################

# All proxies are supported via ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:47:06.458063
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Default auth plugins are loaded but only custom ones can be found by
    # the plugin manager. This test is to check that _AuthTypeLazyChoices
    # correctly queries the plugin manager for the list of auth plugins.
    _AuthTypeLazyChoices().__contains__("custom-plugin-type")

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Deprecated. Use --auth-plugin=<TYPE> instead.
    See http://httpie.org/plugins for a list of available auth plugins.

    ''',
)


# Generated at 2022-06-23 18:47:18.811810
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [] == list(_AuthTypeLazyChoices())
    class FooAuth(AuthPlugin):
        auth_type = 'foo'
    class BarAuth(AuthPlugin):
        auth_type = 'bar'
    with plugin_manager.context() as pm:
        pm.register(FooAuth)
        pm.register(BarAuth)
        assert ('bar', 'foo') == tuple(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:47:29.764220
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list('basic digest oauth1 oauth2'.split())


auth_type = auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force HTTPie to use a certain authentication plugin.

    E.g., when using Basic auth, the client sends the username and password
    encoded in base64. This implementation can be easily tricked into
    revealing a valid password for a different username. To combat this,
    digest auth should be used instead, and so on.

    '''
)

#######################################################################
# Additional
#######################################################################

additional = parser.add_argument_group(title='Additional')

