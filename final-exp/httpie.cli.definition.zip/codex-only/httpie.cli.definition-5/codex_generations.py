

# Generated at 2022-06-23 18:37:35.591455
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest']



# Generated at 2022-06-23 18:37:42.421154
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an alternate authentication plugin to use.
    '''
)

auth_basic = auth.add_argument_group(title='Basic Auth')
auth_basic.add_argument(
    '--auth-type',
    action='store_const',
    const='basic',
    dest='auth_type',
    help=SUPPRESS,
)

# Generated at 2022-06-23 18:37:53.308512
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=(
        'Choose the authentication mechanism. '
        'The default is "auto" which will try a few popular '
        'auth types and fall back to Basic if none are applicable. '
        'Explicitly setting the options "auto" or "interactive" '
        'will still ask for the password, if required.'
    ),
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:38:01.438153
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'oauth2' in auth_type_lazy_choices
    assert 'password' in auth_type_lazy_choices
    assert 'noauth' in auth_type_lazy_choices
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    assert 'aws' in auth_type_lazy_choices

# Generated at 2022-06-23 18:38:12.261110
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('foo')


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),  # See docs.
    default=None,
    help='''
    The authentication mechanism to be used. This only affects
    the way the provided credentials are handled, not how they're
    sent to the server. By default, the provided credentials are
    sent as HTTP Basic auth.

    The supported options depend on the installed auth plugins.

    '''
)


# Generated at 2022-06-23 18:38:20.483719
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism, e.g., "digest" or "ntlm".

    ''',
)


# Generated at 2022-06-23 18:38:32.124383
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
assert test__AuthTypeLazyChoices___contains__()
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    An attempt is made to load the authentication plugin for the given
    authentication type.

    If the authentication type is not specified, an attempt is made to
    auto-discover it based on the --auth option value.

    ''',
)


# Generated at 2022-06-23 18:38:35.872187
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import AuthPluginManager
    from httpie.core import main as httpie
    from .parser import parser
    plugin_manager = AuthPluginManager()
    choices = _AuthTypeLazyChoices()
    for item in choices:
        assert type(item) == str, type(item)
        assert item in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-23 18:38:47.761973
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'custom' in choices


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type (digest or basic).
    Defaults to digest if the --auth option is provided,
    and to basic otherwise.

    ''',
)

#######################################################################
# Request options
#######################################################################

request = parser.add_argument_group(title='Request options')

request.add_argument(
    '--method', '-m',
    type=str,
    help='''
    Specify the HTTP method to use. Defaults to GET.

    '''
)


# Generated at 2022-06-23 18:38:50.994421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:39:01.513129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use, e.g. "basic".
    The value of --auth needs to be provided as well.

    If the type is not specified and there is a colon in the value of --auth,
    the authentication type is guessed from the part before the colon.

    '''
)

# Generated at 2022-06-23 18:39:08.585881
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    httpie_auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    for key in httpie_auth_plugin_mapping:
        assert key in lazy_choices
    non_existing_key = '_non_existing key_'
    assert non_existing_key not in lazy_choices



# Generated at 2022-06-23 18:39:18.791207
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_choices,
    help='''
    Choose an auth plugin or one of the following builtin types:
    {0}'''.format(' (default)'.rstrip(' :'), *sorted(_choices))
)

# Generated at 2022-06-23 18:39:22.737766
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        import pytest  # pylint: disable=unused-import, ungrouped-imports
    except ImportError:
        raise SkipTest


auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:23.945173
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-23 18:39:32.610638
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _x = _AuthTypeLazyChoices()
    assert 'bearer' in _x
    assert 'awesomesauce' not in _x


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type. The default is to auto-detect the type based on
    the supplied credentials.
    The following are the currently supported types:

    {generate_help('--auth-type')}

    '''
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:39:45.081119
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used. If not provided, HTTPie
    will try to guess it.
    Available: {auth_types}

    '''.format(auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

# Generated at 2022-06-23 18:39:58.380651
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Smoke test
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
        The authentication type to use.

        HTTPie currently supports the following auth types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

        The default is "{DEFAULT_AUTH_PLUGIN_NAME}".
    '''
)


# Generated at 2022-06-23 18:39:59.867152
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:11.868682
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for auth_type in _AuthTypeLazyChoices():
        pass

# auth-plugin arguments
auth_plugin = parser.add_argument_group(title='Authentication Plugin')
auth_plugin.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices()
)
auth_plugin.add_argument(
    '--auth-use-defaults',
    default=False,
    action='store_true',
    help="Use plugin's default configuration")

#######################################################################
# HTTP method
#######################################################################
# ``requests.request`` keyword arguments.
request_method = parser.add_argument_group(title='Method')

# Generated at 2022-06-23 18:40:13.494076
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-23 18:40:16.341330
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'JWT' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:40:26.216295
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '-A',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Default: {default}

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME
    )
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not send an initial authentication challenge to the server and let the
    server determine whether authentication is required (default: {default}).

    '''.format(
        default=DEFAULT_AUTH_NO_CHALLENGE
    )
)

#######################################################################
# Cookies
####################################################################

# Generated at 2022-06-23 18:40:37.744208
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('apikey') == True
    assert choices.__contains__('basic') == True
    assert choices.__contains__('digest') == True
    assert choices.__contains__('hmac') == True
    assert choices.__contains__('test') == False
    lst = list(choices)
    assert 'apikey' in lst
    assert 'basic' in lst
    assert 'digest' in lst
    assert 'hmac' in lst
    assert 'test' not in lst


# Generated at 2022-06-23 18:40:49.554116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import json
    auth_type_choices = _AuthTypeLazyChoices()
    json.dumps(list(auth_type_choices))
    assert 'digest' in auth_type_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth type to be used instead of trying them all.
    Currently supported: basic, digest.

    '''
)
auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=True,
    help='''
    Verify SSL certificate when using HTTPS.

    '''
)

# Generated at 2022-06-23 18:40:52.893497
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:40:55.293358
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:57.569432
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()] == ['basic', 'digest']

# Generated at 2022-06-23 18:41:07.301997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(_AuthTypeLazyChoices())


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin module.
    Available: {comma_separated_list(
        plugin_manager.get_auth_plugin_names())}.

    ''',
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:41:17.682275
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    A custom auth type from a plugin.

    If a plugin is installed and it's registered as an auth plugin,
    then the plugin is used to perform auth.

    ''',
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')

# Generated at 2022-06-23 18:41:20.464596
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))



# Generated at 2022-06-23 18:41:32.793755
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:41:40.536786
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication mechanism. Default is "basic".
    '''
)

auth.add_argument(
    '--auth-type-help',
    action='store_true',
    default=False,
    help='''
    Show authentication types help.
    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:41:49.683267
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == []
    plugin_manager.load_builtin_plugins()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == ['hawk', 'http', 'oauth1', 'netrc']


# Generated at 2022-06-23 18:42:00.509460
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to determine the authentication type
    automatically based on the set --auth option.

    ''',
)

#######################################################################
# Connection
#######################################################################

connection = parser.add_argument_group(title='Connection')
connection.add_argument(
    '--verify', '-k',
    action='store_true',
    dest='verify',
    help='''
    Use SSL certs from the system's CAs.
    By default, the SSL certs from the system's CAs are used for verifying
    the server.

    ''',
)

# Generated at 2022-06-23 18:42:08.831825
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from tempfile import NamedTemporaryFile
    from httpie import plugin_manager
    x = _AuthTypeLazyChoices()
    assert 'basic' in x
    with NamedTemporaryFile('w') as f:
        f.write("""
            from httpie.plugins import AuthPlugin

            class TestAuthPlugin(AuthPlugin):
                name = 'test_auth'

                def get_auth(self, username, password):
                    return username, password,
                    """)
        f.flush()
        plugin_manager.load_plugin(f.name)
        assert 'test_auth' in x
        del x
        assert 'test_auth' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:42:10.152441
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:42:19.732505
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'bearer' in lazy_choices
    assert 'http' in lazy_choices
    assert 'foo' not in lazy_choices
    assert 'bearer' in list(lazy_choices)

auth_type_validator = AuthTypeValidator(
    _AuthTypeLazyChoices(),
    'Auth type can be one of {0}'.format(
        plugin_manager.get_auth_plugin_mapping().keys())
)


# Generated at 2022-06-23 18:42:26.812413
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import builtin as built_in_plugins
    plugin_manager.unload_all_plugin_classes()
    plugin_manager.load_plugin_classes(built_in_plugins)
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == ['hawk', 'jwt']
    assert ['hawk', 'jwt'] == list(auth_type_lazy_choices)


# Generated at 2022-06-23 18:42:35.318922
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    x = _AuthTypeLazyChoices()
    assert 'basic' in x
    assert 'digest' in x
    assert 'hawk' in x
    assert 'custom' in x
    assert sorted(x) == ['basic', 'custom', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    default='basic',
    dest='auth_plugin_name',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type ({0}).

    '''.format(
        '|'.join(plugin_manager.get_auth_plugin_mapping())
    )
)



# Generated at 2022-06-23 18:42:39.758596
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('custom-header' in _AuthTypeLazyChoices())
    assert ('basic' in _AuthTypeLazyChoices())
    assert ('digest' in _AuthTypeLazyChoices())
    assert ('ignore' not in _AuthTypeLazyChoices())



# Generated at 2022-06-23 18:42:48.201615
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = _AuthTypeLazyChoices().__iter__()
    assert hasattr(next(it), '__next__')
    assert hasattr(next(it), '__next__')

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help='''
    The name of the plugin (or "auth handler") to use for authentication.
    The default auth plugin is called "basic" and implements Basic
    Authentication.

    To get a list of available auth plugins, run:
        http --debug

    '''
)

# Generated at 2022-06-23 18:42:50.818520
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert {'basic', 'digest'}.issubset(choices)
    assert 'digest' in choices

# Generated at 2022-06-23 18:42:57.582438
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(list(iter(_AuthTypeLazyChoices()))) == 0
AUTH_TYPES = _AuthTypeLazyChoices()
del _AuthTypeLazyChoices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=AUTH_TYPES,
    help='''
    The authentication protocol.
    Default: {0}

    '''.format(DEFAULT_AUTH_PLUGIN_NAME),
)

# Generated at 2022-06-23 18:43:00.588970
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bearer' in _AuthTypeLazyChoices()

_auth_type_validator = AuthPluginTypeValidator()



# Generated at 2022-06-23 18:43:12.062110
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert(_AuthTypeLazyChoices().__iter__() ==
           sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    help='''
    Use the specified auth plugin instead of trying to guess.

    Available plugins: {0}

    '''.format(', '.join(auth_type_choices)),
    choices=auth_type_choices
)

# Generated at 2022-06-23 18:43:23.506103
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(self.__contains__())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    By default, HTTPie attempts to detect the authentication type from the
    given credentials. Use this option to manually specify the authentication
    type if it wasn't detected properly, or if you want to make HTTPie
    explicitly use a particular type of authentication.

    This is helpful in cases where the credentials contain special characters
    that could be interpreted as the basic auth delimiter.

    Available types:

        {auth_types}

    '''.format(
        auth_types=sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )
)


#######################################################################
# HTTP

# Generated at 2022-06-23 18:43:34.576829
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping())
    assert 'NoAuth' in choices
    assert 'Basic' in choices
    assert 'Digest' in choices


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify the authentication mechanism.

    '''
)
auth.add_argument(
    '--auth-scheme',
    metavar='SCHEME',
    help='''
    Specify the authentication scheme to use, e.g., Basic, Digest.

    '''
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group

# Generated at 2022-06-23 18:43:36.359920
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert AVAILABLE_AUTH_PLUGINS == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:43:42.310801
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The available mechanisms are:

        {choices}

    See the full documentation for more details:
    https://httpie.org/docs#authentication

    '''.format(
        choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)

#######################################################################
# Input options
#######################################################################

input_options = parser.add_argument_group(title='Input Options')


# Generated at 2022-06-23 18:43:45.766869
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(_AuthTypeLazyChoices(), '__contains__')


# Generated at 2022-06-23 18:43:49.339216
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:51.570600
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for key in _AuthTypeLazyChoices():
        assert key in plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-23 18:43:58.919992
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # GIVEN
    choices = _AuthTypeLazyChoices()
    # THEN
    for item in plugins.builtin_auth_plugins:
        assert item in choices
    assert 'missing_auth' not in choices


auth.add_argument(
    '--auth-type',
    # TODO: generate the help dynamically
    help='''
    The name of a plugin for configuring the Authorization header.
    Supported plugins:

        {builtin_auth_plugins}
    '''.format(builtin_auth_plugins=', '.join(plugins.builtin_auth_plugins)),
    choices=_AuthTypeLazyChoices(),
)

#######################################################################



# Generated at 2022-06-23 18:44:10.854830
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    instance = _AuthTypeLazyChoices()
    assert 'digest' in instance

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly set the authentication type of the credential provided in --auth.
    Supported types:

        'basic'
        'digest'

    The default is to inspect the credential for a colon to determine the type
    (i.e., 'basic' when it contains a colon, and 'digest' otherwise).

    '''
)
auth.add_argument(
    '--auth-host',
    metavar='HOST',
    help='''
    Used with --auth-type digest to specify the host to obtain the
    credentials from.

    '''
)

#######################################################################
# HTTP related options

# Generated at 2022-06-23 18:44:23.141365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    for k in ['basic', 'digest']:
        assert k in lazy_choices


auth.add_argument(
    '--auth-type',
    type=str,
    default=AUTH_TYPE_DEFAULT,
    # Make sure this is a set that can be extended by plugins.
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. This can be one of:

      * Basic (default)
      * Digest

    If --auth is provided without --auth-type, then the mechanism is guessed
    based on the --auth value.

    ''',
)

# Generated at 2022-06-23 18:44:25.132178
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'something' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:27.737511
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:44:38.841408
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager._load_plugins()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    actual = sorted(auth_type_lazy_choices)
    expected = sorted(['digest', 'jwt'])
    assert actual == expected


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.
    Available choices: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    {plugin_manager.get_auth_plugin_help_strings()}

    '''
)

# Generated at 2022-06-23 18:44:50.825847
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'idcs' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    help='''
    Specifies which HTTPie authentication plugin should be used.
    If set to "auto" and --auth is present, then the plugin
    will be guessed based on the --auth value.
    The following plugins are available:

        {available_plugins}

    '''.format(
        available_plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in
            wrap(', '.join(_AuthTypeLazyChoices()), 60)
        ).strip()
    ),
    choices=_AuthTypeLazyChoices(),
)

# Generated at 2022-06-23 18:44:59.357315
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.load_builtin_plugins()
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin to be used.
    List of builtin plugins (case insensitive):

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Plugin can also be an entry point, e.g.:

        {'--auth-type=foo:bar' if os.name == 'nt' else '--auth-type=foo:bar.baz'}

    '''
)

# Generated at 2022-06-23 18:45:07.858926
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    #TODO: Capture logger output
    plugin_manager._discover()
    try:
        assert (list(_AuthTypeLazyChoices())
                == list(plugin_manager.get_auth_plugin_mapping().keys()))
    finally:
        plugin_manager._forget()

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, the plugin
    attempts to infer it from --auth.

    '''
)

# Generated at 2022-06-23 18:45:21.338160
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'httpbasic' in _AuthTypeLazyChoices()
    assert 'some_random' not in _AuthTypeLazyChoices()
auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    Force usage of the given authentication plugin.
    This can be either a plugin name or an alias.
    See the {docs_url} for more details.
    '''.format(docs_url=DOCS_AUTH_URL)
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:45:26.325762
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        assert [key for key in _AuthTypeLazyChoices()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    except AssertionError as e:
        print("\033[1;31m Test failed for _AuthTypeLazyChoices.__iter__():\033[0m\n", e)
test__AuthTypeLazyChoices___iter__()


# Generated at 2022-06-23 18:45:28.717925
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    wsse = _AuthTypeLazyChoices()
    assert 'wsse' in wsse
    assert 'foo' not in wsse
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-23 18:45:34.583943
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    dest='auth_no_challenge',
    help='''
    Do not allow HTTPie to send the initial unauthenticated request to
    see if the server supports authentication.

    '''
)

#######################################################################
# Initial HTTP(S) proxy.
#######################################################################



# Generated at 2022-06-23 18:45:45.564073
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Bearer' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify an authentication plugin.
    Available plugins: {', '.join(_AuthTypeLazyChoices())}

    '''
)

# Generated at 2022-06-23 18:45:58.402159
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth = _AuthTypeLazyChoices()
    assert 'basic' in auth
    assert 'http' in auth
    assert 'plugin1' in auth
    assert 'plugin2' in auth
    assert 'plugin3' not in auth
    assert sorted(auth) == ['basic', 'http', 'plugin1', 'plugin2']

auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-23 18:46:01.130904
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:04.784802
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert set(choices) == set(plugin_manager.get_auth_plugin_mapping())
test__AuthTypeLazyChoices___iter__()


# Generated at 2022-06-23 18:46:14.998756
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
     assert 'digest' in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=str.lower,
    help='''
    The authentication mechanism to be used. Currently supported:

        {0}

    If not specified, HTTPie tries them all and uses whatever
    works. For example, with --auth-type=digest it fails if the server
    doesn't support Digest authentication.

    Plugins may register support for more types.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')
proxy.add_argument

# Generated at 2022-06-23 18:46:22.628683
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['digest', 'jwt', 'hawk']) == [elem for elem in _AuthTypeLazyChoices()]

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The guessed mechanism is used by
    default.

    '''
)
# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    The HTTP endpoint for obtaining an authentication token.

    '''
)

# Generated at 2022-06-23 18:46:35.394451
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    # just check that it returns something
    assert iter(a)

    with plugin_manager.add_plugin_dir(''):
        assert tuple(a) == ()

    with plugin_manager.add_plugin_dir(os.path.join(os.path.dirname(__file__),
                                                    'test_plugins')):
        assert tuple(a) == ('method-name',)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,  # default value is handled in the HTTPie arguments parser
    help='''
    Tell HTTPie which auth plugin to use. If not specified, it
    will be guessed from the provided --auth value.

    '''
)


# Generated at 2022-06-23 18:46:45.453180
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'something' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The method to use for authentication. Available choices depend on the
    installed plugins. "auto" means that HTTPie will try to auto-detect auth
    type. The default is "auto".

    '''
)

auth.add_argument(
    '--auth-query-param',
    metavar='PARAM_NAME',
    help='''
    The query parameter name to use for the token if auth type is "bearer".
    '''
)

# `requests.

# Generated at 2022-06-23 18:46:56.354128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.
    By default, HTTPie will try to determine the
    best mechanism from the server's response.

    '''
)

# If you update this, check the argparse doc to make sure it's still valid.

# Generated at 2022-06-23 18:47:07.269519
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
_AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices,
    default=None,
    help='''
    Explicitly specify the authentication mechanism to be used.
    Useful for authentication plugins that don't follow the
    Basic/Digest scheme.

    ''',
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-23 18:47:19.470706
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(auth_plugins)


# Generated at 2022-06-23 18:47:30.014070
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert list(choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force using the specified HTTP authentication mechanism.
    Supported: %s

    '''.strip() % ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
)

#######################################################################
# Verification and certificate handling
#######################################################################

verify = parser.add_argument_group(title='SSL/TLS Verification')