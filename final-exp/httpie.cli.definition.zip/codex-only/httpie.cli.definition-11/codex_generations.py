

# Generated at 2022-06-23 18:37:35.698320
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=AuthPluginController.make_auth_type_validator(),
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    The two built-in mechanisms are "basic" and "digest".

    '''
)

# Generated at 2022-06-23 18:37:42.531222
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    _AuthTypeLazyChoices.__iter__()
    """
    # Note: This test is not included into default test suite because of
    # complexity of mocking plugin manager

    from httpie.plugins import auth
    auth_plugin_mapping = {'MyAuthType': auth.MyAuthPlugin}
    with patch('httpie.cli.parser._auth_type_lazy_choices.plugin_manager'
               '.get_auth_plugin_mapping') as func:
        func.return_value = auth_plugin_mapping
        assert list(_AuthTypeLazyChoices()) == list(auth_plugin_mapping)


# Generated at 2022-06-23 18:37:44.968099
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'my_auth_type' in _AuthTypeLazyChoices()
    assert 'my_auth_type' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:37:49.378480
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'bearer',
        'hawk',
        'ntlm',
        'aws'
    ]


# Generated at 2022-06-23 18:37:58.716573
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin instead of the default auth handling.

    '''
)

# Plugins have been supported since v1.0, but the --auth-plugin
# option was still used for a certain period of time. TODO: drop
# it altogether in v2.0

# Generated at 2022-06-23 18:38:09.466723
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The value is a string representing a plugin module (e.g. "digest").

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help=''',
    Tell the server that the client will not follow challenges.
    This is useful when using auth plugins that expect to be able
    to access the error response and overwrite HTTPie's normal
    behaviour.
    '''
)


#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:38:20.674710
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert [choice for choice in choices] == [plugin.name for plugin in sorted(plugin_manager.get_auth_plugin_mapping().values())]

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    To see all auth plugins and their options:

        http --debug

    '''
)


#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:38:22.966366
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk', 'netrc']

# Generated at 2022-06-23 18:38:33.725364
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    iter(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:38:46.075916
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(choices)
    assert 'basic' in choices


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism for the request. Defaults to "auto", which refers to the
    HTTPie default. You can also specify a particular auth plugin.

    '''
)


# Generated at 2022-06-23 18:38:47.298740
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices



# Generated at 2022-06-23 18:38:55.685919
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    Run `http --debug` for a list of available plugins.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Do not send an initial challenge with requests.

    This improves interoperability with non-compliant servers.

    '''
)

# Generated at 2022-06-23 18:39:06.556189
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['Basic', 'Digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Note that the supplied credentials, if any,
    are sent in plain text to the server even when using mechanisms that
    employ encryption.

    This option is experimental and should be used for testing purposes only.
    ''',
)
auth.add_argument(
    '--auth-host',
    type=str,
    metavar='HOST',
    default=None,
    help='''
    Host to use for authentication.  Use --auth-host="" to match all hosts
    (the default).

    '''
)

# Generated at 2022-06-23 18:39:11.271238
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'custom' in lazy_choices
    assert 'nonexistent' not in lazy_choices


# Generated at 2022-06-23 18:39:12.835701
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:15.737467
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    '''Unit test for method __iter__ of class _AuthTypeLazyChoices'''
    choices = _AuthTypeLazyChoices()
    assert sorted(['digest', 'jwt', 'hawk']) == list(choices)

# Generated at 2022-06-23 18:39:27.264252
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['basic', 'digest']) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    type=lambda plugin_name: plugin_manager.load_plugin(
        'auth',
        plugin_name
    ),
    default='basic',
    # Overriding choices to mirror the runtime implementation by passing in a
    # callable to the type argument of argparse.
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Default: %(default)s.
    Available types: {', '.join(sorted(_AuthTypeLazyChoices()))}.

    ''',
)

# Generated at 2022-06-23 18:39:34.568993
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    assert 'basic' in lazy
    assert 'digest' in lazy
    assert 'hmac' in lazy
    assert 'discord' not in lazy
    assert ['basic', 'digest', 'hmac'] == sorted(lazy)


auth.add_argument(
    '--auth-type', '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism.

    Currently supported mechanisms include:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}.

    ''',
)

# Generated at 2022-06-23 18:39:37.337537
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = 'bearer'
    choices = _AuthTypeLazyChoices()
    assert auth_type in choices

# Generated at 2022-06-23 18:39:39.452530
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:43.099510
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert "basic" in auth_type_lazy_choices


# Generated at 2022-06-23 18:39:48.219543
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=defaults.AUTHENTICATION_TYPE,
    help=f'''
    The authentication mechanism to be used. If not specified, the default is
    "basic".

    HTTPie can act as a client for {len(plugin_manager.get_auth_plugin_mapping())}
    authentication plugins:

    {auth_plugins_help(plugin_manager.get_auth_plugin_mapping())}

    Authentication plugins that work with all HTTP methods:
    oauth1, oauth1-session, hmacauth

    '''
)

# Generated at 2022-06-23 18:39:52.980648
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:39:54.671191
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:39:57.436616
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices


# Generated at 2022-06-23 18:40:05.836945
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1', 'sigv4']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use.

    The default is "netrc" if netrc files are enabled and the requested host
    is configured in one of them. Otherwise, the default is "basic".

    The following authentication methods are available as plugins:

        {plugin_list}

    '''.format(plugin_list=format_plugin_list(plugin_manager.get_auth_plugin_mapping())),
)


# Generated at 2022-06-23 18:40:08.584913
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:40:18.967536
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        auth_type for auth_type in _AuthTypeLazyChoices()
    ] == [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
    ]

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Available choices: {choice_list}

    The default is "basic".

    '''.format(
        choice_list=', '.join(sorted(_AuthTypeLazyChoices()))
    ),
)

# Generated at 2022-06-23 18:40:21.070404
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices.__iter__()

# Generated at 2022-06-23 18:40:29.652540
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type', '--auth-plugin',
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    default='basic',
    help='''
    The authentication mechanism to be used.

    It defaults to "basic" and looks for a plugin named "httpie-auth-<NAME>".

    ''',
)

plugins = plugin_manager.get_auth_plugin_mapping()
for name, cls in plugins.items():
    for arg_name, arg_default, arg_help in cls.get_auth_args():
        arg_kwargs = {}

# Generated at 2022-06-23 18:40:31.625812
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest1' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:40:41.666092
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert sorted(lazy_choices) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())
    assert all(item in lazy_choices for item in
               plugin_manager.get_auth_plugin_mapping().keys())
# End test



# Generated at 2022-06-23 18:40:50.248708
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Container)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help='''
    The authentication type to use. It can either be a builtin
    (one of basic, digest) or a plugin name.

    If not specified, it will be guessed from the provided --auth value.

    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-verify',
    metavar='yes|no',
    default=None,
    help='''
    Whether to verify the server certificate. Default is yes.

    '''
)

#######################################################################
# User

# Generated at 2022-06-23 18:41:02.727163
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import doctest
    from httpie.plugins import builtin
    from httpie.plugins.builtin import AuthPlugin
    plugin_manager.get_auth_plugin_mapping().update({
        'test1': lambda: AuthPlugin(),
        'test2': lambda: AuthPlugin(),
        'test3': lambda: AuthPlugin(),
    })
    assert _AuthTypeLazyChoices().__contains__('test1')
    assert _AuthTypeLazyChoices().__contains__('test3')
    assert not _AuthTypeLazyChoices().__contains__('test4')
    assert 'test1' in _AuthTypeLazyChoices()
    assert 'test2' in _AuthTypeLazyChoices()
    assert 'test3' in _AuthTypeLazyChoices()
    assert 'test1' in _AuthTypeLazy

# Generated at 2022-06-23 18:41:08.611940
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.builtin import BasicAuthPlugin
    plugin_manager.register(BasicAuthPlugin)
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'foo' not in auth_type_lazy_choices
    plugin_manager.unregister('basic')

# Generated at 2022-06-23 18:41:11.008578
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    for auth_type in ('basic', 'digest', 'hawk'):
        assert auth_type in auth_types



# Generated at 2022-06-23 18:41:21.408256
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # If the AuthPluginManager is not used correctly,
    # this could break and we need to get it right.
    # The test is used to make sure the implementation
    # is correct.
    # import json
    # print(json.dumps(list(_AuthTypeLazyChoices()), indent=4))
    # import sys
    # sys.exit(0)
    # output: ["aws-sigv4", "awsv4", "basic", "digest", "hawk", "ntlm", "oauth2"]

    lc = _AuthTypeLazyChoices()
    assert len(lc) > 0
    assert 'aws-sigv4' in lc
    assert 'awsv4' in lc
    assert 'basic' in lc
    assert 'digest' in lc
    assert 'hawk' in l

# Generated at 2022-06-23 18:41:33.767840
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    Choose the authentication mechanism. By default HTTPie tries to
    detect the auth mechanism and provides a sensible default. The
    supported values are:

    ''' + '\n'.join(
        ('* {0: <15} {1}'.format(name, auth_plugin.help or ''))
        for name, auth_plugin in sorted(plugin_manager.get_auth_plugin_mapping().items())
        if name != 'auto'
    )
)


# Generated at 2022-06-23 18:41:41.288416
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    _AuthTypeLazyChoices: __iter__()
    """
    ret = _AuthTypeLazyChoices()
    assert list(ret) == list(iter(ret))
    assert list(ret) == ['aws4', 'aws4-hmac-sha256', 'digest', 'hawk', 'netrc', 'oauth1']


# Generated at 2022-06-23 18:41:53.456175
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_choices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a particular auth mechanism.

    '''
)
auth.add_argument(
    '--proxy-auth', '-U',
    default=None,
    metavar='USER[:PASS]',
    help='''
    If only the username is provided (-U username), HTTPie will prompt
    for the password.

    ''',
)

# Generated at 2022-06-23 18:42:03.555065
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' not in auth_type_lazy_choices

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    # Filled in by the plugin manager.
    # Choices=['basic', 'digest', 'aws'],
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help='''
    The authentication plugin to use. Defaults to "basic".
    ''',
)

#######################################################################
# HTTPS, proxies
#######################################################################


# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:42:15.904207
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(item for item in _AuthTypeLazyChoices()) == set(iter(sorted(plugin_manager.get_auth_plugin_mapping().keys())))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    HTTPie features built-in support for: {auth_types}

    '''.format(
        auth_types='\n    '.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-23 18:42:27.526056
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return AuthTypeLazyChoices(True, False) # noqa

AuthTypeLazyChoices = _AuthTypeLazyChoices()  # noqa

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=AuthTypeLazyChoices,
    help='''
    Authentication type to be used. If not provided, an appropriate one is
    guessed based on the provided --auth credentials. Available types:

        {available_types}

    '''.format(
        available_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(AuthTypeLazyChoices)), 60)
        ).strip(),
    )
)


#######################################################################
# SSL

# Generated at 2022-06-23 18:42:28.793410
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:42:31.321903
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    l = _AuthTypeLazyChoices()
    l_ = list(l)
    assert l_ == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:42:44.312435
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    assert 'basic' in lazy
    assert 'digest' in lazy
    assert 'hmac' in lazy

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the auth mechanism. For example, "basic", "digest", etc.

    Defaults to "auto" which means that the auth type is auto-detected
    based on the URL.

    '''
)

# Generated at 2022-06-23 18:42:50.313264
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_objs = _AuthTypeLazyChoices()
    types_list = []
    for auth_type in auth_objs:
        assert auth_type in plugin_manager.get_auth_plugin_mapping()
        types_list.append(auth_type)
    assert sorted(types_list) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:42:55.685131
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    if 'digest' not in lazy_choices:
        raise AssertionError('__contains__ does not work for digest')
    if 'does_not_exist' in lazy_choices:
        raise AssertionError('__contains__ does not work for does_not_exist')

# Generated at 2022-06-23 18:43:09.060214
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert next(iter(lazy_choices)) == 'basic'


# TODO: --auth-type = plugin names
# TODO: --auth-type = human readable aliases (basic, digest, ...)
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=SUPPRESS
)

# ``requests.auth.HTTPBasicAuth`` keyword arguments.

basic_auth = parser.add_argument_group(title='Basic Auth options')

# Generated at 2022-06-23 18:43:14.065279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:24.582945
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'missing' not in choices


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTHPARSE_KWARGS['type'],
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type. If a matching plugin is installed,
    it will be used to authenticate. Otherwise, it will be treated as a custom
    auth scheme.

    '''
)

# Generated at 2022-06-23 18:43:28.191205
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'abc' not in lazy_choices


# Generated at 2022-06-23 18:43:29.764358
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:31.304108
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:43:39.692140
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'foo' not in choices
    assert 'Basic' in choices



# Generated at 2022-06-23 18:43:41.209685
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [2, 3] == list(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:43:51.361881
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin. Available plugins: {0}.

    You can also provide your own plugin by specifying a fully
    qualified name of a subclass of httpie.plugins.AuthPlugin.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping().keys()))
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:43:59.716679
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == {
        'basic',
        'digest',
        'hmac',
        'multi',
        'netrc',
        'oauth1',
        'oauth2',
    }

# NOTE: The description of "--auth-type" argument is generated
# dynamically in HTTPie.main.
auth.add_argument(
    '--auth-type',
    default='multi',
    choices=_AuthTypeLazyChoices(),
    help='%(default)s',
)
auth.add_argument(
    '--auth-plugin',
    dest='auth_plugin_spec',
    default='',
    help='%(default)s',
)
# NOTE: The description of "--auth-disable" argument is generated
# dynamically in HTTPie.main.

# Generated at 2022-06-23 18:44:11.286839
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # TODO: Skip only in unit tests
    if not os.getenv('HTTPIE_PLUGINS') and not os.getenv('TRAVIS_TEST_RESULT'):
        # noinspection PyUnresolvedReferences
        return pytest.skip('no plugins')
    auth = _AuthTypeLazyChoices()
    assert 'basic' in auth, '"basic" should be in plugin AuthTypeLazyChoices'



# Generated at 2022-06-23 18:44:23.172779
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    help='''
    The authentication mechanism to use. The following schemes are supported:

    {schemes}

    '''.format(
        schemes='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        )
    ),
    default=None,
    choices=_AuthTypeLazyChoices(),
)

#######################################################################
# HTTP method
#######################################################################
# ``requests.request`` keyword arguments

# Generated at 2022-06-23 18:44:24.678247
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) == set(_AuthTypeLazyChoices())

# Generated at 2022-06-23 18:44:31.961162
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins import get_auth_plugin_mapping, plugin_manager
    from tests.plugins.auto_auth import AutoAuthPlugin
    try:
        plugin_manager.prepend_plugin(AutoAuthPlugin)
        assert 'auto' in _AuthTypeLazyChoices()
    finally:
        del get_auth_plugin_mapping()[AutoAuthPlugin]


# Generated at 2022-06-23 18:44:41.885359
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    choices=auth_type_choices,
    help=f'''
    The authentication mechanism to be used. Available choices (subject to
    installed plugins) are: {auth_type_choices}.

    The default is 'basic'.

    '''
)

# Generated at 2022-06-23 18:44:52.230681
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.utils import io
    out = io.BytesIO()
    plugin_manager.print_plugin_list(out=out)
    out.seek(0)
    l = [line.rstrip(b'\r\n') for line in out]
    assert list(l)[-1] == b'auth-type-choices'
    assert b'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:44:55.274778
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'Custom' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:57.382456
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:06.584964
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    test = _AuthTypeLazyChoices()
    # Test for real world situation.
    assert list(test) == [
        'basic',
        'digest',
        'gssnegotiate',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
    ]
    # Test for  bad situation.
    plugin_manager.get_auth_plugin_mapping().pop('basic')

    assert list(test) == [
        'digest',
        'gssnegotiate',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
    ]
    # Restore for next tests.
    _register_auth()



# Generated at 2022-06-23 18:45:20.220766
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'jwt' in AuthTypeLazyChoices
    assert 'hmac' in AuthTypeLazyChoices
    assert 'basic' in AuthTypeLazyChoices
    assert 'kerberos' in AuthTypeLazyChoices
    assert 'aws' in AuthTypeLazyChoices
    assert 'digest' in AuthTypeLazyChoices
    assert 'hawk' in AuthTypeLazyChoices
    assert 'ntlm' in AuthTypeLazyChoices
    assert 'aws-sigv4' in AuthTypeLazyChoices
    assert 'digest-future' in AuthTypeLazyChoices
    assert 'digest-ie' in AuthTypeLazyChoices


# Generated at 2022-06-23 18:45:30.311135
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert bool(
        _AuthTypeLazyChoices()
    ) and bool(
        _AuthTypeLazyChoices().__contains__('digest')
    )
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Currently available:

        basic, digest, aws, oauth1

    If not provided, or "auto", the appropriate mechanism is guessed from the URL.

    ''',
)


# Generated at 2022-06-23 18:45:37.151689
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert isinstance(auth_types, _AuthTypeLazyChoices)
    assert isinstance(auth_types, collections.abc.Iterable)
    assert isinstance(auth_types, collections.abc.Container)

    assert list(auth_types) != []


# Generated at 2022-06-23 18:45:46.764630
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_classes = plugin_manager.get_auth_plugin_mapping()
    auth_types = set(auth_type_classes.keys())
    assert auth_types == set(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. By default, one is picked based on the
    provided credentials.

    '''
)
auth.add_argument(
    '--auth-endpoint',
    help='''
    URL endpoint to be used for authentication. For example,
    "https://api.example.org/auth/access_token".

    '''
)


#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:45:59.095700
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
test__AuthTypeLazyChoices___iter__()


auth_plugin = auth \
    .add_mutually_exclusive_group() \
    .add_argument(
    '--auth-type', '-t',
    action='store',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin. Alternatively to the short name, you
    can also use the full dotted import path:

        http --auth-type=basic example.org

        http --auth-type=httpie_oauth.v1:OAuth1 example.org

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:46:09.121754
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
assert test__AuthTypeLazyChoices___iter__()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used for the request.

    The available auth types depend on the installed plugins.
    For example, there's a plugin for OAuth 2.0 that adds an
    ``--auth-type=oauth2``.

    For applicable arguments, see the plugin's documentation.

    '''
)

# Generated at 2022-06-23 18:46:18.602539
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'aws4' in choices
    assert 'foo' not in choices
    assert set(choices) == set(('basic', 'digest', 'aws4'))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Used to indicate which method HTTPie should use for authorization.
    The default is "basic".

    '''
)

# Generated at 2022-06-23 18:46:21.329659
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-23 18:46:25.982498
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:37.837528
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    # Command line options for plugins (e.g., --auth-type=hawk)
    # are dynamically added at runtime.
    # They should be collected by _AuthTypeLazyChoices
    # plugin manager
    pm = plugin_manager
    pm.set_auth_plugins(pm.get_auth_plugins() + (HawkAuthPlugin,))
    assert 'hawk' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:46.676591
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of auth to use. Could be one of:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Use "{AUTO_AUTH_PLUGIN}" to automatically detect the auth scheme
    (default).

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-23 18:46:57.131749
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:46:58.565161
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:47:04.821468
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import json
    import sys
    import httpie.plugins.builtin
    from httpie.plugins import manager
    from httpie.context import Environment

    builtin = sys.modules['httpie.plugins.builtin']

    _env = Environment()
    _cli_opts = params.HTTPiePluginCommandLineOptions()
    _stdin_bytes = b''
    _stdin_isatty = True
    manager._loaded_plugins = None
    manager._instantiate_plugins(_env, _cli_opts, _stdin_bytes, _stdin_isatty)
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    manager._loaded_plugins = {}

# Generated at 2022-06-23 18:47:17.784020
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert sorted(auth_types) == ['basic', 'digest']

auth_types = auth.add_mutually_exclusive_group(required=False)
auth_types.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=plugin_manager.DEFAULT_AUTH_PLUGIN_NAME,
    help='''
    Selects the authentication mechanism (plugin) to be used. Currently
    supported plugins are: %(choices)s.

    If a plugin by the given name can't be found, the ``basic`` plugin is used.

    '''.format(choices=_AuthTypeLazyChoices()),
    type=str,
    choices=_AuthTypeLazyChoices()
)

# Generated at 2022-06-23 18:47:19.853200
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:47:25.121360
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=auth_type_choices,
    help=f'''
    The auth mechanism to use.
    The available options are:

        {', '.join(auth_type_choices)}

    '''
)

# Digest auth parameters.
auth_digest = auth.add_argument_group('Digest auth parameters')