

# Generated at 2022-06-23 18:37:35.474474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to be used. Currently supported: {0}.

    '''.format(', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ))

)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:37:44.863352
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=argparse.SUPPRESS,
)

# Generated at 2022-06-23 18:37:48.777206
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices=_AuthTypeLazyChoices()
    assert set(auth_type_lazy_choices)==set(['basic', 'digest'])


# Generated at 2022-06-23 18:37:58.319368
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # test if the plugin 'basic' is in the auth type
    assert 'basic' in _AuthTypeLazyChoices


auth_type_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=auth_type_choices,
    help=f'''
    The specific authentication type to use.

    The default is "auto" which implies that HTTPie will use the most secure of
    the following four when the username and password are both supplied:
    "basic", "digest", "ntlm", "negotiate". If only one of username or password
    is supplied, only "basic" is used.

    Supported types: {', '.join(auth_type_choices)}

    ''',
)

# Generated at 2022-06-23 18:37:59.715168
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(_AuthTypeLazyChoices.__iter__(None)) > 0


# Generated at 2022-06-23 18:38:10.661457
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type = _AuthTypeLazyChoices()
    assert list(auth_type) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))



# Generated at 2022-06-23 18:38:21.753769
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert set(_AuthTypeLazyChoices()) == set(('digest', 'hawk'))


auth_type = parser.add_argument_group(title='Authentication Type')
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. Currently supported
    authentication mechanisms include: {auth_types_list}.

    '''.format(
        auth_types_list='\n'.join(
            (8 * ' ') + line.strip() for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60)
        ).strip()
    )
)

#######################################################################
# SSL


# Generated at 2022-06-23 18:38:33.142225
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert not set(_AuthTypeLazyChoices()) - set(sorted(mapping.keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom authentication plugin.
    Type must be one of: {auth_types}
    '''.format(auth_types=', '.join(plugin_manager.get_auth_plugin_mapping()))
)


# Generated at 2022-06-23 18:38:39.552595
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    available_auth_types = _AuthTypeLazyChoices()

    assert 'digest' in available_auth_types
    assert 'bearer' in available_auth_types
    assert 'basic' in available_auth_types
    assert 'aws4-hmac-sha256' in available_auth_types
    assert 'custom-plugin' not in available_auth_types


# Generated at 2022-06-23 18:38:51.519568
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin. Valid AUTHTYPEs are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    When "auto", the most secure of basic and digest is used.

    To use a custom plugin from a path or URL, use "plugin[:path]".

    '''
)

# Generated at 2022-06-23 18:38:56.058447
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

_AUTH_TYPES = _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:38:59.406506
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=BasicAuth,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

# Generated at 2022-06-23 18:39:13.075225
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())



# Generated at 2022-06-23 18:39:24.859327
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use. The default is basic.
    Other supported values depend on the installed plugins.

    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=None,
    help=argparse.SUPPRESS
)


# Generated at 2022-06-23 18:39:28.153784
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.clear_auth_plugins()
    assert 'basic' in _AuthTypeLazyChoices()
    plugin_manager.clear_auth_plugins()
    assert 'basic' not in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:36.215567
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    supported_auth_types = _AuthTypeLazyChoices()
    # 'basic' should be a supported auth type since we support it
    assert 'basic' in supported_auth_types
    # 'foo' is not supported
    assert 'foo' not in supported_auth_types
    # 'none' should be a supported auth type since we support it
    assert 'none' in supported_auth_types

auth_type_validator = AuthTypeValidator(
    'Supported auth types: ' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)

# Generated at 2022-06-23 18:39:47.328124
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, list)

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    The auth mechanism to be used. Extend with plugins.

    By default, HTTPie tries to guess the right plugin by itself.
    The choices are:

    {0}

    '''.format(
        '\n'.join(
            sorted('    {0}{1}'.format(8 * ' ', line.strip())
                   for line in wrap(', '.join(
                       sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                       60)
                   )
        ).strip()
    )
)

#######################################################################


# Generated at 2022-06-23 18:39:59.910037
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins import plugin_manager

    auth_type_lazy_choices = _AuthTypeLazyChoices()
    with mock.patch('httpie.plugins.plugin_manager.get_auth_plugin_mapping',
                    return_value={'foo': AuthPlugin()}):
        assert 'foo' in auth_type_lazy_choices
        assert 'foo' in list(auth_type_lazy_choices)


# Generated at 2022-06-23 18:40:07.348233
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import auth_plugin_manager
    auth_plugin_manager.plugin_dir = ('~/.httpie/plugins')
    auth_plugins = _AuthTypeLazyChoices()
    assert sorted(('test', 'bearer')) == sorted(auth_plugins)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism, e.g. "basic", "digest", "ntlm", etc.
    Use `--auth-type=auto' to let HTTPie discover the auth type.

    '''
)

#######################################################################
# No options
#######################################################################

no_options = parser.add_argument_group(title='No Options')


# Generated at 2022-06-23 18:40:17.979532
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    c = _AuthTypeLazyChoices()
    assert sorted(c) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:40:26.875335
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth_plugin = parser.add_argument_group(title='Authentication Plugins')
auth_plugin.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    When set to a supported auth type, the authentication credentials are
    passed to the corresponding authentication plugin.

    Supported auth types (i.e., corresponding plugins) can be listed using:

        HTTPie --plugins

    ''',
)
#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:40:37.947421
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import httpie.plugins.builtin.auth
    assert sorted('basic digest'.split()) == sorted(list(_AuthTypeLazyChoices()))  # noqa
    httpie.plugins.builtin.auth.plugin_manager = None


authtype = auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Defaults to the one provided by the configured auth plugin,
    or to the HTTP standard's "basic" if no plugin is used.

    '''
)
authtype_no_arg_help = authtype.add_argument.__doc__

plugin_manager.load_auth_plugins()

# Generated at 2022-06-23 18:40:49.663225
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert(set(['basic']) == set(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    '''
)

# Requests auth plugin keyword arguments.
auth.add_argument(
    '--auth-endpoint',
    help='''
    An alternative URL that hosts an authentication form.
    If this URL is provided, HTTPie will visit it first,
    parse its HTML for input fields and then submit the
    form. If a login form is detected, this option can be
    omitted, as the login form endpoint is automatically
    inferred and used.

    '''
)

# Generated at 2022-06-23 18:41:02.502818
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'Basic' in auth_types
    assert 'foobar' not in auth_types
    assert list(auth_types) == ['Basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication mechanism. Use `--auth-type=help` to get
    the list of supported ones.

    '''

)


# Generated at 2022-06-23 18:41:12.737180
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for x in _AuthTypeLazyChoices():
        pass

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    Limit the authentication to a specific host.

    ''',
)
auth.add_argument(
    '--ignore-stdin',
    action='store_true',
    default=False,
    help='''
    When stdin is interactive, password can be entered by user.
    This option skips that step and it allows to use httpie in shell
    scripts to executing requests without typing password.

    ''',
)
#

# Generated at 2022-06-23 18:41:16.111327
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        plugin_manager.unload_all()
        assert 'basic' in _AuthTypeLazyChoices()
        plugin_manager.load_builtin_plugins()
        assert 'basic' in _AuthTypeLazyChoices()
    finally:
        plugin_manager.load_builtin_plugins()



# Generated at 2022-06-23 18:41:23.178781
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert ('basic' in auth_type_lazy_choices) is True
    assert ('oauth' in auth_type_lazy_choices) is False

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used.
    Available: basic, digest, oauth1, oauth2, hawk

    '''
)

# Generated at 2022-06-23 18:41:26.919068
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert sorted(iter(_AuthTypeLazyChoices())) == sorted(['basic', 'digest'])



# Generated at 2022-06-23 18:41:28.659002
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:41:40.838195
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'noauth' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:44.047898
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices.__iter__() == auth_type_lazy_choices


# Generated at 2022-06-23 18:41:46.881988
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices().__iter__() == sorted(
        ['basic', 'digest', 'hawk'])

# Generated at 2022-06-23 18:41:49.512294
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:42:00.342018
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), type({}))
    assert isinstance(_AuthTypeLazyChoices(), type([]))

auth.add_argument(
    '--auth-type',
    metavar='{username_password | digest | oauth1 | ...}',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the type of the supplied credentials.
    If not specified, the AUTH provider is guessed.

    When guessing, HTTPie first looks at the URL, and then falls back to
    the HTTP ``Authorization`` header.

    ''',
)

# Generated at 2022-06-23 18:42:08.741948
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. Supported:

        {auth_types}

    '''.format(
        auth_types=', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

#######################################################################
# Timeouts
#######################################################################

timeout = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-23 18:42:11.961900
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert "basic" in choices
    assert "digest" in choices
    assert "custom" not in choices  # Not a real plugin


# Generated at 2022-06-23 18:42:13.446044
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:42:23.895298
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = sorted(_AuthTypeLazyChoices())
    assert (items == ['basic', 'digest', 'hawk'])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication mechanism.

    The default is '{default}' (Basic HTTP Auth).

    Installed plugins:
        {plugins}

    You can write your own (pip install httpie-http2).

    '''.format(
        default=DEFAULT_AUTH_PLUGIN,
        plugins=', '.join(sorted(_AuthTypeLazyChoices()))
    )
)

#######################################################################
# User Agent
#######################################################################

user_

# Generated at 2022-06-23 18:42:33.476316
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help='''
    The authentication mechanism to be used. This option is useful only
    if the authentication mechanism is not Basic or Digest, or if you
    want to force a mechanism different from the one inferred from the
    URL or --auth option.

    The available choices are:

        {0}

    '''.format(', '.join(sorted(auth_type_choices)))
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-23 18:42:45.064524
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    instance = _AuthTypeLazyChoices()
    assert 'basic' in instance
    assert 'digest' in instance
    assert 'foo' not in instance
    assert list(instance) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Basic and Digest authentication are always builtin.

    Use --verbose to display the full list of builtin and plugin-provided
    auth types.
    '''
)

#######################################################################
# Output options
#######################################################################

output_options = parser.add_argument_group(title='Output Options')


# Generated at 2022-06-23 18:42:56.318787
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.examples.plugin_hello_world import example_plugin_class
    with plugin_manager.context() as manager:
        manager.register(example_plugin_class)
        assert example_plugin_class.name in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:43:00.767498
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'awssigv4' in auth_type_lazy_choices


# Generated at 2022-06-23 18:43:03.046930
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:43:13.223923
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bogus' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Currently supported:

    ''' + '\n'.join(
        indent_with_spaces(4)(
            '{0}{1}'.format(k, ' (default)' if k == 'auto' else '')
            for k
            in sorted(plugin_manager.get_auth_plugin_mapping().keys())
        ).strip()
    )
)


# Generated at 2022-06-23 18:43:23.512225
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    set(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force HTTPie to use a specific authentication plugin.

    '''
)
auth.add_argument(
    '--ignore-netrc', '-n',
    action='store_false',
    dest='netrc',
    default=None,
    help='''
    Do not use .netrc for loading credentials.
    '''
)

#######################################################################
# Options for plugins
#######################################################################

# http://docs.python.org/2/library/argparse.html#nargs

# Generated at 2022-06-23 18:43:34.531385
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    chooser = _AuthTypeLazyChoices()
    assert 'http' in chooser
    assert 'http' in chooser
    # Check alphabetical sorting.
    assert list(chooser) == sorted(list(chooser))


auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    metavar='name',
    help='''
    The authentication method to be used.

    By default, 'http' is used, but any installed plugin (e.g., 'digest') can be
    used as well.

    '''
)

# Generated at 2022-06-23 18:43:44.644120
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return [choice in _AuthTypeLazyChoices()
            for choice in list(_AuthTypeLazyChoices())]

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin. The {plugin.auth_plugin_title}
    plugin loads plugins from {plugin.plugin_title} format modules located in
    the {plugin.auth_plugin_location}.

    See <{plugin.auth_plugin_doc_url}> for details.

    ''',
)

# Generated at 2022-06-23 18:43:51.658902
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic']


auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication mechanism to be used. Supported mechanisms: {0} (default:
    {1})

    '''.format(', '.join(sorted(_AuthTypeLazyChoices())), DEFAULT_AUTH_PLUGIN)
)

# Generated at 2022-06-23 18:43:59.913522
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    if 'MyPluginName' not in plugin_manager.get_auth_plugin_mapping():
        raise Exception
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth type. If not specified, an attempt is made to guess it
    based on the provided credentials.
    Available choices:
        {auth_choices}

    '''.format(
        auth_choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys())))
)


# Generated at 2022-06-23 18:44:04.112912
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    >>> _AuthTypeLazyChoices().__contains__('no-such-auth-plugin')
    False
    >>> 'Basic' in _AuthTypeLazyChoices()
    True
    """



# Generated at 2022-06-23 18:44:05.887559
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:44:07.646238
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:19.605490
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import DEFAULT_PLUGIN_CONFIG
    plugin_manager.load_installed_plugins(DEFAULT_PLUGIN_CONFIG)
    return tuple(_AuthTypeLazyChoices())

auth_type_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:28.237725
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)


# Generated at 2022-06-23 18:44:39.937181
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'aws' in choices
    assert 'bearer' in choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to use, if other than Basic or Digest.
    It is a shortcut for --auth-plugin.

    '''.strip()
)


# Generated at 2022-06-23 18:44:51.575789
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    actual = list(_AuthTypeLazyChoices())
    expected = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert actual == expected
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=(
        'Auth plugin to use. Can be: {}'
    ).format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)


#######################################################################
# SSL/TLS specific options.
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:44:59.920604
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == \
        set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently supported:

        {list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default value is "basic".

    '''
)


#######################################################################
# SSL
#######################################################################

# ``requests.request`` keyword arguments.

ssl_ = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:45:08.119338
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _ATLC = _AuthTypeLazyChoices()
    assert len(list(_ATLC)) > 0

_at_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=_at_choices,
    default='auto',
    help=f'''
    The authentication mechanism to be used. The currently supported types
    are: {', '.join(sorted(_at_choices))}.

    '''
)

# ``requests.request`` keyword argument.

# Generated at 2022-06-23 18:45:11.328172
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:45:24.443480
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices

auth.add_argument(
    '--auth-type',
    action=HelpfulSubparsersAction,
    dest='auth_type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication type.

    Several types are supported out-of-the-box:

        {auth_type_help}

    However, you can install plugins that provide more types.
    Use `http --debug` to see all plugin entry points.

    '''.format(auth_type_help=auth_help(
        plugin_manager.get_auth_plugin_mapping()
    ))
)

#######################################################################
# HTTPS
#######################################################################


# Generated at 2022-06-23 18:45:24.991980
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass

# Generated at 2022-06-23 18:45:26.176694
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:33.240810
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(iter(_AuthTypeLazyChoices())) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    type=plugin_manager.get_auth_plugin_mapping().get,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication method. Only Basic and Digest authentication
    are supported natively. Custom authentication methods can be added using
    plugins, e.g., --auth-type=jwt.
    Available methods: {', '.join(plugin_manager.get_auth_plugin_mapping())}
    '''
)


# Generated at 2022-06-23 18:45:35.954569
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    return 'Basic' in choices

# Generated at 2022-06-23 18:45:46.255540
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin. Default is basic.
    To see a list of built-in plugins, use `http --debug`.

    '''
)
auth.add_argument(
    '--auth-type-force-basic-auth',
    action='store_true',
    help='''
    Force HTTP Basic Auth, even when the server doesn't advertise that it
    supports it.

    '''
)

#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-23 18:45:49.162729
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:45:54.802208
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=f'''
    The authentication mechanism to be used. Default: "auto".

    Currently available:
        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Ignore the .netrc file. This is equivalent to passing -n to curl.

    '''
)

# Generated at 2022-06-23 18:46:06.432687
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.authentication = []
    assert sorted(list(_AuthTypeLazyChoices())) == ['digest', 'jwt']
    plugin_manager.authentication = ['httpie_digest_auth']
    assert sorted(list(_AuthTypeLazyChoices())) == ['digest', 'jwt']
    plugin_manager.authentication = ['httpie_digest_auth', 'httpie_jwt_auth']
    assert sorted(list(_AuthTypeLazyChoices())) == ['digest', 'jwt']
    plugin_manager.authentication = ['httpie_jwt_auth']
    assert sorted(list(_AuthTypeLazyChoices())) == ['jwt']



# Generated at 2022-06-23 18:46:14.332346
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    @auther: Calvin
    @description: 测试检测是否包含某个认证方法
    @date: 2020-09-01
    """
    # Arrange
    lazy_choices = _AuthTypeLazyChoices()
    auth_type = 'basic'

    # Act
    result = auth_type in lazy_choices

    # Assert
    assert result == True


# Generated at 2022-06-23 18:46:15.953230
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:46:23.275827
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for __ in _AuthTypeLazyChoices():
        pass


# Generated at 2022-06-23 18:46:35.754278
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    >>> list(sorted(_AuthTypeLazyChoices()))
    ['digest', 'jwt', 'noauth', 'oauth1', 'oauth2']
    """


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism. Possible values:

        auto        (default)
        digest
        jwt
        noauth
        oauth1
        oauth2

    The ``noauth`` value can be useful for making unauthenticated requests,
    with all auth-related headers stripped from the request, which makes it
    possible to test with tools like Curl.

    '''
)


# Generated at 2022-06-23 18:46:45.710146
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices


# HTTPie supports Basic and Digest auth out of the box.
# The other auth mechanisms are supported via plugins.
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    The authentication mechanism.

    Defaults to {DEFAULT_AUTH_PLUGIN_NAME}.
    The available ones are: {', '.join(sorted(_AuthTypeLazyChoices()))}.

    '''
)

# Generated at 2022-06-23 18:46:48.687089
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-23 18:46:51.721801
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'digest' in a
    assert 'basic' in a
    assert 'fake' not in a


# Generated at 2022-06-23 18:46:53.510033
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-23 18:47:00.298962
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to be used instead of the automatically
    detected one.

    The following builtin auth types are available:

        {0}

    '''.format(
        '\n        '.join(
            str(key)
            for key in sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

#######################################################################
# Installation
#######################################################################



# Generated at 2022-06-23 18:47:10.320070
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices is not None
    assert [item for item in choices] is not None

# Authenticating with plugin-provided authentication methods, e.g., OAuth, Digest.
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    dest='auth_plugin',
    help=f'''
    Specify an auth plugin by its name.

    '''
)

# OAuth2.0 access token, e.g.:
# --auth-type=oauth2 --auth-bearer=s3cr3t

# Generated at 2022-06-23 18:47:21.068106
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices
    assert 'custom' not in auth_type_lazy_choices

auth_choices_help = (
    '\n'.join(
        '{0}{1}'.format(
            4 * ' ',
            line.strip()
        )
        for line in wrap(
            ', '.join(
                sorted(plugin_manager.get_auth_plugin_mapping().keys())
            ),
            60
        )
    )
)


# Generated at 2022-06-23 18:47:30.376056
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy = _AuthTypeLazyChoices()
    assert set(lazy) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth_plugin_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    Specify the authentication mechanism. Currently supported:

        {0}

    '''.format(''.join(
        '\n        {0}'.format(name) for name in sorted(auth_plugin_choices))
    ),
    type=str,
    choices=auth_plugin_choices,
    default=None,
)
