

# Generated at 2022-06-23 18:37:29.162905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices  # Built-in
    # Plugin
    assert 'aws' in choices


# Generated at 2022-06-23 18:37:39.847039
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used for interacting with the endpoint
    specified by -a.  Valid options include:

        none     no authentication
        basic    Basic HTTP authentication
        digest   Digest HTTP authentication

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-23 18:37:50.413289
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert hasattr(a, '__iter__')
    assert list(a) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use.

    Currently available:
        {plugin_list}

    '''.format(
        plugin_list="\n        ".join(
            plugin_manager.get_auth_plugin_mapping().keys()
        )
    )
)

# ``requests.request`` keyword arguments.

# SSL
ssl = parser.add_argument_group(title='SSL') \
    .add_mutually_exclusive

# Generated at 2022-06-23 18:37:59.493392
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(iter(_AuthTypeLazyChoices()))[0] == 'basic'

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin_name',
    help='''
    The type of HTTP authentication to use. Currently supported values: '{0}'.

    '''.format("', '".join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

proxy_auth = parser.add_argument_group(title='Proxy Authentication')
proxy_auth.add_argument(
    '--proxy-auth',
    metavar='USER[:PASS]',
    help='''
    If only the username is provided, HTTPie will prompt for the password.

    ''',
)

# Generated at 2022-06-23 18:38:07.201499
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'custom' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:18.804795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=sorted(_AuthTypeLazyChoices()) + ['auto'],
    help='''
    Select an authentication plugin. Defaults to "auto", which will use the
    best matching plugin.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Allow "preemptive" basic/digest auth, i.e., without first receiving a 401
    response. This is a more practical alternative to "--auth-type=basic".

    ''',
)

#######################################################################
#

# Generated at 2022-06-23 18:38:23.461689
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # Iterate through the values of AuthTypeLazyChoices
    assert list(auth_type_lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:38:34.081390
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test the method _AuthTypeLazyChoices.__iter__
    """
    assert (
        list(
            _AuthTypeLazyChoices()
        ) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=AuthCredentials.SEP_DEFAULT,
    type=lambda v: v.lower(),
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP auth to use (if any). For example, "basic" or "digest".
    It is an error to use this argument if --auth is not specified.

    ''',
)
#######################################################################
# Redirects.
#######################################################################

# Generated at 2022-06-23 18:38:46.382874
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'aws-sigv4' in auth_types
    assert 'aws-sigv4' in sorted(auth_types)
    assert 'aws-sigv4' in list(auth_types)
    assert len(list(auth_types)) > 5

auth_type_validator = AuthTypeValidator(
    'Use --auth-type to specify a custom authentication type.'
)
auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES[0],
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=auth_type_validator,
)

#######################################################################
# SSL
#######################################################################

ssl = parser

# Generated at 2022-06-23 18:38:50.563523
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.get_auth_plugin_mapping()
    assert __AuthTypeLazyChoices__instance__ in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:38:53.107480
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:03.120896
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'kerberos' in choices
    assert 'hawk' in choices



# Generated at 2022-06-23 18:39:15.114109
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['digest', 'basic']) == set(_AuthTypeLazyChoices())


# Generated at 2022-06-23 18:39:26.744879
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    expected = set(sorted(plugin_manager.load_plugins().keys()))
    actual = set(_AuthTypeLazyChoices())
    assert expected == actual

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Default depends on the
    authentication plugin.

    Available plugins:

        {plugins}

    '''.format(
        plugins=_list_plugins('Auth', plugin_manager.get_auth_plugins())
    )
)

#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-23 18:39:35.344758
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    help='''
    The authentication mechanism to use. This option is used only
    when the --auth option is specified.

    {example}

    The following values are allowed:

        {plugin_names}

    '''.format(
        example=Example(
            'Supply the auth type explicitly',
            text=f'http --auth-type=basic --auth=username:password https://example.org',  # noqa: E501
            color='green'
        ),
        plugin_names=list2text(list(_AuthTypeLazyChoices())),
    )
)

# Generated at 2022-06-23 18:39:46.881944
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(_AuthTypeLazyChoices())
    assert choices == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth_type_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:39:59.734523
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type', '-t',
    metavar='AUTHTYPE',
    type=AuthCredentials.validate_auth_type,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom HTTP auth type. By default, HTTPie detects the auth type
    based on the realm provided by the server. Supported auth types:

    {auth_types}

    You can also define your own auth type plugin.

    '''.format(
        auth_types='\n'.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )

)

# Generated at 2022-06-23 18:40:06.676276
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class PluginManagerMock:
        def get_auth_plugin_mapping(*args, **kwargs):
            return {'some_plugin': 'some_plugin_instance'}

    manager_mock = PluginManagerMock()
    lazy_choices_instance = _AuthTypeLazyChoices()
    lazy_choices_instance.get_auth_plugin_mapping = manager_mock.get_auth_plugin_mapping
    assert 'some_plugin' in lazy_choices_instance


# Generated at 2022-06-23 18:40:17.755200
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(iter(_AuthTypeLazyChoices()))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism and type (case-insensitive) to use
    for subsequent requests. Currently supported:

        {types}

    '''.format(types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

# Generated at 2022-06-23 18:40:21.261528
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert lazy_choices.__contains__('basic') is True
    assert lazy_choices.__contains__('unknown') is False


# Generated at 2022-06-23 18:40:29.835600
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism.
    '''
)

auth.add_argument(
    '--auth-host',
    metavar='HOST',
    default=None,
    help='''
    The host to perform the authentication against.
    '''
)


# Generated at 2022-06-23 18:40:32.466147
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Bearer' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:40:41.884192
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted({
        'basic', 'digest', 'aws', 'hawk', 'ntlm', 'oauth1'
    }))


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='{%s}' % ', '.join(
        '"%s"' % choice for choice in _AuthTypeLazyChoices()
    ),
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "auto", which
    detects and uses Basic, Digest and OAuth 1.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:40:51.146782
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert HTTPBasicAuth in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use. If not specified, an appropriate one is
    tried to be inferred from the provided --auth credentials, or guessed
    (currently only HTTP Basic without password).
    If none of above works, then HTTP Basic is used.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    By default HTTPie will look in your ~/.netrc file for credentials. 
    This option disables this behaviour.

    '''
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add

# Generated at 2022-06-23 18:41:03.211177
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type = auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an authentication type, defaults to 'auto'.
    Currently supported types:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:41:13.009621
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), list)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    The type of auth plugin to use.

    Available types: {', '.join(_AuthTypeLazyChoices())}

    '''
)

#######################################################################
# Insecure mode
#######################################################################

insecure = parser.add_argument_group(title='Insecure mode')

# Generated at 2022-06-23 18:41:14.644348
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:41:15.607057
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:22.809677
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'jwt' in choices



# Generated at 2022-06-23 18:41:35.059671
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()
    return True


# Generated at 2022-06-23 18:41:45.987910
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom authentication plugin. See https://httpie.org/plugins#authentication
    for details.

    '''
)

auth.add_argument(
    '--auth-verify',
    default=None,
    choices=[True, False, 'yes', 'no'],
    help='''
    Enable or disable peer verification when using custom authentication plugins
    (default: {0}).
    '''.format(True if DEFAULT_VERIFY else False),
)

#######################################################################
# Debug
#######################################################################

debug = parser.add_argument_

# Generated at 2022-06-23 18:41:54.030773
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for i in _AuthTypeLazyChoices():
        print(i)
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin. `auto` is special in that it will
    try to auto detect the auth type (default).

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:42:03.861363
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth type to be used. Available auth types:

        {plugin_types}
    '''.format(
        plugin_types='\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-23 18:42:16.244407
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert list(_AuthTypeLazyChoices()) == sorted(mapping)
    for key in mapping:
        assert key in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not attempt to authenticate when receiving a 401 status code.

    '''
)

#######################################################################
# https://github.com/jakubroztocil/httpie/issues/235
#######################################################################

auth.add

# Generated at 2022-06-23 18:42:22.706215
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from requests_toolbelt.sessions import BaseUrlSession
    class DummyAuthPlugin(BaseUrlSession):
        pass
    dummy_plugin = DummyAuthPlugin()
    with patch.object(plugin_manager, 'get_auth_plugin_mapping') as mock:
        mock.return_value = {'dummy': dummy_plugin}
        assert list(_AuthTypeLazyChoices()) == ['dummy']

# Generated at 2022-06-23 18:42:32.593466
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Given a _AuthTypeLazyChoices object
    lazy_choices = _AuthTypeLazyChoices()
    # When I iterate over the object
    iterated = [item for item in lazy_choices]
    # Then the returned items are sorted
    sorted = iterated == sorted(iterated)
    # And they are the auth type plugin names
    known_types = set(iterated) <= set(plugin_manager.get_auth_plugin_mapping().keys())
    # And the lengths are the same
    same_length = len(iterated) == len(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:42:44.564470
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert sorted(iter(auth_type_lazy_choices)) == ['basic', 'digest']
    assert 'bearer' not in auth_type_lazy_choices


auth.add_argument(
    '--auth-type', '-t',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='HTTP authentication type (basic, digest, bearer).'
)


#######################################################################
# SSL
#######################################################################
ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-23 18:42:55.776716
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(item in _AuthTypeLazyChoices() for item in [
        'basic', 'digest', 'aws', 'hawk'
    ])

auth.add_argument(
    '--auth-type',
    '-t',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='Force the specified authentication method.',
)

# Basic auth credentials
auth_basic = parser.add_argument_group(
    title='Basic Auth',
    description='''
    For example:

        $ http -a username:password example.org

    ''',
)

# Generated at 2022-06-23 18:43:09.246386
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # This test is needed to make sure that the class constructor isn't broken
    # because it relies on a singleton class, which will mess up the test
    # results if the class isn't activated correctly at the beginning of the
    # test suite.
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'hawk' in auth_type
    assert 'aws' in auth_type
    assert 'hmac' in auth_type
    assert 'jwt' in auth_type

add_auth_type_help_argument(auth)
auth_type_choices_default_from_docopt = 'basic'

# Generated at 2022-06-23 18:43:21.605074
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

auth_type_validator = AuthTypeValidator(
    'Invalid authentication type. Supported types: {0}.'
    .format(', '.join(_AuthTypeLazyChoices()))
)

auth.add_argument(
    '--auth-type', '-t',
    type=auth_type_validator,
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently supported:

        {', '.join(sorted(_AuthTypeLazyChoices()))}

    If not specified, the client will try to use the most secure one
    it supports based on the received WWW-Authenticate headers.

    '''
)


# Generated at 2022-06-23 18:43:33.016049
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(_AuthTypeLazyChoices()) > 0
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use. Run `http --auth-type=` _TAB_ to see options.

    To enable a plugin, run `http --debug plugins install <name>`.
    To disable a plugin, run `http --debug plugins uninstall <name>`.
    To list all plugins, run `http --debug plugins list`.

    The default value is "auto", which tries to infer the auth type from
    the URL or the previous authentication exchanges.

    '''
)
auth_plugin = parser.add_argument_group(title='Auth Plugin Options')

# Generated at 2022-06-23 18:43:34.357478
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']



# Generated at 2022-06-23 18:43:35.779357
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:43:37.294061
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'oauth1' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:40.514911
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin-foo-bar' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:43:52.537190
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='NAME',
    type=AuthPluginNameValidator(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    Select a custom authentication plugin (the default is {default}).

    Available: {choices}.

    Plugins are loaded by their name, which is defined in their
    entry point in setup.py

    Authentication plugins read the credentials from either the URL or an
    Authorization header.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)

# Generated at 2022-06-23 18:43:53.864343
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:44:00.254077
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for plugin_info in plugin_manager.get_auth_plugin_mapping().values():
        assert plugin_info.name in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the authentication plugin. It can be one of the following:

        ''' + '\n        '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())) + '''\n

    If this option is not specified, HTTPie tries to guess the auth type by
    inspecting the given credentials.

    '''
)


# Generated at 2022-06-23 18:44:11.616271
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'basic' in auth_types

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to use. A list of available auth plugins
    can be obtained with the ``--debug`` flag.

    '''
)

#######################################################################
# Initial request options
#######################################################################
init_request = parser.add_argument_group(title='Initial Request Options')


# Generated at 2022-06-23 18:44:19.273298
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [i for i in _AuthTypeLazyChoices()]


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an authentication plugin. Available options:

        {available_auth_types}

    If unspecified, HTTPie will attempt to guess which auth plugin to use.

    '''.format(available_auth_types=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)
auth.add_argument(
    '--ignore-netrc',
    default=False,
    action='store_true',
    help='''
    Prevent HTTPie from loading netrc credentials.

    '''
)

# Generated at 2022-06-23 18:44:23.172221
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices"""

    # Code fragment from class _AuthTypeLazyChoices.
    def __contains__(self, item):
        return item in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-23 18:44:28.728887
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    # We need a sorted set to make it deterministic.
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the auth type. One of:

        {choices}

    '''.format(
        choices='\n        '.join(sorted(_AuthTypeLazyChoices()))
    )
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    metavar='PLUGIN_NAME',
    help='''
    Specify the name of an auth plugin to use.

    '''
)

#######################################################################
# follow
#######################################################################

follow = parser

# Generated at 2022-06-23 18:44:33.459148
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom-plugin-name' in choices
_AuthTypeLazyChoices.test = test__AuthTypeLazyChoices___contains__


# Generated at 2022-06-23 18:44:35.078820
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:44:39.473775
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'OAuth2' in auth_type_lazy_choices
    assert 'data' in auth_type_lazy_choices

# Generated at 2022-06-23 18:44:51.067557
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin (instead of the default HTTP Basic).

    The plugin is searched for in the following locations:

      1. A built-in plugin module.

      2. A plugin file specified by its path.

      3. A plugin module/package namespace.

    If more than one plugin matches, then the first one is used.

    Plugins can be used also to tweak the default HTTP Basic Auth by specifying
    it as the plugin (e.g., -t basic).

    ''',
)


# Generated at 2022-06-23 18:45:03.108983
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    The following authentication mechanisms are builtin:

    {auth_help}

    You can extend HTTPie with custom authentication plugins.
    See https://github.com/jkbrzt/httpie#authentication for details.

    '''.format(auth_help=indent(create_auth_help(), initial_indent='        ',
                                subsequent_indent='        '))
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-23 18:45:05.391336
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-23 18:45:07.060453
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:45:12.566476
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'fake' not in choices


# Generated at 2022-06-23 18:45:14.276674
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:26.678469
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:45:33.108286
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'plugins' in plugin_manager.get_auth_plugin_mapping()
    assert 'plugins' in _AuthTypeLazyChoices()
    assert 'plugins' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism, e.g. 'digest'
    or 'bearer-token'.

    '''
)

#######################################################################
# HTTP/2
#######################################################################

h2_group = parser.add_argument_group(title='HTTP/2')

# Generated at 2022-06-23 18:45:35.157854
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:45:40.555505
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The mechanism for providing the credentials.

    The default is "basic".

    Other supported mechanisms are "digest" and "ntlm". Note that NTLM
    requires additional dependencies (`pip install requests[ntlm]`).

    '''
)


#######################################################################
# Cookies
#######################################################################

cookie_options = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-23 18:45:49.099294
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk', 'jwt']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use.

    Choices are: {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-23 18:46:00.366526
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth_arg = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. For Basic, enter an api key as the
    password. Specify "basic" or "digest".

    ''',
)
auth_arg.completer = AuthTypeCompleter()


# Generated at 2022-06-23 18:46:01.157671
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = set(_AuthTypeLazyChoices())
    assert choices


# Generated at 2022-06-23 18:46:12.191935
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(iter(_AuthTypeLazyChoices())) == set(plugin_manager.get_auth_plugin_mapping().keys())

plugin_manager = PluginManager(
    namespace='httpie.plugins.auth',
)

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    If not specified, an appropriate one is automatically selected.

    The following auth types are supported:
        {0}'''.format(
        indent(', '.join(plugin_manager.get_auth_plugin_mapping()), 4 * ' ')
    )
)


#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-23 18:46:20.852400
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use. If not specified, HTTPie tries to find
    the most suitable plugin based on provided credentials and the
    target URL.

    '''
)
for type_, kwargs in plugin_manager.get_plugin_options('auth').items():
    auth.add_argument(**kwargs)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='HTTP(S) Proxy')

# Generated at 2022-06-23 18:46:34.158355
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:46:44.492998
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_plugin_type = auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. Default is 'auto', which means that HTTPie
    will try to auto-detect the scheme based on the --auth option value.
    Supported auth schemes: {supported}.

    '''.format(supported=', '.join(_AuthTypeLazyChoices()))
)
auth_plugin_type.completer = AuthPluginTypeCompleter()

#######################################################################
# Authorization header
#######################################################################


# Generated at 2022-06-23 18:46:55.537526
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:47:06.413088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices."""
    lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(lazy_choices, collections.abc.Iterable)
    assert set(lazy_choices) == set(plugin_manager.get_auth_plugin_mapping())

auth_type = auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
)
auth_type.completer = plugin_name_completer('auth-plugins')


# Generated at 2022-06-23 18:47:18.766365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert [item for item in _AuthTypeLazyChoices()] == []


auth_type = auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin by its import path.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    By default, HTTPie follows 3xx redirects as well as 401 responses to
    negotiate authentication credentials with the server. With
    --auth-no-challenge, neither of these are done.

    '''
)



# Generated at 2022-06-23 18:47:29.736675
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' in _AuthTypeLazyChoices()


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose the authentication mechanism.

    If not specified, an appropriate one is chosen based on the provided
    credentials, i.e., --auth-type=auto.
    ''',
)
