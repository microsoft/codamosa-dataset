

# Generated at 2022-06-23 18:37:37.672399
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == ('basic', 'digest', 'hawk', 'ntlm')

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Authentication method to use. By default, HTTPie will try to use the
    best [1] method based on the provided credentials, or fallback to basic
    auth if none are provided.

    To learn about supported auth types, type: http --help-auth

    [1] = Order of preference: digest, basic.

    '''
)

# Generated at 2022-06-23 18:37:44.126525
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import unittest
    # pylint: disable=unused-variable
    class PluginTests(unittest.TestCase):
        # pylint: enable=unused-variable
        def test_plugin_auth_type(self):
            # pylint: disable=protected-access
            assert plugin_manager.get_auth_plugin_mapping().keys() == \
                [i for i in _AuthTypeLazyChoices()]
            # pylint: enable=protected-access
    from httpie.context import Environment
    from httpie.plugins import BuiltinPlugin, plugin_manager
    Environment.config_dir = os.devnull
    plugin_manager.auto_discover()
    plugin_manager.load_builtin_plugins()
    test_plugin = BuiltinPlugin('test_plugin', 'tests.test_plugin')

# Generated at 2022-06-23 18:37:55.050949
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for choice in auth_type_lazy_choices:
        assert choice in plugin_manager.get_auth_plugin_mapping()
    assert len(list(auth_type_lazy_choices)) == \
        len(plugin_manager.get_auth_plugin_mapping())

# https://github.com/jakubroztocil/httpie/issues/235
# https://github.com/jakubroztocil/httpie/issues/603
# https://github.com/jakubroztocil/httpie/issues/460

# Generated at 2022-06-23 18:38:01.257715
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Type of auth plugin to use. Without this option and without the
    "--auth" option, an attempt is made to use the "netrc" plugin.

    Use --debug to view a list of paths tried.

    '''
)

# Generated at 2022-06-23 18:38:03.729262
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()  # noqa: WPS437



# Generated at 2022-06-23 18:38:05.771470
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    c = _AuthTypeLazyChoices()
    list(iter(c))
    assert True


# Generated at 2022-06-23 18:38:07.843410
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['bearer', 'digest', 'hawk']



# Generated at 2022-06-23 18:38:19.654363
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for item in choices:
        assert item in choices
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified HTTP authentication type (Basic, Digest, etc).
    The default is Basic, which is generally the only one that
    works across all HTTP libraries.

    ''',
)

# Generated at 2022-06-23 18:38:31.713976
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

# ``requests.auth.HTTPBasicAuth`` keyword arguments.

# Generated at 2022-06-23 18:38:33.792120
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'invalid' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:38:46.076141
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

# Help text prefix for the --auth-type option.
AUTH_TYPE_HELP_PREFIX = (
    '\n'.join([
        'The type of the auth credentials.',
        'Default is basic, which sends the credentials in the HTTP Basic Auth'
        ' format.',
        '',
    ]))

# Help text postfix for the --auth-type option.

# Generated at 2022-06-23 18:38:47.880897
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choice = _AuthTypeLazyChoices()
    for name in ('Basic', 'Digest'):
        assert (name in choice)


# Generated at 2022-06-23 18:38:59.356933
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth plugin to use. Contains all auth plugins discovered via
    entry points, as well as the builtin 'basic', and 'digest'.
    If no auth plugin is specified, and --auth is used, then the plugin will
    default to 'basic' or 'digest' depending on the server challenge.

    '''
)

# Generated at 2022-06-23 18:39:01.489566
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('custom')


# Generated at 2022-06-23 18:39:14.320706
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The backend plugin to use for authentication. Available choices:

     {plugin_manager.get_auth_plugin_choices_help()}

    '''
)

# Generated at 2022-06-23 18:39:26.089070
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ('basic' in _AuthTypeLazyChoices()) == (
        'basic' in sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication mechanism.
    The available types are:

        {auth_types}

    '''.format(auth_types='\n'.join(
        (4 * ' ') + auth for auth in sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        )
    ).strip())
)


#######################################################################
# Client authentication
#######################################################################

client_certs = parser.add_argument_

# Generated at 2022-06-23 18:39:35.149205
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert bool(set(_AuthTypeLazyChoices()) - set(mapping)) is False

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    A value of "auto" will attempt multiple types of authentication.
    When specified, this option overrides the implicit mechanism chosen
    by HTTPie, which depends on the --auth option.

    '''
)


# Generated at 2022-06-23 18:39:46.853376
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_auth_type_lazy_choices,
    help='''
    (experimental) Auth plugin to use.

    The default value, "auto", will try to auto-detect auth type
    from the server response.

    The available options are currently:

    {options}

    '''.format(
        options='\n'.join(
            '    ' + line.strip()
            for line in wrap(', '.join(_auth_type_lazy_choices), 60)
        )
    )
)

#######################################################################
# HTTP(S) Proxy
################################################################

# Generated at 2022-06-23 18:39:57.465170
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(iter(_AuthTypeLazyChoices()), list)
    assert len(iter(_AuthTypeLazyChoices())) == 0

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies the authentication mechanism to be used.
    Only relevant if --auth is also specified.

    Accepted values are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    For more details, run:

        http --auth-type=<NAME> --help

    '''
)

# Generated at 2022-06-23 18:40:05.816718
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.get_auth_plugin_class,
    default=AuthCredentials,
    help='''
    The authentication mechanism to use. The value can be "basic" (the default),
    "digest", or an authentication plugin module name.

    ''',
    choices=_AuthTypeLazyChoices(),
)

#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP')


# Generated at 2022-06-23 18:40:16.690716
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin. The default is HTTP Basic auth.
    Other options include 'digest', 'aws', 'ntlm'.

    If a custom plugin is specified, the plugin must be installed
    separately. See: https://httpie.org/docs/plugins#authentication

    '''
)

#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_group(title='HTTPS')

# Generated at 2022-06-23 18:40:26.709407
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():  # noqa
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'auto' in choices
    assert 'custom' in choices
    assert 'no-auth' in choices
    assert 'the-missing-plugin' not in choices
    assert sorted(choices) == ['auto', 'basic', 'custom', 'digest', 'no-auth']

# Generated at 2022-06-23 18:40:37.867888
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an (authentication) plugin. The default, none means that
    HTTPie looks for an auth plugin by examining the URL,
    and if none found, no authentication is attempted.

    The following auth plugins are available:

        {plugins}

    '''.format(
        plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-23 18:40:49.628825
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    assert isinstance(auth_type_lazy_choices, Iterable)
    assert len(list(auth_type_lazy_choices)) > 0
    assert 'basic' in auth_type_lazy_choices
    assert 'aws4' in auth_type_lazy_choices
    assert 'aws4.testserver' in auth_type_lazy_choices
    assert 'aws4.testserver.other' in auth_type_lazy_choices



# Generated at 2022-06-23 18:41:02.456437
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping()))


auth._auth_type_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:41:12.700968
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(AuthCredentials.TYPES)

auth_prompt = auth.add_mutually_exclusive_group()
auth_prompt.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. The supported mechanisms are:

        {list(AuthCredentials.TYPES)}

    The default is "{DEFAULT_AUTH_PLUGIN}".

    When this option is not specified for explicit auth (--auth),
    the plugin is determined automatically.

    Some auth plugins might require additional options,
    see --auth-type=PLUGIN --help.

    '''
)

# Generated at 2022-06-23 18:41:20.461292
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use. Run `http --auth-type=plugin-name -h` to
    see the plugin-specific help.

    ''',
)

#######################################################################
# HTTP protocol options
#######################################################################

http = parser.add_argument_group(title='HTTP Protocol Options')

# Generated at 2022-06-23 18:41:32.739211
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager_orig = plugin_manager
    try:
        plugin_manager_mock = mock.MagicMock(spec=PluginManager)
        plugin_manager_mock.get_auth_plugin_mapping.return_value = {'a':'a','b':'b'}
        AuthTypeLazyChoices = _AuthTypeLazyChoices
        AuthTypeLazyChoices.__contains__('a', plugin_manager_mock)
        AuthTypeLazyChoices.__contains__('b', plugin_manager_mock)
        AuthTypeLazyChoices.__contains__('c', plugin_manager_mock)
        plugin_manager_mock.get_auth_plugin_mapping.assert_called_once_with()
    finally:
        plugin_manager = plugin_manager_orig


# Unit

# Generated at 2022-06-23 18:41:40.471754
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

###########################################################################
# Custom Auth plugin
###########################################################################

auth_plugin = parser.add_argument_group(
    title='Custom Authentication Plugin Options')

auth_plugin.add_argument(
    '--auth-type',
    type=str,
    help=('Authentication plugin type for making custom authentication plugin.'
    )
)
auth_plugin.add_argument(
    '--auth-verify-ssl',
    type=bool,
    help=('Verification of SSL certificate while custom authentication'
    )
)

# Generated at 2022-06-23 18:41:41.759692
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest'
    ]

# Generated at 2022-06-23 18:41:54.178111
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:42:03.946722
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Explicitly specify an auth plugin.
    The default is to auto detect the auth plugin.

    '''
)

#######################################################################
# Files.
#######################################################################

files = parser.add_argument_group(title='Files')


# Generated at 2022-06-23 18:42:16.288541
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # pylint: disable=invalid-name
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. The "auto" auth type (default) will
    attempt to auto-detect the type.

    The following schemes are supported:

        {" ".join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-23 18:42:17.649918
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:42:21.167169
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices().__iter__() == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-23 18:42:22.132212
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert '__auth__' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:24.543251
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:27.372750
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    atl_c = _AuthTypeLazyChoices()
    assert list(atl_c) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-23 18:42:29.518602
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:42:42.268702
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__()
_AuthTypeLazyChoices = _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:42:44.333764
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices

# Generated at 2022-06-23 18:42:55.456340
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:

        basic, digest

    '''
)
auth.add_argument(
    '--auth-host',
    default=DEFAULT_AUTH_HOST,
    help='''
    The host to use for looking up the credentials specified with -a.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP Method')

# Generated at 2022-06-23 18:43:02.553908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'noauth' in choices
    assert 'oauth1' in choices
    assert 'awsv4' in choices
    assert 'ntlm' in choices
    assert 'hawk' in choices
    assert 'negotiate' in choices
    assert iter(choices)

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an HTTP auth type to be used for the request.
    Can be one of {0}.

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    ),
)

#######################################################################

# Generated at 2022-06-23 18:43:06.373879
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert_equal(
        list(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
        list(iter(_AuthTypeLazyChoices()))
    )

# Generated at 2022-06-23 18:43:17.702807
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    default=DEFAULT_AUTH,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use. By default, it's the one associated with the
    URL scheme, or {DEFAULT_AUTH} if none found.

    '''.format(DEFAULT_AUTH=DEFAULT_AUTH)
)

# Generated at 2022-06-23 18:43:26.232037
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use. Available choices depend on the installed plugins
    and the specified auth plugin. By default, the standard HTTP Basic and Digest
    auth mechanisms are always built-in.

    For example, to use the "netrc" option with the HTTP Basic auth:

        http -a username:password --auth-type=basic --auth-type=netrc \\
                httpbin.org/basic-auth/user/password

    '''
)

#######################################################################
# Miscellaneous
#######################################################################


# Generated at 2022-06-23 18:43:36.361405
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class MockAuthPluginManager:
        def get_auth_plugin_mapping(self):
            return {'foo': 1, 'bar': 2}
    plugin_manager = MockAuthPluginManager()
    mapping = dict(plugin_manager.get_auth_plugin_mapping())
    assert all(choice in _AuthTypeLazyChoices() for choice in mapping)
    assert all(choice in mapping for choice in _AuthTypeLazyChoices())
    assert sorted(_AuthTypeLazyChoices()) == sorted(mapping)


# Generated at 2022-06-23 18:43:46.541267
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    metavar='SCHEME',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication scheme used with --auth.
    The default is {DEFAULT_AUTH_PLUGIN_NAME}.

    '''
)


auth.add_argument(
    '--auth-host',
    default=DEFAULT_AUTH_HOST,
    help='''
    The host to use when originating auth requests.
    By default localhost is used.

    '''
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-23 18:43:55.587182
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from unittest import mock
    from httpie.config import plugin_manager

    def return_iterable(val):
        yield val

    # Using side_effect for multiple generator
    plugin_manager.get_auth_plugin_mapping = mock.Mock(side_effect=[
        {'foo': return_iterable('bar')},
        {'foo': return_iterable('bar'), 'bar': return_iterable('foo')},
    ])

    choices = _AuthTypeLazyChoices()

    # Checking if __iter__ returns the generator
    assert iter(choices) == return_iterable('bar')
    # Checking if multiple calls of __iter__ work
    assert list(iter(choices)) == ['foo', 'bar']


# Generated at 2022-06-23 18:44:01.300352
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin.

    The built-in plugins are:

    {builtin_plugins}

    To see a list of all available plugins, run `http --debug`.
    Plugins are searched in the following locations:

    {plugin_locations}

    '''.format(
        builtin_plugins=builtin_plugins(),
        plugin_locations='\n\n'.join(SEARCH_PATH_HELP_TEMPLATE_FOR_DEBUG.strip()
                                     for _ in plugin_manager.get_search_path()),
    )
)

# Generated at 2022-06-23 18:44:03.671159
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt']


# Generated at 2022-06-23 18:44:13.679917
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # There must be at least one auth plugin.
    assert _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication plugin (default is "{DEFAULT_AUTH_PLUGIN_NAME}").
    Use --auth-type=help to list all available plugins.

    '''
)


#######################################################################
# Cache control.
#######################################################################

cache_control = parser.add_argument_group(title='Cache Control')


# Generated at 2022-06-23 18:44:24.453986
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-23 18:44:37.733507
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert [choice for choice in choices] == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism.

    The default is "basic" if the --auth option is provided,
    and empty (no authentication) otherwise.

    These are built-in or bundled auth plugins:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    To see a list of all available auth plugins, use the
    --auth-type=help option:

        $ {program_name} --auth-type=help httpsbin.org/basic-auth/user/passwd

    '''
)


# Generated at 2022-06-23 18:44:44.829008
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:44:48.405432
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'unknown' not in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:45:00.756463
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, if the server supports more
    than one. The available types are:

    {auth_types_doc}

    '''.format(
        auth_types_doc=
        '\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

#######################################################################
# HTTP method
################################

# Generated at 2022-06-23 18:45:03.312617
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_instance = _AuthTypeLazyChoices()

    assert 'digest' in auth_type_instance


# Generated at 2022-06-23 18:45:16.037648
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    c = _AuthTypeLazyChoices()
    assert 'none' in c
    assert not 'foo' in c
    assert list(c) == ['basic', 'digest', 'jwt', 'none']



# Generated at 2022-06-23 18:45:28.256433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'foobar' not in choices
    assert list(choices) == ['basic', 'digest']



# Generated at 2022-06-23 18:45:30.396073
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'awesome' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:45:43.040991
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    return


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this option to explicitly specify the authentication type.
    This is useful if the server requires an authentication type other than
    Basic or Digest. HTTPie ships with plugins for the following common auth
    types:

        {auth_types}

    You can install additional plugins.

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)


# Generated at 2022-06-23 18:45:56.102664
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help='''
    Specify an auth scheme type.

    '''
)
auth.add_argument(
    '--auth-type-force-interactive',
    action='store_true',
    default=False,
    help='''
    Force manually interactive auth scheme type.

    '''
)

# Generated at 2022-06-23 18:45:59.044976
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'stuff' not in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:10.855427
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert next(_AuthTypeLazyChoices()) == 'digest'
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hmac', 'jwt']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    The authentication mechanism to be used. It can be either "auto" (default),
    "basic", "digest", "hmac", or "jwt".

    Plugins can be registered that add support for other types via the
    `requests.auth` registry.

    '''
)

# Generated at 2022-06-23 18:46:14.453714
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'foo' not in auth_type_choices

# Generated at 2022-06-23 18:46:22.439369
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'foo' not in auth_type



# Generated at 2022-06-23 18:46:25.259271
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']

# Generated at 2022-06-23 18:46:37.255209
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # these tests can be run only if there is not imported 'plugin_manager'
    # module from the same directory
    from ..compat import is_py36
    if is_py36:
        from importlib.machinery import SourceFileLoader
        plugin_manager = SourceFileLoader(
            'plugin_manager',
            '../plugin_manager.py'
        ).load_module()
    choices = _AuthTypeLazyChoices()
    # check that 'kerberos' auth plugin exists
    assert 'kerberos' in choices
    # check that 'kerberos' auth plugin is not case-sensitive
    assert 'KERBEROS' in choices


# Generated at 2022-06-23 18:46:46.504864
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-23 18:46:48.632138
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:50.462660
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:46:51.921035
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'generic' in _AuthTypeLazyChoices()

# Generated at 2022-06-23 18:47:01.870377
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert HTTPBasicAuth in _AuthTypeLazyChoices()
    assert 'DigestAuth' in _AuthTypeLazyChoices()
    assert type('X', (AuthBase,), {}) not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='NAME',
    type=PluginManager.get_auth_class,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    {choices}
    '''.format(choices=plugin_manager.get_plugin_help('auth') or '*** No auth plugins found ***')
)


# Generated at 2022-06-23 18:47:04.456891
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == ['digest']



# Generated at 2022-06-23 18:47:17.238144
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    (default: "{default}")

    '''.format(default='digest')
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use .netrc for loading user credentials.

    Note that .netrc is always ignored when the --auth option is used
    (it can contain credentials for multiple hosts).

    '''
)


# Generated at 2022-06-23 18:47:26.911931
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_DEFAULT,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin.

    The value can be "basic" or "digest" (the default) to use HTTP's built-in
    mechanisms, or the name of a plugin to use that plugin.

    See "HTTPie Plugins" below for more info.

    '''
)
