

# Generated at 2022-06-11 23:01:41.102180
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(iter(_AuthTypeLazyChoices()))) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-11 23:01:48.202927
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class _TestAuthPlugin(AuthPlugin):
        auth_type = 'test'
    plugin_manager.register_plugin(_TestAuthPlugin)
    assert 'test' in _AuthTypeLazyChoices()
    #
    assert 'nonexistent' not in _AuthTypeLazyChoices()
    plugin_manager.deregister_plugin(_TestAuthPlugin)

# Generated at 2022-06-11 23:01:56.976704
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to use.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Don't render the challenge request. Useful for clients that don't support
    authorization headers.

    ''',
)

#######################################################################
# Transport
#######################################################################



# Generated at 2022-06-11 23:02:05.064532
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass

# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:02:14.263105
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. The same as the name of the HTTPie
    plugin implementing it.

    Available types:
    {}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)



# Generated at 2022-06-11 23:02:25.114726
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    c = _AuthTypeLazyChoices()
    assert 'basic' in c
    assert 'digest' in c
    assert 'custom' in c
    assert 'mynewmethod' not in c

auth.add_argument(
    '--auth-type',
    metavar='type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism for the request.
    By default it's "basic", but httpie also supports other authentication types
    such as "digest" and "aws" (Amazon Web Services).

    You can override default selection by setting the auth_type in .netrc.

    ''',
)

# Generated at 2022-06-11 23:02:36.850272
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert {'basic': 'basic', 'digest': 'digest'} in _AuthTypeLazyChoices()
#


# Generated at 2022-06-11 23:02:39.015244
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'plugin_name' in lazy_choices
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-11 23:02:51.634955
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to perform. Currently supported are:

        {types}

    '''.format(
        types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# ``requests.auth.HTTPBasicAuth`` keyword argument.

# Generated at 2022-06-11 23:03:03.578578
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently the following
    mechanisms are supported:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)
auth.add_argument(
    '--auth-endpoint',
    default='',
    help='''
    The authentication endpoint to use. In most cases, the authentication
    mechanism is able to detect it automatically.

    '''
)


# Generated at 2022-06-11 23:03:17.782828
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk', 'oauth']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    Note that a custom HTTPie auth plugin must be installed for this to work.

    '''
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    For special use-cases, specify the path to an HTTPie auth plugin.
    
    '''
)

#######################################################################
# Persistence options
#######################################################################

persistence = parser.add_argument_group(title='Persistence Options')


# Generated at 2022-06-11 23:03:19.949272
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:23.612805
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert 'digest' in a
    assert 'abc' not in a



# Generated at 2022-06-11 23:03:35.577765
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication type (default is {DEFAULT_AUTH_PLUGIN}). It can be one
    of:

    {auth_types}

    '''
)

# a_plugin_option is not used in the code, but it's a placeholder for a flag
# that every AuthPlugin should define.
# This arg is added dynamically in `httpie.core`.

# Generated at 2022-06-11 23:03:43.123818
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list('abc') == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported auth types:

    {0}

    If unset, we attempt to guess auth type based on --auth data.

    '''.format('\n'.join(
        8 * ' ' + line.strip()
        for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
    ).strip())
)

#######################################################################
# Streaming
#######################################################################

stream = parser.add_mutually_exclusive_group(required=False)

stream.add_

# Generated at 2022-06-11 23:03:46.511872
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    x = _AuthTypeLazyChoices()
    assert 'basic' in x
    assert ('basic' in x) is True
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-11 23:03:52.613481
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    def was_called():
        raise AssertionError('The plugin manager was called.')
    old_get_auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping
    plugin_manager.get_auth_plugin_mapping = was_called
    try:
        assert 'ntlm' in choices
    finally:
        plugin_manager.get_auth_plugin_mapping = old_get_auth_plugin_mapping


# Generated at 2022-06-11 23:04:05.843149
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Test that plugins are recognized"""
    wrong_auth_type = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    assert wrong_auth_type not in _AuthTypeLazyChoices()
try:
    from pygments.plugin import find_plugin_lexers, find_plugin_styles  # type: ignore
except ImportError:
    # Unit test for method __iter__ of class _AuthTypeLazyChoices
    def test__AuthTypeLazyChoices___iter__():
        """Test that plugins are correctly iterated"""
        assert 'basic' in _AuthTypeLazyChoices()
        assert 'digest' in _AuthTypeLazyChoices()
        assert not (set(_AuthTypeLazyChoices()) - set(['basic', 'digest']))


# Generated at 2022-06-11 23:04:14.565115
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the mechanism used for authentication. If a plugin for the
    specified type is available, it will be used, otherwise it falls back to
    HTTP Basic authentication.

    Type is one of:
    {auth_types}

    '''.format(auth_types=format_auth_plugin_choices(plugin_manager))
)


# Generated at 2022-06-11 23:04:25.391893
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

    assert 'basic' in list(_AuthTypeLazyChoices())
    assert 'digest' in list(_AuthTypeLazyChoices())
    assert 'hawk' in list(_AuthTypeLazyChoices())
    assert 'custom' not in list(_AuthTypeLazyChoices())
    assert 'foobar' not in list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:04:30.886697
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:41.935325
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in iter(_AuthTypeLazyChoices())] == ['digest', 'hawk', 'oauth1', 'spnego']
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to be used.

    ''',
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host to use for HTTP authentication.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:04:54.048709
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert list(choices) == ['basic', 'digest', 'hawk']


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    HTTP authentication type to be used. Plugins can implement:

        {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )

)

# Generated at 2022-06-11 23:05:04.334802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force use of a specific authentication plugin. By default HTTPie will
    detect the type of auth based on the provided credentials.

    '''
)

# Generated at 2022-06-11 23:05:14.025208
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(auth_types)
    assert 'digest' in auth_types
    assert 'unknown' not in auth_types

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto". It will attempt the first mechanism that
    results in a successful login.

    ''',
)

#######################################################################
# HTTPS Client
#######################################################################

https = parser.add_argument_group(title='HTTPS',
                                  description='Options for HTTPS client')


# Generated at 2022-06-11 23:05:15.834937
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == (
        ['basic', 'digest'])

# Generated at 2022-06-11 23:05:25.456566
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert HTTPIE_PROXY_AUTH in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Defaults to 'basic' if the --auth option is present, and to 'noauth'
    otherwise.

    ''',
)

#######################################################################
# Proxies
#######################################################################

proxies = parser.add_argument_group(title='Proxies')

_proxies = proxies.add_mutually_exclusive_group(required=False)


# Generated at 2022-06-11 23:05:35.208235
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    '''Test _AuthTypeLazyChoices.__iter__().'''
    list(_AuthTypeLazyChoices())

# ``requests.auth.HTTPBasicAuth``, ``requests_oauthlib.OAuth1``,
# ``requests_oauthlib.OAuth2`` keyword arguments.
auth_plugin = parser.add_argument_group(
    title='Auth plugin options',
    description='Authentication options for the selected plugin.',
)
auth_plugin.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specified auth plugin.
    This option disables automatic plugin selection.

    ''',
)

#######################################################################
# Verbs
#######################################################################

verbs = parser.add_

# Generated at 2022-06-11 23:05:45.328770
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_auth_type_lazy_choices,
    help='''
    Force a specific authentication plugin. Defaults to auto-detection based
    on the provided credentials and the server response. Only basic and
    digest plugins are supported by default. Install the following plugins to
    enable the other auth types:

    {auth_plugins_list}

    '''
)

# TODO: --auth-type=digest:apop? (apop is supported by requests)


# Generated at 2022-06-11 23:05:58.884591
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'foo' in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-11 23:06:13.677851
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    types = list(obj)
    assert len(types) > 0


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    action=PluginAction,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Currently supported: {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

#######################################################################
# Cookies
#######################################################################
cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:06:24.328242
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The following built-in mechanism are available:

        {choices}

    See "http --help-auth" to learn about available plugins.

    '''.format(choices=', '.join(_AuthTypeLazyChoices()))
)

auth.add_argument(
    '--auth-plugin',
    action='append',
    dest='auth_plugin_args',
    help=SUPPRESS
)

#######################################################################
# Proxy
####################################################################

# Generated at 2022-06-11 23:06:36.721774
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:06:44.451156
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, the appropriate mechanism is inferred from the provided
    credentials.

    The set of available types depends on the installed plugins. Run `http --auth-type-help`
    to learn more.

    '''
)



# Generated at 2022-06-11 23:06:54.554112
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'plugin' in choices
    assert 'plugin' not in choices


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Can be one of: {plugins}
    The default is "{default}"

    '''.format(
        plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
        default=DEFAULT_AUTH_PLUGIN,
    )
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:06:56.688296
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): return list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:07:07.775296
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'foo' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin by its name.
    If no --auth-type is specified, the default plugin
    is used, which is currently set to the Basic auth plugin.

    The following auth plugins are available:

        {plugins}

    Use `http --help-auth` for details about each plugin.

    '''.format(
        plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)

#######################################################################


# Generated at 2022-06-11 23:07:19.053163
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) == set(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this flag to force using a specific authentication backend.

    ''',
)

auth.add_argument(
    '--auth-verify',
    type=input.str2bool,
    default=None,
    help='''
    Force verifying server's TLS certificate when an HTTPS request that
    requires authentication is sent.
    By default, certificate is verified only when auth credentials were
    provided, and it's skipped otherwise.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add

# Generated at 2022-06-11 23:07:25.168210
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.helpers import get_test_environ
    from httpie.plugins import plugin_manager
    plugin_manager.load_installed_plugins()
    plugin_names = sorted(plugin_manager.get_auth_plugin_mapping())
    assert list(_AuthTypeLazyChoices()) == plugin_names

AUTH_TYPES = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:07:34.594754
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'basic' in lazy_choices
    assert 'bearer' in lazy_choices
    assert 'other' not in lazy_choices
    assert 'Digest' not in lazy_choices


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an auth plugin by name.
    Valid choices: {choices}

    '''.format(
        choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)

# Generated at 2022-06-11 23:07:59.980217
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    instance = _AuthTypeLazyChoices()
    assert iter(instance) == iter(sorted(['basic', 'digest']))


auth_type_validator = AuthTypeValidator('Auth type not recognized',
    _AuthTypeLazyChoices())


# Generated at 2022-06-11 23:08:01.334039
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'hash' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:03.342329
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(iter(_AuthTypeLazyChoices()), Iterator)

# Generated at 2022-06-11 23:08:13.786471
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth_plugin_type = \
    plugin_manager.get_auth_plugin_mapping().get(DEFAULT_AUTH_PLUGIN, None)

if auth_plugin_type is None:
    # None of the supplied auth plugins can handle the default auth type.
    auth_plugin_type = 'basic'

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=auth_plugin_type,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used, which is either handled by HTTPie itself or
    by an external plugin. The default is {default}.

    '''.format(default=auth_plugin_type),
)

# Generated at 2022-06-11 23:08:16.403540
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'dummy' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:20.773182
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    # Instantiation of __contains__ will call the method of the same name of
    # class _AuthTypeLazyChoices
    __contains__(obj, _auth_type_choices[0])

# Generated at 2022-06-11 23:08:29.162656
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class FakeAuthPlugin:
        AUTH_NAME = 'fakeauth'
        auth_type = 'fakeauth'

    auth_choices = _AuthTypeLazyChoices()
    assert list(auth_choices) == []
    with plugin_manager.with_plugins([FakeAuthPlugin]):
        assert list(auth_choices) == ['fakeauth']
    assert list(auth_choices) == []



# Generated at 2022-06-11 23:08:40.365047
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()
    auth_plugin = mock.MagicMock()
    auth_plugin.auth_type = 'foo'
    plugin_manager.register(auth_plugin)
    assert 'foo' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specified authentication type.

    {options}

    If not specified, the authentication type is autoselected based
    on the provided credentials.

    '''.format(
        options=get_plugin_options('-a', 'auth')
    )
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser

# Generated at 2022-06-11 23:08:48.605462
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Select an authentication plugin. Default: {0} (the value of the
    --auth option or interactive if --auth is not used).

    The following plugins are available: {1}

    '''.format(
        DEFAULT_AUTH_PLUGIN_NAME,
        ' '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)


#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP Method')

# Note: store_const does not allow specifying a type.
_method_type = lambda x: x
http.add

# Generated at 2022-06-11 23:08:50.390185
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:09:22.318096
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.discover_auth_plugins()
    for item in _AuthTypeLazyChoices():
        assert item in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:30.236909
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert set(auth_type_choices) == set(['basic', 'digest'])
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The default auth plugin. Currently, the only supported plugin is basic.
    Other auth plugins can be installed as well, for example, digest.

    '''
)


# Generated at 2022-06-11 23:09:33.778265
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert sorted(list(auth_type_lazy_choices)) == sorted(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:09:37.260611
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    tester = _AuthTypeLazyChoices()
    assert 'basic' in tester
    assert 'digest' in tester
    assert not 'non_existant' in tester


# Generated at 2022-06-11 23:09:39.822373
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_ch = _AuthTypeLazyChoices()
    assert 'basic' in lazy_ch


# Generated at 2022-06-11 23:09:46.095244
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'aws' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices


# Generated at 2022-06-11 23:09:47.355799
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:09:49.588664
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'aws4' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:00.051138
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    default=None,
    type=str.lower,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Tells HTTPie to use the specified auth plugin, overrides the inferred
    plugin or the one specified in the config.

    Available plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}.

    '''
)


# Generated at 2022-06-11 23:10:03.921781
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iterator = _AuthTypeLazyChoices()
    assert list(iterator) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:11:11.605337
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Doctest..."""
    auth_type_choices = _AuthTypeLazyChoices()
    assert "basic" in auth_type_choices
    assert "digest" in auth_type_choices
    assert "custom" not in auth_type_choices
    assert "invalid_custom_auth" not in auth_type_choices



# Generated at 2022-06-11 23:11:13.984006
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'whatever' not in choices


# Generated at 2022-06-11 23:11:19.695896
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
           sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    The authentication mechanism to be used.  By default, it will be chosen
    based on the provided --auth credentials.
    Supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-11 23:11:28.863159
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert sorted(choices) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='SCHEME',
    help='''
    Set the auth mechanism to use.
    Supported: {0}
    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))),
)

# Generated at 2022-06-11 23:11:39.515879
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_object = _AuthTypeLazyChoices()

    assert 'digest' in auth_type_lazy_choices_object

    for auth_type in auth_type_lazy_choices_object:
        assert auth_type in plugin_manager.get_auth_plugin_mapping().keys()
        # There should be no more than one auth type in a HTTPie session.
        break

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    help='''
    The authentication mechanism to be used.

    ''',
    choices=_AuthTypeLazyChoices(),
)

###############################################################################
# Development
###############################################################################

development = parser.add_argument_group(title='Development Options')

development.add_argument