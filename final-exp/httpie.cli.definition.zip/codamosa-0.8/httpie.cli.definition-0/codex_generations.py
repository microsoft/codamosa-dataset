

# Generated at 2022-06-11 23:01:40.736558
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'bearer' not in choices

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. This can be one of the following:

        {plugin_choices}

    '''
)

auth.add_argument(
    '--auth-type=digest',
    dest='auth_digest_hdr',
    action='store_true',
    help='''
    Use the "Digest" HTTP authentication method.
    Use with --auth [user[:password]].

    ''',
)

# Generated at 2022-06-11 23:01:42.789955
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    ', '.join(iter(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:01:54.176911
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. {default_auth}

    '''.format(
        default_auth=DEFAULT_AUTH_PLUGIN_DESC
    )
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-digest', '--digest',
    action='store_true',
    dest='auth_digest',
    help='''
    Force Digest auth.

    '''
)

# ``requests.request`` keyword arguments.



# Generated at 2022-06-11 23:02:04.290502
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # pylint: disable=unused-variable
    from .auth import AuthPlugin, BasicAuth
    # pylint: enable=unused-variable
    assert iter(_AuthTypeLazyChoices())
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    If the server requires authentication other than Basic, which is the
    default, then you can use this option to explicitly specify an Auth
    plugin. For example, try "--auth-type=digest".
    Available types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)


################################################################

# Generated at 2022-06-11 23:02:07.520186
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    actual = _AuthTypeLazyChoices()
    assert actual.__contains__('digest') is True
    assert actual.__contains__('not-supported') is False

# Generated at 2022-06-11 23:02:10.905251
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'UNKNOWN' not in choices


# Generated at 2022-06-11 23:02:22.910981
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_constant = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_constant
    assert 'digest' in auth_type_constant
    assert 'auto' not in auth_type_constant
    assert 'custom' not in auth_type_constant
    assert list(auth_type_constant) == ['basic', 'digest']



# Generated at 2022-06-11 23:02:28.551905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from pygments.token import Token
    from pygments.lexers.shell import BashLexer

    lexer = BashLexer()
    assert Token.Name.Function in lexer


# TODO: Implement lazy choices here
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Type of HTTP authentication, if any.

    By default, HTTPie attempts to guess the authentication type by looking at
    the HTTP Authorization header, and if not present, by looking at the URL.

    Note that as a special case, you can also use `netrc` as an `--auth-type`
    argument.

    This option is useful in cases where authentication cannot be determined
    automatically, e.g., for requests via proxies.

    '''
)

################################

# Generated at 2022-06-11 23:02:39.334103
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Default value is None, so first item is actually blank.
    assert list(_AuthTypeLazyChoices()) == ['', 'Basic', 'Digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    metavar='TYPE',
    help='''
    The type of the authentication plugin for the specified --auth value.
    Inferred from --auth if not specified.

    '''
)

# Generated at 2022-06-11 23:02:52.087200
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use an authentication plugin (other than the builtin Basic and Digest
    plugins). For example:

        http --auth-type=jwt URL

    To see a list of available plugins, run:

        $ http --debug

    '''
)

#######################################################################
# Options that control which HTTPie features are enabled.
#######################################################################

http_options = parser.add_argument_group(title='HTTP options')


# Generated at 2022-06-11 23:03:06.278809
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for _ in _AuthTypeLazyChoices():
        pass


auth.add_argument(
    '--auth-type', '-A',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    help='''
    Force the specified authentication type.

    The default is "auto", which means HTTPie will try to
    interrogate the url, and use the most secure available.

    The other options are: {available_auth}

    '''.format(
        available_auth=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-11 23:03:08.629604
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:10.544846
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert 'digest' in obj


# Generated at 2022-06-11 23:03:23.456656
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin_name',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    Available choices: {list(_AuthTypeLazyChoices())}

    If a different name is specified and a plugin implementing
    that name is found, then it will be used.

    '''
)



# Generated at 2022-06-11 23:03:35.433305
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    authTypes = _AuthTypeLazyChoices()
    if 'basic' in authTypes:
        pass

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. run `http --debug` to see a list
    of available auth types, or see the docs for
    "Auth Plugins" for information about writing your own.

    '''
)

https = parser.add_argument_group(title='HTTPS')

# Generated at 2022-06-11 23:03:37.599549
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-11 23:03:49.853980
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    AUTH_TYPES = _AuthTypeLazyChoices()
    assert 'digest' in AUTH_TYPES


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifiy an HTTP authentication type to be used, if not specified
    the default of "basic" is used.

    Example: --auth-type=digest.

    You may use the alias basic-digest to try Basic auth first, and if
    that fails, fall back to Digest auth.

    '''
)

# The alias is mentioned in --auth-type help.
plugin_manager.register_auth_plugin_alias('basic-digest', ('basic', 'digest'))

#######################################################################
# Built-in plugins

# Generated at 2022-06-11 23:04:03.602661
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(lazy_choices, _AuthTypeLazyChoices)
    assert len(list(lazy_choices)) > 0

auth.add_argument(
    '--auth-type',
    default=None,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    Use ``--debug`` to list all plugins.
    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Force basic HTTP auth even if the server replies it is going to send a
    challenge.

    '''
)

#######################################################################
# Trust/certificate management
####################################################################

# Generated at 2022-06-11 23:04:05.541679
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(i for i in _AuthTypeLazyChoices()) == set(i for i in ['basic', 'digest'])


# Generated at 2022-06-11 23:04:14.483256
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basic' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    Default: {'basic'}.

    Choose the auth mechanism. Available choices are:

        {sorted(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')
proxy.add_argument(
    '--proxy',
    metavar='URL'
)

# Generated at 2022-06-11 23:04:27.075554
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in _auth_type_lazy_choices
    assert 'digest' in _auth_type_lazy_choices
    assert 'ntlm' in _auth_type_lazy_choices
    assert 'hawk' in _auth_type_lazy_choices
    assert 'kerberos' in _auth_type_lazy_choices

    # Check iterator
    assert 'basic' in _auth_type_lazy_choices
    assert 'digest' in _auth_type_lazy_choices
    auth_types = []
    for _auth_type in _auth_type_lazy_choices:
        auth_types.append(_auth_type)

# Generated at 2022-06-11 23:04:34.950640
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        list(plugin_manager.get_auth_plugin_mapping().keys())
    )

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    When specified, sets the auth plugin to use. Plugins can be added
    dynamically by installing CLI HTTP client auth plugin packages.

    Current plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


#######################################################################
# Auto-suggestions
#######################################################################

suggest = parser.add_argument_group(
    title='Auto-suggestions',
    description='These options are relevant only in interactive mode.',
)

suggest.add_

# Generated at 2022-06-11 23:04:37.750233
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'abc' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:46.523861
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()  # noqa: pycodestyle



# Generated at 2022-06-11 23:04:48.974204
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:58.561468
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth handler. Available handlers: {choices}.

    '''.format(
        choices=plugin_manager.get_plugin_help(
            group_name=AuthPlugin,
            prog_name=parser.prog,
            heading='Auth handlers'
        )
    )
)

# Generated at 2022-06-11 23:05:02.710303
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    auth_type_choices = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_choices
    assert 'Digest' in auth_type_choices
    assert 'client-certs' in auth_type_choices

    assert 'thing-that-does-not-exist' not in auth_type_choices

# Generated at 2022-06-11 23:05:13.571226
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''Unit test for method __contains__ of class _AuthTypeLazyChoices'''
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'awesomesauce' not in lazy_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Manual override for the authentication mechanism used when `--auth`
    is also set. The available authentication types are: {', '.join(sorted(_AuthTypeLazyChoices()))}.

    '''
)

# Generated at 2022-06-11 23:05:24.030482
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [key for key in _AuthTypeLazyChoices()] == [
        'custom',
        'digest',
        'hawk',
        'netrc',
        'ntlm',
        'oauth1'
    ]

auth.add_argument(
    '--auth-type',
    default='custom',
    choices=_AuthTypeLazyChoices(),
    help='''
    How to perform authentication.

    The default `custom` works with any HTTP authentication scheme defined by
    the server.

    For the other built-in types, the server must support a compatible
    authentication scheme.

    ''',
)


# Generated at 2022-06-11 23:05:27.738124
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert "basic" in auth_type_lazy_choices
    assert "digest" in auth_type_lazy_choices

# Generated at 2022-06-11 23:05:45.101895
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, MutableSequence)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified auth plugin.

    Available plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    See https://github.com/jakubroztocil/httpie#authentication for more
    details.

    '''
)

#######################################################################
# Auto-detection
#######################################################################

auto_detection = parser.add_argument_group(title='Auto-detection options')


# Generated at 2022-06-11 23:05:46.835267
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert AUTH_PLUGIN_CHOICES == ['basic', 'digest']

# Generated at 2022-06-11 23:05:59.908984
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    assert 'bearer' in auth_types

    for auth_type in auth_types:
        assert auth_type in ('basic', 'digest', 'bearer')



# Generated at 2022-06-11 23:06:11.396205
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins import plugin_manager
    assert 'bearer' in _AuthTypeLazyChoices()
    plugin_manager.deregister_auth_plugin('bearer')
    assert 'bearer' not in _AuthTypeLazyChoices()
    plugin_manager.register_auth_plugin(
        BearerAuthPlugin(['bearer'])
    )
    assert 'bearer' in _AuthTypeLazyChoices()
    assert sorted(_AuthTypeLazyChoices()) == [
        'bearer', 'digest', 'hmac', 'base64']


# Generated at 2022-06-11 23:06:22.987678
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=AuthCredentials.validate_type,
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Specify an alternate authentication type. By default, HTTPie
    performs Basic auth.

    The following auth types are supported:

        {0}

    '''.format(columnar(
        [
            plugin.name for plugin in plugin_manager.get_auth_plugins()
        ]
    ))
)

#######################################################################
# CLI Behavior
#######################################################################

behavior = parser.add_argument

# Generated at 2022-06-11 23:06:24.217559
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:35.417162
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('bearer' in _AuthTypeLazyChoices()) is True
    assert ('data' in _AuthTypeLazyChoices()) is False



auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    How the credentials are sent to the server.

    TYPE can be one of:

    - auto (default)
    - basic
    - digest
    - {0}

    '''.strip().format(
        '\n- '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-11 23:06:44.421901
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth algorithm.

    Available auth types:

    {auth_types}

    '''.format(
        auth_types=textwrap.indent(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            8 * ' '
        )
    )
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:06:54.524358
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): # noqa
    choices = [
        item for item in plugin_manager.get_auth_plugin_mapping().keys()
    ] == [
        choice for choice in _AuthTypeLazyChoices()
    ]

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    type=AuthPlugin,
    choices=_AuthTypeLazyChoices(),
    help='''
    Forces the use of the specified auth plugin.
    Implies --auth if USER:PASS is not specified.

    To show all available plugins run:

        http --debug

    ''',
)

# Generated at 2022-06-11 23:06:59.044741
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(['bearer', 'digest', 'hawk', 'ntlm', 'oauth1'])

# Generated at 2022-06-11 23:07:20.887668
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'ntlm' in choices
    assert 'hawk' in choices
    assert 'custom' not in choices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Default is `basic`. HTTPie
    supports the following mechanisms:

        {auth_type_choices}

    '''.format(
        auth_type_choices=', '.join(plugin_manager.get_auth_plugin_mapping())
    ),
)

# Generated at 2022-06-11 23:07:30.963209
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockA(AuthPlugin):
        auth_type = 'mocka'
    assert 'mocka' in _AuthTypeLazyChoices()
    assert 'mockb' not in _AuthTypeLazyChoices()
    plugin_manager.register(MockA)
    assert 'mocka' in _AuthTypeLazyChoices()
    assert 'mockb' not in _AuthTypeLazyChoices()
    plugin_manager.unregister('mocka')
    assert 'mocka' not in _AuthTypeLazyChoices()
    assert 'mockb' not in _AuthTypeLazyChoices()
    plugin_manager.unregister('mocka') # no-op


# Generated at 2022-06-11 23:07:37.485090
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    This option is useful when the server uses a non-standard
    authentication scheme.

    ''',
)
auth.add_argument(
    '--auth-force',
    action='store_true',
    help='''
    Force HTTPie to send the Basic auth header even for "non-simple" HTTP
    requests, such as POST.

    '''
)

# Generated at 2022-06-11 23:07:46.346017
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(auth_type_choices) == sorted([
        'basic',
        'digest',
        'custom',
    ])

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used.
    Currently supported: basic and digest.
    ''',
)

auth.add_argument(
    '--auth-host',
    default=DEFAULT_AUTH_HOST,
    help='''
    Hostname to be used for HTTP authentication. This can be useful
    when your server requires authentication for a url other than '/'.

    ''',
)
plugin_manager.add_plugin_args(parser)

################################

# Generated at 2022-06-11 23:07:58.207031
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    >>> iter(_AuthTypeLazyChoices())
    <iterator object at 0x7f2b345c5e48>
    >>> list(iter(_AuthTypeLazyChoices()))
    ['digest', 'jwt']
    """



# Generated at 2022-06-11 23:08:06.244272
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ) == iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Currently supported: basic, digest.

    ''',
)
auth.add_argument(
    '--auth-host',
    help='''
    The host to provide when asked for it.

    '''
)
auth.add_argument(
    '--auth-disable',
    action='store_true',
    help='''
    Do not use any authentication mechanism, even if it is provided in the URL.

    '''
)


############################################################################
# SSL
############################################################################



# Generated at 2022-06-11 23:08:12.314711
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:08:18.087153
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a custom auth plugin by its name, for example,
    "myplugin", or a path to a module or package containing the plugin, for
    example, "/home/user/myplugins/myplugin.py", or
    "/home/user/myplugins/myplugin/__init__.py".

    Plugins are modules containing a function "get_auth" that accepts the
    parsed command-line arguments.

    '''
)


# Generated at 2022-06-11 23:08:19.648440
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('test')

# Generated at 2022-06-11 23:08:22.721196
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    plugin_manager.discover()
    instance = _AuthTypeLazyChoices()
    assert list(instance) == ["basic", "digest"]


# Generated at 2022-06-11 23:09:01.397582
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin (only Basic, Digest and Bearer supported).
    See also: https://github.com/jkbrzt/httpie#authentication.

    '''
)


# Generated at 2022-06-11 23:09:12.177983
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'hawk' in lazy_choices
    assert 'aws-sigv4' in lazy_choices
    assert 'aws' in lazy_choices
    assert 'kerberos' in lazy_choices
    assert 'aws-sigv4-generic' in lazy_choices
    assert 'ntlm' in lazy_choices
    assert 'oauth1' in lazy_choices
    assert 'oauth2' in lazy_choices
    assert '1.0a' in lazy_choices
    assert '2.0' in lazy_choices
    assert 'gssapi' in lazy_choices
    assert 'spnego' in lazy_choices


# Generated at 2022-06-11 23:09:23.220888
# Unit test for constructor of class _AuthTypeLazyChoices

# Generated at 2022-06-11 23:09:30.919610
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['digest', 'jwt', 'oauth1', 'hawkeye']) <= set(_AuthTypeLazyChoices())
auth_type = auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
    required=True
)
auth.add_argument(
    '--digest-auth', '-A',
    default=False,
    const=True,
    nargs='?',
    help='''
    Use HTTP Digest Authentication.
    ''',
)

# Generated at 2022-06-11 23:09:42.874571
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import BuiltinAuthPlugin
    from httpie.plugins import get_auth_plugin_mapping
    plugin_manager.clear()
    mapping = get_auth_plugin_mapping()
    assert not _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()
    plugin_manager.add_plugin('builtin-digest', BuiltinAuthPlugin())
    assert 'digest' in _AuthTypeLazyChoices()
    plugin_manager.clear()
    assert not _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:09:51.454968
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(new_httpie_plugins['auth'].keys()))


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin to use.

    It can be one of: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    ''',
)


# Generated at 2022-06-11 23:10:03.875224
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin or override the automatic detection.

    Plugins are registered via entry points in the ``httpie.plugins.auth``
    group. Use ``${prog} plugins`` to show the currently available plugins.

    '''
)


# Generated at 2022-06-11 23:10:12.076053
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    choices = sorted(plugin_manager.get_auth_plugin_mapping())
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    assert isinstance(auth_type_lazy_choices, Iterable)
    assert isinstance(auth_type_lazy_choices, Container)
    assert sorted(list(auth_type_lazy_choices)) == choices
    assert 'basic' in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin name

    '''
)

# Generated at 2022-06-11 23:10:13.455007
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:23.059052
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    from . import __main__ as main
    auth_type_choices = _AuthTypeLazyChoices()
    main.main(['--auth-type=digest'])
    main.main(['--auth-type=basic'])
    main.main(['--auth-type=custom'])
    assert 'digest' in auth_type_choices
    assert 'basic' in auth_type_choices
    assert 'custom' in auth_type_choices
    assert list(auth_type_choices) == ['basic', 'custom', 'digest']

# Generated at 2022-06-11 23:11:29.596591
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert set(_AuthTypeLazyChoices()) == {'basic', 'digest'}

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    '''
)

#######################################################################
# Parser
#######################################################################
