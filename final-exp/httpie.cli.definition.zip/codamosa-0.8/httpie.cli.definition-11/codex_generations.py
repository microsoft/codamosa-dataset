

# Generated at 2022-06-11 23:01:36.919613
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert not auth_type.__contains__('does_not_exist')
    assert 'Basic' in auth_type



# Generated at 2022-06-11 23:01:50.139414
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    Explicitly specify the auth mechanism. Otherwise, it is guessed from the
    provided username[:password] string.

    Available auth types: {available_auth_types}

    '''.format(
        available_auth_types=', '.join(_AuthTypeLazyChoices())
    ),
    # _AuthTypeLazyChoices cannot be sorted
)

# Generated at 2022-06-11 23:01:59.095106
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert bool(_AuthTypeLazyChoices())


auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    Specify the authentication protocol. If not provided, the type is
    auto-detected from the provided credentials. Currently, supported types are
    "basic", "digest", "bearer" and "hawk".

    '''
)
auth_type.add_argument(
    '--no-auth-type',
    dest='auth_type',
    action='store_const',
    const=None,
    help='''
    Disable authentication (i.e., --auth-type=None).

    '''
)


#######################################################################


# Generated at 2022-06-11 23:02:01.641827
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic')
    assert choices.__contains__('digest')

# Generated at 2022-06-11 23:02:14.745894
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = [i for i in _AuthTypeLazyChoices()]
    assert choices == ['digest', 'hawk', 'jwt']

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='The auth type to use. Default is auto.'
)
auth.add_argument(
    '--auth-strip-trailing-equals',
    default=None,
    action='store_true',
    help='Strip trailing equals sign in auth token.'
)
auth.add_argument(
    '--auth-host',
    help='''
    Hostname of the IP address
    to perform auth challenge with.

    '''
)

# Generated at 2022-06-11 23:02:17.829424
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobarbaz' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:23.301081
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'custom' not in choices
    assert 'digest' in choices

    plugin_manager.deregister(BasicAuthPlugin)
    plugin_manager.register(BasicAuthPlugin)

    assert 'basic' not in choices
    assert 'custom' not in choices
    assert 'digest' in choices


# Generated at 2022-06-11 23:02:28.771789
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Authentication method. Supported by default are "basic", "digest" and "ntlm".
    Use the --debug flag while running the command to see if other types are
    also supported via plugins.

    '''
)
auth.add_argument(
    '--auth-to',
    dest='auth_from',
    help='''
    Any URL to which the authenticated request should be sent.
    This option is required if the response to the previous unauthenticated
    request included a WWW-Authenticate header.

    '''
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-11 23:02:39.158326
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices
    """
    tester = _AuthTypeLazyChoices()
    if tester.__contains__(__test_string__):
        raise AssertionError(
            _test_failed_repr_format(
                __file__, 1, __test_string__,
                'Basic', 'Automatic', __test_string__
            )
        )
    if not tester.__contains__(None) and not tester.__contains__(False):
        raise AssertionError(
            _test_failed_repr_format(
                __file__, 2, __test_string__,
                'Automatic', 'Basic', __test_string__
            )
        )

# Generated at 2022-06-11 23:02:41.697634
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert len(choices) == len(choices.__iter__())

# Generated at 2022-06-11 23:02:52.264005
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for auth_type_lazy_choice in auth_type_lazy_choices:
        assert isinstance(auth_type_lazy_choice, str)

# https://travis-ci.org/jakubroztocil/httpie/jobs/363203088#L1624

# Generated at 2022-06-11 23:02:54.250780
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'token' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:02:59.983583
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    >>> from httpie.cli import _AuthTypeLazyChoices
    >>> 'Digest' in _AuthTypeLazyChoices()
    True
    >>> 'Basic' in _AuthTypeLazyChoices()
    True
    >>> ['Digest', 'Basic'] == sorted(list(_AuthTypeLazyChoices()))
    True
    """



# Generated at 2022-06-11 23:03:02.272314
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'multi', 'netrc']

# Generated at 2022-06-11 23:03:03.999823
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "basic" in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:04.836818
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')



# Generated at 2022-06-11 23:03:17.132343
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(_AuthTypeLazyChoices())
    assert 'Basic' in choices
    assert 'Bearer' in choices
    assert choices == sorted(choices)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin, that is a subclass of
    httpie.plugins.auth.base.BaseAuth, with an `authenticate(self, req)` method.

    '''
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help=SUPPRESS,
)


#######################################################################
# HTTP(S) Proxy
#######################################################################


# Generated at 2022-06-11 23:03:29.712940
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. The value is case-insensitive, and
    it can be one of:

        {auth_types}

    If not specified, HTTPie will try to guess the authentication type
    when given credentials (--auth).

    '''
).completer = ChoicesCompleter(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:03:40.199496
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert tuple(auth_type_lazy_choices) == tuple(['basic', 'digest'])
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'Bearer' not in auth_type_lazy_choices
    assert 'Bearer' not in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-11 23:03:50.753364
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert list(_AuthTypeLazyChoices()) == list(['basic', 'digest'])


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Automatic detection of the auth type is the default and it should be able
    to handle most use cases.

    However, if automatic detection doesn't work for you, you can explicitly
    ask for either Basic or Digest authentication, using this option.

    '''
)

#######################################################################
# Timeouts
#######################################################################
# ``requests.request`` keyword arguments.
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-11 23:04:06.598580
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth scheme to use. The value can be:

    ''' + (
        '\n'.join(8 * ' ' + descr.strip()
                  for descr in wrap(plugin_manager.get_auth_plugins_docs(), 60)
                  )
    )
)

auth.add_argument(
    '--auth-host',
    help='''
    The host to use for the auth plugin.

    '''
)


# Generated at 2022-06-11 23:04:09.243031
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()

    first_choice, *_, last_choice = choices
    assert first_choice
    assert last_choice


# Generated at 2022-06-11 23:04:20.414323
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'digest' in iter(_AuthTypeLazyChoices())

_auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-11 23:04:29.728220
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # We can't import all the plugins at the top of the module, because
    # some of them rely on other modules that might not be available
    # on the user's computer. However, we need to be able to list
    # all the available auth types even if they weren't imported yet.
    # Also, we need to be able to list the available auth types in the docs.
    # And this even though they are actually implemented as plugins.
    # The _AuthTypeLazyChoices class above behaves like a list of all
    # available auth types but only instantiates the plugins right before
    # that list is needed.
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:36.496548
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the auth mechanism to be used. If not specified, the
    mechanism is guessed from the ``--auth`` or ``--auth-plugin`` argument.
    Available mechanisms:

    '''.strip() + '\n'.join(
        8 * ' ' + line for line in wrap(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            60)
    ).strip()
)

# Generated at 2022-06-11 23:04:39.705674
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'notfound' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:47.758136
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'aws4', 'aws4-hmac-sha256', 'aws4-hmac-sha256-propercase'
    ]


# Generated at 2022-06-11 23:04:58.081714
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    pass


_AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices,
    help='''
    The authentication mechanism to be used.

    If no type is provided, an appropriate one is guessed based on the provided
    credentials.

    The following mechanisms are supported by default:

    {auth_types}

    Third-party plugins may register additional mechanisms.
    Use `http --help-auth` to list all available mechanisms.

    '''.format(
        auth_types=indent(
            '\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
        ),
        width=8
    )
)



# Generated at 2022-06-11 23:05:00.440463
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices



# Generated at 2022-06-11 23:05:01.891442
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:14.634834
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'auto' in lazy_choices


# Generated at 2022-06-11 23:05:16.071197
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:05:25.557060
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Defines the authentication mechanism to be used. By default, the plugin
    is auto-detected based on the provided credentials (i.e., no credentials for
    "noauth", username but no password for "basic", username and password for
    "digest").

    {auth_plugin_list}

    '''.format(
        auth_plugin_list='\n'.join(
            wrap(
                ' '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                75
            )
        )
    )
)

#######################################################################
# SSL
#######################################################################

# Generated at 2022-06-11 23:05:35.268546
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import unittest
    class AuthTypeLazyChoicesTestCase(unittest.TestCase):
        def test_available_plugins(self):
            self.assertIn('digest', _AuthTypeLazyChoices())
            self.assertIn('jwt', _AuthTypeLazyChoices())
            self.assertNotIn('not-existent-plugin', _AuthTypeLazyChoices())
    unittest.main()


# Generated at 2022-06-11 23:05:45.397102
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AUTH_PLUGIN_MAPPING.keys())

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism to be used. Currently supported values are:

        {0}

    If the option is not used, HTTPie tries to guess the mechanism.

    '''.format(',\n'.join('    {0}'.format(k) for k in plugin_manager.get_auth_plugin_mapping()))
)


# Generated at 2022-06-11 23:05:58.978517
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == ['digest', 'jwt', 'netrc', 'basic']

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication type, one of:

        {auth_type_choices}

    The default value, "auto", means that the authentication type is
    determined based on the presence of the user credentials.

    '''.format(
        auth_type_choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-11 23:06:10.574225
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # should accept any string
    assert '' in _AuthTypeLazyChoices()
    # should contain the plugin names
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom authentication plugin name to use.
    The plugin must be already known to HTTPie, i.e., either part
    of the standard distribution or installed separately.
    Use the --debug flag to inspect the list of currently available
    plugins.

    '''
)

# Generated at 2022-06-11 23:06:12.869977
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:06:16.115300
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'oauth1' in choices
    assert 'foo' not in choices

# Generated at 2022-06-11 23:06:25.482354
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hmac' in choices
    assert 'MultipartPost' not in choices


# Generated at 2022-06-11 23:06:35.093156
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'baz' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:06:44.206785
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    examples = ['auto', 'basic', 'digest', 'oauth2', 'multiauth', 'hawkeye']
    assert all(choice in choices for choice in examples)
    assert all(choice in examples for choice in choices)

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication mechanism. Defaults to 'auto'
    which automatically select best authentication plugin to use
    (a builtin one or from a plugin).

    ''',
)

# Generated at 2022-06-11 23:06:54.376534
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    Action(option_strings=[], choices=_AuthTypeLazyChoices())

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_auth_type_lazy_choices,
    help='''
    The type of authentication used for the request.

    This option is experimental and its functionality may change.

    If --auth-type is specified, HTTPie will try to use the specified
    type of authentication, ignoring any authentication information provided
    by the user.

    Current methods:

    {methods}

    '''
)

# Generated at 2022-06-11 23:07:07.030555
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter({'basic', 'digest'})) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism:

        {plugin_manager.get_auth_plugin_help()}

    '''
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help=f'''
    Explicit auth endpoint (a URL path).
    If set, it takes precedence over the --auth-type's default endpoint.

    '''
)

#######################################################################
# Configuration
#######################################################################
configuration = parser.add_argument_group(title='Configuration')

configuration.add

# Generated at 2022-06-11 23:07:13.753649
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in lazy_choices
    assert 'Digest' in lazy_choices
    assert 'Bearer' in lazy_choices
    assert 'AWS' in lazy_choices
    assert 'AWS4' in lazy_choices
    assert 'Hawk' in lazy_choices



# Generated at 2022-06-11 23:07:21.501250
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(_AuthTypeLazyChoices()) == len(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:07:22.550164
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:32.430816
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the auth plugin to use for requests.

    Plugins included with HTTPie: {plugins}

    '''.format(plugins=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ))
)

#######################################################################
# HTTP method
#######################################################################



# Generated at 2022-06-11 23:07:34.745462
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'netrc']

# Generated at 2022-06-11 23:07:37.882972
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-11 23:07:58.806505
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=auth_type_lazy_choices,
    help='''The authentication mechanism to be used. Defaults to "basic".
    Can be one of: ''' + ', '.join(sorted(auth_type_lazy_choices)) + '''
    ''',
)
auth.add_argument(
    '--auth-endpoint',
    help='''Specify a custom endpoint for Basic auth credentials. Defaults to
    a URL path of "/".
    '''
)


################################

# Generated at 2022-06-11 23:08:00.269554
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:03.294638
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices

# Generated at 2022-06-11 23:08:13.741473
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert OUTPUT_OPTIONS in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    For example, the "bearer" type implements the bearer token authorization
    (e.g., the token auth scheme defined in RFC 6750).

    For information about bearer token authentication and examples,
    see:

    * https://tools.ietf.org/html/rfc6750
    * https://httpie.org/docs#authentication

    This option is deprecated, use `--auth-scheme` instead.

    ''',
)

# Generated at 2022-06-11 23:08:16.205243
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    for key in auth_type:
        assert key in auth_type

# Generated at 2022-06-11 23:08:26.537459
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(set(_AuthTypeLazyChoices())) == len(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use.

    Available plugins:
        {0}
    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

auth.add_argument(
    '--auth-provider',
    metavar='URL',
    help='''
    The authentication provider's URL.

    '''
)

#######################################################################
# Client Certs
#######################################################################

# Generated at 2022-06-11 23:08:37.266210
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    noop = lambda x: x
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert list(map(_AuthTypeLazyChoices(), [noop] * 10)) == list(map(sorted(plugin_manager.get_auth_plugin_mapping().keys()), [noop] * 10))



# Generated at 2022-06-11 23:08:46.732593
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass # test disabled


auth.add_argument(
    '--auth-type', '--auth-scheme',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth scheme and/or plugin to use.

    The default, `auto' is a shortcut for `digest, basic' and
    means that HTTPie will first try to use the Digest authentication,
    but if it fails, it will then give Basic auth a shot.

    The `plugin' value tells HTTPie to use a custom authentication plugin,
    specified using the --auth-plugin (or AUTH_PLUGIN for short) option.

    '''
)

# Generated at 2022-06-11 23:08:59.163836
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices - {'basic', 'digest', 'fake'} == set()
    # Test that it can be used with ArgumentParser.
    parser.add_argument(
        '--auth-type',
        choices=choices
    )


# Generated at 2022-06-11 23:09:00.725959
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(
        _AuthTypeLazyChoices())

# Generated at 2022-06-11 23:09:43.800182
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from requests.auth import AuthBase
    from httpie.plugins import AuthPlugin

    class AuthPluginDummy(AuthPlugin):
        auth_type = 'dummy'
        auth_type_aliases = ()
        auth_parse = staticmethod(lambda x: x)
        auth_from_netrc = staticmethod(lambda x, y: y)
        auth_apply = staticmethod(lambda x, y: y)

    class AuthPluginDummy2(AuthPlugin):
        auth_type = 'dummy2'
        auth_type_aliases = ()
        auth_parse = staticmethod(lambda x: x)
        auth_from_netrc = staticmethod(lambda x, y: y)
        auth_apply = staticmethod(lambda x, y: y)


# Generated at 2022-06-11 23:09:45.850830
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bogus' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:53.663326
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin (e.g., oauth2).
    The default "auto" is usually the right choice.
    Run `http --auth-type=help` to print the list of all plugins.

    '''
)

#######################################################################
# Config
#######################################################################

config = parser.add_argument_group(title='Config')

# Generated at 2022-06-11 23:09:56.513065
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert "digest" in obj
    assert "nonexistant" not in obj



# Generated at 2022-06-11 23:09:58.943214
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(['basic', 'digest', 'ntlm'])


# Generated at 2022-06-11 23:10:09.940293
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from tests.constants import ANY_STRING
    assert ANY_STRING not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of HTTP authentication to perform. Auto-detected based on the
    provided credentials (--auth option).

    Use this option only to specify an authentication type that cannot be
    auto-detected.

    Supported auth types:
    ''' +
    ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)


#######################################################################
# Request Data
#######################################################################

data = parser.add_argument_group(title='Request Data')

# Generated at 2022-06-11 23:10:21.182858
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth_type_validator = AuthTypeValidator(
    'Authentication type not supported. '
    'Try one of: {0}'.format(', '.join(_AuthTypeLazyChoices()))
)

# Generated at 2022-06-11 23:10:30.289818
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = set(_AuthTypeLazyChoices())
    assert choices >= {'basic', 'digest', 'hawk'}

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism.

    '''
)
auth.add_argument(
    '--auth-digest-nonce-count',
    type=int,
    default=100000,
    help='''
    Use a fixed nonce in the Digest access authentication header.

    This is a brute-force way to avoid the need to track nonce count changes.
    It is useful when debugging. The default is to increment the nonce count.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_

# Generated at 2022-06-11 23:10:33.619523
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert ('DIGEST' in choices) == ('digest' in plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-11 23:10:42.877543
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
