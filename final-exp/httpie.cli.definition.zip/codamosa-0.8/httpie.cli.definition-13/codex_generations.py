

# Generated at 2022-06-11 23:01:40.797927
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'digest' in auth_plugin_mapping
    assert 'jwt' in auth_plugin_mapping
    assert sorted(auth_plugin_mapping.keys()) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used. Currently supported are:

    %(choices)s

    ''',
)

# ``requests.request`` keyword arguments.
auth_plugin_options_group = parser.add_argument_group(title='Authentication Options')


# Generated at 2022-06-11 23:01:53.383278
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        'basic' in _AuthTypeLazyChoices()
        and 'bearer' in _AuthTypeLazyChoices()
        and 'digest' in _AuthTypeLazyChoices()
    ) is True

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices()
)

auth.add_argument(
    '--auth-endpoint',
    metavar='URL',
    help='''
    A URL to which credentials are POSTed on demand.
    It is used only with --auth-type=oauth2.

    '''
)


# Generated at 2022-06-11 23:01:57.756193
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert set(choices) == set(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:01:59.057200
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:10.852860
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test method __iter__ of class _AuthTypeLazyChoices
    """
    _AuthTypeLazyChoices.__iter__()

# Generated at 2022-06-11 23:02:14.799359
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == []  # no plugins for unit test
    # TODO: how to test that the plugins are loaded?



# Generated at 2022-06-11 23:02:25.639087
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'custom' in choices
    assert 'not-existing' not in choices

    assert sorted(choices) == sorted(['Basic', 'Digest', 'custom'])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. May be one of:
    "Basic", "Digest".

    Plugins can define other types. See: {0}

    '''.format(plugin_manager.locate_plugins())
)

# Generated at 2022-06-11 23:02:37.301559
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

#
# Basic Auth
#

# The `requests.request` keyword argument.
# Used with `requests.auth.HTTPBasicAuth`.
basic_auth = parser.add_argument_group(title='Basic Auth')
basic_auth = basic_auth.add_mutually_exclusive_group()

# NOTE: overrides --auth, if both are specified.

# Generated at 2022-06-11 23:02:48.578394
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # need to be able to check if 'element' exists in _AuthTypeLazyChoices()
    # as this class is also used for ``choices``:
    # http://stackoverflow.com/a/2819420/447755
    assert 'bearer' in _AuthTypeLazyChoices()
test__AuthTypeLazyChoices___contains__()



# Generated at 2022-06-11 23:02:51.901826
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-11 23:03:05.089316
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), Iterable)  # noqa: F821
    assert isinstance(_AuthTypeLazyChoices(), Iterable)  # noqa: F821
    assert isinstance(_AuthTypeLazyChoices(), Iterable)  # noqa: F821
    assert isinstance(_AuthTypeLazyChoices(), Iterable)  # noqa: F821

_auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-11 23:03:06.390953
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Bearer' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:08.721224
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:13.966938
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    lazy_choices_items = list(lazy_choices)
    assert len(lazy_choices_items) == 2
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'foo' not in lazy_choices

# Generated at 2022-06-11 23:03:21.314455
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    '''
)
auth.add_argument(
    '--auth-type-force-interactive',
    action='store_true',
    default=False,
    help='''
    Force interactive authentication, even if authentication data is being sent.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use the netrc file to lookup credentials.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser

# Generated at 2022-06-11 23:03:22.457106
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:23.732802
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:03:35.672736
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert AUTH_PLUGIN_NAMES in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an authentication plugin ({', '.join(AUTH_PLUGIN_NAMES)}).
    By default, HTTPie tries to guess what plugin to use based on the URL.

    '''
)

#######################################################################
# Connection
#######################################################################

connection = parser.add_argument_group(title='Connection')

connection.add_argument(
    '--timeout', '-t',
    default=HTTP_TIMEOUT,
    help='Connection timeout in seconds.',
    type=float,
)


# Generated at 2022-06-11 23:03:37.108236
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:49.635743
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom HTTP authentication plugin other than the
    defaults. Supported values are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:04:06.123015
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        sorted(
            [choice for choice in _AuthTypeLazyChoices()]
        ) ==
        sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        )
    )

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
auth.add_argument(
    '--auth-type',
    default=HTTPBasicAuth,
    choices=_AuthTypeLazyChoices(),
    help=f'''
        The authentication plugin to use. Must be one of {sorted(auth_plugin_mapping)}
        Default: [basic]
    '''
)

# Generated at 2022-06-11 23:04:16.828185
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''
    Unit test for method __contains__ of class _AuthTypeLazyChoices
    '''
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an auth implementation (digest).
    The {DEFAULT_AUTH_PLUGIN} plugin is used by default.
    For supported types see "http --help-auth".

    '''
)

# Generated at 2022-06-11 23:04:26.549818
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    atc = _AuthTypeLazyChoices()
    assert 'digest' in atc
    assert 'basic' in atc
    assert 'oauth1' in atc
    assert 'some_type_that_does_not_exist' not in atc


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used for the request.
    Plugins are listed at https://github.com/jakubroztocil/httpie#plugins
    '''
)

# Generated at 2022-06-11 23:04:34.623741
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for _AuthTypeLazyChoices.__iter__()"""
    from getpass import getuser
    auth_type_lazy_choices_ = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_
    assert 'digest' in auth_type_lazy_choices_
    assert 'hawk' in auth_type_lazy_choices_
    assert 'ntlm' in auth_type_lazy_choices_
    assert 'oath' in auth_type_lazy_choices_
    assert 'any' not in auth_type_lazy_choices_
    #
    auth_type_lazy_choices_ = iter(auth_type_lazy_choices_)
    assert next(auth_type_lazy_choices_)

# Generated at 2022-06-11 23:04:45.632875
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Given
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # When
    result = list(auth_type_lazy_choices)
    # Then
    assert [
        'basic',
        'digest'
    ] == result



# Generated at 2022-06-11 23:04:57.013505
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(AUTH_PLUGIN_MAP.keys())
    assert 'Multi' in _AuthTypeLazyChoices()
    abs(hash(frozenset(_AuthTypeLazyChoices())))


# Generated at 2022-06-11 23:05:05.469122
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'foo']
# End unit test


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help='''
    The authentication mechanism to be used. The default is "basic". Use
    --print=B to view the HTTPie-generated Authorization header.

    ''',
)
auth.add_argument(
    '--auth-verify',
    default=True,
    action='store_true',
    help='''
    Verify the SSL certificate of the server. This can also be controlled
    by setting the 'verify' property in the config file.

    '''
)

# Generated at 2022-06-11 23:05:14.575308
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(
        name in _AuthTypeLazyChoices()
        for name in plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=AUTH_PLUGIN_MAP['basic'],
    help=f'''
    Specifies which authentication method to use. {AUTH_PLUGIN_HELP}

    '''
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Path to the endpoint for the chosen auth mechanism.
    By default, the root path '/' is used.

    '''
)

# Generated at 2022-06-11 23:05:24.730906
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import pytest
    assert 'digest' in _AuthTypeLazyChoices()
    # This test will fail if a file in tests/fixtures/auth/plugins is empty.
    # If you see this error, please install "requests-ntlm", "requests-bits".
    assert len(list(_AuthTypeLazyChoices())) >= 7


auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Type of authentication (plugin). The default is to auto-detect the auth
    type based on the provided credentials.

    ''',
)

# Generated at 2022-06-11 23:05:34.784607
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices and 'Basic' in lazy_choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Specifying this option overrides
    the default authentication mechanism that HTTPie would otherwise use.
    Available authentication mechanisms depend on the authentication plugins
    that are currently installed.

    '''
)

# Generated at 2022-06-11 23:05:44.008265
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:57.529161
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    l = _AuthTypeLazyChoices()
    assert 'basic' in l
    assert 'digest' in l
    assert 'hawk' in l


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify the authentication mechanism to be used.
    Currently supported: Basic and Digest.

    '''
)

# Generated at 2022-06-11 23:06:04.295612
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import plugin_manager
    auth_types = _AuthTypeLazyChoices() 
    assert 'digest' in auth_types
    plugin_manager.deregister(plugin_name='digest')
    assert 'digest' not in auth_types


# Generated at 2022-06-11 23:06:06.827933
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        'basic',
        'digest',
        'hawk',
    ] == list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:06:14.099759
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert not 'foobar' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == ['basic']


# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:06:16.014495
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['BASIC', 'DIGEST'] == list(_AuthTypeLazyChoices())



# Generated at 2022-06-11 23:06:25.482562
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to be used. It will be auto-detected by default.
    '''
)


# Generated at 2022-06-11 23:06:38.239729
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(vars(_AuthTypeLazyChoices())) == []

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='Specifies the authentication method to be used'
         ' (default: basic).'
)
auth_type.add_argument(
    '--no-auth',
    dest='auth_type',
    action='store_const',
    const=NO_AUTH,
    help='''
    Disable HTTP authentication.

    '''
)

# Generated at 2022-06-11 23:06:45.130901
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from requests_toolbelt.sessions import BaseUrlSession
    from requests_toolbelt.auth import BearerTokenAuth
    plugin_manager.clear_auth_plugin_mapping()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    auth_type_lazy_choices.__contains__('bearer')
    assert 'bearer' not in auth_type_lazy_choices
    plugin_manager.register_auth_plugin('bearer', BearerTokenAuth)
    assert 'bearer' in auth_type_lazy_choices
    plugin_manager.clear_auth_plugin_mapping()
test__AuthTypeLazyChoices___contains__()


# Generated at 2022-06-11 23:06:54.830974
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices().__iter__()) == [
        'basic', 'digest'
    ]

auth_type_validator = AuthTypeValidator(
    'Unsupported or unknown auth type: %(value)s.'
)


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    type=auth_type_validator,
    help='''
    The authentication mechanism to be used.

    Currently supported auth types:
    {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    ),
)

# Generated at 2022-06-11 23:07:19.972310
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom_auth' in choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.get_plugin_source(AuthPlugin, 'auth_type'),
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Specify an auth plugin by name.

    Available auth plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)


# Generated at 2022-06-11 23:07:31.559388
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

auth_type = auth.add_mutually_exclusive_group(required=False)

auth_type.add_argument(
    '--auth-type',
    metavar='',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of a plugin that handles the authentication type.

    The following built-in plugins are available:
        {available_plugins}

    '''.format(
        available_plugins='\n        '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

# Disable all plugins by default.
auth_plugins = auth.add_mutually_exclusive_group(required=False)


# Generated at 2022-06-11 23:07:43.170492
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'jwt', 'ntlm']
_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_auth_type_lazy_choices,
    help='''
    Explicitly specify a particular auth mechanism, overriding the default.

    Current choices are: {choices}

    '''.format(
        choices=', '.join(iter(_auth_type_lazy_choices))
    )
)


# Generated at 2022-06-11 23:07:55.702872
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism.

    Available plugins are:
    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Options particular to individual authentication plugins.
auth_plugin_options = parser.add_argument_group(title='Authentication options')
plugin_manager.add_plugin_options(auth_plugin_options)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy options')

proxy

# Generated at 2022-06-11 23:08:04.941989
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(list(_AuthTypeLazyChoices())) > 0
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an HTTP authentication type (Basic or Digest). For the
    Basic authentication, provide the username and the password either in
    the URL or using the -a flag. For the Digest authentication,
    provide only the username, as the password will be prompted for.

    The default, "auto", tries to determine the auth type from the
    provided credentials. This only works for Basic auth.

    '''
)


# Generated at 2022-06-11 23:08:15.153438
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_auth_type_lazy_choices,
    help='''
    Explicitly specify an auth plugin to use. Possible values are:

        {choices}

    '''
    if _auth_type_lazy_choices else '',
    choices=_auth_type_lazy_choices
)

# Generated at 2022-06-11 23:08:25.977067
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ('basic', 'digest', 'hawk', 'ntlm')

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism to be used: basic, digest, or hawk.
    Only required if the server requires a non-standard method.
    To list all available auth plugins, run:

        http --debug

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Disable HTTP authentication challenge sending.

    '''
)

# Generated at 2022-06-11 23:08:28.721293
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    actual = []
    for key in iter(_AuthTypeLazyChoices()):
        actual.append(key)
    expected = ['digest', 'hawk']
    assert actual == expected

# Generated at 2022-06-11 23:08:30.156993
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:33.496211
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:14.666477
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # pragma: no cover
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert ['basic', 'digest'] == list(_AuthTypeLazyChoices())



# Generated at 2022-06-11 23:09:25.189066
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # TODO: use `mock`
    global plugin_manager
    _plugin_manager = plugin_manager
    plugin_manager = PluginsManager()

    choices = _AuthTypeLazyChoices()

    assert 'basic' in choices
    assert 'digest' in choices
    assert 'fake' not in choices
    assert sorted(choices) == ['basic', 'digest']

    plugin_manager = _plugin_manager
test__AuthTypeLazyChoices___contains__()


# Generated at 2022-06-11 23:09:27.225213
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    expected = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    actual = list(choices)
    assert expected == actual

# Generated at 2022-06-11 23:09:38.827835
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-11 23:09:40.368388
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), Iterable)



# Generated at 2022-06-11 23:09:49.556377
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify a custom authentication plugin instead of the builtin Basic and
    Digest.

    '''
)

#######################################################################
# HTTP
#######################################################################

http = parser.add_argument_group(title='HTTP')

http.add_argument(
    '--timeout', '-t',
    metavar='SECONDS',
    default=DEFAULT_TIMEOUT,
    type=float,
    help='''
    Specify the timeout in seconds for the connection phase (i.e. the
    i/o operations).

    '''
)

# Generated at 2022-06-11 23:09:51.019376
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk', 'jwt']


# Generated at 2022-06-11 23:10:02.212062
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(sorted(_AuthTypeLazyChoices())) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin. Available plugins include:
    {plugins}.

    The default is "basic" if --auth contains a colon, otherwise "auto".
    The "auto" plugin will use the HTTP Basic auth for all requests.

    '''.format(plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')
timeouts.add_argument

# Generated at 2022-06-11 23:10:09.276800
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class _MockPlugin:
        def __init__(self):
            pass

        @classmethod
        def config_arg_name(cls):
            return 'test'

    class _MockPluginManager:
        def __init__(self):
            pass

        def get_auth_plugin_mapping(self):
            return {
                'test': _MockPlugin
            }
    assert 'test' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:10.655853
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for item in ['flat', 'fruit']:
        assert item in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:11:25.249574
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:11:36.693645
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(AUTH_TYPES) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=AUTH_TYPE_DEFAULT,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Supported mechanisms are:

        {choices}

    The default is "{default}".

    '''.format(
        choices=Formatter().format_choice_list(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        ),
        default=AUTH_TYPE_DEFAULT,
    )
)
