

# Generated at 2022-06-11 23:01:37.757779
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert 'digest' in a
    assert 'fake' not in a
    assert 'basi' not in a

# Generated at 2022-06-11 23:01:42.632409
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # pylint: disable=redefined-outer-name
    it = _AuthTypeLazyChoices()
    # v = pylint: disable=unused-variable
    # The assertion is made in the assertion below.
    v = 'Digest' in it
    v = 'DoesNotExist' in it

# Generated at 2022-06-11 23:01:54.651260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently supported:

    {format_choices_list(sorted(plugin_manager.get_auth_plugin_mapping()))}

    The default auth plugin can be configured in the config file,
    section [defaults], key {KEY_DEFAULT_AUTH}.

    The value is case-insensitive.

    '''
)

#######################################################################
# Output options
#######################################################################

output_options = parser.add_argument_group(title='Output Options')


# Generated at 2022-06-11 23:02:04.568344
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    alc = _AuthTypeLazyChoices()
    assert list(alc) == []
    plugin_manager.get_auth_plugin_mapping()['myauth'] = lambda x: x
    assert list(alc) == ['myauth']
    plugin_manager.get_auth_plugin_mapping()['myauth2'] = lambda x: x
    assert list(alc) == ['myauth', 'myauth2']



# Generated at 2022-06-11 23:02:05.950725
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:02:07.572644
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__(item='')

# Generated at 2022-06-11 23:02:09.356656
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:12.736466
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'key', 'passw', 'oauth2']

# Generated at 2022-06-11 23:02:23.960302
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the auth mechanism to be used. Supported types are:

        {', '.join(_AuthTypeLazyChoices())}

    The default is: {DEFAULT_AUTH_PLUGIN_NAME}

    '''
)
auth.add_argument(
    '--auth-verify',
    action='store_true',
    help='''
    If an auth plugin returns a verification endpoint, verify it by
    sending a GET request to this endpoint.

    '''
)



# Generated at 2022-06-11 23:02:25.474853
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:31.756396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest'
    ]

# Generated at 2022-06-11 23:02:33.815209
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) != []

# Generated at 2022-06-11 23:02:36.121366
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:02:46.514742
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'bearer' in choices

    assert 'BASIC' not in choices
    assert 'BEARER' not in choices



# Generated at 2022-06-11 23:02:50.253422
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices


# Generated at 2022-06-11 23:02:53.816580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

# Generated at 2022-06-11 23:03:05.089731
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an authentication plugin (default is {DEFAULT_AUTH}).
    You can specify plugin options using a JSON-like syntax.
    See the documentation of the particular plugin for details.

    Currently available auth plugins: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    ''',
)

# Generated at 2022-06-11 23:03:13.489654
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set([
        'basic', 'digest', 'hawk', 'ntlm', 'oauth1', 'aws'
    ])

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use:
    {auth_types}
    '''.format(auth_types=plugin_manager.get_plugin_help('auth'))
)



# Generated at 2022-06-11 23:03:16.416830
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:03:29.102603
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication system to use, e.g. "basic".

    ''',
)

#######################################################################
# Custom headers
#######################################################################

headers = parser.add_argument_group(
    title='Custom Headers',
    description='''
    Headers passed with -h/--headers are applied to the request
    AFTER headers set with --auth, --auth-type and --verify.

    '''
)

# Generated at 2022-06-11 23:03:36.109603
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'foo-bar' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:43.393984
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # On instantiation, choices are calculated because there are no plugins
    # in the context where this function is called
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. This can be one of:
    {0}
    or any other authentication plugin installed via
    ``http --debug --plugins-dir=...``.

    The default authentication mechanism is Basic.

    '''.format(
        join_with_human_and(sorted(
            plugin_manager.get_auth_plugins_listing()
        ))
    )
)


# Generated at 2022-06-11 23:03:51.583017
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Force usage of a specific auth plugin:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugins.AUTH_PLUGINS)), 60)
        ).strip()
    )
)
digest_auth_group = auth.add_mutually_exclusive_group()

# Generated at 2022-06-11 23:04:05.274363
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['digest', 'jwt']) == sorted([item for item in _AuthTypeLazyChoices()])
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the authentication method to be used. By default,
    HTTPie tries to determine the authentication method automatically, but
    this option can be used as a fallback. Possible values depend on the
    auth plugins installed.

    ''',
)

#######################################################################
# Secure HTTP
#######################################################################

secure = parser.add_argument_group(title='Secure HTTP')

# Generated at 2022-06-11 23:04:14.446031
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin_name',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin.
    To see a list of supported plugins, use: http --debug

    '''
)

# Generated at 2022-06-11 23:04:25.305621
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Authentication type to be used. If not specified, the following
    heuristics are applied:

    1. If --auth is provided, Basic authentication is used.
    2. If --auth-type is validated against a list of supported auth types based
       on the --auth option is used.
    3. If --auth-type is not used, the server response is examined, and if
       the server indicates that it supports Digest authentication, then
       Digest authentication is used.

    The supported authentication types depend on the installed plugins.
    Try --auth-type for the full list.

    '''
)

#

# Generated at 2022-06-11 23:04:33.772061
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def test(name, expected):
        actual = list(_AuthTypeLazyChoices())
        assert actual == sorted(expected), (name, actual)

    test('empty', [])
    test('load by class', ['class'])
    test('load by package', ['package'])
    test('load by module', ['module'])



# Generated at 2022-06-11 23:04:44.839431
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'bearer' in choices
    assert 'digest' in choices

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the auth plugin to use for the given --auth credentials.
    Defaults to basic, digest, or bearer based on the credentials provided.

    ''',
)


# Generated at 2022-06-11 23:04:49.028545
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:58.592517
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass

auth_plugin_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_plugin_choices,
    help='''
    Specify a custom auth plugin type.
    Available choices: %(choices)s.

    '''
)

#######################################################################
# Configuration
#######################################################################

configuration = parser.add_argument_group(title='Configuration')
conf_parser = configuration.add_mutually_exclusive_group()

# Generated at 2022-06-11 23:05:08.229183
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # init
    _AuthTypeLazyChoices()
    # Use the only __contains__ method
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:09.514496
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('hawk')



# Generated at 2022-06-11 23:05:21.084189
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(plugin_manager.get_auth_plugin_mapping().keys())) == \
           list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    action='append',
    default=None,
    dest='auth_types',
    choices=_AuthTypeLazyChoices(),
    metavar='NAME',
    help=f'''
    The auth plugin to be used. Available plugins are: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}
    ''',
)


# Generated at 2022-06-11 23:05:32.867701
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(_AuthTypeLazyChoices())
    assert next(it) == 'basic'
    assert next(it) == 'digest'
    assert next(it) == 'fake-basic'
    assert next(it) == 'fake-digest'
    assert next(it) == 'fake-ntlm'
    assert list(it) == ['fake-oauth1', 'fake-ntlm-implicit', 'fake-ntlm-negotiate']
    assert list(iter(_AuthTypeLazyChoices())) == ['basic', 'digest', 'fake-basic', 'fake-digest', 'fake-ntlm', 'fake-oauth1', 'fake-ntlm-implicit', 'fake-ntlm-negotiate']

# Generated at 2022-06-11 23:05:43.426453
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    default=None,
    help=f'''
    Specify the auth implementation to use. The default is "auto" (which means
    that HTTPie tries to guess the auth type).
    This option is useful when the scheme matches multiple auth types.
    For example, "httpie --auth-type=basic https://mydomain.com"

    Currently supported types: {', '.join(iter(_AuthTypeLazyChoices()))}

    ''',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
)



# Generated at 2022-06-11 23:05:57.111079
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The default authentication plugin.
    This can be overridden by using the <PLUGIN>: prefix when using the
    --auth flag.

    Authentication plugins:
        {plugins}
    '''.format(
        plugins='\n        '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)

#######################################################################
# Cookies
#######################################################################

# ``requests.request`` keyword arguments.
cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:05:58.551246
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [] == list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:06:10.196834
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    plugin_manager.get_auth_plugin_mapping()
_AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Use a custom HTTP Authenticator plugin.

    Use `{prog} auth-plugin` to see a list of available plugins.

    '''.format(prog=os.path.basename(sys.argv[0]))
)

# Generated at 2022-06-11 23:06:12.413319
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'BasicFake' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:06:23.576605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. By default (i.e., if this option
    is not specified), an appropriate mechanism is selected automatically
    based on the provided credentials.

    Available mechanisms (plugins):

        {auth_plugins}

    '''.format(
        auth_plugins='\n'.join(
            ('    ' + line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60))
    )
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group

# Generated at 2022-06-11 23:06:45.343876
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an auth plugin to be used.
    HTTPie will attempt to guess the plugin.

    '''
)
auth.add_argument(
    '--auth-no-guess',
    action='store_true',
    default=False,
    help='''
    Prevent HTTPie from guessing the auth plugin.
    For instance, it won't try Digest auth when the server responds with a 401
    status.

    '''
)

# Generated at 2022-06-11 23:06:54.912294
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # noqa
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified HTTP Auth type (Basic, Digest, ...).
    The default "auto" value picks it based on the provided URL.

    '''
)
auth.add_argument(
    '--auth-types',
    action='store_true',
    help='''
    Print a list of supported auth plugins.

    '''
)

# Generated at 2022-06-11 23:07:07.244324
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:09.369070
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for item in list(_AuthTypeLazyChoices()):
        assert item in _AuthTypeLazyChoices

# Generated at 2022-06-11 23:07:13.853528
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    loaded_auth_plugins = plugin_manager.get_auth_plugin_mapping()
    for name in _AuthTypeLazyChoices():
        assert name in loaded_auth_plugins

# Generated at 2022-06-11 23:07:25.460657
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    iter(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    type=str.lower,
    help='''
    Specify a custom authentication plugin, if any.
    Available plugins:
    {0}

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping()))
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    Specify a custom host to use for authentication.
    The --auth-host has to be a valid HTTP or HTTPS URL.

    '''
)

# Generated at 2022-06-11 23:07:34.779146
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'multi', 'netrc']

_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

auth_type_default = 'basic' if 'basic' in _plugin_mapping else None
auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=auth_type_default,
    choices=auth_type_choices,
    help=f'''
    The type of the authentication.

    Available types:

    {plugin_manager.get_plugin_help(plugin_manager.get_auth_plugins())}

    '''
)

auth_preset_validator = AuthCredentialsPresetValidator()
auth_preset = os

# Generated at 2022-06-11 23:07:38.529360
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    c = _AuthTypeLazyChoices()
    assert 'basic' in c
    assert 'digest' in c
    assert 'custom_auth_type' not in c


# Generated at 2022-06-11 23:07:48.368276
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    try:
        it = iter(_AuthTypeLazyChoices())
        __next = getattr(it, '__next__', getattr(it, 'next'))
        while True:
            result = __next()
    except StopIteration:
        pass
    return


# Generated at 2022-06-11 23:08:00.174260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    fail_unless_choices_equal(_AuthTypeLazyChoices(), [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oath',
    ])


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use. httpie always attempts to  detect  the  auth  type
    automatically.

    ''',
)

# Generated at 2022-06-11 23:08:30.363447
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:08:34.573619
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa: E302, WPS432
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'doesnotexist' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:45.051912
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'foo' not in auth_type
    assert 'basic' in list(auth_type)


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used. Valid choices depend
    on the installed plugins. By default, HTTPie looks for plugins in
    the following locations:

        {plugin_dirs}

    You can also use `--debug` to get a list of all installed plugins.

    '''.format(
        plugin_dirs='\n'.join(f'    {p}' for p in plugin_manager.directories),
    )
)
auth.add

# Generated at 2022-06-11 23:08:46.875941
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa: E302
    assert 'basic' in _AuthTypeLazyChoices() # noqa: E302

# Generated at 2022-06-11 23:08:59.472476
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test that calling __iter__ of _AuthTypeLazyChoices() raises no exception.
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to be used. If not provided,
    HTTPie would attempt to infer the auth type by inspecting
    the URL, and in that case a warning is printed.

    '''
)
auth.add_argument(
    '--auth-type-needs-password',
    default=False,
    action='store_true',
    help=SUPPRESS
)

# Generated at 2022-06-11 23:09:09.350116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        for plugin in AUTH_PLUGIN_MAP:
            assert plugin in _AuthTypeLazyChoices()
    except ImportError:
        pass
    else:
        assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:09:10.618282
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:12.356868
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-11 23:09:16.742754
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''Unit test for method __contains__ of class _AuthTypeLazyChoices'''
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'ntlm' in choices
    assert 'mock' not in choices

# Generated at 2022-06-11 23:09:19.044826
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = iter(_AuthTypeLazyChoices())
    assert next(auth_type_choices) == 'basic'


# Generated at 2022-06-11 23:10:19.513320
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:29.431678
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    # TODO: mock base_plugin and test import errors

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Client implementation to use. If not provided, an appropriate one is chosen
    based on the --auth option.

    The following built-in types are available:

    '''
)

# Generated at 2022-06-11 23:10:34.094698
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Check that __contains__ raise TypeError"""
    # pylint: disable=unused-variable
    authtype = _AuthTypeLazyChoices()
    try:
        item = 1
        bool(1 in authtype)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-11 23:10:43.116719
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices_iter = iter(_AuthTypeLazyChoices())
    assert next(_AuthTypeLazyChoices_iter) == "basic"
    assert next(_AuthTypeLazyChoices_iter) == "digest"
    assert [element for element in _AuthTypeLazyChoices_iter] == []
test__AuthTypeLazyChoices___iter__.test_name = str(
    _AuthTypeLazyChoices.__iter__.__name__
)
    # need to set the name because otherwise the test's name
    # is the name of the test wrapper function


# Generated at 2022-06-11 23:10:54.194658
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic') == True
    assert choices.__iter__() == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=argparse.SUPPRESS,
)

auth.add_argument(
    '--auth-digest',
    action='store_true',
    help='''
    Use HTTP Digest authentication.
    (implies --auth-type=digest)

    '''
)


# Generated at 2022-06-11 23:10:57.199799
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:11:05.164959
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default, the authentication
    mechanism is guessed from the provided credentials, or Basic if no
    credentials have been provided.

    You can explicitly specify the authentication mechanism to use:

        --auth-type=basic
        --auth-type=digest

    '''
)


# Generated at 2022-06-11 23:11:07.953474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:11:19.823776
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices."""
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=auth_type_choices,
    help='''
    Specify a custom auth plugin. See the Authentication Plugins docs:

    https://httpie.org/plugins#authentication

    '''
)


# Generated at 2022-06-11 23:11:21.101269
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    >>> 'basic' in _AuthTypeLazyChoices()
    True
    """