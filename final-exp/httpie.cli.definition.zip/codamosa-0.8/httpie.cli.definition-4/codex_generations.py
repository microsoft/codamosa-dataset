

# Generated at 2022-06-11 23:01:40.737073
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # This docstring is parsed by pytest.
    from requests_toolbelt import _auth
    from requests_toolbelt.auth.aws._SigV4Auth import SigV4Auth
    from requests_toolbelt.auth.ntlm import HttpNtlmAuth
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert 'aws' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:01:53.294528
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert(set(_AuthTypeLazyChoices()) == set(
        ['basic', 'digest', 'jwt']))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify the authentication mechanism to be used.

    Available auth types: {', '.join(_AuthTypeLazyChoices())}

    '''
)
auth.add_argument(
    '--auth-send',
    dest='auth_send',
    choices=AUTH_SEND_CHOICES,
    default=AUTH_SEND_CHOICES[0],
    help=f'''
    Which request to send the credentials with.

    Available values: {', '.join(AUTH_SEND_CHOICES)}

    '''
)
auth.add_

# Generated at 2022-06-11 23:02:04.155225
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert list(choices) == ['basic']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''\
    The auth mechanism to use.

    It is either one of the builtin types or a path to a plugin.

    '''
)

# Generated at 2022-06-11 23:02:17.424381
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# noinspection PyTypeChecker
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication handler to use. When set to "auto" (default),
    HTTPie tries to guess the plugin based on the server headers. This
    works well for basic and digest auth.

    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Do not use .netrc for fetching passwords. By default, HTTPie
    searches for .netrc in the user HOME directory.

    '''
)

#######################################################################
# HTTPS
#######################################################################

https = parser

# Generated at 2022-06-11 23:02:28.137935
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'basic']

auth_type_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help='''
    Specify an HTTP auth type, by default HTTPie tries to guess.
    Currently supported auth types: {0}

    '''.format(', '.join(sorted(auth_type_choices)))
)

auth.add_argument(
    '--auth-reuse',
    action='store_true',
    default=None,
    help='''
    Send auth credentials to any host, instead of only those that match
    the --auth or --netrc options, if any.

    '''
)

################################

# Generated at 2022-06-11 23:02:30.848293
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in _AuthTypeLazyChoices()] == list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:02:40.446192
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert "basic" in choices


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='auto|<TYPE>',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth plugin to use. The default is 'auto', which will use
    the best plugin based on the URL scheme and the presence of
    the auth plugin for that scheme (see "http --help-auth").

    Supported values:

    {formatted_auth_type_choices}

    '''
)
auth.add_argument(
    '--auth-nonce',
    help='''
    Provide a custom nonce for Digest auth.

    '''
)

# Generated at 2022-06-11 23:02:53.037707
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert len(choices) == len(set(choices))
    assert len(choices) == len(plugin_manager.get_auth_plugin_mapping())
    for choice in choices:
        assert choice in plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-11 23:02:57.998732
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for item in choices:
        assert item in choices
    for item in ['digest', 'digest2', 'non-existsing-choice']:
        if item not in plugin_manager.get_auth_plugin_mapping():
            assert item not in choices

# Generated at 2022-06-11 23:03:07.862889
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'netrc' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices

    sorted_auth_type_lazy_choices = sorted(auth_type_lazy_choices)
    assert sorted_auth_type_lazy_choices[0] == 'basic'
    assert sorted_auth_type_lazy_choices[1] == 'digest'
    assert sorted_auth_type_lazy_choices[2] == 'hawk'
    assert sorted_auth

# Generated at 2022-06-11 23:03:15.414847
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    acl = _AuthTypeLazyChoices()
    assert 'dummy' in acl
    assert 'fancy' in acl
    assert 'does-not-exist' not in acl


# Generated at 2022-06-11 23:03:28.307003
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    possible_values = [
        'basic',
        'digest',
    ]
    assert all(value in _AuthTypeLazyChoices() for value in possible_values)
    assert sorted(_AuthTypeLazyChoices()) == sorted(possible_values)

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use. Possible values:

        {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))),
)


# Generated at 2022-06-11 23:03:29.868964
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:40.232133
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert('basic' in _AuthTypeLazyChoices())

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Anything that is supported by
    `requests` is supported here. See `request --help` for currently supported
    types.

    ''',
)

for auth_plugin in plugin_manager.get_auth_plugins().values():
    auth.add_argument(
        *auth_plugin.args,
        **auth_plugin.kwargs
    )

#######################################################################
# Options common to both plain HTTPie and HTTPie-0.9.7+
#######################################################################


# Generated at 2022-06-11 23:03:44.786516
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test for the format of help for the plugin
    assert 'Digest' in _AuthTypeLazyChoices()
# Test __iter__ of class _AuthTypeLazyChoices ends


# Generated at 2022-06-11 23:03:47.493559
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:03:55.071019
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Unit test for constructor of class _AuthTypeLazyChoices"""
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:57.050504
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()  # noqa: F811

# Generated at 2022-06-11 23:04:03.306548
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Given
    auth_type_lazy_choices_instance = _AuthTypeLazyChoices()
    # When
    result = tuple(auth_type_lazy_choices_instance)
    # Then
    assert result == ('basic', 'digest')

# Generated at 2022-06-11 23:04:06.552670
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['Basic', 'Digest', 'custom']) == sorted(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:04:24.840631
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    action=EnvarArgument('AUTH_TYPE', 'AUTH_TYPE'),
    choices=_AuthTypeLazyChoices(),
    default=guess_auth()
)

auth.add_argument(
    '--ignore-netrc',
    default=False,
    action='store_true',
    help='''
    Ignore the .netrc file. Note that the .netrc file is usually ignored
    when credentials are provided via -a.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_

# Generated at 2022-06-11 23:04:26.086247
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:04:28.318038
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'abc' in lazy_choices
    assert 'abc' not in lazy_choices


# Generated at 2022-06-11 23:04:39.334171
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['digest']) == sorted(list(_AuthTypeLazyChoices()))


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The mechanism used to encode the credentials. This might be useful
    when a server requires a specific method.

    The choice of {0} has no effect and is preserved for compatibility only.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping().keys()))
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    If set, this endpoint is used for authentication. It is useful for a
    standalone authentication server.

    '''
)



# Generated at 2022-06-11 23:04:51.971278
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest'] # TODO: https://github.com/httpie/httpie/issues/388

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    The default is "auto", which means that the authentication mechanism
    is inferred from the URL. If the URL is recognized as belonging to any
    of the supported services (such as Github), the appropriate plugin
    is used.

    '''
)

# Generated at 2022-06-11 23:05:01.387117
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    res = _AuthTypeLazyChoices()
    for auth_type in res:
        assert auth_type in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=list(_AuthTypeLazyChoices()),
    help='''
    Authentication type (default: auto).

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:05:13.102513
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for x in _AuthTypeLazyChoices():
        pass

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    dest='auth_plugin',
    metavar='TYPE',
    help=f'''
    The auth mechanism to be used.

    Currently supported mechanisms:
        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Plugins can define more.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    dest='auth_no_challenge',
    default=False,
    help='''
    Disable HTTP authentication challenge.

    '''
)

#######################################################################
#

# Generated at 2022-06-11 23:05:23.683883
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'hawk' in lazy_choices
    assert 'custom' in lazy_choices
    assert 'httpdigest' in lazy_choices
    assert 'digest' in sorted(lazy_choices)
    assert 'hawk' in sorted(lazy_choices)
    assert 'basic' in sorted(lazy_choices)
    assert 'custom' in sorted(lazy_choices)
    assert 'httpdigest' in sorted(lazy_choices)
    assert 'digest' in iter(lazy_choices)
    assert 'hawk' in iter(lazy_choices)
    assert 'basic' in iter(lazy_choices)

# Generated at 2022-06-11 23:05:34.158884
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # need to initialize plugin manager first
    from httpie import plugin_manager
    from httpie.plugins import plugin_manager as plugin_manager2
    assert plugin_manager is plugin_manager2

    choices = _AuthTypeLazyChoices()
    assert not isinstance(choices, list)
    assert 'basic' in choices
    assert 'digest' in choices
    # add 'test' to plugin mapping
    plugin_manager._plugin_mappings['auth']['test'] = 'test'
    assert 'test' in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:05:37.458249
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:05:49.552376
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "keyring" in _AuthTypeLazyChoices()
    assert "non-existent-plugin" not in _AuthTypeLazyChoices()
# Unit tests for method __iter__ of class _AuthTypeLazyChoices

# Generated at 2022-06-11 23:06:00.932950
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert [] != list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    If not specified and the --auth option is supplied, an attempt is made to
    guess which one to use.
    The option is case-insensitive and accepts a substring of the authentication
    type name, e.g.:

        --auth-type=aws

    explicit string (available are {", ".join(_AuthTypeLazyChoices())}):
    '''
)


# Generated at 2022-06-11 23:06:11.662889
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    This option allows you to specify authentication methods that
    are not natively supported by HTTPie, e.g., "aws" for AWS
    authentication.

    For more information and a list of supported types,
    please use the "--help-auth" option.

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:06:14.110379
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'non-existing-plugin' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:06:19.127761
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

# Plugin-provided auth types.
# Choices are populated lazily
# so that we can run tests without having to load plugins.
auth_type = auth.add_argument(
    '--auth-type',
    help='''
    Specify the authentication mechanism used by the server.
    Choices: {choices}

    ''',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default=None
)
# see https://github.com/jakubroztocil/httpie/issues/41
auth_type.completer = ChoicesCompleter(auth_type.choices)


# ``requests.request`` keyword arguments.
verify = parser.add_argument_group(title='SSL Verification')
verify.add_argument

# Generated at 2022-06-11 23:06:26.253128
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_choices
    assert list(auth_choices)


auth.add_argument(
    '--auth-type',
    default=None,
    type=(lambda value: value.lower()),
    # Choices must have been loaded by this time
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication type to be used. Currently supported:

        '{auth_plugins}'

    '''.format(
        auth_plugins="', '".join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

# Generated at 2022-06-11 23:06:38.950254
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    iterator = _AuthTypeLazyChoices()
    assert isinstance(iterator, _AuthTypeLazyChoices)
    assert set(iterator) == set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    assert 'digest' in iterator
    assert 'ntlm' in iterator

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-11 23:06:46.079303
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom HTTP auth type. The values are plugin names.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
private_key = ssl.add_mutually_exclusive_group()
private_key.add_argument(
    '--ssl-key',
    metavar='PATH',
    help='''
    Path to a private key file for SSL client authentication.

    '''
)

# Generated at 2022-06-11 23:06:55.245921
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from . import auth as auth_mod
    choices = auth_mod._AuthTypeLazyChoices()
    assert isinstance(choices, Iterable)
    assert set(choices) == set(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN,
    help=f'''
    The authentication mechanism.

    {plugin_manager.get_plugin_help_string("auth")}

    '''
)

#######################################################################
# TLS
#######################################################################

tls = parser.add_argument_group(title='TLS')


# Generated at 2022-06-11 23:06:59.880009
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    choices = _AuthTypeLazyChoices()

    assert choices.__contains__('basic') == True

    result = [choice for choice in choices]

    assert result == ['basic', 'digest']


# Generated at 2022-06-11 23:07:21.406703
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Authentication method to be used. HTTPie ships with the following plugins:

        {auth_types_list}

    See also: {plugin_manager.PLUGIN_META_URL}.

    '''.format(
        auth_types_list='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)



# Generated at 2022-06-11 23:07:32.473612
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)

auth_type_choices_lazy = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=auth_type_choices_lazy,
    help='''
    The authentication mechanism to be used. The default is "basic". Other
    options are:

    {plugin_names}

    '''.format(plugin_names=plugin_manager.get_auth_plugin_help())
)
auth.add_argument(
    '--digest',
    default=False,
    action='store_true',
    help='''
    Use HTTP Digest Authentication. This is the default.

    '''
)

# Generated at 2022-06-11 23:07:43.752804
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=f'''
    Auto-detect auth type if --auth= is set.

    The following auth types are currently supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Use "{'basi'}" instead of "{'basic'}" for Basic auth.

    Use "{'dige'}" instead of "{'digest'}" for Digest auth.

    Use "{'AWS4'}" instead of "{'aws4_request'}" for AWS Signature v4.

    '''
)

# Generated at 2022-06-11 23:07:45.665728
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'http-basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:07:49.056613
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == {'basic', 'digest'}
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-11 23:08:00.646634
# Unit test for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-11 23:08:04.753441
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class MockAuthPluginManager:
        @staticmethod
        def get_auth_plugin_mapping():
            return {}
    plugin_manager = MockAuthPluginManager()
    choices = _AuthTypeLazyChoices()
    assert list(choices) == []


# Generated at 2022-06-11 23:08:10.789329
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'auto' in _AuthTypeLazyChoices()
    assert 'CustomAuthPlugin' in _AuthTypeLazyChoices()
    assert 'CustomAuthPlugin2' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:21.446562
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['']) == set(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin module. Use the empty string
    ("") to select the default authentication method implemented by Requests.
    Only relevant when the --auth option is provided.

    ''',
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    default=False,
    help='Show list of available auth plugins and exit.'
)

#######################################################################
# Proxies
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-11 23:08:29.549562
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. It can be one of the
    following values:

        {0}

    '''.strip().format(
        '\n'.join(
            ('{0}{1}'.format(8 * ' ', line.strip()))
            for line in wrap(
                ', '.join(sorted(
                    plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

#######################################################################
#  HTTPS
#######################################################################

https = parser.add

# Generated at 2022-06-11 23:09:05.377766
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()  # noqa: F821

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin to be used for authentication.
    The plugin must be installed through a plugin manager
    (see https://github.com/jakubroztocil/httpie#plugins).

    Available plugins:

        {plugin_manager.get_auth_plugin_mapping().keys()}

    '''
)

# Generated at 2022-06-11 23:09:16.322110
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism via one of the supported auth plugins.
    See 'list --auth-type' for available options.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-11 23:09:22.367134
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''
    >>> assert 'basic' in _AuthTypeLazyChoices()
    >>> assert 'bearer' in _AuthTypeLazyChoices()
    >>> assert 'digest' in _AuthTypeLazyChoices()
    >>> assert 'hawk' in _AuthTypeLazyChoices()
    >>> assert 'hmac' in _AuthTypeLazyChoices()
    '''


# Generated at 2022-06-11 23:09:24.461557
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted([x for x in _AuthTypeLazyChoices()]) == sorted(["digest", "jwt", "hawk"])

# Generated at 2022-06-11 23:09:33.540155
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:09:37.400938
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'netrc',
        'oauth1',
        'oauth2'
    ]


# Generated at 2022-06-11 23:09:39.414260
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:09:48.758870
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Default value for mock
    return list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Example:  --auth-type=jwt

    ''',
)
auth.add_argument(
    '--auth-type-general',
    metavar='GENERAL_AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The general authentication mechanism.

    Example:  --auth-type-general=jwt

    ''',
)

#######################################################################
# SSL/TLS
#######################################################################

ssl = parser.add

# Generated at 2022-06-11 23:09:55.726053
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to use. Currently supported:
        {auth_types}
    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Files
#######################################################################

files = parser.add_argument_group(title='Files')


# Generated at 2022-06-11 23:09:58.685429
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'html-form' in choices
    assert 'dummy' not in choices

# Generated at 2022-06-11 23:11:05.999939
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-11 23:11:18.014066
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'session' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an authentication plugin to be used to setup the authentication
    values.

    Use `http --debug` to see the list of plugin names and its options.

    For example, the following will use the "netrc" plugin to authenticate
    against a site defined in the users's ~/.netrc file:

        http --auth-type=netrc https://example.org/

    '''
)

auth_plugin_options = parser.add_argument_group(title='Authentication Plugins Options')


# Generated at 2022-06-11 23:11:25.863981
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # type: () -> None
    LazyChoices = _AuthTypeLazyChoices()
    assert 'basic' in LazyChoices
    assert 'digest' in LazyChoices
    assert 'aws-s3' in LazyChoices


# Generated at 2022-06-11 23:11:37.365109
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    Needed for unit test for method __contains__ of class _AuthTypeLazyChoices
    """
    from_class = set(_AuthTypeLazyChoices())
    all_plugins = set(plugin_manager.get_auth_plugin_mapping().keys())
    assert all_plugins.issubset(from_class)


# Supported auth schemes.
# TODO: should be plugin-based.