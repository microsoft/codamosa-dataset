

# Generated at 2022-06-11 23:01:42.643127
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(list(choices)) == ['basic', 'digest', 'jwt']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of auth credentials. If provided, overrides the heuristics used
    when auto-determining the auth type from the --auth value (USER[:PASS]).

    Currently supported types: {sorted(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:01:54.654470
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    iter(_AuthTypeLazyChoices())

auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-11 23:01:57.242933
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:01:59.629385
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices


# Generated at 2022-06-11 23:02:11.368309
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Given
    auth_types = _AuthTypeLazyChoices()
    # When
    result = [choice for choice in auth_types]
    # Then
    assert result == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.
    The default is "basic".

    Available types:
    {0}
    '''.format(
        '\n'.join(
            ['    - {0}'.format(name) for name in sorted(
                plugin_manager.get_auth_plugin_mapping().keys()
            )]
        )
    )
)
auth.add

# Generated at 2022-06-11 23:02:23.301393
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:02:25.258182
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-11 23:02:26.939023
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AuthPlugin.Basic in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:02:38.226886
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism (digest, basic, or auto).
    The default is "auto", which tries to autodetect the authentication type.

    '''
)

#######################################################################
# SSL
#######################################################################
ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-11 23:02:50.261019
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_help = '''
    The authentication type to use.

    This option is only required for more complex authorization schemes, such
    as Digest, which cannot be performed without it.

    {0}
    '''.strip().format(
    f'With no plugins installed (the default), '
    f'the only choice is {DEFAULT_AUTH_PLUGIN}.'
)
auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    type=AuthPluginType,
    default=DEFAULT_AUTH_PLUGIN,
    help=_auth_type_help
)

# Generated at 2022-06-11 23:02:58.605266
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert isinstance(a, _AuthTypeLazyChoices)
    assert list(a) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Unit tests for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-11 23:03:08.208781
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert set(lazy_choices) == set(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:03:20.604168
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Exercise method __iter__ of class _AuthTypeLazyChoices"""
    choices = _AuthTypeLazyChoices()
    assert set(choices) == set(plugin_manager.REGISTERED_AUTH_PLUGINS)
test__AuthTypeLazyChoices___iter__()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the authentication plugin.
    This is {default} by default.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME
    )
)

# Generated at 2022-06-11 23:03:23.349260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['digest', 'basic']) == set(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:03:35.328668
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == \
           set(plugin_manager.get_auth_plugin_mapping().keys())

# ``requests.auth.HTTPBasicAuth`` keyword arguments.
auth_type = parser.add_argument_group('Authentication') \
    .add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:
    ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)

# ``requests.auth.HTTPDigestAuth`` keyword arguments.

# Generated at 2022-06-11 23:03:38.674143
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices
    assert 'fake_auth' not in auth_type_lazy_choices


# Generated at 2022-06-11 23:03:44.995272
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'foo' not in auth_type_lazy_choices



# Generated at 2022-06-11 23:03:46.611822
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print(list(_AuthTypeLazyChoices()))

# Generated at 2022-06-11 23:03:50.162092
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test method __iter__ of class _AuthTypeLazyChoices
    """

    assert set(_AuthTypeLazyChoices()) >= {'basic', 'digest'}


# Generated at 2022-06-11 23:04:03.781550
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping()))


# Generated at 2022-06-11 23:04:22.186207
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    for plugin in plugin_manager.get_auth_plugin_mapping():
        assert plugin in auth_types


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Use an authentication plugin that has been installed via "http --plugins".

    '''
)

# requests.auth.HTTPBasicAuth, HTTPTokenAuth, HTTPDigestAuth.
auth.add_argument(
    '--auth-type', '-A',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Try to choose the most secure authentication type
    supported by the server.

    '''
)


#######################################################################
# SSL/

# Generated at 2022-06-11 23:04:31.537347
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    l = _AuthTypeLazyChoices()
    expected = plugin_manager.get_auth_plugin_mapping().keys()
    assert set(l) == expected

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.'''
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group('SSL', description=None)

ssl_group.add_argument(
    '--verify', '-k',
    default=True,
    action='store_true',
    help='''
    Turn on SSL certificate verification.
    '''
)


# Generated at 2022-06-11 23:04:34.665638
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'not-exists' not in choices

# Generated at 2022-06-11 23:04:36.091813
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(['digest'])



# Generated at 2022-06-11 23:04:45.489510
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism (plugin) to use.
    The default is '{'basic'}'.

    ''',
)
auth.add_argument(
    '--auth-no-challenge', '-n',
    action='store_true',
    default=False,
    help='''
    Disable sending default auth headers when authorization
    is not provided.

    This can be useful when authentication is handled by
    a custom HTTP proxy or a web server itself.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies

# Generated at 2022-06-11 23:04:56.908249
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'nonsense' not in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used. Currently supported values:

        {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-11 23:05:05.447582
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert(list(choices) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys())))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=AuthPlugin,
    choices=list(_AuthTypeLazyChoices()),
    help=f'''
    The authentication mechanism.

    {HELP_OPTIONS_STRING}
    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:05:14.553686
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # pylint: disable=unused-variable
    from httpie.cli import output
    assert list(iter(_AuthTypeLazyChoices())) == ['basic', 'digest']

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Specify an authentication type/plugin. By default, basic/digest
    authentication is used.

    Plugins:

    {plugins.get_auth_help()}

    '''
)

#######################################################################
# Configuration
#######################################################################

config = parser.add_argument_group(title='Configuration')


# Generated at 2022-06-11 23:05:24.728679
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin to be used.

    Use the --debug flag to learn which plugins are available.

    '''
)


#######################################################################
# Uploads (implicit form)
#######################################################################


# Generated at 2022-06-11 23:05:34.786502
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    _AuthTypeLazyChoices.__contains__
    """
    # import pytest  # isort:skip
    # pytest.skip("TODO: tests for _AuthTypeLazyChoices")
    import pytest  # isort:skip

    pytest.skip("TODO: tests for _AuthTypeLazyChoices")



# Generated at 2022-06-11 23:05:49.626600
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()


auth_type_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:05:53.221265
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.test_auth import test__AuthTypeLazyChoices___iter__
    test__AuthTypeLazyChoices___iter__(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:06:02.440958
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    iter(choices)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a custom auth plugin by name.
    This is useful when the auth plugin name is different than
    its module name.

    '''
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    metavar='PLUGIN',
    dest='auth_type',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-11 23:06:06.272225
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert_equal(
        'basic' in _AuthTypeLazyChoices(),
        any(isinstance(p, BasicAuthPlugin) for p
            in plugin_manager.get_auth_plugins())
    )



# Generated at 2022-06-11 23:06:13.881286
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'Basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'Digest' in auth_type_choices
    assert 'other_auth' not in auth_type_choices
    assert 'unknown' not in auth_type_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly set auth type (basic, digest). If not provided,
    HTTPie guesses the auth type based on the provided --auth value.

    '''
)


# Generated at 2022-06-11 23:06:24.385188
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'bearer' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'kerberos' in auth_type_choices
    assert 'aws' in auth_type_choices
    assert 'google' in auth_type_choices
    assert 'aws-s3' in auth_type_choices



# Generated at 2022-06-11 23:06:36.825157
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(plugin_manager.get_auth_plugin_mapping()) == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify the auth plugin type to use.
    This is useful when the server uses a custom authorization method,
    or when you want to override the default Basic plugin.

    Available types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-11 23:06:38.084621
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:39.457550
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:50.464057
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    type=AuthCredentials,
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    HTTP authentication type (Plugin based, Basic or Digest).
    Type `auto' is currently only working with Basic Auth and
    negotiates between Basic and Digest.

    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--proxy-auth', '-A',
    default=None,
    metavar='USER[:PASS]',
    help='''
    If only the username is provided (-A username), HTTPie will prompt
    for the password.

    '''
)

# ``requests

# Generated at 2022-06-11 23:07:30.103328
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

auth_type_validator = AuthTypeValidator(
    'Authentication type must be one of {choices}'.format(
        choices=_AuthTypeLazyChoices()
    )
)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=auth_type_validator,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of authentication to use. The default is Basic,
    which is the only auth type included in HTTPie itself.

    Install the [httpie-auth-plugin][] to use other types.

    [httpie-auth-plugin]: https://github.com/jakubroztocil/httpie-auth-plugin

    '''
)


# Generated at 2022-06-11 23:07:37.089816
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'digest', 'hawk', 'jwt', 'oauth1', 'oauth2'
    ]

auth.add_argument(
    '--auth-type', '--auth-scheme',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication type (scheme).
    This is auto-detected by default.

    '''
)
auth.add_argument(
    '--auth-host',
    default='',
    help='''
    The host to authenticate against.  This is required if the
    AUTH_HOST environment variable is not set.

    '''
)

# Generated at 2022-06-11 23:07:46.138421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism.

    One of the {types}

    '''.format(types='\n    '.join(
        [''] + list(plugin_manager.get_auth_plugin_mapping().keys())))
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Don't use .netrc file for authentication.

    '''
)

# Generated at 2022-06-11 23:07:51.160544
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth_type_default = 'basic'
auth.add_argument(
    '--auth-type',
    default=auth_type_default,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    The authentication mechanism to be used:

        basic HTTP Basic authentication (default)
        digest HTTP Digest authentication
        {plugin_manager.get_auth_plugin_mapping_help()}

    Note that using Basic Authentication over an unencrypted connection exposes
    your credentials to third parties.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-11 23:08:02.399059
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of authentication used in the request. This can be one of:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default is to automatically detect the auth type when --auth
    is provided.

    '''
)
auth.add_argument(
    '--auth-host',
    help='''
    Sent as `host` param to the auth plugin. Only relevant when
    --auth-type=auto is used.

    '''
)

################################################################

# Generated at 2022-06-11 23:08:13.172148
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'multipart' in choices


auth_plugin_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH,
    choices=auth_plugin_choices,
    help=f'''
    The authentication mechanism to be used.
    The valid values depend on the plugins that are installed.
    The default value is "{DEFAULT_AUTH}".

    '''
)

# Generated at 2022-06-11 23:08:24.222664
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())
auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    # Explicitly set to None so that the default don't get shown in the docs.
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used for the request.

    If not specified, HTTPie will try to guess it based on the provided
    URL and credentials.
    '''
)


# Generated at 2022-06-11 23:08:30.921434
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
_AuthTypeLazyChoices.__test__ = False

auth.add_argument(
    '--auth-type',
    default=None,
    type=lambda v: v.lower(),
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.
    The value can be one of:

        {plugins}

    '''.format(plugins='\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
    ).strip())
)

# Generated at 2022-06-11 23:08:41.027547
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'noauth' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()
    assert 'aws4' in _AuthTypeLazyChoices()
    assert 'aws4-unsigned-body' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:49.008601
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Set the authentication mechanism. Currently supported:

        {auth_types}

    If not specified, the authentication mechanism is automatically detected,
    based on the provided --auth value's prefix.
    '''.format(
        auth_types='\n\t'.join(
            [
                '{0}: {1}'.format(
                    plugin_name, plugin.AuthPlugin.get_auth_type_name())
                for plugin_name, plugin in
                plugin_manager.get_auth_plugin_mapping().items()
            ]
        )
    )
)
auth.add_

# Generated at 2022-06-11 23:09:49.394412
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'awsv4' in _AuthTypeLazyChoices()

# Test for items() of class _AuthTypeLazyChoices

# Generated at 2022-06-11 23:09:51.679748
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager = tests.plugin_manager
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


# Generated at 2022-06-11 23:09:52.998750
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:05.468353
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(sorted([
        AUTH_PLUGIN_MAP['basic'].auth_type,
        AUTH_PLUGIN_MAP['digest'].auth_type,
        AUTH_PLUGIN_MAP['bearer'].auth_type,
        AUTH_PLUGIN_MAP['hawk'].auth_type
    ])) == set(
        ['basic', 'digest', 'bearer', 'hawk']
    )

auth_type_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:10:10.353380
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockPluginManager:
        @staticmethod
        def get_auth_plugin_mapping():
            return {'mock': 'mock'}
    plugin_manager = MockPluginManager()
    assert 'mock' in _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping = lambda: {}
    assert 'mock' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:21.553454
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import httpie.auth.plugins
    for name in httpie.auth.plugins.__all__:
        __import__('httpie.auth.plugins.{0}'.format(name))
    assert isinstance(_AuthTypeLazyChoices(), list)


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an auth plugin.

    The two built-in plugins are basic and digest.

    Additional plugins can be enabled by installing the relevant Python
    packages. For instance, to enable OAuth 1/2 support:

        $ pip install httpie-oauth

    '''
)


# Generated at 2022-06-11 23:10:25.037554
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:10:35.903172
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism to use. The default value is "basic".

    '''
)

# ``requests.request`` keyword arguments (digest auth).

# Generated at 2022-06-11 23:10:39.881401
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    def check(plugin_mapping, item):
        _AuthTypeLazyChoices.plugin_mapping = plugin_mapping
        return item in _AuthTypeLazyChoices()

    assert check({}, 'basic') is False
    assert check({'basic': object()}, 'basic') is True



# Generated at 2022-06-11 23:10:42.702379
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hmac', 'netrc', 'negotiate', 'ntlm', 'oauth1', 'oauth2', 'token']