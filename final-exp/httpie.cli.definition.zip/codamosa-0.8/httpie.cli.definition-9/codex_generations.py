

# Generated at 2022-06-11 23:01:41.297530
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Available choices are:
    {auth_type_choices}
    '''
)

#######################################################################
# SSL/TLS
#######################################################################

ssl = parser.add_argument_group(title='SSL/TLS')

# Generated at 2022-06-11 23:01:53.719514
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=plugin_manager.get_auth_plugin_mapping()['basic'],
    help='''
    The authentication mechanism to use. By default, basic is used.
    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform authentication challenge. This is useful when
    using the Basic auth method and you don't want the server to
    ask for credentials.
    '''
)

#######################################################################
# Output options


# Generated at 2022-06-11 23:02:02.917569
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'not_existing' not in auth_type_choices

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    The default is "auto", which lets HTTPie guess the best
    mechanism based on the server's responses. Other values:

    "basic"      HTTP Basic Auth
    "digest"     HTTP Digest Auth
    "ntlm"       HTTP NTLM

    '''
)

#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-11 23:02:15.074528
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

AuthTypeLazyChoices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=AuthTypeLazyChoices,
    help='''
    Specify the authentication mechanism used. This can be used to generate the
    authentication credentials from a different source than the console.

    ''',
)

auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='''
    Show help for the specified auth plugin.
    '''
)

#######################################################################
# Python 3 equivalent of Python 2's ``__name__ == '__main__'``.
#######################################################################


# Generated at 2022-06-11 23:02:25.979958
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Bearer' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used, for example Basic or Digest.
    For custom mechanism use "plugin" as TYPE and provide the plugin path
    via --auth-plugin argument.
    The default is Basic auth.
    If TYPE is not provided, it is assumed to be "basic".
    {fmt_plugin_list('auth', plugin_manager.get_auth_plugins())}

    ''',
)

# Generated at 2022-06-11 23:02:37.472155
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockPluginManager(object):
        def get_auth_plugin_mapping(self):
            return {'basic': None, 'digest': None}

    plugin_manager = MockPluginManager()
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type

    class MockPluginManager(object):
        def get_auth_plugin_mapping(self):
            return {}

    plugin_manager = MockPluginManager()
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' not in auth_type
    assert 'digest' not in auth_type


# Generated at 2022-06-11 23:02:49.063081
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = list(_AuthTypeLazyChoices())
    assert items == ['basic', 'digest', 'kodi', 'mock-kodi', 'mock-openrtk']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an auth mechanism. If no auth type is specified, an appropriate one
    is selected automatically (when there's more than one, it's the first one
    of: basic, digest, kodi).

    '''
)

# Generated at 2022-06-11 23:03:01.488341
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert len(list(auth_type_choices)) > 0

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default is "{'auto'}" which causes HTTPie to auto-detect the mechanism
    based on the provided credentials as well as the server response (in case
    of digest auth).

    '''
)

# Generated at 2022-06-11 23:03:09.706165
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    if not _AuthTypeLazyChoices():
        raise Exception('_AuthTypeLazyChoices is empty!')
    test__AuthTypeLazyChoices.__doc__


auth.add_argument(
    '--auth-type',
    help=f'''

    Choose an authentication plugin. The default is
    '{AUTH_PLUGIN_MAP.get_default()}', which handles Basic and Digest auth.

    The following authentication plugins are currently available:

    {plugin_manager.get_auth_plugin_help()}
    ''',
    default=AUTH_PLUGIN_MAP.get_default(),
    choices=_AuthTypeLazyChoices()
)

# Generated at 2022-06-11 23:03:12.439791
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'unknown' not in choices


# Generated at 2022-06-11 23:03:27.277901
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print(list(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES_DEFAULT,
    choices=_AuthTypeLazyChoices(),
    help='''
    Plugins that can be used for authentication. Defaults to:

        {auth_types_default}

    Available plugins: {auth_types_available}

    '''
    .format(
        auth_types_default=AUTH_TYPES_DEFAULT,
        auth_types_available=plugin_manager.get_auth_plugin_mapping().keys(),
    )
)

# netrc keyword arguments.

# Generated at 2022-06-11 23:03:38.544714
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import builtin
    builtin_names = dir(builtin)
    import httpie.plugins.demo
    demo_names = dir(httpie.plugins.demo)
    assert (
        set(builtin_names + demo_names)
        ==
        set(_AuthTypeLazyChoices())
    )


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin.

    ''',
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:03:50.050303
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) == set(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    choices=_AuthTypeLazyChoices(),
    help='''
    Defaults to "basic".

    ''',
)

#######################################################################
# SSL/TLS client
#######################################################################

# ``requests.request`` keyword arguments.
ssl = parser.add_argument_group(title='SSL/TLS')
ssl.add_argument(
    '--cert',
    '--ssl-cert',
    help='''
    Path to an SSL client certificate, a single file containing the private
    key and the certificate in PEM format.

    '''
)
ssl.add_argument

# Generated at 2022-06-11 23:03:56.117080
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'bearer' in choices


# A flag to control whether the auth plugin argument is optional or not.
# Set to True for auth plugins that don't require any arguments.
# Set to False for auth plugins that require arguments.
AUTH_OPTIONAL = True



# Generated at 2022-06-11 23:03:57.619808
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-11 23:04:09.365182
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    '''
)


# Generated at 2022-06-11 23:04:10.859234
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AuthCredentialsParser.BASIC in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:04:22.312364
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    help=SuppressedHelpAction(
        'The backend used to make authenticated requests',
        choices=_AuthTypeLazyChoices(),
        metavar='guess|basic|digest|hawk|ntlm',
    )
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_false',
    dest='auth_challenge',
    help='''
    Do not issue an initial 401 challenge to preemptively send authentication
    credentials.

    '''
)


# Generated at 2022-06-11 23:04:24.707898
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert sorted(a) == sorted(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:04:25.928251
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:31.255024
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:32.601399
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:04:43.934430
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    assert 'digest' in auth_type
    assert 'bearer' in auth_type
    for auth_type in ['digest', 'bearer']:
        assert auth_type in auth_type
    assert 'token' not in auth_type
    assert 'basic' not in auth_type
    assert 'tocken' not in auth_type
    assert 'basix' not in auth_type




# Generated at 2022-06-11 23:04:55.850591
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    If not provided, HTTPie attempts to guess it from the --auth option.
    Available schemes: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))),
)

# Generated at 2022-06-11 23:04:58.646644
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:05:03.307227
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'special'

    class MyAuthPlugin2(AuthPlugin):
        auth_type = 'special-2'

    with plugin_manager.manage([MyAuthPlugin, MyAuthPlugin2]):
        assert 'special' in _AuthTypeLazyChoices()

    assert 'special' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:13.661452
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []
    plugin_manager.load_builtin_plugins()
    plugin_manager.load_external_auth_plugins()
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'jwt', 'hawk']

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'](),
    type=make_auth_type_validator(auth_plugin_mapping=plugin_manager.get_auth_plugin_mapping()),
    help=f'''
    Use the specified HTTP authentication plugin.

    The currently available authentication plugins are:

    {auth_plugin_list_help}

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument

# Generated at 2022-06-11 23:05:24.101928
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:05:34.372402
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'oauth1' not in auth_type_lazy_choices
    assert list(auth_type_lazy_choices) == ['basic', 'digest']


# Generated at 2022-06-11 23:05:42.596309
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''
    >>> 'basic' in _AuthTypeLazyChoices()
    True
    >>> 'digest' in _AuthTypeLazyChoices()
    True
    >>> 'OAuth1' in _AuthTypeLazyChoices()
    True
    >>> 'OAuth2' in _AuthTypeLazyChoices()
    True
    >>> 'noauth' in _AuthTypeLazyChoices()
    True
    >>> 'bogus' in _AuthTypeLazyChoices()
    False
    '''

# Generated at 2022-06-11 23:06:01.366855
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified auth plugin for authentication. By default, HTTPie uses
    Basic authentication unless it detects a form in which case it falls back to
    Form based auth.

    The value can be one of: {', '.join(sorted(_AuthTypeLazyChoices()))}.

    See the official plugins repo for more information:
    {PLUGINS_DOCS_URL}

    '''
)

#######################################################################
# HTTP and HTTPS proxy.
#######################################################################
proxy = parser.add

# Generated at 2022-06-11 23:06:11.853209
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == \
        set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    help='''
    Specify the auth mechanism to use. Available options are:

        {auth_plugins}

    '''.format(auth_plugins=_AuthTypeLazyChoices()),
)

# Generated at 2022-06-11 23:06:23.143037
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. Can be:

        'basic'
        'digest'

    ''',
)

auth_plugin_args = parser.add_argument_group('Authentication plugin arguments')
plugin_manager.load_auth_plugins()
plugin_manager.register_auth_plugin_args(auth_plugin_args)


#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_group(title='HTTPS (SSL/TLS) Options')

# Generated at 2022-06-11 23:06:30.759018
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager_mock = mock.Mock(spec=plugin_manager)
    plugin_manager_mock.get_auth_plugin_mapping.return_value = {
        'type-1': 'path-1',
        'some-type': 'path-2',
        'type-2': 'path-3',
    }
    assert sorted(iter(_AuthTypeLazyChoices())) == ['type-1', 'type-2', 'some-type']


# Generated at 2022-06-11 23:06:32.494916
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:42.853459
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom authentication plugin. Use --debug to find out which one to
    use.

    See https://httpie.org/docs#authentication for details.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timings = parser.add_argument_group(title='Timings')

# Generated at 2022-06-11 23:06:53.315199
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert '__iter__' in dir(_AuthTypeLazyChoices)
    choices = _AuthTypeLazyChoices()
    iterated = [auth_type for auth_type in choices]
    assert 'basic' in iterated
    assert 'digest' in iterated
    assert 'aws4-hmac-sha256' in iterated


# Generated at 2022-06-11 23:06:58.392391
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert [c for c in choices] == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:06:59.207497
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()]


# Generated at 2022-06-11 23:07:08.725723
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin.

    The following authentication methods are available:

    {auth_type_doc}

    If no authenticator is specified and the --auth option is provided, the
    default basic/digest/netrc authenticator is used, based on the availability
    of a password.

    With no --auth and without --auth-type the request is sent without
    authentication headers.

    '''
)


# Generated at 2022-06-11 23:07:18.770528
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'unknown' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:07:30.512929
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # We need to import the plugins which register with the plugin manager.
    from httpie.plugins import (
        builtin,
        auth_plugin,
        downloadable,
    )
    from httpie.plugins.builtin import AuthPlugin
    class AuthPluginMock(AuthPlugin):
        auth_type = None
        description = None
        def get_auth(self, username=None, password=None):
            pass
    class AuthPluginMock1(AuthPluginMock):
        auth_type = 'mock1'
        description = 'Mock1'
    class AuthPluginMock2(AuthPluginMock):
        auth_type = 'mock2'
        description = 'Mock2'
    class AuthPluginMock3(AuthPluginMock):
        auth_type = 'mock3'

# Generated at 2022-06-11 23:07:32.181825
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']


# Generated at 2022-06-11 23:07:32.965919
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass

# Generated at 2022-06-11 23:07:44.115390
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert choices
    assert list(choices)


auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-11 23:07:46.112508
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:07:47.012262
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__(item=None)

# Generated at 2022-06-11 23:07:57.477346
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'plugin:plugin_name' in _AuthTypeLazyChoices()
    assert 'plugin:plugin_name' in _AuthTypeLazyChoices()
    assert 'noauth' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH,
    help=f'''
    The authentication mechanism to be used.
    Can be one of:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()) + ['noauth'])}

    ''',
)



# Generated at 2022-06-11 23:08:05.909142
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='Basic',
    help='''
    To use a non-Basic auth type, the type name has to be provided as a
    prefix to the username.

    For example:

        Digest username

    '''
)
# TODO: --auth-type needs a way to specify the auth scheme URI
# TODO: the auth scheme URI must be filled into the relevant
#       headers during the request


# Generated at 2022-06-11 23:08:13.795203
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert sorted(auth_type_lazy_choices) == [
        'basic', 'digest', 'hawk', 'netrc'
    ]

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use.

    These options are built-in:

    'basic'
        HTTP Basic authentication. API token authentication schemes
        that use basic authentication are also supported.
    'digest'
        HTTP Digest authentication.
    'hawk'
        Hawk authentication.

    In addition to the built-in options, HTTPie's plugin system can
    provide additional authentication types.
    '''
)

auth

# Generated at 2022-06-11 23:08:31.093133
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'DIGEST' not in choices

# Generated at 2022-06-11 23:08:34.104213
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'foo' not in lazy_choices

# Generated at 2022-06-11 23:08:36.845670
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'a' in _AuthTypeLazyChoices()
    assert 'b' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:40.458572
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices

# Generated at 2022-06-11 23:08:41.603298
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in _AuthTypeLazyChoices()] == ['digest', 'hawk', 'oauth1', 'basic']


# Generated at 2022-06-11 23:08:49.339631
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth plugin.

    Available plugins:

        {plugin_manager.get_auth_plugin_list()}

    '''
)
auth.add_argument(
    '--auth-type-redirect',
    action='store_true',
    help='''
    Apply the auth plugin to all redirected URLs.

    '''
)

# Generated at 2022-06-11 23:09:01.469651
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    empty_manager = plugin_manager.LoadedPluginsManager()
    choices = _AuthTypeLazyChoices()
    assert 'foo' not in choices
    assert 'digest' in choices
    # test _AuthTypeLazyChoices.__iter__(), too
    assert 'digest' in list(choices)

    empty_choices = _AuthTypeLazyChoices()
    for choice in choices:
        assert choice in choices
        assert choice not in empty_choices



# Generated at 2022-06-11 23:09:02.913721
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:09:13.512183
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'oauth1']


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f"""
    The authentication mechanism to be used, e.g. "digest".

    Available types (case-insensitive): {', '.join(sorted(_AuthTypeLazyChoices()))}.

    """,
)


# Generated at 2022-06-11 23:09:24.461261
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Currently supported mechanisms are:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    ),
)

#######################################################################
# Cookies.
#######################################################################


# Generated at 2022-06-11 23:10:07.343347
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert (_AuthTypeLazyChoices() ==
            sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication scheme(s) to use, e.g. "basic" or "digest". Can also be
    specified as a comma-separated list, in which case HTTPie will try
    them in order, e.g. "digest,basic".

    {auth_plugin_help}

    '''.format(
        auth_plugin_help='\n' +
        plugin_manager.get_auth_plugin_help_doc()
    )
)

# Generated at 2022-06-11 23:10:13.875012
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:23.252499
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    # pylint: disable=unused-argument
    """Testing __iter__ method of class _AuthTypeLazyChoices"""
    assert len([item for item in _AuthTypeLazyChoices()]) > 1
    assert [item for item in _AuthTypeLazyChoices()] == [
        'digest', 'hawk', 'jwt', 'oauth1', 'spnego'
    ]

auth.add_argument(
    '--auth-type',
    help='''
    Force the specified authentication mechanism.

    ''',
    choices=_AuthTypeLazyChoices(),
)

# Generated at 2022-06-11 23:10:30.811927
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    type=AuthCredentials,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to use. This can be any of: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_false',
    dest='auth_challenge',
    default=True,
    help='''
    Do not perform an authentication challenge request prior to the main
    request.

    '''
)

# Generated at 2022-06-11 23:10:41.366868
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'aws4' in auth_type_lazy_choices
    assert 'aws4' in auth_type_lazy_choices
    assert 'aws4_test' in auth_type_lazy_choices
    assert 'aws_test' not in auth_type_lazy_choices
    assert 'aws_test' not in auth_type_lazy_choices
    assert sorted(auth_type_lazy_choices) == ['aws4', 'aws4_test', 'basic', 'digest']


# Generated at 2022-06-11 23:10:42.888029
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in iter(_AuthTypeLazyChoices())]

# Generated at 2022-06-11 23:10:53.964106
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(ABSTRACT_BASIC_AUTH) == \
        sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default=ABSTRACT_BASIC_AUTH,
    help=f'''
    Specify the authentication mechanism. By default, the "basic" mechanism
    is used, which sends the credentials in the HTTP "Authorization" header.
    Other enabled authentication plugins can be specified by their type name.
    Use {REF_DOC_URL} to see the list of available auth plugins.

    '''
)


# Generated at 2022-06-11 23:11:03.896435
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    How to handle authentication provided with --auth. Can be:

        auto
            infer from the request URL

        basic
            HTTP Basic Authentication. Send the credentials with each request.

        digest
            HTTP Digest Authentication (default). Send the credentials with
            each request.

        oauth1
            OAuth 1 Authorization. Generate a signature (based on the request
            url and method, the credentials, and the OAuth1 client
            credentials).

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys()) or ''}

    '''
)

# Generated at 2022-06-11 23:11:16.137606
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for _ in _AuthTypeLazyChoices():
        break


# Generated at 2022-06-11 23:11:24.689060
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hook' in choices
    assert 'ntlm' in choices
    assert 'aws4-hmac' in choices
    assert 'custom' not in choices
    assert (
        'Custom'
        not in choices
    )
    assert set(choices) == set(('aws4-hmac', 'basic', 'digest', 'hook', 'ntlm'))

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=argparse.SUPPRESS
)


#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

timeouts