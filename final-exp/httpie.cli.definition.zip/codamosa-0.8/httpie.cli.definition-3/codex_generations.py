

# Generated at 2022-06-11 23:01:40.795025
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism.

    By default, HTTPie detects the auth type automatically based on the
    supplied credentials.

    This option is useful when authentication requires multiple steps and/or
    multiple requests.

    For details, please refer to the authentication plugin docs.

    '''
)


# Generated at 2022-06-11 23:01:53.425250
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    l = _AuthTypeLazyChoices()
    assert 'basic' in l
    assert 'digest' in l
    assert 'certificate' in l
    assert 'invalid_auth_type' not in l

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism.

    Can be the name of any authentication plugin (see `http --debug`).

    Defaults to `basic`, which sends the credentials in the HTTP Basic
    Authentication format.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-11 23:02:04.182286
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.core import plugin_manager
    old_get_auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping
    plugin_manager.get_auth_plugin_mapping = lambda: {
        'basic': 'Basic Auth Plugin'
    }
    assert 'basic' in _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping = old_get_auth_plugin_mapping


# Generated at 2022-06-11 23:02:17.477098
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin name.
    See http://httpie.org/plugins#authentication to learn how to write one.

    '''
)
auth.add_argument(
    '--auth-plugin', '-T',
    default=None,
    help='''
    Specify a custom authentication plugin path.

    '''
)

# Generated at 2022-06-11 23:02:28.190033
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # 'basic' is always present because of the built-in plugin
    assert 'basic' in _AuthTypeLazyChoices()
    # 'digest' is there iff the plugin is installed
    if 'digest' in plugin_manager.get_auth_plugin_mapping():
        assert 'digest' in _AuthTypeLazyChoices()
    else:
        assert 'digest' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:02:30.897570
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'yamraj' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:02:40.472858
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'invalid' not in lazy_choices

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use. Run `$ http --auth-type-help' to list
    all available auth plugins.

    '''
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='''
    List all the available auth plugins.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:02:53.237831
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(choices)

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default=None,
    help='''
    Use the specified authentication plugin.
    This flag is mutually exclusive with --auth.
    The following plugins are available:

    {choices}

    '''.format(
        choices='\n'.join('\n'.join((8 * ' ') + line.strip() for line in wrap(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            60
        )))
    ),
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-11 23:02:57.267152
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping()['Basic'].load()
    assert 'Basic' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:07.357742
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert not any(choice in choices for choice in ('foo', 'bar', 'abc'))
    assert 'basic' in choices
    assert 'digest' in choices


_AUTH_TYPES = _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-11 23:03:24.409833
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) <= set(_AuthTypeLazyChoices())



# Generated at 2022-06-11 23:03:36.298111
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))


# Generated at 2022-06-11 23:03:38.670116
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'unknown' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:03:41.353011
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'custom-plugin' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:51.197321
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import AuthPluginManager
    from httpie.plugins.auth.basic import BasicAuthPlugin
    from httpie.plugins.auth.digest import DigestAuthPlugin
    def assert_contains(known_plugins, not_known_plugins):
        known_plugins = [
            AuthPluginManager.PLUGIN_NAMESPACE + '.' + known_plugin
            for known_plugin in known_plugins
        ]
        for auth_plugin in known_plugins:
            assert auth_plugin in _AuthTypeLazyChoices()
        for auth_plugin in not_known_plugins:
            assert auth_plugin not in _AuthTypeLazyChoices()
    assert_contains(
        ['basic', 'digest'],
        ['fake_basic', 'fake_digest']
    )

# Generated at 2022-06-11 23:04:05.072814
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin',
    default=key2val_to_val2key_mapping(AUTH_PLUGIN_MAP),
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication style plugin. The default is basic.
    Use the {0} argument to show the installed authentication plugins.

    '''.format(plugin_manager.plugin_args.arg_show_auth) if plugin_manager.get_auth_plugin_mapping() else SUPPRESS
)

#######################################################################
# Expose and install plugins
#######################################################################

plugins = parser.add_

# Generated at 2022-06-11 23:04:12.856644
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert len(choices) > 0
    assert 'digest' in choices
    assert 'NotARealAuthenticationType' not in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert isinstance(iter(choices), types.GeneratorType)
    assert sorted(list(choices)) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    return True


# Generated at 2022-06-11 23:04:15.918015
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    expected = sorted(plugin_manager.get_auth_plugin_mapping().keys())

    assert list(_AuthTypeLazyChoices()) == expected

# Generated at 2022-06-11 23:04:25.890582
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the authentication type for HTTPie to use.
    This allows for using non-standard auth schemes that don't
    follow the Basic/Digest schemes.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-11 23:04:34.173149
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth_type = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose the authentication mechanism. If not set explicitly, HTTPie will
    try to guess it based on the provided credentials.
    Currently supported authentication types:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)


#######################################################################
# Options for the HTTPie interactive shell.
#######################################################################

if HTTPIE_SHELL:
    from httpie.shell import DEFAULT_SHELL_COMPLETERS
    from httpie import shell_type

    # Get the list of available

# Generated at 2022-06-11 23:04:48.127049
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Test that iterating on class _AuthTypeLazyChoices yields a sorted list of choice items"""
    choices = _AuthTypeLazyChoices()
    assert len(list(choices)) == len(plugin_manager.get_auth_plugin_mapping())
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:04:50.956212
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    for item in plugin_manager.get_auth_plugin_mapping().keys():
        assert item in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:01.530547
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication mechanism.

    The available types are listed by `http --help-auth`.

    For example, --auth-type=digest

    '''
)
auth.add_argument(
    '--auth-plugin', '--auth-type',
    default=None,
    metavar='PLUGIN',
    help=argparse.SUPPRESS
)  # Included for backwards compatibility.

# Generated at 2022-06-11 23:05:13.215382
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test if it can iterate over keys
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(
        _AuthTypeLazyChoices())
    # Test if it can find a key
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth plugin to use. See ``--help=plugins`` for a list of
    available plugins.

    ''',
)

# Generated at 2022-06-11 23:05:23.802432
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['Basic', 'Digest']) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth type (digest or basic; defaults to basic).
    If not specified, the auth type is guessed from --auth.

    You can use this option to explicitly hand HTTPie the credentials
    (e.g., when you know the auth type is not basics but the guessing
    fails).

    ''',
)
auth.add_argument(
    '--auth-type=digest', '--auth-type=basic',
    dest='auth_type',
    # The hidden HTTPie built-in auth types.
    help=SUPPRESS,
)

#######################################################################


# Generated at 2022-06-11 23:05:27.126920
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:34.642725
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '--auth-type',
    default=plugin_manager.get_default_auth_plugin_name(),
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    ''',
)
auth_type.add_argument(
    '--no-auth',
    dest='auth',
    action='store_const',
    const=NO_AUTH,
    help='''
    Explicitly disable authentication.

    '''
)

# Generated at 2022-06-11 23:05:40.069906
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk'
    ]


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is 'basic'
    (i.e., HTTP Basic, which is performed automatically), other
    supported types are:

    ''' + '\n'.join(
        '    {0}{1}{0}  {2}'.format(
            8 * ' ',
            auth_type,
            plugin.description
        )
        for auth_type, plugin in plugin_manager.get_auth_plugin_mapping().items()
    )
)
auth.add

# Generated at 2022-06-11 23:05:40.917234
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('foo')

# Generated at 2022-06-11 23:05:42.660568
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices



# Generated at 2022-06-11 23:05:59.500368
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert(x in _AuthTypeLazyChoices() for x in ['basic', 'digest', 'foo'])
    assert(x not in _AuthTypeLazyChoices() for x in ['bar'])

# Generated at 2022-06-11 23:06:11.095162
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    plugin_manager.get_auth_plugin_mapping()['test'] = None
    assert 'test' in auth_type_lazy_choices
    assert 'test2' not in auth_type_lazy_choices
    del plugin_manager.get_auth_plugin_mapping()['test']
    assert 'test' not in auth_type_lazy_choices

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument('--auth-type', default=None, choices=_AuthTypeLazyChoices())
auth_type.add_argument('--auth-no-challenge', action='store_true', default=False)

#######################################################################
# Timeout
####################################################################

# Generated at 2022-06-11 23:06:22.705574
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """_AuthTypeLazyChoices.__contains__
    """
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication method to be used.

    Available methods:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Default is "auto", which means that HTTPie will try to detect the
    auth method based on the provided credentials and the HTTP response.

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:06:26.439897
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()
    assert 'basic' in AUTH_TYPE_CHOICES
    assert 'digest' in AUTH_TYPE_CHOICES
    assert 'foo' not in AUTH_TYPE_CHOICES


# Generated at 2022-06-11 23:06:32.735800
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

# This code:
#  - Is useful
#  - Is simple
#  - Works on python 3.5
#  - Is testable
#  - Does not use ``with`` statement
#  - Does not depend on any 3rd party library
#  - Does not depend on ``six.moves``

# Generated at 2022-06-11 23:06:43.041116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified authentication type.

    This can be used to send different authentication credentials
    over the same HTTP connection (a single request to the same host
    can contain multiple Authorization headers).

    HTTPie also accepts basic and digest as a shortcut for
    --auth-type=basic and --auth-type=digest.

    '''
)

# Generated at 2022-06-11 23:06:53.503786
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = list(sorted(_AuthTypeLazyChoices()))
    assert choices == [
        'digest', 'hawk', 'basic', 'aws-sigv4'
    ]

# The auth type choices, the content is lazy loaded according the the plugins.
_AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:06.688071
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list_auth_type = _AuthTypeLazyChoices()
    assert 'basic' in list_auth_type
    assert 'digest' in list_auth_type
    assert 'hawk' in list_auth_type
    assert 'aws4' in list_auth_type
    assert 'awscurl4' in list_auth_type
    assert 'aws4-hmac-sha256' in list_auth_type
    assert 'krb5' in list_auth_type
    assert 'ntlm' in list_auth_type
    assert 'oauth1' in list_auth_type
    assert 'oauth2' in list_auth_type


# plugin_manager.get_plugin_choices()

# Generated at 2022-06-11 23:07:09.880016
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'imagine_auth_plugin_that_doesnt_exists' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:20.153095
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'oauth1' in choices
    assert 'oauth2' in choices
    assert 'basic' in choices
    assert 'digest' in choices

    assert 'foo' not in choices
    assert 'http' not in choices  # OK HTTP is not a supported auth type.

    if 'foo' in choices:
        raise RuntimeError('plugin not installed')
    assert 'foo' not in choices

    # Now install the foo plugin.
    import httpie_foo_auth
    plugin_manager.discover()
    assert 'foo' in choices



# Generated at 2022-06-11 23:08:00.553635
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'http' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used (see list of `Auth Plugins`_).
    If "auto", then the authentication mechanism is guessed based on the URL
    hostname.

    .. _`Auth Plugins`: http://httpie.org/plugins#auth

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The hostname to use when guessing the --auth-type.

    '''
)
auth.add_

# Generated at 2022-06-11 23:08:11.426921
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES_DEFAULT,
    choices=_AuthTypeLazyChoices(),
    help=HELP_AUTH_TYPE
)


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-digest',
    default=None,
    metavar='USER[:PASS]',
    help='Same as --auth, but uses HTTP Digest Authentication.',
)

#######################################################################
# Transport
#######################################################################

transport = parser.add_argument_group(title='Transport')

# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:08:22.157406
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'foo' not in choices
    p = plugin_manager.authentication_plugin_load()
    p.method = 'foo'
    p.auth_type_check_compatibility()
    assert 'foo' in choices

auth.add_argument(
    '--auth-type', '-t',
    default=AUTH_PLUGIN_MAP.get('Basic'),
    help='''
    Specify a custom authentication type. When set to 'auto', HTTPie attempts
    to infer the auth type from the provided credentials.

    Available choices: {0}

    '''.format(list(_AuthTypeLazyChoices()))
)

#######################################################################
# Other
#######################################################################

other = parser.add_argument_group(title='Other')

other.add

# Generated at 2022-06-11 23:08:29.926296
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:08:41.165170
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism.

    Currently supported:''' + dedent('''
    ''') + '\n    '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())) + '''

    '''
)

# Generated at 2022-06-11 23:08:43.299396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) == set(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:08:45.249300
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # It is not possible to mock other objects in this class
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:57.536481
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    all_choices = set(_AuthTypeLazyChoices())
    assert all_choices == plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-11 23:09:05.191942
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic','digest','hawk','ntlm','oauth1','query']
auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_lazy_choices,
    default=None,
    metavar='TYPE',
    help=f'''
    Specifies the authentication mechanism to be used.

    Available types (depend on installed plugins):

        {', '.join(['"%s"' % auth_type for auth_type in auth_type_lazy_choices])}

    Note that when an authentication type is specified, it is mandatory.

    '''
).completer = ChoicesCompleter(auth_type_lazy_choices)
auth.add_argument

# Generated at 2022-06-11 23:09:16.277779
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
plugin_manager.register(
    plugin_type='auth',
    name='digest',
    title='Digest',
    description='Digest auth.',
    version=digest.__version__,
    author=digest.__author__,
    author_email=digest.__email__,
    license='BSD',
    long_description=dedent("""
    Digest auth.

    """),
    load_arguments=lambda parser: digest.load_arguments(parser),
    load_auth=lambda args: digest.load_auth(args),
)


# Generated at 2022-06-11 23:10:19.605441
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


# Generated at 2022-06-11 23:10:29.461033
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication plugin to use. If not specified and the URL contains
    embedded credentials, they are used. Otherwise, the default plugin is
    guessed.
    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Don't perform authentication challenge (HTTP 401 handling).
    By default a HTTP 401 Not Authorized response results in another
    request with the appropriate Authorization header.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_

# Generated at 2022-06-11 23:10:40.358668
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Select the auth type plugin (e.g. oauth2).

    ''',
)
auth_type.completer = auth.completer = AuthCredentialsCompleter()

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

proxy.add_argument(
    '--proxy',
    metavar='URL',
    help='''
    Use a proxy.

    '''
)

#######################################################################
# Verify
#######################################################################


# Generated at 2022-06-11 23:10:50.541299
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # test __contains__
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'awesome_auth' in _AuthTypeLazyChoices()
    # test __iter__
    assert 'basic' in list(_AuthTypeLazyChoices())
    assert 'bearer' in list(_AuthTypeLazyChoices())
    assert 'awesome_auth' in list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:11:02.286036
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    type('')(', '.join(_AuthTypeLazyChoices()))


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Default: "auto".

    If "auto" (default), HTTPie tries to autodetect the scheme from scheme
    and hostname of the URL.

    Explicitly specifying a scheme will prevent HTTPie from autodetection
    and use the specified scheme instead.

    Currently supported schemes are:

      {supported_auth_schemes}

    '''.format(
        supported_auth_schemes='\n      '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-11 23:11:04.411947
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:11:16.578720
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth_plugins = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type', '-t',
    type=str,
    choices=auth_plugins,
    default=DEFAULT_AUTH_PLUGIN_NAME,
    help='''
    The name of the plugin used for authentication.

    ''',
)

# TODO: Move this to a plugin.
auth.add_argument(
    '--auth-plugin',
    type=str,
    help=f'(Deprecated in 2.0, use --auth-type instead)',
)

# Generated at 2022-06-11 23:11:24.990860
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    default=None,
    metavar='TYPE',
    choices=auth_type_choices,
    help=f'''
    The authentication scheme to be used.

    Currently supported values: {', '.join(auth_type_choices)}.
    '''
)

# Generated at 2022-06-11 23:11:30.044647
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager._get_auth_plugins = lambda: ['digest', 'jwt']

    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'unknown' not in _AuthTypeLazyChoices()