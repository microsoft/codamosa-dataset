

# Generated at 2022-06-11 23:01:42.270928
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
           sorted(_AuthTypeLazyChoices())


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication backend to use. Run `http --auth-type=help` to print
    a list of all backends.

    ''',
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:01:45.577880
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:01:50.086095
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert  'digest' in choices and 'basic' in choices and 'oauth1' in choices
    assert set(choices) == {'digest', 'basic', 'oauth1'}

# Generated at 2022-06-11 23:01:59.057644
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'password-inline' in _AuthTypeLazyChoices()
    assert 'password-stdin' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256,profile' in _AuthTypeLazyChoices()


auth_type_nargs = '?'
auth_type_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:10.852513
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert list(auth_types) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN,
    help='Specify the authentication type. Available choices: {choices}',
)
auth.add_argument(
    '--auth-type=basic',
    action=DeprecatedAction,
    help=DeprecatedAction.HELP,
    version='2.0',
)

# Generated at 2022-06-11 23:02:13.945963
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices.__iter__(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:02:24.773817
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == tuple(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))

    plugin_manager.deregister_plugin(plugin_manager.get_auth_plugin_mapping()['digest'])

    assert tuple(_AuthTypeLazyChoices()) == tuple(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))


# Generated at 2022-06-11 23:02:33.047805
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.builtin import AuthPlugin
    from tests.helpers import mock
    fake_plugin = mock.MagicMock()
    fake_plugin.name = 'fake-plugin'
    plugin_manager.auth_plugins = [fake_plugin]
    plugin_manager.get_auth_plugin_mapping = lambda: {'fake-plugin': fake_plugin}
    assert 'fake-plugin' in _AuthTypeLazyChoices()
    assert 'fake-plugin' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:41.236933
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported: basic, digest.
    Note that digest authentication sends the passwords unencrypted over
    the network, so you should use HTTPS with it.

    ''',
)
auth.add_argument(
    '--auth-host',
    default='localhost',
    help='''
    The hostname to provide to an auth plugin (e.g. when using Multi-Factor
    Authentication). Defaults to "localhost".

    ''',
)

#######################################################################
#
# Plugin management
# ~~~~~~~~~~~~~~~~~
#
#######################################################################

parser.add

# Generated at 2022-06-11 23:02:43.568344
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert not ('wrong' in _AuthTypeLazyChoices())

# Generated at 2022-06-11 23:02:59.125844
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'auth-type-1' in AuthTypeLazyChoices
    assert 'auth-type-2' in AuthTypeLazyChoices
    if 'auth-type-3' in AuthTypeLazyChoices:
        raise Exception('auth-type-3 is not defined')
    if 'auth-type-4' in AuthTypeLazyChoices:
        raise Exception('auth-type-4 is not defined')
    all_types = list(iter(AuthTypeLazyChoices))
    all_types.sort()
    assert ['auth-type-1', 'auth-type-2'] == all_types
AuthTypeLazyChoices = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:03:08.452374
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices  # from built-ins
    assert 'digest' in choices  # from built-ins
    assert 'fake' not in choices



# Generated at 2022-06-11 23:03:11.593159
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()  # pylint: disable=redefined-outer-name
    assert set(choices) == {'basic', 'digest', 'hawk'}

# Generated at 2022-06-11 23:03:24.951524
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Verify that choices always include built-in auth types
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help=f'''
    The authentication mechanism to be used.

    The choices are: {', '.join(auth_type_choices)}

    For example:

        $ http --auth-type=basic -a username:password https://httpbin.org/basic-auth/username/password

    ''',
)


# Generated at 2022-06-11 23:03:36.892778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

_auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_auth_type_choices,
    help='''
    The authentication mechanism to be used. Use {0} to get the full list.

    '''.format(
        ', '.join(sorted(_auth_type_choices))
    )
)

#######################################################################
# HTTP methods
#######################################################################

method = parser.add_argument_group(
    title='HTTP methods'
).add_mutually_exclusive_group()


# Generated at 2022-06-11 23:03:49.469719
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    available_auth_types = _AuthTypeLazyChoices()
    assert list(available_auth_types) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The mechanism used to perform authentication.

    By default, HTTPie will try to detect what mechanism should be
    used, or use the default ones like Basic or Digest.

    '''
)

# Generated at 2022-06-11 23:04:02.977887
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    sorted(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',  # hidden
    # Must be lazy loaded to make plugin testing possible.
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the credential.

    '''
)
auth.add_argument(
    '--auth-plugin',  # hidden
    default=None,
    help='''
    When --auth-type is set, use the plugin with this name.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Do not load .netrc.

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-11 23:04:13.830365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(plugin_manager.get_auth_plugin_mapping().keys())) == \
        list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='SCHEME',
    help='''
    Use a custom authentication scheme.

    The argument has to be a plugin name that matches
    --auth-plugin-name-prefix, e.g., "basic".

    It is an error if no such plugin has been loaded.

    The plugin must accept the following arguments:

        auth=(username, password)

    and return an HTTP Authorization header value.

    '''
)


# Generated at 2022-06-11 23:04:24.930840
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping())

# Choices are not evaluated until the first access.
# https://bugs.python.org/issue26330#msg274587
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=sorted(_AuthTypeLazyChoices()),
    help='''
    The authentication mechanism to be used.

    If TYPE is "auto" (default), HTTPie tries to detect the authentication type
    from the URL when --auth is specified, and from the server response in
    other cases.

    ''',
)

# Generated at 2022-06-11 23:04:26.776774
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:44.992132
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')
timeouts.add_argument(
    '--timeout',
    type=float,
    default=DEFAULT_TIMEOUT,
    help='''
    Timeout in seconds for the connection attempt (default: {default}).

    '''
)
timeouts.add_argument(
    '--timeout-read',
    type=float,
    default=DEFAULT_TIMEOUT_READ,
    help='''
    Timeout in seconds for waiting for a response (default: {default}).

    '''
)

#######################################################################
# Downloads
####################################################################

# Generated at 2022-06-11 23:04:56.576812
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert PLUGIN_LOADING_FAILED not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use an authentication plugin.

    The following auth plugins are currently available:

        {REGISTERED_AUTH_PLUGINS}

    Use the --debug switch to view the exception traceback should loading
    a plugin fail.

    '''.format(
        REGISTERED_AUTH_PLUGINS=', '.join(
            plugin_manager.get_auth_plugin_mapping().keys()
        )
    )
)


# Generated at 2022-06-11 23:05:00.136271
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:05:04.021547
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    c = _AuthTypeLazyChoices()
    assert 'digest' in c
    assert 'foo' not in c

# Generated at 2022-06-11 23:05:13.918312
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    alc = _AuthTypeLazyChoices()
    assert 'digest' in alc
    assert 'digest_no_challenge' in alc
    assert 'bearer' not in alc


if plugin_manager.get_auth_plugin_mapping():
    auth.add_argument(
        '--auth-type', '-t',
        default='auto',
        metavar='{%s}' % ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys()),
        ),
        choices=_AuthTypeLazyChoices(),
        help='''
        Chooses the auth mechanism to use. By default (auto), HTTPie
        will try to guess it based on the provided credentials.
        '''
    )

# Generated at 2022-06-11 23:05:15.345272
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:05:25.161223
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(set(['basic', 'digest']) <= _AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    By default it is set to "basic", but you can specify any of the
    following: {auth_plugin_types}
    '''.format(auth_plugin_types=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

#######################################################################
# Persistence options
#######################################################################

persistence = parser.add_argument_group(title='Persistence')

# Generated at 2022-06-11 23:05:35.050988
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    authentications = _AuthTypeLazyChoices()
    assert 'basic' in authentications
    assert 'digest' in authentications
    assert 'awsv4' in authentications
    assert 'hawk' in authentications
    assert 'kerberos' in authentications
    assert 'ntlm' in authentications
    assert 'jwt' in authentications



# Generated at 2022-06-11 23:05:45.216085
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert hasattr(auth_type_choices, '__contains__')
    assert hasattr(auth_type_choices, '__iter__')

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used, if not otherwise
    inferred from the provided credentials.

    Note: The plugin may also require additional arguments.
    You can get a list of options by using --help-auth with the
    name of the plugin.
    '''
)


# Generated at 2022-06-11 23:05:47.063560
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:10.200293
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie import docoptstr

    return docoptstr.test_type(
        _AuthTypeLazyChoices(),
        [
            'Basic',
            'Digest',
            'AWS',
            'hawk',
            'Kerberos',
            'ntlm',
        ],
        error='Auth type must be one of: Basic, Digest, AWS, hawk, Kerberos, ntlm',  # noqa: E501
        error_message='Auth type must be one of: Basic, Digest, AWS, hawk, Kerberos, ntlm',  # noqa: E501
    )

# Generated at 2022-06-11 23:06:21.757694
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    The name of an authentication plugin to use. A list of available plugins
    can be printed by executing:

    $ http --debug --auth-type

    '''
)
auth_type.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help=f'''
    Do not send an initial challenge HTTP request.

    '''
)

################################

# Generated at 2022-06-11 23:06:35.280361
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices
    assert list(choices) == ['basic', 'digest']

auth_type_help = f'''
    The authentication type to be used. Supported types are:

    {helpers.wrapped_text(
        text=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
        after='')
    }

    The default is 'basic'.
    '''

# Generated at 2022-06-11 23:06:44.331730
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices



# Generated at 2022-06-11 23:06:54.466852
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin that should be used.
    Takes precedence over --auth.

    ''',
)

#######################################################################
# SSL
#######################################################################

# ``requests.request`` keyword arguments.
ssl = parser.add_argument_group(title='SSL Verification')
ssl.add_argument(
    '--verify', '--ssl',
    action='store_true',
    dest='verify',
    help='''
    (default) Verify SSL certificates.

    '''
)
ssl.add_argument

# Generated at 2022-06-11 23:06:59.828125
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    
    

# Generated at 2022-06-11 23:07:09.002513
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

# Choices without the enabled plugins
AUTH_TYPES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    choices=AUTH_TYPES,
    default=None,
    help=f'''
    The auth mechanism to use. Currently supported:

        {plugin_manager.get_auth_plugin_mapping().keys()}

    ''',
)


# Generated at 2022-06-11 23:07:12.614361
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        list(sorted(_AuthTypeLazyChoices()))



# Generated at 2022-06-11 23:07:21.179840
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = list(_AuthTypeLazyChoices())
    items.sort()
    assert list(items) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin to use.

    ''',
)
auth.add_argument(
    '--auth-type-param',
    dest='auth_plugin_map',
    action=MergeDictWithItemsAction,
    type=item_spec_to_key_value_pair,
    metavar='ITEM_SPEC',
    help='''
    Additional custom parameters for a custom auth plugin.

    ''',
)



# Generated at 2022-06-11 23:07:23.018399
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == AVAILABLE_AUTH_PLUGINS


# Generated at 2022-06-11 23:08:03.030401
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # The plugin search path is not required in unit tests
    auth_type_lazy_choices_instance = _AuthTypeLazyChoices()
    for _ in auth_type_lazy_choices_instance:
        assert _ in auth_type_lazy_choices_instance


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. By default, the authentication
    mechanism is inferred from the URL. You only need to use this option
    when the automatic selection fails.

    '''
)

auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    Don't try to infer the auth type from the URL.

    '''
)

################################

# Generated at 2022-06-11 23:08:13.387330
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    The built-in mechanism is "basic" (alias "basic-auth").

    Use "auto" to try all the available mechanisms for a URL.

    The following auth plugins are available:

        {plugins_list}

    '''.format(
        plugins_list='\n'.join(
            (8 * ' ') + line.strip()
            for line in
            wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

# Generated at 2022-06-11 23:08:24.403794
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism: 'basic', 'digest', 'jwt', 'hawk', etc.
    (default: ${AUTH_PLUGIN_MAP}).

    Use the `--debug` flag to see details of the authentication exchange.

    ''',
)
auth.add_argument(
    '--auth-send',
    metavar='CREDENTIALS',
    help='''
    A login:password pair to be sent with every request. The :password part is
    optional and, if unspecified, HTTPie will prompt for it.

    '''
)
auth

# Generated at 2022-06-11 23:08:34.047533
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    assert list(lazy) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'digest' in lazy


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    '''
)

#######################################################################
# Custom HTTP methods
#######################################################################

custom_method = parser.add_argument_group(
    title='Custom HTTP Methods',
    description='''
    The following arguments define custom HTTP methods.
    The method name is the argument's dest attribute,
    and the method data (or the file path containing it)
    is stored in the argument's default value.
    '''
)

custom_method_op

# Generated at 2022-06-11 23:08:44.635679
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication method.

    Basic is the only method that is always built-in. The other ones
    are only available if the corresponding plugin is installed.

    Install the `httpie-plugins` package to get more auth types.

    ''',
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    help=SUPPRESS
)

# Generated at 2022-06-11 23:08:56.077571
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Don't use this method -- it depends on current plugin manager state,
    # which is not a constant
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Default is "auto", which
    chooses the best mechanism based on the server response.
    You can also specify a custom auth plugin.

    '''
)

# Generated at 2022-06-11 23:08:59.682751
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'digest' in instance
    assert 'Basic' in instance
    assert 'non_existant' not in instance


# Generated at 2022-06-11 23:09:06.162570
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    AVAILABLE_AUTH_TYPES = ['basic', 'digest']
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used.

    An auth type can be one of the built-in ones, such as "basic" or "digest"
    (the default type), or a plugin installed via the `--plugins` option.

    '''
)

#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP method')

# Generated at 2022-06-11 23:09:16.742639
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('digest' in _AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    By default, if --auth is used, HTTPie looks for a plugin that supports
    the same authentication mechanism as curl.
    Available mechanisms include: basic, digest, hawkey, oauth1 and aws4-hmac-sha256.

    '''
)

# Note: the ``type`` callable is simply ignored, but it's still useful to
# have it in the docstring.

# Generated at 2022-06-11 23:09:26.959391
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used for the current request.
    The default is to guess based on the provided credentials.

    The following mechanisms are supported:
        {auth_types}

    '''
)
auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    Use the specified authentication type even if the provided credentials
    look like they should work with another type.

    '''
)



# Generated at 2022-06-11 23:10:29.205739
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:10:40.122628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(list(_AuthTypeLazyChoices())) > 0

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
        The authentication method to be used. (default: "{DEFAULT_AUTH_PLUGIN}")
    '''
)

#######################################################################
# Options common to both GET and POST
#######################################################################

common_http = parser.add_argument_group(title='Common Options')


# Generated at 2022-06-11 23:10:43.058858
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:10:44.365975
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:10:56.288568
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used. Not all are available with all
    servers. By default, the most secure mechanism is used.
    Currently supported:
        {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(
    title='Timeouts',
    description=None
)

# Generated at 2022-06-11 23:11:04.707025
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:11:16.842279
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # For example:
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    help='Force the specified HTTP authentication method, e.g., Basic.'
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_false',
    dest='auth_challenge',
    help='''
    Do not handle HTTP 401 or 407 challenge responses automatically.

    Use this option when:

    * You need to use HTTP auth over HTTP, i.e. with --no-https.

    * You want to bypass any preemptive HTTP auth.

    '''
)

#######################################################################
# SSL/TLS Options
#######################################################################
ssl = parser.add_

# Generated at 2022-06-11 23:11:25.164619
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='auto',
    choice=_lazy_choices,
    help='''
    Authentication type to use. By default, HTTPie attempts to detect the
    auth type by the presence of a password or asking the server via
    OPTIONS.

    Available choices:

    {available_choices}

    '''.format(
        available_choices='\n'.join(
            (8 * ' ') + choice for choice in _lazy_choices
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add

# Generated at 2022-06-11 23:11:32.265450
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.load_installed_auth_plugins()
    expected = list(plugin_manager.get_auth_plugin_mapping())
    expected.sort()
    actual = _AuthTypeLazyChoices()
    assert len(expected) == len(actual)
    for item in expected:
        assert item in actual


AUTH_PLUGIN_CHOICES = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:11:41.261263
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    c = _AuthTypeLazyChoices()
    assert iter(c) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth._register('type', 'choices', _AuthTypeLazyChoices())
auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    default=None,
    help='''
    The auth mechanism to be used.

    The default is "auto", which means that the auth type is guessed
    based on the server response (and on the client's HTTPie version).

    To specify an auth type, use the following values:

        ''',
)