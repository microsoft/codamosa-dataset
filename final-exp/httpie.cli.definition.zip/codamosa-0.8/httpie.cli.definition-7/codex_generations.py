

# Generated at 2022-06-11 23:01:42.293807
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted([a for a in _AuthTypeLazyChoices()]) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-11 23:01:54.397306
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AUTH_TYPES.__contains__('basic') == True
    assert AUTH_TYPES.__contains__('oauth1') == True
    assert AUTH_TYPES.__contains__('oauth2') == True
    assert AUTH_TYPES.__contains__('digest') == False
    assert AUTH_TYPES.__contains__('ntlm') == False


AUTH_TYPES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    help='The authentication mechanism to use. Default is "auto".',
    metavar='TYPE',
    choices=AUTH_TYPES
)


# Generated at 2022-06-11 23:02:04.420485
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert list(lazy_choices) == ['basic']


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    dest='auth_plugin',
    metavar='TYPE',
    help=f'''
    The authentication mechanism to be used. Currently supported:

        basic, digest

    Other plugins can be installed. See: {DOCUMENTATION_URL}/user/plugins/#authentication
    '''
)

#######################################################################
# Verify
#######################################################################

verify = parser.add_argument_group(title='SSL Verification')


# Generated at 2022-06-11 23:02:07.203206
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    _AuthTypeLazyChoices.__iter__()

# Generated at 2022-06-11 23:02:20.185361
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom auth plugin to be used instead of the default one.

    If the plugin does not implement a custom prompt, the value entered for
    --auth is passed to the plugin in the form of --<plugin name>
    (e.g., --digest for the digest plugin).

    ''',
)

#######################################################################
# HTTP
#######################################################################
http = parser.add_argument_group(title='HTTP')


# Generated at 2022-06-11 23:02:31.291481
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.load_builtin_plugins()
    assert list(_AuthTypeLazyChoices()) == list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )
    plugin_manager.unload_builtin_plugins()
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication method, create an auth plugin,
    default is 'auto'.

    Use the `list' command to show available auth plugins.

    '''
)


# Generated at 2022-06-11 23:02:40.221666
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    type_choices = _AuthTypeLazyChoices()
    assert 'basic' in type_choices
    assert 'digest' in type_choices


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify a type for the main auth. If a type is specified
    in the URL, this is ignored. If no URL is specified, this is required.
    Available auth types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}
    '''
)

# New-style auth plugin arguments.
auth_plugins = parser.add_argument_group(title='Auth Plugin Options')

# Generated at 2022-06-11 23:02:42.099897
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-11 23:02:55.087604
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import builtin
    from httpie.output.plugin_manager import OUTPUT_PLUGIN_TYPES
    for plugin_type in OUTPUT_PLUGIN_TYPES:
        plugin_manager._loaded_plugins[plugin_type] = [builtin]
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication type to use.
    Currently supported: {sorted(_AuthTypeLazyChoices())}
    '''
)


# Generated at 2022-06-11 23:03:06.050261
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to use.

    The full list of available plugins:

        {plugin_list}

    '''.format(
        plugin_list='\n'.join(
            '{0}{1}'.format(16 * ' ', line.strip())
            for line in
            wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)

#######################################################################
# Proxy
################################################################

# Generated at 2022-06-11 23:03:13.545783
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), Iterable)
    assert isinstance(_AuthTypeLazyChoices().__iter__(), GeneratorType)
    assert isinstance(list(_AuthTypeLazyChoices()), list)

# Generated at 2022-06-11 23:03:26.773514
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from requests import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBasicAuthPlugin
    from httpie.plugins.manager import plugin_manager
    plugin_manager._clear()
    plugin_manager.discover()
    assert HTTPBasicAuth in plugin_manager.get_auth_plugin_mapping()
    assert HTTPBasicAuth.auth_type in _AuthTypeLazyChoices()
    assert HTTPBasicAuthPlugin.auth_type in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:38.172250
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    str(list(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Default is "basic".
    Can also be "digest".

    Use the --debug flag to view the available plugins.

    '''
)


#######################################################################
# SSL
#######################################################################

# ``requests.request`` keyword arguments.

ssl_verify = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:03:49.978577
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): # noqa
    choices = _AuthTypeLazyChoices()
    assert list(iter(choices)) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Tell HTTPie which authentication method to use. If not provided,
    HTTPie guesses the method from the --auth option value.

    The available authentication methods are:

        {", ".join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    For more details, type:

        http --help-auth=<AUTH_TYPE>

    '''
)

#######################################################################
# Output options
#######################################################################
output_options

# Generated at 2022-06-11 23:03:50.910245
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass


# Generated at 2022-06-11 23:04:02.318247
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockPluginManager:
        def __init__(self, is_called):
            self.is_called = is_called

        def get_auth_plugin_mapping(self):
            self.is_called = True
            return {'mock': 'MockPlugin'}

    auth_type_lazy_choices = _AuthTypeLazyChoices()
    mock_plugin_manager = MockPluginManager(False)
    plugin_manager._instance = mock_plugin_manager

    assert 'mock' in auth_type_lazy_choices
    assert mock_plugin_manager.is_called is True


# Generated at 2022-06-11 23:04:11.470533
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication type (Basic or Digest). By default,
    the authentication type is guessed based on the provided URL (if any).

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Disable automatic sending of the basic auth header upon receiving
    a 401 response. Useful when the remote server doesn't handle
    authentication correctly.

    '''
)

#######################################################################
# SSL
#######################################################################

# Generated at 2022-06-11 23:04:22.851888
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Meta options for auth plugins:
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication scheme to be used.

    (These are plugin-specific, see --help-auth, or see the docs for more
    details.)

    '''
)

# Generated at 2022-06-11 23:04:32.029950
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use (default is "basic"). Can be one of {auth_options}.

    '''.format(
        auth_options=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-11 23:04:43.336212
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert [item for item in _AuthTypeLazyChoices()] == \
        AVAILABLE_AUTH_PLUGIN_TYPES


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of authentication to perform. By default, HTTPie will perform
    'basic' authentication. Use --auth-type to select a different type,
    such as 'digest'.

    You may specify a custom auth plugin by passing its name or a path to a
    python module implementing the plugin.

    Use --debug to see a list of available plugins.

    '''
)

#######################################################################
# Timeouts
#######################################################################



# Generated at 2022-06-11 23:04:49.129441
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "digest" in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:50.535923
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

# Generated at 2022-06-11 23:05:00.939226
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class Foo:
        def __contains__(self, item):
            return False
        def __iter__(self):
            return iter([])
    plugin_manager.get_auth_plugin_mapping = lambda: Foo()
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert not choices.__contains__('foo')
    assert not list(choices.__iter__())



# Generated at 2022-06-11 23:05:12.459384
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():  # noqa
    import httpie.plugins.builtin
    from httpie.plugins import AuthPlugin
    assert 'builtin' in _AuthTypeLazyChoices()

    class AuthPluginSubclass(AuthPlugin):
        auth_type = 'auth-plugin-subclass'
    assert 'auth-plugin-subclass' in _AuthTypeLazyChoices()

    @httpie.plugins.builtin.auth_plugin
    class AuthPluginClass(AuthPlugin):
        auth_type = 'auth-plugin-class'
    assert 'auth-plugin-class' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:23.201301
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(AUTHD_DEFAULT_AUTH_TYPES)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin_name',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication scheme to be used. Currently supported authentication
    types are:

        {', '.join(AUTHD_DEFAULT_AUTH_TYPES)}

    Custom authentication plugins can also be registered.

    '''
)

# Generated at 2022-06-11 23:05:26.229446
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-11 23:05:35.636351
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # We cannot use pytest fixture to set up the plugin manager
    # because the plugins are imported early in the execution
    # and not when the test suite runs.
    plugin_manager.load_installed_plugins()
    assert list(_AuthTypeLazyChoices()) == [
        'aws-auth-v1',
        'aws-auth-v2',
        'aws-sigv4',
        'basic',
        'digest',
        'edgegrid',
        'hawk',
        'kerberos',
        'oidc',
        'oauth1',
        'oauth2',
    ]

_auth_type_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:38.871748
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'non_existing' not in choices


# Generated at 2022-06-11 23:05:45.859098
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    l = list(x)
    l.sort()
    assert l == ['digest', 'jwt', 'oauth1', 'basic']

    # Test that the lazy method does not break the fallback to CLI arg_parse
    # functionality, especially required for sub classes (`jwt`, `digest`).
    auth.add_argument(
        '--auth-type', '-t',
        choices=x,  # <---
        help='''
        The type of auth that should be used to authenticate the specified
        credentials. The default is `basic`.

        '''
    )

# Generated at 2022-06-11 23:05:59.372844
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert all(choice in choices for choice in plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:06:13.793723
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help=f'''
    Use the specified authentication plugin. The default is `basic`.

    Available options: {', '.join(_AuthTypeLazyChoices())}

    For more information, check the docs at https://httpie.org/docs#authentication

    ''',
    choices=_AuthTypeLazyChoices(),
)

#######################################################################
# Misc
#######################################################################

misc = parser.add_argument_group(title='Misc')


# Generated at 2022-06-11 23:06:24.356903
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    l=_AuthTypeLazyChoices()
    l.__iter__()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of a plugin that implements a custom auth scheme.

    Installed plugins: {plugins}

    '''.format(
        plugins=', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

auth.add_argument(
    '--auth-plugin',
    help='''
    The name of a plugin file (omit .py suffix).

    '''
)

# Generated at 2022-06-11 23:06:36.773085
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:06:37.484510
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for x in _AuthTypeLazyChoices():
        pass

# Generated at 2022-06-11 23:06:45.369470
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'krb_negotiate', 'netrc', 'ntlm', 'oauth1'
    ]

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. All the mechanisms supported by
    requests - http://docs.python-requests.org/en/master/user/authentication/ -
    are supported.

    '''
)


# Generated at 2022-06-11 23:06:49.707770
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert len(choices) == len(plugin_manager.get_auth_plugin_mapping())
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:06:51.267748
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest']

# Generated at 2022-06-11 23:07:05.226097
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'jwt',
        'hawk',
        'oauth1',
    ]

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose the authentication plugin (if supported by the --auth option).

    ''',
)

#######################################################################
# Misc
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous')

misc.add_argument(
    '--traceback',
    action='store_true',
    help='Print exception traceback should one occur.'
)


# Generated at 2022-06-11 23:07:09.159109
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices."""
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-11 23:07:12.361496
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-11 23:07:34.715249
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to perform. The value can be one of:

        auto       Try Basic and Digest.
        basic      HTTP Basic Auth (default).
        digest     HTTP Digest Auth.

    Or, the name of an authentication plugin.
    To see the list of available authentication plugins,
    use the `http --help-auth` command.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Don't send an initial challenge without credentials.

    '''
)
auth.add_argument

# Generated at 2022-06-11 23:07:38.477827
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-11 23:07:48.326010
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    assert [
        'basic',
        'digest',
    ] == list(_AuthTypeLazyChoices())
AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='NAME',
    default=None,
    type=str,
    choices=AuthTypeLazyChoices,
    help=f'''
    Force use of a specific HTTP auth plugin.

    Available plugins: {', '.join(AuthTypeLazyChoices)}.

    '''
)


# Generated at 2022-06-11 23:07:49.940168
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:01.474567
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism to be used. The value you set this to
    depends on the plugin you want to use for authentication.

    Available plugins are:

        {auth_plugins}

    Check out each plugin (linked above) for details on how to install it,
    as well as what to use as the value for this option.

    Without this option, HTTPie tries to guess the
    authentication mechanism based on --auth credentials.

    '''.format(auth_plugins=format_plugin_list('auth'))
)

# Generated at 2022-06-11 23:08:12.624849
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:08:23.625201
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth2', 'passwd', 'plugin']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''

    The name of the authentication plugin that should be used.

    Plugins can be added at runtime via the ``--auth-plugin`` option or the
    ``HTTPIE_AUTH_PLUGINS`` environment variable.

    '''
)

#######################################################################
# Cookies
#######################################################################
cookies = parser.add_argument_group(title='Cookies')


# Generated at 2022-06-11 23:08:25.016876
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'Plugin' in instance
    assert 'WhatEver' not in instance
    assert '__iter__' not in instance

# Generated at 2022-06-11 23:08:34.983128
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. httpie looks for an authentication
    plugin whose name or alias matches the provided value.

    If not provided or the value is 'auto', httpie asks the server for the
    available authentication mechanisms and selects the most secure one of those
    which it supports: Negotiate, Digest, then Basic.

    '''
)

auth.add_argument(
    '--auth-host',
    metavar='HOST',
    help='''
    The hostname to be used for authentication.

    The default is used when the URL hostname is IP literal.

    '''
)



# Generated at 2022-06-11 23:08:37.731407
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:08.110586
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:09:18.628338
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk', 'ntlm', 'oauth1']

auth_types = auth.add_mutually_exclusive_group()
auth_types.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin module.
    Plugins need to be installed separately.

    Example:

        $ pip install httpie-aws-authv4

    '''
)
auth_types.add_argument(
    '--auth-type=awsv4',
    dest='awsv4_auth',
    action='store_true',
    default=False,
    help=SUPPRESS
)


#######################################################################
# Configuration
#######################################################################

configuration = parser.add

# Generated at 2022-06-11 23:09:28.270962
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert len(choices) >= 2
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices
    assert isinstance(choices, PluginSubcommandType)


# Generated at 2022-06-11 23:09:40.001227
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types

    assert next(iter(auth_types)) == 'basic'

auth.add_argument(
    '--auth-type',
    default=None,
    help='''
    The auth mechanism to be used. Currently supported:

        {auth_types}

    This option is ignored for HTTP Basic and Digest auth, which use
    the --auth option.

    '''.format(
        auth_types=' '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    ),
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-11 23:09:41.514563
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:09:50.487142
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class X:
        def __contains__(self, item):
            return True

        def __iter__(self):
            return iter(['basic', 'digest'])
    assert _AuthTypeLazyChoices() == X()

auth_only_kwarg = {
    'action': 'store_true',
    'default': default_auth_plugin,
    'help': argparse.SUPPRESS
}

_auth_type_help = '''
    Explicitly specify the authentication plugin. This option is not normally
    needed, as the plugin is guessed based on the information provided.

    Possible values:
        {auth_types}
    '''.format(auth_types=_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:09:52.149224
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'foo' not in choices

# Generated at 2022-06-11 23:09:53.690139
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    set(iter(_AuthTypeLazyChoices()))


# Generated at 2022-06-11 23:09:56.095950
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices


# Generated at 2022-06-11 23:10:07.944174
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Custom' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used:
    {auth_types}
    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(
                    plugin_manager.get_auth_plugin_mapping().keys()
                )),
                60
            )
        ).strip()
    )
)

#######################################################################
# Custom plugins
#######################################################################



# Generated at 2022-06-11 23:11:07.906810
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:11:19.781204
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Test for long name of BasicAuthentication plugin"""
    assert "Basic HTTP Authentication" in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:11:21.037595
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['basic', 'digest']) == sorted(list(_AuthTypeLazyChoices()))

# Generated at 2022-06-11 23:11:27.409077
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == [
        'digest',
        'hawk',
        'hmac',
    ]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism to be used. Defaults to "basic"
    if --auth is provided.

    '''
)
auth.add_argument(
    '--auth-scheme',
    help='''
    Specify name of the auth scheme. Defaults to "Basic".

    '''
)

#######################################################################
# Transport
#######################################################################

transport = parser.add_argument_group(title='Transport')

# Generated at 2022-06-11 23:11:31.754343
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    for plugin_type in plugin_manager.get_auth_plugin_mapping().keys():
        assert plugin_type in auth_type

# Generated at 2022-06-11 23:11:40.912723
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # use argparse._AppendAction as a placeholder argument
    arg = argparse._AppendAction(option_strings=(), dest=None, nargs=None)
    m = _AuthTypeLazyChoices()
    choices_keyword_arg = m.__get_choices_keyword_arg(arg)
    assert all(key in choices_keyword_arg for key in ('choices', 'help'))
    assert len(choices_keyword_arg['choices']) == len(m)
    assert all(item in choices_keyword_arg['choices'] for item in m)
