

# Generated at 2022-06-11 23:01:38.028176
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_instance = _AuthTypeLazyChoices()
    assert 'plugin_name' in auth_type_lazy_choices_instance

# Generated at 2022-06-11 23:01:50.609326
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. With no argument given,
    HTTPie will choose the most secure mechanism it knows about,
    and will prompt if insecure mechanism was chosen.

    With --auth-type given, the argument will be used as the authentication
    mechanism.

    Currently supported mechanisms are:

    - basic (default if no argument is given)
    - digest
    - oauth1

    Additional mechanisms may be provided by plugins.
    Use `http --debug plugins to list available auth plugins.

    ''',
)

# Generated at 2022-06-11 23:01:59.586315
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:11.316794
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import OAuth1Auth
    from httpie.plugins.builtin import OAuth2Auth
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'oauth1', 'oauth2']
    plugin_manager.unregister(HTTPBasicAuth)
    plugin_manager.unregister(HTTPDigestAuth)
    plugin_manager.unregister(OAuth1Auth)
    plugin_manager.unregister(OAuth2Auth)
    assert list(_AuthTypeLazyChoices()) == []



# Generated at 2022-06-11 23:02:23.300896
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported: {0}
    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to which to send the credentials (e.g., when running behind a
    proxy).

    '''
)


# Generated at 2022-06-11 23:02:35.281641
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism. Possible choices:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    If not specified, the plugin attempts to infer it from the provided --auth
    credentials.

    ''',
)


#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:02:45.427576
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for key in _AuthTypeLazyChoices():
        assert plugin_manager.get_auth_plugin_mapping()[key]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default=None,
    help='''
    The authentication mechanism to be used. By default, HTTPie
    tries to figure it out based on the --auth option value.
    The value can be any of:

        {0}

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping()))
)

# Generated at 2022-06-11 23:02:47.135300
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-11 23:02:52.888313
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices()['basic']
    assert _AuthTypeLazyChoices()['digest']
    assert _AuthTypeLazyChoices()['oauth1']
    assert _AuthTypeLazyChoices()['ntlm']
    assert _AuthTypeLazyChoices()['hawk']

# Generated at 2022-06-11 23:02:54.473070
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:07.799392
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    result = list(_AuthTypeLazyChoices())
    assert sorted(result) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))



# Generated at 2022-06-11 23:03:16.363286
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force using a specified authentication plugin. The default one is
    chosen based on -a option value, i.e., if it contains a colon.

    Available auth types: {auth_types}

    '''.format(
        auth_types=plugin_manager.get_auth_plugin_mapping().keys()
    )
)

# Generated at 2022-06-11 23:03:18.679870
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert_equal(
        'digest' in _AuthTypeLazyChoices(),
        True
    )

# Generated at 2022-06-11 23:03:31.210357
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, the
    authentication mechanism is inferred from the URL (e.g., --auth-type=basic
    for Basic auth, --auth-type=digest for Digest auth).

    '''
)
auth.add_argument(
    '--auth-group',
    default=1,
    help='''
    The auth group provided by the user when multiple groups are specified in
    config file

    '''
)

# Generated at 2022-06-11 23:03:33.381341
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    instance.__contains__('digest')

# Generated at 2022-06-11 23:03:35.672530
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices


# Generated at 2022-06-11 23:03:38.365766
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))
auth_plugin_mapping = _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:03:50.010814
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'missing' not in _AuthTypeLazyChoices()


auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=auth_type_choices,
    help=f'''
    The authentication mechanism to be used. Can be one of:

        {', '.join(sorted(auth_type_choices))}.

    "basic" (the default) and "digest" are builtin, others are
    provided through plugins (see "--auth-plugin" option).

    '''
)


# Generated at 2022-06-11 23:03:51.195318
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:05.072815
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockAuthPlugin:
        auth_type = 'sample'
        __namespace__ = 'httpie.plugins.auth.sample'

    def test_plugin(plugin_manager):
        plugin_manager.register(MockAuthPlugin)

    with plugin_context() as (plugin_manager, mock_plugins_dir):
        test_plugin(plugin_manager)

    auth_choices = _AuthTypeLazyChoices()
    assert 'sample' in auth_choices


auth_type_usage = '|'.join(sorted(
    [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2',
        'aws'
    ] + list(plugin_manager.get_auth_plugin_mapping().keys())))

auth.add

# Generated at 2022-06-11 23:04:13.230407
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-11 23:04:24.343054
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['foo', 'bar']


# Generated at 2022-06-11 23:04:33.118194
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices__ok_result)



# Generated at 2022-06-11 23:04:35.727937
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:04:45.159992
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(
        plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Explicitly specify a type of HTTP authentication.

    By default, the authentication mechanism is automatically detected based on
    the provided credentials (i.e., --auth).

    Available mechanisms are:

    ''' +
    '\n'.join(
        '\n'.join(
            8 * ' ' + line.strip()
            for line in wrap(', '.join(_AuthTypeLazyChoices()), 60)
        ).strip()
    )
)

# ``requests.request`` keyword arguments.
auth

# Generated at 2022-06-11 23:04:48.974665
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic') == True
    assert choices.__contains__('other') == False


# Generated at 2022-06-11 23:04:58.562159
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth.add_argument(
    '--auth-type',
    # Default value is set in HTTPie core's __call__()
    default=None,
    metavar='TYPE',
    help='''
    The auth mechanism to be used. By default, HTTPie tries to determine the
    auth mechanism based on the URL.

    The following mechanisms are currently supported:

    {0}

    '''.format('\n'.join(
        ' ' * 8 + line.strip()
        for line in wrap(', '.join(_AuthTypeLazyChoices()), 60)
    ).strip()),
    choices=_AuthTypeLazyChoices()
)

#######################################################################
# Output options


# Generated at 2022-06-11 23:05:09.586758
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert sorted(auth_type_choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, HTTPie
    will try to guess based on the --auth option.

    '''
)

#######################################################################
# Miscellaneous
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous') \
    .add_mutually_exclusive_group(required=False)



# Generated at 2022-06-11 23:05:21.219346
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. The available options depend on the installed
    plugins. Built-in mechanisms are "basic" and "digest".

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    Use a custom host to lookup user credentials in the .netrc file
    (instead of the request's host).

    ''',
)

#######################################################################
# Timeout
#######################################################################

timeout = parser.add_

# Generated at 2022-06-11 23:05:22.674375
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    assert list(_AuthTypeLazyChoices())



# Generated at 2022-06-11 23:05:39.759880
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    p = _AuthTypeLazyChoices()
    assert 'basic' in p
    assert 'digest' in p
    assert 'custom-plugin' not in p

# Generated at 2022-06-11 23:05:42.555831
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:56.549016
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # noqa
    """Unit test for constructor of class _AuthTypeLazyChoices."""
    assert set(_AuthTypeLazyChoices()) == set(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, if --auth is provided.
    The supported mechanisms depend on the installed plugins.
    The basic auth plugin is always available.
    For example, type "http --help-auth" to get a list of
    available auth plugins.

    ''',
)

# Generated at 2022-06-11 23:06:03.801628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(['digest', 'basic'])) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication handler.
    The default is basic.

    ''',
)


#######################################################################
# Connection
#######################################################################
connection = parser.add_argument_group(title='Connection')


# Generated at 2022-06-11 23:06:07.956236
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    'AuthType: iter'
    from httpie.cli.parser import _AuthTypeLazyChoices
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == ['auto', 'password', 'token', 'username']


# Generated at 2022-06-11 23:06:21.092195
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert len(list(lazy_choices)) > 0

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=auth_type_lazy_choices,
    help='''
    Choose the auth type.

    Currently available types:

    ''' + '\n'.join(('  ' + line)
                    for line in wrap(', '.join(auth_type_lazy_choices), 60))

)

# Generated at 2022-06-11 23:06:24.762040
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'basic' in instance
    assert 'digest' in instance
    assert 'plugin-not-loaded' not in instance

# Generated at 2022-06-11 23:06:37.441753
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(['basic','digest','aws','hawk'])

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "basic",
    which sends the username and password over HTTP Basic Authentication.
    Supported: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-11 23:06:47.457903
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    type_lazy_choices = _AuthTypeLazyChoices()
    assert all(name in type_lazy_choices
               for name in plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism.

    The default is "basic" if --auth is provided, and none otherwise.

    The following types are available:

        {','.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-11 23:06:55.685307
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test __contains__
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Non-Existing' not in _AuthTypeLazyChoices()

    # Test __iter__
    expected = list(_AuthTypeLazyChoices())
    actual = [
        'basic', 'Digest', 'aws-sigv4', 'aws4-hmac-sha256',
        'awsv4-signature', 'aws4-signature', 'aws4-sha256'
    ]
    assert sorted(expected) == sorted(actual)


# Generated at 2022-06-11 23:07:26.221676
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for available_auth_plugin in choices:
        assert available_auth_plugin in choices


# Generated at 2022-06-11 23:07:28.186103
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['digest', 'jwt']) == list(auth_type_lazy_choices)

# Generated at 2022-06-11 23:07:36.073218
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    plugin_manager.get_auth_plugin_mapping = lambda: {'foo': 'bar'}
    assert list(_AuthTypeLazyChoices()) == ['foo']

from httpie.plugins import plugin_manager

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. By default, HTTPie
    tries to guess the authentication type. If a plugin providing a custom
    auth mechanism is available, use ``--auth-type=<NAME>`` to use it.

    The following auth mechanism plugins are currently available:

    {plugin_manager.get_auth_plugin_descriptions()}

    '''
)

# Generated at 2022-06-11 23:07:46.028271
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    USERNAME_PASSWORD_AUTH = 'username+password'
    assert USERNAME_PASSWORD_AUTH in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:58.057113
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom HTTP authentication plugin module. Plugins are searched
    for in the current working directory and in the directories provided by
    the --auth-plugin-dir option. The module name should coincide with the
    filename, minus the extension.

    For example, to use the custom plugin from my_auth_plugin.py, use:

        --auth-type=my_auth_plugin

    To see what plugins are available, try:

        $ http --debug

    '''
)

# Generated at 2022-06-11 23:08:06.195687
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

auth_types = parser.add_argument_group(title='Authentication types')
auth_types.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Set the authentication type (plugin) to be used for requests.
    Overrides the default authentication plugin, which is picked
    based on the --auth option value, if present.
    '''
)

#######################################################################
# Cookies
#######################################################################
# ``requests.request`` keyword arguments.
cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:08:15.642125
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    available_types = _AuthTypeLazyChoices()
    for auth_type in available_types:
        assert auth_type in available_types

auth_plugin_descriptions = ', '.join(
    '{0}: {1}'.format(name, plugin.description())
    for name, plugin in plugin_manager.get_auth_plugins()
)

# Generated at 2022-06-11 23:08:26.338295
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(_AuthTypeLazyChoices()) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

_auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_auth_type_choices,
    help=f'''
    The authentication plugin to use.
    By default, the standard HTTP Basic Auth is assumed if the username
    and password are provided with the -a option.

    The following plugins are currently available:

        {', '.join(sorted(_auth_type_choices))}

    Use `http --debug to see how well a given plugin works for a
    particular site.
    '''
)

# Generated at 2022-06-11 23:08:37.003024
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class CustomAuthPlugin(AuthPlugin):
        auth_type = 'custom-plugin'

    with plugin_manager.with_plugins([CustomAuthPlugin()], included=False):
        assert 'custom-plugin' in _AuthTypeLazyChoices()  # noqa


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication mechanism to be used.
    The value is an authentication plug-in name.
    For example, for Digest authentication, use --auth-type=digest

    Available plug-ins:

    {plugins}

    '''.format(
        plugins='\n * '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-11 23:08:46.255397
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
# Test function test__AuthTypeLazyChoices___iter__
test__AuthTypeLazyChoices___iter__()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    Specify the authentication type to be used.
    The default is basic, which is generally the only supported one.
    The following auth types are available: {choices}.
    The auth type can also be specified via HTTPie config or plugin.

    '''.format(
        choices=', '.join(_AuthTypeLazyChoices())
    )
)



# Generated at 2022-06-11 23:09:51.416901
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'digest',
        'hawk',
        'jwt',
        'oauth1',
    ]
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='The authentication method to be used.'
)
auth.add_argument(
    '--auth-endpoint',
    help='The full URL to the authentication endpoint (i.e., if HTTP Basic'
         ' auth is used, then the full URL to the login page).'
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Don't use ``proxies`` argument of ``HTTPAdapter``, because that would make
# it impossible to specify per-scheme proxies.

# Generated at 2022-06-11 23:09:57.313598
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:10:08.841316
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import AuthPlugin

    assert not isinstance({}, _AuthTypeLazyChoices)
    assert 'digest' in _AuthTypeLazyChoices()

    class CustomAuthPlugin(AuthPlugin):

        auth_type = 'custom-auth'

    assert 'custom-auth' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-scheme',
    default=None,
    help='''
    The authentication scheme to be used.

    '''
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-11 23:10:20.174343
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        plugin_manager.load_auth_plugins()
    except:
        pass
    assert 'client-cert' in _AuthTypeLazyChoices()
    assert 'basic' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type to use.
    Run `http --auth-help` to print detailed help.

    The default is 'basic'

    '''
)

auth.add_argument(
    '--auth-help',
    action='store_true',
    default=False,
    help='''

    Print detailed help for --auth-type

    '''
)

################################

# Generated at 2022-06-11 23:10:22.349270
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest']

# Generated at 2022-06-11 23:10:30.789307
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom HTTP authentication plugin. The default value is "basic".

    '''
)
auth.add_argument(
    '--auth-verify',
    action='store_true',
    help='''
    Verify SSL certificate.

    '''
)

# Generated at 2022-06-11 23:10:41.366874
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('basic' in _AuthTypeLazyChoices()) is True
    assert ('digest' in _AuthTypeLazyChoices()) is True
    assert ('hawk' in _AuthTypeLazyChoices()) is True

    for auth_type in _AuthTypeLazyChoices():
        assert auth_type in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-11 23:10:51.850047
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'AWS' in choices

    # Order is defined by the class name
    assert list(choices) == ['AWS', 'Basic', 'Digest']


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. This only makes sense when
    combined with --auth.

    A list of all supported mechanisms can be displayed using the
    `http --auth-type-help` command.

    '''
)
auth.add_argument(
    '--auth-type-help',
    help=SUPPRESS,
    action='store_true'
)

####################################################################

# Generated at 2022-06-11 23:10:55.306819
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-11 23:11:01.837045
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    auth_type_lazy_choices_iter = iter(auth_type_lazy_choices)
    assert next(auth_type_lazy_choices_iter) == 'aws'
    assert next(auth_type_lazy_choices_iter) == 'hawk'
    assert next(auth_type_lazy_choices_iter) == 'multipass'

