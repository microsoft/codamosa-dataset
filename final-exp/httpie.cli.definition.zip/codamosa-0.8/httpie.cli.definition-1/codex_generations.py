

# Generated at 2022-06-11 23:01:40.025422
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    fake_plugin_map = {
            'fake1': None,
            'fake2': None,
            'fake3': None
    }
    with patch.object(plugin_manager, 'get_auth_plugin_mapping', return_value=fake_plugin_map):
        assert 'fake1' in _AuthTypeLazyChoices()
        assert 'fake2' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:01:52.534812
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. The default is "basic".

    Currently supported:
    {supported}

    The {insecure} auth plugin is provided as an example and is not supported.

    '''.format(
        supported=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
        insecure=INSECURE_AUTH_PLUGIN_NAME,
    )
)

# Generated at 2022-06-11 23:02:03.763060
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )
auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth implementation to use.

    Available values:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-11 23:02:17.158605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ) == sorted(list(_AuthTypeLazyChoices()))



# Generated at 2022-06-11 23:02:27.978679
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == list(choices)


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an authentication type.  If not given, the auth plugin with
    the shortest name is used.  The following types are built in:

    {get_docstring_section(Authenticator, 'Supported auth types')}

    Other auth types may be provided by installed plugins.

    '''
)

#######################################################################
# HTTP(S) proxy
#######################################################################

proxy = parser.add_argument_group(title='HTTP(S) Proxy')


# Generated at 2022-06-11 23:02:38.938783
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():    
    def test__AuthTypeLazyChoices___iter__():
        # Test for method __iter__ of class _AuthTypeLazyChoices
        # Caused by (reported by Thomas Grainger)
        from httpie import plugins
        from httpie.plugins import AuthPlugin, plugin_manager
        class ExampleAuthPlugin(AuthPlugin):
            auth_type = 'example'
        plugin_manager.register(ExampleAuthPlugin)
        choices = _AuthTypeLazyChoices()
        assert (list(choices) == ['basic', 'digest', 'example'])
        plugin_manager.unregister(ExampleAuthPlugin)


# Generated at 2022-06-11 23:02:51.471225
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'aws4-hmac-sha256' in auth_type_choices
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(auth_type_choices)


# Generated at 2022-06-11 23:02:54.150501
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices().__iter__(), types.GeneratorType)

# Generated at 2022-06-11 23:03:05.308339
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()


auth_type = auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin, e.g., "digest". Use "http --help-auth"
    to list all the available authentication plugins.

    '''
)

# Generated at 2022-06-11 23:03:17.732798
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)
    assert 'basic' in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies which auth mechanism to use, one of:

        auto
        basic
        digest
        hawk
        aws
        aws4
        oauth1
        ntlm
        negotitate

    The default is "auto".

    '''
)

# Generated at 2022-06-11 23:03:23.201412
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()
_AuthTypeLazyChoices.test__contains__ = test__AuthTypeLazyChoices___contains__

# Generated at 2022-06-11 23:03:25.740887
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = list(_AuthTypeLazyChoices())
    assert choices == ['basic', 'digest', 'hawk', 'netrc']

# Generated at 2022-06-11 23:03:37.380050
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Basic and Digest authentication are always built-in.
    Plugins can register additional ones.

    HTTPie reads credentials from `$HOME/.netrc`, if the file exists and is
    readable.

    '''
)

auth.add_argument(
    '--auth-type-force-basic',
    action='store_true',
    default=False,
    help='''
    Make Basic authentication the default, even when the server
    specifies (using the 401 status code) that Digest authentication
    should be used.

    '''
)


# Generated at 2022-06-11 23:03:43.992116
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    choices=auth_type_choices,
    help='''
    The authentication mechanism to be used for authenticating to the
    server. Currently supported:

    {auth_types}

    '''.format(auth_types='\n'.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ))
)


# Generated at 2022-06-11 23:03:51.701950
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'basic' in auth_types
    assert sorted(auth_types) == ['basic', 'digest']


# Generated at 2022-06-11 23:04:05.438293
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))


# Generated at 2022-06-11 23:04:06.522112
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:17.472247
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Tests the auth plugin availability."""
    # pylint: disable=protected-access
    if not isinstance(_AuthTypeLazyChoices(), list):
        raise TypeError('_AuthTypeLazyChoices is not a list')

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use.

    '''
)

#######################################################################
# Optimizations
#######################################################################

optimizations = parser.add_argument_group(title='Optimizations')
optimizations.add_argument(
    '--follow', '-F',
    action='store_true',
    default=False,
    help='''
    Follow redirects.

    '''
)
optimizations.add

# Generated at 2022-06-11 23:04:19.911021
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert iter(choices) == iter(list(choices))


# Generated at 2022-06-11 23:04:28.823013
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Currently supported:
    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-11 23:04:43.639254
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hmac' in choices
    assert 'foo' not in choices


auth_type = parser.add_argument_group(title='Authentication Types')
auth_type.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth type to be used.

    One of:

        basic - HTTP Basic Authentication
        digest - HTTP Digest Authentication
        hmac - Requests compatible authentication

    See also the -a or --auth flag.

    '''
)

# Generated at 2022-06-11 23:04:55.641017
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        "basic",
        "digest",
        "hawk",
        "netrc",
        "ntlm",
        "oauth1",
    ]



# Generated at 2022-06-11 23:05:00.532835
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    # keyError = None
    try:
        instance.__contains__('some random string')
    except KeyError as keyError:
        pass
    assert keyError is not None

# Generated at 2022-06-11 23:05:11.796285
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(PLUGIN_MAP['auth']))


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help=f'''
    Use the specified authentication plugin. By default, the plugin is inferred
    from the --auth option value (e.g., "foo" implies "--auth-type=basic").

    Available plugins: {_AuthTypeLazyChoices()}

    ''',
    metavar='PLUGIN'
)


#######################################################################
# Miscellaneous
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous')



# Generated at 2022-06-11 23:05:14.307784
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    >>> sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    True
    """

# Generated at 2022-06-11 23:05:24.546660
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Verify that the choices are cached when accessed
    choices = _AuthTypeLazyChoices()
    is_first_access = True
    for choice in choices:
        if is_first_access:
            is_first_access = False
        else:
            # Verify that we are working against a cached data
            assert choice in choices


# Generated at 2022-06-11 23:05:34.682009
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(list(_AuthTypeLazyChoices())) == AUTH_PLUGIN_MAP.keys()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    help='''
    If specified, the value must be the name of the auth plugin to use.
    The default type is inferred from the provided credentials.

    '''
)
auth.add_argument(
    '--auth-type-help',
    action='store_const',
    const=True,
    help='''
    Display help message for the specified --auth-type

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:05:42.217985
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    options = _AuthTypeLazyChoices()
    assert len(set(options) & {'http', 'kerberos'}) == 2
    assert 'http' in options
    assert 'kerberos' in options
    assert 'foo' not in options

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use.

    ''',
)
auth_type.completer = AuthPluginCompleter()

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Prevents HTTPie from sending an initial response to a request that
    requires authentication.

    ''',
)
auth.add

# Generated at 2022-06-11 23:05:44.082020
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:55.424840
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

plugin_manager.load_auth_plugins()
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to perform (default is "auto").

    Possible values:
        'auto', 'basic', 'digest', 'hawk', 'ntlm'

    '''
)


# Generated at 2022-06-11 23:06:12.355689
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(auth_type_lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping())


auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:06:13.944211
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert list(_AuthTypeLazyChoices()) == []

# Generated at 2022-06-11 23:06:17.809845
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('basic' in _AuthTypeLazyChoices())
    assert ('bearer' in _AuthTypeLazyChoices())
    # assertion
    assert ('nonexistent' not in _AuthTypeLazyChoices())


# Generated at 2022-06-11 23:06:26.113603
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """

    Example::

        >>> import os
        >>> from httpie.plugins import builtin
        >>> os.environ['HTTPIE_PLUGINS_DIR'] = ''
        >>> list(_AuthTypeLazyChoices())
        ['Basic', 'Digest']  # default
        >>> list(_AuthTypeLazyChoices())
        ['Basic', 'Digest', 'WDigest']  # default + default HTTPie plugin
        >>> _ = builtin.__file__
        >>> list(_AuthTypeLazyChoices())
        ['Basic', 'Digest']  # default
        >>> import os
        # Remove the plugin directory so that it is not considered.
        >>> os.environ['HTTPIE_PLUGINS_DIR'] = 'foo'
        >>> list(_AuthTypeLazyChoices())
        ['Basic', 'Digest']

    """


# Generated at 2022-06-11 23:06:38.856745
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert str(list(_AuthTypeLazyChoices())) == '[]'


# TODO:
# class _AuthTypes(sorted(plugin_manager.get_auth_plugin_mapping())):
#     def __contains__(self, item):
#         return super().__contains__(item)
#
#     def __iter__(self):
#         yield from super().__iter__()
#     #     return super().__iter__()
#     #     return iter(sorted(plugin_manager.get_auth_plugin_mapping()))
#
#     def __getattr__(self, item):
#         if item in self:
#             return item
#         raise AttributeError(item)


auth_keyword = auth.add_argument_group(title='Keyword Arguments')
# The following line

# Generated at 2022-06-11 23:06:46.033985
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    obj = _AuthTypeLazyChoices()
    assert obj == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin (e.g., oauth2, sigv4, ...).
    See "http --auth-type=oauth2 --help" for more info.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-11 23:06:55.201213
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used for looking up the password in
    the keyring.

    '''
)

#######################################################################
# HTTP methods
#######################################################################

methods = parser.add_argument_group(title='HTTP methods')

METHOD_CHOICES = ('GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS')

# Generated at 2022-06-11 23:07:07.375271
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the authentication plugin. For a list of built-in plugins,
    run: `http --help-auth`.
    The default auth plugin is "{default}".

    '''.format(default=DEFAULT_AUTH_PLUGIN_NAME),
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:07:18.759000
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for i in _AuthTypeLazyChoices():
        assert i in plugin_manager.get_auth_plugin_mapping()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. Available types are:

        {plugin_list}

    Type names are case-insensitive.

    '''.format(
        plugin_list=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-11 23:07:21.444112
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:07:45.758257
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'my-super-cool-auth-type' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The HTTP authentication type to be used. Defaults to "basic".

    The plugin interface allows for custom auth types to be registered.

    Use the --debug flag to show the list of all available auth types.

    '''
)

# Generated at 2022-06-11 23:07:57.873663
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert len(list(lazy_choices.__iter__())) > 1

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. Supported auth types depend on installed plugins.
    By default HTTPie tries to guess the auth type.

    Examples:

        --auth-type=basic
        --auth-type=oauth
        --auth-type=digest

    The following AUTH_TYPES are currently available:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

#######################################################################
# TLS/SSL client-side options
################################################################

# Generated at 2022-06-11 23:08:06.122661
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(plugin_manager.get_auth_plugin_mapping().keys())) == list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    type=auth_type,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    Use --debug to list all plugins. You can also specify a path to a
    module or class.

    '''
)



#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:08:14.050500
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import AuthPlugin, plugin_manager
    from six import add_metaclass
    from unittest import TestCase
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.plugins.builtin import HTTPBasicAuth

    class AuthConflictAuth(AuthPlugin):
        auth_type = 'conflict'

    @add_metaclass(plugin_manager.PluginMount)
    class AuthConflictAuth2(AuthPlugin):
        auth_type = 'conflict'

    try:
        class AuthConflictAuth3(AuthPlugin):
            auth_type = 'conflict'

    except PluginAlreadyRegistered as e:
        assert str(e).split('\n')[0] == \
            'httpie.plugins.builtin.HTTPBasicAuth'


# Generated at 2022-06-11 23:08:16.158859
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for choice in _AuthTypeLazyChoices():
        assert choice in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:26.495151
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert len(list(_AuthTypeLazyChoices())) > 0

# Register Auth Plugins
plugin_manager.load_auth_plugins()

auth.add_argument(
    '--auth-type',
    metavar='NAME',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use. Plugins registered: {auth_types}

    '''.format(auth_types=', '.join(plugin_manager.get_auth_plugin_mapping().keys()))
)

auth_plugin_kwargs_decoder = JSONArgumentDecoder(decode_dict_keys=True,
                                                 decode_dict_values=True)


# Generated at 2022-06-11 23:08:27.793740
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:29.128862
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # assert 'Basic' in _AuthTypeLazyChoices()
    pass

# Generated at 2022-06-11 23:08:40.319012
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

_auth_type_lazy_choices = _AuthTypeLazyChoices()

_auth_type_help = '''
    '.netrc' machanism from .netrc_path file (see also --netrc-path).

    'digest', 'digest-ie' - digest auth (see also --auth-digest-ie).

    The following '<TYPE>' values are supported: {auth_types}.
    '''

# Generated at 2022-06-11 23:08:45.288353
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'string' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:16.133548
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert 'basic' in obj


# Generated at 2022-06-11 23:09:26.439248
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    type=str.lower,
    help='''
    The authentication method to be used. The default is to try them all
    in order as presented here.

    Note that some of the auth types require a plugin, which needs to be
    installed. The available auth types are:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)


# ``requ

# Generated at 2022-06-11 23:09:37.308922
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert sorted(['basic', 'digest']) == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    # We implement the choices in a custom way because:
    # 1. We want to be able to lazy-fetch them and
    # 2. They are sorted by the name
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "basic".

    If the server supports multiple authentication schemes
    (e.g. "Basic" and "Digest"), the most secure one is automatically
    chosen.

    '''
)

# Generated at 2022-06-11 23:09:40.268238
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:09:42.694083
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == \
        sorted(plugin_manager.get_auth_plugin_mapping())



# Generated at 2022-06-11 23:09:51.310439
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert sorted(get_auth_plugins()) == sorted(choices)
    [choice in choices for choice in sorted(get_auth_plugins())]
    assert all(choice in choices for choice in sorted(get_auth_plugins()))


# Generated at 2022-06-11 23:09:52.448821
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:05.018260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:10:12.733243
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert BasicAuthPlugin.auth_type in lazy_choices
    assert DigestAuthPlugin.auth_type in lazy_choices
    assert HawkAuthPlugin.auth_type in lazy_choices
    assert False

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the authentication plugin to use. By default, HTTPie
    tries to detect the correct plugin to use (currently only Basic is
    supported).

    '''
)

# Generated at 2022-06-11 23:10:15.066650
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(iter(_AuthTypeLazyChoices()))) == [
        'basic', 'digest', 'plugin-', 'plugin-plugin-name'
    ]

# Generated at 2022-06-11 23:11:25.468221
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth_plugin_type = auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of authentication plugin. Currently implemented plugins are: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-11 23:11:36.844015
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used: basic, digest, hawk.
    Defaults to basic.

    '''
)
auth.add_argument(
    '--auth-nonce',
    default=None,
    help='''
    Specify the nonce (a unique token) used by Digest authentication.
    This nonce is used until the requests session is closed.

    '''
)