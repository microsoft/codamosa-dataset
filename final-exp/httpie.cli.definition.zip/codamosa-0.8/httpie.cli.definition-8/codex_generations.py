

# Generated at 2022-06-11 23:01:42.420912
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used, if different than the default:

    {auth_type_choices}

    '''
)

auth.add_argument(
    '--auth-type-force',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used, ignoring default value. This can be
    used to enable an authentication type even if the server does not
    advertise it.

    '''
)


# Generated at 2022-06-11 23:01:47.105881
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.load_builtin_plugins()
    valid_auth_types = _AuthTypeLazyChoices()
    assert 'digest' in valid_auth_types
    assert len(list(valid_auth_types)) > 0

# Generated at 2022-06-11 23:01:57.379800
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in ','.join(_AuthTypeLazyChoices())
    assert sorted(['digest', 'kerberos', 'jwt']) == \
        sorted(list(_AuthTypeLazyChoices()))
auth.add_argument(
    '--auth-type', '--auth-type',
    metavar='TYPE',
    default=None,
    type=AuthCredentials.type_from_name,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication method to be used. By default, HTTPie will
    automatically select the most secure method available.

    '''
)

# Generated at 2022-06-11 23:02:01.105228
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lc = _AuthTypeLazyChoices()
    assert 'basic' in lc
    assert 'custom' not in lc
    plugin_manager.get_plugin_class('auth', 'custom')
    assert 'custom' in lc


# Generated at 2022-06-11 23:02:08.890608
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert not isinstance(
        _AuthTypeLazyChoices(),
        collections.abc.Mapping
    )
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices, collections.abc.Iterable)
    for auth_type in auth_type_lazy_choices:
        assert isinstance(auth_type, str)
        assert auth_type in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-11 23:02:12.218157
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _type = _AuthTypeLazyChoices()
    assert isinstance(iter(_type), collections.abc.Iterator)

# Generated at 2022-06-11 23:02:12.917745
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-11 23:02:24.063801
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    atlc = _AuthTypeLazyChoices()
    assert not list(atlc)
test__AuthTypeLazyChoices___iter__()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom (3rd party) auth plugin module. A plugin module is a
    HTTPie plugin that supports the auth hook. See the plugins documentation
    (https://httpie.org/docs/plugins#authentication-plugins)
    for more details.
    ''',
)


# Generated at 2022-06-11 23:02:26.585657
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_map = plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-11 23:02:37.929398
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ["basic", "digest"]


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication mechanism to be used.

    Choices:

        {", ".join(_AuthTypeLazyChoices())}

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Do not perform the initial authentication challenge. Useful if the server
    is not configured to handle authentication over unencrypted HTTP, but
    still responds to unauthenticated reqests over HTTPS.

    '''
)

# Generated at 2022-06-11 23:02:43.091685
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'jwt' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:02:56.355704
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # possible_items -> __iter__ -> __contains__ -> get_auth_plugin_mapping
    possible_items = ('abc', 'basic', 'digest')
    mock_mapping = {'basic': 'mock_basic', 'digest': 'mock_digest'}
    with patch('httpie.cli.plugin_manager.get_auth_plugin_mapping',
               return_value=mock_mapping) as mock_get_mapping:
        actual = list(_AuthTypeLazyChoices())
        assert list(actual) == ['basic', 'digest']



# Generated at 2022-06-11 23:02:58.346366
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(item in _AuthTypeLazyChoices() for item in _AuthTypeLazyChoices())



# Generated at 2022-06-11 23:03:00.089297
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:03:08.916142
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    lazy_choices = _AuthTypeLazyChoices()
    # This test is just to make sure that this test method is run.
    assert '' in lazy_choices
    assert 'jwt' in lazy_choices
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices

    try:
        next(lazy_choices)
    except StopIteration:
        pytest.fail('_AuthTypeLazyChoices.__iter__() returned an empty iterator.  Should not happen.')


# Generated at 2022-06-11 23:03:22.145624
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Unit test for class _AuthTypeLazyChoices.
    """
    lazy_choices = _AuthTypeLazyChoices()
    assert(len(list(iter(lazy_choices))) > 0)


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    type=str.lower,
    help='''
    The name of an auth plugin.

    The option is interpreted as an HTTPie plugin if it does not match
    any predefined auth type.

    Available auth types: none, basic, digest, oauth1, oauth2.

    ''',
    choices=_AuthTypeLazyChoices()
)

# Generated at 2022-06-11 23:03:27.437274
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    items = ['noauth', 'digest', 'bearer']
    assert items[0] in _AuthTypeLazyChoices()
    assert items[1] in _AuthTypeLazyChoices()
    assert items[2] in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:28.995197
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'jwt' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:39.736712
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping()
    )


# Generated at 2022-06-11 23:03:41.455059
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:55.462525
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    assert len(list(_AuthTypeLazyChoices())) > 1


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use, e.g. {auth_types}.

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    Domain of the host to use for HTTP authentication.

    '''
)
auth.add_argument(
    '--no-auth',
    dest='auth',
    action='store_const',
    const=None,
    help='''
    Inhibits sending any Authorization/Proxy-Authorization headers.

    '''
)


#######################################################################

# Generated at 2022-06-11 23:04:02.423602
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    if not hasattr(test__AuthTypeLazyChoices___contains__, 'results'):
        test__AuthTypeLazyChoices___contains__.results = _AuthTypeLazyChoices()
    return test__AuthTypeLazyChoices___contains__.results
del test__AuthTypeLazyChoices___contains__

# Generated at 2022-06-11 23:04:11.512498
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-11 23:04:22.852335
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    if not isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices):
        raise AssertionError(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. The default is
    inferred from the provided credentials.

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    Host (domain or IP) for which basic/digest auth credentials apply.
    Defaults to the request host.

    '''
)

#######################################################################
# Certificate
#######################################################################

cert = parser.add_argument_group(title='Certificate')

# Generated at 2022-06-11 23:04:23.479336
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass

# Generated at 2022-06-11 23:04:32.489143
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'plugin' in auth_type_choices


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    This can be a built-in mechanism:

        basic

    Or a plugin:

        {auth_types}

    '''.format(
        auth_types='\n        '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

# Generated at 2022-06-11 23:04:34.458426
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:35.910210
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:37.112742
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:04:46.159716
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import builtin
    from httpie.plugins.manager import plugin_manager
    from httpie.plugins.builtin import BasicAuthPlugin

    auth_types_before = list(_AuthTypeLazyChoices())

    plugin_manager.unregister(BasicAuthPlugin)
    plugin_manager.register(BasicAuthPlugin())

    builtin.__all__.append('BasicAuthPlugin')
    try:
        auth_types = list(_AuthTypeLazyChoices())
        assert 'basic' not in auth_types  # This test would fail without __iter__
        assert 'digest' in auth_types   # This test should pass in normal case
        assert 'bearer' in auth_types
    finally:
        builtin.__all__.pop()
        plugin_manager.unregister(BasicAuthPlugin)
        plugin_manager.register

# Generated at 2022-06-11 23:05:01.933095
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == \
           set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['auto'],
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of a plugin to use for authentication. The default is
    "auto", which will automatically choose the best plugin.

    ''',
)

auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    Disable automatic plugin selection, and force the use of the plugin
    specified by --auth-type. This will avoid rescans for available plugins.

    ''',
)

#######################################################################
# Follow

# Generated at 2022-06-11 23:05:13.471923
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin (e.g., 'ntlm', 'digest').

    '''
)
# Add auth plugin arguments.
for plugin_name in plugin_manager.get_auth_plugin_mapping().values():
    plugin_args = plugin_manager.get_plugin_argspec(plugin_name, 'auth')

# Generated at 2022-06-11 23:05:23.954606
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == auth_plugin_types

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the given auth plugin for authentication. By default, HTTPie will try
    to auto-detect the auth scheme from the provided credentials, if any.
    Available auth schemes: {', '.join(auth_plugin_types)}.

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-11 23:05:34.229472
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    type=str,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies the auth mechanism.

    By default, HTTPie prompts for password if no auth type is
    specified and the password is missing.

    The built-in auth types (can be used with --auth-type) are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    You can specify a custom authentication plugin (e.g., --auth-type=foo)
    which will use a class named `HTTPiePluginFooAuth`
    from the `httpie_foo_auth` module.

    '''
)


# Generated at 2022-06-11 23:05:44.985570
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    possible_auth_choices = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert list(_AuthTypeLazyChoices()) == possible_auth_choices


auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select authentication plugin to use. Run `http --auth-type=help' to list
    the built-in plugins and their options.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:05:58.601817
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie import __version__
    from httpie.cli import StatusCodes
    from httpie.compat import is_win32
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'ntlm'
    ]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a customized authentication plugin name. By default, if --auth
    option is provided, HTTPie will try to guess the plugin name from the
    --auth option username.

    '''
)


# Generated at 2022-06-11 23:06:10.238440
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    assert list(lazy) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth scheme by name. The scheme must be implemented by a
    plugin. See the [docs](https://httpie.org/docs/plugins/auth) for more.

    '''
)
#######################################################################
# Other options
#######################################################################

other_options = parser.add_argument_group(title='Other Options')


# Generated at 2022-06-11 23:06:21.802260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # The constructor is tested implicitly by running
    # ``http --debug --auth-type invalid-auth-type ...``
    names = _AuthTypeLazyChoices()
    assert 'digest' in names
    assert 'basic' in names
    assert 'ntlm' in names
    assert 'plugin-name' not in names
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:06:24.716357
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():  # noqa
    assert sorted(list(_AuthTypeLazyChoices())) == ['basic', 'digest']

# Generated at 2022-06-11 23:06:26.191785
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'base64' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:06:51.314505
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_class_validator = AuthTypeValidator(
    'Authentication plugin must be one of: {0}'.format(
        ', '.join(_AuthTypeLazyChoices())
    )
)


# Generated at 2022-06-11 23:07:05.397971
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert list(choices) == ['basic', 'digest', 'hawk']



# Generated at 2022-06-11 23:07:17.836008
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    help='''
    Explicitly specify a custom auth plugin by name.
    Use `http --debug plugins` to list the available ones.

    ''',
    choices=_AuthTypeLazyChoices(),
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    By default, HTTPie will try to load credentials from the user's netrc file.
    Use this flag to prevent that behavior, and instead require that
    all credentials are supplied via command line arguments, environment
    variables, or HTTPie config files.

    '''
)

################################################################

# Generated at 2022-06-11 23:07:30.059989
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

AUTH_PLUGIN_MAPPING = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=AUTH_PLUGIN_MAPPING,
    help=f'''
    The auth mechanism to be used. If no value is given, the
    most secure mechanism is picked automatically.

    Available types: {', '.join(AUTH_PLUGIN_MAPPING)}

    '''
)

# Generated at 2022-06-11 23:07:37.066701
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Explicitly specify a particular auth plugin to use.

    Available plugins: {auth_plugins}

    '''
)


# Generated at 2022-06-11 23:07:43.170814
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'digest' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-types',
    dest='auth_type',
    action='extend',
    choices=auth_type_choices,
    help='''
    Force the specified authentication types. The default is all available
    auth types.

    '''.strip()
)

# Generated at 2022-06-11 23:07:50.503475
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    assert 'gssnegotiate' in auth_type_lazy_choices
    assert 'fakeauth' not in auth_type_lazy_choices
    assert 'gssnego' not in auth_type_lazy_choices

# Generated at 2022-06-11 23:07:55.942149
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert all(key in auth_plugin_mapping for key in choices)
    assert not ('abc' in auth_plugin_mapping and 'abc' in choices)



# Generated at 2022-06-11 23:08:05.061316
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert set(iter(_AuthTypeLazyChoices())) == set(
        plugin_manager.get_auth_plugin_mapping().keys()
    )
    assert list(iter(_AuthTypeLazyChoices())) == list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'non-existent' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:08:06.905417
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:08:45.408706
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication protocol ({', '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())
    )}).

    The default is '{DEFAULT_AUTH_PLUGIN}'.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not send an initial authentication challenge (e.g., for HTTP
    Basic or Digest authentication) with the first request.

    '''
)

################################################################

# Generated at 2022-06-11 23:08:48.131765
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    l = _AuthTypeLazyChoices()
    assert 'oauth2' in l
    assert 'basic' in l
    assert l.__contains__('oauth1') == False


# Generated at 2022-06-11 23:08:51.496307
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class_instance = _AuthTypeLazyChoices()
    assert 'digest' in class_instance
    assert 'Basic' in class_instance
    assert 'does-not-exist' not in class_instance


# Generated at 2022-06-11 23:09:02.824303
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin. Available plugins: basic.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--ssl',
    dest='verify',
    action=DeprecatedAction,
    help='''
    Deprecated. Use --verify.

    '''
)

# Generated at 2022-06-11 23:09:04.698612
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'multi' in _AuthTypeLazyChoices()
    assert 'nonexisting' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:09:16.040925
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # The base class for this class is argparse._StoreAction;
    # this test ensures that the constructor of it is not called
    # because we don't want to call the choices argument that has
    # side-effects (on plugin loading) when creating the parser
    try:
        _AuthTypeLazyChoices()
    except ValueError as err:
        assert str(err) == 'choices must be a container'
    else:
        assert False, '_AuthTypeLazyChoices constructor failed to raise expected exception'



# Generated at 2022-06-11 23:09:26.358070
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert len(list(auth_type_choices)) > 0


auth.add_argument(
    '--auth-type',
    help='''
    Specify an authentication handler to use. Supported choices:

    {0}

    You can also specify a custom module path, e.g.,

        --auth-type ~/custom-auth.py

    Instead of specifying --auth-type and --auth, you can use a shortcut:

        --auth-type=basic:user:pass

    For security reasons, this has the same effect as:

        --auth='user:pass' --auth-type=basic

    '''.format(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)



# Generated at 2022-06-11 23:09:28.977640
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    A = _AuthTypeLazyChoices()
    assert list(iter(A)) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:09:40.446055
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """ Unit test for constructor of class _AuthTypeLazyChoices """
    auth_types = _AuthTypeLazyChoices()
    for item in auth_types:
        assert item in auth_types
    assert 'Basic' in auth_types
    assert 'Digest' in auth_types

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type to be used.
    The value is a plug-in name. Use 'http --debug' to get a list
    of all built-in plugins.

    ''',
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_

# Generated at 2022-06-11 23:09:49.640443
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert set(['basic', 'digest', 'digest-ie']) \
        < set(auth_type_lazy_choices)


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the authentication mechanism used. This option is only needed when
    the authentication mechanism can not be sniffed from the URL.

    '''
)
auth.add_argument(
    '--auth-type-force',
    default=False,
    action='store_true',
    help='''
    Force the use of the --auth-type even if the authentication mechanism
    can be sniffed from the URL.

    '''
)

# Generated at 2022-06-11 23:10:54.339977
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Bearer' not in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:10:56.651377
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

# Generated at 2022-06-11 23:11:04.878802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type to be used:

    {'|'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add_argument(
    '--auth-protocol',
    default=None,
    metavar='PROTOCOL',
    help='Authorization protocol to be used.',
)

# Generated at 2022-06-11 23:11:07.231345
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:11:10.918639
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:11:21.669110
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Test method _AuthTypeLazyChoices.__iter__()"""
    # _AuthTypeLazyChoices
    assert list(_AuthTypeLazyChoices()) == sorted([])

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    help="""
    Specify a custom authentication plugin.
    See http://httpie.org/plugins#authentication.

    """,
    choices=(_AuthTypeLazyChoices(),),
)


# Generated at 2022-06-11 23:11:23.403929
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:11:34.828553
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # All installed choices for AUTH_TYPES should be in AUTH_PLUGIN_MAP
    assert all(
        choice in AUTH_PLUGINS_MAP
        for choice in plugin_manager.get_auth_plugin_mapping()
    )
    # All AUTH_PLUGIN_MAP keys should appear in the iterator
    assert all(
        key in _AuthTypeLazyChoices()
        for key in plugin_manager.get_auth_plugin_mapping()
    )
    # The iterator is sorted
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping())
