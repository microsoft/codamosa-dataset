

# Generated at 2022-06-11 23:01:42.245999
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(iter(choices)) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used for the request.

    Available types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


auth.add_argument(
    '--auth-endpoint',
    metavar='URL',
    default=None,
    help='''
    URL of the authentication endpoint. Used by authentication plugins.

    '''
)

# Generated at 2022-06-11 23:01:54.359485
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type (plugin), such as "oauth2".
    ''',
)

#######################################################################
# Options common to all output formatter plugins
#######################################################################

options = parser.add_argument_group(title='Options Common to All Output Plugins')


# Generated at 2022-06-11 23:02:04.396333
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin for advanced use cases.

    '''
)

#######################################################################
#  Cookies.
#######################################################################

cookies = parser.add_argument_group(title='Cookies')


# Generated at 2022-06-11 23:02:06.284943
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:02:09.048341
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basic' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:02:18.249870
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == AVAILABLE_AUTH_PLUGINS


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    Available auth mechanisms include:  {available_auth_plugins}

    '''.format(available_auth_plugins=', '.join(AVAILABLE_AUTH_PLUGINS))
)



# Generated at 2022-06-11 23:02:25.224367
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(auth_type)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    The HTTP endpoint used to obtain an authentication token. The endpoint
    must return the token in the body of the response.

    HTTPie will look for the token in the ``$TOKEN`` environment variable
    before issuing a request to the endpoint.

    ''',
)

#######################################################################
# Custom headers
#######################################################################


# Generated at 2022-06-11 23:02:28.618895
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:02:39.367005
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic']


# Generated at 2022-06-11 23:02:52.086207
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert iter(AUTH_TYPES)
#
# Optimization for --help
#
auth_type_kwargs = {
    'choices': _AuthTypeLazyChoices()
}

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    help='''
    Specify an authentication type.
    The default is "basic".

    The following authentication types are supported:

        {auth_types}

    '''.format(auth_types=', '.join(sorted(auth_type_kwargs['choices']))),
    **auth_type_kwargs
)


#######################################################################
# Redirects
#######################################################################


# Generated at 2022-06-11 23:02:58.092505
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:00.241416
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices())[0] == 'aws'


# Generated at 2022-06-11 23:03:02.543382
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:03:04.224572
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ['basic'] == list(_AuthTypeLazyChoices())


# Generated at 2022-06-11 23:03:10.839580
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    plugin_manager.deregister_auth_plugin('digest')
    try:
        assert 'digest' not in _AuthTypeLazyChoices()
    finally:
        plugin_manager.register_auth_plugin('digest')

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin. The value is a path to a Python
    module that is a subclass of the HTTPie authentication plugin interface.

    '''
)

# Generated at 2022-06-11 23:03:19.946795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import builtin as plugin_builtin
    from httpie.plugins import compat as plugin_compat
    from httpie.plugins import user as plugin_user

    with plugin_manager.add_plugin(plugin_builtin), \
            plugin_manager.add_plugin(plugin_compat), \
            plugin_manager.add_plugin(plugin_user):
        assert _AuthTypeLazyChoices() == {'basic', 'digest', 'hawk'}
    assert _AuthTypeLazyChoices() == set()

# Generated at 2022-06-11 23:03:24.462227
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Unit test for method __iter__ of class _AuthTypeLazyChoices
    """
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-11 23:03:27.126227
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'MyCustomAuth' in _AuthTypeLazyChoices()
    assert 'MyMissingAuth' not in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:03:38.422578
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert [
        'Basic',
        'Digest',
        'hawk',
        'oauth1'
    ] == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin (by name), e.g. "Digest", "Basic",
    "oauth1", or "hawk".

    The value "auto" enables auto-detection based on the HTTP response
    (default).

    '''
)

# Generated at 2022-06-11 23:03:50.010839
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
auth_plugins_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_plugins_choices,
    default='auto',
    help=f'''
    Specify the authentication mechanism, can be one of:

        {', '.join(sorted(auth_plugins_choices))}

    If "auto", then the type is guessed based on the provided credentials.

    '''
)

# Generated at 2022-06-11 23:04:00.316808
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    assert AUTH_PLUGIN_NAME in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:03.557740
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert len(list(auth_types)) == 1


# Generated at 2022-06-11 23:04:12.766271
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import collections.abc
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Name of the plugin to use for sending the credentials.
    Plugins are discovered by entry point (see "http --help plugins").
    The default plugin uses the HTTP Basic auth scheme.

    ''',
)


# Generated at 2022-06-11 23:04:18.097562
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices
    assert 'basic' in auth_type_lazy_choices
    assert 'non-existing' not in auth_type_lazy_choices

# Generated at 2022-06-11 23:04:27.519038
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is basic, which is completely insecure.
    Using digest is a little better as passwords are not sent in cleartext.

    The other supported methods are:
    ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    The HTTP URL of the authentication endpoint.
    '''
)

auth

# Generated at 2022-06-11 23:04:31.665298
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'krb_digest' in choic

# Generated at 2022-06-11 23:04:42.883922
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'aws',
        'digest',
        'netrc',
        'oauth1',
        'oauth2',
        'wincred',
    ]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Specify an auth plugin. To see all available auth plugins, run:

        http --debug

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-11 23:04:54.943802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from pprint import pprint
    pprint(sorted(list(AuthTypeLazyChoices())))

# ``requests.request`` keyword argument.
basic_auth = parser.add_argument_group(title='Basic Authentication')

# Generated at 2022-06-11 23:04:59.723475
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == [
        'basic',
        'digest',
        'hawk',
        'jwt',
        'oauth1',
        'ntlm'
    ]

# Generated at 2022-06-11 23:05:11.549527
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == tuple(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth_type_choices = _AuthTypeLazyChoices()
auth_type_choices_str = 'One of: ' + ', '.join(auth_type_choices)
auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help=f'''
    Choose an authentication plugin. Different plugins expose different
    authentication mechanism to HTTPie. {auth_type_choices_str}.
    ''',
)

# Generated at 2022-06-11 23:05:26.654765
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:29.624247
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_plugin_type = auth.add_mutually_exclusive_group(required=False)



# Generated at 2022-06-11 23:05:32.059217
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'Digest' in lazy_choices
    assert 'unknown-auth' not in lazy_choices


# Generated at 2022-06-11 23:05:43.965533
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    return _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Defaults to 'basic' for plain HTTP, or 'digest' for HTTPS.

    '''
)
auth.add_argument(
    '--auth-verify',
    default='yes',
    type=_yes_no,
    help='''
    Verify the server certificate with HTTPS requests.

    Defaults to 'yes'.

    '''
)


#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-11 23:05:49.367856
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'invalid' not in auth_type

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    For supported types, see "--help-auth-types".

    ''',
)

auth.add_argument(
    '--auth-type-help',
    metavar='TYPE',
    help='''
    Show help and available options for an auth type.

    ''',
)

auth.add_argument(
    '--auth-help',
    action='store_true',
    help='''
    Show help and available options for all auth types.

    ''',
)



# Generated at 2022-06-11 23:06:00.805591
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    assert set(iter(_AuthTypeLazyChoices())) == set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-11 23:06:02.788189
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:12.531929
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert len(list(choices)) == len(choices)

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    help='''
    Specify an authentication type to be used. This can be one of the
    core types, or a plugin name. Core types are:
        'basic'      HTTP Basic Authentication (default)
        'digest'     HTTP Digest Authentication
        'hawk'       Secure HTTP authenticated by Hawk
        'ntlm'       NTLM Authentication
        'aws4-hmac'  AWS4-HMAC-SHA256

    '''
)


# Generated at 2022-06-11 23:06:14.936748
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:06:24.961410
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    type=AuthCredentials.validate_auth_type,
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If the mechanism is not specified,
    the "basic" mechanism is used. The supported authentication mechanisms
    are:

        {auth_plugins}

    '''.format(auth_plugins=', '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-11 23:07:06.014247
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    expected_auth_types = list(_AuthTypeLazyChoices())
    assert 'basic' in expected_auth_types
    assert 'digest' in expected_auth_types
    assert 'awsv4' in expected_auth_types
    assert len(expected_auth_types) == 3

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Default is "auto", which means
    HTTPie tries to guess the authentication type by looking at the 'WWW-
    Authenticate' response header.

    '''
)


# Generated at 2022-06-11 23:07:18.026961
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert len(list(_AuthTypeLazyChoices())) > 0


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication mechanism.

    ''',
)

auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    Use URL as the host when authenticating with a proxy.

    ''',
)


# Generated at 2022-06-11 23:07:23.539787
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basic' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an Authorization mode (Basic by default).

    '''
)
auth.add_argument(
    '--digest',
    action='store_const',
    const='digest',
    dest='auth_type',
    help='''
    Use HTTP Digest Authentication. Shortcut for --auth-type=digest.

    '''
)

# Generated at 2022-06-11 23:07:33.956176
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    choices_iterator = iter(choices)
    assert next(choices_iterator) == 'basic'
    assert next(choices_iterator) == 'digest'

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication mechanism. The default is "basic".

    '''
)

# Generated at 2022-06-11 23:07:38.163241
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'bearer' in choices
    assert 'Basic' in choices

    assert 'doesnotexist' not in choices


# Generated at 2022-06-11 23:07:46.013755
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Currently supported:

    ''' + '\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)
auth.add_argument(
    '--auth-type-info',
    action='store_true',
    help='''
    Show the help and options for an authentication type. Requires --auth-type.
    Example: http --auth-type-info kerberos

    '''
)

# Generated at 2022-06-11 23:07:48.326826
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    instance = _AuthTypeLazyChoices()
    for value in instance:
        pass

# Generated at 2022-06-11 23:07:50.314999
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'Digest' in lazy_choices

# Generated at 2022-06-11 23:07:54.490431
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'fake' not in lazy_choices


# Generated at 2022-06-11 23:08:04.197283
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices).sort() == sorted(plugin_manager.get_auth_plugin_mapping())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    With --auth, use a custom authentication plugin. Defaults to the
    plugin guessed from --auth if present else the "basic" plugin.

    ''',
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Ignore the ~/.netrc file.

    '''
)

#######################################################################
# HTTP method and headers
#######################################################################

method = parser.add_

# Generated at 2022-06-11 23:09:06.364039
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. By default, the client will
    attempt to determine the most secure mechanism supported by the server.
    Otherwise, one of the following can be specified: basic|digest|bearer|auto

    '''
)


#######################################################################
# HTTP method
#######################################################################
method = parser.add_argument_group(title='HTTP method')


# Generated at 2022-06-11 23:09:09.212599
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-11 23:09:11.213702
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    klass = _AuthTypeLazyChoices
    assert list(klass()) == list(klass)

# Generated at 2022-06-11 23:09:18.021902
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=auth_type_choices,
    help=f'''
    The authentication mechanism to be used. Supported mechanisms:

        {', '.join(auth_type_choices)}
    '''
)



# Generated at 2022-06-11 23:09:22.728507
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    from httpie.plugins.builtin import AuthPlugin
    class Plugin(AuthPlugin):
        name = 'plugin'
    plugin_manager.register(Plugin)
    assert list(_AuthTypeLazyChoices()) == ['plugin']
    plugin_manager.unregister(Plugin)

# Generated at 2022-06-11 23:09:29.878063
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'dummy' not in choices
    plugin_manager.get_auth_plugin_mapping()['dummy'] = object()
    assert 'dummy' in choices

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The method that should be used for authentication. The default is "auto",
    which will attempt to auto detect the auth plugin.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not attempt to authenticate if the server challenges with 401,
    instead just error.
    '''
)
#######################################################################
# Timeouts
####################################################################

# Generated at 2022-06-11 23:09:41.650423
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'fake_plugin' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-A',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    By default, HTTPie will first try the "basic" auth type.
    If the server responds with a 401 status code, it will
    then try the "digest" auth type.

    ''',
)


# Generated at 2022-06-11 23:09:47.997805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    aa = _AuthTypeLazyChoices()
    a = list(aa)
    assert isinstance(a,list)


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    To view the available plugins, run:

        $ http --debug

    See also: https://httpie.org/docs#authentication

    '''
)


# Generated at 2022-06-11 23:09:55.212709
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    # --auth-plugin-help will create a new
    # plugin_manager but plugin 'basic' is built-in
    assert 'basic' in iter(auth_type_lazy_choices)


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. Default is "basic", but you can use
    "digest" or any third-party authentication plugin.

    ''',
)

# Generated at 2022-06-11 23:10:07.312923
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []


_auth_type_lazy_choices = _AuthTypeLazyChoices()
