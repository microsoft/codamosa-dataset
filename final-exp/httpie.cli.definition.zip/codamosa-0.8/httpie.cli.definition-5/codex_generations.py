

# Generated at 2022-06-11 23:01:38.890690
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'auto' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=AuthCredentials.DEFAULT_AUTH_TYPE,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''\
    The authentication mechanism to be used.
    There are several built-in mechanisms:

        'auto', 'basic', 'digest'

    Plugins can implement additional types.

    '''
)


# Generated at 2022-06-11 23:01:44.194461
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted([
        'basic',
        'digest',
        'hawk',
        'multipass',
        'netrc',
        'oauth1',
        'oauth2',
        'aws4-hmac-sha256',
    ]) == list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:01:48.047870
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    plugin_manager.load_plugins()
    assert 'digest' in obj
test__AuthTypeLazyChoices___contains__()


# Generated at 2022-06-11 23:01:51.655898
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()



# Generated at 2022-06-11 23:02:01.991558
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    # A plugin name.
    assert HTTPBasicAuthPlugin.auth_type in _AuthTypeLazyChoices()

#
# Mutually exclusive, ``requests.request`` keyword arguments.
#
_digest_mutex_kwargs = {
    'action': 'store_const',
    'const': 'digest',
    'dest': 'auth'
}
_ntlm_mutex_kwargs = {
    'action': 'store_const',
    'const': 'ntlm',
    'dest': 'auth'
}



# Generated at 2022-06-11 23:02:14.853778
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication scheme to use.

    '''
)

# Generated at 2022-06-11 23:02:25.690431
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    help=(
        'The AUTH_TYPE for authentication.'
        ' Only relevant when using --auth.'
        f' Valid choices are: {_AuthTypeLazyChoices()}.'),
    choices=_AuthTypeLazyChoices(),
    default='auto',
)

auth.add_argument(
    '--auth-verify',
    action='store_true',
    help='''
    Verify server certificate when using HTTPS.

    '''
)


# Generated at 2022-06-11 23:02:37.344563
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    The auth type to use.

    Only "basic" is supported natively. For other types, you need to
    install the corresponding plugin module.

    Use `{program} --debug plugins` to see a list of available plugins.

    '''.format(program=parser.prog)
)
auth.add_argument(
    '--hash-password',
    default=False,
    # This is an output argument so we don't want to echo it.
    action='store_true',
    help=SUPPRESS,
)

# Generated at 2022-06-11 23:02:48.625996
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The mechanism for sending the credentials

    When no plugin provides for a specific scheme, HTTPie will prompt for the
    credentials.

    Available plugins:

    {plugins}

    '''.format(
        plugins=plugin_manager.get_plugin_help('auth'),
        plugin=PLUGIN_NAME,
    )
)
auth.add_argument(
    '--auth-nonce',
    action='store_true',
    help='''
    Force the authentication to use a fresh nonce. Only relevant for
    auth-type=basic.
    '''
)

#######################################################################
# Plugins
#######################################################################

plugins = parser

# Generated at 2022-06-11 23:02:52.428945
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    is_contained = 'Digest' in _AuthTypeLazyChoices()
    is_contained = is_contained and 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:06.576806
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to use. If not specified, it will be guessed
    based on the provided credentials. The following are currently supported:

    ''' + ', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ) + '''

    '''
)

# Generated at 2022-06-11 23:03:08.801913
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:14.843546
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # type: () -> None
    from tests.constants import TEST_PLUGINS_DIR
    from httpie.plugins import plugin_manager
    plugin_manager.load_directory(TEST_PLUGINS_DIR)
    auth_types = _AuthTypeLazyChoices()
    assert [item for item in auth_types] == ['custom', 'test']



# Generated at 2022-06-11 23:03:22.450824
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class TestAuth:
        usage = 'Test {help} usage'
        help = 'Test help'

    class TestAuth1(TestAuth):
        help = 'Test help 1'

    class TestAuth2(TestAuth):
        help = 'Test help 2'

    backup_plugins = plugin_manager.get_auth_plugin_mapping()
    plugin_manager.auth_plugins = {
        'test': TestAuth,
        'test1': TestAuth1,
        'test2': TestAuth2
    }
    choices = _AuthTypeLazyChoices()
    assert 'test' in choices
    assert 'test1' in choices
    assert 'test2' in choices
    assert not ('test0' in choices)
    assert 'test1' in choices
    assert 'test2' in choices

# Generated at 2022-06-11 23:03:23.365321
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['foo', 'bar'] == list(_AuthTypeLazyChoices())

# Generated at 2022-06-11 23:03:35.328976
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'auto' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'plugin-name' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:03:42.987054
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Mock plugin manager with a single mocked plugin
    mock_plugin_manager = mock.MagicMock()
    plugin_manager_instance = mock_plugin_manager.return_value
    plugin_manager_instance.get_auth_plugin_mapping.return_value={
        'foo': mock.MagicMock()
    }
    with mock.patch('httpie.cli.plugins.plugin_manager', mock_plugin_manager):
        auth_type_lazy_choices = _AuthTypeLazyChoices()
        assert [item for item in auth_type_lazy_choices] == ['foo']



# Generated at 2022-06-11 23:03:51.385576
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(list(_AuthTypeLazyChoices())) > 0

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to use (if --auth is set).

    If the AUTH_TYPE is not provided, HTTPie tries to guess it
    based on the --auth option value. Supported AUTH_TYPEs are:

        {supported}

    Note that not all AUTH_TYPEs may be supported by the server.

    '''.format(
        supported=' '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

#######################################################################
# Verbosity / Debugging
#######################################################################



# Generated at 2022-06-11 23:04:05.157372
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    try:
        assert 'basic' in auth_type
    except:
        raise Exception('Unit test for method __contains__ of class _AuthTypeLazyChoices failed')

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    Use `http --debug` to print a list of all available auth plugins.

    '''
)


# Generated at 2022-06-11 23:04:14.446016
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    actual = 'digest' in _AuthTypeLazyChoices()
    assert actual == True


auth.add_argument(
    '--auth-type', '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='NAME',
    default=None,
    help=f'''
    The auth mechanism to be used.

    Supported: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}.
    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Disable automatic authentication challenge handling. This is useful when
    you want to authenticate with a server that does not send HTTP 401 Not
    Authorized for authentication failures.

    '''
)
auth

# Generated at 2022-06-11 23:04:23.376122
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:04:32.412315
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Supported: "basic", "digest",
    "digest-ie", "hawk".

    ''',
)
auth.add_argument(
    '--auth-nonce',
    help='''
    Override the nonce used in Digest authentication.

    '''
)
auth.add_argument(
    '--auth-opaque',
    help='''
    Override the opaque used in Digest authentication.

    '''
)

# Generated at 2022-06-11 23:04:36.312323
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    list(map(choices.__contains__, auth_plugin_mapping.keys()))


# Generated at 2022-06-11 23:04:37.695163
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))

# Generated at 2022-06-11 23:04:45.333156
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    '''Test for _AuthTypeLazyChoices'''
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'foo' in iter(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.  Can be any of:
    basic, digest, htpasswd, or a plugin name.

    '''
)



# Generated at 2022-06-11 23:04:56.800617
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')


# Generated at 2022-06-11 23:05:03.338830
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'aws-sigv4'
    ]


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Specify the auth mechanism.

    Default: basic.

    '''
)



# Generated at 2022-06-11 23:05:13.691478
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    auth_type_choices = _AuthTypeLazyChoices()

    assert iter(auth_type_choices)

    assert list(auth_type_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help='Override the Authorization scheme.'
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='The host to provide the credentials for (defaults to the host of '
         'the requested URL).'
)
auth.add_argument(
    '--auth-plugin',
    help=argparse.SUPPRESS,
) 

# Generated at 2022-06-11 23:05:24.136908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    >>> _AuthTypeLazyChoices()
    ['basic', 'digest', 'hawk']
    """
    pass

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the type of authentication. If no type is specified,
    HTTPie will try to guess; this might not work for non-Basic/Digest
    schemes.

    The following authentication types are supported and are provided
    by plugins. Run `$ http --debug in order to see the list of
    enabled plugins and their configuration.

    {auth_types_help}

    '''.format(auth_types_help=plugin_manager.get_auth_plugin_help()),
)

# Generated at 2022-06-11 23:05:25.820949
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:05:43.771146
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()
    # The next line fails in unit test. 'custom' is present.
    #assert 'custom' not in _AuthTypeLazyChoices()


# Generated at 2022-06-11 23:05:47.050094
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'gssnegotiate' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:06:00.027286
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())



# Generated at 2022-06-11 23:06:11.471517
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices() == sorted(plugin_manager.get_auth_plugin_mapping().keys())
test__AuthTypeLazyChoices___iter__()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the auth mechanism for requests. Supported: netrc, basic, digest, aws.

    '''
)

auth.add_argument(
    '--auth-netrc',
    action='store_true',
    help='''
    Use the .netrc file.
    Deprecated by --auth-type=netrc.

    '''
)

# Generated at 2022-06-11 23:06:22.987234
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert str(AUTH_PLUGIN_HELP) in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group(required=False)

auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help=AUTH_PLUGIN_HELP
)
auth_type.add_argument(
    '--digest-auth', '--digest',
    action='store_const',
    const='digest',
    dest='auth_type',
    help='''
    Shortcut for --auth-type=digest.

    '''
)

# Generated at 2022-06-11 23:06:35.507423
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_validator = AuthPluginValidator()

auth.add_argument(
    '--auth-type', '--auth-type',
    type=auth_type_validator,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Select the method used for authentication:

    {auth_plugin_list}

    If the AUTH_TYPE argument is omitted, HTTPie looks for
    a plugin matching the AUTH value.

    ''',
)

# Generated at 2022-06-11 23:06:40.745944
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Note that this test should be executed only after plugin discovery
    from httpie.core import main
    import os
    import tempfile
    plugin_filename = os.path.join(tempfile.gettempdir(), 'test-plugin')

# Generated at 2022-06-11 23:06:51.591403
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication implementation.
    Accepted values depend on the installed plugins.

    ''',
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    Specify the API endpoint that provides the authentication
    credentials.

    '''
)

# Generated at 2022-06-11 23:06:53.732404
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:07:06.805175
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_validator = AuthTypeValidator(
    '%s is not a valid authentication type. '
    'Available authentication types: %s' % (
        '{0}',
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

auth.add_argument(

    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    type=auth_type_validator,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    If no auth-type is provided, basic is assumed.

    ''',
)

# Generated at 2022-06-11 23:07:38.870720
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    actual = list(map(str, choices))
    assert actual == sorted(plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-11 23:07:40.973014
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.load_builtin_plugins()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(list(_AuthTypeLazyChoices()))



# Generated at 2022-06-11 23:07:48.215250
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert (list(_AuthTypeLazyChoices()) ==
           sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin.
    If not provided, then the authentication plugin is guessed from
    the available authentication data (--auth, --auth-type, and --auth-plugin).
    '''
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    Load an authentication plugin.
    Plugins are resolved in the following order: --auth-plugin > --auth-type.
    '''
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-11 23:08:00.030590
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test for method __iter__ of class _AuthTypeLazyChoices
    """
    assert 'HawkAuth' in _AuthTypeLazyChoices()
    assert 'BearerToken' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''Specify a custom auth plugin by the import path to its class.'''
)
auth.add_argument(
    '--auth-endpoint',
    metavar='URL',
    default=None,
    help='Authentication provider endpoint URI.'
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-11 23:08:10.623139
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help='''
    By default, HTTPie uses HTTP Basic Authentication, which works for most
    services.

    To use a different authentication plugin, specify its name as the value of
    this option. For example, the ``my-plugin`` plugin is specified as:

        --auth-type=my-plugin

    To see the list of available authentication plugins, run:

        $ http --debug --help

    '''
)

# TODO: sort by name
auth_plugin_arg_groups = plugin_manager.load_auth_plugins_options(parser)

#######################################################################
# Extensions.
####################################################################

# Generated at 2022-06-11 23:08:17.837599
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'netrc' in choices
    assert isinstance(choices, list)


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is 'basic'.

    ''',
)



# Generated at 2022-06-11 23:08:27.436407
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin by name. By default, HTTPie will detect the
    auth plugin based on the hostname.

    ''',
)


#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-11 23:08:38.431393
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    # len(choices) not implemented
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hmac' in choices
    assert 'foo' not in choices

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Force the authentication mechanism (Basic, Digest, or a custom HTTPie
    plugin).

    {AUTH_PLUGIN_DESC}

    '''
)

#######################################################################


# Generated at 2022-06-11 23:08:47.441440
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin. Run {0} for a list of the
    available plugins.

    '''.format(_get_path(argv0, '--plugins'))
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Whether or not to assume the server supports Basic/Digest
    authentication and will challenge.

    When this option is disabled and no password is provided
    (just -a username), HTTPie will prompt for the password.

    '''
)

####################################################################

# Generated at 2022-06-11 23:09:00.018121
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('Basic', 'Digest') in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Auth type to use for the provided credentials (e.g. "basic", "digest").
    If not provided and credentials are present, the auth type will be
    guessed.

    You can install plugins that provide more auth types.
    Available auth types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

#######################################################################
# SSL/TLS
#######################################################################
ssl = parser.add_argument_group(title='SSL/TLS') \
    .add_mutually

# Generated at 2022-06-11 23:10:08.297425
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), list)


# Generated at 2022-06-11 23:10:11.997973
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [plugin_name for plugin_name in _AuthTypeLazyChoices()] == [
        'basic',
        'digest',
        'hawk',
        'hmac',
        'jwt',
        'oauth1a',
        'oauth2',
        'selenium',
    ]


# Generated at 2022-06-11 23:10:13.734863
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert isinstance(_AuthTypeLazyChoices, _AuthTypeLazyChoices) is True

# Generated at 2022-06-11 23:10:23.211893
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert next(_AuthTypeLazyChoices()) == 'asan'

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin.

    Example:

        $ http --auth-type=awesome-auth --auth=user:pass https://example.org

    Available plugins:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The auth plugin must be importable, e.g.:

        $ http --auth-type=awesome-auth \
            --auth-plugin=httpie_awesome_auth \
            --auth=user:pass https://example.org

    '''
)

# Generated at 2022-06-11 23:10:25.037632
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-11 23:10:35.862475
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for auth_type in _AuthTypeLazyChoices():
        assert auth_type in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. The default is "auto" which means that
    HTTPie will guess and use the appropriate auth mechanism.

    You can also explicitly set the auth mechanism by using one of the
    following values:

        {0}

    (The set of auth types may further be extended by third party plugins.)

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_

# Generated at 2022-06-11 23:10:43.715755
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    # ``--auth-type`` is defined in the API, so no double hyphen allowed.
    dest='auth_plugin',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism to be used for the given session.
    By default, HTTPie will try to detect the authentication method.

    The available types are: {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    For more information, including usage examples, run:

        http --help-auth <auth-type>

    '''
)

# Generated at 2022-06-11 23:10:49.969560
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert set(auth_types) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Default: basic
    The auth mechanism to be used.
    ''',
)

# Generated at 2022-06-11 23:11:01.952581
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism.
    This option is useful when the server uses NTLM or Digest auth,
    which are only explicitly supported by HTTPie.

    ''',
)

# Generated at 2022-06-11 23:11:13.690347
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for i in _AuthTypeLazyChoices():
        pass
