

# Generated at 2022-06-17 19:52:03.238747
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:52:04.722923
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:52:14.604421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 19:52:16.153630
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:20.376710
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:31.621975
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform challenge response (i.e., do not send 401/407 responses).

    '''
)
auth.add_argument(
    '--auth-timeout',
    type=float,
    default=None,
    help='''
    Timeout in seconds to wait for a response from the server that requires
    authentication.

    '''
)



# Generated at 2022-06-17 19:52:34.944597
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:44.872895
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto" which means that HTTPie will first try to use
    the "digest" auth type and if that fails, it will fall back to "basic".

    ''',
)

# Generated at 2022-06-17 19:52:54.807954
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:53:05.504587
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no
    authentication is used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)
ssl.add_argument

# Generated at 2022-06-17 19:53:11.776957
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:53:18.303333
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 19:53:21.424809
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:53:30.457296
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no
    authentication is used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify SSL certificates.

    '''
)

# Generated at 2022-06-17 19:53:38.881098
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-type-force-interactive',
    action='store_true',
    default=False,
    help='''
    Force interactive authentication even if the auth plugin supports
    non-interactive authentication.

    ''',
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')
cookies.add

# Generated at 2022-06-17 19:53:48.872758
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no
    authentication is used.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)

# Generated at 2022-06-17 19:53:56.452252
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server's SSL certificate. This is enabled by default.

    '''
)

# Generated at 2022-06-17 19:54:02.815201
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-signature' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-body' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-headers' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:54:14.460769
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-17 19:54:16.384987
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:54:35.350434
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    By default, the appropriate one is guessed based on the provided credentials.

    ''',
)

# Generated at 2022-06-17 19:54:45.417885
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    The default is "auto" which means that HTTPie will try to determine the
    authentication type by inspecting the server's response.

    ''',
)


# Generated at 2022-06-17 19:54:54.707946
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform authentication challenge (HTTP 401 handling).

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:55:04.131420
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Currently supported: {0}.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


# Generated at 2022-06-17 19:55:05.488599
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:55:15.128184
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Disable sending the initial authentication challenge.
    This is useful when the server does not respond correctly to the
    challenge, but the authentication credentials are still accepted.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:55:24.968059
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to guess the auth type based on the provided
    credentials.

    The following auth types are available:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

#######################################################################
# SSL
####################################################################

# Generated at 2022-06-17 19:55:26.307251
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:55:37.891977
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    ''',
)

# Generated at 2022-06-17 19:55:45.607986
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the authentication type by looking at the HTTP response.
    This should work in most cases.

    If the server responds with a 401 status code, HTTPie will
    present a list of supported authentication types to choose from.

    ''',
)

# Generated at 2022-06-17 19:56:12.954960
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform authentication challenge (HTTP 401 handling).

    '''
)

# Generated at 2022-06-17 19:56:24.431111
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload-unsigned-headers' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:29.290232
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:56:39.831314
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to guess the authentication type by looking at the
    provided credentials.

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host to use for authentication.

    By default, the host part of the URL is used.

    ''',
)

# Generated at 2022-06-17 19:56:49.052770
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'basic' in list(_AuthTypeLazyChoices())
    assert 'digest' in list(_AuthTypeLazyChoices())
    assert 'foo' not in list(_AuthTypeLazyChoices())


# Generated at 2022-06-17 19:56:59.176142
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'basic' in list(_AuthTypeLazyChoices())
    assert 'digest' in list(_AuthTypeLazyChoices())
    assert 'foo' not in list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to detect the auth type by looking at the
    HTTP response.

    '''
)

# Generated at 2022-06-17 19:57:06.385573
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to guess the authentication type by looking at
    the provided credentials.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial challenge response to the server.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-17 19:57:17.854863
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to detect the authentication type by the
    --auth option value.

    ''',
)

auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    Force the specified --auth-type.

    By default, HTTPie tries to detect the authentication type by the
    --auth option value.

    ''',
)

#######################################################################
# SSL
#######################################################################



# Generated at 2022-06-17 19:57:24.728123
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')
method.add_argument(
    '--method', '-m',
    default=DEFAULT_METHOD,
    metavar='METHOD',
    help='''
    The HTTP method to be used for the request (default is "{default}").

    '''.format(default=DEFAULT_METHOD)
)

#######################################################################
# HTTP headers
################################

# Generated at 2022-06-17 19:57:27.378825
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:58:07.635875
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'ntlm' in choices
    assert 'aws4-hmac-sha256' in choices
    assert 'aws4-hmac-sha256-signed-body' in choices
    assert 'aws4-hmac-sha256-unsigned-payload' in choices
    assert 'aws4-hmac-sha256-unsigned-headers' in choices
    assert 'aws4-hmac-sha256-unsigned-body' in choices
    assert 'aws4-hmac-sha256-unsigned-all' in choices
    assert 'aws4-hmac-sha256-unsigned-all-no-body' in choices

# Generated at 2022-06-17 19:58:18.377109
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    ''',
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    The authentication endpoint URL.

    The default is to use the same URL as the request being authenticated.

    ''',
)

#######################################################################
# SSL
################################

# Generated at 2022-06-17 19:58:30.241050
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    The authentication plugin to be used.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use the netrc file to attempt to login.

    '''
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-17 19:58:39.563361
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic".

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify SSL certificates.

    '''
)

# Generated at 2022-06-17 19:58:52.331496
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-17 19:58:56.744157
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:59:04.278108
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Disable sending the initial authentication challenge.

    This is useful when the server does not support
    authentication or when the authentication credentials are provided
    in the URL.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group

# Generated at 2022-06-17 19:59:13.925695
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect the mechanism based on the provided credentials.

    The following mechanisms are supported:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)



# Generated at 2022-06-17 19:59:15.394872
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:59:21.436734
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to use for authentication.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 20:00:47.245937
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial authentication challenge.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 20:00:51.866372
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:01:02.878464
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 20:01:04.402298
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:01:09.882565
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to determine the
    auth type automatically.

    ''',
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')

# Generated at 2022-06-17 20:01:19.569577
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial challenge in case of Digest authentication.

    ''',
)
auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=False,
    help='''
    Verify the server certificate when using HTTPS.

    ''',
)

# Generated at 2022-06-17 20:01:21.293462
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 20:01:30.660141
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 20:01:38.661994
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Disable HTTP authentication challenge (for basic and digest auth).

    '''
)

# Generated at 2022-06-17 20:01:49.151337
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The following mechanisms are available:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')