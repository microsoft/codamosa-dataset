

# Generated at 2022-06-17 19:51:51.514669
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:51:58.878868
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    By default, SSL certificates are verified. Use --no-verify to skip
    verification.

    '''
)

# Generated at 2022-06-17 19:52:09.484258
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect the authentication type based on the
    provided credentials.

    '''
)

# Generated at 2022-06-17 19:52:19.641991
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-unsigned-payload' in _AuthTypeL

# Generated at 2022-06-17 19:52:23.124905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:52:33.059400
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)

# Generated at 2022-06-17 19:52:34.550946
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:52:44.663203
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)

# Generated at 2022-06-17 19:52:54.672249
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    The HTTP endpoint to use for authentication.
    This is useful for APIs that use a different endpoint for authentication
    than the main API.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-17 19:53:05.473443
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-unsigned-payload' in _AuthTypeL

# Generated at 2022-06-17 19:53:10.350419
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:53:11.417243
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:53:19.383904
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will first try to use
    the "digest" auth type, and if that fails, it will fall back to "basic".

    ''',
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host to use for authentication.

    This is useful when the host for the request is different than the host
    used for authentication.

    '''
)

# Generated at 2022-06-17 19:53:29.281170
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "auto", which
    means that HTTPie will try to auto-detect the authentication type by
    inspecting the HTTP response.

    ''',
)

# Generated at 2022-06-17 19:53:39.207089
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify SSL certificates.

    '''
)

# Generated at 2022-06-17 19:53:42.745297
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:53:44.273483
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:53:52.729116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-signature' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-body' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-headers' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:54:00.371276
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise None.

    The following authentication types are supported:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

#######################################################################
# SSL
#######################################################################

ssl

# Generated at 2022-06-17 19:54:01.504354
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:54:19.062238
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is used, otherwise empty.

    ''',
)


# Generated at 2022-06-17 19:54:30.712686
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "auto", which
    means that HTTPie will try to guess the most suitable mechanism.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Disable HTTP authentication challenge (Basic and Digest).

    '''
)

# Generated at 2022-06-17 19:54:41.875568
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:54:51.879671
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic".

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Prevent HTTPie from sending an initial request to authenticate.

    This is useful when the server does not support the "Authentication
    Challenge" mechanism, but it does support the "Authentication Response"
    mechanism.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument

# Generated at 2022-06-17 19:55:00.683752
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-body' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-body' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-all' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:55:11.653894
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']


# Generated at 2022-06-17 19:55:20.025132
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 19:55:28.463556
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to use for authentication.

    ''',
)
auth.add_argument(
    '--auth-timeout',
    default=None,
    metavar='SECONDS',
    type=float,
    help='''
    The timeout in seconds to use for authentication.

    ''',
)

#######################################################################

# Generated at 2022-06-17 19:55:40.573585
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that the authentication mechanism is
    chosen based on the provided credentials.

    If the credentials contain a colon (":"), then "basic" is assumed.
    Otherwise, "digest" is assumed.

    '''
)

# Generated at 2022-06-17 19:55:45.430950
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:05.442927
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:56:09.303792
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:13.880396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'oauth1', 'hawk']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-type-force-http-basic',
    action='store_true',
    default=False,
    help='''
    Force HTTP Basic authentication even when the server supports other
    authentication mechanisms.

    ''',
)

# Generated at 2022-06-17 19:56:24.832437
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4' in _AuthTypeLazyChoices()
    assert 'aws4_test' in _AuthTypeLazyChoices()
    assert 'aws_sigv4' in _AuthTypeLazyChoices()
    assert 'aws_sigv4_test' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'jwt_auth' in _

# Generated at 2022-06-17 19:56:28.039933
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:38.804223
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no
    authentication is used.

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to use for authentication.

    The default is the host of the request URL.

    ''',
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-17 19:56:40.134265
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:43.442380
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:49.070905
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    By default, SSL certificates are verified.
    Use --no-verify to skip verification.

    '''
)

# Generated at 2022-06-17 19:56:54.294821
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-signature' in _AuthTypeLazyChoices()
    assert 'aws4-sigv4' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-hmac-sha256' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:57:32.684011
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the auth type by looking at the HTTP response.

    ''',
)

# Generated at 2022-06-17 19:57:34.033267
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:57:43.065323
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    The default authentication plugin is "basic".

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify', '-k',
    default=True,
    action='store_true',
    help='''
    (default) Verify SSL certificates.

    '''
)

# Generated at 2022-06-17 19:57:51.589014
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:58:02.781156
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    If not specified, HTTPie tries to guess it based on the --auth option.

    The following mechanisms are supported:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)


# Generated at 2022-06-17 19:58:14.741502
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    By default, HTTPie tries to detect the auth type by looking at the
    HTTP response.

    '''
)

# Generated at 2022-06-17 19:58:16.800959
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:58:18.238869
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:58:30.172335
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to detect the authentication mechanism based on the
    provided credentials.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)

# Generated at 2022-06-17 19:58:32.976578
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:59:39.180801
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'unknown' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:59:50.676316
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-type-force-http-basic',
    action='store_true',
    default=False,
    help='''
    Force HTTP Basic authentication even when the server responds with a 401
    status code and WWW-Authenticate header that indicates a different
    authentication mechanism.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:59:58.408276
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform challenge response (i.e., do not send 401/407
    responses needed to negotiate credentials).

    '''
)

auth.add_argument(
    '--auth-jwt',
    metavar='JWT',
    help='''
    Send a JSON Web Token (JWT) in the Authorization header.

    '''
)

# Generated at 2022-06-17 20:00:09.197281
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no
    authentication is used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 20:00:12.950318
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:00:19.740487
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the authentication type by looking at the HTTP response.

    ''',
)
auth.add_argument(
    '--auth-type-force',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the authentication mechanism to be used.

    This is useful when the server does not return a 401 status code
    when it requires authentication.

    ''',
)

#######################################################################

# Generated at 2022-06-17 20:00:27.343574
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-send',
    default='auto',
    choices=['auto', 'always', 'never'],
    help='''
    When to send the authentication credentials.

    '''
)

# Generated at 2022-06-17 20:00:30.764470
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:00:37.786595
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The following mechanisms are supported:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

auth

# Generated at 2022-06-17 20:00:49.392794
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)
auth.add_argument(
    '--auth-type-force-http-basic',
    action='store_true',
    default=False,
    help='''
    Force HTTP Basic authentication even if the server doesn't advertise
    support for it.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')