

# Generated at 2022-06-17 19:52:03.087522
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 19:52:06.616197
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:15.706537
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'plugin' in _AuthTypeLazyChoices()
    assert 'plugin-with-options' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-plugin',
    metavar='PLUGIN_NAME',
    help='''
    The name of the plugin to be used for authentication.

    '''
)

#######################################################################
# SSL
####################################################################

# Generated at 2022-06-17 19:52:19.054846
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:29.607492
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-17 19:52:39.982527
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic", which is the only one that works without plugins.

    Plugins can be used to enable other mechanisms. For example, the "digest"
    plugin enables Digest auth.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:52:50.977939
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'custom-plugin' in _AuthTypeLazyChoices()
    assert 'custom-plugin-with-args' in _AuthTypeLazyChoices()
    assert 'custom-plugin-with-kwargs' in _AuthTypeLazyChoices()
    assert 'custom-plugin-with-args-and-kwargs' in _AuthTypeLazyChoices()
    assert 'custom-plugin-with-args-and-kwargs-and-auth' in _AuthTypeLazyChoices()
    assert 'custom-plugin-with-args-and-kwargs-and-auth-and-session' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:54.160227
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:52:59.004894
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:53:08.446328
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-body' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_

# Generated at 2022-06-17 19:53:14.614600
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:53:17.926735
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-17 19:53:19.515890
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:53:29.376824
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the most secure mechanism supported by the server.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Disable sending authentication information in response to a
    challenge from the server.

    ''',
)

# Generated at 2022-06-17 19:53:39.247102
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server SSL certificate.

    '''
)

# Generated at 2022-06-17 19:53:49.087378
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-signature' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'apikey' in _

# Generated at 2022-06-17 19:53:56.614857
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify SSL certificates.

    '''
)

# Generated at 2022-06-17 19:54:06.857839
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial challenge.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:54:09.937935
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:54:17.845058
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the auth type by looking at the HTTP response.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial authentication challenge.

    '''
)

#######################################################################


# Generated at 2022-06-17 19:54:33.319750
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie will try to
    detect the authentication type by looking at the HTTP response.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:54:43.711797
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect the mechanism based on the provided credentials.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial authentication challenge.

    '''
)

#######################################################################
# HTTP(S) Proxy
#######################################################################


# Generated at 2022-06-17 19:54:47.008937
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:54:58.775486
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect the mechanism based on the provided credentials
    and the server's response.

    ''',
)


# Generated at 2022-06-17 19:55:02.175163
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:55:05.238524
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:55:06.620192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:55:15.934620
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1', 'oauth2']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to detect the authentication type by the provided
    credentials.

    ''',
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='URL',
    help='''
    The authentication endpoint URL.

    This is only needed for OAuth 2.0 authentication.

    ''',
)

# Generated at 2022-06-17 19:55:18.881699
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:55:27.755305
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    ''',
)

auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=False,
    help='''
    Verify the server SSL certificate.

    ''',
)


# Generated at 2022-06-17 19:55:52.616510
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to detect the authentication type by the
    Authorization HTTP header.

    '''
)

auth.add_argument(
    '--auth-type-key',
    default=None,
    metavar='KEY',
    help='''
    The name of the key in the JSON response that contains the
    authentication token.

    '''
)


# Generated at 2022-06-17 19:56:04.210512
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1', 'oauth2']


# Generated at 2022-06-17 19:56:08.593304
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existent' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:56:10.153174
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:56:20.887580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    The following plugins are available:

        {plugins}

    '''.format(
        plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_

# Generated at 2022-06-17 19:56:29.437318
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to detect the authentication mechanism based on the
    provided credentials.

    The following mechanisms are supported:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-17 19:56:39.915521
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is 'auto', which means that HTTPie will try to
    detect the auth type by looking at the HTTP response.

    ''',
)

# Generated at 2022-06-17 19:56:49.925709
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')
ssl.add_argument(
    '--verify',
    default=True,
    action='store_true',
    help='''
    Verify the server's SSL certificate.
    This is enabled by default.

    ''',
)

# Generated at 2022-06-17 19:57:01.458750
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to auto-detect the authentication type based on the
    provided credentials.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial authentication challenge.

    This is useful for preemptively sending the credentials when the server
    does not send an authentication challenge.

    '''
)

####################################################################

# Generated at 2022-06-17 19:57:13.957263
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1', 'basic']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    The following mechanisms are supported:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-17 19:58:00.353326
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-type-force-interactive',
    action='store_true',
    default=False,
    help='''
    Force interactive authentication even if the auth plugin supports
    non-interactive authentication.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_

# Generated at 2022-06-17 19:58:07.081159
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-payload' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-signed-headers' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256-unsigned-unsigned-payload' in _AuthTypeL

# Generated at 2022-06-17 19:58:18.061374
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')
method.add_argument(
    '--method', '-m',
    default='GET',
    help='''
    The HTTP method to be used for the request.
    The default is "GET".

    '''
)

#######################################################################
# HTTP headers
#######################################################################

headers = parser.add_argument_group(title='HTTP headers')
headers.add_argument

# Generated at 2022-06-17 19:58:30.047607
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise none.

    ''',
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    The name of the auth plugin to use.

    This option is deprecated. Use --auth-type instead.

    ''',
)

# Generated at 2022-06-17 19:58:39.435002
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default, the appropriate
    one is guessed based on the provided credentials.

    The following auth types are available:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-17 19:58:42.926169
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 19:58:54.991825
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "auto", which means that HTTPie tries to guess the
    authentication type by looking at the provided credentials.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-17 19:59:03.008829
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    If set to 'auto' (default), HTTPie tries to guess the auth type from the
    provided credentials.

    ''',
)

auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    Force the specified auth type.

    By default, HTTPie tries to guess the auth type from the provided
    credentials.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_

# Generated at 2022-06-17 19:59:07.409811
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'unknown' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 19:59:08.959705
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 20:00:25.374869
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 20:00:27.527128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:00:35.775343
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    ''',
)

auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    The authentication plugin to be used.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an initial authentication challenge (WWW-Authenticate header).
    This is useful when the server does not support the 401 status code.

    '''
)

################################################################

# Generated at 2022-06-17 20:00:40.524918
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-17 20:00:42.046048
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-17 20:00:47.789149
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'aws4-signature' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-body' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-headers' in _AuthTypeLazyChoices()
    assert 'aws-sigv4-unsigned-payload' in _AuthTypeLazyChoices()

# Generated at 2022-06-17 20:00:55.208512
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic" if --auth is provided, otherwise no authentication
    is used.

    ''',
)

# Generated at 2022-06-17 20:01:03.862886
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2'
    ]

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic".

    '''
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    The authentication endpoint URL.

    '''
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The authentication host.

    '''
)


# Generated at 2022-06-17 20:01:12.499061
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is to try to use the most secure mechanism available.

    ''',
)


# Generated at 2022-06-17 20:01:17.790284
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform challenge response (i.e., do not send 401/407
    responses needed to negotiate credentials).

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')