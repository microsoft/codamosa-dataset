

# Generated at 2022-06-21 13:19:07.072088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list()


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication plugin.

    The default plugin is "{DEFAULT_AUTH_PLUGIN}".

    You can use "{CUSTOM_AUTH_PLUGIN_MARKER}" as a TYPE to specify that the
    password is a Base64-encoded string instead of a plaintext password.

    '''
)

# Generated at 2022-06-21 13:19:19.758251
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(iter(_AuthTypeLazyChoices()))


auth_type = parser.add_argument_group('Authentication Type')
auth_type.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this option to specify the authentication type explicitly. You can use
    it along with --auth, or instead of it.

    If HTTPie detects an auth plugin for the acutal response status code, then
    it will ignore --auth-type.

    Available types: {auth_types}

    '''
)

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-21 13:19:30.083705
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()).sort() == list(_AuthTypes).sort()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Currently supported auth types are:

        basic, digest, aws

    You can also enable plugins that provide auth types.
    '''
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host to use for HTTP Digest Authentication.
    See also --auth-type.
    '''
)


# Generated at 2022-06-21 13:19:32.809665
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:43.506366
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()

auth_type_type = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=type_validator('Invalid authentication type.', auth_type_type),
    choices=auth_type_type,
    help='''
    The auth mechanism to use.
    Currently supported: {supported}

    '''.format(supported=', '.join(auth_type_type))
)

# kwargs[<auth-type>]
# eg. kwargs['digest']


# Generated at 2022-06-21 13:19:46.869189
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(plugin_manager.get_auth_plugin_mapping(), '__iter__')
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:19:58.384668
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['Basic'].name,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to use. The value can be one of:

        {auth_types}

    If not specified, Basic authentication is used.

    '''.format(
        auth_types='\n'.join(
            (8 * ' ') + line
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        ).strip()
    )
)



# Generated at 2022-06-21 13:20:10.337405
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    ''',
)

# Deprecated, replaced by --auth-type=digest
auth.add_argument(
    '--auth-digest',
    action='store_const',
    const='digest',
    dest='auth_type',
    help=argparse.SUPPRESS
)


# Generated at 2022-06-21 13:20:23.057125
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(
        _AuthTypeLazyChoices()
    ) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    The default is to always use the best available mechanism, but you can also
    specify it explicitly. A custom value can be used to invoke auth plugins
    (see http://httpie.org/plugins).

    '''
)


# Generated at 2022-06-21 13:20:32.203877
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _ATLC = _AuthTypeLazyChoices()
    assert 'basic' in _ATLC

auth_type_choices_validator = AuthTypeValidator()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    type=auth_type_choices_validator,
    help='''
    Force the specified HTTP auth implementation.
    The default (auto) is HTTP Basic auth,
    provided that the --auth option is present.

    '''
)

# Generated at 2022-06-21 13:20:46.531126
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Test constructor of class _AuthTypeLazyChoices."""
    """_AuthTypeLazyChoices()"""

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=AuthCredentials(name='AUTH_TYPE'),
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    The authentication mechanism to use.

    If not provided, HTTPie tries to guess; most of the time it gets it right.

    ''',
)

# Generated at 2022-06-21 13:20:57.830831
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))  # self.__iter__

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin. Plugins are modules that can be
    found using Python's module resolution mechanism. For more info,
    see: https://httpie.org/plugins#authentication

    ''',
)
auth.add_argument(
    '--auth-type-keyword',
    default=None,
    metavar='AUTH_KEYWORD',
    help='''
    The authentication plugin's keyword argument. If not specified,
    it defaults to the ``auth-type`` argument.

    '''
)

################################################################

# Generated at 2022-06-21 13:21:02.276763
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import requests.auth
    _AuthTypeLazyChoices().__contains__('basic')
    not _AuthTypeLazyChoices().__contains__('asic')


# Generated at 2022-06-21 13:21:13.956869
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager._load_plugins()
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:21:23.448284
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    default='auto',
    choices=_AuthTypeLazyChoices,
    help='''
    The authentication mechanism to be used.

    The available types vary depending on the installed plugins.

    By default, the plugin ``httpie-auth-plugin`` (which is installed
    automatically) will try to detect the type automatically based on the
    presence of Auth-* headers.

    '''
)


#######################################################################
# HTTP method
#######################################################################
method = parser.add_argument_group(title='HTTP Method')


# Generated at 2022-06-21 13:21:27.092458
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'aws-s3' in auth_type
    assert 'oauth1' in auth_type
    assert 'jwt' in auth_type
    assert 'aws_auth_v4' in auth_type
    assert 'digit' not in auth_type
    assert 'bearer' not in auth_type


# Generated at 2022-06-21 13:21:38.642706
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'asd' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth type to be used.
    By default, there is no auth.

    Available auth types:

        {plugin_help}

    '''.format(
        plugin_help='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)


# Generated at 2022-06-21 13:21:52.783761
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    def get_auth_plugin_mapping(self):
        return dict(foo=None, bar=None)
    plugin_manager._get_auth_plugin_mapping = get_auth_plugin_mapping
    plugin_manager._get_auth_plugin_mapping.__func__.__name__ += '__mock'
    try:
        assert list(_AuthTypeLazyChoices()) == ['bar', 'foo']
    finally:
        plugin_manager._get_auth_plugin_mapping.__func__.__name__ = \
            plugin_manager._get_auth_plugin_mapping.__func__.__name__[:-7]

# Actual arguments.


# Generated at 2022-06-21 13:21:54.109490
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(
        _AuthTypeLazyChoices()
    ) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:22:02.906979
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism (when it can't be inferred from the --auth option).

    Use with --auth to force using the specified auth plugin, e.g.:

        --auth-type=jwt --auth="token"

    Available auth plugins:

    {help}

    '''.format(
        help='\n    '.join(
            line.strip() for line in plugin_manager.get_auth_plugin_help().splitlines()
        )
    )
)

# Generated at 2022-06-21 13:22:08.838048
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'non-existent' not in choices


# Generated at 2022-06-21 13:22:12.103388
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.get_auth_plugin_mapping()['plugin'] = 'plugin'
    auth_type = _AuthTypeLazyChoices()
    assert 'plugin' in auth_type


# Generated at 2022-06-21 13:22:23.677974
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    help=f'''
    The authentication mechanism to be used. Valid values depend on the
    installed plugins. Install plugins with:

        $ pip install httpie-{plugin_manager.type}-auth

    The following are the currently available plugins:

        {', '.join(plugin_manager.get_auth_plugin_mapping()) or 'none'}

    Plugins can be enabled or disabled using the
    {plugin_manager.environment_plugin_option_name} environment variable.
    ''',
    type=AuthCredentials(
        plugin_manager,
        auth_type_choices=_AuthTypeLazyChoices(),
    )
)

#######################################################################
# HTTP methods


# Generated at 2022-06-21 13:22:33.589721
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    types = _AuthTypeLazyChoices()
    assert isinstance(types, collections.Iterable)
    assert set(types) == set(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force usage of a specific authentication type. By default HTTPie tries to
    use the most secure one.

    The following auth types are supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-21 13:22:44.268079
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(DEFAULT_AUTH_PLUGINS) in _AuthTypeLazyChoices()

auth_type_validator = AuthTypeValidator(
    plugin_manager.get_auth_plugin_mapping(),
    '{0} is not a valid auth plugin. The built-in plugins are: {1}.'.format(
        '{0}',
        ', '.join(DEFAULT_AUTH_PLUGINS)
    )
)

# Generated at 2022-06-21 13:22:54.813805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['basic', 'digest']
AUTH_PAIRED_PARAMETER_CHOICES = {'digest': None}

# Generated at 2022-06-21 13:23:00.503109
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class Test:
        def foo(self, *args, **kwargs):
            return args, kwargs
    auth_plugin_mapping = {
        'foo': Test(),
        'bar': Test(),
        'baz': Test(),
    }
    with patch.object(plugin_manager, 'get_auth_plugin_mapping',
                      return_value=auth_plugin_mapping):
        assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
            sorted(auth_plugin_mapping)


# Generated at 2022-06-21 13:23:03.010370
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:23:03.717923
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass



# Generated at 2022-06-21 13:23:04.323442
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass

# Generated at 2022-06-21 13:23:22.718539
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Only relevant when also
    specifying --auth.

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host to use for authentication if different from the request host.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:23:32.967953
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert len(list(choices)) >= 2

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The special value auto (default)
    causes HTTPie to auto-detect the mechanism based on the provided credentials.
    You can also use one of the following case-insensitive values: basic, digest.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Ignore the netrc file, even if it exists and is readable.

    '''
)

# Generated at 2022-06-21 13:23:37.563481
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Check if all values, returned by method __iter__, are in __contains__"""
    auth_type_choices = _AuthTypeLazyChoices()
    for auth_type in auth_type_choices:
        assert(auth_type in auth_type_choices)

# Generated at 2022-06-21 13:23:39.355348
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:48.993567
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_auth_type_lazy_choices,
    help=f'''
    The type of the provided credentials.
    If not provided, the auth plugin will try to guess it based on the provided credentials.
    Otherwise, it will try to use the "basic" auth plugin.

    Available auth types are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# `requests.auth.HTTPBasicAuth` keyword arguments.

# Generated at 2022-06-21 13:23:52.303972
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert sorted(a) == ['basic', 'digest', 'hawk', 'kerberos', 'ntlm', 'oath', 'pki']


# Generated at 2022-06-21 13:24:05.224415
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert sorted(list(lazy_choices)) == sorted(list(_AuthTypeLazyChoices()))

AuthTypeLazyChoices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=AuthTypeLazyChoices,
    help='''
    Specify an auth plugin to use. By default, the most secure plugin provided
    by the server is used.
    '''
)

#######################################################################
# HTTP method
#######################################################################

http_method = parser.add_argument_group(title='HTTP method')

# Generated at 2022-06-21 13:24:16.302698
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    help='''
    Force the use of a particular authentication plugin.

    Common plugins include: basic, digest.

    Additional custom plugins can be provided through
    plugins (see '--plugins' option).
    ''',
    default=None,
    choices=_AuthTypeLazyChoices()
)


#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:24:18.323252
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:24:28.830086
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    >>> choices = _AuthTypeLazyChoices()
    >>> choices
    _AuthTypeLazyChoices()
    >>> 'digest' in choices
    True
    >>> 'basic' in choices
    True
    >>> next(iter(choices))
    'basic'
    """

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=AuthPluginProxy,
    default=None,
    help='''
    Force the specified authentication method. The values that can be used
    depend on the installed plugins.

    '''
)

# The auth plugin arguments.
auth_plugin_proxy = AuthPluginProxy()

# Generated at 2022-06-21 13:24:54.819370
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'kerberos' in lazy_choices
    assert 'myplugin' not in lazy_choices

auth.add_argument(
    '--auth-type',
    type=AuthPlugin,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Plugin used to handle authentication. Default to "basic".

    The following plugins are available ({count}):

        {types}

    Use --debug to see the list of all available plugins.

    '''.format(
        count=len(plugin_manager.get_auth_plugin_mapping()),
        types=', '.join(plugin_manager.get_auth_plugin_mapping()),
    )
)

#######################################################################
# Timeouts


# Generated at 2022-06-21 13:25:00.520474
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices.__contains__('test')


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the default HTTPie authentication plugin
    (usually the "auto" one that detects the auth type based on the URL).

    To see a list of supported auth plugin types, run: http --auth-type=

    '''
)

# Deprecated
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help=argparse.SUPPRESS
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='Request Method')

# Generated at 2022-06-21 13:25:07.658778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted([
        'basic', 'digest', 'plugin', 'plugin-implicit'
    ])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the Authorization scheme.

    The default is "basic". Use "digest" to force digest auth.

    Plugins can define non-standard auth types; use --auth-type=plugin to see
    the full list.

    ''',
)

# Generated at 2022-06-21 13:25:08.560960
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:25:17.039269
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager_instance = plugin_manager.get_instance()
    auth_types = [name for name in _AuthTypeLazyChoices()]
    assert auth_types == plugin_manager_instance.get_auth_plugin_mapping().keys()

# Generated at 2022-06-21 13:25:20.298988
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-21 13:25:23.821343
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from unittest.mock import Mock
    manager = Mock()
    manager.get_auth_plugin_mapping.return_value = {'digest': 'digest_class'}
    assert list(_AuthTypeLazyChoices(manager)) == ['digest']


# Generated at 2022-06-21 13:25:32.702783
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='{' + ', '.join(plugin_manager.get_auth_plugin_mapping().keys()) + '}',  # noqa
    help='''
    Specify the authentication mechanism. By default, HTTPie attempts to
    figure out the correct auth mechanism based on the provided credentials,
    and fails if more than one mechanism matches.

    '''
)
auth.add_argument(
    '--auth-type-force',
    default=None,
    help=SUPPRESS
)


# Generated at 2022-06-21 13:25:40.887967
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert ['basic', 'digest'] == sorted(list(choices))

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default HTTPie
    attempts to use the most secure mechanism available.

    ''',
)
auth_plugin_help = wrap_with_fill(
    'The following auth plugins are available: {}.'.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    ),
    initial_indent=8 * ' ',
    subsequent_indent=8 * ' '
)

# Generated at 2022-06-21 13:25:52.187851
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices.__contains__(_AuthTypeLazyChoices(), 'Basic')


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    The type of credentials provided in --auth. The default is ``auto``, which
    is a shortcut for ``--auth-type=basic``.

    You can use this to implement HTTP APIs that use a non-standard auth scheme
    that is not Basic or Digest.

    The value of this option is the suffix of the related AuthPlugin class
    name. For example, ``--auth-type=digest`` loads the
    ``httpie.plugins.auth.digest.DigestAuthPlugin`` class.

    ''',
)

# Generated at 2022-06-21 13:26:36.576881
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(AuthTypeLazyChoices, _AuthTypeLazyChoices)


auth.add_argument(
    '--auth-type',
    choices=AuthTypeLazyChoices(),
    help=f'''
    Choose an auth handler. Currently available: {plugin_manager.get_auth_plugin_mapping()}

    ''',
)

auth.add_argument(
    '--auth-warn',
    dest='auth_warn',
    action='store_true',
    default=AUTH_WARN,
    help='''
    Print a warning if no --auth credentials are provided.

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-21 13:26:38.004307
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:26:44.034839
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert len([x for x in choices]) > 1

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism to be used, e.g., basic, digest.

    ''',

)

auth_plugin_group = auth.add_argument_group(title='Auth Plugin Options')
plugin_manager.add_plugin_args(auth_plugin_group)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:26:46.146302
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'oauth1', 'signed_auth']

# Generated at 2022-06-21 13:26:56.201008
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins import builtin
    builtin.load_plugins()
    assert 'jwt' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used.

    This should be one of the values listed below:

        {auth_types_list}

    '''.format(
        auth_types_list='\n'.join(
            '\t' + line.strip() for line in
            wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        )
    )
)

# Generated at 2022-06-21 13:27:02.751527
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth_types = plugin_manager.get_auth_plugin_mapping().keys()

auth_type_validator = AuthPluginValidator('auth type')
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    default='basic',
    help=f'''
    Use TYPE authentication. Choices: {', '.join(auth_types)}.

    The default is "basic".

    ''',
    type=auth_type_validator,
)


# Generated at 2022-06-21 13:27:08.910623
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []
    auth_plugins = {'basic': 'Basic', 'digest': 'Digest'}
    plugin_manager.set_auth_plugin_mapping(auth_plugins)
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-21 13:27:17.593304
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    # because we're mocking out the plugins, this should work even when
    # the digest module hasn't been installed.
    assert 'digest' in auth_types

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=auth_type_choices,
    help='''
    The type of auth to use.
    If no value is provided, the type of auth will be auto-detected.

    The auto detection covers all known auth types in the order below:
    Basic, Digest, Hawk, Netrc.

    ''',
)


# Generated at 2022-06-21 13:27:23.991672
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=(
        'The authentication mechanism to be used. If not provided, then HTTPie '
        'will automatically detect the most suitable mechanism: Basic, Digest, '
        'or OAuth 1. Supported authentication mechanisms are: %(choices)s. '
        'The default is: %(default)s.'
    )
)
auth.add_argument(
    '--auth-type-force-interactive',
    action='store_true',
    help='''
    Force interactive auth when --auth-type is auto.

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-21 13:27:35.538610
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert sorted(list(choices)) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='auto',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. Default is "auto".

    {auth_plugin_help}

    '''.format(
        auth_plugin_help=plugin_manager.get_auth_plugin_help()
    )

)

# Generated at 2022-06-21 13:28:49.458241
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:28:57.013086
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication mechanism. The default ("auto") uses the same
    mechanism as curl ("basic" unless --insecure is set, in which case "digest").

    Supported types:
      {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)