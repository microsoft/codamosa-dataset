

# Generated at 2022-06-21 13:18:56.546651
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:18:59.494420
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:19:05.079812
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'basic' in auth_types


# Generated at 2022-06-21 13:19:12.990463
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert list(choices) == sorted(['basic', 'digest', 'hawk'])


auth_type_choices = _AuthTypeLazyChoices()
auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    The authentication mechanism to be used. Default is "auto",
    which is an alias for "basic".

    Available types: "basic" (default), "digest", "hawk"

    ''',
)

#######################################################################
# Server, Proxy
#######################################################################

server_group = parser.add

# Generated at 2022-06-21 13:19:14.864068
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')

# Generated at 2022-06-21 13:19:23.626544
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.discover_plugins()
    auth_types = _AuthTypeLazyChoices()
    assert list(auth_types) == [
            'basic',
            'digest'
    ]
    assert list(auth_types) == [
            'basic',
            'digest'
    ]


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Type of authentication to use. The default is "basic".
    May be a plugin name (e.g., "digest").

    '''
)

# Generated at 2022-06-21 13:19:35.760742
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'oauth2' in _AuthTypeLazyChoices()


auth_plugin_help_prefix = f'''
    Select an auth plugin to be used for sending the request.
    The built-in options are:

        {', '.join(sorted(DEFAULT_AUTH_PLUGIN_MAPPING.keys()))}

    '''


# Generated at 2022-06-21 13:19:47.084205
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used.

    If a plugin provides a custom auth method, use ``--auth-type=<name>`` to
    use it. Available plugins and auth methods can be displayed with
    ``http --debug``.

    '''
)

# Generated at 2022-06-21 13:19:50.010281
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert len(list(auth_type_choices)) > 0


# Generated at 2022-06-21 13:20:03.122878
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert len(choices) > 0
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The plugin to use for authentication.

    '''
)


# Generated at 2022-06-21 13:20:19.564050
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import collections
    collections.abc.Iterable.register(_AuthTypeLazyChoices)
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()

auth_plugin = parser.add_argument_group(title='Authentication Plugin')
auth_plugin.add_argument(
    '--auth-type',
    default=None,
    metavar='PLUGIN_NAME',
    choices=_AuthTypeLazyChoices(),
    help='''
    If multiple auth plugins are installed, select one to be used.

    ''',
)

# JSON Pointer,
# see https://tools.ietf.org/html/rfc6901
JSONPointer = argparse.RegexValidator

# Generated at 2022-06-21 13:20:29.955222
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert list(lazy_choices)
    assert BasicAuth('username', 'password') in lazy_choices
    assert DigestAuth('username', 'password') in lazy_choices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force the specified authentication type.

    Currently available: {sorted(_AuthTypeLazyChoices())}

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Ignore the netrc file. This option does not affect session files.

    '''
)

#######################################################################
# HTTP and HTTPS proxy.
#######################################################################

# Generated at 2022-06-21 13:20:39.033755
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert set(choices) == {'basic', 'digest'}

# Note that `action='append'` can't be used here because of validation.

# Generated at 2022-06-21 13:20:49.863744
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for item in choices:
        assert item in choices

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth type to use for authentication. Available types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    ''',
    metavar='TYPE',
)

# Generated at 2022-06-21 13:20:55.873803
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'basic' in lazy_choices
    assert 'hawk' in lazy_choices
    assert 'foo' not in lazy_choices

auth_type_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    Specify an authentication type to be used. By default, the authentication
    type is auto-detected using server's 401 response. This option should be
    used only in cases when auto-detection fails or to use custom auth type
    plugins.

    '''.strip()
)

# Generated at 2022-06-21 13:21:03.270243
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_auth_type_choices,
    help=f'''
    Specify a custom authentication plugin, e.g. WSAuth or HawkAuth.
    The plugin path can be a dotted module name or a path to a
    module.

    '''
)

# Generated at 2022-06-21 13:21:14.686696
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    plugin_manager_instance = plugin_manager.get_instance()
    plugin_manager_instance.load_auth_plugin_from_module(
        'httpie.plugins.auth.basic',
        name='basic',
    )
    plugin_manager_instance.load_auth_plugin_from_module(
        'httpie.plugins.auth.digest',
        name='digest',
    )
    plugin_manager_instance.load_auth_plugin_from_module(
        'httpie.plugins.auth.hawk',
        name='hawk',
    )
    plugin_manager_instance.load_auth_plugin_from_module(
        'httpie.plugins.auth.oauth2',
        name='oauth2',
    )

# Generated at 2022-06-21 13:21:19.983087
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert sorted(list(auth_type_choices)) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))
    plugin_manager.get_auth_plugin_mapping().clear()
    assert list(auth_type_choices) == []


# Generated at 2022-06-21 13:21:22.854833
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    inst = _AuthTypeLazyChoices()
    assert 'digest' in inst
    assert 'BasicDigestAuth' in inst
    assert 'custom' not in inst


# unit test for method __iter__ of class _AuthTypeLazyChoices

# Generated at 2022-06-21 13:21:32.513917
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism, e.g. "basic" or "digest".
    The default is "basic".

    '''
)


#######################################################################
# HTTP Method
#######################################################################

method = parser.add_argument_group(title='HTTP Method')
method.add_argument(
    '--method', '-m',
    default='GET',
    metavar='METHOD',
    help='''
    The HTTP method to be used for the request. The default is GET.

    '''
)

################################

# Generated at 2022-06-21 13:21:41.716797
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy = _AuthTypeLazyChoices()
    assert 'basic' in lazy
    assert 'digest' in lazy


# Generated at 2022-06-21 13:21:55.807599
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.builtin import AuthPlugin
    test_instance = _AuthTypeLazyChoices()
    assert AuthPlugin.name in test_instance
    plugin_manager.unload_plugin(AuthPlugin)
    assert AuthPlugin.name not in test_instance


# Generated at 2022-06-21 13:22:03.923877
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:22:14.962908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    empty_plugin_manager()
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' not in lazy_choices
    assert 'digest' not in lazy_choices
    register_plugin_classes(BasicAuthPlugin, DigestAuthPlugin)
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices

auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-21 13:22:18.328450
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))

# Generated at 2022-06-21 13:22:21.085781
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:22:31.640877
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    By default, Basic and Digest mechanisms are tried in this order,
    unless an explicit type is given.

    If a custom plugin is supplied and it's entry point is not called
    "httpie_auth_TYPE" then the full dotted entry point name (e.g.
    "package.module.plugin") must be used.

    Available built-in mechanisms:
    http://httpie.org/plugins#authentication

    '''
)


# Generated at 2022-06-21 13:22:44.147569
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.compat import is_py26
    from httpie import plugins as httpie_plugins
    _AuthTypeLazyChoices.__iter__.__func__.__code__.co_firstlineno + 2
    items = set(item for item in _AuthTypeLazyChoices())
    if is_py26:
        # Python 2.6 doesn't have `set_name` constructor argument.
        httpie_plugins.HawkAuthPlugin.__name__ = 'hawk'
        httpie_plugins.DigestAuthPlugin.__name__ = 'digest'
    else:
        plugins.HawkAuthPlugin.__name__ = 'hawk'
        plugins.DigestAuthPlugin.__name__ = 'digest'

# Generated at 2022-06-21 13:22:45.240457
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:22:55.557350
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _ = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    help='''
    Choose an authentication plugin. By default the right plugin is chosen
    based on the provided credentials (e.g. "-a username:passwd" implies
    Basic auth).

    Available types: {0}

    '''.format(', '.join(_AuthTypeLazyChoices()))
)


#######################################################################
# SSL/TLS
#######################################################################


# Generated at 2022-06-21 13:23:24.465072
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'HTTPieBasicAuthPlugin' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Each authentication plugin implements its own options. For a complete list
    of available plugins and their options, as well as how to implement custom
    plugins, see the Authentication section of the HTTPie manual:
    https://httpie.org/docs#authentication

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:23:34.370839
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(
        AUTH_PLUGIN_MAP
    ) == sorted(
        list(_AuthTypeLazyChoices())
    )

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used for the request.

    When using this option HTTPie first tries to find a plugin that
    implements the given type. If no plugin is found the option is passed
    to the underlying HTTP client library, giving it a chance to resolve it.

    The default behavior is to let the client library choose the
    authentication type to use.

    '''
)

# Generated at 2022-06-21 13:23:45.355253
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    dest='auth_plugin',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth plugin to use.

    Currently supported plugins:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-21 13:23:52.367254
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == \
           list(sorted(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used.
    Valid types are:

        {types}

    '''.format(types=', '.join(plugin_manager.get_auth_plugins()))
)


# Generated at 2022-06-21 13:24:05.331394
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert set(['basic', 'digest', 'hawk']) == set(auth_types)

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    How to encode the credentials in the request.

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:24:13.814904
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices"""
    from httpie.input import auth_type as _auth_type
    from httpie.input import plugin_manager as _plugin_manager
    instance = _AuthTypeLazyChoices()
    instance_attr_1 = _auth_type
    instance_attr_2 = _plugin_manager
    item = 42
    try:
        return instance.__contains__(item)
    finally:
        del instance
        del _auth_type
        del _plugin_manager

# Generated at 2022-06-21 13:24:17.383865
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for key in auth_type_lazy_choices:
        assert key in auth_type_lazy_choices
        assert isinstance(key, str)


# Generated at 2022-06-21 13:24:27.336599
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=KeyValueAuthPlugin.name,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication methods that HTTPie can currently handle.
    The default is "key-value", which means the username and password are
    provided in the URL query string:

        http --auth-type=key-value -a username:password example.org

    Other methods that HTTPie can use are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

#######################################################################
# HTTPS
#######################################################################

# Generated at 2022-06-21 13:24:36.490844
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Currently supported: {0}.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)
auth.add_argument(
    '--auth-host',
    metavar='HOST',
    default=None,
    help='''
    The host to use for HTTP authentication, as specified in RFC 7235. If no
    host is specified, the host of the request url is used instead.

    '''
)

# Generated at 2022-06-21 13:24:38.506579
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping()))

# Generated at 2022-06-21 13:25:21.660578
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:31.130022
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    metavar='TYPE',
    help=f'''
    The authentication mechanism to be used.
    Recognized mechanisms are:

    {sorted(plugin_manager.get_auth_plugin_mapping())}

    '''
)

#######################################################################
# Redirects
#######################################################################

redirects = parser.add_argument_group(title='Redirects')

redirects.add_argument(
    '--follow', '-F',
    action='store_true',
    default=False,
    help='''
    Follow redirects.

    '''
)


# Generated at 2022-06-21 13:25:32.140101
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices



# Generated at 2022-06-21 13:25:34.662787
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'Digest' in choices
    assert 'Custom_Auth' not in choices



# Generated at 2022-06-21 13:25:37.358852
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'invalid' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:25:44.307495
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    return list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism.

    The `digest' authentication is only applied if the server
    specifically asks for it (via a 401 response). This is true for
    all `--auth-type' options.

    The available auth types are:
    {auth_type_choices}
    '''.format(auth_type_choices=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping())
    ))
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:25:57.561409
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert (sorted(list(_AuthTypeLazyChoices())) ==
            ["basic", "digest", "hawk", "netrc", "ntlm", "oauth1"])

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism for the request, e.g. "basic", "digest",
    "hawk", "netrc", "ntlm". By default, HTTPie follows RFC 2617 and tries
    "basic", "digest", and "ntlm", in that order.

    ''',
)


# Generated at 2022-06-21 13:26:01.292779
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert list(auth_type_lazy_choices) == ['basic', 'digest']



# Generated at 2022-06-21 13:26:11.368596
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    dest='auth_plugin_name',
    help='''
    The name of the plugin that will be used to perform the authentication.

    '''
)
auth.add_argument(
    '--auth-type=BASIC',
    action='store_const',
    const='basic',
    dest='auth_plugin_name',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-21 13:26:21.187419
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-type=',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type. The value is a plugin
    name from the installed plugins (type `http --debug` to see a list).
    You can specify the plugin name only if there is a single match in
    which case it is treated as an abbreviation.

    '''
)


# Generated at 2022-06-21 13:27:42.195558
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices  # noqa: F821
    assert 'digest' in _AuthTypeLazyChoices  # noqa: F821
    assert 'awsv4' in _AuthTypeLazyChoices  # noqa: F821
    assert sorted([
        'basic',
        'digest',
        'awsv4'
    ]) == sorted(_AuthTypeLazyChoices)


# Generated at 2022-06-21 13:27:43.501063
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('digest')


# Generated at 2022-06-21 13:27:45.479033
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:55.966673
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:

    {0}

    '''.format(
        '\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:28:03.102379
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to be used.

    The default value, "auto", is the most secure choice in most cases.
    It automatically detects and uses the strongest mechanism
    supported by both the server and HTTPie, which is usually
    Digest, but falls back to Basic.

    Choosing "digest" or "basic" enforces usage of the respective
    authentication mechanism, regardless of server support.

    Install the Digest and/or Basic plugins with:

        $ pip install httpie-{digest,basic}-auth

    '''
)

#######################################################################
# HTTP verb
#######################################################################


# Generated at 2022-06-21 13:28:07.251979
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    from httpie.plugins import plugin_manager
    choices = _AuthTypeLazyChoices()
    assert plugin_manager.builtin_plugins.BasicAuth.auth_type in choices
    assert 'basic' in choices
    assert 'foo' not in choices

# Generated at 2022-06-21 13:28:08.991239
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())  # noqa



# Generated at 2022-06-21 13:28:19.634660
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(isinstance(choice, str)
               for choice in _AuthTypeLazyChoices())



# Generated at 2022-06-21 13:28:20.948870
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:28:27.481088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(['basic', 'digest']))
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Authentication method. If not specified, HTTPie will auto-detect the
    auth type or prompt for it.
    '''
)

