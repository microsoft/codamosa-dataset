

# Generated at 2022-06-21 13:19:08.421236
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) == set(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Unless specified, the plugin attempts to
    infer it from the provided --auth value, or prompts the user to select
    one:

        http --auth-type=basic

    To disable authentication:

        http --auth-type=none

    Available plugins:

    ''' + render_docstring_to_rst(
        render_auth_plugins_to_rst(
            plugin_manager.list_auth_plugins())
    )
)

#######################################################################
# HTTP method


# Generated at 2022-06-21 13:19:11.915037
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""
    assert 'fake_auth' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:22.229804
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert list(lazy_choices) == sorted(['basic', 'digest'])


# Generated at 2022-06-21 13:19:31.089960
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(iter(_AuthTypeLazyChoices())) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type_choices = _AuthTypeLazyChoices()

auth_plugin = parser.add_argument_group(title='Authentication Plugin') \
    .add_mutually_exclusive_group(required=False)

auth_plugin.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help='''
    The authentication plugin to use. Run `http --auth-type=?` to
    see the available options.
    '''
)

# Generated at 2022-06-21 13:19:32.866240
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'fake' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:36.784189
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    # non-existing type
    assert 'non-existing' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:46.326370
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'DigestAuth' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    See '{0} --help' for a list of built-in options.

    '''.format(os.path.basename(sys.argv[0]))
)

# Generated at 2022-06-21 13:19:59.265361
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    atlc = _AuthTypeLazyChoices()

    assert 'basic' in atlc
    assert len(list(atlc)) == len(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default,
    the "basic" mechanism is used.

    The available types depend on the installed plugins. Run
    `http --debug` to see a list of all installed plugins.

    '''
)

#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP')

# Generated at 2022-06-21 13:20:10.707788
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        list({
            'bearer',
            'basic',
            'digest',
            'hawk'
        }) == list(_AuthTypeLazyChoices)
    )



# Generated at 2022-06-21 13:20:23.511219
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    plugin_manager._installed_plugins = []
    assert 'Basic' in AuthTypeLazyChoices

    plugin_manager._installed_plugins = [BasicAuthPlugin()]
    assert 'Basic' in AuthTypeLazyChoices


AuthTypeLazyChoices = _AuthTypeLazyChoices()  # noqa

# Generated at 2022-06-21 13:20:35.521603
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'jwt' in choices
    assert 'basic' in choices
    assert 'bearer' in choices


auth.add_argument(
    '--auth-type', '-t',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "basic".
    Each scheme may include a number of parameters. For the list
    of the supported ones and how to specify them, please refer
    to the documentatio for the particular plugin.

    ''',
)
auth.add_argument(
    '--auth-scheme',
    dest='auth_type',
    action='store_const',
    const='basic',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-21 13:20:45.958875
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a linked auth plugin (Secure Link, digest, etc. See
    `http --debug --help` for the full list).

    By default, the plugin is guessed from the auth credentials passed in
    the --auth option.

    '''
)

# Generated at 2022-06-21 13:20:48.080277
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:58.694520
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class _AuthTypeLazyChoices:
        def __contains__(self, item):
            return True

        def __iter__(self):
            return iter(['foo', 'bar'])

    lazy = _AuthTypeLazyChoices()
    assert isinstance(lazy, _AuthTypeLazyChoices)
    assert 'foo' in lazy
    assert 'bar' in lazy



# Generated at 2022-06-21 13:21:00.160043
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass

# Generated at 2022-06-21 13:21:02.041817
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iter(_AuthTypeLazyChoices())
    assert True

# Generated at 2022-06-21 13:21:13.728378
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:21:23.324028
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(_AuthTypeLazyChoices(), '__iter__')
    assert isinstance(iter(_AuthTypeLazyChoices()), Iterator)


# Generated at 2022-06-21 13:21:33.001438
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    Asserts method __contains__ of class _AuthTypeLazyChoices.
    """

    # Arrange
    import httpie.core
    httpie.core.plugin_manager = MagicMock()

    plugin_manager = httpie.core.plugin_manager
    lazy_choices = _AuthTypeLazyChoices()

    plugin_manager.get_auth_plugin_mapping.return_value = {'foo': MagicMock()}

    # Act
    is_foo_in_lazy_choices = 'foo' in lazy_choices

    # Assert
    assert_true(is_foo_in_lazy_choices)

    # Act
    is_bar_in_lazy_choices = 'bar' in lazy_choices

    # Assert

# Generated at 2022-06-21 13:21:43.325790
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # pylint: disable=unused-variable
    from httpie.auth.plugins import AuthPluginTest
    from httpie.plugins import plugin_manager

    # Create a dummy plugin.
    class FooPlugin(AuthPluginTest):

        auth_type = 'foo'

        def get_auth(self, username, password):
            return None, None

    plugin_manager.register(FooPlugin)

    # Check that our dummy plugin is listed in the choices.
    assert 'foo' in _AuthTypeLazyChoices()

    # Clean up.
    plugin_manager.deregister(FooPlugin)
    delattr(FooPlugin, 'auth_type')



# Generated at 2022-06-21 13:21:59.682590
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(get_auth_plugin_mapping().keys()) == sorted(list(_AuthTypeLazyChoices()))



# Generated at 2022-06-21 13:22:11.562071
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert list(lazy_choices) == ['basic', 'digest']


# Generated at 2022-06-21 13:22:15.894024
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def test_instance(instance):
        assert 'basic' in instance
        for value in instance:
            assert value in instance
        assert 'xxx' not in instance
        assert len(instance) > 0

    test_instance(iter(_AuthTypeLazyChoices()))
    test_instance(_AuthTypeLazyChoices())
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

# Generated at 2022-06-21 13:22:27.404385
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(_AuthTypeLazyChoices())
    assert next(it) == AUTH_PLUGIN_MAP_DEFAULT
    assert next(it) == AUTH_PLUGIN_MAP_OAUTH1
    assert next(it) == AUTH_PLUGIN_MAP_OAUTH2
    list(it)



# Generated at 2022-06-21 13:22:36.147516
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('foo' in _AuthTypeLazyChoices()) is False
    assert ('basic' in _AuthTypeLazyChoices()) is True
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Can be one of:

    {choices}

    '''
)
auth.add_argument(
    '--auth-endpoint',
    default=None,
    metavar='AUTH_ENDPOINT',
    help='''
    The endpoint for fetching the auth token. For example: /api/auth/login
    Some auth types like OAuth1 require you to set this.

    '''
)

# Generated at 2022-06-21 13:22:37.835886
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for choice in choices:
        assert choice in choices


# Generated at 2022-06-21 13:22:48.570698
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['Basic', 'Digest']) == sorted(list(
        _AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used for the request.
    It is auto-detected based on --auth credentials, if not specified.

    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Ignore the netrc file.

    '''
)

#######################################################################
# Custom headers
#######################################################################

custom_headers = parser.add_argument_group(title='Custom headers')
custom_headers.add

# Generated at 2022-06-21 13:22:57.482821
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:23:08.206477
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['Basic', 'Digest'] == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication mechanism if several are supported by the server.
    Supported authentication methods:
        Basic, Digest
    Note: Some are plugins and may not be available on all systems.
    ''',
)

# Generated at 2022-06-21 13:23:17.213217
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices
    assert 'digest' in _AuthTypeLazyChoices
    assert 'custom' not in _AuthTypeLazyChoices
    assert 'bogus' not in _AuthTypeLazyChoices
    assert list(_AuthTypeLazyChoices) == ['basic', 'digest']

if '__doc__' in globals():
    AUTH_TYPES_CHOICES_TEXT = f'''
    Supported authentication types are:

    {", ".join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}
    '''

# Generated at 2022-06-21 13:23:27.035988
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'FAKE' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:36.004149
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(list(plugin_manager.get_auth_plugin_mapping().keys())))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. By default HTTPie tries to guess.

    ''',
)
auth.add_argument(
    '--auth-endpoint',
    metavar='ENDPOINT',
    help='''
    URL to be used to obtain an authentication token.

    ''',
)

# Generated at 2022-06-21 13:23:46.635342
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(iter(choices)) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    default='auto',
    help=f'''
        The authentication mechanism to be used.

        The argument is a comma-separated list of authentication
        mechanisms to be tried in order. The ``auto`` value can be used
        to try all a built-in mechanisms.

        The following mechanisms are currently supported:

            {plugin_manager.get_auth_plugin_mapping().keys()}

        See also: --auth-plugin.
        '''
)

# Generated at 2022-06-21 13:23:58.090389
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices.__iter__()



# Generated at 2022-06-21 13:24:10.780737
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())[0] in {'JsonAuth', 'DigestAuth'}


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    Can be one of:

    {plugins}

    '''
)

# Generated at 2022-06-21 13:24:13.318059
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    was_installed = False
    if 'foo' not in _AuthTypeLazyChoices():
        was_installed = plugin_manager.install_auth_plugin('foo')
    assert 'foo' in _AuthTypeLazyChoices()
    if was_installed:
        plugin_manager.uninstall_auth_plugin('foo')



# Generated at 2022-06-21 13:24:21.899235
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # ... needs to use
    #         sorted(plugin_manager.get_auth_plugin_mapping().keys())
    # and not just
    #         plugin_manager.get_auth_plugin_mapping().keys()
    # in order for the test to work under Python 2.
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())

_AuthTypeHelpScaffold = f'''
    Use one of the following authentication types, or specify an authentication
    plugin explicitly to use a custom authentication type:

        {", ".join(plugin_manager.get_auth_plugin_mapping().keys())}
    '''


# Generated at 2022-06-21 13:24:32.713579
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'oauth2' in choices
    assert 'basic' in choices
    assert len(choices) == len(plugin_manager.get_auth_plugin_mapping())
    assert sorted(choices)[0] == 'basic'
    assert sorted(choices)[1] == 'digest'
    assert sorted(choices)[2] == 'oauth2'
    assert [c for c in choices] == sorted(choices)



# Generated at 2022-06-21 13:24:35.053563
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    A = _AuthTypeLazyChoices
    assert [i for i in A()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:24:45.011969
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. It can be one of:

    {0}

    If not specified, an appropriate one is chose based on the --auth
    credentials, if any.

    '''.format(', '.join(_AuthTypeLazyChoices()))
)
auth.add_argument(
    '--auth-nonce',
    default=False,
    action='store_true',
    help='''
    Generate a random cnonce for each request. This is required for some buggy
    servers (see http://bugs.python.org/issue9797).

    '''
)

####################################################################

# Generated at 2022-06-21 13:25:14.098777
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) \
        == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication handler plugin.
    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    Disable sending the initial authentication challenge and instead use
    the supplied credentials for all requests.

    Useful for preventing sending a cookie stored in the session file, and
    instead use an Authorization header for all requests.

    ''',
)

#######################################################################

# Generated at 2022-06-21 13:25:15.174817
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    def run():
        A = _AuthTypeLazyChoices()
        for choice in A:
            assert choice in A
    run()

# Generated at 2022-06-21 13:25:20.557744
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()


auth_type_default = 'basic' if DEFAULT_AUTH else None
auth_type_help = (
    'The type of auth to use. '
    'Values parallel those of ``requests.auth.HTTPBasicAuth``, '
    '``requests.auth.HTTPDigestAuth``, etc. '
    f'Default: {auth_type_default}'
)
auth.add_argument(
    '--auth-type',
    default=auth_type_default,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=auth_type_help
)

# Generated at 2022-06-21 13:25:30.308668
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) == set(
        _AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The name of the auth plugin to use.
    {plugin_info}
    '''.format(plugin_info=plugin_info_string('auth'))
)

#######################################################################
# Cookies
#######################################################################

cookie = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:25:38.513796
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin (see "http --help-auth").

    ''',
)
auth.add_argument(
    '--ignore-netrc', '-n',
    action='store_true',
    default=False,
    help='''
    Do not use .netrc to look up authentication information.

    ''',
)

# Generated at 2022-06-21 13:25:39.638097
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-21 13:25:46.109027
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    type=lambda value: value.lower(),
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism for the request.

    To use the default mechanism, which is chosen based on the URL and
    --auth option, simply specify `--auth-type=auto'.

    To get a list of all available mechanisms, set --auth-type to `help'.

    ''',
)

# Generated at 2022-06-21 13:25:49.535587
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:56.730593
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    mapping = _AuthTypeLazyChoices()
    assert 'foo' in mapping  # This is not true but we fake it in the unit test


#######################################################################
# Miscellaneous
#######################################################################


# Generated at 2022-06-21 13:25:58.149279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert DEFAULT_AUTH_PLUGIN_NAME in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:26:41.947805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = list(_AuthTypeLazyChoices())
    assert items


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method
    (e.g. "digest", "edigest", "basic").'''
)
auth.add_argument(
    '--auth-group',
    metavar='NAME',
    help='''
    If using a vault, read authentication from vault\'s named auth group (see
    --auth-vault).'''
)

auth_vault = parser.add_argument_group(title='Auth Vault')

# Generated at 2022-06-21 13:26:50.909605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # noinspection PyUnresolvedReferences
    from tests.data.plugins.auth import TestAuthPlugin
    # noinspection PyUnresolvedReferences
    from tests.data.plugins.auth.digest import DigestAuthPlugin
    assert TestAuthPlugin.scheme in _AuthTypeLazyChoices()
    assert DigestAuthPlugin.scheme in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:52.614093
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert (OUT_REQ_HEAD) in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:00.119484
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert list(iter(auth_types)) == list(iter(auth_types))

auth_type_validator = AuthTypeValidator(
    'Must be one of: {choices}'
)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    type=auth_type_validator,
    help='''
    Specify an auth plugin by name.
    Use `--debug` to list all the available auth plugins
    (see: "HTTPie Plugins").

    '''
)

plugins_group = parser.add_argument_group(title='HTTPie Plugins')

# Generated at 2022-06-21 13:27:11.843755
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'Bearer' in choices
    assert 'hmac' in choices
    assert 'hawk' in choices
    assert 'aws4-hmac-sha256' in choices


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication mechanism to be used. Default is "auto" which uses the
    "Authorization" header if credentials are included in the URL, or prompts
    for them otherwise.
    Other supported types are: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add

# Generated at 2022-06-21 13:27:20.147606
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)
auth.add_argument(
    '--auth-type-force-override',
    action='store_true',
    help=SUPPRESS,
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='''
    Print a help message for the authentication plugin.

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:27:31.198910
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == tuple(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified authentication plugin.

    Plugins are registered via setuptools entry points in the
    "httpie.plugins.auth.v1" namespace.

    The default auth plugin is {default}.
    '''.format(default=DEFAULT_AUTH_PLUGIN),
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:27:34.930060
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'oauth2' in _AuthTypeLazyChoices()
    assert 'xyz' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:43.969294
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism, one of {0}.

    Use --auth-type=help to list the parameters for the specified TYPE.

    E.g. for Basic auth:

        https://{host} --auth-type=basic --auth='username:password'

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Client cert
#######################################################################

client_cert = parser.add_argument_group

# Generated at 2022-06-21 13:27:46.587187
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping()
    )