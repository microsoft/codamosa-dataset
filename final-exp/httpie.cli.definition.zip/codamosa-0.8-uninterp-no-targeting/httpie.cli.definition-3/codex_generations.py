

# Generated at 2022-06-21 13:19:05.174738
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

# ``requests.auth`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the use of a specific authentication type.
    The default value is a guess determined by the auth prefix.
    '''
)


# Generated at 2022-06-21 13:19:06.466767
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert choices == plugin_manager.get_auth_plugin_mapping().keys()



# Generated at 2022-06-21 13:19:19.709125
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'hawk']

auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The builtin methods are: {0}
    '''.format(', '.join(sorted(_AuthTypeLazyChoices()))),

)

auth.add_argument(
    '--auth-plugin',
    metavar='PLUGIN_NAME',
    default=None,
    help='''
    The name of a plugin to be used for authentication.
    It must be already installed.
    ''',
)


#######################################################################
# Timeouts
################################################################

# Generated at 2022-06-21 13:19:22.715412
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    atlc = _AuthTypeLazyChoices()
    assert 'basic' in atlc


# Generated at 2022-06-21 13:19:24.785472
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:32.716566
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Check that everything works after lazy plugin loading."""
    assert 'basic' in _AuthTypeLazyChoices()

auth._AuthTypeAction.choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    help='''
    The authentication mechanism. If not provided, HTTPie will attempt to use
    the most secure mechanism available.

    ''',
)

auth.add_argument(
    '--digest',
    action='store_true',
    help='''
    Use HTTP Digest Authentication. This is the default authentication method
    when no --auth-type is provided.

    ''',
)


# Generated at 2022-06-21 13:19:35.304775
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "basic" in _AuthTypeLazyChoices()
    assert "gss" not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:45.303565
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES[0],
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an auth type. The default is "basic".

    ''',
)


#######################################################################
# Plugins
#######################################################################

plugins = parser.add_argument_group(title='Plugins')

plugins.add_argument(
    '--debug-plugins',
    action='store_true',
    help='''
    Allow loading of development plugins from the current directory.

    ''',
)


# Generated at 2022-06-21 13:19:57.527889
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())  # noqa

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help='''
    Authentication scheme to use. Currently supported: {0}.

    '''.format(', '.join(auth_type_choices))
)

# Generated at 2022-06-21 13:20:09.831024
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_plugin_name = 'test_plugin'
    plugin_manager.get_auth_plugin_mapping()[test_plugin_name] = None
    assert test_plugin_name in _AuthTypeLazyChoices()
    del plugin_manager.get_auth_plugin_mapping()[test_plugin_name]
    assert test_plugin_name not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:18.094598
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'hmac' in auth_type_choices
    assert 'ntlm' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'bearer' in auth_type_choices
    assert 'jwt' in auth_type_choices

    for auth_type in auth_type_choices:
        assert auth_type in plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-21 13:20:19.779488
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:21.687737
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:31.325515
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()] == list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:20:40.990518
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'http' in list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:20:44.755770
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import string
    assert all(isinstance(x, str) and x in string.ascii_letters for x in _AuthTypeLazyChoices())
    assert list(_AuthTypeLazyChoices()) == _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:55.910713
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('digest')


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism. Supported plugins:

    {plugins}

    '''.format(
        plugins='\n'.join(
            '{name} - {description}'.format(name=name, **data)
            for name, data in
            plugin_manager.get_auth_plugin_mapping().items()
        )
    )
)
auth.add_argument(
    '--auth-hide', action='store_true', default=True,
    help='''
    Hide password when logging the HTTP request.'''
)

#######################################################################
#

# Generated at 2022-06-21 13:21:02.952863
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. The default is "basic", but in some cases
    (e.g., when the server uses Windows Authentication) "digest" might be
    needed.

    '''
)

_auth_plugin_type_help = '''
    Specify an auth plugin type.

    You can define it using one of the following:

        * <AUTH_PLUGIN_TYPE>

        * <AUTH_PROVIDER>/<AUTH_PLUGIN_TYPE>

        * <AUTH_PROVIDER>/<AUTH_MODULE_PATH>

    '''.strip()

# Generated at 2022-06-21 13:21:04.514406
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:05.959284
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:22.922157
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth_type_validator = AuthTypeValidator(
    'Auth type must be one of: {0}.'.format(
        _AuthTypeLazyChoices(),
    )
)
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=auth_type_validator,
    choices=_AuthTypeLazyChoices(),  # Lazy evaluated
    help='''
    Auth types: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)
auth.add_argument(
    '--auth-plugin',
    type=AuthPluginValidator(),
    help=SUPPRESS
)
auth.add_argument

# Generated at 2022-06-21 13:21:32.554185
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins.builtin import AuthPlugin

    class FooAuthPlugin(AuthPlugin):
        auth_type = 'foo'

    plugin_manager.register(FooAuthPlugin)
    assert list(_AuthTypeLazyChoices()) == ['foo', 'digest']
    plugin_manager.unregister(FooAuthPlugin)


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, e.g. 'digest' or 'jwt'.

    Run `http --auth-type=digest --help` for details.

    Run `http --debug --auth-type=digest --help` to see details for all
    installed auth types

    '''
)
auth.add_argument

# Generated at 2022-06-21 13:21:35.121208
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:21:36.497499
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), Iterable)


# Generated at 2022-06-21 13:21:44.234287
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(
        _AuthTypeLazyChoices()
    )

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication mechanism.

    By default, HTTPie tries to detect the auth type from the --auth option,
    which needs to be URL encoded if credentials contain colons.

    Alternatively, you can force a specific auth type by setting this option,
    for example: --auth-type=basic.

    '''
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='Print help for each supported auth type and exit.'
)

#######################################################################
# Cookies

# Generated at 2022-06-21 13:21:47.991475
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = list(_AuthTypeLazyChoices())
    assert choices == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:21:52.662685
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__(HttpAuthPluginController.SCHEME)
    _AuthTypeLazyChoices().__contains__('NOT_EXIST_AUTH_TYPE')

# Generated at 2022-06-21 13:22:02.489972
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass


# Generated at 2022-06-21 13:22:13.877605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to use. It can be either a fully qualified name of the
    plugin module, or the name of an auth plugin (such as digest) that is
    already activated.

    Use --debug to see all available auth plugins.

    '''
)

# Generated at 2022-06-21 13:22:18.051868
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'oauth1',
        'oauth2'
    ] == list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:22:34.264613
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_choices
    assert 'digest' in auth_choices


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=strtobool,
    choices=_AuthTypeLazyChoices(),
    help='''
    The default is "basic".

    ''',
)


auth.add_argument(
    '--auth-host',
    metavar='HOST',
    default=None,
    help='''
    The host for which the auth credentials apply.

    '''
)

# Generated at 2022-06-21 13:22:44.463387
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # noqa: D103
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:22:55.014017
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:06.705851
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The set of available types varies
    between installations. Run ``http --debug`` to see the list.

    '''
)

# Generated at 2022-06-21 13:23:10.114674
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    value_true = 'basic'
    value_false = 'does_not_exist'
    assert value_true in _AuthTypeLazyChoices()
    assert value_false not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:13.878060
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basicaaa' not in _AuthTypeLazyChoices()

PLUGIN_HELP_TEMPLATE = '''
**Auth plugin**: `{name}`

{docstring}

'''



# Generated at 2022-06-21 13:23:21.408618
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        list(_AuthTypeLazyChoices()) ==
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

auth.add_argument(
    '--auth-type',
    type=AuthCredentials,
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. Can be one of:
    {{{plugin_manager.get_auth_plugin_mapping().keys()}}}

    Defaults to "basic".

    ''',
)

# Generated at 2022-06-21 13:23:22.811078
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:27.632801
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the plugin for handling the supplied credentials for HTTP
    authentication. Normally HTTPie can guess this information from the supplied
    credentials. The default is {DEFAULT_AUTH_PLUGIN_NAME}. To see a list of
    available plugins, run:

        $ http --help-auth

    Plugins can also be specified using URLs -- e.g.

        $ http --auth-type=netrc https://httpbin.org/basic-auth/user/passwd

    '''
)


# Generated at 2022-06-21 13:23:37.609906
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert hasattr(choices, '__iter__')
    assert hasattr(choices, '__contains__')
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:24:03.583365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    kwargs = {
        'metavar': 'TYPE[:PATH_OR_DATA]',
        'help': f'''
        TYPE can be one of:

            {', '.join(_AuthTypeLazyChoices())}

        The plugin is enabled only for the current request. Unless --session is
        set, the state is not persisted.
        The plugin may read extra data from PATH_OR_DATA
        or stdin if PATH_OR_DATA is "-".

        '''
    }
    arguments.add_plugin_argument(auth, 'auth', **kwargs)


#######################################################################
# Configuration
#######################################################################

config = parser.add_argument_group(title='Configuration')

config.add_argument(
    '--config',
    type=Path
)


# Generated at 2022-06-21 13:24:15.532612
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(list(AuthPluginManager.AUTH_PLUGIN_MAPPING.keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to be used. If ``auto`` (default), then the
    authentication method is inferred from the provided credentials, or the
    server response.

    Supported types:

        {0}

    '''.format(', '.join(sorted(AuthPluginManager.AUTH_PLUGIN_MAPPING.keys())))
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-21 13:24:23.456447
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Used to test init of _AuthTypeLazyChoices class
    assert list(_AuthTypeLazyChoices()) == [
        'aws',
        'bearer',
        'digest',
        'hawk',
        'netrc',
        'oauth1',
        'smb',
        'token',
    ]
    # TODO: Test with plugins
    # Test __contains__
    assert 'aws' in _AuthTypeLazyChoices()
    # Test __contains__
    assert 'basic' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:33.570995
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),  # Needed for plugin testing
    help='''
    The authentication mechanism to be used. Defaults to auto,
    which means that the mechanism will be guessed based on the provided URL.

    '''
)

# Generated at 2022-06-21 13:24:39.186849
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    all_types = set(_AuthTypeLazyChoices())
    assert all_types

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.make_plugin_choices_validator(
        AuthPlugin,
        error_template='{name}: {error}',
    ),
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    HTTPie can guess the authentication type by inspecting the credentials.
    Supported types: basic, digest.

    '''.format(name='{name}')
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:24:47.474282
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """Check that the choices are not hard-coded."""
    assert 'foo' not in _AuthTypeLazyChoices()
    assert 'bar' not in _AuthTypeLazyChoices()

    class FakeAuthPlugin(AuthPlugin):
        auth_type = 'foo'

    class FakeAuthPlugin2(AuthPlugin):
        auth_type = 'bar'

    plug = FakeAuthPlugin()
    plugin_manager.register(plug)
    plug2 = FakeAuthPlugin2()
    plugin_manager.register(plug2)

    assert 'foo' in _AuthTypeLazyChoices()
    assert 'bar' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:48.454880
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


# Generated at 2022-06-21 13:24:57.036374
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='The auth type to use for the request.'
)

auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    help='''
    Do not send auth credentials unless the server explicitly
    requested them via 401.
    '''
)


# Generated at 2022-06-21 13:25:02.309897
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import tempfile
    from httpie.plugins import plugin_manager

    assert 'Plugin-0' in plugin_manager.get_auth_plugin_mapping()

    with tempfile.TemporaryDirectory() as plugins_dir:
        plugin_manager.load_directory(plugins_dir)
        assert 'Plugin-0' not in plugin_manager.get_auth_plugin_mapping()

        with pytest.raises(
                argparse.ArgumentError,
                match=r'invalid choice: \'Plugin-0\' \(choose from Plugin-1\)'
        ):
            auth_type_lazy_choices = _AuthTypeLazyChoices()
            [name for name in auth_type_lazy_choices if name == 'Plugin-0']


# Generated at 2022-06-21 13:25:08.975694
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for t in _AuthTypeLazyChoices():
        pass

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    For example, to use the `hawk` auth mechanism, which is provided by the
    `httpie-hawk` plugin, you would pass:

        --auth-type=hawk

    '''
)


# Generated at 2022-06-21 13:25:50.156228
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:25:57.450000
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

_ = auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth type to be used.

    By default, the plugin is inferred from the URL, or the HTTP 401 response.
    Use this option to override the default.

    Plugin names:

        {" ".join(plugin_manager.get_auth_plugin_mapping().keys())}

    See also: {_plugin_docs_section}#writing-plugins-for-custom-auth-types.

    ''',
)


# Generated at 2022-06-21 13:26:02.933591
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']

auth_plugin_names = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP.getdefault(
        '--auth-type'
    ),
    choices=auth_plugin_names,
    help='''
    Specify an HTTP auth type (basic, digest).

    '''
)
auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_type',
    default=AUTH_PLUGIN_MAP.getdefault(
        '--auth-plugin'
    ),
    choices=auth_plugin_names,
    help=SUPPRESS
)

# Generated at 2022-06-21 13:26:12.761795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use. The value is a plugin name, such as
    "basic", "digest". HTTPie comes with the following plugins:

        {0}

    Third-party plugins can be installed from PyPI. Like, for example:

        $ pip install httpie-aws-auth

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


# Generated at 2022-06-21 13:26:22.011591
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    metavar='AUTH_TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom auth plugin.

    Available plugins:
    {plugin_list}

    '''.format(
        plugin_list='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-21 13:26:30.248839
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'oauth2' not in auth_type_lazy_choices
    assert list(auth_type_lazy_choices) == ['basic', 'digest', 'oauth1']


# Generated at 2022-06-21 13:26:31.845537
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices


# Generated at 2022-06-21 13:26:39.674609
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the auth type. Supported auth types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)
auth_type.add_argument(
    '--no-auth-type',
    action='store_true',
    default=False,
    help='''
    Do not use an auth plugin.

    '''
)


# Generated at 2022-06-21 13:26:42.517434
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    assert AuthPlugin in plugin_manager.get_auth_plugin_mapping().values()
    assert 'plugin' in auth_type_lazy_choices


# Generated at 2022-06-21 13:26:51.322912
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    for choice in choices:
        assert choice in choices
        assert choice in plugin_manager.get_auth_plugin_mapping()
    assert 'xxx' not in choices
    assert 'xxx' not in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified auth type, e.g. "digest".

    '''
)

# Generated at 2022-06-21 13:28:00.125552
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()] == ['basic']

# Generated at 2022-06-21 13:28:09.929172
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to use.

    If you want to learn more about plugins, run:

        $ http --docs-plugins

    ''',
)
auth.add_argument(
    '--auth-scheme',
    dest='auth_plugin_args',
    action='append',
    help='''
    Specify the auth scheme to use. If a plugin implements
    multiple schemes, this option is required.

    ''',
)

# Generated at 2022-06-21 13:28:20.313228
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()
    # assert 'ntlm' in _AuthTypeLazyChoices()  # auth_ntlm 0.3.0 is broken
    assert 'aws' in _AuthTypeLazyChoices()
    assert 'aws-sigv4' in _AuthTypeLazyChoices()
    # assert 'aws-sigv4-header' in _AuthTypeLazyChoices()  # auth_aws-sigv4 1.0.0 is broken
    assert 'aws-sigv4-nocreds' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:28:21.517760
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AUTH_PLUGIN_JSON in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:28:32.691564
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    for choice in choices:
        assert choice in choices


# Generated at 2022-06-21 13:28:39.919275
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # TODO: Py3.7: assertCountEqual
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())


    # Needed for plugin testing
auth = parser.add_argument_group(title='Authentication')

# Generated at 2022-06-21 13:28:48.371325
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    try:
        assert 'basic' in auth_types
    except AssertionError:
        print('unit test for method __contains__ of class _AuthTypeLazyChoices is failed')
        raise

auth.add_argument(
    '--auth-type',
    default='auto',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism. The default is "auto", which means that
    HTTPie will attempt to find the most secure mechanism supported by
    the server. Other supported values include "basic" (default),
    "digest", and "NTLM".

    ''',
)

# Generated at 2022-06-21 13:28:49.494601
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:28:56.200460
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # pylint: disable=expression-not-assigned
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    An incomplete list of options includes "basic", "digest", "aws", "hawk",
    "netrc", "ntlm" and "oauth1".

    '''
)

#######################################################################
# SSL
#######################################################################

ssl_verify = parser.add_argument_group(title='SSL Options')

# Generated at 2022-06-21 13:28:59.221736
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'noauth' in _AuthTypeLazyChoices()
