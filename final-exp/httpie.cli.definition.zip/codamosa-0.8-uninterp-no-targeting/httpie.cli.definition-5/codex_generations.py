

# Generated at 2022-06-21 13:18:57.615318
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    GIVEN _AuthTypeLazyChoices instance WHEN __iter__ called THEN return list of values
    """
    authTypeLazyChoices = _AuthTypeLazyChoices()
    assert ['basic', 'digest', 'hawk', 'netrc'] == list(authTypeLazyChoices)


# Generated at 2022-06-21 13:19:02.998814
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    return type(_AuthTypeLazyChoices()) is list


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Only relevant when --auth is also used.
    The only built-in mechanism is "basic".
    See "http --help-auth" for a list of installed plugins.

    '''
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    # Not used in code but useful for documentation generation.
    metavar='PLUGIN',
    help='\b'
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:19:04.890940
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(iter(_AuthTypeLazyChoices()), '__iter__')

# Generated at 2022-06-21 13:19:06.200111
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'browser' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:11.126534
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified HTTP authentication type.

    {choices}

    By default, HTTPie tries to detect the correct
    authentication type.

    '''.format(
        choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip()) for line in
            wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)

#######################################################################
# HTTPS


# Generated at 2022-06-21 13:19:13.389365
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    return (assertRaises(TypeError)
            if _AuthTypeLazyChoices() == 17 else True)

# Generated at 2022-06-21 13:19:21.173198
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Check if _AuthTypeLazyChoices.__iter__() returns all items in plugin_manager.get_auth_plugin_mapping()."""

    m = plugin_manager.get_auth_plugin_mapping()
    m._plugins_cache = [DummyPlugin(name) for name in m._cache]
    auth_type_choices = _AuthTypeLazyChoices()
    assert len(list(iter(auth_type_choices))) == len(m._cache)
    for item in m._cache:
        assert item in auth_type_choices

# Generated at 2022-06-21 13:19:30.541975
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for _ in _AuthTypeLazyChoices():
        pass


auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of the provided credentials. The following types are supported:

      {plugin_manager.get_auth_plugin_list_as_str(80)}

    The default is "{DEFAULT_AUTH_PLUGIN}".

    ''',
)

# Generated at 2022-06-21 13:19:41.786068
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) == set(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default='basic',
    type=str,
    choices=_AuthTypeLazyChoices(),
    metavar='NAME',
    help='''
    The authentication mechanism to be used. It must be one of:

        {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Network
#######################################################################

network = parser.add_argument_group(title='Network')


# Generated at 2022-06-21 13:19:53.375326
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class TestAuthPlugin(AuthPlugin): pass
    with plugin_manager.context(TestAuthPlugin()):
        AuthTypeLazyChoices()
    with plugin_manager.context(TestAuthPlugin()):
        assert 'test' in AuthTypeLazyChoices()
        assert 'madeup' not in AuthTypeLazyChoices()

AuthTypeLazyChoices = _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:59.087064
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:01.093335
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))

# Generated at 2022-06-21 13:20:11.569694
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'JWTAuth' in choices
    assert 'AWSRequestV4' in choices
    assert 'AWSRequestV2' in choices
    assert 'AWSCredentials' in choices
    assert 'AdobeToken' in choices

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. By default, the appropriate mechanism is
    guessed based on the provided credentials.

    '''
)

# Generated at 2022-06-21 13:20:24.205270
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1']

auth.add_argument(
    '--auth-type',
    # Tuple is needed for Python <= 3.5 to work (comprehension)
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use. The available plugins are:

    ''' + (
        '\n    '.join(
            (' ' * 20) + ', '.join(sorted(auth_plugins))
            for auth_plugins in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        )
    ),
)

#######################################################################
# Compression
#######################################################################



# Generated at 2022-06-21 13:20:32.982454
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. Default is "auto", which is HTTPie's
    flexible auto-detection based on the URL and whether the auth data
    is given on the command line or in a config file.

    Available mechanisms are:

    {plugin_manager.get_auth_help().rstrip()}
    '''
)


#######################################################################
# Config file
#######################################################################

config = parser.add_argument_group(title='Configuration')

# Generated at 2022-06-21 13:20:34.590723
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:45.069947
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    for auth_type in plugin_manager.get_auth_plugin_mapping():
        assert auth_type in lazy_choices
    assert '__AUTO__' in lazy_choices
    assert 'non_existing_auth_type' not in lazy_choices


_auth_type_validator = AuthTypeValidator(
    'Auth type is invalid. Check %(dest)s list for available auth types.'
)

# Generated at 2022-06-21 13:20:47.977188
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'oauth1', 'hawk']


# Generated at 2022-06-21 13:20:58.618483
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    return 'Basic' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used (takes a plugin name).
    For example: "digest".

    ''',
)

#######################################################################
# Proxies
#######################################################################

proxies = parser.add_argument_group(title='Proxying')

# Generated at 2022-06-21 13:21:02.198167
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:17.581845
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from requests.auth import HTTPBasicAuth
    from httpie.plugins.auth.basic import BasicAuthPlugin

    plugin_manager.register(BasicAuthPlugin)

    assert HTTPBasicAuth in _AuthTypeLazyChoices()

    plugin_manager.deregister('basic')


# The default value of this argument is processed in a custom way.
auth_plugin = auth.add_argument(
    '--auth-type', '-t',
    metavar='NAME',
    action=LazyAuthPluginChoices,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an auth plugin for advanced/custom authentication.
    Overrides --auth.

    '''
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-21 13:21:18.943978
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-21 13:21:24.308967
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices())

auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:30.104121
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import httpie.plugins
    from httpie.plugins import builtin

    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert choices.__contains__('basic')
    for plugin_class in (builtin.BasicAuthPlugin,
                         builtin.DigestAuthPlugin,
                         builtin.BearerTokenAuthPlugin,
                         httpie.plugins.plugin.AuthPlugin):
        assert plugin_class.auth_type in choices


# Generated at 2022-06-21 13:21:39.230350
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(AVAILABLE_AUTH_PLUGINS)


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication type (default is "auto"). Currently supported
    types: {", ".join(AVAILABLE_AUTH_PLUGINS)}.
    ''',
)

#######################################################################
# HTTPie plugins.
#######################################################################

parser.add_argument(
    '--debug',
    action='store_true',
    help=argparse.SUPPRESS
)


# Generated at 2022-06-21 13:21:41.286882
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:55.413128
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert bool(_AuthTypeLazyChoices()) is True

auth.add_argument(
    '--auth-type', '--auth-types',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of authentication used: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}.
    By default, HTTPie tries to detect the authentication type based on
    the server's authentication challenge.

    '''
)


# Generated at 2022-06-21 13:21:58.147636
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'Custom' not in choices


# Generated at 2022-06-21 13:22:10.616124
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert sorted(['basic', 'digest']) == sorted(_AuthTypeLazyChoices())

auth_type = auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    metavar='TYPE',
    help='''
    The authentication mechanism. By default, HTTPie looks for a plugin
    implementing the provided TYPE.

    This can be used to invoke an authentication plugin without specifying
    a username, i.e., "http --auth-type=digest".

    '''
)

# Generated at 2022-06-21 13:22:12.103288
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:29.690140
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert next(_AuthTypeLazyChoices()) == 'digest'

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. The default is '{AUTO_AUTH_TYPE}',
    which means that HTTPie tries to automatically detect the correct auth
    type from the URL and the server response.

    If the type cannot be determined automatically, you can use this option to
    explicitly specify the auth type. Available types are:

    {auth_type_list}

    '''
)

#######################################################################
#
# HTTP
#
#######################################################################

http = parser.add_argument_group(title='HTTP')


# Generated at 2022-06-21 13:22:31.772505
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'basic']



# Generated at 2022-06-21 13:22:44.146815
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The auth mechanism to be used. The default is "basic".
    HTTPie can handle any auth mechanism that the underlying requests library
    can handle. If a custom auth type is used (i.e., one that isn't built-in)
    but there is no requests auth plugin installed for it, then HTTPie will
    fall back to `--auth-type=basic`.

    '''
)

# Generated at 2022-06-21 13:22:54.687255
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_list = list(_AuthTypeLazyChoices())

auth_type_choice = _AuthTypeLazyChoices()
auth_type_help = '''
    The authentication type. If not specified, an attempt is made to guess it.
    The following values are accepted:

    {auth_types}

    '''.format(
    auth_types='\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(auth_type_choice), width=60)
    ).strip()
)
auth.add_argument(
    '--auth-type',
    help=auth_type_help,
    choices=auth_type_choice
)

#######################################################################
# Config
#######################################################################

config = parser.add_argument_group

# Generated at 2022-06-21 13:23:06.660012
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert('basic' in auth_type_lazy_choices)
    assert(sorted(list(auth_type_lazy_choices)) == ['basic'])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. The following authentication
    plugins are available:

    {plugin_manager.get_auth_plugin_help()}

    '''
)

#######################################################################
# Custom headers
#######################################################################

headers = parser.add_argument_group(title='Custom Headers')

# Generated at 2022-06-21 13:23:15.994890
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    plugin_manager.load_auth_plugins()
    assert list(choices) == ['basic', 'digest']


# Generated at 2022-06-21 13:23:18.591977
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'custom' in choices
    assert 'non-existant' not in choices



# Generated at 2022-06-21 13:23:29.318798
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Name of the auth plugin to use. By default, the appropriate plugin is
    inferred from the provided credentials.

    Select from:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-21 13:23:39.563753
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy = _AuthTypeLazyChoices()
    for i in sorted(plugin_manager.get_auth_plugin_mapping().keys()):
        assert i in lazy
    assert 'does_not_exist' not in lazy



auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    By default, the authentication method is inferred from the provided
    credentials. This option can be used to explicitly specify an
    authentication method.
    ''',
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-21 13:23:45.960004
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert {'digest', 'jwt'}.issubset(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used with --auth.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Disables automatic authentication challenge response (useful with NTLM to
    avoid an extra round-trip).

    ''',
)


# Generated at 2022-06-21 13:24:03.636942
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    t = _AuthTypeLazyChoices()
    assert 'basic' in t # Only if 'basic' auth is available.
    assert 'digest' in t # Only if 'digest' auth is available.
    assert 'non-existent' not in t

# Generated at 2022-06-21 13:24:06.759906
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:24:09.337258
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert issubclass(_AuthTypeLazyChoices.__iter__, collections_abc.__iter__)


# Generated at 2022-06-21 13:24:19.162421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


_auth_type_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:20.590168
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert AVAILABLE_AUTHS == [item for item in _AuthTypeLazyChoices()]

# Generated at 2022-06-21 13:24:31.857676
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication scheme to be used. This is usually handled automatically,
    but in some cases, such as when HTTPie is used without a terminal
    (piped to `less` or to a file), it may be necessary to specify it
    explicitly.

    '''
)

# Generated at 2022-06-21 13:24:39.753333
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default (i.e., when
    --auth is also used), it's guessed based on the provided credentials.
    Available mechanisms: %(choices)s.

    ''',
)
auth.add_argument(
    '--auth-type-insensitive',
    action='store_true',
    help='''
    Ignore case when specifying --auth-type.

    '''
)

# Generated at 2022-06-21 13:24:47.914021
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    actual = list(_AuthTypeLazyChoices())
    assert actual == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify a custom auth plugin to be used instead of the default one.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Do not perform challenge response (i.e., send the credentials in the
    initial request).

    '''
)


# Generated at 2022-06-21 13:24:50.606192
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert choices and list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:24:58.329209
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(['basic', 'digest']))


auth.add_argument(
    '--auth-type',
    metavar=('basic'
             '|digest'
             '|{auth_plugins}'.format(
                 auth_plugins='|'.join(plugin_manager.get_auth_plugin_mapping()))),
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism.
    By default, the authentication mechanism is guessed based on the --auth
    option value.
    The following auth types are supported:

        {', '.join(sorted(AUTH_PLUGIN_MAP.keys(), key=lambda x: x != 'digest'))}

    ''',
)

################################

# Generated at 2022-06-21 13:25:44.338476
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == list(choices)  # test that iter() is idempotent
    assert list(choices)[:] in ([], ['digest'], ['basic'], ['digest', 'basic'])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is basic.
    Supported types: {auth_types}

    '''.format(
        auth_types=format_choices_list(
            sorted(plugin_manager.get_auth_plugin_mapping())
        ),
    )
)

# Generated at 2022-06-21 13:25:47.907830
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:58.768627
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == plugin_manager.get_auth_plugin_mapping().keys()



# Generated at 2022-06-21 13:26:09.745675
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


#######################################################################
# Proxies
#######################################################################

proxies = parser.add_argument_group(title='Proxies')
proxies.add_argument(
    '--proxy', '-p',
    default=None,
    metavar='PROTOCOL://HOST[:PORT]',
    help='''
    If only the host is provided (-p host:port), HTTPie will prompt
    for the username and password.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:26:17.387164
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'basic' in instance
    assert 'digest' in instance
    assert 'zalando' in instance
    assert 'aws' in instance
    assert 'aws-sigv4' in instance
    assert 'jwt' in instance
    assert 'oauth1' in instance
    assert 'hmac' in instance
    assert 'foo' not in instance
    assert 'awssigv4' not in instance
test__AuthTypeLazyChoices___contains__()


# Generated at 2022-06-21 13:26:18.986082
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('digest')



# Generated at 2022-06-21 13:26:27.790057
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The auth mechanism to use.

    Currently supported mechanisms:

        {_list_auth_plugins()}

    Other auth mechanisms can be added via plugins.

    '''
)

#######################################################################
# SSL/TLS
#######################################################################

ssl = parser.add_argument_group(title='SSL/TLS')


# Generated at 2022-06-21 13:26:30.053804
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'fail' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:38.260181
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Supported types are:

        {choices}

    '''.format(
        choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    ),
)

# Generated at 2022-06-21 13:26:44.224115
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    metavar='{basic,digest,etc.}',
    default='basic',
    type=PluginManager.get_auth_plugin_mapping,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The following values are
    supported:

        {0}

    '''.format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)


# Generated at 2022-06-21 13:27:50.483558
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:27:59.204988
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class _Choice:
        def __contains__(self, item):
            return False

    choices = _Choice()
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices.__iter__(choices))



# Generated at 2022-06-21 13:28:08.892279
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # type: () -> None
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_validator = AuthTypeValidator('Unsupported auth type.')


# Generated at 2022-06-21 13:28:10.235910
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list(str(_AuthTypeLazyChoices()))

# Generated at 2022-06-21 13:28:20.439805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager_real = plugin_manager
    plugin_manager_mock = Mock()
    plugin_manager_mock.get_auth_plugin_mapping.return_value = {'x': 'y', 'a': 'b'}
    try:
        # Replace the global `plugin_manager` for the duration of the test only.
        globals()['plugin_manager'] = plugin_manager_mock
        assert list(_AuthTypeLazyChoices()) == ['a', 'x']
    finally:
        globals()['plugin_manager'] = plugin_manager_real  # Restore


# Generated at 2022-06-21 13:28:31.566194
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), SortedItems)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this option to specify a non-standard
    authentication method.

    These are the currently available auth plugin names:

      {available_auth_types}

    '''.format(
        available_auth_types='\n      '.join(
            wrap(', '.join(sorted(_AuthTypeLazyChoices())),
                 initial_indent=8*' ',
                 subsequent_indent=8*' ',
                 width=60)
        )
    )
)

# Generated at 2022-06-21 13:28:39.221761
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test = _AuthTypeLazyChoices()
    assert 'basic' in test
    assert 'digest' in test
    assert 'plugin_plugin' not in test
    assert 'plugin_plugin' in plugin_manager.get_auth_plugin_mapping()
    assert 'plugin_plugin' not in test


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. Use `--debug` to show the
    available auth plugins.

    '''
)

# Generated at 2022-06-21 13:28:44.760603
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )



# Generated at 2022-06-21 13:28:52.982266
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force a custom auth plugin to be used.

    Choices:

        The built-in auth plugins: {builtin_plugins}.

        The ones that you've installed in your Python environment:
        {available_plugins}.

    '''.format(
        builtin_plugins=', '.join(BUILTIN_AUTH_PLUGINS),
        available_plugins=', '.join(plugin_manager.get_auth_plugin_names()),
    )
)


#######################################################################
# SSL