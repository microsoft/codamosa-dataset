

# Generated at 2022-06-21 13:19:08.459056
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) == set(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to perform.
    The options are: '{0}'.

    '''.format("', '".join(sorted(_AuthTypeLazyChoices())))
)

# Generated at 2022-06-21 13:19:20.266235
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == _AuthTypeLazyChoices.__iter__(None)  # noqa: E501

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to use.
    Default is to auto-detect from URL and auth credentials.
    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    help='''
    Disable automatic sending of Basic/Digest auth credentials in response to
    a 401/407 challenge.

    '''
)

#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-21 13:19:30.082828
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.cli.utils import display
    from pprint import pprint

    with display.temp_disabled():
        pprint(list(_AuthTypeLazyChoices()))


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. By default, HTTPie chooses the first available
    mechanism among the Basic, Digest, and OAuth.

    The default choice can be overridden by supplying this option to the
    command, e.g., --auth-type=digest.

    ''',
)

# Generated at 2022-06-21 13:19:41.451079
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

    from httpie.plugins import get_async_plugin_manager, get_plugin_manager

    def mock_get_plugin_manager(*args, **kwargs):
        plugin_manager = get_plugin_manager()
        plugin_manager.plugin_manager_exception_class = args[0]
        return plugin_manager


# Generated at 2022-06-21 13:19:49.184009
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Iterable)



# Generated at 2022-06-21 13:20:01.912481
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Default: "basic".

    The name of the auth plugin to use. See the documentation of the
    corresponding plugin for details. The plugin name is case insensitive.

    The following auth plugins are available:

    {plugin_documentation}

    '''.format(plugin_documentation=plugin_manager.get_auth_plugin_docs())
)



# Generated at 2022-06-21 13:20:12.012465
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices() == set(plugin_manager.get_auth_plugin_mapping().keys())

_lazy_choices = _AuthTypeLazyChoices()

auth_types_help = wrap(
    '''
    Use the specified HTTP auth scheme. Valid built-in schemes are:

        {builtin_auth_types}

    {plugins_help}
    '''.format(
        builtin_auth_types=', '.join(
            sorted(httpie.plugins.auth.BUILTIN_AUTH_TYPES)
        ),
        plugins_help=plugin_manager.plugins_help('auth'),
    ),
    width=78,
    initial_indent=' ' * 4,
    subsequent_indent=' ' * 4
)



# Generated at 2022-06-21 13:20:24.636908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:33.261815
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'oauth1']
# Autocompletion starts to work after the attribute is defined.
_AuthTypeLazyChoices.__doc__ = wrap(
    '''
    Selects the method of HTTP authentication. The default is 'basic'.
    The following methods are currently supported:

        {auth_methods}

    '''.format(
        auth_methods='\n'.join(
            '{0} {1}'.format(
                8 * ' ',
                line.strip()
            )
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys())), 30)
        ).strip()
    ),
    REPLACEMENTS
)


# Generated at 2022-06-21 13:20:43.940084
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The plugin that handles the supplied credentials. Plugins are found by
    their lower-case name.

    The default is "auto", which tries to guess the plugin based on
    the --auth option value.

    See 'http --help-auth' for details.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')

# Generated at 2022-06-21 13:20:59.034301
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for item in _AuthTypeLazyChoices():
        assert item in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-21 13:21:11.685493
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-type',
    type=str.lower,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.
    This affects both how the auth credentials are sent to the server
    and how the URL is parsed.

    Possible values for TYPE:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Most often, you wouldn't need to explicitly set this, as HTTPie
    can auto-detect most of the supported types.

    '''
)

# Generated at 2022-06-21 13:21:21.890413
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins.builtin import BasicAuthPlugin, DigestAuthPlugin
    plugin_manager.deregister(BasicAuthPlugin())
    plugin_manager.deregister(DigestAuthPlugin())
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:21:23.418561
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))
# Unittest for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-21 13:21:33.113154
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help='''
    Specify a custom auth plugin.

    Use `http --debug` to get a list of available builtin plugins.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_false',
    default=True,
    dest='auth_send_challenge',
    help='''
    Do not send an initial authentication challenge.

    '''
)

# Generated at 2022-06-21 13:21:35.313421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(list(defaults.AUTH_PLUGIN_MAP))

# Generated at 2022-06-21 13:21:38.123580
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    if 'HTTPBasicAuth' not in _AuthTypeLazyChoices():
        raise SystemExit(1)
    if 'SomethingUnknown' in _AuthTypeLazyChoices():
        raise SystemExit(1)



# Generated at 2022-06-21 13:21:51.446176
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for key in ['basic', 'digest']:
        assert key in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of HTTP authentication. If not specified, an appropriate
    one is guessed from the URL (e.g., for URLs starting with
    "https://", digest auth is used). You can force Basic or Digest
    auth by providing the corresponding value to this option.

    '''
)
auth.add_argument(
    '--auth-cert',
    default=None,
    metavar='CLIENT_CERT',
    help='''
    Path to the client SSL certificate to be used for authentication.

    '''
)

#######################################################################
# Output

# Generated at 2022-06-21 13:21:57.050323
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_types = _AuthTypeLazyChoices()
    assert 'Basic' in auth_types
    assert 'Digest' in auth_types
    assert 'NTLM' in auth_types
    assert 'fake' not in auth_types
    assert 'Fake' not in auth_types

# Generated at 2022-06-21 13:21:59.921701
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'random' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:22:09.629708
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))

# Generated at 2022-06-21 13:22:21.240423
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=AuthCredentials('', '').type,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin to use.
    The plugin must be installed. Run `http --debug' for a list of
    available plugins.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Do not use netrc to read ~/.netrc.

    '''
)

# Generated at 2022-06-21 13:22:31.772307
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(AuthTypeLazyChoices())

AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=AuthTypeLazyChoices,
    help='''
    Specify the authentication mechanism like:

        http --auth-type=basic --auth='username:password' example.org

    Available types are:

    {auth_types}

    '''.format(
        auth_types='\n    '.join(
            line.strip() for line in
            wrap(', '.join(sorted(AuthTypeLazyChoices)), 60)
        ).strip(),
    ),
)

#######################################################################
# Common options
#######################################################################

common_options = parser.add_argument_group(title='Common Options')

# Generated at 2022-06-21 13:22:38.383676
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth_type = auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Plugin to use for authentication. If not provided, the plugin will be
    inferred from --auth value, or the best available plugin will be tried.

    '''
)

auth.add_argument(
    '--auth-from-file',
    metavar='USER[:PASS]@FILENAME',
    help='''
    Same as --auth, but the credentials are read from a file.
    The credentials are read from the first line of the file.
    If the credentials contain a colon, they need to be provided in quotes,
    i.e. "user:password".

    '''
)

# Generated at 2022-06-21 13:22:39.703957
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__("basic")


# Generated at 2022-06-21 13:22:46.298098
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import AuthPlugin
    class DummyAuth(AuthPlugin):
        name = 'dummy-auth'
    try:
        plugin_manager.deregister_plugin_instances(DummyAuth)
        plugin_manager.register_plugin(DummyAuth)
        choices = _AuthTypeLazyChoices()
        assert list(choices) == ['dummy-auth']
    finally:
        plugin_manager.deregister_plugin_instances(DummyAuth)



# Generated at 2022-06-21 13:22:49.279917
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:22:57.780589
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    Select an authentication plugin, if more than one are found
    and the automatic choice (default) isn't satisfactory.
    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Specify the endpoint to use to obtain authentication tokens.
    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:23:08.432815
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    choices_iterator = iter(choices)
    assert next(choices_iterator) == "basic"
    assert next(choices_iterator) == "digest"
    assert next(choices_iterator) == "hawk"
    with pytest.raises(StopIteration):
        next(choices_iterator)


# Generated at 2022-06-21 13:23:10.755376
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a
    assert 'digest' in a
    assert 'foo' not in a

# Generated at 2022-06-21 13:23:34.410411
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used. The following plugins are available:

    {auth_plugins_doc}

    Use the --auth-type=help option to view the documentation for an
    authentication type.

    '''.format(
        auth_plugins_doc='\n'.join(
            '    ' + line for line in AUTH_PLUGINS_DOC.strip().splitlines()
        )
    )
)

# Generated at 2022-06-21 13:23:37.362072
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(
        _AuthTypeLazyChoices()
    ) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:23:38.925689
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'custom' in choices


# Generated at 2022-06-21 13:23:43.780295
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockPluginManager:
        def get_auth_plugin_mapping(self):
            return {'basic': object()}
    plugin_manager = MockPluginManager()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices

# Generated at 2022-06-21 13:23:51.516442
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(AUTH_PLUGIN_NAMES)

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_DEFAULT.name,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism. It can be (case-insensitive) name of
    one of the plugins, e.g. "digest", "ntlm", as well as the full module
    name, e.g. httpie.plugins.auth.basic.BasicAuthPlugin. Use
    `http --debug` to see a list of available plugins.

    '''
)


# Generated at 2022-06-21 13:24:03.851256
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type', '--auth-plugin',
    help='''
    Explicitly specify an auth plugin. Defaults to Basic.

    Available choices:

        {choices}

    '''.format(
        choices=',\n'.join(
            (8 * ' ') + choice
            for choice in _AuthTypeLazyChoices()
        )
    ),
    type=plugin_manager.make_auth_type_validator(),
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-21 13:24:15.712915
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class MyAuthPlugin(AuthPlugin):
        auth_type = 'my-auth-type'
        auth_require = True
        def get_auth(self, username, password):
            pass
    from httpie.auth import plugin_manager
    plugin_manager.register(MyAuthPlugin)
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, _AuthTypeLazyChoices)
    assert isinstance(iter(choices), type(iter([])))
    assert 'my-auth-type' in choices


# Generated at 2022-06-21 13:24:23.568738
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this flag to explicitly specify which authentication plugin to use.
    The flag value is the name of a plugin (e.g., basic, digest).
    Example: --auth-type=digest.

    '''
)

# Generated at 2022-06-21 13:24:33.658897
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    # Not using a pytest fixture here to make the test independent
    # of the content of the default plugin directory.

    plugin_manager._load_installed_plugins()

    assert 'basic' in _AuthTypeLazyChoices()
    assert 'OAuth2' in _AuthTypeLazyChoices()
    assert 'invalid' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:24:44.875754
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted([
        'basic', 'digest', 'foo', 'hawk', 'ntlm'
    ])

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an authentication plugin. Currently supported: basic, digest, hawk,
    ntlm, and foo (a dummy plugin used for testing).

    '''
)

# Generated at 2022-06-21 13:25:26.724803
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['Basic', 'Digest']) == sorted(list(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth type (auto, basic, digest, oauth1, oauth2, aws, or custom).

    '''
)



# Generated at 2022-06-21 13:25:35.640809
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:39.779974
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices
    assert 'DIGEST' in auth_type_lazy_choices
    assert 'nonsense' not in auth_type_lazy_choices



# Generated at 2022-06-21 13:25:46.219741
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. One of:

        {auth_type_choices}

    The "auto" value can be used to select the most secure mechanism based on
    the request URL.

    '''
        .format(
        auth_type_choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument

# Generated at 2022-06-21 13:25:47.990971
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # SUT
    lazy_choices = _AuthTypeLazyChoices()
    # Check whether item is in lazy_choices
    assert 'digest' in lazy_choices
    assert 'foo' not in lazy_choices

# Generated at 2022-06-21 13:25:50.991175
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lc = _AuthTypeLazyChoices()
    assert 'Basic' in lc
    assert 'Digest' in lc
    assert 'foo' not in lc

# Generated at 2022-06-21 13:25:52.643296
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Needed for plugin testing
    assert list(_AuthTypeLazyChoices()) == sorted(['digest', 'jwt'])

# Generated at 2022-06-21 13:25:59.549195
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:05.444755
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(_AuthTypeLazyChoices()) > 1

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin (or type). The default is to auto-detect
    the authentication type.

    Use --debug or --print=h to see the actual auth type being used.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    dest='allow_401_auth',
    help='''
    Don't let an HTTP 401 Not Authorized response trigger an HTTP Basic
    challenge.

    '''
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-21 13:26:07.438872
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:20.866019
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == ['Basic']

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used.

    Defaults to "auto", which means HTTPie will try to use the most secure
    method available to authenticate based on the information available.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Disable HTTP authentication challenge (and fail if the server tries to
    use one).

    ''',
)

#######################################################################
# SSL
################################

# Generated at 2022-06-21 13:27:32.732476
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an authentication handler. By default, HTTPie uses the
    authentication handler according to the provided scheme.

    The supported authentication handlers are:

        {', '.join(auth_plugin_mapping.keys())}

    The implementation of the Digest authentication handler is
    also available as a standalone httpie plugin:

        https://github.com/jkbrzt/httpie-digest-auth

    '''
)

# Generated at 2022-06-21 13:27:40.744244
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    The name of the auth plugin to use (default: "{DEFAULT_AUTH_PLUGIN_NAME}").

    The following auth plugins are built-in. Use "plugin install" to install
    others from the community repository.

        {formatted_plugin_list}

    '''.strip()
)


# Generated at 2022-06-21 13:27:42.295588
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:53.802340
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping()) == sorted(lazy_choices)
    assert plugin_manager.get_auth_plugin_mapping() == dict(lazy_choices)
    assert 'basic' in plugin_manager.get_auth_plugin_mapping()
    assert 'basic' in lazy_choices

auth.add_argument(
    '--auth-type',
    default=None,
    help='Override the auth plugin to use. Available options: '
         '{0}'.format(', '.join(plugin_manager.get_auth_plugin_mapping())),
    choices=_AuthTypeLazyChoices(),  # deferring the loading of plugins until the cmd is parsed
    metavar='AUTH_TYPE'
)

# Generated at 2022-06-21 13:28:01.347426
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='auth-type',
    type=plugin_manager.get_auth_plugin_class,
    default=plugin_manager.get_auth_plugin_class('basic'),
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used for the request, if any.

    This can be one of:
    {0}
    '''.format('\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
    ).strip())
)


# Generated at 2022-06-21 13:28:11.831433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    l = set(plugin_manager.get_auth_plugin_mapping().keys())
    assert set(_AuthTypeLazyChoices()) == l


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The supported types are:

    ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())) + '''


    '''
)

auth.add_argument(
    '--auth-nonce',
    nargs='?',
    type=_AuthNonceType,
    help='The nonce value to use in Digest authentication',
)



# Generated at 2022-06-21 13:28:21.239696
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    https://github.com/jakubroztocil/httpie/pull/489
    """
    import pytest
    from pytest import approx

    with pytest.raises(AssertionError) as excinfo:
        list(_AuthTypeLazyChoices())
    assert 'Plugin manager not initialized' in str(excinfo.value)

    from . import plugin
    plugin.plugin_manager = None
    assert list(_AuthTypeLazyChoices()) == []

    plugin.plugin_manager = plugin.PluginManager()
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'netrc', 'ntlm']


# Generated at 2022-06-21 13:28:32.436587
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('Basic')
    assert choices.__contains__('Digest')
    assert choices.__contains__('JWTAuth')
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'JWTAuth' in choices
    assert sorted(choices) == ['Basic', 'Digest', 'JWTAuth']
    assert list(choices) == ['Basic', 'Digest', 'JWTAuth']


# Generated at 2022-06-21 13:28:33.750583
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): assert 'AUTH_TYPE' in _AuthTypeLazyChoices()