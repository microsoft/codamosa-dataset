

# Generated at 2022-06-21 13:19:09.097134
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == AUTH_PLUGIN_NAMES


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method:

        {auth_type_list}

    The default value is `basic' if --auth is provided or `auto' otherwise.

    '''.format(
        auth_type_list='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(AUTH_PLUGIN_NAMES)), 60)
        ).strip(),
    )
)

# Generated at 2022-06-21 13:19:20.752149
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert sorted(choices) == ['basic', 'digest']


# Generated at 2022-06-21 13:19:22.803406
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    assert 'digest' in instance


# Generated at 2022-06-21 13:19:31.429387
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    Specify an custom auth plugin to use.
    The plugin is identified by its entry point name, which is the value of
    the ``AuthPlugin`` attribute of the plugin class.
    '''
)

auth_help = '''

The default auth plugin is Basic Auth and is used when no other auth plugin
is specified.

The list of available auth plugins is available with:

    $ http --debug

'''

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-21 13:19:37.989159
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "digest" in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication type (plugins).

    Available types:

    {format_auth_plugins()}
    '''
).completer = ListCompleter(
    plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:19:49.266103
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'force-digest',
    ]

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. By default, basic HTTP authentication
    is used. The following authentication mechanisms are supported:

    {auth_type_list}

    '''.format(
        auth_type_list='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
                60,
            )
        )
    )
)

################################################################

# Generated at 2022-06-21 13:20:01.970438
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    The authentication mechanism used by the plugin.
    The argument is the name of the authentication plugin.
    To see the list of the currently installed authentication plugins,
    use the --debug flag.
    ''',
)

auth.add_argument(
    '--auth-type',
    action=SubcommandFullPaths,
    metavar='',
    choices=SubcommandFullPaths.choices,
    help='''
    The authentication mechanism used by the plugin.
    The argument is the full path to the authentication plugin module.
    ''',
)


auth.add_argument

# Generated at 2022-06-21 13:20:06.500777
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'basic' in AuthTypeLazyChoices
    assert 'digest' in AuthTypeLazyChoices
    assert 'foo' not in AuthTypeLazyChoices


# Generated at 2022-06-21 13:20:14.080571
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar=None,
    help='''
    Explicitly specify a backend plugin for authentication to use. For example:

        --auth-type=digest

    Available types: {auth_types}

    '''.format(
        auth_types=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping())
        ).upper()
    ),
    type=lambda s: s.lower(),
    choices=_AuthTypeLazyChoices(),
)

#######################################################################
# Custom headers
#######################################################################

headers = parser.add_argument_group(title='Custom Headers')

# Generated at 2022-06-21 13:20:26.188365
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iterator = _AuthTypeLazyChoices()
    assert next(iterator) == 'auto'

_authtype_lazy_choices = _AuthTypeLazyChoices()

auth_plugin = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_authtype_lazy_choices,
    help='''
    Tells HTTPie which authentication plugin to use. See the documentation
    at https://httpie.org/plugins for plugin installation info.

    The default is "auto", which will try to auto-detect the provider.
    In most cases this will not be needed, and "Basic" would be the right choice.

    '''
)
auth_plugin.completer = plugin_manager.auth_plugin_com

# Generated at 2022-06-21 13:20:39.286643
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(AUTH_PLUGIN_TYPES))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin type.

    Use `http --debug` to find out the available auth plugins.

    '''
)

auth.add_argument(
    '--auth-plugin',
    metavar='MODULE_PATH',
    default=None,
    help='''
    Specify a custom path to an authentication plugin implementation.

    The auth plugin is a Python class that hooks into HTTPie.

    See https://httpie.org/plugins#authentication for details.

    '''
)


# Generated at 2022-06-21 13:20:41.342150
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:20:42.771398
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

# Generated at 2022-06-21 13:20:44.446692
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:20:46.789495
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'nonExistingPlugin' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:50.673896
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices."""
    # pylint: disable=no-self-use,protected-access
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-21 13:21:00.577759
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'implicit' in auth_type_lazy_choices
    assert 'bearer' in auth_type_lazy_choices
    assert 'non_existing' not in auth_type_lazy_choices

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=AUTH_PLUGIN_MAP['basic'].auth_type,
    help='''
    The authentication mechanism to be used.
    '''
)

# Generated at 2022-06-21 13:21:12.410776
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(set(_AuthTypeLazyChoices()))
    assert all(isinstance(x, str) for x in _AuthTypeLazyChoices())


# Generated at 2022-06-21 13:21:22.461297
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    with patch('httpie.cli.plugin_manager.get_auth_plugin_mapping') as mock_method:

        def mock_get_auth_plugin_mapping():
            return {'a': 'b'}

        mock_method.side_effect = mock_get_auth_plugin_mapping

        auth_type_choices = _AuthTypeLazyChoices()
        assert 'a' in auth_type_choices
        assert 'b' not in auth_type_choices
        assert list(auth_type_choices) == ['a']



# Generated at 2022-06-21 13:21:31.654821
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication type to use. If a type of auth is not specified, HTTPie
    attempts to guess.

    The available types are:

        {auth_type_choices_help}

    Shortcuts:

        {', '.join('{0} -a "{0}:{1}"'.format(name, alias)
               for name, alias in SHORTCUT_TYPES.items())}

    '''
)

#######################################################################
# HTTP method
#######################################################################

http_method = parser.add_argument_group(title='HTTP Method')

# Generated at 2022-06-21 13:21:53.297474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # See https://github.com/jakubroztocil/httpie/issues/1551
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert iter(auth_type_lazy_choices) == iter(auth_type_lazy_choices)


auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    If specified, this forces the use of a particular authentication type
    plugin. Supported authentication types are shown in the output of the
    `http --help-auth` command.

    '''
)


# Generated at 2022-06-21 13:22:02.812696
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Just call the method
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies which auth plugin to use. By default, the plugin is guessed from
    the provided credentials. If --auth is provided without a password, for
    example, --auth-type=basic will use Basic Auth.

    Available auth backends are:

        {', '.join(plugin_manager.get_auth_plugin_mapping())}

    This option is useful when you have the same credentials for more than one
    type of authentication (e.g., both API token and HTTP basic auth).

    '''
)

#######################################################################
# Proxy
#######################################################################


# Generated at 2022-06-21 13:22:14.106229
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(iter(_AuthTypeLazyChoices())) == set(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. The default is "basic" if none is specified.

    Use --debug to show the available auth plugins.

    '''
)

# Generated at 2022-06-21 13:22:16.945217
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:22:28.143883
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The mechanism to use for authenticating requests. Currently supported:

        auto, basic, digest, hawk, netrc, oauth1, oauth2

    The default is "auto", in which HTTPie tries to determine the
    authentication type by inspecting the URL and the available
    HTTPie Plugins.

    '''
)

# Generated at 2022-06-21 13:22:38.567351
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


auth.add_argument(
    '--auth-type',
    help='''
    The auth plugin to use.

    The default is the best match based on the URL, or `basic' if no
    match was found.

    Plugins: {plugins}

    '''.format(
        plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)


# Generated at 2022-06-21 13:22:49.328332
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    list(choices)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism.

    '''
)
auth.add_argument(
    '--auth-check',
    action='store_true',
    help='''
    Check if the specified credentials are valid but don't send any request.

    '''
)


#######################################################################
# Verbose / Debug
#######################################################################

verbose = parser.add_argument_group(title='Debug')

# Generated at 2022-06-21 13:22:53.119987
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Bearer' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:55.092439
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:23:06.706449
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Defaults to "basic" if --auth option is specified.

    '''
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Auth handler endpoint.

    If specified, the endpoint is used for retrieving credentials for the
    given scheme.
    If not specified, HTTPie attempts to use the standard auth handler
    endpoints.
    '''
)


# Generated at 2022-06-21 13:23:32.879221
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']

# Generated at 2022-06-21 13:23:35.338456
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices."""
    CONTAINS = _AuthTypeLazyChoices()
    assert 'basic' in CONTAINS


# Generated at 2022-06-21 13:23:36.836562
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'custom' in auth_type
    assert 'digest' in auth_type
    assert 'missing' not in auth_type

# Generated at 2022-06-21 13:23:47.368204
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify an auth plugin.

    Available plugins:
        {', '.join(plugin_manager.get_auth_plugin_mapping())}

    '''
)
auth.add_argument(
    '--auth-host', '-A',
    default=None,
    help='''
    Explicitly specify the auth host for Digest auth.

    '''
)
# Deprecated
auth.add_argument(
    '--auth-digest',
    action='store_true',
    default=None,
    help=SUPPRESS
)

# Generated at 2022-06-21 13:23:48.697120
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('digest')

# Generated at 2022-06-21 13:24:00.848433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(lazy_choices) == sorted(_AuthTypeLazyChoices())

lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=lazy_choices,
    help='''
    The authentication type to use for the request.
    "auto" (the default) detects which scheme should be used based on the URL.

    Available values: {auth_types}

    '''.format(
        auth_types=' '.join(sorted(lazy_choices))
    )
)
auth.add_argument(
    '--auth-netrc',
    action='store_true',
    help='''
    Read credentials also from ~/.netrc, see curl(1).

    '''
)
auth.add_

# Generated at 2022-06-21 13:24:13.145324
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of Auth plugin to use. This can be a built-in plugin such as 'basic',
    or a class path to a custom plugin, such as 'myproject.plugins.AuthPlugin'.
    This option can be used to allow using custom Auth plugins with the --auth
    option.
    '''
)

#######################################################################
# RequestOptions
#######################################################################

request_options = parser.add_argument_group(title='Request Options')


# Generated at 2022-06-21 13:24:15.257339
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    l = _AuthTypeLazyChoices()
    assert next(iter(l)) == 'aws-sigv4'


# Generated at 2022-06-21 13:24:23.281121
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'bearer' in lazy_choices
    assert 'basic' in lazy_choices

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "basic", but "auto" can be specified to let HTTPie pick
    the most secure mechanism that the server supports.

    Plugins can be used to define custom authentication mechanisms,
    e.g. "my-plugin".

    '''
)
# ``requests.session.request`` keyword arguments.

# Generated at 2022-06-21 13:24:29.420696
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk', 'netrc']
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    Authorization plugin to use. Available choices: {choices}.

    '''.format(
        choices=_AuthTypeLazyChoices()
    )
)

# Generated at 2022-06-21 13:25:16.788687
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(AUTH_PLUGIN_MAP) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication scheme to use.

    auto:
        If the URL contains credentials, use them. Otherwise, prompt for
        basic or digest auth, depending on the HTTP response.

    basic:
        Use HTTP Basic Authentication.

    digest:
        Use HTTP Digest Authentication.

    '''
)

# Generated at 2022-06-21 13:25:17.330088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass

# Generated at 2022-06-21 13:25:22.810822
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. The default is "{default}", where the
    auth mechanisms are tried in the order at which they are listed in
    --auth-types.

    {auth_type_help}

    '''.format(
        default=httpie.auth.AUTO,
        auth_type_help=plugin_manager.get_auth_plugin_help(),
    )
)


# Generated at 2022-06-21 13:25:32.016282
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the auth plugin to use.

    Each plugin supports different arguments,
    see the plugin-specific help for details.

    Available plugins: {0}

    '''.format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:25:37.246871
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager

    # No plugins
    with override_plugins([]):
        assert 'basic' not in _AuthTypeLazyChoices()
        assert 'no_plugin_to_match' not in _AuthTypeLazyChoices()

    # Basic auth plugin
    with override_plugins([BasicAuthPlugin()]):
        assert 'basic' in _AuthTypeLazyChoices()
        assert 'no_plugin_to_match' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:38.438461
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:45.162328
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == ['digest']
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_TYPE,
    help='''
    The authentication mechanism to be used. Supported types include basic,
    digest (default), and hawkauth.

    ''',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
)
auth.add_argument(
    '--auth-host',
    default='',
    help='''
    The host for which to use the provided credentials.

    '''
)

# Generated at 2022-06-21 13:25:57.754924
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == AVAILABLE_AUTH_PLUGINS

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The auth mechanism to be used. If not provided, it will be guessed based
    on the --auth option.

    Currently supported mechanisms:
        {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)


#######################################################################
# Timeouts
#######################################################################
# ``requests.request`` keyword arguments.
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-21 13:25:58.639044
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:26:01.425007
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.discover_auth_plugins()
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:49.529659
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. It can be one of:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    The default authentication mechanism is {DEFAULT_AUTH_PLUGIN_NAME}.

    '''
)

# Generated at 2022-06-21 13:26:57.787569
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
  for item in plugin_manager.get_auth_plugin_mapping():
    assert item in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    # Providing the choices as a dynamic list (rather than static)
    # is part of the workaround for making the --auth-plugin work
    # as expected. See: https://github.com/jakubroztocil/httpie/issues/354
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The currently supported ones are: {0}.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-21 13:27:03.549181
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test for covering one line
    plugin_manager.get_auth_plugin_mapping()
    # Test for covering one line
    plugin_manager.get_auth_plugin_mapping().keys()
    for test in _AuthTypeLazyChoices():
        print(test)
test__AuthTypeLazyChoices___iter__()
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use. It can be any of the values supported by
    the {0} Python library.

    '''.format(REQUESTS)
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:27:06.420999
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:07.989663
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bar' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:09.182109
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iter(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:27:17.937446
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import builtin
    from httpie.plugins import HttpAuthPlugin
    try:
        from tests.plugins.plugin_pluginmanager_testplugin import (
            PluginManagerTestPlugin
        )
    except ImportError:
        # build-time script, no plugin available
        pass
    else:
        builtin.plugins.append(PluginManagerTestPlugin)
    old_get_auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping
    plugin_manager.get_auth_plugin_mapping = lambda: {
        'default': HttpAuthPlugin,
        'PluginManagerTestPlugin': PluginManagerTestPlugin()
    }
    try:
        assert list(_AuthTypeLazyChoices()) == ['PluginManagerTestPlugin', 'default']
    finally:
        plugin_manager.get_auth_plugin_

# Generated at 2022-06-21 13:27:19.407763
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:20.446109
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert None in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:22.977325
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:28:50.111772
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk'
    ]

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use.

    --auth-type is normally optional, as HTTPie infers it from
    --auth[-type] option name (e.g., from --digest-auth). If a different
    --auth-type is specified, however, its corresponding authentication
    string has to be provided as well.

    '''
)

# Generated at 2022-06-21 13:28:56.897732
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:29:05.395543
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-A',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism.

    Choose from: {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method') \
    .add_mutually_exclusive_group()