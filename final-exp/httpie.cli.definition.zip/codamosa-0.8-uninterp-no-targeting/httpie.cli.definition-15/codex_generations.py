

# Generated at 2022-06-21 13:18:58.468536
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    options = [
        'Basic',
        'Digest',
        'Hawk',
        'Bearer',
    ]
    assert options == list(_AuthTypeLazyChoices())
    for option in options:
        assert option in _AuthTypeLazyChoices



# Generated at 2022-06-21 13:19:03.937019
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    types = _AuthTypeLazyChoices()
    assert 'basic' in types
    assert 'digest' in types
    assert 'hmac' in types
    assert 'jwt' in types
    assert 'oauth1' in types
    assert 'aws4' in types
    assert 'awsv4' in types
    assert 'awssigv4' in types
    assert 'custom' in types

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authenticator plugin to use.

    '''
)
# custom auth type
auth.add_argument(
    '--auth-plugin',
    help='''
    The path to the Python module that implements the authenticator plugin.

    '''
)


# No idea how to test

# Generated at 2022-06-21 13:19:04.822792
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:06.309487
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert '__no_such_item__' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:19.661272
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Contains position arg for _AuthTypeLazyChoices.__contains__
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Supported mechanisms are:

        {plugin_manager.get_auth_plugin_help()}

    If not specified, the plugin is selected based on the following precedence:
        1. The auth type is taken from the URL, such as http://user:pass@example.org
        2. The plugin is inferred from the value of --auth, such as --auth=digest
        3. The plugin is set to basic

    '''
)

# Generated at 2022-06-21 13:19:22.941068
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(sorted(iter(_AuthTypeLazyChoices()))) == sorted(iter(_AuthTypeLazyChoices()))

# Generated at 2022-06-21 13:19:24.867578
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(AUTH_PLUGIN_MAP.keys()))

# Generated at 2022-06-21 13:19:26.347592
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert AuthType.BASIC in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:19:33.625729
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(list(plugin_manager.get_auth_plugin_mapping().keys())) == iter(
        iter(_AuthTypeLazyChoices())
    )
test__AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use. The default is basic. Other possible values
    include digest and oauth1. The oauth1 type requires the --oauth1-*
    options to be specified.

    Possible values: {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-21 13:19:44.107941
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    e = 'plugin_name_3'
    plugin = auth_plugin = plugin_manager.create_auth_plugin(e)
    auth_plugin.load()
    assert e in _AuthTypeLazyChoices()
    assert 'plugin_name_6' not in _AuthTypeLazyChoices()

authentication_type = auth \
    .add_mutually_exclusive_group(required=False)

# Generated at 2022-06-21 13:19:56.510863
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Authentication plugin to use. Default is {DEFAULT_AUTH_PLUGIN_NAME}.
    {AUTH_PLUGIN_HELP_REGISTRY}

    '''
)

#######################################################################
# HTTP method
#######################################################################



# Generated at 2022-06-21 13:19:58.488176
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:20:00.675713
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:11.404075
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'missing' not in lazy_choices


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose the authentication mechanism. This defaults to the URL
    hostname, port and the realm (if present).

    Valid choices are:

        {auth_plugin_choices}

    '''.format(
        auth_plugin_choices=wrap_with_line_breaks(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            width=DEFAULT_TERMINAL_WIDTH
        )
    )
)
auth.add_argument

# Generated at 2022-06-21 13:20:24.070223
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'Basic' in choices
    assert 'Custom' in choices
    assert 'fake-auth' not in choices
    assert sorted(choices) == ['Basic', 'Custom', 'digest']



# Generated at 2022-06-21 13:20:32.917579
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    from httpie.plugins import plugin_manager
    # Don't use assertIn, as we'd like to test __contains__ method itself.
    assert 'bearer' in choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'oauth1' in choices
    assert 'ntlm' in choices
    assert 'aws4-hmac-sha256' in choices
    assert 'aws4-hmac-sha256-signed-headers' in choices
    plugin_manager.set_plugins([])
    assert 'bearer' not in choices
    assert 'basic' not in choices
    assert 'digest' not in choices
    assert 'hawk' not in choices
    assert 'oauth1' not in choices

# Generated at 2022-06-21 13:20:43.537227
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # test for __contains__()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'unsupported' not in _AuthTypeLazyChoices()
    assert '__init__' not in _AuthTypeLazyChoices()

    # test for __iter__()
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# Generated at 2022-06-21 13:20:46.151754
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'not-exist' not in choices

# Generated at 2022-06-21 13:20:57.484822
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=argparse.SUPPRESS
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL Settings')
ssl.add_argument(
    '--verify', '-k',
    default=True,
    action=BooleanAction,
    help='''
    By default, SSL certificates are validated, and connections
    will not proceed if a certificate verification failure occurs.
    Use --no-verify to turn off SSL certificate validation.

    '''
)
ssl.add_argument

# Generated at 2022-06-21 13:21:03.179581
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()  # noqa
    assert 'Digest' in _AuthTypeLazyChoices()  # noqa
    assert 'Custom' not in _AuthTypeLazyChoices()  # noqa

# Generated at 2022-06-21 13:21:12.977715
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hmac', 'jwt']

# Generated at 2022-06-21 13:21:22.857122
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    # Do not simply use the set below, we test _AuthTypeLazyChoices()
    # in the unit test test__AuthTypeLazyChoices___contains__
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to use for a request. Choices:
        {0}
    '''.format('\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
    ).strip())
)

# Generated at 2022-06-21 13:21:32.474329
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def _test_not_empty(choices):
        if not choices:
            raise AssertionError('The list cannot be empty.')

    def _test_containment(choices):
        for choice in choices:
            if choice not in choices:
                raise AssertionError('"{0}" not in {1}'.format(choice, choices))

    def _test_iterator(choices):
        iterator = iter(choices)
        try:
            next(iterator)
        except StopIteration:
            raise AssertionError('Iterator cannot be empty.')

    _test_not_empty(_AuthTypeLazyChoices())
    _test_containment(_AuthTypeLazyChoices())
    _test_iterator(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:21:37.996834
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )
    from httpie.plugins.builtin import HTTPBasicAuth
    plugin_manager.deregister(HTTPBasicAuth)
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )

# Generated at 2022-06-21 13:21:51.188517
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:22:02.051757
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # should be in plugin auth_plugin_mapping
    assert 'digest' in _AuthTypeLazyChoices()
    # should not be in plugin auth_plugin_mapping
    assert 'not-in-auth-plugin-mapping' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. "auto" (default) means that the auth
    mechanism will be auto-detected based on the provided credentials
    when --auth option is used.
    The available auth mechanisms depend on the installed plugins.
    Use `http --auth-type-help` to get a list of available mechanisms.

    ''',
)

# Generated at 2022-06-21 13:22:13.484720
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'jwt', 'oauth1', 'ntlm'
    ]
AuthTypeLazyChoices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=AuthTypeLazyChoices,
    help='''
    Choose an authentication plugin:

        {auth_type_mapping}

    '''.format(
        auth_type_mapping=', '.join(
            f'"{auth_type}"' for auth_type in AuthTypeLazyChoices
        )
    )
)


# Generated at 2022-06-21 13:22:25.228619
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(_AuthTypeLazyChoices, "__iter__")
    assert hasattr(_AuthTypeLazyChoices, "__contains__")



# Generated at 2022-06-21 13:22:34.610512
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'kerberos']

auth.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified authentication plugin. Supported plugins:

        digest
            Digest authentication, which is more secure than Basic,
            but not as widely deployed.

        jwt
            JSON Web Token authentication.

        kerberos
            Kerberos/SPNEGO authentication. For this to work the
            requests-kerberos plugin needs to be installed.

    '''
)

# Generated at 2022-06-21 13:22:44.757972
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == \
           sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Depends on plugins.
    The default is %(default)s.

    See "http --help-auth" for a list of supported auth types.

    ''',
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:23:11.133338
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_plugin_type = parser.add_argument_group(title='Authentication plugin')
auth_plugin_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Name of an authentication plugin to use instead of the default one.

    '''
)
#######################################################################
# Custom HTTP methods
#######################################################################

custom_methods = parser.add_argument_group(title='Custom HTTP Methods')
custom_methods.add_argument(
    '--method',
    metavar='METHOD',
    help='''
    Specifies an HTTP method to be used instead of the default one.
    The specified METHOD is case-insensitive.

    '''
)

####################################################################

# Generated at 2022-06-21 13:23:12.015982
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:20.350054
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []



# Generated at 2022-06-21 13:23:25.487636
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert auth_type_choices.__contains__('digest')
    assert auth_type_choices.__contains__('basic')
    assert auth_type_choices.__contains__('oauth1')
    assert 'digest' in auth_type_choices
    assert 'basic' in auth_type_choices
    assert 'oauth1' in auth_type_choices
    assert sorted(list(auth_type_choices)) == ['basic', 'digest', 'oauth1']
    assert 'custom' not in auth_type_choices


# Generated at 2022-06-21 13:23:34.849447
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for auth_type in _AuthTypeLazyChoices():
        assert auth_type in plugin_manager.get_auth_plugin_mapping()


auth.add_argument(
    '--auth-type',
    default=plugins.AuthCredentials(),
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication handler.

    The available handlers are:

        {auth_types}

    To see which options are available for a certain handler, run:

        $ http --auth-type=TYPE --help

    '''.format(auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

#######################################################################
# Persistent Options
#######################################################################

persistent = parser.add_argument_group

# Generated at 2022-06-21 13:23:40.858365
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # We don't want our test to depend on any real plugin.
    fake_name = 'fake_name'
    fake_plugin_cls = 'fake plugin class'
    with mock.patch.object(
        plugin_manager, 'get_auth_plugin_mapping'
    ) as get_auth_plugin_mapping_mock:
        get_auth_plugin_mapping_mock.return_value = {fake_name: fake_plugin_cls}
        assert fake_name in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:23:42.431614
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:44.596039
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazyChoices = _AuthTypeLazyChoices()
    return 'a' in lazyChoices and 'z' not in lazyChoices

# Generated at 2022-06-21 13:23:49.951544
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the authentication type.  If not provided, the authentication
    type is determined from the provided --auth argument.

    Available authentication types: {auth_types}

    '''
)

#######################################################################
# Proxies
#######################################################################



# Generated at 2022-06-21 13:24:02.019835
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    plugins = list(auth_type_choices)
    assert len(plugins) == len(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Client implementation to use for performing HTTP authentication.
    The default is 'auto', which means that HTTPie tries to be smart.

    '''
)
auth.add_argument(
    '--auth-verify',
    default=True,
    action='store_false',
    help='''
    Skip server certificate verification.

    '''
)

# Generated at 2022-06-21 13:24:35.724560
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()
    assert len(choices) == len(auth_plugin_mapping)
    for choice in choices:
        assert choice in auth_plugin_mapping

# Generated at 2022-06-21 13:24:37.050572
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:24:45.702500
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    x = _AuthTypeLazyChoices()
    assert 'basic' in x
    assert 'digest' in x


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used:

    * basic: HTTP Basic Auth
    * digest: HTTP Digest Auth

    '''
)
_auth_plugin.add_plugin_args(auth)

#######################################################################
# Follow
#######################################################################

follow = parser.add_argument_group(title='Follow')

# Generated at 2022-06-21 13:24:55.245075
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='Choose an authentication plugin.'
)
#######################################################################
# Json Pointers
#######################################################################

pointers = parser.add_argument_group(title='Pointers')


# Generated at 2022-06-21 13:24:56.541061
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert _AuthTypeLazyChoices().__iter__() == ['foo', 'bar']



# Generated at 2022-06-21 13:24:59.368391
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    Test method __contains__ of class _AuthTypeLazyChoices
    """
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    assert 'custom' not in auth_types

# Generated at 2022-06-21 13:25:05.007214
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The type of HTTP authentication to use. If not set, it will be inferred
    from the provided credentials. If not credentials are provided, it defaults
    to `auto'. The available types are:

    auto:

        Use the most secure method (digest, if supported, followed by
        basic).

    basic:

        Use HTTP Basic Authentication.

    digest:

        Use HTTP Digest Authentication.

    response:

        Same as digest but force the server to identify itself with a 401
        Unauthorized response before sending the WWW-Authenticate header.

    ''',
)

auth.add_argument

# Generated at 2022-06-21 13:25:07.652217
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Test if method __contains__ of class _AuthTypeLazyChoices works correctly."""
    assert 'aws' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:08.405939
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:25:12.510368
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockAuthPlugin(object):
        auth_type = 'mock'

    plugin_manager.add_plugin('auth', MockAuthPlugin)
    lazy_choices = _AuthTypeLazyChoices()
    plugin_manager.remove_plugin('auth', MockAuthPlugin)
    assert 'mock' in lazy_choices


# Generated at 2022-06-21 13:26:42.816884
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:51.541291
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mapping = plugin_manager.get_auth_plugin_mapping()
    matching = set(mapping)
    for i in _AuthTypeLazyChoices():
        assert i in matching
    for i in matching:
        assert i in _AuthTypeLazyChoices()

auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=auth_type_lazy_choices,
    default=None,
    help='''
    Specify an auth plugin to use. For example:

        $ http --auth-type=digest -a user:pass ...

    By default, the plugin is guessed from the provided credentials
    based on the credential syntax.

    ''',
)

# Generated at 2022-06-21 13:26:59.366503
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_choices, collections.abc.Iterable)
    assert list(auth_type_choices) == ['auto', 'digest', 'jwt', 'multipart']


# Generated at 2022-06-21 13:27:02.413494
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    res = _AuthTypeLazyChoices()
    for item in ('Basic', 'Digest'): assert item in res
    for item in ('Basic1', 'Digest1'): assert item not in res

# Generated at 2022-06-21 13:27:13.905940
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. The default is "basic".
    Other HTTPie-supported mechanisms include "digest", "hmac", "ntlm"
    and "oauth1". For a full list, run: http --plugins-auth.

    '''
).completer = ChoicesCompleter(
    _AuthTypeLazyChoices()
)

#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-21 13:27:23.085802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert next(iter(choices)) == 'basic'

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used.

    The supported types are:

    {auth_types}
    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(
                    sorted(plugin_manager.get_auth_plugin_mapping().keys())
                ),
                57,
            )
        ).strip()
    ),
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add

# Generated at 2022-06-21 13:27:34.843553
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for item in _AuthTypeLazyChoices():
        pass

auth_type = auth.add_mutually_exclusive_group()

auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH_PLUGIN,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The plugin used for authentication. The default is `{0}'.

    Available plugins:

    {1}

    '''.format(
        DEFAULT_AUTH_PLUGIN,
        _get_auth_plugin_docs()
    )
)

# Generated at 2022-06-21 13:27:43.908059
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(
        ('Basic', 'Digest')
    ) == sorted(list(_AuthTypeLazyChoices()))

auth_type_validator = AuthTypeValidator(
    '{auth_type} is not a valid authentication type.'
)


# Generated at 2022-06-21 13:27:54.888624
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()


auth_type_help = '''
    The type of the auth mechanism.

    AUTHTYPE is one of:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=auth_type_help
)


# Generated at 2022-06-21 13:28:06.380933
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert ['basic', 'digest'] == list(_AuthTypeLazyChoices())


auth_type = auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Authentication method. The default is "basic". See python-requests
    documentation for details.

    The currently supported methods are:

        {sorted(plugin_manager.get_auth_plugin_mapping())}

    '''
)

#######################################################################
# URL
#######################################################################

url = parser.add_argument_group(title='URL')