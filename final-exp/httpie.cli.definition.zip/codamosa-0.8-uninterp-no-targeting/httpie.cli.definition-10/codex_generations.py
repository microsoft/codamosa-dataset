

# Generated at 2022-06-21 13:19:03.214421
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. It can be one of:

        {0}

    If not provided, the plugin is chosen based on the HTTP
    URL (using the httpie-<AUTH_TYPE> package; e.g., httpie-ntlm).
    The option can be used to override a default choice.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)


# Generated at 2022-06-21 13:19:11.763053
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == list(sorted(AUTH_PLUGIN_MAP))




auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Defaults to "auto" which
    chooses the most secure mechanism available.

    Currently supported options:

        auto
            The default. Choose the most secure mechanism available.

        basic
            HTTP Basic Auth (base64-encoded username:password).

        digest
            HTTP Digest Auth (hash-based message authentication code).


    '''
)

# Generated at 2022-06-21 13:19:14.549200
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:19:23.439573
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import json

    # noinspection PyUnresolvedReferences
    def foo():
        pass

    # noinspection PyUnresolvedReferences
    def bar():
        pass

    # noinspection PyUnresolvedReferences
    def baz():
        pass

    # noinspection PyUnresolvedReferences
    class Qux:
        pass

    plugin_manager.register_plugin(
        Plugin(
            name='foo',
            auth_types=['foo'],
            auth_parse=foo
        )
    )
    plugin_manager.register_plugin(
        Plugin(
            name='bar',
            auth_types=['bar'],
            auth_parse=bar
        )
    )

# Generated at 2022-06-21 13:19:26.490631
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert ('not_valid_auth' not in lazy_choices)
    assert ('digest' in lazy_choices)


# Generated at 2022-06-21 13:19:29.863049
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
       value = _AuthTypeLazyChoices()  # type: _AuthTypeLazyChoices
       assert (value.__contains__("fake") != True)

# Generated at 2022-06-21 13:19:41.356445
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    instance = _AuthTypeLazyChoices()
    assert sorted(instance) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:19:43.766378
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

_auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:45.655568
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Fake' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:19:46.750790
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'kerberos' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:03.609570
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for item in AUTH_PLUGIN_MAPPING:
        assert item in _AuthTypeLazyChoices()


_auth_type_validator = AuthTypeValidator('Invalid auth type.')

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=_auth_type_validator,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to perform.
    The available auth types depend on the plugins that are installed.
    The default is "basic".

    ''',
)

# Generated at 2022-06-21 13:20:12.575703
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['digest', 'jwt']) == sorted(_AuthTypeLazyChoices())
_AuthTypeChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeChoices,
    help='''
    Specify an authentication type to be used. Valid types include:

        {types}

    If no type is specified, 'basic' is assumed.

    '''.format(
        types=(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
        )
    )
)

# Generated at 2022-06-21 13:20:15.483284
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:20:19.122011
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


_auth_type_lazy_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:20:29.619209
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for auth_plugin in _AuthTypeLazyChoices():
        assert auth_plugin in auth_type_lazy_choices


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.
    This should be a plugin name (e.g., digest) or a path to a Python
    module (e.g., ~/plugins/my-plugin.py) or a fully qualified path to
    a callable (e.g., ~/plugins/my-plugin.py:plugin_func).

    '''
)


# Generated at 2022-06-21 13:20:30.905542
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(_AuthTypeLazyChoices()) > 0

# Generated at 2022-06-21 13:20:40.460918
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    Test constructor of class _AuthTypeLazyChoices
    """
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified authentication plugin.

    The available auth types depend on the plugins currently loaded.
    To see the list of available auth types, use the --debug flag or
    check the documentation of the installed plugins.

    '''
)

auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to provide the credentials to, as per RFC7235.

    '''
)


# Generated at 2022-06-21 13:20:47.981800
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.
    Available options: {auth_plugins}.

    '''
)



# Generated at 2022-06-21 13:20:51.184323
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'custom' in choices
    assert 'non-existing' not in choices
    assert 'basic' not in choices
    assert 'custom' not in choices


# Generated at 2022-06-21 13:21:00.933170
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=argparse.SUPPRESS,
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP method')

method.add_argument(
    '--method', '-m',
    metavar='METHOD',
    type=str.upper,
    help='''
    Specify an HTTP method to use (default is GET).
    This overrides the method specified in the URL.

    '''
)

#######################################################################
# Output options
#######################################################################

output_options = parser.add_argument_group(title='Output options')

output_

# Generated at 2022-06-21 13:21:12.052856
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'no-auth-type-project' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:22.183675
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): # noqa
    # ...

    class _AuthTypeCustom:
        def __init__(self, *arg, **kwargs):
            ...
    class _AuthTypeCustomWithoutName:
        pass

    class _AuthPluginMock(AuthPlugin):
        name = 'custom'
        auth_type = _AuthTypeCustom
        auth_type_without_name = _AuthTypeCustomWithoutName()
        auth_type_without_name.name = 'custom_without_name'

    auth_plugin_mock = _AuthPluginMock()
    auth_plugins_mapping = {
        auth_plugin_mock.name: auth_plugin_mock,
        auth_plugin_mock.auth_type_without_name.name:
            auth_plugin_mock.auth_type_without_name
    }


# Generated at 2022-06-21 13:21:31.604780
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        list(_AuthTypeLazyChoices())
        ==
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=AuthPlugin,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication types supported by the {AUTH_PLUGIN_TITLE} plugin:

        {AUTH_PLUGIN_GET_HELP_DOCS()}

    Type is also a plugin entrypoint name. Use `--debug` flag to find out
    available entrypoints.
    '''
)


# Generated at 2022-06-21 13:21:34.180909
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:21:40.811340
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) \
        == [
            'aws-sigv4',
            'basic',
            'digest',
        ]

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use.
    HTTPie supports the following auth plugins:

    {plugins}

    '''
).completer = ChoicesCompleter(
    plugin_manager.get_auth_plugin_mapping().keys()
)



# Generated at 2022-06-21 13:21:54.951719
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    assert sorted(x.__iter__()) == ['digest', 'jwt']

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Defaults to "auto", which means
    that HTTPie attempts to auto-detect the auth mechanism based on the
    server response.

    ''',
)

# Generated at 2022-06-21 13:22:03.539397
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert PLUGIN_NAME in _AuthTypeLazyChoices()


# http://docs.python.org/3/library/argparse.html#choices
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The available options are:

        {available_types}

    '''.format(
        available_types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                60
            )
        ).strip(),
    )
)

#######################################################################
# JSON options
################################################################

# Generated at 2022-06-21 13:22:05.130766
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bearer' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:16.613615
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert len(list(auth_types)) > 0
    assert 'basic' in auth_types


auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    type=auth_plugin_name_type,
    help='''
    The authentication mechanism to be used: basic, digest (default: auto).

    If a 401 response is received and the server sets "WWW-Authenticate"
    header, the auth type is automatically determined.

    ''',
)

#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP')

# Generated at 2022-06-21 13:22:27.855107
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    len(set(_AuthTypeLazyChoices())) > 0

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Select the user-agent plugin to use to perform the authentication.
    The default, "{AUTO_AUTH_PLUGIN}", auto-detects the plugin based on the URL.

    '''
)
auth.add_argument(
    '--auth-send',
    default='auto',
    choices=['auto', 'always', 'never'],
    help='''
    Controls when to send the username and password to the server.
    By default, only send the credentials when prompted by the server.

    '''
)

# Generated at 2022-06-21 13:22:47.450878
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk'
    ]


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method, defaults to "basic" if --auth option is provided.
    Available plugins: {0}.

    '''.format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

# Generated at 2022-06-21 13:22:56.953450
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert iter(_AuthTypeLazyChoices()).next()


# Generated at 2022-06-21 13:23:07.631886
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'auto' in choices
    assert 'bearer' not in choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'oauth1' in choices
    assert 'ntlm' in choices
    assert 'federated' in choices
    assert 'auto' in choices


# Generated at 2022-06-21 13:23:16.816223
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''

    Choose an auth mechanism.

    Known values:
        {auth_types}

    Additional mechanism may be provided by plugins.
    To see the full list, run: `http --debug`

    '''.format(
        auth_types=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)


# Generated at 2022-06-21 13:23:27.482192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import inspect
    import sys
    import unittest
    name_of_class = _AuthTypeLazyChoices.__name__
    name_of_module = inspect.getmodule(_AuthTypeLazyChoices).__name__
    sys.modules.pop(name_of_class, None)
    sys.modules.pop(name_of_module, None)
    try:
        from httpie.cli import _AuthTypeLazyChoices
    except ImportError:
        assert False, 'The import must succeed'
    del sys.modules[name_of_class]
    del sys.modules[name_of_module]
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for auth_type in ['basic', 'digest']:
        assert auth_type in auth_type_lazy_cho

# Generated at 2022-06-21 13:23:36.257795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin',
    type=plugin_manager.get_auth_plugin,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use a custom authentication plugin.
    The default value is "auto" which causes HTTPie to figure out the
    plugin type based on the HTTP method and the user credentials.
    The value "auto" is also used when --auth-type is not specified.

    ''',
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:23:46.897209
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():                                                ###
    assert 'digest' in _AuthTypeLazyChoices()                                   ###
    assert 'basic' in _AuthTypeLazyChoices()                                    ###

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=auth_type_lazy_choices,
    help='''
    Use the specified auth plugin. The default is the "basic" plugin.
    When "digest" auth is used (with --auth-type=digest), HTTPie
    sends the first request unconditionally without waiting for an WWW-
    Authenticate challenge from the server, because if the server
    doesn't support digest auth, this results in a faster failure.

    '''
)


# Generated at 2022-06-21 13:23:58.416514
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for auth_plugin_name in _AuthTypeLazyChoices():
        assert auth_plugin_name in plugin_manager.get_auth_plugin_mapping()

#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP Method', description=None)
method.add_argument(
    '--method', '-m',
    default=DEFAULT_METHOD,
    help='Specify an HTTP method to use.'
)

#######################################################################
# HTTPie
#######################################################################

about = parser.add_argument_group(title='About HTTPie', description=None)
about.add_argument(
    '--version',
    action='version',
    version='HTTPie %s' % __version__,
    help='Print HTTPie version and exit.'
)
about

# Generated at 2022-06-21 13:24:02.253188
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    choice = 'basic'
    assert choice in choices
    assert choice not in choices + ['foo']
test__AuthTypeLazyChoices___contains__.__test__ = False


# Generated at 2022-06-21 13:24:14.475384
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from collections import Sequence
    assert isinstance(_AuthTypeLazyChoices(), Sequence)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    You may either enter the name of the plugin or one of its aliases.

    Use the `--debug' flag to list all available plugins, such as:

        * httpie-ntlm
        * httpie-oauth
        * httpie-aws-authv4
        * etc...
    '''
)

#######################################################################
# Connection options
#######################################################################

connection = parser.add_argument_group(title='Connection')


# Generated at 2022-06-21 13:24:47.868045
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:24:56.608552
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    Test if _AuthTypeLazyChoices contains all the items in AuthPlugin.mapping.
    The test will fail if we use AuthPlugin.mapping in the initialization of
    _AuthTypeLazyChoices, because the value of AuthPlugin.mapping will change
    after plugins are loaded.
    """
    assert _AuthTypeLazyChoices() == set(AuthPlugin.mapping.keys())

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    Currently supported:

    {auth_type_map_docstring}

    The default is "basic".

    '''
)

# Generated at 2022-06-21 13:25:02.693078
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # noqa
    assert 'digest' in _AuthTypeLazyChoices()

_auth_type_lazy_choices = _AuthTypeLazyChoices()

auth_type = parser.add_argument_group(title='Authentication Type')
auth_type.add_argument(
    '--auth-type',
    default='auto',
    choices=_auth_type_lazy_choices,
    help='''
    The authentication mechanism to be used. Currently supported values:

    * "basic" - HTTP Basic Authentication.
    * "digest" - HTTP Digest Authentication.
    * "auto" (default) - detect the scheme based on the realm attribute
      of the HTTP 401 response of the server.

    '''
)

#######################################################################
# Additional options
#######################################################################

additional = parser.add_

# Generated at 2022-06-21 13:25:04.354951
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:10.218663
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert list(choices)[0] == 'basic'


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. Defaults to "auto" which
    is HTTPie's own implementation.

    Plugins can also be used for this option.
    The list of plugins used for --auth-type can be found via `http --debug`.
    '''
)

# Generated at 2022-06-21 13:25:11.201709
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == ['basic', 'digest']

# Generated at 2022-06-21 13:25:18.675248
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # list(..) is needed for Python 3 and Python 3.2.
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type', '-t',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. By default, the appropriate
    mechanism is guessed based on the provided credentials, but this can
    be used to explicitly specify one. Available authentication mechanisms:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-21 13:25:20.129227
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:22.975110
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices

    for choice in choices:
        assert choice in plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-21 13:25:32.110575
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('basic' in _AuthTypeLazyChoices()) is True

auth.add_argument(
    '--auth-type',
    type=AuthCredentials.type_validator,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism, for example:

        basic, digest.

    Use --auth-type=auto to let HTTPie detect the auth type.

    Alternatively, you can use an alias for the --auth-type
    option. For example, --auth-type=digest is equivalent to -d.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Automatically send credentials without prompting for password.

    '''
)



# Generated at 2022-06-21 13:26:56.667862
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from requests_toolbelt.authentication import TrustNet
    plugin_manager.deregister_auth_plugin(TrustNet)
    assert 'trust-net' not in _AuthTypeLazyChoices()
    plugin_manager.register_auth_plugin(TrustNet)
    assert 'trust-net' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:02.996739
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specifying the given auth plugin, e.g. '{}'.

    The default is to automatically detect the auth type.

    '''.format(
        '/'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Options that take no value
#######################################################################


# Generated at 2022-06-21 13:27:14.346616
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # type: () -> None
    choices = _AuthTypeLazyChoices()
    assert len(list(choices)) > 0

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of credentials.
    If not provided, HTTPie will auto-detect the auth type by examining the
    given credentials.

    The following types are supported: {', '.join(
        plugin_manager.get_auth_plugin_mapping().keys()
    )}

    '''
)

# Generated at 2022-06-21 13:27:21.854048
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Test for method __iter__ of class _AuthTypeLazyChoices
    """
    from httpie.plugins import plugin_manager
    from httpie.cli import _AuthTypeLazyChoices
    mock_plugin_manager = mock.Mock()
    mock_plugin_manager.get_auth_plugin_mapping.return_value = {
        'key-1': 'Value-1',
        'key-2': 'Value-2',
        'key-3': 'Value-3',
    }
    with mock.patch.object(httpie.plugins, 'plugin_manager', mock_plugin_manager):
        auth = _AuthTypeLazyChoices()
        expected = ['key-1', 'key-2', 'key-3']
        assert list(sorted(iter(auth))) == expected


auth.add_argument

# Generated at 2022-06-21 13:27:33.835355
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Auth plugins specific options.
auth_plugin = parser.add_argument_group(title='Authentication Plugin Options')
auth_plugin.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default mechanism is "basic".

    Note that only the options relevant for the selected mechanism will be
    shown in the help. To see all options, run:

        $ http --help

    '''
)

#######################################################################
# Certificates
#######################################################################

certs = parser.add_argument_group(title='Certificates')


# Generated at 2022-06-21 13:27:37.167896
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_typer = _AuthTypeLazyChoices()
    assert iter(sorted(plugin_manager.get_auth_plugin_mapping().keys())) == auth_typer.__iter__()


# Generated at 2022-06-21 13:27:45.252909
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    plugin_manager.load_builtin_plugins()
    expected_items = {'basic', 'digest', 'hmac'}
    actual_items = set(_AuthTypeLazyChoices())
    assert actual_items == expected_items

_auth_type_lazy_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_auth_type_lazy_choices,
    help='Auth type. See: httpie.org/plugins.html#auth'
)

# Generated at 2022-06-21 13:27:55.812116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. Unless the server requires \"basic\",
    HTTPie will automatically select the most secure one out of the ones
    that the server supports.

    Available mechanisms are:

      {0}

    See the documentation for the full details.

    '''.format(', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ))
)

# Generated at 2022-06-21 13:28:02.947761
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == ()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authenticate according to the specified scheme. The default is
    "{default_auth_plugin}".

    The following authentication schemes are supported. Note that each
    of them also has its own respective options available:

        {auth_plugin_list}

    '''.format(
        default_auth_plugin=DEFAULT_AUTH_PLUGIN,
        auth_plugin_list='\n'.join(
            (8 * ' ') + description[0]
            for description in plugin_manager.get_auth_plugin_descriptions()
        ).strip()
    )
)

################################

# Generated at 2022-06-21 13:28:13.979908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    Test for constructor of class _AuthTypeLazyChoices.
    """

    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices

    for value in lazy_choices:
        assert value in list(lazy_choices)


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Default is "auto", which is HTTP basic AUTH when --auth is used,
    and No authentication otherwise.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')