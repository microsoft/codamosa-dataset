

# Generated at 2022-06-21 13:19:03.165933
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'not-existing-auth-type' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:11.693935
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    actual = list(_AuthTypeLazyChoices())
    expected = list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    assert actual == expected

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an authentication method. The default authentication mechanism is
    Basic, but Digest and others are also supported. The supported methods
    depend on the installed plugins. Run `{APP_NAME} --plugins` for a list of
    plugins. If you want to extend HTTPie with a custom plugin, see
    http://httpie.org/plugins.

    '''
)


# Generated at 2022-06-21 13:19:22.105095
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [item for item in _AuthTypeLazyChoices()]

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. The value is case-insensitive and it
    can be abbreviated as long as there is no ambiguity.

    It can be one of:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

#######################################################################
#

# Generated at 2022-06-21 13:19:23.479134
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:35.472051
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        list(_AuthTypeLazyChoices())
    except PluginError:
        pass

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin_name',
    help=f'''
    Auth plugin to use, e.g., {', '.join(
        plugin_manager.get_auth_plugin_mapping().keys()
    )}.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    type=parse_bool,
    default=False,
    help='''
    Don't allow the server to challenge the client for credentials.
    This option is useful when using --auth with an API that responds with
    401 Unauthorized to a request with missing authorization.

    ''',
)



# Generated at 2022-06-21 13:19:36.548041
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'netrc', 'oauth1', 'basic']

# Generated at 2022-06-21 13:19:46.145950
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    type=str,
    help='''
    The auth mechanism to use.
    The options are: {default_auth_map}
    If no auth-type is specified, the default auth-type is Basic.

    '''.format(
        default_auth_map=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        ).strip()
    )
)

# Generated at 2022-06-21 13:19:58.962861
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '--auth-type',
    help='''
    Type of HTTP authentication to use.

    The default and currently the only supported authentication types are:
    {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)
auth_type.add_argument(
    '--auth-type=Basic',
    action='store_const',
    const='Basic',
    help=argparse.SUPPRESS,
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:20:10.528446
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices() == plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    The default is "auto", which will attempt "basic", then digest
    and then fallback to any other supplied plugins.

    To see a list of all supported mechanisms, use "--auth-type=help"
    or "--session-help".

    ''',
)

#######################################################################
# Plugin and configuration.
#######################################################################

plugin = parser.add_argument_group(
    title='Plugins and configuration',
)

# Generated at 2022-06-21 13:20:23.299163
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'password' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism or plugin used.

    Supports basic, digest, and oauth1.

    If unset, an appropriate one is selected based on the --auth option.

    '''
)
auth.add_argument(
    '--auth-combined',
    default=None,
    help='''
    The HTTPie's own, native authentication plugin.

    '''
)

# Generated at 2022-06-21 13:20:31.886590
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert '' in auth_type_choices
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices


auth_type_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:20:39.553798
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    class FakePluginMgr:
        def get_auth_plugin_mapping(self):
            return {'foo':'bar'}

    plugin_manager = FakePluginMgr()

    lazy_choices = _AuthTypeLazyChoices()
    # False case
    item = 'asdf'
    output = item in lazy_choices
    assert output == False, 'test_mock.__contains__() is incorrect'
    # True case
    item = 'foo'
    output = item in lazy_choices
    assert output == True, 'test_mock.__contains__() is incorrect'


# Generated at 2022-06-21 13:20:50.413195
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type', '--auth-scheme',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    Specify the authentication mechanism to be used.

    The default value, None, will attempt each of the available auth types and
    use the best one. For example, if the server responds to a
    "Basic"-authenticated request with a 401 status code, but then allows
    the same request when authenticated with "Digest", then the "Digest"
    scheme will be used for subsequent requests.

    If the auth type is known, then you can use this option to skip the
    initial unauthenticated request

    ''',
)


# Generated at 2022-06-21 13:21:00.421080
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    _AuthTypeLazyChoices.__iter__() returns an iterator over the expected auth types
    """
    lazy_type = _AuthTypeLazyChoices()

    assert len(list(lazy_type)) == len(plugin_manager.get_auth_plugin_mapping())

    for auth_type in lazy_type:
        assert auth_type in plugin_manager.get_auth_plugin_mapping()




# Generated at 2022-06-21 13:21:12.310439
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ['Basic'] == list(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:21:16.461994
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hmac' in choices
    assert sorted(choices) == ['basic', 'digest', 'hmac']

# Generated at 2022-06-21 13:21:22.330878
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Available values are: {auth_type_choices}

    '''.format(
        auth_type_choices=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:21:23.352216
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:33.077658
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert sorted(['digest', 'jwt', 'netrc', 'ntlm', 'oauth1', ' basic']) == list(auth_types)

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. The default is "basic" and other
    choices are:

        {' '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='HTTP(S) Proxy')
proxy.add_argument

# Generated at 2022-06-21 13:21:43.609355
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iter(plugin_manager.get_auth_plugin_mapping().keys())
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism to be used.
    '''
)

# auth.add_argument(
#     '--digest',
#     default=False,
#     action='store_true',
#     help=(
#         'Use HTTP Digest Authentication (rather than Basic).'
#     )
# )

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:21:59.593322
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['basic', 'digest']) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use.
    '''
)

# Generated at 2022-06-21 13:22:00.914463
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-21 13:22:04.966865
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'aws_sigv4',
        'basic',
        'digest',
        'hawk',
        'ntlm',
    ]

# Generated at 2022-06-21 13:22:16.363968
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'Basic' in auth_types
    assert sorted(list(auth_types)) == sorted({'digest', 'Basic'})

auth_types = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=auth_types,
    dest='auth_type',
    help=f'''
    Choose the authentication mechanism and override the
    mechanism inferred (based on --auth option) if needed.
    (default: "auto")

    {HELP_AUTH_HEADER}

    '''
)

# Generated at 2022-06-21 13:22:27.658402
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(AUTHTYPE_MAP.keys())


# ``requests.auth.HTTPBasicAuth`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this flag to force a specific authentication method.
    For example, to force the use of HTTP Basic Auth, use
        --auth-type=basic

    Available auth types:
    {available_auth_types}

    '''.format(
        available_auth_types=', '.join(sorted(AUTHTYPE_MAP.keys()))
    )
)

#######################################################################
#  Timeouts
#######################################################################

timeouts = parser.add_argument_

# Generated at 2022-06-21 13:22:36.374871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['basic', 'digest']) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. Currently supported authentication
    mechanisms are:

        "basic"
        "digest"

    ''',
)
auth.add_argument(
    '--auth-send',
    action='store_true',
    help='''
    Send credentials for all requests, even unauthenticated ones.

    '''
)

#######################################################################
# Custom configuration
#######################################################################
other = parser.add_argument_group(title='Other')

# Generated at 2022-06-21 13:22:46.713140
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    tester = _AuthTypeLazyChoices()
    assert list(iter(tester)) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:22:56.694004
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(
        plugin_manager.get_auth_plugin_mapping().keys()) == [
            item for item in _AuthTypeLazyChoices()]

auth.add_argument(
    '--auth-type',
    default='auto',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of credentials to send to the server. The option is only needed if
    you want to force HTTPie to use Basic/Digest/etc auth when following a
    redirect from a site served via Negotiate/NTLM.
    Specifying --auth-type without --auth is only useful for the "auto" choice
    (which means auto-detection).

    Plugins can add their own auth types, e.g., `--auth-type=bearer`.

    '''
)

# Generated at 2022-06-21 13:22:58.973507
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert AUTH_PLUGIN_MAP.keys() == _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:01.919179
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    auth_type_lazy_choices = _AuthTypeLazyChoices()

    assert 'basic' in auth_type_lazy_choices


# Generated at 2022-06-21 13:23:13.099083
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert {'basic', 'digest'} <= set(lazy_choices)

# Generated at 2022-06-21 13:23:21.075438
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'Digest' in auth_type
    assert 'MyAuthPlugin' in auth_type

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin to use.
    It is only required if HTTPie has to choose among multiple plugins.

    '''
)

# Generated at 2022-06-21 13:23:31.396587
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type', '-A',
    metavar='TYPE',
    type=CaseInsensitiveChoices(),  # Accept both `basic` or `Basic`.
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The authentication type to be used.
    You can use a custom auth type added by a plugin.

    ''',

)

# Generated at 2022-06-21 13:23:34.336068
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'test' not in lazy_choices


# Generated at 2022-06-21 13:23:39.661400
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(builtin_auth_plugins + [
        AUTH_PLUGIN_NAME_TOKEN,
        'digest',
        'multipart',
        'netrc',
    ])) == list(_AuthTypeLazyChoices())

_AUTH_CHOICES_TYPE = _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:43.731603
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()
    assert 'mock' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:23:44.370094
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): pass

# Generated at 2022-06-21 13:23:51.865705
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_class = _AuthTypeLazyChoices()
    assert 'token' in test_class
    assert 'notexist' not in test_class
    assert 'basic' in test_class
    assert sorted([i for i in test_class]) == [
        'anyauth',
        'basic',
        'digest',
        'hawk',
        'ntlm',
        'token'
    ]


# Generated at 2022-06-21 13:23:54.071133
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in _AuthTypeLazyChoices()] == ['bearer', 'digest']

# Generated at 2022-06-21 13:24:06.760858
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of HTTP authentication to use for requests.
    The default is Basic, for which the ``--auth`` option is used.

    ''',
)

auth_type.completer = ChoicesCompleter(auth_type.choices)

auth.add_argument(
    '--auth-type=basic',
    dest='auth',
    default=None,
    help=argparse.SUPPRESS,
)


# Generated at 2022-06-21 13:24:20.589763
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:31.857236
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy = _AuthTypeLazyChoices()
    assert list(lazy) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:24:32.563626
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:24:40.228580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():  # noqa: E302
    assert list(_AuthTypeLazyChoices()) == [
        'aws', 'aws_s3', 'digest', 'gssnegotiate', 'hmac', 'jwt', 'kerberos',
        'oauth1a', 'oauth2', 'ntlm']


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin by name.

    '''
)

# Generated at 2022-06-21 13:24:48.307373
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'jwt' in auth_types
    assert 'basic' in auth_types
    assert 'bearer' in auth_types
    assert 'hawk' in auth_types
    assert 'oauth1' in auth_types
    assert 'custom' in auth_types


# Generated at 2022-06-21 13:24:55.534342
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # The type is a subclass of list, so should be iterable.
    assert hasattr(_AuthTypeLazyChoices, '__iter__')

    # Should contain all elements provided by plugins
    assert "digest" in _AuthTypeLazyChoices
    assert "bearer" in _AuthTypeLazyChoices

    # Should contain only the elements provided by plugins
    assert "oauth1" not in _AuthTypeLazyChoices

    # Should return a sorted list
    returned_list = list(_AuthTypeLazyChoices)
    assert returned_list == sorted(returned_list)


# Generated at 2022-06-21 13:24:59.803916
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('basic' in _AuthTypeLazyChoices()) is True
    assert ('digest' in _AuthTypeLazyChoices()) is True
    assert ('fake' in _AuthTypeLazyChoices()) is False
    class FakePluginManager:
        @staticmethod
        def get_auth_plugin_mapping():
            return {}
    with patch('httpie.cli.plugin_manager', FakePluginManager):
        assert ('fake' in _AuthTypeLazyChoices()) is False



# Generated at 2022-06-21 13:25:01.526075
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'django' in _AuthTypeLazyChoices()
    assert 'x' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:02.636765
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert {'basic'} <= _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:09.187039
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    '''
)

auth.add_argument(
    '--auth-plugin',
    metavar='PLUGIN',
    help='''
    A custom authentication plugin.

    '''
)

# Generated at 2022-06-21 13:25:57.944885
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types


auth.add_argument(
    '--auth-type', '--auth-plugin',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used.

    Basic HTTP authentication is the default and only built-in
    mechanism. Plugins can be used to implement other types,
    such as OAuth 1.0/a.

    ''',
)


# Generated at 2022-06-21 13:26:08.839580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication type to be used. The available options depend on the
    installed plugins. {plugin_manager.list_auth_plugins()}
    '''
)

#######################################################################
# HTTP and HTTPS
#######################################################################
http = parser.add_argument_group(title='HTTP')

http.add_argument(
    '--follow', '-F',
    action='store_true',
    default=False,
    help='''
    Follow redirects.

    '''
)

# Generated at 2022-06-21 13:26:10.681673
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'abc' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:26:20.475569
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(['digest', 'jwt', 'hawk'])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a different authentication mechanism.
    Currently supported: {_AuthTypeLazyChoices()}.

    This can also be configured in the config file as:
    {' '.join(
            '{0} = {1}'.format(
                key, indent(value.strip(), 4).strip())
            for key, value in AUTH_PLUGIN_CONFIG_HINTS.items())}

    '''
)


# Generated at 2022-06-21 13:26:22.516579
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )



# Generated at 2022-06-21 13:26:30.593335
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    help='''
    Authentication protocol to use for the request. The default, "auto", detects
    the scheme from the --auth argument. Specify the protocol explicitly via
    one of the following:

      {auth_types}

    '''.format(
        auth_types='\n      '.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(_AuthTypeLazyChoices()), 60)
        ).strip()
    )
)

auth_plugin_mapping = plugin_manager.get_auth_plugin_mapping()

# Generated at 2022-06-21 13:26:38.735201
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, collections.abc.Container)
    assert isinstance(choices, collections.abc.Sequence)
    assert isinstance(choices, collections.abc.Set)
    assert isinstance(choices, collections.abc.MutableSet)
    assert isinstance(choices, collections.abc.Sized)
    assert isinstance(choices, collections.abc.Iterable)
    assert isinstance(choices, collections.abc.Reversible)
    assert str(choices) == '_AuthTypeLazyChoices()'
    assert repr(choices) == '_AuthTypeLazyChoices()'
    assert len(choices) == len(plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-21 13:26:44.573719
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert type(_AuthTypeLazyChoices).__name__ == "_AuthTypeLazyChoices"
    _object = _AuthTypeLazyChoices()
    # AssertionError: {'aws4-hmac-sha256', 'oauth1', 'basic', 'aws4-signature', 'digest', 'hawk', 'aws4-sigv4'} != ['aws4-hmac-sha256', 'aws4-sigv4', 'aws4-signature', 'basic', 'digest', 'hawk', 'oauth1']
    #assert set(_object) == ['aws4-hmac-sha256', 'aws4-sigv4', 'aws4-signature', 'basic', 'digest', 'hawk', 'oauth1']
    #assert isinstance(_object, _AuthTypeLazyChoices)
    #

# Generated at 2022-06-21 13:26:54.855156
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices

auth.add_argument(
    # TODO: add type=str.lower when support for Python3.3 is dropped.
    # See https://github.com/jakubroztocil/httpie/issues/902
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication type. The default
    is to detect the auth type based on the auth plugin
    implementation.

    '''
)

# Generated at 2022-06-21 13:26:57.387134
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert a.__iter__()
    assert len(list(a)) == 3
    assert 'basic' in a
    assert 'digest' in a
    assert 'hawk' in a


# Generated at 2022-06-21 13:28:12.707285
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class FakeAuthPlugin:
        auth_type = 'fake-auth'
    _auth_plugin_manager = plugin_manager.AuthPluginManager({
        'fakeauth': FakeAuthPlugin
    })
    _AuthTypeLazyChoices.__contains__(_auth_plugin_manager, 'fake-auth')


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. May be one of "basic",
    "digest", "hawk" or "netrc". If this argument is not provided, it is
    guessed based on the presence of a password in the --auth option.

    '''
)



# Generated at 2022-06-21 13:28:21.797011
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'hawk' in auth_type_lazy_choices
    assert 'oauth1' in auth_type_lazy_choices
    assert 'ntlm' in auth_type_lazy_choices
    all_choices = [choice for choice in auth_type_lazy_choices]
    all_choices.sort()
    assert all_choices == ['basic', 'digest', 'hawk', 'ntlm', 'oauth1']


# Generated at 2022-06-21 13:28:32.938974
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'ntlm' in auth_type_choices
    assert 'oauth1' in auth_type_choices
    assert 'plugin' in auth_type_choices


# Generated at 2022-06-21 13:28:40.089365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices) == ['basic', 'digest']


# Generated at 2022-06-21 13:28:49.205253
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert AUTH_PLUGIN_MAP_BASIC in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specified authentication plugin.

    Available plugins:

    {plugins}

    '''.format(
        plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', plugin) for plugin in
            plugin_manager.get_auth_plugin_mapping()
        ).strip()
    )
)

#######################################################################
# Other arguments
#######################################################################
# ``requests.request`` keyword arguments.
other = parser.add_argument_group(title='Other')

# Generated at 2022-06-21 13:28:50.400128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:28:56.009105
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    mock_plugins_mapping = {
        'auth1': 'AUTH_PLUGIN',
        'auth2': 'AUTH_PLUGIN'
    }
    with patch(
            'httpie.cli.plugin_manager'
            '.get_auth_plugin_mapping'
    ) as get_auth_plugin_mapping:
        get_auth_plugin_mapping.return_value = mock_plugins_mapping
        assert 'auth1' in _AuthTypeLazyChoices()
        assert 'auth2' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:29:04.700895
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Bearer' in _AuthTypeLazyChoices()
    assert 'Bearer' in list(_AuthTypeLazyChoices())
    assert 'bearer' not in _AuthTypeLazyChoices()
    assert 'bearer' not in list(_AuthTypeLazyChoices())
_AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices,
    help='''
    How to perform authentication. By default, the "auto" plugin is used, which
    will try to use the most secure plugin available: digest, then basic.

    ''',
)
