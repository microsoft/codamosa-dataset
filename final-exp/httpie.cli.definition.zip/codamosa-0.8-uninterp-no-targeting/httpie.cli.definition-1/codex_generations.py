

# Generated at 2022-06-21 13:19:03.870516
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin_class_name' in _AuthTypeLazyChoices()
    assert 'non_existing' not in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose the auth plugin to use. Only relevant when the --auth option is
    provided.

    The default, and currently the only auth plugin is basic, which provides
    support for HTTP Basic Authentication.

    Auth plugins are discovered automatically when installed to the
    entry-points defined in setup.py.

    '''
)

#######################################################################
# Other
#######################################################################

other

# Generated at 2022-06-21 13:19:04.768853
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:12.795784
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is 'basic', which
    corresponds to HTTP Basic Authentication. Other built-in options are 'digest'
    and 'ntlm'.

    '''
)

auth_plugins = plugin_manager.get_auth_plugins()
for _auth_plugin in auth_plugins:
    for _auth_type, _arg_info in _auth_plugin._get_auth_type_arg_info():
        _arg_info.pop('name')
        auth.add_argument(_auth_type, **_arg_info)

#######################################################################
# SSL
####################################################################

# Generated at 2022-06-21 13:19:15.562318
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-21 13:19:23.925655
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """Unit test for method __contains__ of class _AuthTypeLazyChoices"""
    _contains__ = _AuthTypeLazyChoices().__contains__

    assert 'digest' in _contains__


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication mechanism. The following are built-in:

        {builtin_auth_types}

    You can also provide your own custom mechanism by installing a
    {auth_plugin_intro}.

    '''
)

# Generated at 2022-06-21 13:19:32.364537
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(_AuthTypeLazyChoices())


auth_arg = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific auth mechanism.
    The default is to autodetect. If the server returns a 401 Unauthorized
    response, HTTPie tries Basic and then Digest auth.

    '''
)



# Generated at 2022-06-21 13:19:43.157641
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

# ``requests.auth.HTTPBasicAuth`` and ``requests_ntlm.HttpNtlmAuth``
# keyword arguments.
auth_plugin_args = parser.add_argument_group(title='Auth Plugin Options')
auth_plugin_args.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the auth plugin to use. It can be one of the built-in plugins
    or a 3rd-party plugin. You can see a list of installed plugins by running
    "http --debug".

    The default is "{DEFAULT_AUTH_PLUGIN}".

    ''',
)

# Generated at 2022-06-21 13:19:45.732002
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'oauth2' not in choices
    assert 'does-not-exist' not in choices



# Generated at 2022-06-21 13:19:58.211012
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())
    'basic' in _AuthTypeLazyChoices()
    'basic' not in _AuthTypeLazyChoices()

AUTH_TYPE_CHOICES = _AuthTypeLazyChoices()
AUTH_TYPE_HELP = "Authentication type. Defaults to 'basic' if no other type is specified"
auth.add_argument(
    '--auth-type',
    default=None,
    help=AUTH_TYPE_HELP,
    choices=AUTH_TYPE_CHOICES
)

# Generated at 2022-06-21 13:20:05.841365
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert not hasattr(plugin_manager, '_plugin_mapping')
    assert not hasattr(plugin_manager, '_plugin_names')
    auth_types = _AuthTypeLazyChoices()
    assert set(auth_types) == AUTH_PLUGIN_MAPPING
    assert set([auth_type for auth_type in auth_types]) == AUTH_PLUGIN_MAPPING


# Generated at 2022-06-21 13:20:22.293503
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )



# Generated at 2022-06-21 13:20:24.251007
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(['basic', 'digest']) == list(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:20:33.012455
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported mechanisms are
    "basic" and "digest".

    ''',
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Use it to explicitly disable support for the .netrc file.

    '''
)

#######################################################################
# Connection options
#######################################################################

connection = parser.add_argument_group(title='Connection')


# Generated at 2022-06-21 13:20:36.809215
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    n = _AuthTypeLazyChoices()
    from functools import partial
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(map(partial(getattr,''.join),iter(n)))

# Generated at 2022-06-21 13:20:38.060795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:20:38.706228
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass

# Generated at 2022-06-21 13:20:49.707496
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.compat import is_py3
    if not is_py3:
        import sys
        reload(sys)
        sys.setdefaultencoding('UTF8')
    lazy_choice = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choice
    assert 'digest' in lazy_choice
    assert '2fa-totp' in lazy_choice
    assert list(lazy_choice) == ['2fa-totp', 'basic', 'digest']



# Generated at 2022-06-21 13:20:59.929260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(iter(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH,
    dest='auth_plugin',
    help=f''' (default: {DEFAULT_AUTH})
    Choose an auth handler. Available choices:

        {', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )}

    For more details, please check:

        https://httpie.org/plugins

    '''
).completer = _AuthTypeLazyChoices()

#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_group(title='HTTPS')

# Generated at 2022-06-21 13:21:03.757101
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:10.227175
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert plugin_manager.get_auth_plugin_mapping().keys() == {'basic'}
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' not in auth_type_lazy_choices
    register_plugin('digest', AuthPlugin)
    assert 'digest' in auth_type_lazy_choices

# Generated at 2022-06-21 13:21:23.323403
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    assert iter(auth_types) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth_type_validator = AuthTypeValidator(
    # The list of valid auth types is lazily determined on the first use.
    valid_choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify an auth plugin. By default, it is determined on the
    basis of the provided username and password. When no username and
    password is provided and this field is not specified, the authentication
    is determined from the URL.

    For example, to use OAuth 1.0 when the username is an API key:

        http -a user: HEAD api.example.org Authorization:""

    '''
)

# Generated at 2022-06-21 13:21:26.625904
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    This unit test test method __contains__ of class _AuthTypeLazyChoices
    :return:
    """
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:38.170393
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted([
        'basic', 'digest', 'hawk', 'netrc', 'oauth1', 'oauth2'
    ]))
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism.

    ''',
)
auth.add_argument(
    '--auth-type-name',
    default=None,
    metavar='TYPE_NAME',
    help='''
    Specifies the authentication type name.

    ''',
)

# Generated at 2022-06-21 13:21:39.522933
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'DigestAuth' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:21:54.114129
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'http' in _AuthTypeLazyChoices()
    assert 'oauth' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()


auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-21 13:22:03.177410
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    help=f'''
    Specify an auth plugin. For example: {', '.join(_AuthTypeLazyChoices())}.

    Use --debug to find out what's available.

    ''',
    choices=_AuthTypeLazyChoices(),
)


# Generated at 2022-06-21 13:22:05.398219
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-21 13:22:16.890468
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert sorted(list(auth_type_choices)) == sorted(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Supported choices:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            (8 * ' ') + line.strip() for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                50,
            ).strip()
        )
    )
)

# Generated at 2022-06-21 13:22:28.076996
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'foo' not in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert sorted('foo') == ['f', 'o', 'o']
    assert sorted(['foo']) == ['foo']

# HTTPie plugin argument.

# Generated at 2022-06-21 13:22:36.621841
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic'                in _AuthTypeLazyChoices()
    assert 'Token'                in _AuthTypeLazyChoices()
    assert 'JWT'                  in _AuthTypeLazyChoices()
    assert 'Digest'               in _AuthTypeLazyChoices()
    assert 'Bearer'               in _AuthTypeLazyChoices()
    assert 'NTLM'                 in _AuthTypeLazyChoices()
    assert 'Negotiate'            in _AuthTypeLazyChoices()
    assert 'AWS'                  in _AuthTypeLazyChoices()
    assert 'Kerberos'             in _AuthTypeLazyChoices()
    assert 'OAuth1'               in _AuthTypeLazyChoices()
    assert 'OAuth2'               in _AuthTypeLazyChoices()
    assert 'Hawk'                 in _

# Generated at 2022-06-21 13:22:48.170990
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'Bearer' in choices
    assert 'BASIC' not in choices
    assert 'Foo' not in choices


# Generated at 2022-06-21 13:22:57.316187
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    type=str.lower,
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism to use.
    '''
)


# ``requests.request`` keyword arguments.
verify = parser.add_argument_group(title='SSL Verification')

# Generated at 2022-06-21 13:23:08.067605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-21 13:23:17.055671
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:27.773362
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mapping = plugin_manager.get_auth_plugin_mapping()
    for key in _AuthTypeLazyChoices():
        assert key in mapping
    assert 'foo' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication mechanism. The default is to
    automatically detect the most secure mechanism supported by the server.

    To see a list of all supported authentication mechanisms, run:

        $ http --debug

    '''
)


# Generated at 2022-06-21 13:23:30.288840
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert list(lazy_choices) == ['basic',]



# Generated at 2022-06-21 13:23:37.985772
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    help='Authentication mechanism',
    choices=_AuthTypeLazyChoices()
)
auth.add_argument(
    '--auth-verify',
    default=False,
    metavar='yes|no',
    choices=('yes', 'no'),
    help="""If yes, SSL certificate will be verified.
    It can also be set to 'no' to skip verification.""",
)

# Generated at 2022-06-21 13:23:48.135593
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help='''
    Specify the authentication mechanism, be it "basic", "digest", "aws", etc.
    See Plugins section of the HTTPie docs to learn what plugins are
    available.

    ''',
)
auth.add_argument(
    '--auth-host',
    help='''
    Hostname to use for authentication plugin, if plugin requires
    host-specific credentials (such as AWS S3).

    '''
)

#######################################################################
# Pretty
#######################################################################

pretty = parser.add_argument_group(title='Pretty')

pretty.add_argument

# Generated at 2022-06-21 13:24:00.177630
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

_auth_type_choices = _AuthTypeLazyChoices()
auth_type_choices = ', '.join(sorted(_auth_type_choices))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_auth_type_choices,
    help=f'''
    Default: basic.

    Other values: {auth_type_choices}.

    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    Default: basic.

    Other values: digest.

    '''
)

auth.add

# Generated at 2022-06-21 13:24:05.663260
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Unit test for method __iter__ of class _AuthTypeLazyChoices
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_plugin = auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    # choices=plugin_manager.get_auth_plugin_mapping().keys(),
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth plugin to use. Can be:
        {available_plugins}
    '''.format(available_plugins=", ".join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-21 13:24:21.168994
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices().__iter__()

# Generated at 2022-06-21 13:24:26.085526
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    class MockAuthPlugin(AbstractAuthPlugin):
        name = 'mock_auth_plugin'

    with PluginManager(AuthPluginManager, MockAuthPlugin()):
        assert 'mock_auth_plugin' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:27.592279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:36.636041
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(auth_type_choices) == sorted([
        'basic',
        'digest',
        'multipart',
        'custom',
    ])

auth.add_argument(
    '--auth-type', '--auth-type',
    default='basic',
    metavar='TYPE',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication mechanism. Note that it is needed only when
    the server doesn't advertise a supported authentication method via
    the 401 response or via the WWW-Authenticate header.
    The default is "basic".

    '''
)

# Generated at 2022-06-21 13:24:45.424662
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    return bool(auth_type)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    dest='auth_plugin',
    help='''
    The authentication mechanism to use.

    By default, HTTPie tries to detect the auth mechanism in the following
    order:

        - Basic
        - Digest
        - OAuth1 (2-legged only)

    '''
)

#######################################################################
# HTTP and HTTPS proxy
#######################################################################

proxies = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-21 13:24:48.307059
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices_list = sorted(
        plugin_manager.get_auth_plugin_mapping().keys())
    assert list(_AuthTypeLazyChoices()) == choices_list

# Generated at 2022-06-21 13:24:56.862852
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (
        _AuthTypeLazyChoices() ==
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )

auth_plugin = auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.

    '''
)
# Workaround for http://bugs.python.org/issue9351.
auth_plugin.completer = AuthPluginCompleter(
    sorted(plugin_manager.get_auth_plugin_mapping().keys())
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group('SSL')

ssl_group.add_argument

# Generated at 2022-06-21 13:25:05.326965
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    type=CaseInsensitiveChoices(_AuthTypeLazyChoices()),
    help=f'''
    The authentication mechanism used. "Basic" is the default.
    Available in the current environment:

        {list(_AuthTypeLazyChoices())}

    '''
)


# Generated at 2022-06-21 13:25:07.589827
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'bearer' in choices



# Generated at 2022-06-21 13:25:15.945253
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default, `basic`, is the most common and widely supported.
    HTTPie also supports multiple other schemes, such as 'digest' and
    'aws' (Amazon Web Services).

    '''
)
auth._add_container_actions(
    'auth',
    dest='auth_plugin_args',
    nargs=1,
    metavar='KEY:VALUE',
    help='''
    Parameters to be passed to the auth plugin specified with --auth-type.

    '''
)

################################################################

# Generated at 2022-06-21 13:26:03.354468
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'keyring' not in choices and 'key' not in choices
    for choice in choices:
        assert isinstance(choice, str)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Default value depends on the authentication
    credentials.

    If no credentials are used, the default is "auto", which is a special
    value that causes HTTPie to try to use a plugin appropriate for the URL.

    If credentials are used, the default is "basic", which causes HTTPie to
    use HTTP Basic Auth.

    '''
)

# Generated at 2022-06-21 13:26:13.132867
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(
        _AuthTypeLazyChoices()
    ) == set(
        plugin_manager.get_auth_plugin_mapping()
    )


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Select a custom auth plugin.

    Available auth plugins:
        {', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )}

    To see help for the plugin, run ``http --help-auth=NAME``.

    This option is equivalent to ``--auth-plugin=TYPE``,
    which is deprecated and will be removed in a future release.

    '''
)

# Generated at 2022-06-21 13:26:15.375954
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'noauth' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:26:24.252572
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in _AuthTypeLazyChoices()] ==['basic', 'digest']

auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_type_lazy_choices,
    default=None,
    help='''
    Specify a custom auth plugin.

    Already installed plugins: {installed_plugins}.

    See
    https://github.com/httpie/httpie#authentication for instructions
    on installing and developing plugins.

    '''.format(
        installed_plugins=', '.join(sorted(auth_type_lazy_choices))
    )
)

# Generated at 2022-06-21 13:26:31.781603
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == []


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Select the HTTP authentication type. Default: "basic".
    If plugin for specified type is not installed, error is shown.

    Available auth types: {', '.join(_AuthTypeLazyChoices())}.

    '''
)

# Generated at 2022-06-21 13:26:39.643632
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hmac']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. The default is 'basic'.

    It can also be one of:

        {auth_types}

    '''.format(
        auth_types=wrap(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
            64,
        )
    ),
)

# Generated at 2022-06-21 13:26:42.947685
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(list(iter(_AuthTypeLazyChoices()))) >= 1

# Generated at 2022-06-21 13:26:51.631908
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'basic' in auth_types
    assert 'hawk' in auth_types
    assert sorted(auth_types) == sorted(['digest', 'basic', 'hawk'])


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of auth plugin to use.
    Currently supported: {0}

    '''.format(', '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())))
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:26:52.905528
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:00.308103
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported: basic, digest.

    This option is required when using the ``--auth`` option.
    '''
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    Skip the authentication challenge. Useful for HTTP APIs that expect
    authentication credentials to be sent on the first request.
    '''
)

#######################################################################
# SSL
#######################################################################

# Generated at 2022-06-21 13:28:21.325330
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert set(auth_type_choices) == set(['basic', 'digest'])

auth.add_argument(
    '--auth-type',
    default=None,
    help=f'''
    Used to explicitly specify the auth type to be used
    for all the requests. See {DOCURL}#authentication for more information.
    Supported auth types: {', '.join(_AuthTypeLazyChoices())}.
    ''',
)

auth.add_argument(
    '--auth-endpoint',
    default=None,
    help='''
    Used to specify auth endpoint.
    ''',
)
auth.add_

# Generated at 2022-06-21 13:28:32.473816
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'bearer' in choices
    assert 'basic' in choices
    assert 'digest' in choices
    assert len(list(choices)) == len(plugin_manager.get_auth_plugin_mapping())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use.

    (default: "{default}")

    Can be either a name of an auth plugin, or an import string
    for the plugin class.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME
    )
)

# Generated at 2022-06-21 13:28:39.942136
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth_type = auth.add_mutually_exclusive_group()

# Generated at 2022-06-21 13:28:49.059139
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth_type_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:28:56.716435
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom authentication type for the request.

    Currently supported: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)
auth.add_argument(
    '--digest',
    action='store_true',
    default=False,
    help='''
    Use HTTP Digest Authentication.
    Overrides --auth-type.

    '''
)