

# Generated at 2022-06-21 13:18:54.726345
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:05.458654
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()  # builtin
    assert 'foobar' not in _AuthTypeLazyChoices()
    assert 'digest' in plugin_manager.get_auth_plugin_mapping()
    assert 'foobar' not in plugin_manager.get_auth_plugin_mapping()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the HTTP authentication mechanism (Basic, Digest, NTLM, etc).

    Useful for testing, the default is to try them all in sequence and
    use the first one that works.

    '''

)

# Generated at 2022-06-21 13:19:10.485261
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    token = uuid4().hex.encode()[:6]
    plugin_manager.register_auth_plugin('my_auth_plugin',
                                        lambda _: token)
    assert 'my_auth_plugin' in _AuthTypeLazyChoices()
    plugin_manager.accumulate = True
    assert 'my_auth_plugin' not in _AuthTypeLazyChoices()
    plugin_manager.accumulate = False

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth plugin.

    The value must be one of:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-21 13:19:12.097684
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:19:22.323952
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='SCHEME',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the given authentication scheme. The scheme is usually the name
    of an authentication plugin.

    '''
)
auth.add_argument(
    '--auth-scheme',
    dest='auth_type',
    metavar='SCHEME',
    help=argparse.SUPPRESS
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    default=False,
    action='store_true',
    help='''
    Disable HTTP authentication challenge (HTTP 401).

    '''
)
auth.add_

# Generated at 2022-06-21 13:19:31.153800
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'basic' in auth_types
    assert 'digest' in auth_types
    # Assert that the state of the plugin manager is preserved.
    assert 'netrc' not in auth_types
    assert sorted(list(auth_types)) == ['basic', 'digest']



# Generated at 2022-06-21 13:19:42.296320
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(sorted(auth_type_choices)) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth type to be used. Available built-in auth types: {list(
        sorted(set(plugin_manager.get_auth_plugin_mapping().keys())))}

    '''
)


# Generated at 2022-06-21 13:19:49.680986
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    for key in plugin_manager.get_auth_plugin_mapping().keys():
        assert key in choices

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    Specify an authentication type to be used.
    Available types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}
    '''
)

#######################################################################
# Cookies
#######################################################################
cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:19:53.101154
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    type_ = _AuthTypeLazyChoices()
    assert not isinstance(type_, _AuthTypeLazyChoices)
    assert sorted(type_) == sorted(plugin_manager)



# Generated at 2022-06-21 13:19:57.283537
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'my-custom-auth' in choices
    assert 'non-existing' not in choices

# Generated at 2022-06-21 13:20:03.999427
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'foo' not in choices


# Generated at 2022-06-21 13:20:12.800884
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hmac' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. Defaults to "basic".

    If the value you provide is the name of an in-built mechanism, then that
    mechanism is used.

    If the value starts with ``@``, e.g. ``@path/to/file``, then the file is
    imported as a custom auth plugin. The auth plugin needs to be a subclass of
    ``httpie.plugins.auth.auth.AuthPlugin``.
    '''
)

# custom auth

# Generated at 2022-06-21 13:20:25.217146
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class FakePluginManager(object):
        def get_auth_plugin_mapping(self):
            return {'a': 1, 'b': 1, 'c': 1}
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    auth_type_lazy_choices._plugin_manager = FakePluginManager()
    items = list(auth_type_lazy_choices)
    assert items == ['a', 'b', 'c']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=argparse.SUPPRESS,
)

# Generated at 2022-06-21 13:20:30.179979
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    # The list of keys is sorted as it should be presented in the CLI help
    # message.
    assert list(sorted(_AuthTypeLazyChoices())) == [
        'basic', 'digest', 'hawk', 'jwt', 'netrc', 'oauth1', 'awssigv4',
        'ntlm', 'aws-sigv4-custom'
    ]

# Generated at 2022-06-21 13:20:39.507402
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert "basic" in _AuthTypeLazyChoices()
    for item in _AuthTypeLazyChoices():
        assert isinstance(item, str)


# Generated at 2022-06-21 13:20:50.369760
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    auth_types_set = set(auth_types)
    assert 'basic' in auth_types_set
    assert 'digest' in auth_types_set
    assert 'hawk' in auth_types_set

auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-21 13:21:00.386915
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    If not provided, the authentication mechanism is inferred from the
    provided credentials. If the credentials are just the username,
    then HTTPie prompts for the password.

    Available values:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add_argument(
    '--auth-use-netrc',
    action='store_true',
    help='''
    Use ~/.netrc for looking up the credentials before prompting
    for them.

    '''
)

#######################################################################

# Generated at 2022-06-21 13:21:12.258148
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert {'basic', 'digest'} == set(_auth_type_lazy_choices)



# Generated at 2022-06-21 13:21:22.346593
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'test_auth' in _AuthTypeLazyChoices()


AUTHTYPE_LAZY_CHOICES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=AUTHTYPE_LAZY_CHOICES,
    metavar='TYPE',
    help='''
    If set, HTTPie will use the auth plugin of the provided type.
    The default is to use the auth plugin that supports the URL's host.

    '''
)

# Generated at 2022-06-21 13:21:28.078426
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in lazy_choices
    assert 'bearer' in lazy_choices
    assert 'hmac' in lazy_choices
    assert 'basic' in lazy_choices

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=auth_type_choices,
    help='''
    The auth mechanism to be used.
    If not provided, an appropriate one is selected automatically,
    based on the hostname. When using --auth-type=digest, the server
    must support RFC 7616 (Digest).

    ''',
)


# Generated at 2022-06-21 13:21:36.768418
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:21:44.399745
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:21:58.062649
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.
    The available types are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)
auth.add_argument(
    '--auth-type-force',
    action='store_true',
    help='''
    By default, HTTPie first tries to use the selected auth type, but it falls
    back to a different one if that didn't work. This option disables the fall
    back mechanism.

    '''
)

# Generated at 2022-06-21 13:22:10.566645
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication protocol to use. Only relevant when --auth is used.

    The supported protocols are:

        {types}

    '''.format(
        types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip()
    )
)

#######################################################################
# Timeouts
#######################################################################
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-21 13:22:22.122582
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to use. Available choices depend on the
    plugins available. The default is `basic`.

    ''',
)
auth.add_argument(
    '--auth-type-2069',
    default=False,
    action='store_true',
    help='''
    The 2069 digest authentication algorithm. This is a variant of digest
    authentication which doesn't require access to the cleartext password.
    It is deprecated and you will want to use --auth-type=digest.

    '''
)


#######################################################################
#

# Generated at 2022-06-21 13:22:32.461639
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'gssnegotiate' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()
    assert 'awsv4' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:22:44.147885
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins import AuthPlugin, plugin_manager
    _ = plugin_manager.clear()
    plugin = AuthPlugin('test', None)
    plugin_manager.add(plugin)
    assert plugin.name in _AuthTypeLazyChoices()
    _ = plugin_manager.clear()
    assert plugin.name not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:22:54.687479
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []

    plugin_manager.importer.register_plugin_class(AuthPluginMock)
    assert list(_AuthTypeLazyChoices()) == ['mock']


_auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    # choices=_auth_type_lazy_choices,
    choices=plugin_manager.get_auth_plugin_mapping().keys(),
    help='''
    Authentication method to be used.

    '''
)

#######################################################################
# HTTP method
#######################################################################

http = parser.add_argument_group(title='HTTP method')

# HTTP method aliases.

# Generated at 2022-06-21 13:23:06.661123
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication provider

    ''',
)
#######################################################################
# HTTP
#######################################################################

http = parser.add_argument_group(title='HTTP')

http.add_argument(
    '--headers',
    metavar='HEADER',
    help='''
    Custom headers, e.g. "X-API-Token:123, X-Another: abc".
    This option can be used multiple times.

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:23:13.609579
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'BearerToken' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='TYPE',
    type=str.upper,
    default='BASIC',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication type (case insensitive).
    Currently supported:

    {__AuthTypeLazyChoices.__doc__}


    '''
)


# Generated at 2022-06-21 13:23:35.940836
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert [] == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert len(list(_AuthTypeLazyChoices())) == 0


# Generated at 2022-06-21 13:23:46.635170
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie import __main__ as main
    assert list(_AuthTypeLazyChoices()) == list(main.ARG_TYPES['auth_type'])

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default,
    the "basic" mechanism is used. Other mechanisms
    can be used if their respective plugin is installed.
    Use `http --help-auth` to list the plugins.

    '''
)

# Generated at 2022-06-21 13:23:49.002845
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'netrc', 'oauth1', 'aws'
    ]


# Generated at 2022-06-21 13:24:01.211321
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mocked_plugin_manager = MockedPluginManager(
        plugin_manager.get_auth_plugin_mapping()
    )
    _AuthTypeLazyChoices = _AuthTypeLazyChoices.__func__(mocked_plugin_manager)
    assert set(_AuthTypeLazyChoices) == set(sorted(
        mocked_plugin_manager.get_auth_plugin_mapping().keys()
    ))


# Generated at 2022-06-21 13:24:05.647309
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'never-gonna-be-auth-type' not in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:16.666482
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    instance = _AuthTypeLazyChoices()
    assert 'basic' in instance
    assert 'digest' in instance
    assert 'foo' not in instance
    assert list(instance) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    help='''
    Explicitly specify auth type (Basic, Digest).
    ''',
    choices=_AuthTypeLazyChoices(),
)
auth.add_argument(
    '--auth-endpoint',
    help='''
    The URL of a custom endpoint for authentication.
    '''
)

#######################################################################
# Transport
#######################################################################

transport = parser.add_argument_group(title='Transport')


# Generated at 2022-06-21 13:24:24.039684
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
# End of test case for method __iter__ of class _AuthTypeLazyChoices
auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Can be one of:
        {0}
    The default is "{1}".
    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
        DEFAULT_AUTH_PLUGIN_NAME,
    ))

#######################################################################
# Certificates
#######################################################################

# ``

# Generated at 2022-06-21 13:24:26.550101
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choice = _AuthTypeLazyChoices()
    assert 'digest' in choice
    assert 'bearer' not in choice


# Generated at 2022-06-21 13:24:35.912902
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(_AuthTypeLazyChoices())

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:24:42.714477
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use this authentication type. You can use `http --auth-types` to see
    a list of supported authentication types. When no type is specified,
    HTTPie will try to guess what you want.

    The `digest` type supports HTTP Digest Authentication, and `hawk`
    supports the Hawk Authentication Scheme.

    Other types can be provided through plugins.

    '''
)

# Generated at 2022-06-21 13:25:30.678356
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism:

    - for Basic/Digest, use "basic" or "digest".
    - for Bearer Token authentication, the value is an API key in itself,
      which is provided as a string.
    - any other string is considered to be the name of a class to be loaded
      dynamically, e.g., to register an auth plugin.

    '''
)

# Generated at 2022-06-21 13:25:38.867865
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(_AuthTypeLazyChoices())) == [
        auth_name for auth_name in sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
            )
        ]

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Select authentication plugin (default is '{DEFAULT_AUTH_PLUGIN}').

    '''
)

#######################################################################
# HTTP and HTTPS
#######################################################################


# Generated at 2022-06-21 13:25:44.777640
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Fixture
    _AuthTypeLazyChoices

    # Exercise
    choices = list(_AuthTypeLazyChoices())

    # Verify
    assert choices == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify the authentication mechanism.

    Use "auto" to automatically detect the authentication mechanism,
    and "none" to disable authentication.

    To view all available authentication options, run:

        $ http --auth-type=help

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group('''SSL''') \
   

# Generated at 2022-06-21 13:25:57.614795
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # There is an implicit test in test_plugin.py (test_auth_plugin).
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.
    By default, it is guessed, but can be forced with this option.

    Currently supported: {supported_auth_types}

    '''.format(supported_auth_types=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-21 13:26:03.027045
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from tests.constants import DEFAULT_PLUGINS_DIR
    from httpie.cli.plugins import plugin_manager
    plugin_manager.load_from_cwd()
    plugin_manager.load_from_directory(DEFAULT_PLUGINS_DIR)
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'nonexistent' not in choices # can work with a bad provider name

auth_type = parser.add_argument_group(title='Auth Type')

auth_type.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism, the default is "basic".

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument

# Generated at 2022-06-21 13:26:12.867835
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert list(choices) == ['basic', 'digest', 'hawk']


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin.

    Available values (ask httpie --help-auth for details):

        {choices_string}

    '''
).completer = ChoicesCompleter(choices=_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:26:22.071758
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == []
    class TestAuthPlugin:
        auth_type = 'test'
    plugin_manager.register(TestAuthPlugin)
    assert list(_AuthTypeLazyChoices()) == ['test']


# Generated at 2022-06-21 13:26:24.045810
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'jwt', 'multi', 'netrc', 'oauth1', 'basic']



# Generated at 2022-06-21 13:26:25.676520
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('test')

# Generated at 2022-06-21 13:26:34.599124
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth_type_validator = AuthPluginValidator(
    'Auth plugin "{plugin_name}" not installed.\n'
    'Use `{cli_name} plugin install {plugin_name}` to install it.\n'
    'Use `{cli_name} plugin list to see all available plugins.'.format(
        cli_name=CLI_NAME,
    )
)


# Generated at 2022-06-21 13:27:45.220952
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert all(isinstance(c, str) for c in choices)
    assert 'basic' in choices
    assert 'digest' in choices

# ``requests.auth.HTTPBasicAuth`` and ``requests.auth.HTTPDigestAuth``
# keyword arguments.

# Generated at 2022-06-21 13:27:48.190006
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == \
        list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-21 13:27:53.712719
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    options = _AuthTypeLazyChoices()
    assert isinstance(options, collections.abc.Iterable)
    assert 'kerberos' in options
    assert 'digest' in options
    assert 'basic' in options
    assert 'ntlm' in options
    assert sorted(list(options)) == plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-21 13:28:01.283802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    # If not given, the default plugin is used.
    help='''
    The authentication mechanism to be used. The following options are
    supported. If not given, the default mechanism is used.

    ''',
)

auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=False,
    help='''
    Verify HTTP server certificate when an HTTPS request is sent.

    '''
)


# Generated at 2022-06-21 13:28:11.672514
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()
    assert 'oauth1' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is "basic".
    Other supported values are: {0}.
    '''.format(', '.join(sorted(_AuthTypeLazyChoices())))
)



# Generated at 2022-06-21 13:28:13.937033
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:28:15.134889
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('basic')

# Generated at 2022-06-21 13:28:23.142110
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Allows to manually override the autodetected authentication mechanism.
    Currently supported auth types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

#######################################################################
# Timeouts
#######################################################################
# ``requests.request`` keyword arguments:
timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-21 13:28:33.826854
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(list(_AuthTypeLazyChoices())) == set(['hawk', 'basic'])

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported: basic, hawk.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not send an initial authentication challenge (OPTIONS or HEAD request);
    proceed directly with the actual request method.

    This can help when the server behaves incorrectly (e.g., when --auth
    is used with an incorrect password).

    '''
)

#######################################################################
# Advanced
#######################################################################


# Generated at 2022-06-21 13:28:35.666749
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Basic ' not in _AuthTypeLazyChoices()