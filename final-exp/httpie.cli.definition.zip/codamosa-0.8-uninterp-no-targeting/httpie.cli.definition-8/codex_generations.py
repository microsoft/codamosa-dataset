

# Generated at 2022-06-21 13:18:57.603145
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices


# Generated at 2022-06-21 13:19:07.908108
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication mechanism, such as "basic", "digest", or "aws".
    If not specified, HTTPie will attempt to guess it based on the provided
    URL and credentials.
    Available authentication mechanisms are:
    {auth_types}
    '''.format(
        auth_types=(
            '\n'.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
        )
    )
)

# Generated at 2022-06-21 13:19:19.932534
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

AUTH_TYPE_LAZY_CHOICES = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    choices=AUTH_TYPE_LAZY_CHOICES,
    help='''
    The authentication mechanism to be used.

    Possible values depend on the installed plugins.
    Run `$ http --plugins` to see the available options.

    The recommended plugins are:

        httpie-digest-auth

        httpie-jwt-auth

        httpie-hawk-auth

        httpie-netrc-auth

    ''',
)


# Generated at 2022-06-21 13:19:22.506565
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'fake_auth' not in lazy_choices

# Generated at 2022-06-21 13:19:23.834249
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest']

# Generated at 2022-06-21 13:19:33.995954
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'myplugin' in _AuthTypeLazyChoices()
    assert 'DoesNotExist' not in _AuthTypeLazyChoices()
    assert 'MyPlugin' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    help='''
    Specify an auth type to be used with the given credentials.
    If not provided, the default basic auth is used.

    ''',
    choices=_AuthTypeLazyChoices()
)

# Generated at 2022-06-21 13:19:38.657134
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices
    assert 'NotExist' not in auth_type_lazy_choices

# Generated at 2022-06-21 13:19:40.136882
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:19:48.361960
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'plugin_name' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, e.g. "basic" or "digest".
    Defaults to "basic".

    ''',
)

# Generated at 2022-06-21 13:19:54.736146
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        class MockAuthPlugin(AuthPlugin): pass
        plugin_manager.plugin_manager.add_plugin(MockAuthPlugin)
        auth_type = _AuthTypeLazyChoices()
        assert MockAuthPlugin.auth_type in auth_type
    finally:
        plugin_manager.plugin_manager.remove_plugin(MockAuthPlugin)

# Generated at 2022-06-21 13:20:10.336477
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted([
        'basic',
        'digest',
    ]) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Documentation for class _AuthTypeLazyChoices
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specific authentication mechanism. When not specified,
    HTTPie will attempt to determine the most secure mechanism
    supported by the server.
    This option can be used to explicitly disable an authentication method
    (e.g., --auth-type=basic), or to request a mechanism explicitly when the
    server doesn't include an Auth-Type header (e.g., --auth-type=digest).
    '''
)

#######################################################################
# HTTPS
################################

# Generated at 2022-06-21 13:20:23.057806
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert sorted(list(choices)) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. Currently supported values:

    ''' + plugin_manager.get_auth_plugins_doc(),
)

# Generated at 2022-06-21 13:20:28.231809
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:20:34.379293
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    x = _AuthTypeLazyChoices()
    assert isinstance(x, _AuthTypeLazyChoices)
    assert iter(x) and not isinstance(iter(x), list)
    assert 'basic' in x

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.
    This can be one of the built-in mechanisms:

        {', '.join(sorted(AUTH_PLUGINS_BUILTIN))}

    or one provided by a plugin.

    '''
)


# Generated at 2022-06-21 13:20:37.232552
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    >>> lazy_choices = _AuthTypeLazyChoices()
    >>> 'digest' in lazy_choices
    True
    >>> 'basic' in lazy_choices
    True
    """

# Generated at 2022-06-21 13:20:45.067114
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'oauth1' in choices
    #assert 'oauth2' in choices
    # Unregister oauth2 Auth plugin
    assert 'oauth2' in choices
    plugin_manager.unregister_auth_plugin('oauth2')
    assert 'oauth2' not in choices
    # Cleanup
    plugin_manager.register_auth_plugin('oauth2') #BUG
    assert 'oauth2' in choices


# Generated at 2022-06-21 13:20:46.531655
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:20:57.831393
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    __contains__ = _AuthTypeLazyChoices.__contains__
    __iter__ = _AuthTypeLazyChoices.__iter__

    assert 'fake' in __contains__
    assert 'real' not in __contains__
    assert 'real' in __contains__

    assert list(__iter__()) == sorted(['fake', 'real'])
    assert list(__iter__()) == sorted(['fake', 'real', 'another'])



# Generated at 2022-06-21 13:21:11.094751
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())

# ``requests.request`` keyword argument.
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authorization mechanism to use. The available choices are: {choices}

    '''.format(
        choices=', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        ))
    )
)


# Generated at 2022-06-21 13:21:15.881478
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the use of a specific authentication mechanism. If not specified,
    HTTPie attempts to guess it based on the --auth option value.

    ''',
)

verify = parser.add_argument_group(title='SSL')

# Generated at 2022-06-21 13:21:25.626541
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'new-something' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:34.636568
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:21:43.030156
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'AWS' in choices
    choices = list(choices)
    assert 'Basic' in choices
    assert 'Digest' in choices
    assert 'AWS' in choices


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used:
    ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
)

#######################################################################
# Wget-like options
#######################################################################


# Generated at 2022-06-21 13:21:56.996465
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    lhs, rhs = _AuthTypeLazyChoices(), sorted(plugin_manager.get_auth_plugin_mapping().keys())
    assert sorted(lhs) == rhs

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    help='The auth mechanism to be used.'
)
auth.add_argument(
    '--auth-verify',
    action='store_false',
    dest='auth_verify_ssl',
    help='Do not verify auth server SSL certificate.'
)

# Generated at 2022-06-21 13:22:09.299659
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import AuthPluginManager
    from httpie.plugins.auth.builtin import BasicAuthPlugin
    from httpie.plugins.auth.builtin import DigestAuthPlugin
    from httpie.plugins.auth.builtin import HawkAuthPlugin

    class TestAuthPluginManager(AuthPluginManager):
        def __init__(self):
            super(TestAuthPluginManager, self).__init__()
            self._plugin_classes = [
                BasicAuthPlugin,
                DigestAuthPlugin,
                HawkAuthPlugin,
            ]

    plugin_manager.__dict__['_plugin_manager'].__class__ = TestAuthPluginManager

    expected_items = sorted([
        plugin.auth_type
        for plugin in plugin_manager.get_auth_plugin_mapping().values()
    ])

# Generated at 2022-06-21 13:22:20.703730
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert OUTPUT_OPTIONS == ''.join(OUTPUT_OPTIONS)
    assert 'GET' in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Defaults to "auto".
    This can also be used to totally override HTTPie's built-in auth mechanism
    with a custom one. In this case, you can use ":" as the "user" value
    in --auth to avoid being prompted for it.
    ''',
)


# Generated at 2022-06-21 13:22:31.417698
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices().__contains__('Basic')

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=get_auth_type_choices_help(),
)

auth.add_argument(
    '--auth-plugin', '-A',
    default=None,
    help='''
    The name of a custom auth plugin. Use --debug to view the list of plugins
    and their arguments.

    Example:

        $ http --debug --auth-type=custom --auth-plugin=custom-auth-plugin ...

    '''
)

#######################################################################
# Timeout
#######################################################################
timeout = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-21 13:22:43.931856
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()

    assert list(auth_type_choices) == list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )


auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP.get('', ''),
    choices=_AuthTypeLazyChoices(),
    help='''
    Plugins can define additional auth types. To see a list of available
    plugins, run:

        http --help

    ''',
)


# Generated at 2022-06-21 13:22:47.269975
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(sorted(auth_type_choices)) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:22:56.921826
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    items = list(choices)
    assert items is not None
    assert len(items) <= 2

auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_type_choices,
    help=f'''
    Specify a custom auth plugin type.

    Plugins may throw errors if dependencies are not installed.
    See built-in plugins for examples at:

        {HERE}/httpie/plugins/auth

    '''
)


# Generated at 2022-06-21 13:23:24.999417
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    if 'foo' in _AuthTypeLazyChoices():
        assert False, 'foo should not be in AuthTypeLazyChoices'

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authorization plugin to use.

    Plugins need to be installed separately.
    See {auth_plugin_docs} for details.

    '''.format(
        auth_plugin_docs=AUTH_PLUGIN_DOCS_URL
    )
)


# Generated at 2022-06-21 13:23:34.522237
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use (default is basic).

    Note that this option is *not* interchangeable with --auth.
    Combining --auth and --auth-type is currently not supported.

    '''
)

# HTTPie-specific arguments.
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Disable support ~/.netrc.

    '''
)

# Generated at 2022-06-21 13:23:41.176771
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication type (plugin).

    ''',
    default=None
)
# Plugin testing

# Generated at 2022-06-21 13:23:50.047892
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    items_list = [
        'basic', 'digest', 'hmac', 'jwt', 'hawk', 'oauth1', 'oauth2'
    ]

    for items in items_list:
        assert items in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help="The auth plugin to use."
)
auth.add_argument(
    '--auth-endpoint',
    help="The auth endpoint to use."
)

#######################################################################
# SSL / TLS verification
#######################################################################
ssl_verification = parser.add_argument_group(title='SSL / TLS verification')

# Generated at 2022-06-21 13:23:51.799805
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    choices.__contains__(None)

# Generated at 2022-06-21 13:24:04.181240
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:24:15.895720
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'basic' in AuthTypeLazyChoices


parser.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Available types:

    {choices}

    '''.format(
        choices='\n'.join(
            ''.join([8 * ' ', line.strip()])
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)


# Generated at 2022-06-21 13:24:17.255613
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:24:27.026452
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import json
    assert list(_AuthTypeLazyChoices()) == [
        'aws-sigv4',
        'basic',
        'digest',
        'hmac',
        'jwt',
        'kerberos',
        'oauth1',
        'oauth2',
        'ntlm',
    ]
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth method to use.

    By default, HTTPie will try to guess the auth method from the known
    password manager.

    ''',
)

# Generated at 2022-06-21 13:24:36.240802
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used. The default value is "basic".

    You can install plugins to support other types:

        $ http --help-auth

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Prevents HTTPie from sending an initial request with no credentials to try
    to obtain a challenge from the server.

    '''
)

# Generated at 2022-06-21 13:24:59.479048
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    arg_str  = '--auth-type AUTH_PLUGIN'
    arg_type = _AuthTypeLazyChoices()
    for name in arg_type:
        assert name in arg_type
    assert 'none' in arg_type


# Generated at 2022-06-21 13:25:06.879707
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'some-invalid-auth-type' not in choices


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth plugin to use. Currently, the supported plugins are:

        {auth_choices}

    You can also use this option to switch between basic and digest auth.
    The default is "basic".
    '''.format(
        auth_choices=', '.join(_AuthTypeLazyChoices()),
    )
)

#######################################################################
# Persistence
#######################################################################

persistence = parser.add_argument_

# Generated at 2022-06-21 13:25:15.118186
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert tuple(_AuthTypeLazyChoices()) == ('digest', 'jwt', 'hawk')


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_plugin',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Available plugins
    are: {auth_types}
    '''.format(auth_types=', '.join(_AuthTypeLazyChoices()))
)


# Generated at 2022-06-21 13:25:20.439418
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(list(_AuthTypeLazyChoices())) == sorted(['digest', 'jwt', 'netrc'])
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used. The default is to detect it based
    on the provided values, but sometimes the server requires a specific type
    (e.g., "Digest" authentication, which is not the default).

    '''
).completer = ChoicesCompleter(
    # TODO: Command should be attached to the parent parser (not group).
    command=auth,
    choices_provider=lambda: plugin_manager.get_auth_plugin_mapping().keys()
)
auth.add_argument

# Generated at 2022-06-21 13:25:23.216192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Digest' not in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:32.320565
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'ntlm', '2.0'
    ]



# Generated at 2022-06-21 13:25:40.496721
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(choices)


# HTTPie-specific CLI arguments.

auth.add_argument(
    '--auth-type',
    default='auto',
    const='auto',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use.

    For example, the builtin "basic" auth plugin supports Basic
    and Digest authentication by Auto-Detecting the type.

    However, you can force Digest authentication with "--auth-type=digest".

    By default, the "auto" plugin is used.

    '''
)


# Generated at 2022-06-21 13:25:46.817547
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='Specify an auth plugin to use.'
)

http = parser.add_argument_group(title='HTTP')
http.add_argument(
    '--follow', '-F',
    dest='follow_redirects',
    action='store_true',
    help='''
    Follow redirects.

    '''
)


# Generated at 2022-06-21 13:25:58.237963
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    >>> AUTH_TYPES = _AuthTypeLazyChoices()
    >>> 'bearer' in AUTH_TYPES
    True
    >>> 'fake' in AUTH_TYPES
    False
    """
    pass
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Auth type to be used in authentication.
    The value can be `basic`, `digest` or the name of a plugin.
    The default is `basic`.
    '''
)

#######################################################################
# Download-related
#######################################################################

download_group = parser.add_argument_group(title='Download Options')

# Generated at 2022-06-21 13:26:04.387591
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


# Generated at 2022-06-21 13:26:45.521491
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert (
        'digest' in choices,
        'aws-sigv4' in choices,
    )



# Generated at 2022-06-21 13:26:53.444433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_choices
    assert list(auth_type_choices) == ['digest', 'hawk']


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism. Supported auth mechanisms depend on the
    installed auth plugins.

    '''
)
auth.add_argument(
    '--auth-host',
    default=getattr(settings, 'DEFAULT_AUTH_HOST', None),
    help=f'''
    The host to use for HTTP authentication. Defaults to {settings.DEFAULT_AUTH_HOST}.

    '''
)

# Generated at 2022-06-21 13:27:00.313394
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    return 42

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom HTTP auth type.

    Use this option when the usual digest or basic auth mechanisms
    do not work.

    Note that only auth types implemented in a Python plugin (such as
    {auth_plugin_examples}) can be used.

    '''.format(
        auth_plugin_examples=', '.join(
            plugin_manager.get_auth_plugin_mapping().keys()),
    )
)

###########################################################################
# Install plugins
###########################################################################

plugins = parser.add_argument_group(title='Plugins')


# Generated at 2022-06-21 13:27:06.593741
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert "basic" in _AuthTypeLazyChoices()
    assert "digest" in _AuthTypeLazyChoices()
    assert "hawk" in _AuthTypeLazyChoices()
    assert "kv-storage" in _AuthTypeLazyChoices()
    assert "foo" not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:27:08.182370
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:17.178661
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices


auth_type_kwargs = {
    'metavar': 'TYPE',
    'default': None,
    'choices': _AuthTypeLazyChoices(),
    'help': 'Auth plugin to use.'
}

auth.add_argument(
    '--auth-type',
    **auth_type_kwargs,
)

auth.add_argument(
    '--auth-plugin',
    **auth_type_kwargs,
)


# Generated at 2022-06-21 13:27:23.752002
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']


# This needs to be lazy because plugins can add more auth types.
auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='basic',
    choices=auth_type_choices,
    help='''
    HTTP authentication type (default: {default}). Supported types:

    {supported_types}

    You can use both the short and long names (e.g., --auth-type=digest and
    --auth-type=Digest).

    '''.format(
        default='basic',
        supported_types=', '.join(sorted(auth_type_choices))
    )
)

# Generated at 2022-06-21 13:27:26.549729
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for auth_plugin_name in plugin_manager.get_auth_plugin_mapping().keys():
        assert auth_plugin_name in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:28.308713
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:27:39.556962
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

auth_type = auth.add_mutually_exclusive_group()
auth_type.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism. If not specified, an appropriate
    one is automatically selected based on the --auth option value, URL, and
    redirects.

    The available mechanisms are:

        {mechanisms}

    '''
)