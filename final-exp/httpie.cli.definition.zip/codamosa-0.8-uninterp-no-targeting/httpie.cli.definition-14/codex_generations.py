

# Generated at 2022-06-21 13:19:03.677582
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'bearer' in _AuthTypeLazyChoices()
    assert 'custom' not in _AuthTypeLazyChoices()
    assert 'basic' in ('basic',)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    How to use the provided credentials for authentication.

    Available choices for --auth-type:

        {helpers.pretty_dict(
            plugin_manager.get_auth_plugin_mapping(),
            key_color=None,
            val_color=None,
            key_width=0
        )}

    '''
)

auth.add_

# Generated at 2022-06-21 13:19:09.016579
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert not _AuthTypeLazyChoices()
    plugin_manager.load_installed_plugins()
    expected = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    actual = list(_AuthTypeLazyChoices())
    assert expected == actual

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin (modulename.ClassName).
    Plugins are searched for in HTTPie's working directory.
    '''
)

# httpie.auth.AuthPlugin keyword arguments.
# TODO: support --auth-type?

# Generated at 2022-06-21 13:19:15.389302
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'Basic' in lazy_choices
    assert 'basic' in lazy_choices
    assert 'Digest' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'Request-body' in lazy_choices
    assert 'request-body' in lazy_choices



# Generated at 2022-06-21 13:19:23.853006
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'plugin_1' in choices
    assert 'plugin_2' in choices
    assert 'plugin_3' not in choices
    assert sorted(choices) == sorted(['plugin_1', 'plugin_2'])

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin. The default is to guess based on --auth
    username.

    ''',
)

# Generated at 2022-06-21 13:19:35.932978
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert len(set(auth_type_lazy_choices)) == len(auth_type_lazy_choices)

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use.

    By default, HTTPie performs the authentication challenge-response
    automatically, based on the WWW-Authenticate response header.

    Plugins implementing a custom auth type can be registered via the
    `httpie.plugins.auth.<TYPE>.<NAME>` entry point in the distribution
    `entry_points.txt`.

    ''',
)

# Generated at 2022-06-21 13:19:37.874801
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'fake' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:40.285084
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping()
    )

# Generated at 2022-06-21 13:19:43.163665
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'digest' in auth_type
    assert 'basic' in auth_type
    assert 'unknown' not in auth_type


# Generated at 2022-06-21 13:19:46.313089
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    type = _AuthTypeLazyChoices()
    assert 'digest' in type
    assert 'basic' in type
    assert 'plugin_name' in type
    assert 'something_else' not in type



# Generated at 2022-06-21 13:19:52.250820
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(['basic', 'digest', 'aws', 'hawk'])
del test__AuthTypeLazyChoices___iter__


auth.add_argument(
    '--auth-type', '-t',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to be used. Currently available plugins:
    {0}.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)


# Generated at 2022-06-21 13:20:08.578257
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'auto' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES_DEFAULT,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the type of the credentials provided with --auth. {AUTH_TYPES_DOC}

    If omitted, HTTPie tries to guess the type.

    '''
)

auth.add_argument(
    '--auth-forest',
    default=False,
    action='store_true',
    help=f'''
    Do not abort request when auth fails on the initial request. Retry the
    request with the same auth against all URLs of responses' HTTP Location
    headers (only for methods HEAD, GET, OPTIONS, and TRACE).

    '''
)

# Generated at 2022-06-21 13:20:21.568027
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'aws' in auth_type_choices
    assert 'oauth1.0a' in auth_type_choices
    assert 'bearer' in auth_type_choices
    assert 'aws4' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'ntlm' in auth_type_choices
    assert 'spnego' in auth_type_choices


# Generated at 2022-06-21 13:20:31.251177
# Unit test for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-21 13:20:40.903802
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    help='''
    Specifies the authentication mechanism to be used (if the server supports
    more than one). If not provided and --auth is specified, an appropriate one
    is guessed.

    Available types:            {0}

    '''.format(
        ', '.join(_AuthTypeLazyChoices())
    ),
    choices=_AuthTypeLazyChoices()
)

auth.add_argument(
    '--auth-plugin',
    help='''
    Specifies an authentication plugin to use. Typically, this option is not
    necessary because HTTPie can automatically choose the best one.

    '''
)


#######################################################################
# TLS/SSL
#######################################################################


# Generated at 2022-06-21 13:20:43.485913
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:20:54.758294
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(
        sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# ``requests.auth.HTTPBasicAuth`` keyword arguments.
auth_plugin = auth.add_mutually_exclusive_group(required=False)
auth_plugin.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The name of a plugin to use for authentication.
    Installs and loads the plugin if it isn't already.

    For example, --auth-type=jwt will install the JWTAuth plugin and use it
    to obtain an authentication token to use in the Authorization header,
    which it will refresh as needed.

    '''
)

# Generated at 2022-06-21 13:20:57.136908
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lc = _AuthTypeLazyChoices()
    assert 'basic' in lc
    assert 'invalid' not in lc


# Generated at 2022-06-21 13:21:10.990974
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the plugin used for authentication. "auto" is special value
    that makes HTTPie try different plugins in a predefined order.

    See https://httpie.org/docs#authentication for the list of available
    plugins.

    '''
)


# Generated at 2022-06-21 13:21:21.383639
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert callable(_AuthTypeLazyChoices.__iter__)
    assert not callable(_AuthTypeLazyChoices.__iter__)
    assert _AuthTypeLazyChoices() == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism.

    The following built-in types are supported:

        {built_in_auth_types}

    You can also use auth plugins.

    '''.format(
        built_in_auth_types=', '.join(builtin_auth_types)
    )
)

# Generated at 2022-06-21 13:21:22.605144
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:30.898794
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:40.622109
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the auth mechanism used by specifying its type:

    ''' + '\n'.join('{0}{1}'.format(8 * ' ', line.strip())
                    for line in wrap(
                        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
                    ).strip()
)

# Generated at 2022-06-21 13:21:54.595783
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())
    assert list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


_AUTH_PLUGIN_HELP_TEMPLATE = textwrap.dedent(r'''
    The specified value is passed to the plugin selected by the --auth-type option.
    The plugin should be properly installed (see `http --help-auth`).

    Example values: "{example_values}".
''').lstrip()


auth_plugin = auth.add_argument_group(title='Authentication plugins')

# Generated at 2022-06-21 13:22:03.406986
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_types = _AuthTypeLazyChoices()
    assert 'digest' in auth_types
    assert 'Basic' in auth_types
    assert 'basic' not in auth_types


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to use. Supported values:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping()
            )), 60)
        ).strip()
    )
)
auth.add_argument

# Generated at 2022-06-21 13:22:06.541613
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert 'Basic' in obj
    assert 'Digest' in obj
    assert 'Foo' not in obj


# Generated at 2022-06-21 13:22:17.880089
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'fake' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The supported mechanisms
    are: {0}.'''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    ),
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    The host to authenticate against.
    '''
)

# Generated at 2022-06-21 13:22:28.951474
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert len(_AuthTypeLazyChoices()) > 1

# plugin_type_validator is a function because PluginManager is a singleton.
plugin_type_validator = PluginTypeValidator(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    type=plugin_type_validator,
    help='''
    Specify the auth mechanism to be used. Possible values: {0}.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping()))
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='Authenticate only against this host. Useful for API endpoints '
         'with a common domain different from the authorization domain.'
)

# Generated at 2022-06-21 13:22:35.913489
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']



auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    #choices=sorted(plugin_manager.get_auth_plugin_mapping()),
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin (typically, a non-standard
    authentication type).

    '''
)


#######################################################################
# Cookies
#######################################################################

cookie_group = parser.add_argument_group(title='Cookies')



# Generated at 2022-06-21 13:22:46.157587
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    )


# Generated at 2022-06-21 13:22:56.321374
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Kerberos' in _AuthTypeLazyChoices()


auth_group = auth.add_mutually_exclusive_group(required=False)
auth_group.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin by import path.

    '''
)
auth_group.add_argument(
    '--auth-type=',
    dest='auth_type',
    action='store_const',
    const='',
    help='''
    Disable authentication.

    '''
)

# ``requests.

# Generated at 2022-06-21 13:23:20.281861
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_contains = _AuthTypeLazyChoices()
    assert 'digest' in lazy_contains

plugin_manager.load_auth_plugins()
auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type to be used for an authentication plugin.
    Run `{prog} plugins --auth` to see a list of all installed
    authentication plugins.

    '''.format(prog=PROG)
)


args = parser.parse_args()

args.output_options = args.output_options or OUTPUT_OPTIONS_DEFAULT

# Generated at 2022-06-21 13:23:21.655808
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:23.597227
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices() ) == ['basic', 'digest']

# Generated at 2022-06-21 13:23:25.431948
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'fakeauth' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:27.627410
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    """
    It should work with a subset of the available types

    """
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:23:36.380702
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    dest='auth_type',
    help='''
    Specify the authentication type, e.g. "basic" or "digest". The default is
    "basic".

    ''',
    metavar='TYPE'
)

#######################################################################
# SSL
#######################################################################

verify = parser.add_argument_group(title='SSL')
verify.add_argument(
    '--ssl', '--verify',
    action='store_true',
    default=False,
    help='Verify SSL certificates.'
)

# Generated at 2022-06-21 13:23:46.982622
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from io import StringIO
    from httpie.plugins import builtin, CONF_DIR
    sys.path.append(os.path.join(CONF_DIR, 'auth-plugins'))
    sys.stdout = StringIO()
    plugin_manager.discover()
    assert 'customauth' in _AuthTypeLazyChoices()
    plugins = _AuthTypeLazyChoices()
    assert 'customauth' in plugins
    assert 'basic' in plugins
    assert 'digest' in plugins
    assert 'AWS' in plugins
    assert 'Azure' in plugins
    assert 'NTLM' in plugins
    assert 'Negotiate' in plugins
    assert 'custom' in plugins
    assert 'test-auth' not in plugins
    sys.stdout = sys.__stdout__


# Generated at 2022-06-21 13:23:58.521842
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(sorted(_AuthTypeLazyChoices())) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication method to be used, e.g., oauth1.
    For a list of available auth types, run: http --auth-types.

    '''
)
auth.add_argument(
    '--auth-type=oauth1',
    help=argparse.SUPPRESS)
auth.add_argument(
    '--auth-type=basic',
    help=argparse.SUPPRESS)

# Generated at 2022-06-21 13:24:00.337462
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:24:12.721989
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class MockAuthPlugin:
        auth_type = 'foo'

    with mock.patch('httpie.plugins.manager.plugin_manager.get_auth_plugin_mapping',
                    return_value={'foo': MockAuthPlugin}):
        assert 'foo' in _AuthTypeLazyChoices()
        assert 'bar' not in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:24:45.107817
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert isinstance(choices, collections.abc.Iterable)
    assert iter(choices)



# Generated at 2022-06-21 13:24:48.702198
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'hawk' in auth_type_choices



# Generated at 2022-06-21 13:24:51.328552
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'http' in choices
    assert 'digest' in choices
    assert 'unknown' not in choices
    return True



# Generated at 2022-06-21 13:24:58.811526
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from requests_toolbelt.auth import DigestAuth  # NOQA
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'foobar' not in auth_type_choices
    assert next(iter(auth_type_choices)) == 'basic'
    assert 'basic' in plugin_manager.get_auth_plugin_mapping()
    assert 'digest' in plugin_manager.get_auth_plugin_mapping()
    assert 'foobar' not in plugin_manager.get_auth_plugin_mapping()



# Generated at 2022-06-21 13:25:04.582146
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic')
    assert choices.__contains__('digest')
    assert sorted(choices) == sorted(('basic', 'digest'))

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='The authentication method to be used.'
)
auth.add_argument(
    '--auth-send',
    default='auto',
    choices=('always', 'never', 'auto'),
    help='''
    When to send the credentials. By default they are sent immediately
    (auto), but can be sent only when a challenge is received (always) or
    never (never).

    '''
)

# Generated at 2022-06-21 13:25:05.722419
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:09.121688
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    assert 'auto' in lazy_choices
    assert 'Basic' in lazy_choices
    assert 'Digest' in lazy_choices
    assert 'TotallyFakeAuthType' not in lazy_choices


# Generated at 2022-06-21 13:25:10.763840
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:25:18.360435
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'basic' in _AuthTypeLazyChoices


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The scheme that will be used to perform the authentication.

    ''',
)

auth.add_argument(
    '--auth-verify',
    action='store_true',
    help='''
    The auth certificate is verified against the system's CAs.

    '''
)

auth.add_argument(
    '--auth-cert',
    dest='auth_cert',
    default=None,
    metavar='CERT',
    help='''
    Client TLS certificate path.

    '''
)


# Generated at 2022-06-21 13:25:28.118104
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    type=lambda s: s.lower(),
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    help='''
    Specify the auth type to be used.

    If the auth type is not specified, the method is inferred from the
    provided credentials, or the default of {default} is used.

    Available auth types:

        {choices}

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        choices=', '.join(sorted(_AuthTypeLazyChoices())),
    )
)

# Generated at 2022-06-21 13:26:16.250707
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(_AuthTypeLazyChoices()) == set(plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:26:18.517636
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_choices = _AuthTypeLazyChoices()
    assert list(auth_type_choices) == list(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:26:27.463930
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    Auto-detect the auth mechanism based on the provided credentials.
    You can force a particular auth mechanism with this option.

    Currently supported:

        {0}

    '''.format(humanize_list(
        sorted(plugin_manager.get_auth_plugin_mapping().keys()),
        indent=8
    ))
)


# Generated at 2022-06-21 13:26:33.943102
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication scheme to be used.
    By default, it is guessed from the provided credentials.

    ''',
)

#######################################################################
# Plugins
#######################################################################

# plugins = parser.add_argument_group(title='Plugins').add_mutually_exclusive_group(required=False)

#######################################################################
# Input options
#######################################################################

input_options = parser.add_argument_group(title='Input Options')


# Generated at 2022-06-21 13:26:40.283509
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [i for i in _AuthTypeLazyChoices()] == sorted(plugin_manager.get_auth_plugin_mapping().keys())

_AuthTypeLazyChoices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=list(_AuthTypeLazyChoices),
    help='''
    Specify a custom authentication plugin (e.g., "digest").
    Use --auth-type=help to list the available authentication plugins.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:26:50.785173
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Method __iter__ of class _AuthTypeLazyChoices"""
    _AuthTypeLazyChoices.__iter__()
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Defaults to 'auto', which causes
    HTTPie to attempt Basic, Digest, and Hawk authentication, in that order.

    '''
)

# Generated at 2022-06-21 13:26:52.489444
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(AVAILABLE_AUTH_PLUGINS) == sorted(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:26:59.374653
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_choices = _AuthTypeLazyChoices()
    try:
        assert FORM in auth_type_choices
    except AssertionError:
        assert 'form' in auth_type_choices


# Generated at 2022-06-21 13:27:11.246002
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(plugin_manager.get_auth_plugin_mapping().keys()) == set(_AuthTypeLazyChoices())


auth_type_validator = AuthTypeValidator(
    'Auth plugin not installed. Install it with: pip install {name}',
    'Auth plugin does not exists. Choose one of: {choices}'
)
auth.add_argument(
    '--auth-type', '-t',
    type=auth_type_validator,
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Choose an auth plugin. Run `http --plugins' for a list of installed
    plugins.

    '''
)

#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_group(title='HTTPS')

https.add

# Generated at 2022-06-21 13:27:13.318196
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert "basic" in _AuthTypeLazyChoices()
    assert "digest" in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:28:32.939353
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'kerberos' in _AuthTypeLazyChoices()
    assert 'oauth' not in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication type. The default is "auto" which will attempt to determine the necessary auth type from the server's 401 response, if one is received.

    The following authentication types are supported:
    {0}
    '''.format('\n'.join(
        '        {0: <15} {1}'.format(name, plugin.description)
        for name, plugin in sorted(plugin_manager.get_auth_plugin_mapping().items())
    ))
)


# Generated at 2022-06-21 13:28:34.191419
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'Basic' in choices
    assert 'NotFound' not in choices


# Generated at 2022-06-21 13:28:35.968227
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:28:40.717164
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie.plugins.builtin import AuthPlugin
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foo' not in _AuthTypeLazyChoices()

    AuthPlugin.implements = ['foo']
    assert 'foo' in _AuthTypeLazyChoices()
    del AuthPlugin.implements


# Generated at 2022-06-21 13:28:49.822286
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'fake' in _AuthTypeLazyChoices()
    assert 'fake' in plugin_manager.get_auth_plugin_mapping().keys()

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help=f'''
    Explicitly specify an auth plugin. Available choices are:

        {', '.join(auth_type_choices)}

    '''
)


#######################################################################
# Output options
#######################################################################

download_options = parser.add_argument_group(title='Download Options')


# Generated at 2022-06-21 13:28:52.540887
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [
        x for x in _AuthTypeLazyChoices()
    ] == [
        x for x in sorted(plugin_manager.get_auth_plugin_mapping().keys())
    ]