

# Generated at 2022-06-21 13:18:58.416548
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-21 13:19:08.571812
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'whatever' not in auth_type


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    '''
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    help='''
    Print detailed help for specified --auth-type, e.g.:

        $ http --auth-type-help digest

    This option is only useful with --auth-type.

    '''
)

#######################################################################
# HTTPS
#######################################################################

https = parser.add_argument_group

# Generated at 2022-06-21 13:19:20.351672
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

# ``requests.request`` keyword arguments.
auth_plugin = parser.add_argument_group(title='Auth plugin')
auth_plugin.add_argument(
    '--auth-type',
    metavar='AUTH_PLUGIN',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin. Run `http --auth-type-help'
    to get help for the plugin.

    ''',
)
auth_plugin.add_argument(
    '--auth-type-help',
    metavar='AUTH_PLUGIN',
    nargs='?',
    help='''
    Show help for the specified auth plugin.

    ''',
)

# ``requests.request`` keyword

# Generated at 2022-06-21 13:19:21.084904
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list(_AuthTypeLazyChoices())

# Generated at 2022-06-21 13:19:30.471280
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(iter(_AuthTypeLazyChoices())) == sorted(['digest', 'hawk', 'jwt'])


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an auth plugin.

    Available plugins:
        ''' + '\n        '.join(
            map(lambda s: '{s:<10}'.format(s=s), _AuthTypeLazyChoices())) + '''

    '''
)

# Generated at 2022-06-21 13:19:34.052567
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'foobar' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:19:44.446012
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from tests.helpers import assert_equal
    from httpie.plugins.builtin import FormAuthPlugin
    from httpie.plugins.manager import PluginManager
    from tests.helpers import mock
    for plugin in (FormAuthPlugin(),):
        with mock.patch.object(PluginManager, 'get_auth_plugin_mapping', return_value={plugin.get_auth_type():plugin}):
            assert_equal(list(_AuthTypeLazyChoices()), [plugin.get_auth_type()])


# Generated at 2022-06-21 13:19:56.923397
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    # make sure that _AuthTypeLazyChoices is iterable
    for choice in choices:
        assert choice in plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The scheme for authenticating HTTP requests.

    Available options:
    {plugins}
    '''.format(plugins=sorted_plugin_list(plugin_manager.get_auth_plugins()))
)

# Generated at 2022-06-21 13:20:02.698417
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='Authentication plugin to use',
)



# Generated at 2022-06-21 13:20:06.974813
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-21 13:20:17.696563
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.clear()
    assert ('foo' in _AuthTypeLazyChoices()) == False
    plugin_manager.import_plugin_module(SimpleAuthPlugin())
    assert ('foo' in _AuthTypeLazyChoices()) == False
    plugin_manager.import_plugin_module(SimpleAuthPlugin('foo'))
    assert ('foo' in _AuthTypeLazyChoices()) == True

# Generated at 2022-06-21 13:20:21.000952
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    result = 'foo' in choices
    assert result is False
test__AuthTypeLazyChoices___contains__()

# Generated at 2022-06-21 13:20:30.864069
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()  # noqa
    assert list(x) == list(x)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type.

    The available choices depend on installed plugins. Run
    `http --auth-type=help' to see the list.

    '''
)
auth.add_argument(
    '--auth-prompt',
    action='store_true',
    help='''
    Prompt for the username and password when needed.
    Overrides the default option --no-auth-prompt.

    '''
)

# Generated at 2022-06-21 13:20:36.984540
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    assert isinstance(x, _AuthTypeLazyChoices)
    assert isinstance(x, collections.abc.Iterable)
    assert isinstance(x, collections.abc.Container)
    assert isinstance(x, collections.abc.Set)

    assert len(x) > 0
    assert isinstance(iter(x), collections.abc.Iterator)
    assert set(x) == set(x)
    assert set(x) == set(iter(x))

    assert 'auto' in x
    assert 'basic' in x
    assert 'digest' in x


# Generated at 2022-06-21 13:20:48.263002
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices


auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used.

    The default is "auto" which results in issuing a "Basic" request first and
    then automatically falls back to "Digest" if needed.

    ''',
)


# Generated at 2022-06-21 13:20:50.779702
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(iter(_AuthTypeLazyChoices())) == set(PLUGIN_MANAGER.get_auth_plugin_mapping().keys())



# Generated at 2022-06-21 13:21:00.705737
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_choices
    assert 'digest' in auth_type_choices
    assert 'hawk' in auth_type_choices
    assert 'bearer' in auth_type_choices
    assert 'aws4-hmac-sha256' in auth_type_choices
    assert 'aws4-hmac-sha1' in auth_type_choices
    assert 'aws4-hmac-sha256-client-auth' in auth_type_choices
    assert 'aws4-hmac-sha1-client-auth' in auth_type_choices

    assert 'http-basic' in auth_type_choices
    assert 'http-digest' in auth_type_choices

# Generated at 2022-06-21 13:21:12.503857
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    # We could hardcode ``choices=('basic', 'digest')``, but we want the list of
    # auth types to be dynamic.
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the HTTP ``Authorization`` header to be sent. If omitted,
    HTTPie figures the correct auth type by inspecting the server's
    ``WWW-Authenticate`` header, if provided.

    Currently supported auth types:

    ''' + ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
)


#######################################################################
# Certificates
#######################################################################


# Generated at 2022-06-21 13:21:22.542960
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__(): # noqa
    assert 'TestPlugin' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:21:25.584619
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert sorted(list(_AuthTypeLazyChoices()))



# Generated at 2022-06-21 13:21:42.036131
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert [1, 2] == sorted(choices)


auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP.get(AUTH_PLUGIN_DEFAULT, AUTH_PLUGIN_DEFAULT),
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use. The default is {AUTH_PLUGIN_DEFAULT}.
    Supported values: {", ".join(sorted(AUTH_PLUGIN_MAP.keys()))}

    '''
)

# Generated at 2022-06-21 13:21:56.087528
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(
        [i for i in _AuthTypeLazyChoices()]
    ) == len(plugin_manager.get_auth_plugin_mapping())


auth_type_validator = AuthPluginValidator(
    'The specified auth plugin is not available.'
)
auth.add_argument(
    '--auth-type',
    metavar='{' + ','.join(_AuthTypeLazyChoices()) + '}',
    type=auth_type_validator,
    help='''
    Specify an authentication method for the request.

    - basic: Basic HTTP auth.
    - digest: Digest HTTP auth.
    - oauth1: OAuth 1 auth.

    Note that this option is ignored if basic or digest auth is triggered
    by the presence of --auth.

    '''
)
auth.add_

# Generated at 2022-06-21 13:21:58.327142
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:22:10.730408
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(AuthTypeLazyChoices()) == \
           list(_AuthTypeLazyChoices())
AuthTypeLazyChoices = _AuthTypeLazyChoices

auth_plugin = parser.add_argument_group(
    title='Authentication Plugin Options',
    description='''\
Additional authentication options for the following authentication plugins:
{0}

'''.format(indent(line) for line in plugin_manager.build_auth_help_lines())
)
auth_plugin.add_argument(
    '--auth-type',
    default=None,
    choices=AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use. It can be enabled without plugin-specific
    options.

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:22:13.393575
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(sorted(auth_types()))

_auth_type_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:22:25.131805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())

auth_type_validator = ChoicesValidator(
    _AuthTypeLazyChoices(),
    '%(choices)s',
    'Proper authentication type required.'
)
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    type=auth_type_validator,
    help='''
    The authentication mechanism to be used. If not provided, the plugin
    attempts to figure it out based on the provided credentials.

    Available choices: %(_AuthTypeLazyChoices)s

    '''
)


# Generated at 2022-06-21 13:22:28.192979
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
   lazy_choices = _AuthTypeLazyChoices()
   assert list(lazy_choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

# Generated at 2022-06-21 13:22:36.675264
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    return list(_AuthTypeLazyChoices())

_auth_type_default = 'digest' if 'digest' in _AuthTypeLazyChoices() else 'basic'

auth.add_argument(
    '--auth-type',
    default=_auth_type_default,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Currently supported auth types:

    {plugin_manager.get_auth_plugin_names_as_choices_help()}

    The default auth type is {_auth_type_default}.

    '''
)

# Generated at 2022-06-21 13:22:41.815339
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    opts = _AuthTypeLazyChoices()
    assert 'basic' in opts
    assert 'Basic' in opts
    assert 'Bearer' in opts
    assert 'bearer' in opts

    assert 'does_not_exist' not in opts
    assert 'Digest' not in opts
    assert 'digest' not in opts



# Generated at 2022-06-21 13:22:52.816732
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'test_name' in _AuthTypeLazyChoices()
    assert 'test_name' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used.
    You can use the keyword 'plugin' to choose from a list of installed plugins.

    ''',
)


#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-21 13:23:12.245063
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:23:20.474595
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help=f'''
    Select an authentication plugin.

    HTTPie comes with the following auth plugins:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

auth.add_argument(
    '--auth-type-verify',
    action='store_true',
    help='''
    Verify and prompt for missing arguments for the selected auth plugin when
    creating an auth context.

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-21 13:23:26.267201
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(iter(_AuthTypeLazyChoices())) == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Available options depend on the plugins installed.

    '''
)


# Generated at 2022-06-21 13:23:28.456780
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:23:30.935416
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    '''Test AuthTypeLazyChoices.__contains__'''
    _AuthTypeLazyChoices().__contains__(item = 'DigestAuth')


# Generated at 2022-06-21 13:23:38.411980
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'foo' not in auth_type
    assert sorted(auth_type) == ['basic', 'digest']


auth.add_argument(
    '--auth-type',
    default='basic',
    help=f'''
    The type of HTTP authentication to use (default is "basic").
    The value can be One of:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-21 13:23:48.429194
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set([item for item in _AuthTypeLazyChoices()]) == set(['basic'])

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    metavar='AUTH_TYPE',
    help=f'''
    Type of HTTP authentication to use. The supported types are:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

auth.add_

# Generated at 2022-06-21 13:24:00.551181
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'foo' not in auth_type_lazy_choices
    assert list(auth_type_lazy_choices) == ['basic', 'digest']



# Generated at 2022-06-21 13:24:02.439372
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices

# Generated at 2022-06-21 13:24:14.616443
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'digest' in choices
    assert 'basic' in choices
    assert 'my-auth-plugin' in choices  # <-- plugin name
    assert len(list(choices)) > 0


# Generated at 2022-06-21 13:24:53.964628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'Bearer' in choices
    assert 'aws4-hmac-sha256' in choices
    assert 'aws4-hmac-sha256' == next(iter(choices))

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    type=plugin_manager.load_plugin_from_name_arg,
    help=f'''
    The authentication mechanism to be used.
    Use {PLUGIN_INSTALL} to see the available options.

    '''
)


# Generated at 2022-06-21 13:25:00.716572
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    for key in plugin_manager.get_auth_plugin_mapping().keys():
        assert key in auth_type

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=f'''
    Authentication types:

        auto - Automatically detect the type.
        {' '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# Cookies
#######################################################################

cookie_options = parser.add_argument_group(title='Cookies')


# Generated at 2022-06-21 13:25:02.209884
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

# Generated at 2022-06-21 13:25:08.902807
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. For Basic and Digest auth, HTTPie will prompt
    for the password unless it is specified in the URL or via -a.

    The default is 'auto', which will cause HTTPie to automatically detect the
    auth type by attempting Basic auth against the URL and falling back to
    Digest, if necessary.

    Supported values:

    {0}

    '''.format(
        ', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser

# Generated at 2022-06-21 13:25:17.322954
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert set(['basic', 'digest']) <= set(_AuthTypeLazyChoices())
    _AuthTypeLazyChoices().__contains__('basic')


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='Authentication type. One of: ' + ', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())
    )
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Do not send a 401 response to authentication challenges (for digest auth).
    Only applicable when the auth plugin handles auth challenges.

    '''
)
auth.add_

# Generated at 2022-06-21 13:25:22.299898
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = iter(_AuthTypeLazyChoices())
    assert next(choices) == 'basic'
    assert next(choices) == 'digest'
    assert next(choices) == '2fa'
    assert next(choices) == 'hawk'
    with pytest.raises(StopIteration):
        next(choices)

# Generated at 2022-06-21 13:25:31.592027
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type_choices = _AuthTypeLazyChoices()
_auth_group = auth.add_mutually_exclusive_group()
_auth_group.add_argument(
    '--auth-type',
    choices=auth_type_choices,
    help=f'''
    The type of HTTP authentication to use. Currently supported types:

    {', '.join(auth_type_choices)}

    This argument is for advanced use mainly. For example, "OAuth 2.0" is
    handled as "oauth2", in order to keep the argument shorter.

    '''.strip()
)

# Generated at 2022-06-21 13:25:33.616216
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    assert 'http' in _AuthTypeLazyChoices()

    assert 'non-existing-auth-type' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:25:41.537202
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    as_set = frozenset(_AuthTypeLazyChoices())
    assert as_set.issuperset(set(DEFAULT_AUTH_TYPES))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='SCHEME',
    help='''
    Use a custom authentication scheme. This option is experimental,
    use at your own risk. The authentication scheme must implement
    the auth plugin API, see:

        https://github.com/jkbrzt/httpie#custom-authentication-plugin

    ''',
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-21 13:25:49.889083
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_types = _AuthTypeLazyChoices()
    for auth_type in auth_types:
        pass

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_TYPE,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of HTTP auth to use. The available options are determined by
    the installed plugins. The default is:

        {DEFAULT_AUTH_TYPE}

    '''
)

# Generated at 2022-06-21 13:27:14.030030
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['digest', 'jwt', 'hawk']) == sorted(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='{0}'.format(', '.join(_AuthTypeLazyChoices())),
    choices=_AuthTypeLazyChoices(),
    help='''
    The mechanism used to perform authentication.

    auto
        If --auth is used, then this is the default. HTTPie will try to
        determine the authentication mechanism based on the provided credentials
        or, if none are provided, guess it from the server response.

    available mechanisms:
        {0}

    '''.format(', '.join(sorted(_AuthTypeLazyChoices())))
)

#######################################################################
# Timeouts
#######################################################################
timeouts

# Generated at 2022-06-21 13:27:16.809533
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    all_auth_types = _AuthTypeLazyChoices()
    assert set(DEFAULT_AUTH_PLUGIN_NAMES) <= set(all_auth_types)

# Generated at 2022-06-21 13:27:18.286876
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == \
        ['basic', 'digest', 'hawk']

# Generated at 2022-06-21 13:27:28.310035
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    ''',
)

#######################################################################
# SSL
#######################################################################
ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-21 13:27:39.557625
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    This test covers the method __iter__ of class _AuthTypeLazyChoices, if run from the root directory.
    """
    # Set up plugin manager.
    plugin_manager.initialize_plugins()
    global_options = GlobalOptions()
    global_options.colors = False
    global_options.output_options = OUTPUT_OPTIONS
    global_options.output_options_history = OUTPUT_OPTIONS
    global_options.prettify = PRETTY_STDOUT_TTY_ONLY
    global_options.style = DEFAULT_STYLE
    global_options.default_options = request_default_options(global_options)
    global_options.format_options = DEFAULT_FORMAT_OPTIONS
    global_options.config_dir = DEFAULT_CONFIG_DIR


# Generated at 2022-06-21 13:27:41.182603
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [i for i in _AuthTypeLazyChoices()] == ['basic', 'digest']

# Generated at 2022-06-21 13:27:42.499141
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:27:54.066522
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():    
    print('\nTEST: class _AuthTypeLazyChoices')
    auth_choices = _AuthTypeLazyChoices()
    assert list(auth_choices) == ['digest', 'hawk', 'jwt'] 

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of credentials being used.

    '''
)

# Generated at 2022-06-21 13:28:01.539193
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from requests_toolbelt.auth.basic import HTTPBasicAuth
    from httpie.plugins import AuthPlugin, plugin_manager as pm

    class DummyBasicAuthPlugin(AuthPlugin):
        auth_type = 'dummy-basic-auth'
        auth_class = HTTPBasicAuth

    auth_type_lazy_choices = _AuthTypeLazyChoices()
    plugin_manager.prepend_auth_plugin(DummyBasicAuthPlugin)

    assert 'dummy-basic-auth' in auth_type_lazy_choices
    assert 'dummy-basic-auth' in pm.get_auth_plugin_mapping()
    pm.remove_plugin(DummyBasicAuthPlugin)
    assert 'dummy-basic-auth' not in auth_type_lazy_choices



# Generated at 2022-06-21 13:28:02.684187
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()