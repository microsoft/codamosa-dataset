

# Generated at 2022-06-21 13:18:55.199862
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(iter(_AuthTypeLazyChoices())) == set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:19:05.929309
# Unit test for constructor of class _AuthTypeLazyChoices

# Generated at 2022-06-21 13:19:07.423967
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(_AuthTypeLazyChoices()) == iter(sorted(
        plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:19:19.848261
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert sorted(i for i in a) == sorted(a)
    assert sorted(i for i in a) == ['digest']


auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth type. By default, it is guessed from the --auth option value.

    The available auth types are listed in the output of: http --debug

    '''
)

#######################################################################
# HTTP
#######################################################################

http = parser.add_argument_group(title='HTTP')


# Generated at 2022-06-21 13:19:23.382821
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert sorted(['basic', 'digest']) == list(auth_type_lazy_choices)
    assert 'NonExistentAuthPlugin' not in auth_type_lazy_choices


# Generated at 2022-06-21 13:19:31.839879
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()

auth_type = auth.add_argument(
    '--auth-type', '--auth-plugin',
    # `default=None` is explicitly needed so that `None` can be passed
    # to `requests.request` with `argparse.Namespace`.
    default=None,
    metavar='TYPE',
    help='''
    The plugin that implements the authentication logic. The default,
    {default_auth_type}, might not be what you want. Try --auth-type=basic
    or another value for this option to see if you get a different result.

    '''.format(
        default_auth_type=DEFAULT_AUTH_PLUGIN_NAME
    ),
    choices=_AuthTypeLazyChoices()
)

# Generated at 2022-06-21 13:19:34.905508
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for _ in plugin_manager.get_auth_plugin_mapping().keys():
        assert _ in _AuthTypeLazyChoices()
    return


# Generated at 2022-06-21 13:19:45.024490
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'HTTPBasicAuth' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:19:57.334393
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'builtin' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    metavar='auth_type',
    default='builtin',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin to use.
    '''
)


# ``requests.request`` keyword arguments.
from httpie.auth import AUTH_PLUGIN_MAP  # NOQA
from httpie.plugins import plugin_manager


# Generated at 2022-06-21 13:20:01.257826
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    for auth_type in auth_type_lazy_choices:
        pass



# Generated at 2022-06-21 13:20:13.171934
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an HTTP authentication plugin.  \
The default is "basic".

    Available plugins:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    For more details, run:

        $ http --help-auth=<AUTH_TYPE>

    ''',
)


# Generated at 2022-06-21 13:20:25.533651
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert 'hawk' in choices
    assert 'aws' in choices
    assert 'aws-s3' in choices
    assert 'awsv4' in choices
    assert 'ntlm' in choices
    assert 'oauth1' in choices


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin to use instead of the auto-detection performed
    by HTTPie.

    See all available plugins with `http --debug` and examples with
    `http --help-auth`.

    '''
)

# Generated at 2022-06-21 13:20:27.313054
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert set(choices) == set(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

# Generated at 2022-06-21 13:20:32.597782
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_choices = _AuthTypeLazyChoices()
    # Some existing auth types
    assert 'basic' in lazy_choices
    assert 'digest' in lazy_choices
    assert 'hawk' in lazy_choices
    assert 'ntlm' in lazy_choices
    assert 'oautlib' in lazy_choices
    assert 'aws' in lazy_choices
    # Some non-existing auth types
    assert 'foo' not in lazy_choices
    assert 'mark' not in lazy_choices

# Generated at 2022-06-21 13:20:40.770654
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication plugin to use. Currently supported auth types are:

        {", ".join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Default: {DEFAULT_AUTH_PLUGIN_NAME}

    '''
)

_auth_plugin_kwargs_validators = plugin_manager.get_auth_plugin_kwargs_validators()



# Generated at 2022-06-21 13:20:51.883100
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Method __iter__ returns an iterator.
    # This function tests if it is iterable and if it contains the correct values.
    auth_types = _AuthTypeLazyChoices()
    for item in auth_types:
        assert item in plugin_manager.get_auth_plugin_mapping()
        assert item in str(auth_types)

auth.add_argument(
    '--auth-type',
    default=None,
    help=f'''
    Specify the authentication mechanism.

    If not provided, the authentication mechanism will be automatically detected
    based on the --auth option value or, if --auth is not specified, based on
    the URL host.

    The available mechanisms are:
    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

################################################################

# Generated at 2022-06-21 13:21:01.190208
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(['basic', 'digest']) == list(sorted(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    `--help-auth` to see available plugins.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Disable automatic HTTP authorization challenge responses.

    This is useful when the same request is supposed to be sent multiple
    times, and unauthenticated responses are acceptable.

    '''
)


# Generated at 2022-06-21 13:21:12.840887
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == \
        sorted(_AuthTypeLazyChoices())
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Foo' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:21:22.821246
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert sorted(['basic', 'digest']) == list(_AuthTypeLazyChoices())


# Generated at 2022-06-21 13:21:32.108528
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest']

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    Available plugins:

    ''',
)

#######################################################################
# HTTP(S) Proxy
#######################################################################


# Generated at 2022-06-21 13:21:45.666162
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class FakePluginManager:
        @staticmethod
        def get_auth_plugin_mapping():
            return {'foo': 'bar'}
    plugin_manager.set_testing_plugin_manager(FakePluginManager)
    assert set(['foo']) == set(_AuthTypeLazyChoices())
    plugin_manager.set_testing_plugin_manager(None)



# Generated at 2022-06-21 13:21:52.663844
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy_list = _AuthTypeLazyChoices()
    assert 'basic' in lazy_list
    assert 'digest' in lazy_list
    assert 'oauth1' in lazy_list
    assert 'oauth2' in lazy_list
    assert 'hawk' in lazy_list
    assert 'netrc' in lazy_list

# Generated at 2022-06-21 13:21:53.612535
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():  # pragma: no cover
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:22:02.970201
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'netrc' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='NAME',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    AUTH plugin to use: {0} or {1}.
    If not specified, it is guessed from --auth.

    '''.format(', '.join(sorted(AUTH_PLUGINS)),
               ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

# Generated at 2022-06-21 13:22:14.215750
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices()))[0] == 'basic'


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    How the credentials are sent. Supported authentication types:

        {choices}

    '''.format(
        choices=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-21 13:22:26.025980
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'aws' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The "auto" mechanism performs
    automatic authentication using the best available mechanism.

    The supported authentication mechanisms are:

    ''' + '\n'.join(
        '{0}{1}'.format(4 * ' ', line.strip())
        for line in wrap(', '.join(plugin_manager.get_auth_plugin_mapping().keys()), 60)
    )
)

# Generated at 2022-06-21 13:22:27.102768
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:28.905776
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices


# Generated at 2022-06-21 13:22:30.239063
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "foo" in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:31.940671
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:22:57.107227
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Verify we can use a plugin by name
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:22:58.842539
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:09.338050
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__(): pass


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The supported types are:

        auto - (default) automatically detect the mechanism
        basic - HTTP Basic Auth
        digest - HTTP Digest Auth
    {auth_plugin_mapping}
    '''.format(
        auth_plugin_mapping=_format_auth_plugin_mapping(
            '        ', ' - '
        )
    )
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:23:18.084151
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    choices = _AuthTypeLazyChoices()
    assert 'basic' in choices
    assert 'digest' in choices
    assert len(choices) == 2
    assert list(choices) == ['basic', 'digest']

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication mechanism. Currently supported: {choices}.

    '''.format(choices=', '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())))
)


# Generated at 2022-06-21 13:23:28.892831
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # tests that in python2.7 and python3.4 options are displayed
    for auth in _AuthTypeLazyChoices():
        # print(auth)
        pass


# Generated at 2022-06-21 13:23:39.511836
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert list(_AuthTypeLazyChoices()) == sorted(mapping.keys())



# Generated at 2022-06-21 13:23:42.814693
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' in auth_type
    assert 'digest' not in auth_type


# Generated at 2022-06-21 13:23:44.976238
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'token' in _AuthTypeLazyChoices() and \
        'bearertoken' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:23:52.199049
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == list([
        'basic',
        'digest',
        'hawk',
    ])

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.
    Defaults to basic. Currently supported:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)

# Generated at 2022-06-21 13:23:56.276798
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == list(iter(lazy_choices))

# Generated at 2022-06-21 13:24:19.200920
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    choices = _AuthTypeLazyChoices()
    assert sorted(choices) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-21 13:24:20.627910
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    lazy = _AuthTypeLazyChoices()
    return {'basic'} <= lazy

# Generated at 2022-06-21 13:24:31.900682
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'ntlm' in _AuthTypeLazyChoices()


auth_plugin_mapping_docstring = '\n'.join(
    '    {0:<15} {1}'.format(key, plugin.get_auth_type_name())
    for key, plugin in plugin_manager.get_auth_plugin_mapping().items()
)


# Generated at 2022-06-21 13:24:39.786210
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    plugin_manager.clear()
    pm = plugin_manager
    pm.unregister_auth_plugin('basic')
    pm.register_auth_plugin('basic')
    auth_type = _AuthTypeLazyChoices()
    assert 'basic' in auth_type
    assert 'digest' not in auth_type
    pm.register_auth_plugin('digest')
    assert 'digest' in auth_type


auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='The authentication type. '
         f'Defaults to {DEFAULT_AUTH_PLUGIN_NAME}.'
)

# Generated at 2022-06-21 13:24:47.944581
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for i in list(_AuthTypeLazyChoices()):
        pass

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=DefaultAuthPlugin.name,
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help='''
    How to handle the provided credentials.

    The value is case-insensitive.
    For backward compatibility, the "basic" auth plugin is the default if no
    value is provided with the --auth-type option.

    {plugin_str}

    '''.format(plugin_str=get_auth_plugin_info())
)

# Generated at 2022-06-21 13:24:54.500567
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['Basic', 'Digest']

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=AuthPlugin.normalize_auth_type,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the credentials.
    This can be any of: {0}.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-21 13:25:04.144260
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    class _AuthTypeLazyChoicesTest(ArgumentParser):
        def _check_value(self, action, value):
            try:
                super(_AuthTypeLazyChoicesTest, self)._check_value(action, value)
            except ArgumentTypeError as e:
                print(e)

    parser = _AuthTypeLazyChoicesTest()
    parser.add_argument('--auth-type', nargs='?', choices=_AuthTypeLazyChoices())

    parser.parse_args(['--auth-type', ''])


# Generated at 2022-06-21 13:25:10.097841
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert '123' not in auth_type_lazy_choices

    assert list(auth_type_lazy_choices) == ['basic', 'digest']

    plugin_manager.discover_auth_plugins()

    assert 'hawk' in auth_type_lazy_choices
    assert '123' not in auth_type_lazy_choices
    assert list(auth_type_lazy_choices) == ['basic', 'digest', 'hawk']


# Generated at 2022-06-21 13:25:18.089198
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'aws' in auth_type_lazy_choices
    assert 'aws' in auth_type_lazy_choices
    assert 'aws' in auth_type_lazy_choices
    mylist = [el for el in auth_type_lazy_choices]
    assert mylist == ['aws', 'hawk', 'http', 'jwt', 'kerberos', 'netrc', 'oauth1']


# Generated at 2022-06-21 13:25:20.669131
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'no-such-scheme' not in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:26:10.591461
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    del plugin_manager.plugin_map['auth']
    assert list(_AuthTypeLazyChoices()) == []
    plugin_manager.discover()
    assert sorted(list(_AuthTypeLazyChoices())) == ['basic', 'digest']

auth_type_choices = _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:26:20.403918
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'authtype' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_SCHEME',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication scheme to be used.  This option is available only if
    plugins have been installed using the "http --install-auth-plugin" command.

    ''',
)

# Generated at 2022-06-21 13:26:28.995022
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(_AuthTypeLazyChoices()) == [
        'digest',
        'jwt',
        'hawk',
        'ntlm',
        'oauth1',
        'aws',
    ]


# Generated at 2022-06-21 13:26:30.216058
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'dp' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:26:32.464499
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic',
        'digest',
        'hawk',
        'ntlm',
    ]


# Generated at 2022-06-21 13:26:40.121325
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert [x for x in _AuthTypeLazyChoices()] == ['digest', 'jwt', 'tls']

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    If a custom auth plugin is installed, use this option to specify the auth
    type. If no auth plugin is installed, an error is raised.

    Example::

        $ http --auth-type=my-custom-auth -a user:pass

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy_group = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-21 13:26:45.224942
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'custom' in _AuthTypeLazyChoices()
    assert 'unexpected' not in _AuthTypeLazyChoices()


# Generated at 2022-06-21 13:26:49.208832
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    choices = _AuthTypeLazyChoices()
    assert choices.__contains__('basic')
    assert not choices.__contains__('does not exist')

# Generated at 2022-06-21 13:26:57.537840
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
auth_type = parser.add_argument_group(title='Authentication') \
    .add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified,
    HTTPie tries to guess from --auth.

    {choices}
    '''.format(
        choices=(
            'Must be one of: ' +
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
    )
)


#######################################################################
# SSL
#######################################################################

# Generated at 2022-06-21 13:26:58.832453
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for value in _AuthTypeLazyChoices():
        assert value in _AuthTypeLazyChoices()



# Generated at 2022-06-21 13:28:07.072637
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices())



# Generated at 2022-06-21 13:28:18.245256
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == [
        'basic', 'digest', 'hawk', 'netrc', 'oauth1'
    ]


# Generated at 2022-06-21 13:28:29.625173
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mapping = plugin_manager.get_auth_plugin_mapping()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'custom-header-auth' in _AuthTypeLazyChoices()
    assert 'custom-query-auth' in _AuthTypeLazyChoices()
    assert list(_AuthTypeLazyChoices()) == sorted(list(mapping.keys()))

# ``requests.request`` keyword arguments.

# Generated at 2022-06-21 13:28:30.939232
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-21 13:28:38.799032
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert AUTH_PLUGIN_MAPPER_NAME in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAPPER_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is "{}" which is a builtin intelligent
    guesser of the authentication type.

    The available choices depend on installed plugins.
    Use `http --debug plugins' to get the list.
    (Plugin developers: see <{}>.)

    '''.format(AUTH_PLUGIN_MAPPER_NAME, PLUGIN_DOCS_PAGE_URL)
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-21 13:28:44.426964
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    >>> list(_AuthTypeLazyChoices()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())
    True
    """



# Generated at 2022-06-21 13:28:52.688768
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an HTTP authentication type to be used for making HTTP request
    (default: {'auto'}).

    The available types are:

      {', '.join(plugin_manager.get_auth_plugin_mapping())}

    To find more about authentication plugins, see
    https://github.com/jkbrzt/httpie#authentication.
    ''',
)
