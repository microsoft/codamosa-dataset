

# Generated at 2022-06-25 17:54:47.534266
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices is not None
    assert 'plugin' in auth_type_lazy_choices
    assert 'basic' in auth_type_lazy_choices
    assert any(True for _ in auth_type_lazy_choices)
    assert len(list(auth_type_lazy_choices)) > 0 


# Generated at 2022-06-25 17:54:49.600779
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(auth_type_lazy_choices_0)) == sorted(list(plugin_manager.get_auth_plugin_mapping().keys()))



# Generated at 2022-06-25 17:55:00.321200
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert(test_case_0())

#######################################################################
# Pretty output
#######################################################################

pretty = parser.add_argument_group(title='Pretty output')
pretty.add_argument(
    '--style', '-s',
    dest='style',
    metavar='STYLE',
    default=DEFAULT_STYLE,
    choices=AVAILABLE_STYLES,
    help='''
    Output coloring style. One of:

    {available_styles}

    '''.format(
        available_styles='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(AVAILABLE_STYLES)), 60)
        ).strip(),
    )
)

# Generated at 2022-06-25 17:55:02.379081
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert choi in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:03.736915
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:14.592099
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    plugins = plugin_manager.get_auth_plugin_mapping()

    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0_iter = iter(auth_type_lazy_choices_0)

    plugin_manager_auth_plugin_mapping_values_iter = iter(plugins.values())
    plugin_manager_auth_plugin_mapping_keys_iter = iter(plugins.keys())


# Generated at 2022-06-25 17:55:24.829164
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    register_plugin_class(
        test_plugin_0_0.TestCasePlugin_0_0,
        'test_plugin_0_0',
        'test_plugin_0_0',
        'test_plugin_0_0')
    register_plugin_class(
        test_plugin_0_1.TestCasePlugin_0_1,
        'test_plugin_0_1',
        'test_plugin_0_1',
        'test_plugin_0_1')
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert 'test_plugin_0_0' in auth_type_lazy_choices_1
    assert 'test_plugin_0_1' in auth_type_lazy_choices_1
    assert 'test_plugin_0_2'

# Generated at 2022-06-25 17:55:26.402960
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert (test_case_0()[0])


# Generated at 2022-06-25 17:55:34.918959
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(test_case_0, 'auth_type_lazy_choices_0')

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. It can be one of the following:

        {auth_type_choices}

    '''.format(
        auth_type_choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)

#######################################################################
# Transport
#######################################################################


transport = parser.add

# Generated at 2022-06-25 17:55:37.697971
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-25 17:55:51.715840
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    list_1 = auth_type_lazy_choices_0.__iter__()


auth.add_argument(
    '--auth-type',
    default=None,
    type=plugin_manager.resolve_plugin_name_to_plugin,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The explicit authentication type to use. When not provided, an appropriate
    authentication type is auto-detected as described below:

    {_AUTH_TYPE_HELP}

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies', )

# Generated at 2022-06-25 17:56:01.330444
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    try:
        assert var_0 == False
        print("OK")
    except AssertionError as e:
        print("Error")

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    The available options depend on the installed plugins.

    Example:

        $ {program} --auth-type=digest ...

    '''.replace('    ', '')  # Strip indent from the help message.
)

# Generated at 2022-06-25 17:56:07.133079
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for iterator_0 in auth_type_lazy_choices_0:
        pass
    iterator_1 = auth_type_lazy_choices_0
    auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:56:11.400492
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)


# Generated at 2022-06-25 17:56:12.401942
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:56:22.468353
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for var_0 in auth_type_lazy_choices_0.__iter__():
        pass

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force HTTPie to use the specified authentication type, overriding the
    default one, which is auto-detected.

    Use this option if you are experiencing problems with automatic detection
    of the correct auth type for your web service.

    '''
)

# Generated at 2022-06-25 17:56:24.178762
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)


# Generated at 2022-06-25 17:56:36.202425
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = ['zZBKj3', 'cO', '4NQj6U', '6v', '7dW8L9', 'BNLiZz', 'sE', 'sR', 'EPHlAu', ' ', 'KjPxrB', 'T']
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_0.__next__()
    var_0.__next__()
    var_0.__next__()
    var_0.__next__()
    var_0.__next__()



# Generated at 2022-06-25 17:56:46.518959
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type = plugin_manager.get_auth_plugin_mapping() or {}

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to use.

    If set to 'auto' (default), the auth type is autodetected based on
    the supplied credentials (if any).

    The following auth types are supported by HTTPie:

        {', '.join(auth_type)}

    If the URL contains embedded credentials and --auth is also provided,
    then the latter takes precedence.

    ''',
)


#######################################################################
# Plugin configuration
#######################################################################

plugin_config = parser.add_argument_group

# Generated at 2022-06-25 17:56:47.706665
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 17:57:04.285937
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. If not provided, an appropriate one is
    automatically selected based on the --auth option value. Usually, --auth
    and --auth-type are used together. But in some cases, an auth plugin can
    deduce the required credentials from the URL or other options, and in such
    cases it's possible to use --auth-type only.

    The following auth mechanisms are available:

        {auth_type_choices}

    '''
)

#######################################################################
# HTTP scheme
#######################################################################

scheme = parser.add_argument_group(title='HTTP scheme')

# Generated at 2022-06-25 17:57:05.825206
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = _AuthTypeLazyChoices()
    var_0 = list_0.__iter__()



# Generated at 2022-06-25 17:57:08.545663
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:57:20.052804
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__().__next__()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify the authentication mechanism.
    For example, to use OAuth 2:

        --auth-type=oauth2

    Available types:

        {auth_plugins}

    To get help for a specific mechanism:

        http --auth-type=<type> --help

    '''.format(
        auth_plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-25 17:57:27.193329
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    except Exception as e:
        var_1 = False
    else:
        var_1 = True
    assert var_1


# Generated at 2022-06-25 17:57:29.147280
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:57:38.281306
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    plugin_manager_0 = PluginManager()
    var_1 = plugin_manager_0.get_auth_plugin_mapping()
    var_2 = auth_type_lazy_choices_0.__contains__(var_1)
    auth_type_lazy_choices_0.__iter__()
    auth_type_lazy_choices_0.__iter__()
    auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:57:44.599188
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices__contains___0 = None
    _AuthTypeLazyChoices__contains___1 = None
    var_0 = _AuthTypeLazyChoices().__contains__(_AuthTypeLazyChoices__contains___0)
    var_1 = _AuthTypeLazyChoices().__contains__(_AuthTypeLazyChoices__contains___1)


# Generated at 2022-06-25 17:57:55.634692
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)

auth_type = auth.add_argument(
    '--auth-type',
    choices=sorted(plugin_manager.get_auth_plugin_mapping().keys()),
    help='''
    The authentication mechanism.  Defaults to the most secure mechanism
    available.

    '''
)

#######################################################################
# Custom headers
#######################################################################

headers = parser.add_argument_group(title='Custom Headers')


# Generated at 2022-06-25 17:57:58.658832
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:58:17.989444
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    default=None,
    help='''
    The authentication mechanism to use. Run ``http --debug --help`` to see a
    list of built-in and third-party plugins.

    '''
)

# Generated at 2022-06-25 17:58:30.830108
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    new_instance = _AuthTypeLazyChoices()
    assert isinstance(new_instance, _AuthTypeLazyChoices)
    assert new_instance.__contains__('token')
    assert new_instance.__contains__('digest')
    assert new_instance.__contains__('json')
    # assert new_instance.__contains__('obj')
    # assert new_instance.__contains__('args')
    # assert new_instance.__contains__('kwargs')
    # assert new_instance.__contains__('argv')
    # assert new_instance.__contains__('item')
    # assert new_instance.__contains__('list_0')
    # assert new_instance.__contains__('temp_2')
    # assert new_instance.__contains__('temp

# Generated at 2022-06-25 17:58:39.430385
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    help='''
    Type of HTTP authentication.

    Available values:

        {choices}

    '''.format(
        choices='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    ),
    choices=_AuthTypeLazyChoices(),
)

# Generated at 2022-06-25 17:58:49.434700
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    print(var_0)
    print('Done')

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    At the moment, the following auth mechanisms are supported:
    {0}
    '''.format(
        wrap(' '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        ), 80)
    ),
)

# Generated at 2022-06-25 17:58:51.724164
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert True


_AUTH_TYPES = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:53.025792
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert_equal(test_case_0(), True)


# Generated at 2022-06-25 17:59:03.480701
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test for method __contains__
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    metavar='NAME',
    type=AuthPluginNameValidator(),
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The name of the authentication plugin to use. If not specified, the
    authentication plugin is tried to be inferred from the username. The
    following authentication plugins are currently available:

    {auth_plugin_names}

    Note that the `http' plugin is the same as no `--auth-type' being specified
    at all.

    '''
)


# Generated at 2022-06-25 17:59:10.280964
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert True

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication type to use. The value can be one of:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    Or the path to a Python module that defines an HTTPie authentication
    plugin.

    The default authentication type is Basic.

    '''
)


# Generated at 2022-06-25 17:59:11.905672
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 17:59:20.812610
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = []
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert isinstance(var_0, iter) == True
    # Test if there is an element in iterator
    list_0 += [var_0.__next__()]
    assert len(list_0) > 0

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=AuthCredentials.validate_auth_type,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Default is guessed from the provided credentials.

    ''',
)

# Generated at 2022-06-25 17:59:43.562094
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True == _AuthTypeLazyChoices.__contains__(_AuthTypeLazyChoices(), None)
    assert True == _AuthTypeLazyChoices().__contains__(None)
    assert True == _AuthTypeLazyChoices().__contains__('digest')
    assert True == _AuthTypeLazyChoices().__contains__(None)
    assert True == _AuthTypeLazyChoices().__contains__('basic')


# Generated at 2022-06-25 17:59:52.627916
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    iterator_0 = auth_type_lazy_choices_0.__iter__()
    var_0 = isinstance(iterator_0, Iterator)
    assert var_0 == True

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Overrides the authentication mechanism used (Basic, Digest etc.).
    Types are case-insensitive and values are as produced by
    `http --debug | grep ^auth-type`.

    ''',
)

# Generated at 2022-06-25 18:00:03.729183
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = None
    test_case_0()
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    type=plugin_manager.get_auth_plugin_mapping(),
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, it will be
    auto-detected.

    Current choices:

        {auth_plugins}

    '''.format(
        auth_plugins='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(_AuthTypeLazyChoices())), 60)
        ).strip(),
    )
)

# Generated at 2022-06-25 18:00:14.965712
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Valid builtin types include:

        basic, digest

    Use the --auth-plugin option to list all the builtin types,
    as well as any installed plugin types.

    ''',
)

# Generated at 2022-06-25 18:00:23.400721
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _iter__0 = None
    _iter__1 = None
    _iter__2 = None
    _iter__3 = None
    _iter__4 = None
    _iter__5 = None
    _iter__6 = None
    _iter__7 = None
    _iter__8 = None
    _iter__9 = None
    _iter__10 = None
    _iter__11 = None
    _iter__12 = None
    _iter__13 = None
    _iter__14 = None
    _iter__15 = None
    _iter__16 = None
    _iter__17 = None
    _iter__18 = None
    _iter__19 = None
    _iter__20 = None
    _iter__21 = None
    _iter__22 = None
    _iter__23 = None
    _iter__24 = None

# Generated at 2022-06-25 18:00:35.589861
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    val_0 = auth_type_lazy_choices_0.__iter__()
    assert not var_0
    assert val_0 is not None

auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-25 18:00:41.289287
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    if var_0:
        print("1")
    else:
        print("2")


# Generated at 2022-06-25 18:00:53.484865
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_2 = None
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = plugin_manager.get_auth_plugin_mapping(list_2, auth_type_lazy_choices_1)
    var_2 = list(auth_type_lazy_choices_1)
    assert var_1 == var_2

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.
    Run ``http --help-auth`` to print the list of supported auth types.

    '''
)

#######################################################################
# HTTP method
#######################################################################


# Generated at 2022-06-25 18:01:03.031810
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of auth plugin to use. By default, the plugin is guessed from the
    --auth option.

    The following plugins are currently available:

    {auth_plugins_help}

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help=f'''
    Do not load .netrc data.

    '''
)


#######################################################################
# Certificates
#######################################################################

certs = parser.add_argument_group(title='Certificates')

cert

# Generated at 2022-06-25 18:01:09.126118
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0() == False

auth.add_argument(
    '--auth-type',
    metavar='type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force a particular authentication method to be used. Valid choices are:

    '''.strip() + '\n'.join(
        (8 * ' ') + '{0}{1}'.format(
            k, ' ' * (16 - len(k))
        ) + plugin.description
        for k, plugin in plugin_manager.get_auth_plugin_mapping().items()
    ).strip()
)

#######################################################################
# Miscellanea
#######################################################################

miscellanea = parser.add_argument_group(title='Miscellanea')

miscellanea

# Generated at 2022-06-25 18:01:52.182585
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of the specified auth plugin. By default the appropriate
    plugin is guessed based on the provided credentials. That is, --auth-type
    is only needed when the credentials are ambiguous (e.g., both a token
    and a username were provided).

    The available plugins are: {0}.

    '''.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping())
    ).strip()
)
auth.add_argument

# Generated at 2022-06-25 18:02:04.142698
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # ValueError is raised for invalid types for parameter 'item'
    # in the method __contains__ of class _AuthTypeLazyChoices.
    # Invalid types for 'item'
    # are empty strings, None, and floats.
    assert_raises(ValueError, test_case_0)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=sorted(_AuthTypeLazyChoices()),
    help='''
    Specify a custom authentication plugin, e.g., ``ntlm``.
    Use ``--debug`` flag to see a list of all plugins.

    ''',
)

# Generated at 2022-06-25 18:02:06.191602
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:02:14.306502
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for i in auth_type_lazy_choices_0:
        print(i)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of a registered plugin that handles the authentication mechanism.

    ''',
).completer = ChoicesCompleter(
    ChoicesCompleter.DYNAMIC_MAPPING_ATTR, 'get_auth_plugin_mapping',
    ChoicesCompleter.DYNAMIC_MAPPING_KEY, 'name',
)


# Generated at 2022-06-25 18:02:23.533678
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    default=None,
    help='''
    The authentication mechanism. By default, HTTPie tries to determine
    the authentication type and prompts for missing credentials, if
    necessary. If a known authentication type is specified, then HTTPie
    may not prompt for anything, even if more credentials are needed.

    The following authentication mechanisms are currently supported:

        {auth_types}
        custom ... Use a custom auth plugin.

    '''.format(
        auth_types=_AuthTypeLazyChoices(),
    )
)


# Generated at 2022-06-25 18:02:36.090344
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth implementation to use. Defaults to "auto",
    which allows HTTPie to choose the best plugin based on the --auth option
    value.

    ''',
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 18:02:45.555864
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    auth_type_lazy_choices_0_0 = _AuthTypeLazyChoices()
    for item in auth_type_lazy_choices_0_0:
        print(item)
    auth_type_lazy_choices_0_1 = _AuthTypeLazyChoices()
    for item in auth_type_lazy_choices_0_1:
        print(item)
    auth_type_lazy_choices_0_2 = _AuthTypeLazyChoices()
    for item in auth_type_lazy_choices_0_2:
        print

# Generated at 2022-06-25 18:02:46.353592
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:02:47.289791
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True == test_case_0()

# Generated at 2022-06-25 18:02:55.252170
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    iterator_0 = auth_type_lazy_choices_0.__iter__()
    assert_true(isinstance(iterator_0, Iterator))
    assert_equal(next(iterator_0), list_0)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism (basic, digest, or a proprietary
    one provided by a plugin).

    '''
)

# Generated at 2022-06-25 18:04:08.296079
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        print('test case 0 failed')


# Generated at 2022-06-25 18:04:12.765698
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 1
    plugin_manager.get_auth_plugin_mapping()
    var_0 = auth_type_lazy_choices_0.__contains__(list_0)
    assert var_0 == None


# Generated at 2022-06-25 18:04:21.460871
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()



# Generated at 2022-06-25 18:04:28.073257
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used with --auth. The default value is
    '{default}' if none is specified.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN
    )
)

# Generated at 2022-06-25 18:04:34.596825
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Which method to use for authenticating against the server. If
    no scheme is provided (e.g., "username" instead of "basic:username"),
    HTTPie will attempt to guess the scheme based on the server's
    401 response(s) (default: "auto").

    ''',
)

# Generated at 2022-06-25 18:04:39.569931
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = None
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__iter__(list_0)
