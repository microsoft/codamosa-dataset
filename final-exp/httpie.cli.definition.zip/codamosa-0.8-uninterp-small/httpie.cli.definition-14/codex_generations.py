

# Generated at 2022-06-25 17:54:38.269626
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()



# Generated at 2022-06-25 17:54:45.335634
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test case 0
    it = iter(auth_type_lazy_choices_0)
    assert(isinstance(it, types.GeneratorType))
    key = next(it)
    assert(key == 'basic')
    key = next(it)
    assert(key == 'digest')
    with raises(StopIteration): next(it)
    # Test case 1:
    assert(auth_type_lazy_choices_1.__contains__('basic'))
    assert(auth_type_lazy_choices_1.__contains__('digest'))

auth_type_lazy_choices_1 = _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:54:47.858434
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__('digest') == True


# Generated at 2022-06-25 17:54:58.447671
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    print("auth_type_lazy_choices: %s" % auth_type_lazy_choices)
    assert "basic" in auth_type_lazy_choices
    assert "digest" in auth_type_lazy_choices
    assert "hawk" in auth_type_lazy_choices
    assert "aws4-hmac-sha256" in auth_type_lazy_choices


# Generated at 2022-06-25 17:55:00.751789
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    at = _AuthTypeLazyChoices()
    assert 'basic' in at
    assert 'digest' in at
    assert 'fake-auth' in at


# Generated at 2022-06-25 17:55:06.557247
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from pytest import raises

    with raises(TypeError):
        _AuthTypeLazyChoices()



auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to use for authentication.

    Available plugins:

    {auth_plugins}

    '''.format(auth_plugins=plugin_manager.get_help_for_auth_plugins())
)


#######################################################################
# HTTP and HTTPS
#######################################################################

http = parser.add_argument_group(title='HTTP and HTTPS')


# Generated at 2022-06-25 17:55:08.681739
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['digest', 'hawk', 'oauth1']


# Generated at 2022-06-25 17:55:14.678803
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test directly
    iter_result = list(_AuthTypeLazyChoices().__iter__())
    iter_expect = ['basic', 'digest', 'hawk', 'jwt', 'oauth1', 'session']
    assert iter_result == iter_expect

    # Test indirectly
    assert list(_AuthTypeLazyChoices()) == ['basic', 'digest', 'hawk', 'jwt', 'oauth1', 'session']


# Generated at 2022-06-25 17:55:24.255460
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class Subclass(_AuthTypeLazyChoices):
        def __iter__(self):
            return iter(sorted(['aa', 'bb', 'cc']))
    assert list(Subclass()) == ['aa', 'bb', 'cc']

# For subclasses of _AuthTypeLazyChoices, the method __iter__ should return a
# list sorted in ascending order.

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='The auth mechanism to be used. Currently supported: basic, digest.'
)

# Generated at 2022-06-25 17:55:26.862427
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert iter(auth_type_lazy_choices_1) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


# Generated at 2022-06-25 17:55:36.968678
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('basic' in _AuthTypeLazyChoices()) is True

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin. The default is "basic",
    which is basically Base64-encoded "{auth}".  To disable any
    authentication, use "noauth". Plugins are searched for in the
    "httpie/plugins/auth" directory, similarly to other plugins.
    To learn how to write plugins, see
    https://httpie.org/docs/plugins.html#authentication-plugins.

    '''.format(auth=HTTP_AUTHORIZATION_HEADER)
)

# Generated at 2022-06-25 17:55:38.816212
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'Basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:44.849102
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    def __next__():
        rv = next(iter(auth_type_lazy_choices_0))
        return rv
    class Iterator:

        def __iter__(self):
            return self

    assert list(Iterator()) == list(mock_iter())


# Generated at 2022-06-25 17:55:47.835751
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(auth_type_lazy_choices_0)
    try:
        while True: next(it)
    except StopIteration as e: pass


# Generated at 2022-06-25 17:55:50.716229
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:00.715311
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert __new__(set).__init__(auth_type_lazy_choices_0) == None
    assert all(auth_type_lazy_choices_0) == False


# Generated at 2022-06-25 17:56:12.490450
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism. The default is to figure it out automatically.
    HTTPie can do Basic, Digest and Kerberos authentication.

    The available auth types for a given URL depend on the plugins
    installed. Run `http --debug` to see a list of installed plugins
    and which auth types are available for a given URL.

    '''
)
auth.add_argument(
    '--auth-overwrite', '-A',
    action='store_true',
    help='''
    Overwrite existing authentication headers and credentials.

    '''
)

# Generated at 2022-06-25 17:56:22.468181
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'kerberos' in auth_type_lazy_choices_0
    assert 'gssnegotiate' in auth_type_lazy_choices_0
    assert 'ntlm' in auth_type_lazy_choices_0
    assert 'oauth1' in auth_type_lazy_choices_0
    assert 'mutual-tls' in auth_type_lazy_choices_0



# Generated at 2022-06-25 17:56:24.367856
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    try:
        ans = list(auth_type_lazy_choices)
    except:
        raise Exception('Failed to iterate over _AuthTypeLazyChoices')


# Generated at 2022-06-25 17:56:27.191928
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('digest' in _AuthTypeLazyChoices()) # test__AuthTypeLazyChoices___contains__


# Generated at 2022-06-25 17:56:40.073128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Test with concrete value
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        list_0 = ['basic', 'digest', 'hawk', 'ntlm']
        for var_0 in list_0:
            var_1 = auth_type_lazy_choices_0.__contains__(var_0)
            assert var_1 == True
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 17:56:44.783281
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the authentication mechanism.

    Choose one of:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:56:50.518471
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    help='''
    The type of auth to use.

    The available auth types depend on the installed plugins.

    ''',
    choices=auth_type_lazy_choices,
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:56:54.559377
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # unit test for method __contains__ of class _AuthTypeLazyChoices
    test_case_0()


# Generated at 2022-06-25 17:57:05.944251
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    default=DEFAULT_AUTH_PLUGIN,
    dest='auth_plugin_name',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. It can be one of:

        {auth_types}

    Defaults to '{default}'.

    '''.format(
        default=DEFAULT_AUTH_PLUGIN,
        auth_types='\n'.join(
            (8 * ' ') + line.strip()
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip()
    )
)
auth.add

# Generated at 2022-06-25 17:57:08.673029
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(var_0)



# Generated at 2022-06-25 17:57:20.348708
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. This is usually inferred from the
    command-line flag and arguments. However, it can be specified explicitly
    with this option.

    For Basic and Digest auth, the username and password are parsed from the
    URL.

    Examples:
        --auth-type=basic
        --auth-type=digest
        --auth-type=bearer

    '''
)

# Generated at 2022-06-25 17:57:21.622038
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 17:57:33.744727
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_plugin',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    metavar='NAME',
    help='''
    Use the specified authentication plugin.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not try to perform challenge request in case of HTTP 401 response.
    Instead, provide the credentials in the request.
    Implies --auth-type=basic.

    '''
)

# Generated at 2022-06-25 17:57:45.686107
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('json')
    if (var_0):
        pass


# Generated at 2022-06-25 17:58:00.659367
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# The `choices` argument must be specified after the `default` argument.
# See https://github.com/jakubroztocil/httpie/issues/617.
auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    Authentication plugin to use. Supported plugins:

        {plugin_manager.get_installed_auth_plugin_names()}

    The default plugin is used when this option is not provided (see
    the --auth-type option).

    '''
)

# Generated at 2022-06-25 17:58:13.297580
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN_NAME,
    help=f'''
    Set the authentication mechanism.

    Available authentication plug-ins are:

    {auth_plugin_table}

    Check the documentation for more details:
        {AUTH_PLUGINS_HELP_URL}
    '''
)

auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Do not use the ~/.netrc file to lookup credentials for the URL host.

    ''',
)

#######################################################################
# Timeouts
#######################################################################


# Generated at 2022-06-25 17:58:22.962930
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    list_0 = [var_0]
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices(*list_0)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help=f'''
    The method used to process credentials.
    {HELP_AUTH_PLUGINS}
    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 17:58:26.797378
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__('--auth-type')
    except Exception as exception_0:
        print(exception_0)
    var_1 = auth_type_lazy_choices_0.__contains__('--auth-type')


# Generated at 2022-06-25 17:58:28.240124
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:58:37.653591
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import unittest
    try:
        test_case_0()
    except:
        raise unittest.SkipTest(
            'Unable to run test case since the module '
            'httpie.cli.argtypes is inaccessible'
        )

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    dest='auth_plugin_name',
    choices=_AuthTypeLazyChoices(),
    nargs='?',
    help='''
    The auth scheme. By default, requests tries to determine the scheme from
    the URL. This option can also be used to force the use of HTTP Basic
    auth (--auth-type=basic).

    '''
)


# Generated at 2022-06-25 17:58:39.517294
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

# Unit tests for class _AuthTypeLazyChoices

# Generated at 2022-06-25 17:58:49.470357
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified auth plugin. The default, if this option is not used,
    is to auto-detect the auth type, by looking at the supplied username and
    password, and other request details.

    Available plugins:

    {0}

    Use --debug to show the request details.

    '''.format(get_available_auth_plugins_doc())
)

#######################################################################
# SSL
#######################################################################

ssl_ = parser.add_argument_group(title='SSL')


# Generated at 2022-06-25 17:58:57.234371
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()  # noqa: E741
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=plugin_manager.make_auth_type_validator(),
    choices=auth_type_lazy_choices,
    default=DEFAULT_AUTH_PLUGIN,
    help='''
    Choose an authentication plugin. Use "http --debug" to see the available
    plugins. The default is "{0}".

    Most plugins also support the --auth and --auth-type options
    for configuring the credentials. See the plugin documentation for details.

    '''.format(DEFAULT_AUTH_PLUGIN)
)

# Generated at 2022-06-25 17:59:00.281898
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'basic'
    assert str_0 in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:59:23.730976
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    # Constructor call without arguments
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Set the authentication mechanism.

    The value is one of the HTTPie-provided mechanisms,
    such as "basic" or "digest", or is the name of a plugin,
    such as for the GitHub auth plugin: "gh".

    '''
)

# Generated at 2022-06-25 17:59:31.623695
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    Specify the auth mechanism.

    (DEPRECATED) Please use --auth-plugin instead.

    '''
)

auth.add_argument(
    '--auth-plugin',
    choices=_AuthTypeLazyChoices(),
    default=None,
    metavar='TYPE',
    help='''
    Specify the auth mechanism.

    Available types: {types}.

    See https://httpie.org/plugins for details.

    '''.format(
        types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)



# Generated at 2022-06-25 17:59:36.652050
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(
       plugin_manager.get_auth_plugin_mapping())

# Generated at 2022-06-25 17:59:44.933923
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
  try:
    test_case_0()
  except:
    print("Testcase 0 failed")
  else:
    print("Testcase 0 passed")


# Generated at 2022-06-25 17:59:53.262854
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='Type of HTTP authentication.'
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='Send preemptive Basic/Digest auth credentials.'
)
auth.add_argument(
    '--ignore-netrc',
    default=False,
    action='store_true',
    help='Do not use .netrc for auth credentials.'
)
auth.add_argument(
    '--netrc-path',
    default=None,
    help='Path to .netrc file.'
)

# Generated at 2022-06-25 17:59:56.807859
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        assert auth_type_lazy_choices_0.__contains__('basic')
    except Exception as err:
        print(err)


# Generated at 2022-06-25 18:00:01.524947
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    list_0 = [var_0]
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices(*list_0)



# Generated at 2022-06-25 18:00:07.614520
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__iter__()
    # iterable: '_AuthTypeLazyChoices'
    result_1 = list(var_1)
    assert(sorted(result_1) == sorted(sorted(plugin_manager.get_auth_plugin_mapping().keys())))


# Generated at 2022-06-25 18:00:17.477020
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    default=DEFAULT_AUTH,
    help=f'''
    The name of an authentication plugin (e.g., "basic", "digest").
    See the list of built-in plugins below, or use the --debug flag
    to get a list of all plugins.

    To disable authentication, use --auth-type=off.

    The default is {DEFAULT_AUTH!r}.

    In addition to built-in plugins, custom ones can be registered via
    setuptools entry points in the ``httpie_auth_plugin`` group.

    Available plugins: {_AuthTypeLazyChoices()}

    '''
)


# Generated at 2022-06-25 18:00:20.031695
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import pytest
    with pytest.raises(AssertionError):
        _AuthTypeLazyChoices.__iter__(None)


# Generated at 2022-06-25 18:01:02.470014
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
# ``--auth-type`` value -> ``requests.request`` ``auth`` kwarg.
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used: basic, digest, or auto (default).

    '''
)

#######################################################################
# Other
#######################################################################

other = parser.add_argument_group(title='Other')
other.add_argument(
    '--pretty-traceback',
    action='store_true',
    default=False,
    help='''
    Display a prettified traceback in case of an error.

    '''
)

# Generated at 2022-06-25 18:01:13.036354
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
    except:
        status = 'fail'
    else:
        status = 'pass'
    print("Test case {0} {1}".format('__iter__',status))

# Unit Test Runner
if __name__ == '__main__':
    test__AuthTypeLazyChoices___iter__()


# Generated at 2022-06-25 18:01:24.712566
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    list_0 = []
    list_1 = []
    list_0.append(list_1)
    list_2 = []
    list_0.append(list_2)
    list_3 = iter(list_0)
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify an Auth plugin. By default, HTTPie will try to guess
    based on the --auth option value.

    To see a list of supported auth types, use the --debug flag.

    '''
)

#######################################################################
# SSL/TLS options
#######################################################################


# Generated at 2022-06-25 18:01:28.987634
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    itr = iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    auth_type_lazy_choices = _AuthTypeLazyChoices(itr)
    var = auth_type_lazy_choices.__contains__(next(auth_type_lazy_choices.__iter__()))
    assert var == True


# Generated at 2022-06-25 18:01:30.607382
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices().__iter__(), types.MethodType)


# Generated at 2022-06-25 18:01:42.928667
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    sess = requests.Session()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(sess)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used. The default is "basic".
    '''
)

auth.add_argument(
    '--auth-type-',
    dest='auth_type_null_help',
    action='store_true',
    help=argparse.SUPPRESS
)
auth.set_defaults(auth_type_null_help=False)

#######################################################################
# Install arguments
#######################################################################


# Generated at 2022-06-25 18:01:51.676512
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism, overriding the default
    one, that is based on the URL hostname.

    When the value doesn't correspond to a registered plugin, HTTPie
    will try to load it as a Python module and will then assume that it
    is a custom auth plugin.

    Example:

        $ http -a user:password --auth-type=basic example.org

    Custom auth plugins are expected to be located in the
    ~/.config/httpie/auth directory.

    '''
)

# Generated at 2022-06-25 18:01:56.196229
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_0.__contains__('digest'))


# Generated at 2022-06-25 18:01:57.256235
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:02:08.508149
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    list_0 = [var_0]
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices(*list_0)
    var_1 = auth_type_lazy_choices_0.__iter__()
    var_2 = auth_type_lazy_choices_1.__iter__()
    var_3 = auth_type_lazy_choices_1.__contains__(var_2)

# Generated at 2022-06-25 18:03:16.131708
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:03:26.768187
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:03:27.775404
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:03:29.094388
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0()
    pass


# Generated at 2022-06-25 18:03:37.909168
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='SCHEME',
    type=plugin_manager.get_auth_plugin_mapping(),
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use a custom authentication mechanism.

    For example:

        --auth-type=amazon

    The auth mechanism is determined from the URL when this option is not
    specified.

    Check 'http --debug' output to see the list of builtin auth mechanisms.

    '''
)

#######################################################################
# Cookies
#######################################################################

# ``requests.request`` keyword arguments.
cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-25 18:03:41.217014
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(1)
    list_0 = [var_0]
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices(*list_0)


# Generated at 2022-06-25 18:03:49.552018
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
    except AttributeError as e:
        print("AttributeError")

auth.add_argument(
    '--auth-type',
    default=None,
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Currently implemented
    authentication schemes include: Basic, Digest. If not specified,
    HTTPie tries to detect the scheme.

    ''',
)

#######################################################################
# HTTP method
#######################################################################
method = parser.add_argument_group(title='HTTP method')


# Generated at 2022-06-25 18:03:50.457675
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass


# Generated at 2022-06-25 18:03:53.430426
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not auth_type_lazy_choices_0.__contains__("")


# Generated at 2022-06-25 18:04:01.521817
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    type=AuthCredentialsInUrlValidator,
    help=f'''
    Force the specified authentication mechanism. Currently supported:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    The default scheme is "Basic" (unless the URL contains credentials).

    '''
)