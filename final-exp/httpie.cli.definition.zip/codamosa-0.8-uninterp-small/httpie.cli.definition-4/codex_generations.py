

# Generated at 2022-06-25 17:54:43.785033
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
   auth.add_argument(
       '--auth-type',
       default=None,
       choices=_AuthTypeLazyChoices(),
       help='''
       Specify an authentication plugin by name.
       If not specified, the plugin is auto-detected.

       The auto-detection works like this:

       The plugin is determined from the username, if one
       is provided via -a, --auth.

       If no username is provided, and there is only one plugin
       registered, then that plugin is used.

       Otherwise, the interactive prompt is shown.

       Available plugins:

           {plugins}

       '''.format(
           plugins=' '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
       )
   )


# Generated at 2022-06-25 17:54:51.066565
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        assert (auth_type_lazy_choices_0.__contains__(0) == False)
    except:
        print(traceback.format_exc())
    try:
        assert (auth_type_lazy_choices_0.__contains__(True) == False)
    except:
        print(traceback.format_exc())
    try:
        assert (auth_type_lazy_choices_0.__contains__(False) == False)
    except:
        print(traceback.format_exc())

# Generated at 2022-06-25 17:54:55.068654
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert all([True if (item in plugin_manager.get_auth_plugin_mapping()) else False for item in _AuthTypeLazyChoices()])


# Generated at 2022-06-25 17:54:57.372760
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-25 17:55:04.665939
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin. If set to "auto", HTTPie attempts to
    detect the authentication type based on the presence of specific headers
    in the server's response.

    - basic: HTTP Basic Authentication.
    - digest: HTTP Digest Authentication.
    - jwt: JSON Web Token Authentication, requires pyjwt library.

    ''',
)


# Generated at 2022-06-25 17:55:15.374279
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    # Verify that every item of 'auth_type_lazy_choices_0' is within 'sorted(plugin_manager.get_auth_plugin_mapping().keys())'
    assert all(((item in sorted(plugin_manager.get_auth_plugin_mapping().keys())) for item in auth_type_lazy_choices_0))

    # Verify that every item of 'sorted(plugin_manager.get_auth_plugin_mapping().keys())' is within 'auth_type_lazy_choices_0'
    assert all(((item in auth_type_lazy_choices_0) for item in sorted(plugin_manager.get_auth_plugin_mapping().keys())))


# Generated at 2022-06-25 17:55:19.155216
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from httpie import plugin_manager
    how_many = len(plugin_manager.get_auth_plugin_mapping())
    assert how_many > 0
    for key in plugin_manager.get_auth_plugin_mapping().keys():
        assert key in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:24.770521
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from inspect import signature
    from httpie.config import AUTH_PLUGIN_MAP
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Test with different args
    args_list = (
        ('test_var_0',),
    )
    for args in args_list:
        assert args in signature(auth_type_lazy_choices_0.__contains__).bind(*args).arguments

    # Test raises exception
    args = ('test_var_0',)
    assert args not in AUTH_PLUGIN_MAP



# Generated at 2022-06-25 17:55:33.985567
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert _AuthTypeLazyChoices().__contains__('basic') == True
    assert _AuthTypeLazyChoices().__contains__('hawk') == False


auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. It can be "basic", "digest",
    "hawk" or a plugin's short name. For example, "aws" for the AWS
    authentication plugin (https://github.com/jakubroztocil/httpie-aws-auth).

    The default value is "basic".

    '''
)

#######################################################################
# Request redirection
#######################################################################

# Generated at 2022-06-25 17:55:35.329607
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('http' in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:51.297982
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    print ("test case for _AuthTypeLazyChoices")
    test_case_0()
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Instructs HTTPie to use a specific authentication plugin.

    Plugins are not loaded automatically (for performance reasons).
    You need to explicitly specify their name with this option
    in order to use them.

    ''',
)

# Generated at 2022-06-25 17:55:52.374502
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()



# Generated at 2022-06-25 17:55:54.786328
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert all(e in plugin_manager.get_auth_plugin_mapping() for e in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:56:03.083442
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert not test_case_0()



auth.add_argument(
    '--auth-type', '-A',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Auth plugin to use.
    Choices: {', '.join(_AuthTypeLazyChoices())}

    '''
)

auth.add_argument(
    '--auth-send',
    default='auto',
    choices=('auto', 'always', 'never'),
    help='''
    When to send credentials.
    Choices: auto (default), always, never.

    '''
)


# Generated at 2022-06-25 17:56:06.491441
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:56:11.611242
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    items = list(auth_type_lazy_choices)
    assert len(items) > 0
    assert items == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:56:21.793571
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''

    Authentication plugin to use [{', '.join(plugin_manager.get_auth_plugin_mapping().keys())}]
    '''
)

#######################################################################
# SSL
#######################################################################

ssl_verify = parser.add_argument_group(title='SSL/TLS verification')

# Generated at 2022-06-25 17:56:23.639445
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
    except:
        ut.printException()
        return False

    return True


# Generated at 2022-06-25 17:56:25.987819
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_0()
    assert ('asd' in auth_type_lazy_choices_0) == False


# Generated at 2022-06-25 17:56:32.164914
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    temp_lazy_var_0 = False
    try:
        temp_lazy_var_0 = (auth_type_lazy_choices_0).__contains__('')
    except:
        raise Exception()
    assert temp_lazy_var_0


# Generated at 2022-06-25 17:56:47.535547
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    def test_0():
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        assert auth_type_lazy_choices_0.__class__ == _AuthTypeLazyChoices
        assert auth_type_lazy_choices_0.__dict__ == {}
        assert auth_type_lazy_choices_0.__doc__ == None
        assert auth_type_lazy_choices_0.__hash__() == hash(_AuthTypeLazyChoices)
        assert auth_type_lazy_choices_0.__init__.__class__ == functools.partial
        assert auth_type_lazy_choices_0.__module__ == 'httpie.cli.argtypes'

# Generated at 2022-06-25 17:57:01.100325
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass    # No error

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism used for the request. Supported types:

        {0}

    '''.format('\n'.join(
        '{0}{1}'.format(8 * ' ', line.strip())
        for line in wrap(', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()
        )), 60)
    ).strip(),)
)

#######################################################################
# Timeouts.
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')


# Generated at 2022-06-25 17:57:04.378243
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (_AuthTypeLazyChoices() == \
            _AuthTypeLazyChoices())
    assert (_AuthTypeLazyChoices() != \
            _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:57:12.785916
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    help='''
    The auth mechanism to use.

    To use custom plugin-based auth schemes, prepend plugin name and a colon to
    the auth type, e.g., "customauth:oauth2".

    Use the --debug flag to see the list of all available plugins.

    ''',
    default=None,
    choices=_AuthTypeLazyChoices()
)


#######################################################################
# Proxying
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-25 17:57:16.754802
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__contains__('basic')


# Generated at 2022-06-25 17:57:18.106968
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:57:21.862968
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_1


# Generated at 2022-06-25 17:57:27.192323
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    d = _AuthTypeLazyChoices()
    s = ['basic', 'digest', 'aws_sigv4', 'hmac', 'custom']
    for i in range(len(s)):
        assert s[i] in d
    assert len(list(d)) == 5


# Generated at 2022-06-25 17:57:30.521023
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'aws4' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:57:33.527271
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(auth_type_lazy_choices_0)
    assert hasattr(it, "__iter__") or not isinstance(it, collections.Iterable)


# Generated at 2022-06-25 17:57:52.608117
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help='''
    The authentication mechanism to be used.

    Currently supported are:
    {list}

    '''.format(list=(8 * ' ') + ', '.join(
        plugin_manager.get_auth_plugin_mapping().keys()
    ).strip())
)

# Generated at 2022-06-25 17:58:01.035704
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_1.__contains__('--auth-type')

auth.add_argument(
    '--auth-type',
    default='auto',
    type=str,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism.
    Currently supported mechanisms: basic, digest.
    Set to "auto" to let HTTPie guess (default).

    ''',

)

# Generated at 2022-06-25 17:58:13.637352
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert test_case_0() == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    type=AuthPluginAliasValidator(),
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicitly specify a custom auth type to be used.
    Only applicable when --auth is set.

    The following built-in auth types are available:

    {plugin_manager.get_auth_plugin_mapping_as_string()}

    There are also {len(plugin_manager.get_auth_plugin_mapping())} third-party
    auth plugins that you can install and use.

    '''
)

# Generated at 2022-06-25 17:58:15.096545
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:58:23.975351
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices.__contains__('JWTAuthPlugin')
    assert auth_type_lazy_choices.__contains__('DigestAuth')
    assert auth_type_lazy_choices.__contains__('BasicAuth')
    assert auth_type_lazy_choices.__contains__('AWSAuthPlugin')
    assert auth_type_lazy_choices.__contains__('AWS4AuthPlugin')
    assert auth_type_lazy_choices.__contains__('AWS4AuthPlugin')
    assert auth_type_lazy_choices.__contains__('AWSAuthPlugin')



# Generated at 2022-06-25 17:58:35.022240
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert var_0.__class__.__name__ == 'list_iterator'


auth.add_argument(
    '--auth-type',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to use.
    By default, the built-ins {0} are supported.

    '''.format(', '.join(sorted(DEFAULT_AUTH_PLUGINS)))
)

# Generated at 2022-06-25 17:58:37.130801
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert str(type(_AuthTypeLazyChoices())) == "<class 'httpie.cli._AuthTypeLazyChoices'>"

# Generated at 2022-06-25 17:58:42.819345
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = iter(auth_type_lazy_choices_0)
    assert isinstance(var_0, Iterator) == True and var_0 != True
    try:
        var_0.__next__()
    except StopIteration:
        raise AssertionError

# Generated at 2022-06-25 17:58:51.206828
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        var_0 = auth_type_lazy_choices_0.__iter__()
        # compare the type and value of constructor
        if type(var_0) != list:
            raise Exception("test Failed")
    except Exception as exception_instance:
        raise AssertionError("test Failed")



# Generated at 2022-06-25 17:58:52.904319
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__("Basic") == True


# Generated at 2022-06-25 17:59:10.512363
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 17:59:20.778624
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()
    var_0 = _AuthTypeLazyChoices.__iter__(_AuthTypeLazyChoices())
    var_1 = _AuthTypeLazyChoices.__iter__(_AuthTypeLazyChoices())
    assert var_0 == var_1


auth.add_argument(
    '--auth-type',
    default=HTTPBasicAuthPlugin.name,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of an auth plugin to use. To see a list of supported
    auth plugins run "{HELP_DOC_URL}plugins".

    The default is "{HTTPBasicAuthPlugin.name}", which is the
    standard HTTP Basic authentication.

    '''
)

# Arguments to be passed to the auth plugin.
#
# They must not conflict with any

# Generated at 2022-06-25 17:59:30.863019
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except Exception:
        print_exc()
        assert False

    expected_value_0 = 'assword'
    actual_value_0 = ''
    actual_value_0 = plugin_manager.get_auth_plugin_mapping().keys()
    actual_value_0 = str(actual_value_0)
    actual_value_0 = actual_value_0[actual_value_0.find('auth_type_lazy_choices_0.__iter__'):]
    assert expected_value_0 == actual_value_0


auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:59:41.953906
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert plugin_manager.get_auth_plugin_mapping()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin.
    Available plugins: {auth_plugins}
    '''.format(auth_plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)
auth.add_argument(
    '--auth-plugin', '-A',
    dest='auth_type',
    action='append',
    help=argparse.SUPPRESS
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-25 17:59:51.933448
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert_equal(test_case_0(), None)


# Generated at 2022-06-25 17:59:55.074510
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert type(auth_type_lazy_choices_0) == _AuthTypeLazyChoices



# Generated at 2022-06-25 18:00:06.030949
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (True)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify HTTP authentication type. The default is "basic".
    Plugins may define additional types, so check
    "http --help-auth" for a list of all challenges.

    ''',
)
_auth_plugins = plugin_manager.get_auth_plugin_mapping()
if _auth_plugins:
    help_auth = ''

# Generated at 2022-06-25 18:00:16.797352
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    help='''
    The authentication mechanism to be used. Only useful when the server
    response to an unauthenticated request with a ``401 Unauthorized`` status
    code. Supported authentication mechanisms are ``basic``, ``digest``,
    ``hawk``, and ``aws4``.

    Default is to auto-detect the mechanism from the ``WWW-Authenticate``
    response header.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Resend the initial request without checking for a ``401 Unauthorized``
    response and without prompting for the credentials.

    '''
)

# Generated at 2022-06-25 18:00:24.508276
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

_auth_type_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_auth_type_choices,
    help=plugin_manager.get_auth_plugin_help
)

auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    help='''
    Disable HTTP authentication challenge. The server must send the
    authentication information without asking for it.

    '''
)

# Generated at 2022-06-25 18:00:35.878119
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:01:15.554386
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    print('TEST _AuthTypeLazyChoices: ALL CASES PASSED!!!')


# Generated at 2022-06-25 18:01:16.569794
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:01:19.055066
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__(None) == True


# Generated at 2022-06-25 18:01:28.850824
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Iterator assignment guard
    var_0 = auth_type_lazy_choices_0.__iter__()
    # Iterator assignment guard
    var_1 = auth_type_lazy_choices_0.__iter__()
    # Iterator assignment guard
    var_0 = auth_type_lazy_choices_0.__iter__()
    # AssertionError
    assert list(var_0) == ['digest', 'hawk', 'multi_key', 'ntlm', 'oauth1', 'passwd', 'prompt',
                           'unix', 'wincred', 'wrap']

# Generated at 2022-06-25 18:01:40.739806
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication method to be used. Possible values are (case-insensitive):

        {', '.join(list(plugin_manager.get_auth_plugin_mapping()))}

    The default is "basic".

    ''',
)


# Generated at 2022-06-25 18:01:47.210946
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(item='digest')
    var_1 = auth_type_lazy_choices_0.__contains__(item='gssnegotiate')
    var_2 = auth_type_lazy_choices_0.__contains__(item='aws')


# Generated at 2022-06-25 18:01:53.869562
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Constructing object of type _AuthTypeLazyChoices
    var_1 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom HTTP authentication type. If not provided,
    the auth type is sniffed from the provided credentials.

    Choices:

        {plugin_manager.get_auth_plugin_help(format=AuthPluginHelpFormat.CHOICES)}

    '''
)

# Generated at 2022-06-25 18:02:05.820254
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    if False:
        raise Exception()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an overriding authentication plugin. The default automatic choice is
    ``{AUTH_PLUGIN_AUTO}``.

    Available plugins:

    {auth_plugins_doc}

    '''
)

# Generated at 2022-06-25 18:02:08.435482
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert_raises_regex(
        NotImplementedError,
        '__init__() has not been implemented.',
        _AuthTypeLazyChoices,
    )


# Generated at 2022-06-25 18:02:10.100863
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__contains__('basic')


# Generated at 2022-06-25 18:03:33.032044
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0() == None

basic_choices_0 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=basic_choices_0,
    help='''
    Auth plugin to use. Default: "basic".
    See the docs for more info: https://httpie.org/plugins

    ''',
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-25 18:03:38.582866
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__contains__('basic')

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an authentication plugin.

    Plugins provided with HTTPie:

        {format_list(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')
proxy.add_argument(
    '--proxy',
    help='''
    Specify a proxy in the form [user:passwd@]proxy.server:port.

    '''
)

# Generated at 2022-06-25 18:03:48.292908
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices___contains___0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices___contains___0.__contains__(1)


# Generated at 2022-06-25 18:03:49.719321
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

# ----------------------------------------------------------------------------


# Generated at 2022-06-25 18:03:52.403613
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    variable_0 = _AuthTypeLazyChoices()
    variable_1 = variable_0.__contains__(None)
    assert variable_1 == False


# Generated at 2022-06-25 18:03:53.155733
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0()


# Generated at 2022-06-25 18:03:58.854653
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

    var_0_is_class_instance = isinstance(var_0, _AuthTypeLazyChoices)
    if var_0_is_class_instance:
        # [4/4]
        var_0_is_class_instance = (
            # [4/4]
            var_0.__iter__()
        )
    # [4/4]



# Generated at 2022-06-25 18:03:59.871234
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:04:04.836352
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices___contains___object = _AuthTypeLazyChoices()
    _AuthTypeLazyChoices___contains___item = None
    _AuthTypeLazyChoices___contains___var_0 = _AuthTypeLazyChoices___contains___object.__contains__(_AuthTypeLazyChoices___contains___item)


# Generated at 2022-06-25 18:04:13.150228
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Test __iter__ method of class _AuthTypeLazyChoices"""
    # No exception thrown
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)

    # No exception thrown
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Custom authentication method.

    The special value `auto' is used to automatically detect the auth type.
    It is the default.

    ''',
)