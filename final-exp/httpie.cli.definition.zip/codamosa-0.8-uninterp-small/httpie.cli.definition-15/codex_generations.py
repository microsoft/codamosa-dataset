

# Generated at 2022-06-25 17:54:40.859548
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices__contains___0 = _AuthTypeLazyChoices()
    _AuthTypeLazyChoices__contains___0.__contains__('molt')
    _AuthTypeLazyChoices__contains___0.__contains__(None)


# Generated at 2022-06-25 17:54:42.344518
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Case 0
    test_case_0()


# Generated at 2022-06-25 17:54:44.366969
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(auth_type_lazy_choices_0)
    for i in it:
        pass


# Generated at 2022-06-25 17:54:47.533694
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from collections.abc import Iterable
    assert isinstance(_AuthTypeLazyChoices(), Iterable), \
        'Class _AuthTypeLazyChoices is not Iterable. dx'

# # Unit test for method __contains__ of class _AuthTypeLazyChoices

# Generated at 2022-06-25 17:54:58.104566
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    test_case_0()

    # Unit test for method __contains__ of class _AuthTypeLazyChoices
    a = _AuthTypeLazyChoices()
    r = a.__contains__(item="")
    expected = ""
    assert r == expected
    print("Method __contains__ of class _AuthTypeLazyChoices works as expected.")

    # Unit test for method __iter__ of class _AuthTypeLazyChoices
    a = _AuthTypeLazyChoices()
    r = a.__iter__()
    expected = ""
    assert r == expected
    print("Method __iter__ of class _AuthTypeLazyChoices works as expected.")

test__AuthTypeLazyChoices()




# Generated at 2022-06-25 17:55:00.716209
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert __is_iterator(auth_type_lazy_choices_0.__iter__())


# Generated at 2022-06-25 17:55:04.338942
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    # __iter__ of _AuthTypeLazyChoices
    assert list(obj) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:55:09.451044
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    iterator = auth_type_lazy_choices_0.__iter__()
    x = iterator.__next__()
    while True:
        try:
            x = iterator.__next__()
        except StopIteration:
            break


# Generated at 2022-06-25 17:55:11.126855
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    res = obj.__iter__()
    assert isinstance(res, collections.abc.Iterator)
    assert list(res) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:55:20.580292
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from HTTPie.context import Environment

    env = Environment(
        stdin=io.StringIO,
        stdout=io.StringIO,
        stderr=io.StringIO,
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        stdout_override=io.StringIO,
        stdin_override=io.StringIO,
        stderr_override=io.StringIO,
        stdin_encoding='utf8',
        stdout_encoding='utf8',
        stderr_encoding='utf8'
    )
    expected = {'digest', 'hawk', 'basic'}
    assert expected == set(env.auth_plugin_manager.get_auth_plugin_mapping())

auth

# Generated at 2022-06-25 17:55:26.004140
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins.builtin import BasicAuthPlugin
    from inspect import isfunction
    assert isfunction(BasicAuthPlugin.authenticate)

# Generated at 2022-06-25 17:55:30.919330
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'foo' in auth_type_lazy_choices_0
    assert 'HttpNtlmAuth' in auth_type_lazy_choices_0
    assert 'HttpNtlmAuth' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:34.642330
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for var_1 in auth_type_lazy_choices_0:
        var_1
    return None


# Generated at 2022-06-25 17:55:35.651569
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass


# Generated at 2022-06-25 17:55:36.738171
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass


# Generated at 2022-06-25 17:55:48.716961
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'Basic' in auth_type_lazy_choices_0
    assert 'Digest' in auth_type_lazy_choices_0
    assert 'Hawk' in auth_type_lazy_choices_0
    assert 'Bearer' in auth_type_lazy_choices_0

# We do this to be able to test the help text.
auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:51.767916
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Test with basic class __contains__
     assert 'basic' in _AuthTypeLazyChoices()
    

# Generated at 2022-06-25 17:55:55.047931
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    sizeof_fmt(auth_type_lazy_choices_0.__iter__())


# Generated at 2022-06-25 17:55:56.422300
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('basic' in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:56:04.009834
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. This can be either "basic",
    "digest", "jwt", "hawk", "ntlm", "oauth1" or "auto".

    The "auto" option (default) will choose the mechanism based on the
    "Authorization" header present in the request. If there are no credentials,
    or if the "Authorization" header is missing, "basic" authentication is used.

    '''
)

# Generated at 2022-06-25 17:56:18.795799
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    @auth_plugin_manager.register_auth_plugin
    def foo(): pass
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_0()
    assert foo in auth_type_lazy_choices_0



# Generated at 2022-06-25 17:56:20.891971
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__iter__()


# Generated at 2022-06-25 17:56:27.330754
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except TypeError as e:
        print('TypeError:', e)

test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=('''
The authentication mechanism to be used. If not specified, an intelligent
guess based on the provided credentials is made. Available mechanisms are:

    ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-25 17:56:28.324624
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()



# Generated at 2022-06-25 17:56:41.451597
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:56:43.041650
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test__AuthTypeLazyChoices_0()
    test__AuthTypeLazyChoices_1()


# Generated at 2022-06-25 17:56:46.080623
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    for var_1 in var_0:
        print(var_1)


# Generated at 2022-06-25 17:56:48.451894
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert_equals(True, auth_type_lazy_choices_0.__contains__('123'))


# Generated at 2022-06-25 17:57:02.248839
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(1)


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to use for a request.
    This can be used in conjunction with or instead of --auth.

    '''
)
auth.add_argument(
    '--auth-type=basic',
    action='append_const',
    const='basic',
    dest='auth_types',
    help='''
    Force the use of the HTTP Basic Authentication.
    This is useful when the server requires credentials to view the
    resource, but does not advertise this fact.

    '''
)


# Generated at 2022-06-25 17:57:11.405373
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Type of HTTP authentication to use (default is "auto"). There are 3 types:

    - "basic" for HTTP Basic Authentication,
    - "digest" for Digest Authentication,
    - "jwt" for JWT Authentication,
    - "auto" to let HTTPie decide (default).

    There could be others depending on the plugins installed
    (see https://httpie.org/plugins).

    Note: depending on the server, "auto" may still result in using "basic"
    or "digest".

    ''',
)

#######################################################################
# Connection Options
#######################################################################


# Generated at 2022-06-25 17:57:22.560936
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('super')


# Generated at 2022-06-25 17:57:34.329468
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        auth_type_lazy_choices_0.__iter__()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 17:57:46.318515
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # No arguments
    # Runs __init__()
    _AuthTypeLazyChoices()

    # Following runs __contains__(), __iter__(), __contains__()
    test_case_0()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force the authentication mechanism. Default: "auto" to let HTTPie figure it
    out.

    Available: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-25 17:57:56.578897
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'digest'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    if (var_0 is True):
        test_case_0()


# Generated at 2022-06-25 17:57:57.454124
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0()


# Generated at 2022-06-25 17:57:59.055786
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert sys.getsizeof(_AuthTypeLazyChoices()) == 56




# Generated at 2022-06-25 17:58:11.932995
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:58:12.926778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:58:17.334400
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    try:
        var_1 = auth_type_lazy_choices_1.__contains__(item='item_var_1')
    except AttributeError:
        print('Expected AttributeError')


# Generated at 2022-06-25 17:58:25.509561
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except TypeError:
        print('Failed')

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=(plugin_manager.get_auth_plugin_mapping().keys()),
    default=None,
    help='''
        Specify a custom authentication plugin to use, if the one inferred
        from the --auth option is not appropriate.

        Available plugins: {0}

        Plugins can be installed in the same manner as other HTTPie plugins.

        '''.format(
        ', '.join(sorted(auth_type_lazy_choices))
    )
)


# Generated at 2022-06-25 17:58:43.879056
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    r = auth_type_lazy_choices.__iter__()
    assert r == ['basic', 'digest', 'hawk', 'hmac']


# Generated at 2022-06-25 17:58:52.032544
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:54.363393
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(1)


# Generated at 2022-06-25 17:59:04.951771
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices.__iter__()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    # Choices dynamically loaded from plugins.
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. Can be a name of a built-in or a plugin.

    These are built-in:

        {", ".join(sorted(BUILTIN_AUTH_PLUGIN_NAMES))}

    See `http --debug --help` to see all installed plugins.

    '''
)

# Generated at 2022-06-25 17:59:07.884109
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0, _AuthTypeLazyChoices)


# Generated at 2022-06-25 17:59:13.980325
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        _AuthTypeLazyChoices_0 = _AuthTypeLazyChoices()
        var_0 = _AuthTypeLazyChoices_0.__iter__()
        return var_0
    except Exception as e:
        print(str(e))
        sys.exit(1)


# Generated at 2022-06-25 17:59:24.027040
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    The default is to auto-detect the auth mechanism based on the provided
    credentials and the HTTP auth realm (if any).

    ''',
)

#######################################################################
# HTTP verb
#######################################################################

method = parser.add_argument_group(title='HTTP verb')
method.add_argument(
    '--method', '-m',
    metavar='VERB',
    default='GET',
    help='''
    Specify the HTTP verb (GET, POST, PUT, DELETE, etc). By default, GET
    is used.

    '''
)

# Generated at 2022-06-25 17:59:27.302584
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:59:29.459044
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("")


# Generated at 2022-06-25 17:59:32.526393
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('http')


# Generated at 2022-06-25 18:00:11.335813
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    dest='auth_plugin_name',
    metavar='AUTH_TYPE',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. This is a shortcut for the following
    plugins:

    {prettify_choices(
        plugin_manager.get_auth_plugin_mapping(),
        bullet='*',
        indent=8
    )}

    Each plugin may provide additional options. Use `--auth-type=<plugin-name>
    --help` to learn about them.

    '''
)

# Generated at 2022-06-25 18:00:12.296275
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:00:15.736518
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(None)


# Generated at 2022-06-25 18:00:23.855688
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)

    assert 'Basic' in auth_type_lazy_choices
    assert 'Digest' in auth_type_lazy_choices

    var = auth_type_lazy_choices.__iter__()
    assert isinstance(iter(var), iter)



# Generated at 2022-06-25 18:00:28.488871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert len(var_0) == 5


# Generated at 2022-06-25 18:00:38.045994
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # test code here...
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_1.__iter__()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication method. Possible values:

        {TextWrapper(width=79, initial_indent=6 * ' ', subsequent_indent=6 * ' ').fill(
            ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))}

    The default value is "basic" which is equivalent to --auth.
    '''
)


#######################################################################
# HTTP(S) proxy


# Generated at 2022-06-25 18:00:49.256885
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('abc')


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    '''
)

auth.add_argument(
    '--auth-unix-socket',
    default=None,
    help='''
    Use local unix socket for authentication.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-25 18:00:58.936235
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Type of HTTP authentication to use.

    If `--auth' has a value but `--auth-type' isn't set, the default scheme is
    Basic. With Digest, the `--auth' value should be the username only, without
    the password.

    '''
)
auth.add_argument(
    '--auth-from-netrc',
    action='store_true',
    default=False,
    help='''
    Load auth credentials from .netrc.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')


# Generated at 2022-06-25 18:00:59.936889
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert True


# Generated at 2022-06-25 18:01:03.097739
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__contains__('NTLM')
    assert var_1 == False


# Generated at 2022-06-25 18:02:17.483509
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    class_0 = AuthPluginCommand
    var_1 = var_0.__contains__(class_0)


# Generated at 2022-06-25 18:02:19.402837
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj_0 = test_case_0()
    test_obj_0 = obj_0.__contains__('digest')


# Generated at 2022-06-25 18:02:21.965783
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    param_0 = _AuthTypeLazyChoices()
    assert isinstance(param_0, _AuthTypeLazyChoices) == True
    print("Test successful!")

test_case_0()
test__AuthTypeLazyChoices()

# Generated at 2022-06-25 18:02:34.620434
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    Print('Test __iter__')
    test_case_0()
    var_0 = sorted(sorted(plugin_manager.get_auth_plugin_mapping().keys()))



auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Supported mechanisms:

        {plugins_doc}

    '''.format(
        plugins_doc=plugin_manager.get_auth_plugin_help(),
    ).rstrip()
)

# Generated at 2022-06-25 18:02:38.918583
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:02:43.777791
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    
    var_0 = auth_type_lazy_choices_0.__contains__('hello')
    
    var_0 = auth_type_lazy_choices_0.__contains__('hello2')
    assert var_0 == False


# Generated at 2022-06-25 18:02:46.671730
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_0 = auth_type_lazy_choices_0.__contains__('digest')
    assert test_0 == True


# Generated at 2022-06-25 18:02:52.785423
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Imports
    from httpie._compat import is_py2

    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('aws4')
    if var_0:
        var_1 = 'aws4'
    else:
        var_1 = 'aws3'
    assert var_1 in auth_type_lazy_choices_0



# Generated at 2022-06-25 18:02:55.225483
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert (test_case_0())



# Generated at 2022-06-25 18:03:05.307079
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()



auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Tell HTTPie which authentication method to use for the request.
    This option also accepts custom authentication plugins.

    '''
)