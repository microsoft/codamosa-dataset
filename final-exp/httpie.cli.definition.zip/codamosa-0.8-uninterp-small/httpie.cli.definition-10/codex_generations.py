

# Generated at 2022-06-25 17:54:42.105401
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Test Method
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'foo'
    bool_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert bool_0



# Generated at 2022-06-25 17:54:49.986336
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    expected_values = ['basic', 'digest', 'hawk']
    assert list(auth_type_lazy_choices) == expected_values


# Generated at 2022-06-25 17:55:00.682022
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication type to be used with ``--auth``.

    By default, HTTPie would try to detect the auth type from the server
    response. For example, it detects Basic from a 401 response with a Basic
    auth challenge.

    Available types:

        {plugin_doc_strings}

    '''.format(
        plugin_doc_strings='\n        '.join(
            plugin_manager.get_auth_plugin_docstrings()
        )
    )
)

#######################################################################
# Redirects
#######################################################################

redirects = parser.add_argument_group(title='Redirects')
redirects

# Generated at 2022-06-25 17:55:04.339119
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:55:06.295234
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    desc = _AuthTypeLazyChoices()
    assert 'basic' in desc


# Generated at 2022-06-25 17:55:09.889511
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # the constructor of class _AuthTypeLazyChoices must be called with an argument
    try:
        _AuthTypeLazyChoices()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:55:11.382219
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('' in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:13.502865
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    # Test with __iter__: returns iterator
    assert iter(_AuthTypeLazyChoices()) == iter(_AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:24.179374
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # verifications
    assert 'digest' in auth_type_lazy_choices_0
    assert 'Jwt' in auth_type_lazy_choices_0
    assert 'bearer' in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0
    assert 'aws' in auth_type_lazy_choices_0
    assert 'crammd5' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'ntlm' in auth_type_lazy_choices_0



# Generated at 2022-06-25 17:55:26.403221
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:35.899581
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert (callable(plugin_manager.get_auth_plugin_mapping))


test_case_0()
test__AuthTypeLazyChoices()
del test_case_0
del test__AuthTypeLazyChoices

auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:47.885841
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism (named auth plugin) to be used.

    If set to "auto" (the default), HTTPie tries to guess the plugin to use
    from the --auth username and the server's HTTP response.

    Available auth types: {0}

    '''.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping())
    )
)

# Generated at 2022-06-25 17:55:53.782329
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, object)

    # Constructor test
    var_0 = _AuthTypeLazyChoices()
    try:
        var_0.__init__()
    except Exception:
        var_1 = False
    else:
        var_1 = True
    finally:
        assert var_1


# Generated at 2022-06-25 17:55:57.345152
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__contains__('')
    assert var_1 == True


# Generated at 2022-06-25 17:56:04.415329
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # FIXME: the class is defined in this function
    # Create object _AuthTypeLazyChoices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Iterate over object _AuthTypeLazyChoices
    for var_0 in auth_type_lazy_choices_0:
        pass



# Generated at 2022-06-25 17:56:06.919338
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:56:10.630507
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("password")


# Generated at 2022-06-25 17:56:11.860864
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:56:21.986479
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism (if the server requires something
    other than the HTTP Basic auth).

    The available auth types are:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys()
            )), 60)
        ).strip(),
    )
)

#######################################################################
# Query strings
#######################################################################

querystring = parser.add_argument_group(title='Query Strings')

# Generated at 2022-06-25 17:56:24.666359
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    new = auth_type_lazy_choices_0.__contains__
    var_0 = new('md5')


# Generated at 2022-06-25 17:56:41.933933
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__iter__() == sorted(plugin_manager.get_auth_plugin_mapping().keys()), 'assert auth_type_lazy_choices_0.__iter__() == sorted(plugin_manager.get_auth_plugin_mapping().keys())'



# Generated at 2022-06-25 17:56:48.093116
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 = _AuthTypeLazyChoices()
    var_0.__iter__()
    assert True


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to use. It can be one of:

    {auth_types}

    Use the `http --auth-type=plugin-name --help` command to get help for
    the plugin.

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(4 * ' ', auth_type.strip())
            for auth_type in plugin_manager.get_auth_plugin_help_as_lines()
        ).strip()
    )
)


# Generated at 2022-06-25 17:57:01.813350
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    type=str,
    default=None,
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin.

    To see a list of available plugins, run:

        $ http --debug

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use credentials for HTTP authentication from the user's
    ~/.netrc file.

    '''
)

# Generated at 2022-06-25 17:57:11.067815
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Note that the auto value is equivalent to the default in requests, which is
    basic.

    '''
)

#######################################################################
# Components filtering
#######################################################################

components = parser.add_argument_group(title='Components filtering')

components.add_argument(
    '--ignore-stdin',
    action='store_true',
    default=False,
    help='''
    Skip stdin. For example, you can now use shell pipes with HTTPie.

    '''
)

#######################################################################
# Non-standard HTTP features
#######################################################################


# Generated at 2022-06-25 17:57:12.100954
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:57:25.319555
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

if __name__ == "__main__":
    test__AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Which authentication scheme to use. By default,
    the authentication scheme used is the one specified
    in the URL, or auto-detected from the .netrc file.
    Otherwise, to pick a custom scheme,
    the following are the available options:

        ''' + textwrap.dedent(', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )).strip()
)


# Generated at 2022-06-25 17:57:36.078218
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("a")
    assert var_0 == False, "expected False, got {}".format(var_0)

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use. By default, it's guessed from the --auth
    option value, or auto-detected based on the server response.

    '''
)



# Generated at 2022-06-25 17:57:40.272362
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        assert (not (iter(auth_type_lazy_choices_0) is None))
    except AssertionError as e:
        raise


# Generated at 2022-06-25 17:57:52.513352
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = None
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        var_0 = auth_type_lazy_choices_0.__iter__()
    finally:
        if auth_type_lazy_choices_0:
            auth_type_lazy_choices_0.dispose()


# Generated at 2022-06-25 17:58:00.944379
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Test of negative result as the result of iterable.
    var_0 = None
    auth_type_lazy_choices_iter_0 = auth_type_lazy_choices_0.__iter__()
    if auth_type_lazy_choices_iter_0.__next__() not in auth_type_lazy_choices_iter_0:
        var_0 = False
    assert not var_0

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    '''
)

# Generated at 2022-06-25 17:58:09.843565
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True


# Generated at 2022-06-25 17:58:11.297403
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass


# Generated at 2022-06-25 17:58:21.194157
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_1 = 'a'
    var_2 = var_1.join('')
    var_3 = var_2.join('b')
    var_4 = var_3.join('c')
    var_5 = var_4.join('')
    var_6 = 'b'
    var_7 = var_6.join('a')
    var_8 = var_7.join('')
    var_9 = var_8.join('c')
    var_10 = var_9.join('')
    var_11 = 'c'
    var_12 = var_11.join('a')
    var_13 = var_12.join('b')
    var_14 = var_13.join('')
    var_15 = None

# Generated at 2022-06-25 17:58:26.324268
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    try:
        _AuthTypeLazyChoices()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 17:58:28.194932
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Case 0
    test_case_0()



# Generated at 2022-06-25 17:58:33.608189
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert_true(auth_type_lazy_choices_0.__contains__('basic'))
    assert_true(auth_type_lazy_choices_0.__contains__('digest'))
    assert_true(auth_type_lazy_choices_0.__contains__('awsv4'))


# Generated at 2022-06-25 17:58:36.385454
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('a')
    assert var_0 == False


# Generated at 2022-06-25 17:58:46.951594
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')

auth.add_argument(
    '--auth-type',
    # This helps sphinx generate the available auth types.
    choices=_AuthTypeLazyChoices(),
    help='''
    Type of authentication to perform for an HTTP request.
    If not set the default is to use Basic authentication.
    Basic, Digest, and Hawk are always available.
    Plugins provide additional types.

    '''
)

# TODO: Make this read-only once it is generated.

# Generated at 2022-06-25 17:58:55.665871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Test with an empty list of choices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Test with a non empty list of choices
    var_0 = auth_type_lazy_choices_0.__iter__()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Test with a non empty list of choices
    var_1 = auth_type_lazy_choices_0.__iter__()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=('The auth mechanism to be used.')
)

# Generated at 2022-06-25 17:58:58.433674
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_0.__contains__('Basic')


# Generated at 2022-06-25 17:59:22.953776
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the credential used to authenticate requests.
    Only relevant when --auth is used.

    '''
)

#######################################################################
# HTTPie plugins.
#######################################################################

# Register command-line options for all plugins.
plugin_manager.discover_and_load_plugins()
parser.add_argument_group(title='Plugin options')
plugin_manager.register_command_line_options(parser)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-25 17:59:30.311123
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Used to specify the authentication mechanism.
    The default, "auto", will attempt to auto-detect the auth mechanism based on
    the response from the server and will fall back to digest auth, if
    necessary. Other values include "basic" and "digest".

    '''
)
auth.add_argument(
    '--auth-plugin',
    metavar='AUTH_PLUGIN_NAME',
    help=argparse.SUPPRESS
)

# Generated at 2022-06-25 17:59:34.288565
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not ('digest' in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:59:38.663067
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('--auth-type')

auth_type = auth.add_mutually_exclusive_group(required=False)
auth_type.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not specified, HTTPie
    attempts to guess it based on the --auth option value.
    Plugins can add custom auth types, see:

    https://github.com/jakubroztocil/httpie#plugins

    '''
)


#######################################################################
# High level request options.
#######################################################################

http

# Generated at 2022-06-25 17:59:42.463265
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print('Testing __iter__ of class _AuthTypeLazyChoices')
    test_case_0()
    print('Done!')


# Generated at 2022-06-25 17:59:44.722052
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 17:59:53.154841
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(test_case_0()) == []

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism and, optionally,
    the the plugin that implements it.

    Available mechanisms (plugins):

        {plugin_manager.get_auth_plugin_help()}

    By default, the plugin is guessed from --auth username,
    or from the URL hostname.

    To force guessing, use {EXPLICIT_AUTH_PLUGIN_ARG_VALUE}.

    ''',
)

# Generated at 2022-06-25 18:00:03.782611
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


"""
auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-type',
    help='''
    The authentication mechanism to be used. Defaults to basic. Available
    choices:

    {auth_types}

    '''.format('\n'.join(
        '{0}{1}'.format(4 * ' ', '{0}: {1}'.format(k, v))
        for k, v in plugin_manager.get_auth_plugin_mapping().items()
    )),
    choices=auth_type_lazy_choices
)
"""


# Generated at 2022-06-25 18:00:11.421578
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert all((ix
        # Iterator over the iterable returned by __iter__ of the object.
        in list(auth_type_lazy_choices_0.__iter__())
        # Builtin iter
        # Iterator over the iterable returned by __iter__ of the object.
        in list(builtins.iter(auth_type_lazy_choices_0))
        for ix in input_0()
    ))

# Generated at 2022-06-25 18:00:21.294572
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("asdf")

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=AUTH_PLUGIN_MAP['basic'].name,
    choices=_AuthTypeLazyChoices(),
    help='''
    Default: basic.

    Use a custom authentication plugin.

    The bundled ones are:

    {auth_plugin_names}

    Third party plugins are discoverable by their entry points (see
    https://packaging.python.org/specifications/entry-points/).

    '''
)

# Generated at 2022-06-25 18:01:05.416586
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'Digest'
    auth_type_lazy_choices_0.__contains__(str_0)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an auth plugin to use. The default is Basic. You can find a list of
    available auth plugins with: http --debug --help

    '''
)
auth.add_argument(
    '--auth-type-help',
    default=None,
    help='''
    Print help for the specified auth plugin and exit.

    '''
)


# Generated at 2022-06-25 18:01:16.377900
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    with raises(TypeError):
        var_1 = next(var_0)
    try:
        var_2 = next(var_0)
    except StopIteration:
        assert False
    try:
        var_3 = next(var_0)
    except StopIteration:
        assert False
    try:
        var_4 = next(var_0)
    except StopIteration:
        assert False
    try:
        var_5 = next(var_0)
    except StopIteration:
        assert False
    try:
        var_6 = next(var_0)
    except StopIteration:
        assert False


# Generated at 2022-06-25 18:01:20.940843
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')


# Generated at 2022-06-25 18:01:29.485868
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0, _AuthTypeLazyChoices)

    # <listcomp> terminated but not consumed

    # <listcomp> terminated but not consumed

auth_type = auth.add_argument(
    '--auth-type',
    default=None,
    help='Force the specified authentication method.',
    choices=_AuthTypeLazyChoices(),
    # choices=lambda: sorted(
    #    plugin_manager.get_auth_plugin_mapping().keys()
    # ),
    metavar='{0}'.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    )
)

#######################################################################
# Timeouts


# Generated at 2022-06-25 18:01:41.449709
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    assert var_0, 'Expected var_0 to be true but was %s' % var_0


# Generated at 2022-06-25 18:01:46.391580
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    from itertools import chain
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = chain(auth_type_lazy_choices_0.__iter__())
    print(var_0)
    print(auth_type_lazy_choices_0)


# Generated at 2022-06-25 18:01:53.241146
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_1 = _AuthTypeLazyChoices()
    var_2 = {
        'digest', 'gssnegotiate', 'hawk', 'ntlm', 'oauth1'
    }.__iter__()
    pass

auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication plugin to use.

    Currently supported plugins:

        {auth_type_choices}

    The default is "basic".

    '''.format(
        auth_type_choices='\n        '.join(sorted(
            plugin_manager.get_auth_plugin_mapping().keys()))
    )
)



# Generated at 2022-06-25 18:02:05.190064
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    type_case_0 = test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    Currently supported: {0}.

    The "auto" value automatically detects the authentication mechanism
    based on the supplied credentials.

    '''.format(
        ', '.join(sorted(
            plugin_manager.get_auth_plugin_mapping()
        )))
)

# Generated at 2022-06-25 18:02:13.448602
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    expect_0 = 'HTTPBasicAuth'
    actual_0 = test_case_0()
    assert expect_0 in actual_0


auth.add_argument(
    '--auth-type',
    default=None,
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    help='''
    Force the HTTP Authentication mechanism.
    By default, HTTPie tries to determine Auth type automatically.
    Possible values:

        'basic' Basic HTTP Auth, provided in the URL (deprecated)
        'digest' Digest HTTP Auth
        'jwt' JSON Web Token Auth

    The auth plugin can be also specified by prefixing the username
    with the plugin name and the colon character. For example:

        jwt:<token>

    '''
)
auth.add_argument

# Generated at 2022-06-25 18:02:22.527002
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Explicitly specify an auth type for HTTPie to use. Choices:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)


#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-25 18:03:31.404974
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert True


# Generated at 2022-06-25 18:03:39.268262
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(0)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Type of authentication plugin to use. Currently supported:

        {', '.join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

# Generated at 2022-06-25 18:03:49.463307
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from hypothesis import given
    from hypothesis.strategies import sampled_from, text
    from hypothesis import settings
    settings.max_examples = 10

# Generated at 2022-06-25 18:03:52.995074
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert "Negotiate" in auth_type_lazy_choices_0
    assert None is not auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 18:04:01.005613
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert_equal(isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices), True)

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=auth_type_lazy_choices,
    help='''
    The authentication mechanism to be used.
    HTTPie supports several authentication mechanisms out of the box:

        basic, digest, aws

    Note that, unless stated otherwise, all mechanisms expect the credentials
    to be provided using --auth.

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 18:04:10.354997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the auth mechanism to use.

    There are two built-in mechanisms:

        auto               (default)

            Automatic detection of basic and digest auth. Use the WWW-
            Authenticate response header to decide which method to use.

        basic

            HTTP Basic Auth.

    Additionally, there may be auth plugins available. Use the --plugins
    option to see all plugins and their names.

    Example: http --auth-type=digest -a alice:secret https://example.org/

    ''',
)


# Generated at 2022-06-25 18:04:19.132684
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__iter__()

auth.add_argument(
    '--auth-type',
    metavar='[{0}]'.format('|'.join(
        plugin_manager.get_auth_plugin_mapping().keys()
    )).upper(),
    type=str.upper,
    default=None,
    help='Type of redirects to follow.',
)

###########################################################################
# Response info
###########################################################################
response_info = parser.add_argument_group(title='Response info')

# Generated at 2022-06-25 18:04:25.936039
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    test_case_1()

auth_type_lazy_choices = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type', '-t',
    choices=auth_type_lazy_choices,
    help=f'''
    Select the authentication mechanism.
    The default is "basic", other options are:

        {", ".join(plugin_manager.get_auth_plugin_mapping().keys())}

    '''
)

#######################################################################
# HTTP and HTTPS
#######################################################################

http = parser.add_argument_group(title='HTTP(S) Options')

# Generated at 2022-06-25 18:04:32.102784
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()
    test_case_1()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Manual override of the automatic detection of the auth type to be used
    (see the Github issues #51, #63, and #125 for details).

    Available auth types:
    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-25 18:04:33.289014
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()
