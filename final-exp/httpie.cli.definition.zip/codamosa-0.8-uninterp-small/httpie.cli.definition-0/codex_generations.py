

# Generated at 2022-06-25 17:54:41.872656
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for item in ['SASL', 'Basic', 'Digest', 'AWS4-HMAC-SHA256', 'Custom']:
        assert item in _AuthTypeLazyChoices()



# Generated at 2022-06-25 17:54:43.617860
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert isinstance(_AuthTypeLazyChoices().__contains__(chr(64)), bool)


# Generated at 2022-06-25 17:54:45.094882
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:54:51.865701
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert set(test_case_0.auth_type_lazy_choices_0) == {'basic', 'digest'}

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of the auth plugin that should be used to generate the
    Authorization header. Choices: {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:54:55.482419
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(auth_type_lazy_choices_0))[0] == 'awscurl'


# Generated at 2022-06-25 17:54:57.798891
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'aws' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:54:59.680476
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert type(next(iter(auth_type_lazy_choices_0))) is str


# Generated at 2022-06-25 17:55:11.283874
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert('WWW-Authenticate' in _AuthTypeLazyChoices())
    assert('NTLM' in _AuthTypeLazyChoices())
    assert(len(_AuthTypeLazyChoices()) == 8)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use a custom authentication type. By default, authentication is inferred
    from the Authorization header. There are some preconfigured default
    authentication types:

    {captured}

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use the netrc file for user-pass credential lookup.

    '''
)

#######################################################################
# HTTP
################################

# Generated at 2022-06-25 17:55:12.686905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:18.114699
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # assert that built in plugin 'DigestAuth' exist in choices
    assert 'DigestAuth' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:30.918795
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(list(iter(auth_type_lazy_choices_0)), list)

auth_type = auth.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-25 17:55:33.089280
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = list(auth_type_lazy_choices_0)
    # Assert length of items is not 0
    assert len(items) != 0


# Generated at 2022-06-25 17:55:38.157673
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    res_0 = next(iter(auth_type_lazy_choices_0))
    assert (res_0 == 'basic')
    res_1 = all(iter(auth_type_lazy_choices_0))
    assert (res_1 == True)


# Generated at 2022-06-25 17:55:50.483247
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from pytest import raises
    from hypothesis import given
    from hypothesis.strategies import lists, integers
    from hypothesis.strategies import builds

    @given(lists(integers(min_value=1), min_size=1).map(sorted).map(tuple))
    def test_0(x):
        class Foo0:
            def __iter__(this):
                yield from x
        with raises(TypeError):
            foo0 = Foo0()
            foo0_instance = _AuthTypeLazyChoices()
            foo0_instance.__iter__()
    @given(lists(integers(min_value=1), min_size=1).map(sorted).map(tuple))
    def test_1(x):
        class Foo1:
            def __iter__(this):
                yield from x


# Generated at 2022-06-25 17:55:53.780551
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__contains__("^C")


# Generated at 2022-06-25 17:55:55.400782
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not 'null' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:56:03.428485
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0
    assert 'plugin_name' in auth_type_lazy_choices_0

_default_auth_type = 'basic'


# Generated at 2022-06-25 17:56:05.844366
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    a = _AuthTypeLazyChoices()
    assert 'basic' in a


# Generated at 2022-06-25 17:56:09.297871
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # self.assertTrue("AWS4-HMAC-SHA256" in _AuthTypeLazyChoices())
    assert "AWS4-HMAC-SHA256" in _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:56:12.401533
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(auth_type_lazy_choices_0)) == ['digest', 'jwt', 'multipart', 'netrc']

# Generated at 2022-06-25 17:56:15.491010
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:56:17.188099
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    global var_0, var_1
    var_0 = True
    var_1 = False


# Generated at 2022-06-25 17:56:25.506166
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test Exception #0
    try:
        test_case_0()
    except:
        raise Exception

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Auth plugin to use.

    Currently available plugins:
        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}.

    To install additional plugins, use:

        $ {PIP} install httpie-{plugin_manager.plugin_prefix}PLUGIN_NAME

    '''
)


#######################################################################
# Miscellanous
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous')


# Generated at 2022-06-25 17:56:39.453692
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    set_0 = set()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()

# Generated at 2022-06-25 17:56:41.047483
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    if ENABLED:
        test_case_0()


# Generated at 2022-06-25 17:56:47.158304
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
# Adding new class

# Generated at 2022-06-25 17:56:54.736824
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    set_0 = set()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__contains__(set_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1.__contains__(set_0)


# Generated at 2022-06-25 17:57:06.120958
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'W#q3m'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    set_1 = set()
    iter_0 = auth_type_lazy_choices_2.__iter__(set_1)
    auth_type_lazy_choices_3 = _AuthTypeLazyChoices()
    str

# Generated at 2022-06-25 17:57:14.458679
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom HTTP authentication plugin.

    Plugins are registered via entry points in pyhton's `entry_points` in the
    `httpie.plugins.auth` namespace.

    '''
)

#######################################################################
# Configuration
#######################################################################

config = parser.add_argument_group(title='Configuration')

# Generated at 2022-06-25 17:57:23.673880
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Call constructor: test_case_0
    test_case_0()
    pass

# Call function: test__AuthTypeLazyChoices
test__AuthTypeLazyChoices()

# ``auth`` should be a mutually exclusive group with ``auth-type``,
# but that didn't work well with argparse, so we do it manually.
#
# https://github.com/psf/requests/blob/master/requests/auth.py

# Generated at 2022-06-25 17:57:37.341649
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    # Iterator yield
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    generator_0 = auth_type_lazy_choices_1.__iter__()
    next_1 = next(generator_0)
    set_0 = {' %\\s/E'}
    bool_0 = set_0.__contains__(next_1)
    next_2 = next(generator_0)
    bool_1 = set_0.__contains__(next_2)
    auth_type_lazy_

# Generated at 2022-06-25 17:57:49.714078
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin. Note that AUTH_TYPE_PLUGIN_MAP
    is only populated if HTTPie was installed with plugins. See
    {plugins_doc}
    '''.format(plugins_doc=PLUGINS_DOC)
)

#######################################################################
# Secure HTTPS
#######################################################################

https = parser.add_argument_group(title='Secure HTTPS')

# Generated at 2022-06-25 17:57:50.863055
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:59.916190
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=DEFAULT_AUTH,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default the HTTP basic
    authentication mechanism is used, but the user can specify an alternative
    auth mechanism. Available mechanisms are:

    ''' + '\n    '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 17:58:01.001144
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:13.594821
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    list_0 = list()
    set_0 = set()
    for obj_0 in auth_type_lazy_choices_0.__iter__():
        list_0.append(obj_0)


auth_type_validator = AuthTypeValidator(
    'Auth type must be one of: {}.'.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)


# Generated at 2022-06-25 17:58:23.209782
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

parser.test_plugin_with_test_flag()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='auto|{}'.format('|'.join(_AuthTypeLazyChoices())),
    help='''
    The auth mechanism to be used.  The default, "auto",
    will follow HTTP redirects and pick the appropriate
    auth type (basic, digest or oauth1) for each request.
    ''',
)

auth.add_argument(
    '--auth-type-help',
    dest='auth_type',
    action=_AuthenticationHelpAction,
    nargs=0,
    help='''Show help on available auth types.'''
)


# Generated at 2022-06-25 17:58:34.981453
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Plugin names are case-insensitive.
    Supported built-in types:

        {auth_types}

    '''.format(auth_types='\n        '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())),
    )
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='Do not use HTTP authentication challenge.'
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_

# Generated at 2022-06-25 17:58:35.882051
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:58:41.249079
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:56.946456
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    asdf()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin. To see a list of available authentication
    plugins, run: http --debug | grep "Auth plugin".

    '''
)
auth.add_argument(
    '--auth-endpoint',
    help='''
    Specify an endpoint (URL) to use for Authentication.
    Overrides the default endpoint specified by the plugin.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:58:57.916133
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:59:06.982392
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    int_0 = -41
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    set_0 = set()
    var_0 = auth_type_lazy_choices_0.__contains__(set_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_1 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_1)
    str_0 = '\\/'
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:59:14.174837
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
#
auth.add_argument(
    '--auth-type',
    default=None,
    type=(lambda a_type: a_type.lower()),
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify how requests should be authenticated.
    Available plugins: %s
    ''' % ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
)


auth.add_argument(
    '--auth-pwexpiry',
    default=None,
    type=int,
    help='''
    The number of seconds until auth password expires.
    '''
)

#######################################################################
# SSL
#######################################################################



# Generated at 2022-06-25 17:59:24.191748
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_validator = AuthPluginValidator(
    'Auth plugin "%(value)s" not found.\n\n'
    'Did you mean any of:\n\n'
    '    %(candidates)s\n\n'
    'Available auth plugins:\n\n'
    '    %(available)s\n\n'
    '  Use `--auth-type=list` to list them all.\n'
)


# Generated at 2022-06-25 17:59:30.906015
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_2.__contains__(var_0)
    auth_type_lazy_choices_2.__contains__(var_1)


# Generated at 2022-06-25 17:59:33.527117
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:59:40.438002
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:59:50.607881
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:00:01.059894
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    print('Done!')

# Strings used by the program.

DEFAULT_SESSIONS_DIR = expanduser('~/.httpie')
SESSION_FILE_SUFFIX = '.json'

DEFAULT_STYLE = AUTO_STYLE

# Whether to prettify the output.
#   True: yes, always;
#   False: no, never;
#   None: yes, but only if stdout is a TTY.
PRETTY_STDOUT_TTY_ONLY = None
PRETTY_MAP = {
    'none': None,
    'all': True,
    'colors': True,
    'format': True,
}

# We use a single character as separator because template items
# should not contain any of these.
SEPARATOR_CRED

# Generated at 2022-06-25 18:00:21.588342
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    str_0 = ' %\\s/E'
    var_1 = var_0.__contains__(str_0)
    set_0 = set()
    var_2 = var_0.__contains__(set_0)
    pass


# Generated at 2022-06-25 18:00:34.129649
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a custom auth plugin. The default is to automatically
    detect the auth type from a specified username/password.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

ssl.add_argument(
    '--verify', '-k',
    action='store_false',
    dest='verify',
    help='''
    (default: on).
    Disable SSL certificate verification.
    '''
)


# Generated at 2022-06-25 18:00:41.388023
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# Test class _AuthTypeLazyChoices
test__AuthTypeLazyChoices()

# This is used in add_arguments() to prevent parsing errors and
# to allow our custom actions to process the arguments.
auth.add_argument('--auth-type',
                  action='append_const',
                  dest='auth_type',
                  choices=_AuthTypeLazyChoices())

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-25 18:00:53.604653
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
      test_case_0()
      assert False
    except AssertionError:
      assert True

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=('Use a custom authentication plugin.')
)
auth.add_argument(
    '--proxy-auth',
    default=None,
    metavar='USER[:PASS]',
    help='''
    Specify a username and password for HTTP proxy authentication.
    Like --auth but applies to the proxy instead of the remote host.
    Implies --proxy.

    '''
)

# Generated at 2022-06-25 18:01:03.175292
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Input params
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Output params
    # Output params
    # Output params
    # Expected return value
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    # Expected return value
    assert var_0
    # 2. Assertion error
    # Input params
    set_0 = set()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    # Output params
    # Output params
    # Output params
    # Expected return value
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    # Expected

# Generated at 2022-06-25 18:01:08.086895
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert(var_0 == False)

    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    assert(var_1 == False)


# Generated at 2022-06-25 18:01:12.017025
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 18:01:23.903229
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = '0H %2-ojC'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_2.__iter__()
    auth_type_lazy_choices_3 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:01:31.228913
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

    # Testing for coverage of the _AuthTypeLazyChoices class
    assert plugin_manager.get_auth_plugin_mapping()
    plugin_manager.get_auth_plugin_mapping()
    assert plugin_manager.__init__
    plugin_manager.__init__
    assert test__AuthTypeLazyChoices
    test__AuthTypeLazyChoices()
    # Testing for members of _AuthTypeLazyChoices class
    assert test_case_0
    test_case_0()
    auth_type_lazy_choices_3 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_3.__contains__
    auth_type_lazy_choices_3.__contains__(' %\\s/E')
    assert auth_

# Generated at 2022-06-25 18:01:43.494325
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_2 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_3 = _AuthTypeLazyChoices()
    str_1 = '/E'
    var_3 = auth_type_lazy_choices_3.__contains__(str_1)
    auth_type_lazy_choices_4 = _AuthTypeLazyChoices()
    str_2 = ' %\\s'
    var_4 = auth_type_lazy_choices_4.__contains__(str_2)
    auth_type_lazy_choices_5 = _AuthTypeLazyChoices()
    list_0 = list()
    var_5 = auth_type_lazy_choices_5.__contains__(list_0)


# Generated at 2022-06-25 18:02:28.016635
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert auth_type_lazy_choices_0.__contains__(str_0)
    assert not auth_type_lazy_choices_1.__contains__(set_0)


# Generated at 2022-06-25 18:02:35.854441
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert not var_0
    set_0 = set()
    var_1 = auth_type_lazy_choices_0.__contains__(set_0)
    assert not var_1


# Generated at 2022-06-25 18:02:38.775353
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        import sys
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-25 18:02:39.885243
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:02:44.177252
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Initialize the instance.
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Invoke method.
    var_0 = auth_type_lazy_choices_0.__contains__()
    # Verify the result.
    assert var_0 == None


# Generated at 2022-06-25 18:02:45.178682
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:02:53.807694
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    type=str,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used for authenticating against the
    server. The default is to auto-detect the authentication
    mechanism based on provided credentials.

    The mechanism can be one of the following:

        {0}

    '''.format(
        '\n        '.join(
            '{0!r}'.format(key)
            for key in sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    )
)


# Generated at 2022-06-25 18:02:59.488578
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = ' %\\s/E'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # check if value exists in mapping
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert var_0 == True
    # check if empty value exists in mapping
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    set_0 = set()
    var_1 = auth_type_lazy_choices_1.__contains__(set_0)
    assert var_1 == False
    # check if invalid value exists in mapping (must be only key) 
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    set_1 = set

# Generated at 2022-06-25 18:03:01.269725
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Create an instance of the class under test
    authTypeLazyChoices_0 = _AuthTypeLazyChoices()
    # Call the method under test
    iterator_0 = authTypeLazyChoices_0.__iter__()


# Generated at 2022-06-25 18:03:04.140725
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_1 = _AuthTypeLazyChoices()
    var_2 = var_1.__contains__(var_1)
    var_1 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:04:24.765249
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0() == None


# Generated at 2022-06-25 18:04:25.536762
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:04:27.914533
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'B'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 18:04:33.478140
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. TYPE is one of:

    {auth_plugin_choices}

    '''.format(
        auth_plugin_choices='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(
                plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)


# Generated at 2022-06-25 18:04:37.027807
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert ('\\' in _AuthTypeLazyChoices())
    assert ('s' in _AuthTypeLazyChoices())
    assert (True in _AuthTypeLazyChoices())
