

# Generated at 2022-06-25 17:54:46.648451
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from httpie.plugins import builtin as plugin_builtin
    from httpie.plugins import manager as plugin_manager
    builtin_auth_plugins = plugin_builtin.__all__
    plugin_manager.load_builtin_plugins()
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert sorted(builtin_auth_plugins) == sorted(auth_type_lazy_choices)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specifies the authentication mechanism.

    This is helpful when the server uses a non-standard
    authentication scheme.

    '''
)

# Generated at 2022-06-25 17:54:57.805574
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for __iter__ of class _AuthTypeLazyChoices, using:
        __contains__, __iter__, __main__, __name__, __package__, __spec__, get_auth_plugin_mapping, import_string, is_authenticating_plugin, iter, lazy_auth_types, lazy_auth_types_choices, lazy_choices, lazy_choices_0, lazy_choices_1, plugin_manager, plugin_manager_0, sorted"""
    from . import import_string
    from . import plugin_manager
    from .plugin_manager import is_authenticating_plugin
    from .plugin_manager import plugin_manager_0
    from .plugin_manager import lazy_auth_types
    from .plugin_manager import lazy_auth_types_choices
    from .plugin_manager import lazy_choices

# Generated at 2022-06-25 17:55:04.919946
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    _expected_0 = sorted(plugin_manager.get_auth_plugin_mapping().keys())
    _actual_0 = auth_type_lazy_choices_0.__iter__()
    assert _expected_0 == _actual_0

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified auth plugin.

    Available plugins: {', '.join(_AuthTypeLazyChoices())}

    '''
)

# Generated at 2022-06-25 17:55:07.943377
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for i in auth_type_lazy_choices_0:
        pass


# Generated at 2022-06-25 17:55:18.022970
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an authentication plugin.

    The {default_type} plugin is the default, and is equivalent to the
    --auth option. If a username is provided along with the plugin name
    (e.g. {default_type} -a username), then the password is prompted for.

    '''.format(
        default_type=DEFAULT_AUTH_PLUGIN,
    )
)

#######################################################################
# SSL
#######################################################################
ssl = parser.add_argument_group(title='SSL')


# Generated at 2022-06-25 17:55:20.334873
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices_instance = _AuthTypeLazyChoices()
    assert _AuthTypeLazyChoices_instance.__contains__('basic') == True


# Generated at 2022-06-25 17:55:21.828905
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert any('basic' in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:32.313732
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=AUTH_PLUGIN_MAP['basic'],
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.

    The available auth types are:

    {available_auth_types}

    The default is basic.

    Example:

        --auth-type=digest

    '''
)


#######################################################################
# HTTP Method
#######################################################################

http_method = parser.add_argument_group(title='HTTP Method')

# Generated at 2022-06-25 17:55:44.461758
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_false',
    dest='auth_challenge',
    default=True,
    help='''
    Do not perform a challenge before the main request.

    Some services require authentication to be performed by
    not sending credentials with the request. This option
    allows user to perform authentication separately before
    sending the main request.

    '''
)


# Generated at 2022-06-25 17:55:56.012982
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Test method __iter__ of class _AuthTypeLazyChoices"""
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    test_case_0()
    test_get_auth_plugin_mapping()
    # Case 1 (General Case)
    iter_0 = auth_type_lazy_choices_1.__iter__()
    assert iter_0 != None

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication mechanism; one of:

    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

#######################################################################
# Options common to all plugins


# Generated at 2022-06-25 17:56:06.761032
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    if ("basic" in auth_type_lazy_choices_0):
        pass
    else:
        pass
    if ("digest" in auth_type_lazy_choices_0):
        pass
    else:
        pass
    if ("aws_s3_v4" in auth_type_lazy_choices_0):
        pass
    else:
        pass


# Generated at 2022-06-25 17:56:18.186887
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)
    plugin_manager.load_plugins(
        ENV_PLUGINS=None,
        plugin_dirs=ENV.get('HTTPIE_PLUGIN_DIRS')
    )
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices



# Generated at 2022-06-25 17:56:26.190979
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(plugin_manager.get_auth_plugin_mapping().keys()) == list(_AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type', '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    If no type is provided, an appropriate one is guessed based on the --auth
    option value.

    ''',
)
auth.add_argument(
    '--auth-type=',
    action='append_const',
    const=None,
    dest='auth_plugin_map',
    help='''
    Disable automatic guessing of the authentication mechanism.

    If no type is provided, the request will be sent without authentication

    ''',
)

# Generated at 2022-06-25 17:56:30.885587
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():

    obj = _AuthTypeLazyChoices()

    assert 'basic' in obj
    try:
        assert 'digest' in obj
    except Exception:
        pass
    try:
        assert 'aws' in obj
    except Exception:
        pass


# Generated at 2022-06-25 17:56:34.870198
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices_0) == ['basic', 'digest', 'hawk']


# Generated at 2022-06-25 17:56:45.676096
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_1.__contains__('digest')
    assert 'digest' in auth_type_lazy_choices_1
    assert 'digest' in auth_type_lazy_choices_1
    assert auth_type_lazy_choices_1.__contains__('aws')
    assert auth_type_lazy_choices_1.__contains__('hawk')
    assert auth_type_lazy_choices_1.__contains__('aws')
    assert auth_type_lazy_choices_1.__contains__('aws-s3')



# Generated at 2022-06-25 17:56:58.569686
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Imports
    try:
        from requests.structures import CaseInsensitiveDict
    except ImportError:
        CaseInsensitiveDict = dict





# Generated at 2022-06-25 17:57:08.546013
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication type to be used.
    Available choices depend on what auth plugins are installed.
    The default is 'auto', which means that HTTPie will try to
    detect the appropriate auth type.

    '''
)

# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-host',
    dest='auth_host',
    default=DEFAULT_AUTH_HOST,
    help=f'''
    Host to use for digest and basic authentication.
    Default is {DEFAULT_AUTH_HOST!r}.

    '''
)
#

# Generated at 2022-06-25 17:57:13.931892
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assertion_fails = False
    try:
        assert '--auth-type' in auth_type_lazy_choices_0
    except AssertionError:
        assertion_fails = True
    if assertion_fails:
        raise Exception('Failed test')
    # --auth-type exists in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:26.193731
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__("kerberos") == True
    assert auth_type_lazy_choices_0.__contains__("basic") == True
    assert auth_type_lazy_choices_0.__contains__("digest") == True
    assert auth_type_lazy_choices_0.__contains__("aws") == True
    assert auth_type_lazy_choices_0.__contains__("aws4") == True
    assert auth_type_lazy_choices_0.__contains__("hawk") == True


# Generated at 2022-06-25 17:57:34.307913
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:57:35.950045
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert isinstance(_AuthTypeLazyChoices().__iter__(), types.GeneratorType)


# Generated at 2022-06-25 17:57:48.388048
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(list(_AuthTypeLazyChoices())) > 0

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    HTTPie will try to detect auth types that need special handling,
    such as when using OAuth 1.0a (--auth-type=oauth1) or when sending
    an API key in a custom header (--auth-type=api-key), but you can
    explicitly specify an auth type when needed.

    When "auto" (the default), the auth type is inferred from the URL
    or the provided credentials.

    The available auth types depends on the installed plugins. For more
    information, run:

        $ http --debug

    '''
)

####################################################################

# Generated at 2022-06-25 17:57:53.246217
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
  # See https://github.com/natasha/natasha/blob/master/test/test_test_cases.py
  assert 'Basic' in _AuthTypeLazyChoices()
  assert 'Digest' in _AuthTypeLazyChoices()
  assert 'MyFakeAuthType' not in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:55.167701
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert tuple() == tuple(auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:58:02.621802
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_1.__contains__('basic') == True
    assert auth_type_lazy_choices_1.__contains__('digest') == True
    assert auth_type_lazy_choices_1.__contains__('bearer') == False
    assert auth_type_lazy_choices_1.__contains__('AWS4-HMAC-SHA256') == False
    assert auth_type_lazy_choices_1.__contains__('AWS4-HMAC-SHA256') == False
    assert auth_type_lazy_choices_1.__contains__('http-key') == False
    assert auth_type_lazy_choices_1

# Generated at 2022-06-25 17:58:06.006947
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter___0 = _AuthTypeLazyChoices()
    assert _AuthTypeLazyChoices___iter___0.__iter__() == iter(())


# Generated at 2022-06-25 17:58:12.400700
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    itr = _AuthTypeLazyChoices.__iter__(test_case_0())
    assert next(itr) == 'basic'
    assert next(itr) == 'digest'
    with raises(StopIteration):
        next(itr)
    assert True


# Generated at 2022-06-25 17:58:17.508874
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 17:58:25.632289
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert list(set(_AuthTypeLazyChoices())) ==  list(set(plugin_manager.get_auth_plugin_mapping().keys()))
    assert "auto" in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:43.091420
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'awsv4' in auth_type_lazy_choices


# Generated at 2022-06-25 17:58:51.371261
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in auth_type_lazy_choices_0
    assert 'bearer' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'awsv4' in auth_type_lazy_choices_0
    assert 'awsv4_sigv4' in auth_type_lazy_choices_0

auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:57.989673
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    b = _AuthTypeLazyChoices()
    assert len(a) == len(b)
    assert isinstance(b, _AuthTypeLazyChoices)


auth.add_argument(
    '--auth-type',
    metavar='NAME',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin, bypassing HTTPie's
    builtin Basic, Digest, and WSSE mechanisms.

    Use `http --auth-types' to see a list of all builtin and
    third-party plugins.

    '''
)

auth.add_argument(
    '--auth-types',
    action=AuthTypes,
    nargs=0,
    help=argparse.SUPPRESS
)

#######################################################################

# Generated at 2022-06-25 17:59:02.040954
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices_0) == sorted(
        plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:59:11.726629
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Lazy load choices
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'basic' in _AuthTypeLazyChoices()
    

auth.add_argument(
    '--auth-type',
    default=None,
    # Choices are lazy loaded so that we can test plugins
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. This can be any of:

        {0}

    If the value is not provided and the --auth option is, then HTTPie
    detects the auth mechanism based on the --auth value.

    The --auth-type and --auth options are mutually exclusive.

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

# Generated at 2022-06-25 17:59:15.576524
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert('httpie.plugins.auth.http.HTTPBasicAuthPlugin' in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:59:25.422351
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    Method: __iter__
    Test: __iter__
    Test Data Type: str
    Test Data Value: 'Basic'
    Test Data Type: str
    Test Data Value: 'Digest'
    Test Data Type: str
    Test Data Value: 'Bearer'
    Test Data Type: str
    Test Data Value: 'AWS4-HMAC-SHA256'
    Test Data Type: str
    Test Data Value: 'AWS4-Signature'
    Test Data Type: str
    Test Data Value: 'Hawk'
    Test Data Type: str
    Test Data Value: 'Netrc'
    """
    obj = _AuthTypeLazyChoices()
    """
    Test: str
    Test Data Type: str
    Test Data Value: 'Basic'
    """
    obj_str = str(obj)
   

# Generated at 2022-06-25 17:59:31.577477
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices_0) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:59:42.404576
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for item in (iter(lambda: {'foo', 'bar', 'baz'})):
        assert item in ('foo', 'bar', 'baz')

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.

    Defaults to "basic", and is inferred from --auth option by default.
    It is only needed to be used explicitly when you want to override this
    default.

    The following are the built-in types:

    {builtin_auth_plugins}

    Plugins may register additional types by using the @auth_plugin
    decorator.
    '''.format(builtin_auth_plugins=list_plugins(AuthPlugin, sep='\n    '))
)
auth.add

# Generated at 2022-06-25 17:59:50.069152
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('fvZoS')
    var_1 = auth_type_lazy_choices_0.__contains__('zLtw')
    try:
        var_2 = auth_type_lazy_choices_0.__contains__('fvZoSzLtw')
    except Exception as e:
        print(e)
    else:
        raise AssertionError('No exception raised')


# Generated at 2022-06-25 18:00:08.285460
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(0)
    assert (var_0 == False)


# Generated at 2022-06-25 18:00:09.935911
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_1 = _AuthTypeLazyChoices()
    assert var_1 is not None


# Generated at 2022-06-25 18:00:14.483582
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print("start to test _AuthTypeLazyChoices___iter__")
    try:
        test_case_0()
    except AssertionError as e:
        print("Test case 0 failed")
        print(e)
        raise e


print("unit_method_test.py tests done")

# Generated at 2022-06-25 18:00:21.538877
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = list()
    for var_2 in var_0:
        var_1.append(var_2)
    if var_1 != ['aws4-hmac-sha256', 'awsv4', 'basic', 'digest']:
        raise Exception("Expected: ['aws4-hmac-sha256', 'awsv4', 'basic', 'digest'], but got: var_1")


# Generated at 2022-06-25 18:00:31.501843
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
        print('pass')
    except Exception:
        print('exception')

# @add_doc
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    help='''
    Specify a custom auth plugin. Use

        https://httpie.org/plugins#authentication

    to find plugin names and docs.

    '''
)
try:
    from collections import OrderedDict
except ImportError:
    OrderedDict = dict


# Generated at 2022-06-25 18:00:33.610813
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # __iter__() -> iterator object
    assert not isinstance(_AuthTypeLazyChoices.__iter__, types.FunctionType)


# Generated at 2022-06-25 18:00:40.942913
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert hasattr(test_case_0, '__wrapped__')
    test_case_0.__wrapped__()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism, either "basic" or "digest".
    Useful when the server sent a 401 response without the WWW-Authenticate
    header, as is the case with some IIS servers.

    '''
)
auth.add_argument(
    '--auth-digest',
    metavar='ALGORITHM',
    choices=['md5', 'md5-sess'],
    default='md5',
    help='''
    The digest authentication algorithm to use.

    '''
)

# Generated at 2022-06-25 18:00:48.100297
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__("819zknd9v")
        print("Test case 0: Pass")
    except Exception:
        print("Test case 0: Fail")


# Generated at 2022-06-25 18:00:57.617756
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_0.__contains__("my_auth")
    if (var_1):
        var_0 = True
    else:
        var_0 = False
    return var_0


# Generated at 2022-06-25 18:00:58.712709
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:01:35.408657
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

if __name__ == "__main__":
    test__AuthTypeLazyChoices()

# Generated at 2022-06-25 18:01:39.552572
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (str(auth_type_lazy_choices_0.__contains__('o')) == 'False') == True


# Generated at 2022-06-25 18:01:49.582408
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    assert_equal(var_0,var_1)
    var_2 = auth_type_lazy_choices_0.__contains__('basic')
    assert_equal(var_2,True)
    var_3 = auth_type_lazy_choices_0.__contains__('digest')
    assert_equal(var_3,True)
    var_4 = auth_type_lazy_choices_0.__contains__('hawk')
    assert_equal(var_4,True)
    var

# Generated at 2022-06-25 18:02:01.935418
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = "bearer"
    var_1 = auth_type_lazy_choices_0.__contains__(var_0)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    '''
)

#######################################################################
# HTTP method
#######################################################################
http_method = parser.add_mutually_exclusive_group(required=False)

# Generated at 2022-06-25 18:02:05.693333
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__('ho')


# Generated at 2022-06-25 18:02:13.696739
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, object)
    test_case_0()


# Generated at 2022-06-25 18:02:22.816983
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The value is one of the following:

        {available_auth_types}

    Run ``http --debug`` to see all available plugins.

    '''.format(
        available_auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())), 60)
        ).strip(),
    )
)


# Generated at 2022-06-25 18:02:35.552505
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an auth plugin to use.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    Send the Basic auth credentials even if the server responds with a 401
    Unauthorized and WWW-Authenticate header.

    '''
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')

# Generated at 2022-06-25 18:02:36.982602
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 =  _AuthTypeLazyChoices().__iter__()


# Generated at 2022-06-25 18:02:46.228271
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    The default is {default},
    which is the requests library's mechanism:

        https://python-requests.org/en/master/user/authentication

    Other options, if available, are loaded from plugins.
    '''.format(default=DEFAULT_AUTH_PLUGIN)
)

# Generated at 2022-06-25 18:03:56.509564
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__("")


# Generated at 2022-06-25 18:03:57.589095
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__("")


# Generated at 2022-06-25 18:04:06.962916
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__iter__()
    var_2 = None
    for var_3 in var_1:
        var_2 = var_3

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin.

    '''
)

#######################################################################
# CLI formatter
#######################################################################
cli_formatter = parser.add_argument_group(title='CLI Formatter')

# Generated at 2022-06-25 18:04:15.388709
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    #ret_4 = None
    #lazy_iter_arg_0 = None
    ret_4 = None
    var_2 = None
    plugin_manager_var_0 = plugin_manager
    var_3 = plugin_manager_var_0.get_auth_plugin_mapping()
    if (not (type(var_3) is dict)):
        raise AssertionError
    var_4 = (not (type(var_3) is dict))
    var_5 = var_4
    var_6 = var_5
    var_7 = var_6
    var_8 = sorted(var_3)
    if (not (type(var_8) is list)):
        raise AssertionError
    var_9 = (not (type(var_8) is list))
    var_10 = var_

# Generated at 2022-06-25 18:04:23.348108
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    help='''
    Specify an authentication type, which is usually automatically inferred
    from the provided URL.

    Use --debug to see the inferred auth types and available plugins.

    ''',
    choices=_AuthTypeLazyChoices(),
)
auth.add_argument(
    '--auth-send',
    default=DEFAULT_AUTH_SEND,
    help='''
    Controls whether to send auth headers during the first (non-redirect)
    request or not.

    By default (--auth-send=first), auth headers are not sent during a
    redirect. This can be changed by setting --auth-send=everywhere.

    '''
)

# Generated at 2022-06-25 18:04:25.600877
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("'\"v\"'")


# Generated at 2022-06-25 18:04:31.840565
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:04:36.524982
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert auth_type_lazy_choices_0.__contains__('lst')
    assert auth_type_lazy_choices_0.__contains__('digest')
    assert not auth_type_lazy_choices_0.__contains__('digest1')
