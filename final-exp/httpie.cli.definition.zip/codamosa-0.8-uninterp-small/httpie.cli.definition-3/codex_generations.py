

# Generated at 2022-06-25 17:54:39.064298
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'bearer' not in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:54:47.681499
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert ('Digest' in auth_type_lazy_choices_1) == True
    assert ('Basic' in auth_type_lazy_choices_1) == True
    assert ('Hawk' in auth_type_lazy_choices_1) == True
    assert ('AWS' in auth_type_lazy_choices_1) == True
    assert ('Kerberos' in auth_type_lazy_choices_1) == True
    assert ('Bearer' in auth_type_lazy_choices_1) == False
    assert ('Invalid' in auth_type_lazy_choices_1) == False


# Generated at 2022-06-25 17:54:58.243366
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    ###
    # Verify call
    ###
    # Verify return value
    # To verify return value, there are three ways, 1: pass a `return_value`
    # argument to mock method, 2: use side effect, 3: return a `MagicMock`
    # when mock method is called.
    # 1: pass a `return_value` argument
    # mock_method_0.return_value = expected_return_value
    # 2: use side effect
    # mock_method_0.side_effect = Exception('side effect')
    # 3: return a `MagicMock`
    # mock_method_0.return_value = MagicMock()

    # Construct arguments
    args = []
    kwargs = {}

    # Call method

# Generated at 2022-06-25 17:55:05.162163
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    method_name = 'HTTPie.cli._argparse._AuthTypeLazyChoices.__iter__'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for value in auth_type_lazy_choices_0:
        pass

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies the authentication mechanism. Available choices are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    If no type is given, a default is guessed based on --auth.

    '''
)


# Generated at 2022-06-25 17:55:06.732681
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:10.347207
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_list = list(_AuthTypeLazyChoices().__iter__())
    test_list.sort()
    assert test_list in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-25 17:55:21.859934
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted([1, 2, 3]) == sorted(_AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    required=False,
    help='''
    Authentication type to use. If not specified, HTTPie tries to detect the
    auth type based on the response.

    Available auth types: {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

#######################################################################
# Config/Environment
#######################################################################

config = parser.add_argument_group(title='Config/Environment')


# Generated at 2022-06-25 17:55:25.549015
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' not in _AuthTypeLazyChoices()
    assert 'Digest' not in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:26.674832
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:55:30.483980
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not ('' in auth_type_lazy_choices_0)
    assert 'bewit' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:45.762179
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import pytest
    from hypothesis import given
    from hypothesis.strategies import lists, integers
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import DigestAuth
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthPlugin

# Generated at 2022-06-25 17:55:47.834409
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert all(__iter___result
              for __iter___result in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:58.845606
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_validator = AuthTypeValidator(
    'Invalid auth plugin: {0}.'.format,
    'No such auth plugin: {0}.'.format
)

auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    type=auth_type_validator,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin.

    The following plugins are available:

    ''' + help_texts.get_available_auth_plugins()
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 17:56:02.026173
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = iter(_AuthTypeLazyChoices())
    assert isinstance(it, collections.Iterator)
    assert type(it) is collections.abc.Iterator
    assert iter(it) is it


# Generated at 2022-06-25 17:56:14.458410
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'jwt' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in _AuthTypeLazyChoices()
    assert 'awscurl' in _AuthTypeLazyChoices()

auth_type_choices_help = '''
    One of the auth types supported by the HTTPie auth plugin system.

    Run `http --auth-type=help` to get a list of all the supported types.

    '''


# Generated at 2022-06-25 17:56:23.527423
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__('basic') == 'basic' in plugin_manager.get_auth_plugin_mapping()
    assert auth_type_lazy_choices_0.__contains__('digest') == 'digest'  in plugin_manager.get_auth_plugin_mapping()
    assert auth_type_lazy_choices_0.__contains__('test') == 'test' in plugin_manager.get_auth_plugin_mapping()
    assert auth_type_lazy_choices_0.__iter__() == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:56:24.599929
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert_equal(test_case_0(), None)

# Generated at 2022-06-25 17:56:26.868662
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:39.801121
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in auth_type_lazy_choices_0

auth_type_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=auth_type_choices,
    help='''
    Authentication mechanism. Default: "auto". Use "help" to list available
    authentication mechanisms.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use the netrc file.
    Overrides and voids the netrc option in the config file.

    '''
)

#######################################################################
# .netrc
#######################################################################


# Generated at 2022-06-25 17:56:42.145622
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(auth_type_lazy_choices_0) == sorted(['digest', 'generic'])


# Generated at 2022-06-25 17:56:48.128418
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('Basic')
    assert var_0 == True


# Generated at 2022-06-25 17:56:59.865530
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__iter__()
    except Exception:
        var_1 = 0
        var_2 = sys.exc_info()
        var_3 = var_2[0]
        var_4 = 'please report this'
        print('Exception!', var_1, var_3, var_4, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
    else:
        var_1 = 1


# Generated at 2022-06-25 17:57:09.563953
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter___var_0 = "\x00\x00\x00\x00\x00\x00\x00\x00)"
    _AuthTypeLazyChoices___iter___var_0 += "\x00\x00\x00\x00\x00\x00\x00\x00"
    _AuthTypeLazyChoices___iter___var_0 += "\x00\x00\x00\x00\x00\x00\x00\x00"
    _AuthTypeLazyChoices___iter___var_0 += "\x00\x00\x00\x00\x00\x00\x00\x00"

# Generated at 2022-06-25 17:57:21.622874
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """
    It tests method __iter__ of class _AuthTypeLazyChoices.
    It tests part of condition that key of kwargs is equal to 'plugin_manager'.
    """
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    plugin_manager_0 = PluginManager()
    kwargs_0 = {'plugin_manager': plugin_manager_0}
    result_0 = auth_type_lazy_choices_0.__iter__(**kwargs_0)
    print(result_0)


# Generated at 2022-06-25 17:57:33.742087
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assertTrue(auth_type_lazy_choices_0.__contains__('digest'), "auth_type_lazy_choices_0.__contains__('digest') failed after auth_type_lazy_choices_0 = _AuthTypeLazyChoices()")
    assertFalse(auth_type_lazy_choices_0.__contains__('digest'), "auth_type_lazy_choices_0.__contains__('digest') failed after auth_type_lazy_choices_0 = _AuthTypeLazyChoices()")

# Generated at 2022-06-25 17:57:45.682396
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    import builtins
    if hasattr(builtins, '__IPYTHON__'):
        import unittest
        import sys

        class _Test(unittest.TestCase):
            def test(self):
                self.assertRaises(Exception, test_case_0)

        unittest.main(argv=[''], exit=False, testRunner=_Test)
    else:
        test_case_0()


# Generated at 2022-06-25 17:57:56.065213
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth_type_validator = AuthPluginTypeValidator(
    'Auth type {0} is not supported.'
)

auth.add_argument(
    '--auth-type',
    default=None,
    type=auth_type_validator,
    metavar='SCHEME',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Choose an auth type (plugin).

    Use the special value `{AUTH_PLUGIN_MAP_ALL}` to list available auth
    plugins.

    '''
)

# Generated at 2022-06-25 17:57:59.469273
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices__0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices__0.__contains__('kerberos')
    # assert ....


# Generated at 2022-06-25 17:58:12.205599
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():


    # Check for __contains__
    # TODO: check for __contains__
    test_case_0()
    test_case_1()


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    metavar='TYPE',
    dest='auth_plugin',  # For `Args`.
    type=AuthPluginArgType(
        metavar='TYPE',
        lazy_choices=_AuthTypeLazyChoices(),
    ),
    help='''
    The authentication method to use. Currently supported: {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

#######################################################################
# HTTP methods
#######################################################################

methods

# Generated at 2022-06-25 17:58:16.582061
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (isinstance(auth_type_lazy_choices_0, object))
    assert (auth_type_lazy_choices_0.__class__ == _AuthTypeLazyChoices)


# Generated at 2022-06-25 17:58:30.505561
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    metavar='TYPE',
    help='''
    The authentication mechanism. The default is "auto". Alternatively, the
    following mechanisms are supported:

        auto            Auto-detect the mechanism based on the --auth value.
        basic           HTTP Basic Auth (default if --auth contains a colon).
        digest          HTTP Digest Auth.
        aws             AWS Signature Version 4.
        hawk            Hawk Authentication.
        oauth1          OAuth 1.0.
        oauth2          OAuth 2.0 (a.k.a Bearer Token).

    '''
)

# Generated at 2022-06-25 17:58:34.266169
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    with pytest.raises(StopIteration):
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        var_0 = auth_type_lazy_choices_0.__iter__()
        next(var_0)


# Generated at 2022-06-25 17:58:37.428602
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Create an instance of _AuthTypeLazyChoices
    obj_1 = _AuthTypeLazyChoices()
    func_result_2 = obj_1.__contains__("ntlm")
    assert func_result_2 == True


# Generated at 2022-06-25 17:58:47.732692
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_0 = test_case_0()
    test_result_1 = (var_0 is not None)
    assert test_result_1

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. By default, the plugin is guessed based on
    the --auth value.

    The available plugins are: {', '.join(_AuthTypeLazyChoices())}

    ''',
)


# Generated at 2022-06-25 17:58:50.639034
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'str_0'
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:58:57.636585
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    var_1 = plugin_manager.get_auth_plugin_mapping()
    var_2 = 'Basic'
    var_3 = var_1.__contains__(var_2)
    var_4 = var_0.__contains__(var_2)
    assert var_4 == var_3



# Generated at 2022-06-25 17:59:08.513994
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(None)

auth.add_argument(
    '--auth-type',
    dest='auth_type_option',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=argparse.SUPPRESS
)

auth.add_argument(
    '--auth-type=Basic|Digest',
    dest='auth_type_option',
    choices=['basic', 'digest'],
    action=CompatOptionAction,
    help='''
    The name of the auth plugin to use.
    These are aliases for --auth-type=<name>.

    '''
)

#######################################################################
# SSL


# Generated at 2022-06-25 17:59:18.535751
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert auth_type_lazy_choices_0.__contains__(var_1) == True

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=auth_type_lazy_choices,
    help='''
    Specify an authentication type to be used.

    The available types vary depending on the plugins
    installed. The full list of types can be displayed
    by running:

        http --auth-type=

    If a plugin for a type is installed, but not
    enabled (see --plugin), then a warning is
    displayed.

    ''',
).completer = ChoicesCompleter(auth_type_lazy_choices)


# Generated at 2022-06-25 17:59:21.290820
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__iter__()
    var_1.__next__()


# Generated at 2022-06-25 17:59:29.573916
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for var_0 in auth_type_lazy_choices_0.__iter__():
        assert isinstance(var_0, str)
        assert len(var_0) > 0
        assert var_0 == var_0.strip()


# Generated at 2022-06-25 17:59:45.223111
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var = _AuthTypeLazyChoices()
    for i in var:
        pass
    return


# Generated at 2022-06-25 17:59:53.470394
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    temp_0 = _AuthTypeLazyChoices()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    Specify the authentication mechanism to be used, if not otherwise
    inferred from the --auth option value.

    ''',
)

auth.add_argument(
    '--auth-type=',
    action=ResetAuthenticationAction,
    nargs=0,
    default=None,
    help='Reset any authentication information, including cached credentials.'
)

# XXX - This should be moved to a default

# Generated at 2022-06-25 17:59:55.032785
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    test_case_0()


# Generated at 2022-06-25 17:59:56.797956
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert True


# Generated at 2022-06-25 18:00:00.285968
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for var_0 in auth_type_lazy_choices_0.__iter__():
        pass


# Generated at 2022-06-25 18:00:11.336027
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert issubclass(_AuthTypeLazyChoices, object), "_AuthTypeLazyChoices is not a subclass of object"
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0, _AuthTypeLazyChoices), "auth_type_lazy_choices_0 is not an instance of _AuthTypeLazyChoices"
    test_case_0()



# Generated at 2022-06-25 18:00:18.790919
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert callable(_AuthTypeLazyChoices)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Explicit auth type (basic, digest, etc.), for when the server does not
    advertise it properly in 401 responses.

    The available auth types depend on plugins. These are the currently active
    auth plugins: {', '.join(plugin_manager.get_auth_plugin_mapping())}.

    '''
)



# Generated at 2022-06-25 18:00:21.758221
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = isinstance(var_0, _AuthTypeLazyChoices)
    var_2 = var_0.__contains__('foo')


# Generated at 2022-06-25 18:00:34.294804
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('jwt')
    return var_0


# Generated at 2022-06-25 18:00:35.927394
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    print('\n**** Test Case 0 ****')
    test_case_0()


# Generated at 2022-06-25 18:01:23.847692
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    try:
        while True:
            var_1 = next(var_0)
    except StopIteration:
        pass

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin to use.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Do not use the .netrc file even if it exists.

    '''
)

#######################################################################
# HTTP and HTTPS Proxy
#######################################################################


# Generated at 2022-06-25 18:01:25.182518
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert callable(_AuthTypeLazyChoices.__init__)


# Generated at 2022-06-25 18:01:27.624608
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')


# Generated at 2022-06-25 18:01:28.440779
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:01:31.273517
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('gqO')


# Generated at 2022-06-25 18:01:43.494649
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    global plugin_manager
    global auth_type_lazy_choices
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    help=f'''
    Specify the authentication mechanism to use. Default: {DEFAULT_AUTH_PLUGIN}.
    Available plugins:

    {', '.join(auth_type_lazy_choices)}

    Some plugins support sending the credentials from a file with '@' prefix
    (e.g., --auth-type=jwt --auth='@credentials.json').
    '''
)

# Generated at 2022-06-25 18:01:52.028088
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an HTTP authentication type (Basic or Digest).

    '''.format(
        default=DEFAULT_AUTH_PLUGIN_NAME,
        available=', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-25 18:01:58.142978
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('foo')
    var_1 = auth_type_lazy_choices_0.__contains__('Basic')


# Generated at 2022-06-25 18:02:00.364576
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices_instance_0 = _AuthTypeLazyChoices()
    var_1 = test_case_0()


# Generated at 2022-06-25 18:02:05.898597
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    session = requests.sessions.Session()

    url = 'https://httpbin.org/cookies/set/__test_key/__test_value'
    cookies = {'__test_key': '__test_value'}
    resp = session.get(url, cookies=cookies)

    assert resp.status_code == 200


# Generated at 2022-06-25 18:03:21.121162
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:03:32.196968
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = next(var_0)
    var_2 = next(var_0)
    var_3 = next(var_0)
    var_4 = next(var_0)
    var_5 = next(var_0)
    var_6 = next(var_0)
    var_7 = next(var_0)
    var_8 = next(var_0)
    var_9 = next(var_0)
    var_10 = next(var_0)
    var_11 = next(var_0)
    var_12 = next(var_0)
    var_13 = next(var_0)

# Generated at 2022-06-25 18:03:34.901299
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__contains__(auth)


# Generated at 2022-06-25 18:03:41.539994
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:03:52.372228
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_0.__iter__() == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys())))


# Generated at 2022-06-25 18:04:00.353269
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test with the first constructor
    test_case_0()
    return

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Define the authentication mechanism to be used, e.g. Hashicorp Vault.

    ''',
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help=f'''
    Send authentication data without waiting for the server's 401
    challenge.

    Use this option to pass authentication data in case the server does not
    return a 401 Unauthorized.

    HTTP Basic Authentication is only supported.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts

# Generated at 2022-06-25 18:04:09.760364
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of authentication to use for the request. If the type is not
    explicitly provided, the client will attempt to guess it based on the
    presence of a password or a token in the credentials.

    Default:

        guess based on presence of a password or a token in the credentials

    Available types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-25 18:04:16.957449
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var = _AuthTypeLazyChoices()
    assert var.__contains__(None) == True
    assert var.__contains__(None) == True
    assert var.__iter__() != True
    assert var.__iter__() != False
    assert var._AuthTypeLazyChoices__contains__(None) == True
    assert var._AuthTypeLazyChoices__contains__(None) == True
    assert var._AuthTypeLazyChoices__iter__() != True
    assert var._AuthTypeLazyChoices__iter__() != False

# Tests for the constructor of class _AuthTypeLazyChoices

# Generated at 2022-06-25 18:04:24.124955
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('basic')
    var_0 = auth_type_lazy_choices_0.__iter__()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    dest='auth_type',
    #choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth type.

    Plugin authors: note that the auth plugin name must be equal to the
    AUTH_TYPE argument value.

    '''
)

#######################################################################
# SSL
#######################################################################


# Generated at 2022-06-25 18:04:30.558567
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('foo')

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used.
    When "auto" and both -a USER and -a PASS are present,
    it will select the most secure of the available mechanisms.

    The available types are:

    ''' + '\n'.join('* {0}'.format(auth_name) for auth_name in sorted(plugin_manager.get_auth_plugin_mapping().keys())) + '''

    '''
)