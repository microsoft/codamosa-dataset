

# Generated at 2022-06-25 17:54:47.997061
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use for the request. The available mechanisms are:

    {help_list}

    '''.format(
        help_list='\n'.join([
            '\n'.join(wrap(
                plugin.help,
                initial_indent=8 * ' ',
                subsequent_indent=8 * ' ')
            )
            for plugin in plugin_manager.get_auth_plugins().values()
        ])
    )
)

#######################################################################
# Miscellaneous
#######################################################################

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 17:54:58.611615
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. An explicit value can be passed in
    order to use a third-party (i.e., not builtin) plugin.
    If not passed, the plugin is inferred from --auth.

    '''
)

# Generated at 2022-06-25 17:55:00.608872
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (False)


# Generated at 2022-06-25 17:55:11.886970
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

AuthTypeLazyChoices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=AuthTypeLazyChoices,
    help='''
    The authentication mechanism to use.

    Use --auth-type={0} to display a list of supported types.

    '''.format(','.join(plugin_manager.get_auth_plugin_mapping()))
)

#######################################################################
# SSL/TLS verification
#######################################################################

verify = parser.add_argument_group(title='SSL/TLS Verification')


# Generated at 2022-06-25 17:55:24.002657
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert Iterable(auth_type_lazy_choices_1).is_iterable()


auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    type=plugin_manager.get_auth_plugin_class,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. It is guessed from
    --auth credentials, if not specified. Available values are:

        {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)


# Generated at 2022-06-25 17:55:25.386964
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
  pass


# Generated at 2022-06-25 17:55:34.371810
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    res0 = ('digest' in auth_type_lazy_choices_0)

    assert res0



# Generated at 2022-06-25 17:55:46.072132
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    print(isinstance(_AuthTypeLazyChoices(), collections.abc.Container))
    print('__contains__' in dir(_AuthTypeLazyChoices))
    print(plugin_manager.get_auth_plugin_mapping())
    print(plugin_manager.get_auth_plugin_mapping().keys())
    for type in _AuthTypeLazyChoices():
        print(type)


# Generated at 2022-06-25 17:55:50.776821
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    v0_0 = _AuthTypeLazyChoices()
    assert (iter(v0_0) is not None)
    v0_6 = v0_0.__contains__('abc')
    assert (v0_6 is not None)


# Generated at 2022-06-25 17:55:56.509940
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(iter(_AuthTypeLazyChoices())) == list(sorted(plugin_manager.get_auth_plugin_mapping().keys()))

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used. By default,
    HTTPie tries to guess the auth type by inspecting the provided
    credentials.

    '''
)

netrc = auth \
    .add_mutually_exclusive_group(required=False)

# Generated at 2022-06-25 17:56:09.985135
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_contains_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_contains_0.__contains__("ntlm")
    var_1 = auth_type_lazy_choices_contains_0.__contains__("aws4")
    var_2 = auth_type_lazy_choices_contains_0.__contains__("aws_sigv4")




# Generated at 2022-06-25 17:56:20.610209
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom authentication plugin ('''
    + ''', '''.join(
        "'{}'".format(name)
        for name in plugin_manager.get_auth_plugin_mapping().keys())
    + '''). The default is basic,
    i.e., HTTP Basic Authentication.

    Note that when using the default (and most other built-in) plugins, the
    --auth option provides a more convenient interface.

    '''
)

# Generated at 2022-06-25 17:56:27.462184
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Argument names
    arg_0 = _AuthTypeLazyChoices()
    # Assign
    var_0 = arg_0
    var_0 = arg_0.__iter__()
    # Assert
    assert True


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    This is an alias for the -a flag that also allows you to explicitly choose
    which authentication plugin to use. Only relevant if the chosen --auth
    plugin supports multiple types of authentication.

    The following authentication types are supported:

    {_format_auth_plugins_list()}

    '''.strip()
)

# Generated at 2022-06-25 17:56:40.595608
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert True


auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. The default is Basic. Use --debug to see
    what auth plugins are available in your environment.

    '''
)
# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 17:56:47.306849
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter___var_0 = None
    try:
        _AuthTypeLazyChoices___iter___var_0 = _AuthTypeLazyChoices()
    except NameError as err:
        print(err)
        return
    _AuthTypeLazyChoices___iter___var_1 = None
    try:
        _AuthTypeLazyChoices___iter___var_1 = _AuthTypeLazyChoices___iter___var_0.__iter__()
    except NameError as err:
        print(err)
        return
    print(_AuthTypeLazyChoices___iter___var_1)


# Generated at 2022-06-25 17:56:58.269815
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__iter__()
    var_0_0 = auth_type_lazy_choices_0.__iter__().__next__()
    var_0_1 = auth_type_lazy_choices_1.__iter__().__next__()


# Generated at 2022-06-25 17:57:08.327701
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    if "_AuthTypeLazyChoices__iter__" in INSTANCES:
        raise Exception("Method __iter__ of class _AuthTypeLazyChoices is already defined")
    else:
        INSTANCES.add("_AuthTypeLazyChoices___iter__")

    global plugin_manager_0
    plugin_manager_0 = create_plugin_manager()

    test_case_0()


# Generated at 2022-06-25 17:57:15.358238
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    AUTH_TYPES = plugin_manager.get_auth_plugin_mapping().keys()
    if AUTH_TYPES == sorted(AUTH_TYPES):
        print("Unit test for constructor of class _AuthTypeLazyChoices() is completed")
    else:
        print("Unit test for constructor of class _AuthTypeLazyChoices() is failed") 

test__AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:28.455716
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0() == '<generator object _AuthTypeLazyChoices.__iter__ at 0x000001CB2E5A4138>'

auth.add_argument(
    '--auth-type',
    help='''
    The custom auth type to use. By default, HTTPie looks for a plugin
    implementing the auth scheme specified by --auth.

    The plugin must be an instance of
    ``httpie.plugins.AuthPlugin`` and registered via
    ``httpie.plugins.auth_plugin_manager.register``.

    ''',
    choices=_AuthTypeLazyChoices(),
)
auth.add_argument(
    '--auth-prompt',
    action='store_true',
    default=False,
    help='Prompt for HTTP auth credentials.'
)

#######################################################################
#

# Generated at 2022-06-25 17:57:38.028530
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    var_1 = auth_type_lazy_choices_0.__iter__()
    print(var_0, var_1)

auth.add_argument(
    '--auth-type', '--auth-plugin',
    dest='auth_type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. The options are:

        ''' + ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())) + '''

    '''
)


# Generated at 2022-06-25 17:57:53.244440
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    dest='auth_plugin',
    help=f'''
    If set to auto (default), HTTPie determines the auth plugin to use based
    on the provided credentials and the HTTP authentication type presented by
    the server. Otherwise, it can be set to one of the following:

    {plugin_manager.get_auth_plugin_names_as_choices()}

    '''
)

#######################################################################
# Certificates
#######################################################################

certs = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:57:55.326886
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
    except TypeError as e:
        raise Exception(e)



# Generated at 2022-06-25 17:58:02.735382
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert callable(_AuthTypeLazyChoices.__iter__)


# Generated at 2022-06-25 17:58:15.537473
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_1 = 'basic'
    var_2 = 'digest'
    var_3 = 'hawk'
    var_4 = 'ntlm'
    var_5 = 'aws4-hmac-sha256'
    var_6 = 'custom'

# Generated at 2022-06-25 17:58:24.039884
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (isinstance(auth_type_lazy_choices_0, 
                       _AuthTypeLazyChoices)), "Assertion failed."
    assert (hasattr(auth_type_lazy_choices_0, '__contains__')), \
    "AttributeError: attribute '__contains__' of '_AuthTypeLazyChoices' \
    objects is not readable"
    assert (hasattr(auth_type_lazy_choices_0, '__iter__')), \
    "AttributeError: attribute '__iter__' of '_AuthTypeLazyChoices' \
    objects is not readable"
    test_case_0()


# Generated at 2022-06-25 17:58:31.136055
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # The following 5 lines were extracted from:
    #     str_0 = 'basic'
    #     assert str_0 in auth_type_lazy_choices_0
    #     var_0 = plugin_manager.get_auth_plugin_mapping()
    #     assert str_0 in var_0
    #     assert str_0 in plugin_manager.get_auth_plugin_mapping()
    #
    assert 'basic' in plugin_manager.get_auth_plugin_mapping()
    # The following 5 lines were extracted from:
    #     str_0 = 'digest'
    #     assert str_0 in auth_type_lazy_choices_0
    #     var_0 = plugin_manager.get_auth

# Generated at 2022-06-25 17:58:31.929129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:58:40.404759
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default "auto" chooses between
    the mechanisms supported by the host. Available choices are:
    {auth_choices}.

    '''.format(
        auth_choices=humanize_list(
            plugin_manager.get_auth_plugin_mapping().keys()
        )
    )
)

#######################################################################
# Key
#######################################################################


# Generated at 2022-06-25 17:58:49.849437
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        _AuthTypeLazyChoices()
    except Exception as e:
        print('Exception: {}'.format(e))
    finally:
        print('Finished!')


# Generated at 2022-06-25 17:58:51.549538
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:59:09.657384
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type', metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use. If no value is given (default), an appropriate auth
    plugin is auto-selected based on provided credentials.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Do not send an initial credential carrying request when using Digest
    auth. Rather, always use the traditional application layer credential
    exchange.

    '''
)

# ``requests.Session`` keyword arguments.
session_opts = parser.add_argument_group(title='Session Options')

# Generated at 2022-06-25 17:59:13.190879
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    temp_0 = _AuthTypeLazyChoices()
    temp_1 = temp_0.__iter__()
    assert temp_1, 'Instance variable not set right'


# Generated at 2022-06-25 17:59:23.347140
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')
    return var_0


# Generated at 2022-06-25 17:59:24.272676
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()



# Generated at 2022-06-25 17:59:31.162437
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("c")
    assert var_0 == False
    # assert var_0 == True


# Generated at 2022-06-25 17:59:38.110830
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 0 == len(list(auth_type_lazy_choices_0.__iter__()))
    assert auth_type_lazy_choices_0.__contains__('custom')
    assert not auth_type_lazy_choices_0.__contains__('azhang')


# Generated at 2022-06-25 17:59:46.352200
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # The following code is generated:
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__iter__()
    assert (var_1 is not None)
    # var_1 is iterator, get the first element:
    var_2 = var_1.__next__()
    assert (var_2 is not None)

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    PyPI name of a plugin providing an auth implementation.
    The default value is "auto".

    '''
)


# Generated at 2022-06-25 17:59:51.568543
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    def __bool__(x_0):
        return True
    def __next__(x_1):
        return x_1
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_0.__next__ = __next__
    var_0.__bool__ = __bool__


# Generated at 2022-06-25 18:00:02.217637
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert len(_AuthTypeLazyChoices()) == 11
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-25 18:00:04.145381
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_1 = _AuthTypeLazyChoices()
    test_case_0()


# Generated at 2022-06-25 18:00:19.844166
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()



# Generated at 2022-06-25 18:00:24.174014
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__(auth_type_lazy_choices_0)
        var_1 = auth_type_lazy_choices_0.__contains__(auth_type_lazy_choices_0)
    except:
        raise ScriptException('Exception raised in test#0')


# Generated at 2022-06-25 18:00:35.889578
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()


auth.add_argument(
    '--auth-type',
    metavar='NAME',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of the auth mechanism used. Use "auto" to detect from server response.
    You can also use pre-defined auth types (Basic, Digest, etc.).
    See `http --help-auth-types` for a list of available auth types.
    If the provided auth type is not installed, HTTPie will bail out early.

    '''
)


# Generated at 2022-06-25 18:00:36.682630
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()



# Generated at 2022-06-25 18:00:37.457248
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:00:43.651079
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

# def test_case_0():
#     auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
#     var_0 = auth_type_lazy_choices_0.__contains__('token')
#
#
# # Unit test for method __contains__ of class _AuthTypeLazyChoices
# def test__AuthTypeLazyChoices_contains():
#     assert test_case_0()



# Generated at 2022-06-25 18:00:55.550661
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    try:
        assert 'basic' in auth_type_lazy_choices
    except AssertionError as e:
        print('AssertionError:', e)
        print('Expected: True')
    try:
        assert 'azure' not in auth_type_lazy_choices
    except AssertionError as e:
        print('AssertionError:', e)
        print('Expected: False')
    try:
        print('AUTH_TYPE_CHOICES - 1', AUTH_TYPE_CHOICES)
    except Exception as e:
        print('Uncaught exception when invoking AUTH_TYPE_CHOICES')
        print('Exception:', str(type(e)), ':', e)

# Generated at 2022-06-25 18:00:58.577085
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0.__iter__(), types.GeneratorType)


# Generated at 2022-06-25 18:01:06.593018
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for _ in range(500):
        test_case_0()



# Generated at 2022-06-25 18:01:10.585060
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print("Testing __iter__ of class _AuthTypeLazyChoices")
    test_case_0()
    print("Test case passed!")

_AuthTypeLazyChoices___iter__ = test__AuthTypeLazyChoices___iter__


# Generated at 2022-06-25 18:01:52.419715
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()

#######################################################################
# HTTP.
#######################################################################

http = parser.add_argument_group(title='HTTP')

http.add_argument(
    '--proxy',
    default='',
    help='''
    Use this proxy.
    '''
)
http.add_argument(
    '--check-status',
    default=True,
    dest='verify',
    action='store_true',
    help='''
    Check the status code of the response. By default (without --check-status
    or --no-check-status), the status code is checked unless redirects are
    being followed (with --follow) or the method is HEAD.

    '''
)

# Generated at 2022-06-25 18:02:04.182551
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used:

        {0}


    '''.format(plugin_manager.get_auth_plugins_help())
)

#######################################################################
# Miscellaneous
#######################################################################

# ``requests.request`` keyword arguments.
misc = parser.add_argument_group(title='Miscellaneous')

# Generated at 2022-06-25 18:02:13.294962
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_0()
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Override the default authentication handler.
    You can use this option multiple times. The last matching plugin
    takes precedence.
    For example:

        --auth-type=basic --auth-type=digest

    Use `--debug` for a list of all supported authentication methods.

    ''',
)


# ``requests`` keyword arguments.
auth_opts = parser.add_argument_group(title='Authentication options') \
    .add_mutually_

# Generated at 2022-06-25 18:02:19.502024
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from example import _AuthTypeLazyChoices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for var_1 in auth_type_lazy_choices_0:
        pass
    try:
        var_2 = auth_type_lazy_choices_0.__iter__()
        while True:
            var_3 = var_2.__next__()
    except StopIteration as e:
        pass


# Generated at 2022-06-25 18:02:31.293119
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    obj = _AuthTypeLazyChoices()
    # Test for __init__
    for item in obj:
        try:
            print(item)
        except:
            assert False

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    default='HttpBasicAuth',
    help=f'''
    Specify a non-default HTTP authentication type.
    The default is '{'HttpBasicAuth'}', in which case the
    specified credentials are used to encode a standard HTTP
    Authorization header.

    Currently available authentication types are:
    {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-25 18:02:39.033649
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    var_1 = auth_type_lazy_choices_0.__contains__('digest')
    var_2 = auth_type_lazy_choices_0.__contains__('NTLM')


# Generated at 2022-06-25 18:02:42.642848
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(item='foo')
    return var_0


# Generated at 2022-06-25 18:02:52.755501
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an HTTPie authentication plugin.

    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')
proxy.add_argument(
    '--proxy', '-p',
    metavar='USER[:PASS]@SERVER:PORT',
    help='Specify a proxy in the user:pass@server:port format.',
)

# Generated at 2022-06-25 18:03:04.707999
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=(_AuthTypeLazyChoices()),
    help='''
    The auth mechanism to be used.
    Plugins may add more auth types.

    '''
)


# Generated at 2022-06-25 18:03:05.799134
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()



# Generated at 2022-06-25 18:04:18.262493
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:04:25.095602
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert callable(_AuthTypeLazyChoices)



# Generated at 2022-06-25 18:04:31.400194
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    if (var_0 == False):
        raise Exception('Assertion failed')


# Generated at 2022-06-25 18:04:33.850108
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 18:04:44.304567
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('0')
    assert var_0 is not None
