

# Generated at 2022-06-25 17:54:38.256755
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'foo' not in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:54:43.583552
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():

    # value
    expected_value_0 = [('digest', 'Digest'), ('hmac', 'HMAC'), ('never', 'Never'), ('oauth1', 'OAuth1'), ('oauth2', 'OAuth2'), ('ntlm', 'NTLM')]
    actual_value_0 = list(_AuthTypeLazyChoices())

    assert expected_value_0 == actual_value_0



# Generated at 2022-06-25 17:54:50.955007
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    cases = [
        {
            "input": {
            },
            "output": {
            }
        }
    ]
    for case in cases:
        output = _AuthTypeLazyChoices(**case["input"])


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication scheme to be used. Supported values depend on the
    HTTP client implementation in use.

    Defaults to "auto", which is an alias for "basic".

    Valid values include:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    '''
)

# Generated at 2022-06-25 17:54:56.006796
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices.__new__(_AuthTypeLazyChoices)
    def callit(): return iter(obj)
    assert sorted(callit()) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:54:57.249531
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:04.580029
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'hawk' in _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    for item in auth_type_lazy_choices_1: assert type(item) is str
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_2
    assert 'digest' in auth_type_lazy_choices_2
    assert 'hawk' in auth_type_lazy_choices_2


# Generated at 2022-06-25 17:55:08.834225
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # http://stackoverflow.com/questions/1707709/how-do-i-unit-test-something-that-depends-on-raw-input
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:11.034334
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    my_obj = _AuthTypeLazyChoices()
    assert len(my_obj) > 0


# Generated at 2022-06-25 17:55:12.823298
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:15.968742
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter___0 = _AuthTypeLazyChoices()
    assert isinstance(iter(_AuthTypeLazyChoices___iter___0), types.GeneratorType) is True


# Generated at 2022-06-25 17:55:30.487887
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '-A',
    choices=auth_type_lazy_choices,
    metavar='TYPE',
    default=None,
    help=f'''
    Force the specified authentication type. The default is to use the
    authentication mechanism proposed by the server (e.g., Basic).

    Currently supported authentication types:

        {', '.join(auth_type_lazy_choices)}

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 17:55:35.382646
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        obj_0 = _AuthTypeLazyChoices()
        test_case_0()
        assert obj_0.__iter__() == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    except:
        import traceback
        traceback.print_exc()
        assert False


# Generated at 2022-06-25 17:55:47.371613
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except Exception as e:
        print('Exception raised: %s' % repr(e))
        return 1
    else:
        return 0

if __name__ == '__main__':
    import sys
    sys.exit(test__AuthTypeLazyChoices())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication protocol to be used. Supported protocols:

        {plugins}

    Run `$ http --help-auth` for details on a specific plugin.

    '''.format(
        plugins=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-25 17:55:58.494959
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test case 0
    test_case_0()


auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    dest='auth_type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified authentication plugin. If not specified, HTTPie
    guesses the plugin based on --auth credentials, if present.

    Available plugins:

        {plugin_manager.get_auth_plugin_mapping()}

    ''',
)

# Generated at 2022-06-25 17:56:10.355840
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from hypothesis import given
    from hypothesis.strategies import just, text

    # Check that the constructor returns an object of the correct type
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices), 'Constructor failed to create object of type _AuthTypeLazyChoices'

    # Check that the constructor returns an object of the correct type
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices), 'Constructor failed to create object of type _AuthTypeLazyChoices'

    # Check that the constructor returns an object of the correct type
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices), 'Constructor failed to create object of type _AuthTypeLazyChoices'

    # Check that the constructor returns an object of the correct type

# Generated at 2022-06-25 17:56:20.892452
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# Run tests on class _AuthTypeLazyChoices
test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. default=auto.

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    help='''
    Don't send an initial authentication challenge.
    By default, HTTPie sends the initial authentication challenge
    (request) to provide credentials to the server (e.g., Basic, Digest).

    '''
)

#######################################################################
# HTTP and HTTPS
#######################################################################


# Generated at 2022-06-25 17:56:24.254094
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    it = auth_type_lazy_choices_0.__iter__()
    assert isinstance(it, Iterator)
    assert callable(it.__next__)
    assert not hasattr(it, '__iter__')
    assert hasattr(it, '__next__')


# Generated at 2022-06-25 17:56:28.818452
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_1.__contains__('basic') == plugin_manager.get_auth_plugin_mapping().__contains__('basic'))


# Generated at 2022-06-25 17:56:42.062008
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism.  Currently supported: {', '.join(
        plugin_manager.get_auth_plugin_mapping().keys())}.
    Defaults to Basic for HTTP and Bearer for HTTPS.

    '''
)

# Generated at 2022-06-25 17:56:48.273958
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # As of this writing, the following plugins are available:
    #  'basic', 'digest', 'hawk', 'ntlm', 'oauth1' and 'oauth2'
    assert 'basic' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'ntlm' in auth_type_lazy_choices_0
    assert 'oauth1' in auth_type_lazy_choices_0
    assert 'oauth2' in auth_type_lazy_choices_0
    assert 'mock' not in auth_type_lazy_choices_

# Generated at 2022-06-25 17:56:59.815166
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    import unittest
    class __AuthTypeLazyChoices_TestCase (unittest.TestCase):
        def test_0(self):
            auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
            self.assertEqual(list(auth_type_lazy_choices_0)[0], 'basic')
    unittest.main()


# Generated at 2022-06-25 17:57:09.523053
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Forces the specified authentication mechanism.

    The default is "auto", which means HTTPie will try to
    auto-detect the authentication type.

    ''',
)

auth.add_argument(
    '--auth-host',
    dest='auth_host',
    default=None,
    metavar='HOST',
    help='''
    The server host to use for HTTP authentication, e.g.
    http://example.org.

    '''
)


# Generated at 2022-06-25 17:57:12.390322
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x = _AuthTypeLazyChoices()
    for item in x:
        assert item in ['basic', 'digest', 'hawk', 'ntlm', 'oauth1']


# Generated at 2022-06-25 17:57:13.798698
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass # TODO: implement your test here


# Generated at 2022-06-25 17:57:18.047126
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0, _AuthTypeLazyChoices)


# Generated at 2022-06-25 17:57:31.377922
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert '' not in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0
    assert 'Basic' not in auth_type_lazy_choices_0
    assert 'basicAuth' not in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'digestAuth' not in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'hawkAuth' not in auth_type_lazy_choices_0
    assert 'jwt' in auth_type_lazy_choices_0
    assert 'JWT'

# Generated at 2022-06-25 17:57:39.191436
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='{auth_types}'.format(
        auth_types='|'.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys())
        )
    ),
    default=None,
    type=AuthPlugin.create,
    help='''
    Force HTTPie to use a specific authentication plugin.
    Useful primarily for plugins that aren't discovered automatically, such as
    "digest".

    ''',
    choices=_AuthTypeLazyChoices()
)


# Generated at 2022-06-25 17:57:51.562700
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert iter(auth_type_lazy_choices_0) == iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))


auth.add_argument(
    '--auth-type',
    default=BASIC_AUTH_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication plugin to use. By default, it's "basic" (i.e., HTTP Basic),
    but you may specify any installed plugin, such as "digest", "aws", "netrc",
    etc.

    '''
)

# Generated at 2022-06-25 17:58:00.337534
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_arg_0 = 'basic'
    str_arg_0_0 = auth_type_lazy_choices_0.__contains__(str_arg_0)
    str_arg_1 = 'Basic'
    str_arg_1_0 = auth_type_lazy_choices_0.__contains__(str_arg_1)
    str_arg_2 = 'BASIC'
    str_arg_2_0 = auth_type_lazy_choices_0.__contains__(str_arg_2)
    boolean_arg_0 = str_arg_0_0
    boolean_arg_1 = str_arg_1_0
    boolean_arg_2 = str_arg_2_

# Generated at 2022-06-25 17:58:13.014798
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # __iter__() of _AuthTypeLazyChoices
    x = list(auth_type_lazy_choices_0)
    # x: List[str] = ['encrypted', 'digest-demo', 'digest-legacy', 'digest', 'jwt-mac', 'jwt', 'kerberos', 'negotiate', 'ntlm-compat', 'ntlm', 'oauth1', 'password-base', 'spnego', 'wss']
    # verify the type of x
    try:
        assert isinstance(x, list) and all(isinstance(i, str) for i in x)
    except:
        print('Expected: List[str]')

# Generated at 2022-06-25 17:58:25.091146
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert_true('_auth' in var_0)
    assert_false('_auth' in auth_type_lazy_choices_0.__iter__())
    assert_true('_auth' in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:58:35.471205
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('basic')
    if var_2:
        print('True')
    else:
        print('False')


# Generated at 2022-06-25 17:58:42.293638
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=auth_type_lazy_choices,
    help=f'''
    The authentication method to use. The available types are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    If not provided, HTTPie will try to guess the authentication method
    from the --auth option.

    For more details, use the option's "help" subcommand:

        $ http --auth-type=TYPE --help

    '''
)


#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group

# Generated at 2022-06-25 17:58:50.859997
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('basic')
    assert var_2 == True

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The auth mechanism to be used. If not specified, a guess is made based
    on the provided --auth value.

    Available schemes are: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}.

    '''
)


#######################################################################
# HTTP(S) proxy
#######################################################################


# Generated at 2022-06-25 17:58:52.148242
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert callable(_AuthTypeLazyChoices)


# Generated at 2022-06-25 17:58:54.945974
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    string_0 = "basic"
    _AuthTypeLazyChoices_0 = _AuthTypeLazyChoices()
    var_0 = _AuthTypeLazyChoices_0.__contains__(string_0)
    assert var_0 == True


# Generated at 2022-06-25 17:58:56.961499
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _AuthTypeLazyChoices___contains__(
        _AuthTypeLazyChoices(),
        'plugin_manager'
    )


# Generated at 2022-06-25 17:58:57.916632
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# Generated at 2022-06-25 17:58:59.028630
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()

# Generated at 2022-06-25 17:59:00.032125
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:59:11.516271
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    global plugin_manager
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = auth_type_lazy_choices_0.__iter__()
    print(var_0)
    print(var_1)


# Generated at 2022-06-25 17:59:20.050068
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__iter__()
    var_3 = iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    var_4 = auth_type_lazy_choices_0.__iter__()
    var_5 = iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    var_6 = auth_type_lazy_choices_0.__contains__('digest')
    var_7 = 'digest' in plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-25 17:59:28.742137
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('Basic')

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify a custom authentication plugin to use.
    All built-in authentication plugins are:

    - basic
    - digest

    Alternatively, specify the path to a custom authentication plugin.
    For example: --auth-type=~/.local/lib/httpie/auth.py

    '''
)

# Generated at 2022-06-25 17:59:29.542208
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

# Generated at 2022-06-25 17:59:40.921296
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('')

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a specified auth plugin for the request, e.g., "digest",
    "jwt".

    '''
)


#######################################################################
# HTTP method
#######################################################################

method = parser.add_argument_group(title='HTTP Method')

# Generated at 2022-06-25 17:59:51.219521
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('')


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used (e.g., "basic"). If no
    type is specified, then an appropriate one is automatically selected.

    Use the `--debug` option to get a list of all the supported types.

    '''
)

# Generated at 2022-06-25 17:59:53.917031
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj_0 = _AuthTypeLazyChoices()
    var_0 = obj_0.__contains__(None)
    assert var_0 == False


# Generated at 2022-06-25 17:59:56.667383
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(1)


# Generated at 2022-06-25 18:00:08.415001
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = plugin_manager.AuthPluginManager()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    if not (auth_type_lazy_choices_0.__iter__() == plugin_manager.AuthPluginManager().get_auth_plugin_mapping()):
        raise AssertionError


_AUTH_TYPE_LAZY_CHOICES = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:00:18.275774
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj_0 = _AuthTypeLazyChoices()
    assert obj_0.__contains__("digest")

# Generated at 2022-06-25 18:00:42.125089
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__("*")
    var_3 = auth_type_lazy_choices_0.__contains__("*")
    var_4 = auth_type_lazy_choices_0.__contains__("*")
    var_5 = auth_type_lazy_choices_0.__contains__("*")
    assert(var_2 == var_3)
    assert(var_2 == var_4)
    assert(var_2 == var_5)


# Generated at 2022-06-25 18:00:54.383398
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__iter__()
    var_3 = auth_type_lazy_choices_0.__iter__()


auth_plugin_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    default='auto',
    choices=auth_plugin_choices,
    help=f'''
    Choose an authentication mechanism. Available:

        {', '.join(auth_plugin_choices)}

    The default is "auto", which means that the authentication mechanism will
    be inferred from the provided credentials, if possible.

    '''
)

# httpbin.org itself doesn't require auth by default,
# but it's automatically installed

# Generated at 2022-06-25 18:01:03.783662
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    var_1 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:01:09.213561
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = auth_type_lazy_choices_0.__iter__()


# NOTE: We use a custom action class here because we want to use the
#       'choices' argument in __call__, which is only available there.

# Generated at 2022-06-25 18:01:21.339368
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Constructor for unit testing
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''

    The type of the auth mechanism. Currently supported:

        {plugins_list}

    '''.format(
        plugins_list=', '.join(
            sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    )
)

# Generated at 2022-06-25 18:01:29.775824
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    __contains__ = _AuthTypeLazyChoices.__contains__
    assert(False not in _AuthTypeLazyChoices())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help=f'''
    The type of HTTP authentication to perform. By default, HTTPie attempts to
    detect it automatically. Supported types:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# Generated at 2022-06-25 18:01:41.858322
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:01:51.088541
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to use. Defaults to "basic".

    Available types:

        %(choices)s

    Use the `--auth-type help <type>` to get more detailed help. For example:

        %(prog)s --auth-type help digest

    '''
)

# Generated at 2022-06-25 18:02:02.961846
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')
    assert var_0 == True, 'var_0 is: ' + str(var_0)

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='Override the auth plugin used.'
)
auth.add_argument(
    '--auth-host',
    metavar='AUTH_HOST',
    default=DEFAULT_AUTH_HOST,
    help='The host to use when resolving the auth plugin.'
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add

# Generated at 2022-06-25 18:02:03.899988
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:02:42.555038
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_3 = _AuthTypeLazyChoices()
    var_4 = var_3.__contains__(None)


# Generated at 2022-06-25 18:02:52.755691
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_2.__iter__()


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism by the name of an auth plugin. Currently
    supported: {0}.

    '''.format(', '.join(plugin_manager.get_auth_plugin_mapping()))
)


# Generated at 2022-06-25 18:02:57.630587
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("")

from tests.utils import unit_test

# Generated at 2022-06-25 18:03:06.574128
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify an auth mechanism. These are the supported values:

        {list_of_auth_types()}

    '''
)

#######################################################################
# Config
#######################################################################

config_location_validator = ConfigFileLocationValidator(
    'Only one configuration file may be specified.'
)

config = parser.add_argument_group(title='Configuration')

# Generated at 2022-06-25 18:03:16.051417
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_2 = auth_type_lazy_choices_0.__contains__('ntlm')
    assert var_2 == True

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default value, "auto", tells
    HTTPie to automatically determine which mechanism to use based on the URL
    and the server response.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 18:03:26.728941
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type', '-t',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified HTTP authentication mechanism.
    ''',
)

#######################################################################
# Response Output
#######################################################################

parser.add_argument(
    '--verify', '-k',
    action='store_true',
    default=True,
    help='''
    (default) Secure Requests: verify SSL certificates.

    '''
)

# Generated at 2022-06-25 18:03:29.186766
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_2 = _AuthTypeLazyChoices()
    assert var_2.__contains__(None)


# Generated at 2022-06-25 18:03:37.987623
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_3 = _AuthTypeLazyChoices()
test__AuthTypeLazyChoices()


# Generated at 2022-06-25 18:03:40.705463
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_0.__contains__('') == plugin_manager.get_auth_plugin_mapping().__contains__(''))


# Generated at 2022-06-25 18:03:43.704891
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test class variables and methods
    assert hasattr( _AuthTypeLazyChoices, '__contains__' )
    # Test instance methods
    var_0 = _AuthTypeLazyChoices()
    test_case_0()
    pass

