

# Generated at 2022-06-25 17:54:34.013989
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert \
        (
            'basic' in _AuthTypeLazyChoices()
        )


# Generated at 2022-06-25 17:54:45.168756
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    dest='auth_plugin',
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    action=_EchoPluginNameAction,
    help=f'''
    Use the specified plugin (instead of guessing).

    {get_auth_plugin_help()}

    '''
)

#######################################################################
# Client-side SSL/TLS verification
#######################################################################

ssl = parser.add_argument_group(title='Client-side SSL/TLS verification')

# Generated at 2022-06-25 17:54:47.963290
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert ('basic' in auth_type_lazy_choices_0) == (True)


# Generated at 2022-06-25 17:54:58.570967
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    assert 'bearer' in obj



# Generated at 2022-06-25 17:55:05.390371
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    authtype_mapping = plugin_manager.get_auth_plugin_mapping()
    assert_equal(set(authtype_mapping), set(_AuthTypeLazyChoices()))
    assert_true(all(key in _AuthTypeLazyChoices() for key in authtype_mapping))


auth.add_argument(
    '--auth-type',
    dest='auth_type',
    default=None,
    help='''
    The auth protocol/scheme to use.

    The value is case-insensitive.

    The default is "basic" if --auth is provided,
    or empty string (no auth) otherwise.

    The available auth protocols are:

    '''.strip(),
    choices=_AuthTypeLazyChoices()
)

#######################################################################
# https://github.com/jakubro

# Generated at 2022-06-25 17:55:10.350065
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices
    assert 'digest' in auth_type_lazy_choices


# Generated at 2022-06-25 17:55:14.114481
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    res = tuple(iter(obj))
    assert isinstance(res, tuple)
    assert len(res) == 4
    assert res == ('digest', 'hmac', 'jwt', 'oauth1')


# Generated at 2022-06-25 17:55:19.286416
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    result = iter(auth_type_lazy_choices_1).__contains__('basic')
    assert result is True


# Generated at 2022-06-25 17:55:23.501781
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices
    for x in auth_type_lazy_choices:
        assert 'basic' in x


# Generated at 2022-06-25 17:55:30.058638
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # __class__ reference to class _AuthTypeLazyChoices
    class_reference = _AuthTypeLazyChoices
    test_case_0()
    class_reference.__contains__ = _AuthTypeLazyChoices.__contains__
    class_reference.__iter__ = _AuthTypeLazyChoices.__iter__

plugin_auth_kwargs = parser.add_argument_group(title='Auth Plugin Options')
# TODO: generate this dynamically.


# Generated at 2022-06-25 17:55:35.141533
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    # Call method
    var = iter(obj)


# Generated at 2022-06-25 17:55:36.991632
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:39.258328
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert (1, False) == (1, 'basic' in _AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:42.182858
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())


# Generated at 2022-06-25 17:55:50.885617
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    class MockPluginManager(object):
        def get_auth_plugin_mapping(self_):
            return {}
    try:
        plugin_manager_0 = MockPluginManager()
        try:
            _AuthTypeLazyChoices__iter___comprehension = [_AuthTypeLazyChoices__iter___comprehension for _AuthTypeLazyChoices__iter___comprehension in _AuthTypeLazyChoices().__iter__()]
        except TypeError:
            return
        assert False
    finally:
        plugin_manager = plugin_manager_0


# Generated at 2022-06-25 17:55:57.344730
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert ('basic' in _AuthTypeLazyChoices()) == True
    assert ('digest' in _AuthTypeLazyChoices()) == True
    assert ('krb5' in _AuthTypeLazyChoices()) == True
    assert ('gssapi' in _AuthTypeLazyChoices()) == True
    assert ('negotiate' in _AuthTypeLazyChoices()) == True
    assert ('ntlm' in _AuthTypeLazyChoices()) == True


# Generated at 2022-06-25 17:56:08.435639
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    r = _AuthTypeLazyChoices.__iter__(test_case_0.auth_type_lazy_choices_0)
    assert r


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.  If the `auto` option is chosen,
    the authentication mechanism is automatically detected.

    '''
)
auth.add_argument(
    '--auth-host',
    help='''
    The hostname from the request URL to be used in the `Host` header
    used for Basic and Digest auth.

    '''
)

# Generated at 2022-06-25 17:56:12.402061
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    CHECK_BEFORE = set()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    CHECK_AFTER = set()
    assert CHECK_BEFORE == CHECK_AFTER


# Generated at 2022-06-25 17:56:22.468347
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    t0_0 = _AuthTypeLazyChoices()
    t0_1 = ['Basic']
    t0_1 = [t0_1[i] for i in range(len(t0_1))]
    def __getattr__(name):
        return locals()[name]
    def __init__(self):
        pass
    def append(value):
        t0_2 = t0_0.__iter__()
        while True:
            try:
                t0_3 = next(t0_2)
            except StopIteration:
                break
            t0_1.append(t0_3)
        return None
    def __len__():
        return len(t0_1)
    def __getitem__(index):
        return t0_1[index]
    return __init__

# Generated at 2022-06-25 17:56:26.447549
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    words = set()
    for i in range(0, 10):
        words.add(str(i) * random.randint(0, 100))
    for word in words:
        if (word in auth_type_lazy_choices_0):
            auth_type_lazy_choices_0.add(word)


# Generated at 2022-06-25 17:56:44.865793
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Run a test case
    test_case_0()


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=DEFAULT_AUTH_PLUGIN,
    help=f'''
    Authentication method. The default is {DEFAULT_AUTH_PLUGIN}. Use
    --auth-type=help to get a list of available authentication methods.

    '''
)
auth.add_argument(
    '--auth-type=help',
    action='store_true',
    help=f'''
    Show a list of available authentication methods.

    '''
)

# Generated at 2022-06-25 17:56:46.933835
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    if DEFAULT_AUTH_PLUGIN_NAME in _AuthTypeLazyChoices():
        pass
    else:
        raise Exception('Unable to find default authentication scheme')


# Generated at 2022-06-25 17:56:48.130804
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'digest' in _AuthTypeLazyChoices()



# Generated at 2022-06-25 17:56:50.628526
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert (
        'digest' in _AuthTypeLazyChoices()
    )


# Generated at 2022-06-25 17:57:04.004698
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use. Only relevant when the username
    and password are specified.

    The default ('') behavior is to detect the authentication type automatically.
    Currently supported authentication types are:

        {auth_types}

    '''.format(
        auth_types='\n'.join(
            [8 * ' ' + ', '.join(group)]
            for group in chunks(
                sorted(plugin_manager.get_auth_plugin_mapping().keys()),
                3
            )
        )
    )
)
auth.add_argument

# Generated at 2022-06-25 17:57:07.587761
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    
    return_value_0 = auth_type_lazy_choices.__contains__(1)
    assert return_value_0 == 0
    
    return_value_1 = auth_type_lazy_choices.__contains__(2)
    assert return_value_1 == 0


# Generated at 2022-06-25 17:57:08.476524
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert "netrc" in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:19.884548
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from _pytest.monkeypatch import MonkeyPatch
    from httpie.plugins import AuthPlugin
    from httpie.context import Environment
    from httpie.plugins import plugin_manager
    from httpie.auth import AuthCredentials

    class TestPlugin(AuthPlugin):
        auth_type = 'test'

        def get_auth(self, username=None, password=None):
            yield 'Test header', 'Test value'

    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(plugin_manager, 'get_auth_plugin_mapping', lambda: {'test': TestPlugin})
    auth = parser.add_argument_group(title='Authentication')

# Generated at 2022-06-25 17:57:24.152519
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert (('key', 'value') in plugin_manager.get_auth_plugin_mapping()) == (
        'key' in _AuthTypeLazyChoices()
    )


# Generated at 2022-06-25 17:57:26.249598
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(auth_type_lazy_choices_0) == []


# Generated at 2022-06-25 17:57:51.869462
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    expected = (plugin_manager.get_auth_plugin_mapping().keys())
    actual = _AuthTypeLazyChoices().__iter__()
    assert sorted(expected) == sorted(actual)

auth.add_argument(
    '--auth-type',
    help='''
    Choose the authentication mechanism: basic or digest
    (default: basic)

    ''',
    choices=_AuthTypeLazyChoices()
)

auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    Host to use for authentication. By default, the host of the destination
    URL is used.

    '''
)

#######################################################################
# Serialization
#######################################################################

serialization = parser.add_argument_group(title='Serialization')

serialization.add

# Generated at 2022-06-25 17:57:55.807279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    arg = 'Dummy'
    expected_ret = False
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    ret = auth_type_lazy_choices_0.__contains__(arg)
    assert ret == expected_ret


# Generated at 2022-06-25 17:58:01.245485
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Assigning to variable 'test_case_0' from outer scope
    # Assigning to variable 'auth_type_lazy_choices_0' from outer scope
    # Assigning to variable 'auth_type_lazy_choices_0' from outer scope
    # Assigning to variable 'auth_type_lazy_choices_0' from outer scope

    assert 'colon' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:58:13.864034
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='Authentication type.'
)
auth.add_argument(
    '--auth-host',
    default=AUTH_HOST_DEFAULT,
    help='''
    Auth host to use for the various authentication schemes (default is
    {auth_host_default}). This option supports parsing of IPv6 addresses.

    '''.format(
        auth_host_default=AUTH_HOST_DEFAULT,
    )
)

# Generated at 2022-06-25 17:58:15.179834
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:58:19.939099
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert callable(getattr(_AuthTypeLazyChoices, "__iter__"))
    # Call the method with a positional argument
    assert hasattr(getattr(_AuthTypeLazyChoices, "__iter__"), "__call__")
    iterator = _AuthTypeLazyChoices.__iter__()
    assert hasattr(iterator, "__iter__")


# Generated at 2022-06-25 17:58:27.197807
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import unittest
    class Test_AuthTypeLazyChoices(unittest.TestCase):
        def test__AuthTypeLazyChoices(self):
            assert True == ('hmac' in _AuthTypeLazyChoices())
    test_suite = unittest.TestLoader().loadTestsFromTestCase(Test_AuthTypeLazyChoices)
    unittest.TextTestRunner(verbosity=2).run(test_suite)

auth.add_argument(
    '--auth-type',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select an authentication mechanism. Default is "basic".
    When set to "help", a list of all built-in and imported
    mechanisms is printed.

    ''',
)

# Global default auth credentials.
#

# Generated at 2022-06-25 17:58:35.935162
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    mock_plugin_manager = MagicMock()
    mock_plugin_manager.get_auth_plugin_mapping.return_value = {
        'foo': 'bar',
        'baz': 'qux',
    }
    with patch('httpie.cli.argtypes._AuthTypeLazyChoices.plugin_manager', new=mock_plugin_manager):
        assert list(_AuthTypeLazyChoices()) == ['baz', 'foo']
        mock_plugin_manager.get_auth_plugin_mapping.assert_called_with()
        assert mock_plugin_manager.get_auth_plugin_mapping.call_count == 1


# Generated at 2022-06-25 17:58:42.365529
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used, e.g. 'basic'.
    You can use this option multiple times.
    Use `--auth-type=help' to get a list of available types.

    '''
)
auth.add_argument(
    '--auth-type-help',
    action='store_true',
    dest='auth_type_help',
    help='''
    Get a list of available authentication types.

    '''
)

#######################################################################
# TLS client
#######################################################################



# Generated at 2022-06-25 17:58:47.688939
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    (
        choose_auth_type,
        test_description,
        expected_output
    ) = test_cases["test__AuthTypeLazyChoices___contains__"]

    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    actual_output = auth_type_lazy_choices_0.__contains__(choose_auth_type)
    assert actual_output == expected_output


# Generated at 2022-06-25 17:59:19.022333
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = (_AuthTypeLazyChoices())
    assert auth_type_lazy_choices_0.__contains__('mock') == True


# Generated at 2022-06-25 17:59:28.111766
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except Exception:
        print("Test case 0 failed")
    else:
        print("Test case 0 passed")


auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:

    {auth_types}

    '''.format(
        auth_types=
            ', '.join('{0}{1}'.format(8 * ' ', a)
                      for a in sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-25 17:59:33.441193
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    t_choice_=test_case_0()
    assert isinstance(t_choice_,_AuthTypeLazyChoices)
test__AuthTypeLazyChoices()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='PLUGIN',
    choices=auth_type_lazy_choices,
    dest='auth_type',
    help='''
    Specify an auth plugin.
    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')


# Generated at 2022-06-25 17:59:43.477003
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    _iter_0 = iter(auth_type_lazy_choices_0)
    try:
        while True:
            _next_0 = next(_iter_0)
            pass
    except StopIteration:
        pass

auth.add_argument(
    '--auth-type', '--auth-type',
    metavar='',
    default=AUTH_PLUGIN_DEFAULT,
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help='''
    Choose an authentication plugin for the request.
    Uses the plugin specified by {default_auth_plugin} by default.

    '''.format(default_auth_plugin=AUTH_PLUGIN_DEFAULT)
)
auth

# Generated at 2022-06-25 17:59:45.180401
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:59:53.431198
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    auth_type_lazy_choices_0_dict_0 = {}
    auth_type_lazy_choices_0_dict_0['0'] = '!'
    auth_type_lazy_choices_0_dict_0['1'] = '"'
    auth_type_lazy_choices_0_dict_0['2'] = '#'
    auth_type_lazy_choices_0_dict_0['3'] = '$'
    auth_type_lazy_choices_0_dict_0['4'] = '%'
    auth_type_lazy_choices_0_dict_0['5'] = '&'
    auth_type_lazy_choices_0_dict_0

# Generated at 2022-06-25 18:00:03.885087
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='basic',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.

    Plugins can be used to implement custom auth types.
    The built-in auth types are:

        {auth_types}

    '''.format(
        auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 18:00:07.528385
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'jwt' in auth_type_lazy_choices_0


# Generated at 2022-06-25 18:00:11.129160
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for name in auth_type_lazy_choices_0:
        assert plugin_manager.get_auth_plugin_mapping().get(name) != None


# Generated at 2022-06-25 18:00:12.068953
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:00:56.047879
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. By default, it is determined
    automatically based on the provided credentials (--auth option).

    The supported types are:

        {0}

    '''.format(
        ', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    )
)

# Generated at 2022-06-25 18:01:01.891389
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter___0 = _AuthTypeLazyChoices()
    _AuthTypeLazyChoices___iter___1 = None
    _AuthTypeLazyChoices___iter___0.__iter__()

auth.add_argument(
    '--auth-type',
    '-t',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help='''
    The name of an authentication plugin (e.g., "basic", "digest") to use.

    ''',
)


# Generated at 2022-06-25 18:01:02.803141
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:01:09.002842
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import lists
    from hypothesis.strategies import sampled_from
    from hypothesis.strategies import dictionaries
    from hypothesis.strategies import characters
    from hypothesis.strategies import integers
    from hypothesis.strategies import binary
    from hypothesis.strategies import floats
    from hypothesis.strategies import booleans
    from hypothesis.strategies import tuples
    from hypothesis.strategies import none
    from hypothesis.strategies import one_of
    from hypothesis.strategies import composite

    @composite
    def none_of_iter(draw, elements):
        return draw(elements)

    @composite
    def one_of_iter(draw, elements):
        return draw(elements)

   

# Generated at 2022-06-25 18:01:12.805746
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(auth_type_lazy_choices_0)


# Generated at 2022-06-25 18:01:23.368426
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert hasattr(auth_type_lazy_choices_0, '__iter__') and callable(getattr(auth_type_lazy_choices_0, '__iter__'))
    assert hasattr(auth_type_lazy_choices_0, '__contains__') and callable(getattr(auth_type_lazy_choices_0, '__contains__'))

    assert hasattr(auth_type_lazy_choices_0, '__iter__')
    assert (auth_type_lazy_choices_0.__iter__() is not None)


# Generated at 2022-06-25 18:01:30.909803
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    item_0 = 'basic'
    var_0 = auth_type_lazy_choices_0.__contains__(item_0)


# Generated at 2022-06-25 18:01:43.131351
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    default='auto',
    type=AuthPluginAuto,
    help='''
    The authentication type to be used, e.g. basic.

    '''
)

auth.add_argument(
    '--auth-endpoint',
    type=AuthCredentialsEndpoint,
    metavar='URL',
    help='''
    Endpoint for HTTPie to obtain the auth credentials from.
    If not specified, the URL of the current request is used.

    '''
)

#######################################################################
# HTTP method
#######################################################################

method = parser.add

# Generated at 2022-06-25 18:01:51.797138
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices.__iter__() is not None


# Generated at 2022-06-25 18:02:03.944882
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert 'basic' in var_0


# Generated at 2022-06-25 18:03:14.161706
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert True


# Generated at 2022-06-25 18:03:16.966225
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:03:27.628032
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0.__iter__(), types.GeneratorType)

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    dest='auth_type',
    metavar='TYPE',
    type=AuthCredentials.validate_type,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication type to be used.

    ''',
)

# Generated at 2022-06-25 18:03:32.241504
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = isinstance(var_0, Iterator)
    assert(var_1)


# Generated at 2022-06-25 18:03:33.333741
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:03:40.494824
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    expected_var_0 = iter(sorted(plugin_manager.get_auth_plugin_mapping().keys()))
    assert var_0 == expected_var_0

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    type=plugin_manager.make_auth_plugin_validator(
        'Auth type',
        'auth_type'
    ),
    help='''
    Force the specified auth mechanism.

    '''
)

# Generated at 2022-06-25 18:03:50.599715
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert hasattr(test_case_0, "__wrapped__")
    assert type(test_case_0.__wrapped__) == getattr.__wrapped__

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin. Implies --auth.
    Use `http --auth-type=digest --help` for details.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    help='''
    Force ignoring .netrc file.

    '''
)

# Generated at 2022-06-25 18:03:53.563460
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 18:04:01.696557
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication mechanism.

    Plugins are available to support the auth types below.
    Install the extra dependencies to enable corresponding plugin.

    ''',
)
auth.add_argument(
    '--auth-plugin',
    default=None,
    help='''
    Specify the auth plugin to use.

    Format: <module>.<name>

    Plugins are loaded from the plugin directory listed in the
    configuration. See the `--plugin-dir` option.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')



# Generated at 2022-06-25 18:04:10.886986
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str())

auth.add_argument(
    '--auth-type',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Currently supported:

        {0}

    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')