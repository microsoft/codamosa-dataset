

# Generated at 2022-06-25 17:54:41.737762
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Tests calling the code inside of the iter method.
    # See: https://github.com/jakubroztocil/httpie/issues/1529
    assert next(iter(test_case_0.auth_type_lazy_choices_0)) == 'bearer'


# Generated at 2022-06-25 17:54:49.770523
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    print('test_case_0: %s' % test_case_0())
    print('test__AuthTypeLazyChoices___contains__(): %s' % auth_type_lazy_choices_0.__contains__(None))


# Generated at 2022-06-25 17:54:55.618886
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(iter(auth_type_lazy_choices_0), collections.abc.Iterator)
    assert isinstance(iter(auth_type_lazy_choices_0), collections.abc.Iterable)


# Generated at 2022-06-25 17:55:00.726296
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        for arg0 in auth_type_lazy_choices_0:
            pass
        print('PASSED: for arg0 in auth_type_lazy_choices_0')
    except StopIteration:
        print('FAILED: for arg0 in auth_type_lazy_choices_0')


# Generated at 2022-06-25 17:55:03.936495
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__('') == False


# Generated at 2022-06-25 17:55:09.399723
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'aws4-hmac-sha256' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:11.486371
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    except:
        return False

    return True


# Generated at 2022-06-25 17:55:18.476504
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    iterator = auth_type_lazy_choices_0.__iter__()
    assert isinstance(iterator, collections.abc.Iterator)
    assert iterator == iter(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:55:22.727138
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Asserts that a sequence with the elements equal to the given sequence is contained
    assert 'bearer' in auth_type_lazy_choices_0
    # Assert that the given condition is not satisfied
    assert 'bearer1' not in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:26.726752
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_0.__contains__('asap')) == assert_boolean


# Generated at 2022-06-25 17:55:30.922098
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert iter(auth_type_lazy_choices_0) == iter(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:55:42.972390
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert (auth_type_lazy_choices_0.__contains__('basic') == True)
    assert (auth_type_lazy_choices_0.__contains__('bearer') == True)
    assert (auth_type_lazy_choices_0.__contains__('digest') == True)
    assert (auth_type_lazy_choices_0.__contains__('hmac') == True)
    assert (auth_type_lazy_choices_0.__contains__('hawk') == True)


# Generated at 2022-06-25 17:55:48.117643
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        assert "value" in auth_type_lazy_choices_0
    except AssertionError:
        var = "value" not in auth_type_lazy_choices_0
        raise AssertionError(var)

# Generated at 2022-06-25 17:55:59.105843
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    x0 = _AuthTypeLazyChoices()
    y0 = list(x0)
    print(y0)
    assert('basic' in y0)
    assert('digest' in y0)
    assert('oauth1' in y0)
    assert('ntlm' in y0)
    assert('hmac' in y0)
    assert('aws' in y0)
    assert('hawk' in y0)
    assert(('aws4' or 'aws4-request') in y0)
    assert('bearer' in y0)
    assert('kerberos' in y0)
    assert(('kerberos-spnego' or 'negotiate') in y0)


# Generated at 2022-06-25 17:56:03.142198
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices__AuthTypeLazyChoices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices__AuthTypeLazyChoices_0.__class__ is _AuthTypeLazyChoices


# Generated at 2022-06-25 17:56:06.545605
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()
    # AssertionError
    except AssertionError:
        print("AssertionError")


# Generated at 2022-06-25 17:56:18.015935
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The type of auth plugin.

    Defaults to "{DEFAULT_AUTH_PLUGIN_NAME}".
    You can specify your own custom plugins.
    See https://httpie.org/plugins#authentication for more details.

    '''
)

auth.add_argument(
    '--auth-type=',
    action='store_const',
    const=None,
    help=SUPPRESS,
)

#######################################################################
# Miscellaneous
#######################################################################

misc = parser.add_argument_group(title='Miscellaneous')


# Generated at 2022-06-25 17:56:20.854432
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert httplib.HTTPConnection.getresponse in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:56:23.639362
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    print("start unit test for constructor of class _AuthTypeLazyChoices")
    # test case 0
    test_case_0()
    print("end unit test for constructor of class _AuthTypeLazyChoices")


# Generated at 2022-06-25 17:56:27.093894
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), _AuthTypeLazyChoices)
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:33.471494
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:39.743982
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    import httpie.plugins
    httpie.plugins.plugin_manager = PluginManager()
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'digest' in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:56:47.807564
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert next(iter(auth_type_lazy_choices_0)) == 'basic'
    assert next(iter(auth_type_lazy_choices_0)) == 'digest'
    assert next(iter(auth_type_lazy_choices_0)).startswith('hawk')
    assert next(iter(auth_type_lazy_choices_0)).startswith('ntlm')
    assert next(iter(auth_type_lazy_choices_0)).startswith('oauth1')


# Generated at 2022-06-25 17:57:01.435263
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0 == _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Use the specified authentication plugin.

    '''
)
# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-endpoint',
    metavar='URL',
    help='''
    URL of the authentication endpoint, e.g.
    https://example.org/authorizations/new

    '''
)
auth.add_argument(
    '--auth-env',
    metavar='ENVVAR',
    help='''
    Environment variable containing JSON dictionary with the initial auth
    request data.

    '''
)
auth.add

# Generated at 2022-06-25 17:57:04.285564
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    obj = _AuthTypeLazyChoices()
    item = unittest.mock.Mock()
    result = obj.__contains__(item)
    return result

# Generated at 2022-06-25 17:57:09.479788
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices_0) == ['digest', 'jwt', 'mal-digest', 'malformed-digest', 'multi-auth-preferred', 'multi-auth-required', 'multiauth-required', 'oauth1', 'oauth2', 'oauth2-implicit', 'token']


# Generated at 2022-06-25 17:57:13.420820
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # __contains__ is implemented as a __contains__ of a plugin_manager
    assert 'Basic' in auth_type_lazy_choices_0
    # check the case when there is no such key in a plugin_manager
    assert 'no_key' not in auth_type_lazy_choices_0



# Generated at 2022-06-25 17:57:15.498069
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:18.985114
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    for item in auth_type_lazy_choices_0:
        if True:
            assert item in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:57:24.263916
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        test_case_0()
    except:
        assert False
        print('Assertion failed')
    else:
        print('Assertion passed')



# Generated at 2022-06-25 17:57:37.304870
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify a custom authentication plugin to use.

    Available plugins are: %(choices)s

    If the --auth-type option is given, the default --auth option value is
    ignored.

    Use the following to see what options a plugin supports:

        http --auth-type=<TYPE> --help

    '''
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:57:39.191988
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 17:57:51.562433
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    pass


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth plugin to use (defaults to the detected one, or it
    can be auto-detected from the user/password input).

    Use `--auth-type=auto' to explicitly auto-detect the auth plugin,
    which is the default behaviour.

    Use `--auth-type=basic' for Basic Auth,
    `--auth-type=digest' for Digest Auth,
    `--auth-type=oauth1' for OAuth 1,
    etc.

    See https://httpie.org/docs#authentication for more information.

    ''',
)


# Generated at 2022-06-25 17:57:57.670750
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    new_object = _AuthTypeLazyChoices()
    assert new_object is not None

auth.add_argument(
    '--auth-type', '-t',
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. The default is basic, which depens on your
    username and password.

    ''',
    choices=_AuthTypeLazyChoices(),
    default='basic'
)
auth.add_argument(
    '--auth-nonce', '-n',
    type=int,
    metavar='NONCE',
    help='''
    A number for creating the authentication.
    ''',
    default=0
)

# Generated at 2022-06-25 17:58:10.409771
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    val_0 = _AuthTypeLazyChoices()
    __tracebackhide__ = True
    assert val_0.__contains__('basic') == True

    __tracebackhide__ = True
    assert val_0.__contains__('not-basic') == False



# Generated at 2022-06-25 17:58:20.582095
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Create a new instance of _AuthTypeLazyChoices
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    # Iterate over the instance and print the values
    for var in auth_type_lazy_choices:
        print(var)
    # Create a new instance of _AuthTypeLazyChoices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Assign to var the next item in the iterator
    var_0 = next(auth_type_lazy_choices_0.__iter__())
    # Assert len(var_0) == 11
    assert len(var_0) == 11
    # Assign to var_0 the next item in the iterator

# Generated at 2022-06-25 17:58:33.498701
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = auth_type_lazy_choices_0.__iter__()
    var_2 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='Authentication mechanism.'
)
auth.add_argument(
    '--proxy-auth', '-pa',
    default=None,
    metavar='USER[:PASS]',
    help='''
    If only the username is provided, HTTPie will prompt for the password.

    '''
)
auth

# Generated at 2022-06-25 17:58:39.262797
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='Authentication type to use (for plugins).'
)
auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='Do not prompt for authentication if 401 is received.'
)

#######################################################################
# Cookies
#######################################################################

cookies = parser.add_argument_group(title='Cookies')



# Generated at 2022-06-25 17:58:49.258727
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''

    If the auth mechanism is different than Basic or Digest, use this option
    to specify a custom auth type.

    You can register custom auth plugins by using the `httpie-auth-plugin`
    entry point.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:58:53.833146
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        result_0 = auth_type_lazy_choices_0.__contains__('digest')
    except Exception as e:
        print(str(e))
    print(result_0)


# Generated at 2022-06-25 17:59:11.036931
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Testing __iter__
    var_0 = auth_type_lazy_choices_0.__iter__()
    # Testing __contains__
    var_1 = auth_type_lazy_choices_0.__contains__(var_0)

# Checked



# Generated at 2022-06-25 17:59:20.740420
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert getattr(auth_type_lazy_choices_0, '__init__')() is None
    assert auth_type_lazy_choices_0.__iter__() == []
    assert auth_type_lazy_choices_0.__iter__() != ['']
    assert auth_type_lazy_choices_0.__iter__() != ['abc']
    assert auth_type_lazy_choices_0.__iter__() != ['[0,1,2,3,4]']
    assert auth_type_lazy_choices_0.__iter__() != ['[]']
    assert auth_type_lazy_choices_0.__iter__() != ['{}']
    assert auth_type_lazy_choices_0.__iter__() != ['a:b']
   

# Generated at 2022-06-25 17:59:23.301996
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    return auth_type_lazy_choices_0


# Generated at 2022-06-25 17:59:30.511628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN.get_auth_type(),
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication plugin used. Defaults to "{DEFAULT_AUTH_PLUGIN.get_auth_type()}".
    Can be one of: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}.
    For more information: {PLUGINS_DOC_URL}#authentication-plugins

    '''
)


# Generated at 2022-06-25 17:59:41.656127
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the type of the auth plugin.

    '''
)
auth.add_argument(
    '--auth-host',
    default=None,
    help='''
    The host for which to apply this authentication method.
    This affects the URL prefix for which the auth plugin is applied.

    '''
)

# Generated at 2022-06-25 17:59:51.619623
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    # The next line tests constructor of class _AuthTypeLazyChoices
    var_1 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''\
    The authentication mechanism.

    The default 'auto' value picks the most secure mechanism
    based on the provided credentials.

    ''',
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use netrc for loading the credentials (unless required by --auth-type).

    '''
)

# It's important the default value is `

# Generated at 2022-06-25 17:59:55.033462
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    print(var_0)


# Generated at 2022-06-25 17:59:55.630670
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    pass


# Generated at 2022-06-25 17:59:59.739188
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    item_0 = '__contains__'.lower()
    var_0 = auth_type_lazy_choices_0.__contains__(item_0)



# Generated at 2022-06-25 18:00:03.989215
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_1.__contains__('_auth_plugin_dummy')
    assert var_1 == True


# Generated at 2022-06-25 18:00:21.041060
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:00:21.896748
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:00:34.427161
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # Create an instance of the class
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Assign var_0 to __iter__
    var_0 = auth_type_lazy_choices_0.__iter__()
    # Make the assertion
    assert [x in var_0 for x in ['negotiate', 'basic', 'digest']]
    # Create an instance of the class
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    # Assign var_1 to __contains__
    var_1 = auth_type_lazy_choices_1.__contains__('digest')


# Generated at 2022-06-25 18:00:38.478607
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        var_0 = auth_type_lazy_choices_0.__iter__()
        try:
            var_0.__next__()
        except StopIteration:
            pass
        else:
            raise RuntimeError
    except:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-25 18:00:39.121683
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:00:50.475287
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__('rfc7617')
    except Exception as e:
        print(e)
    var_1 = auth_type_lazy_choices_0.__contains__('rfc')
    var_2 = auth_type_lazy_choices_0.__contains__('abc')
    var_3 = auth_type_lazy_choices_0.__contains__('mock')

    assert var_0 == True
    assert var_1 == False
    assert var_2 == False
    assert var_3 == True


# Generated at 2022-06-25 18:01:00.095428
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
    except Exception as e:
        print(e)

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism.

    Currently supported auth types: {0}


    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

# Generated at 2022-06-25 18:01:04.187876
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    args = [[], [], []]
    arg_types = ['__init__']
    ret_type = None
    for arg, arg_type in zip(args, arg_types):
        with pytest.raises(TypeError, match='.*missing.*required positional.*'):
            test_case_0()


# Generated at 2022-06-25 18:01:14.046661
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # For coverage.
    _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Supported:
    {supported}
    '''
        .format(
        supported='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in
            wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys())),
                width=60)
        ).strip()
    )
)

#######################################################################
# SSL
#######################################################################



# Generated at 2022-06-25 18:01:25.784262
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(plugin_manager.get_auth_plugin_mapping().keys()) > 0

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    help='''
    The authentication mechanism to be used. The available types are HTTP
    Basic and Digest, which are provided by the Python standard library,
    and the ones registered as plugins by the installed third-party
    extensions.

    The default is 'auto' which will determine the best plugin to use based
    on the location of the server, the existence of a password, and the
    capabilities of the plugins.

    '''
)

#######################################################################
# HTTP(S) Proxy
#######################################################################

proxy = parser.add_argument_group(title='HTTP(S) Proxy')


# Generated at 2022-06-25 18:02:03.038426
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    # Test when item is in iteration of __iter__()
    var_3 = auth_type_lazy_choices_2.__contains__('digest')


# Generated at 2022-06-25 18:02:04.288882
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()




# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 18:02:13.317458
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to be used. By default, HTTPie looks for the correct
    auth plugin based on the the Netrc entry or the HTTP auth challenge,
    but you can use this flag to specify the auth mechanism explicitly.

    The available auth types depend on the installed plugins.

    '''
)
auth.add_argument(
    '--auth-endpoint',
    dest='auth_endpoint',
    default=DEFAULT_AUTH_ENDPOINT,
    help='''
    Specify a custom authentication endpoint to be used by
    --auth-type=bearer_token.

    '''
)

# Generated at 2022-06-25 18:02:19.508497
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()
# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    metavar='BACKEND',
    choices=_AuthTypeLazyChoices(),
    help='''
    Select the authentication backend (plugin) to use. By default, HTTPie
    detects the auth type based on the provided credentials.

    If the BACKEND is 'auto' or unspecified, HTTPie tries to detect the auth
    type. This is useful when working with sites that use a combination of
    auth schemes.

    The available backends are:

    {plugin_help}

    '''
    .format(plugin_help=plugin_manager.get_auth_plugin_help())
)


# Generated at 2022-06-25 18:02:21.380184
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import pytest
    import sys
    import inspect

    # Load tests
    test_case_0()

    print('Unit test completed')

# Unit test entry point
if __name__ == '__main__':
    test__AuthTypeLazyChoices()

# Generated at 2022-06-25 18:02:33.801271
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    global plugin_manager
    plugin_manager = plugin_manager(AuthPluginManager())
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__contains__('basic')
    var_2 = var_0.__contains__('digest')
    var_3 = var_0.__contains__('hawk')
    var_4 = var_0.__contains__('ntlm')
    var_5 = var_0.__contains__('aws4-hmac-sha256')
    var_6 = var_0.__contains__('aws4-hmac-sha256-sigv4')
    var_7 = var_0.__contains__('oauth1a')
    var_8 = var_0.__contains__('oauth2')
    var

# Generated at 2022-06-25 18:02:44.684954
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    print(test_case_0())

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    default='basic',
    metavar='AUTH_PLUGIN',
    choices=test_case_0(),
    help='''
    The authentication plugin to be used. Run `http --help-auth` to see a list of
    all built-in plugins and their options.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_send_credentials_only_once',
    action='store_true',
    default=False,
    help='''
    Do not perform challenge response (send credentials only once).

    '''
)

# Generated at 2022-06-25 18:02:53.463520
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('--auth-type')
    assert var_0 == True


# Generated at 2022-06-25 18:02:57.105927
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    from types import GeneratorType
    assert type(test_case_0()) is GeneratorType
    assert test_case_0().__next__() == 'aws4'


# Generated at 2022-06-25 18:03:06.220344
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    type=plugin_manager.get_auth_plugin_mapping(),
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Select an authentication type to use. The default is "{'auto'}", i.e.,
    HTTPie figures out the correct auth type based on the scheme and netloc.

    All the registered auth types can be listed with:

        $ http --auth-type=help

    '''
)


# Generated at 2022-06-25 18:04:24.006990
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__iter__() is None

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    HTTP authentication type (Basic or Digest). The default is "auto",
    which causes HTTPie to first attempt Basic auth and then fall back to Digest
    if that fails with a 401 status code.

    ''',
)

# Generated at 2022-06-25 18:04:25.473800
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    print("Unit test for method __iter__ of class _AuthTypeLazyChoices")
    assert test_case_0()


# Generated at 2022-06-25 18:04:31.739892
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert not hasattr(plugin_manager, 'get_auth_plugin_mapping')
    assert not hasattr(plugin_manager, 'get_auth_plugin_mapping')
    assert not hasattr(plugin_manager, 'get_auth_plugin_mapping')
    assert not hasattr(plugin_manager, 'get_auth_plugin_mapping')
    assert not hasattr(plugin_manager, 'get_auth_plugin_mapping')


# Generated at 2022-06-25 18:04:37.364028
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_0.__contains__('')
    var_0 = var_1 is True
    try:
        assert var_0 is True
    except AssertionError:
        raise AssertionError('Test case 0 has failed')
