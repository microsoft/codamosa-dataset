

# Generated at 2022-06-25 17:54:38.469816
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(_AuthTypeLazyChoices(), collections.abc.Container)


# Generated at 2022-06-25 17:54:41.212093
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == ['aws', 'basic', 'digest', 'hawk', 'jwt', 'oauth1', 'oauth2']


# Generated at 2022-06-25 17:54:44.089805
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 'Basic' in _AuthTypeLazyChoices()
    assert 'Digest' in _AuthTypeLazyChoices()
    assert 'Custom' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:54:51.227849
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'basic' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    metavar='plugin',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The options depend on what
    plugins are installed and currently loaded.

    '''
)

auth.add_argument(
    '--auth-endpoint',
    dest='auth_endpoint',
    default=None,
    help='''
    The provided URL is used as an endpoint for attempting an authentication.

    If no URL is specified, then endpoint is taken from the URL of the
    request. This feature is useful with --auth-type=oauth2.

    '''
)


# Generated at 2022-06-25 17:55:01.484516
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    except:
        print('FAIL')
    else:
        print('SUCCESS')

test__AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help=f'''
    The type of auth credentials provided.

    The {DEFAULT_AUTH_PLUGIN} plugin is activated when --auth is used with
    username:password and no --auth-type is specified.
    {' '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}
    '''
)

# Generated at 2022-06-25 17:55:03.985192
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for x in auth_type_lazy_choices_0:
        pass


# Generated at 2022-06-25 17:55:06.776318
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for i in auth_type_lazy_choices_0:
        pass


# Generated at 2022-06-25 17:55:17.003404
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        _AuthTypeLazyChoices()
    except Exception:
        assert False

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of credentials to use for authentication.

    The default, "basic", is the standard HTTP Basic auth.

    Specify "digest" to use HTTP Digest auth.

    Specify a plugin name (e.g., "netrc", or "ntlm") to use a plugin.
    For more details, run "http --help-auth".

    ''',
)


#######################################################################
# HTTPS, proxies
#######################################################################

security = parser.add_argument_group(title='Security')

# Generated at 2022-06-25 17:55:20.418763
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert bool(auth_type_lazy_choices_0.__contains__('basic')) == bool('basic' in plugin_manager.get_auth_plugin_mapping())


# Generated at 2022-06-25 17:55:31.180530
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    __AuthTypeLazyChoices = _AuthTypeLazyChoices()
    assert 'basic' in __AuthTypeLazyChoices
    assert 'digest' in __AuthTypeLazyChoices
    assert 'hawk' in __AuthTypeLazyChoices
    assert 'aws4' in __AuthTypeLazyChoices
    assert 'aws4-hmac-sha256' in __AuthTypeLazyChoices
    assert 'aws4-hmac_sha256' in __AuthTypeLazyChoices
    assert 'aws4-signing-key' in __AuthTypeLazyChoices



# Generated at 2022-06-25 17:55:46.490667
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_1
    assert 'digest' in auth_type_lazy_choices_1
    assert 'hawk' in auth_type_lazy_choices_1

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str.lower,
    choices=_AuthTypeLazyChoices(),
    default='basic',
    help=f'''
    The authentication mechanism to be used.

    Currently, the following mechanisms are supported:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)


# Generated at 2022-06-25 17:55:57.792643
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _auth_tyle_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'basic' in _auth_tyle_lazy_choices_0
    assert 'digest' in _auth_tyle_lazy_choices_0
    assert 'hawk' in _auth_tyle_lazy_choices_0
    assert 'ntlm' in _auth_tyle_lazy_choices_0
    assert 'aws' in _auth_tyle_lazy_choices_0
    assert 'aws2' in _auth_tyle_lazy_choices_0
    assert 'kerberos' in _auth_tyle_lazy_choices_0
    assert 'aws-sigv4-test' in _auth_tyle_lazy_choices_0

#

# Generated at 2022-06-25 17:56:08.989341
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=AuthCredentialsInferrer(
        plugin_manager.get_auth_plugin_mapping()
    ),
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin.

    '''
)
auth.add_argument(
    '--auth-verify',
    action='store_true',
    default=False,
    help='''
    If the server requires authenticated requests, but no auth credentials
    were provided, abort. The default behaviour is to prompt for credentials.

    '''
)


#######################################################################
# Custom headers
#######################################################################

# ``requests.request`` keyword arguments.


# Generated at 2022-06-25 17:56:20.049825
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from nose.tools import assert_equals
    assert_equals(
        sorted(plugin_manager.get_auth_plugin_mapping().keys()),
        [
            'basic',
            'digest',
            'hawk',
            'ntlm',
            'oauth1',
        ]
    )


# Generated at 2022-06-25 17:56:27.159274
# Unit test for method __iter__ of class _AuthTypeLazyChoices

# Generated at 2022-06-25 17:56:32.395498
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assertIterableEqual(
        list(auth_type_lazy_choices_0),
        ['digest', 'hmac', 'jwt', 'oauth1', 'plugin-oauth2.provider']
    )


# Generated at 2022-06-25 17:56:37.812012
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Testing if plugin_manager.get_auth_plugin_mapping().keys() is in instance attribute '__contains__' of class '_AuthTypeLazyChoices'
    assert(plugin_manager.get_auth_plugin_mapping().keys() in auth_type_lazy_choices_0)



# Generated at 2022-06-25 17:56:40.462933
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(auth_type_lazy_choices_0) == ['basic', 'digest']


# Generated at 2022-06-25 17:56:45.122058
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_test = _AuthTypeLazyChoices()
    assert "basic" in auth_type_lazy_choices_test
    assert "custom" in auth_type_lazy_choices_test
    assert "digest" in auth_type_lazy_choices_test
    assert "bearer" in auth_type_lazy_choices_test


# Generated at 2022-06-25 17:56:49.271806
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        assert not ('' in auth_type_lazy_choices_0)
    except AssertionError:
        raise AssertionError("method __contains__ of class _AuthTypeLazyChoices returned True for '', expected False")


# Generated at 2022-06-25 17:57:02.106871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    items = [
        'basic',
        'digest',
        'hawk',
        'netrc',
        'ntlm',
        'oauth1',
        'oauth2'
    ]
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for expected in items:
        assert expected in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:57:03.279997
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:57:05.854236
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Constructor for class _AuthTypeLazyChoices
    assert str(_AuthTypeLazyChoices()) == "<_AuthTypeLazyChoices()>"


# Generated at 2022-06-25 17:57:06.828076
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass


# Generated at 2022-06-25 17:57:09.853616
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Basic test
    assert 'basic' in _AuthTypeLazyChoices()

    # TODO: Test disabled for now
    # Test when plugin is not supported
    # assert 'test' not in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:16.247854
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()



auth.add_argument(
    '--auth-type',
    '--auth-plugin',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the HTTP auth plugin to use (default is "auto", to
    automatically detect the auth type).

    For example, to use "Digest" auth:

        http --auth-type=digest -a username:password httpbin.org/get

    To use "Basic" auth:

        http --auth-type=basic -a username:password httpbin.org/get

    To use "AWS" auth:

        http --auth-type=aws -a access-key-id:secret-key-id httpbin.org/get

    '''

)

# Generated at 2022-06-25 17:57:25.101475
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    arg_0 = 'test_value'
    ret_0 = None
    with patch('plugins.manager.plugin_manager.get_auth_plugin', return_value=None) as mock_get_auth_plugin:
        ret_0 = _AuthTypeLazyChoices().__contains__(arg_0)
        mock_get_auth_plugin.assert_called_with(arg_0)
    # <class 'bool'>
    assert isinstance(ret_0, type(True))


# Generated at 2022-06-25 17:57:35.919760
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert 'digest' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:57:38.610152
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert sorted(plugin_manager.get_auth_plugin_mapping().keys()) == sorted(_AuthTypeLazyChoices())


# Generated at 2022-06-25 17:57:50.863372
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    empty_class_1 = _AuthTypeLazyChoices()
    assert (empty_class_1) is not None

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism. The default is "{DEFAULT_AUTH_PLUGIN}".
    Available choices depend on the installed plugins.

    ''',
)
auth.add_argument(
    '--auth-no-challenge',
    dest='auth_no_challenge',
    action='store_true',
    default=False,
    help='''
    Do not send an authorization header when the request response status code
    is 401 and no custom --auth header was specified.

    '''
)

#######################################################################
# SSL

# Generated at 2022-06-25 17:58:10.110091
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Assert
    try:
        test_case_0()
    except Exception as e:
        print('Test failed: ', e)

_AuthTypeLazyChoices = _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:58:20.411736
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():

    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    help='''
    Specify an authentication type to be used. The 'auto' value is used by
    default, which results in a guesswork. There are currently two cases in
    which a guess cannot be made:

    1. Authentication credentials contain a ":" character, e.g.
    token-based authentication.
    2. Basic authentication with a username that contains a ":" character.

    In such cases, the 'basic' type needs to be explicitly specified.

    Available choices depend on the plugins installed. If unavailable,
    the "plugins" command can be used to list plugins and their
    capabilities.

    ''',
    choices=_AuthTypeLazyChoices(),
)

#######################################################################
#

# Generated at 2022-06-25 17:58:27.499311
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'p^'
    dict_0 = {str_0: {}}
    var_0 = {}.__contains__(dict_0)

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. To see the list of supported
    mechanisms, run: $ http --debug

    '''
)
auth.add_argument(
    '--auth-verify', '--auth-no-verify',
    action='store_const',
    const={'verify': True},
    dest='auth_options',
    help='''
    Verify HTTP authentication certificate.
    The default is: --auth-no-verify

    '''
)
# ``--verify`` is used for SSL,

# Generated at 2022-06-25 17:58:37.048891
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    str_10 = 'D'
    str_0 = '3>|'
    dict_0 = {str_0: auth_type_lazy_choices_1}
    var_0 = auth_type_lazy_choices_1.__contains__(dict_0)
    str_1 = '8'
    list_0 = [str_0, str_10, str_1]
    dict_0 = {str_10: list_0}
    var_1 = auth_type_lazy_choices_1.__contains__(dict_0)
    set_0 = {str_1}
    dict_0

# Generated at 2022-06-25 17:58:47.477567
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = '{i}'
    auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:58:53.360610
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    str_0 = '`'
    dict_0 = {str_0: auth_type_lazy_choices_1}
    var_0 = auth_type_lazy_choices_1.__contains__(dict_0)
    # assert var_0 == False


# Generated at 2022-06-25 17:59:03.710586
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    list_var_0 = list(auth_type_lazy_choices_0.__iter__())


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Specify an authentication plugin. Run `$ http --auth-type=help` for more
    information.

    '''
)


#######################################################################
# Custom configuration options
#######################################################################

options = parser.add_argument_group(title='Options')

# Generated at 2022-06-25 17:59:12.485818
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'W}'
    list_0 = []
    for str_1 in list_0:
        str_0 = str_1
    str_2 = 'U-S'
    str_3 = str_0 + str_2
    str_4 = 'wp'
    var_0 = auth_type_lazy_choices_0.__iter__()
    str_5 = str_3 + str_4
    str_6 = 'f'
    str_7 = str_5 + str_6
    str_8 = 'P'
    str_9 = str_7 + str_8
    list_1 = []
    for str_10 in list_1:
        str_9 = str_10
   

# Generated at 2022-06-25 17:59:17.271096
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'CW'
    dict_0 = {str_0: auth_type_lazy_choices_0}
    iterator_0 = auth_type_lazy_choices_0.__iter__()
    for var_0 in iterator_0:
        print(var_0)


# Generated at 2022-06-25 17:59:18.358097
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0() == False


# Generated at 2022-06-25 17:59:42.372366
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 17:59:43.711202
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    
    test_case_0()


# Generated at 2022-06-25 17:59:52.721755
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True == _AuthTypeLazyChoices().__contains__('p^')

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Force the specified authentication mechanism, that is, either
    "basic", "digest" or "auto" (default).

    The "auto" value causes HTTPie to guess the most appropriate
    authentication mechanism based on the server response.

    '''
)
auth.add_argument(
    '--auth-digest-algorithm',
    default='md5',
    choices=['md5', 'sha-256'],
    help='Use the specified digest algorithm for Digest auth (default: md5).'
)

#######################################################################
# Follow
#######################################################################
follow = parser

# Generated at 2022-06-25 17:59:56.412840
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()

_auth_plugin_mapping_0 = plugin_manager.get_auth_plugin_mapping()
_auth_plugin_mapping_1 = plugin_manager.get_auth_plugin_mapping()


# Generated at 2022-06-25 17:59:58.180532
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = '@'
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert not var_0


# Generated at 2022-06-25 17:59:59.567175
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    p_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:00:10.806516
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices, _AuthTypeLazyChoices)



# Generated at 2022-06-25 18:00:11.850376
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:00:14.172294
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    a = _AuthTypeLazyChoices()
    assert isinstance(a, collections.Iterable)


# Generated at 2022-06-25 18:00:15.275420
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()



# Generated at 2022-06-25 18:00:50.435222
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0() == True


# Generated at 2022-06-25 18:00:53.735604
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'p^'
    dict_0 = {str_0: _AuthTypeLazyChoices()}
    var_0 = _AuthTypeLazyChoices().__contains__(dict_0)


# Generated at 2022-06-25 18:01:03.287152
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    bool_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of auth to be used for the request.

    '''
)
auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The type of auth to be used for the request.

    '''
)

# Requests understands "user[:pass]@host" syntax as well.
# parser.add_argument(
#     '--auth-host',
#    

# Generated at 2022-06-25 18:01:06.160183
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = {f'{var_0}': var_0}
    var_2 = var_0.__contains__(var_1)
    var_3 = test_case_0()


# Generated at 2022-06-25 18:01:16.831116
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    for i in range(10):
        test_case_0()

auth.add_argument(
    '--auth-type', '--auth-plugin',
    default=None,
    help='''\
    Specify a custom auth plugin to be used. By default, the plugin
    is inferred from the provided URL (only Basic and Digest are supported).

    Plugins are discovered via entry points by the 'httpie_oauth_plugin' or
    'httpie_auth_plugin' entry point group. To see the list of available plugins:

        $ http --debug --info | grep httpie-

    '''
)

auth.add_argument(
    '--auth-type-help',
    help=SUPPRESS,
    action=AuthTypeHelpAction,
)

# ``requests.request`` keyword arguments.
auth_plugin_

# Generated at 2022-06-25 18:01:20.993409
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        var_0 = test_case_0()
    except SystemExit as e:
        print("test_case_0(self):", e)
        raise


# Generated at 2022-06-25 18:01:25.784273
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'liY#|'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    dict_0 = {str_0: auth_type_lazy_choices_0}
    var_0 = auth_type_lazy_choices_0.__contains__(dict_0)


# Generated at 2022-06-25 18:01:27.972417
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    instance = _AuthTypeLazyChoices()
    instance.__contains__()
    assert True


# Generated at 2022-06-25 18:01:39.684702
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    list_0 = [8, 6, 7, 4]
    list_1 = list()
    for var_0 in list_0:
        list_1.append(var_0)

    set_0 = set(list_1)
    set_1 = set(list_0)
    tuple_0 = (set_1, set_0)
    dict_0 = dict([tuple_0])
    int_0 = auth_type_lazy_choices_0.__iter__(dict_0)

auth_type_choices = _AuthTypeLazyChoices

# Generated at 2022-06-25 18:01:49.696885
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        auth_type_lazy_choices_0.__iter__()
        raise ValueError
    except:
        pass

auth.add_argument(
    '--auth-type', '--auth-plugin',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth protocol/plugin to use.

    The default is to autodetect the auth protocol based on the credentials
    provided. If no credentials are provided, the HTTP Auth header is not
    sent.

    '''
)


# Generated at 2022-06-25 18:03:07.175152
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'p^'
    dict_0 = {str_0: auth_type_lazy_choices_0}
    var_0 = auth_type_lazy_choices_0.__contains__(dict_0)
    assert all(var_0 for var_0 in auth_type_lazy_choices_0)


# Generated at 2022-06-25 18:03:08.398138
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0() == None

# Generated at 2022-06-25 18:03:09.556435
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:03:12.621816
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    set_0 = set()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 18:03:22.618754
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    dest='auth_plugin_name',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use an auth plugin. The following plugins are currently
    available:

        {", ".join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    Use ``--debug`` to see the authentication details exchanged.
    Plugin-specific options can be provided. For example:

        --auth-type digest --auth-digest-algorithm MD5

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 18:03:33.333599
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

ACCESS_TOKEN_AUTH_TYPE = 'token'
# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The name of the auth plugin to use.

    Plugin names: {plugin_manager.get_auth_plugin_mapping().keys()}

    Successful authentication is indicated by a green "auth"
    label in the HTTPie output.

    You can create your own authentication plugins.
    Check out the existing ones for inspiration:

        {plugin_manager.get_auth_plugins_dir()}

    '''
)

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 18:03:40.522448
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'q'
    dict_0 = {str_0: 'ce'}
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    str_1 = ''

    for var_0 in auth_type_lazy_choices_2:
        if var_0 not in dict_0:
            str_1 += var_0

    var_1 = str_1[:-1]
    var_2 = var_1 + str_0


# Generated at 2022-06-25 18:03:50.634729
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'p^'
    dict_0 = {str_0: auth_type_lazy_choices_0}
    var_0 = auth_type_lazy_choices_0.__iter__()
    # Unit test for method __contains__ of class _AuthTypeLazyChoices
    def test__AuthTypeLazyChoices___contains__():
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        value_0 = 1
        str_0 = 'p^'
        dict_0 = {str_0: value_0}
        var_0 = auth_type_lazy_choices_0.__contains__(dict_0)
    auth.add_

# Generated at 2022-06-25 18:03:59.027617
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'p^'
    dict_0 = {str_0: auth_type_lazy_choices_0}
    var_0 = auth_type_lazy_choices_0.__contains__(dict_0)
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    str_1 = 'p^'
    dict_1 = {str_1: auth_type_lazy_choices_1}
    var_1 = auth_type_lazy_choices_1.__contains__(dict_1)
    # assert auth_type_lazy_choices_0 == auth_type_lazy_choices_1


# Generated at 2022-06-25 18:04:08.537708
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'F(i'
    str_1 = 'o_5'
    str_2 = '8Xv'
    list_0 = [str_0, str_1, str_2]
    int_0 = 0
    for str_3 in list_0:
        test_case_0()
        int_0 += 1
