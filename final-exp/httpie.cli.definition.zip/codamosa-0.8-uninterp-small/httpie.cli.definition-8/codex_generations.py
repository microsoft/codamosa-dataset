

# Generated at 2022-06-25 17:54:35.117856
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lc = _AuthTypeLazyChoices()
    assert isinstance(lc.__iter__(), types.GeneratorType)


# Generated at 2022-06-25 17:54:40.448774
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'digest' in _AuthTypeLazyChoices()
    assert sorted(['digest','interactive','minimal','NTLM','ntlm','wsl']) \
        == sorted(list(_AuthTypeLazyChoices()))

auth.add_argument(
    '--auth-type',
    default='basic',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    How to send the authentication data (default is "basic").
    The supported choices are:

        {', '.join(_AuthTypeLazyChoices())}

    '''
)

# Generated at 2022-06-25 17:54:43.017850
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    _AuthTypeLazyChoices___iter__0 = _AuthTypeLazyChoices()
    _AuthTypeLazyChoices___iter__0.test_case_0()


# Generated at 2022-06-25 17:54:44.327441
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'basic' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:54:48.061855
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    """Unit test for method __iter__ of class _AuthTypeLazyChoices"""
    # code to be executed to test method __iter__ of class _AuthTypeLazyChoices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert "basic" in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:54:50.539929
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'aws4-signv4' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:54:54.607351
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except NameError as e:
        if 'plugin_manager' in str(e):
            return


# Generated at 2022-06-25 17:54:59.388245
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert ('basic' in auth_type_lazy_choices_0) or ('basic' not in auth_type_lazy_choices_0)
    assert ('digest' in auth_type_lazy_choices_0) or ('digest' not in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:55:02.869505
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    for e0 in auth_type_lazy_choices_0:
        print(e0)


# Generated at 2022-06-25 17:55:04.435919
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert  'digest' in _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:55:16.501018
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=auth_type_lazy_choices,
    help='''
    Specify the authentication mechanism. The following values are supported:

    {auth_types}

    By default, HTTPie uses Basic Authentication if the --auth option is set,
    and no other authentication mechanism is specified.

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', plugin_info.help)
            for plugin_info in plugin_manager.get_auth_plugin_infos()
        ).strip()
    )
)

####################################################################

# Generated at 2022-06-25 17:55:17.285044
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass


# Generated at 2022-06-25 17:55:24.957455
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. The default is basic.

    The following auth types are currently supported:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(', '.join(
                sorted(plugin_manager.get_auth_plugin_mapping())), 60)
        ).strip()
    )
)

# Generated at 2022-06-25 17:55:28.942849
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    str_0 = 'bold'
    assert var_0.__contains__(str_0) == plugin_manager.get_auth_plugin_mapping().__contains__(str_0)


# Generated at 2022-06-25 17:55:31.408204
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    
    # Call method __contains__ with arguments.
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:55:43.864605
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    var_1 = auth_type_lazy_choices_0.__iter__()
    var_2 = isinstance(var_1, collections.abc.Iterator)
    return var_2

auth.add_argument(
    '--auth-type',
    default=None,
    # This is only a documentation. The choices are generated dynamically.
    choices=list(_AuthTypeLazyChoices()),
    help='''
    The type of auth plugin to use for the given --auth credentials.

    --auth '' is a shortcut for --auth-type native

    '''
)
auth

# Generated at 2022-06-25 17:55:45.012678
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:55:56.468556
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_0.__next__()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the auth mechanism to use. The special value "auto" (the default)
    will pick the best plugin based on the server response.

    Available plugins:
        {0}

    '''.format(
        ', '.join(plugin_manager.get_auth_plugin_mapping().keys())
    ),
)

# Generated at 2022-06-25 17:56:01.260630
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test method __contains__, if str_0 is in auth_type_lazy_choices_0
    test_case_0()
    # Test method __contains__, if str_0 is not in auth_type_lazy_choices_0
    test_case_1()
    # Test method __contains__, if str_0 is of the type int
    test_case_2()


# Generated at 2022-06-25 17:56:02.333058
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:56:17.532829
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Verify the constructor
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_0 = 'bold'
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert var_0 == False
    list_0 = []

    # Verify __contains__
    for str_0 in auth_type_lazy_choices_0:
        list_0.append(str_0)
    assert list_0 == []
    assert auth_type_lazy_choices_0.__contains__(str_0) == False


# Generated at 2022-06-25 17:56:21.096172
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'italic'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:56:22.648746
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        print('Exception raised')


# Generated at 2022-06-25 17:56:28.601541
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True == test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. If not provided, an appropriate
    one is automatically selected.

    The available options depend on the installed plugins.

    '''
)
auth.add_argument(
    '--auth-digest',
    action='store_true',
    help='''
    Use HTTP Digest Auth (mutually exclusive with --auth).

    Authentication headers are not saved in session files.

    Note that this will send your password over the wire in plain-text
    (unless SSL is used). Consider using --auth to send the password
    in an encrypted form and to avoid duplicate prompts.

    '''
)
_no_auth

# Generated at 2022-06-25 17:56:41.847459
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    var_1 = auth_type_lazy_choices_0.__iter__()


auth.add_argument(
    '--auth-type', '-t',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    ''',
)
auth.add_argument(
    '--auth-plugin', '-T',
    help=SUPPRESS,
)

# Generated at 2022-06-25 17:56:47.940340
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth.add_argument(
    '--auth-type',
    default=GUESS,
    metavar='TYPE',
    type=str,
    help='''
    The authentication mechanism to be used.
    Supported values depend on the --auth option.
    Defaults to "auto", which tries to guess one from the --auth
    argument.

    These values are supported by default:

        'auto', 'basic', 'digest', 'hawk'

    '''
)

# Generated at 2022-06-25 17:57:01.576080
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used.
    It is detected automatically when possible.
    Use this option to force a specific auth type.
    Use --debug flag to see what mechanism HTTPie tried to use.

    Currently supported: {supported_auth_types}

    '''.format(
        supported_auth_types=', '.join(
            plugin_manager.get_auth_plugin_mapping().keys())
    )
)


# Generated at 2022-06-25 17:57:10.874864
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert test_case_0() == True


# Generated at 2022-06-25 17:57:23.801917
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    The name of an auth plugin for authenticating the request.

    To see a list of available plugins, use:
        $ http --debug
    '''
)
auth.add_argument(
    '--auth-type-help',
    metavar='AUTH_TYPE',
    help='''
    Show help for the authentication type AUTH_TYPE.

    To see a list of available authentication types, use:
        $ http --debug
    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 17:57:24.989850
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0()


# Generated at 2022-06-25 17:57:36.502583
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    if var_0:
        var_1 = 0
    else:
        var_1 = -1
    return int(var_1)


# Generated at 2022-06-25 17:57:49.208989
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'json'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_0(str_0, auth_type_lazy_choices_0)

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use.

    Default is basic. For Digest auth, use --auth-type=digest.

    '''
)

# Generated at 2022-06-25 17:57:50.289028
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 17:57:59.517468
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    help=f'''
    Force usage of a specified auth plugin. For example, to force Digest auth:

        {HTTPIE} -a user:pass --auth-type=digest https://httpbin.org/headers

    Available choices are: {[_AuthTypeLazyChoices()]}

    !!! NOTE !!!
    Unlike --auth/-a, --auth-type takes a non-URL-encoded value.

    '''
)


# Generated at 2022-06-25 17:58:01.641381
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_0()


# Generated at 2022-06-25 17:58:14.289578
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    iter_0 = auth_type_lazy_choices_0.__iter__()
    elem = iter_0.__next__()
    assert str_0 == elem


# Generated at 2022-06-25 17:58:15.538884
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 17:58:17.845240
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    if ((var_0 and True) or (not var_0 and False)):
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-25 17:58:30.750043
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Test input
    str_0 = 'bold'
    # Test output
    bool_0 = _AuthTypeLazyChoices.__contains__(_AuthTypeLazyChoices, str_0)
    # Test type
    assert(isinstance(bool_0, bool))
    # Test value
    assert(bool_0 == True)



# Generated at 2022-06-25 17:58:39.326656
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        status = 'fail'
    else:
        status = 'pass'
    assert status == 'pass'

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of auth to perform against the server.
    e.g., digest for Digest auth.
    The recognized auth types can vary based on plugins.

    '''
)

# Generated at 2022-06-25 17:58:56.329096
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    iter_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:58:59.215531
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# Test for lines covered for plugin test

# Generated at 2022-06-25 17:59:05.134473
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth_type_validator = ChoicesValidator(
    choices=_AuthTypeLazyChoices(),
    message='Unknown auth plugin: %(found)s.\n\n'
            'Choose one of: %(choices)s.\n'
            'Use "http --help" for more information.'
)



# Generated at 2022-06-25 17:59:13.127617
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type', '--auth-plugin',
    choices=_AuthTypeLazyChoices(),
    metavar='BACKEND_NAME',
    help='''
    Use the specified auth plugin.

    Available auth plugins:
        {installed_plugins}

    If not specified, HTTPie first tries to use the custom
    implementation and then falls back to the builtins.

    '''.format(
        installed_plugins=format_installed_plugins(
            plugin_manager.get_auth_plugin_mapping()
        )
    )
)

#######################################################################
# Other options
#######################################################################

config = parser.add_argument_group(
    title='Configuration File Options'
).add_mutually_exclusive_group()

config.add_argument

# Generated at 2022-06-25 17:59:23.302395
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    str_1 = 'underline'
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    var_1 = auth_type_lazy_choices_0.__contains__(str_1)
    var_2 = auth_type_lazy_choices_0.__iter__()
    var_3 = next(var_2)
    var_4 = next(var_2)


# Generated at 2022-06-25 17:59:28.082713
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_1 = 'bold'
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    try:
        var_1 = auth_type_lazy_choices_1.__iter__()
        assert True
    except:
        var_1 = False
    assert var_1


# Generated at 2022-06-25 17:59:36.519567
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_0.__contains__(str_0)
    var_2 = auth_type_lazy_choices_0.__iter__()
    var_3 = var_2.__iter__()
    assert str(str(var_3)) == '<list_iterator object at 0x7fd856db3748>'


# Generated at 2022-06-25 17:59:44.809430
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    str_1 = 'red'
    str_2 = 'blue'
    str_3 = 'green'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    list_0 = list(auth_type_lazy_choices_0)
    list_0_length = len(list_0)
    list_0_0 = list_0[0]
    list_0_1 = list_0[1]
    list_0_2 = list_0[2]
    list_0_3 = list_0[3]
    list_0_4 = list_0[4]
    list_0_5 = list_0[5]
    list_0_6 = list_0[6]
    list_0_7 = list_

# Generated at 2022-06-25 17:59:48.001933
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 17:59:55.283902
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    str_1 = 'zigzag'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__

# Generated at 2022-06-25 18:00:36.003270
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    type=plugin_manager.get_auth_plugin_mapping(),
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin.

    The available plugins are:

        {plugins}

    By default, HTTPie uses the "auto" plugin, which tries all of them and
    refuses to authenticate only if all of them refuse.

    '''
)

#######################################################################
# CLI extras
#######################################################################

extras = parser.add_argument_group(title='Extras')


# Generated at 2022-06-25 18:00:42.625949
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism to use. By default HTTPie tries to figure out
    the most suitable auth mechanism for the current request.

    It is generally easier to just use --auth which behaves as if
    --auth-type=auto was set.

    '''
)

#######################################################################
# Programming interface
#######################################################################

programming_interface = parser.add_argument_group(title='Programming Interface')


# Generated at 2022-06-25 18:00:44.247888
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 18:00:56.015931
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    Defaults to the URL hostname.

    '''
)

#######################################################################
# Custom headers
#######################################################################
custom_headers = parser.add_argument_group(title='Custom Headers')

# Generated at 2022-06-25 18:01:04.999566
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

# Help text for --auth-type
auth_type_help = f'''
    Use the specified HTTP auth type. Valid options are:

        {', '.join(sorted(_AuthTypeLazyChoices()))}

    '''

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=auth_type_help,
)
auth.add_argument(
    '--proxy-auth', '-pa',
    metavar='USER[:PASS]',
    help='''
    Same as --auth but used in case of proxy auth.

    ''',
)

# Generated at 2022-06-25 18:01:15.998978
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    dest='auth_plugin',
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin (see the docs).

    '''
)

#######################################################################
# Transport
#######################################################################

transport = parser.add_argument_group(title='Transport')


# Generated at 2022-06-25 18:01:18.145260
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")


# Generated at 2022-06-25 18:01:28.339960
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

# ``requests.request`` keyword argument for authentication plugins.

# Generated at 2022-06-25 18:01:37.384884
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    iterator_0 = auth_type_lazy_choices_0.__iter__()
    iterator_1 = iterator_0
    method_0 = iterator_1.__next__
    assert method_0
    iterator_2 = iterator_0
    string_0 = iterator_2.__next__()
    print(string_0)


# Generated at 2022-06-25 18:01:41.402872
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 18:03:04.845749
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Default is basic for HTTP and digest for
    HTTPS. The following auth types are available:

    {plugin_map}

    Plugins can add more.
    '''
        .format(
        plugin_map='\n'.join(
            [8 * ' ' + line.strip() for line in wrap(
                ', '.join(
                    sorted(
                        plugin_manager.get_auth_plugin_mapping().keys())), 60)]).strip())
)

#######################################################################
# SSL
#######################################################################

# ``requests.request`` keyword arguments.

# Generated at 2022-06-25 18:03:12.400493
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert var_0 == True
    list_0 = []
    for item_0 in auth_type_lazy_choices_0.__iter__():
        list_0.append(item_0)
    list_1 = ['basic', 'digest', 'hawk', 'ntlm', 'multipart']
    assert list_0 == list_1


# Generated at 2022-06-25 18:03:15.539299
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__(str_0) == True


# Generated at 2022-06-25 18:03:26.197379
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# Generated at 2022-06-25 18:03:35.841755
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism for the request.

    Default, "auto", meaning "HTTP Basic Auth if credentials are included in
    the URL, otherwise no auth".

    Specify one of the following, if you want to override the default:

        ''' + ', '.join(
        plugin_manager.get_auth_plugin_mapping().keys()
    ) + '''

    '''
)
auth.add_argument(
    '--auth-disable',
    action='store_true',
    help='''
    Disable HTTPie's built-in authentication plugin handling. Useful if it's
    conflicting with a plugin you've installed.

    '''
)

# Generated at 2022-06-25 18:03:38.358071
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)


# Generated at 2022-06-25 18:03:43.843866
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    var_1 = auth_type_lazy_choices_0.__iter__()
    assert var_0 is True

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify the authentication mechanism to be used.
    It can be one of:

    {plugin_manager.get_auth_plugin_help()}

    '''
)

# ``requests.request`` keyword arguments.
verify_options = parser.add_argument_group(title='SSL Options')
verify_options

# Generated at 2022-06-25 18:03:48.494337
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    assert var_0 == True


# Generated at 2022-06-25 18:03:49.550040
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:03:57.687961
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    str_0 = 'bold'
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__(str_0)
    str_1 = 'basic'
    var_1 = auth_type_lazy_choices_0.__contains__(str_1)
    str_2 = 'bearer'
    var_2 = auth_type_lazy_choices_0.__contains__(str_2)
    str_3 = 'digest'
    var_3 = auth_type_lazy_choices_0.__contains__(str_3)
    str_4 = 'hawk'