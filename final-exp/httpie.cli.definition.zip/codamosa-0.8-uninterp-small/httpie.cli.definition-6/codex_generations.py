

# Generated at 2022-06-25 17:54:37.858085
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    result = iter(obj)
    assert iter(result) == iter(obj)



# Generated at 2022-06-25 17:54:39.191223
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    print(_AuthTypeLazyChoices())


# Generated at 2022-06-25 17:54:40.908550
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert 'Bearer' in _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:54:44.172948
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_1()
    try:
        # Unit test for method __contains__ of class _AuthTypeLazyChoices
        # Invisible if called from the module
        test_case_2()
    except Exception as e:
        pass


# Generated at 2022-06-25 17:54:46.358514
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert list(_AuthTypeLazyChoices()) == \
        sorted(plugin_manager.get_auth_plugin_mapping().keys(), key=str.lower)


# Generated at 2022-06-25 17:54:57.372506
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Authentication type. If no explicit type is specified, the client
    will attempt to infer it form the --auth username (if it looks like
    an email) or the hostname.

    ''',
)
auth.add_argument(
    '--auth-jwt',
    default=None,
    metavar='JWT',
    help='''
    Authenticate with JSON Web Token (JWT). Sets Authorization header to
    'Bearer <JWT>'.

    ''',
)

# Generated at 2022-06-25 17:54:59.108110
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:55:05.672279
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert 'path' in auth_type_lazy_choices_0


auth.add_argument(
    '--auth-type',
    default='auto',
    choices=auth_type_lazy_choices_0,
    help='''
    Specify an authentication plugin. Plugins are registered via entry points
    and usually correspond to a specific auth scheme, such as "digest" or "aws".

    The default "auto" means that authentication is attempted over all available
    plugins.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    default=False,
    help='''
    Prevent HTTPie from sending the Authorization header when it detects 401 or
    407 response code.

    '''
)

#######################################################################



# Generated at 2022-06-25 17:55:09.748466
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert list(auth_type_lazy_choices_0) == sorted(plugin_manager.get_auth_plugin_mapping().keys())


# Generated at 2022-06-25 17:55:12.462517
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not (1 in auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:55:24.224600
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Construct global instance of class _AuthTypeLazyChoices
    var_5 = _AuthTypeLazyChoices()
    var_5.__contains__(1)
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_5.__iter__().__next__()
    var_

# Generated at 2022-06-25 17:55:29.263954
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # This test case can only be used for unit test
    if not hasattr(sys, '_called_from_test'):
        raise Exception("Please run this test case in unit test mode.")
    var_0 = _AuthTypeLazyChoices.__iter__(auth_type_lazy_choices_0)


# Generated at 2022-06-25 17:55:39.258491
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__contains__(auth_type_lazy_choices_1)
    except TypeError:
        print("TypeError")

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication method to be used. The value can be "basic" (default)
    or the name of any other authentication method supported by
    the installed plugins.

    To see the available authentication methods, run:

    $ http --auth-type=help

    '''
)

auth.add_

# Generated at 2022-06-25 17:55:41.068111
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:55:52.995782
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('ntlm')
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 17:56:02.198544
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify a custom auth plugin (e.g., oauth2).

    '''
)
auth.add_argument(
    '--auth-host',
    help='''
    The host to which the auth credentials apply. Useful for Basic/Digest
    auth when your credentials are expected to work on multiple host domains
    and subdomains, but you want to provide different credentials for each.
    E.g. --auth-host=api.github.com:user:pass --auth-host=gist.github.com:user2:pass2

    '''
)

#######################################################################
# Verify

# Generated at 2022-06-25 17:56:03.271365
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:05.370967
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:56:17.317927
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help="""
    Force the authentication mechanism.

    auto (default):

        Detect and auto-select the best auth mechanism
        (digest, oauth1, oauth2, basic, or custom).

    custom:

        Use the user-specified custom auth plugin.

    """,
)

# Generated at 2022-06-25 17:56:21.834604
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    find_program_path()
    # _AuthTypeLazyChoices needs to be tested
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    if not plugin_manager.get_auth_plugin_mapping() in auth_type_lazy_choices_0:
        raise Exception("Not true")
    else:
        pass


# Generated at 2022-06-25 17:56:29.320279
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('ntlm')


# Generated at 2022-06-25 17:56:39.799472
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    pass  # Nothing to test

auth.add_argument(
    '--auth-type',
    dest='auth_type',
    help='''
    Specify an HTTPie auth plugin to use. To see the list of available auth
    plugins, run:

        http --auth-type=

    If a custom auth plugin, the path to it should be provided.
    See https://httpie.org/docs/plugins/authentication.html
    for more information.

    ''',
    choices=_AuthTypeLazyChoices(),
)
# Needed for plugin testing



# Generated at 2022-06-25 17:56:46.672764
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('baz')
    var_1 = auth_type_lazy_choices_0.__contains__('anonymous')
    var_2 = auth_type_lazy_choices_0.__contains__('http')
    var_3 = auth_type_lazy_choices_0.__contains__('digest')
    var_4 = auth_type_lazy_choices_0.__contains__('basic')


# Generated at 2022-06-25 17:57:00.008105
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    # Execute constructor
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to use.

    The default is basic, which is generally the most useful one.
    Other options include digest and oauth1.

    ''',
)

#######################################################################
# Proxy
#######################################################################

# ``requests.request`` keyword arguments.
proxy = parser.add_argument_group(title='Proxy')

# Generated at 2022-06-25 17:57:09.685887
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # TODO: GET RID OF MAGIC NUMBER
    for _ in range(10):
        test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    dest='auth_plugin_name',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the auth mechanism to use.

    If `auto` (default), then the value of the --auth flag determines
    which auth plugin is used.

    ''',
)

auth.add_argument(
    '--auth-username',
    default=None,
    dest='auth_username',
    help='''
    The username, if provided, overrides the username in --auth, if provided.

    ''',
)

# Generated at 2022-06-25 17:57:12.918447
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from pytest import raises
    with raises(NotImplementedError):
        auth_type_lazy_choices = _AuthTypeLazyChoices()
        auth_type_lazy_choices.__iter__()


# Generated at 2022-06-25 17:57:26.364931
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force the specified authentication mechanism.

    If the ``--auth-type`` option is not specified, the required
    mechanism is inferred from the ``--auth`` option value.

    If both ``--auth-type`` and ``--auth`` are not provided, then the request
    is sent without authentication.

    ''',
)

#######################################################################
# Transport
#######################################################################

transport = parser.add_argument_group(title='Transport')

# Generated at 2022-06-25 17:57:30.210969
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__()


# Generated at 2022-06-25 17:57:40.848539
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__('kerb') == True
    assert auth_type_lazy_choices_0.__contains__(None) == False
    assert auth_type_lazy_choices_0.__contains__(False) == False
    assert auth_type_lazy_choices_0.__contains__(True) == False
    assert auth_type_lazy_choices_0.__contains__('ntlm') == True
    assert auth_type_lazy_choices_0.__contains__(5) == False
    assert auth_type_lazy_choices_0.__contains__(3) == False
    assert auth_type_

# Generated at 2022-06-25 17:57:44.547492
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_2.__contains__('')


# Generated at 2022-06-25 17:58:00.271874
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0() is None

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices=auth_type_lazy_choices,
    help='''
    Specifies the authentication mechanism to be used.

    This can be useful when, for example, the server responds
    with a `401 Unauthorized` and provides a `WWW-Authenticate`
    header specifying multiple supported authentication types.

    Available auth types: {sorted_auth_types}

    '''.format(
        sorted_auth_types=', '.join(sorted(auth_type_lazy_choices)),
    ),
)

#######################################################################
# Options
#######################################################################

options = parser.add_argument_group(title='Options')

# Generated at 2022-06-25 17:58:12.970512
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    The auth mechanism for the request.

    The default behavior is to auto-detect the auth mechanism based on the
    official name of the HTTP auth scheme (Basic, Digest, etc.). However,
    there are cases when this is impossible, e.g., when the server sets an
    auth scheme not defined in the HTTP spec, or it is using a custom
    implementation.

    In such a case, you can specify the auth mechanism explicitly. To get
    the list of available mechanisms, run `http --debug'.

    ''',
)


# Generated at 2022-06-25 17:58:22.626619
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()

# Generated at 2022-06-25 17:58:28.330580
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:58:34.179007
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    t = _AuthTypeLazyChoices()
    assert t == _AuthTypeLazyChoices()
    assert t[0] != _AuthTypeLazyChoices()
    assert t.__class__ == _AuthTypeLazyChoices
    assert t.__class__.__name__ == '_AuthTypeLazyChoices'
    assert str(t) == '_AuthTypeLazyChoices'
    assert repr(t) == '_AuthTypeLazyChoices()'


# Generated at 2022-06-25 17:58:37.042036
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    var = auth_type_lazy_choices.__contains__('Basic')

# Dummy test for class _AuthTypeLazyChoices

# Generated at 2022-06-25 17:58:47.435791
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('foo')
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    dest='auth_type',
    help='''
    Custom auth implementation to use.
    ''',
)

#######################################################################
# Streaming
#######################################################################
streaming = parser.add_argument_group(title='Streaming')

# Generated at 2022-06-25 17:58:49.904480
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    return var_0

# Generated at 2022-06-25 17:58:51.971415
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert next(test_case_0.var_0) == 'aws'


# Generated at 2022-06-25 17:58:58.322380
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_1 = test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Force usage of a particular authentication plugin.
    Otherwise, HTTPie will attempt to guess.

    Plugins:

        {auth_plugins}

    '''.format(
        auth_plugins='\n'.join(
            '{0}{1}'.format(8 * ' ', line.strip())
            for line in wrap(
                ', '.join(sorted(plugin_manager.get_auth_plugin_mapping())),
                60
            )
        ).strip()
    )
)

#######################################################################
# Miscellaneous
#######################################################################


# Generated at 2022-06-25 17:59:16.455407
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    itr = iter(_AuthTypeLazyChoices())
    while True:
        try:
            next(itr)
        except StopIteration:
            break
    try:
        next(itr)
    except StopIteration:
        pass


# Generated at 2022-06-25 17:59:19.240426
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_0 = _AuthTypeLazyChoices()
    bool_0 = test_0.__contains__('http')
    var_1 = test_0.__contains__('http')


# Generated at 2022-06-25 17:59:28.244021
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    A case-insensitive string of the authentication mechanism to be used:

    {auth_type_help}

    '''
)
auth.add_argument(
    '--auth-no-challenge',
    default=False,
    action='store_true',
    help='''
    When specified, do not send an initial unauthenticated request to
    obtain a challenge (e.g., via Digest, NTLM, and Negotiate authentication
    schemes).

    '''
)

#######################################################################
# HTTP method, and related options
#######################################################################


# Generated at 2022-06-25 17:59:34.440308
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    return True

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The type of HTTP authentication to perform, if any. By default,
    HTTPie tries to determine the auth type if possible.

    Currently supported: {0}
    '''.format(', '.join(sorted(plugin_manager.get_auth_plugin_mapping())))
)


#######################################################################
# HTTP and HTTPS
#######################################################################

# ``requests.request`` keyword arguments.
http = parser.add_argument_group(title='HTTP')

# Generated at 2022-06-25 17:59:35.842128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices_0.__contains__(str())


# Generated at 2022-06-25 17:59:44.445808
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()



auth.add_argument(
    '--auth-type',
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Force usage of a specific authentication type.
    Available choices: {', '.join(_AuthTypeLazyChoices())}.

    '''
)
auth.add_argument(
    '--auth-nonce',
    dest='auth_nonce',
    metavar='NONCE',
    help='''
    When using Digest authentication, provide a pre-set nonce value to be used
    instead of the one issued by the server.
    '''
)

# Generated at 2022-06-25 17:59:53.875711
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    assert 'basic' in var_0
    assert 'digest' in var_0
    assert 'hawk' in var_0
    assert 'ntlm' in var_0
    assert 'aws4-hmac-sha256' in var_0
    assert 'aws4-hmac-sha256-unsigned-body' in var_0
    assert 'aws-sigv4' in var_0
    assert 'aws-sigv4-unsigned-body' in var_0
    assert 'ed25519' in var_0
    assert 'ed25519sha256' in var_0
    assert 'mac' in var_0
    assert 'oauth1' in var_0
    assert 'oauth2' in var_0


# Generated at 2022-06-25 18:00:04.413062
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()



auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify the authentication mechanism to be used.
    If not provided, the plugin will be guessed from the provided credentials.

    '''
)

# Generated at 2022-06-25 18:00:05.677707
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:00:16.505823
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Use the specified auth plugin. Available plugins:

    {plugin_manager.describe_auth_plugins()}

    '''
)

auth.add_argument(
    '--auth-endpoint',
    help='''
    Use the specified HTTP endpoint for obtaining tokens. Used by OAuth plugin.

    '''
)


# Generated at 2022-06-25 18:00:54.032345
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_2 = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices_2.__contains__('hawk')
    auth_type_lazy_choices_3 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:01:03.530989
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('x-auth-plugin')
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify an auth mechanism, so that HTTPie knows which
    plugin to use by default. Without this option, HTTPie will try to
    detect the auth mechanism by the response status code and possibly
    by the presence of the WWW-Authenticate and Proxy-Authenticate headers.

    '''
)

# Generated at 2022-06-25 18:01:08.136286
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var = _AuthTypeLazyChoices()
    assert isinstance(var, _AuthTypeLazyChoices), f'Expected type _AuthTypeLazyChoices, but got {type(var)}'
    assert var.__iter__() == var.__iter__(), f'Expected value {var.__iter__()}, but got {var.__iter__()}'



# Generated at 2022-06-25 18:01:11.203192
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_3 = auth_type_lazy_choices_0.__contains__('[')


# Generated at 2022-06-25 18:01:12.448885
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert True


# Generated at 2022-06-25 18:01:24.064832
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
    pass

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism. Available options:

        {options}

    '''.format(options=sorted(
        plugin_manager.get_auth_plugin_mapping().keys()
    ))
)

# Generated at 2022-06-25 18:01:26.681018
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    var_1 = var_0.__contains__('digest')
    var_2 = _AuthTypeLazyChoices()


# Generated at 2022-06-25 18:01:29.731218
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('Basic')
    assert(var_0 == True)


# Generated at 2022-06-25 18:01:41.783081
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert 1==1
    return True


auth.add_argument(
    '--auth-type',
    default=DEFAULT,
    dest='auth_type',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used.

    By default, HTTPie uses the standard HTTP Basic auth if a username
    is provided with -a, and no other authentication mechanism is specified.
    This is because Basic auth is the only auth standard that
    browsers automatically supply credentials for.

    The following values are accepted:

        {_AuthTypeLazyChoices()}

    It's possible to use any external program as a password-providing
    process. See the "PASSWORD PROVIDERS" section of the manual for details.

    '''
)

# Generated at 2022-06-25 18:01:51.027715
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices1 = _AuthTypeLazyChoices()
    assert auth_type_lazy_choices0 == auth_type_lazy_choices1
    assert auth_type_lazy_choices0 is not auth_type_lazy_choices1

auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Authentication plugin to use. If not specified, an appropriate one is
    guessed. Following plugins are available:
        {", ".join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}
    '''
)

# Generated at 2022-06-25 18:03:01.401312
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 18:03:05.328680
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Create an instance of class
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    # create variables of type str
    var_0 = "basic"
    var_0 = "digest"
    var_0 = "hawk"
    var_0 = "custom"
    var_1 = "_AuthTypeLazyChoices.__contains__"
    assert_equals(auth_type_lazy_choices_1.__contains__(var_0), True)


# Generated at 2022-06-25 18:03:09.370918
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert ("myauth" in auth_type_lazy_choices) == False
    assert ("httpauth" in auth_type_lazy_choices) == True


# Generated at 2022-06-25 18:03:10.465981
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()



# Generated at 2022-06-25 18:03:12.086785
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()



# Generated at 2022-06-25 18:03:13.546682
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    # __iter__ of class _AuthTypeLazyChoices
    test_case_0()


# Generated at 2022-06-25 18:03:24.159463
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        test_case_0()

    # AssertionError: Test for _AuthTypeLazyChoices constructor failed
    except AssertionError:
        print('AssertionError: Test for _AuthTypeLazyChoices constructor failed')
    else:
        print('Passed!')


# ``requests.request`` keyword arguments.
auth.add_argument(
    '--auth-type', '-A',
    default=DEFAULT_AUTH_PLUGIN,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Auth plugin to use. Available plugins include: {auth_plugins}

    '''.format(auth_plugins=' '.join(sorted(
        plugin_manager.get_auth_plugin_mapping().keys())))
)



# Generated at 2022-06-25 18:03:26.360633
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert len(_AuthTypeLazyChoices()) == 3
    assert len(str(_AuthTypeLazyChoices())) == 23


# Generated at 2022-06-25 18:03:35.942320
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify an authentication method.
    '''
)

#######################################################################
# Proxy
#######################################################################

proxy = parser.add_argument_group(title='Proxy')

proxy.add_argument(
    '--proxy',
    default=None,
    metavar='[PROTOCOL://]HOST[:PORT]',
    help='''
    Specify a proxy in the form
    [PROTOCOL://]HOST[:PORT]
    ''',
)


#######################################################################
# HTTP(S)
#######################################################################


# Generated at 2022-06-25 18:03:38.582815
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    assert var_0
