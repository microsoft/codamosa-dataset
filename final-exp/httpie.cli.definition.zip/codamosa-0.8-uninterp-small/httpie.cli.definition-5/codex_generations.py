

# Generated at 2022-06-25 17:54:38.437159
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    assert ('digest' in auth_type_lazy_choices_1) is True


# Generated at 2022-06-25 17:54:47.682582
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        pass
    except:
        assert False


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used with the auth plugin.

    This can be one of:
        {auth_type_choices}

    '''.format(
        auth_type_choices=', '.join(
            item for item in _AuthTypeLazyChoices()
        )
    )
)


# Generated at 2022-06-25 17:54:58.289778
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from httpie.plugins import plugin_manager
    from httpie.plugins._auth.aws import AWSPlugin
    from httpie.plugins._auth.digest import DigestAuthPlugin
    from httpie.plugins._auth.jwt import JWTAuthPlugin
    from httpie.plugins._auth.netrc import NetrcAuthPlugin
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()

    # Test __iter__ method
    assert list(auth_type_lazy_choices_1) == [
        'aws', 'digest', 'jwt', 'netrc']

    # False positive
    assert 'hoge' not in auth_type_lazy_choices_1

# Generated at 2022-06-25 17:55:05.214086
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    from collections import Iterator, Iterable
    from types import GeneratorType
    
    # Test for method __iter__ of class _AuthTypeLazyChoices
    # Instance of class _AuthTypeLazyChoices
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    
    # Test for method __iter__ of class _AuthTypeLazyChoices in class _AuthTypeLazyChoices
    assert isinstance(iter(auth_type_lazy_choices_0), Iterator)
    
    # Test for method __iter__ of class _AuthTypeLazyChoices in class _AuthTypeLazyChoices
    assert isinstance(iter(auth_type_lazy_choices_0), Iterable)
    
    # Test for method __iter__ of class _AuthTypeLazyChoices in class _

# Generated at 2022-06-25 17:55:10.979560
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    it = auth_type_lazy_choices.__iter__()
    assert hasattr(it, '__next__')
    expected = [
        'auto',
        'basic',
        'digest',
        'hawk',
    ]
    assert list(it) == expected


# Generated at 2022-06-25 17:55:20.399265
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'basic' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'awsv4' in auth_type_lazy_choices_0

    types = []
    for type in auth_type_lazy_choices_0:
        types.append(type)

    assert 'basic' in types
    assert 'digest' in types
    assert 'hawk' in types
    assert 'awsv4' in types


# Generated at 2022-06-25 17:55:29.038256
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert not hasattr(auth_type_lazy_choices_0, "__next__")
    assert not hasattr(auth_type_lazy_choices_0, "next")
    for __dummy in auth_type_lazy_choices_0:
        raise AssertionError("Iterator is not empty")
    assert not hasattr(auth_type_lazy_choices_0, "__next__")
    assert not hasattr(auth_type_lazy_choices_0, "next")


# Generated at 2022-06-25 17:55:36.407199
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'aws4' in auth_type_lazy_choices_0
    assert 'aws4-hmac' in auth_type_lazy_choices_0
    assert 'aws4-sigv4' in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0
    assert 'bearer' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'hmac' in auth_type_lazy_choices_0
    assert 'jwt' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:43.973449
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    test_case_result_0 = 'basic'
    test_case_result_1 = auth_type_lazy_choices_0.__iter__()
    for test_case_result_2 in test_case_result_1:
        test_case_result_0 = test_case_result_2
    assert test_case_result_0 == 'ntlm'


# Generated at 2022-06-25 17:55:46.993628
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_1.__init__()


# Generated at 2022-06-25 17:55:53.727619
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'aws4-hmac-sha256' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:55:56.422721
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    try:
        test_case_0()
        method_success = True
    except Exception:
        method_success = False

    assert method_success


# Generated at 2022-06-25 17:55:58.380028
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    lazy_choices = _AuthTypeLazyChoices()
    x = [i for i in lazy_choices]
    assert not x == []


# Generated at 2022-06-25 17:56:10.196149
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    except:
        assert False


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism to be used. Use --debug to see a list of
    built-in and third-party plugins that are available.

    '''
)
auth.add_argument(
    '--auth-protocol',
    default=None,
    choices=['basic', 'digest'],
    help='''
    By default, HTTPie tries to detect the auth protocol automatically.

    This option can be used to enforce a particular protocol.

    '''
)

# Generated at 2022-06-25 17:56:14.040187
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    obj = _AuthTypeLazyChoices()
    # No exception to raise, when called the method __iter__ of class _AuthTypeLazyChoices
    returned_value = obj.__iter__()



# Generated at 2022-06-25 17:56:23.167389
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    Force the specified authentication mechanism. By default, HTTPie
    detects the auth mechanism by the supplied credentials, but
    with Digest auth,  it's sometimes safer to explicitly set the
    auth type.

    ''',
)
auth.add_argument(
    '--auth-host',
    default=None,
    metavar='HOST',
    help='''
    Override the default host for the authentication credentials.

    ''',
)

#######################################################################
# Connection
#######################################################################

connection = parser.add_argument_group(title='Connection')


# Generated at 2022-06-25 17:56:28.842031
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0.__name__ == "test_case_0"

auth.add_argument(
    '--auth-type',
    default=DEFAULT_AUTH_PLUGIN_NAME,
    metavar='TYPE',
    choices=plugin_manager.get_auth_plugin_mapping(),
    help=f'''
    The authentication mechanism to be used.

    If a username is specified with -a but no password and this option is
    provided, the credentials will be retrieved from keyring.

    The available types are:

        {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    If a type is not provided and credentials are specified, the default
    auth type "basic" is used.

    '''
)

# Generated at 2022-06-25 17:56:32.338090
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    x0 = _AuthTypeLazyChoices()
    x1 = x0.__contains__('search_engine_copy')
    return x1


# Generated at 2022-06-25 17:56:44.160030
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_1 = _AuthTypeLazyChoices()


auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    Explicitly specify the type of credentials. If not provided, HTTPie
    attempts to guess the type from the --auth value.

    The available types are:

    {auth_types}

    '''.format(
        auth_types='\n'.join(
            '* {0}'.format(
                '\n  '.join(wrap(auth_type.name, 55))
            )
            for auth_type in plugin_manager.get_auth_plugins()
        )
    )
)


# Generated at 2022-06-25 17:56:50.216893
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    import pytest

    with pytest.raises(AttributeError):
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        auth_type_lazy_choices_0.attr
    with pytest.raises(IndexError):
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        auth_type_lazy_choices_0[1]
    with pytest.raises(KeyError):
        auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
        auth_type_lazy_choices_0['attr']



# Generated at 2022-06-25 17:56:55.579722
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert callable(_AuthTypeLazyChoices)



# Generated at 2022-06-25 17:57:00.140034
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    try:
        var_0 = auth_type_lazy_choices_0.__iter__()
    except StopIteration:
        pass


auth_type = auth.add_argument_group(title='Authentication type') \
    .add_mutually_exclusive_group()


# Generated at 2022-06-25 17:57:05.631544
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    var_0 = _AuthTypeLazyChoices()
    assert isinstance(var_0, AuthTypeLazyChoices)
    var_1 = var_0.__contains__('digest')
    assert isinstance(var_1, bool)
    var_2 = var_0.__contains__('digest')
    assert isinstance(var_2, bool)


# Generated at 2022-06-25 17:57:06.961082
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert isinstance(test_case_0(), types.GeneratorType)


# Generated at 2022-06-25 17:57:14.519177
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("K")
    return var_0


auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Set the authentication handler to use.
    Supported authentication types are {sorted(plugin_manager.get_auth_plugin_mapping())}.

    ''',
)

auth.add_argument(
    '--auth-none',
    action='store_true',
    dest='auth_no',
    help='''
    Explicitly disable any authentication.

    '''
)

# Generated at 2022-06-25 17:57:28.321871
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    var_1 = _AuthTypeLazyChoices()
    try:
        var_2 = var_1.__iter__()
    except ImportError:
        pass
    except Exception:
        var_3 = var_1.__iter__()
    try:
        var_4 = var_1.__iter__()
    except Exception:
        var_5 = var_1.__iter__()
    except ImportError:
        var_6 = var_1.__iter__()
    var_7 = var_1.__iter__()



# Generated at 2022-06-25 17:57:37.963270
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert test_case_0()

auth_type_lazy_choices = _AuthTypeLazyChoices()
auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    default=None,
    choices=auth_type_lazy_choices,
    help='''
    The authentication mechanism. The following types are supported:
    {0}
    '''.format(
        '\n'.join(
            '    {0}'.format(name) for name in sorted(
                plugin_manager.get_auth_plugin_mapping().keys()
            )
        )
    )
)

# Generated at 2022-06-25 17:57:50.185223
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    # Test with non-existing value.
    auth_type_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_0.__contains__('')
    assert var_0

    # Test with existing value.
    auth_type_1 = _AuthTypeLazyChoices()
    var_1 = auth_type_1.__contains__('aws4')
    assert var_1

    # Test with non-existing value.
    auth_type_2 = _AuthTypeLazyChoices()
    var_2 = auth_type_2.__contains__('basic')
    assert var_2

    # Test with existing value.
    auth_type_3 = _AuthTypeLazyChoices()
    var_3 = auth_type_3.__contains__('aws4')
    assert var

# Generated at 2022-06-25 17:57:59.450206
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices.__iter__(), Iterator)

auth.add_argument(
    '--auth-type',
    metavar='TYPE',
    type=str,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specify a custom auth type to be used.

    Available types: {', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))}.

    '''
)

#######################################################################
# Timeouts
#######################################################################

timeouts = parser.add_argument_group(title='Timeouts')

# Generated at 2022-06-25 17:58:12.206339
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('~n:>7Vp')

auth_type_lazy_choices = _AuthTypeLazyChoices()


# Generated at 2022-06-25 17:58:20.367744
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:58:22.011186
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert type(test_case_0().__class__) == type(test_case_1().__class__)


# Generated at 2022-06-25 17:58:25.269359
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    pass


# Generated at 2022-06-25 17:58:35.548049
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 17:58:38.361317
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('basic')
    assert var_0 == True


# Generated at 2022-06-25 17:58:48.634828
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    assert test_case_0() is None

test__AuthTypeLazyChoices___iter__()

auth_type_lazy_choices = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=auth_type_lazy_choices,
    help='''
    The authentication mechanism to be used.
    Possible values depend on build-time configuration.

    ''',
)


# Generated at 2022-06-25 17:58:49.815046
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices().__contains__("Basic")


# Generated at 2022-06-25 17:58:53.213228
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('0')


# Generated at 2022-06-25 17:58:54.410063
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()


# Generated at 2022-06-25 17:59:05.055199
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    for i in range(0, 10):
        test_case_0()

auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default='auto',
    help='''
    The mechanism for authenticating the request.
    Allowed values:

    * basic
    * digest
    * netrc (alias for "basic")

    Other types are supported if the plugin is installed, e.g.:

        {plugins}

    The default is "auto", which will fallback to "basic" when the response
    code is 401 and basic authentication is detected.

    '''.format(plugins=', '.join(
        '"{}"'.format(a) for a in sorted(plugin_manager.get_auth_plugin_mapping())
    ))
)


# Generated at 2022-06-25 17:59:28.923516
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()

auth.add_argument(
    '--auth-type',
    metavar='PLUGIN',
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an auth plugin that should be used to handle the specified
    credentials. It supersedes the auth plugin inferred from the provided
    credentials (if any).
    ''',
)

# ``requests.request`` keyword arguments.
verify = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 17:59:40.183282
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert 'base64' in auth_type_lazy_choices_0
    assert 'basic' in auth_type_lazy_choices_0
    assert 'digest' in auth_type_lazy_choices_0
    assert 'hawk' in auth_type_lazy_choices_0
    assert 'multipart' in auth_type_lazy_choices_0
    assert 'netrc' in auth_type_lazy_choices_0
    assert 'ntlm' in auth_type_lazy_choices_0


# Generated at 2022-06-25 17:59:50.466868
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = _AuthTypeLazyChoices()
    test_case_0()

auth.add_argument(
    '--auth-type',
    metavar='AUTHTYPE',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help='''
    If specified, use a custom authentication type (plugin).
    For example, you can use a custom auth plugin for OAuth 2 with JWT.

    '''
)

auth.add_argument(
    '--auth-no-challenge',
    action='store_true',
    dest='auth_no_challenge',
    default=False,
    help='''
    If set, the authentication credentials are sent in the initial request
    instead of waiting for 401 Unauthorized response.

    '''
)


#######################################################################


# Generated at 2022-06-25 17:59:56.273524
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    '''
    Method that tests constructor of class _AuthTypeLazyChoices
    '''
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

    assert auth_type_lazy_choices_0.__iter__() is not None

auth.add_argument(
    '--auth-type',
    metavar='AUTH_TYPE',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help=f'''
    Specifies the type of authentication to use. It must be one of:

        {','.join(sorted(plugin_manager.get_auth_plugin_mapping()))}

    The option is ignored if --auth is not set.

    '''
)

# Generated at 2022-06-25 18:00:01.873128
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__("Digest")
    assert var_0 == True
    var_0 = auth_type_lazy_choices_0.__contains__("Basic")
    assert var_0 == True


# Generated at 2022-06-25 18:00:12.799033
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    pass

auth.add_argument(
    '--auth-type',
    default=AUTH_TYPES_REQUESTS_DEFAULT,
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The auth mechanism to be used.
    Defaults to "basic". Possible values: {auth_types}

    '''.format(auth_types=', '.join(
        sorted(plugin_manager.get_auth_plugin_mapping().keys())))
)

auth.add_argument(
    '--auth-endpoint',
    default=AUTH_ENDPOINT_REQUESTS_DEFAULT,
    metavar='URL',
    help='''
    The endpoint used to obtain the access token. Defaults to "/".

    '''
)



# Generated at 2022-06-25 18:00:22.225555
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert isinstance(auth_type_lazy_choices_0, _AuthTypeLazyChoices)
    assert isinstance(auth_type_lazy_choices_0, object)


auth.add_argument(
    '--auth-type',
    choices=_AuthTypeLazyChoices(),
    default=None,
    help=f'''
    Specify an authentication plugin.

    If it is not specified, then HTTPie will try to guess it based on --auth
    value.

    The following authentication plugins are available:
    {' '.join(sorted(plugin_manager.get_auth_plugin_mapping().keys()))}

    '''
)

# ``requests.request`` keyword arguments.
authentication = parser

# Generated at 2022-06-25 18:00:24.980039
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    assert True


# Generated at 2022-06-25 18:00:36.192013
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_0 = test_case_0()
auth.add_argument(
    '--auth-type',
    default=None,
    choices=_AuthTypeLazyChoices(),
    help='''
    Specify an authentication plugin by name ({auth_plugins}) or a path to a
    Python module defining one.

    '''
)

#######################################################################
# Redirects and follow
#######################################################################

follow_redirects = parser.add_argument_group(title='Redirects')
follow_redirects.add_argument(
    '--follow', '-F',
    action='store_true',
    help='''
    Follow HTTP redirects. Redirects are not printed by default. Use
    --all to display them.

    '''
)

# Generated at 2022-06-25 18:00:42.775589
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    var_2 = None
    var_3 = None
    test_case_0()
    var_0 = _AuthTypeLazyChoices()
    if (var_0.__iter__() == var_2):
        var_1 = True
    else:
        var_1 = False
    assert var_1


# Generated at 2022-06-25 18:01:22.159714
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices = _AuthTypeLazyChoices()
    var_1 = auth_type_lazy_choices.__contains__("aws-auth")


# Generated at 2022-06-25 18:01:30.198953
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    try:
        _AuthTypeLazyChoices()
        assert True
    except NameError:
        raise AssertionError("Errors in call to __AuthTypeLazyChoices")


auth_type = auth.add_mutually_exclusive_group()



# Generated at 2022-06-25 18:01:37.397598
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    """
    Assert that the type of a returned value is correct
    """
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    try:
        assert type(var_0) is type(iter(tuple()))
    except AssertionError:
        raise AssertionError(var_0)


# Generated at 2022-06-25 18:01:48.223678
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    var_1 = auth_type_lazy_choices_0.__iter__()
    var_2 = var_1.__next__()
    assert var_2 == 'aws'
    var_3 = auth_type_lazy_choices_0.__iter__()
    var_4 = var_3.__next__()
    assert var_4 == 'aws'
    var_5 = auth_type_lazy_choices_0.__iter__()
    var_6 = var_5.__next__()
    assert var_6 == 'aws'
    var_7 = var_1.__next__()
    assert var

# Generated at 2022-06-25 18:01:51.796154
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__contains__('digest')


# Generated at 2022-06-25 18:02:03.950213
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()
auth.add_argument(
    '--auth-type',
    default='auto',
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help='''
    The authentication mechanism.
    {default} to automatically detect the authentication scheme by
    examining the WWW-Authenticate response header.
    {supported}
    '''.format(
        default=colorize(Auto,) + ' ' + Auto.description,
        supported='\n'.join(
            '{0} {1}'.format(colorize(key), plugin.description)
            for key, plugin in plugin_manager.get_auth_plugin_mapping().items()
        )
    ).strip()
)

# Generated at 2022-06-25 18:02:06.833836
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 18:02:08.875633
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    arg_0 = 'basic'
    var_0 = _AuthTypeLazyChoices()
    var_0.__contains__(arg_0)


# Generated at 2022-06-25 18:02:15.868463
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()

auth.add_argument(
    '--auth-type',
    choices='?_AuthTypeLazyChoices()',
    default='auto',
    help=f'''
    Force HTTPie to use a specified authentication plugin. By default, HTTPie
    detects the auth plugin automatically.

    '''
)
auth.add_argument(
    '--ignore-netrc',
    action='store_true',
    default=False,
    help='''
    Do not use credentials from the .netrc file.

    '''
)

#######################################################################
# SSL
#######################################################################

ssl_group = parser.add_argument_group(title='SSL')

# Generated at 2022-06-25 18:02:19.873345
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    auth_type_lazy_choices_0.__iter__()
    var_0 = auth_type_lazy_choices_0.__iter__()


# Generated at 2022-06-25 18:03:34.483359
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    assert test_case_0()

auth.add_argument(
    '--auth-type',
    type=str.lower,
    default='basic',
    choices=_AuthTypeLazyChoices(),
    metavar='TYPE',
    help='''
    The authentication mechanism to be used, if --auth is set
    (default is "basic").

    The only built-in mechanism is "basic".

    Run `{program} plugins` to show all available authentication plugins.

    '''.format(program=PROG)
)



# Generated at 2022-06-25 18:03:41.235174
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()



# Generated at 2022-06-25 18:03:42.108112
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    test_case_0()


# Generated at 2022-06-25 18:03:52.831129
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    test_case_0()

auth.add_argument(
    '--auth-type',
    default='auto',
    choices=_AuthTypeLazyChoices(),
    # help='''
    # The auth mechanism to use.
    #
    # If 'auto' (default), HTTPie tries to determine the auth mechanism
    # from the provided credentials.
    #
    # The supported auth mechanisms are:
    #     {auth_types}
    #
    # '''.format(
    #     auth_types=', '.join(sorted(plugin_manager.get_auth_plugin_mapping()))
    # ),
)

# Generated at 2022-06-25 18:03:54.653348
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    test_case_0()


# This is a special case when the developer directly calls the main function
# outside the http executable.

# Generated at 2022-06-25 18:04:03.117635
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    var_0 = auth_type_lazy_choices_0.__iter__()
    assert var_0 == sorted(plugin_manager.get_auth_plugin_mapping().keys())

auth.add_argument(
    '--auth-type',
    default=None,
    metavar='TYPE',
    choices=_AuthTypeLazyChoices(),
    help=f'''
    The authentication mechanism to be used. Recognized values are those that
    have registered authentication plugins. See "http --help-auth" for a list
    of currently available authentication plugins.

    '''
)

# Generated at 2022-06-25 18:04:10.148569
# Unit test for constructor of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices():
    mock_auth_plugin_mapping_0 = mock.Mock()
    with mock.patch.object(plugin_manager, 'get_auth_plugin_mapping', new=mock_auth_plugin_mapping_0):
        assert hasattr(_AuthTypeLazyChoices(), '__iter__')()
        assert callable(_AuthTypeLazyChoices().__iter__)

test__AuthTypeLazyChoices()

auth_plugin_mock_func_0 = mock.Mock(return_value=None)

# Generated at 2022-06-25 18:04:14.446690
# Unit test for method __iter__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___iter__():
    auth_type_lazy_choices_0 = _AuthTypeLazyChoices()
    # Testing if the method iterator of '_AuthTypeLazyChoices' is working properly
    try:
        var_0 = auth_type_lazy_choices_0.__iter__()
        assert (True)
    except:
        assert (False)


# Generated at 2022-06-25 18:04:16.796948
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    assert _AuthTypeLazyChoices.__contains__(_AuthTypeLazyChoices, 'basic') == True


# Generated at 2022-06-25 18:04:18.269887
# Unit test for method __contains__ of class _AuthTypeLazyChoices
def test__AuthTypeLazyChoices___contains__():
    _0 = _AuthTypeLazyChoices()
    _1 = 'http_basic'
    _1 = _0.__contains__(_1)
    return _1
