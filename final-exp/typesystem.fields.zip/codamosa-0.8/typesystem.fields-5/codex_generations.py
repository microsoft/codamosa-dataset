

# Generated at 2022-06-12 15:41:18.406565
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(None, allow_null=False)
    with pytest.raises(AssertionError):
        Const(None, allow_null=True)
    with pytest.raises(AssertionError):
        Const(True, allow_null=False)
    with pytest.raises(AssertionError):
        Const(True, allow_null=True)
    Const(True)


# Generated at 2022-06-12 15:41:21.132579
# Unit test for method serialize of class Array
def test_Array_serialize():
    # array_field is of type Array
    array_field = Array()
    # serialized_value is of type int
    serialized_value = array_field.serialize(value)
    assert isinstance(serialized_value, (int, float, bool, str, list, dict))


# Generated at 2022-06-12 15:41:28.243118
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(
        choices=[
            ('foo', 'foo'),
            ('bar', 'bar'),
            ('foo bar', 'foo bar'),
        ]
    )
    # Test that method rejects unallowed values
    assert choice.validate_or_error('').is_error()
    assert choice.validate_or_error('unknown').is_error()
    # Test that method accepts allowed values
    assert choice.validate_or_error('foo').is_valid()
    assert choice.validate_or_error('bar').is_valid()
    assert choice.validate_or_error('foo bar').is_valid()


# Generated at 2022-06-12 15:41:31.326851
# Unit test for method validate of class String
def test_String_validate():
    x = String(title='Sample title', description='Sample description')
    y = x.validate('aa') 
    assert y == "aa"
# Test case for method validate of class String

# Generated at 2022-06-12 15:41:34.897981
# Unit test for method validate of class Union
def test_Union_validate():
    # pos
    field = Union(any_of=[])
    assert field.validate(value = {}) is None
    # neg
    field = Union(any_of=[])
    with pytest.raises(ValidationError):
        field.validate(value = None)
    
    

# Generated at 2022-06-12 15:41:46.803808
# Unit test for method validate of class Union
def test_Union_validate():
    # simple test case with integer field
    field = Union([Integer()])
    assert field.validate([1]) == [1]
    # simple test case with string field
    field = Union([String()])
    assert field.validate(["hello"]) == ["hello"]
    # complex test case with both integer and string field
    field = Union([Integer(), String()])
    assert field.validate(["hello"]) == ["hello"]
    assert field.validate([1]) == [1]
    # test case with nested union
    field = Union([Union([String(), Integer()])])
    assert field.validate(["hello"]) == ["hello"]
    assert field.validate([1]) == [1]
    # test case with integer, string and boolean field
    field = Union([Integer(), String(), Boolean()])
    assert field

# Generated at 2022-06-12 15:41:53.946353
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String(format="date"))
    assert field.validate([None]) == ["None"]
    
    field = Array(items=Integer())
    assert field.validate([None]) == [None]
    
    field = Array(items=Integer())
    assert field.validate(["1","2"]) == [1,2]
    
    field = Array(items=Integer())
    try:
        field.validate([1,2.2,3])
    except ValidationError as e:
        assert str(e) == 'Invalid value for "1": Must be an integer.'


# Generated at 2022-06-12 15:41:57.520033
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field()
    v = f.validate_or_error(1)
    assert isinstance(v.value, int)
    assert isinstance(v.error, ValidationError)



# Generated at 2022-06-12 15:41:59.945379
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = []
    for i in range(4):
        any_of.append(String())
    union = Union(any_of)
    value = "hi"
    assert union.validate(value) == "hi"
    value = 2
    with raises(ValidationError):
        union.validate(value)

# Generated at 2022-06-12 15:42:00.575096
# Unit test for method validate of class Union
def test_Union_validate():
    pass


# Generated at 2022-06-12 15:42:16.829932
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=[("a", "apple"), ("b", "banana"), ("c", "coconut")])
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    try:
        choice.validate("d")
    except ValidationError:
        assert True



# Generated at 2022-06-12 15:42:26.052421
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Field2(Field):
        def __init__(self, *args, **kwargs):
            super(Field2, self).__init__(*args, **kwargs)

    f2 = Field2()
    assert f2.get_default_value() == None

    class Field3(Field):
        def __init__(self, *args, **kwargs):
            super(Field3, self).__init__(*args, **kwargs)

        def __new__(cls, **kwargs):
            instance = super(Field3, cls).__new__(cls)
            instance.default = lambda: None
            return instance

    f3 = Field3()
    assert f3.get_default_value() == None



# Generated at 2022-06-12 15:42:31.071668
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Str(Field):
        def validate(self, value, strict=False):
            return ""
    class Bool(Field):
        def validate(self, value, strict=False):
            return True
    field = Str() | Bool()
    assert hasattr(field, "validate")

# Generated at 2022-06-12 15:42:34.289359
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    number = Boolean()
    assert number.validate('true') == True
    assert number.validate('false') == False
    assert number.validate('on') == True
    assert number.validate('off') == False
    assert number.validate('1') == True
    assert number.validate('0') == False
    assert number.validate(' ') == False
    assert number.validate('null') == False


# Generated at 2022-06-12 15:42:43.456510
# Unit test for method validate of class Array
def test_Array_validate():
    # test when value is None
    value = None
    items = None
    additional_items = 0
    min_items = 0
    max_items = 5
    unique_items = True
    field = Array(items, additional_items, min_items, max_items, unique_items)
    field.validate(value)

    # test when value is empty
    value = []
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages == [Message(code='min_items', text='Must have at least 0 items.', key=None)]

    # test when value is too large
    value = [1, 2, 3, 4, 5, 6]
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages

# Generated at 2022-06-12 15:42:52.557076
# Unit test for method validate of class Array
def test_Array_validate():

    a = Array(items=Field(type="string"), min_items=1)
    b = Array(items=Field(type="string"), min_items=1)

    print("\n# Unit test for method validate of class Array.\n")

    try:
        print("# Array a: ", a.validate(["a"]))
        print("# Array b: ", b.validate(["b"]))
    except ValidationError as err:
        print("# Error: ", err.messages())
test_Array_validate()


# Generated at 2022-06-12 15:42:55.555710
# Unit test for method validate of class String
def test_String_validate():
    test = String(
    )
    try:
        assert test.validate(None) == None
    except ValidationError as e:
        print('Error:', e)
    

# Generated at 2022-06-12 15:43:03.913108
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number(description="description", title="title", format= "null", allow_null= True)
    assert(n.validate(1.5)==1.5)
    assert(n.validate(0.5)==0.5)
    assert(n.validate(-1.5)==-1.5)
    assert(n.validate(float('inf')) is None)
    assert(n.validate(float('nan')) is None)
    assert(n.validate(0)==0)
    assert(n.validate('test') is None)
    assert(n.validate(False) is None)
    assert(n.validate(None) is None)



# Generated at 2022-06-12 15:43:06.383168
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("") == ""



# Generated at 2022-06-12 15:43:07.263042
# Unit test for constructor of class Const
def test_Const():
    try:
        const = Const(2)
    except AssertionError:
        pass


# Generated at 2022-06-12 15:43:27.270066
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    dummy = Field()
    dummy.default = "dummy"
    assert dummy.get_default_value() == "dummy"


# Generated at 2022-06-12 15:43:29.878712
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert len(Choice().validate('xD') == 'xD')
    assert len(Choice().validate('xD') != 'xD1')


# Generated at 2022-06-12 15:43:36.456971
# Unit test for method validate of class Number
def test_Number_validate():
    class Integer(Number):
        numeric_type=int
        precision = "1"
        multiple_of = 2

    number = Integer(allow_null=True, minimum=2)
    assert number.validate("3.0") == 3
    assert number.validate("3") == 3
    assert number.validate(3) == 3
    assert number.validate(3.2) == 3
    assert number.validate("4.0") == 4
    assert number.validate("4") == 4
    assert number.validate(4) == 4
    assert number.validate(4.2) == 4



# Generated at 2022-06-12 15:43:44.559375
# Unit test for method __or__ of class Field
def test_Field___or__():
    import unittest
    from typesystem.types import String
    from typesystem.types import Number
    from typesystem.types import Union
    from typesystem.types import Integer

    class TestField___or__(unittest.TestCase):
        def test_return_type(self):
            #TODO: Tests for method __or__ of class Field
            assert True # TODO: implement your test here
    unittest.main()


# Generated at 2022-06-12 15:43:48.710624
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_choice = Choice(label="test_choice", choices=[1, 2, 3])
    assert test_choice.validate(1) == 1
    assert test_choice.validate(4) == "choice"
    assert test_choice.validate("") == "required"

# Class Dictionary

# Generated at 2022-06-12 15:44:01.232078
# Unit test for constructor of class String
def test_String():
    s = String()
    # print (s.trim_whitespace)
    # print (s.title)
    # print (s.description)
    # print (s.default)
    # print (s.errors)
    # print("Now testing 'String' constructor")
    
    # Testing for error cases
    assert isinstance(s, String)
    assert s.trim_whitespace == True
    assert s.title == ""
    assert s.description == ""
    assert s.default == NO_DEFAULT

# Generated at 2022-06-12 15:44:11.597919
# Unit test for method serialize of class Array
def test_Array_serialize():
    str_schema = String(max_length=8, allow_null=True)
    int_schema = Integer(allow_null=True)
    arr_schema = Array(items=[str_schema, int_schema], allow_null=True)
    assert arr_schema.serialize(["abc", 4]) == ["abc", 4]
    assert arr_schema.serialize([4, "abc"]) == ["4", "abc"]
    assert arr_schema.serialize(["abc", 4, 9]) == ["abc", 4, 9]
    assert arr_schema.serialize(None) == None



# Generated at 2022-06-12 15:44:17.120408
# Unit test for method validate of class String
def test_String_validate():
    message_title = 'test'
    assert (String(title=message_title).validate(value='string', strict=False) == 'string')
    assert (String(title=message_title).validate(value='', strict=False) == '')
    assert (String(title=message_title).validate(value='1234', strict=False) == '1234')



# Generated at 2022-06-12 15:44:26.924199
# Unit test for constructor of class String
def test_String():
    # default constructor
    s = String()
    assert isinstance(s, String) and isinstance(s, Field)
    assert s.allow_null==False and s.title=="" and s.description=="" and s.allow_blank==False and s.trim_whitespace==True and s.max_length==None and s.min_length==None and s.pattern==None and s.format==None
    assert s.has_default()==False
    assert s.get_default_value()==NO_DEFAULT

# Generated at 2022-06-12 15:44:33.978397
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number(title="test",description="test",minimum=5)
    num.validate(3)
    test = Number(title="test",description="test",minimum=5)
    test.validate(3)
    test.validate(5)
    test.validate(6)
    num.validate(5)
    test.validate(10)
    num.validate(6)
    num.validate(10)
    test.validate(7)
    num.validate(7)



# Generated at 2022-06-12 15:44:50.774552
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a","a")])
    assert choice.validate("b") == "b"
    try:
        choice.validate("c")
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-12 15:45:00.287575
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Field()
    )

    assert field.validate([]) == []
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate(None) == None

    field = Array(
        items=[Field(), Field(), Field()],
        additional_items=True
    )

    assert field.validate([1, 2]) == [1, 2]
    assert field.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert field.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    field = Array(
        items=[Field(), Field(), Field()],
        additional_items=False
    )


# Generated at 2022-06-12 15:45:10.113374
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(name="choice", choices=["Y", "N"])
    assert choice.validate("Y") is "Y"
    assert choice.validate("N") is "N"
    with pytest.raises(ValidationError) as exc_info:
        choice.validate("")
    assert str(exc_info.value) == "This field is required."
    assert choice.allow_null

    choice = Choice(name="choice", choices=["Y", "N"], allow_null=False)
    with pytest.raises(ValidationError) as exc_info:
        choice.validate("")
    assert str(exc_info.value) == "Not a valid choice."
    assert not choice.allow_null

    choice = Choice(name="choice", choices=["Y", "N"])

# Generated at 2022-06-12 15:45:10.711658
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    pass

# Generated at 2022-06-12 15:45:19.260311
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[1, 2])
    result = field.validate('1')
    assert result == '1'
    try:
        field.validate('3')
    except:
        assert True
    assert field.validate('2') == '2'
    field.allow_null = True
    assert field.validate(None, strict=False) == None
    field.allow_null = False
    try:
        field.validate(None, strict=False)
    except:
        assert True
    result = field.validate('', strict=True)
    assert result == ''
    try:
        result = field.validate('', strict=False)
    except:
        assert True
    try:
        field.validate('', strict=True)
    except:
        assert True

# Generated at 2022-06-12 15:45:26.332697
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean(allow_null = False)
    assert b.validate(False) == False
    assert b.validate("true") == True
    assert b.validate("on") == True
    assert b.validate("1") == True
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate("null") == None
    assert b.validate("") == None



# Generated at 2022-06-12 15:45:29.720481
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("spa", "Spanish"), ("eng", "English")])
    assert choice.validate("spa") == "spa"
    assert choice.validate("eng") == "eng"


# Generated at 2022-06-12 15:45:35.804952
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.has_default() == False
    assert field.get_default_value() == None
    #
    field = Field(default=1)
    assert field.has_default() == True
    assert field.get_default_value() == 1
    #
    def f():
        return 2
    field = Field(default=f)
    assert field.has_default() == True
    assert field.get_default_value() == 2


# Generated at 2022-06-12 15:45:39.323140
# Unit test for method validate of class String
def test_String_validate():
    id = String(pattern = "/a/")
    assert id.validate("a") == "a"
    try:
        id.validate("h")
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-12 15:45:49.475550
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=["black", "white"])
    assert field.validate(None) == None
    assert field.validate("black") == "black"
    assert field.validate("white") == "white"
    with pytest.raises(ValidationError):
        field.validate(None, strict=True)
    with pytest.raises(ValidationError):
        field.validate(42)
    with pytest.raises(ValidationError):
        field.validate("orange")
    with pytest.raises(ValidationError):
        field.validate("")
    with pytest.raises(ValidationError):
        field.validate("white", strict=False)
    with pytest.raises(ValidationError):
        field.validate("orange", strict=True)


# Generated at 2022-06-12 15:46:10.643114
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Boolean(default=False, allow_null=True),
        additional_items=Boolean(default=False, allow_null=True),
        allow_null=True,
    )
    assert_valid(field, [True], [True])



# Generated at 2022-06-12 15:46:20.610318
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = 3
    def default():
        return a
    # case 1: default=NO_DEFAULT
    new_field = Field()
    assert new_field.get_default_value() is None
    # case 2: default=default()
    new_field.default = default()
    assert new_field.get_default_value() == 3
    # case 3: default=3
    new_field.default = 3
    assert new_field.get_default_value() == 3
    # case 4: default=callable
    new_field.default = default
    assert new_field.get_default_value() == 3


# Generated at 2022-06-12 15:46:30.352421
# Unit test for constructor of class Array
def test_Array():
    field = Array(
        items=[Integer(), Boolean()],
        additional_items=True,
        min_items=1,
        max_items=2,
        exact_items=None,
        unique_items=False,
        allow_null=True,
        default=None,
    )
    assert field.items == [Integer(), Boolean()]
    assert field.additional_items == True
    assert field.min_items == 1
    assert field.max_items == 2
    assert field.exact_items == None
    assert field.unique_items == False
    assert field.allow_null == True
    assert field.default == None



# Generated at 2022-06-12 15:46:33.974132
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_1 = String()
    field_2 = String()
    union = field_1 | field_2
    assert union.any_of[0] is field_1
    assert union.any_of[1] is field_2



# Generated at 2022-06-12 15:46:43.435687
# Unit test for method validate of class Array
def test_Array_validate():
    array_field = Array(items=[String(max_length=10)])
    assert array_field.validate(["hello","world"]) == ["hello","world"]
    assert array_field.validate(["hello","world", "to", "my", "world"]) == ["hello","world", "to", "my", "world"]
    assert array_field.validate(["hello","wow", "why", "you", "are", "so"]) == ["hello","wow", "why", "you", "are", "so"]
    try:
        array_field.validate(["hello","wow"])
    except ValidationError:
        assert True
    array_field = Array(items=[String(max_length=10)],
    max_items=2, min_items=2)

# Generated at 2022-06-12 15:46:46.719533
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert (
        Field() | Field()
    ).__class__ == Union
# End unit test for method __or__ of class Field


# Generated at 2022-06-12 15:46:53.462797
# Unit test for constructor of class Array
def test_Array():
    schema = Array(
        items=String(),
        additional_items=True,
        min_items=1,
        max_items=2,
        unique_items=True,
    )
    assert schema == {
        "type": "array",
        "items": {"type": "string"},
        "additionalItems": True,
        "minItems": 1,
        "maxItems": 2,
        "uniqueItems": True,
    }

test = test_Array()


# Generated at 2022-06-12 15:46:58.345739
# Unit test for constructor of class Const
def test_Const():
    c = Const(const=1)
    assert c.const == 1
    assert c.errors["only_null"] == "Must be null."
    assert c.errors["const"] == "Must be the value '1'."
    assert c.validate(value=1) == 1
    assert c.validate(value=None) == None
    try:
        c.validate(value=2)
    except ValidationError as e:
        assert e.messages[0].code == "const"
    else:
        assert False, "Expected error"



# Generated at 2022-06-12 15:47:09.067014
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["", "test"])
    assert choice.validate("test") == "test"
    assert choice.validate(None) is None
    assert choice.validate("") == ""
    assert choice.validate("unexpected") == "unexpected"
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate("test1")
    with pytest.raises(ValidationError):
        choice.validate("unexpected")



# Generated at 2022-06-12 15:47:11.037411
# Unit test for constructor of class Const
def test_Const():
    const = Const(42)
    assert const.const == 42

test_Const()


# Generated at 2022-06-12 15:47:19.492187
# Unit test for method validate of class Array
def test_Array_validate():
    with pytest.raises(ValidationError):
        Array(unique_items=True).validate([1, 1])

# Validate that errors are of type ValidationError

# Generated at 2022-06-12 15:47:24.169260
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    # test for: value is None
    try:
        validated_value = field.validate(None)
    except ValidationError:
        validated_value = None
    assert validated_value == None
    # test for: value is not None, not string
    try:
        validated_value = field.validate(123)
    except ValidationError:
        validated_value = None
    assert validated_value == None
    # test for: value is not None, string, not contains '\0'
    try:
        validated_value = field.validate('abc')
    except ValidationError:
        validated_value = None
    assert validated_value == 'abc'
    # test for: value is not None, string, contains '\0'

# Generated at 2022-06-12 15:47:32.136343
# Unit test for method validate of class Number
def test_Number_validate():
    test_cases = [
        ((None,), ValidationError(code='null', text='May not be null.')),
        ((bool,), ValidationError(code='type', text='Must be a number.')),
        (('10',), 10),
        ((10,), 10),
        (('10.5',), 10.5),
        ((10.5,), 10.5),
        (('10.059',), '10.059'),
    ]
    for args, res in test_cases:
        assert Number().validate(*args) == res



# Generated at 2022-06-12 15:47:39.116006
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_obj = Choice(choices=["blue", "red", "green"])
    test_obj.validate("blue")
    test_obj.validate("red")
    test_obj.validate("green")
    with pytest.raises(ValidationError):
        test_obj.validate("yellow")
    with pytest.raises(ValidationError):
        test_obj.validate(None)
    with pytest.raises(ValidationError):
        test_obj.validate("")
    with pytest.raises(ValidationError):
        test_obj.validate(True)
    with pytest.raises(ValidationError):
        test_obj.validate(False)
    with pytest.raises(ValidationError):
        test_obj.validate(1)

# Generated at 2022-06-12 15:47:51.912790
# Unit test for method validate of class Object
def test_Object_validate():
    import json
    from pprint import pprint
    from json.decoder import JSONDecodeError


    # Define this function to treat the exception of JSONDecodeError.
    def test_Object_validate_handler(test_case):
        try:
            test_case()
        except JSONDecodeError as err:
            print(f'JSONDecodeError: {err.msg}')


    test_Object_validate_handler(test_Object_validate)

    #TODO:
    #  Improve the error message
    #  Allow only one pattern property
    #  Allow additional properties
    #  Check if vaildation works properly with nested object


    class ExampleSchema(Schema):
        name = String(required=True)
        age = Integer(required=True)

# Generated at 2022-06-12 15:47:58.760835
# Unit test for method __or__ of class Field
def test_Field___or__():
# Var: other
    from .fields.union import Union
# Var: expected_result
    expected_result = None
# Var: any_of
    any_of = [Field()]
    other = Union(any_of=any_of)
# Var: self
    self = Field()
    self = self | other
    expected_result = Union([Field(), Union(any_of=any_of)])
    assert self == expected_result

# Generated at 2022-06-12 15:48:05.887483
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Integer(default=1)
    )
    value = [2, 3, 4]
    result, err = field.validate_or_error(value)
    assert result == [2, 3, 4]

    field = Array(
        items=Integer(default=1)
    )
    value = [2, 'a', 4]
    result, err = field.validate_or_error(value)
    assert isinstance(err, ValidationError)
    assert len(err.messages()) == 1

    field = Array(
        items=Integer(default=1)
    )
    value = [2]
    result, err = field.validate_or_error(value)
    assert result == [2]


# Generated at 2022-06-12 15:48:08.588394
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Float, String

    Float | String


# Generated at 2022-06-12 15:48:12.983215
# Unit test for method __or__ of class Field
def test_Field___or__():
    import typesystem.fields

    field_1=typesystem.fields.String()
    field_2=typesystem.fields.String()

    union_fields=field_1 | field_2
    assert isinstance(union_fields, typesystem.fields.Union)
    assert len(union_fields.any_of) == 2

# Generated at 2022-06-12 15:48:15.807320
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() == None
    assert Field(default=10).get_default_value() == 10
    assert Field(default=10, allow_null=True).get_default_value() == None

# Generated at 2022-06-12 15:48:27.380022
# Unit test for method validate of class Array
def test_Array_validate():
    print("Testing validate of field Array")
    values = [1, 2, 3, 4]
    obj = Array(min_items=1,max_items=5)
    validation_result = obj.validate(values, strict=False)
    print("Values validated successfully: ", obj.validate(values, strict=False))
    assert validation_result == values, "Value validation unsuccessful"


# Generated at 2022-06-12 15:48:35.774123
# Unit test for method validate of class Array
def test_Array_validate():
  #Checks behaviour when array isn't initialized
  array = Array()
  value = [1,2,3]
  with pytest.raises(ValueError) as e:
    array.validate(value)
  assert 'items' in str(e.value)

  #Checks behaviour when array is empty
  array = Array(items = [Integer(min_value=1)])
  value = []
  with pytest.raises(ValidationError) as e:
    array.validate(value)
  assert 'empty' in str(e.value)
  #Checks behaviour when array contains other data types
  value = [1,"a"]
  with pytest.raises(ValidationError) as e:
    array.validate(value)
  assert 'must be an integer' in str(e.value)

 

# Generated at 2022-06-12 15:48:40.422453
# Unit test for method __or__ of class Field
def test_Field___or__():
    def test_or_without_unions():
        class TestField(Field):
            pass

        field1 = TestField()
        field2 = TestField()
        union = field1 | field2

        assert isinstance(union, Union)
        assert isinstance(union.any_of[0], TestField)
        assert isinstance(union.any_of[1], TestField)

    def test_or_with_unions():
        class TestField(Field):
            pass

        field1 = TestField()
        field2 = TestField()
        field3 = TestField()
        union1 = field1 | field2
        union2 = field3 | union1

        assert isinstance(union2, Union)
        assert isinstance(union2.any_of[0], TestField)

# Generated at 2022-06-12 15:48:53.125888
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test with valid value
    field = Choice(choices=[(0, '0'), (1, '1'), (2, '2')], default=0)
    result = field.validate(0)
    assert isinstance(result, int)
    assert result == 0
    # Test with invalid value
    field = Choice(choices=[(0, '0'), (1, '1'), (2, '2')], default=0)
    try:
        field.validate(3)
        assert False
    except ValidationError as e:
        assert isinstance(e.code, str)
        assert e.code == "choice"
    # Test with null value
    field = Choice(choices=[(0, '0'), (1, '1'), (2, '2')], default=0)
    result = field.validate

# Generated at 2022-06-12 15:48:59.396487
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() == None
    assert Field(default=1).get_default_value() == 1
    assert Field(default=None).get_default_value() == None
    assert Field(default=lambda: 5).get_default_value() == 5
    assert Field(default=lambda: None).get_default_value() == None


# Generated at 2022-06-12 15:49:07.940847
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for when no property name matches key
    field = Object()
    # No error messages
    assert field.validate({'property1':20}) == {'property1':20}
    # Error messages
    try:
        field.validate({1:'property1'})
        assert False
    except ValidationError as e:
        assert len(e.messages) == 1
        assert e.messages[0].text == 'All object keys must be strings.'
        assert e.messages[0].code == 'invalid_key'
        assert e.messages[0].index == [1]
    # Test for when keys are not in properties or pattern properties
    field = Object(properties={'property1':Field(), 'property2':Field()},
                   pattern_properties={'^[A-Z]':Field()})
    #

# Generated at 2022-06-12 15:49:16.496334
# Unit test for method validate of class Array
def test_Array_validate():
    field1 = Int(default=0)
    field2 = String()
    field3 = String()
    schema = Array(items=[field1,field2])
    assert schema.validate(["", "", "", "", "", ""]) == [0, "", "", "", "", ""]
    assert schema.validate([1, "a", 2, "b", 3, "c", 4, "d", 5, "e", 6, "f"]) == [1, "a", 2, "b", 3, "c", 4, "d", 5, "e", 6, "f"]
    schema = Array(items=[field1,field2], min_items=0, max_items=3)