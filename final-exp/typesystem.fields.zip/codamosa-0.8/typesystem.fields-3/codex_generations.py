

# Generated at 2022-06-12 15:40:32.881386
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union(
        any_of=[
            Text(
                description="The ID uniquely identifies an entry. It can be any non-empty string up to 255 characters.",
                min_length=1,
                max_length=255,
                pattern="^[^\s]+$",
            ),
            Integer(
                description="The ID uniquely identifies an entry. It can be any integer number.",
                minimum=1,
                maximum=9223372036854775807,
            ),
        ],
    )
    x = u.validate("abcd")
    y = u.validate("abcd1234")
    z = u.validate("12345")
    assert x == "abcd"
    assert y == "abcd1234"
    assert z == 12345


# Generated at 2022-06-12 15:40:43.276882
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items = String(max_length = 3,min_length = 2),min_items = 2,max_items = 2)
    value = ["a","ab"]
    value = field.validate(value)
    assert value == ["a","ab"]
    value = field.serialize(value)
    assert value == ["a","ab"]
    value = ["a","ab","ac"]
    with pytest.raises(ValidationError):
        value = field.validate(value)
    value = ["a"]
    with pytest.raises(ValidationError):
        value = field.validate(value)
    value = []
    with pytest.raises(ValidationError):
        value = field.validate(value) 
    value = ["a","a"]

# Generated at 2022-06-12 15:40:49.730233
# Unit test for constructor of class Choice
def test_Choice():
    # Given
    list_items = [
        ("Spider", "Spider"),
        ("Cat", "Cat"),
        ("Puppy", "Puppy")
    ]
    
    # When
    choice = Choice(choices=list_items)

    # Then
    assert choice.choices == list_items
    for key, value in choice.choices:
        assert key == value
    

# Generated at 2022-06-12 15:40:51.918404
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = Field()
    assert a.get_default_value() == None


# Generated at 2022-06-12 15:40:59.811577
# Unit test for method validate of class Object
def test_Object_validate():
    class Person(Object):
        name = String(default="unknown")
        age = Integer(minimum=0)
        smoke = Boolean(default=False)

    # Test 1
    person = Person(properties={"name": String(default="unknown"), "age": Integer(minimum=0), "smoke": Boolean(default=False)}, pattern_properties={"": String()}, additional_properties=False, property_names=String(), min_properties=None, max_properties=None, required=["name"])
    value = {"name": "John"}             # Object
    print(person.validate(value, strict=True))
    print("*"*100)

    # Test 2

# Generated at 2022-06-12 15:41:09.170812
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        def __init__(self,*args, **kwargs):
            super().__init__(*args, **kwargs)

    testField = MyField(title='null')
    assert testField.get_default_value() == None

    testField1 = MyField(title='string', default='title')
    assert testField1.get_default_value() == 'title'

    testField2 = MyField(title='Zero')
    testField2.default = 0
    assert testField2.get_default_value() == 0

    testField3 = MyField(title='True')
    testField3.default = True
    assert testField3.get_default_value() == True

    testField4 = MyField(title='empty list', default=[])
    assert testField4.get_default_

# Generated at 2022-06-12 15:41:15.394388
# Unit test for constructor of class Const
def test_Const():
    f = Const(1)

    # Wrong type
    try:
        f.validate(3)
        assert False
    except ValidationError:
        pass
    except Exception as e:
        print(e)
        assert False    

    # Right type
    try:
        f.validate(1)
        assert True
    except ValidationError:
        assert False
    except Exception as e:
        print(e)
        assert False    


# Generated at 2022-06-12 15:41:16.580368
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array(min_items=1)
    arr.validate(['a'])


# Generated at 2022-06-12 15:41:26.537885
# Unit test for method validate of class Object
def test_Object_validate():
    myDict = {
    'properties' : {
        'first_name' : String(allow_empty=False,required=True),
        'last_name' : String(allow_empty=False,required=True),
    },
    'additional_properties':False
    }
    testObj =  Object(**myDict)
    test_data = {
        'first_name':'Maggie',
        'last_name':'Simpson',
        'age':2,
        'gender':'Female'
    }
    result = testObj.validate(test_data,strict=True)
    assert result == {
        'first_name':'Maggie',
        'last_name':'Simpson',
    }
    
    

# Generated at 2022-06-12 15:41:34.172856
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("12") == "12"
    assert String(format="date").serialize("12") == "12"
    assert String(format="datetime").serialize("12") == "12"
    assert String(format="time").serialize("12") == "12"
    assert String(format="uuid").serialize("12") == "12"
    assert String(format="email").serialize("12") == "12"
    assert String(format="ipv4").serialize("12") == "12"
    assert String(format="ipv6").serialize("12") == "12"
    assert String(format="ipv46").serialize("12") == "12"
    assert String(format="mac").serialize("12") == "12"

# Generated at 2022-06-12 15:42:07.890487
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    assert n.validate(1) == 1
    assert n.validate(-1) == -1
    assert n.validate(1.1) == 1.1
    assert n.validate(-1.1) == -1.1



# Generated at 2022-06-12 15:42:12.101993
# Unit test for method validate of class Object
def test_Object_validate():
    input_value = {"name": "abc", "age": 20}
    obj1 = Object()
    obj1.validate(input_value, strict=False)

# Generated at 2022-06-12 15:42:14.034870
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices_field=Choice(choices="abcd")
    assert choices_field.validate("a")=="a"
    assert choices_field.validate("e")=="e"



# Generated at 2022-06-12 15:42:25.449430
# Unit test for method __or__ of class Field
def test_Field___or__():
    field = Field(title="title", description="description")
    field1 = Field(title="title1", description="description1")
    field2 = Field(title="title2", description="description2")

    union = field | field1
    if not isinstance(union, Union):
        raise ValueError("union must be an instance of Union!")
    if union.any_of != [field, field1]:
        raise ValueError(f"union.any_of must be [field, field1] but it's {union.any_of}!")

    union = field | field2
    if not isinstance(union, Union):
        raise ValueError("union must be an instance of Union!")

# Generated at 2022-06-12 15:42:26.530199
# Unit test for constructor of class Const
def test_Const():
    f = Const(1)
    assert f.const == 1



# Generated at 2022-06-12 15:42:38.451454
# Unit test for method validate of class Array
def test_Array_validate():
    # Build the field used in Array class
    # Build the validator used in Array class
    items = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=0, maximum=100)
    ]
    additional_items = Boolean()
    min_items = 2
    max_items = 5
    unique_items = True
    array_field = Array(items=items, additional_items=additional_items, min_items=min_items,
                        max_items=max_items, unique_items=unique_items)

    # Test normal cases
    arr_1 = [1, 2, 3, 4, 5]
    assert array_field.validate(arr_1) == arr_1

    # Test empty array
    arr_2 = []

# Generated at 2022-06-12 15:42:45.972390
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=(('A1', 'A1'), ('B1', 'B1'), ('C1', 'C1')))
    assert field.validate('B1') == 'B1'
    assert field.validate('A1') == 'A1'
    assert field.validate('C1') == 'C1'
    field = Choice(choices=(('A2', 'A2'), ('B2', 'B2')), required=True)
    assert field.validate('B2') == 'B2'
    assert field.validate('A2') == 'A2'
    field2 = Choice(choices=(('A1', 'A1'), ('B1', 'B1'), ('C1', 'C1')), allow_null=False)

# Generated at 2022-06-12 15:42:47.846259
# Unit test for method validate of class Boolean

# Generated at 2022-06-12 15:42:53.860471
# Unit test for method validate of class Number
def test_Number_validate():
    instance = Number()
    # Test 1
    assert instance.validate("a") == None
    # Test 2
    assert instance.validate("4") == None
    # Test 3
    assert instance.validate("5") == None
    # Test 4
    assert instance.validate("6") == None
    # Test 5
    assert instance.validate(None) == None
    # Test 6
    # assert instance.validate() == None



# Generated at 2022-06-12 15:42:59.077923
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(required=True, items=Field(), null=False, strict=True)
    assert field.validate(None) is None
    assert field.validate([]) == []
    assert field.validate([None]) == [None]
    assert field.validate([1, "a", 2]) == [1, "a", 2]


# Generated at 2022-06-12 15:43:18.432638
# Unit test for method __or__ of class Field
def test_Field___or__():
    from . import Duration, Integer, Union
    field_1 = Union([Duration(), Integer()])
    field_2 = Union([Duration(), Integer()])
    result = field_1 | field_2
    assert result.any_of[0].__class__ == field_1.any_of[0].__class__
    assert result.any_of[1].__class__ == field_1.any_of[1].__class__
    assert result.any_of[2].__class__ == field_2.any_of[0].__class__
    assert result.any_of[3].__class__ == field_2.any_of[1].__class__



# Generated at 2022-06-12 15:43:25.269530
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return None
    testField = TestField()

    assert testField.get_default_value() is None

    testField.default = "good"
    assert testField.get_default_value() == "good"

    testField.default = lambda: "lambda"
    assert testField.get_default_value() == "lambda"


# Generated at 2022-06-12 15:43:28.002761
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test for when self is Union
    # Test for when other is Union
    # Test for when self is Field
    # Test for when other is Field
    pass

# Generated at 2022-06-12 15:43:29.412887
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(default = '1').validate(None) == None



# Generated at 2022-06-12 15:43:35.532572
# Unit test for constructor of class Const
def test_Const():
    # initialize a class Const
    new_const = Const(123)
    # test the value of const
    assert new_const.const == 123
    # test the default value of allow_null
    assert new_const.allow_null == False
    # test the default value of default
    assert new_const.default == None
    # test the value of errors
    assert new_const.errors['only_null'] == "Must be null."
    assert new_const.errors['const'] == "Must be the value '{const}'."


# Generated at 2022-06-12 15:43:38.238573
# Unit test for method validate of class Number
def test_Number_validate():
    x = {"title": "numeric field", "type": "number", "minimum": 1, "maximum": 10, "exclusive_minimum": 7, "exclusive_maximum": 8}
    n = Number(**x)
    x=n.validate(7.1)
    assert x == 7.1


# Generated at 2022-06-12 15:43:49.870707
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(
        items=Integer(),
        additional_items=Boolean(),
        min_items=1,
        max_items=3,
        unique_items=False,
    )
    
    # Integer
    obj = [1,2,3]
    result = field.serialize(obj)
    assert result == obj
    # Boolean
    obj = [True,False]
    result = field.serialize(obj)
    assert result == obj
    # None
    obj = None
    result = field.serialize(obj)
    assert result == obj
    # Array
    obj = [[1,2,3], [3,4,5]]
    result = field.serialize(obj)
    assert result == obj
    # Float
    obj = [1.0,2.2, 3.333]
   

# Generated at 2022-06-12 15:43:54.362729
# Unit test for method validate of class Object
def test_Object_validate():
    class Person(Object):
      properties = {
        'name': String()
      }

    validator = Person()

    assert validator.validate({'name': 'John'}) == {'name': 'John'}
    try:
        validator.validate({'name': 666})
    except ValidationError as e:
        error = e.messages[0]
        assert error.index == ['name']
        assert error.code == 'type'
        assert error.text == 'Must be a string.'

    class Person(Object):
      properties = {
        'name': String(),
        'age': Number()
      }

    validator = Person(required=['name', 'age'])


# Generated at 2022-06-12 15:44:01.522449
# Unit test for method __or__ of class Field
def test_Field___or__():
    from datetime import datetime
    from typesystem.base import Field, ValidationError
    from typesystem.types import Boolean, DateTime

    f1 = Field()
    f2 = Field()
    f3 = Field()
    f4 = Field()
    
    assert f1|f2|f3|f4
    assert f1.__or__(f2).__or__(f3).__or__(f4)
    



# Generated at 2022-06-12 15:44:14.137751
# Unit test for method validate of class Choice
def test_Choice_validate():
# test for condition: if value is None and self.allow_null:
    field= Choice(allow_null=True)
    value=field.validate(None)
    expected = None
    assert value == expected
# test for condition: elif value is None:
    field= Choice(allow_null=False)
    value=field.validate(None)
    expected = None
    assert value == expected
# test for condition: elif value not in Uniqueness([key for key, value in self.choices]):
    field=Choice(choices=[(1,1),(2,2),(3,3),(4,4),(5,5)])
    value=field.validate(6)
    expected = None
    assert value == expected
# test for condition: if value == "":

# Generated at 2022-06-12 15:44:29.627818
# Unit test for method validate of class String
def test_String_validate():
    valid_string = String(allow_blank=True,min_length=5,max_length=20, pattern="^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,6}$", format="email")
    # Test cases
    assert valid_string.validate("name2@gmail.com") == "name2@gmail.com"
    assert valid_string.validate("") == None
    assert valid_string.validate("aaa") == None
    assert valid_string.validate("a"*21) == None
    assert valid_string.validate("1234") == None
    assert valid_string.validate(123) == None
    assert valid_string.validate(None) == None

# Generated at 2022-06-12 15:44:32.374308
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Initialize new Field object
    Field1=Field()
    # Assert that the default value is not callable
    assert Field1.get_default_value() is None


# Generated at 2022-06-12 15:44:42.009933
# Unit test for method __or__ of class Field
def test_Field___or__():

    from typesystem.fields import Integer

    integer_or_other_integer_or_string = Integer() | Integer() | 'a string'

    assert integer_or_other_integer_or_string.__class__.__name__ == 'Union'
    assert len(integer_or_other_integer_or_string.any_of) == 3
    assert integer_or_other_integer_or_string.any_of[0].__class__.__name__ == 'Integer'
    assert integer_or_other_integer_or_string.any_of[1].__class__.__name__ == 'Integer'
    assert type(integer_or_other_integer_or_string.any_of[2]) == str



# Generated at 2022-06-12 15:44:46.857392
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    print("========== test_Boolean_validate ==========")
    b = Boolean()
    s = b.validate("True")
    print("Output of method Boolean.serialize() of class Boolean is: {}".format(s))



# Generated at 2022-06-12 15:44:47.876840
# Unit test for constructor of class Const
def test_Const():
    assert Const(1)



# Generated at 2022-06-12 15:44:50.325783
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    x = Field(default = 'prajval')
    assert x.get_default_value() == 'prajval'

# Generated at 2022-06-12 15:44:55.500529
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        choices = [
            ("Armenia", "AM"),
            ("Netherlands", "NL"),
            ("United Kingdom", "UK")
        ]
        c = Choice(choices = choices)
        assert c.validate("Universe") == "Universe"
    except Exception as e:
        raise e


# Generated at 2022-06-12 15:45:01.449491
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(10) == 10

    # cant cast to int
    num = Number()
    with pytest.raises(ValidationError) as exc_info:
        num.validate(10.0)
    assert exc_info.value.code == "type"

    # cant cast to float
    num = Number()
    with pytest.raises(ValidationError) as exc_info:
        num.validate(10)
    assert exc_info.value.code == "type"

    # cant cast to int
    num = Number()
    with pytest.raises(ValidationError) as exc_info:
        num.validate(10.0)
    assert exc_info.value.code == "type"

    # cant cast to int
    num = Number()

# Generated at 2022-06-12 15:45:10.864010
# Unit test for constructor of class String
def test_String():
    field = String()
    assert type(field) == String
    assert field.allow_blank == False
    assert field.trim_whitespace == True
    assert field.max_length == None
    assert field.min_length == None
    assert field.pattern == None
    assert field.format == None
    assert field.pattern_regex == None

    field = String(max_length = 10, format = "date")
    assert field.max_length == 10
    assert field.format == "date"
    assert field.pattern_regex == None

    import re
    field = String(pattern = re.compile("[a-z]+"))
    assert field.pattern == "[a-z]+"
    assert field.pattern_regex != None


# Generated at 2022-06-12 15:45:19.413038
# Unit test for method validate of class Array
def test_Array_validate():
	
	string = String()
	boolean = Boolean()
	integer = Integer()
	nested = Dict(properties={'foo': String(required=True)})
	nested_validated = Dict(properties={'foo': String()})
	
	string_array = Array(items=String(), additional_items=True, min_items=0, max_items=5)
	string_array_validated = Array(items=String())
	
	boolean_array = Array(items=Boolean(), additional_items=False, min_items=2, max_items=4, required=True)
	boolean_array_validated = Array(items=Boolean())

	object_array = Array(items=nested, min_items=2, max_items=2)

# Generated at 2022-06-12 15:45:38.021916
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = String()
    field2 = String()
    result = (field1 | field2)
    assert type(result) == Union
    assert result.any_of == [field1, field2]



# Generated at 2022-06-12 15:45:40.366444
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    value = 1234
    error = ValueError
    assert string.validate(value) == error



# Generated at 2022-06-12 15:45:48.270414
# Unit test for method validate of class Choice
def test_Choice_validate():
    # simple test for length of choices
    assert len(Choice(choices=[1,2,3])[0]) == 3
    # simple test for length of choices
    assert len(Choice(choices=[])[0]) == 0
    
    # simple test for choosing choices
    assert Choice(choices=[1,2,3]).validate(2) == 2
    
    # simple test for choosing invalid value
    try:
        assert Choice(choices=[1,2,3]).validate(5)
    except ValidationError:
        assert True
    else:
        assert False
        

# Generated at 2022-06-12 15:45:56.595817
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("choice") == "choice"
    assert Choice(choices=["choice1", "choice2"]).validate("choice1") == "choice1"
    assert Choice(choices=[("choice1", "value1"), "choice2"]).validate("choice1") == "choice1"
    assert Choice(choices=[("choice1", "value1"), "choice2"]).validate("value1") == "choice1"
    assert Choice(choices=[("choice1", "value1"), "choice2"]).validate("choice2") == "choice2"
    assert Choice(choices=[("choice1", "value1"), "choice2"]).validate("choice3") == None
    assert Choice(choices=[("choice1", "value1"), "choice2"]).validate("value3") == None



# Generated at 2022-06-12 15:46:05.453057
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    value = None
    strict = False
    assert field.validate(value, strict=strict) is None
    strict = True
    try:
        assert field.validate(value, strict=strict) is None
    except Exception as err:
        expt_msg = "May not be null."
        expt_err_code = "null"
        assert str(err) == expt_msg
        assert err.code == expt_err_code



# Generated at 2022-06-12 15:46:09.668514
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Case 1: If a String is given, return None
    Field = Choice(allow_null=True)
    assert Field.validate("NULL") == None

    # Case 2: If a String is given, return the String
    Field = Choice()
    assert Field.validate("NULL") == "NULL"



# Generated at 2022-06-12 15:46:18.279353
# Unit test for method validate of class Choice
def test_Choice_validate():
    new_Choice = Choice(description="description", error_messages={}, required=True)
    new_Choice.allow_null=True
    assert new_Choice.validate(None) == None
    assert new_Choice.validate("") == None
    assert new_Choice.validate("aaa") == "aaa"
    assert new_Choice.validate("bbb") == "bbb"
    assert new_Choice.validate("ccc") == "ccc"



# Generated at 2022-06-12 15:46:20.253862
# Unit test for method validate of class Union
def test_Union_validate():
    with pytest.raises(ValidationError):
        Union(any_of=[String()]).validate(1)



# Generated at 2022-06-12 15:46:31.862007
# Unit test for method serialize of class Array
def test_Array_serialize():
    import json
    class List(Array):
        items = [
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
            Integer(minimum=0, maximum=99, required=True),
        ]
        
    list1 = List()

# Generated at 2022-06-12 15:46:39.524532
# Unit test for method validate of class Array
def test_Array_validate():
    array_field = Array()
    assert array_field.validate([]) == []
    assert array_field.validate([1]) == [1]
    assert array_field.validate([1,2]) == [1,2]
    assert array_field.validate(['1','2']) == ['1','2']
    assert array_field.validate(['1', 2]) == ['1', 2]
    assert array_field.validate([1, '2']) == [1, '2']
    assert array_field.validate(['1', 2]) == ['1', 2]
    assert array_field.validate([1, 2, 3]) == [1, 2, 3]
    assert array_field.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert array

# Generated at 2022-06-12 15:46:54.294513
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(name="test_Choice_validate")
    assert field.validate("A", strict="True") == "A"
    assert field.validate("a", strict="True") == "a"


# Generated at 2022-06-12 15:46:56.454916
# Unit test for method __or__ of class Field
def test_Field___or__():
    a = Field(1,2)
    b = Field(3,4)
    c = a | b
    assert c.any_of == [1,2,3,4]

# Generated at 2022-06-12 15:47:08.164263
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Field1(Field):
        def __init__(self,*args, **kwargs):
            super().__init__(*args, **kwargs)

    class Field2(Field):
        def __init__(self,*args, **kwargs):
            super().__init__(*args, **kwargs)

    class Field3(Field):
        def __init__(self,*args, **kwargs):
            super().__init__(*args, **kwargs)

    def func():
        return 'test'

    field1 = Field1(default=func)
    field2 = Field2(default='test')
    field3 = Field3()

    # assert fields with default value
    assert field1.get_default_value() == 'test'
    assert field2.get_default_value() == 'test'

    #

# Generated at 2022-06-12 15:47:10.158722
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    value = 5
    assert num.validate(value) == 5
    

# Generated at 2022-06-12 15:47:21.394639
# Unit test for method validate of class Number
def test_Number_validate():
    int_number = Number()
    float_number = Number()
    decimal_number = Number()
    assert int_number.validate(123) == 123
    assert int_number.validate("123") == 123
    assert float_number.validate(123.0) == 123.0
    assert float_number.validate("123.0") == 123.0
    assert decimal_number.validate(123.0) == 123.0
    assert decimal_number.validate("123.0") == 123.0

    class Int_Number(Number):
        numeric_type = int
    int_number = Int_Number()
    assert int_number.validate(123) == 123
    assert int_number.validate("123") == 123
    assert int_number.validate(123.0) == 123
    assert int_number

# Generated at 2022-06-12 15:47:28.840945
# Unit test for method validate of class Array
def test_Array_validate():
    unittest.TestCase.assertEqual(Array().validate([]), [])
    unittest.TestCase.assertEqual(Array().validate([1, 2, 3]), [1, 2, 3])
    unittest.TestCase.assertEqual(Array().validate([1, None, 3]), [1, None, 3])
    unittest.TestCase.assertEqual(Array().validate(None), None)
    with unittest.TestCase.assertRaises(ValidationError):
        Array().validate(["a", "b", "c"])
    with unittest.TestCase.assertRaises(ValidationError):
        Array().validate({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-12 15:47:35.016015
# Unit test for method validate of class String
def test_String_validate():
    s = String('test',default='test',min_length=3)
    # The test should pass
    s.validate('test')
    # The test should pass
    s.validate('test1234567890')
    # The test should pass
    s.validate('')
    # The test should pass
    s.validate(None)
    # The test should raise AssertionError
    try:
        result = s.validate('te')
        assert False
    except AssertionError:
        assert True
    except Exception as e:
        print(e)
        assert False
    # The test should raise AssertionError
    try:
        result = s.validate('tes')
        assert False
    except AssertionError:
        assert True
    except Exception as e:
        print(e)

# Generated at 2022-06-12 15:47:47.723961
# Unit test for method validate of class Union
def test_Union_validate():
    class TestUnionChild(Field):
        errors = {"type": "Must be an integer."}

        def validate(self, value: typing.Any) -> typing.Any:
            if not isinstance(value, int):
                raise self.validation_error("type")
            return value

    test_child = TestUnionChild()
    test_union = Union([test_child], nullable=True)

    # Test null
    value = None
    try:
        validated = test_union.validate(value)
    except ValidationError as error:
        assert error.code == "null"
    else:
        assert validated is None
    
    # Test int
    value = 1
    validated = test_union.validate(value)
    assert validated == 1

    # Test float
    value = 1.0

# Generated at 2022-06-12 15:47:55.305355
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class String(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
            super().__init__(
                title=title,
                description=description,
                default=default,
                allow_null=allow_null,
            )

    Fld = String(default=NO_DEFAULT, allow_null=False)
    res = Fld.get_default_value() 
    assert res == None


# Generated at 2022-06-12 15:48:04.326415
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Fields(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
         assert isinstance(title, str)
        assert isinstance(description, str)
        if allow_null and default is NO_DEFAULT:
            default = None
        if default is not NO_DEFAULT:
            self.default = default
        self.title = title
        self.description = description
        self.allow_null = allow_null
        self._creation_counter = Field._creation_counter
        Field._creation_counter += 1
    try:
        AnyField=Fields(title="String", description="String", default=NO_DEFAULT, allow_null=True)
    except ValidationError as error:
        return error


# Generated at 2022-06-12 15:48:12.674844
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    assert choice.validate(None) == None



# Generated at 2022-06-12 15:48:16.600548
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title='x', description='x', allow_null=False)
    assert f.get_default_value() == None
    f = Field(title='x', description='x', allow_null=False, default='')
    assert f.get_default_value() == ''


# Generated at 2022-06-12 15:48:19.262664
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test that serialize works as expected
    string = String()
    arr = Array(items=string)
    assert arr.serialize(["a", "b"]) == ["a", "b"]



# Generated at 2022-06-12 15:48:29.630381
# Unit test for method validate of class String
def test_String_validate():
    assert String(allow_null=False, default=" ").validate(' ') == ' '
    assert String(allow_blank=True, allow_null=False, default=" ").validate(' ') == None
    assert String(min_length=1, allow_null=False, default=" ").validate(' ') == None
    assert String(max_length=1, min_length=1, allow_null=False, default=" ").validate(' ') == ' '
    assert String(pattern="^\d+$", allow_null=False, default=" ").validate(' ') == None
    assert String(format="time", pattern="^\d+$", allow_null=False, default=" ").validate(' ') == None

# Generated at 2022-06-12 15:48:37.226260
# Unit test for method validate of class Object
def test_Object_validate():
    # Initialize a field Object
    field_Object = Object(title='title', description='description')
    # Validate obj is None
    assert field_Object.validate(obj=None) == None
    # Validate obj is an instance of a dictionary
    assert field_Object.validate(obj={'name': 'John', 'surname': 'Doe'}) == {'name': 'John', 'surname': 'Doe'}
    # Validate obj is an instance of a integer
    with pytest.raises(ValidationError):
        field_Object.validate(obj=12)
    # Validate obj is an instance of a list
    with pytest.raises(ValidationError):
        field_Object.validate(obj=['John', 'Doe'])


# Generated at 2022-06-12 15:48:49.279907
# Unit test for method validate of class Array
def test_Array_validate():
    def test_Array_validate_void_type():
        a = Array()
        try:
            a.validate(None)
        except ValidationError:
            pass
        else:
            assert False

    def test_Array_validate_null():
        a = Array(allow_null=True)
        a.validate(None)

    def test_Array_validate_with_item_null():
        a = Array(items=[Integer(allow_null=True)])
        a.validate([1, 2, 3])

    def test_Array_validate_with_items_null():
        a = Array([Integer()], additional_items=Integer(allow_null=True))
        a.validate([1, 2, 3, None])


# Generated at 2022-06-12 15:48:53.177291
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice()
    try:
        value = field.validate('aaa')
    except ValidationError as error:
        assert error.code == "choice"
    else:
        raise AssertionError("Should not return a value")



# Generated at 2022-06-12 15:48:57.438284
# Unit test for method validate of class Array
def test_Array_validate():
    with open("./examples/test_data/test_test_Array_validate.json") as data_file:
        data_loaded = json.load(data_file)
    # Check method validate of class Array
    validator = Array(items=Integer(required=True), required=True)
    assert validator.validate(data_loaded["body"]) == data_loaded["breakpoint"]
    try:
        validator.validate(data_loaded["breakpoint"])
        assert False
    except ValidationError as e:
        assert data_loaded["validate_error"] == format_error(e)



# Generated at 2022-06-12 15:49:07.136008
# Unit test for method validate of class Union
def test_Union_validate():
    assert 1==1, "Invalid test"
    #Method's body
    any_of = [Number(), Text()]
    union = Union(any_of = any_of)

    #Error: test (validate)
    #Validate function of Union class accepts only text or int values
    with pytest.raises(ValueError) as excinfo:
        union.validate(0.25)
    assert "ValueError: 0.25 is not a valid int" in str(excinfo.value)

    #Error: test (validate)
    #Validate function of Union class accepts only text or int values
    with pytest.raises(ValidationError) as excinfo:
        union.validate(0.25)