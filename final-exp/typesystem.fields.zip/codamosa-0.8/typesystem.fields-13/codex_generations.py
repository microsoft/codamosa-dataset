

# Generated at 2022-06-12 15:40:42.045057
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # field = Field(default="a")
    # field.get_default_value()
    assert True==True

# Generated at 2022-06-12 15:40:50.007569
# Unit test for method __or__ of class Field
def test_Field___or__():
    # For | and |=, we would like to just define __or__ and __ior__ and be
    # done with it, but the behavior of those operators with unhashable types
    # is so utterly demented that we have to do all the work ourselves.
    class Foo(Field):
        pass

    class Bar(Field):
        pass

    foo = Foo()
    bar = Bar()

    assert foo | bar == Union([foo, bar])
    assert bar | foo == Union([foo, bar])

    foo_bar = foo | bar
    assert foo_bar == Union([foo, bar])

    foo_bar.any_of = list(foo_bar.any_of)
    assert foo_bar.any_of == [foo, bar]

    foo_bar |= Bar()

# Generated at 2022-06-12 15:40:53.879275
# Unit test for method validate of class Union
def test_Union_validate():
    any_of1 = String()
    any_of = [any_of1]
    union = Union(any_of = any_of)
    value = 1
    result = union.validate(value)
    assert result is True

# Generated at 2022-06-12 15:40:56.932631
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field().validate_or_error(None).is_valid
    assert not Field().validate_or_error(None, strict=True).is_valid
    assert Field().validate_or_error(None, strict=False).is_valid


# Generated at 2022-06-12 15:41:02.553808
# Unit test for method serialize of class String
def test_String_serialize():
    test_string = String(title='test', description='test_description', default='test_default')
    assert test_string.serialize('test') == 'test'
    assert test_string.serialize(None) == None
    assert test_string.serialize(NotImplemented) == NotImplemented


# Generated at 2022-06-12 15:41:11.178394
# Unit test for method validate of class Number
def test_Number_validate():
    from test_ex_1 import test_object_to_json, test_json_to_object

    class NumberTest(Number):
        pass

    n = NumberTest(allow_null=False)
    assert n.validate(1) == 1
    assert n.validate("1") == 1
    assert n.validate("-1") == -1
    assert n.validate("-1.0") == -1.0
    assert n.validate("1.0") == 1.0
    assert n.validate("-1.1") == -1.1
    assert n.validate("1.1") == 1.1
    try:
        n.validate("")
        assert False
    except ValidationError as e:
        assert e.code == "null"

# Generated at 2022-06-12 15:41:16.885621
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_default_value()
    assert expected == actual

    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_default_value()
    assert expected == actual

    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_default_value()
    assert expected == actual

    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_default_value()
    assert expected == actual

    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_default_value()
    assert expected == actual

    # Test for obj
    obj = Field()
    expected = None
    actual = obj.get_

# Generated at 2022-06-12 15:41:22.893804
# Unit test for method serialize of class Array
def test_Array_serialize():
    from jsonschema.exceptions import ValidationError
    class TestSchema(Array):
        errors = {
            "null": "May not be null.",
            "empty": "Must not be empty.",
            "exact_items": "Must have {min_items} items.",
            "min_items": "Must have at least {min_items} items.",
            "max_items": "Must have no more than {max_items} items.",
            "additional_items": "May not contain additional items.",
            "unique_items": "Items must be unique.",
            "type": "Must be an array.",
        }
    instance = TestSchema()
    # 1
    obj = None
    assert instance.serialize(obj) is None
    # 2
    obj = [1, 1, 2, 3]
    result = instance

# Generated at 2022-06-12 15:41:35.138340
# Unit test for method validate of class Number
def test_Number_validate():
    num =  Number(maximum=5,minimum=-5,exclusive_minimum=-4,exclusive_maximum=4)
    assert num.validate(1) == 1
    assert num.validate(0) == 0
    assert num.validate("1") == 1
    assert num.validate("1.1") == 1.1
    # assert num.validate("one") == "one"       # WRONG VALUE, ERROR
    # assert num.validate("-5.000000001") == "-5.000000001"   # WRONG VALUE, ERROR
    assert num.validate("-5.000000001") == -5.0
    assert num.validate("-4.999999999") == -4.999999999
    assert num.validate("-4.999999999") == -4.999999999

# Generated at 2022-06-12 15:41:36.793197
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
  assert (Field.validate_or_error(instance=None, strict=False)==None)

# Generated at 2022-06-12 15:42:12.472074
# Unit test for method validate of class String
def test_String_validate():
    a = String()
    assert a.validate("") == ""
    assert a.validate(None) == ""
    assert a.validate("1") == "1"
    try:
        a.validate(1)
    except ValidationError as e:
        assert e.code == "type"


# Generated at 2022-06-12 15:42:18.761638
# Unit test for constructor of class Const
def test_Const():
    a = Const(5)
    assert a.errors['only_null'] == 'Must be null.'
    assert a.errors['const'] == 'Must be the value \'{const}\'.'

# Generated at 2022-06-12 15:42:21.489801
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    bool_true = Boolean(allow_null=True)
    bool_false = Boolean(allow_null=True)
    bool_true.validate(True)
    bool_false.validate(False)


# Generated at 2022-06-12 15:42:28.901362
# Unit test for method validate of class Array
def test_Array_validate():
    a = [dataclasses.asdict(TestUser(username="Jason", email="jason@jasonlalor.com"))]
    b = Array(
        additional_items=DataclassField(TestUser),
        min_items=1,
        max_items=2,
        unique_items=True,
        description="this is a description",
    )

    result = b.validate(a)
    assert result[0].username == "Jason"
    assert result[0].email == "jason@jasonlalor.com"


# Generated at 2022-06-12 15:42:35.179627
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Serializer(Serializer):
        obj = Array(items=Int())

    obj = Serializer(
        {
            'obj': [1, 2, 3]
        }
    )

    assert obj.serialize() == {
        'obj': [1, 2, 3]
    }


# Generated at 2022-06-12 15:42:44.009279
# Unit test for constructor of class Array
def test_Array():
    # Test 1
    # input
    field = Array(items=String())
    # output
    assert isinstance(field, Field)
    assert field.items == String()
    assert isinstance(field.additional_items, bool)
    assert isinstance(field.min_items, int)
    assert isinstance(field.max_items, int)
    assert isinstance(field.unique_items, bool)

    # Test 2
    # input
    field = Array(items=[String(), Number()], additional_items=False,
        min_items=2, max_items=3, unique_items=True, allow_null=True)
    # output
    assert isinstance(field, Field)
    assert isinstance(field.additional_items, bool)
    assert field.min_items == 2
    assert field.max_items

# Generated at 2022-06-12 15:42:55.356739
# Unit test for constructor of class Array
def test_Array():
    # Setup
    def successful_assertions(obj):
        assert isinstance(obj, Array)
        assert obj.allow_null is False
        assert obj.has_default() is False
        assert obj.items is None
        assert obj.additional_items is False
        assert obj.min_items is None
        assert obj.max_items is None
        assert obj.unique_items is False

    def unsuccessful_assertions(obj):
        assert isinstance(obj, Array)
        assert obj.allow_null is True
        assert obj.has_default() is True
        assert obj.items is None
        assert obj.additional_items is False
        assert obj.min_items is 0
        assert obj.max_items is 1
        assert obj.unique_items is True

    obj = Array(allow_null=False)
    assert obj

# Generated at 2022-06-12 15:42:58.325318
# Unit test for constructor of class Const
def test_Const():
    error = Const("Hi").validate("Hello")
    assert error.messages()[0].code == "const"
    Const("Hi").validate("Hi")


# Generated at 2022-06-12 15:43:05.208970
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        def __init__(self, title: str, description: str):
            super().__init__(title=title, description=description)

    class Field2(Field):
        def __init__(self, title: str, description: str):
            super().__init__(title=title, description=description)

    f1 = Field1("field1", "description")
    f2 = Field2("field2", "description")

    f3 = f1 | f2

    assert isinstance(f3, Union)
    assert f3.any_of == [f1, f2]



# Generated at 2022-06-12 15:43:11.870771
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(allow_null=True, choices=[("A", "Alice"), ("B", "Bob")])
    assert choice.validate("A") == "A"
    assert choice.validate("B") == "B"
    assert choice.validate("") == None
    assert choice.validate(None) == None
    assert choice.validate("C") == TypeError
    assert choice.validate("") == ValidationError



# Generated at 2022-06-12 15:43:32.558147
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-12 15:43:33.919044
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice()
    print(field.validate(None, strict=False))



# Generated at 2022-06-12 15:43:36.411949
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    
    

# Generated at 2022-06-12 15:43:38.726724
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    assert choice.validate(1) == 1


# Generated at 2022-06-12 15:43:50.479271
# Unit test for method validate of class String
def test_String_validate():
    data = ["", "ab", "a" * 10009]
    obj = String(allow_blank=False, max_length=10000)
    _expected = "Must have no more than 10000 characters."
    for _value in data:
        try:
            res = obj.validate(_value)
        except ValidationError as error:
            assert error.text == _expected
        else:
            if len(_value) > 10000:
                assert False
    obj = String(allow_blank=False, max_length=10000, format="uuid")
    _expected = "Must be a valid uuid."
    for _value in data:
        try:
            res = obj.validate(_value)
        except ValidationError as error:
            assert error.text == _expected

# Generated at 2022-06-12 15:44:00.932306
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("choice1", "choice1"), ("choice2", "choice2"),("choice3", "choice3")]
    choice_field = Choice(choices=choices)
    assert choice_field.validate(None) is None
    assert choice_field.validate("choice1") == "choice1"
    assert choice_field.validate("choice2") == "choice2"
    assert choice_field.validate("choice3") == "choice3"
    assert choice_field.validate("choice4") == "choice4"
    assert choice_field.validate("") == ""

# Test for method serialize of class Choice

# Generated at 2022-06-12 15:44:13.611202
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test 1
    c = Choice (allow_null=True,choices=[(1, 'a'), (2, 'b')])
    assert c.validate(None) == None
    # test 2
    c = Choice (allow_null=False,choices=[(1, 'a'), (2, 'b')])
    assert c.validate(None) == ValidationError(text=c.get_error_text(code='null'), code='null')
    # test 3
    c = Choice (allow_null=False,choices=[(1, 'a'), (2, 'b')])
    assert c.validate(3) == ValidationError(text=c.get_error_text(code='choice'), code='choice')
    # test 4

# Generated at 2022-06-12 15:44:24.318940
# Unit test for method validate of class Union
def test_Union_validate():
    class A(Field):
        pass
    class B(Field):
        pass
    class C(Field):
        pass

    cls = Union([A(),B(),C()])
    cls.validate(1)
    cls.validate(2)
    cls.validate(3)
    with pytest.raises(ValidationError):
        cls.validate(4)

    # Unit test for error union of class Union
    def test_Union_error():
        class A(Field):
            pass
        class B(Field):
            pass
        class C(Field):
            pass

        cls = Union([A(),B(),C()])
        assert cls.error('union') == 'Did not match any valid type.'

        # Unit test for method serialize of class Union

# Generated at 2022-06-12 15:44:36.025706
# Unit test for method validate of class Array
def test_Array_validate():
    from pydantic import BaseModel
    import pytest
    array_test_obj1 = {"a":1}
    array_test_obj2 = {"a":2}
    array_test_obj3 = {"a":3}
    array_test_obj4 = {"a":4}
    array_test_obj5 = {"a":5}

    class ArrayTest(BaseModel):
        test_array: Array = Array([array_test_obj1, array_test_obj2, array_test_obj3, array_test_obj4, array_test_obj5])
    
    ArrayTest(
        test_array= [array_test_obj1, array_test_obj1, array_test_obj1, array_test_obj1, array_test_obj1]
        )

# Generated at 2022-06-12 15:44:39.072434
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(String())
    assert field.serialize(None) is None
    assert field.serialize([1,2]) == [1,2]


# Generated at 2022-06-12 15:45:05.368511
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    # value = hello
    value = "hello"
    assert value == s.validate(value)
    # value = null
    value = None
    assert value == s.validate(value)

# Generated at 2022-06-12 15:45:08.287926
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items = Integer())
    assert field.validate([1,2,3]) ==[1,2,3]



# Generated at 2022-06-12 15:45:18.190535
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title='', description='', default=None)
    assert field.get_default_value() is None

    field = Field(title='', description='', default=2)
    assert field.get_default_value() == 2

    field = Field(title='', description='', default=3)
    assert field.get_default_value() == 3

    field = Field(title='', description='', default=[])
    assert field.get_default_value() == []

    field = Field(title='', description='', default=['a'])
    assert field.get_default_value() == ['a']

    field = Field(title='', description='', default=())
    assert field.get_default_value() == ()

    field = Field(title='', description='', default=('a',))
    assert field.get

# Generated at 2022-06-12 15:45:22.221869
# Unit test for method serialize of class Array
def test_Array_serialize():
    "____"
    print_title("Test serialize method of class Array", color = "green")
    # Test data
    data = [True, '2',3]
    # Instantiation
    array_field = Array(items = Boolean(default=True))
    # Run test
    array_value = array_field.serialize(data)
    print(array_value)
    # Check result
    assert_equal(array_value, [True, True, True])


# Generated at 2022-06-12 15:45:27.153935
# Unit test for constructor of class Const
def test_Const():
    field = Const(True, title="Any Boolean")
    try:
        field.validation_error("only_null")
    except ValueError as e:
        assert str(e) == "The text 'only_null' is not associated with this field"


# Generated at 2022-06-12 15:45:29.255121
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import types
    assert isinstance ((types.String() | types.String()), types.Union)
    return None


# Generated at 2022-06-12 15:45:30.978249
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field=Field()
    assert field.get_default_value() == None



# Generated at 2022-06-12 15:45:33.688940
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title="field1", description="field1", default=15)
    assert f.get_default_value() == 15
    assert f.get_default_value() == 15


# Generated at 2022-06-12 15:45:38.386966
# Unit test for constructor of class Const
def test_Const():
    const = Const(0)
    assert const.const == 0
    with pytest.raises(AssertionError) as excinfo:
        Const(1, allow_null=True)
    assert str(excinfo.value) == "assertion failed"



# Generated at 2022-06-12 15:45:41.185495
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title = "title", description = "description", default = NO_DEFAULT, allow_null = False)
    assert field.get_default_value() == None

# Generated at 2022-06-12 15:45:56.357671
# Unit test for method validate of class Object
def test_Object_validate():
    props = {"age": IntegerField()}
    pattern_props = {"pattern": IntegerField()}
    additional_props = IntegerField()
    prop_names = IntegerField()
    req = ["age"]
    obj = Object(
        properties=props,
        pattern_properties=pattern_props,
        additional_properties=additional_props,
        property_names=prop_names,
        min_properties=1,
        max_properties=10,
        required=req
    )
    try:
        obj.validate({"age": 1})
    except:
        pass
    finally:
        assert obj.properties == {"age": IntegerField()}
        assert obj.pattern_properties == {"pattern": IntegerField()}
        assert obj.additional_properties == IntegerField()

# Generated at 2022-06-12 15:46:00.415078
# Unit test for method validate of class String
def test_String_validate():
    x=String()
    try:
        x.validate(1)
    except ValidationError:
        pass
    else:
        assert False

# Generated at 2022-06-12 15:46:06.165636
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b", "c"]).validate("b") == "b"
    assert Choice(choices=["a", "b", "c"]).validate("a") == "a"
    assert Choice(choices=["a", "b", "c"]).validate("c") == "c"


# Generated at 2022-06-12 15:46:14.196443
# Unit test for method validate of class Union
def test_Union_validate():
    # Create a Union instance with two AnyOf elements
    # Create an integer element
    u_value = 2
    integer_field = Plain(type="integer")
    errors = {}
    u_expected_result = u_value
    # Execute method validate
    try :
      u_result = integer_field.validate(u_value)
      if u_result != u_expected_result:
          errors["001"] = "method validate of class Plain fails with integer type element"
    except:
        errors["001"] = "method validate of class Plain fails with integer type element"
    # Create a number element
    u_value = 2.3
    number_field = Plain(type="number")
    errors = {}
    u_expected_result = u_value
    # Execute method validate

# Generated at 2022-06-12 15:46:16.329987
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default= "abc")
    assert field.get_default_value() == "abc"

# Generated at 2022-06-12 15:46:20.058801
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class field(Field):
        def __init__(self, **kwargs):
            self.default = kwargs.get('default', None)
    a_field = field(default=None)
    assert a_field.get_default_value() == None
test_Field_get_default_value()

# Generated at 2022-06-12 15:46:31.592617
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices = ['a']).validate(1) == 1, "Test Case 1 Fail" # Test Case 1
    assert Choice(choices = ['a']).validate('a') == 'a', "Test Case 2 Fail" # Test Case 2
    assert Choice(choices = ['a', 'b']).validate('a') == 'a', "Test Case 3 Fail" # Test Case 3
    assert Choice(choices = ['a', 'b']).validate('b') == 'b', "Test Case 4 Fail" # Test Case 4
    assert Choice(choices = ['a', 'b', 'c']).validate('c') == 'c', "Test Case 5 Fail" # Test Case 5
    assert Choice(choices = ['a', 'b']).validate('c') == 'c', "Test Case 6 Fail" # Test Case 6

# Generated at 2022-06-12 15:46:39.112155
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Arrange
    c = Choice(
        choices=[
            ("true", "true"),
            ("false", "false"),
            ("on", "on"),
            ("off", "off"),
            ("1", "1"),
            ("0", "0"),
            ("", ""),
            (1, 1),
            (0, 0),
        ]
    )
    # Act
    result = c.validate(None)
    assert result == None
    result = c.validate(1)
    assert result == 1
    result = c.validate(0)
    assert result == 0
    result = c.validate(True)
    assert result == True
    result = c.validate(False)
    assert result == False
    # Assert



# Generated at 2022-06-12 15:46:43.072938
# Unit test for method validate of class Array
def test_Array_validate():
    data = Array()
    data_val = data.validate([1,2,3]) == [1,2,3]
    assert data_val == True
    data_val_error = data.validate("Hello") == [1,2,3]
    assert data_val_error == False


# Generated at 2022-06-12 15:46:54.608426
# Unit test for method validate of class Array
def test_Array_validate():
    from src.validation import Integer, Boolean, String, BaseField
    from marshmallow import Schema

    class TestSchema(Schema):
        a = Integer(allow_null=True)
        b = String()
        c = Boolean()
        d = Integer(min_value=2, validate=lambda n: n % 2 == 0)

    valid_data = {
        "a": 1,
        "b": "hello",
        "c": True,
        "d": 4,
    }

    invalid_data = {
        "d": 1,
    }

    data, errors = TestSchema().load(valid_data)
    assert data == valid_data
    assert errors == {}

    data, errors = TestSchema().load(invalid_data)
    assert data == invalid_data

# Generated at 2022-06-12 15:47:04.580150
# Unit test for method __or__ of class Field
def test_Field___or__():
    a = Field()
    b = Field()
    c = Field()
    d = Field()
    e = Field()
    
    assert a|b|c|d|e


# Generated at 2022-06-12 15:47:17.106005
# Unit test for method __or__ of class Field
def test_Field___or__():
    v1 = String()
    v2 = String()
    assert v1 | v2 == v1.__or__(v2)
    assert type(v1) == type(v1.__or__(v2).any_of[0])
    assert type(v2) == type(v1.__or__(v2).any_of[1])
    v3 = Integer()
    assert type(v2) == type(v1.__or__(v3).any_of[1])
    assert type(v3) == type(v1.__or__(v3).any_of[2])
    v4 = v1 | v2
    assert type(v1) == type(v4.__or__(v3).any_of[0])

# Generated at 2022-06-12 15:47:21.627183
# Unit test for method validate of class Choice
def test_Choice_validate():
    f = Choice(choices=[('C', 'C'), ('C++', 'C++')])
    assert f.validate('C')=='C'
    assert f.validate('C++')=='C++'
    with raises(ValidationError):
        f.validate('C#')



# Generated at 2022-06-12 15:47:29.463286
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["1", "2", "3"])
    assert c.validate("1") == "1"
    try:
        c.validate(None)
    except ValidationError:
        assert True
    except:
        assert False
    try:
        c.validate("5")
    except ValidationError:
        assert True
    except:
        assert False




# Generated at 2022-06-12 15:47:37.378532
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(4) == 4
    assert num.validate(1.234) == 1.234
    assert num.validate('3.14') == 3.14
    with pytest.raises(ValidationError):
        num.validate('a')
    with pytest.raises(ValidationError):
        num.validate(1 / 0)
    assert num.validate(None, strict=True) is None
    with pytest.raises(ValidationError):
        num.validate(None)
    assert num.validate('', strict=True) == ''
    with pytest.raises(ValidationError):
        num.validate('', strict=False)
    with pytest.raises(ValidationError):
        num.validate(True)

# Generated at 2022-06-12 15:47:41.585836
# Unit test for constructor of class Choice
def test_Choice():
    # Test if KeyError is raised
    with pytest.raises(KeyError):
        Choice(choices={1: "one", 2: "two"})

# Unit tests for validate static method of class Choice

# Generated at 2022-06-12 15:47:53.957058
# Unit test for method validate of class Choice
def test_Choice_validate():
    field=Choice()
    # Corner case: no choices have been made
    assert field.validate(None)==None
    assert field.validate(None)==None
    assert field.validate(None)==None
    assert field.validate(None)==None
    # Corner case: value is a empty string
    assert field.validate("")==None
    assert field.validate("")==None
    # Corner case: value is not in the choices
    try:
        field.validate("d")
    except ValidationError:
        pass
    # Corner case: value is not in the choices
    try:
        field.validate("d")
    except ValidationError:
        pass
    # Corner case: value is not in the choices
    # Corner case: the choices is [('', '')]

# Generated at 2022-06-12 15:48:03.164347
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate('') == ''
    assert field.validate('', strict=True) == ''
    assert field.validate(None, strict=True) == None
    assert field.validate('', strict=False) == ''
    assert field.validate(None, strict=False) == None
    assert field.validate(1) == '1'
    assert field.validate(True) == 'True'
    assert field.validate(False) == 'False'
    assert field.validate('hoge') == 'hoge'
    assert field.validate(['hoge']) == 'hoge'
    assert field.validate(1.2) == '1.2'
test_String_validate()

# Generated at 2022-06-12 15:48:10.319557
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    f = Boolean()
    assert f.validate(True) == True
    assert f.validate("on") == True
    assert f.validate("1") == True
    assert f.validate("") == False
    assert f.validate(0) == False
    assert f.validate(None, strict=True) == None
    
test_Boolean_validate()


# Generated at 2022-06-12 15:48:19.429490
# Unit test for method validate of class Array
def test_Array_validate():
    def test_Array_validate_1():
        arr = Array()
        arr.validate([0, 1])
        try:
            arr.validate(1)
            return False
        except ValidationError as e:
            return True

    def test_Array_validate_2():
        arr = Array(allow_null=True)
        arr.validate(None)
        try:
            arr.validate(1)
            return False
        except ValidationError as e:
            return True

    def test_Array_validate_3():
        arr = Array(items=Integer())
        arr.validate([0, 1])
        try:
            arr.validate([0, "1"])
            return False
        except ValidationError as e:
            return True


# Generated at 2022-06-12 15:48:41.088542
# Unit test for method validate of class Choice
def test_Choice_validate():
    if __name__ == "__main__":
        try:
            class Test(Schema):
                choice = Choice(choices=["a", "b"])
            val_obj = Test().load({"choice": "a"})
            assert val_obj.data["choice"] == "a"
            val_obj = Test().load({"choice": "b"})
            assert val_obj.data["choice"] == "b"
            val_obj = Test().load({"choice": "c"}) # raises a ValidationError
            assert val_obj.data["choice"] == None
            val_obj = Test().load({"choice": None})
            assert val_obj.data["choice"] == None
        except ValidationError as error:
            print(error.messages)


# Generated at 2022-06-12 15:48:47.459516
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_1 = Choice(choices = {"a", "b", "c"})
    value = "a"
    assert test_1.validate(value, strict = False) == "a"

test_2 = Choice(choices = {"a", "b", "c"})
value = "d"
assert test_2.validate(value, strict = False) == None



# Generated at 2022-06-12 15:48:51.559143
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    title = "wonder"
    description = "man"
    default = True

    f = Field(title=title, description=description, default=default)
    assert f.get_default_value() == default

# Generated at 2022-06-12 15:49:03.479661
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typing import NoReturn, Any
    from typesystem import Union

    class Foo:
        def __init__(self):
            pass
        def __or__(self, other):
            return 1
        def validate(self, value, *, strict=False):
            return 1
        def get_default_value(self):
            return 1
        def has_default(self):
            return False
        def has_unique_value(self):
            return False
        def get_unique_value(self):
            return False
        def get_error_text(self, code):
            return 0
        def validation_error(self, code):
            raise NoReturn()
        def serialize(self, obj):
            return 1

    field_1 = Field()
    field_2 = Foo()