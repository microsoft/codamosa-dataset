

# Generated at 2022-06-12 15:41:24.359357
# Unit test for method validate of class String
def test_String_validate():
    s = String(title="s", description="s", allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern="", format="")

    value = "1"
    strict = False
    assert s.validate(value, strict=strict) == "1"

    value = "1"
    strict = True
    assert s.validate(value, strict=strict) == "1"

# Generated at 2022-06-12 15:41:33.617764
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["WRITE", "READ", "EXECUTE"])
    value = "READ"
    assert choice.validate(value) == "READ"
    value = "NOT_VALID_CHOICE" 
    assert choice.validate(value, strict=True) == "NOT_VALID_CHOICE"
    value = ""
    assert choice.validate(value, strict=True) == ""
    value = None
    assert choice.validate(value, strict=True) == None
    value = ""
    assert choice.validate(value, strict=False) == None



# Generated at 2022-06-12 15:41:39.273645
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [('one','two')])
    assert choice.validate('one') == 'one'
    assert choice.validate('two') == 'two'
    with pytest.raises(ValidationError) as exc_info:
        choice.validate('three')
    with pytest.raises(ValidationError) as exc_info:
        choice.validate(None)
    with pytest.raises(TypeError):
        choice.validate(1)



# Generated at 2022-06-12 15:41:48.958024
# Unit test for method __or__ of class Field
def test_Field___or__():
    from .integer import Integer
    from .string import String
    from .union import Union
    from .list import List
    int_str_union = Integer() | String()
    assert isinstance(int_str_union, Union)
    assert set(int_str_union.any_of) == {Integer(), String()}
    single_type_list = List(List(Integer()))
    multiple_type_list = List(Integer() | String())
    str_list_list = List(List(String()))
    assert isinstance((multiple_type_list | single_type_list), List)
    assert isinstance(multiple_type_list, List)
    assert multiple_type_list.item_type == Integer() | String()
    assert set(multiple_type_list.item_type.any_of) == {Integer(), String()}

# Generated at 2022-06-12 15:41:51.595126
# Unit test for method validate of class Array
def test_Array_validate():
    array_field = Array()
    assert array_field.validate([1,2,3]) == [1,2,3]
    assert array_field.serialize([1,2,3]) == [1,2,3]



# Generated at 2022-06-12 15:41:55.294935
# Unit test for constructor of class Choice
def test_Choice():
    choices = [1, 2, 3]
    choice_field = Choice(choices=choices)
    assert(choice_field.choices == [(1,1), (2,2), (3,3)])


# Generated at 2022-06-12 15:42:00.269332
# Unit test for method validate of class Union
def test_Union_validate():
    class UnionTest(Union):
        def __init__(self, any_of: typing.List[Field]) -> None:
            super().__init__(any_of)
    class UnionTest1(UnionTest):
        def __init__(self, any_of: typing.List[Field]) -> None:
            super().__init__(any_of)
    class UnionTest2(UnionTest):
        def __init__(self, any_of: typing.List[Field]) -> None:
            super().__init__(any_of)
    class UnionTest3(UnionTest):
        def __init__(self, any_of: typing.List[Field]) -> None:
            super().__init__(any_of)
    UnionTest1([Integer(), Number()])
    UnionTest2([Integer()])

# Generated at 2022-06-12 15:42:07.556330
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # test of case error
    # result of assert is True, test is passed
    assert (test_field_1.validate_or_error(5, strict=False).error != None)
    # test of case result of function validate
    # result of assert is True, test is passed
    assert (test_field_1.validate_or_error(4, strict=False).value == 4.0)



# Generated at 2022-06-12 15:42:14.062030
# Unit test for constructor of class String
def test_String():
    string = String(title="Hello world", description="My test", default=str(1))
    assert string.title == "Hello world"
    assert string.description == "My test"
    assert string.default == "1"
    assert string.has_default() == True
    assert string.get_default_value() == "1"
    result = string.validate_or_error("")
    assert result.value == ""
    assert result.error == None
    result = string.validate_or_error("Hello")
    assert result.value == "Hello"
    assert result.error == None
    result = string.validate_or_error(123)
    assert result.value == None
    assert result.error == "Must be a string."



# Generated at 2022-06-12 15:42:25.149822
# Unit test for method validate of class Choice
def test_Choice_validate():

    field = Choice(choices=[("a", "A"),("b", "B")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    with pytest.raises(ValidationError):
        field.validate("c")

    field = Choice(choices=[("a", "A"),("b", "B")], null=True)
    assert field.validate("a") == "a"
    assert field.validate(None) == None
    assert field.validate("c") == "c"
    assert field.validate("") == ""
    with pytest.raises(ValidationError):
        field.validate("c")


# Generated at 2022-06-12 15:42:37.192711
# Unit test for method validate of class Union
def test_Union_validate():
    """Unit test for method valid of class Union"""
    
    #When using 'strict'
    union = Union([Integer(),Number()])
    assert isinstance(union.validate(3, strict=True), int) #passing
    #but fail
    with pytest.raises(ValidationError) as exception_info:
        union.validate('hola', strict=True)
    messages = exception_info.value.messages()
    assert len(messages) == 1 #there is only one message in the error
    message = messages[0]
    assert message.code == 'union' #of type 'union'
    #finally
    assert union.validate('hola', strict=False) == 'hola' #loosy



# Generated at 2022-06-12 15:42:45.010798
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    """
    Test for test for validate of class Boolean
    """
    print("test Boolean validate")
    test_Boolean = Boolean(title="a")
    value = True
    assert test_Boolean.validate(value=value) == True
    test_Boolean = Boolean(title="a",allow_null=True)
    value = None
    assert test_Boolean.validate(value=value) == None
    value = False
    try:
        print("")
        print("test Boolean validate raise error")
        print(test_Boolean.validate(value=value))
    except ValidationError as error:
        print(error)
        print("Test suceessfully")


# Generated at 2022-06-12 15:42:55.804129
# Unit test for method validate of class Choice
def test_Choice_validate():
    error = None

    # Pass
    try:
        Choice(choices=["1","2"]).validate("1")
    except Exception as err:
        error = err

    assert error is None

    # Fail
    error = None

    try:
        Choice(choices=["1","2"]).validate("3")
    except Exception as err:
        error = err

    assert isinstance(error, ValidationError)
    assert error.code == "choice"

    # Fail, null check
    error = None

    try:
        Choice(choices=["1","2"]).validate(None)
    except Exception as err:
        error = err

    assert isinstance(error, ValidationError)
    assert error.code == "null"

    # Fail, class type check
    error = None


# Generated at 2022-06-12 15:42:57.102547
# Unit test for method validate of class Number
def test_Number_validate():
        value = "100"
        assert Number().validate(value) == 100



# Generated at 2022-06-12 15:43:01.603938
# Unit test for method validate of class Union
def test_Union_validate():
    Union_test = Union([Text(), Number(integer=True)],
                       allow_null=True)
    assert Union_test.validate(5) == 5
    assert Union_test.validate("5") == "5"
    assert Union_test.validate(None) == None



# Generated at 2022-06-12 15:43:13.037548
# Unit test for method validate of class Number
def test_Number_validate():
    f = Number()
    assert f.validate(1.0) == 1.0
    assert f.has_default() is False
    assert f.get_default_value() is None

    f = Number(maximum=3.0)
    assert f.validate(1.0) == 1.0
    assert f.validate(3.0) == 3.0
    try:
        f.validate(3.1)
        assert False
    except ValidationError as e:
        assert str(e) == "'Must be less than or equal to 3.' (validation.maximum)"

    f = Number(minimum=3.0)
    assert f.validate(3.0) == 3.0
    assert f.validate(4.0) == 4.0

# Generated at 2022-06-12 15:43:22.464705
# Unit test for constructor of class String
def test_String():
    str1 = String(title = "ex", description = "ex", default = "ex", allow_null = False, allow_blank = False, trim_whitespace = True, max_length = 123, min_length = 123, pattern = None, format = None)

    assert str1.title == "ex"
    assert str1.description == "ex"
    assert str1.default == "ex"
    assert str1.allow_null == False
    assert str1.allow_blank == False
    assert str1.trim_whitespace == True
    assert str1.max_length == 123
    assert str1.min_length == 123
    assert str1.pattern == None
    assert str1.format == None

# Unit test to check the default value of constructor

# Generated at 2022-06-12 15:43:32.687219
# Unit test for method __or__ of class Field
def test_Field___or__():
    # NOTE: The tests below are written to be general, to test any class that is
    # a subclass of Field (since Field is an abstract base class). For this
    # reason, the tests below only focus on the expected behavior of
    # Field.__or__.
    Boolean1 = types.new_class("Boolean1", (Field,), {"errors": {}})
    Boolean2 = types.new_class("Boolean2", (Field,), {"errors": {}})
    Boolean3 = types.new_class("Boolean3", (Field,), {"errors": {}})

    # Test if an exception is raised when trying to union with a non-instance
    # of Field. Note that this test doesn't depend on the tested method. It is
    # testing the fact that any_of must be a list of instances of Field.

# Generated at 2022-06-12 15:43:35.729712
# Unit test for method validate of class Array
def test_Array_validate():
    arr=Array()
    arr.validate([{"name":"Tom","age":12},{"name":"Adam","age":21},{"name":"Paul","age":29}])

# Generated at 2022-06-12 15:43:38.170329
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
  defaultValue = Field.get_default_value()
  assert(defaultValue!=None)


# Generated at 2022-06-12 15:43:47.419541
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format="date")
    print(s.serialize('2000-12-31'))



# Generated at 2022-06-12 15:43:53.261179
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("1","A"),("2","B")])
    assert c.validate(None)==None
    #assert c.validate("1")=="1"
    #assert c.validate("2")=="2"
    #assert c.validate("3")==ValueError
    assert c.validate("")==None


# Generated at 2022-06-12 15:43:57.593992
# Unit test for method validate of class String
def test_String_validate():
    s = String(allow_null=True)
    assert s.validate('test') == 'test'
    assert s.validate('') == ''
    with pytest.raises(ValidationError):
        s.validate(None)
    assert s.validate(None, strict=True) is None


# Generated at 2022-06-12 15:44:03.413258
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([Number(), String()])
    value = u.validate(None)
    assert value is None
    value = u.validate(10)
    assert value == 10
    value = u.validate('a')
    assert value == 'a'
    try:
        u.validate([])
        assert 0
    except ValidationError as e:
        assert e.messages()[0].text == "Did not match any valid type."



# Generated at 2022-06-12 15:44:14.572802
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("CSE-43323", "DATABASE SYSTEM"), ("CSE-43328", "DATA MINING"), ("CSE-43341", "Software Engineering"), ("CSE-43331", "Software Project Management"), ("CSE-43322", "Algorithms"), ("CSE-43126", "Artificial Intelligence")]
    assert Choice(choices=[("CSE-43323", "DATABASE SYSTEM"), ("CSE-43328", "DATA MINING"), ("CSE-43341", "Software Engineering"), ("CSE-43331", "Software Project Management"), ("CSE-43322", "Algorithms"), ("CSE-43126", "Artificial Intelligence")]).validate("CSE-43323") == "CSE-43323"

# Generated at 2022-06-12 15:44:24.859628
# Unit test for method serialize of class String
def test_String_serialize():
    from typesystem.base import Type
    from typesystem.types import String
    import datetime
    import pytest

    class SerializeType(Type):
        format = "datetime"
        type = "serializeType"

    type_field = String(format="datetime")
    date_time_obj = datetime.datetime.now()
    serialize_string = type_field._serialize(date_time_obj, strict=False)
    assert isinstance(serialize_string, str)

    type_field = SerializeType()
    serialize_string = type_field._serialize(date_time_obj, strict=False)
    assert isinstance(serialize_string, str)

    type_field = SerializeType()

# Generated at 2022-06-12 15:44:27.990400
# Unit test for method serialize of class String
def test_String_serialize():
    a = String()
    assert isinstance(a.serialize("obj"),str)


# Generated at 2022-06-12 15:44:30.929518
# Unit test for constructor of class String
def test_String():
    with pytest.raises(AssertionError):
        String(title = 1, description = 'test')
    String(title = 'test', description = 'test')


# Generated at 2022-06-12 15:44:40.021391
# Unit test for method validate of class Object
def test_Object_validate():
    from cslang.api import SchemaObject, String, Integer
    s = SchemaObject(
        properties = {
            "a": String(),
            "b": Integer(),
            "c": String()
        },
        required = ["a", "b"],
        additional_properties = False
    )
    print(s.validate({"a": "a", "b": 1, "c": "d"}))
    print(s.validate({"a": "a", "b": 1, "d": "d"}))



# Generated at 2022-06-12 15:44:50.825687
# Unit test for method __or__ of class Field
def test_Field___or__():
    message = "this is an error message"

    field_0 = Field(default=1)
    field_1 = Field(default=2)
    field_2 = Field(default=3)

    union_field = field_0 | field_1 | field_2
    assert isinstance(union_field.any_of, list)
    assert len(union_field.any_of) == 3
    assert union_field.any_of[0].default == 1
    assert union_field.any_of[1].default == 2
    assert union_field.any_of[2].default == 3

    union_field = field_0 | field_1
    assert isinstance(union_field.any_of, list)
    assert len(union_field.any_of) == 2

# Generated at 2022-06-12 15:45:03.049767
# Unit test for method validate of class Object
def test_Object_validate():
    class MyField(Field):
        errors = {
            "null": "May not be null.",
            "required": "This field is required.",
            "invalid_key": "All object keys must be strings.",
            "invalid_property": "Invalid property name.",
            "empty": "Must not be empty.",
            "max_properties": "Must have no more than {max_properties} properties.",
            "min_properties": "Must have at least {min_properties} properties.",
        }
        def validate(self, value, *, strict=False) -> typing.Any:
            return value
        def serialize(self, obj: typing.Any) -> typing.Any:
            return obj
    object_1 = {'a': 30, 'b': 40}
    object_2 = {'a': 50, 'b': 60}
   

# Generated at 2022-06-12 15:45:05.180090
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    assert field.validate([]) == []

# Generated at 2022-06-12 15:45:16.392696
# Unit test for method validate of class String
def test_String_validate():
    assert String(max_length=10, allow_null=True, allow_blank=True).validate(None) == None
    assert String(max_length=10, allow_null=True, allow_blank=True).validate("") == ""
    assert String(max_length=10, allow_null=False, allow_blank=True).validate("") == ""
    assert String(max_length=10, allow_null=False, allow_blank=False).validate("") == None
    assert String(max_length=10).validate("") == None
    assert String(max_length=10).validate("TextString") == "TextString"
    assert String(max_length=10, min_length=2).validate("Text") == "Text"
    assert String(max_length=10, min_length=2).valid

# Generated at 2022-06-12 15:45:28.937799
# Unit test for method validate of class Choice
def test_Choice_validate():
    
    # create a class subclassing Choice
    class myChoice(Choice):
        pass
    
    # initialize an object of this class
    my_instance = myChoice()
    
    # return value in list of choices
    # use case
    value = 1
    choices = [1, 2]
    assert my_instance.validate(value, choices=choices) == 1
    
    # raise ValidationError if value is not in list of choices
    # use case
    value = 'a'
    choices = [1, 2]
    try:
        my_instance.validate(value, choices=choices)
    except ValidationError:
        assert True
    else:
        assert False
    
    # return value if value is equal to 'null' and allow_null=True
    # use case

# Generated at 2022-06-12 15:45:37.571308
# Unit test for method __or__ of class Field
def test_Field___or__():
    class FieldA(Field):
        def __init__(self, allow_null=False, **kwargs):
            super().__init__(allow_null=allow_null, **kwargs)
        def validate(self, value):
            if value in [1, 2]:
                return "A"
            else:
                raise self.validation_error("invalid")
    class FieldB(Field):
        def __init__(self, allow_null=False, **kwargs):
            super().__init__(allow_null=allow_null, **kwargs)
        def validate(self, value):
            if value in [3, 4]:
                return "B"
            else:
                raise self.validation_error("invalid")
    fa = FieldA()
    fb = FieldB()
    fu = fa | f

# Generated at 2022-06-12 15:45:41.494544
# Unit test for method __or__ of class Field
def test_Field___or__():
    # given
    a = Boolean()
    b = Integer()
    c = Integer()
    # when
    r = a | b | c
    # then
    assert isinstance(r, Union)
    assert r.any_of == [a, b, c]



# Generated at 2022-06-12 15:45:48.148725
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import types
    string = types.String()
    number = types.Integer()
    union1 = string | number
    assert isinstance(union1, types.Union)
    assert union1.any_of[0] == string
    assert union1.any_of[1] == number
    union2 = string | string
    assert isinstance(union2, types.Union)
    assert union2.any_of[0] == string
    assert union2.any_of[1] == string


# Generated at 2022-06-12 15:45:56.498142
# Unit test for method validate of class Object
def test_Object_validate():
    def validate(schema, data):
        try:
            return schema.validate(data)
        except ValidationError as e:
            return [
                {
                    "code": message.code,
                    "index": message.index,
                    "text": message.text,
                }
                for message in e.messages()
            ]

    schema = Object(properties={"a": Integer()})
    assert validate(schema, {"a": 5}) == {"a": 5}
    assert validate(schema, {"a": "5"}) == {"a": 5}
    assert validate(schema, {"a": "nope"}) == [{"code": "type", "index": ["a"]}]

    schema = Object(properties={"a": Decimal()})

# Generated at 2022-06-12 15:46:03.812181
# Unit test for constructor of class Choice
def test_Choice():
    choices = Choice(required=False, choices=[(1, "1"), (2, "2")])
    assert choices.allow_null == True
    assert choices.choices[0][0] == "1"
    assert choices.choices[0][1] == "1"
    assert choices.choices[1][0] == "2"
    assert choices.choices[1][1] == "2"



# Generated at 2022-06-12 15:46:04.985200
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test values that can be None
    testValue="test"
    f=Choice()
    assert f.validate(testValue)==testValue



# Generated at 2022-06-12 15:46:18.038226
# Unit test for method validate of class Object
def test_Object_validate():
    return_result = Object.validate("", required=True)
    assert return_result==None
    return_result = Object.validate("", required=False)
    assert return_result==None
    return_result = Object.validate({})
    assert return_result=={}
    return_result = Object.validate([])
    assert return_result==None

# Generated at 2022-06-12 15:46:22.373173
# Unit test for method __or__ of class Field
def test_Field___or__():
    class SampleField(Field):
        errors: typing.Dict[str, str] = {
            "invalid_type": "Expected a value of type '{title}'"
        }
        title: str  # noqa
        description: str = ""  # noqa
        default: typing.Any = NO_DEFAULT  # noqa
        allow_null: bool = False  # noqa
    assert (SampleField() | SampleField())



# Generated at 2022-06-12 15:46:33.539220
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["a", "b"])
    c.validate("a")
    try:
        c.validate("c")
        assert False
    except ValidationError:
        assert True
    try:
        c.validate("")
        assert False
    except ValidationError:
        assert True
    c = Choice(choices=["a", "b"], allow_null=True)
    assert c.validate("") is None
    assert c.validate(None) is None
    assert c.validate(False) is None
    try:
        c.validate("a")
        assert False
    except ValidationError:
        assert True
    try:
        c.validate("c")
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-12 15:46:36.317612
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate('') == ''
    assert String().validate('astring') == 'astring'
    assert String().validate(None) is None

# Generated at 2022-06-12 15:46:40.329202
# Unit test for method validate of class Union
def test_Union_validate():
    f1 = Field()
    f2 = Field()
    f3 = Field()
    f = Union(any_of = [f1,f2,f3])
    f.validate(None)


# Generated at 2022-06-12 15:46:42.903943
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    error = a.validate([2,"b",[1,2],{'c':3}])
    print(error)

# Generated at 2022-06-12 15:46:45.967274
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=1)
    assert field.get_default_value() == 1



# Generated at 2022-06-12 15:46:55.821075
# Unit test for constructor of class String
def test_String():
    # title
    try:
        String(title=42)
        assert False
    except AssertionError:
        pass

    # description
    try:
        String(description=42)
        assert False
    except AssertionError:
        pass

    # allow_blank
    true = String(allow_blank=True)
    false = String(allow_blank=False)
    assert true.allow_blank
    assert not false.allow_blank

    # trim_whitespace
    true = String(trim_whitespace=True)
    false = String(trim_whitespace=False)
    assert true.trim_whitespace
    assert not false.trim_whitespace

    # max_length

# Generated at 2022-06-12 15:47:07.075607
# Unit test for method validate of class Object
def test_Object_validate():
    class Schema(Object):
        properties = {
            'id': Integer(),
            'username': String(),
            'email': String(),
            'address': String()
        }
        required = ['id', 'username']

    data = {
        'id': 1,
        'username': 'admin',
        'email': 'admin@gmail.com',
        'address': '123 fake st, niagara falls, USA'
    }

    schema = Schema()
    assert isinstance(schema.validate(data), dict)
    assert schema.validate(data) == data

    data['age'] = '20'
    try:
        schema.validate(data)
    except ValidationError:
        assert True
    else:
        assert False

    data = {'id': '1', 'username': 'admin'}

# Generated at 2022-06-12 15:47:11.953666
# Unit test for constructor of class Const
def test_Const():
    # test regular case
    Const(const=True)
    Const(const=1)
    Const(const=1.0)
    # test case where error should be raised
    # Const(const=None, allow_null=True)
    # Const(const=False)
    return True


# Generated at 2022-06-12 15:47:26.161780
# Unit test for method validate of class Union
def test_Union_validate():
    data = {"type": "object", "properties": {}}
    schema = Schema.from_json(data)
    fields = schema.create(data)
    a = Object()
    b = Array()
    u = Union([a,b],name="Abc")
    try:
        u.validate(object())
    except ValidationError as ve:
        assert(ve.messages()[0].code == "union")

    try:
        u.validate(object())
    except ValidationError as ve:
        assert(ve.messages()[0].code == "union")
    
    
# Test the method validate of class Union
test_Union_validate()


# Generated at 2022-06-12 15:47:35.909776
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(title="", description="", default=NO_DEFAULT, allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, precision=None, multiple_of=None).validate(1.2) == 1.2
    assert Number(title="", description="", default=NO_DEFAULT, allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, precision=None, multiple_of=None).validate(1.0) == 1
    assert Number

# Generated at 2022-06-12 15:47:37.150173
# Unit test for method __or__ of class Field
def test_Field___or__():
    a = Field()
    isinstance(a|a, Union)

# Generated at 2022-06-12 15:47:44.880737
# Unit test for method get_default_value of class Field
def test_Field_get_default_value(): 
  f = Field(description = "description", title = "title")
  assert f.get_default_value() == None, "The 'get_default_value' method is wrong!"
  #f = Field(description = "description", title = "title", default = "default")
  #assert f.get_default_value() == "default", "The 'get_default_value' method is wrong!"
  
test_Field_get_default_value()


# Generated at 2022-06-12 15:47:57.678561
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(
        choices=[
            ("", ""),
            ("1", "1"),
            (1, 1),
            ("a", "a"),
            ("a", None),
            (None, "a"),
            (None, 1),
            ("a", 1),
        ]
    )
    assert choice.validate(1) == 1
    assert choice.validate("1") == "1"
    assert choice.validate("a") == "a"
    assert choice.validate(None) == None
    assert choice.validate(None) == None

    try:
        assert choice.validate("x") == "x"
    except ValidationError:
        pass
    try:
        assert choice.validate(2) == 2
    except ValidationError:
        pass

# Generated at 2022-06-12 15:48:04.729233
# Unit test for method validate of class Number
def test_Number_validate():
    num1 = Number(title = "id", description="Must be an integer.", minimum=0, exclusive_minimum=0, allow_null=False)
    assert num1.validate(1) == 1 #test for int
    assert num1.validate(1.1) == 1.1 #test for float
    assert num1.validate(0) == 0 #test for exclusive_minimum
    assert num1.validate(-1) is None #test for below minimum
    assert num1.validate(-1, strict=False) == -1 #test for below minimum
    assert num1.validate(1e300) is None #test for infinity
    assert num1.validate(1e300, strict=False) == 1e300  #test for infinity
    assert num1.validate('1') == 1 #test for string
    assert num1

# Generated at 2022-06-12 15:48:15.681998
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(
        choices=[
            ("instructor_evaluate", "我要查询老师的评分"),
            ("student_evaluate", "我要给老师评分"),
        ]
    ).validate(value = "instructor_evaluate") == "instructor_evaluate"
    assert Choice(
        choices=[
            ("instructor_evaluate", "我要查询老师的评分"),
            ("student_evaluate", "我要给老师评分"),
        ]
    ).validate(value = "student_evaluate") == "student_evaluate"

# Generated at 2022-06-12 15:48:18.603143
# Unit test for method validate of class String
def test_String_validate():
    # assert 1 == 2
    s = String(allow_null=False, allow_blank=False, max_length=5, min_length=5)
    s.validate("12345")
    s.validate("123456")


# Generated at 2022-06-12 15:48:27.421382
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = Integer()
    f2 = Nullable() | Common() | Integer()
    f3 = Nullable() | Common() | Integer() | List()
    f4 = (Nullable() | Common() | Integer()) | List()
    assert f2.any_of == f3.any_of == f4.any_of == [Nullable(), Common(), Integer()]
    f5 = f1 | f3
    assert f5.any_of == [f1, f2]
    f6 = f5 | f4
    assert f6.any_of == [f1, f2, List()]
    assert f6 == f5 | f4


# Generated at 2022-06-12 15:48:32.776261
# Unit test for method __or__ of class Field
def test_Field___or__():
	# given:
	field1 = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
	field2 = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
	# when:
	union = field1 | field2
	# then:
	assert type(union) is Union
	assert union.any_of == [field1, field2]

# Generated at 2022-06-12 15:48:47.223021
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    print('Test get_default_value of class Field')
    #test case 1:
    field = Field()
    assert field.get_default_value() == None

    #test case 2:
    field = Field(default = 0)
    assert field.get_default_value() == 0

    #test case 3:
    field = Field()
    field.default = 0
    assert field.get_default_value() == 0

    #test case 4:
    def default():
        return 0
    field = Field(default = default)
    assert field.get_default_value() == 0

    #test case 5:
    field = Field()
    field.default = default
    assert field.get_default_value() == 0

    #test case 6:

# Generated at 2022-06-12 15:49:00.056614
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(5) == 5
    assert Number().validate(-5) == -5
    assert Number().validate("5") == 5
    assert Number().validate("-5") == -5
    assert Number().validate("-5.5") == -5.5
    assert Number().validate("invalid", strict=False) == "invalid"
    assert Number(allow_null=True).validate("", strict=False) is None
    assert Number(allow_null=True).validate("", strict=True) is None
    assert Number().validate("", strict=True) == ""
    assert Number().validate(" ") == " "
    assert Number(trim_whitespace=False).validate(" ") == " "
    assert Number(allow_blank=True).validate("") == ""
   

# Generated at 2022-06-12 15:49:03.381032
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(default = 'abc')
    try:
        assert f.get_default_value() == 'abc'
        print('Test passed')
    except:
        print('Test failed')


# Generated at 2022-06-12 15:49:14.690249
# Unit test for method validate of class String
def test_String_validate():
    import logging
    import sys
    import unittest

    logger = logging.getLogger(__name__)
    logger.level = logging.INFO
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s:%(name)s:(%(levelname)s):%(message)s"))
    logger.addHandler(handler)


    class TestString_validate(unittest.TestCase):
        
        def setUp(self):
            pass
        
        def tearDown(self):
            pass
 

        def test_String_validate_t1(self):
            logger.info("test_String_validate_t1. Starting test")
            data = True
            expected = True
            actual = None