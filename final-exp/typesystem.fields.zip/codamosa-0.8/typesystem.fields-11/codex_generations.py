

# Generated at 2022-06-12 15:41:02.231360
# Unit test for method serialize of class String
def test_String_serialize():
        assert String().serialize("abc") == "abc"
        assert String(format="date").serialize("abc") == "abc"
        assert String(format="date").serialize("2020-01-01") == "2020-01-01"



# Generated at 2022-06-12 15:41:05.692943
# Unit test for method validate of class Number
def test_Number_validate():
    f = Number()
    assert f.validate(1) == 1
    assert f.validate('1') == 1


# Generated at 2022-06-12 15:41:10.627511
# Unit test for method validate of class Array
def test_Array_validate():
    with pytest.raises(ValidationError):
        Array(
            items=Integer(), unique_items=True
        ).validate([1, 2, 1])

    with pytest.raises(ValidationError):
        Array(items=Integer(), max_items=2, allow_null=True).validate(None)


    assert Array(items=Integer(), max_items=2, allow_null=True).validate([]) == []



# Generated at 2022-06-12 15:41:13.801958
# Unit test for method validate of class Array
def test_Array_validate():
    items = [
        Integer(minimum=0, exclusiveMaximum=2),
        String(max_length=10),
        Array(items=Boolean()),
    ]
    data = [1, "a", [True, False, True]]
    schema = Array(items=items)

    assert schema.validate(data) == data



# Generated at 2022-06-12 15:41:17.045450
# Unit test for method validate of class String
def test_String_validate():
     string=String()
     assert(string.validate("asd")=="asd")

# Generated at 2022-06-12 15:41:23.320489
# Unit test for method validate of class Union
def test_Union_validate():
    string_field = String()
    int_field = Integer()
    union_field = Union([string_field, int_field])
    assert union_field.validate("string") == "string"
    assert union_field.validate(5) == 5
    assert str(union_field.validation_error("type", index=[5])) == "type error at [5]"



# Generated at 2022-06-12 15:41:35.549593
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        additional_items=Integer(minimum=1, maximum=5),
        items=Integer(minimum=5, maximum=5),
        max_items=5,
        min_items=5,
        unique_items=True,
    )

    assert field.validate(list(range(5))) == list(range(5))
    assert field.validate(list(range(5, 10))) == list(range(5, 10))
    assert field.validate([1, 2, 3, 4, 7]) == [1, 2, 3, 4, 7]

    with pytest.raises(ValidationError):
        field.validate([1, 2, 3, 4, 7, 10])


# Generated at 2022-06-12 15:41:39.113879
# Unit test for method serialize of class String
def test_String_serialize():
    field = String()
    assert field.serialize(123) == 123

    field = String(format='uuid')
    assert field.serialize('123e4567-e89b-12d3-a456-426655440000') == '123e4567-e89b-12d3-a456-426655440000'


# Generated at 2022-06-12 15:41:48.841105
# Unit test for method validate of class Array
def test_Array_validate():

    # Case 1: Test when self.items is an instance of Field
    test_field = Field()
    test_array = Array(items=test_field)
    assert test_array.validate([1, 2, 3]) == [1, 2, 3]

    # Case 2: Test when self.items is an instance of list, and len(self.items) is nonzero
    test_field = Field()
    test_array = Array(items=[test_field, test_field])
    assert test_array.validate([1, 2, 3]) == [1, 2]

    # Case 3: Test when self.items is an instance of list, and len(self.items) is zero
    test_field = Field()
    test_array = Array(items=[])

# Generated at 2022-06-12 15:41:55.533008
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    a = "banana"
    b = "123"
    c = ""
    d = "python"
    e = "apple"
    f = "dog"
    g = "cat"
    h = "    monkey    "

    assert (string.validate(a) == "banana")
    assert (string.validate(b) == "123")
    assert (string.validate(c) == "")
    assert (string.validate(d) == "python")
    assert (string.validate(e) == "apple")
    assert (string.validate(f) == "dog")
    assert (string.validate(g) == "cat")
    print(string.validate(h))
    assert (string.validate(h) == "monkey")
test_String_valid

# Generated at 2022-06-12 15:42:12.928919
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
    Test that __or__ method properly combines simple fields or unions
    """
    import pytest

    str_field = String()
    int_field = Integer()
    bool_field = Boolean()

    str_or_int = str_field | int_field
    assert len(str_or_int.any_of) == 2
    assert String in str_or_int.any_of
    assert Integer in str_or_int.any_of

    # Check that a union of union and a simple field
    # produces a union of three fields
    str_or_int_or_bool = str_or_int | bool_field
    assert len(str_or_int_or_bool.any_of) == 3
    assert String in str_or_int_or_bool.any_of
    assert Integer in str_or_

# Generated at 2022-06-12 15:42:16.682313
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj1 = Choice(choices=["Male", "Female"])
    obj2 = Choice(choices=["Male", "Female"])
    assert obj1.validate(value="Male") == "Male"
    assert obj2.validate(value="Female") == "Female"



# Generated at 2022-06-12 15:42:26.530812
# Unit test for method validate of class Number
def test_Number_validate():
    assert Integer().validate(3) == 3
    assert Integer().validate(-3) == -3
    assert Integer().validate(3.3) == 3
    assert Integer().validate('3') == 3
    assert Integer().validate(None) is None
    assert Integer().validate('') == 0
    assert Integer().validate('') is not None
    assert Integer().validate('test') == 0
    assert Integer().validate('test') is not None
    assert Integer().validate(False) == 0
    assert Integer().validate(True) == 1
    assert Integer(allow_null=True).validate(None) == None
    assert Integer().validate(34) == 34
    assert Integer().validate(2.5) == 3
    assert Integer().validate(-2.5) == -3
    assert Integer

# Generated at 2022-06-12 15:42:32.544472
# Unit test for method validate of class Choice
def test_Choice_validate():
    
    # Test for case when all arguments are valid
    assert Choice(allow_null=True, choices=("a","b")).validate("a") == "a"
    
    # Test for case when  argument, value , is None
    assert Choice(allow_null=True, choices=("a","b")).validate(None) == None
    
    # Test for case when argument, value , is not in choices
    try:
        Choice(allow_null=True, choices=("a","b")).validate("c")
        assert False
    except ValidationError:
        assert True
        
    # Test for case when argument, value , is empty string and
    # allow_null is True

# Generated at 2022-06-12 15:42:37.458976
# Unit test for method serialize of class Array
def test_Array_serialize():
    items_values = [[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[8,9],[9,10]]
    items_fields = [
        Integer(maximum=5, minimum=1),
        Integer(maximum=10, minimum=2),
    ]
    items_fields[0].serialize(items_values[0][0])
    items_fields[1].serialize(items_values[0][1])
    items_fields[0].serialize(items_values[1][0])
    items_fields[1].serialize(items_values[1][1])
    items_fields[0].serialize(items_values[2][0])
    items_fields[1].serialize(items_values[2][1])
    items_fields[0].serial

# Generated at 2022-06-12 15:42:45.905238
# Unit test for method __or__ of class Field
def test_Field___or__():
    ''' Method __or__ of class Field '''
    valA = 'test'
    # print("valA:",valA)
    valB = 'test'
    # print("valB:",valB)
    valC = 'test'
    # print("valC:",valC)
    valD = 'test'
    # print("valD:",valD)
    valE = 'test'
    # print("valE:",valE)
    valF = 'test'
    # print("valF:",valF)
    valG = 'test'
    # print("valG:",valG)
    valH = 'test'
    # print("valH:",valH)
    valI = 'test'
    # print("valI:",valI)

# Generated at 2022-06-12 15:42:48.121155
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None



# Generated at 2022-06-12 15:42:57.843572
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.base import Type
    from typesystem import string

    class TestType(Type):
        pass
    type_one = TestType()
    type_two = TestType()
    type_three = TestType()
    assert TestType() | string.String() == TestType() | string.String()
    assert TestType() | TestType() == TestType() | TestType()
    assert TestType() | TestType() == TestType() | TestType() | TestType()
    assert TestType() | TestType() == TestType() | TestType() | string.String()
    assert TestType() | TestType() == TestType() | string.String()
    assert TestType() | TestType() == TestType() | string.String()
    assert TestType() | TestType() | TestType() == TestType() | TestType() | TestType

# Generated at 2022-06-12 15:43:00.314615
# Unit test for method validate of class Number
def test_Number_validate():
    test_class = Number(minimum = 10)
    assert test_class.validate(15) == 15
    assert test_class.validate(9) == None


# Generated at 2022-06-12 15:43:04.899560
# Unit test for method validate of class Object
def test_Object_validate():
    # Test Object_validate function
    schema = Object(properties={"foo": Integer(minimum=0, maximum=10)})
    try:
        schema.validate({"foo": 5})
        assert True
    except ValidationError:
        assert False
    
test_Object_validate()


# Generated at 2022-06-12 15:43:33.812465
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    if Field.get_default_value.__doc__:
        assert True
    else:
        assert False

# Generated at 2022-06-12 15:43:46.810355
# Unit test for constructor of class Choice
def test_Choice():
    # Case 1
    a = Choice(choices=[])
    assert isinstance(a, Field)
    assert len(a.choices) == 0

    # Case 2
    a = Choice(choices=["a", "b", "c"])
    assert isinstance(a, Field)
    assert len(a.choices) == 3
    assert a.choices == [("a", "a"), ("b", "b"), ("c", "c")]

    # Case 3
    a = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert isinstance(a, Field)
    assert len(a.choices) == 3
    assert a.choices == [("a", "a"), ("b", "b"), ("c", "c")]

    # Case 4


# Generated at 2022-06-12 15:43:59.599164
# Unit test for constructor of class Array

# Generated at 2022-06-12 15:44:02.827378
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String, Boolean
    field = String(title='Title')
    other_field = Boolean(title='Other title')
    union = field | other_field
    assert isinstance(union, Union)
    assert union.any_of == [field, other_field]



# Generated at 2022-06-12 15:44:05.786160
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[])
    try:
        choice.validate(None)
    except:
        assert True


# Generated at 2022-06-12 15:44:17.324838
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(
        properties={
            "age": Integer(),       
            "name": String(max_length=5),
        },
        additional_properties=False,
        error_messages={
            "age": "age is not a integer",
            "name": "name is not a string",
        }
    )
    
    assert field
    
    assert field.validate({
        "age": 30,
        "name": "John"
    })
    
    assert field.validate({
        "age": 30,
        "name": "John Doe"
    }) == {
        "age": 30,
        "name": "John"
    }
    

# Generated at 2022-06-12 15:44:27.117815
# Unit test for method validate of class Union
def test_Union_validate():
    with pytest.raises(ValidationError) as info:
        Union([Integer(), String()]).validate(False)
        assert info.value.messages() == [
            {
                "code": "union",
                "text": "Did not match any valid type.",
                "index": [],
                "key": None,
            }
        ]

    with pytest.raises(ValidationError) as info:
        Union([Integer(), String()]).validate(None)
        assert info.value.messages() == [
            {
                "code": "union",
                "text": "Did not match any valid type.",
                "index": [],
                "key": None,
            }
        ]

# Generated at 2022-06-12 15:44:37.246137
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["f", "g", "h"]).validate("f")
    assert Choice(choices=["f", "g", "h"]).validate("g")
    assert Choice(choices=["f", "g", "h"]).validate("h")
    # check for error
    error_msg = "Invalid value for Choice"
    with pytest.raises(ValidationError) as error:
        Choice(choices=["f", "g", "h"]).validate("i")
    assert error.value.text == error_msg
    # check for error for null input
    error_msg = "May not be null."
    with pytest.raises(ValidationError) as error:
        Choice(choices=["f", "g", "h"]).validate(None)
    assert error

# Generated at 2022-06-12 15:44:45.808494
# Unit test for method validate of class Array
def test_Array_validate():
    class Test:
        @classmethod
        def run(cls, test_range):
            for i in test_range:
                test = cls()
                cls.test_case_1(test, i)

        @classmethod
        def test_case_1(cls, test, i):
            test.min_items = i[0] 
            test.max_items = i[1]
            try:
                test.validate(i[2])
                assert 0, 'assertion failed'
            except ValidationError:
                pass

    Test.run([[1, None, []], [1, 2, list(range(3))], [None, 2, list(range(3))]])

# Generated at 2022-06-12 15:44:53.803404
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    value1 = "boolean"
    value2 = "boolean"
    value3 = "boolean"
    value4 = "boolean"
    value5 = "boolean"
    value6 = "boolean"
    value7 = "boolean"
    value8 = "boolean"
    value9 = "boolean"
    value10 = "boolean"
    value11 = "boolean"
    value12 = "boolean"
    value13 = "boolean"
    value14 = "boolean"
    value15 = "boolean"
    value16 = "boolean"
    value17 = "boolean"
    value18 = "boolean"
    value19 = "boolean"
    value20 = "boolean"
    value21 = "boolean"
    value22 = "boolean"
   

# Generated at 2022-06-12 15:45:06.682103
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    from typesystem.fields import String

    field = String()
    assert field.get_default_value() is None

    field = String(default="foo")
    assert field.get_default_value() == "foo"

    def frob():
        return "frob"

    field = String(default=frob)
    assert field.get_default_value() == "frob"


# Generated at 2022-06-12 15:45:12.442448
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[('test', 'test')], allow_null=True)
    assert field.validate('test') == 'test'
    assert field.validate(None) == None
    assert field.validate('test2') == 'test'
    assert field.validate('') == None

# BEGIN: Unit test for method serialize of class Choice

# Generated at 2022-06-12 15:45:14.770626
# Unit test for constructor of class String
def test_String():
    with pytest.raises(AssertionError, match=r".*isinstance.*int.*"):
        String(max_length="test")


# Generated at 2022-06-12 15:45:22.019357
# Unit test for method validate of class Object
def test_Object_validate():
    sample = {"first_name":"Kumaran",
              "second_name":"Murugan",
              "tax-id": "123-45-6789",
              "email":"kumarank2@gmail.com",
              "birthdate": "2020-08-15T16:00:00Z"}
    data_field_schema = {'first_name': {'required': True, 'type': 'string'},
                         'tax-id': {'required': True, 'type': 'string'},
                         'email': {'required': True, 'type': 'string'},
                         'birthdate': {'required': True, 'type': 'string'}}
    additional_properties = True
    # additional_properties = False
    field = Object(additional_properties=additional_properties, properties=data_field_schema)
   

# Generated at 2022-06-12 15:45:26.866078
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_one = Field(title='field_one')
    field_two = Field(title='field_two')
    union_field = field_one | field_two
    assert union_field.any_of == [field_one, field_two]



# Generated at 2022-06-12 15:45:32.483668
# Unit test for constructor of class Const
def test_Const():
    assert Const(True).validate(True) == True
    assert Const(True).validate(False) == ValueError
    assert Const(False).validate(True) == ValueError
    assert Const(False).validate(False) == False
    assert Const(None).validate(None) == None
    assert Const(None).validate(False) == ValueError
    assert Const(False).validate(None) == ValueError
    

# Generated at 2022-06-12 15:45:38.772627
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1
    field_string = String(max_length=30, allow_blank=False, allow_null=False, default="")
    assert field_string.validate("") == "", "Failed test case #1.1 of method validate in class String"
    assert field_string.validate(None) == "", "Failed test case #1.2 of method validate in class String"
    assert field_string.validate(12) == "", "Failed test case #1.3 of method validate in class String"
    assert field_string.validate(True) == "", "Failed test case #1.4 of method validate in class String"
    assert field_string.validate("This is a test string") == "This is a test string", "Failed test case #1.5 of method validate in class String"
   

# Generated at 2022-06-12 15:45:40.366500
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field().__or__(Field()) == None
    


# Generated at 2022-06-12 15:45:50.233663
# Unit test for method validate of class Choice
def test_Choice_validate():
    #Function to test if the validation function of class Choice works
    print("Testing Choice validate")

    #Test input is a string
    Choice_test = Choice(field_name="Gender", default="M", choices=[("F","Female"), ("M","Male")])
    assert Choice_test.validate("M") == "M"

    #Test input is the null string 
    Choice_test = Choice(field_name="Gender", default="M", choices=[("F","Female"), ("M","Male")])
    assert Choice_test.validate("") == None

    #Test input is a digit
    Choice_test = Choice(field_name="Gender", default="0", choices=[("F","Female"), ("M","Male")])
    assert Choice_test.validate("0") == "0"
    
    #Test input is not a valid choice
   

# Generated at 2022-06-12 15:45:55.167455
# Unit test for method validate of class Object
def test_Object_validate():
    from schemas import Object
    from schemas import Integer
    from schemas import String
    
    obj = Object(
        title="object",
        properties={
            "name": String(title="name"),
            "age": Integer(title="age"),
        },
        required=["name", "age"]
    )
    
    obj.validate({"name": "test", "age": 21})
test_Object_validate()


# Generated at 2022-06-12 15:46:19.987946
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice(choices = [(1,"One"), (2,"Two"), (3,"Three")])
    assert choices.validate(1) == 1
    assert choices.validate("Two") == "Two"
    assert choices.validate(3) == 3
    assert choices.validate("Thre") == "Thre"
    with pytest.raises(ValidationError):
        choices.validate("One")
    with pytest.raises(ValidationError):
        choices.validate("Four")
    with pytest.raises(ValidationError):
        choices.validate("")
    with pytest.raises(ValidationError):
        choices.validate(4)
    with pytest.raises(ValidationError):
        choices.validate(4.5)

# Generated at 2022-06-12 15:46:31.454182
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test case data
    field_A_data = {'title': 'titleA', 'description': 'descriptionA', 'default': 'defaultA', 'allow_null': False}
    field_A = Field(**field_A_data)
    field_B_data = {'title': 'titleB', 'description': 'descriptionB', 'default': 'defaultB', 'allow_null': False}
    field_B = Field(**field_B_data)
    union_AB_data = {'title': '', 'description': '', 'default': NO_DEFAULT, 'allow_null': False}
    union_AB = Union(any_of=[field_A, field_B])
    # Perform the test
    result = field_A | field_B
    # Ensure the test results
    assert isinstance(result, Union)
   

# Generated at 2022-06-12 15:46:36.697412
# Unit test for method validate of class Array
def test_Array_validate():
    # Initialization
    arr_field = Array(unique_items=True)

    # Test case
    data = [1, 2, 2, 3]
    expected_return = [1,2,3]
    expected_exception = ValidationError([Message(text='Items must be unique.', code='unique_items', key=1)])
    actual_return = arr_field.validate(data)
    assert actual_return == expected_return



# Generated at 2022-06-12 15:46:41.580010
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {"name": Str()}
    obj = Object(properties=properties)
    value = obj.validate({"name": "Jack"})
    assert value == {"name": "Jack"}
    value = obj.validate({"age": 12})
    assert value["age"] == 12



# Generated at 2022-06-12 15:46:48.033831
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyDefault(Field):
        def __init__(self):
            super().__init__(default=1)

    class MyCallableDefault(Field):
        def __init__(self):
            super().__init__(default=lambda: 1)

    assert MyDefault().get_default_value() == 1
    assert MyCallableDefault().get_default_value() == 1


# Generated at 2022-06-12 15:46:52.425087
# Unit test for method validate of class String
def test_String_validate():
    a = String()
    assert a.validate('budi') == 'budi'
    assert a.validate('budi', strict=True) == 'budi'
    assert a.validate('budi', strict=False) == 'budi'
    assert a.validate(None) == None
    assert a.validate(None, strict=True) == None
    assert a.validate(None, strict=False) == None
    assert a.validate('') == ''
    assert a.validate('', strict=True) == ''
    assert a.validate('', strict=False) == ''
    assert a.validate(' ', strict=True) == ' '
    assert a.validate(' ', strict=False) == None
    assert a.validate(None, strict=False) == None

# Generated at 2022-06-12 15:46:53.436777
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    assert obj.get_default_value() == None

# Generated at 2022-06-12 15:47:00.451141
# Unit test for method validate of class Union
def test_Union_validate():
    '''
    This test is built to verify the method validate of Union
    '''

    # Define the correct tests
    correct_tests = {
        'value1': ({"key1": "value"}, {"key1": "value"}),
        'value2': ({"key2": 10}, {"key2": 10}),
        'value3': ({"key3": None}, {"key3": None}),
    }

    # Define the wrong tests
    wrong_tests = {
        'value1': ({"key1": 1}, {"key1": 1}),
        'value2': ({"key2": "hello"}, {"key2": "hello"}),
        'value3': ({"key3": "value"}, {"key3": "value"}),
    }

    # Define some schemas

# Generated at 2022-06-12 15:47:13.091462
# Unit test for method validate of class Array
def test_Array_validate():

    # create a stupid field for array 
    class StupidField(Field):
        def serialize(self, x):
            return str(x)
        def deserialize(self, x):
            return int(x)

    # create an array schema
    s = Array(items=StupidField())

    # test min_items, max_items, unique_items and additional_items
    s = Array(min_items=4, max_items=4, unique_items=True, additional_items=False)
    assert s.validate([11,22,33,44]) == [11,22,33,44]
    try:
        assert s.validate([1,2,3,4,5])
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-12 15:47:21.395308
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice(choices=[("F", "F")])
    assert c1.validate("F") == "F"

    c2 = Choice(choices=[("F", "F"), ("M", "M")])
    assert c2.validate("F") == "F"
    assert c2.validate("M") == "M"

    # Test case where value is null and this field should not be null
    with pytest.raises(ValidationError):
        c3 = Choice(choices=[("F", "F")])
        c3.validate(None)



# Generated at 2022-06-12 15:47:34.895864
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(
        name="myField"
    )
    value = None
    res_value = field.validate(value)
    assert res_value is None, 'validate(field, value) has not the expected value'
    
    field = Choice(
        name="myField"
    )
    value = ''
    try:
        res_value = field.validate(value)
    except Exception as e:
        assert 'Must be a valid choice.' in str(e)
    else:
        assert False, 'validate(field, value) does not raise the expected ValidationError'
    
    field = Choice(
        name="myField",
        choices=[('foo', 'one')]
    )
    value = 'foo'
    res_value = field.validate(value)
    assert res_value

# Generated at 2022-06-12 15:47:47.566346
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    assert field.validate([]) == []
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "c", "c"]) == ["a", "c", "c"]
    assert field.validate([]) == []
    assert field.validate(["x"]) == ["x"]
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]

    field = Array(min_items=1, max_items=1)
    assert field.validate([]) == []
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]

# Generated at 2022-06-12 15:47:51.680472
# Unit test for method validate of class Union
def test_Union_validate():
    #TODO: Try to fix this test
    any_of = [String(format="text"), Integer(format="int32")]
    union = Union(any_of =any_of)
    assert union.validate(1, strict = False) == 1
    

# Generated at 2022-06-12 15:48:02.202970
# Unit test for method validate of class Choice

# Generated at 2022-06-12 15:48:08.175361
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    try:
        s.validate(None)
        assert False
    except ValidationError:
        assert True
    s = String(allow_null=True)
    assert s.validate(None) == None
    s = String()
    try:
        s.validate(True)
        assert False
    except ValidationError:
        assert True
    s = String()
    try:
        s.validate('')
        assert False
    except ValidationError:
        assert True
    s = String(allow_blank=True)
    assert s.validate('') == ''
    s = String()
    try:
        s.validate('a'*257)
        assert False
    except ValidationError:
        assert True
    s = String(max_length=256)


# Generated at 2022-06-12 15:48:14.208516
# Unit test for method validate of class Choice
def test_Choice_validate():   
    choices = [("0", "A"), ("1", "B"), ("2", "C")]
    choice_from_list = Choice(choices=choices)
    assert choice_from_list.validate("0") == "0"
    assert choice_from_list.validate("1") == "1"
    assert choice_from_list.validate("2") == "2"
    assert choice_from_list.validate("3") == "3"


# Generated at 2022-06-12 15:48:17.830211
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice(choices=(("test1","test1"),("test2","test2")))
    assert choices.validate("test1") == "test1"
    assert choices.validate("test2") == "test2"
    assert choices.validate("test3") == "choice"



# Generated at 2022-06-12 15:48:26.673614
# Unit test for method validate of class Array
def test_Array_validate():
    def get_args(obj):
        return obj
    class VarType:
        pass
    # Test with items
    items = None
    additional_items = False
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    items_arg = [
        VarType(),
    ]
    test_array_obj = Array(items=items_arg)
    test_array_obj.validate(get_args(items_arg))
    # Test with additional_items
    items = [
        VarType(),
    ]
    additional_items = None
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    additional_items_arg = VarType()

# Generated at 2022-06-12 15:48:29.858291
# Unit test for constructor of class Const
def test_Const():
    # Given
    const = Const(const=None, default="fruit")
    # When
    when1 = "fruit"
    when2 = "apple"
    # Then
    assert when1 == const.default
    assert None == const.const
    assert when2 == const.validate(when2)
    
    

# Generated at 2022-06-12 15:48:32.194116
# Unit test for method __or__ of class Field
def test_Field___or__():
    field = Field()
    assert field.__or__(field) is not None
    assert type(field.__or__(field)).__name__ == 'Union'


# Generated at 2022-06-12 15:48:41.775017
# Unit test for method validate of class Array
def test_Array_validate():
    array_validator = Array(exact_items=4, min_items=2, max_items=10, unique_items=True)
    values = [10, 20, 30, 40, 50, 60]
    result = array_validator.validate(values)
    assert result == values


# Generated at 2022-06-12 15:48:51.381794
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_data = [True, 1, 1.0, 1+0j, "True"]
    exp_data = [True, 1, 1.0, 1+0j, "True"]
    valid = []
    for idx, i in enumerate(test_data):
        try:
            assert Choice(choices=[True,1,1.0,1+0j,"True"]).validate(i) == exp_data[idx]
            valid.append(True)
        except:
            valid.append(False)
    for i in valid:
        assert i

# Generated at 2022-06-12 15:48:54.379305
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=["abc"])
    assert choice.validate_or_error("abc").error is None


# Generated at 2022-06-12 15:49:05.346090
# Unit test for method validate of class Union
def test_Union_validate():
  # Testing for Case 1
  array_of_fields = [Boolean(), Number(), Integer()]
  union_field = Union(array_of_fields)
  input_value = 3.14
  # Expected output: False
  expected_output = union_field.validate(input_value)
  # Actual output
  actual_output = 3.14
  assert expected_output == actual_output
  # Testing for Case 2
  array_of_fields1 = [Boolean(), Number(), Integer()]
  union_field1 = Union(array_of_fields1, allow_null = True)
  input_value1 = None
  # Expected output: False
  expected_output1 = union_field1.validate(input_value1)
  # Actual output
  actual_output1 = None