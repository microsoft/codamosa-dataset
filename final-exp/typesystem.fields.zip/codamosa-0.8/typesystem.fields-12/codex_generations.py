

# Generated at 2022-06-12 15:41:05.104191
# Unit test for method validate of class Choice

# Generated at 2022-06-12 15:41:13.109933
# Unit test for method __or__ of class Field
def test_Field___or__():
    # self is "send_email" and other is not "send_sms"
    from typesystem import types

    boolean = types.Boolean()
    null = types.Null()
    any_of = boolean | null

    assert any_of.validate(True)
    assert any_of.validate(False)
    assert any_of.validate(None)

    try:
        any_of.validate(None, strict=True)
    except ValidationError:
        pass
    else:
        assert False, "Null should not be valid in strict mode"

    try:
        any_of.validate(None, strict=True)
    except ValidationError:
        pass
    else:
        assert False, "None should not be valid in strict mode"


# Generated at 2022-06-12 15:41:24.279398
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union([Integer(), String()]).validate(1)==1
    assert Union([Integer(), String(), Null()]).validate(None) == None
    assert Union([Integer(), String()]).validate("string")=="string"
    assert Union([Integer(), String()]).validate(1.1)==1.1
    assert Union([Integer(), String()]).validate(True)==True
    assert Union([Integer(), String()]).validate([1,2,3])==[1,2,3]
    assert Union([Integer(), String()]).validate({"key": "value"}) == {"key": "value"}




# Generated at 2022-06-12 15:41:34.245238
# Unit test for method validate of class Choice
def test_Choice_validate():

    from dataclasses import dataclass, field
    from typing import List

    @dataclass
    class TestChoice:
        field1: int = field(metadata={'choices': [(1, 'One'), (2, 'Two')]})

    t = TestChoice()
    t.field1 = 1
    assert t.field1 == 1

    t.field1 = 2
    assert t.field1 == 2

    try:
        t.field1 = 3
    except ValidationError:
        assert True
    else:
        assert False

    try:
        t.field1 = ''
    except ValidationError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 15:41:40.640117
# Unit test for method __or__ of class Field
def test_Field___or__():
  from mv_typesystem.fields import Integer
  from mv_typesystem.fields import Number
  from mv_typesystem.fields import String
  from mv_typesystem.fields import Union
  assert (Integer(title='Integer', description='') | Number(title='Number',
    description='')).__class__ == Union

  assert (Integer(title='Integer', description='') | Number(title='Number',
    description='')).__class__ == Union

  assert (Integer(title='Integer', description='') | String(title='String',
    description='')).__class__ == Union
# Test
_test_Field___or__()



# Generated at 2022-06-12 15:41:50.014953
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=Integer()).serialize([1, 2, 3]) == [1, 2, 3]
    assert Array(items=Float()).serialize([1, 2, 3]) == [1.0, 2.0, 3.0]
    assert Array(items=Date()).serialize([date(2019, 7, 2)]) == ["2019-07-02"]
    assert Array(items=Time()).serialize([time(11, 22, 33)]) == ["11:22:33"]
    assert Array(items=DateTime()).serialize([datetime(2019, 7, 2, 11, 22, 33)]) == [
        "2019-07-02T11:22:33"
    ]
    assert Array(items=String()).serialize([1, 2, 3]) == ["1", "2", "3"]


# Generated at 2022-06-12 15:41:56.405069
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(min_items=1, max_items=1, items=Integer(min_value=1, max_value=10))
    assert schema.validate([1]) == [1]
    assert schema.validate(None) == None
    # Error: array is None
    try:
        schema.validate(None) == None
    except Exception as e:
        assert e.messages[0].code == "null"
    # Error: array object is not a list
    try:
        schema.validate(1) == None
    except Exception as e:
        assert e.messages[0].code == "type"
    # Error: array object is not a list of integer

# Generated at 2022-06-12 15:42:01.427843
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(
        properties = {
            "name": String(),
            "age": Integer()
        },
        additional_properties = False, #It means that when the validator is called, it is not possible to add a new property to the object, otherwise an error is returned.
        required = ["name", "age"]
    )

    # Use of the validator
    value = {"name":"John", "age": 25, "gender": "male"}
    try:
        data = schema.validate(value)
        print("Data is valid")
        print(data)
    except ValidationError as error:
        print("Error:")
        print(error.messages)

    # call to the method validate of class Object

# Generated at 2022-06-12 15:42:06.219409
# Unit test for method validate of class Number
def test_Number_validate():
    value = Number.validate(15, strict = False)
    assert value == 15
    value = Number.validate(15.3, strict = False)
    assert value == 15.3
    with pytest.raises(ValidationError):
        Number.validate(1000000000000000000000000000000000000000, strict = False)
    with pytest.raises(ValidationError):
        Number.validate(1000000000000000000000000000000000000000.15, strict = False)
    with pytest.raises(ValidationError):
        Number.validate("string_value", strict = False)
    with pytest.raises(ValidationError):
        Number.validate(True, strict = False)
    with pytest.raises(ValidationError):
        Number.validate(None, strict = False)

# Generated at 2022-06-12 15:42:08.816947
# Unit test for method validate of class Object
def test_Object_validate():
    result = Object(properties={'name': String()}).validate({"name": "Ham"})


# Generated at 2022-06-12 15:42:21.345388
# Unit test for method validate of class Union
def test_Union_validate():
    uni = Union(any_of=[Integer(), String()])
    uni.validate("hello")
    uni.validate(123)
    try:
        uni.validate({"hello": "world"})
        assert False
    except Union.validation_error:
        assert True



# Generated at 2022-06-12 15:42:25.589726
# Unit test for method serialize of class String
def test_String_serialize():
    print("\n------\nString test_String_serialize")
    a = String(title='string', allow_blank=True,format='date')
    value = a.serialize('2020-10-01')
    assert value == '2020-10-01'
    print(value)
    print("\n------\nString test_String_serialize End")

# Generated at 2022-06-12 15:42:30.979527
# Unit test for method serialize of class Array
def test_Array_serialize():
    schema = Array(items=Integer())
    assert schema.serialize([1, 2, 3]) == [1, 2, 3]
    assert schema.serialize((1, 2, 3)) == [1, 2, 3]

    schema = Array(items=Integer(), allow_null=True)
    assert schema.serialize(None) is None

# Generated at 2022-06-12 15:42:41.685463
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    def test_Boolean_validate_case(value, expected):
        b = Boolean()
        assert b.validate(value) == expected

    test_Boolean_validate_case(False, False)
    test_Boolean_validate_case(True, True)

    test_Boolean_validate_case("on", True)
    test_Boolean_validate_case("OFF", False)

    test_Boolean_validate_case(1, True)
    test_Boolean_validate_case(0, False)

    test_Boolean_validate_case("", False)
    test_Boolean_validate_case(" ", False)

    test_Boolean_validate_case("null", False)
    test_Boolean_validate_case("None", False)
    test_Boolean_

# Generated at 2022-06-12 15:42:44.083078
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        pass
    
    field1 = Field1()
    assert field1.__or__(Field1()) == Union([field1, Field1()])

# Generated at 2022-06-12 15:42:55.356768
# Unit test for method validate of class Number
def test_Number_validate():
    number1 = Number()
    assert number1.validate(3.14)==3.14
    assert number1.validate(3)==3
    assert number1.validate(3.00)==3
    assert number1.validate("3.00")==3
    assert number1.validate("3")==3
    number2 = Number(precision='0.01')
    assert number2.validate(3.145)==3.15
    assert number2.validate(3.1449)==3.14
    assert number2.validate("3.1449")==3.14
    assert number2.validate("3.1451")==3.15
    number3 = Number(minimum=2, maximum=5)
    assert number3.validate(2.1)==2.1

# Generated at 2022-06-12 15:43:02.828833
# Unit test for constructor of class String
def test_String():
    my_string = String(title="my string")
    assert my_string.title == "my string"
    assert my_string.description == ""
    assert not my_string.has_default()
    assert not my_string.allow_null
    assert not my_string.allow_blank
    assert my_string.trim_whitespace
    assert my_string.max_length is None
    assert my_string.min_length is None
    assert my_string.pattern is None
    assert my_string.format is None
    assert my_string.get_default_value() == None


# Generated at 2022-06-12 15:43:09.772102
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(3) == 3
    assert type(number.validate(3)) == int

    integer = Integer()
    assert integer.validate(3.0) == 3
    assert type(integer.validate(3.0)) == int

    float = Float()
    assert float.validate(3) == 3.0
    assert type(float.validate(3)) == float
    assert float.validate(3.1) == 3.1
    assert type(float.validate(3.1)) == float

    # Check if validate throws an error when the value
    # that is inputted is not of the correct type
    number = Number()
    with pytest.raises(ValidationError):
        number.validate("3")

    integer = Integer()

# Generated at 2022-06-12 15:43:10.403818
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    pass

# Generated at 2022-06-12 15:43:15.429534
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[(1,2),(2,3)])
    assert choice.validate(1) == 1
    assert choice.validate(2) == 2
    try:
        choice.validate(3)
        assert False
    except ValidationError:
        assert True
    assert choice.validate(None) == None



# Generated at 2022-06-12 15:43:43.029770
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    title = "test_get_default_value_by_default_method"
    description = "test_get_default_value_by_default_method"
    default = "test_get_default_value_by_default_method"
    text = "test_get_default_value_by_default_method"
    field = Field(
        title=title,
        description=description,
        default=lambda: default,
    )
    output = field.get_default_value()
    assert output == default



# Generated at 2022-06-12 15:43:54.163613
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String


    class TestField(Field):
        pass


    f1 = TestField()
    f2 = TestField()
    assert (f1 | f2).any_of == [f1, f2]

    f3 = TestField()
    assert (f1 | f2 | f3).any_of == [f1, f2, f3]
    assert (f1 | (f2 | f3)).any_of == [f1, f2, f3]

    u1 = Union([f1, f2])
    assert (u1 | f3).any_of == [f1, f2, f3]
    assert (f3 | u1).any_of == [f3, f1, f2]

    u2 = Union([f1, f2])

# Generated at 2022-06-12 15:43:56.135232
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {'key1': Integer(minimum=10)}
    test_data = {'key1': 12}
    ob = Object(properties=properties)
    ob.validate(test_data)
    @ob.validator
    def validate_object(value, **kwargs):
        return value

test_Object_validate()

# Generated at 2022-06-12 15:43:59.437195
# Unit test for method serialize of class Array
def test_Array_serialize():
    ary = Array(items=String(), max_items=5)
    assert ary.serialize([1, 2, '3', 4]) == ['1', '2', '3', '4']
    assert ary.serialize([1]) == ['1']
    assert ary.serialize(None) is None


# Generated at 2022-06-12 15:44:05.054142
# Unit test for method validate of class Choice
def test_Choice_validate():
    ch_object = Choice(**{'allow_null':True, 'choices':[(1,1),(2,2),(3,3)]})
    assert ch_object.validate(None) == None
    assert ch_object.validate(3) == 3
    assert ch_object.validate('3') == '3'
    assert ch_object.validate('1') == '1'
    assert ch_object.validate(1) == 1
    assert ch_object.validate(2) == 2
    assert ch_object.validate('') == ''

# Generated at 2022-06-12 15:44:11.206761
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(min_items=1, max_items=1)
    assert field.validate([1]) == [1]
    with pytest.raises(ValidationError, match="Must have 1 items."):
        field.validate([])
    with pytest.raises(ValidationError, match="Must have 1 items."):
        field.validate([1, 2])
        

# Generated at 2022-06-12 15:44:20.366599
# Unit test for method validate of class String
def test_String_validate():
    test_string = String(max_length=10, ensure_ascii=True, format='email')
    assert test_string.validate('12345@example.com') == '12345@example.com'
    assert test_string.validate('12345@exa,ple.com') == '12345@exa,ple.com'
    assert test_string.validate('12345@example.com', strict=True) == '12345@example.com'
    assert test_string.validate('12345@exa,ple.com', strict=True) == '12345@exa,ple.com'


# Generated at 2022-06-12 15:44:23.393732
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[('a','a'),('b','b')])
    assert c.validate('b') == 'b'
    assert c.validate('c') == 'c'

# Generated at 2022-06-12 15:44:28.169087
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(allow_null = True, choices = [1, 2, 3])
    print(choice.validate(1))
    print(choice.validate(5))
    print(choice.validate(None))
test_Choice_validate()


# Generated at 2022-06-12 15:44:31.436089
# Unit test for method validate of class String
def test_String_validate():

    # Assign
    s = String()
    v = 'String1'

    # Act
    result = s.validate(v)

    # Assert
    assert result == v


# Generated at 2022-06-12 15:44:46.113541
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['a', 'b'])
    assert choice.validate('a') == 'a'
    assert choice.validate(b'a') == 'a'
    assert choice.validate(1) == '1'
    try:
        choice.validate(u'a')
    except AssertionError:
        print ("Test not passed")
    try:
        choice.validate(2)
    except AssertionError:
        print ("Test not passed")
    try:
        choice.validate('')
    except AssertionError:
        print ("Test not passed")
# Testing method validate of Class Choice
test_Choice_validate()



# Generated at 2022-06-12 15:44:50.575679
# Unit test for method validate of class String
def test_String_validate():
    str = String(max_length=5,pattern="^[abc]+$")
    str.validate("abc")
    str.validate("ab")
    with pytest.raises(ValidationError):
        str.validate("bbc")
        str.validate("bbca")
        str.validate("bbcasfasd")

# Generated at 2022-06-12 15:44:52.735197
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.has_default() == False, "Failed to test method get_default_value() of class Field"

# Generated at 2022-06-12 15:45:01.531227
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """Test that get_default_value() returns a proper value for Field and its subclasses"""
    # Test for values of the parameter 'default' in the constructor
    # Field.__init__(self, default)
    # default is a string
    s=String(default="abc") 
    assert s.get_default_value() == "abc"

    # default is a number
    s=Integer(default=1) 
    assert s.get_default_value() == 1

    # default is a bool
    s=Boolean(default=True) 
    assert s.get_default_value() == True

    # default is None, and allow_null is False
    s=Boolean(default=None, allow_null=False) 
    assert s.get_default_value() == None

    # default is None, and allow_

# Generated at 2022-06-12 15:45:11.560306
# Unit test for constructor of class Array
def test_Array():
    array_f1 = Array(name="array_f1", additional_items=0, min_items=5, max_items=10, unique_items=True)
    assert array_f1.name=="array_f1"
    assert type(array_f1.additional_items)==int
    assert array_f1.additional_items==0
    assert type(array_f1.min_items)==int
    assert array_f1.min_items==5
    assert type(array_f1.max_items)==int
    assert array_f1.max_items==10
    assert type(array_f1.unique_items)==bool
    assert array_f1.unique_items==True


# Generated at 2022-06-12 15:45:13.642717
# Unit test for method validate of class Choice
def test_Choice_validate():
    d = Choice(choices=[1,2,3,4])
    assert d.validate(1) == 1


# Generated at 2022-06-12 15:45:15.672870
# Unit test for method validate of class String
def test_String_validate():
    String_obj = String(title='string_field',allow_blank=False,trim_whitespace=True,max_length=None,min_length=None,pattern=None,format=None)
    assert String_obj.validate('Hello World') == 'Hello World'

# Generated at 2022-06-12 15:45:28.017981
# Unit test for method validate of class Array
def test_Array_validate():
    # define json schema dictionary
    schema_dict = {
        "type": "array",
        "items": {
            "type": "array",
            "items": {
                "type": "string"
            }
        },
       "additionalItems": {"type": "string"},
       "minItems": 2,
       "maxItems": 3,
       "uniqueItems": True
    }
    # convert json schema dictionary to python object
    schema_Obj = json2obj(schema_dict)
    # convert json schema object to Field object
    field_Obj = convert_json_schema_to_Field(schema_Obj)
    # test
    value = [["a", "b", "c"], "i", "j"]
    validated = field_Obj.validate(value)
    print("validated: ", validated)


# Generated at 2022-06-12 15:45:37.084265
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        c = Choice(choices=['JD', 'Yukon'])
        assert c.validate("JD", strict=False) == "JD"
        assert c.validate("Yukon", strict=False) == "Yukon"
        assert c.validate("", strict=False) == None
        assert c.validate(None, strict=False) == None
        assert c.validate("QC", strict=False) == None
    except:
        assert False

# Generated at 2022-06-12 15:45:45.340859
# Unit test for method serialize of class Array
def test_Array_serialize():        
    import io
    import sys
    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        a = Array(items = [String()], unique_items = True)
        a.serialize(["", "", "", "", ""])
        output = out.getvalue()
        print(output)
        assert output == '[\n    "",\n    "",\n    "",\n    "",\n    ""\n]\n'
    finally:
        sys.stdout = saved_stdout



# Generated at 2022-06-12 15:45:55.299484
# Unit test for method validate of class Array
def test_Array_validate():
    # testcase: Array(items=[String()])
    _Array = Array(items=[String()])
    val = _Array.validate(["123", "456"])
    assert val == ["123", "456"], "Testcase failed!"



# Generated at 2022-06-12 15:46:01.396649
# Unit test for constructor of class Const
def test_Const():
    import json
    import pytest
    from .errors import ValidationError
    from .fields import Const
    from .validators import not_empty

    # Test for the initial case
    with pytest.raises(ValidationError, match=r".*Must be the value.*"):
        class User(Schema):
            group_id = Const(1)

        json_str = '{"group_id":2}'
        schema = User()
        schema.validate(json.loads(json_str))
    # Test for the specific case
    with pytest.raises(ValidationError, match=r".*Must be the value.*"):
        class User(Schema):
            group_id = Const(1)

        json_str = '{"group_id":1}'
        schema = User()
        schema.validate

# Generated at 2022-06-12 15:46:11.956581
# Unit test for constructor of class Const
def test_Const():
    # create an instance of Const
    const1 = Const(1)
    # run test
    assert isinstance(const1, Field)
    assert const1.const == 1
    assert const1.errors["const"] == "Must be the value '{const}'."
    assert const1.errors["only_null"] == "Must be null."
    # create an instance of Const with invalid input
    try:
        const2 = Const(allow_null=False)
        assert False
    except AssertionError:
        assert True
    # check the validation function
    assert const1.validate(1) == 1
    try:
        const1.validate(2)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-12 15:46:12.966973
# Unit test for constructor of class Const
def test_Const():
    c = Const(12)
    assert c.const == 12


# Generated at 2022-06-12 15:46:22.210718
# Unit test for method validate of class Array
def test_Array_validate():
    for arg in [
        ["a", "b", "c"],
        ["a", "b", "b"],
        ["a", "b", None],
        [],
        tuple([]),
        None
    ]:
        try:
            assert Array(unique_items=True).validate(arg) == arg
        except ValidationError:
            pass
    try:
        Array(unique_items=True).validate(["a", "b", "b"])
        assert False
    except ValidationError:
        pass
    try:
        Array(unique_items=True).validate(["a", "b", None])
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-12 15:46:25.936985
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title="title", description="description",
                  default=True, allow_null=True)
    field.get_default_value()
    assert True


# Generated at 2022-06-12 15:46:27.302711
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    assert obj.get_default_value() == None

# Generated at 2022-06-12 15:46:36.661073
# Unit test for method validate of class String
def test_String_validate():
    try:
        # Test 1
        # testing the regular input
        field = String(allow_blank=False, trim_whitespace=False, max_length=None, min_length=None, pattern=None, format=None, allow_null=False, title="", description="")
        field.validate("test")
        field.validate("  ")
        field.validate("")
        field.validate("\0")
        field.validate(None)
        print("The test has passed!")
    except:
        print("The test has failed")
    finally:
        print("")
        

# Generated at 2022-06-12 15:46:40.916666
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate(None) == None
    assert b.validate(True) == True

# Generated at 2022-06-12 15:46:52.592247
# Unit test for method __or__ of class Field
def test_Field___or__():
  # Make sure a Union is returned, and that
  # the Union contains both inputs
  def test(size):
    try:
      # Use the default value
      f1 = Str(min_length=size)
      # Use a custom value
      f2 = Str(min_length=size+1)
      f = f1 | f2
      assert isinstance(f, Union)
      assert f1 in f.any_of
      assert f2 in f.any_of
    except Exception as e:
      raise AssertionError(str(e))

  # Test all possible values of size
  for size in range(-10,10):
    test(size)
  for size in range(-100,100):
    test(size)
  for size in range(100,-100,-100):
    test(size)

# Generated at 2022-06-12 15:47:04.177048
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[1,2,3])
    field.validate(value = 3)

# Generated at 2022-06-12 15:47:16.697307
# Unit test for method validate of class String
def test_String_validate():
    assert String(default="").validate("") == ""
    assert String(default="").validate("abc") == "abc"
    assert String(default="").validate(None) == None
    assert String(default="", allow_null=True).validate(None) == None
    assert String(default="").validate(None, strict=True) == ""
    assert String(default="", allow_null=True).validate(None, strict=True) == None
    assert String(allow_blank=True).validate("") == ""
    assert String(allow_blank=True).validate(None, strict=True) == None
    assert String(allow_blank=True).validate(None) == ""
    assert String(allow_blank=True, allow_null=True).validate(None) == None


# Generated at 2022-06-12 15:47:26.338012
# Unit test for method validate of class Union
def test_Union_validate():
  u = Union(any_of=[
    Integer(maximum=3, minimum=1)
  ])

  assert u.validate(1) == 1
  with pytest.raises(ValidationError):
    u.validate(0)
  with pytest.raises(ValidationError):
    u.validate(100)

  u = Union(any_of=[
    Integer(maximum=3, minimum=1),
    String(enum=['foo', 'bar']),
    Constant('baz')
  ])

  assert u.validate(1) == 1
  assert u.validate('foo') == 'foo'
  assert u.validate('baz') == 'baz'
  with pytest.raises(ValidationError):
    u.validate(0)

# Generated at 2022-06-12 15:47:35.945845
# Unit test for method validate of class Object
def test_Object_validate():
    class MyField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return 'Text_'+value if isinstance(value, str) else super().validate(value, strict=False)


# Generated at 2022-06-12 15:47:38.473543
# Unit test for method validate of class Number
def test_Number_validate():
    import pytest
    assert Number.validate(1,0) == 1
    with pytest.raises(ValueError):
        Number.validate(1,"")

# Generated at 2022-06-12 15:47:45.036718
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test 1 (Ausführung von test_Field___or__)
    import typesystem
    any_of = []
    a = typesystem.String()
    b = typesystem.Integer()
    any_of.append(a)
    any_of.append(b)
    assert type(a.__or__(b)) == typesystem.Union

# Generated at 2022-06-12 15:47:57.810065
# Unit test for method __or__ of class Field
def test_Field___or__():
    def test_Field___or___1():
        # https://www.mypy-lang.org/api/mypy_extensions.html#mypy_extensions.Type
        from typing import Type
        from typesystem.fields import Field
        import typesystem.fields
        from typesystem.fields import Boolean, Integer, String
        from typesystem.fields import Union
        assert issubclass(typesystem.fields.Field, typesystem.fields.Field)
        assert issubclass(typesystem.fields.Boolean, typesystem.fields.Boolean)
        assert issubclass(typesystem.fields.Integer, typesystem.fields.Integer)
        assert issubclass(typesystem.fields.String, typesystem.fields.String)
        assert issubclass(typesystem.fields.Union, typesystem.fields.Union)

# Generated at 2022-06-12 15:48:03.893454
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_choices = [
    ('1', 'johndoe'),
    ('2', 'janedoe'),
    ('3', 'janepublic'),
    ('4', 'publicjohn'),
    ('5', 'johnnyenglish')
    ]
    test_choice = Choice(choices=test_choices)
    assert test_choice.validate(value=1) == 1
    assert test_choice.validate(value=2) == 2
    assert test_choice.validate(value=3) == 3
    assert test_choice.validate(value=4) == 4
    assert test_choice.validate(value=5) == 5





# Generated at 2022-06-12 15:48:10.550269
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	assert Field().get_default_value() is None
	assert Field(default=lambda: 3).get_default_value() == 3
	assert Field(default=3).get_default_value() == 3
	assert Field(allow_null=True).get_default_value() is None
	assert Field(allow_null=True, default=3).get_default_value() is None

# Generated at 2022-06-12 15:48:19.565741
# Unit test for method __or__ of class Field

# Generated at 2022-06-12 15:48:34.811051
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    class b(Boolean):
        def __init__(self):
            super().__init__(allow_null=True)
    
    b1 = b()
    print(b1.validate('true'))
    print(b1.validate('on'))
    print(b1.validate('1'))
    print(b1.validate('0'))
    print(b1.validate('false'))
    print(b1.validate('off'))
    print(b1.validate(1))
    print(b1.validate(0))
    print(b1.validate(''))
    print(b1.validate(True))
    print(b1.validate(False))
    print(b1.validate(None))

# Generated at 2022-06-12 15:48:35.904952
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(1235) == True

# Generated at 2022-06-12 15:48:40.187181
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    first_field = Field()
    assert first_field.get_default_value() is None

    second_field = Field(default='default')
    assert second_field.get_default_value() == 'default'


# Generated at 2022-06-12 15:48:49.905028
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    f = Field(default=1)
    assert f.get_default_value() == 1
    assert f.has_default() == True

    def foo():
        return 1

    f = Field(default=foo)
    assert f.get_default_value() == 1
    assert f.has_default() == True

    f = Field(default=None, allow_null=True)
    assert f.get_default_value() == None
    assert f.has_default() == True

    f = Field()
    assert f.has_default() == False
    assert f.get_default_value() == None



# Generated at 2022-06-12 15:48:54.661729
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.default = 1
    field = MyField()
    assert field.get_default_value() == 1



# Generated at 2022-06-12 15:48:59.215311
# Unit test for constructor of class Array
def test_Array():
    a = Array(unique_items=True)
    assert a.items == None
    assert a.additional_items == False
    assert a.min_items == None
    assert a.max_items == None
    assert a.unique_items == True


# Generated at 2022-06-12 15:49:06.497124
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["M", "F", "A", "U", "T", "O"])
    assert choice.validate_or_error("T").value == "T"
    assert choice.validate_or_error("X").error.code == "choice"
    assert choice.validate_or_error(None).error.code == "null"

    choice = Choice(allow_null=True, choices=["M", "F", "A", "U", "T", "O"])
    assert choice.validate_or_error(None).value is None

    




# Generated at 2022-06-12 15:49:15.772722
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    class MyBoolean(Boolean):
        null = True
    test1 = MyBoolean(allow_null = True)
    assert test1.validate(1) == True
    assert test1.validate(1.0) == True
    assert test1.validate('on') == True
    assert test1.validate(1.0) == True
    assert test1.validate('true') == True
    assert test1.validate('') == False
    assert test1.validate('null') == None
    assert test1.validate('none') == None
    assert test1.validate('on') == True
    assert test1.validate(2) == True
    assert test1.validate(False) == False
    assert test1.validate(None) == None