

# Generated at 2022-06-12 15:40:45.922191
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Array1(Array):
        def __init__(self) -> None:
            super().__init__(items=Integer())
    _ = Array1().serialize([1, 2, 3])

    class Array2(Array):
        def __init__(self) -> None:
            super().__init__(items=[String(), Date()])
    _ = Array2().serialize(["a", datetime.date(2020, 1, 1)])

    class Array3(Array):
        def __init__(self) -> None:
            super().__init__(items=String())
    _ = Array3().serialize(["a", "b"])

    class Array4(Array):
        def __init__(self) -> None:
            super().__init__(items=Date())

# Generated at 2022-06-12 15:40:52.171395
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=1)
    assert field.get_default_value() == 1
    def testf():
        return 2
    field = Field(default=testf)
    assert callable(field.get_default_value())
    assert field.get_default_value() == 2



# Generated at 2022-06-12 15:41:03.207884
# Unit test for method serialize of class Array
def test_Array_serialize():
    _list = [1,2,3]
    _list_expected_result = [1,2,3]
    _list_serialized = Field().serialize(_list)
    assert(_list_serialized == _list_expected_result)
    _list = [1,2,3]
    _list_expected_result = [1,2,3]
    _list_serialized = Field().serialize(_list)
    assert(_list_serialized == _list_expected_result)
    _list = [1,2,3]
    _list_expected_result = [1,2,3]
    _list_serialized = Field().serialize(_list)
    assert(_list_serialized == _list_expected_result)
    _list = [1,2,3]

# Generated at 2022-06-12 15:41:08.360139
# Unit test for method serialize of class Array
def test_Array_serialize():
    array = Array(String())
    obj = ["one", "two", "three"]
    value = array.serialize(obj)
    assert value == obj
    array = Array(Integer())
    obj = [1, 2, 3, 4]
    value = array.serialize(obj)
    assert value == [1, 2, 3, 4]


# Generated at 2022-06-12 15:41:16.825087
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format="date")
    assert s.serialize("2020-01-01") == "2020-01-01"
    assert s.serialize("2001-02-03") == "2001-02-03"
    assert s.serialize("2000-05-01") == "2000-05-01"
    s = String(format="time")
    assert s.serialize("00:00:00") == "00:00:00"
    assert s.serialize("23:59:59") == "23:59:59"
    assert s.serialize("12:34:56") == "12:34:56"
    s = String(format="datetime")
    assert s.serialize("2020-01-01T00:00:00") == "2020-01-01T00:00:00"

# Generated at 2022-06-12 15:41:19.377454
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default = lambda : 'Hello') 
    assert field.get_default_value() == 'Hello'


# Generated at 2022-06-12 15:41:29.210891
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate('hello') == 'hello'
    assert String(allow_null=False, allow_blank=True).validate('') == ''
    assert String(allow_null=False, allow_blank=True).validate('hello') == 'hello'
    assert String(allow_null=False, allow_blank=True, max_length=5).validate('hello') == 'hello'
    assert String(allow_null=False, allow_blank=True, max_length=2).validate('hello') == 'he'
    assert String(allow_null=False, allow_blank=True, min_length=2).validate('he') == 'he'
    assert String(allow_null=False, allow_blank=True, min_length=2, max_length=5).validate('hello') == 'hello'
   

# Generated at 2022-06-12 15:41:35.674191
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Field_default_test(Field):
        def __init__(self, default):
            super().__init__(default=default)
        
    test1 = Field_default_test("test1")
    assert test1.get_default_value()=="test1"
    test2 = Field_default_test("test2")
    assert test2.get_default_value()=="test2"
    
    
    
    
#Unit test for method validate of class Field

# Generated at 2022-06-12 15:41:39.658040
# Unit test for method validate of class Array
def test_Array_validate():
    value = []
    obj = Array()
    result = obj.validate(value)
    assert result == []

# Generated at 2022-06-12 15:41:45.637317
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class DemoField(Field):
        pass
    a = DemoField()
    assert a.get_default_value() == NO_DEFAULT
    default = NO_DEFAULT
    a = DemoField(default=default)
    assert a.get_default_value() == NO_DEFAULT
    default = 'TEST_VALUE'
    a = DemoField(default=default)
    assert a.get_default_value() == 'TEST_VALUE'


# Generated at 2022-06-12 15:42:31.962683
# Unit test for method validate of class Object
def test_Object_validate():
    value = None
    strict = "test"
    with pytest.raises(ValidationError) as err:
        Object().validate(value, strict=strict)
    assert str(err.value) == "null"
    assert isinstance(err.value, ValidationError)

    value = "test"
    strict = "test"
    with pytest.raises(ValidationError) as err:
        Object().validate(value, strict=strict)
    assert str(err.value) == "type"
    assert isinstance(err.value, ValidationError)

    value = []
    strict = "test"
    with pytest.raises(ValidationError) as err:
        Object().validate(value, strict=strict)
    assert str(err.value) == "type"
    assert isinstance

# Generated at 2022-06-12 15:42:32.665841
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None)
    

# Generated at 2022-06-12 15:42:35.370943
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    res=n.validate('a')
    assert res == None


# Generated at 2022-06-12 15:42:37.113601
# Unit test for constructor of class String
def test_String():
    assert String(title = "My cool string field") == "My cool string field"


# Generated at 2022-06-12 15:42:39.050235
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    a.validate(["c","d","e"], strict=False)
    a.validate(["c","d"], strict=False)
    a.validate(["c"], strict=False)
    a.validate([], strict=False)
    a.validate(["c"], strict=True)


# Generated at 2022-06-12 15:42:43.386069
# Unit test for method validate of class Choice
def test_Choice_validate():
    class MyStyle(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3
    class Color(Choice):
        choices = [
            ("red", "Red"),
            ("green", "Green"),
            ("blue", "Blue"),
            (1, "Red"),
            (MyStyle.GREEN, "Green"),
            (MyStyle.RED, "Red"),
        ]
        allow_null = True
        allow_blank = True
    assert Color().validate(None) == None
    assert Color().validate("") == None
    assert Color().validate(1) == "red"
    assert Color().validate("red") == "red"
    assert Color().validate(MyStyle.GREEN) == "green"
    assert Color().validate(MyStyle.RED) == "red"

# Generated at 2022-06-12 15:42:48.240513
# Unit test for method __or__ of class Field
def test_Field___or__():
    from .union import Union
    field = Field()
    result = field | field
    assert isinstance(result, Union)
    assert result.any_of == [field, field]


# Generated at 2022-06-12 15:42:57.984821
# Unit test for method validate of class Array
def test_Array_validate():
    
    
    # Test 1
    
    
    try:
        test_obj_1 = Array(
            items=String(),
        )
        test_input_1 = [
            "hello",
            "world",
            "foo",
            "bar",
        ]
        expected_return_1 = [
            "hello",
            "world",
            "foo",
            "bar",
        ]
        returned_1 = test_obj_1.validate(test_input_1)
        assert returned_1 == expected_return_1
    except:
        log_error()

    
    # Test 2
    
    

# Generated at 2022-06-12 15:43:01.741628
# Unit test for method validate of class String
def test_String_validate():
    test_object = String()
    assert test_object.validate(value="1234567890 abcd efgh ijkl mnop qrst uvw xyz") == "1234567890 abcd efgh ijkl mnop qrst uvw xyz"


# Generated at 2022-06-12 15:43:04.256623
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import Boolean, Integer, String
    field = Boolean() | Integer() | String()
    assert isinstance(field, Union)
    assert len(field.any_of) == 3



# Generated at 2022-06-12 15:43:27.541895
# Unit test for constructor of class Const
def test_Const():
    # Check for valid constructor of class Const
    const = Const("hello", allow_null=False, description="hello")
    assert const.const == "hello"
    assert const.allow_null == False
    assert const.description == "hello"


# Generated at 2022-06-12 15:43:36.390312
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number()
    a.validate(33)
    a.validate(33.0)
    a.validate(33.0, True)
    a.validate("33")
    a.validate("33.0")
    assert a.validate("33.0", True) is None
    a.validate(True)
    assert a.validate(None) is None

    b = Number(allow_null=True)
    b.validate(33)
    b.validate(33.0)
    b.validate(33.0, True)
    b.validate("33")
    b.validate("33.0")
    assert b.validate("33.0", True) is None
    b.validate(True)
    assert b.validate(None) is None

   

# Generated at 2022-06-12 15:43:46.476844
# Unit test for method validate of class Choice
def test_Choice_validate():
  test_choice = Choice(name="test_choice", choices=(("choice 1", "choice_1"), ("choice 2", "choice_2")))
  tuple_choices = test_choice.validate("choice 1")
  assert tuple_choices[0] == "choice 1"
  assert tuple_choices[1] == "choice_1"
  tuple_choices = test_choice.validate("choice_2")
  assert tuple_choices[0] == "choice 2"
  assert tuple_choices[1] == "choice_2"

test_Choice_validate()


# Generated at 2022-06-12 15:43:54.071439
# Unit test for method validate of class Choice
def test_Choice_validate():
    

    # Act
    instance = Choice(allow_null=False, allow_blank=False,required=True)
    # Assert
    assert instance.validate("apple") == "apple"
    assert instance.validate("0",strict=True) == "0"
    assert instance.validate("null",strict=True) == "null"
    assert instance.validate("",strict=True) == ""
    # Test accepts null object
    assert instance.validate(None) == None

# Generated at 2022-06-12 15:44:02.538856
# Unit test for method validate of class String
def test_String_validate():
    testTranslator = String(allow_blank=True,trim_whitespace=True,max_length=None,min_length=None,pattern=None)
    assert testTranslator.validate("123") == "123"
    assert testTranslator.validate(" ") == " "
    assert testTranslator.validate("") == ""
    assert testTranslator.validate(123) == "123"
    assert testTranslator.validate(12.3) == "12.3"
    assert testTranslator.validate(None) == None


# Generated at 2022-06-12 15:44:05.474145
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice(choices=["test"])
    value = choices.validate("test")
    assert value == "test"

# Generated at 2022-06-12 15:44:16.936846
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
    Union should be able to take either a field or a list of fields
    """
    from .fields import String, Number
    from .schema import Schema
    from .uniqueness import Unique
    from .typesystem import SchemaError
    from .exceptions import ValidationError
    from .mixins import EnumMixin, FormatMixin

    s = String(title="Name", max_length=3) | Number(title="Age", minimum=0, maximum=150)
    assert isinstance(s, Union)
    assert str(s) == "(String | Number)"

    # Union with empty list
    with pytest.raises(SchemaError):
        s = String(title="Name", max_length=3) | Union(any_of=[])
        print(s)

    # Union with list and field
    s = String

# Generated at 2022-06-12 15:44:26.803105
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(allow_null=True, properties={"name": String(allow_null=False, default="Ran"), "id": String(allow_null=False)}, required=["id"])
    assert obj.validate({'id': '1234', 'name': None}) == {'id': '1234', 'name': 'Ran'}
    assert obj.validate({'id': '1234'}) == {'id': '1234', 'name': 'Ran'}
    assert obj.validate({'id': None, 'name': 'Ran'}) == {'id': None, 'name': 'Ran'}
    assert obj.validate(None) == None
    pytest.raises(ValidationError, obj.validate, '{id: 1234, name: Ran}')

# Generated at 2022-06-12 15:44:31.391171
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    my_title = "title"
    my_default = 5
    my_field = Field(title = my_title, 
                     description = "", 
                     default = my_default, 
                     allow_null = False)
    assert my_field.get_default_value() == my_default


# Generated at 2022-06-12 15:44:39.685218
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for case None
    schema = Array(allow_null=False)

    result = schema.validate(None)
    assert result == "ValidationError at <Array> with [null]"

    # Test for case []
    schema = Array(allow_null=False)

    result = schema.validate([])
    assert result == []

    # Test for case [1]
    schema = Array(allow_null=False)

    result = schema.validate([1])
    assert result == [1]



# Generated at 2022-06-12 15:45:03.394302
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choiceobj = Choice(Choices = ["Logging","Alert"])
    val = Choiceobj.validate("Logging")
    assert val == "Logging"
    val = Choiceobj.validate("Alert")
    assert val == "Alert" 
    try:
        Choiceobj = Choice(Choices = ["Logging","Alert"])
        val = Choiceobj.validate(None)
    except ValidationError as Error:
        assert Error.args[0] == 'May not be null.'


    try:
        Choiceobj = Choice(Choices = ["Logging","Alert"])
        val = Choiceobj.validate("Monitoring")
    except ValidationError as Error:
        assert Error.args[0] == 'Not a valid choice.'

    

# Generated at 2022-06-12 15:45:11.801387
# Unit test for method validate of class Choice
def test_Choice_validate():
    def test_pos_1():
        """
        Test case with allow_null = False
        """
        class Model(Serializer):
            choice = Choice(
                choices=(("a", 1), ("b", 2), ("c", 3)), allow_null=False
            )
        serializer = Model()
        serializer.load("choice", "a")
        assert serializer.data["choice"] == "a"
        try:
            serializer.load("choice", "d")
        except ValidationError as err:
            assert (
                err.messages == {'choice': ['Not a valid choice.']}
            )
    def test_pos_2():
        """
        Test case with allow_null = True
        """

# Generated at 2022-06-12 15:45:16.477750
# Unit test for method validate of class Object
def test_Object_validate():
    pass
    '''
    p = {
        'title': 'Product',
        'type': 'object',
        'properties': {
            'code': {'type': 'string'},
            'name': {'type': 'string'},
        },
        'required': ['code', 'name'],

    }
    s = Object(**p)

    v = {'code': 'CC', 'name': 'Computer'}
    s.validate(v)
    '''



# Generated at 2022-06-12 15:45:22.152299
# Unit test for method validate of class Choice
def test_Choice_validate():
    actual = Choice(
        choices=[
            ("", "Select a service"),
            ("bus", "Bus"),
            ("metro", "Metro"),
            ("rail", "Rail"),
        ]
    ).validate(value="metro")
    assert actual=="metro"


# Generated at 2022-06-12 15:45:33.086067
# Unit test for method validate of class Array
def test_Array_validate():
    value_1 = [1, 2, 3]
    value_2 = ["1", "2", "3"]
    value_3 = [1, 2, 3, 4]
    value_4 = [1, 2, 3.5, 4]
    value_5 = [3, 2, 1]
    validator_1 = Array(items = None)
    validator_2 = Array(items = Integer(min_value = 1, max_value = 3))
    validator_3 = Array(items = String(min_length = 1, max_length = 3))
    validator_4 = Array(items = Integer(min_value = 1, max_value = 3), min_items = 4)

# Generated at 2022-06-12 15:45:44.589678
# Unit test for method validate of class Boolean

# Generated at 2022-06-12 15:45:48.509869
# Unit test for method validate of class Choice
def test_Choice_validate():
    F = Choice(choices = [('1','b'),('2','a'),('','kek')])
    assert F.validate(1) == 'b'
    F = Choice(choices = ['1','2','kek'])
    assert F.validate('2') == '2'
    F = Choice(choices = ['1', '2'])
    assert F.validate('3') == None
    F = Choice(choices = ['1', '2', ''])
    assert F.validate(3) == None



# Generated at 2022-06-12 15:45:56.691505
# Unit test for method __or__ of class Field
def test_Field___or__():
    import pytest
    from hypothesis import given
    from hypothesis.strategies import integers, lists
    from typesystem.field import Field, StringField, IntegerField

    class StringField1(StringField):
        pass

    @given(lists(integers()))
    def test_Field___or__(list_of_integers):
        field1 = IntegerField(default=list_of_integers[0])
        field2 = IntegerField(default=list_of_integers[1])
        field3 = StringField(default=str(list_of_integers[2]))

        class StringField4(StringField1):
            pass

        str_field = StringField1(default=str(list_of_integers[3]))

# Generated at 2022-06-12 15:46:03.669626
# Unit test for method validate of class Object
def test_Object_validate():
    v = Object(description="description", example="example", nullable=False,
            properties={'key1':String(description="description", example="example", nullable=False)},
            min_properties=1, max_properties=10, required=['key1'])
    assert v.validate({"key1":"string"}) == {"key1":"string"}


# Generated at 2022-06-12 15:46:13.179528
# Unit test for method validate of class Choice
def test_Choice_validate():
    field_choice = Choice(
        choices=[
        ("a", "A"), ("b", "B"), ("c", "C"), ("d", "D"), ("e", "E")
        ],
        description="Testing choice field",
        allow_null=True,
        label="Choice Field",
        max_length=100,
        title="Choice",
    )
    assert field_choice.validate("a") == "a"
    assert field_choice.validate("b") == "b"
    assert field_choice.validate("c") == "c"
    assert field_choice.validate("d") == "d"
    assert field_choice.validate("e") == "e"
    assert field_choice.validate(None) == None
    assert field_choice.validate(()) is None
    assert field_choice

# Generated at 2022-06-12 15:46:27.203276
# Unit test for method validate of class Union
def test_Union_validate():
    def validate(validation, instance, schema = None, *args, **kwargs):
        return validation(
            instance, schema=schema, *args, **kwargs
        )
    import json
    from typing import Union
    from datetime import datetime
    from dateutil.parser import parse
    from pydantic import BaseModel
    from pydantic.validators import validator

    class Model(BaseModel):
        class Config:
            validate_all = True
            allow_mutation = False

        dt: Union[datetime, str]

        @validator("dt", pre=True)
        def process_dt(cls, v):
            return parse(v)

    # no validation performed
    x = Model(dt="2019-06-04T12:45:26Z")

# Generated at 2022-06-12 15:46:29.306349
# Unit test for method __or__ of class Field
def test_Field___or__():
  from typesystem import String

  obj = String()
  assert type(obj) == String
  assert not isinstance(obj, Union)


# Generated at 2022-06-12 15:46:40.165012
# Unit test for method validate of class Object
def test_Object_validate():
    sample_object = {"a": 1, "b": "abc"}
    correct_result = {"a": 1, "b": "abc"}
    field = Object()
    result = field.validate(sample_object)
    assert result == correct_result
    # Test with error message
    sample_object = {"a": 1, "b": "abc", "c": 12.34}
    error_message = "Invalid property name."
    with pytest.raises(ValidationError, match=error_message):
        field.validate(sample_object)
    # Test with required field
    field = Object(required=["a", "b"])
    error_message = "This field is required."

# Generated at 2022-06-12 15:46:42.610175
# Unit test for method validate of class String
def test_String_validate():
    s = String(allow_blank=True, max_length=10, min_length=1)
    assert s.validate('ad') == 'ad'


# Generated at 2022-06-12 15:46:43.262837
# Unit test for method validate of class Array
def test_Array_validate():

    assert True == True

# Generated at 2022-06-12 15:46:46.716914
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	import typesystem
	f = typesystem.Field(default=42)
	assert f.get_default_value() == 42



# Generated at 2022-06-12 15:46:47.755980
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(1, allow_null=False)
    Const(1)



# Generated at 2022-06-12 15:46:48.637195
# Unit test for constructor of class Const
def test_Const():
    test = Const(const="hi")
    assert test.const == "hi"


# Generated at 2022-06-12 15:46:57.606145
# Unit test for constructor of class String
def test_String():
    field1 = String(title="first", description="first field", default="first field", allow_null=True)
    assert field1.title =="first"
    assert field1.description == "first field"
    assert field1.default == "first field"
    assert field1.allow_null == True
    field1_1 = String(title="first", description="first field", default="first field", allow_null=False)
    assert field1_1.allow_null == False
    field2 = String(title="second", description="second field", allow_blank=True)
    assert field2.title == "second"
    assert field2.description == "second field"
    assert field2.allow_blank == True
    field3 = String(title="third", description="third field", trim_whitespace=True)
    assert field3

# Generated at 2022-06-12 15:46:58.991769
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
   assert Field().get_default_value()==None
   assert Field(default=1).get_default_value()==1


# Generated at 2022-06-12 15:47:09.291555
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title='name',description='description',default=5)
    #print(field)
    assert field.get_default_value() == 5


# Generated at 2022-06-12 15:47:17.755779
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(properties={"b": String()}, additional_properties=True) 
    d = {"a": 1, "b": "a"}
    assert field.validate(d) == {"a": 1, "b": "a"}
    d = {"a": 1, "b": "a", 1.0: "b"}
    assert field.validate(d) == {"a": 1, "b": "a", 1.0: "b"}
    assert field.serialize(d) == {"a": 1, "b": "a", 1.0: "b"}



# Generated at 2022-06-12 15:47:26.895000
# Unit test for method validate of class Choice
def test_Choice_validate():
    value = "test"
    c = Choice(choices=["test1","test2","test3"])
    assert c.validate(value, strict=True)==value
    c1 = Choice(choices=["test1","test2","test3"])
    assert c1.validate(value, strict=False)==value
    assert c1.validate(None) == None
    assert c1.validate(None, strict=True) == None
    c2 = Choice(choices=["test1","test2","test3"], allow_null=True)
    assert c2.validate(None) == None
    assert c2.validate(None, strict=True) == None
    c3 = Choice(choices=["test1","test2","test3"], allow_null=False)

# Generated at 2022-06-12 15:47:33.034019
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=Integer())
    assert field.serialize([1, 2, 3]) == [1, 2, 3]
    assert field.serialize(None) == None

    field = Array(items=[Integer(), Integer(), Integer()])
    assert field.serialize([1, 2, 3]) == [1, 2, 3]
    assert field.serialize([1, 2, 3, 4, 5]) == [1, 2, 3]
    assert field.serialize(None) == None
    field = Array(items=None)
    assert field.serialize([1, 2, 3]) == [1, 2, 3]
    assert field.serialize(None) == None

    field = Array(items = [Integer(max_value=99), Integer(), Integer(max_value=99)])

# Generated at 2022-06-12 15:47:41.338664
# Unit test for method validate of class Number
def test_Number_validate():
    """
    Unit test for method Number.validate
    """
    # Valid cases
    int_val = 123
    str_val = "123"
    float_val = 123.45
    decimal_val = decimal.Decimal("123.45")
    num1 = Number()
    num1.validate(int_val)
    num1.validate(str_val)
    num1.validate(float_val)
    num1.validate(decimal_val)

    # Invalid cases
    bool_val = True
    num1.validate(bool_val)


# Generated at 2022-06-12 15:47:53.775733
# Unit test for method validate of class Array
def test_Array_validate():
    # Test Array() validates list of ints
    schema = Array(items=Integer())
    check = schema.validate([0,1,2,3])
    assert check == [0,1,2,3]
    # Test Array() validates list of ints, floats, strings
    schema = Array(additionalItems=True)
    check = schema.validate([0,1,2.0,'3'])
    assert check == [0,1,2.0,'3']
    # Test Array() raises error on float
    schema = Array(items=Integer())
    error = None
    try:
        schema.validate([0.0,1,2,3])
    except ValidationError as err:
        error = err
    assert error.messages[0].code == 'type'

# Generated at 2022-06-12 15:48:03.299699
# Unit test for method __or__ of class Field
def test_Field___or__():
    from . import Number, String
    field1 = Number(minimum=10)
    field2 = String(max_length=100)
    field3 = Number(maximum=10)
    field1_or_field2 = field1.__or__(field2)
    print(field1_or_field2)
    assert field1_or_field2
    field1_or_field2_or_field3 = field1_or_field2.__or__(field3)

    import json
    import jsonschema
    validate_json = jsonschema.Draft7Validator(json.loads(field1_or_field2_or_field3.to_json()))
    assert validate_json.is_valid(json.loads('{"type": "string", "maxLength": 100}'))

# Generated at 2022-06-12 15:48:15.384214
# Unit test for method validate of class Union
def test_Union_validate():
    class BaseError(Exception):
        code : str
    
    class ValidationError(BaseError):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.messages()
    
    class ChildError(BaseError):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.messages()
    
    class Field:
        def __init__(self, allow_null):
            self.allow_null = allow_null
        def validation_error(self, code):
            return ValidationError(code)
        def validate_or_error(self, value, strict):
            validated = value
            error = None
            return validated, error
        

# Generated at 2022-06-12 15:48:20.033123
# Unit test for method validate of class Union
def test_Union_validate():
    any_of_list = [Number(), String()]
    u1 = Union(any_of_list)
    print(u1.validate(10))
    print(u1.validate("abc"))
    print(u1.validate(None))
    # print(u1.validate(list()))

# Generated at 2022-06-12 15:48:23.814971
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [("1","1"),("2","2")])
    assert choice.validate("2") == "2"


# Generated at 2022-06-12 15:48:34.730058
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(const = "abc", allow_null = True)



# Generated at 2022-06-12 15:48:40.899225
# Unit test for method validate of class Union
def test_Union_validate():
    def test_1():
        class UnionChild1(Field):
            def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
                if isinstance(value, str):
                    return value
                raise ValidationError(
                    messages=[
                        Message(text="not a string", code="type", field_name="field")
                    ]
                )
        class UnionChild2(Field):
            def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
                if isinstance(value, int):
                    return value
                raise ValidationError(
                    messages=[
                        Message(text="not an integer", code="type", field_name="field")
                    ]
                )

# Generated at 2022-06-12 15:48:54.236893
# Unit test for method validate of class Object
def test_Object_validate():
    # initialize a field
    testfield = Object(properties={
        'intfield': Integer(minimum=1),
        'stringfield': String(min_length=5),
        'booleanfield': Boolean(),
        'numberfield': Number()
        },
        property_names=String(min_length=2),
        required=['intfield', 'stringfield', 'booleanfield', 'numberfield']
        )
    # start unit test
    test_dic = {
        'intfield': 1,
        'stringfield': 'foobar',
        'booleanfield': True,
        'numberfield': 3.14
    }
    assert testfield.validate(test_dic, strict=True) == test_dic

# Generated at 2022-06-12 15:49:00.102511
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[('1', '1'), ('value', 'value')])
    assert field.validate(1) == 1
    assert field.validate('1') == '1'
    assert field.validate('value') == 'value'
    try:
        field.validate('random_value')
        assert False
    except:
        assert True



# Generated at 2022-06-12 15:49:08.252811
# Unit test for method validate of class Number
def test_Number_validate():
    with pytest.raises(ValidationError):
        Number().validate(None)
    with pytest.raises(ValidationError):
        Number().validate(False)
    with pytest.raises(ValidationError):
        Number().validate(1.1)
    with pytest.raises(ValidationError):
        Number().validate(2.2)
    with pytest.raises(ValidationError):
        Number().validate(-3.3)
    with pytest.raises(ValidationError):
        Number().validate(-4.4)
    with pytest.raises(ValidationError):
        Number().validate(5.5)
    with pytest.raises(ValidationError):
        Number().validate(6.6)