

# Generated at 2022-06-12 15:41:34.233948
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    case1 = Field()
    assert case1.get_default_value() is None
    case2 = Field(default=1)
    assert case2.get_default_value() == 1
    case3 = Field(default=2)
    assert case3.get_default_value() == 2
    case4 = Field(default="hello")
    assert case4.get_default_value() == "hello"
    case5 = Field(default={"name": "dog"})
    assert case5.get_default_value() == {"name": "dog"}
    case6 = Field(default=["name", "age"])
    assert case6.get_default_value() == ["name", "age"]

    def test_func1():
        return 1
    case7 = Field(default=test_func1)

# Generated at 2022-06-12 15:41:41.729831
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    
    r = field.validate(True)
    assert r == True
    r = field.validate(False)
    assert r == False
    r = field.validate(10)
    assert r == 10
    r = field.validate(10.1)
    assert r == 10.1
    r = field.validate("true")
    assert r == True
    r = field.validate("false")
    assert r == False
    r = field.validate("on")
    assert r == True
    r = field.validate("off")
    assert r == False
    r = field.validate("1")
    assert r == True
    r = field.validate("0")
    assert r == False
    r = field.validate(1)
    assert r == 1


# Generated at 2022-06-12 15:41:43.197949
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    assert (Integer() | String())



# Generated at 2022-06-12 15:41:45.953564
# Unit test for method validate of class Number
def test_Number_validate():
    #test case 1
    num_instance = Number(maximum=10)
    assert num_instance.validate(11) == None
    #test case 2
    test_num = int(input("Enter an integer: "))
    assert num_instance.validate(test_num) != None
    #test case 3
    num_instance = Number(allow_null=True)
    assert num_instance.validate(None) == None


# Generated at 2022-06-12 15:41:47.679986
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for the method validate of Array class
    items = Array(items = String())
    print(items.validate(value = ['1', '2']))
    print(items.validate(value = '1'))


# Generated at 2022-06-12 15:41:50.087824
# Unit test for method validate of class Array
def test_Array_validate():
    type_test = Array(items=str)
    type_test.validate([1])
    assert "Array  of str Fail" == "Array  of str Fail"



# Generated at 2022-06-12 15:42:02.020313
# Unit test for method validate of class Array
def test_Array_validate():
    assert Array(items=[Field()]).validate(["text"], strict=True) == ["text"]
    assert Array(items=[Field()]).validate(["text"], strict=False) == ["text"]

    # Test that it fails with a non nullable value
    with pytest.raises(ValidationError):
        Array(items=[Field()]).validate(None, strict=True)

    # Test that it fails with a non nullable value
    with pytest.raises(ValidationError):
        Array(items=[Field()]).validate(None, strict=False)

    # Test that it fails with a non nullable value
    with pytest.raises(ValidationError):
        Array(items=[Field()]).validate(None, strict=False)

    # Test that it fails with a non nullable value

# Generated at 2022-06-12 15:42:07.709270
# Unit test for constructor of class Choice
def test_Choice():
    #Test case 1
    choice = Choice(choices=["M","F"])

    #Test case 2
    choice = Choice(choices=["M","F","U"])
    #Test case 3
    choice = Choice(choices=["M","F","U"])
    choice.validate("M")


# Generated at 2022-06-12 15:42:14.183713
# Unit test for constructor of class Array
def test_Array():
    items = [Text(), URL(), URL()]
    array = Array(items, strict=True)
    assert array.items == items
    assert array.additional_items is False
    assert array.min_items == 3
    assert array.max_items == 3
    assert array.unique_items is False

# Generated at 2022-06-12 15:42:23.995107
# Unit test for method validate of class Array
def test_Array_validate():
    """
    Test the validate method of class Array.
    """
    Case = collections.namedtuple(
        "Case",
        [
            "data",
            "error",
            "validated",
        ],
    )
    cases = [
        Case(
            data=None,
            error=None,
            validated=None,
        ),
        Case(
            data=[],
            error=None,
            validated=[],
        ),
        Case(
            data=[1],
            error=None,
            validated=[1],
        ),
    ]

# Generated at 2022-06-12 15:42:38.361528
# Unit test for method serialize of class String
def test_String_serialize():
    string_object = String(format = 'time')
    a = string_object.serialize(datetime.datetime.now().time())
    assert(isinstance(a, str))


# Generated at 2022-06-12 15:42:41.726249
# Unit test for method validate of class Array
def test_Array_validate():
    class TestArray(Array):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            print("ok")
            return value
    test = TestArray()
    print(test.validate([1, 2, 3]))

# Generated at 2022-06-12 15:42:42.990810
# Unit test for constructor of class Const
def test_Const():
    Const(const=1)
    Const(const=None)
    try:
        Const(1)
    except ValueError:
        pass
    


# Generated at 2022-06-12 15:42:51.665544
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [(1,2),(3,4)], allow_null = True, required = True)
    print(choice.validate(1))
    print(choice.validate(3))
    print(choice.validate(None))
    try:
        print(choice.validate(5))
    except Exception as e:
        print(f"{e.__class__.__name__}:{e}")


########################################################################################################################



# Generated at 2022-06-12 15:43:01.528090
# Unit test for method validate of class Choice
def test_Choice_validate():
    from swpt_creditors.models import Choice
    my_choices = [(1, "choice 1"), (2, "choice 2"), (3, "choice 3")]
    my_choice = Choice(choices=my_choices, allow_null=True)
    assert my_choice.validate(value=None, strict=True) is None
    assert my_choice.validate(value=None, strict=False) is None
    assert my_choice.validate(value=1, strict=True) == 1
    assert my_choice.validate(value=1, strict=False) == 1
    try:
        my_choice.validate(value=0, strict=True)
    except ValidationError as e:
        assert e.code == "choice"
    else:
        assert False

# Generated at 2022-06-12 15:43:12.645416
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object()
    assert field.validate({}) == {}
    assert field.validate({'a': 1}) == {'a': 1}
    assert field.validate({'a':1,'b':2}) == {'a':1,'b':2}
    assert field.validate({'a':[1,2]}) == {'a':[1,2]}
    assert field.validate({'a':[1,2,{'b':3}]}) == {'a':[1,2,{'b':3}]}
    assert field.validate({'a':[1,2,{'b':{'c':4}}]}) == {'a':[1,2,{'b':{'c':4}}]}

# Generated at 2022-06-12 15:43:22.490899
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=None)
    assert field.serialize(None) == None
    assert field.serialize([]) == []
    assert field.serialize([1, 2, 1]) == [1, 2, 1]
    assert field.serialize([1, '2', [3, 1, 4]]) == [1, '2', [3, 1, 4]]

    field = Array(items='any')
    assert field.serialize(None) == None
    assert field.serialize([]) == []
    assert field.serialize([1, 2, 1]) == [1, 2, 1]
    assert field.serialize([1, '2', [3, 1, 4]]) == [1, '2', [3, 1, 4]]

    field = Array(items=Any)
    assert field.serialize(None)

# Generated at 2022-06-12 15:43:26.285783
# Unit test for method validate of class Array
def test_Array_validate():
    print("Test Array validate method:")
    array = Array(items=[Int()])
    print(array)
    print(array.validate_or_error([1,2,3,4]))



# Unit tests for class Boolean

# Generated at 2022-06-12 15:43:29.050051
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_Field=Field(title='title', description='des', default=42, allow_null=False)
    assert test_Field.get_default_value() == 42


# Generated at 2022-06-12 15:43:37.454785
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[(1,2),(3,4)]).validate(1) == 1
    try:
        assert Choice(choices=[(1,2),(3,4)]).validate(5) == 1
    except AssertionError:
        print("The value is not in the choices, thus the assertion is correct")
    assert Choice(choices=[(1,2),(3,4)]).validate(None) == None
    assert Choice(choices=[(1,2),(3,4)]).validate(1,strict=True) == 1

# Generated at 2022-06-12 15:43:53.737023
# Unit test for method validate of class Object
def test_Object_validate():
    o = Object(properties={"name": Text()}, required=["name"])
    o.validate({"name": "hello "}, strict=True)
    assert o.serialize({"name": "hello"}) == {"name": "hello"}
    with pytest.raises(ValidationError):
        o.validate({"name": "hello"}, strict=True)
    o.validate({"name": "hello"}, strict=False)
    with pytest.raises(ValidationError):
        o.validate({"name": 1}, strict=True)
    with pytest.raises(ValidationError):
        o.validate(1, strict=True)
    with pytest.raises(ValidationError):
        o.validate({"name": "hello"}, strict=False)

# Generated at 2022-06-12 15:44:04.179462
# Unit test for method validate of class Array
def test_Array_validate():
    items = [
        Field(default="foo", allow_null=True),
        Field(default="bar", allow_null=True),
        Field(default="baz", allow_null=True),
    ]
    field = Array(items=items)
    assert field.validate([]) == ["foo", "bar", "baz"]

    assert field.validate(["foo"]) == ["foo", "bar", "baz"]
    assert field.validate(["foo", "bar"]) == ["foo", "bar", "baz"]
    assert field.validate(["foo", "bar", "baz"]) == ["foo", "bar", "baz"]

    field = Array(items=items, additional_items=True)

# Generated at 2022-06-12 15:44:15.803978
# Unit test for method validate of class Number
def test_Number_validate():
    field = Number()
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0

    field = Number(precision="1e-1")
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.11) == 1.1
    assert field.validate(1.111) == 1.1
    assert field.validate(1.211) == 1.2

    field = Number(minimum=0, maximum=255)
    assert field.validate(0) == 0
    assert field.validate(255) == 255

# Generated at 2022-06-12 15:44:19.028774
# Unit test for method validate of class Choice
def test_Choice_validate():
    nickname = Choice(
        choices = [
            ('nickname1', 'nickname1'),
            ('nickname2', 'nickname2'),
            ('nickname3', 'nickname3'),
        ],
        required = True)
    result = nickname.validate('nickname4')
    assert result=='choice'

# Test method validate_or_error of class Field

# Generated at 2022-06-12 15:44:23.393839
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert isinstance((Field() | Field()), Union)
    assert isinstance((Field(title="x") | Field()), Union)
    assert isinstance((Field() | Field(title="x")), Union)
test_Field___or__()

    # Unit test for method __or__ of class Field

# Generated at 2022-06-12 15:44:26.512835
# Unit test for method validate of class Number
def test_Number_validate():
    num1 = Number()
    value = 2
    result = num1.validate(value)
    assert result == 2


# Generated at 2022-06-12 15:44:33.256639
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	drive_through_field = Field(default=[]) # template Field
	assert drive_through_field.get_default_value() == [] # test get_default_value
	drive_through_field.default = [3, 4] # setting default of drive_through_field
	assert drive_through_field.get_default_value() == [3, 4] # testing get_default_value
	assert type(drive_through_field.get_default_value()) == list # testing type of return value


# Generated at 2022-06-12 15:44:39.461533
# Unit test for constructor of class Const
def test_Const():
    # an instance of Const with None value
    n = Const(None, allow_null=True)
    # a simple instance of Const
    const = Const("foo")
    assert const.const == "foo"
    # const field can not accept null values by default
    with pytest.raises(ValidationError):
        const.validate(None)
    # const field with fields set to None
    assert n.validate(None) == None


# Generated at 2022-06-12 15:44:47.297972
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_data = [
        ("", ["", "", ""], None),
        ("", ["1", "2", "3"], "Choice"),
        ("", ["", "", ""], "Choice"),
        ("1", ["1", "", ""], "Choice"),
        ("1", ["1", "2", "3"], None),
        ("2", ["", "2", "3"], None),
        ("2", ["1", "2", "3"], None),
        ("3", ["", "", "3"], None),
        ("3", ["1", "2", "3"], None),
        (None, ["", "", ""], "Null"),
        (None, ["1", "2", "3"], None),
    ]
    for value, choices, error in test_data:
        test_choice = Choice(choices=choices)

# Generated at 2022-06-12 15:44:50.157230
# Unit test for method __or__ of class Field
def test_Field___or__():
    obj1 = Field()
    obj2 = Field()
    assert isinstance(obj1 | obj2, Union)

# Generated at 2022-06-12 15:45:16.305016
# Unit test for method validate of class Number
def test_Number_validate():
    # Testing if class Number raises the correct error if value is a String
        with pytest.raises(ValidationError):
            Number().validate_or_error("invalid")

    # Testing if class Number raises the correct error if value is a Boolean
        with pytest.raises(ValidationError):
            Number().validate_or_error(True)

    # Testing if class Number raises the correct error if value is a float
        with pytest.raises(ValidationError):
            Number().validate_or_error(4.75)

    # Testing if class Number raises the correct error if value is a decimal
        with pytest.raises(ValidationError):
            Number().validate_or_error(5.5)

    # Testing if class Number raises the correct error if value is infinity

# Generated at 2022-06-12 15:45:21.206220
# Unit test for method __or__ of class Field
def test_Field___or__():
    field = Field() | Field()
    assert isinstance(field, Union)
    assert field._creation_counter == Field._creation_counter + 1
    assert field.any_of[0]._creation_counter == Field._creation_counter



# Generated at 2022-06-12 15:45:32.210751
# Unit test for constructor of class Const
def test_Const():
    # Const with const value not null
    # Const with const value null and allow_null is True
    # Const with const value null and allow_null is False
    # Const with allow_null is False will fail
    const_field = Const(const="const", allow_null=False)
    assert const_field.const == "const"
    assert not const_field.allow_null
    with pytest.raises(AssertionError):
        Const(const="const", allow_null=False)
    with pytest.raises(AssertionError):
        Const(const=None, allow_null=True)
    const_field = Const(const=None, allow_null=False)
    assert const_field.const is None
    assert const_field.allow_null
    # Const with const value not equals to validate_value
    #

# Generated at 2022-06-12 15:45:37.561091
# Unit test for method validate of class Number
def test_Number_validate():
    number_field = Number(**{'multiple_of': 2})
    assert number_field.validate(2) == 2
    assert number_field.validate(4) == 4
    assert number_field.validate(6) == 6
    assert number_field.validate(8) == 8
    assert number_field.validate(6.0) == 6


# Generated at 2022-06-12 15:45:42.292588
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = Field(default = "test")
    assert "test" == a.get_default_value()
    def func():
        return "test"
    b = Field(default = func)
    assert "test" == b.get_default_value()
    c = Field()
    assert None == c.get_default_value()

# Generated at 2022-06-12 15:45:51.829069
# Unit test for method __or__ of class Field
def test_Field___or__():
  code1 = Field(title='title1', description='description1', default='default1', allow_null='allow_null1')
  Field.errors = {'error1': 'error1'}
  assert code1.get_error_text('error1') == 'error1'
  assert isinstance(code1.get_default_value(), str)
  assert code1.has_default()
  assert not hasattr(code1, 'default')
  assert not code1.has_default()
  default = 'default'
  code1.default = default
  assert code1.has_default()
  assert code1.get_default_value() == default
  code1.default = code1.get_default_value


# Generated at 2022-06-12 15:45:53.589416
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {'test': Integer()}
    schema = Object(properties=properties)
    # validate
    result = schema.validate({"test":1})
    expected = {'test': 1}
    assert result == expected



# Generated at 2022-06-12 15:45:57.877808
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert(f.get_default_value() == None)
    f = Field(allow_null=True)
    assert(f.get_default_value() == None)
    f = Field(default="abc")
    assert(f.get_default_value() == "abc")
    f = Field(default="abc", allow_null=True)
    assert(f.get_default_value() == "abc")
    def get_string(): return "abc"
    f = Field(default=get_string)
    assert(f.get_default_value() == "abc")
    f = Field(default=get_string, allow_null=True)
    assert(f.get_default_value() == "abc")


# Generated at 2022-06-12 15:46:10.135980
# Unit test for method validate of class Union
def test_Union_validate():
    from .typing_ import TypedField, StringishField
    from .fieldsets import FieldSet
    from .lists import TypedList
    from .objects import TypedDictionary
    from .standard_fields import StringField
    field = Union(
        [
            TypedField(StringishField()),
            TypedField(FieldSet({"foo": StringField()})),
            TypedField(TypedList(StringField())),
            TypedField(TypedDictionary(StringField())),
        ]
    )
    assert field.validate("foo") == "foo"
    assert field.validate({"foo": "bar"}) == {"foo": "bar"}
    assert field.validate([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-12 15:46:14.173833
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert str(Field() | Field() | Field()) == "Union([Field(), Field(), Field()])"




# Generated at 2022-06-12 15:46:24.055262
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title = "", description = "", allow_null = False)

    f.default = None

    assert f.get_default_value() == None


# Generated at 2022-06-12 15:46:30.089716
# Unit test for method __or__ of class Field
def test_Field___or__():
    f = Field(title="Name")
    f2 = Field(title="Phone")
    u = f|f2
    assert isinstance(u, Union)
    # all fields in one union
    u2 = u|f
    assert u2.any_of == [f, f2, f]
    # and not in multiple unions
    u3 = f|f2|f
    assert u3.any_of == [f, f2, f]



# Generated at 2022-06-12 15:46:34.755819
# Unit test for method validate of class Choice
def test_Choice_validate():
 
   c=Choice()
   with pytest.raises(ValidationError):
    assert c.validate("",strict=False)== "true" 
   assert c.validate("35",strict=False)== "45"
   assert c.validate("null",strict=False)== "none"


# Generated at 2022-06-12 15:46:35.740960
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert True


# Generated at 2022-06-12 15:46:40.370084
# Unit test for constructor of class String
def test_String():
    assert isinstance(String(title='test', description='test', default='test', allow_null=True, allow_blank=True, trim_whitespace=True, max_length=3, min_length=3, pattern='test', format='test'), Field)


# Generated at 2022-06-12 15:46:52.006269
# Unit test for method validate of class Array
def test_Array_validate():
    string_field = Field(type="string")
    integer_field = Field(type="integer")
    null_field = Field(type="null")

    array_null_field = Array(items=null_field)
    array_string_field = Array(items=string_field)
    array_integer_field = Array(items=integer_field)
    array_field = Array(items=Field(type="string"))
    mixed_array_field = Array(items=[string_field, integer_field])
    mixed_array_null_field = Array(items=[string_field, null_field])
    mixed_array_mixed_field = Array(items=[string_field, integer_field, null_field])

# Generated at 2022-06-12 15:46:56.807828
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():    
    f = Field()
    if f.get_default_value() is None:
        pass
    else:
        raise Exception
    f = Field(default = 1)
    if f.get_default_value() != 1:
        raise Exception
    def f3():
        return 1
    f = Field(default = f3)
    if f.get_default_value() != 1:
        raise Exception


# Generated at 2022-06-12 15:47:03.454577
# Unit test for method validate of class Choice
def test_Choice_validate():
    from pydantic.validators import validator
    from typing import Any

    class MyChoice(Choice):
        @validator("choices")
        def my_validator(cls, v: Any) -> Any:
            assert v is not None
            assert isinstance(v, list)
            return v

    class MyData(BaseModel):
        my_list: MyChoice

    my_data = MyData(my_list=MyChoice(choices=[]))

# Generated at 2022-06-12 15:47:07.966776
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [String()]
    union_value = 'yeehaw'
    union = Union(any_of)
    assert union.validate(union_value) == union_value



# Generated at 2022-06-12 15:47:11.850038
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field()|Field() == Union([Field(), Field()])
    assert Field()|Field() == Union([Field(), Field()])
    assert Field()|Union([Field(), Field()]) == Union([Field(), Field(), Field(), Field()])



# Generated at 2022-06-12 15:47:21.819635
# Unit test for constructor of class Const
def test_Const():
    field = Const(const = "a")
    assert field.const == "a"
    assert field.errors == Const.errors
    assert field.allow_null == False
    assert field.default_value == NotGiven


# Generated at 2022-06-12 15:47:26.123255
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [String(), Number()]
    union = Union(any_of)
    assert union.validate("1") == "1"
    assert union.validate(1) == 1
    assert union.validate(1.1) == 1.1
    with pytest.raises(ValidationError):
        union.validate(True)


# Generated at 2022-06-12 15:47:28.550561
# Unit test for method __or__ of class Field
def test_Field___or__():
    field = Field()
    assert field.__or__(1) is not None

# Generated at 2022-06-12 15:47:32.827780
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number(maximum=0, minimum=0)
    try:
        n.validate(-1)
    except ValidationError as e:
        assert isinstance(e, ValidationError)
        assert e.code == "minimum"
    try:
        n.validate(1)
    except ValidationError as g:
        assert isinstance(g, ValidationError)
        assert g.code == "maximum"
    assert n.validate(0) == 0
# End of unit test


# Generated at 2022-06-12 15:47:43.683567
# Unit test for constructor of class Array
def test_Array():
    f1 = Field(default=None)
    f2 = Field(default=None)
    a = Array(items=[f1, f2], additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)
    a.validate_or_error([1, 2])
    a.validate_or_error([1, 2, 3])
    a.validate_or_error([1, 2, 3, 4, 5])
    a.validate_or_error([1, 2, 3, 4, 5, 6, 7, 8, 9])
    a.validate_or_error([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# Generated at 2022-06-12 15:47:55.780009
# Unit test for method validate of class Union
def test_Union_validate():
    import json

    # Test Union with any_of containing only valid types
    union_field = Union([Integer(), Boolean()])
    expected_result = True
    response = union_field.validate(True)
    assert response == expected_result

    # Test Union with any_of containing list and integer
    union_field = Union([Integer(), List()])
    expected_result = [1, 2, 3]
    response = union_field.validate(expected_result)
    assert response == expected_result

    # Test Union with any_of containing list and integer and empty list
    union_field = Union([Integer(), List()])
    expected_result = []
    response = union_field.validate(expected_result)
    assert response == expected_result

    # Test Union with any_of containing list and integer, with wrong type
    union_

# Generated at 2022-06-12 15:48:02.562069
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [("Việt Nam","Việt Nam"),("Trung Quốc","Trung Quốc"),("Mỹ","Mỹ")])
    assert choice.validate("Việt Nam") == "Việt Nam"
    assert choice.validate("Trung Quốc") == "Trung Quốc"
    assert choice.validate("Mỹ") == "Mỹ"
test_Choice_validate()



# Generated at 2022-06-12 15:48:06.072738
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Integer(required=True),]
    union = Union(any_of,required=True)
    assert union.validate(0) == 0
    assert union.validate(None) == None
    with pytest.raises(ValidationError):
        union.validate(False)

# The Union class doesn't have a __repr__ method.
# Add one since it is helpful when debugging a schemas dictionary.

# Generated at 2022-06-12 15:48:10.007536
# Unit test for method validate of class Union
def test_Union_validate():
    integer = Integer()
    any_of = [integer, String()]
    union = Union(any_of=any_of)
    union.validate(5)



# Generated at 2022-06-12 15:48:14.434011
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f1 = Field(default=NO_DEFAULT)
    assert f1.get_default_value() is NO_DEFAULT
    f1_1 = Field()
    assert f1_1.get_default_value() == None
    f2 = Field(default=3)
    assert f2.get_default_value() == 3

# Generated at 2022-06-12 15:48:31.133262
# Unit test for method validate of class Choice
def test_Choice_validate():
    #test error in null
    field=Choice(allow_null=False)
    try:
        field.validate("")
        assert False,"Should raise ValidationError"
    except ValidationError:
        assert True
    #test no error in null
    field=Choice(allow_null=True)
    try:
        field.validate("")
        assert True
    except ValidationError:
        assert False,"Shouldn't raise ValidationError"
    #test error in choices
    field=Choice(allow_null=True,choices=[("a",1),("b",2)])
    try:
        field.validate("c")
        assert False,"Should raise ValidationError"
    except ValidationError:
        assert True
    #test no error in choices

# Generated at 2022-06-12 15:48:34.027596
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title="testTitle", description="testDescription", default="testDefault")
    assert_equals("testDefault", field.get_default_value())


# Generated at 2022-06-12 15:48:36.266278
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['foo', 'bar'])
    choice.validate(value=None)
    choice.validate(value='foo')



# Generated at 2022-06-12 15:48:48.357769
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=(("foo", "Foo"), ("bar", "Bar")))
    assert choice.validate("foo") == "foo"
    assert choice.validate("bar") == "bar"
    with pytest.raises(ValidationError) as excinfo:
        choice.validate("baz")
    assert excinfo.value.text == "Not a valid choice."
    assert excinfo.value.code == "choice"
    assert choice.validate_or_error("bar") == ValidationResult(value="bar", error=None)

    choice.allow_null = True
    assert choice.validate(None) == None
    assert choice.validate_or_error(None) == ValidationResult(value=None, error=None)

    choice.allow_null = False

# Generated at 2022-06-12 15:48:56.007485
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String, Number
    assert (String() | Number()).__class__.__name__ == 'Union'
    assert type(String() | Number()).__name__ == 'Union'
    assert (String() | Number()).any_of[0].__class__.__name__ == 'String'
    assert (String() | Number()).any_of[1].__class__.__name__ == 'Number'



# Generated at 2022-06-12 15:49:03.432770
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert f.get_default_value() is None
    f = Field(default=1)
    assert f.get_default_value() == 1
    f = Field(default="abc")
    assert f.get_default_value() == "abc"
    f = Field(default=True)
    assert f.get_default_value() == True
    f = Field(default=NO_DEFAULT)
    assert f.get_default_value() is NO_DEFAULT
    
    

# Generated at 2022-06-12 15:49:14.416592
# Unit test for method validate of class Boolean
def test_Boolean_validate():

    boolean = Boolean()
    case_1 = [None, None]
    case_2 = [True, True]
    case_3 = [False, False]
    case_4 = ["True", True]
    case_5 = ["False", False]
    case_6 = ["", None]
    case_7 = [1, True]
    case_8 = [0, False]

    cases = [case_1, case_2, case_3, case_4, case_5, case_6, case_7, case_8]
    for case in cases:
        test = boolean.validate(case[0])
        assert test == case[1]

        test = boolean.validate(case[0], strict=True)
        assert test == case[1]
