

# Generated at 2022-06-12 15:40:34.414725
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2016-01-02") == "2016-01-02"
    assert String(format="time").serialize("10:11:12") == "10:11:12"
    assert String(format="datetime").serialize("2016-01-02T10:11:12Z") == "2016-01-02T10:11:12Z"
    assert String(format="uuid").serialize("66c32a72-b3dd-48b3-97bf-2d12c723d9ab") == "66c32a72-b3dd-48b3-97bf-2d12c723d9ab"

test_String_serialize()



# Generated at 2022-06-12 15:40:40.902635
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    assert s.serialize("7") == "7"
    assert s.serialize(44) == 44
    assert s.serialize(None) == None
    assert s.serialize(30.5) == 30.5
    assert s.serialize(False) == False
    assert s.serialize([1, 2, 3]) == [1, 2, 3]
    assert s.serialize((1, 2, 3)) == (1, 2, 3)
    assert s.serialize({1, 2, 3}) == {1, 2, 3}
    assert s.serialize({"k1": 1, "k2": 2, "k3": 3}) == {"k1": 1, "k2": 2, "k3": 3}



# Generated at 2022-06-12 15:40:45.684738
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(default=NO_DEFAULT)
    assert f.get_default_value() == NO_DEFAULT
    f = Field(default="DEFAULT")
    assert f.get_default_value() == "DEFAULT"
    f = Field(default=lambda: "DEFAULT")
    assert f.get_default_value() == "DEFAULT"

# Generated at 2022-06-12 15:40:56.808528
# Unit test for method validate of class Number
def test_Number_validate():
    min_val = 3
    max_val = 7
    exc_max_val = 6
    exc_min_val = 4
    mult_val = 2

    val = Number(
        minimum = min_val,
        maximum = max_val,
        exclusive_minimum = exc_min_val,
        exclusive_maximum = exc_max_val,
        multiple_of = mult_val
    )
    num = val.validate(val = 3)
    assert num == 3
    num = val.validate(val = 4)
    assert num == 4
    num = val.validate(val = 5)
    assert num == 5
    num = val.validate(val = 6)
    assert num == 6
    num = val.validate(val = 7)
    assert num == 7
    num = val.validate

# Generated at 2022-06-12 15:41:04.618394
# Unit test for constructor of class Choice
def test_Choice():
    try:
        choices = Choice(choices=[("f", "b")])
        assert len(choices.choices)==1
    except:
        raise AssertionError("Constructor of Choice does not work.")

    try:
        choices = Choice(choices=[("f", "b"), "f"])
        assert len(choices.choices)==2, "second item should be converted to a tuple"
    except:
        raise AssertionError("Constructor of Choice does not work.")
        

# Generated at 2022-06-12 15:41:12.803706
# Unit test for method validate of class Array
def test_Array_validate():
    # Test a object of Array with required properties
    instance = Array(
        title="integer list",
        description="A list of integers",
        min_items=3,
        max_items=3,
        items=Integer(title="Integer", description="Integer"),
    )
    assert instance.validate([1,2,3]) == [1,2,3]

    # Test a object of Array with additional_items
    instance = Array(
        title="integer list",
        description="A list of integers",
        min_items=3,
        max_items=3,
        items=Integer(title="Integer", description="Integer"),
        additional_items=False,
    )
    assert instance.validate([1,2,3,4]) == None

    # Test a object of Array with unique_items

# Generated at 2022-06-12 15:41:17.533617
# Unit test for method serialize of class String
def test_String_serialize():
    class Dummy:
        pass
    dummy = Dummy()
    string = String()
    assert string.serialize("test") == "test"
    assert string.serialize(dummy) == dummy

# Generated at 2022-06-12 15:41:27.723449
# Unit test for method validate of class Choice
def test_Choice_validate():
    from datetime import date, datetime
    from decimal import Decimal
    from hypothesis import given
    from hypothesis.strategies import integers, text, datetimes, dates, decimals, lists

    # valid inputs
    # given
    # when
    choice = Choice(choices=['aaa', 'bbb', 'ccc', 'cdd'])
    value1 = 'aaa'
    value2 = 'bbb'
    value3 = 'ccc'
    value4 = 'cdd'
    # then
    assert choice.validate(value1) == 'aaa'
    assert choice.validate(value2) == 'bbb'
    assert choice.validate(value3) == 'ccc'
    assert choice.validate(value4) == 'cdd'

    # invalid inputs
    # given
    # when


# Generated at 2022-06-12 15:41:37.736138
# Unit test for method validate of class Number
def test_Number_validate(): 
    wrong_inputs = [
        (1.3),
        (4.4),
        (4),
        (True),
        (False),
        (1.0),
        (0.2),
        ("abc")
    ]
    correct_inputs = [
        (1.1),
        (2.2),
        (2),
        (2),
        (1.1),
        (0.1),
        (1),
        ("decimal"),
        ("time"),
        ("datetime"),
        ("date"),
        ("uuid")
    ]
    for input in wrong_inputs:
        assert Number(minimum=2, maximum=2, precision="1.1", multiple_of=0.1, format="decimal").validate(input)!=input

# Generated at 2022-06-12 15:41:41.487949
# Unit test for method validate of class String
def test_String_validate():
    str_1 = String()
    str_1.validate('')
    str_1.validate('fjsdkljflks')
test_String_validate()

# Generated at 2022-06-12 15:42:23.810982
# Unit test for constructor of class Const
def test_Const():
    assert Const(1).schema() == {"const": 1}
    assert Const(1).const == 1
    assert Const(1, allow_null=True).allow_null == False
    assert Const(1).allow_null == False


# Generated at 2022-06-12 15:42:24.964544
# Unit test for method validate of class Object
def test_Object_validate():
    pass

# Generated at 2022-06-12 15:42:36.936440
# Unit test for method validate of class Array
def test_Array_validate(): 
    from vpype_cli.presets import preset_default
    from vpype_cli.presets.preset_default import (
        mm_to_pt,
        pt_to_mm,
        pt_to_px,
        px_to_pt,
    )
    from vpype_cli.validators import (
        AutoConvert,
        Boolean,
        Choice,        
        Integer,
        Length,
        LengthUnit,
        Number,
        NumberUnit,
        Object,
        Text,        
        validate,
    )
    my_array = Array(items=Integer(), additional_items=False)
    print(my_array.validate([1,2,3]))
    print(my_array.validate([1,2,3,4,5]))

# Generated at 2022-06-12 15:42:45.089428
# Unit test for method validate of class Union
def test_Union_validate():
    class Foo(Schema):
        bar = Field()
        bar_bar = Field()

    class Bazz(Schema):
        a = Field()
        b = Field()

    # class NoneType(Schema):
    #     None = Field() 

    class Test(Schema):
        a = Field()
        b = Union([Foo, Bazz])
        c = Union([Foo, Bazz, None])
        d = Union([Foo, None])


    test = Test({"a": 0, "b": {"bar": "bar"}, "d": None})
    assert test.to_dict() == {"a": 0, "b": {"bar": "bar"}, "d": None}


# Generated at 2022-06-12 15:42:56.177721
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Test the case where input is a valid object
    test_data = [2, 3, 4, 5]
    for test_data_item in test_data:
        field_instance = Field(title="Title", description="Description")
        expected_result = ValidationResult(value=test_data_item, error=None)
        actual_result = field_instance.validate_or_error(test_data_item)
        assert expected_result == actual_result

    # Test the case where input is an invalid object
    class MyField(Field):
        errors = {"invalid_type": "Invalid type"}
        def validate(self, value, strict=False):
            if isinstance(value, int):
                return value
            else:
                raise self.validation_error("invalid_type")


# Generated at 2022-06-12 15:43:03.993644
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    s.validate('', strict=True)
    try:
        s.validate(None, strict=True)
    except ValidationError:
        assert True
    try:
        s.validate(1, strict=True)
    except ValidationError:
        assert True
    s.validate('', strict=False)
    s.validate(None, strict=False)
    try:
        s.validate(1, strict=False)
    except ValidationError:
        assert True



# Generated at 2022-06-12 15:43:07.316372
# Unit test for method validate of class Array
def test_Array_validate():
    assert Array().validate(3, strict=True) == []
    assert Array().validate([3, "abc"], strict=True) == []
    assert Array().validate([3, [5]], strict=True) == []
    assert Array().validate([3, "abc", [5]], strict=True) == []



# Generated at 2022-06-12 15:43:12.133245
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Integer

    class TestClass:
        pass

    f = Integer() | Integer()

    assert isinstance(f, Union)
    assert isinstance(f.any_of[0], Integer)
    assert isinstance(f.any_of[1], Integer)



# Generated at 2022-06-12 15:43:18.653654
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array(allow_null=False,items=Array(allow_null=True,items=Integer(allow_null=False,maximum=10,minimum=2)),additional_items=Boolean(allow_null=False),max_items=3,min_items=1,required=False,unique_items=False)
    obj.validate([2, 3, [4, 5, 6], True])
    try:
        obj = Array(allow_null=False,items=Array(allow_null=True,items=Integer(allow_null=False,maximum=10,minimum=2)),additional_items=Boolean(allow_null=False),max_items=3,min_items=1,required=False,unique_items=False)
        obj.validate(None)
    except ValidationError as e:
        assert e.error

# Generated at 2022-06-12 15:43:22.875197
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """ Testing get_default_value method of class Field"""
    a = Field(default="3")
    assert a.get_default_value() == "3"
    a.default = 3
    assert a.get_default_value() == 3



# Generated at 2022-06-12 15:43:35.769877
# Unit test for method validate of class Array
def test_Array_validate():
    try:
        array_field = Array(items=Integer(), min_items=2)
        field_value = array_field.validate([1, 2, 3])
        assert field_value == [1, 2]
        assert array_field.is_valid([1, 2])
        assert not array_field.is_valid([1])
    except ValidationError as v:
        print(v.messages)


# Generated at 2022-06-12 15:43:48.099532
# Unit test for method serialize of class Array
def test_Array_serialize():
    test_Array_serialize_list = [ 
        [5],
        ['abc','abc'],
        ['abc','def']
    ]
    test_Array_serialize_list = [ 
        [5],
        ['abc','abc'],
        ['abc','def']
    ]
    test_Array_serialize_list_Str = [ 
        '5',
        'abc','abc',
        'abc','def'
    ]
    test_Array_serialize_list_tuple = [ 
        (5,),
        ('abc','abc'),
        ('abc','def')
    ]
    test_Array_serialize_list_tuple_Str = [ 
        '5',
        'abc','abc',
        'abc','def'
    ]

# Generated at 2022-06-12 15:43:53.125410
# Unit test for method validate of class String
def test_String_validate():
    field = String()

    # Happy Path
    assert field.validate("hello") == "hello"
    assert field.validate("hello") == "hello"
    assert field.validate("") == ""
    assert field.validate("") == ""
    # Unit test for method validate_or_error of class String

# Generated at 2022-06-12 15:43:56.422630
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title = "test", description = "test", default = "test")
    assert field.get_default_value() == "test"



# Generated at 2022-06-12 15:44:04.207369
# Unit test for method validate of class Union
def test_Union_validate():
    print("\n----- test_Union_validate -----")
    class Validate():
        def check(self, value, expected):
            print(f"check({value}, {expected})")
            union = Union([Integer(), String()])
            actual = union.validate(value)
            assert actual == expected, f"value={value}, expected={expected}, actual={actual}"

        def test(self):
            self.check(123, 123)
            self.check("abc", "abc")
            # self.check(Union(), "abc") # error, can't be instance of Union
            self.check(None, None)
    Validate().test()



# Generated at 2022-06-12 15:44:11.149689
# Unit test for method __or__ of class Field
def test_Field___or__():
    t1 = String(min_length=2)
    t2 = String(max_length=5)
    t3 = String(allow_empty=True)
    assert (t1 | t2).any_of == [t1, t2]
    assert (t1 | t2 | t3).any_of == [t1, t2, t3]
    assert (Any() | String()).any_of == [Any(), String()]
    return



# Generated at 2022-06-12 15:44:22.383609
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_field = Boolean()
    # Test for null value and allow_null is true
    assert boolean_field.validate(None, strict=False) is None
    strict_boolean_field = Boolean()
    # Test for null value and allow_null is false
    with pytest.raises(ValidationError):
        strict_boolean_field.validate(None, strict=True)
    # Test for boolean value
    assert boolean_field.validate(True, strict=False) == True
    # Test for string value
    assert boolean_field.validate("off", strict=False) == False
    with pytest.raises(ValidationError):
        strict_boolean_field.validate(None, strict=True)
    # Test for coerce values type error
    with pytest.raises(TypeError):
        boolean

# Generated at 2022-06-12 15:44:26.813537
# Unit test for method validate of class Choice
def test_Choice_validate():
    list_of_choices=["choice1","choice2","choice3"]
    obj=Choice(choices=list_of_choices)
    assert obj.validate("choice2")=="choice2"
    assert obj.validate(None)==None



# Generated at 2022-06-12 15:44:31.117884
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray_serialize:
        @staticmethod
        def test_call():
            schema = Array()
            obj = [1, 2, 3]
            assert schema.serialize(obj) == obj
    TestArray_serialize.test_call()



# Generated at 2022-06-12 15:44:42.889310
# Unit test for method serialize of class Array
def test_Array_serialize():
    class ArraySerialize(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def serialize(self, obj: typing.Any):
            if obj is None:
                return None
            return [self.items.serialize(value) for value in obj]

    class Nested(Object):
        properties = {
            "foo": Field(type="string", default=None),
            "bar": Field(type="boolean", default=None),
            "baz": Field(type="integer", default=None),
        }


# Generated at 2022-06-12 15:45:38.860343
# Unit test for method validate of class Array
def test_Array_validate():
    field_tester = FieldTester.for_field(Array)
    
    # Test "type": "Must be an array."
    field_tester.test_valid(
        field_name="test",
        value=["a", "b", "c"],
        expected_value=["a", "b", "c"],
    )
    field_tester.test_invalid(
        field_name="test",
        value={
            "a": 1,
            "b": 2,
            "c": 3,
        },
        errors=[
            {"code": "type", "message": "Must be an array."}
        ],
    )

# Generated at 2022-06-12 15:45:43.396753
# Unit test for method validate of class Object
def test_Object_validate():
    data = {
        "name": "Toyota", "initial_release_year": 1987, "models": ["Camry", "Corolla", "Tacoma"], "price": 2300
    }
    fields = {
        "name": String(),
        "initial_release_year": Integer(minimum = 1975, maximum = 2020),
        "models": Array(items = String()),
        "price": Decimal(minimum = 0.0)
    }
    object = Object(properties = fields)
    
    print("Input data: ", data)
    output = object.validate(data)
    print("Valid data:", output)
    assert len(output) == 4
    assert output["name"] == "Toyota"
    assert output["initial_release_year"] == 1987

# Generated at 2022-06-12 15:45:47.611194
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    result = number.validate(1.0)
    assert result == 1.0
    with pytest.raises(ValidationError) as excinfo:
        number.validate('string')
    assert 'Must be a number.' in str(excinfo.value)


# Generated at 2022-06-12 15:45:55.975500
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test invalid value with 'value' is None and self.allow_null is True
    choice_1 = Choice()
    assert choice_1.validate(None, strict=False) == None
    # Test invalid value with 'value' is None and self.allow_null is False(default)
    assert choice_1.validate(None, strict=False) == None
    # Test invalid value with 'value' not in Uniqueness of all keys of choices
    choice_2 = Choice(choices=["a", "b", "c"])
    with pytest.raises(ValidationError) as exception_info:
        choice_2.validate("d", strict=False)
    assert exception_info.value.code == "choice"
    # Test valid value
    assert choice_2.validate("a", strict=False) == "a"

# Generated at 2022-06-12 15:46:08.732682
# Unit test for method validate of class String
def test_String_validate():
    t1 = String("this is a string")
    t2 = String("this is a string", min_length=4)
    t3 = String("this is a string", format="date")
    t4 = String("this is a string", max_length=4)
    t5 = String("this is a string", pattern="^[0-9]*")
    t6 = String("this is a string", allow_null=True)


    assert t1.validate("this is a string") == "this is a string"
    assert t1.validate("") == ""
    assert t2.validate("this is a string") == "this is a string"
    assert t3.validate("22/03/2019") == datetime.date(2019, 3, 22)

# Generated at 2022-06-12 15:46:15.541481
# Unit test for method serialize of class Array
def test_Array_serialize():
    s = Array(items=String())
    assert s.serialize(["abc", "efg"]) == ["abc", "efg"]
    assert s.serialize((None, 1)) == [None, "1"]
    assert s.serialize(["abc"]) == ["abc"]
    assert s.serialize([]) == []



# Generated at 2022-06-12 15:46:22.541780
# Unit test for constructor of class String
def test_String():
    assert String().validate('abc') == 'abc'
    assert String(allow_null=True).validate(None) == None
    assert String().validate('    abc   ').strip() == 'abc'
    assert String(allow_blank=True).validate('') == ''
    assert String(allow_blank=True, allow_null=True).validate(None) == ''
    assert String(min_length=10).validate('abc') == 'abc'
    assert String(max_length=10).validate('abc') == 'abc'
    assert String(pattern='/^a*b*c$/').validate('abc') == 'abc'

# Generated at 2022-06-12 15:46:30.680533
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # test_Boolean_validate_coerce
    field = Boolean(allow_null=True)
    assert field.validate(None) is None
    assert field.validate(False) is False
    assert field.validate(True) is True
    assert field.validate("") is False
    assert field.validate("false") is False
    assert field.validate("true") is True
    assert field.validate(1) is True
    assert field.validate(0) is False
    assert field.validate("1") is True
    assert field.validate("0") is False
    assert field.validate("null") is None
    assert field.validate("none") is None

    field = Boolean()
    assert field.validate(False) is False
    assert field.validate(True) is True


# Generated at 2022-06-12 15:46:37.293649
# Unit test for method validate of class Object
def test_Object_validate():
    import fields

    foo = fields.Object(
        properties={
            "nested": fields.Object(
                properties={
                    "bar": fields.Integer(minimum=2)
                },
            )
        },
    )

    value, error = foo.validate_or_error(
        {
            "nested": {
                "bar": 1, 
                "foo": 2
            },
        }
    )

    assert value is None
    assert len(error.messages()) == 3


# Generated at 2022-06-12 15:46:43.754051
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    error_message = "The method get_default_value of class Field is not working as expected"
    # Test the behavior of the method get_default_value when there is a default value
    field_with_default = Field(default="some_default_value")
    assert field_with_default.get_default_value() == "some_default_value", error_message
    # Test the behavior of the method get_default_value when there is no default value
    field_with_default = Field()
    assert field_with_default.get_default_value() == None, error_message



# Generated at 2022-06-12 15:47:13.235342
# Unit test for method validate of class String

# Generated at 2022-06-12 15:47:22.673283
# Unit test for method validate of class String
def test_String_validate():
    s=String()
    print(s.validate('123'))
    print(s.validate('type'))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #assert True
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
test_String_validate()


# Generated at 2022-06-12 15:47:33.698886
# Unit test for method __or__ of class Field
def test_Field___or__():
    from random import random
    from math import floor
    from typesystem.types import String, Integer, Number
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Field
    val = floor(random() * 1000)
    print(val)
    res=val%2
    if res == 0:
        obj = Field()
    elif res == 1:
        obj = Field()
    elif res == 2:
        obj = Field()
    elif res == 3:
        obj = Field()
    elif res == 4:
        obj = Field()
    elif res == 5:
        obj = Field()
    elif res == 6:
        obj = Field()
    elif res == 7:
        obj = Field()
    elif res == 8:
        obj = Field()

# Generated at 2022-06-12 15:47:44.829125
# Unit test for method __or__ of class Field
def test_Field___or__():
    import datetime
    from typesystem.fields import String, DateTime
    date_format = "%Y-%m-%dT%H:%M:%S"
    string_date = '2013-08-20T11:39:00' 
    date = datetime.datetime.strptime(string_date, date_format)
    valid_date = String(pattern=r'\d\d\d\d-\d\d-\d\dT\d\d:\d\d:\d\d') | DateTime(format="%Y-%m-%dT%H:%M:%S")
    assert valid_date.validate(string_date) == date 
    assert valid_date.validate(date) == date
    assert valid_date.validate(3)

# Generated at 2022-06-12 15:47:57.632106
# Unit test for method validate of class String
def test_String_validate():
    #title, description, default, allow_null
    str0 = String()
    str1 = String(title="Title", description="Description", default="Default", allow_null=True)
    str2 = String(title="Title", description="Description", default="Default", allow_null=False)
    str3 = String(title="Title", description="Description", default="", allow_null=True)
    str4 = String(title="", description="", default="", allow_null=True)
    str5 = String(title="Title", description="Description", default="Default", allow_null=False)
    str6 = String(title="Title", description="Description", default="Default", allow_null=True)
    str7 = String(title="Title", description="Description", default="Default", allow_null=True)

    assert str0.validate("")

# Generated at 2022-06-12 15:48:04.557667
# Unit test for method validate of class Union
def test_Union_validate():
    def test(clz):
        u = Union([
            clz,
            Text(),
        ])
        assert u.validate("foo") == "foo"
        assert u.validate(1) == 1
        assert u.validate(1.0) == 1.0
        assert u.validate(True) == True
        assert u.validate([1, 2, 3]) == [1, 2, 3]

        try: u.validate(None)
        except ValidationError: pass
        else: raise Exception("Must raise ValidationError")

    test(Integer())
    test(Number())
    test(Boolean())
    test(Array())
    test(Object())



# Generated at 2022-06-12 15:48:09.521210
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Integer(Field):
        pass

    class String(Field):
        pass

    integer_or_string = Integer() | String()
    assert isinstance(integer_or_string, Union)
    assert len(integer_or_string.any_of) == 2



# Generated at 2022-06-12 15:48:12.814527
# Unit test for method validate of class Union
def test_Union_validate():
    # test case 1
    validator = Union([String(max_length=10)])
    value = "abc"
    validated, errors = validator.validate_or_error(value)
    assert validated == value


# Generated at 2022-06-12 15:48:15.202094
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = Field(title=1, description=1, default=1, allow_null=True)
    f2 = Field(title=2, description=2, default=2, allow_null=True)
    u = f1 | f2
    assert isinstance(u, Union)
    assert u.any_of == [f1, f2]


# Generated at 2022-06-12 15:48:26.259963
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items = None, additional_items = False, min_items = None, max_items = None, exact_items = None, unique_items = False)
    obj = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    ret = field.serialize(obj)
    assert ret == obj
    obj = [0,'a',2,3,4,5,6,7,8,9]
    ret = field.serialize(obj)
    assert ret == obj
    field = Array(items = Float(), additional_items = False, min_items = None, max_items = None, exact_items = None, unique_items = False)
    ret = field.serialize(obj)

# Generated at 2022-06-12 15:48:46.151683
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestCls(Field):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.default = 20
    obj = TestCls()
    assert obj.get_default_value() == 20


# Generated at 2022-06-12 15:48:54.831532
# Unit test for method __or__ of class Field
def test_Field___or__():
	if getattr(Field, "__or__") == Field.__or__:
		x = Field()
		y = Field()
		z = Field()
		w = Field()
		assert (x | y) in (x | y | z | w)
		assert (x | y) in (z | y | x | w)
		assert (x | y) in (z | w | y | x)
		assert (x | y) in (x | y)


# Generated at 2022-06-12 15:48:56.810979
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(allow_null=True)
    assert field.get_default_value() is None

# Generated at 2022-06-12 15:49:06.769523
# Unit test for method validate of class Array
def test_Array_validate():
    class Nested(object):
        a = Field()
        b = Field()
    class T(object):
        array = Array(
            items = Field(allow_null = True),
            additional_items = False,
            max_items = 7,
            min_items = 2,
            exact_items = None,
            unique_items = True
        )
        nested_array = Array(
            items = Nested()
        )
    def t(schema : T, obj, *, strict = False, expect_success = True, expected_obj = None):
        print("-------------New test-------------")
        try:
            res = schema.validate(obj, strict = strict)
            assert res == expected_obj
            assert expect_success
        except ValidationError as e:
            print(e)
            assert not expect_success
