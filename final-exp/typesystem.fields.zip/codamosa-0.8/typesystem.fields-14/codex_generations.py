

# Generated at 2022-06-12 15:40:55.820542
# Unit test for method validate of class Array
def test_Array_validate():
    from pydantic import BaseModel


    class Schema(BaseModel):
        values: typing.List[int]


    schema = Schema(values=[0, 1, 2, 3, 4, 5])
    values_f = Array(min_items=0, max_items=6)
    assert values_f.validate([0, 1, 2, 3, 4, 5]) == schema.values
    assert values_f.validate([0, 1, 2]) == [0, 1, 2]
    assert values_f.validate([]) == []
    assert values_f.validate(None) is None

    values_f = Array(min_items=1, max_items=6)
    assert values_f.validate([0, 1, 2, 3, 4, 5]) == schema.values
    assert values_f

# Generated at 2022-06-12 15:40:59.343286
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Setup
    field = Field()

    # Exercise
    default_value = field.get_default_value()

    # Verify
    assert default_value is None

# Generated at 2022-06-12 15:41:04.488042
# Unit test for method validate of class Choice
def test_Choice_validate():

    Choice.choices = [
        (choice if isinstance(choice, (tuple, list)) else (choice, choice))
        for choice in ["a", "b", "c"]
    ]
    assert Choice.validate("a", strict=True) == "a"

    with pytest.raises(ValidationError):
        Choice.validate("d", strict=True)



# Generated at 2022-06-12 15:41:08.569349
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices=[('a', 'b'), ('c', 'd')])
    assert obj.validate('a') == 'a'
    assert obj.validate('c') == 'c'
    expect_exception(obj.validate('d'), 'choice')
    expect_exception(obj.validate('e'), 'choice')



# Generated at 2022-06-12 15:41:15.374066
# Unit test for method validate of class Array
def test_Array_validate():
    items=[Field(),Field(),Field(),Field(),Field(),Field()]
    obj=Array(items=items)
    assert obj.validate([1,2,3,4,5,6])==[1,2,3,4,5,6]
    assert obj.validate([1,2,3])==[1,2,3]
    assert obj.validate([1,2,3,4,5,6,7,8,9,10])==[1,2,3,4,5,6,7,8,9,10]
    assert obj.validate(["1","2","3","4","5","6"])==["1","2","3","4","5","6"]

# Generated at 2022-06-12 15:41:26.228781
# Unit test for method validate of class Object
def test_Object_validate():
    with open('schema.json') as f:
        schema = json.load(f)
    field = Object(**schema["properties"]["person"])
    field.validate({"name": "Tom", "age": 30})
    field.validate({"name": "Tom", "age": 30}, strict=True)
    # TODO: Can't understand the following behaviour
    # field.validate({"name": "Tom", "age": 30.1})
    field.validate({"name": "Tom", "age": 30.1}, strict=True)
    field.validate({"name": "Tom", "age": "30.1"})
    field.validate({"name": "Tom", "age": "30.1"}, strict=True)



# Generated at 2022-06-12 15:41:29.960892
# Unit test for method __or__ of class Field
def test_Field___or__():
    sys_argvs = ["prog", "input_file"]
    expected = 0
    actual = field_test_main(sys_argvs, Field___or__)
    assert actual == expected

# Generated at 2022-06-12 15:41:35.799717
# Unit test for method validate of class Union
def test_Union_validate():
    # Test valid case
    field = Union([Field(), Int()])
    value, error = field.validate_or_error(5)
    assert value == 5
    assert error is None

    # Test invalid case
    field = Union([Field(), Int()])
    value, error = field.validate_or_error("test")
    assert value == "test"
    assert len(error.messages()) == 2
    message = error.messages()[0]
    assert message.code == "union"
    message = error.messages()[1]
    assert message.code == "union"


# Generated at 2022-06-12 15:41:47.559740
# Unit test for method validate of class Union
def test_Union_validate():
    import collections
    import datetime
    from marshmallow_dataclass import dataclass, field
    from marshmallow import Schema

    @dataclass
    class Body(object):
        field: typing.Union[str, int] = field(type_=str)

    print("Body class in Union class: ", Body)
    
    class BodySchema(Schema):
        field = Union(
            [
                String(min_length=1),
                Integer(min_value=0, allow_null=False),
            ]
        )

    print("BodySchema class in Union class: ", BodySchema)

    assert BodySchema().validate({"field": "a"}) == {"field": "a"}
    assert BodySchema().validate({"field": 1}) == {"field": 1}

# Generated at 2022-06-12 15:41:54.963020
# Unit test for method validate of class String
def test_String_validate():
    print("\nTest for method validate of class String")
    myString = String(title="name", description="Name")
    value = "abc"
    assert myString.validate(value) == "abc"
    value = 123
    try:
        myString.validate(value)
    except ValidationError as error:
        print(error)
    value = ""
    try:
        myString.validate(value)
    except ValidationError as error:
        print(error)
    value = []
    try:
        myString.validate(value)
    except ValidationError as error:
        print(error)
    value = {"a", "b", "c"}
    try:
        myString.validate(value)
    except ValidationError as error:
        print(error)
    value = None

# Generated at 2022-06-12 15:42:18.127054
# Unit test for method validate of class Union
def test_Union_validate():
    # Set the value to validat
    value = 5
    # Call the method validate
    field = Union(any_of=[Integer()])
    result = field.validate(value)
    # Check the result
    assert result == value


# Test for method serialize of class Union

# Generated at 2022-06-12 15:42:29.130677
# Unit test for method validate of class Array
def test_Array_validate():
    import json

    f = Array(max_items = 3)

    print(json.dumps(f.validate([1,2,3]), indent=4))
    # [
    #     1,
    #     2,
    #     3
    # ]

    try:
        print(json.dumps(f.validate([1,2,3,4]), indent=4))
    except ValidationError as ve:
        print(ve)
        # <ValidationError>
        #     "Must have no more than 3 items."

    try:
        print(json.dumps(f.validate([1,2,3,4,5]), indent=4))
    except ValidationError as ve:
        print(ve)
        # <ValidationError>
        #     "Must have no more than 3 items."



# Generated at 2022-06-12 15:42:34.028618
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["chien", "chat", "cheval"], allow_null=True)
    modele = "chien"
    assert c.validate(modele, strict=False) == modele



# Generated at 2022-06-12 15:42:36.231966
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[("key", "value")]).validate("key") == "key"

# Generated at 2022-06-12 15:42:43.303403
# Unit test for method serialize of class String
def test_String_serialize():
    input = "1"
    obj = String()
    obj.errors = {
        "type": "Must be a string.",
        "null": "May not be null.",
        "blank": "Must not be blank.",
        "max_length": "Must have no more than {max_length} characters.",
        "min_length": "Must have at least {min_length} characters.",
        "pattern": "Must match the pattern /{pattern}/.",
        "format": "Must be a valid {format}.", 
    }

    output = input

    assert obj.validate(input) is None
    assert obj.serialize(input) == output



# Generated at 2022-06-12 15:42:55.320131
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    # print(n.validate(None))
    assert n.validate(None) == None
    assert n.validate(-1.7976931348623157e+308) == None
    assert n.validate(1.7976931348623157e+308) == None
    assert n.validate(0) == 0
    assert n.validate(2) == 2
    assert n.validate(-2) == -2
    assert n.validate(2.0) == 2.0
    assert n.validate(-2.0) == -2.0
    assert n.validate(2.00000000001) == None
    assert n.validate(-2.00000000001) == None
    assert n.validate(1.797693134862315) == 1.797693134862315

# Generated at 2022-06-12 15:43:01.775151
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field=Field()
    assert field.error == {}
    assert field.validate_or_error()==None
    assert field.validate_or_error(value="",strict=False) == None
    assert field.validate_or_error(value="",strict=True) == None
    assert field.validate_or_error(value=None,strict=False) == None
    assert field.validate_or_error(value=None,strict=True) == None


# Generated at 2022-06-12 15:43:06.773603
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
  # Test1:Test for default value which is not callable
  f1 = Field(title="Title",description="Description",default="Default")
  assert f1.get_default_value() == "Default"
  # Test2:Test for default value which is callable
  def func(x,y):
    return x+y
  f2 = Field(title="Title",description="Description",default=func)
  assert f2.get_default_value()(2,2) == 4

# Generated at 2022-06-12 15:43:18.593077
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.fields import Field
    from typesystem.numbers import Float
    from typesystem.types import Integer
    from typesystem.base import ValidationError, ValidationResult
    from typesystem import formats
    import decimal
    import re
    import typing
    from math import isfinite
    from typing import Dict, Any, Union, List, Callable, Optional, Tuple, TypeVar
    from typesystem import formats
    from typesystem.unique import Uniqueness
    NO_DEFAULT = object()
    FORMATS = {
        "date": formats.DateFormat(),
        "time": formats.TimeFormat(),
        "datetime": formats.DateTimeFormat(),
        "uuid": formats.UUIDFormat(),
    }


# Generated at 2022-06-12 15:43:24.466517
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("kino") == "kino"
    with pytest.raises(ValidationError):
        Choice().validate("")
    with pytest.raises(ValidationError):
        Choice(choices=["kino", "divadlo"]).validate("koncert")
    assert Choice(allow_null=True).validate(None) is None


# Generated at 2022-06-12 15:43:50.058099
# Unit test for method validate of class Choice
def test_Choice_validate():
    def test_corner_case_1():
        choices = [(x,x) for x in range(5)]
        assert Choice(choices=choices).validate(1) == 1
    def test_corner_case_2():
        assert Choice().validate(None) is None
    def test_corner_case_3():
        choices = [(x,x) for x in range(5)]
        assert Choice(choices=choices).validate(-1) == -1
    def test_corner_case_4():
        choices = [(x,x) for x in range(5)]
        assert Choice(choices=choices).validate(1.0) == 1.0
    def test_corner_case_5():
        choices = [(x,x) for x in range(5)]

# Generated at 2022-06-12 15:44:02.283697
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice()
    assert field.validate(None, True) == None
    assert field.validate(1, True) == None
    field = Choice(allow_null=True)
    assert field.validate(None) == None
    field = Choice()
    assert field.validate(1, True) == None
    field = Choice(allow_blank=True)
    assert field.validate(1, True) == None
    assert field.validate(1) == None
    assert field.validate(True, True) == None
    field = Choice()
    assert field.validate(1) == None
    field = Choice(allow_blank=True)
    assert field.validate(1) == None
    field = Choice(allow_null=True)
    assert field.validate(None) == None

    
    

# Generated at 2022-06-12 15:44:14.458023
# Unit test for method validate of class Choice
def test_Choice_validate():
    # case 1
    try:
        Choice().validate(None, strict=False)
    except ValidationError as e:
        assert str(e) == 'Must be a {expected}, got {actual}.'.format(
            expected='str',
            actual=str(type(None))
        )

    # case 2
    try:
        Choice(allow_null=True).validate(None, strict=False)
    except ValidationError as e:
        assert str(e) == 'Must be a {expected}, got {actual}.'.format(
            expected='str',
            actual=str(type(None))
        )

    # case 3

# Generated at 2022-06-12 15:44:21.963774
# Unit test for method validate of class Union
def test_Union_validate():
    from . import OneOf
    from . import Number
    from . import Structure
    from . import Integer

    from . import Any
    from . import Boolean

    from .structures import StructureField

    from .fields import TextField
    schema = Union(
        [
            OneOf([TextField(format="text"), Number(format="number")]),
            Structure({"foo":Integer()}),
            Boolean(),
            Any(),
        ]
    )
    obj=schema.validate(3)
    assert obj==3
    assert type(obj)==int

# Generated at 2022-06-12 15:44:28.736080
# Unit test for method validate of class Object
def test_Object_validate():
    class MyObject(Object):
        age = Integer()
    
    # Validate parameters of the second object
    obj = MyObject()
    obj.validate({"age": "22"})
    assert obj.properties["age"].name == "age"
    assert obj.properties["age"].errors["type"] == "Must be an integer."

    # Validate parameters of the first object
    obj.validate({"age": "23"})
    assert obj.properties["age"].name == "age"
    assert obj.properties["age"].errors["type"] == "Must be an integer."

test_Object_validate()


# Generated at 2022-06-12 15:44:34.073149
# Unit test for method validate of class Object
def test_Object_validate():
    from pydantic import BaseModel

    class Model(BaseModel):
        a: bool
        b: int
        c: str = "three"
        d: typing.Dict[str, int]

    schema = {"a": Boolean(), "b": Integer(), "c": String(), "d": Object(properties={
        "e": Integer(),
        "f": Integer()
    }, additional_properties=False)}

    result1 = {"a": True, "b": 1, "d": {"e": 2}}
    r1, e1 = Model.parse_obj(
        result1,
        schema=schema,
        validate=True,
        extra=False
    )
    assert not isinstance(r1, ValidationError)

# Generated at 2022-06-12 15:44:35.699520
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    testField = Field()
    assert testField.get_default_value() == 0

# Generated at 2022-06-12 15:44:42.952121
# Unit test for constructor of class String
def test_String():
    s = String(title="title", description="description")
    assert s.title == "title"
    assert s.description == "description"
    assert not s.allow_null
    assert s.trim_whitespace
    assert s.allow_blank
    assert not hasattr(s, "default")
    assert s.max_length is None
    assert s.min_length is None
    assert s.pattern is None
    assert s.pattern_regex is None
    assert s.format is None
    assert not hasattr(s, "value")



# Generated at 2022-06-12 15:44:47.428137
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {"key1": String(),"key2": String()}
    additional_properties = String()
    minimum = 2
    maximum = 4
    required = ["key1", "key2"]

    my_Object = Object(properties=properties, additional_properties=additional_properties, min_properties=minimum, max_properties=maximum, required = required)

    val = {"key1":"something", "key2":"something", "key3":"something"}
    my_Object.validate(val)




# Generated at 2022-06-12 15:44:50.552325
# Unit test for method validate of class Object
def test_Object_validate():
    with pytest.raises(ValidationError):

        value = ["a", "b"]
        field = Object()
        field.validate(value)


# Generated at 2022-06-12 15:45:09.182135
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value()



# Generated at 2022-06-12 15:45:11.684729
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_field = Choice(choices=["1", "2"])
    print(choice_field.validate("1"))
    print(choice_field.validate("2"))
    print(choice_field.validate("3"))
        
test_Choice_validate()



# Generated at 2022-06-12 15:45:18.579373
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Schema
    from typesystem import types
    from typesystem import validators

    class TestType(types.Type):
        pass

    class TestType2(types.Type):
        pass

    class TestSchema(Schema):
        a = TestType | TestType2
        b = TestType | validators.Minimum(1)
        c = TestType | TestType2 | None
        
    assert(isinstance(TestSchema.fields["a"], Union))
    assert(isinstance(TestSchema.fields["b"], Union))
    assert(isinstance(TestSchema.fields["c"], Union))



# Generated at 2022-06-12 15:45:22.375205
# Unit test for method validate of class Choice
def test_Choice_validate():
    a = Choice(choices=[("m", "male"), ("f", "female")])
    if a.validate('m') != "m":
        raise AssertionError("validate of class Choice failed")



# Generated at 2022-06-12 15:45:33.289423
# Unit test for constructor of class Array
def test_Array():
    A = Array()
    assert A.items is None
    assert A.additional_items is False
    assert A.min_items is None
    assert A.max_items is None
    assert A.unique_items is False

    A = Array(items=[String()])
    assert isinstance(A.items, list)
    assert len(A.items) == 1
    assert isinstance(A.items[0], Field)
    assert A.additional_items is False
    assert A.min_items is 1
    assert A.max_items is 1
    assert A.unique_items is False

    A = Array(items=String())
    assert isinstance(A.items, Field)
    assert A.additional_items is False
    assert A.min_items is None
    assert A.max_items is None

# Generated at 2022-06-12 15:45:37.145009
# Unit test for method validate of class Number
def test_Number_validate():
    f = Number(minimum=5)
    assert f.validate(5) == 5
    try:
      f.validate(1)
      assert False
    except ValidationError:
      pass


# Generated at 2022-06-12 15:45:40.859882
# Unit test for method validate of class Array
def test_Array_validate():
    try:
        class User(BaseModel):
            email: str
            active: bool = True
        class Data(BaseModel):
            users: typing.List[User] = None
            user_data: typing.Dict[str, typing.List[int]] = None
        data = Data(users=[User(email="a@gmail.com")], user_data={"a": [1]})
        assert data.users[0].active == True
    except (AssertionError, AttributeError, NameError, TypeError, ValueError) as e:
        print(e)
        raise e

# Generated at 2022-06-12 15:45:49.644727
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test_case1: test the successful case
    choices = ["option1"]
    field = Choice(choices=choices)
    result = field.validate('option1')
    expected = 'option1'
    assert result == expected
    # test_case2: test the fail case
    choices = ["option1"]
    field = Choice(choices=choices)
    result = field.validate('option2')
    expected = None
    assert result == expected
    # test_case3: test the case when value is null
    choices = ["option1"]
    field = Choice(choices=choices)
    result = field.validate(None)
    expected = None
    assert result == expected


# Generated at 2022-06-12 15:45:57.563143
# Unit test for method validate of class String
def test_String_validate():
    a = String()
    b = String(max_length=20)
    c = String(pattern=r"^[A-Z]")
    d = String(format='uuid')
    e = String(format='date')
    assert a.validate("123")=="123"
    assert a.validate("1")=="1"
    assert a.validate("")==""
    assert a.validate(None) is None
    assert a.validate(123)=="123"
    assert b.validate(None) is None
    assert b.validate("123")=="123"
    assert b.validate("1")=="1"
    assert b.validate("")==""
    assert b.validate("123456789012345678901") is None
    assert c.validate

# Generated at 2022-06-12 15:46:10.090887
# Unit test for method validate of class Array
def test_Array_validate():
    with pytest.raises(ValidationError):
        field = Array(
            required=True,
            items=String(required=True),
            additional_items=False,
            min_items=1,
            max_items=3,
            unique_items=False
        )
        field.validate(value=1)
    with pytest.raises(ValidationError):
        field = Array(
            required=True,
            items=String(required=True),
            additional_items=False,
            min_items=1,
            max_items=3,
            unique_items=False
        )
        field.validate(value=[])

# Generated at 2022-06-12 15:46:22.914821
# Unit test for method validate of class String
def test_String_validate():
    s = String(allow_null=True)
    assert s.validate(None) is None
    assert s.validate('') is None
    s = String(allow_blank=True)
    assert s.validate(None) is ''
    assert s.validate('a') is 'a'
    s = String(trim_whitespace=True)
    assert s.validate(' a ') is 'a'
    assert s.validate(' ') is ''
    s = String(allowed_blank=False)
    with pytest.raises(ValidationError):
        s.validate('')
    s = String(allow_null=False, allow_blank=True)
    with pytest.raises(ValidationError):
        s.validate(None)
    assert s.validate('')

# Generated at 2022-06-12 15:46:25.289035
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(1, allow_null=False)



# Generated at 2022-06-12 15:46:26.991479
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate("abc") == "abc"



# Generated at 2022-06-12 15:46:31.721957
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()

    assert field.get_default_value() is NO_DEFAULT

    field.default = "foo"
    assert field.get_default_value() == "foo"

    def fn():
        return "bar"
    field.default = fn
    assert field.get_default_value() == "bar"



# Generated at 2022-06-12 15:46:33.578772
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(allow_null=True)
    assert choice.validate(value=None) is None


# Generated at 2022-06-12 15:46:36.658366
# Unit test for method validate of class Choice
def test_Choice_validate():
    f1 = Choice(choices=['a','b'])
    v1 = 'c'
    r1 = f1.validate(v1)
    assert isinstance(r1, ValidationError)



# Generated at 2022-06-12 15:46:40.464611
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_instance = Choice(name="Choice")
    test_get_error_text = test_instance.get_error_text
    # test null value
    assert test_get_error_text("null") == "May not be null."
    # test required value
    assert test_get_error_text("required") == "This field is required."
    # test choice value
    assert test_get_error_text("choice") == "Not a valid choice."



# Generated at 2022-06-12 15:46:46.577650
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=[(1, "a"), (2, "b"), (3, "c")])
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(3) == 3

    assert field.validate(None) == None
    assert field.validate(4) == None


# Generated at 2022-06-12 15:46:48.127244
# Unit test for constructor of class Const
def test_Const():
    assert Const(5).const == 5


if __name__ == "__main__":
    import doctest
    import unittest

    doctest.testmod()
    unittest.main()

# Generated at 2022-06-12 15:46:50.597838
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    myField = Boolean()
    result = myField.validate(1)
    assert result == True    
    

# Generated at 2022-06-12 15:47:03.120811
# Unit test for method validate of class Array
def test_Array_validate():
    # test 1
    schema = Array(items = Integer(), min_items = 0, max_items = 2)
    # 2 elements
    array = [0, 1]
    assert schema.validate(array) == [0, 1]
    # under min length
    array = []
    try:
        schema.validate(array)
        assert False
    except Exception as ex:
        assert str(ex) == "Must not be empty."
    # over max length
    array = [0, 1, 2]
    try:
        schema.validate(array)
        assert False
    except Exception as ex:
        assert str(ex) == "Must have no more than 2 items."

    # test 2
    schema = Array(items = [Integer(), String()], min_items = 1, max_items = 2)
    # 1 element

# Generated at 2022-06-12 15:47:15.838926
# Unit test for method validate of class Array
def test_Array_validate():
    
    obj = Array(items = [String(), Boolean()], min_items = 1)
    
    assert obj.validate(None, strict = False) == None
    assert obj.validate("a", strict = False) == None
    assert obj.validate([1,2], strict = False) == None
    assert obj.validate(["",""], strict = False) == None
    
 
    
    try:
        obj.validate(None, strict = True) 
    except ValidationError as e:
        error_msg = e.messages()
        assert error_msg[0].text == "May not be null."
        assert error_msg[0].code == "null"
        assert error_msg[0].index == []
    

# Generated at 2022-06-12 15:47:20.286869
# Unit test for method validate of class Choice
def test_Choice_validate():
    ch = Choice(name="test", choices=["a", "b"])
    assert ch.validate("a") == "a"
    assert ch.validate("b") == "b"
    try:
        ch.validate("c") == "c"
    except ValidationError:
        assert True


# Generated at 2022-06-12 15:47:26.712814
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	title_str="Title"
	des_str="Description"

	f1=Field(title=title_str, description=des_str)
	
	res=f1.get_default_value()
	assert res==None

	f1.default={"a":"b"}

	res=f1.get_default_value()
	assert res=={"a":"b"}

	def fun():
		return "a"
	
	f1.default=fun

	res=f1.get_default_value()
	assert res=="a"


# Generated at 2022-06-12 15:47:30.389132
# Unit test for constructor of class Choice
def test_Choice():
    f = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert f.validate("") == None


# Generated at 2022-06-12 15:47:34.527038
# Unit test for method __or__ of class Field
def test_Field___or__():
    # we put this in a method so pylint will import the field classes.
    # pylint: disable=unused-variable
    from typesystem.fields import (
        Boolean,
        Constant,
        Date,
        DateTime,
        Float,
        Integer,
        Number,
        String,
        Time,
        UUID,
        Union,
    )
    assert (String() | Boolean()) is not None


# Generated at 2022-06-12 15:47:46.897538
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    method = Boolean(allow_null=True).validate
    assert method(None) == None
    assert method(True) == True
    assert method(False) == False
    assert method("true") == True
    assert method("tRue") == True
    assert method("false") == False
    assert method("fAlse") == False
    assert method("null") == None
    assert method("None") == None
    assert method("") == None
    assert method(1) == True
    assert method(0) == False
    # assert method(1.1) == 1.1
    # assert Boolean.validate(None, allow_null=True) == None
    # assert Boolean.validate(None, allow_null=False) == False
    # assert Boolean.validate(True) == True
    # assert Boolean.validate(True

# Generated at 2022-06-12 15:47:58.592595
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Boolean(Field):
        errors = {}
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            raise NotImplementedError()  # pragma: no cover
    class String(Field):
        errors = {}
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            raise NotImplementedError()  # pragma: no cover
    boolean = Boolean(title='', description='')
    string = String(title='', description='')
    union = boolean | string
    assert isinstance(union,Union)
    assert len(union.any_of)==2
    assert boolean in union.any_of
    assert string in union.any_of
    union2 = union | Boolean(title='', description='')

# Generated at 2022-06-12 15:48:05.748690
# Unit test for method validate of class Object

# Generated at 2022-06-12 15:48:11.407256
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    assert s.serialize('12345') == '12345' # condition 1: obj == '12345'
    assert s.serialize(12345) == '12345' # condition 2: obj == 12345
    assert s.serialize(None) == None # condition 3: obj == None
    
    

# Generated at 2022-06-12 15:48:26.248652
# Unit test for method serialize of class String
def test_String_serialize():
    
    # test case 1: obj:str
    instance_1 = String()
    instance_1_res =  instance_1.serialize("string")
    assert instance_1_res == "string"
    
    # test case 2: obj:datetime.date
    instance_2 = String(format="date")
    instance_2_res =  instance_2.serialize("2020-07-01")
    assert instance_2_res == "2020-07-01"
    
    # test case 3: obj:datetime.time
    instance_3 = String(format="time")
    instance_3_res =  instance_3.serialize("12:00")
    assert instance_3_res == "12:00"
    
    # test case 4: obj: datetime.datetime

# Generated at 2022-06-12 15:48:30.603809
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=['a', 'b'])
    assert('a' == c.validate('a'))
    assert(None == c.validate(None))
    assert(None == c.validate('', strict=False))
    # ValueError: too many values to unpack (expected 2)
    # assert(c.validate('c'))    
    

# Generated at 2022-06-12 15:48:36.424366
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic import BaseModel
    from pydantic.error_wrappers import ValidationError
    from pydantic.fields import Field
    from pydantic.types import conint
    
    
    schema = Field(None, alias='schema')
    schema = Union(any_of=[schema,conint ])
    
    
    value = 3
    
    
    validated, error = schema.validate_or_error(value, strict = False)

# Generated at 2022-06-12 15:48:48.774141
# Unit test for method validate of class Array

# Generated at 2022-06-12 15:48:52.365947
# Unit test for method validate of class Choice
def test_Choice_validate():
    fields = Choice(choices = ['1','2','3'])
    for i in range(4):        
        assert fields.validate_or_error(str(i)).value == i



# Generated at 2022-06-12 15:49:04.096795
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=["CAS","EMP","STD"])
    # Test constructor_1
    assert choice.choices==[('CAS', 'CAS'), ('EMP', 'EMP'), ('STD', 'STD')]
    # Test constructor_2
    choice_2 = Choice(choices=[["CAS","CAS"],["EMP","EMP"],["STD","STD"]])
    assert choice_2.choices==[('CAS', 'CAS'), ('EMP', 'EMP'), ('STD', 'STD')]
    # Test constructor_3
    choice_3 = Choice(choices=[("CAS","CAS"),("EMP","EMP"),("STD","STD")])
    assert choice_3.choices==[('CAS', 'CAS'), ('EMP', 'EMP'), ('STD', 'STD')]
    

# Generated at 2022-06-12 15:49:09.708731
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field() | Field() == Union(any_of=[Field(), Field()])
    assert Field() | Union(any_of=[Field()]) == Union(any_of=[Field(), Field()])
    assert Union(any_of=[Field()]) | Field() == Union(any_of=[Field(), Field()])

