

# Generated at 2022-06-12 15:40:28.879843
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field(title='', description='')
    field2 = Field(title='', description='')
    field1 | field2



# Generated at 2022-06-12 15:40:34.746647
# Unit test for method validate of class String

# Generated at 2022-06-12 15:40:40.032670
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('a', 'b'), ('c', 'd')])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'a'
    assert choice.validate('c') == 'c'
    assert choice.validate('d') == 'c'


# Generated at 2022-06-12 15:40:44.322751
# Unit test for method serialize of class Array
def test_Array_serialize():
    class S(Array):
        def serialize(self, obj):
            return [self.serializer.serialize(value) for value in obj]
    class F(Field):
        def serialize(self, obj):
            return obj if isinstance(obj, int) else 1
    array = S(items=[F(), F()])
    assert array.serialize([1, 2]) == [1, 2]
    assert array.serialize(['a', 'b']) == [1, 1]



# Generated at 2022-06-12 15:40:56.271529
# Unit test for method validate of class Array
def test_Array_validate():
    LIST_DATA = [1, 2, 3]
    OBJ_DATA = {'a': 1, 'b': 2}
    EMPTY_LIST = []
    EMPTY_OBJ = {}
    EMPTY_STR = ''
    NONE_OBJ = None
    # single item
    obj_field = Integer()
    assert obj_field.validate(1) == 1
    # list of single item
    obj_field = Array(items=obj_field)
    assert obj_field.validate(LIST_DATA) == LIST_DATA
    # list of dict
    obj_field = Array(items=Object(properties=OBJ_DATA))
    assert obj_field.validate([OBJ_DATA]) == [OBJ_DATA]
    # list of dict with NONE

# Generated at 2022-06-12 15:41:04.083538
# Unit test for method validate of class Array
def test_Array_validate():
    class TestClass(unittest.TestCase):
        def test_validate_default(self):
            obj = Array()
            self.assertEqual(obj.validate(['hello','world']), obj.validate(['hello','world']))
            self.assertEqual(obj.validate('hello'),obj.validate('hello'))
            
    testCase = TestClass()
    testCase.test_validate_default()
    print("test_Array_validate: OK")


# Generated at 2022-06-12 15:41:12.377715
# Unit test for method validate of class String
def test_String_validate():
    field = String(default = '',title = '',description = '',allow_null = False)
    value = field.validate('123')
    assert value == '123', 'Value should be 123'

    # Value is of type int
    value = field.validate(123)
    assert value is None, 'Value should be None'
    
    # Value is of type float
    value = field.validate(112.32)
    assert value is None, 'Value should be None'
    
    # Value is of type float and allow_null is set to True
    field = String(default = '',title = '',description = '',allow_null = True)
    value = field.validate(112.32)
    assert value is None, 'Value should be None'
    
    # Value is of type float, allow_null is

# Generated at 2022-06-12 15:41:14.381237
# Unit test for method validate of class Array
def test_Array_validate():
    # unit test for validate method
    d = Array(max_items=7)
    assert d.validate([1, 2]) == [1, 2]

# Generated at 2022-06-12 15:41:19.470383
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice  = Choice(choices=("abc", "def"))
    assert choice.validate("abc") == "abc"
    with pytest.raises(ValidationError):
        choice.validate("cba")



# Generated at 2022-06-12 15:41:20.754747
# Unit test for method validate of class Number
def test_Number_validate():
    field = Number()
    value = 100
    assert field.validate(value) == 100



# Generated at 2022-06-12 15:41:54.428484
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    choice.allow_null = True
    assert choice.validate(None) == None


# Generated at 2022-06-12 15:41:59.124543
# Unit test for method validate of class Array
def test_Array_validate():
    class MySchema(Schema):
        values = Array(min_items = 2)

    schema = MySchema()
    schema.validate({"values": [1,2]})

    with pytest.raises(ValidationError):
        schema.validate({"values": [1]})

# Generated at 2022-06-12 15:42:02.328992
# Unit test for method validate of class Union
def test_Union_validate():
    any_tel_number = Union([
        Integer(minimum=10000000000, maximum=19999999999),
        Integer(minimum=20000000000, maximum=29999999999),
        Integer(minimum=50000000000, maximum=59999999999),
    ])
    validated_val, error = any_tel_number.validate_or_error(12345678901)
    assert error
    assert validated_val is None
    validated_val, error = any_tel_number.validate_or_error(19999999999)
    assert not error
    assert validated_val == 19999999999


# Generated at 2022-06-12 15:42:05.232606
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        "name": Fields.Str(required=True),
        "email": Fields.Email(required=True),
        "age": Fields.Int(required=True),
    }
    obj = Object(properties=properties)
    input_val = {"name": "John Doe", "email": "john@example.com", "age": 31}
    obj.validate(input_val)

test_Object_validate()


# Generated at 2022-06-12 15:42:13.529153
# Unit test for method __or__ of class Field
def test_Field___or__():
    def method(self, other):
        return self | other

    class Field1(Field):
        pass
    class Field2(Field):
        pass
    class Field3(Field):
        pass
    class Field4(Field):
        pass
    class Field5(Field):
        pass
    class Field6(Field):
        pass

    assert method(Field1(), Field2()) == Union([Field1(), Field2()])
    assert method(Union([Field3(), Field4()]), Field5()) == Union([Field3(), Field4(), Field5()])
    assert method(Field6(), Union([Field3(), Field4()])) == Union([Field6(), Field3(), Field4()])

# Generated at 2022-06-12 15:42:23.297917
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice1 = Choice(choices=[("123", "456")])
    choice1.validate("123", strict=False) #should not raise an error
    choice2 = Choice(choices=[("123", "456")], allow_null=True)
    choice2.validate("123", strict=False) #should not raise an error
    choice3 = Choice(choices=[("123", "456"), ("456", "123")])
    choice3.validate("123", strict=False) #should not raise an error
    choice3.validate("456", strict=False) #should not raise an error
    choice4 = Choice(choices=[("123", "456"), ("456", "123")], allow_null=True)
    choice4.validate("123", strict=False) #should not raise an error

# Generated at 2022-06-12 15:42:27.053288
# Unit test for method serialize of class String
def test_String_serialize():
    string1 = String()
    testObject = string1
    testValue = ""
    result = testObject.serialize(testValue)
    assert result == '', "Failed to serialize String"


# Generated at 2022-06-12 15:42:38.935726
# Unit test for method validate of class Array
def test_Array_validate():
    from pydantic_schema.typing import JsonData

# Generated at 2022-06-12 15:42:40.519395
# Unit test for method serialize of class String
def test_String_serialize():
    myString = String()
    assert myString.serialize("") == ""


# Generated at 2022-06-12 15:42:43.598184
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=0).validate(1) == 1
    assert Number(minimum=10).validate(10.5) == 10.5
    assert Number(maximum=-100).validate(-100.5) == -100.5
    assert Number(multiple_of=5).validate(10) == 10

# Generated at 2022-06-12 15:43:06.744877
# Unit test for constructor of class Const
def test_Const():
    # const is not None so should not raise AssertionError
    const = Const(const=None)
    # const is None so should raise AssertionError
    with pytest.raises(AssertionError):
        const = Const(None)


# Generated at 2022-06-12 15:43:16.129777
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    '''
    This function is used to test the function get_default_value.
    
    Args:
        None.
    Returns:
        A dictself.
    '''
    field = Field()
    assert field.title == ""
    assert field.description == ""
    assert field.default == NO_DEFAULT
    assert field.allow_null == False
    field.title = "title"
    field.description = "description"
    assert field.title == "title"
    assert field.description == "description"
    
    
    
    
    

# Generated at 2022-06-12 15:43:18.391290
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert __name__ == '__main__'
# Created: 2019-06-14 19:24:19.382555
# Version: 0.3.1



# Generated at 2022-06-12 15:43:25.901878
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field(title = "", description = "")
    assert isinstance(field1, Field)
    field2 = Field(title = "", description = "")
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert isinstance(field3.any_of, list)
    assert len(field3.any_of) == 2
    assert isinstance(field3.any_of[0], Field)
    assert isinstance(field3.any_of[1], Field)



# Generated at 2022-06-12 15:43:31.579558
# Unit test for method validate of class Union
def test_Union_validate():
    from jsonschema.exceptions import ValidationError
    from jsonschema.schemas.json_schema import SCHEMA as schema
    
    # Create a schema instance
    schema_obj = schema()
    # Create a Union instance
    union = Union(any_of = [
        Number(),
        String(format= 'date')
    ])
    
    data = 2
    actual = union.validate(value = data, strict = False)
    expected = data
    assert actual == expected
    
    data = '2018-01-01'
    actual = union.validate(value = data, strict = False)
    expected = data
    assert actual == expected
    
    data = '2017-01-01'

# Generated at 2022-06-12 15:43:33.372905
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()
    assert obj.validate([None,None, None, 3, 2, 1]) == [None, None, None, 3, 2, 1]


# Generated at 2022-06-12 15:43:36.129447
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert {'a': 1} | {'b': 2} == {'a': 1, 'b': 2}
    


# Generated at 2022-06-12 15:43:43.688807
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b"]).validate("a") == "a"
    with pytest.raises(ValidationError):
        Choice(choices=["a", "b"]).validate("3")
    assert Choice(allow_null=True).validate(None) == None
    assert Choice().validate(None) == None
    assert Choice().validate('') == None



# Generated at 2022-06-12 15:43:46.298335
# Unit test for method serialize of class Array
def test_Array_serialize():
    serializer = Array(items=Integer())
    res = serializer.serialize([1,2,3,4])
    assert res == [1,2,3,4]



# Generated at 2022-06-12 15:43:58.872962
# Unit test for method validate of class Union
def test_Union_validate():
    import json
    import csv

    # Test for type float
    field = Union(any_of=[Number(type="float")])
    if field.validate(3.3) != 3.3:
        print("Test 1.1 failed")
    if field.validate(3.3) == "3.3":
        print("Test 1.2 failed")
    if field.validate(3) == 3:
        print("Test 1.3 failed")
    if field.validate(True) == True:
        print("Test 1.4 failed")
    if field.validate(True) != False:
        print("Test 1.5 failed")

# Generated at 2022-06-12 15:44:17.622807
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("0", "1"),("1","2")]
    choice = Choice(choices=choices)
    assert choice.validate("1")  == "1"



# Generated at 2022-06-12 15:44:22.611586
# Unit test for constructor of class Choice
def test_Choice():
    choices = [("key1", "value1"), ("key2", "value2"), ("key3", "value3")]
    choice = Choice(choices=choices)
    assert choice.choices == [(("key1", "value1"), ("key2", "value2"), ("key3", "value3"))]


# Generated at 2022-06-12 15:44:33.665711
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test Array with multiple items
    serializer = Array(
        items=[Int(), String()])
    assert serializer.serialize([1, "2"]) == [1, "2"]
    assert serializer.serialize(["1", "2"]) == [1, "2"]
    assert serializer.serialize(["1", 2]) == [1, "2"]

    # Test Array with single item
    serializer = Array(items=Int())
    assert serializer.serialize([1, 2]) == [1, 2]
    assert serializer.serialize(["1", 2]) == [1, 2]

    # Test Array with no item
    serializer = Array()
    assert serializer.serialize([1, 2]) == [1, 2]

# Generated at 2022-06-12 15:44:43.611598
# Unit test for method validate of class Union
def test_Union_validate():
    test_field1 = String(format="email")
    test_field2 = String(format="url")
    test_field3 = String(format="ipv4")
    test_field4 = String(format="ipv6")
    test_union1 = Union([test_field1,test_field2,test_field3,test_field4])
    assert test_union1.validate("ahmed.sabry@gmail.com") == "ahmed.sabry@gmail.com", "Error"
    assert test_union1.validate("ahmed.com") == "ahmed.com", "Error"
    assert test_union1.validate("127.0.0.1") == "127.0.0.1", "Error"

# Generated at 2022-06-12 15:44:51.577390
# Unit test for method serialize of class Array
def test_Array_serialize():
    if not isinstance(field, Array):
        print(f"expected : <class 'calmjs.schema.fields.Array'>")
        print(f"actual : {type(field)}")
        raise AssertionError()
    if field.errors != {'max_items': 'Must have no more than {max_items} items.', 'unique_items': 'Items must be unique.', 'required': 'This field is required.', 'min_items': 'Must have at least {min_items} items.', 'additional_items': 'May not contain additional items.', 'null': 'May not be null.', 'empty': 'Must not be empty.', 'type': 'Must be an array.'}:
        print(f"expected : {field.errors}")
        print(f"actual : {field.errors}")
        raise Assert

# Generated at 2022-06-12 15:44:54.432598
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=String())
    assert field.serialize(["foo", "bar"]) == ["foo", "bar"]


# Generated at 2022-06-12 15:44:56.652544
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = Field()
    f2 = Field()
    Union1 = f1 | f2
    assert type(Union1) == Union
    assert len(Union1.any_of) == 2
    Union2 = f1 | f2 | f1



# Generated at 2022-06-12 15:44:58.887494
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(max_items=2)
    assert field.serialize([[1,2],[3,4]]) == [[1,2],[3,4]]


# Generated at 2022-06-12 15:45:04.231668
# Unit test for method validate of class Object
def test_Object_validate():
# Value is None and Variable allow_null is True
    properties = {"a" : 1, "b" : Number()}
    pattern_properties={}
    additional_properties = True
    property_names = None
    min_properties = None
    max_properties = None
    required = []
    allow_null = True
    obj = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required, allow_null=allow_null)
    assert obj.validate(None, strict=False) == None


# Value is None and Variable allow_null is False
    properties = {"a" : 1, "b" : Number()}
    pattern_properties={}
    additional_properties = True


# Generated at 2022-06-12 15:45:10.518839
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_default1 = Field(default="1234")
    assert test_default1.get_default_value() == "1234"
    test_default2 = Field(default=lambda: "5678")
    assert test_default2.get_default_value() == "5678"
# Testing for method get_error_text of class Field

# Generated at 2022-06-12 15:45:35.771013
# Unit test for method validate of class Array
def test_Array_validate():
    # Test to validate the array with array of keys
    validator = Array()
    value_1 = [1, 2, 3, 4]
    print(validator.validate(value_1))

    validator = Array(items=[1, 2, 3, 4], min_items=2)
    value_2 = [3, 3, 3]
    print(validator.validate(value_2))

    # Test to validate the array with minimal 
    validator = Array(items=[Integer(minimum=4, maximum=8)], min_items=2)
    value_3 = [4, 5, 6, 7]
    print(validator.validate(value_3))

    validator = Array(items=[1, 2, 3, 4], min_items=2, max_items=4)

# Generated at 2022-06-12 15:45:41.082106
# Unit test for method validate of class Choice
def test_Choice_validate():
    #Tests that Choice.validate raises a ValidationError when the input is not valid.
    #This input is the string 'two' that doesn't belong to the sequence ['zero', 'one'].
    choice = Choice(choices=['zero', 'one'])
    with pytest.raises(ValidationError):
        choice.validate('two')



# Generated at 2022-06-12 15:45:43.507191
# Unit test for method validate of class Choice
def test_Choice_validate():
    f = Choice([("A", "A")])
    assert f.validate("A") == "A"


# Generated at 2022-06-12 15:45:52.610207
# Unit test for method validate of class Array
def test_Array_validate():
    # positive cases
    try:
        Array().validate([1, 2])
    except ValidationError:
        assert False
    else:
        assert True

    try:
        Array().validate([])
    except ValidationError:
        assert False
    else:
        assert True

    # negative cases
    with pytest.raises(ValidationError):
        Array().validate(None)

    with pytest.raises(ValidationError):
        Array().validate({})

    with pytest.raises(ValidationError):
        Array().validate(1)

    # with specific items type
    try:
        Array(items=Integer()).validate([1, 2])
    except ValidationError:
        assert False
    else:
        assert True

    # with specific items type

# Generated at 2022-06-12 15:45:59.553084
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()
    assert obj.validate(1) == [1]
    assert obj.validate([1,2,3]) == [1,2,3]
    try:
        obj.validate(None)
        assert False
    except ValidationError:
        pass
    try:
        obj.validate('a')
        assert False
    except ValidationError:
        pass

    obj = Array(max_items=2)
    assert obj.validate('a') == ['a']
    assert obj.validate(['a','b']) == ['a','b']
    try:
        obj.validate(['a','b','c'])
        assert False
    except ValidationError:
        pass

    obj = Array(min_items=2)

# Generated at 2022-06-12 15:46:11.079705
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices = [("A", "A"), ("B", "B")]).validate("A" ) == "A"
    # Test when value is equal to an allowed choice
    assert Choice(choices = [("A", "A"), ("B", "B")]).validate("B" ) == "B"
    # Test when value is equal to an allowed choice
    assert Choice(choices = [("A", "A"), ("B", "B")]).validate("C" ) == None
    # Test when value is not equal to any allowed choice
    assert Choice(choices = [("A", "A"), ("B", "B")], allow_null = True).validate(None) == None
    # Test when value is equal to null and field allows null

# Generated at 2022-06-12 15:46:16.631386
# Unit test for method validate of class Object
def test_Object_validate():
    assert Object(properties={'name': String(max_length=32, allow_blank=True)})\
        .validate_or_None({'name': 'John'}) == {'name': 'John'}

# Generated at 2022-06-12 15:46:24.194896
# Unit test for method validate of class Object
def test_Object_validate():
    # test bed data
    value = None
    properties = properties={1:"chandler",2:"monica"}
    pattern_properties = pattern_properties={3:"ross",4:"racheal"}
    additional_properties = additional_properties = False
    property_names = property_names = None
    min_properties = min_properties = None
    max_properties = max_properties = None
    required = required = None
    strict = strict = False
    # test case 1
    test_object = Object(properties,pattern_properties,additional_properties,property_names,min_properties,max_properties,required)
    assert test_object.validate(value,strict) == None 
    assert test_object.allow_null == True
    # test case 2

# Generated at 2022-06-12 15:46:34.293646
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Create a Field instance a
    a = Field(title="", description="")
    # Create a Field instance b
    b = Field(title="", description="")
    # Create a Field instance c
    c = Field(title="", description="")
    assert a._creation_counter == 0
    assert b._creation_counter == 1
    assert c._creation_counter == 2
    # Try to invoke the or operator
    or_result = a | b | c
    # Check the validity of or_result
    assert isinstance(or_result, Union)
    assert len(or_result.any_of) == 3
    assert or_result.any_of[0] == a
    assert or_result.any_of[1] == b
    assert or_result.any_of[2] == c

    # TODO: consider testing

# Generated at 2022-06-12 15:46:43.509597
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Case 1:
    field_1 = Field()
    field_2 = Field()
    field_3 = Field()
    field_4 = Field()
    union_1 = Union(any_of=[field_1, field_2])
    union_2 = Union(any_of=[field_3, field_4])
    union_3 = Union(any_of=[field_1, field_2, field_3, field_4])
    result = field_1 | field_2 | field_3 | field_4
    expected = union_3
    assert result == expected
    # Case 2:
    result = field_1 | field_2 | union_2
    expected = union_3
    assert result == expected
    # Case 3:
    result = union_1 | field_3 | field_4
    expected = union_3

# Generated at 2022-06-12 15:46:53.718515
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("A", "A")])
    assert field.validate("A") == "A"
    with pytest.raises(ValidationError):
        assert field.validate("B")


# Generated at 2022-06-12 15:47:00.623914
# Unit test for method validate of class Array
def test_Array_validate():
    '''
    Test method validate of class Array
    '''
    String = String()
    String_required = String(required=True)
    String_unique = String(unique=True)
    String_unique_False = String(unique=False)
    
    Array_equal_3_String = Array(items=String,min_items=3,max_items=3)
    Array_String_unique = Array(items=String,unique_items=True)
    Array_String_unique_False = Array(items=String,unique_items=False)
    Array_String_required = Array(items=String_required)
    Array_String_required_unique = Array(items=String_required,unique_items=True)
    Array_String_required_unique_False = Array(items=String_required,unique_items=False)
   

# Generated at 2022-06-12 15:47:13.089528
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice=Choice()
    # the case with 'strict' equals False (default value)
    assert choice.validate(value=None, strict=False) == None
    # the case with 'strict' equals True
    assert choice.validate(value=None, strict=True) == None
    # function does not return correct value when input is a wrong type
    with pytest.raises(ValidationError):
        choice.validate(value=1.1, strict=False)
    with pytest.raises(ValidationError):
        choice.validate(value=1.1, strict=True)
    # function does not return correct value when input is an empty string
    choice.allow_null = False
    with pytest.raises(ValidationError):
        choice.validate(value="", strict=False)

# Generated at 2022-06-12 15:47:23.635404
# Unit test for method validate of class Array
def test_Array_validate():
    msg = "The field <Array> is not valid."
    with pytest.raises(ValidationError, match=msg):
        f = Array(min_items=3)
        f.validate([1, 2])

    # Test max_items
    f = Array(max_items=3)
    f.validate([1]) # no error
    f.validate([1, 2, 3]) # no error
    with pytest.raises(ValidationError, match=msg):
        f.validate([1, 2, 3, 4])

    # Test min_items
    f = Array(min_items=3)
    f.validate([1, 2, 3])  # no error
    with pytest.raises(ValidationError, match=msg):
        f.validate([1])

    # Test additional

# Generated at 2022-06-12 15:47:24.853506
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert field.get_default_value() == "test"

# Generated at 2022-06-12 15:47:29.730934
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=3)
    assert field.get_default_value() == 3
    field = Field(default=lambda : 4)
    assert field.get_default_value() == 4



# Generated at 2022-06-12 15:47:30.696337
# Unit test for constructor of class String
def test_String():
    pass
#Unitest for Method validate of class String

# Generated at 2022-06-12 15:47:33.266040
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title="title")
    assert f.get_default_value() == None
    f.default = 1
    assert f.get_default_value() == 1
    f.default = lambda: 1
    assert f.get_default_value() == 1


# Generated at 2022-06-12 15:47:35.354551
# Unit test for method validate of class Choice
def test_Choice_validate():
    x = Choice(choices=[('1', 'role1'), ('2', 'role2')])
    assert x.validate('2') == '2'


# Generated at 2022-06-12 15:47:37.468536
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [1, 2, 3]
    field = Choice(choices)
    assert field.validate(1) == 1



# Generated at 2022-06-12 15:48:08.823061
# Unit test for method validate of class Number
def test_Number_validate():
    test_object = Number()
    test_case = (1,)
    result = test_object.validate(test_case)
    expected_result = (1,)
    assert result == expected_result
    



# Generated at 2022-06-12 15:48:10.898036
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title='Test Field')
    assert field.get_default_value() == None
    assert field.has_default() == False

# Generated at 2022-06-12 15:48:17.007372
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field0 = Field(title=0)
    field1 = Field(title=1, default=2)
    field2 = Field(title=2, default=lambda: 3)
    field3 = Field(title=3, default=lambda: lambda: 4)

    assert field0.get_default_value() == None
    assert field1.get_default_value() == 2
    assert field2.get_default_value() == 3
    assert field3.get_default_value() == 4


# Generated at 2022-06-12 15:48:25.238297
# Unit test for method validate of class Number
def test_Number_validate():
    # Case 1
    field = Number(minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, precision=None)
    value = 2
    strict = False
    assert field.validate(value, strict=strict)==value
    assert type(field.validate(value, strict=strict))==type(value)

    # Case 2
    field = Number(minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, precision=None)
    value = None
    strict = False
    assert field.validate(value, strict=strict)==None
    assert type(field.validate(value, strict=strict))==type(value)

    # Case 3

# Generated at 2022-06-12 15:48:28.417757
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = Text()
    f2 = Integer()
    assert f1.__or__(f2).__class__.__name__ == "Union"
# End unit test for method __or__ of class Field



# Generated at 2022-06-12 15:48:33.620246
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field0 = Field(default = 11)
    assert field0.get_default_value() == 11
    field1 = Field(default = 5)
    assert field1.get_default_value() == 5
    field2 = Field(default = 0)
    assert field2.get_default_value() == 0
    field3 = Field(default = -1)
    assert field3.get_default_value() == -1

# Generated at 2022-06-12 15:48:38.471538
# Unit test for method validate of class Object
def test_Object_validate():
    # case 1
    obj_validate = Object(
        properties= {
            "hello":Str(max_length=10),
        },
        pattern_properties ={"\d+": Str(max_length=10)},
        additional_properties = True,
        property_names = Str(pattern="^\w+$"),
        min_properties = 0,
        max_properties = None,
    )
    try:
        obj_validate.validate({"hello": "hi"})
        assert True
    except:
        assert False


# Generated at 2022-06-12 15:48:41.615405
# Unit test for method validate of class Choice
def test_Choice_validate():
    print("Start of test_Choice_validate")
    print("test_Choice_validate executed successfully")
    choices=[('Choice1', 'Choice2'),('Choice3', 'Choice4')]
    choice=Choice(choices=choices)
    print(choice.validate('Choice3'))

# Generated at 2022-06-12 15:48:48.306066
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    a = Field()
    assert a.get_default_value() is None

    a = Field(default = None)
    assert a.get_default_value() is None

    b = Field(default = Field)
    assert b.get_default_value() is Field
    
    c = Field(default = lambda: 1)
    assert c.get_default_value() is 1

# Generated at 2022-06-12 15:49:00.896668
# Unit test for method validate of class Object
def test_Object_validate():
    testField = Field('testField')
    class test:pass
    test_obj = test()

    testField.allow_null = False
    testField.required = []
    testField.description = 'testField'
    testField.allow_coerce = False
    testField.errors = {}
    testField.null_error = None
    testField.coerce_values = {}
    testField.coerce_null_values = {}

    assert testField.validate(None) == None
    assert testField.validate(True) == True
    assert testField.validate(False) == False
    assert testField.validate(True) == True
    assert testField.validate(123) == 123
    assert testField.validate(0) == 0