

# Generated at 2022-06-12 15:42:18.983166
# Unit test for method validate of class Union
def test_Union_validate():
  dic = {"email": "test@test.test", "password": "12345678"}
  schema = Union([
      Object(
          properties={
              "email": String(format="email"),
              "password": String(pattern=r"\d{8}"),
          },
          required=["email", "password"],
      ),
      Object(properties={"password": String(pattern=r"\d{8}")}, required=["password"]),
      Object(properties={"email": String(format="email")}, required=["email"]),
  ])
  assert schema.validate(dic) == dic
  assert schema.validate({"password": "12345678"}) == {"password": "12345678"}

# Generated at 2022-06-12 15:42:20.259701
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
   print ("test_Field_get_default_value successfully")

# Generated at 2022-06-12 15:42:28.256560
# Unit test for method validate of class Choice
def test_Choice_validate():
    c1 = Choice(required=True, choices=[('1','red'),('2','blue'),('3','green')])
    assert c1.validate('1') == '1'
    c2 = Choice(required=True, choices=['red','blue','green'])
    assert c2.validate('red') == 'red'
    c3 = Choice(required=False, choices=[('1','red'),('2','blue'),('3','green')])
    assert c3.validate('2') == '2'
    c4 = Choice(required=False, choices=['1','2','3'])
    assert c4.validate('3') == '3'
    c5 = Choice(required=False, choices=['1'])
    assert c5.validate('') == ''



# Generated at 2022-06-12 15:42:40.072414
# Unit test for method validate of class Union

# Generated at 2022-06-12 15:42:43.697945
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    def random_str():
        import string
        import random
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

    f = Field(title='User Name', description='Place for User Name', default=random_str)
    assert(f.get_default_value() != f.get_default_value())



# Generated at 2022-06-12 15:42:50.927824
# Unit test for method validate of class Union
def test_Union_validate():
    # Test cases for method validate of class Union
    # Input parameters:
    #   value: typing.Any = None
    #   strict: bool = False
    # Expected output: None
    value = None
    strict = False
    obj = Union(any_of=[])
    try:
        obj.validate(value, strict=strict)
    except ValidationError:
        pass



# Generated at 2022-06-12 15:43:00.970269
# Unit test for method validate of class Union

# Generated at 2022-06-12 15:43:04.941416
# Unit test for method validate of class Array
def test_Array_validate():
    item_field=Field()
    array=Array(items=item_field)
    validate_result=array.validate([1,2,3])
    assert validate_result==[1,2,3]


# Generated at 2022-06-12 15:43:16.899141
# Unit test for method validate of class Array
def test_Array_validate():
    # Edge case: when value is None, if self.allow_null is True, return None
    field = Array(allow_null=True)
    assert field.validate(None) == None

    # Edge case: when value is None, if self.allow_null is False and self.default is not None, return self.default
    field = Array(default="test")
    assert field.validate(None) == "test"

    # Edge case: when value is None, if self.allow_null is False and self.default is None, raise error
    field = Array()
    with pytest.raises(ValidationError) as exc_info:
        field.validate(None)
    assert exc_info.type == ValidationError
    assert exc_info.value.messages[0].code == "null"

    # when value is not

# Generated at 2022-06-12 15:43:19.729650
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice1 = Choice(choices=[("a", "b"), ("c", "d"), ("e", "f")])
    print(choice1.validate("a"))
    print(choice1.validate("g"))




# Generated at 2022-06-12 15:43:51.828973
# Unit test for method __or__ of class Field
def test_Field___or__():
    class TestClass:
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
        field_4 = Field()
        field_5 = Field()
        field_6 = Field()

    assert isinstance((TestClass.field_1 | TestClass.field_2 | TestClass.field_3), Union)
    assert (TestClass.field_1 | TestClass.field_2 | TestClass.field_3).any_of == [TestClass.field_1, TestClass.field_2, TestClass.field_3]

# Generated at 2022-06-12 15:43:59.513723
# Unit test for method validate of class Array
def test_Array_validate():
    """
    Test the validation of a field array
    """
    class UserSchema(Schema):
        name = String()
        email = String()

    class UsersSchema(Schema):
        users = Array(items=UserSchema, min_items=1, max_items=10, unique_items=True)
    #
    class Test():
        def test_test(self):
            user1 = {"name": "John", "email": "john@example.com"}
            user2 = {"name": "Mary", "email": "mary@example.com"}
            users = [user2, user1]
            try:
                schema = UsersSchema()
                schema.validate({"users": users})
            except ValidationError as e:
                assert e
    #
    t = Test()
    test_function = get

# Generated at 2022-06-12 15:44:01.190327
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default="test")
    assert field.get_default_value() == "test"

# Generated at 2022-06-12 15:44:14.078600
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_test = Choice()
    #check when the value is None and allow_null is false
    assert choice_test.validate(None, strict=False) == None
    #check when the value is None and allow_null is True
    choice_test.allow_null = True
    assert choice_test.validate(None, strict=False) == None
    #check when choice_test is a valid choice
    choice_test.choices = ["a"]
    assert choice_test.validate("a", strict=False) == "a"
    #check when choice_test is not a valid choice
    choice_test.choices = ["b"]
    assert choice_test.validate("a", strict=False) == None
    #check when value is "" and allow_null is true
    choice_test.allow_null = True

# Generated at 2022-06-12 15:44:16.345907
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    valueTest = Field(default=12)
    test = valueTest.get_default_value()
    assert test == 12



# Generated at 2022-06-12 15:44:19.521005
# Unit test for method __or__ of class Field
def test_Field___or__():
    other = int(10)
    f = Field()
    assert isinstance(f.__or__(other), Union)
    assert isinstance(f.__or__(f), Union)

# Generated at 2022-06-12 15:44:20.608668
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field() | Field()



# Generated at 2022-06-12 15:44:26.003715
# Unit test for method validate of class Array
def test_Array_validate():
    class Test():
        field = Array(
            items=Field(type="string", pattern=r"^[0-9]+$")
        )
    data = Test(field=["12345", "56789"])
    assert data.field == ["12345", "56789"]
    data = Test(field=["12345", "5679z"])
    assert data.field == ["12345", "5679z"]

# Generated at 2022-06-12 15:44:28.126244
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice(choices=["a", "b"]).validate(1)


# Generated at 2022-06-12 15:44:37.971835
# Unit test for method validate of class Array
def test_Array_validate():
    import pytest

    test = Array(
        title="Test Array",
        description="Array for testing",
        min_items=3,
        max_items=3,
    )

    # Minimum number of items is 3
    with pytest.raises(ValidationError) as error:
        test.deserialize([None, None])

    assert error.value.messages()[0].code == "min_items"

    # Maximum number of items is 3
    with pytest.raises(ValidationError) as error:
        test.deserialize([None, None, None, None])

    assert error.value.messages()[0].code == "max_items"

    # Success
    assert test.deserialize([None, None, None]) == [None, None, None]



# Generated at 2022-06-12 15:45:10.948052
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.allow_blank         == False
    assert s.trim_whitespace     == True
    assert s.max_length          == None
    assert s.min_length          == None
    assert s.pattern             == None
    assert s.format              == None
    assert s._creation_counter   == 0

    s = String(allow_blank=True)
    assert s.allow_blank         == True
    assert s.trim_whitespace     == True
    assert s.max_length          == None
    assert s.min_length          == None
    assert s.pattern             == None
    assert s.format              == None
    assert s._creation_counter   == 1

    s = String(trim_whitespace=False)
    assert s.allow_blank         == False
    assert s

# Generated at 2022-06-12 15:45:13.066651
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[1,2,3])
    assert(choice.validate(1)==1)


# Generated at 2022-06-12 15:45:20.830671
# Unit test for method validate of class Number
def test_Number_validate():
    # Testing for value null
    val1 = None
    assert Number().validate(val1) == None
    # Testing for value of length less than minimum length
    val2 = ""
    assert Number().validate(val2) == None
    # Testing for value of length greater than maximum length
    val3 = "123456789012"
    assert Number().validate(val3) == None
    # Testing for value of type string
    val4 = "1234"
    assert Number().validate(val4) == None
    # Testing for value of type integer
    val5 = 1234
    assert Number().validate(val5) == 1234
    # Testing for value of type float
    val6 = 12.34
    assert Number().validate(val6) == 12.34
    # Testing for value of type positive infinity
    val

# Generated at 2022-06-12 15:45:25.867445
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "b"), ("c", "d")])
    assert field.validate("a") == "a"
    assert field.validate("c") == "c"
    assert field.validate("") == None
    assert field.validate("d") == "d"



# Generated at 2022-06-12 15:45:35.965032
# Unit test for method validate of class Array
def test_Array_validate():
    class MyArray(Array):
        def __init__(self, min_items: int = None, max_items: int = None, **kwargs: typing.Any):
            super().__init__(min_items=min_items, max_items=max_items, **kwargs)
            self.items = Integer()

    class MyObject:
        def __init__(self):
            self.arr = MyArray()

        def validate(self):
            return self.arr.validate([1,2])

    obj = MyObject()

    # Case 1: Successful case
    result = obj.validate()
    assert result == [1,2]

    # Case 2: Failure case
    obj.arr.min_items = 3
    with pytest.raises(ValidationError):
        result = obj.validate()
   

# Generated at 2022-06-12 15:45:39.571203
# Unit test for method validate of class Object
def test_Object_validate():
    # When no exception is raised
    # Example 1: value is None and self.allow_null is True
    obj = Object(**{'allow_null': True})
    rst = obj.validate(None, strict=False)
    assert rst == None
    # Example 2: type(value) == dict and strict == False
    obj = Object()
    rst = obj.validate({}, strict=False)
    assert rst == {}

# Generated at 2022-06-12 15:45:47.398012
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array(min_items=1, max_items=2, unique_items=False, default=[] )
    try:
        res = arr.validate([1,2,3])
    except ValidationError as e:
        assert str(e) == "Must have no more than 2 items."
    else:
        raise Exception(f"The result '{res}' is unexpected")
    try:
        res = arr.validate([])
        assert res == []
    except ValidationError as e:
        raise Exception(f"The result '{res}' is unexpected")



# Generated at 2022-06-12 15:45:55.709915
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import Boolean, Integer, Schema
    from typesystem.typing import List

    schema_1 = Schema.of(
        Integer(minimum=3, maximum=4)
    )
    schema_2 = Schema.of(
        Integer(minimum=5, maximum=6)
    )
    union_1_2 = schema_1 | schema_2

    schema_3 = Schema.of(
        Boolean(title="a boolean field")
    )
    union_1_2_3 = union_1_2 | schema_3

    schema_4 = Schema.of(
        List(
            Integer(minimum=3, maximum=4),
            title="a list field",
            min_items=1,
            max_items=2
        )
    )

    union_1_2_3_

# Generated at 2022-06-12 15:46:06.162605
# Unit test for method validate of class String
def test_String_validate():
    string0 = String()
    # true
    assert string0.validate("hello") == "hello"
    # true
    assert string0.validate("sdkjhf") == "sdkjhf"
    # true
    assert string0.validate("sdfsdf") == "sdfsdf"
    # true
    assert string0.validate("sdkjhf") == "sdkjhf"
    # true
    assert string0.validate("") == ""
    try:
        string0.validate(1234)
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:46:14.093733
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(10) == 10
    assert number.validate(10, strict=False) == 10
    assert number.validate(10.0) == 10.0
    assert number.validate(10.0, strict=False) == 10.0
    with pytest.raises(ValidationError) as error:
        number.validate(False)
    assert error.value.code == 'type'
    with pytest.raises(ValidationError) as error:
        number.validate(False, strict=False)
    assert error.value.code == 'type'
    with pytest.raises(ValidationError) as error:
        number.validate(None)
    assert error.value.code == 'null'

# Generated at 2022-06-12 15:46:43.004688
# Unit test for method validate of class Number
def test_Number_validate():
    import math
    import random
    import numbers
    import sys

    # Valid int value
    test_value_int = 2

    # Valid float value
    test_value_float = 1.0

    # Invalid int value
    test_value_bad_int = "a"

    # Invalid float value
    test_value_bad_float = "a"

    # This function checks if the object passed is of numeric type.
    # 0 is false and 1 is true
    def check_is_num(value):
        if isinstance(value, numbers.Number):
            return 0
        else:
            return 1

    # This function checks if the object passed is an integer.
    # 0 is false and 1 is true

# Generated at 2022-06-12 15:46:54.429437
# Unit test for method validate of class String

# Generated at 2022-06-12 15:47:01.075292
# Unit test for method __or__ of class Field
def test_Field___or__():
    for a, b in [(1, 2), (3, 4), ("a", "b"), ("c", "d"), (None, None), ("", "")]:
        f = Field()
        assert id(f) == id(f | f)
        assert id(f) == id(f | Field())
        assert id(f) == id(Field() | f)
        assert id(f) == id(Field() | Field())
        assert id(f) == id(Union([f, f]))
        assert id(f) == id(Union([Field(), Field()]))
        assert id(f) == id(Union([f, Field()]))
        assert id(f) == id(Union([Field(), f]))
        assert id(f) == id(f | Union([f, Field()]))
        assert id(f)

# Generated at 2022-06-12 15:47:07.439469
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() is None
    assert Field(default="value").get_default_value() == "value"

    def _get_result():
        return "Hello"

    # Reason: cannot compare unorderable types: FunctionType, FunctionType
    assert Field(default=_get_result).get_default_value() == _get_result()

# Generated at 2022-06-12 15:47:16.628521
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["choice1", "choice2"])
    assert choice.validate(value="choice1") == 'choice1'
    assert choice.validate(value="choice2") == 'choice2'
    with pytest.raises(ValidationError) as ve:
        choice.validate(value='choice3')
    assert ve.value.detail == {'choice': 'Not a valid choice.'}
    with pytest.raises(ValidationError) as ve:
        choice.validate(value='')
    assert ve.value.detail == {'choice': 'Not a valid choice.'}



# Generated at 2022-06-12 15:47:26.234456
# Unit test for method validate of class Number
def test_Number_validate():
    from typesystem import String
    from typesystem import Number
    from typesystem import Array
    from typesystem import fields, types
    from typesystem import validate
    from typesystem import ValidationError

    def _test_integers():
        _test_integer_no_range(0)
        _test_integer_with_max(100, 100)
        _test_integer_with_min(100, None, 100)
        _test_integer_with_min_and_max(100, 100, 100, 100)
        _test_integer_with_multiple_of(100, 5)
        _test_integer_with_negative_min(100, None, -100)
        _test_integer_with_negative_max(100, -100)
        _test_integer_with_negative_multiple_of(100, -5)
       

# Generated at 2022-06-12 15:47:35.910193
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(123) == 123
    assert Number().validate(123.456) == 123.456
    assert Number().validate(True) == 1
    assert Number().validate(False) == 0
    assert Number().validate('123') == 123
    assert Number().validate('123.456') == 123.456
    assert Number().validate(None) == None
    # Invalid type
    try:
        Number().validate('abc')
    except Exception as e:
        assert str(e) == 'Must be a number.'
    # Invalid type
    try:
        Number().validate('123.456a')
    except Exception as e:
        assert str(e) == 'Must be a number.'
    # Invalid type

# Generated at 2022-06-12 15:47:48.851419
# Unit test for method validate of class Array
def test_Array_validate():
    # Case 1: items is a list of Field
    def _case1():
        class _Array(Array):
            def validate(self, value, strict = False):
                return super().validate(value)

        arr = _Array(items=[Integer(), String()])
        try:
            v = arr.validate([1, "abc", 2])
            assert v == [1, "abc", 2]
        except ValidationError as e:
            assert False

        try:
            v = arr.validate([1, 3, "abc"])
            assert False
        except ValidationError as e:
            assert True

        try:
            v = arr.validate(1)
            assert False
        except ValidationError as e:
            assert True
    
    # Case 2: items is single Field

# Generated at 2022-06-12 15:47:55.569992
# Unit test for constructor of class String
def test_String():
    assert String.__init__ is not Field.__init__
    assert String._creation_counter == 0
    s = String(allow_blank=True)
    assert s.allow_blank is True
    assert s._creation_counter == 1
    assert String._creation_counter == 2
    assert String.__init__ is Field.__init__
    s = String(allow_blank=True)
    assert s.allow_blank is True
    assert s._creation_counter == 4



# Generated at 2022-06-12 15:48:03.232919
# Unit test for method __or__ of class Field
def test_Field___or__():
    class String(Field):
        pass
    assert (String() | String()) | String() == Union([String(), String(), String()])
    assert String() | String() == Union([String(), String()])
    assert String() | String() | String() == Union([String(), String(), String()])
    assert String() | String() | String() | String() == Union([String(), String(), String(), String()])
    assert String() | String() | String() | String() | String() == Union([String(), String(), String(), String(), String()])
    # TODO assert String() | String() | String() | String() | String() | String() is equal to something



# Generated at 2022-06-12 15:48:24.389397
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["a", "b"])
    assert c.validate("b") == "b"
    try:
        c.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "null"



# Generated at 2022-06-12 15:48:31.696615
# Unit test for method validate of class Choice
def test_Choice_validate():
    unittest.TestCase().assertEqual(Choice(choices=["X","Y"], null=True).validate("X", strict=False), "X")
    unittest.TestCase().assertEqual(Choice(choices=["X","Y"], null=True).validate("", strict=False), "")
    unittest.TestCase().assertEqual(Choice(choices=["X","Y"], null=True).validate("Y", strict=False), "Y")
    unittest.TestCase().assertEqual(Choice(choices=["X","Y"], null=True).validate("Z", strict=False), "Z")



# Generated at 2022-06-12 15:48:40.294887
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    try:
        n.validate("not_a_number")
        assert False
    except ValidationError as e:
        assert e.code == "type"
    try:
        n.validate("1.0")
        assert False
    except ValidationError as e:
        assert e.code == "type"
    try:
        n.validate("NaN")
        assert False
    except ValidationError as e:
        assert e.code == "finite"
    try:
        n.validate("Inf")
        assert False
    except ValidationError as e:
        assert e.code == "finite"
    try:
        n.validate("Ninf")
        assert False
    except ValidationError as e:
        assert e.code == "finite"

# Generated at 2022-06-12 15:48:45.798484
# Unit test for method __or__ of class Field
def test_Field___or__():
    class DummyField(Field):
        pass
    f1 = DummyField()
    f2 = DummyField()
    f3 = DummyField()
    f4 = DummyField()
    assert f1 | f2 | f3 | f4 == Union(any_of=(f1, f2, f3, f4))


# Generated at 2022-06-12 15:48:54.096682
# Unit test for method __or__ of class Field
def test_Field___or__():
    from . import String, Integer
    from .union import Union
    x = String()
    y = Integer()
    result = x | y
    result = x | y
    assert isinstance(result, Union)
    result = y | x
    result = x | y
    result = x | y
    result = x | y
    result = x | y
    assert isinstance(result, Union)
    assert result.any_of == [x, y]



# Generated at 2022-06-12 15:49:01.940694
# Unit test for method __or__ of class Field
def test_Field___or__():
   field1 = Field()
   field2 = Field()
   field3 = Field()
   field4 = Field()
   field5 = Field()
   field6 = Field()
   field7 = Field()
   field8 = Field()
   field9 = Field()
   assert (field1 | field2 | field3 | field4 | field5 | field6 | field7 | field8 | field9).any_of == [field1, field2, field3, field4, field5, field6, field7, field8, field9]



# Generated at 2022-06-12 15:49:06.142181
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Test the case of default value is a value
    obj=Field(default=5)
    assert obj.get_default_value()==5
    # Test the case of default value is a function
    def testfunc():
        return 5
    obj=Field(default=testfunc)
    assert obj.get_default_value()==5


# Generated at 2022-06-12 15:49:11.144391
# Unit test for constructor of class String
def test_String():
    import unittest
    class TestString(unittest.TestCase):
        def test_String(self):
            data=None
            actual = String().validate(data, strict=False)
            expected = None
            self.assertEqual(actual, expected)
    unittest.main()

test_String()
