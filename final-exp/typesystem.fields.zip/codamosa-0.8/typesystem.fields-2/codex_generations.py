

# Generated at 2022-06-12 15:40:52.222123
# Unit test for method validate of class Union
def test_Union_validate():
    unit = Union(any_of= [Integer(),String()])
    validated, error = unit.validate_or_error("a")
    assert validated == "a"
    validated, error = unit.validate_or_error(1)
    assert validated == 1
    _, error = unit.validate_or_error(True)
    assert error.messages()[0].code == "union"

# Generated at 2022-06-12 15:41:03.208872
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
  # get the function to test
  function = Field.validate_or_error
  # For test coverage we need to test for different arguments:
  # - try with wrong type for value
  # assert that a ValidationError is raised
  try:
      function("string")
  except ValidationError:
      pass
  # assert that a ValidationError is raised
  try:
      function(1)
  except ValidationError:
      pass
  # assert that a ValidationError is raised
  try:
      function(False)
  except ValidationError:
      pass
  # assert that a ValidationError is raised
  try:
      function(dict())
  except ValidationError:
      pass
  # assert that a ValidationError is raised
  try:
      function(list())
  except ValidationError:
      pass


# Generated at 2022-06-12 15:41:11.757707
# Unit test for method validate of class Choice
def test_Choice_validate():
  calling_Choice_validate_with_null_for_value_results_in_ValueError = raises(
      ValidationError,
      lambda: Choice().validate(
          value=None
      )
  )
  assert True == ("null" in str(calling_Choice_validate_with_null_for_value_results_in_ValueError.value))
  #
  calling_Choice_validate_with_non_string_for_value_results_in_ValueError = raises(
      ValidationError,
      lambda: Choice(
          choices=["choice1"]
      ).validate(
          value=1
      )
  )
  assert True == ("choice" in str(calling_Choice_validate_with_non_string_for_value_results_in_ValueError.value))
  #
  calling_Choice

# Generated at 2022-06-12 15:41:15.177166
# Unit test for method serialize of class Array
def test_Array_serialize():
    print("Test Array serialize")
    import json
    schema = Array(minItems=1, items=Integer(minimum=0))
    serialized_data = schema.serialize([1, 2, 3])
    print(serialized_data)
    assert serialized_data == [1, 2, 3]
    print("")

# Generated at 2022-06-12 15:41:26.386938
# Unit test for method validate of class Union
def test_Union_validate():
    # Create a mock class
    class MockUnion_validate_0:
        def validate_or_error(self, value, strict):
            return None, None
    # Create a mock class
    class MockUnion_validate_1:
        def validate_or_error(self, value, strict):
            return None, None
    # Create a mock class
    class MockUnion_validate_2:
        def validate_or_error(self, value, strict):
            return None, None
    # Create a mock class
    class MockUnion_validate_3:
        def validate_or_error(self, value, strict):
            return None, None

    # Create a mock class
    class MockUnion_validate_4:
        def validate_or_error(self, value, strict):
            return None, None

    # Create a

# Generated at 2022-06-12 15:41:31.958314
# Unit test for method validate of class String
def test_String_validate():
    str_ = String(max_length = 8)
    assert str_.validate('string') == 'string'
    assert str_.validate('test') == 'test'
    assert str_.validate('stringlongerthan8') == 'stringlo'
    try:
        str_.validate(1)
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-12 15:41:40.434059
# Unit test for method validate of class Array

# Generated at 2022-06-12 15:41:45.327848
# Unit test for method validate of class Union
def test_Union_validate():
    # key = 'union'
    class Test_Union(Field):
        errors = {"union": "Did not match any valid type."}
    
    # value = "union"
    result = str(Test_Union(allow_null=False))
    assert result == "description: 'description', display_name: 'display_name', nullable: 'allow_null'"



# Generated at 2022-06-12 15:41:51.268418
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(
        allow_null=True, choices=[("0", "something"), ("1", "else")]
    )
    choice.validate(0)
    choice.validate(None)
    assert choice.validate("0") == "0"
    assert choice.validate("1") == "1"
    with pytest.raises(ValidationError) as e:
        choice.validate("5")



# Generated at 2022-06-12 15:41:59.587218
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate('a string') == 'a string'
    assert s.validate('A STRING') == 'A STRING'
    assert s.validate('') == ''
    assert s.validate('   ') == ''
    assert s.validate(None) == None
    assert s.validate(None, strict=True) == None
    try:
        assert s.validate(None, strict=True)
    except ValidationError as e:
        assert e.code == 'null'

# Generated at 2022-06-12 15:42:22.341808
# Unit test for method __or__ of class Field
def test_Field___or__():
    def test_Field___or__1():
        class F1(Field):
            pass

        class F2(Field):
            pass

        f1 = F1()
        f2 = F2()
        field = f1 | f2
        assert isinstance(field, Union)
        assert field.any_of == [f1, f2]
        # test if original fields are not changed
        assert isinstance(f1, F1)
        assert isinstance(f2, F2)
    def test_Field___or__2():
        class F1(Field):
            pass

        class F2(Field):
            pass

        class F3(Field):
            pass

        union1 = F1() | F2()
        field23 = F2() | F3()
        field = union1 | field23
        assert isinstance

# Generated at 2022-06-12 15:42:27.457982
# Unit test for constructor of class Const
def test_Const():
    const = Const(
        const=1,
        description="Test",
        title="Test Title",
        error_messages={"const": "Custom message"},
    )
    error = const.validate_or_error(1, strict=True)
    assert error is None

    error = const.validate_or_error(2, strict=True)
    assert isinstance(error, ValidationError)
    assert error.messages()[0].code == "const"
    assert error.messages()[0].text == "Custom message"



# Generated at 2022-06-12 15:42:39.322748
# Unit test for method serialize of class Array
def test_Array_serialize():
    class MyField(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return obj

    assert Array(items=MyField()).serialize([1, 2]) == [1, 2]
    assert Array(items=[MyField(), MyField()]).serialize([1, 2]) == [1, 2]
    assert Array(items=MyField(), min_items=3).serialize([]) == []
    assert Array(items=MyField(), min_items=3).serialize([1]) == [1]
    assert Array(items=MyField(), min_items=3).serialize([1, 2]) == [1, 2]
    assert Array(items=MyField(), min_items=3).serialize([1, 2, 3, 4]) == [
        1, 2, 3, 4
    ]


# Generated at 2022-06-12 15:42:46.525479
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {'name': String(), 'age': Integer()}
    pattern_properties = {'^p': String()}
    additional_properties = {'class': String()}
    min_properties = 2
    max_properties = 3
    required = ['name', 'age']

    value = {'name': 'jon', 'age': 20}
    Object_obj = Object(properties=properties, pattern_properties=pattern_properties,
                        additional_properties=additional_properties,
                        property_names=None, min_properties=min_properties,
                        max_properties=max_properties, required=required)
    assert (Object_obj.validate(value)) == {'name': 'jon', 'age': 20}

    value = {'name': 'jon', 'age': 20, 'p': 'student'}

# Generated at 2022-06-12 15:42:47.736977
# Unit test for constructor of class Const
def test_Const():
    result = Const(True, default=True)
    assert result.const == True
    assert result.default == True


# Generated at 2022-06-12 15:42:50.667610
# Unit test for method __or__ of class Field
def test_Field___or__():
    f = Field()
    f__or__ = f.__or__(other=None)
    print(f__or__)
    assert f__or__ is not None



# Generated at 2022-06-12 15:42:57.067853
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class User(Schema):
        age = String()

    inputs = [{'age': '1'}, {'age': 1}]
    user = User(inputs[0])
    success, data = user()

    user = User(inputs[1])
    success, data = user()

    user = User(inputs[0]) | User(inputs[1])
    for input in inputs:
        success, data = user(input)


# Generated at 2022-06-12 15:43:00.888804
# Unit test for method __or__ of class Field
def test_Field___or__():
    f = String | String | String
    assert f.any_of[0].__class__ == String
    assert f.any_of[1].__class__ == String
    assert f.any_of[2].__class__ == String



# Generated at 2022-06-12 15:43:05.940190
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title="some field")
    assert field.get_default_value() == None
    field.default = "ok"
    assert field.get_default_value() == "ok"
    field.default = lambda : "ok2"
    assert field.get_default_value() == "ok2"
    
    

# Generated at 2022-06-12 15:43:10.134727
# Unit test for method validate of class Array
def test_Array_validate():
    with pytest.raises(ValidationError) as e_info:
        Array(items=[String(), Integer()]).validate(["abc", 3, 4])
    assert (
        e_info.value.messages[0].text
        == "no additional_items allowed ('[2]')"
    )
    assert e_info.value.messages[0].code == "additional_items"
    assert e_info.value.messages[0].index == [2]



# Generated at 2022-06-12 15:43:32.513832
# Unit test for method validate of class String
def test_String_validate():
    string = String(
        allow_blank = True,
        trim_whitespace = False,
        max_length = 10,
        min_length = 2,
        pattern = "^[a-z]*",
        format = "uuid",
        title = "",
        description = "",
        default = None,
        allow_null = True,
    )
    res = string.validate("abc")
    assert res == "abc", res


# Generated at 2022-06-12 15:43:37.538512
# Unit test for method validate of class String
def test_String_validate():
    string_test = String()
    print(string_test.validate("123") == "123")
    print(string_test.validate("abc") == "abc")
    try:
        string_test.validate(123)
    except ValidationError as error:
        print(error)
    try:
        string_test.validate(None)
    except ValidationError as error:
        print(error)
if __name__ == "__main__":
    test_String_validate()


# Generated at 2022-06-12 15:43:44.655427
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format='uuid').serialize(uuid.uuid4()) == str(uuid.uuid4())
    assert String(format='uuid').serialize('7109565b-ff1f-4b14-9f39-9a8fe2404d94') == '7109565b-ff1f-4b14-9f39-9a8fe2404d94'


# Generated at 2022-06-12 15:43:56.200444
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean().validate("False") == False
    assert Boolean().validate("") == False
    assert Boolean().validate("0") == False
    assert Boolean().validate("null") == None
    assert Boolean().validate(None) == None
    assert Boolean().validate(True, strict = True) == True
    assert Boolean().validate(False, strict = True) == False
    with pytest.raises(ValidationError):
        Boolean().validate("False", strict = True)
    with pytest.raises(ValidationError):
        Boolean().validate("", strict = True)
    with pytest.raises(ValidationError):
        Boolean().validate("0", strict = True)

# Generated at 2022-06-12 15:43:59.817151
# Unit test for method serialize of class String
def test_String_serialize():
    test_string = String()
    test_string_value = '20/04/2020'
    test_string_expected = '20/04/2020'
    assert test_string_expected == test_string.serialize(test_string_value)

    # Test when format is in FORMATS
    test_string = String(format='date')
    test_string_value = datetime.date(2020, 4, 20)
    test_string_expected = '2020-04-20'
    assert test_string_expected == test_string.serialize(test_string_value)

# Generated at 2022-06-12 15:44:04.796287
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('1', '1'), ('2', '2')])
    choice.validate('1')
    try:
        choice.validate('3')
    except ValidationError as error:
        assert error.code == 'choice'



# Generated at 2022-06-12 15:44:09.547893
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate("hello") == "hello"
    assert field.validate("") == ""
    assert field.validate(" ") == ""
    assert field.validate("\n") == ""
    assert field.validate("\t") == ""



# Generated at 2022-06-12 15:44:11.149532
# Unit test for method serialize of class String
def test_String_serialize():
    str = String()
    assert str.serialize("")==""

# Generated at 2022-06-12 15:44:13.295754
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    assert obj.get_default_value() is None



# Generated at 2022-06-12 15:44:24.061348
# Unit test for method validate of class Array
def test_Array_validate():
    
    # Test array with a list of serializers
    array_with_list_of_serializers = Array(
        items=[
            String(),
            Number(),
            Integer(),
            Boolean(),
        ]
    )
    
    errors = array_with_list_of_serializers.validate(
        [
            "a",
            1.234,
            567,
            True
        ]
    )
    
    assert errors == [
        "a",
        1.234,
        567,
        True
    ]
    
    # Test array with additional items
    array_with_additional_items = Array(
        items=[
            String(),
            Number(),
            Integer(),
            Boolean(),
        ],
        additional_items = Number()
    )
    
    errors = array_with_add

# Generated at 2022-06-12 15:44:39.593139
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([Number(), String()])
    validate = u.validate
    assert validate(None) == None
    assert validate(0) == 0
    assert validate("") == ""
    assert validate(False) == False
    assert validate(True) == True
    #assert validate(0) == 0


# Generated at 2022-06-12 15:44:46.914385
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = Field()
    f2 = Field()
    assert (f1 | f2) == Union(any_of=[f1, f2])
    f3 = Field()
    f4 = Field()
    assert (f1 | f2 | f3) == Union(any_of=[f1, f2, f3])
    assert (f1 | f2 | f3 | f4) == Union(any_of=[f1, f2, f3, f4])
    assert (f1 | Union(any_of=[f2, f3, f4]) | Union(any_of=[f5, f6])) == Union(any_of=[f1, f2, f3, f4, f5, f6])


# Generated at 2022-06-12 15:44:54.385361
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['A', 'B'])
    assert choice.validate('B') =='B'
    assert choice.validate('A') =='A'
    assert choice.validate(1) ==1
    try:
        assert choice.validate('C')
    except ValidationError as error:
        assert error.code == 'choice'
        assert error.text == 'Not a valid choice.'
    try:
        assert choice.validate('')
    except ValidationError as error:
        assert error.code == 'required'
        assert error.text == 'This field is required.'
    try:
        assert choice.validate(None)
    except ValidationError as error:
        assert error.code == 'null'
        assert error.text == 'May not be null.'
    assert choice.valid

# Generated at 2022-06-12 15:44:56.750928
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        default = "foo"

    field = MyField()
    assert field.get_default_value() == "foo"



# Generated at 2022-06-12 15:44:58.194250
# Unit test for method validate of class Union
def test_Union_validate():
    assert True
    v = Union(any_of=[
        Integer(),
        Null(),
    ])
    assert v.validate(None) == None
    assert v.validate(1) == 1



# Generated at 2022-06-12 15:45:01.216424
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	obj = Field()
	def f():
		return 5
	obj.default = f
	assert obj.get_default_value() == 5


# Generated at 2022-06-12 15:45:10.331895
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([String()])
    try:
        a = u.validate(1)
    except ValidationError as e:
        assert str(e) == 'Did not match any valid type.'
        assert str(e.messages()) == '[<Message code="union" text="Did not match any valid type.">]'
    else:
        assert False
    a = u.validate('a')
    assert a == 'a'
    try:
        a = u.validate(None)
    except ValidationError as e:
        assert str(e) == 'May not be null.'
        assert str(e.messages()) == '[<Message code="null" text="May not be null.">]'
    else:
        assert False

# Generated at 2022-06-12 15:45:15.937801
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[('1', 'm'), ('2', 'n'), ('3', 'o')])
    assert c.validate(1) is None
    assert c.validate(2) is None
    assert c.validate(3) is None
    assert c.validate(4) is None
    assert c.validate('1') == '1'
    assert c.validate('2') == '2'
    assert c.validate('3') == '3'
    assert c.validate('4') == '4'
    #assert c.validate('5') == None
    assert c.validate('m') == 'm'
    assert c.validate('n') == 'n'
    assert c.validate('o') == 'o'
    #assert c.validate('p') == None

# Generated at 2022-06-12 15:45:20.141859
# Unit test for constructor of class Const
def test_Const():
    # Const()
    try:
        Const()
        assert False, "Expected ValueError"
    except ValueError:
        pass

    # Const(1.0)
    x = Const(1.0)
    assert x.const == 1.0

    # Invalid chaining errors should work
    try:
        Const(1.0, allow_null=False, chain_errors=True).validate('a')
        assert False, "Expected validation error"
    except ValidationChainError as chain_error:
        assert len(chain_error.chain) == 1
        assert isinstance(chain_error.chain[0], ValidationError)
        assert len(chain_error.chain[0].messages) == 1
        assert chain_error.chain[0].messages[0].code == "const"

# Generated at 2022-06-12 15:45:23.046750
# Unit test for method validate of class Choice
def test_Choice_validate():

    test_obj = Choice(choices=["test1", "test2", "test3", "test4"])
    assert test_obj.validate("test2") == "test2"



# Generated at 2022-06-12 15:45:38.339980
# Unit test for method validate of class Choice
def test_Choice_validate():
    field1 = Choice(choices=[(0, "Red"), (1, "Green"), (2, "Blue")])
    assert field1.validate(1) == 1
    field2 = Choice(choices=[(0, "Red"), (None, "Green"), (2, "Blue")])
    assert field2.validate(None) == None
    assert field2.validate(1) == None
    assert field2.validate(1, strict=True) == None
    assert field2.validate(None, strict=True) == None
    field3 = Choice(choices=[(0, "Red"), (1, "Green"), (2, "Blue")],allow_null=True)
    assert field3.validate(None) == None
    assert field3.validate(1) == 1

# Generated at 2022-06-12 15:45:46.988669
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(
            name = "choice",
            choices = [("1", "one"), ("2", "two")],
            required = True
        )
    print("TEST CHOICE CLASS")
    print("Test choice validate 1")
    print(choice.validate("1"))
    print("Test choice validate 2")
    try:
        print(choice.validate("3"))
    except ValidationError as e:
        print(e)
    print("Test choice validate 3")
    try:
        print(choice.validate(None))
    except ValidationError as e:
        print(e)

test_Choice_validate()


# Generated at 2022-06-12 15:45:55.444468
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True, strict=True) == True
    assert Boolean().validate(False, strict=True) == False
    assert Boolean().validate(None, strict=True) == None
    assert Boolean().validate(None, strict=False) == None
    assert Boolean().validate(False, strict=False) == False
    assert Boolean().validate(True, strict=False) == True
    assert Boolean().validate(1, strict=True) == True
    assert Boolean().validate(1, strict=False) == True
    assert Boolean().validate(0, strict=False) == False
    assert Boolean().validate(0, strict=True) == False
    assert Boolean().validate("True", strict=False) == True
    assert Boolean().validate("False", strict=False) == False

# Generated at 2022-06-12 15:45:58.665265
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    try:
        field1 = Field()
        field1.default = True
        assert field1.get_default_value() == True
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-12 15:46:04.429688
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(name='test', choices=[('A', 'A'), ('B', 'B')])
    obj.validate(value="A", strict=False) == "A"
    obj.validate(value=None, strict=False) == None
    obj.validate(value="C", strict=False) == None


# Generated at 2022-06-12 15:46:11.221826
# Unit test for method validate of class Array
def test_Array_validate():
    class Test(Array):
        items = [Integer(), Integer(), Integer()]

    test = Test()
    test.validate([1, 1, 1])
    test.validate([])

    with pytest.raises(ValidationError):
        test.validate([1, 2])
    with pytest.raises(ValidationError):
        test.validate([1, 2, 3, 4])
    with pytest.raises(ValidationError):
        test.validate(1)



# Generated at 2022-06-12 15:46:13.319428
# Unit test for constructor of class Const
def test_Const():
    class User(Document):
        pass
    user = User(name='Guido')
    assert isinstance(user.name, Field)
    assert isinstance(user.name, Const)


# Generated at 2022-06-12 15:46:22.401979
# Unit test for method validate of class Object
def test_Object_validate():
    def test_object_validate(field, data, strict=False):
        try:
            field.validate(data, strict=strict)
            return True, None
        except ValidationError as e:
            return False, e.messages

    # TODO: more
    field = Object(properties={"name": String()}, required=["name"])
    data = {"name": "Jack"}
    strict = False
    res, _ = test_object_validate(field, data, strict)
    assert res
    data = {"name": ""}
    res, _ = test_object_validate(field, data, strict)
    assert not res
    data = {"name": "", "age": "18"}
    res, _ = test_object_validate(field, data, strict)
    assert not res
    data

# Generated at 2022-06-12 15:46:27.441320
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test __or__ of Field
    field = Field(description='description', title='title', allow_null=False) | Field(description='description', title='title', allow_null=False)
    assert isinstance(field, Union)
    assert len(field.any_of) == 2


# Generated at 2022-06-12 15:46:37.482027
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    """
    Unit test for method validate from class Boolean
    """
    allowed_values = ["true", "false", "on", "off", "1", "0", "", 1, 0]
    allowed_null = ["", "null", "none"]
    not_allowed = [2, 3, 4, 5, 6, "a", "b", "c", " TRUE", "FALSE", r"\0", "<", ">"]

    field = Boolean()
    results = [field.validate(allowed_values[i])
               for i in range(len(allowed_values))]
    expected = [True, False, True, False, True, False, False, True, False]
    assert results == expected

    results = [field.validate(None) for i in range(25)]
    expected = [None for i in range(25)]

# Generated at 2022-06-12 15:46:57.218549
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(
        title="test",
        description="test",
        properties=dict(
            string=String(title="test", description="test"), 
            number=Number(title="test", description="test", numeric_type=int)
        ), 
        required=["string"]
    )
    assert obj.validate(dict(string="foo", number=3)) == {'string': 'foo', 'number': 3}
    assert obj.validate(dict(number=3)) == {'number': 3}
    assert obj.validate(dict(string="foo")) == {'string': 'foo'}
    assert obj.validate(dict(string="foo", number=3.4)) == {'string': 'foo', 'number': 3}

# Generated at 2022-06-12 15:47:02.329052
# Unit test for method validate of class Union
def test_Union_validate():
    cases = [(0, 1), (1, 2)]
    array = Array(items=cases)
    cases = {'Number': Number(), 'Array': array}
    cases = [Number(), Array(items=cases)]
    u = Union(cases)
    assert u.validate(0) == 0
    assert u.validate(1) == 1



# Generated at 2022-06-12 15:47:10.160078
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("1", "one"), ("2", "two"), ("3", "three")])
    assert field.validate("1") == "1"
    assert field.validate("2") == "2"
    assert field.validate("3") == "3"
    try:
        field.validate("4")
        assert False, "should not reach here"
    except ValidationError as e:
        assert e.code == "choice"



# Generated at 2022-06-12 15:47:13.381756
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        Choice(choices=[1, None]).validate(1)
    except ValidationError as error:
        return error.code == "choice"
    assert False


# Generated at 2022-06-12 15:47:23.850293
# Unit test for method validate of class Choice
def test_Choice_validate():
    class TestChoice(Choice):
        def __init__(self, *,
                     choices: typing.Sequence[typing.Union[str, typing.Tuple[str, str]]] = None,
                     **kwargs: typing.Any,
                     ) -> None:
            super().__init__(**kwargs)
            self.choices = [
                (choice if isinstance(choice, (tuple, list)) else (choice, choice))
                for choice in choices or []
            ]
            assert all(len(choice) == 2 for choice in self.choices)
        
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None and self.allow_null:
                return None

# Generated at 2022-06-12 15:47:34.098597
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(-1) == -1
    assert number.validate(1.0) == 1.0
    assert number.validate(-1.0) == -1.0
    assert number.validate("1.1") == 1.1
    assert number.validate("-1.1") == -1.1
    assert number.validate("1.1", strict=True) is None
    assert number.validate("-1.1", strict=True) is None

    # Test unique validation
    assert number.validate(1).unique is True
    assert number.validate("1").unique is True
    assert number.validate("1.0").unique is True
    assert number.validate("1").__class__ == int

# Generated at 2022-06-12 15:47:41.549941
# Unit test for method validate of class Choice
def test_Choice_validate():
    ################################
    # Test1 - correct choice
    ################################
    choiceField = Choice(choices=[('a','b'), ('c','d')])
    try:
        assert choiceField.validate('c') == 'c'
    except:
        assert 0
    ################################
    # Test2 - incorrect choice
    ################################
    try:
        choiceField.validate('e')
        assert 0
    except ValidationError:
        assert 1



# Generated at 2022-06-12 15:47:43.993046
# Unit test for constructor of class Const
def test_Const():
    expected_result = Const(const=5)
    result = Const(const=5)
    assert expected_result == result


# Generated at 2022-06-12 15:47:47.865894
# Unit test for method __or__ of class Field
def test_Field___or__():
    f = Field()
    print(f|f)
    print(f | f)
    print(type(f | f))
    assert isinstance(f | f, Union)


# Generated at 2022-06-12 15:47:52.277597
# Unit test for constructor of class String
def test_String():
    s = String(max_length=1,allow_blank=True,trim_whitespace=True,format="time")
    assert s.max_length == 1
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.format == "time"


# Generated at 2022-06-12 15:48:06.095983
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate("1") == 1
    assert Number().validate("-1.123") == -1.123
    assert Number().validate(1.123) == 1.123
    assert Number().validate("0") == 0
    assert Number().validate("0.123") == 0.123
    assert Number().validate("-0.1233") == -0.1233
    assert Number().validate("1.123e10") == 1123000000000.0
    assert Number().validate("+1.123e10") == 1123000000000.0
    assert Number().validate("-1.123e10") == -1123000000000.0
    assert Number().validate("1.123E10") == 1123000000000.0
    assert Number().validate

# Generated at 2022-06-12 15:48:10.366167
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "a")])
    value = choice.validate("1")
    assert value == "1"
    value = choice.validate("")
    assert value == None



# Generated at 2022-06-12 15:48:15.487320
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [('key1', 'value1'), ('key2', 'value2')]
    # input ('key1', 'value1')
    # output ('key1', 'value1')
    # input ('key1')
    # output ('key1', 'value1')
    # input ('key2')
    # output ('key2', 'value2')
    # input ('key3')
    # output ('key3', 'key3')
    # input ('')
    # output ('', '')
    # input ('', null)
    # output (null)
    # input ('', '', required)
    # output ('', '')
    # input ('', '', not required)
    # output (null)
    # input (null)
    # output (null)
    # input ()
    # output ()


# Generated at 2022-06-12 15:48:26.388812
# Unit test for method validate of class Choice
def test_Choice_validate():
    # the function should return the value itself if it does exist in the choices
    assert Choice(choices=["1","2"]).validate("1") == "1"
    assert Choice(choices=["1","2"]).validate("2") == "2"
    # if the value does not exist in choices, the function should raise an error
    with pytest.raises(ValidationError) as e:
        Choice(choices=["1","2"]).validate("3")
    assert str(e.value) == "Not a valid choice."
    # the function should return the value itself if it is a choice
    assert Choice(choices=["1","2"]).validate("1") == "1"
    # the function should return None if the value is empty and the field is not required

# Generated at 2022-06-12 15:48:31.875887
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice(allow_null=True, choices=['a', 'b', 'c']).validate('a')
    Choice(allow_null=True, choices=['a', 'b', 'c']).validate('b')
    Choice(allow_null=True, choices=['a', 'b', 'c']).validate('c')

    with pytest.raises(ValidationError):
        Choice(allow_null=True, choices=['a', 'b', 'c']).validate('d')
    with pytest.raises(ValidationError):
        Choice(allow_null=True, choices=['a', 'b', 'c']).validate('')
    with pytest.raises(ValidationError):
        Choice(allow_null=True, choices=[1, 2, 3]).validate(4)
# Test

# Generated at 2022-06-12 15:48:38.669837
# Unit test for method validate of class String
def test_String_validate():
    # check type
    field = String(title="String_01", allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    value = 100
    strict = False
    expected_value = "Must be a string."
    result = field.validate(value, strict=strict)
    assert isinstance(result, typing.Any) == True
    assert result == None
    assert field._creation_counter == 0
    # check allow_blank
    field = String(title="String_02", allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    value = "  "
    strict = False
    expected_value = "Must not be blank."

# Generated at 2022-06-12 15:48:44.648195
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(properties={"test": Decimal()})
    field.validate({"test": 1.2})

    field = Object(properties={"test": Decimal()}, allow_null=True)
    field.validate(None)

    field = Object(properties={"test": Decimal()})
    field.validate({"test": "test"})
test_Object_validate()


# Generated at 2022-06-12 15:48:57.533304
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.validate("foo") == "foo"
    s = String(allow_blank=True)
    assert s.validate("") == ""
    s = String(allow_null=True)
    assert s.validate("") == ""
    assert s.validate(None) == None
    s = String(default="")
    assert s.validate("") == ""
    assert s.validate(None) == ""
    s = String(allow_null=True, default="")
    assert s.validate(None) == None
    s = String(allow_null=True, default="", allow_blank=True)
    assert s.validate(None) == None
    assert s.validate("") == ""

# Generated at 2022-06-12 15:49:07.162521
# Unit test for method validate of class Object
def test_Object_validate():
    # Create a new instance of Object
    json_schema = {
        "type": "object",
        "title": "Example Schema",
        "additionalItems": {"type": "string"},
        "properties": {
            "firstName": {
                "type": "string",
                "description": "The person's first name.",
            },
            "lastName": {
                "type": "string",
                "description": "The person's last name.",
            },
            "age": {
                "description": "Age in years which must be equal to or greater than zero.",
                "type": "integer",
                "minimum": 0,
            },
        },
    }

    obj = Object(schema = json_schema)
    
    # Check the values of parameters