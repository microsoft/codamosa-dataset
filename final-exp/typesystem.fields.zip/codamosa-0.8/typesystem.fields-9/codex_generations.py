

# Generated at 2022-06-12 15:40:55.934843
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() == None
test_Field_get_default_value()


# Generated at 2022-06-12 15:41:06.965008
# Unit test for method validate of class Union
def test_Union_validate():
    # Testing if the method validate is working properly when there's only one child in Union
    bool_fld = Boolean()
    integer_fld = Integer()
    union_fld = Union([bool_fld])
    # Testing if the method validate is working properly when there's multiple children in Union
    union_fld2 = Union([integer_fld, bool_fld])
    assert union_fld.validate(1) == True
    assert union_fld.validate(0) == False
    assert union_fld.validate("foo") is None
    assert union_fld.validate("foo") is None
    assert union_fld2.validate("foo") is None
    assert bool_fld.validate("foo") is None
    assert union_fld2.validate("foo") is None
    assert union

# Generated at 2022-06-12 15:41:14.601217
# Unit test for method validate of class Object
def test_Object_validate():
    """
    Unit test for method validate of Class Object
    """
    test_dict = {
        "properties": {
            "name": String(required=True),
            "age": Integer(min_value=1, max_value=99),
            "height": Float(min_value=0, max_value=20)
        },
        "required": [
            "name", "age"
        ],
        "min_properties": 2,
        "max_properties": 3
    }
    test_obj = Object(**test_dict)
    
    assert test_obj.validate({"name": "John Doe", "age": 15, "height": 1.8}) == {"name": "John Doe", "age": 15, "height": 1.8}

# Generated at 2022-06-12 15:41:17.708855
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    assert field1 | field2 == Union([field1, field2])
    assert field2 | field3 == Union([field2, field3])
    assert field3 | field1 == Union([field3, field1])
    assert field1 | field2 | field3 == Union([field1, field2, field3])



# Generated at 2022-06-12 15:41:20.731590
# Unit test for constructor of class String
def test_String():
    String(title = "", description = "", allow_blank = True, max_length = None, \
    min_length = None, pattern = None, format = None)




# Generated at 2022-06-12 15:41:25.191586
# Unit test for method validate of class Union
def test_Union_validate():
    from jsonasobj import load
    from chiton.closet.data import SizeProfile

    def get_schema():
        return Union(any_of=[SizeProfile, {"type": "integer"}])

    schema = get_schema()

    assert schema.validate([]) == []
    assert schema.validate({"standard": [["S", "XS", "L"]]}) == {
        "standard": [["S", "XS", "L"]]
    }
    assert schema.validate(1) == 1



# Generated at 2022-06-12 15:41:36.247628
# Unit test for method validate of class Choice
def test_Choice_validate():
    # case 1: value is None and allow_null is True
    choice = Choice()
    choice.allow_null = True
    assert choice.validate(None) == None
    # case 2: value is None and allow_null is False
    choice = Choice()
    choice.allow_null = False
    try:
        choice.validate(None)
    except ValidationError as error:
        assert error.code == 'null'
    # case 3: value is not None and in choices
    choice = Choice()
    choice.choices = [('A', 'A'), ('B', 'B')]
    assert choice.validate('A') == 'A'
    # case 4: value is not None and not in choices
    choice = Choice()
    choice.choices = [('A', 'A'), ('B', 'B')]


# Generated at 2022-06-12 15:41:39.816502
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None


# Generated at 2022-06-12 15:41:49.358110
# Unit test for method validate of class Array
def test_Array_validate():
    # Assert that Array validates correctly if all parameters are within the ranges
    field = Array(max_items = 3)
    field.validate([1, 2, 3])

    # Assert that Array validates correctly if all parameters are within the ranges
    field = Array(min_items = 3, max_items = 3)
    field.validate([1, 2, 3])
    try:
        # Assert that Array validates correctly if all parameters are within the ranges
        field = Array(min_items = 3, max_items = 3)
        field.validate([1, 2])
    except ValidationError:
        True


# Generated at 2022-06-12 15:41:55.466727
# Unit test for constructor of class Array
def test_Array():
    # Test 1
    assert Array().items is None
    assert Array().additional_items is False
    assert Array().min_items is None
    assert Array().max_items is None
    assert Array().unique_items is False

    # Test 2
    assert Array(items = "TEST").items == "TEST"
    assert Array(items = "TEST").additional_items is False
    assert Array(items = "TEST").min_items is None
    assert Array(items = "TEST").max_items is None
    assert Array(items = "TEST").unique_items is False

    # Test 3
    assert Array(items = ["TEST"]).items == ["TEST"]
    assert Array(items = ["TEST"]).additional_items is False
    assert Array(items = ["TEST"]).min_items == 1


# Generated at 2022-06-12 15:42:44.640933
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    print(a.validate([1, 2, 3]))


# Generated at 2022-06-12 15:42:46.716697
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None


# Generated at 2022-06-12 15:42:57.266179
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(
        properties={
            "foo": String(min_length=1, max_length=10),
            "bar": Integer(minimum=0, maximum=100),
        },
        required=["foo"],
        min_properties=1,
        max_properties=1,
    )
    assert field.validate({"foo": "hello"}) == {"foo": "hello"}
    # Additional properties
    field = Object(
        properties={"foo": String(min_length=1)},
        required=["foo"],
        additional_properties=False,
    )

    with pytest.raises(ValidationError) as excinfo:
        field.validate({"foo": "bar", "baz": 42})
    assert excinfo.value.messages[0].code == "invalid_property"

# Generated at 2022-06-12 15:43:05.693186
# Unit test for method validate of class Union
def test_Union_validate():
    test_field = Union(any_of = [
        String(),
        Number(),
        Boolean(),
        Date(),
        ])
    #assert test_field.validate(value = '123') == '123'
    #assert test_field.validate(value = 123) == 123
    #assert test_field.validate(value = True) == True
    #assert test_field.validate(value = '2000-01-02') == '2000-01-02'
    return print('test_Union_validate passed!')
test_Union_validate()



# Generated at 2022-06-12 15:43:14.128297
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [('a', 'A'), ('b', 'B')])
    assert choice.validate(None) == None
    assert choice.validate('a') == 'a'
    try:
        choice.validate(2)
    except ValidationError as error:
        assert error.code == 'choice'
    try:
        choice.validate('c')
    except ValidationError as error:
        assert error.code == 'choice'
    try:
        choice.validate('')
    except ValidationError as error:
        assert error.code == 'choice'


# Generated at 2022-06-12 15:43:18.134218
# Unit test for constructor of class Const
def test_Const():
    """
    # Too strict
    obj = Const(const = 10, allow_extra = True)
    obj.validate(value = 10, strict = True)
    # Not too strict, but missed error
    obj = Const(const = 10, allow_extra = True)
    obj.validate(value = 11, strict = False)
    """
    obj = Const(const = 10, allow_extra = True)
    obj.validate(value = 10, strict = True)

# Generated at 2022-06-12 15:43:20.838648
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = Field()
    assert a.get_default_value() == None
    result = a.get_default_value() == None
    assert result == True

# Generated at 2022-06-12 15:43:25.443244
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class FieldClass(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.default = 'Hello'

    field = FieldClass()
    assert field.get_default_value() == 'Hello'



# Generated at 2022-06-12 15:43:29.318127
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Setup
    field = Field()
    other = Field()

    # Exercise
    r = field.__or__(other)

    # Verify
    assert isinstance(r, Union)
    assert len(r.any_of) == 2

    # Cleanup - none necessary



# Generated at 2022-06-12 15:43:37.594071
# Unit test for constructor of class String
def test_String():
    s = String(
        title = 'string test',
        description = 'test string',
        default = 'string',
        allow_blank = True,
        trim_whitespace = True,
        max_length = 10,
        min_length = 1,
        pattern = '[A-Za-z]+',
        format = 'None'
    )
    print('title: ', s.title)
    print('description: ', s.description)
    print('default: ', s.default)
    print('allow_blank: ', s.allow_blank)
    print('trim_whitespace: ', s.trim_whitespace)
    print('max_length: ', s.max_length)
    print('min_length: ', s.min_length)
    print('pattern: ', s.pattern)

# Generated at 2022-06-12 15:43:50.107343
# Unit test for method validate of class String
def test_String_validate():
    from typesystem.base import ValidationError
    from typesystem.fields import String
    for field in [String(), String(allow_blank=True), String(allow_null=True)]:
        try:
            assert field.validate("") == ""
        except ValidationError as error:
            assert error.code == "blank"
        try:
            assert field.validate("\0") == "\\u0000"
        except ValidationError as error:
            assert error.code == "type"



# Generated at 2022-06-12 15:43:57.904025
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[
        ("AL", "Alabama"),
        ("CA", "California"),
        ("NV", "Nevada"),
    ])
    result = c.validate(1)
    assert result == 1
    result = c.validate(None)
    assert result == None
    try:
        result = c.validate('NV')
    except ValidationError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 15:43:59.365530
# Unit test for constructor of class String
def test_String():
    assert String.__name__ == 'String'

# Generated at 2022-06-12 15:44:02.048922
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    try:
        f.get_default_value()
        assert isinstance(f.get_default_value(), object)
    except Exception:
        assert False



# Generated at 2022-06-12 15:44:14.245602
# Unit test for method validate of class Object

# Generated at 2022-06-12 15:44:14.921629
# Unit test for constructor of class Const
def test_Const():
    assert Const(5).const == 5

# Generated at 2022-06-12 15:44:19.944360
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1.
    field = String(pattern="^Test$")
    value = field.validate("Test")
    assert value == "Test"
    # Test case 2.
    field = String(pattern="^Test$")
    try:
        value = field.validate("Invalid")
        assert False
    except ValidationError as error:
        assert error.text == "Must match the pattern /^Test$/."
        assert error.code == "pattern"


# Generated at 2022-06-12 15:44:23.710150
# Unit test for method validate of class String
def test_String_validate():
    f = String(max_length=4)
    res = f.validate('abcd')
    assert res == 'abcd'
    try:
        f.validate('abcdef')
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-12 15:44:29.884163
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with no value for any_of
    union = Union(any_of=[])
    try:
        union.validate(1)
        assert False
    except ValidationError:
        assert True

    # Test with no value for value
    union = Union(any_of=[Integer()])
    try:
        union.validate(None)
        assert False
    except ValidationError:
        assert True

    # Test with valid value
    union = Union(any_of=[Integer()])
    try:
        union.validate(1)
        assert True
    except ValidationError:
        assert False


# Generated at 2022-06-12 15:44:33.287473
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert f.get_default_value() == None
    f = Field(default = 123)
    assert f.get_default_value() == 123
    f = Field(default = 'a')
    assert f.get_default_value() == 'a'
    f = Field(default = lambda: 123)
    assert f.get_default_value() == 123
    f = Field(default = lambda: 'a')
    assert f.get_default_value() == 'a'


# Generated at 2022-06-12 15:44:46.635707
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    def func():
        return 123

    field = Field()
    field.default = 123
    assert field.get_default_value() == 123
    field.default = func
    assert field.get_default_value() == 123

# Generated at 2022-06-12 15:44:52.327593
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean(allow_null=True)
    result = field.validate(value=None, strict=True)
    assert result == None
    result = field.validate(value=True)
    assert result == True
    result = field.validate(value=False)
    assert result == False
    result = field.validate(value=None)
    assert result == None



# Generated at 2022-06-12 15:45:01.284800
# Unit test for constructor of class String
def test_String():
    string_instance = String()
    assert isinstance(string_instance, String), "string instance is not an instance of String"
    assert isinstance(string_instance, Field), "string instance is not an instance of Field"
    assert string_instance.title == '', 'string_instance.title is not the default value'
    assert string_instance.description == '', 'string_instance.description is not the default value'
    assert string_instance.allow_null is False, 'string_instance.allow_null is not the default value'
    assert string_instance.allow_blank is False, 'string_instance.allow_blank is not the default value'
    assert string_instance.trim_whitespace is True, 'string_instance.trim_whitespace is not the default value'

# Generated at 2022-06-12 15:45:04.108732
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    v = s.validate("foo")
    assert v == 'foo'

# Generated at 2022-06-12 15:45:08.892816
# Unit test for method validate of class Number
def test_Number_validate():
    instances = [Int(maximum=5), Int(minimum=7), Int(multiple_of=0)]
    values = [1, -1, 5, 7, 9]
    expected = [1, -1, 5, 7, 9]
    i = 0
    for instance in instances:
        for value in values:
            assert instance.validate(value) == expected[i]
            i += 1


# Generated at 2022-06-12 15:45:11.457554
# Unit test for method validate of class Number
def test_Number_validate():
    #instance of Number
    num = Number()
    assert num.validate(10) == 10



# Generated at 2022-06-12 15:45:20.579098
# Unit test for method validate of class Object
def test_Object_validate():
    from pydantic import ValidationError, BaseModel
    from pydantic.types import conint, conlist
    from pydantic.fields import Constant, Field, Number, Boolean
    class Model(BaseModel):
        a: Number
        b: Number = None
        c: Number = Number(default=1)
        d: Number
    class Model2(BaseModel):
        a: int
        b: int = None
        c: int = 1
        d: int
    def test_default_simple():
        m = Model()
        assert m.a is None
        assert m.b is None
        assert m.c == 1
        assert m.d is None
        m = Model(a=1)
        assert m.a == 1
        assert m.b is None
        assert m.c == 1
        assert m.d

# Generated at 2022-06-12 15:45:31.575530
# Unit test for method validate of class Choice
def test_Choice_validate():
    class C(Choice):
        def validate(self, value, *, strict=False):
            return super().validate(value, strict=strict)
    c = C(allow_null=True, choices=["foo", "bar"])
    assert c.validate(None) is None
    assert c.validate("foo") == "foo"
    assert c.validate("FOO") == "foo"
    with pytest.raises(ValidationError) as exc_info:
        c.validate("qux")
    assert exc_info.value.code == "choice"
    c = C(allow_null=True, choices=[("foo", "Foo"), ("bar", "Bar")])
    assert c.validate(None) is None
    assert c.validate("foo") == "foo"

# Generated at 2022-06-12 15:45:32.802664
# Unit test for constructor of class Const
def test_Const():
    # Default
    Const(const=None)


if __name__ == "__main__":
    test_Const()

# Generated at 2022-06-12 15:45:35.484505
# Unit test for method __or__ of class Field
def test_Field___or__():
    instance1 = Field()
    instance2 = Field()
    assert isinstance(instance1 | instance2, Union)


# Generated at 2022-06-12 15:45:55.750508
# Unit test for constructor of class String
def test_String():
    # test default values
    s = String()
    assert s.title == ""
    assert s.description == ""
    assert s.allow_blank == False
    assert s.allow_null == False
    assert s.format == None
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s._creation_counter == Field._creation_counter - 1
    assert s.has_default() == False

    # test parameters
    s = String(
        title = "title",
        description = "description",
        default = "default",
        trim_whitespace = False,
        max_length = 32,
        min_length = 3,
        pattern = "pattern",
        format = "format"
    )


# Generated at 2022-06-12 15:46:01.678365
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import AnyOf, String, Integer, Float
    from typesystem.types import Type
    Field1 = Field()
    Field2 = Field()
    assert type(Field1 | Field2) is Union
    assert type(Field1 | Field2 | Field1) is Union
    assert type(Field1 | Field2 | Field1 | Field2) is Union
    assert Field1 | Field2 == Union(any_of=[Field1, Field2])
    assert Field1 | Field2 | Field1 == Union(any_of=[Field1, Field2, Field1])
    assert Field1 | Field2 | Field1 | Field2 == Union(any_of=[Field1, Field2, Field1, Field2])
    Field1 = String()
    Field2 = Integer()
    assert type(Field1 | Field2) is AnyOf
    Field1

# Generated at 2022-06-12 15:46:04.236830
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    assert(obj.get_default_value() == None)
test_Field_get_default_value()


# Generated at 2022-06-12 15:46:08.913826
# Unit test for method validate of class Object
def test_Object_validate():
    #test_schema = Object(required=["test"], properties={'name':String(required=True)}, additional_properties=False,allow_null=True)
    #test_schema.validate({"test": 1, "hello": 2})
    pass



# Generated at 2022-06-12 15:46:16.681801
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array( 
        items = [
            Field(serialize = lambda x:x), 
            Field(serialize = lambda x:x**2),
            Field(serialize = lambda x:x**3)
        ]
    )
    print(field.serialize([2, 3, 4]))
    value = [2, 3, 4]
    field.validate(value)
        

# Generated at 2022-06-12 15:46:24.234590
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert 'foo' == (Choice().validate('foo'))
    result = Choice().validate('')
    assert ((result == None) or (result is None) )
    assert_raises(ValidationError, Choice().validate, '', strict=True)
    result = Choice().validate(None, strict=True)
    assert ((result == None) or (result is None) )
    assert_raises(ValidationError, Choice().validate, 'bar')
    result = Choice(choices=['foo']).validate('foo')
    assert ('foo' == result)
    assert_raises(ValidationError, Choice(choices=['foo']).validate, 'bar')
    result = Choice(choices=[('foo', 'bar')]).validate('foo')
    assert ('foo' == result)
    assert_

# Generated at 2022-06-12 15:46:34.373517
# Unit test for method validate of class String
def test_String_validate():
	field = String(title="title", description="description", allow_blank=True, trim_whitespace=False, max_length=10, min_length=3, pattern="[A-Z]{3}")
	with pytest.raises(ValueError):
		assert field.validate("",strict=True) == ""
	with pytest.raises(ValueError):
		assert field.validate(" ") == ""
	with pytest.raises(ValueError):
		assert field.validate("a") == ""
	with pytest.raises(ValueError):
		assert field.validate("abcdefghijklmnop") == ""
	with pytest.raises(ValueError):
		assert field.validate("aaa") == ""

# Generated at 2022-06-12 15:46:40.451870
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String
    s = String(max_length=10) | String(min_length=5)
    s.validate_or_error("12345").value
    s.validate_or_error("123456").value
    with pytest.raises(ValidationError) as excinfo:
        s.validate_or_error("")



# Generated at 2022-06-12 15:46:44.344896
# Unit test for method validate of class Array
def test_Array_validate():
    a_field=Array(items=Number(max_value=100, min_value=0),min_items=1, max_items=2, unique_items=False)
    a_field.validate([0, 1, 2])

# Generated at 2022-06-12 15:46:55.004044
# Unit test for method validate of class Union
def test_Union_validate():
    class_under_test = Union
    u0 = Union([String()])
    value = "hello"
    strict = False
    expected_result = "hello"
    actual_result = u0.validate(value, strict = strict)
    assert actual_result == expected_result
    
    u1 = Union([Integer()])
    value = 1
    strict = False
    expected_result = 1
    actual_result = u1.validate(value, strict = strict)
    assert actual_result == expected_result
    
    u2 = Union([List([String(), Integer()])])
    value = [1, "hello"]
    strict = False
    expected_result = [1, "hello"]
    actual_result = u2.validate(value, strict = strict)
    assert actual_result == expected_result
    


# Generated at 2022-06-12 15:47:14.762449
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=choices)
    try:
        choice.validate('choice1')
    except ValidationError:
        pass
    else:
        assert False

    try:
        choice.validate('choice2')
    except ValidationError:
        pass
    else:
        assert False

    try:
        choice.validate('choice3')
    except ValidationError:
        assert False
    else:
        pass


# Generated at 2022-06-12 15:47:17.106161
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f=Field(default='default_value')
    assert f.get_default_value()=='default_value'

# Generated at 2022-06-12 15:47:19.528288
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = Field(title='title', description='description', default='default')
    assert a.get_default_value() == 'default'

# Generated at 2022-06-12 15:47:24.623128
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert f.get_default_value() is None
    f = Field(default=123)
    assert f.get_default_value() == 123
    f = Field(default=lambda: 234)
    assert f.get_default_value() == 234
    f = Field(default=NO_DEFAULT)
    assert f.get_default_value() is None


# Generated at 2022-06-12 15:47:26.782288
# Unit test for constructor of class Const
def test_Const():
    class Final(Const):
        pass
    final = Final('a')
    assert isinstance(final, Const)



# Generated at 2022-06-12 15:47:34.098265
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        choice = Choice(choices=["a", "b"])
        choice.validate("c")
        assert False # test should have failed with choice.validate("c")
    except ValidationError:
        pass
    except:
        assert False # unexpected error
        
    try:
        choice = Choice(choices=["a", "b"])
        choice.validate("a")
        assert True
    except ValidationError:
        assert False # test should have succeeded with choice.validate("c")
    except:
        assert False # unexpected error



# Generated at 2022-06-12 15:47:40.672168
# Unit test for method validate of class Choice
def test_Choice_validate():
    print('Unit test for method validate')
    choice = Choice(choices=[(0, 'zero'), (1, 'one'), (2, 'two')], allow_null=True)
    assert choice.validate(0) == 0
    assert choice.validate('0') == 0
    assert choice.validate('') == None
    assert choice.validate(None) == None
    assert choice.validate([]) == None



# Generated at 2022-06-12 15:47:52.543830
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestClass:
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
        def get_arg(self):
            return self.arg1 + self.arg2
    test_schema = TestClass(1, 2)
    class TestField(Field):
        def __init__(self):
            self.default = test_schema.get_arg
    # test case 1
    field_test1 = TestField()
    assert field_test1.get_default_value() == 3
    # test case 2
    class TestField2(Field):
        def __init__(self):
            self.default = 3
    field_test2 = TestField2()
    assert field_test2.get_default_value() == 3
    # test case

# Generated at 2022-06-12 15:48:01.184956
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a=Boolean()

    assert a.validate(False, strict=False) == False
    assert a.validate(True, strict=False) == True
    assert a.validate(None, strict=False) == None
    assert a.validate("true", strict=False) == True
    assert a.validate(0, strict=False) == False
    assert a.validate(1, strict=False) == True
    assert a.validate("", strict=False) == False
    assert a.validate("sdfsfd", strict=True) == False
    assert a.validate(1.14, strict=True) == False



# Generated at 2022-06-12 15:48:05.320188
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1=Field(title='Date',description='',default=NO_DEFAULT,allow_null=False)
    f2=Field(title='Date',description='',default=NO_DEFAULT,allow_null=False)
    import typesystem.types as types
    u1=types.Union(any_of=[f1])
    u2=u1|f2
    assert(u1.any_of==u2.any_of)


# Generated at 2022-06-12 15:48:17.158815
# Unit test for constructor of class Array
def test_Array():
    items = [Int()]
    additional_items = True
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False

    # Should not raise any exceptions
    field = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items,
                  exact_items=exact_items, unique_items=unique_items)



# Generated at 2022-06-12 15:48:19.090596
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[1,2,3,4])
    assert c.validate('3') == '3'

# Generated at 2022-06-12 15:48:22.345050
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=['a', 'b'])
    c.validate('a')
    c.validate(None)



# Generated at 2022-06-12 15:48:27.923916
# Unit test for method validate of class Union
def test_Union_validate():
    # case1:
    f = Field()
    f1 = Field()
    f2 = Field()
    u = Union([f1,f2])
    f1.validate = "validate f1"
    f2.validate = "validate f2"
    assert u.validate(f) == "validate f1"
    assert u.validate(f) == "validate f2"


# Generated at 2022-06-12 15:48:36.199053
# Unit test for method validate of class Array
def test_Array_validate():

    from models.courses import Course
    from models.teachers import Teacher
    
    # Array of strings
    arr = Array(String())
    # Valid string
    print(arr.validate(["a", "a", "a", "a", "a", "a"]))
    # Invalid type, must be string
    print(arr.validate([0, 1, 2, 3, 4, 5]))
    
    # Array of Course
    arr = Array(Course())
    # Valid Course

# Generated at 2022-06-12 15:48:43.536700
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[('a', 'A'), ('b', 'B'), ('c', 'C')], allow_null=True)
    assert field.validate(None) is None
    assert field.validate('') == 'a'

    field = Choice(choices=[('a', 'A'), ('b', 'B'), ('c', 'C')], allow_null=False)
    assert field.validate('a') == 'a'
    try:
        field.validate('d')
    except ValidationError as error:
        assert error.code == 'choice'
    try:
        field.validate(None)
    except ValidationError as error:
        assert error.code == 'null'


# Generated at 2022-06-12 15:48:53.124466
# Unit test for method validate of class Choice
def test_Choice_validate():
    field=Choice(choices=["hi","hello","good morning","good evening","good afternoon", "how are you", "good day"])
    assert field.validate("how are you")=="how are you"
    try:
        field.validate("")
    except ValidationError as error:
        assert error.code=="required"
        assert isinstance(error,ValidationError)
    try:
        field.validate("hi there")
    except ValidationError as error:
        assert error.code=="choice"
        assert isinstance(error,ValidationError)
test_Choice_validate()





# Generated at 2022-06-12 15:48:54.248236
# Unit test for constructor of class Const
def test_Const():
    const = Const(True)
    actual = const.validate(True)
    expected = True
    assert actual == expected


# Generated at 2022-06-12 15:49:05.231468
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[
        ("1", "title1"),
        ("2", "title2"),
        ("3", "title3"),
        ("4", "title4"),
    ])
    expected = None # None value
    result = choice.validate(None)
    assert(expected == result)

    expected = "valid_value"
    result = choice.validate("valid_value")
    assert(expected == result)

    expected = "not_valid_type"
    try:
        result = choice.validate(123)
        assert(False)
    except ValidationError as e:
        result = str(e)
    assert(expected in result)

    expected = "not_existed_value"

# Generated at 2022-06-12 15:49:15.261694
# Unit test for method validate of class String
def test_String_validate():
    string_obj = String(
        title="Name",
        description="",
        allow_blank=True,
        trim_whitespace=False,
        max_length=None,
        min_length=None,
        pattern=None,
        allow_null=False,
        default=NO_DEFAULT,
    )
    # case when value is None and allow_null = False
    try:
        assert string_obj.validate(None) == None
    except ValidationError:
        pass
    # case when value is None and allow_blank = True
    assert string_obj.validate(None) == ""
    # case when value is None and allow_blank = False
    # assert string_obj.validate(None) == ValidationError("Must not be blank.")
    # case when value is not None and value is not String