

# Generated at 2022-06-12 15:40:37.982863
# Unit test for method validate of class Const
def test_Const_validate():
    a = Const(1, )
    assert a.validate(1) == 1
    assert a.validate(2) == None



# Generated at 2022-06-12 15:40:41.430994
# Unit test for constructor of class String
def test_String():
    string = String()
    string = String(title='Foo')
    string = String(description='Bar')
    string = String(default='')
    string = String(default=None)
    string = String(allow_null=True)
    string = String(allow_blank=True)
    string = String(trim_whitespace=True)
    string = String(max_length=15)
    string = String(min_length=50)
    string = String(pattern='')
    string = String(pattern='\d{1,2}')
    string = String(format='date')
    string = String(format='time')
    string = String(format='datetime')
    string = String(format='uuid')



# Generated at 2022-06-12 15:40:49.607786
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Array, Boolean, Integer, String
    a = Field()
    b = Field()
    c = a | b
    assert isinstance(c, Union)
    assert c.any_of == [a, b]

    a = Array(items=Integer())
    b = Array(items=String())
    c = a | b
    assert isinstance(c, Union)
    assert c.any_of == [a, b]

    a = String()
    b = Boolean()
    c = a | b
    assert isinstance(c, Union)
    assert c.any_of == [a, b]

    a = String()
    b = String()
    c = a | b
    assert isinstance(c, Union)
    assert c.any_of == [String()]


# Generated at 2022-06-12 15:40:58.903217
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationResult
    from typesystem.fields import String
    from typesystem.errors import ValidationError
    from typesystem.types import StringType
    instance = String(description="", title="", default=NO_DEFAULT, allow_null=False)
    ret = instance.validate_or_error("abc")
    assert isinstance(ret, ValidationResult)

    try:
        instance = String(description="", title="", default=NO_DEFAULT, allow_null=False)
        ret = instance.validate_or_error(123)
    except ValidationError as e:
        assert True
    else:
        raise Exception("unexpected code")

# Generated at 2022-06-12 15:41:05.321777
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=Integer(), max_items=5).serialize([]) == []
    assert Array(items=Integer(), max_items=5).serialize([1,2,3,4,5]) == [1,2,3,4,5]
    assert Array(items=Integer(), max_items=5).serialize([1,2,3,4,5,6]) == [1,2,3,4,5]

test_Array_serialize()



# Generated at 2022-06-12 15:41:06.661728
# Unit test for method serialize of class String
def test_String_serialize():
    obj = String()
    assert obj.serialize("") == ""



# Generated at 2022-06-12 15:41:11.287213
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    #The function is simply call validate with same input
    class Field_mock(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            assert value == 1
            assert strict == True
    field_mock = Field_mock()
    field_mock.validate_or_error(1, True)
test_Field_validate_or_error()


# Generated at 2022-06-12 15:41:19.516888
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1) == 1
    assert Number().validate(True) == ValidationError
    assert Number().validate(-1.1) == -1.1
    assert Number().validate(-1) == -1
    assert Number().validate(None) == ValidationError
    assert Number().validate('') == ValidationError
    assert Number().validate('123') == 123

# Generated at 2022-06-12 15:41:22.806505
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Test case 1
    class Test1(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            pass
        pass
    obj = Test1()
    assert obj.validate_or_error(value = 1, strict = False) == ValidationResult(value = None, error = None)



# Generated at 2022-06-12 15:41:27.534099
# Unit test for method validate of class Choice
def test_Choice_validate():
    from cg_object_storage.storage.marshmallow.fields import Choice
    choice_field = Choice(
        choices=[('key', 'value'), ('key2', 'value2'), ('key3', 'value3')]
    )
    assert choice_field.validate('key') == 'key'
    assert choice_field.validate('value') == 'key'
    assert choice_field.validate('') == None



# Generated at 2022-06-12 15:41:48.718624
# Unit test for constructor of class String
def test_String():
    def create_string(i):
        return String(
            title=str(i),
            description='',
            default=NO_DEFAULT,
            allow_null=False,
            allow_blank=True,
            trim_whitespace=False,
            max_length=None,
            min_length=None,
            pattern=None,
            format=None,
        )
    INFO = 1000
    assert create_string(1).__dict__ == create_string(2).__dict__
    for i in range(1, INFO + 1):
        assert create_string(i).__dict__ == create_string(i + 1).__dict__



# Generated at 2022-06-12 15:41:55.478024
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array()
    try:
        arr.validate([1,2], strict=False)
        assert True
    except ValidationError:
        assert False
    try:
        arr.validate([1,2], strict=True)
        assert False
    except ValidationError:
        assert True
    try:
        arr.validate(['a', 'b'], strict=False)
        assert True
    except ValidationError:
        assert False
    try:
        arr.validate(['a', 'b'], strict=True)
        assert True
    except ValidationError:
        assert False
    arr.unique_items = True
    try:
        arr.validate([1,1], strict=False)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-12 15:42:04.360385
# Unit test for method validate of class Number
def test_Number_validate():
    Number_validate_result = Number(minimum=10, maximum=20, exclusive_minimum=10, exclusive_maximum=20, multiple_of=1)
    assert Number_validate_result.validate(15) == 15
    # Unit test for method validate of class Float
    Float_validate_result = Float(minimum=1, maximum=2, exclusive_minimum=1, exclusive_maximum=2, multiple_of=0.1)
    assert Float_validate_result.validate(1.5) == 1.5
    # Unit test for method validate of class Int
    Int_validate_result = Int(minimum=1, maximum=2, exclusive_minimum=1, exclusive_maximum=2, multiple_of=1)
    assert Int_validate_result.validate(1) == 1


# Generated at 2022-06-12 15:42:08.920695
# Unit test for method validate of class String
def test_String_validate():
    class test_String_validate(unittest.TestCase):
        def test_1(self):
            field = String()
            self.assertEqual(field.validate(""), "")
        def test_2(self):
            field = String(allow_blank=False)
            self.assertEqual(field.validate(""), "")
        def test_3(self):
            field = String(allow_blank=True)
            self.assertEqual(field.validate(""), "")
        def test_4(self):
            field = String(allow_null=True, allow_blank=True)
            self.assertEqual(field.validate(""), "")
            self.assertEqual(field.validate(None), None)

# Generated at 2022-06-12 15:42:16.032547
# Unit test for method serialize of class Array
def test_Array_serialize():
    items1 = apply_defaults(String())
    items2 = apply_defaults(String())
    obj = apply_defaults(Array(items=[items1, items2]))
    val = ["aaa", "bbb"]
    val2 = ["ccc", "ddd"]
    stored_val = obj.serialize(val)
    stored_val2 = obj.serialize(val2)
    assert stored_val == val
    assert stored_val2 == val2



# Generated at 2022-06-12 15:42:26.525366
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([Integer(), Text(), DateTime()])
    assert u.validate(10) == 10
    assert u.validate("hello") == "hello"
    assert u.validate(datetime.datetime.now()) == u.validate(datetime.datetime.now())
    try:
        u.validate(True)
        assert False
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].text == "Did not match any valid type."
        assert e.messages()[0].code == "union"
    try:
        u.validate(10.0)
        assert False
    except ValidationError as e:
        assert len(e.messages()) == 1

# Generated at 2022-06-12 15:42:31.921363
# Unit test for method validate of class Array
def test_Array_validate():

    road = String(min_length = 1, max_length = 50, required= False, )
    suburb = String(min_length = 1, max_length = 100, required= False, )
    state = String(min_length = 1, max_length = 100, required= False, )
    postcode = Integer(min_value = 1000, max_value = 9999, required= False, )
    street_number = Integer(required= False, )
    street = Object(min_properties = None, max_properties = None, required= False, properties = {
        'suburb': suburb, 
        'state': state, 
        'postcode': postcode, 
        'road': road, 
        'street_number': street_number, 
    }, )
    

# Generated at 2022-06-12 15:42:42.207539
# Unit test for method validate of class Array
def test_Array_validate():
    # --
    # Test for Array
    # --
    # Validate for Array
    schema = Array()
    assert schema.validate([1, 2, 3]) == [1, 2, 3]  # Check with list value
    assert schema.validate((1, 2, 3)) == (1, 2, 3)  # Check with tuple value
    try:
        schema.validate({"a": "b"})  # Check with dict value
    except ValidationError as error:
        assert error.code == "type"
    try:
        schema.validate(None)  # check with None value
    except ValidationError as error:
        assert error.code == "null"

# Generated at 2022-06-12 15:42:45.487123
# Unit test for method validate of class Object
def test_Object_validate():
    my_object=Object()
    my_object.validate({"a": 1})
    assert True


# Generated at 2022-06-12 15:42:51.716779
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[1,2,3])
    assert c.validate(1)==1
    assert c.validate("2")==2
    assert c.validate("hello")=="hello"
    try:
        c.validate("123")==123
    except ValidationError:
        print("choice(123)->ValidationError")


# Generated at 2022-06-12 15:43:20.682251
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("yes", "Yes"), ("no", "No")]
    choice = Choice(choices=choices)
    assert choice.validate("yes") == "yes"
    assert choice.validate("no") == "no"
    with pytest.raises(ValidationError):
        choice.validate("maybe")
    assert choice.validate("") == None
    choice = Choice(choices=choices, allow_null=True)
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate("maybe")
    assert choice.validate("yes") == "yes"


# Generated at 2022-06-12 15:43:31.218057
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number()
    assert a.validate(123) == 123
    assert a.validate(12.3) == 12.3
    assert a.validate(-123) == -123
    assert a.validate(-12.3) == -12.3
    assert a.validate(None) == None
    assert a.validate("123") == 123
    assert a.validate("12.3") == 12.3

    #test the exception handling
    try:
        a.validate("abcd")
    except ValidationError as e:
        assert str(e) == "Must be a number."
    try:
        a.validate(10.0/0)
    except ValidationError as e:
        assert str(e) == "Must be finite."

# Generated at 2022-06-12 15:43:34.383535
# Unit test for method validate of class Array
def test_Array_validate():
    assert all([Array().validate([]),Array().validate([1,2]),Array().validate(["a","b"])])
    assert not all([Array().validate({"a":"b"}),Array().validate("a"),Array().validate("1"),Array().validate(None)])


# Generated at 2022-06-12 15:43:47.032475
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(allow_null=True, allow_blank=True).validate(None) == None
    assert Choice().validate(None) == "null"
    choices = [
        ('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'), ('10', '10')
    ]
    assert Choice(choices=choices).validate('1') == '1'
    assert Choice(choices=choices).validate('2') == '2'
    assert Choice(choices=choices).validate('3') == '3'
    assert Choice(choices=choices).validate('4') == '4'
    assert Choice(choices=choices).valid

# Generated at 2022-06-12 15:43:54.209943
# Unit test for method __or__ of class Field
def test_Field___or__():
    # 1. Create class objects
    field_obj1 = Field()
    field_obj2 = Field()
    # 2. Execute code to be tested
    obj = field_obj1 | field_obj2
    # 3. Asserts
    assert isinstance(obj, Union)
    assert len(obj.any_of) == 2
    assert obj.any_of[0] == field_obj1
    assert obj.any_of[1] == field_obj2



# Generated at 2022-06-12 15:44:04.462057
# Unit test for method validate of class Array
def test_Array_validate():
    # Validating array with field item
    validator = Array(items=Integer(), min_items=2, max_items=2)
    assert(validator.validate([5,5]) == [5,5])
    # Validating array with field item and field additional item
    validator = Array(items=Integer(), additional_items=String(), min_items=2, max_items=3)
    assert(validator.validate([5,5,"Hello"]) == [5,5,"Hello"])
    # Validating array without field item
    validator = Array(additional_items=String(), min_items=1, max_items=10)
    assert(validator.validate(["Hello"]) == ["Hello"])
    # Validating array in case of excessive items

# Generated at 2022-06-12 15:44:07.833537
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=3)
    field.validate([1,2,3])
    field.validate([1])
    field.validate([1,2,3,4])
    

# Generated at 2022-06-12 15:44:12.432765
# Unit test for method serialize of class String
def test_String_serialize():
    obj = "asdf";
    if(String().serialize(obj) != obj):
        print("String().serialize() test failed!")
    else:
        print("String().serialize() test passed!")

test_String_serialize()


# Generated at 2022-06-12 15:44:23.303107
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(
            items=Integer(min_value=1, max_value=4),
            additional_items=False,
        )
    try:
        value = [1, 3]
        expected = [1, 3]
        assert schema.validate(value) == expected
    except Exception as e:
        print (e)
    try:
        value = [1, 3, 5]
        # expected = [1, 3, 5]
        schema.validate(value)
    except Exception as e:
        assert str(e) == 'Must have no more than 2 items.'

    try:
        value = [1, 3, 5]
        expected = [1, 3, 5]
        assert schema.validate(value, strict=True) == expected
    except Exception as e:
        print (e)
# Unit

# Generated at 2022-06-12 15:44:28.305231
# Unit test for method validate of class Number
def test_Number_validate():
    minimum = 0
    maximum = 0
    exclusive_minimum = 0
    exclusive_maximum = 0
    multiple_of = 0
    allow_null = True
    number = Number(minimum=minimum,maximum=maximum, exclusive_minimum=exclusive_minimum, exclusive_maximum=exclusive_maximum,multiple_of=multiple_of,allow_null=allow_null)
    value = 0
    strict = True
    assert number.validate(value=value,strict=strict) == 0


# Generated at 2022-06-12 15:44:42.972136
# Unit test for method validate of class Array
def test_Array_validate():
    myArray = Array(
        items=[
            Integer(min_value=0),
            Integer(max_value=10),
            Integer(min_value=0),
        ],
        min_items=3,
        max_items=3,
    )
    # Test case 1
    test_value=[4, 7, 10]
    result, error  = myArray.validate_or_error(test_value)
    assert result == test_value
    # Test case 2
    test_value=[4, 7, 10]
    result, error  = myArray.validate_or_error(test_value)
    assert result == test_value
    # Test case 3
    test_value=[4, 7, 10]
    result, error  = myArray.validate_or_error(test_value)
    assert result

# Generated at 2022-06-12 15:44:44.382387
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert f.get_default_value() is None
test_Field_get_default_value()
    

# Generated at 2022-06-12 15:44:46.634107
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(1, allow_null=True)


# Test Const class

# Generated at 2022-06-12 15:44:50.356894
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None

    field.default = 123
    assert field.get_default_value() == 123

    def default_fn():
        return 321

    field.default = default_fn
    assert field.get_default_value() == 321



# Generated at 2022-06-12 15:44:59.969134
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["a", "b", "c"])
    assert(c.validate("b") == "b")
    assert(c.validate("a") == "a")
    assert(c.validate("c") == "c")
    try:
        assert(c.validate("e") == "c")
    except ValidationError as e:
        assert(e.text=="Not a valid choice.")
    c = Choice(choices=[("a", "aa"), ("b", "bb"), ("c", "cc")])
    assert(c.validate("b") == "b")
    assert(c.validate("a") == "a")
    assert(c.validate("c") == "c")

# Generated at 2022-06-12 15:45:07.923260
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("1", 1), "2", ("3", "three")])
    assert c.validate("1") == 1
    assert c.validate("2") == "2"
    assert c.validate("3") == "three"
    assert c.validate(1) == 1
    assert c.validate(2) == "2"
    assert c.validate(3) == "three"
    # assert c.validate(4) == "validate_error"
    assert c.validate(None) == "validate_error"



# Generated at 2022-06-12 15:45:12.488833
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format="date")
    date_before  = datetime.date(2020, 6, 11)
    date_after = s.serialize(date_before)
    date_expected = date_before.isoformat()
    assert date_after == date_expected



# Generated at 2022-06-12 15:45:17.720708
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Teste du nom du fichier (regarder le retour de message d'erreur)
    # Teste la valeur entrée correspond à la valeur sortie à l'aide de la fonction assertEqual(value,value)
    assertEqual(Boolean().validate(False),False)
    assertEqual(Boolean().validate(True),True)
    assertEqual(Boolean().validate(""),None)
    assertEqual(Boolean().validate("1"),True)
    assertEqual(Boolean().validate(1),True)
    assertEqual(Boolean().validate("0"),False)
    assertEqual(Boolean().validate(0),False)
    assertEqual(Boolean().validate("null"),None)

# Generated at 2022-06-12 15:45:21.433684
# Unit test for constructor of class Const
def test_Const():
    try:
        a = Const(const=1)

    except Exception as e:
        print(e)


# Generated at 2022-06-12 15:45:32.389267
# Unit test for method __or__ of class Field
def test_Field___or__():
    import jsonpickle
    import jsonpickle.tags.enaml
    from unittest.case import TestCase

    class TestField___or__(TestCase):
        def test_union_field(self):
            # noinspection PyTypeChecker
            class TestSchema(Schema):
                string_or_number = String() | Integer()
            schema = TestSchema()

            self.assertEqual(schema.serialize({"string_or_number": "hello"}),
                             {"string_or_number": "hello"})
            self.assertEqual(schema.serialize({"string_or_number": 42}),
                             {"string_or_number": 42})


# Generated at 2022-06-12 15:45:48.914571
# Unit test for constructor of class String
def test_String():
    s = String()
    assert isinstance(s, String)


# Generated at 2022-06-12 15:45:49.495452
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    pass



# Generated at 2022-06-12 15:45:56.530910
# Unit test for method validate of class Object
def test_Object_validate():
    class Foo(Field):
        errors = {
            "type": "Must be a string.",
            "required": "This field is required.",
        }
        def validate(self, value, *, strict: bool = False) -> typing.Any:
            return value

    class Bar(Object):
        properties = {"foo": Foo()}

    b = Bar(required=["foo"])
    assert b.validate({"foo": "some"}) == {"foo": "some"}
    with pytest.raises(ValidationError) as excinfo:
        b.validate({})
    assert excinfo.value.messages()[0].text == "This field is required."


# Generated at 2022-06-12 15:46:01.940501
# Unit test for method serialize of class String
def test_String_serialize():
    def test_String_serialize():
        s = String('time')
        assert s.serialize(datetime.time(12, 30, 30, 30)) == datetime.time(12, 30, 30, 30)
    test_String_serialize()



# Generated at 2022-06-12 15:46:12.282430
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None, strict=False) == False
    assert b.validate(None, strict=True) == None
    assert b.validate("", strict=False) == False
    assert b.validate("true", strict=False) == True
    assert b.validate("false", strict=False) == False
    assert b.validate("on", strict=False) == True
    assert b.validate("off", strict=False) == False
    assert b.validate("1", strict=False) == True
    assert b.validate("0", strict=False) == False
    assert b.validate(1, strict=False) == True

# Generated at 2022-06-12 15:46:21.069150
# Unit test for method validate of class Choice
def test_Choice_validate():
    from src.exceptions.main import ValidationError
    from src.fields.base import Choice

    try:
        Choice(choices=["a", "b", "c"]).validate("a")
    except ValidationError:
        assert False
    else:
        assert True

    try:
        Choice(choices=["a", "b", "c"]).validate("")
    except ValidationError:
        assert True
    else:
        assert False

    try:
        Choice(choices=["a", "b", "c"]).validate("z", strict=True)
    except ValidationError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 15:46:31.945829
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """
    This test will check if the Field.get_default_value() works
    """
    with pytest.raises(AssertionError):
        Field(default="")

    field = Field(default=None, allow_null=True)
    assert field.get_default_value() is None
    assert field.get_default_value() is None

    field2 = Field(default=123)
    assert field2.get_default_value() == 123
    assert field2.get_default_value() == 123

    field3 = Field(default=lambda: "foo")
    assert field3.get_default_value() == "foo"
    assert field3.get_default_value() == "foo"



# Generated at 2022-06-12 15:46:39.607741
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    assert a.validate([]) == []

    a = Array(min_items=1)
    with pytest.raises(ValidationError):
        a.validate([])

    a = Array(max_items=2)
    with pytest.raises(ValidationError):
        a.validate([1, 2, 3])

    a = Array(items=String())
    assert a.validate(["1", "2", "3"]) is None

    a = Array(items=String(), max_items=2)
    with pytest.raises(ValidationError):
        a.validate(["1", "2", "3"])

    a = Array(items=String(), min_items=2)

# Generated at 2022-06-12 15:46:42.607272
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Create a Union Object
    union = Union(any_of=[])

    # Create a Field object
    field = Field()

    assert (field or union).any_of == [field]



# Generated at 2022-06-12 15:46:54.021344
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """
    test method get_default_value of class Field
    """
    # 使用默认值
    f1 = Field(default=1)
    assert f1.get_default_value() == 1

    # 使用默认值的情况下，未定义的属性应该提示AttributeError
    try:
        f1.get_default_value_should_error()
        assert False
    except AttributeError:
        assert True

    # 使用自定义函数作为默认值
    def custom_func(): return 3

    f2 = Field(default=custom_func)
    assert f2

# Generated at 2022-06-12 15:47:15.686825
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['test_value'])
    test_value = 'test_value'
    expected_result = 'test_value'
    assert(choice.validate(test_value) == expected_result)
    
    test_value = 'wrong_value'
    expected_result = 'choice'
    assert(choice.validate(test_value).code == expected_result)
    
    choice = Choice(choices=['test_value'], allow_null=True)
    test_value = None
    expected_result = None
    assert(choice.validate(test_value) == expected_result)



# Generated at 2022-06-12 15:47:19.297068
# Unit test for method serialize of class String
def test_String_serialize():
    string_test = String(default="test")
    string_test_serialize = string_test.serialize("test")
    print(string_test_serialize)
    assert string_test_serialize == "test"


# Generated at 2022-06-12 15:47:24.460500
# Unit test for method validate of class Array
def test_Array_validate():
    # setup
    class ValidationSchema(Schema):
        title = Text()

    schema = Array(
        items=ValidationSchema(title="test"),
    )

    # test
    assert schema.validate(
        [{"title": "test"}]
    ) == [{"title": "test"}]

    # test
    assert schema.validate(
        []
    ) == []



# Generated at 2022-06-12 15:47:30.674749
# Unit test for constructor of class Array
def test_Array():
    field = Array(min_items=1, max_items=1)
    assert field.min_items == 1
    assert field.max_items == 1
    field = Array(unique_items=True)
    assert field.unique_items == True
    field = Array(items=["test"], unique_items=True)
    assert isinstance(field.items, list) == True
    assert isinstance(field.items[0], str) == True
    field = Array(exact_items=2)
    assert field.min_items == 2
    assert field.max_items == 2
    field = Array(min_items=1, max_items=1, exact_items=2)
    assert field.min_items == 2
    assert field.max_items == 2


# Generated at 2022-06-12 15:47:32.925115
# Unit test for method __or__ of class Field
def test_Field___or__():
    _self_0 = Field()
    _other_0 = Field()
    _out_0 = _self_0.__or__(_other_0)

# Generated at 2022-06-12 15:47:37.378942
# Unit test for method validate of class String
def test_String_validate():
    assert String(title='pro', description='testing').validate("kkk") == 'kkk'
    assert String(title='pro', description='testing').validate("123") == '123'
    assert String(title='pro', description='testing').validate("@!##") == '@!##'
    assert String(title='pro', description='testing').validate("") == ''
    assert String(title='pro', description='testing').validate("\0") == ''


# Generated at 2022-06-12 15:47:42.894079
# Unit test for method validate of class Array
def test_Array_validate():
    # Test code
    if __name__ == "__main__":
        a = [1, 2, 3]
        b = Array(items=Number(), min_items=1)
        assert b.validate(None) == None
        assert b.validate(a) == a



# Generated at 2022-06-12 15:47:48.127974
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    def default_callable():
        return 123

    field = Field(default=123)
    assert field.get_default_value() == 123

    field = Field(default=default_callable)
    assert field.get_default_value() == 123

# Generated at 2022-06-12 15:47:54.006554
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object()
    obj1 = Object()
    obj2 = Object()
    obj3 = Object()
    obj4 = Object()
    obj5 = Object()
    obj6 = Object()
    obj7 = Object()
    obj8 = Object()
    obj9 = Object()
    obj10 = Object()
    obj11 = Object()
    obj12 = Object()
    obj13 = Object()
    obj14 = Object()
    obj15 = Object()
    obj16 = Object()
    obj17 = Object()
    obj18 = Object()
    obj19 = Object()
    obj20 = Object()
    obj21 = Object()
    obj22 = Object()
    obj23 = Object()
    obj24 = Object()
    obj25 = Object()
    obj26 = Object()
    obj27 = Object()

# Generated at 2022-06-12 15:47:57.988300
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('first', 'first'),('second', 'second')])
    result = choice.validate('first')
    expected = 'first'
    assert result == expected

# Generated at 2022-06-12 15:48:12.402748
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array(items=[String(),Integer()],unique_items=True)
    try:
        a.validate([1,2,3])
    except ValidationError as e:
        print(e.messages)
    try:
        a.validate([1,2,1])
    except ValidationError as e:
        print(e.messages)


if __name__ == "__main__":
    test_Array_validate()

# Generated at 2022-06-12 15:48:14.254432
# Unit test for method validate of class String
def test_String_validate():
    x = String(format='time')
    x.validate('12:35')

# Generated at 2022-06-12 15:48:22.340948
# Unit test for constructor of class Array
def test_Array():
    class Address(Object):
        country = Optional[String(default="India")]

    class User(Object):
        name = String(max_length=32, min_length=2)
        age = Int(max_value=100, min_value=18)
        gender = Choice(choices=["male", "female"])
        cards = Array(items=String())
        addresses = Array(items=Address())
        tasks = Array(
            items=Array(
                items=Object(
                    properties={
                        "title": String(),
                        "done": Boolean(),
                    }
                )
            )
        )

    user = User()

    assert isinstance(user.items, type(None))
    assert user.min_items is None
    assert user.max_items is None
    assert user.unique_items is False



# Generated at 2022-06-12 15:48:28.207574
# Unit test for method validate of class Choice
def test_Choice_validate():
    
    choices = [(1,1),(2,2),(3,3),(4,4),(5,5)]
    choice = Choice(choices=choices)
    values = (1, 2, 3, 4, 5)
    for value in values:
        assert choice.validate(value) == value, "Error"
    assert choice.validate(None) == None, "Error"
    assert choice.validate("") == None, "Error"
    
    
    
    
    
    


# Generated at 2022-06-12 15:48:31.457210
# Unit test for method validate of class String
def test_String_validate():
    str = String()
    print("String.validate: ",str.validate("eu sunt un string"))
    print("String.validate: ",str.validate("eu sunt un string", strict=False))


# Generated at 2022-06-12 15:48:34.317583
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice_choice = Choice(name='choice', choices=['male', 'female'])
    assert Choice_choice.validate(value=None) == None


# Generated at 2022-06-12 15:48:42.143030
# Unit test for constructor of class Array
def test_Array():
    a = Array()
    b = Array(max_items=10)
    c = Array(min_items=1)
    d = Array(max_items=10, min_items=1)
    e = Array(max_items=10, min_items=0)
    f = Array(max_items=0)
    g = Array(min_items=10)
    h = Array(max_items=0, min_items=10)
    print("TESTING FOR ARRAY")
    print("-----------------")
    print("Default Array: ")
    print(a)
    print("Array with max_items=10: ")
    print(b)
    print("Array with min_items=1: ")
    print(c)

# Generated at 2022-06-12 15:48:46.098621
# Unit test for method __or__ of class Field
def test_Field___or__():
    f1 = String('','')
    f2 = String('','')
    f3 = f1 | f2
    assert f3.any_of == [f1, f2]


# Generated at 2022-06-12 15:48:59.124634
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()

    assert number.validate(None, strict=True) is None
    assert str(number.validate(None)) == ""
    assert number.validate(None, strict=True) is None
    assert number.validate(None) == None
    assert number.validate("") == 0
    assert number.validate(1) == 1
    assert number.validate(1.1) == 1.1
    assert number.validate("1") == 1
    assert number.validate("1.1") == 1.1
    # Invalid values.
    with pytest.raises(ValidationError) as exc_info:
        number.validate(True)
    assert str(exc_info.value) == "Must be a number."


# Generated at 2022-06-12 15:49:07.811988
# Unit test for method validate of class Object
def test_Object_validate():
    fields = {"address": String(), "birthday": DateTime()}
    properties = {"name": String(), "phone": String()}
    schema = Object(
        fields,
        required=["name"],
        properties=properties,
        min_properties=1,
        max_properties=2
    )
    data = {
        "name": "Jack",
        "phone": "0987654321",
        "address": "Taipei City",
        "birthday": "2000-01-01 00:00:00",
        "id": "1234123"
    }
    result = schema.validate(data)