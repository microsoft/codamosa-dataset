

# Generated at 2022-06-12 15:41:37.915424
# Unit test for method validate of class Array
def test_Array_validate():
    print("\n\nUnit test for method validate of class Array")
    # array_object = Array(allow_null=False)
    # result = array_object.validate(None)
    # print("result is " + str(result))   # expect raise error
    
    array_object = Array(allow_null=True)
    result = array_object.validate(None)
    print("result is " + str(result))   # expect None
    
    array_object = Array(allow_null=False, max_items=2)
    result = array_object.validate([1, 2, 3])
    print("result is " + str(result))   # expect raise error

    array_object = Array(allow_null=False, min_items=1)
    result = array_object.validate([])
    print

# Generated at 2022-06-12 15:41:48.450102
# Unit test for method validate of class Object
def test_Object_validate():
    def func():
        return {
            "properties": {"a": Integer(),
                           "b": String()},
            "additional_properties": String(),
            "required": ["a", "b"],
        }
    field = Object(**func())
    schema = {
        "a": 100,
        "b": "abcd",
        "c": "efgh",
        "d": "efgh",
    }
    assert field.validate(schema) == schema
    schema = {
        "a": 100,
        "b": "abcd",
        "c": "efgh",
    }
    assert field.validate(schema) == schema
    schema = {
        "a": 100,
        "b": "abcd",
        "c": [],
        "d": {},
    }

# Generated at 2022-06-12 15:41:55.254751
# Unit test for constructor of class String
def test_String():
    assert isinstance(String(), String)
    assert isinstance(String(title="title"), String)
    assert isinstance(String(description="description"), String)
    assert isinstance(String(default="default"), String)
    assert isinstance(String(allow_null=True), String)
    assert isinstance(String(allow_blank=True), String)
    assert isinstance(String(trim_whitespace=True), String)
    assert isinstance(String(max_length=10), String)
    assert isinstance(String(min_length=1), String)
    assert isinstance(String(pattern="^[a-z]+$"), String)
    assert isinstance(String(format="date"), String)
    assert isinstance(String(other="other"), String)

# Generated at 2022-06-12 15:42:04.297271
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    _boolean = Boolean(allow_null=True)
    assert _boolean.validate('true') == True, "Coercion did not work"
    assert _boolean.validate('false') == False, "Coercion did not work"
    assert _boolean.validate('1') == True, "Coercion did not work"
    assert _boolean.validate('0') == False, "Coercion did not work"
    assert _boolean.validate('on') == True, "Coercion did not work"
    assert _boolean.validate('off') == False, "Coercion did not work"
    assert _boolean.validate('') == False, "Coercion did not work"
    assert _boolean.validate(1) == True, "Coercion did not work"
   

# Generated at 2022-06-12 15:42:12.840074
# Unit test for method __or__ of class Field
def test_Field___or__():
  from typesystem import types, pydantic
  from typesystem.union import Union
  from typesystem.fields import Field
  from typesystem.structures import Schema
  s = Schema(field1=Union(types.String, types.Integer), field2=Union(types.String, types.Integer))
  assert isinstance(s.field1.any_of[0], types.String)
  assert isinstance(s.field1.any_of[1], types.Integer)
  assert isinstance(s.field2.any_of[0], types.String)
  assert isinstance(s.field2.any_of[1], types.Integer)

  s.field1 = Union(types.String) | types.Integer
  assert isinstance(s.field1.any_of[0], types.String)
  assert isinstance

# Generated at 2022-06-12 15:42:22.585046
# Unit test for method validate of class Union
def test_Union_validate():
    """
    Unit test for method validate of class Union
    """
    obj = Union([Number(), String()])
    #------
    value = "value"
    res = obj.validate(value, strict=True)
    # res == value
    #------
    value = 1.0
    res = obj.validate(value, strict=True)
    # res == value
    #------
    validator = Union([String(), Number()])
    value = "10"
    res = validator.validate(value, strict=True)
    assert res == value
    #------
    validator = Union([String(), Number()])
    value = 10
    res = validator.validate(value, strict=True)
    assert res == value
    #------
    union = Union([String(), Number()])

# Generated at 2022-06-12 15:42:29.747836
# Unit test for method serialize of class String
def test_String_serialize():
    from typesystem.base import format_validation_error_message
    import datetime
    class String1(String):
        def __init__(self, *, format = 'datetime', **kwargs):
            super(String1, self).__init__(format = format, **kwargs)
    field = String1()
    expected_result = "2019-02-15"
    try:
        actual_result = field.serialize(datetime.datetime(2019,2,15))
    except Exception:
        assert False, format_validation_error_message("Method serialize of class String should serialize datetime", 
                                                       field, datetime.datetime(2019,2,15))

# Generated at 2022-06-12 15:42:36.467178
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    union1 = Union(any_of=[field1, field2])
    union2 = Union(any_of=[field2, field3])
    assert (field1 | field2) == union1
    assert (field1 | field2 | field3) == (union1 | union2)



# Generated at 2022-06-12 15:42:38.183090
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=5, maximum=10).validate(value=6) == 6


# Generated at 2022-06-12 15:42:45.987822
# Unit test for method validate of class Choice

# Generated at 2022-06-12 15:42:58.418389
# Unit test for constructor of class String
def test_String():
    n = String()
    assert n.validate('aha') == 'aha'
    assert n.validate('a') == 'a'
    assert not n.validate('') == ''


# Generated at 2022-06-12 15:43:05.029722
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        assert Choice().validate(None) == None
    except ValidationError:
        assert False
    try:
        assert Choice().validate(0) == 0
    except ValidationError:
        assert False
    try:
        Choice().validate(None,strict=True) == None
    except ValidationError:
        assert True
    try:
        Choice(allow_null=True).validate(None) == None
    except ValidationError:
        assert False
    try:
        Choice().validate('Vu') == 'Vu'
    except ValidationError:
        assert False



# Generated at 2022-06-12 15:43:11.603176
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # case 1:
    field = Field(default="value")
    assert field.get_default_value() == "value"

    # case 2:
    field = Field(default=lambda: "value")
    assert field.get_default_value() == "value"
    field.default = 'value'
    assert field.get_default_value() == "value"


test_Field_get_default_value()


# Generated at 2022-06-12 15:43:18.105992
# Unit test for method __or__ of class Field
def test_Field___or__():
    """Unit test for method __or__ of class Field."""
    f1 = Field(description='description1')
    f2 = Field(description='description2')
    union = f1 | f2
    assert isinstance(union, Union)
    assert union.any_of[0] == f1
    assert union.any_of[1] == f2
    union2 = union | f1
    assert isinstance(union2, Union)
    assert union2.any_of[0] == f1
    assert union2.any_of[1] == f2
    assert union2.any_of[2] == f1

    union3 = Field(description='description3') | union2
    assert isinstance(union3, Union)
    assert union3.any_of[0] == f3
    assert union3.any_

# Generated at 2022-06-12 15:43:20.186765
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate(123) == "123"
    assert field.validate(None) == None
    assert field.validate(123) == "123"
    assert field.validate(None) == None
    assert field.validate(123) == "123"



# Generated at 2022-06-12 15:43:28.962915
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate("10") == 10
    assert number.validate("10.5") == 10.5
    assert number.validate("10.5") == 10.5
    number = Number(allow_null=True)
    assert number.validate("") is None
    number = Number(multiple_of=2)
    assert number.validate("10") == 10
    assert number.validate("10.5") == 10.5
    assert number.validate("10.5") == 10.5

if __name__ == '__main__':
    test_Number_validate()


# Generated at 2022-06-12 15:43:34.821983
# Unit test for method validate of class Choice
def test_Choice_validate():
    from validator import Choice, ValidationError

    my_choice = Choice(choices=("apple", "orange", "grape"))
    assert my_choice.validate("apple") == "apple"
    assert my_choice.validate("orange") == "orange"
    assert my_choice.validate("grape") == "grape"
    try:
        my_choice.validate("banana")
    except ValidationError:
        pass
    else:
        assert False
        


# Generated at 2022-06-12 15:43:47.076483
# Unit test for method serialize of class Array
def test_Array_serialize():
    valid_items_1 = [Integer(maximum = 100),Integer(maximum = 100),Integer(maximum = 100)]
    value = Array(items=valid_items_1)
    value._allow_null = True
    value._allow_empty = True
    obj = [4,4,4]
    expected_value = [4,4,4]
    actual_value = value.serialize(obj)
    assert actual_value == expected_value

    valid_items_1 = [Integer(maximum = 100),Integer(maximum = 100),Integer(maximum = 100)]
    value = Array(items=valid_items_1)
    value._allow_null = False
    value._allow_empty = True
    obj = [4,4,4]
    expected_value = [4,4,4]

# Generated at 2022-06-12 15:43:53.720569
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format='uuid').serialize('0b93a8f1-e368-4f49-a7d2-d91377f8ba8c') == '0b93a8f1-e368-4f49-a7d2-d91377f8ba8c'
    assert String(format='uuid').serialize(None) == None
    assert String().serialize('') == ''


# Generated at 2022-06-12 15:43:57.158822
# Unit test for method validate of class Boolean
def test_Boolean_validate():
  a=Boolean()
  assert a.validate(None)==None
  assert a.validate("")==False
  assert a.validate("1")==True


# Generated at 2022-06-12 15:44:09.805392
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=[("1", "1"), ("2", "2")])
    assert field.choices == [("1", "1"), ("2", "2")]
    field = Choice(choices=["1", "2"])
    assert field.choices == [("1", "1"), ("2", "2")]



# Generated at 2022-06-12 15:44:21.182332
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    
    class CustomField(Field):
        def __init__(self, *, title: str = "", description: str = ""):
            super().__init__(title=title, description=description)
        def get_default_value(self):
            return "N/A"
    
    # default value is a string
    field = CustomField()
    expected = "N/A"
    assert expected == field.get_default_value()

    # default value is None
    field.default = None
    expected = None
    assert expected == field.get_default_value()
    
    # default value is object
    field.default = NO_DEFAULT
    expected = NO_DEFAULT
    assert expected == field.get_default_value()
    
    # default value is function that returns a string

# Generated at 2022-06-12 15:44:29.441843
# Unit test for method validate of class String
def test_String_validate():
    # check if the value is a string
    test_obj = String()
    assert test_obj.validate("string") == "string"
    with pytest.raises(ValidationError, match="Must be a string."):
        test_obj.validate(0)
    # check if the value is not None
    test_obj = String(default="", allow_null=False)
    assert test_obj.validate("string") == "string"
    with pytest.raises(ValidationError, match="May not be null."):
        test_obj.validate(None)
    # check if the value is not blank
    test_obj = String(default="", allow_blank=False)
    assert test_obj.validate("string") == "string"

# Generated at 2022-06-12 15:44:32.331483
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert(Field.get_default_value() is None)
    assert(Field.get_default_value() == Field.get_default_value())

# Generated at 2022-06-12 15:44:42.989412
# Unit test for method validate of class Union
def test_Union_validate():
    from jsl import StringField, IntField, Document
    from jsl.validators import StringFormat, StringRegex

    class Regex(StringRegex):
        pattern = re.compile("^.*$")
        error_messages = {"regex": "Did not match pattern."}

    u = Union([StringField(format="uri"), StringField(format="email")], title="link")
    v, error = u.validate_or_error("https://google.com")
    assert v == "https://google.com", "Unit test for method validate of class Union failed"

    # Test additional_properties
    class SubString(StringField):
        def __init__(self, **kwargs) -> None:
            super().__init__(**kwargs)

# Generated at 2022-06-12 15:44:48.744135
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        def validate(self, value, *, strict=False):
            if value == 1:
                raise self.validation_error("code1")
            return value
        errors = {
            "code1": "error1"
        }
    class Field2(Field):
        def validate(self, value, *, strict=False):
            if value == 2:
                raise self.validation_error("code1")
            return value
        errors = {
            "code1": "error1"
        }
    class Field3(Field):
        def validate(self, value, *, strict=False):
            if value == 3:
                raise self.validation_error("code1")
            return value
        errors = {
            "code1": "error1"
        }

# Generated at 2022-06-12 15:44:58.626989
# Unit test for method validate of class Array
def test_Array_validate():
    with pytest.raises(ValidationError):
        assert Array(String()).validate(["foo", 1])  # type: ignore
    with pytest.raises(ValidationError):
        assert Array(Number()).validate(["foo", 1])  # type: ignore
    with pytest.raises(ValidationError):
        assert Array(String(), Number()).validate(["foo", 1, "bar"])  # type: ignore
    with pytest.raises(ValidationError):
        assert Array(String(), allow_null=True).validate(None)  # type: ignore
    with pytest.raises(ValidationError):
        assert Array(String(), allow_null=False).validate(None)  # type: ignore

# Generated at 2022-06-12 15:45:03.647537
# Unit test for method validate of class Union
def test_Union_validate():
    from .base import Field

    class TestClass(Field):
        errors = {"test": "test"}

        def validate(self, value, strict=False):
            return value, None

    f = Union(any_of=[String(), TestClass()])

    value, error = f.validate_or_error("test")
    assert value == "test"
    assert error is None

    value, error = f.validate_or_error("test", strict=True)
    assert value == "test"
    assert error is None

    value, error = f.validate_or_error(1)
    assert value == 1
    assert error is None

    with pytest.raises(ValidationError):
        f.validate(1, strict=True)


# Generated at 2022-06-12 15:45:08.068793
# Unit test for method validate of class Array
def test_Array_validate():
    data = Array(items='string')
    
    # True
    if data.validate(['str', 'str1']) == ['str', 'str1']:
        print('validate_method_true')

   

# Generated at 2022-06-12 15:45:18.037691
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    c1 = c.validate(value="a",strict=False)
    assert c1 == "a"
    c2 = c.validate(value=None,strict=False)
    assert c2 is None
    c3 = c.validate(value="c",strict=False)
    assert c3 is None
    c4 = c.validate(value="",strict=False)
    assert c4 is None
    c5 = c.validate(value=["a","b"],strict=False)
    assert c5 is None
    c6 = c.validate(value="a",strict=True)
    assert c6 == "a"



# Generated at 2022-06-12 15:45:28.982763
# Unit test for method __or__ of class Field
def test_Field___or__():
    class TestField(Field):
        errors = {
            "required": "This field is required",
        }

        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value
    test_field = TestField()

# Generated at 2022-06-12 15:45:36.119548
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).validate(1) == 1
    with pytest.raises(ValidationError) as excinfo:
        Const(const=1).validate(2)
    assert excinfo.value.messages()[0].text == "Must be the value '1'."
    assert Const(const=None).validate(None) is None
    with pytest.raises(ValidationError) as excinfo:
        Const(const=None).validate(1)
    assert excinfo.value.messages()[0].text == "Must be null."


# Generated at 2022-06-12 15:45:38.432731
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Integer, Float
    field_int_float = Integer() | Float()
    assert isinstance(field_int_float, Union)



# Generated at 2022-06-12 15:45:45.037240
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        def validate(self, value, *, strict=False):
            return value

    f = MyField(default="foo")
    assert f.get_default_value() == "foo"

    f = MyField(default=lambda: "foo")
    assert f.get_default_value() == "foo"

    f = MyField(default="foo", allow_null=True)
    assert f.get_default_value() == None


# Generated at 2022-06-12 15:45:49.983367
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_cases = [(None, 'null'), ('', 'required'), ('invalid', 'choice')]
    f = Choice(choices = ['valid'], allow_null = True)
    for v, e in test_cases:
        result = f.validate_or_error(v)
        assert result.error.code == e
        assert isinstance(result, ValidationResult)
    pass



# Generated at 2022-06-12 15:45:57.151716
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[(1,2),(2,3)])
    assert field.validate(1) == 1
    #Test the method in case the value is not in choices
    try:
        field.validate(3)
    except ValidationError:
        print("The value is not in choices")
    #Test the method in case the value is blank
    try:
        field.validate('')
    except ValidationError:
        print("The value is blank")
    #Test the method in case the value is null
    try:
        field.validate('')
    except ValidationError:
        print("The value is null")

# Test for method has_default of class Choice

# Generated at 2022-06-12 15:46:01.842317
# Unit test for method validate of class String
def test_String_validate():
    string = String(title='Test String')
    try:
        string.validate(1)
        assert(False)
    except ValidationError as e:
        assert(True)


# Generated at 2022-06-12 15:46:03.569044
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert (Field() | Field())
    assert (Field() | Union())



# Generated at 2022-06-12 15:46:09.362108
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Field_Test(Field):
        def __init__(self,*args,**kwargs):
            super().__init__(*args, **kwargs)
            self.default = 'a'

    f = Field_Test(title="test")

    assert f.get_default_value() == 'a'
    assert hasattr(f, "default") == True



# Generated at 2022-06-12 15:46:15.952370
# Unit test for constructor of class Choice
def test_Choice():

    # Test with different choices
    assert Choice(choices=[True, False]).choices == [(True, True), (False, False)]
    assert Choice(choices=[3, 4]).choices == [(3, 3), (4, 4)]

    # Test with no choices
    assert Choice().choices == []


# Generated at 2022-06-12 15:46:45.155628
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array()
    arr.validate([1,2])

# Generated at 2022-06-12 15:46:49.669973
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b"]).validate("a") == "a"
    assert Choice(choices=["a", "b"]).validate("b") == "b"
    assert Choice(choices=["a", "b"]).validate("x") == None



# Generated at 2022-06-12 15:46:58.204996
# Unit test for method validate of class Union
def test_Union_validate():

    class TestSchema(Schema):
        int_field = Integer(location="query")
        str_field = String(location="query")
        union_field = Union(any_of=[Integer(location="query"), String(location="query")])

    str_value = "123"
    int_value = 123

    # Case of exception
    # Case of exception when value is None
    query = {"union_field": None}
    try:

        TestSchema().validate(query)
    except ValidationError as e:
        assert e.messages()[0].message == "May not be null." and e.messages()[0].code == "null"
    # Case of exception when value is failed to match any of valid type
    query = {"union_field": "bad value"}

# Generated at 2022-06-12 15:47:08.317180
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field(title='test1')
    field2 = Field(title='test2')
    field3 = Field(title='test3')

    union1 = field1 | field2
    assert isinstance(union1, Union)
    assert union1.any_of == [field1, field2]

    union2 = union1 | field3
    assert isinstance(union2, Union)
    assert union2.any_of == [field1, field2, field3]

    union3 = field3 | union1
    assert isinstance(union3, Union)
    assert union3.any_of == [field3, field1, field2]



# Generated at 2022-06-12 15:47:13.289352
# Unit test for method validate of class Object
def test_Object_validate():
    class TestSchema(Schema):
        test = Object(properties={"subfield": String(max_length=2)})

    schema = TestSchema()
    data = schema.load({"test":{"subfield":"test"}})
    assert data == {"test": {"subfield": "test"}}


# Generated at 2022-06-12 15:47:22.005547
# Unit test for constructor of class Array
def test_Array():
    array = Array(name="test_array")
    assert array.name == "test_array"

    # Test constructor named arguments
    array = Array(name="test_array", descriptions="This is a array", nullable=True)
    assert array.name == "test_array"
    assert array.descriptions == "This is a array"
    assert array.allow_null == True

    # Test constructor nameless arguments
    array = Array("test_array", "This is a array", True, True)
    assert array.name == "test_array"
    assert array.descriptions == "This is a array"
    assert array.allow_null == True

# Generated at 2022-06-12 15:47:22.888994
# Unit test for method validate of class Array
def test_Array_validate():
    pytest.fail("all tests pass")
    #assert False
    
    
    



# Generated at 2022-06-12 15:47:29.705705
# Unit test for method validate of class Object
def test_Object_validate():
    from pydantic import BaseModel
    from pydantic.main import create_model
    from xeries.fields import Object
    from xeries.types import ObjectType
    from xeries.errors import ValidationError

    class User(BaseModel):
        name: str
        score: int

    class Question(BaseModel):
        title: str
        type: ObjectType = "object"
        properties: typing.Dict[str, Field] = None
        pattern_properties: typing.Dict[str, Field] = None
        additional_properties: typing.Union[bool, None, Field] = True
        property_names: Field = None
        min_properties: int = 1
        max_properties: int = 4
        required: typing.Sequence[str] = None


# Generated at 2022-06-12 15:47:37.506373
# Unit test for method validate of class Number
def test_Number_validate():
    my_int = Number(maximum=10, multiple_of=2)
    assert my_int.validate(0) == 0
    assert my_int.validate(2) == 2
    assert my_int.validate(8) == 8
    with pytest.raises(ValidationError):
        my_int.validate(11)
    with pytest.raises(ValidationError):
        my_int.validate(12)
    with pytest.raises(ValidationError):
        my_int.validate(15)
    with pytest.raises(ValidationError):
        my_int.validate(20)
    with pytest.raises(ValidationError):
        my_int.validate(100)
    with pytest.raises(ValidationError):
        my_int.valid

# Generated at 2022-06-12 15:47:50.574462
# Unit test for method validate of class Array
def test_Array_validate():
    def test_1():
        #arrange
        field=Array()
        input=[1,2]
        expected=[1,2]
        
        #act
        result=field.validate(input)
        
        #assert
        assert expected==result
    test_1()
    def test_2():
        #arrange
        field=Array()
        input=None
        expected=None
        
        #act
        result=field.validate(input)
        
        #assert
        assert expected==result
    test_2()

    def test_3():
        #arrange
        field=Array()
        input=3
        expected=3
        with pytest.raises(ValidationError) as e:
            #act
            result=field.validate(input)
        #assert

# Generated at 2022-06-12 15:48:09.664652
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field(default='default value').get_default_value() == 'default value'
    assert Field(default=lambda: 'default value').get_default_value() == 'default value'
    assert Field().get_default_value() == None


"""
String field.
"""



# Generated at 2022-06-12 15:48:13.924563
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # 1. Arrange
    # 2. Act
    # 3. Assert

    class DField(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return obj

    empty_default=DField()
    assert empty_default.get_default_value() == None
    assert empty_default.has_default() == False

    #### test for get_default_value with a default string
    class SDField(Field):
        def __init__(self, default="ThisIsDefault", *, title=None, description=None, allow_null=False):
            super().__init__(title=title, description=description, allow_null=allow_null)
            self.default = default
        def serialize(self, obj: typing.Any) -> typing.Any:
            return obj

    d

# Generated at 2022-06-12 15:48:17.722586
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[("A", "a"), ("B", "b")]).validate("A") == 'A'
    assert Choice(allow_null=True,
                  choices=[("A", "a"), ("B", "b")]).validate("") == None
    assert Choice(choices=[("A", "a"), ("B", "b")]).validate("C") == None
    assert Choice(choices=[("A", "a"), ("B", "b")]).validate("A") == 'A'
    assert Choice(choices=[("A", "a"), ("B", "b")]).validate("A") == 'A'



# Generated at 2022-06-12 15:48:20.463798
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.unions import Union
    assert (String(max_length=10) | String(min_length=3)) == Union([String(max_length=10),String(min_length=3)])



# Generated at 2022-06-12 15:48:25.514772
# Unit test for method validate of class String
def test_String_validate():
    string=String()
    assert (string.validate(value="test data") == "test data")
    assert (string.validate(value=' ') == None)
    assert (string.validate(value="") == None)
    assert (string.validate(value=None) == None)

# Generated at 2022-06-12 15:48:31.018743
# Unit test for method validate of class Object
def test_Object_validate():
    from bigchaindb.common.schema import validator
    test_schema = {
        'type': 'object',
        'properties': {
            'hello': {
                'type': 'string'
            }
        }
    }

    test_v = validator(test_schema)
    test_obj = {'hello': 'world'}

    try:
        test_v.validate(test_obj)
    except Invalid:
        pass
    
    test_inp = test_obj.copy()
    test_inp['hello'] = ''
    try:
        test_v.validate(test_inp)
    except Invalid:
        pass
    
    test_inp = test_obj.copy()
    test_inp['hello'] = 0

# Generated at 2022-06-12 15:48:39.278611
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String, Integer
    # Union Field __or__ Integer
    field = String() | Integer()
    assert isinstance(field, Union)
    assert isinstance(field.any_of[0], String)
    assert isinstance(field.any_of[1], Integer)
    # Union Field __or__ UnionField
    field2 = Integer() | String()
    field3 = field | field2
    assert isinstance(field3, Union)
    assert isinstance(field3.any_of[0], String)
    assert isinstance(field3.any_of[1], Integer)
    assert isinstance(field3.any_of[2], String)
    assert isinstance(field3.any_of[3], Integer)



# Generated at 2022-06-12 15:48:45.704637
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test for Choice.validate when value is None and allow_null is True
    field = Choice(allow_null=True, choices=[])
    assert field.validate(None) == None
    # test for Choice.validate when value is None, allow_null is False, and strict is False
    field1 = Choice(allow_null=False, choices=[])
    assert field1.validate(None) == None
    # test for Choice.validate when value is None, allow_null is False, and strict is True
    field2 = Choice(allow_null=False, choices=[])
    try:
        field2.validate(None, strict=True)
    except ValidationError:
        pass
    else:
        raise Exception
    # test for Choice.validate when value is not None, value is not in chosen choice

# Generated at 2022-06-12 15:48:58.832343
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True)==True
    assert Boolean().validate(False)==False
    assert Boolean().validate(0)==False
    assert Boolean().validate(1)==True
    assert Boolean().validate('True')==True
    assert Boolean().validate('False')==False
    assert Boolean().validate('')==False
    assert Boolean().validate(None) is None
    assert Boolean().validate(None, strict=True) == ValidationError(text='May not be null.', code='null')
    assert Boolean().validate('', strict=True) == ValidationError(text='Must be a boolean.', code='type')
    assert Boolean().validate('', strict=True) == ValidationError(text='Must be a boolean.', code='type')
    assert Boolean(allow_null=True).validate

# Generated at 2022-06-12 15:49:01.030357
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.base import Field
    
    a = Field()
    b = Field()
    c = Field()
    a | b | c
