

# Generated at 2022-06-24 10:38:35.631028
# Unit test for method validate of class String
def test_String_validate():
    a = String()
    assert a.validate("test") == "test"
    assert a.validate(None) == "test"

# Generated at 2022-06-24 10:38:37.787218
# Unit test for method validate of class String
def test_String_validate():
    string_object = String()
    assert string_object.validate("string") == "string"


# Generated at 2022-06-24 10:38:42.147461
# Unit test for constructor of class Const
def test_Const():
    const = Const (
        const = "Minh Quan",
        title = "Full name",
        description = "This is my full name"
    )

    print(const)



# Generated at 2022-06-24 10:38:51.641245
# Unit test for constructor of class Text
def test_Text():
    base = Field(name="base")
    base.name = "base"
    text1 = Field(format="text")
    text2 = Field(format="text")
    Text_test = Text()
    assert (Text_test.errors == text1.errors)
    assert (Text_test.name == base.name)
    assert (Text_test.allow_null == text2.allow_null)
    assert (Text_test.allow_empty == text2.allow_empty)
    assert (Text_test.name == text1.name)
    assert (Text_test.format == text2.format)



# Generated at 2022-06-24 10:38:52.302458
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime()


# Generated at 2022-06-24 10:38:54.550429
# Unit test for constructor of class Choice
def test_Choice():
    ch = Choice(choices=[('key1', 'value1'), ('key2', 'value2'), ('key3', 'value3')])
    assert ch.__dict__['choices'] == [('key1', 'value1'), ('key2', 'value2'), ('key3', 'value3')]


# Generated at 2022-06-24 10:39:00.544909
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field(title="titre_test")
    field2 = Field(title="titre_test")
    union = field1 | field2
# end unit test for method __or__ of class Field

    def __repr__(self):
        return "{}.{}".format(self.__class__.__name__, self.title or self.name)



# Generated at 2022-06-24 10:39:09.025053
# Unit test for constructor of class Decimal
def test_Decimal():
    d1 = Decimal(default=1.5, precision="0.001")
    assert d1.validate_or_error(1.5).value == 1.5
    assert d1.validate_or_error(1.501).value == 1.501
    assert d1.validate_or_error(1.501).error.code == "type"
    assert d1.validate_or_error(1.501).error.text == "Must be a number."
    assert d1.validate_or_error("1.501").value == 1.501
    assert d1.validate_or_error("1.501").error.code == "type"
    assert d1.validate_or_error("1.501").error.text == "Must be a number."


# Generated at 2022-06-24 10:39:10.984362
# Unit test for constructor of class Const
def test_Const():
    a = Const(1, description="")
    eq_(a.const, 1)
    eq_(a.description, "")

    b = Const(1, title="")
    eq_(b.const, 1)
    eq_(b.title, "")

# Unit tests for using Const

# Generated at 2022-06-24 10:39:19.826222
# Unit test for constructor of class String
def test_String():
    from typing import Any, Dict, Optional

    assert String.__init__.__annotations__ == {
        'self': Any,
        'allow_blank': bool,
        'trim_whitespace': bool,
        'max_length': Optional[int],
        'min_length': Optional[int],
        'pattern': Optional[typing.Union[str, typing.Pattern]],
        'format': Optional[str],
        'kwargs': Dict[str, Any],
    }
# End of unit test for constructor of class String


# Generated at 2022-06-24 10:39:26.677848
# Unit test for method validate of class Union
def test_Union_validate():
    import pytest
    from . import types

    field = Union(any_of=[types.String, types.Integer])
    with pytest.raises(ValidationError, match='Must be a string, integer or null.'):
        field.validate('string')
    with pytest.raises(ValidationError, match='Did not match any valid type.'):
        field.validate(1.0)
    with pytest.raises(ValidationError, match='May not be null.'):
        field.validate(None)

# Generated at 2022-06-24 10:39:31.699241
# Unit test for method validate of class Choice

# Generated at 2022-06-24 10:39:42.436773
# Unit test for constructor of class Union
def test_Union():
    from . import Int

    age = Int(min_value=1, max_value=120, allow_null=False)
    gpa = Int(min_value=0, max_value=100, allow_null=False)
    validator = Union([age, gpa])
    testage = age.validate(30)
    testgpa = gpa.validate(90)
    validator.validate(testage)
    validator.validate(testgpa)
    assert validator.validate(40) == 40
    assert validator.validate(20) == 20
    # Try to validate invalid input
    try:
        validator.validate(999)
    except ValidationError:
        pass
    # Try to validate null

# Generated at 2022-06-24 10:39:50.146970
# Unit test for constructor of class Number
def test_Number():
    Number.numeric_type = None
    a = Number(minimum = 1, maximum = 10, exclusive_minimum = 2, exclusive_maximum = 9, multiple_of = 2)
    assert a.minimum == 1
    assert a.maximum == 10
    assert a.exclusive_minimum == 2
    assert a.exclusive_maximum == 9
    assert a.multiple_of == 2

test_Number()



# Generated at 2022-06-24 10:39:54.180974
# Unit test for method validate of class String
def test_String_validate():
    string = String(title='title', description='description', allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern='.*', format='format')
    assert string.validate('value') == 'value'


# Generated at 2022-06-24 10:39:57.518467
# Unit test for constructor of class Time
def test_Time():
    """
    >>> t = Time()
    >>> t.serialize(datetime.now())
    '2020-05-16T19:05:34.587551'

    >>> t.deserialize('2020-05-16T19:05:34.587551')
    datetime.datetime(2020, 5, 16, 19, 5, 34, 587551)
    """



# Generated at 2022-06-24 10:40:02.628203
# Unit test for constructor of class Integer
def test_Integer():
    i = Integer(minimum=1, maximum=3)
    assert i.minimum == 1
    assert i.maximum == 3
    assert i.precision is None
    assert i.multiple_of is None
    assert i.exclusive_maximum is None
    assert i.exclusive_minimum is None



# Generated at 2022-06-24 10:40:03.872518
# Unit test for constructor of class Any
def test_Any():
    f = Any()
    assert f is not None, "Any() failed"


# Generated at 2022-06-24 10:40:06.421994
# Unit test for method validate of class Union
def test_Union_validate():
    import pytest
    has_errors = False
    with pytest.raises(ValidationError) as excinfo:
        Union(any_of=[Integer()]).validate(0.0)
    assert repr(excinfo.value) == "ValidationError(messages=[Message(text='Did not match any valid type.', code='union')])"
    return not has_errors
test_Union_validate()


# Generated at 2022-06-24 10:40:15.906836
# Unit test for method serialize of class String
def test_String_serialize():
    a = String()
    assert a.serialize(1) == 1
    assert a.serialize('') == ''
    a = String(format="date")
    assert a.serialize(datetime.date(2019, 9, 19)) == "2019-09-19"
    a = String(format="time")
    assert a.serialize(datetime.time(16, 30, 30)) == "16:30:30"
    a = String(format="datetime")
    assert a.serialize(datetime.datetime(2019, 9, 19, 16, 30, 30)) == "2019-09-19 16:30:30"
    a = String(format="uuid")

# Generated at 2022-06-24 10:40:18.848058
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    assert field.validate(123) == 123
    assert field.validate(123.45) == 123.45
    assert field.validate('abc') == 'abc'
    assert field.validate([]) == []
    assert field.validate({'a':1,'b':2}) == {'a':1,'b':2}
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None



# Generated at 2022-06-24 10:40:28.927095
# Unit test for constructor of class Boolean
def test_Boolean():
    # Testing function with default values
    test_bool = Boolean()
    assert test_bool.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert test_bool.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
    }
    assert test_bool.coerce_null_values == {"", "null", "none"}
    assert test_bool.allow_null == False
    assert test_bool.title == ""
    assert test_bool.description == ""
    assert test_bool.allow_blank == False
    assert test_bool.trim_whites

# Generated at 2022-06-24 10:40:32.929472
# Unit test for constructor of class String
def test_String():
    obj = String()
    assert issubclass(String, Field)
test_String()


# Generated at 2022-06-24 10:40:37.221175
# Unit test for constructor of class Time
def test_Time():
    schema = Time(format="date-time", allow_null=True, default="12:30:00")
    assert schema.deserialize(None) is None
    assert schema.serialize(datetime.datetime.now()) is not None



# Generated at 2022-06-24 10:40:38.267820
# Unit test for constructor of class Time
def test_Time():
    time = Time()



# Generated at 2022-06-24 10:40:45.948682
# Unit test for constructor of class Object
def test_Object():
    o_obj = Object(properties = {'a': object}, pattern_properties = None, additional_properties = True, property_names = None, min_properties = None, max_properties = None, required = None)
    assert type(o_obj) == Object
    assert o_obj.properties == {'a': object}
    assert o_obj.pattern_properties == {}
    assert o_obj.additional_properties == True
    assert o_obj.property_names == None
    assert o_obj.min_properties == None
    assert o_obj.max_properties == None
    assert o_obj.required == []


# Generated at 2022-06-24 10:40:58.035812
# Unit test for constructor of class Object
def test_Object():
    from pydantic.typing import DictStrAny
    error_msgs_type = {"type": "Must be an object."}
    error_msgs_null = {"null": "May not be null."}
    error_msgs_invalid_key = {"invalid_key": "All object keys must be strings."}
    error_msgs_required = {"required": "This field is required."}
    error_msgs_invalid_property = {"invalid_property": "Invalid property name."}
    error_msgs_empty = {"empty": "Must not be empty."}
    error_msgs_max_properties = {"max_properties": "Must have no more than {max_properties} properties."}
    error_msgs_min_properties = {"min_properties": "Must have at least {min_properties} properties."}

# Generated at 2022-06-24 10:41:00.692395
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    try:
        field.validate(3)
        assert False
    except NotImplementedError:
        pass
    return True


# Generated at 2022-06-24 10:41:10.024651
# Unit test for constructor of class DateTime
def test_DateTime():
    #Create DateTime object
    dt = DateTime()
    #test the constructor
    assert dt.allow_null == False
    assert dt.min_length == 1
    assert dt.max_length == 100
    assert dt.pattern == None
    assert dt.format == "datetime"
    assert dt.alphabet == characters.PRINTABLE
    assert dt.default_value == None
    assert dt.get_default_value() == ""
    assert dt.has_default() == False
    assert dt.enum == None
    assert dt.const_value == None

# Generated at 2022-06-24 10:41:19.688492
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a = Boolean()
    b = Boolean(allow_null=True)
    c = Boolean()

    assert a.validate(True) == True
    assert a.validate(False) == False
    assert a.validate(None) == None
    assert a.validate(0) == None
    assert a.validate(1) == None

    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate(0) == False
    assert b.validate(1) == True

    try:
        c.validate(None)
        assert False
    except ValidationError:
        assert True

    try:
        c.validate(0)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-24 10:41:27.683831
# Unit test for constructor of class Choice
def test_Choice():
    # Constructor without input
    c1 = Choice()
    assert c1.choices == []

    # Constructor with input as None
    c2 = Choice(choices=None)
    assert c2.choices == []

    # Constructor with input as a list of string

# Generated at 2022-06-24 10:41:37.459348
# Unit test for method validate of class Any
def test_Any_validate():
    from datetime import datetime
    from .errors import ValidationError
    from .fields import Any

    field = Any()
    assert field.validate('aaa') == 'aaa'
    assert field.validate(1) == 1
    assert field.validate([1,2]) == [1,2]
    assert field.validate({'a':'b'}) == {'a':'b'}
    assert field.validate(datetime.now()) == datetime.now()
    assert field.validate(field) == field
    assert field.validate(None) == None


# Generated at 2022-06-24 10:41:39.123331
# Unit test for constructor of class Time
def test_Time():
    field = Time()
    assert field.allow_null == False


# Generated at 2022-06-24 10:41:43.391312
# Unit test for constructor of class String
def test_String():
    def __init__(
        self,
        *,
        allow_blank: bool = False,
        trim_whitespace: bool = True,
        max_length: int = None,
        min_length: int = None,
        pattern: typing.Union[str, typing.Pattern] = None,
        format: str = None,
        **kwargs: typing.Any,
    ) -> None:
        super().__init__(**kwargs)

        assert max_length is None or isinstance(max_length, int)
        assert min_length is None or isinstance(min_length, int)
        assert pattern is None or isinstance(pattern, (str, typing.Pattern))
        assert format is None or isinstance(format, str)

        if allow_blank and not self.has_default():
            self.default = ""

# Generated at 2022-06-24 10:41:49.716907
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean(default = True, allow_null = True)
    print(b.validate(True))
    print(b.validate(False))
    print(b.validate(None))
    print(b.validate(0))
    print(b.validate(1))
    print(b.validate('0'))
    print(b.validate('on'))
    print(b.validate('off'))
    print(b.validate('abc'))
    print(b.validate(''))
    print(b.validate('null'))
    print(b.validate('none'))
    print(b.validate('yes'))
    try:
        b.validate('')
    except ValidationError as e:
        print(e)

test_Boolean

# Generated at 2022-06-24 10:41:51.031332
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj=None
    number = Decimal()
    assert number.serialize(obj) == None

# Generated at 2022-06-24 10:41:55.390714
# Unit test for constructor of class Choice
def test_Choice():
    choice_list = [(1, 'one'), (2, 'two')]
    test_class = Choice(choices=choice_list)
    assert test_class.choices == choice_list
    assert test_class.validate(None) == None
    assert test_class.validate(2) == 2
    assert test_class.validate("one") == "one"
    assert test_class.validate("", strict=True) == "one"


# Generated at 2022-06-24 10:41:58.756843
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(
        description="testing Choice class method validate",
        allow_null=True,
        choices=["test1", "test2"]
    )
    assert c.validate(value="test2") == "test2"
    try:
        c.validate(value="test3")
    except Exception as e:
        assert type(e) == ValidationError
    try:
        c.validate(value="")
    except Exception as e:
        assert type(e) == ValidationError

# Unit tests for method has_default of class Choice

# Generated at 2022-06-24 10:42:03.448688
# Unit test for constructor of class Number
def test_Number():
    foo = Number(minimum=0, maximum=10)
    assert foo._creation_counter == 0
    assert foo.allow_blank == False
    assert foo.allow_null == False
    assert foo.default == None
    assert foo.description == ""
    assert foo.title == ""
    assert foo.minimum == 0
    assert foo.maximum == 10
    assert foo.exclusive_minimum == None
    assert foo.exclusive_maximum == None
    assert foo.multiple_of == None
    assert foo.precision == None


# Generated at 2022-06-24 10:42:04.574477
# Unit test for constructor of class Array
def test_Array():
    assert Array(items=Integer()).items == Integer()
    assert Array(items=Integer(), unique_items=True).unique_items == True


# Generated at 2022-06-24 10:42:07.669137
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    d = 'This field is required.'
    f = Field(title='Name', description='The name of a person', errors={'required': d})
    assert f.get_error_text('required') == d



# Generated at 2022-06-24 10:42:12.698604
# Unit test for method validate of class Array
def test_Array_validate(): 
    items = {"a":String()}
    a = Array(items)
    assert str(a.validate(["a","b"])) == "['a', 'b']"
    #print(a.validate(["a","b"]))



# Generated at 2022-06-24 10:42:18.426010
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    """
        Unit test for method validate_or_error
    """
    class F(Field):
        errors = {
            "1": "a",
            "2": "b",
        }
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value == 1:
                return 2
            else:
                raise self.validation_error(code="1")
    
    if isinstance(F().validate_or_error(1), ValidationResult):
        print("ok")
    else:
        print("error")


# Generated at 2022-06-24 10:42:20.760870
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(default='kamlesh')
    assert f.get_default_value() == 'kamlesh'

# Generated at 2022-06-24 10:42:22.638407
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(1) == 1

# Generated at 2022-06-24 10:42:23.685354
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer.numeric_type == int


# Generated at 2022-06-24 10:42:25.604266
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("") == ""
    assert String().serialize("Hi") == "Hi"
    assert String().serialize(5) == 5


# Generated at 2022-06-24 10:42:27.536440
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field._creation_counter == 0
    assert field.__dict__['errors'] == {}



# Generated at 2022-06-24 10:42:28.629070
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime().format == "datetime"

# Generated at 2022-06-24 10:42:29.854568
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime(allow_null=True, default='2019-05-06')

# Generated at 2022-06-24 10:42:35.948229
# Unit test for method validate of class Object
def test_Object_validate():
    my_dict = {"a": 1}
    # test_object
    test_object = Object()
    assert test_object.validate(my_dict) == my_dict

    #test_required
    test_required_str = Object(required=['a', 'b'])
    assert test_required_str.validate(my_dict) == my_dict
    test_required_list = Object(required=('a', 'b'))
    assert test_required_list.validate(my_dict) == my_dict

    #test_additional_properties
    test_additional_properties_true = Object(additional_properties=True)
    assert test_additional_properties_true.validate(my_dict) == my_dict
    test_additional_properties_false = Object(additional_properties=False)



# Generated at 2022-06-24 10:42:47.997713
# Unit test for constructor of class String
def test_String():
    s = String()
    # check default value of class String
    assert s.has_default() == False
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.allow_null == False
    assert s.title == ""
    assert s.description == ""

# Generated at 2022-06-24 10:42:52.207656
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_one = Field()
    field_two = Field()

    assert type(field_one | field_two) == Union
    assert (field_one | field_two).any_of[0] == field_one
    assert (field_one | field_two).any_of[1] == field_two



# Generated at 2022-06-24 10:42:56.472293
# Unit test for method serialize of class String
def test_String_serialize():
    str_obj=String(a=1,b=2)
    assert str_obj.serialize(123)==123
    assert str_obj.serialize('123')=='123'



# Generated at 2022-06-24 10:42:58.107357
# Unit test for method validate of class Any
def test_Any_validate():
    fs = Any()
    assert fs.validate(1) == 1
    assert fs.validate(True) == True
    assert fs.validate([]) == []
    assert fs.validate('') == ''
    assert fs.validate({}) == {}


# Generated at 2022-06-24 10:42:59.991689
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field(title="Hello", description="World")
    assert field.serialize("Test") == "Test"



# Generated at 2022-06-24 10:43:00.962090
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal()



# Generated at 2022-06-24 10:43:12.538403
# Unit test for constructor of class Object
def test_Object():
    a = Object()
    assert a.properties is None
    assert a.pattern_properties is None
    assert a.additional_properties is None
    assert a.property_names is None
    assert a.min_properties is None
    assert a.max_properties is None
    assert a.required is None
    
    a = Object(properties={"a": 100})
    assert a.properties == {"a": 100}
    assert a.pattern_properties is None
    assert a.additional_properties is None
    assert a.property_names is None
    assert a.min_properties is None
    assert a.max_properties is None
    assert a.required is None

    a = Object(properties=100)
    assert a.properties is None
    assert a.pattern_properties is None
    assert a.additional_properties == 100
   

# Generated at 2022-06-24 10:43:14.265206
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field._creation_counter == 0


# Generated at 2022-06-24 10:43:17.402928
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(2)
    validated = const.validate(2)
    assert validated == 2
    try:
        const.validate(3, strict=True)
    except ValidationError as e:
        expected_error = [Message(text='Must be the value \'2\'.', code='const')]
        assert e.messages() == expected_error
    else:
        assert False, "Should raise an error!"



# Generated at 2022-06-24 10:43:24.182029
# Unit test for constructor of class Object
def test_Object():
    import uuid
    from .utils import describe_type

    @dataclass
    class Schema:
        id: UUID = Field(description="Unique ID.", required=True)
        name: str = Field(description="Name.", required=True)
        parent: typing.Optional[Schema] = Field(
            description="Parent object.", field_type=Object, allow_null=True
        )

    schema = Schema()
    assert schema.id.__class__ == UUID
    assert schema.id._description == "Unique ID."
    assert schema.id._required == True
    assert schema.name.__class__ == String
    assert schema.name.__class__ == String
    assert schema.name._description == "Name."
    assert schema.name._required == True
    assert schema.parent.__class__ == Object
    assert schema

# Generated at 2022-06-24 10:43:30.896520
# Unit test for constructor of class String
def test_String():
  print("test_String():")
  s = String(title='name', description='This is a String', allow_blank=False, trim_whitespace=True, max_length=10, min_length=2, pattern='^(Mr\.)?\s([a-z]\w*)$', format='date')
  s.validate('123')
  print(s.__dict__)



# Generated at 2022-06-24 10:43:36.729857
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    from decimal import Decimal
    from typesystem import types
    decimal_field = types.Decimal()
    decimal_value = Decimal('1.1')
    result = decimal_field.serialize(decimal_value)
    assert result == 1.1
    result = decimal_field.serialize(None)
    assert result is None
###########


# Generated at 2022-06-24 10:43:38.347841
# Unit test for method serialize of class String
def test_String_serialize():
    # type: () -> None
    assert String(format="date").serialize(date(2018, 1, 1)) == "2018-01-01"



# Generated at 2022-06-24 10:43:40.965916
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    format_string = 'This is a test'
    a = Field(errors = {'test': format_string})
    error_string = a.get_error_text('test')
    assert(format_string == error_string)


# Generated at 2022-06-24 10:43:44.083620
# Unit test for constructor of class Time
def test_Time():
    Time()


# Generated at 2022-06-24 10:43:46.310804
# Unit test for constructor of class Field
def test_Field():
    """
    Testing constructor of class Field
    """
    assert isinstance(Field(title="title", description="description"), Field)


# Generated at 2022-06-24 10:43:51.512073
# Unit test for constructor of class Number
def test_Number():
    field = Number(minimum=5, maximum=100, exclusive_minimum=6, exclusive_maximum=99)
    assert field.minimum == 5
    assert field.maximum == 100
    assert field.exclusive_minimum == 6
    assert field.exclusive_maximum == 99
    assert field.precision == None
    assert field.multiple_of == None
    assert field == Number(minimum=5, maximum=100, exclusive_minimum=6, exclusive_maximum=99)



# Generated at 2022-06-24 10:43:52.835417
# Unit test for constructor of class Const
def test_Const():
    f1 = Const(4)
    assert f1.const == 4
    assert f1.allow_null == False



# Generated at 2022-06-24 10:44:00.205989
# Unit test for method validate of class Choice
def test_Choice_validate():
    my_choice = Choice(name='my_choice', choices=[('1', 'One'), ('2', 'Two'), ('3', 'Three')], allow_null=True, default='3')
    my_choice.validate('2')
    try:
        my_choice.validate('4')
    except ValidationError as e:
        assert(e.code == 'choice')
        assert(e.text.startswith("Not a valid choice."))

    try:
        my_choice.validate('')
    except ValidationError as e:
        assert(e.code == 'required')
        assert(e.text.startswith("This field is required."))

    try:
        my_choice.validate(None)
    except ValidationError as e:
        assert(e.code == 'null')

# Generated at 2022-06-24 10:44:11.251358
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Add test values for global variable Field.errors
    Field.errors['invalid'] = 'Invalid data{"": "{}"}'
    Field.errors['empty'] = 'Empty value{"": "{}"}'

    class MyField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None:
                return value
            if not value:
                raise ValidationError("invalid")
            return value

    field = MyField()
    result = field.validate_or_error('')
    assert isinstance(result, ValidationResult)
    
    

# Generated at 2022-06-24 10:44:16.258659
# Unit test for constructor of class Field
def test_Field():
    field = Field(title = 'title_name', description = 'field_description', default = 0, allow_null = True)
    assert field.title == 'title_name'
    assert field.description == 'field_description'
    assert field.default == 0
    assert field.allow_null == True


# Generated at 2022-06-24 10:44:21.674978
# Unit test for method validate of class Number
def test_Number_validate():
    value = "a"
    try:
        assert Number.validate(None, value)
    except ValidationError as e:
        validate_result = e.text
    assert validate_result == "Must be a number."
    value = 1
    try:
        assert Number.validate(None, value)
    except ValidationError as e:
        validate_result = e.text
    assert validate_result == "Must be a number."



# Generated at 2022-06-24 10:44:25.526585
# Unit test for method validate of class String
def test_String_validate():
    '''This Unit test is designed to test the method validate of class String'''
    assert String().validate('Hello') == 'Hello'
    assert String().validate('') == ''
    assert String().validate(None) == None
    assert String().validate(0) != 'Hello'


# Generated at 2022-06-24 10:44:27.602970
# Unit test for constructor of class Text
def test_Text():
    assert Text().get_formats() == ["text"]



# Generated at 2022-06-24 10:44:30.159731
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field._creation_counter == 0
    assert field.errors == {}
    assert field.title == ""
    assert field.description == ""


# Generated at 2022-06-24 10:44:36.137572
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=NO_DEFAULT)
    assert field.get_default_value() == None


# Generated at 2022-06-24 10:44:44.765801
# Unit test for method validate of class Array
def test_Array_validate():
    # Create an Array
    array = Array()

    # Test for Exception "type" of class Array
    with pytest.raises(ValidationError):
        array.validate(1)

    # Test for Exception "type" of class Array
    with pytest.raises(ValidationError):
        array.validate('string')

    # Test for Exception "type" of class Array
    with pytest.raises(ValidationError):
        array.validate(True)

    # Test for Exception "null" of class Array
    with pytest.raises(ValidationError):
        array.validate(None)

    # Test for Exception "null" of class Array
    with pytest.raises(ValidationError):
        array = Array(allow_null=False)
        array.validate(None)

    # Test for Exception

# Generated at 2022-06-24 10:44:50.917093
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate("true") == True
    assert Boolean().validate("True") == True
    assert Boolean().validate("1") == True
    assert Boolean().validate("on") == True
    assert Boolean().validate("ON") == True
    assert Boolean().validate("") == False
    assert Boolean().validate("false") == False
    assert Boolean().validate("False") == False
    assert Boolean().validate("0") == False
    assert Boolean().validate("off") == False
    assert Boolean().validate("OFF") == False
    assert Boolean().validate(1) == True
    assert Boolean().validate(0) == False



# Generated at 2022-06-24 10:44:57.138686
# Unit test for method __or__ of class Field
def test_Field___or__():
    from io import StringIO
    from typesystem import String
    import sys
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    print(String("fname") | String("lname"))
    sys.stdout = sys.__stdout__
    out = capturedOutput.getvalue()
    assert out.strip() == "{Union(any_of=[<String fname>, <String lname>])}"


##
# String
##

# Generated at 2022-06-24 10:45:02.661467
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typing import Union, Callable
    from typesystem.base import Field

    Any = Union[int, str, bool]

    def assertUnionEqual(a, b):
        assert isinstance(a, Union)
        assert isinstance(b, Union)
        assert set(a.any_of) == set(b.any_of)

    assertUnionEqual(
        Field(title='First field') | Field(title='Second field'),
        Union(any_of=[Field(title='First field'), Field(title='Second field')])
    )
    assertUnionEqual(
        Field(title='First field') | Field(title='Second field') | Field(title='Third field'),
        Union(any_of=[Field(title='First field'), Field(title='Second field'), Field(title='Third field')])
    )

# Generated at 2022-06-24 10:45:04.369605
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert (Field() | Field())



# Generated at 2022-06-24 10:45:07.479869
# Unit test for constructor of class DateTime
def test_DateTime():
    class User(Schema):
        id = Field(type="integer")
        created = DateTime()

    user = User(id="1", created="2019-05-18 12:54:00")

    assert user.id == 1
    assert user.created == "2019-05-18 12:54:00"

    # For some reason, this test case fails
#    assert user.created == datetime(2019, 5, 18, 12, 54, 00)


# Generated at 2022-06-24 10:45:13.400698
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(format='datetime', allow_null=True)
    import datetime as dt
    date = '2019-09-27'
    date = dt.datetime.strptime(date,'%Y-%m-%d')
    assert string.serialize(obj=date) == date.isoformat()


# Generated at 2022-06-24 10:45:18.355780
# Unit test for constructor of class Any
def test_Any():
    any = Any();
    assert any.validate(1) == 1
    assert any.validate(None) == None
    assert any.validate('str') == 'str'
    assert any.validate(True) == True
    assert any.validate([1, 2, 'str', True]) == [1, 2, 'str', True]
    assert any.validate({'k': 'v'}) == {'k': 'v'}


# Generated at 2022-06-24 10:45:27.569333
# Unit test for method validate of class Number
def test_Number_validate():
  import decimal
  # Testing class Number
  test_Number = Number()
  # Testing method validate of class Number
  # Testing None
  # Testing function allow_null of class Number
  result1 = test_Number.allow_null
  assert result1 == False, "AssertionError: False != {0}".format(result1)
  test_Number = Number(allow_null = True)
  # Testing function allow_null of class Number
  result2 = test_Number.allow_null
  assert result2, "AssertionError: True != {0}".format(result2)
  # Testing function get_default of class Number
  result3 = test_Number.get_default()
  
  assert result3 == None, "AssertionError: None != {0}".format(result3)

# Generated at 2022-06-24 10:45:35.985799
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice().validate("America/Los_Angeles") == "America/Los_Angeles"
    assert Choice(choices=[("America/Los_Angeles", "Los_Angeles")]).validate("America/Los_Angeles") == "America/Los_Angeles"
    assert Choice().validate(None) is None
    assert Choice().validate("") == ""
    with pytest.raises(ValidationError):
        assert Choice(choices=[("America/Los_Angeles", "Los_Angeles")]).validate("America/New_York")



# Generated at 2022-06-24 10:45:39.665299
# Unit test for method validate of class Field
def test_Field_validate():
    test_obj = Field()
    test_obj.validate(12)


# Generated at 2022-06-24 10:45:43.416908
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            raise NotImplementedError()

    return ValidationResult(value=None, error=ValidationError(text='', code=''))



# Generated at 2022-06-24 10:45:46.379018
# Unit test for constructor of class Const
def test_Const():
    strict = False
    const = Const(const = 42)
    value = 42
    assert const.validate(value, strict) == value

test_Const()

# Generated at 2022-06-24 10:45:49.402926
# Unit test for method has_default of class Field
def test_Field_has_default():
    from typesystem import String

    field = String()
    assert field.has_default() is False
    field = String(default="")
    assert field.has_default() is True



# Generated at 2022-06-24 10:45:50.635456
# Unit test for constructor of class Text
def test_Text():
    t = Text()

    assert t.format == "text"


# Generated at 2022-06-24 10:45:51.805927
# Unit test for constructor of class DateTime
def test_DateTime():
    try:
        d = DateTime()
    except Exception as e:
        assert False



# Generated at 2022-06-24 10:45:59.655376
# Unit test for constructor of class String
def test_String():
    field = String()
    assert field.title == ""
    assert field.description == ""
    assert field.allow_blank == False
    assert field.has_default() == False
    assert field.trim_whitespace == True
    assert field.max_length == None
    assert field.min_length == None
    assert field.pattern == None
    assert field.format == None

    field = String(title = "My field", description = "This is my field", default = "", allow_blank = True, trim_whitespace = False, max_length = 10, min_length = 5, pattern = "\w+", format = "uuid")
    assert field.title == "My field"
    assert field.description == "This is my field"
    assert field.allow_blank == True
    assert field.has_default() == True


# Generated at 2022-06-24 10:46:01.086531
# Unit test for constructor of class Choice
def test_Choice():
    # type: (None) -> None
    ch = Choice(choices=[("a", "apple"), ("b", "bear"), ("c", "carrot")])
    print("Successfully passed test_Choice")



# Generated at 2022-06-24 10:46:07.251292
# Unit test for method validate of class Object
def test_Object_validate():
    print('----- start test_Object_validate() -----')
    # case 1
    input_dict = {
        'name': 'John',
        'age': 17
    }
    data_schema = {
        'type': 'object',
        'properties': {
            'name': {
                'type': 'string'
            },
            'age': {
                'type': 'integer'
            }
        },
        'required': [
            'name',
            'age'
        ]
    }
    data = Object(**data_schema)
    #data.validate(input_dict)
    print(data.validate(input_dict))
    # case 2
    input_dict = {
        'name': 'John',
        'age': 17,
        'height': 1.8
    }

# Generated at 2022-06-24 10:46:14.904202
# Unit test for constructor of class String
def test_String():
    st = String()
    assert st.allow_null == False
    assert st.allow_blank == False
    assert st.trim_whitespace == True
    assert st.max_length == None
    assert st.min_length == None
    assert st.pattern == None
    assert st.format == None
    assert st.pattern_regex == None
    assert st.title == ""
    assert st.description == ""


# Generated at 2022-06-24 10:46:24.985578
# Unit test for constructor of class Object
def test_Object():
    def test(name, val, exp):
        try:
            _ = Object(**val)
            assert False, "{} failed".format(name)
        except AssertionError as e:
            assert str(e) == exp, "{} failed".format(name)

    test(
        "property_names",
        {"property_names": "notfield"},
        "assert all(isinstance(k, str) for k in properties.keys()): ",
    )
    test(
        "min_properties",
        {"min_properties": "notint"},
        "assert min_properties is None or isinstance(min_properties, int): ",
    )

# Generated at 2022-06-24 10:46:35.208024
# Unit test for constructor of class Object
def test_Object():
    # Test 1: Create object with no parameter
    obj = Object()

    # Test 2: Create object with all parameters
    obj = Object(
        description="Test",
        allow_null=True,
        name='test',
        title='test',
        default=datetime.datetime.now(),
        properties={},
        pattern_properties={},
        additional_properties=True,
        property_names={},
        min_properties=1,
        max_properties=None,
        required=["test"]
    )

    # Test: Create object with some parameters
    obj = Object(
        allow_null=True,
        properties={},
        pattern_properties={},
        additional_properties=True,
        min_properties=1,
        max_properties=None,
        required=["test"]
    )


# Unit test

# Generated at 2022-06-24 10:46:38.685886
# Unit test for method serialize of class Field
def test_Field_serialize():
    """Unit test for method serialize of class Field"""
    expected = 1
    input = 1
    assert Field().serialize(input) == expected

# Generated at 2022-06-24 10:46:42.452581
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    res = f.get_default_value()
    assert res is None
    
    f.default = "this is a default"
    res = f.get_default_value()
    assert res == "this is a default"

# Generated at 2022-06-24 10:46:47.706637
# Unit test for constructor of class Time
def test_Time():
    time = Time(allow_null=True,default='09:05:00')
    x = time.get_default_value()
    assert x == '09:05:00'


# Generated at 2022-06-24 10:46:54.428469
# Unit test for constructor of class Const
def test_Const():
    #This_Const = Const(0)
    assert Const(0)
    assert Const(1)
    assert Const(2)
    assert Const(3)
    assert Const(4)
    assert Const(5)
    assert Const(6)
    assert Const(7)
    assert Const(8)
    assert Const(9)
    assert Const(10)
    assert Const(11)
    assert Const(12)


# Generated at 2022-06-24 10:47:02.644993
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(description = "This is a field", allow_null = False)
    assert field.has_default() == False
    field1 = Field(description = "This is a field", allow_null = False, default = 5)
    assert field1.has_default() == True
    field2 = Field(description = "This is a field", allow_null = True, default = 5)
    assert field2.has_default() == False
    field3 = Field(description = "This is a field", allow_null = True)
    assert field3.has_default() == False

# Generated at 2022-06-24 10:47:12.476863
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import typesystem
    from typesystem.error_messages import ErrorMessage
    from typesystem.fields import String, Integer

    class CustomField(String):
        errors = {"INVALID": ErrorMessage("Custom Error Message")}

        def validate(self, value, **kwargs):
            if "foo" in value:
                raise ValidationError("INVALID")
            return super().validate(value, **kwargs)

    str_field = String(min_length=1, max_length=3)
    int_field = Integer(min_value=1, max_value=3)
    custom_field = CustomField(pattern=r"^[a-zA-Z0-9]*$")

# Generated at 2022-06-24 10:47:14.544509
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any.validate(8.92) == 8.92


# Generated at 2022-06-24 10:47:15.241804
# Unit test for constructor of class Date
def test_Date():
    Date()



# Generated at 2022-06-24 10:47:18.232737
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(const="const")
    assert const.validate(value="const") == "const"
    with pytest.raises(ValidationError):
        const.validate(value="wrong_value")
    

# Generated at 2022-06-24 10:47:22.405344
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(1)
    assert const.validate(1) == 1
    with pytest.raises(ValidationError) as err:
        const.validate(2)
    assert err.match("")



# Generated at 2022-06-24 10:47:23.153011
# Unit test for constructor of class Date
def test_Date():
    assert isinstance(Date(), String)
    assert Date().format == 'date'

# Generated at 2022-06-24 10:47:25.881976
# Unit test for constructor of class Field
def test_Field():
    x=Field()
    assert x.title ==""
    assert x.description==""
    assert x.allow_null==False
    assert x.has_default() == False


# Generated at 2022-06-24 10:47:26.536806
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
  pass

# Generated at 2022-06-24 10:47:31.639222
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f=Field()
    f._creation_counter=Field._creation_counter
    assert f._creation_counter==0
    f._creation_counter+=1
    assert f._creation_counter==1
    assert f.has_default()==False
    f.default="hello"
    assert f.has_default()==True
    assert f.get_default_value()=="hello"
    assert f.get_error_text("123")=="error 123"



# Generated at 2022-06-24 10:47:42.410457
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean(title = "My Boolean")
    assert Boolean(title = "Your Boolean", description = "This is your Boolean")
    assert Boolean(title = "Our Boolean", description = "This is our Boolean", allow_null = True)
    assert Boolean(title = "His Boolean", description = "This is his Boolean", default = True)
    assert Boolean(title = "str Boolean", description = "This is a string", default = "This is a string")
    assert Boolean(title = "str Boolean 2", description = "This is a string", default = "")
    assert Boolean(title = "str Boolean 3", description = "This is a string", default = None)
    assert Boolean(title = "str Boolean 4", description = "This is a string", default = "null")

# Generated at 2022-06-24 10:47:48.976736
# Unit test for method validate of class Const
def test_Const_validate():
    # Test Const.validate for a non-null value
    field = Const(const=5)
    assert field.validate(5) == 5
    try:
        field.validate(6)
        assert False
    except ValidationError as e:
        assert str(e) == "Must be the value '5'."
    
    # Test Const.validate for a null value
    field = Const(const=None)
    assert field.validate(None) == None
    try:
        field.validate(5)
        assert False
    except ValidationError as e:
        assert str(e) == "Must be null."
    
    
# Running unit tests
test_Const_validate()



# Generated at 2022-06-24 10:47:50.761628
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    field.name = "my_name"
    assert field.validation_error("my_code")


# Generated at 2022-06-24 10:47:59.109156
# Unit test for method validate of class Number
def test_Number_validate():
    field1 = String(allow_null=True)
    field2 = String()
    field3 = Number()
    field4 = Number(allow_null=True)
    field5 = Number(minimum=2)

    field1.validate("value1")
    field1.validate("")
    field1.validate(None)

    field2.validate("value2")
    field2.validate("")

    field3.validate("value3")

    field4.validate("value4")
    field4.validate(None)

    field5.validate("value5")
    field5.validate("1")



# Generated at 2022-06-24 10:48:01.820804
# Unit test for constructor of class Const
def test_Const():
    assert Const(None).const == None
    assert Const(None, title="None").const == None
    assert Const(None, description="a null value").const == None


# Generated at 2022-06-24 10:48:09.841245
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typeguard.type_checking_only import make_type_checker

    # class Field(...) -> ValidationResult
    def validate_or_error(
        self, value: typing.Any, *, strict: bool = False
    ) -> ValidationResult:
        try:
            value = self.validate(value, strict=strict)
        except ValidationError as error:
            return ValidationResult(value=None, error=error)
        return ValidationResult(value=value, error=None)

    # validate_or_error = make_type_checker(validate_or_error)

    def test_1():
        self = Field(
            title="", description="", default=NO_DEFAULT, allow_null=False
        )
        value = None
        strict = False
        # self.validate = validate

# Generated at 2022-06-24 10:48:11.481135
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code="code"
    assert isinstance(field.validation_error(code), ValidationError)


# Generated at 2022-06-24 10:48:15.711562
# Unit test for method serialize of class String
def test_String_serialize():
    data = "2019-10-01"
    text = String(title="Date", format="date")
    assert text.serialize(data) == data


# Generated at 2022-06-24 10:48:24.396363
# Unit test for method validate of class Union
def test_Union_validate():
    """
    Unit test for method validate of class Union
    """
    from jsonschema import validate
    from jsonschema import ValidationError


# Generated at 2022-06-24 10:48:31.897788
# Unit test for constructor of class Array
def test_Array():
    items = String(max_length=10)
    testArr = Array(items=items)
    assert testArr
    assert testArr.items == items

    assert testArr.validate(["hello", "world"])


# Generated at 2022-06-24 10:48:41.133824
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array(
        id="array",
        title="Array Test",
        description="Test Array Class",
        nullable=True
    )
    assert obj.validate(None) == None
    assert obj.validate([]) == []
    assert obj.validate([1, 2, 3]) == [1, 2, 3]
    assert obj.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    obj.min_items = 3
    obj.max_items = 4
    assert obj.validate([1, 2, 3]) == [1, 2, 3]
    assert obj.validate([1, 2, 3, 4]) == [1, 2, 3, 4]