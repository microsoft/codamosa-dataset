

# Generated at 2022-06-24 10:38:33.768416
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    aDecimal = Decimal()
    assert aDecimal.serialize(None) == None
    assert aDecimal.serialize(10) == 10
    assert aDecimal.serialize(10.12) == 10.12



# Generated at 2022-06-24 10:38:46.129041
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={"name": String(max_length=10)})
    # Case 1: value is a dictionary
    test_data1 = {"name": "dhtuan"}
    assert schema.validate(test_data1) == test_data1
    test_data2 = {1: "dhtuan"}
    try:
        schema.validate(test_data2)
    except ValidationError:
        pass
    # Case 2: value is a string
    test_data3 = "dhtuan"
    try:
        schema.validate(test_data3)
    except ValidationError:
        pass
    # Case 3: value is a list
    test_data4 = ["dhtuan"]
    try:
        schema.validate(test_data4)
    except ValidationError:
        pass

# Generated at 2022-06-24 10:38:49.659037
# Unit test for constructor of class Text
def test_Text():
    try:
        Text()
    except Exception as e:
        print("Error in constructor of class Text:", e)
    
    try:
        Text(format="text", default="hello world")
    except Exception as e:
        print("Error in constructor of class Text:", e)


# Generated at 2022-06-24 10:38:51.478067
# Unit test for method has_default of class Field
def test_Field_has_default():
    # Arrange
    field = Field()
    # Act
    result = field.has_default()
    # Assert
    assert result == False

# Generated at 2022-06-24 10:38:54.747316
# Unit test for constructor of class Boolean
def test_Boolean():
    b1 = Boolean()
    assert b1.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert b1.coerce_values == {"true": True, "false": False, "on": True, "off": False, "1": True, "0": False, "": False, 1: True, 0: False}
    assert b1.coerce_null_values == {"", "null", "none"}


# Generated at 2022-06-24 10:38:56.943188
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(None) == None



# Generated at 2022-06-24 10:38:58.717145
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.validate("2019-01-31") == "2019-01-31"


# Generated at 2022-06-24 10:39:02.613848
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert list(Field.validate_or_error.__code__.co_varnames) == ['self', 'value', 'strict']
    assert Field.validate_or_error.__defaults__ == (False,)
test_Field_validate_or_error()

# Generated at 2022-06-24 10:39:06.591300
# Unit test for constructor of class DateTime
def test_DateTime():
    input = '{"type": "string", "format": "datetime"}'
    expected = DateTime.from_json(input)
    assert isinstance(expected, DateTime)



# Generated at 2022-06-24 10:39:09.593175
# Unit test for method validate of class Number
def test_Number_validate():
    val = Number(minimum = 1, maximum = 3, exclusive_minimum = False, exclusive_maximum = True, multiple_of = 2)
    assert val.validate(2) == 2
    #return val
test_Number_validate()


# Generated at 2022-06-24 10:39:10.436776
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(0) == 0



# Generated at 2022-06-24 10:39:11.603831
# Unit test for constructor of class DateTime
def test_DateTime():
    datetime = DateTime()
    assert datetime.format == "datetime"

# Generated at 2022-06-24 10:39:15.513380
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=5)
    with pytest.raises(ValidationError):
        const.validate(6)


# Generated at 2022-06-24 10:39:16.776392
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field.validate_or_error("test")


# Generated at 2022-06-24 10:39:19.344562
# Unit test for method validate of class Field
def test_Field_validate():
    x = Field()
    assert x.validate(1) == 1
    assert x.validate("1") == "1"
    assert x.validate(True) == True

# Generated at 2022-06-24 10:39:23.998507
# Unit test for constructor of class Array
def test_Array():
    items = Array(additional_items = True, min_items = None, max_items = None, unique_items = False)
    assert items.additional_items == True
    assert items.unique_items == False
    assert items.max_items == None
    assert items.min_items == None


# Generated at 2022-06-24 10:39:30.818236
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate("not a list") == ['not a list']
    assert field.validate(1) == [1]
    
    field = Array(items=Integer(), allow_null=True)
    assert field.validate(None) is None

    field = Array(items=[String(pattern="^[a-z]+$"), Integer()])
    assert field.validate(["abc", 1]) == ["abc", 1]

    field = Array(items=String(pattern="^[a-z]+$"), additional_items=Integer())
    assert field.validate(["abc", 1]) == ["abc", 1]


# Generated at 2022-06-24 10:39:37.821239
# Unit test for method validate of class String
def test_String_validate():
    assert String(default="0", format="uuid").validate(None) == "0"
    assert String(default="2", format="uuid").validate(None) == "2"
    assert String(allow_blank=True, default="0", format="uuid").validate(None) == "0"
    assert String(allow_blank=True, default="2", format="uuid").validate(None) == "2"

# Generated at 2022-06-24 10:39:42.126170
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array([String(), Integer()], min_items=1, max_items=3)
    aa = a.validate(["abc", 1, "abcd", "abcde"])
    print (aa)
    assert aa == ["abc", 1, "abcd"]

# Generated at 2022-06-24 10:39:48.884309
# Unit test for method validate of class String
def test_String_validate():
    st = String(allow_blank=False, title="", description="", allow_null=False)
    assert st.validate("abc") == "abc"
    assert st.validate("") == ""
    try:
        st.validate("")
    except ValidationError as e:
        assert str(e) == "Must not be blank."
        assert e.code == "blank"
    try:
        st.validate(None)
    except ValidationError as e:
        assert str(e) == "Must be a string."
        assert e.code == "type"

    st = String(allow_blank=True, title="", description="", allow_null=False)
    assert st.validate("") == ""

# Generated at 2022-06-24 10:39:51.140367
# Unit test for constructor of class Time
def test_Time():
    try:
        _ = Time()
    except TypeError:
        raise AssertionError("Time should not expect extra parameters")
    except Exception as e:
        raise e


# Generated at 2022-06-24 10:39:57.594141
# Unit test for constructor of class Any
def test_Any():
    a1 = Any()
    assert a1.name is None
    assert a1.description is None
    assert a1.default_value is None
    assert a1.allow_null is False
    assert a1.allow_blank is False

    a2 = Any(
        name="The example Any field",
        description="I am a description.",
        default_value="No value given.",
        allow_null=True,
        allow_blank=True,
    )

    assert a2.name == "The example Any field"
    assert a2.description == "I am a description."
    assert a2.default_value == "No value given."
    assert a2.allow_null == True
    assert a2.allow_blank == True

test_Any()

# Generated at 2022-06-24 10:39:59.194780
# Unit test for constructor of class Time
def test_Time():
    assert Time


# Generated at 2022-06-24 10:40:00.212154
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.format == "text"
    assert text.allow_null == False



# Generated at 2022-06-24 10:40:01.117112
# Unit test for constructor of class Time
def test_Time():
    time=Time()
    assert time!=None


# Generated at 2022-06-24 10:40:04.533545
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(5) == 5



# Generated at 2022-06-24 10:40:14.381558
# Unit test for method validate of class String
def test_String_validate():
    strField = String()
    assert strField.validate("123456") == "123456"
    assert strField.validate("123456", strict=False) == "123456"

    # test for null
    try:
        strField.validate(None)
    except ValidationError:
        pass
    except Exception:
        assert False
    else:
        assert strField.validate(None) is None

    try:
        strField.validate(None, strict=True)
    except ValidationError:
        pass
    except Exception:
        assert False
    else:
        assert strField.validate(None, strict=True) is None

    # string.strip()
    assert strField.validate("  123456") == "123456"

# Generated at 2022-06-24 10:40:16.637149
# Unit test for constructor of class Field
def test_Field():
    field = Field(title='title', description='description', default=None, allow_null=False)
    assert field.title == "title"
    assert field.description == "description"
    assert field.default == None
    assert field.allow_null == False


# Generated at 2022-06-24 10:40:24.730191
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal(title="Decimal").serialize(decimal.Decimal('100.00')) == float('100.0')
    assert Decimal(title="Decimal").serialize(decimal.Decimal('100.00') == None)
    assert Decimal(title="Decimal").serialize(decimal.Decimal('100.00') != None)
    assert Decimal(title="Decimal").serialize(decimal.Decimal('100.00') == 100.00)



# Generated at 2022-06-24 10:40:25.484133
# Unit test for constructor of class DateTime
def test_DateTime():
    schema = DateTime()
    assert schema.format == "datetime"



# Generated at 2022-06-24 10:40:28.321752
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title= "title test", description="description test", default={"default":"test"}, allow_null=False)
    assert field.get_default_value() == {"default":"test"}


# Generated at 2022-06-24 10:40:30.864316
# Unit test for constructor of class Const
def test_Const():
    field1 = Const(2)
    field2 = Const(2, allow_null=True)
    field3 = Const(const=5)
    try:
        field4 = Const(const=5, allow_null=True)
    except TypeError as e:
        print(e)
    else:
        raise AssertionError("TypeError not raised")


# Generated at 2022-06-24 10:40:42.370661
# Unit test for method validate of class Object
def test_Object_validate():
    # Creating an object field
    obj_field = Object()
    # Testing that it raises an error if argument is not an object
    with pytest.raises(ValidationError):
        obj_field.validate("this is not an object")
    # Testing that it raises an error if argument is an integer
    with pytest.raises(ValidationError):
        obj_field.validate(1)
    # Testing that it raises an error if argument is a boolean
    with pytest.raises(ValidationError):
        obj_field.validate(True)
    # Testing that it raises an error if argument is a list
    with pytest.raises(ValidationError):
        obj_field.validate([1, 2, 3, 4])
    # Testing that it raises an error if argument is a dictionary but has a key that is not a

# Generated at 2022-06-24 10:40:45.789684
# Unit test for method serialize of class String
def test_String_serialize():
    field = String(format='datetime')
    assert field.serialize(obj=datetime.datetime(2017, 2, 25, 2, 45, 19, 276504)) == '2017-02-25T02:45:19.276504'



# Generated at 2022-06-24 10:40:48.200232
# Unit test for constructor of class DateTime
def test_DateTime():
    datetime = DateTime()

    assert datetime.format == "datetime"
    assert datetime.valid_formats == ["datetime"]
    assert datetime.allow_null == False
    assert datetime.get_default_value() == None
    assert datetime.required == True



# Generated at 2022-06-24 10:40:58.223745
# Unit test for constructor of class Number
def test_Number():
    #    allow_null: bool = False,
    #    minimum: typing.Union[int, float, decimal.Decimal] = None,
    #    maximum: typing.Union[int, float, decimal.Decimal] = None,
    #    exclusive_minimum: typing.Union[int, float, decimal.Decimal] = None,
    #    exclusive_maximum: typing.Union[int, float, decimal.Decimal] = None,
    #    multiple_of: typing.Union[int, float, decimal.Decimal] = None,
    #    precision: str = None,
    #    **kwargs: typing.Any,
    # pass

    number = Number()
    number = Number(allow_null=True)
    number = Number(minimum=3)
    number = Number(maximum=3)

# Generated at 2022-06-24 10:41:06.026572
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()

    print(number.validate(1))
    assert number.validate(1) == 1
    assert number.validate(True) == 1
    assert number.validate(False) == 0
    assert number.validate('1') == 1

    print(number.validate(1.5))
    assert number.validate(1.5) == 1.5
    assert number.validate('1.5') == 1.5

    print(number.validate(None))
    assert number.validate(None) == None


test_Number_validate()    



# Generated at 2022-06-24 10:41:07.584832
# Unit test for constructor of class Integer
def test_Integer():
    field = Integer()
    assert field is not None



# Generated at 2022-06-24 10:41:10.101056
# Unit test for constructor of class Time
def test_Time():
    field = Time()
    assert field.format == "time"

# Generated at 2022-06-24 10:41:13.771369
# Unit test for method validate of class Any
def test_Any_validate():
    x = Any()
    assert x.validate(1) == 1
    assert x.validate(None) is None
    assert x.validate(True) is True
    assert x.validate(3.1415) == 3.1415
    assert x.validate("hello") == "hello"
    assert x.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-24 10:41:21.362793
# Unit test for constructor of class Number
def test_Number():
    num = Number()
    num.allow_null=True
    assert(num.validate(None,True)==None)
    assert(num.validate(None,False)==None)
    assert(num.validate(0,False)==0)
    assert(num.validate(1,False)==1)
    assert(num.validate(3.3,False)==3.3)
    assert(num.validate("3.3",False)==3.3)
    assert(num.validate(False,False)==None)
    num.allow_null=False
    assert(num.validate(0,False)==0)
    num = Number()
    num.allow_null=True
    num.minimum=10

# Generated at 2022-06-24 10:41:30.436071
# Unit test for method validate of class Object
def test_Object_validate():

	class TestObjectSchema(Schema):
	    int_property = fields.Integer(description="int_property of an object")

	class TestSchema(Schema):
		test_field = fields.Object(properties={
			"test_property": fields.Integer(description="test_property of an object")
		}, additional_properties=TestObjectSchema)
		required_field = fields.String(required=True)

	schema = TestSchema()
	data = {
	    "test_field": {
	        "test_property": 0,
	        "test_field": {
	            "int_property": "test"
	        }
	    },
	    "required_field": "test"
	}
	data, errors = schema.load(data)

# Generated at 2022-06-24 10:41:32.199151
# Unit test for constructor of class Date
def test_Date():
    d = Date()
    assert d.format == "date"


# Generated at 2022-06-24 10:41:35.285281
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = String()
    field2 = String()
    assert field1 | field2.update(title="test") == Union([field1, field2])


# Generated at 2022-06-24 10:41:40.258924
# Unit test for constructor of class Const
def test_Const():
#     # Check for exceptions when const is None
#     with pytest.raises(TypeError) as excinfo:
#         Const()
#     assert "__init__() missing 1 required positional argument: 'const'" in str(excinfo.value)
#     # Check for exceptions when const is not a valid type
#     with pytest.raises(TypeError) as excinfo:
#         Const(const= {})
#     assert "const must be a dict" in str(excinfo.value)
    assert Const(const=None).const == None
    # Check for exceptions when const is not a valid type
    with pytest.raises(TypeError) as excinfo:
        Const(const= {})
    assert "const must be a dict" in str(excinfo.value)
#     # Check for exceptions when const is not a valid type


# Generated at 2022-06-24 10:41:47.294991
# Unit test for method __or__ of class Field
def test_Field___or__():
	# create two Field objects
	field_1 = Field(title = 'title 1', description = 'description 1', default = NO_DEFAULT, allow_null = False)
	field_2 = Field(title = 'title 2', description = 'description 2', default = NO_DEFAULT, allow_null = True)
	
	# create a list of Field objects
	any_of = [field_1, field_2]
	
	# create a Union object
	union = Union(any_of = any_of)
	
	# create a new Union object
	new_union = field_1 | field_2
	
	assert union == new_union


# Generated at 2022-06-24 10:41:55.742584
# Unit test for constructor of class Const
def test_Const():
    try:
        schema = Const(None)
    except AssertionError:
        assert True
    else:
        assert False # Should not reach here

    schema = Const(const=None)
    assert schema.const == None
    assert not schema.allow_null
    
    schema = Const(const=None, allow_null=True)
    assert schema.const == None
    assert schema.allow_null


# Generated at 2022-06-24 10:41:56.729169
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(5,2)==7


# Generated at 2022-06-24 10:41:59.433976
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(1) == 1


# Generated at 2022-06-24 10:42:00.760997
# Unit test for constructor of class Float
def test_Float():
    assert isinstance(Float(1, 2, 3), Float)



# Generated at 2022-06-24 10:42:01.496685
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert a.format == 'text'


# Generated at 2022-06-24 10:42:03.482307
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate("a.com") == "a.com"
    with pytest.raises(ValidationError):
        assert Any(allow_null=False).validate(None) == None

# Generated at 2022-06-24 10:42:05.466684
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a = Decimal()
    assert a.serialize(1) == 1
    assert a.serialize(None) is None


# Generated at 2022-06-24 10:42:07.060969
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice()
    assert field.validate('13', strict = True) == '13'
    assert field.validate(13, strict = True) == 13
    assert field.validate('test', strict = True) == 'test'


# Generated at 2022-06-24 10:42:10.121663
# Unit test for constructor of class Float
def test_Float():
    assert Float(minimum = 0, maximum = 100, precision = "0.1")


# Generated at 2022-06-24 10:42:14.942877
# Unit test for constructor of class Time
def test_Time():
    time = Time(strict=False, required=False, allow_null=True)
    assert time.allow_null == True
    assert time.required == False
    assert time.strict == False
    assert time.allow_empty == None
    assert time.trim == None
    assert time.min_length == None
    assert time.max_length == None
    assert time.min_length == None
    assert time.max_length == None


# Generated at 2022-06-24 10:42:17.725493
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # type: () -> None
    class MyField(Field):
        def __init__(self, default="foo"):
            self.default = default
            super(MyField, self).__init__()
    assert MyField().get_default_value() == "foo"



# Generated at 2022-06-24 10:42:19.720956
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(1)
    assert const.validate(1) == 1
    try:
        const.validate(2)
    except ValidationError as e:
        pass
    else:
        assert False


# Generated at 2022-06-24 10:42:25.142790
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestField(Field):
        def __init__(self):
            super().__init__()
            self.default = 5
    field = TestField()
    assert field.get_default_value() == 5, 'Default value: 5'
    field.default = 6
    assert field.get_default_value() == 6, 'Default value: 6'


# Generated at 2022-06-24 10:42:27.337880
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    error = field.validation_error(code = '1')
    assert isinstance(error, ValidationError)
    assert error.text == "This field is required"
    assert error.code == '1'


# Generated at 2022-06-24 10:42:34.554066
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("", strict=False) == None
    assert Choice(allow_null=False).validate("", strict=False) == "choice"
    assert Choice(allow_null=True).validate("", strict=False) == None
    assert Choice(choices=[("a", "a")]).validate("") == "choice"
    assert Choice(choices=[("a", "a")]).validate("a") == "a"
    assert Choice(choices=[("a", "a")]).validate("b") == "choice"
    assert Choice(choices=[("a", "a")]).validate("A") == "choice"
    assert Choice(choices=[("a", "a")]).validate("A", strict=False) == "choice"

# Generated at 2022-06-24 10:42:44.110834
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_choice = Choice(
        choices=[("1", "1"), ("2", "2"), ("", "null")]
    )
    assert test_choice.validate("1") == "1"
    assert test_choice.validate("2") == "2"
    assert test_choice.validate("") is None
    assert test_choice.validate(None) is None
    assert test_choice.allow_null == True

    try:
        test_choice.validate("10")
        assert False
    except ValidationError as e:
        assert e.code == "choice"



# Generated at 2022-06-24 10:42:46.212986
# Unit test for constructor of class Field
def test_Field():
    assert Field.__init__
    field = Field()
    assert field is not None


# Generated at 2022-06-24 10:42:50.516145
# Unit test for method validate of class Array
def test_Array_validate():
    val = [1, 2, 3] # array

    items = Number(validator = "Number") # object
    arr = Array(items = items,validator = "Array")
    assert arr.validate(val) == [1, 2, 3]


# Generated at 2022-06-24 10:43:02.465689
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    t = Decimal()
    assert t.serialize(None) == None
    assert t.serialize(decimal.Decimal(1)) == 1.0
    assert t.serialize(-1) == -1.0
    assert t.serialize(1) == 1.0
    assert t.serialize(1.0) == 1.0
    assert t.serialize(1.1) == 1.1
    assert t.serialize(0) == 0.0
    assert t.serialize(0.0) == 0.0
    assert t.serialize(0.1) == 0.1
    assert t.serialize(.1) == 0.1
    assert t.serialize('1') == 1.0
    assert t.serialize('1.0') == 1.0

# Generated at 2022-06-24 10:43:06.211733
# Unit test for constructor of class String
def test_String():
    assert isinstance(String(max_length = 10), String)
    assert not isinstance(String(max_length = 0.5), String)


# Generated at 2022-06-24 10:43:13.812574
# Unit test for constructor of class Integer
def test_Integer():
    integer = Integer(title="a", description="b", default=1, maximum=10, allow_null=False)
    assert isinstance(integer, Integer) == True
    assert integer.title == "a"
    assert integer.description == "b"
    assert integer.default == 1
    assert integer.maximum == 10
    assert integer.allow_null == False
    assert integer.validate(5) == 5
    assert integer.validate(5, strict=True) == 5
    assert integer.validate_or_error(5) == ValidationResult(value=5, error=None)


# Generated at 2022-06-24 10:43:20.749266
# Unit test for constructor of class String
def test_String():
    # Should create a new instance of class String without error
    test_string = String()
    assert test_string is not None
    # Should create a new instance of class String without error
    test_string_with_param = String(max_length=10)
    assert test_string_with_param is not None
    # Should throw error if the parameter max_length is not integer
    try:
        String(max_length="10")
    except AssertionError as e:
        return 'Pass'
    return 'Fail'


# Generated at 2022-06-24 10:43:26.613824
# Unit test for constructor of class Array
def test_Array():
    f = Array(
        min_items=0,
        max_items=3,
        items=String(max_length=10),
    )
    f.validate(['a', 'b', 'c'])
    f.validate([])
    try:
        f.validate(['a' * 11])
    except ValidationError as e:
        assert e.messages()[0].text == 'Must have no more than 10 characters.'
    try:
        f.validate([['a']])
    except ValidationError as e:
        assert e.messages()[0].text == 'Must be a string.'
    try:
        f.validate([1, 2, 3])
    except ValidationError as e:
        assert e.messages()[0].text == 'Must be a string.'


# Generated at 2022-06-24 10:43:30.345925
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field(title='title', description='description')
    field.errors['required'] = "This is required"
    assert field.validation_error('required') == ValidationError(code='required', text="This is required")

# Generated at 2022-06-24 10:43:40.957375
# Unit test for constructor of class Time
def test_Time():
    field = Time()
    assert field.format == "time"
    assert field.messages is None
    assert field.allow_null is False
    assert field.has_default() is False
    assert field.default_value is None
    assert field.get_default_value() is None 
    assert field.serialize(None) is None
    assert field.validate("h:m:s") == "h:m:s"

# Generated at 2022-06-24 10:43:51.843533
# Unit test for method validate of class Union
def test_Union_validate():
    from core.errors import ValidationError
    from core.fields import String
    from core.fields import Number

    f1 = String()
    f2 = Number()
    u = Union(any_of=[f1, f2])

    # Test success
    assert u.validate("3") == "3"
    assert u.validate(3) == 3

    # Test raise error: 'union'
    try:
        u.validate(False)
    except ValidationError as err:
        assert err.messages[0].text == "Did not match any valid type."
        assert err.messages[0].code == "union"

    # Test raise error: 'type'

# Generated at 2022-06-24 10:43:55.937318
# Unit test for constructor of class Decimal
def test_Decimal():
    # Test passing none values to Decimal constructor
    d = Decimal()
    assert d is not None

    # Test passing integer values for minimum and maximum.
    d = Decimal(minimum=-50)
    assert d.minimum == -50
    d = Decimal(maximum=50)
    assert d.maximum == 50


# Generated at 2022-06-24 10:43:58.338419
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2020-05-11T14:14:14+00:00") == "2020-05-11T14:14:14+00:00"
    
    

# Generated at 2022-06-24 10:44:00.329694
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field(title='abc')
    f.default = 3
    assert f.has_default() == True

# Generated at 2022-06-24 10:44:07.933957
# Unit test for constructor of class Union
def test_Union(): 
    """ Test constructor of class Union """
    assert Union([String(allow_empty=False), Integer(), Number()], allow_null=True).allow_null == True
    assert Union([String(allow_empty=False), Integer(), Number()], allow_empty=False).allow_empty == False
    assert Union([String(allow_empty=False), Integer(), Number()], description="A description").description == "A description"
    assert Union([String(allow_empty=False), Integer(), Number()], default="default").default == "default"
    assert Union([String(allow_empty=False), Integer(), Number()], default=None).default == None
    assert Union([String(allow_empty=False), Integer(), Number(), Boolean()], allow_null=False).allow_null == False

# Generated at 2022-06-24 10:44:09.564588
# Unit test for constructor of class Date
def test_Date():
    assert(type(Date()).__name__ == 'Date')


# Generated at 2022-06-24 10:44:14.017477
# Unit test for method validate of class Object
def test_Object_validate():
    testField = Object()
    assert testField.validate({"a": 1}) == {"a": 1}
    assert_raises(ValidationError, testField.validate, None)


# Generated at 2022-06-24 10:44:17.315150
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer().allow_null is False
    assert Integer(allow_null=False).allow_null is False
    assert Integer(allow_null=True).allow_null is True
    assert Integer(allow_null=True).numeric_type is int



# Generated at 2022-06-24 10:44:23.155540
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    D = Decimal()
    assert D.serialize(None) is None
    assert D.serialize(2) == 2.0
    assert D.serialize(2.2) == 2.2
    assert D.serialize(decimal.Decimal('2')) == 2.0
    assert D.serialize(decimal.Decimal('2.2')) == 2.2


BOOLEAN_TRUE = frozenset(("t", "true", "1"))
BOOLEAN_FALSE = frozenset(("f", "false", "0"))



# Generated at 2022-06-24 10:44:31.908891
# Unit test for method validate of class Union
def test_Union_validate():
    un = Union([Integer(), Number(), String()])
    un.validate(1337, strict=True)
    assert un.validate_or_error(1337, strict=True)[0] == 1337
    assert un.validate_or_error(13.37, strict=True)[0] == 13.37
    assert un.validate_or_error("1337", strict=True)[0] == "1337"
    assert isinstance(un.validate_or_error(None, strict=True)[1], ValidationError)
    assert isinstance(un.validate_or_error(False, strict=True)[1], ValidationError)


# Generated at 2022-06-24 10:44:34.427460
# Unit test for method validate of class Field
def test_Field_validate():
    try:
        field = Field()
        field.validate()
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:44:44.735491
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    code1 = 'code1'
    code2 = 'code2'
    code3 = 'code3'
    code4 = 'code4'
    field1 = Field()
    field2 = Field()
    field3 = Field()
    field4 = Field()
    field1.errors = {
        code1: 'This is an error message for x={x!r}',
        code2: 'This is an error message for y={y!r}',
    }
    field2.errors = {
        code2: 'This is an error message for y={y!r}',
        code3: 'This is an error message for z={z!r}',
    }

# Generated at 2022-06-24 10:44:50.308461
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typing import Any
    from yandex_music.schema import Field
    from yandex_music.schema import Integer
    from yandex_music.schema import String
    from yandex_music.schema import Union

    field1 = Integer(maximum=10)
    field2 = String(max_length=10)
    union1 = field1 | field2

    expected_result = Union([field1, field2], [])
    actual_result = union1

    assert expected_result == actual_result


# Generated at 2022-06-24 10:44:59.872344
# Unit test for method serialize of class Field
def test_Field_serialize():
    class Test:
        def __init__(self, field1, field2):
            self.field1 = field1
            self.field2 = field2

        def __str__(self):
            return "Test(field1 = " + str(self.field1) + ", field2 = " + str(self.field2) + ")"
    
    f1 = String(default="v1")
    f2 = String(default="v2")
    t = Test("v1", "v2")
    result = f1.serialize(t)
    expected = "v1"
    assert result == expected
    result = f2.serialize(t)
    expected = "v2"
    assert result == expected
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-24 10:45:00.989343
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any().validate(value=1)
    assert(a == 1)
    return None


# Generated at 2022-06-24 10:45:07.073468
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    title1 = 'title1'
    description1 = 'description1'
    default1 = 'default1'
    allow_null1 = True
    field = Field(title=title1,description=description1,default=default1,allow_null=allow_null1)
    value = 'value'
    strict = False
    field.validate_or_error(value=value,strict=strict)



# Generated at 2022-06-24 10:45:12.726454
# Unit test for constructor of class DateTime
def test_DateTime():
    from datetime import datetime
    from .validators import is_valid_datetime

    assert isinstance(DateTime(), DateTime)
    # assert isinstance(DateTime(default=datetime(2018, 6, 10)), DateTime)
    # assert isinstance(DateTime(default=is_valid_datetime), DateTime)

# Generated at 2022-06-24 10:45:14.336257
# Unit test for constructor of class Text
def test_Text():
    new_object = Text()
    assert isinstance(new_object, Text)


# Generated at 2022-06-24 10:45:18.757090
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field(title='abc', description='abc', default=1, allow_null=False).has_default()
    assert Field(title='abc', description='abc', allow_null=False).has_default() == False



# Generated at 2022-06-24 10:45:24.842228
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    number.allow_null = True
    assert number.validate('3.3') == '3.3'
    assert number.validate('3.3', strict = True) == '3.3'
    assert number.validate('3') == 3
    assert number.validate(3.3) == 3.3
    assert number.validate(3) == 3
    assert number.validate(None) == None
    assert number.validate('a') == None



# Generated at 2022-06-24 10:45:36.604858
# Unit test for method validate of class Choice
def test_Choice_validate():
    class Choice(Field):
        errors = {
            "null": "May not be null.",
            "required": "This field is required.",
            "choice": "Not a valid choice.",
        }

        def __init__(
                self,
                *,
                choices: typing.Sequence[typing.Union[str, typing.Tuple[str, str]]] = None,
                **kwargs: typing.Any,
        ) -> None:
            super().__init__(**kwargs)
            self.choices = [
                (choice if isinstance(choice, (tuple, list)) else (choice, choice))
                for choice in choices or []
            ]
            assert all(len(choice) == 2 for choice in self.choices)


# Generated at 2022-06-24 10:45:47.402134
# Unit test for method validate of class Union

# Generated at 2022-06-24 10:45:51.032891
# Unit test for method validate of class Const
def test_Const_validate():
    a = Const(None)
    assert a.validate(None) == None
    b = Const(False)
    assert b.validate(False) == False
    c = Const(42)
    assert c.validate(42) == 42
    d = Const(42.5)
    assert c.validate(42.5) == 42.5



# Generated at 2022-06-24 10:45:53.733728
# Unit test for constructor of class Object
def test_Object():
    field = Object(
        properties = {
            "a": Field(allow_null = True),
        }
    )
    field.validate({"a": None})


# Generated at 2022-06-24 10:46:01.675194
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    data = [(-4.4, -4.4),
            (-4, -4.0),
            (-0.005, -0.005),
            (0, 0.0),
            (3.5, 3.5),
            (4, 4.0)]
    for (input, expectedOutput) in data:
        test = Decimal()
        actualOutput = test.serialize(input)
        print(actualOutput)
        if actualOutput == expectedOutput:
            print("Test passed")
        else:
            print("Test failed. Expected output: {}".format(expectedOutput))


# Generated at 2022-06-24 10:46:12.129008
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [('en', 'English'), ('fr', 'French')]
    choice = Choice(choices=choices, allow_null=True)
    # Test that method validates correctly when value is null
    assert choice.validate(None, strict=False) == None
    # Test that method validates correctly when value is a valid choice
    assert choice.validate('en', strict=False) == 'en'
    # Test that method validates correctly when value is in choices but not a valid choice
    try:
        choice.validate('sp', strict=False)
        assert False
    except ValidationError:
        assert True
    # Test that method validates correctly when value is ""
    try:
        choice.validate('', strict=False)
        assert False
    except ValidationError:
        assert True
    # Test that method valid

# Generated at 2022-06-24 10:46:17.870482
# Unit test for method validate of class String
def test_String_validate():
    string = String(title="", description="", default=NO_DEFAULT, allow_null=False)
    assert string.validate(value=None, strict=False) == None
    assert string.validate(value="", strict=False) == ""
    assert string.validate(value="a", strict=False) == "a"
    assert string.validate(value=None, strict=True) == None

# Generated at 2022-06-24 10:46:22.855544
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=["1", "2"])
    val = field.validate("3")
    assert val is None


# Generated at 2022-06-24 10:46:26.125713
# Unit test for method validate of class Any
def test_Any_validate():
    f = Any()
    assert f.validate(1) == 1
    assert f.validate(1.1) == 1.1
    assert f.validate('a') == 'a'
    assert f.validate(True) == True
    assert f.validate(None) == None
    assert f.validate({}) == {}
    assert f.validate([]) == []



# Generated at 2022-06-24 10:46:29.870560
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestField(Field):
        default = 5
        def validate(self, value, *, strict=False):
            return value

    assert TestField.get_default_value() == 5

# Generated at 2022-06-24 10:46:37.922194
# Unit test for method validate of class Object
def test_Object_validate():
    data = {"c":4,"a":{"a":{"b":1}},"d":5,"b":5,"e":5}
    sub_schema = Object(properties={
        "b":Integer()
    })
    schema = Object(properties={
        "a":sub_schema
    })
    try:
        result = schema.validate(data)
        print("The result is: {}".format(result))
    except ValidationError as err:
        print("Oh no, the schema does not match the data!")
        for message in err.messages():
            print(message)

# Test the result
test_Object_validate()

# Test the object that has no properties, it contains only allowed_values

# Generated at 2022-06-24 10:46:45.047941
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    assert a.validate(12) == 12
    assert a.validate(12.5) == 12.5
    assert a.validate('str') == 'str'
    assert a.validate(True) == True
    assert a.validate([1,2,3]) == [1,2,3]
    assert a.validate((1,2,3)) == (1,2,3)
    assert a.validate({1:1, 2:2}) == {1:1, 2:2}
    assert a.validate(None) == None


# Generated at 2022-06-24 10:46:49.062517
# Unit test for constructor of class Number
def test_Number():
    num = Number(minimum=10, maximum=20)
    assert num.minimum == 10
    assert num.maximum == 20


# Generated at 2022-06-24 10:46:57.690614
# Unit test for method validate of class Any
def test_Any_validate():
    from .marshmallow import Schema
    from .exceptions import ValidationError

    class TestSchema(Schema):
        data = Any()

    schema = TestSchema()
    data, error = schema.load_or_error({"data": "hello"})

    assert not error
    assert data == {"data": "hello"}

    with pytest.raises(ValidationError) as e:
        schema.load({"data": "hello"}, partial={"data": {"allow_null": True}})

    assert len(e.value.messages) == 1
    assert e.value.messages[0].code == "null"
    assert e.value.messages[0].index == ["data"]


# Generated at 2022-06-24 10:46:59.455937
# Unit test for method serialize of class String
def test_String_serialize():
    field = String(
        title="",
        description="",
        format="date",
    )
    assert field.serialize("2019-04-01") == "2019-04-01"


# Generated at 2022-06-24 10:47:02.729885
# Unit test for constructor of class Boolean
def test_Boolean():
    obj = Boolean()
    assert obj.__dict__['allow_null'] == False
    obj = Boolean(allow_null = True)
    assert obj.__dict__['allow_null'] == True
    return



# Generated at 2022-06-24 10:47:09.109570
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code = 'code'
    text = 'text'
    # Test cases: 
    # - Assert if a ValidationError is returned
    # - Assert the error code that was given by the user and the error text
    # are correct
    e = field.validation_error(code)
    assert isinstance(e, ValidationError)
    assert code == e.code
    assert (text == e.text)
    
    
# Unit test case for method get_error_text of class Field

# Generated at 2022-06-24 10:47:12.109084
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    err = ValidationError(text="This is an error", code=None)
    assert err == Field.validation_error(Field, "required")


# Generated at 2022-06-24 10:47:15.633537
# Unit test for method serialize of class Array
def test_Array_serialize():
    countries = ['Germany','USA','France','Japan','France','India']
    assert Array(items=String()).serialize(obj=countries) == ['Germany','USA','France','Japan','France','India']

# Generated at 2022-06-24 10:47:24.207224
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True, name="t")
    choice.validate("a")
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("xxx") == None # xxx is not a valid choice according to definition of class Choice
    assert choice.validate("d") == None


# Generated at 2022-06-24 10:47:26.299935
# Unit test for constructor of class Any
def test_Any():
    test_Any_field = Any()
    assert test_Any_field.validate(1) == 1



# Generated at 2022-06-24 10:47:37.212113
# Unit test for constructor of class Array
def test_Array():
    # Case 1
    array_elements = [
        Field(name="name", type_=str),
        Field(name="age", type_=int),
        Field(name="age", type_=str),
        Field(name="age", type_=str),
        Field(name="age", type_=str),
    ]
    array_obj = Array(name="persons", items=array_elements)
    assert isinstance(array_obj, Array)

    # Case 2
    array_elements = [
        Field(name="name", type_=str),
        Field(name="age", type_=int),
        Field(name="age", type_=str),
        Field(name="age", type_=str),
        Field(name="age", type_=str),
    ]

# Generated at 2022-06-24 10:47:45.547760
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field.__or__.__doc__ == "Return a Union type."

    from . import types
    from .fields import Integer

    class TestField(types.Field):
        errors = {
            "custom_error_1": "Custom error 1.",
        }
        def validate(self, value, *, strict):
            return value

    test_field_1 = TestField()
    test_field_2 = TestField()
    test_field_3 = Integer()
    test_field_4 = TestField()
    field_1 = test_field_1 | test_field_2
    field_2 = test_field_3 | test_field_4
    assert isinstance(field_1, types.Union)
    assert isinstance(field_2, types.Union)


# Generated at 2022-06-24 10:47:47.815545
# Unit test for method validate of class String
def test_String_validate():
    field = String(title = 'test', description = 'test')
    with pytest.raises(NotImplementedError):
        field.validate("123")


# Generated at 2022-06-24 10:47:55.532602
# Unit test for method has_default of class Field
def test_Field_has_default():
    f1 = Field()
    assert f1.has_default() == False

    f2 = Field(default=2)
    assert f2.has_default() == True

#Unit test for method get_default_value of class Field

# Generated at 2022-06-24 10:48:01.120519
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    """
    Test function to test method get_error_text of class Field
    """
    f = Field(title = "My Title", description = "My Description")
    f.errors["required"] = "{title}"
    f.errors["invalid_type"] = "{title}"
    assert f.get_error_text("required") == "My Title"
    assert f.get_error_text("invalid_type") == "My Title"


# Generated at 2022-06-24 10:48:09.961653
# Unit test for method serialize of class Array
def test_Array_serialize():
        # create values
        int_serializer = Int()
        float_serializer = Float()
        str_serializer = String()
        # create values_array
        values_array = []
        # create Array Field
        array = Array(items=[int_serializer, float_serializer, str_serializer])
        # iterate
        for i in range(0, 4):
            values_array.append(array.serialize(obj=i))
        # assert that the length of the Array is correct
        assert len(values_array) == 4



# Generated at 2022-06-24 10:48:10.751259
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field().validate() == None

# Generated at 2022-06-24 10:48:12.028152
# Unit test for constructor of class Text
def test_Text():
    x = Text()
    assert x.format == 'text'


# Generated at 2022-06-24 10:48:18.864817
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class MyField(Field):
        errors = {
            "my:code": "my error message"
        }
    f = MyField()
    assert f.get_error_text("my:code") == "my error message"
    assert f.get_error_text("my:code").format(**f.__dict__) == "my error message"


# Generated at 2022-06-24 10:48:24.849362
# Unit test for constructor of class Any
def test_Any():
    schema = Any()
    assert schema.validate(1) == 1
    assert schema.validate("hi") == "hi"
    assert schema.validate([1, 2, 3]) == [1, 2, 3]
    assert schema.validate({"a": "b"}) == {"a": "b"}


# Generated at 2022-06-24 10:48:36.411452
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from numbers import Number

    class Int(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None:
                return None
            return int(value)

    class Float(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None:
                return None
            return float(value)

    class Number(Union):
        any_of = [Int(), Float()]

    assert isinstance(Number(), Field)
    assert Number._creation_counter > Int._creation_counter
    assert Number._creation_counter > Float._creation_counter

    integer = Number().validate_or_error(1)
    assert integer.value == 1
    assert integer.error is None
# Unit test