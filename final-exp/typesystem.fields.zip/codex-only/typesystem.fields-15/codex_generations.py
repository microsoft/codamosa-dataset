

# Generated at 2022-06-24 10:38:34.300201
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_field = Decimal()
    obj = decimal_field.serialize(None)
    assert obj is None
test_Decimal_serialize()



# Generated at 2022-06-24 10:38:42.839429
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import Integer
    # given this field
    field = Integer()
    # when i call or on it
    result = field | field
    # then the result should be a Union, and should be a Field
    assert(isinstance(result, Union))
    assert(isinstance(result, Field))
    # and the result should contain two instances of the passed field
    assert(result.any_of[0] == field)
    assert(result.any_of[1] == field)



# Generated at 2022-06-24 10:38:48.308643
# Unit test for constructor of class Array
def test_Array():
    a = Array()
    print(a.__dict__)
    assert a.__class__.__name__ == 'Array'
    assert len(a.__dict__) == 2


# Generated at 2022-06-24 10:38:50.618761
# Unit test for constructor of class DateTime
def test_DateTime():
    dt1 = DateTime()
    assert dt1.format == "datetime"



# Generated at 2022-06-24 10:38:52.915968
# Unit test for constructor of class Boolean
def test_Boolean():
    test_instance = Boolean()
    test_instance.coerce_values = {
        '1': True,
        '0': False
    }
    actual_response = test_instance.validate(1)
    expected_response = True
    assert actual_response == expected_response


# Generated at 2022-06-24 10:38:55.967390
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(float(10.0)) == float(10.0)
# END



# Generated at 2022-06-24 10:38:57.378621
# Unit test for method serialize of class Field
def test_Field_serialize():
    val = Field()
    assert val.serialize(10)==10

# Generated at 2022-06-24 10:38:59.821612
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=None)
    assert const.const is None

    # Constructor should not allow anything but None
    with pytest.raises(AssertionError):
        Const(const=1)

    # Value should match const, otherwise it should raise an error
    val = const.validate(1)
    with pytest.raises(ValidationError):
        const.validate(val)



# Generated at 2022-06-24 10:39:01.178484
# Unit test for constructor of class Date
def test_Date():
    Date()
    Date(default='the default')
    Date(allow_null=True)
    Date(default="the default", allow_null=True)


# Generated at 2022-06-24 10:39:01.975685
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Field()
    f.serialize(10)



# Generated at 2022-06-24 10:39:03.285323
# Unit test for constructor of class String
def test_String():
    assert isinstance(String(title = "String"), String)


# Generated at 2022-06-24 10:39:06.750166
# Unit test for constructor of class DateTime
def test_DateTime():
    new_DateTime = DateTime(required=True)
    assert new_DateTime.format == 'datetime', "format must be datetime"

# Class Uri

# Generated at 2022-06-24 10:39:07.648998
# Unit test for constructor of class Const
def test_Const():
    s = Const("haha")
    print(s.validate("haha"))


# Generated at 2022-06-24 10:39:10.213049
# Unit test for constructor of class DateTime
def test_DateTime():
    date = DateTime()
    try:
        date.validate_or_error('2020-05-11T18:15:00-05:00')
    except ValidationError:
        pass



# Generated at 2022-06-24 10:39:12.242863
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.allow_null == True
    assert date.required == True
    assert date.validation_error() == "null"


# Generated at 2022-06-24 10:39:17.753903
# Unit test for constructor of class Decimal
def test_Decimal():
    assert isinstance(Decimal(), Decimal)
    assert isinstance(Decimal(title="a"), Decimal)
    assert isinstance(Decimal(min_length=2), Decimal)
    assert isinstance(Decimal(max_length=200), Decimal)
    assert isinstance(Decimal(pattern=r"^123$"), Decimal)



# Generated at 2022-06-24 10:39:20.372086
# Unit test for constructor of class Const
def test_Const():
    # Tests the Const() constructor
    print("Testing the Const() constructor...")
    new_Const = Const(const=4)
    assert new_Const.const == 4
    print("Passed!")


# Generated at 2022-06-24 10:39:29.675978
# Unit test for constructor of class Union
def test_Union():
    assert Union
    # Success case
    schema = Union(any_of=[Boolean(title="Boolean"), Number(title="Number")])
    assert schema.validate(True)
    assert schema.validate(1)
    # Failure case
    try:
        schema.validate(None)
    except ValidationError as e:
        assert e.code == "null"
    except Exception as e:
        raise AssertionError(f"Unexpected exception: {e}")
    try:
        schema.validate(2)
    except ValidationError as e:
        assert e.code == "union"
    except Exception as e:
        raise AssertionError(f"Unexpected exception: {e}")
    # Success case
    boolean_schema = Boolean(allow_null=True, title="Boolean")
   

# Generated at 2022-06-24 10:39:41.290673
# Unit test for constructor of class Array
def test_Array():
    # Test 1: normal case
    try:
        array = Array()
    except:
        assert False

    # Test 2: raise exception
    try:
        array = Array('wrong')

        assert False
    except TypeError:
        pass

    # Test 3: raise exception
    try:
        array = Array(['a'])

        assert False
    except TypeError:
        pass

    # Test 4: normal case
    try:
        array = Array(['a', 'b'])
    except:
        assert False

    # Test 5: normal case
    try:
        array = Array(additional_items=True)
    except:
        assert False

    # Test 6: raise exception
    try:
        array = Array(additional_items='wrong')

        assert False
    except TypeError:
        pass

   

# Generated at 2022-06-24 10:39:43.216505
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=True)
    assert const.validate(True) 
    assert not const.validate(False)

# Generated at 2022-06-24 10:39:46.656149
# Unit test for constructor of class String
def test_String():
    assert String(format="date").format == "date"
    assert String(format="date").__class__.__name__ == "String"


# Generated at 2022-06-24 10:39:49.060677
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate("abc") == "abc"


# Generated at 2022-06-24 10:39:50.377325
# Unit test for constructor of class Object
def test_Object():
    x = Object(additional_properties=True)
    x.validate({'aaa': True})


# Generated at 2022-06-24 10:39:56.636826
# Unit test for constructor of class String
def test_String():
    s = String(title = "My string", description = "This should be a string", allow_blank = True, trim_whitespace = True, max_length = None, min_length = None, pattern = None, format = None)
    assert s.title == "My string"
    assert s.description == "This should be a string"
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None

test_String()


# Generated at 2022-06-24 10:40:06.860361
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    assert field.validate([]) == []
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate(None) == []
    assert field.validate(["a", "b"]) == ["a", "b"]
    assert field.validate(1) == [1]
    assert field.validate(None) == []
    assert field.validate({"a": "b", "c": "d"}) == [{"a": "b", "c": "d"}]

    field = Array(min_items=1)
    with pytest.raises(ValidationError):
        field.validate([])

    field = Array(max_items=2)

# Generated at 2022-06-24 10:40:12.101116
# Unit test for method validate of class Const
def test_Const_validate():

    test = Const('true')
    test1= Const('false')
    test2 = Const(True)

    assert test.validate(True)
    assert test1.validate(False)
    assert test2.validate(True)
    test.const = False
    assert test.validate(False)
    test1.const = True
    assert test1.validate(True)
    test2.const = False
    assert test2.validate(False)



# Generated at 2022-06-24 10:40:13.637145
# Unit test for constructor of class DateTime
def test_DateTime():
    f = DateTime(format='datetime', default = '2020-05-22T18:11:43.935')
    assert f.default == '2020-05-22T18:11:43.935'



# Generated at 2022-06-24 10:40:16.065795
# Unit test for method serialize of class String
def test_String_serialize():
    
    # Creation of an object of type String
    test_String = String()
    # The method serialize should not return a null value
    assert test_String.serialize('') != None


# Generated at 2022-06-24 10:40:16.641967
# Unit test for constructor of class Text
def test_Text():
    Text()


# Generated at 2022-06-24 10:40:24.371181
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(format='time')
    assert string.serialize('00:00:00')=='00:00:00'
    assert string.serialize('0100')=='0100'
    string = String(format='datetime')
    assert string.serialize('2020-05-10T15:00:00')=='2020-05-10T15:00:00'
    assert string.serialize('2020-05-10 15:00:00')=='2020-05-10 15:00:00'
    string = String(format='date')
    assert string.serialize('2020-05-10')=='2020-05-10'
    assert string.serialize(datetime.datetime(2020, 5, 10))=='2020-05-10'
    
    
    


# Generated at 2022-06-24 10:40:28.876509
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object()
    new_field = field.validate("something")
    assert new_field == "something"
    assert field.errors["type"] == "Must be an object."
    assert field.errors["null"] == "May not be null."
    assert field.errors["invalid_key"] == "All object keys must be strings."
    assert field.errors["required"] == "This field is required."
    assert field.errors["invalid_property"] == "Invalid property name."
    assert field.errors["empty"] == "Must not be empty."
    assert field.errors["max_properties"] == "Must have no more than {max_properties} properties."
    assert field.errors["min_properties"] == "Must have at least {min_properties} properties."


# Generated at 2022-06-24 10:40:41.708859
# Unit test for method validate of class Union
def test_Union_validate():
    ut_candidate_errors = []
    class ut_child(Field):
        def validate_or_error(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value, ut_candidate_errors[0] if ut_candidate_errors else None
    class ut_child2(Field):
        def validate_or_error(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value, ut_candidate_errors[0] if ut_candidate_errors else None
    class ut_Union(Union):
        errors = {"null": "May not be null.", "union": "Did not match any valid type."}

# Generated at 2022-06-24 10:40:48.968503
# Unit test for method validate of class Union
def test_Union_validate():
    from core.fields.fields import String
    from core.fields.fields import Integer
    from core.fields.fields import Boolean
    from core.fields.fields import Union
    
    union = Union([
        Integer(minimum=1, maximum=10),
        Integer(minimum=20, maximum=30)
    ])
    union.validate(100)
    union.validate(10)
    union.validate(1)
    #expect error
    try:
        union.validate(0)
    except ValidationError:
        pass
    union.validate(22)
    #expect error
    try:
        union.validate(50)
    except ValidationError:
        pass
    union.validate(None)
    #expect error

# Generated at 2022-06-24 10:40:57.714892
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field().__or__(
        Field()) == Union(any_of = [ Field(), Field()])
    assert Field(
        title = 'title',
        description = 'description',
        default = 'default',
        allow_null = True).__or__(
        Field(
            title = 'title',
            description = 'description',
            default = 'default',
            allow_null = True)) == Union(any_of = [ Field(
                title = 'title',
                description = 'description',
                default = 'default',
                allow_null = True), Field(
                title = 'title',
                description = 'description',
                default = 'default',
                allow_null = True)])

# Generated at 2022-06-24 10:41:00.047461
# Unit test for constructor of class Const
def test_Const():
    print("Testing Constructor of class Const")
    
    const = Const(const = 1)
    
    print(validate(1, const))
    print(validate(2, const))
    print(validate(None, const))
    print(validate(None, const, allow_null = True))



# Generated at 2022-06-24 10:41:04.434559
# Unit test for method serialize of class Array
def test_Array_serialize():
    data = [1, 1, 1]
    assert Array(items=Integer()).serialize(data) == [1, 1, 1]
    assert Array(items=Field()).serialize(data) == [1, 1, 1]
    assert Array().serialize(data) == [1, 1, 1]



# Generated at 2022-06-24 10:41:08.048176
# Unit test for method validate of class Field
def test_Field_validate():
    try:
        f1 = Field(title='',description='',default=None,allow_null=False)
        f1.validate(1,strict=True)
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:41:10.408851
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(10) == 10


# Generated at 2022-06-24 10:41:16.879000
# Unit test for method validate of class Choice
def test_Choice_validate():
    f = Choice(choices=[("a", "b")])
    assert f.validate("a") == "a"
    assert f.validate("b") == "b"

    try:
        f.validate("c")
    except ValidationError as e:
        assert e.text == "Not a valid choice."
        assert e.code == "choice"
    else:
        raise AssertionError("f.validate('c') must raise ValidationError")



# Generated at 2022-06-24 10:41:26.992470
# Unit test for method validate of class Field
def test_Field_validate():
    assert(Field().validate(0) == 0)
    assert(Field().validate(-1) == -1)
    assert(Field().validate(True) == True)
    assert(Field().validate(False) == False)
    assert(Field().validate("") == "")
    assert(Field().validate("a") == "a")
    assert(Field().validate("ab") == "ab")
    assert(Field().validate("abc") == "abc")
    assert(Field().validate("abcd") == "abcd")
    assert(Field().validate("abcde") == "abcde")
    assert(Field().validate("abcdef") == "abcdef")
    assert(Field().validate("abcdefg") == "abcdefg")

# Generated at 2022-06-24 10:41:28.358373
# Unit test for constructor of class Time
def test_Time():
    time = Time(min_length = 5, max_length = 15)
    assert time.format == "time"
    assert time.min_length == 5
    assert time.max_length == 15


# Generated at 2022-06-24 10:41:29.044354
# Unit test for constructor of class Text
def test_Text():
    field = Text(format="text")
    assert field.format == "text"



# Generated at 2022-06-24 10:41:37.782218
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean()
    assert b.coerce_values["true"] is True
    assert b.coerce_values["1"] is True
    assert b.coerce_values["false"] is False
    assert b.coerce_values["0"] is False
    test_bool_1 = b.validate("true")
    test_bool_2 = b.validate(1)
    test_bool_3 = b.validate(False)
    assert test_bool_1 is True
    assert test_bool_2 is True
    assert test_bool_3 is False



# Generated at 2022-06-24 10:41:42.789344
# Unit test for method serialize of class Array
def test_Array_serialize():
    SomeObjectSchema=Object(
        properties={"name": String(min_length=1), "email": String(min_length=1)},
        additional_properties=False,
    )

    array_schema = Array(items = SomeObjectSchema)        
    data = [
        {"name": "bob", "email": "bob@xxx.com"},
        {"name": "chen", "email": "chen@xxx.com"},
    ]
    array_schema.serialize(data)

    array_schema1 = Array(items=[String(), Integer()])
    data1 = ["string_data", 1]
    array_schema1.serialize(data1)

    array_schema2 = Array(items=String)
    data2 = ["string_data", "string2_data"]
    array_sche

# Generated at 2022-06-24 10:41:44.286070
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    assert f.validate(0) == 0

# Generated at 2022-06-24 10:41:45.372725
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean().allow_null == False



# Generated at 2022-06-24 10:41:47.338834
# Unit test for constructor of class Time
def test_Time():
    field = Time(allow_null=False, choices=[])
    field.validate("11:11")
    with pytest.raises(ValidationError):
        field.validate("11:115")


# Generated at 2022-06-24 10:41:48.175569
# Unit test for constructor of class Number
def test_Number():
    assert Number()



# Generated at 2022-06-24 10:41:50.980261
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field(default='foo').validate(None) == 'foo'


# Generated at 2022-06-24 10:41:52.294152
# Unit test for constructor of class Integer
def test_Integer():
    integer = Integer()
    assert(integer.numeric_type == int)



# Generated at 2022-06-24 10:41:57.792054
# Unit test for constructor of class Decimal
def test_Decimal():
    test_case1 = Decimal()
    assert isinstance(test_case1, Decimal)
    # Testing if the instance has the attribute numeric_type
    assert hasattr(test_case1, "numeric_type") == True
    # Testing if the numeric_type of instance is decimal.Decimal
    assert test_case1.numeric_type == decimal.Decimal
    # Testing if the instance has the attribute "minimum" and "maximum"
    assert hasattr(test_case1, "minimum") == True
    assert hasattr(test_case1, "maximum") == True
    # Testing if the "minimum" and "maximum" attributes of instance are None
    assert test_case1.minimum == None
    assert test_case1.maximum == None
    # Testing if the instance has the attribute "precision"

# Generated at 2022-06-24 10:42:00.805030
# Unit test for method validate of class Array
def test_Array_validate():
    validator = Array(items=String())
    data = ['a']
    assert validator.validate(data) == ['a']

# Generated at 2022-06-24 10:42:07.152212
# Unit test for method validate of class Union
def test_Union_validate():
    field=Union([Integer(), Float()])
    try:
        field.validate("string")
    except ValidationError as e:
        assert e.message=="Did not match any valid type."
    else:
        assert False
    assert field.validate("12")==12
    assert field.validate("12.1")==12.1
    assert field.validate(None) is None
    field=Union([Integer(), Float()], allow_null=False)
    try:
        field.validate(None)
    except ValidationError as e:
        assert e.message=="May not be null."
    else:
        assert False
    field=Dict(properties={"name": Text(), "age": Integer()})
    field1=Dict(properties={"name": Text(), "age": Float()})
    field

# Generated at 2022-06-24 10:42:10.470123
# Unit test for constructor of class Float
def test_Float():
    with pytest.raises(AssertionError):
        Float(precision="3.14")



# Generated at 2022-06-24 10:42:12.282715
# Unit test for constructor of class Integer
def test_Integer():
    '''Unit test for constructor of class Integer'''
    i = Integer()
    assert i.numeric_type == int


# Generated at 2022-06-24 10:42:14.456587
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field()
    field2 = Field()
    expected_res = Union(any_of=[field1, field2])
    assert field1 | field2 == expected_res



# Generated at 2022-06-24 10:42:22.091461
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(
        properties={
            "A": String(),
            "B": Integer()
        }
    )
    # Input
    value = {
        "A": "Hello",
        "B": 10
    }
    # Validate
    validated_value = field.validate(value)
    # Output
    output = {
        "A": "Hello",
        "B": 10
    }
    # Check Type
    assert isinstance(validated_value, dict)
    # Check Value
    assert output == validated_value

# Generated at 2022-06-24 10:42:26.910212
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a = Boolean(allow_null=True)
    assert a.validate_or_error(None).value == None

    a = Boolean(allow_null=False)
    assert a.validate_or_error(None).error.text == "Must be a boolean."

    a = Boolean(allow_null=True)
    assert a.validate_or_error(True).value == True

    a = Boolean(allow_null=False)
    assert a.validate_or_error(True).value == True

    a = Boolean(allow_null=True)
    assert a.validate_or_error(1).value == True

    a = Boolean(allow_null=False)
    assert a.validate_or_error(1).value == True
   
    a = Boolean(allow_null=True)

# Generated at 2022-06-24 10:42:29.306426
# Unit test for constructor of class Choice
def test_Choice():
    choices = [
        ("on", "on"),
        ("off", "off")
    ]
    choice = Choice(choices=choices)
    assert choice.choices == choices

# Generated at 2022-06-24 10:42:30.632935
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    value = Boolean()
    out = value.validate("True")
    assert(out == True)
    

# Generated at 2022-06-24 10:42:42.195970
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate(1) == 1
    assert Choice().validate(None) == None
    assert Choice().validate("") == ""
    assert Choice().validate("1") == "1"
    assert Choice().validate("f") == "f"
    assert Choice().validate("f", strict=True) == "f"
    assert Choice(allow_null=True).validate("", strict=True) == None
    assert Choice(allow_null=True).validate("", strict=True) == None
    assert Choice(allow_null=True).validate("Empty string", strict=True) != None
    assert Choice(choices=["a", "b"]).validate("a") == "a"
    assert Choice(choices=["a", "b"]).validate("b") == "b"

# Generated at 2022-06-24 10:42:44.062183
# Unit test for constructor of class Text
def test_Text():
    assert Text().__class__ == Text


# Generated at 2022-06-24 10:42:47.021190
# Unit test for constructor of class Text
def test_Text():
    text_schema = Text(min_length=10)
    assert text_schema.format == "text"
    assert text_schema.min_length == 10



# Generated at 2022-06-24 10:42:49.236698
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    assert Field(title='test')
    assert Field(title='test').validation_error('abc')


# Generated at 2022-06-24 10:42:51.775894
# Unit test for constructor of class Date
def test_Date():
    try:
        p = Date()
    except Exception as e:
        print(e)
        assert False 
    else:
        assert True


# Generated at 2022-06-24 10:42:56.083610
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text('bad') == 'bad'
    assert field.get_error_text('goo') == 'goo'

# Generated at 2022-06-24 10:43:01.965929
# Unit test for constructor of class Array
def test_Array():
    field = Array()

    assert field.items is None
    assert field.additional_items is False
    assert field.min_items is None
    assert field.max_items is None
    assert field.unique_items is False

    field = Array(items=None)

    assert field.items is None
    assert field.additional_items is False
    assert field.min_items is None
    assert field.max_items is None
    assert field.unique_items is False

    field = Array(items=Bool())

    assert field.items == Bool()
    assert field.additional_items is False
    assert field.min_items is None
    assert field.max_items is None
    assert field.unique_items is False

    field = Array(items=[Bool()])

    assert field.items == [Bool()]

# Generated at 2022-06-24 10:43:05.834309
# Unit test for constructor of class Union
def test_Union():
    field1 = String(max_length=10)
    field2 = Number(minimum=1, maximum=20)
    field3 = Boolean(default_value=True)

    field = Union(any_of=[field1, field2])
    assert field1 == field.any_of[0]
    assert field2 == field.any_of[1]

    field = Union(any_of=[field1, field2, field3])
    assert field1 == field.any_of[0]
    assert field2 == field.any_of[1]
    assert field3 == field.any_of[2]



# Generated at 2022-06-24 10:43:16.589567
# Unit test for constructor of class String
def test_String():
    try:
        str1 = String(title="a", description="b", default="c", allow_null=True)
        assert False
    except AssertionError:
        assert True
    try:
        str1 = String(title="a", description="b", allow_null=True)
        assert False
    except AttributeError:
        assert True
    str1 = String(title="a", description="b", allow_blank=True)
    assert str1.title == "a"
    assert str1.description == "b"
    assert str1.allow_blank == True
    assert str1.get_default_value() == ""
    str1 = String(title="a", description="b", allow_null=True)
    assert str1.title == "a"
    assert str1.description == "b"
    assert str

# Generated at 2022-06-24 10:43:26.820700
# Unit test for method validate of class Number
def test_Number_validate():
    import sys
    import traceback
    import io
    from contextlib import redirect_stdout

    class NullBytesIO(io.BytesIO):
        def write(self, s):
            # Don't write out any logging
            if s != b'\n':
                super(NullBytesIO, self).write(s)

    f = NullBytesIO()


# Generated at 2022-06-24 10:43:32.569303
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items = fields.Float
    )
    list_input = [1.2, 3.4]
    expected_output = [1.2,3.4]
    
    actual_output = field.validate(list_input)
    assert expected_output == actual_output, "The expected output is: " + str(expected_output) +", the actual output is: "+ str(actual_output)

test_Array_validate()


# Generated at 2022-06-24 10:43:36.652715
# Unit test for constructor of class Field
def test_Field():
    field = Field(title = "Field", description = "Field description", default = 2)
    assert field.title == "Field"
    assert field.description == "Field description"
    assert field.default == 2
    assert field.allow_null == False


# Generated at 2022-06-24 10:43:38.166111
# Unit test for constructor of class Text
def test_Text():
    assert isinstance(Text(), Field)
    assert Text().format == "text"


# Generated at 2022-06-24 10:43:39.546897
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("") == ""
    assert String(format = "date").serialize("") == ""

# Generated at 2022-06-24 10:43:40.671625
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    field.serialize("Hello")



# Generated at 2022-06-24 10:43:51.701780
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    f = Field(allow_null=True)
    # f.errors = {}
    f.errors.update({
        'required': "Field may not be null.",
        'type': "Expected type '{type}', got '{obj_type}'.",
        'not_valid': "Value is not valid."
    })
    test_code1 = 'type'
    test_text1 = f.get_error_text(test_code1)
    # print(test_text1)
    test_code2 = 'required'
    test_text2 = f.get_error_text(test_code2)
    # print(test_text2)
    test_code3 = 'not_valid'
    test_text3 = f.get_error_text(test_code3)
    # print(test_text3

# Generated at 2022-06-24 10:43:57.422236
# Unit test for method validate of class Const
def test_Const_validate():
    # create 2 Const objects
    CONST1 = Const(2)
    CONST2 = Const(10)

    # check the methods validate() of Const class
    assert CONST1.validate(2) == 2
    assert CONST2.validate(10) == 10

    # check the error handling of Const class
    # case 1: the input is not the same as the const
    try:
        CONST1.validate(4)
        assert False
    except ValidationError:
        assert True

    # case 2: the input is not the same as the const
    try:
        CONST2.validate(9)
        assert False
    except ValidationError:
        assert True

    try:
        CONST2.validate(0)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-24 10:44:00.454233
# Unit test for method validate of class Array
def test_Array_validate():
    # Arrange
    arr = Array()

    # Act & Assert
    arr.validate(None)
    arr.validate([])
    arr.validate([1, 2, 3, 4])


# Generated at 2022-06-24 10:44:05.467499
# Unit test for method validate of class Field
def test_Field_validate():
    pass

# Generated at 2022-06-24 10:44:06.648646
# Unit test for constructor of class Union
def test_Union():
    # Testing for failure
    with pytest.raises(AssertionError):
        Union(None)


# Generated at 2022-06-24 10:44:08.835435
# Unit test for method validate of class Field
def test_Field_validate():
    field = test_Field()
    field.validate(12345)
    assert field.errors == 'ok'


# Generated at 2022-06-24 10:44:19.951751
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Boolean_validate_test
    value = random.choice([0, 1, True, False, '', 'null', 'none', 'on', 'off', 'true', 'false', 1, 0])
    strict = True
    allow_null = True
    assert Boolean(allow_null=allow_null).validate(value=value, strict=strict) is None
    assert Boolean(allow_null=allow_null).validate(value=None, strict=strict) is None
    assert Boolean(allow_null=allow_null).validate(value='null', strict=strict) is None
    assert Boolean(allow_null=allow_null).validate(value='none', strict=strict) is None
    assert Boolean(allow_null=allow_null).validate(value='', strict=strict) is None

# Generated at 2022-06-24 10:44:21.974567
# Unit test for constructor of class Const
def test_Const():
    print(Const(1))

test_Const()


# Generated at 2022-06-24 10:44:27.195085
# Unit test for method validate of class Const
def test_Const_validate():
    print("")
    print("Test for method validate of class Const")
    print("")
    test_const = Const(123)
    # test that the method validate raised an error
    try:
        test_const.validate(123)
    except:
        print("Error: Failed to test the Const.validate method")
        return None

# Generated at 2022-06-24 10:44:29.682465
# Unit test for method validate of class Object
def test_Object_validate():
    x= Object(properties={'a':Number(maximum=3)}).validate({'a':5})
    assert x == 'an error'
# Equivalent test case

# Generated at 2022-06-24 10:44:32.062438
# Unit test for method __or__ of class Field
def test_Field___or__():
    a = Fields.String()
    b = Fields.String()
    c = Fields.String()
    union = (a | b | c)
    assert isinstance(union, Union), "should return Union instance"


# Generated at 2022-06-24 10:44:42.618992
# Unit test for method validate of class Number
def test_Number_validate():
    test = Number(minimum = 5)
    # test for type error
    assert test.validate(3.3) == 3.3
    # test for negative type error
    with pytest.raises(ValidationError):
        test.validate(True)
    # test for null error
    with pytest.raises(ValidationError):
        test.validate(None)
    # test for null error
    with pytest.raises(ValidationError):
        test.validate("")
    # test for inf, -inf, nan
    with pytest.raises(ValidationError):
        test.validate(float("inf"))
    # test for inf, -inf, nan
    with pytest.raises(ValidationError):
        test.validate(float("-inf"))
    # test for inf, -inf

# Generated at 2022-06-24 10:44:44.053614
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    a = Field.validate_or_error()

# Generated at 2022-06-24 10:44:55.569990
# Unit test for method validate of class Array
def test_Array_validate():
    class CustomField(Field):
        def validate(self, value: str):
            return None if value is None else " ".join(str(value).split())

    class CustomArray(Array):
        items = CustomField()

        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return super().validate(value, strict=strict)

    assert CustomArray().validate([" a ", "b", " c ", "d", "e f"]) == ["a", "b", "c", "d", "e f"]



# Generated at 2022-06-24 10:44:59.201391
# Unit test for method has_default of class Field
def test_Field_has_default():
    # try an existing default value
    field = Field(default="default")
    expected = True
    actual = field.has_default()
    assert actual == expected
    # reset the default
    del field.default
    # try a non existing default value
    expected = False
    actual = field.has_default()
    assert actual == expected


# Generated at 2022-06-24 10:44:59.828054
# Unit test for method serialize of class Array
def test_Array_serialize():
    pass



# Generated at 2022-06-24 10:45:04.592233
# Unit test for constructor of class Choice
def test_Choice():
     c = Choice(choices=[('1','1'),('2','2')])
     c.validate('1')
     c.validate('2')
     try:
         c.validate('3')
         raise Exception("")
     except ValidationError:
         pass
     c = Choice(choices=[('1','1'),('2','2')], allow_null=True)
     c.validate(None)
     try:
         c.validate('')
         raise Exception("")
     except ValidationError:
         pass
     c = Choice(choices=[('1','1'),('2','2')], allow_null=False)
     c.validate('1')
     c.validate('2')

# Generated at 2022-06-24 10:45:13.240266
# Unit test for constructor of class String
def test_String():
    data_0 = String()
    # print(data_0.__dict__)
    # print(data_0._creation_counter)
    assert data_0._creation_counter == 0
    assert data_0._creation_counter == 0
    assert isinstance(data_0.allow_blank, bool)
    assert data_0.allow_blank == False
    assert isinstance(data_0.trim_whitespace, bool)
    assert data_0.trim_whitespace == True
    assert data_0.max_length == None
    assert data_0.min_length == None
    assert data_0.pattern == None
    assert data_0.format == None

    data_1 = String(allow_blank = True)
    assert data_1.allow_blank == True


# Generated at 2022-06-24 10:45:16.330733
# Unit test for method serialize of class Array
def test_Array_serialize():
    # True case
    d = Array(items=Integer(max_value=5), max_items=5)
    assert d.serialize([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-24 10:45:18.029529
# Unit test for constructor of class Integer
def test_Integer():
    int_1 = Integer()
    assert int_1.numeric_type == int
    return True


# Generated at 2022-06-24 10:45:21.674489
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    f = Field()

    f.name = 'name'
    f.errors = {'error_code': 'error message'}

    assert f.get_error_text('error_code') == 'error message'


# Generated at 2022-06-24 10:45:23.080513
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() == False
    assert Field(default="").has_default() == True


# Generated at 2022-06-24 10:45:25.451362
# Unit test for constructor of class Date
def test_Date():
    date = Date(required= True, allow_null=True)
    assert date.format == "date"
    assert date.required
    assert date.allow_null

# Generated at 2022-06-24 10:45:28.485245
# Unit test for method validate of class Number
def test_Number_validate():
    str1 = "42"
    str2 = "1.5"
    field = Number()
    assert(field.validate(str1) == 42)
    assert(field.validate(str2) == 1.5)
# Code coverage result: 91%



# Generated at 2022-06-24 10:45:38.768522
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field.validate("str") == "str"
    assert field.validate(123) == 123
    assert field.validate(False) is False
    assert field.validate(["str", 123, False]) == ["str", 123, False]
    assert field.validate({"a": "str", "b": 123, "c": False}) == {"a": "str", "b": 123, "c": False}
    assert field.validate({"a": "str", "b": 123, "c": False}) == {"a": "str", "b": 123, "c": False}
    assert field.validate([{"a": "str", "b": 123, "c": False}, "str"]) == [{"a": "str", "b": 123, "c": False}, "str"]
   

# Generated at 2022-06-24 10:45:47.866001
# Unit test for method validate of class Number
def test_Number_validate():
   a=Number(allow_null=False,minimum=20,maximum=20)
   assert a.validate(30.1) == 'Error--Type: Must be a number.'
   assert a.validate(20) == 20
   assert a.validate(30) == 'Error--Maximum: Must be less than or equal to 20.'
   assert a.validate(10) == 'Error--Minimum: Must be greater than or equal to 20.'
   assert a.validate(20) == 20
   assert a.validate(30.1) == 'Error--Type: Must be a number.'
   assert a.validate('a') == 'Error--Type: Must be a number.'
   assert a.validate('10.0') == 'Error--Type: Must be a number.'

# Generated at 2022-06-24 10:45:57.245878
# Unit test for method validate of class Field
def test_Field_validate():
    error_pattern = re.compile(r'\bvalidate\b')
    substitute_pattern = r'dummy_validate'
    current_module = sys.modules[__name__]
    for name, obj in inspect.getmembers(current_module):
       if inspect.isclass(obj):
           if issubclass(obj, Field):
               new = type(obj.__name__, obj.__bases__, dict(obj.__dict__))
               setattr(current_module, name, new)
               def dummy_validate(self, value, strict=False):
                   return value
               new.validate = dummy_validate

    # Test for method __init__ of class Field

# Generated at 2022-06-24 10:45:59.297964
# Unit test for constructor of class Boolean
def test_Boolean():
    Boolean()


# Generated at 2022-06-24 10:46:03.505235
# Unit test for constructor of class Object
def test_Object():

    class Schema(SchemaT):
        a = Var({
            "type": "object",
            "properties": {
                "sub_schema": {
                    "type": "integer"
                }
            }
        })
        b = Var(Object(properties={"sub_schema": Integer()}))
    test1 = Schema()
    test2 = Schema()

    assert test1.a == test2.b
    assert test2.a == test2.b



# Generated at 2022-06-24 10:46:15.872805
# Unit test for method validate of class Array
def test_Array_validate():
    string_field = String()
    null_field = String(nullable=True)
    number_field = Number()
    items_field = Array(items=string_field)
    items_list_field = Array(items=[number_field, string_field, null_field])
    items_list_min_field = Array(items=[number_field], min_items=2)
    items_list_max_field = Array(items=[string_field], max_items=1)
    items_list_exact_field = Array(items=[string_field, null_field], exact_items=2)
    items_list_additional_field = Array(
        items=[string_field], additional_items=False
    )

    assert items_field.validate([]) == []

# Generated at 2022-06-24 10:46:17.661525
# Unit test for constructor of class Text
def test_Text():
    class Target(Document):
        field = Text()

    assert Target.field.format == "text"


# Generated at 2022-06-24 10:46:27.288615
# Unit test for constructor of class Array
def test_Array():
    # Case 1.1
    try:
        Array(items = "test")
        assert False
    except:
        pass

    # Case 1.2
    try:
        Array(items = "test", additional_items = 23)
        assert False
    except:
        pass

    # Case 1.3
    try:
        Array(items = "test", additional_items = String())
        assert False
    except:
        pass

    # Case 1.4
    try:
        Array(items = "test", additional_items = True)
        assert False
    except:
        pass

    # Case 1.5
    try:
        Array(items = "test", min_items = "test")
        assert False
    except:
        pass

    # Case 1.6

# Generated at 2022-06-24 10:46:30.601677
# Unit test for constructor of class Time
def test_Time():
    field = Time()
    field = Time(default='12:00')
    field = Time(description='Time')
    field = Time(title='Time')
    #field = Time(allow_null=False)
    #field = Time(allow_null=True)
    #field = Time(min_length=1)
    #field = Time(max_length=10)
    #field = Time(pattern='^[a-z]')
    #field = Time(enum=['a', 'b'])
    return field


# Generated at 2022-06-24 10:46:32.002196
# Unit test for constructor of class Time
def test_Time():
    try:
        Time()
    except:
        print('test_Time: Assertion error')
        assert False
    else:
        assert True



# Generated at 2022-06-24 10:46:42.549558
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
	field = Field(title='name', description='Name')
	assert field.get_error_text('required') == 'This field may not be null.'
	assert field.get_error_text('invalid') == 'Value does not match expected format.'
	assert field.get_error_text('in') == "'{value}' is not in the allowed list: {choices}."
	assert field.get_error_text('not_in') == "'{value}' is not in the forbidden list: {choices}."
	assert field.get_error_text('not_blank') == "This field may not be blank."
	assert field.get_error_text('too_short') == "Ensure this field has at least {min_length} characters."

# Generated at 2022-06-24 10:46:46.112261
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    obj = field.serialize('hello')
    assert obj == 'hello'


# Generated at 2022-06-24 10:46:50.810841
# Unit test for method validate of class String
def test_String_validate():
    obj = String()
    #Case 1
    obj.min_length = 0
    obj.allow_blank = False
    obj.allow_null = True
    obj.trim_whitespace = True
    assert obj.validate("test") == "test"


# Generated at 2022-06-24 10:46:51.905706
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    assert a.validate(3) == 3


# Generated at 2022-06-24 10:46:53.068189
# Unit test for constructor of class Time
def test_Time():
    a = Time()
    assert a.field_type == "Time"



# Generated at 2022-06-24 10:46:58.128479
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.types import String
    from typesystem.exceptions import ValidationError
    from typesystem.result import ValidationResult

    class myField(Field):
        def validate(self, value, **kwargs):
            return value
    myField=myField()
    value=myField.validate_or_error("ab")
    assert isinstance(value, ValidationResult)
    assert value.value=="ab"
    assert value.error==None 


# Generated at 2022-06-24 10:47:00.916834
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    value = "yuzhou"
    assert s.validate(value) == value


# Generated at 2022-06-24 10:47:02.971396
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text("ERROR") == "ERROR"



# Generated at 2022-06-24 10:47:04.780104
# Unit test for constructor of class Time
def test_Time():
    try:
        t = Time()
        assert t.format == 'time'
    except Exception:
        assert False


# Generated at 2022-06-24 10:47:15.230357
# Unit test for constructor of class Number
def test_Number():
    int_field = Number(minimum=2, maximum=40, exclusive_minimum=10, exclusive_maximum=10)
    assert int_field.errors['type'] == "Must be a number."
    assert int_field.errors['null'] == "May not be null."
    assert int_field.errors['integer'] == "Must be an integer."
    assert int_field.errors['finite'] == "Must be finite."
    assert int_field.errors['minimum'] == "Must be greater than or equal to {minimum}."
    assert int_field.errors['exclusive_minimum'] == "Must be greater than {exclusive_minimum}."
    assert int_field.errors['maximum'] == "Must be less than or equal to {maximum}."
    assert int_field.errors['exclusive_maximum'] == "Must be less than {exclusive_maximum}."
   

# Generated at 2022-06-24 10:47:19.337723
# Unit test for constructor of class String
def test_String():
    string = String(min_length=3)
    assert string.errors["min_length"] == "Must have at least {min_length} characters."
    assert string.allow_blank == False
    assert string.trim_whitespace == True
    assert string.max_length == None
    assert string.min_length == 3

#test get_error_text

# Generated at 2022-06-24 10:47:22.887708
# Unit test for method has_default of class Field
def test_Field_has_default():
    # Create an instance of the class Field
    field = Field()
    # Test the method has_default calling is with the parameter "default"
    result = field.has_default()
    # assert the result
    assert result != True

# Generated at 2022-06-24 10:47:24.739096
# Unit test for method serialize of class String
def test_String_serialize():
    obj = "@mgfz.com"
    assert not re.findall("@", obj)



# Generated at 2022-06-24 10:47:28.137055
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Boolean, Integer, String
    field = Field()
    assert field is None
    field = Integer() | String()
    print(field)
    assert field is not None
    assert isinstance(field, Union)



# Generated at 2022-06-24 10:47:42.023575
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate('1') == True
    assert b.validate('0') == False
    assert b.validate('yes') == True
    assert b.validate('no') == False
    assert b.validate('false') == False
    assert b.validate('true') == True
    assert b.validate('False') == False
    assert b.validate('True') == True
    assert b.validate('YES') == True
    assert b.validate('NO') == False
    assert b.validate('FALSE') == False
    assert b.validate('TRUE') == True

# Generated at 2022-06-24 10:47:44.327193
# Unit test for constructor of class Any
def test_Any():
    a = Any()
    assert not a.allow_null
    a = Any(allow_null=True)
    assert a.allow_null
test_Any()


# Generated at 2022-06-24 10:47:54.503370
# Unit test for method validate of class String
def test_String_validate():
    print("\n-------------------\nValidationError: Must be a string.")
    s = String()
    try:
        result = s.validate(42)
    except ValidationError as error:
        print(error.text + " Code: " + error.code)

    print("\n-------------------\nValidationError: Must have no more than 6 characters.")
    s = String(max_length=6)
    try:
        result = s.validate('Hallo, ich bin ein String der zu lange ist')
    except ValidationError as error:
        print(error.text + " Code: " + error.code)

    print("\n-------------------\nValidationError: Must have at least 2 characters.")
    s = String(min_length=2)

# Generated at 2022-06-24 10:47:58.311478
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field()
    f.validate_or_error("test")
    f.validate_or_error(None)
    f.validate_or_error("test", strict=True)
    f.validate_or_error(None, strict=True)



# Generated at 2022-06-24 10:48:04.064785
# Unit test for method validate of class Any
def test_Any_validate():
    validator = Any()
    assert validator.validate("") == ""
    assert validator.validate(0) == 0
    assert validator.validate("a") == "a"
    assert validator.validate(1) == 1
    assert validator.validate("x") == "x"
    assert validator.validate(2) == 2
    assert validator.validate("abc") == "abc"
    assert validator.validate(3) == 3


# Generated at 2022-06-24 10:48:08.388440
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["Pesho", "Gosho"]).validate("Gosho") == "Gosho"
    assert Choice(choices=["Pesho", "Gosho"]).validate(None) is None



# Generated at 2022-06-24 10:48:14.886944
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(
        properties={
            "name": String(max_length=10, pattern='^[a-zA-Z0-9_]*$'),
            "age": Integer(minimum=1, maximum=100)
        },
        required=["name", "age"],
        additional_properties=False
    )

    # Normal case
    input_data = {
        "name": "John Doe",
        "age": 21,
    }
    output_data = schema.validate(input_data)
    assert(output_data == {"name": "John Doe", "age": 21})

    # Additional properties
    input_data = {
        "name": "John Doe",
        "age": 21,
        "is_married": True
    }

# Generated at 2022-06-24 10:48:19.090116
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean = Boolean()
    test_value = "test"
    with pytest.raises(ValidationError) as exc:
        boolean.validate(test_value)
    assert "Must be a boolean." in str(exc.value)



# Generated at 2022-06-24 10:48:22.191117
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal(minimum=1)
    b = Decimal()
    assert b.validate(1)
    assert a.validate(1) == 1
    assert a.validate(0) == 0
    assert a.validate(-1) == -1


# Generated at 2022-06-24 10:48:31.769575
# Unit test for constructor of class Text
def test_Text():
    fmt = Text()
    assert fmt.name == 'Text'
    assert fmt.description == None
    assert fmt.default == None
    assert fmt.allow_null == False
    assert fmt.validation_error == 'Field does not match expected schema.'
    assert fmt.format == 'text'
    fmt1 = Text(name = 'Te', description='Sample description', default = 'default', allow_null=True)
    assert fmt1.name == 'Te'
    assert fmt1.description == 'Sample description'
    assert fmt1.default == 'default'
    assert fmt1.allow_null == True
    assert fmt1.validation_error == 'Field does not match expected schema.'
    assert fmt1.format == 'text'
    assert_raises(AssertionError, Text, min_length=-2)

# Generated at 2022-06-24 10:48:41.002874
# Unit test for method validate of class Union
def test_Union_validate():
    for i in range(10):  # test 10 times
        x=random.randint(0,2) # randomly choose x from 0,1,2
        y=random.randint(0,2) # randomly choose y from 0,1,2
        z=random.randint(0,2) # randomly choose z from 0,1,2
        if x==1 and y==1 and z==1:
            continue
        # From the definition of Union, we immediately know that Union([Array([Number(),Number(),Number()])]) is a valid instance, so we just need to test exceptional cases.
        else:
            # if x=0 and y=0 and z=0, Union([]) will raise a validation_error("union")
            if x==0 and y==0 and z==0:
                s=Union([])