

# Generated at 2022-06-24 10:38:34.435035
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field()
    assert f.has_default() == False

# Generated at 2022-06-24 10:38:45.352176
# Unit test for method validate of class Any
def test_Any_validate():
    print("\nTesting method validate of class Any...")
    def test_case(i, expected):
        message = "    Testing method validate with input {}".format(str(i))
        result = Any().validate(i)
        print(message + " -> {}".format(str(result)))
        assert result == expected
    test_case([0,0], [0,0])
    test_case({"b": "ab", "a": "ab"}, {"b": "ab", "a": "ab"})
    test_case(1, 1)
    test_case({"a": 1, "b": 1}, {"a": 1, "b": 1})

# Generated at 2022-06-24 10:38:52.202013
# Unit test for method validate of class String
def test_String_validate():
    assert String(title="Foo").validate("bar")=="bar"
    assert String(title="Foo").validate("")==""
    assert String(allow_blank=True, title="Foo").validate('')==''
    assert String(allow_blank=True, title="Foo").validate(None)==""
    assert String(allow_blank=False, title="Foo").validate(None)==None
    assert String(allow_blank=False, title="Foo").validate('')==None
    assert String(format="date", title="Foo").validate('2019-01-01')=='2019-01-01'
    assert String(format="time", title="Foo").validate('2019-01-01')=='2019-01-01'

# Generated at 2022-06-24 10:39:03.720986
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array(foo=str,bar=int,baz=str) 
    assert arr.validate({"foo":"a", "bar":1, "baz":"b"}) == {'foo':'a','bar':1,'baz':'b'}
    assert arr.validate(["a", 1, "b"]) == {'foo':'a','bar':1,'baz':'b'}
    try:
        arr.validate("[a, 1, b]")
    except ValidationError as e:
        assert e.message("type") == "Must be an array."
    arr = Array(foo=str,bar=int,baz=str, allow_null =True)
    assert arr.validate(None) == None

# Generated at 2022-06-24 10:39:06.788690
# Unit test for method validate of class Field
def test_Field_validate():
    f=Field()
    assert f.validate(1)==1;
    assert f.validate(1,strict=True)==1;


# Generated at 2022-06-24 10:39:14.515958
# Unit test for method validate of class Union
def test_Union_validate():
    # test case 1
    u = Union(any_of = [String(format = None, 
                               length = None, 
                               minimum = None, 
                               maximum = None, 
                               allow_null = True, 
                               allow_blank = False, )])
    assert u.validate(None, strict = False) is None
    assert str(u.validate("hello", strict = False)) == "hello"
    # test case 2

# Generated at 2022-06-24 10:39:16.848229
# Unit test for constructor of class Time
def test_Time():
    time_obj = Time()
    assert time_obj.pattern == None
    assert time_obj.format == 'time'
    assert time_obj.allow_null == False
    assert time_obj.allow_empty == False
    assert time_obj.default == None



# Generated at 2022-06-24 10:39:28.295528
# Unit test for method validate of class Array
def test_Array_validate():
    # case 1
    items = [String()]
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    value = ["a", "b"]
    output = array.validate(value)
    assert output == ["a", "b"]

    # case 2
    items = [String(), Number()]
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False

# Generated at 2022-06-24 10:39:40.481802
# Unit test for method validate of class Union
def test_Union_validate():
    arr1 = [1,2,3]
    arr2 = [1,2,3,4]
    arr3 = "hello"
    arr4 = [1, 2, "hello"]
    arr5 = {"arr": [1, 2, "hello"]}
    arr6 = [1, {"nested": {"field1": 1, "field2": 2}}]
    arr7 = [1, {"nested": {"field1": 1.5, "field2": 2}}]
    arr8 = [1, {"nested": {"field1": 1, "field2": 2.5}}]
    arr9 = [1, {"nested": {"field1": "hello", "field2": 2}}]
    arr10 = [1, {"nested": {"field1": 1, "field2": "hello"}}]
    arr11

# Generated at 2022-06-24 10:39:43.018974
# Unit test for constructor of class Union
def test_Union():
    test_schema = Union([
        String(),
        Array()
    ])
    assert test_schema.allow_null is False
    assert test_schema.any_of == [
        String(),
        Array()
    ]


# Generated at 2022-06-24 10:39:54.368089
# Unit test for method validate of class Array
def test_Array_validate():
    import json
    from pydantic import BaseModel
    from pydantic import ValidationError
    from marshmallow import Schema, fields
    import jsonslicer
    from jsonslicer import JsonSlicer

    class ArraySchema(Schema):
        data = fields.List(fields.String())

    # 1
    obj1 = '["foo", "bar", "baz", "qux", "quux"]'
    jsonobj1 = json.loads(obj1)
    schema1 = ArraySchema(many=False)
    schema1.load(jsonobj1)
    try:
        JsonSlicer.validate(ArraySchema, jsonobj1)
    except ValidationError as e:
        print(e)
    B = BaseModel.schema()

# Generated at 2022-06-24 10:39:59.151723
# Unit test for constructor of class String
def test_String():
    s = String()

    assert s.validate("") is None
    assert s.validate("") == ""
    assert s.validate("a") == "a"
    assert s.validate("aa") == "aa"


# Generated at 2022-06-24 10:40:00.238241
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    import typesystem

# Generated at 2022-06-24 10:40:01.043811
# Unit test for constructor of class Any
def test_Any():
    param = 'abc'
    obj = Any()
    assert obj.validate(param) == param


# Generated at 2022-06-24 10:40:03.575318
# Unit test for constructor of class Choice
def test_Choice():
    choices = [1, 2]
    assert Choice(choices=choices).choices == [(1, 1), (2, 2)]
    # Test if choice contains 2-tuple (key, value)
    choices = [(1, "one"), (2, "two")]
    assert Choice(choices=choices).choices == choices



# Generated at 2022-06-24 10:40:08.995759
# Unit test for method has_default of class Field
def test_Field_has_default():
    test_field = Field()
    test_field_with_default = Field(default="test")
    assert test_field.has_default() is False
    assert test_field_with_default.has_default() is True



# Generated at 2022-06-24 10:40:17.664050
# Unit test for method serialize of class Array
def test_Array_serialize():
    from copy import deepcopy
    from pydantic import BaseModel
    from jsonschema import validate, ValidationError

    class Nested(BaseModel):
        nested_field: int

    class Model(BaseModel):
        nested: Nested
        list_of_nested: typing.List[Nested]
        list_of_non_nested: typing.List[int]

        class Config:
            arbitrary_types_allowed = True

    def _assert_equal_dicts(test_dict, expected_dict):
        # This function is not present in the pydantic code, but in the tests one.
        # It is basically the same.
        if isinstance(test_dict, dict):
            assert isinstance(expected_dict, dict)
            for key, value in test_dict.items():
                _assert_equal_dict

# Generated at 2022-06-24 10:40:25.070030
# Unit test for method validate of class Array
def test_Array_validate():
    # Array
    schema = Array(items=Integer)
    assert schema.validate([1, 2, 3]) == [1, 2, 3]
    assert schema.validate([1, 2, "a"]) == ValidationError

    schema = Array(items=Integer, min_items=2)
    assert schema.validate([1, 2]) == [1, 2]
    assert schema.validate([1]) == ValidationError

    schema = Array(items=Integer, max_items=2)
    assert schema.validate([1, 2]) == [1, 2]
    assert schema.validate([1, 2, 3]) == ValidationError

    schema = Array(items=Integer, additional_items=False)
    assert schema.validate([1]) == [1]
    assert schema.validate([1, 2, 3])

# Generated at 2022-06-24 10:40:27.770543
# Unit test for constructor of class Array
def test_Array():
    test = Array(items=[Integer(), Text(), Boolean()], additional_items = True)
    assert test.default_value == None
    assert test.allow_null == True
    assert test.items == [Integer(), Text(), Boolean()]
    assert test.min_items == None
    assert test.max_items == None
    


# Generated at 2022-06-24 10:40:29.119043
# Unit test for constructor of class Date
def test_Date():
    a = Date()
    assert a.format == 'date'


# Generated at 2022-06-24 10:40:35.183450
# Unit test for constructor of class DateTime
def test_DateTime():
    a = DateTime(max_length=100)
    a.set_default_value("Default")
    assert a.format == "date"
    assert a.max_length == 100



# Generated at 2022-06-24 10:40:36.042550
# Unit test for constructor of class Float
def test_Float():
    x = Float()
    assert x
    return x



# Generated at 2022-06-24 10:40:38.633287
# Unit test for constructor of class Date
def test_Date():
    from datetime import datetime
    x = Date().validate(str(datetime.now().date()))
    x = Date().serialize(datetime.now().date())


# Generated at 2022-06-24 10:40:40.263328
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_field = Decimal()
    assert decimal_field.serialize(None) == None



# Generated at 2022-06-24 10:40:49.853172
# Unit test for constructor of class Decimal
def test_Decimal():
    test1 = Decimal(
        minimum=decimal.Decimal(9.0),
        maximum=decimal.Decimal(11.0),
        exclusive_minimum=decimal.Decimal(9.0),
        exclusive_maximum=decimal.Decimal(11.0),
        multiple_of=decimal.Decimal(3.0),
        precision="1.0"
    )
    assert test1.minimum == decimal.Decimal(9.0)
    assert test1.maximum == decimal.Decimal(11.0)
    assert test1.exclusive_minimum == decimal.Decimal(9.0)
    assert test1.exclusive_maximum == decimal.Decimal(11.0)
    assert test1.multiple_of == decimal.Decimal(3.0)
    assert test1.precision == "1.0"

# Generated at 2022-06-24 10:40:51.533681
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert type(f.numeric_type) is type


# Generated at 2022-06-24 10:40:53.633382
# Unit test for constructor of class Number
def test_Number():
    test = Number(maximum=20, minimum=10)
    assert(test.maximum == 20)
    assert(test.minimum == 10)



# Generated at 2022-06-24 10:40:56.508690
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a=Boolean(allow_null=True)
    assert a.validate(None)==None


# Generated at 2022-06-24 10:40:59.983006
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate('123') == '123'
    assert Any().validate(123) == 123
    assert Any().validate([1,2,3]) == [1,2,3]
    assert Any().validate(None) == None



# Generated at 2022-06-24 10:41:01.431126
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal.numeric_type.is_integer()


# Generated at 2022-06-24 10:41:02.909197
# Unit test for constructor of class Union
def test_Union():
    field = Union([String(), Number()])
    assert (type(field) == Union)

# Generated at 2022-06-24 10:41:09.842078
# Unit test for method validate of class Union
def test_Union_validate():
    fields = [String(), Integer()]
    Union1 = Union(fields)
    Union2 = Union(fields, allow_null=True)
    print(Union1.validate('qwerty'))
    print(Union1.validate(123))
    print(Union1.validate(True))
    print(Union2.validate(None))
    print(Union2.validate(123))
    try:
        Union2('123')
    except Exception as e:
        print(e)
    #need to be fixed to get correct output

test_Union_validate()


# Generated at 2022-06-24 10:41:14.667720
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    result1 = Boolean().validate('')
    assert result1 == False
    # Check if the field is not strict
    result2 = Boolean().validate('')
    assert result2 == None
    result3 = Boolean().validate(True)
    assert result3 == True


# Generated at 2022-06-24 10:41:25.825594
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal1 = Decimal()
    decimal2 = Decimal(allow_null=True)
    decimal3 = Decimal(title="")
    decimal4 = Decimal(description="")
    decimal5 = Decimal(default=None)
    decimal6 = Decimal(allow_null=True, default=None)
    decimal7 = Decimal(minimum=100)
    decimal8 = Decimal(maximum=100)
    decimal9 = Decimal(exclusive_minimum=100)
    decimal10 = Decimal(exclusive_maximum=100)
    decimal11 = Decimal(multiple_of=100)
    decimal12 = Decimal(precision="")
    return decimal1, decimal2, decimal3, decimal4, decimal5, decimal6, decimal7, decimal8, decimal9, decimal10, decimal11, decimal12



# Generated at 2022-06-24 10:41:31.517566
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize(None) is None
    assert String().serialize(False) is False
    assert String().serialize(123.4) == "123.4"
    assert String().serialize(["a", "b", "c"]) == '["a", "b", "c"]'
    assert String().serialize({"a": "b"}) == '{"a": "b"}'
    assert String(format="date").serialize(datetime.date(2000, 1, 1)) == "2000-01-01"
    assert String(format="time").serialize(datetime.time(1, 1, 1)) == "01:01:01"
    assert String(format="datetime").serialize(datetime.datetime(2000, 1, 1)) == "2000-01-01T00:00:00"

# Generated at 2022-06-24 10:41:37.437945
# Unit test for constructor of class Array
def test_Array():
    test_length_items = 3
    test_additional_items = 1
    item = Integer(title="item", description="item description.")
    test_items = [item] * test_length_items + [test_additional_items]
    test_min_items = 3
    test_max_items = 6
    test_unique_items = True
    test_Field = Array(items=item, additional_items=test_additional_items, min_items=test_min_items,
                       max_items=test_max_items, unique_items=test_unique_items)
    assert test_Field.items == test_items
    assert test_Field.additional_items == test_additional_items
    assert test_Field.min_items == test_min_items
    assert test_Field.max_items == test_max

# Generated at 2022-06-24 10:41:38.581442
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime(format = "datetime")


# Generated at 2022-06-24 10:41:41.961426
# Unit test for constructor of class Union
def test_Union():
    any_of = [int, str]
    f = Union(any_of)
    assert f.any_of == any_of
    assert f.allow_null == False


# Generated at 2022-06-24 10:41:49.109549
# Unit test for constructor of class Array
def test_Array():
    temp_Array = Array()
    assert isinstance(temp_Array, Array)
    assert isinstance(temp_Array.errors, dict)
    assert temp_Array.errors == {'type': 'Must be an array.', 'null': 'May not be null.',
                                 'empty': 'Must not be empty.', 'exact_items': 'Must have {min_items} items.',
                                 'min_items': 'Must have at least {min_items} items.',
                                 'max_items': 'Must have no more than {max_items} items.',
                                 'additional_items': 'May not contain additional items.',
                                 'unique_items': 'Items must be unique.'}
    assert isinstance(temp_Array.items, None)
    assert isinstance(temp_Array.additional_items, bool)

# Generated at 2022-06-24 10:41:51.524655
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() == False
test_Field_has_default()

# Generated at 2022-06-24 10:41:52.125882
# Unit test for constructor of class Union
def test_Union():
    assert Union(any_of=[Text()]) is not None

# Generated at 2022-06-24 10:41:55.093085
# Unit test for constructor of class Const
def test_Const():
    f = Const(const=3)
    assert f.const == 3
    assert f.null_allowed() == True


# Generated at 2022-06-24 10:41:56.061247
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(minimum=1)



# Generated at 2022-06-24 10:42:07.398476
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Arrange
    class TestObject1:
        def __init__(self, value: int):
            self.value = value

    class TestSerializer1(Serializer):
        value = IntegerField()

        class Meta:
            target_class = TestObject1

    class TestObject2:
        def __init__(self, value: str):
            self.value = value

    class TestSerializer2(Serializer):
        value = CharField()

        class Meta:
            target_class = TestObject2

    items = Array(
        items=[TestSerializer1(), TestSerializer2()],
    )

    # Act - Assert
    assert items.serialize([TestObject1(1)]) == [{"value": 1}]

# Generated at 2022-06-24 10:42:17.359878
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import typesystem
    a = typesystem.String(max_length=None)
    b = typesystem.String(name='test', label='test', empty=False, max_length=None, allow_null=False, required=False, trim_whitespace=False, choices=None)
    c = typesystem.String(name='test', label='test', empty=False, max_length=None, allow_null=False, required=False, trim_whitespace=False, choices=None)
    d = typesystem.String(name='test', label='test', empty=False, max_length=None, allow_null=False, required=False, trim_whitespace=False, choices=None)

# Generated at 2022-06-24 10:42:22.386960
# Unit test for method serialize of class Array
def test_Array_serialize():
    test_array = Array().items(String())
    assert test_array.serialize(['123', 'abc', '你好']) == ['123', 'abc', '你好']

# Test the method serialize of class Array
test_Array_serialize()



# Generated at 2022-06-24 10:42:24.388254
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    value, error = field.validate_or_error(1, strict=True)
    assert value == 1
    assert error is None



# Generated at 2022-06-24 10:42:24.811204
# Unit test for constructor of class Object
def test_Object():
    pass


# Generated at 2022-06-24 10:42:26.416822
# Unit test for constructor of class Text
def test_Text():
    assert Text()._format == "text"

    with pytest.raises(AssertionError) as exc_info:
        Text(format="text")
    assert "Default value should be None." in str(exc_info.value)

# Generated at 2022-06-24 10:42:27.379588
# Unit test for constructor of class Any
def test_Any():
    x = Any()



# Generated at 2022-06-24 10:42:34.603429
# Unit test for method validate of class Union

# Generated at 2022-06-24 10:42:38.405829
# Unit test for method has_default of class Field
def test_Field_has_default():
    field_1 = Field(default='abc')
    assert field_1.has_default() == True
    field_2 = Field()
    assert field_2.has_default() == False


# Generated at 2022-06-24 10:42:41.708825
# Unit test for constructor of class Const
def test_Const():
    # try to initialize with only a const value
    const = Const(const = "val")
    # test if the initialized object has the const variable assigned the correct value
    assert const.const == "val"


# Generated at 2022-06-24 10:42:45.734369
# Unit test for constructor of class Time
def test_Time():
    obj1 = Time()
    assert obj1.allow_null == False
    assert obj1.default_value is None
    assert obj1.validator is None
    assert obj1.format == 'time'



# Generated at 2022-06-24 10:42:51.857621
# Unit test for method serialize of class Array
def test_Array_serialize():
    schema_a = Array(items=Array(items=Integer()), unique_items=True)
    # input obj: {'x': [1]}
    print(schema_a.serialize({'x': [1]}))  # {'x': [1]}
    schema_b = Array(items=Integer(), unique_items=True)
    print(schema_b.serialize({'x': [1]}))  # [1]



# Generated at 2022-06-24 10:43:03.075053
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    try:
        from typesystem.schemas import ValidationError, ValidationResult
    except ImportError:
        from typesystem.errors import ValidationError, ValidationResult

    class Integer(Field):
        def validate(self, value, *, strict=False):
            if self.allow_null and value is None:
                return value
            return int(value)

    field = Integer(title="test", default=lambda:1, allow_null=True)

    with pytest.raises(TypeError):
        assert field.validate_or_error(3) is None

    assert field.validate_or_error(3, strict=True) == ValidationResult(value=3, error=None)
    with pytest.raises(ValidationError):
        assert field.validate_or_error(None, strict=True)

# Generated at 2022-06-24 10:43:05.747235
# Unit test for constructor of class Date
def test_Date():
    test = Date()
    assert test.format == "date"


# Generated at 2022-06-24 10:43:10.065561
# Unit test for method serialize of class Field
def test_Field_serialize():
    # Default is serialize(self,obj: typing.Any) -> typing.Any:
        # return obj
        obj = 5
        f = Field()
        assert f.serialize(obj) == obj
        obj = "Hello"
        assert f.serialize(obj) == obj


# Generated at 2022-06-24 10:43:13.787253
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(None) == None

# Generated at 2022-06-24 10:43:16.691072
# Unit test for method validate of class Field
def test_Field_validate():

    f = Field()
    try:
        f.validate(None)
    except NotImplementedError:
        pass



# Generated at 2022-06-24 10:43:23.490332
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class TestField(Field):
        errors = {
            "required": "{title} is required",
            "invalid_type": "{title} must be {type}",
            "read_only": "{title} is read only",
            "max_length": "{title} is too long",
            "min_length": "{title} is too short",
            "max_items": "{title} has too many items",
            "min_items": "{title} has too few items",
        }

    field = TestField(title="The Title")


# Generated at 2022-06-24 10:43:28.434651
# Unit test for constructor of class Field
def test_Field():
    assert(isinstance(Field(), Field))
    assert(isinstance(Field("", ""), Field))
    assert(isinstance(Field("", "", NO_DEFAULT, False), Field))


# Generated at 2022-06-24 10:43:33.829748
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test_obj = Boolean(allow_null=True,title='',description='')
    value = True
    res = test_obj.validate(value)
    expected = True
    assert res == expected


# Generated at 2022-06-24 10:43:35.897989
# Unit test for constructor of class Float
def test_Float():
    expected_result = 1.0
    floatObject = Float(1.0)
    assert floatObject == expected_result


# Generated at 2022-06-24 10:43:38.012587
# Unit test for constructor of class Integer
def test_Integer():
    test_int = Integer()
    assert test_int.numeric_type == int


# Generated at 2022-06-24 10:43:44.930031
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    pass
    # # boolean_field = Boolean(allow_null=True)
    # # assert boolean_field.validate(True) == True
    # # assert boolean_field.validate(False) == False
    # # check null
    # # assert boolean_field.validate(None) == True
    # # check coerce values
    # # assert boolean_field.validate("true") == True
    # # assert boolean_field.validate("True") == True
    # # assert boolean_field.validate("TRUE") == True
    # # assert boolean_field.validate("false") == False
    # # assert boolean_field.validate("False") == False
    # # assert boolean_field.validate("FALSE") == False
    # # assert boolean_field.validate("1") == True
    # # assert

# Generated at 2022-06-24 10:43:50.056251
# Unit test for method validate of class Object
def test_Object_validate():
    #for required fields.
    schema = Schema({
        "name": Field(required=True)
    })
    input1 = {
        "name": "Shantanu"
    }
    output1 = schema.validate(input1)
    #print(output1)
    assert output1 == input1

    input2 = {
        "name": None
    }
    try:
        #print(schema.validate(input2))
        assert schema.validate(input2) == input2
    except ValidationError:
        pass
    except:
        assert False

    #for additional fields.
    schema = Schema({
        "name": Field(required=True),
        "age": Field()
    })

# Generated at 2022-06-24 10:43:54.219086
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    f = Field()
    f.errors = {'101': 'value {x} is invalid'}
    f.x = 2
    assert f.validation_error('101').text == 'value 2 is invalid'
    assert f.validation_error('101').code == '101'


# Generated at 2022-06-24 10:44:00.495528
# Unit test for method has_default of class Field
def test_Field_has_default():
    # create field object with default attribute
    field_with_default = Field(title='Field with default',
                               description='Field with default value',
                               default='Default Value')
    
    # create field object without default attribute
    field_without_default = Field(title='Field without default',
                                  description='Field without default value')
    
    # test on both field objects
    assert field_with_default.has_default() == True
    assert field_without_default.has_default() == False

# Generated at 2022-06-24 10:44:01.371528
# Unit test for constructor of class Text
def test_Text():
    assert Text() == String(format="text")


# Generated at 2022-06-24 10:44:07.564024
# Unit test for constructor of class Any
def test_Any():
    with pytest.raises(TypeError):
        Any(allow_null=False)



# Generated at 2022-06-24 10:44:09.255273
# Unit test for method validate of class Const
def test_Const_validate():
    assert Const(1).validate(1)

# Generated at 2022-06-24 10:44:20.281850
# Unit test for method validate of class String
def test_String_validate():
    test_title = "This field is a string"
    test_description = "please enter a string"
    test_default = "string"
    test_allow_null = True
    test_allow_blank = True
    test_trim_whitespace = True
    test_max_length = 20
    test_min_length = 2
    test_pattern = "^[A-Za-z]*$"
    test_format = "time"
    test_strict = False


# Generated at 2022-06-24 10:44:25.482070
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import typesystem
    f=typesystem.String()
    assert f.validate_or_error("abcdef")==ValidationResult(value="abcdef", error=None)
    assert f.validate_or_error(1.0)==ValidationResult(value=None, error=ValidationError(text="Value must be a string.", code="type"))


# Generated at 2022-06-24 10:44:30.632240
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    try:
        field.validate(1)
    except NotImplementedError:
        assert True
    except:
        assert False

    try:
        field.validate(1, strict=True)
    except NotImplementedError:
        assert True
    except:
        assert False



# Generated at 2022-06-24 10:44:31.330213
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.format == "date"


# Generated at 2022-06-24 10:44:33.797305
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(decimal.Decimal('1.2'))==1.2



# Generated at 2022-06-24 10:44:35.036751
# Unit test for constructor of class Text
def test_Text():
    test = Text(required=True)
    assert test.format == "text"
    assert test.required == True



# Generated at 2022-06-24 10:44:37.370197
# Unit test for method has_default of class Field
def test_Field_has_default():
    from typesystem.base import Field
    field = Field()
    assert field.has_default() == False

# Generated at 2022-06-24 10:44:40.952980
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field_obj = Field()
    code = "abc"
    field_obj.errors = {"abc": "def"}
    assert field_obj.get_error_text(code) == "def"


# Generated at 2022-06-24 10:44:42.299150
# Unit test for method validate of class Const
def test_Const_validate():
    Const(10).validate(10)



# Generated at 2022-06-24 10:44:48.510794
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Case 1: Value is null && allow_null is true
    choice1 = Choice()
    result = choice1.validate(None)
    assert result == None
    # Case 2: Value is null && allow_null is false
    choice2 = Choice(allow_null=False)
    result = choice2.validate(None)
    assert result == None
    # Case 3: Value is not null && choices is empty
    choice3 = Choice()
    result = choice3.validate("any")
    assert result == None
    # Case 4: Value is not null && choices contains value
    choice4 = Choice(choices=["any"])
    result = choice4.validate("any")
    assert result == "any"
    # Case 5: Value is not null && choices do not contains value

# Generated at 2022-06-24 10:44:52.991946
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(title="", description="", default=NO_DEFAULT, allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, precision=None, multiple_of=None) !=None


# Generated at 2022-06-24 10:45:00.981653
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    from typesystem import Boolean, String
    class MyField(Field):
        def validate(self, value, *, strict=False):
            if value is None:
                return value
            if isinstance(value, (float, int)):
                return int(value)
            if isinstance(value, str):
                return value
        def has_default(self):
            return True
        pass
    # Test case 1
    # Testing the value of the attributes
    myfield = MyField(title="myfield", description="myfield", default=3)
    assert myfield.title == "myfield"
    assert myfield.description == "myfield"
    assert myfield.validate(3) == 3
    assert myfield.validate(3.0) == 3
    assert myfield.validate("3") == "3"
   

# Generated at 2022-06-24 10:45:07.123669
# Unit test for constructor of class String

# Generated at 2022-06-24 10:45:17.327924
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([String(), Integer()])
    t1 = u.validate("hello")
    assert t1 == "hello"
    t2 = u.validate(2)
    assert t2 == 2
    t3 = u.validate(["hello"])
    assert t3[0] == "hello"
    t4 = u.validate({"hello": 2})
    assert t4["hello"] == 2
    t5 = u.validate([1])
    assert t5[0] == 1
    t6 = u.validate(True)
    assert t6 is True
    try:
        u.validate(["hello", 1])
    except:
        t7 = True
    assert t7 is True



# Generated at 2022-06-24 10:45:19.057279
# Unit test for constructor of class Decimal
def test_Decimal():
    assert isinstance(Decimal(minimum=0), Decimal)
    assert isinstance(Decimal(maximum=100), Decimal)

# Generated at 2022-06-24 10:45:22.823110
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class StringField(Field):
        def validate(self, value, *, strict):
            return str(value)

    field = StringField()
    assert field.validate_or_error('ok') == ValidationResult(value="ok", error=None)


# Generated at 2022-06-24 10:45:25.101432
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    try:
        s.validate(1)
    except Exception as e:
        assert type(e) == ValidationError


# Generated at 2022-06-24 10:45:27.893386
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="title", description="description")
    assert field.title == "title"
    assert field.description == "description"



# Generated at 2022-06-24 10:45:29.265545
# Unit test for constructor of class DateTime
def test_DateTime():
    # In this case, the format is datetime
    cls = DateTime()
    actual = cls.format
    expected = "datetime"
    assert actual == expected



# Generated at 2022-06-24 10:45:37.910228
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array().serialize([1,2,3]) == [1,2,3]
    assert Array(items=Number().serialize(1)).serialize([1,2,3]) == [1,1,1]
    assert Array(items=[Number().serialize(1), Number().serialize(2)]).serialize([1,2,3]) == [1,2,1]
    assert Array(items=String()).serialize([1,2,3]) == ['1','2','3']
    assert Array(items=String().serialize('aa')).serialize([1,2,3]) == ['aa','aa','aa']


# Generated at 2022-06-24 10:45:39.637797
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String
    # Union.__init__
    assert String().__or__(String()) == String() | String()

# Generated at 2022-06-24 10:45:43.734347
# Unit test for constructor of class Array
def test_Array():
    a = Array(min_items=1, max_items=5)
    assert (a.min_items == 1)
    assert (a.max_items == 5)
    assert (a.unique_items == False)
    assert (a.additional_items == False)



# Generated at 2022-06-24 10:45:47.729375
# Unit test for constructor of class Date
def test_Date():
    try:
        d1 = Date(format="date-time")
    except ValueError:
        print("The format is not allowed to be 'date-time'.")
    else:
        print("The format is allowed to be 'date-time'.")

    d2 = Date(format="date")
    print("The format is allowed to be 'date'.")


# Generated at 2022-06-24 10:45:49.534437
# Unit test for constructor of class Const
def test_Const():
    f = Const(const=5)
    assert f.const == 5
    assert f.allow_null == False


# Generated at 2022-06-24 10:45:52.088683
# Unit test for constructor of class Field
def test_Field():
    a = Field(title = "Field1", description = "Field1", default = 1, allow_null = False)
    assert a.title == "Field1"
    assert a.description == "Field1"
    assert a.allow_null == False
    assert a.default == 1
    

# Generated at 2022-06-24 10:45:52.974402
# Unit test for constructor of class Const
def test_Const():
    myField = Const(True)
    assert myField.const




# Generated at 2022-06-24 10:46:00.591491
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    _field = Field()
    assert _field.get_default_value() is None

    _field = Field(title='title', description='description', default='default')
    assert _field.get_default_value() == 'default'

    _field = Field(title='title', description='description', default=lambda: 'default')
    assert _field.get_default_value() == 'default'

    _field = Field(title='title', description='description', default=NO_DEFAULT)
    assert _field.get_default_value() is NO_DEFAULT

    _field = Field(title='title', description='description', default=NO_DEFAULT)
    assert _field.get_default_value() is NO_DEFAULT

    _field = Field(title='title', description='description', allow_null=True, default=NO_DEFAULT)

# Generated at 2022-06-24 10:46:01.442249
# Unit test for constructor of class DateTime
def test_DateTime():
    schema = DateTime(required=False)
    assert schema.format == "datetime"

# Generated at 2022-06-24 10:46:06.306276
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        "name": String(length=255, required=True),
        "age": Integer(minimum=0, maximum=150),
        "gender": String(
            length=1, required=True, choices=[("M", "Male"), ("F", "Female")]
        ),
    }
    obj = Object(properties=properties, additional_properties=False)
    assert obj.validate({"name": "Hoang", "age": 20, "gender": "M"}) == {
        'age': 20,
        'gender': 'M',
        'name': 'Hoang',
    }



# Generated at 2022-06-24 10:46:17.913834
# Unit test for constructor of class Number
def test_Number():
    number = Number(minimum=4, maximum=10)
    # check for errors
    assert number.errors == {
        "type": "Must be a number.",
        "null": "May not be null.",
        "integer": "Must be an integer.",
        "finite": "Must be finite.",
        "minimum": "Must be greater than or equal to {minimum}.",
        "exclusive_minimum": "Must be greater than {exclusive_minimum}.",
        "maximum": "Must be less than or equal to {maximum}.",
        "exclusive_maximum": "Must be less than {exclusive_maximum}.",
        "multiple_of": "Must be a multiple of {multiple_of}.",
    }
    # check for attributes
    assert number.minimum == 4
    assert number.maximum == 10
    assert number.exclusive_minimum == None
    assert number

# Generated at 2022-06-24 10:46:24.337868
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(allow_null=True, choices=[('A', 'B'), ('C', 'D')])
    assert choice.validate('A') == 'A'
    assert choice.validate('C') == 'C'
    assert choice.validate('') == None
    with pytest.raises(ValidationError):
        choice.validate('')
    assert choice.validate(None) == None



# Generated at 2022-06-24 10:46:25.966562
# Unit test for constructor of class Const
def test_Const():
    assert Const(2).get_default_value() == 2


# Generated at 2022-06-24 10:46:28.131844
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    assert f.validate('a') == 'a'

# Generated at 2022-06-24 10:46:29.913435
# Unit test for method validate of class Number
def test_Number_validate():
    num = 999
    assert number.validate(num) == num



# Generated at 2022-06-24 10:46:35.292275
# Unit test for method validate of class Array
def test_Array_validate():
    array_object = Array(items=["a", "b", "c"], min_items=0, max_items=3, default=[])
    # array_object = Array(items=["a", "b", "c"], min_items=2, max_items=3, default=[])
    # array_object = Array(items=["a", "b", "c"], min_items=2, max_items=3, unique_items=True, default=[])
    # array_object = Array(items=["a", "b", "c"], min_items=2, max_items=3, unique_items=True, default=[1])
    # array_object = Array(items=["a", "b", "c"], min_items=0, max_items=3, unique_items=True, default=[1])
    # array_object

# Generated at 2022-06-24 10:46:37.798776
# Unit test for method serialize of class Field
def test_Field_serialize():
    name = String()
    name.serialize('Hello')



# Generated at 2022-06-24 10:46:44.700225
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(maximum=99).validate(88, strict=True) == 88
    assert Number(minimum=50).validate(99, strict=True) == 99
    assert Number(multiple_of=2).validate(88, strict=True) == 88
    assert Number(exclusive_maximum=19).validate(20, strict=True) == 20
    assert Number(exclusive_minimum=30).validate(20, strict=True) == 20
    assert Number(precision=2).validate(18.28, strict=True) == 18.28



# Generated at 2022-06-24 10:46:47.503421
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime().format == "datetime"


# Generated at 2022-06-24 10:46:57.627959
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    """
    This function is meant to test the method validate_or_error of the class Field
    """
    #Test with a field
    field=Field(default='spam',title='Eggs')
    try:
        field.validate_or_error(1)
    except ValidationError as error:
        assert error.text=='"Eggs" field may not be set.'
    except:
        raise AssertionError("Test with a field fails")

    #Test with a field and a strict=True
    try:
        field.validate_or_error(1, strict=True)
    except ValidationError as error:
        assert error.text=='"Eggs" field may not be set.'
    except:
        raise AssertionError("Test with a field and a strict=True fails")


# Unit

# Generated at 2022-06-24 10:47:00.167882
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    try:
        f.get_default_value()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 10:47:03.632043
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class TestField(Field):
        errors = {
            "invalid": "This is an error message"
        }
    field = TestField()
    assert field.get_error_text("invalid") == "This is an error message"

# Generated at 2022-06-24 10:47:04.583370
# Unit test for constructor of class Boolean
def test_Boolean():
    Boolean(allow_null=True)


# Generated at 2022-06-24 10:47:05.856702
# Unit test for constructor of class Number
def test_Number():
    assert Number.__doc__ is not None


# Generated at 2022-06-24 10:47:10.269095
# Unit test for method __or__ of class Field
def test_Field___or__():
  from typesystem import fields
  from pytest import raises
  from typesystem.fields import AnyOf, Union

  @fields.any_of(fields.Float())
  class MyField(Field):
    pass

  assert isinstance(MyField() | MyField(), AnyOf)
  assert isinstance(MyField() | MyField() | MyField(), Union)



# Generated at 2022-06-24 10:47:20.103135
# Unit test for constructor of class Decimal

# Generated at 2022-06-24 10:47:24.545702
# Unit test for constructor of class Decimal
def test_Decimal():
    dec = Decimal()
    assert dec.numeric_type == decimal.Decimal
    assert dec.minimum is None
    assert dec.maximum is None
    assert dec.exclusive_minimum is None
    assert dec.exclusive_maximum is None
    assert dec.multiple_of is None
    assert dec.precision is None



# Generated at 2022-06-24 10:47:30.683015
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Arrange
    class BooleanTest(Boolean):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)

    obj = BooleanTest(title = "", description = "", default = NO_DEFAULT, allow_null = False)

    # Act
    try:
        result = obj.validate(None, strict = False)
    except Exception as ex:
        result = ex

    # Assert
    assert isinstance(result, ValidationError)

# Generated at 2022-06-24 10:47:36.816336
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean(title="test", description="test description", default=True, allow_null=True)
    assert b.title == "test"
    assert b.description == "test description"
    assert b.default == True
    assert b.allow_null == True

# Testing for Integer class

# Generated at 2022-06-24 10:47:43.035076
# Unit test for constructor of class Choice
def test_Choice():
    choices = [45]
    choice = Choice(choices=choices)
    assert choice.choices == [(45, 45)]

    choices = [45, (-8, 'negative eight')]
    choice = Choice(choices=choices)
    assert choice.choices == [(45, 45), (-8, 'negative eight')]

    choices = [45, (8, 'eight'), 'nine']
    choice = Choice(choices=choices)
    assert choice.choices == [(45, 45), (8, 'eight'), ('nine', 'nine')]
    

# Generated at 2022-06-24 10:47:48.939255
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const(const=1)
    assert field.validate(1) == 1
    try:
        field.validate(2)
    except ValidationError as err:
        assert err.messages == [Message(code='const', text="Must be the value '{const}'.", key='', field='', index=['const'], const=1)]
    try:
        field = Const(const=None)
        field.validate(1)
    except ValidationError as err:
        assert err.messages == [Message(code='only_null', text="Must be null.", key='', field='', index=[])]

# Generated at 2022-06-24 10:47:57.982733
# Unit test for constructor of class Union
def test_Union():
    title = String(title="Title")
    title_with_default = String(title="Title",default='Ugly Title')
    author = String(title="Author")
    upc = String(title="Upc",format="upc")
    union_field = Union([title,author],nullable=False)
    union_field_with_default = Union([title,author],default=title_with_default)
    assert union_field.validate(None) == None
    assert union_field_with_default.validate(None) == title_with_default.validate(None)
    assert union_field.validate('') == ''
    assert union_field.validate('Matias') == 'Matias'


# Generated at 2022-06-24 10:48:06.088571
# Unit test for method validate of class String
def test_String_validate():
	strf = String(allow_blank=False, allow_null=True, title='', description='', default=None, trim_whitespace=True, min_length=5, max_length=10, pattern=r'\w+\-*\w*', format=None)
	assert strf.validate(None) == None
	assert strf.validate("  ") == ""
	assert strf.validate("fdfa ") == "fdfa"
	assert strf.validate("Fdfa") == "Fdfa"
	assert strf.validate("123") == "123"
	assert strf.validate("1234567890") == "1234567890"
	assert strf.validate("12345678901") == None

# Generated at 2022-06-24 10:48:07.765631
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert str(Field() | Field()) == "Union(Field(), Field())"


# Generated at 2022-06-24 10:48:12.363317
# Unit test for constructor of class Field
def test_Field():
    f = Field(title="foo", description="bar", default="baz", allow_null=True)
    assert isinstance(f, Field)
    assert f.title == "foo"
    assert f.description == "bar"
    assert f.default == "baz"
    assert f.allow_null == True


# Generated at 2022-06-24 10:48:20.041127
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    
    # Case A: Raise error
    try:
        field = Field()
        field.validate(value = 123)
    except Exception as e:
        assert "NotImplementedError" in str(e)
    
    # Case B: correct
    field = Field()
    field.has_default = lambda: True
    assert field.validate_or_error(value = 123) == ValidationResult(value=None, code=None)

# Generated at 2022-06-24 10:48:21.580009
# Unit test for constructor of class Union
def test_Union():
    any_of = [Type(), Type()]
    assert(Union(any_of) != None)


# Generated at 2022-06-24 10:48:30.078806
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class NameField(Field):
        errors = {
            "invalid": "Name field has invalid value."
        }

        def validate(self, value, **kwargs):
            if len(value) < 3:
                raise ValidationError(self.get_error_text("invalid"))
            return value

    name = NameField()
    result = name.validate_or_error("Bill")
    assert result.is_valid()
    assert result.value == "Bill"

    result = name.validate_or_error("Bi")
    assert not result.is_valid()
    assert result.error.code == "invalid"
    assert result.error.text == "Name field has invalid value."


# Generated at 2022-06-24 10:48:32.724072
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    assert choice.validate("-value-")=="-value-"
    assert choice.validate(None) is None
    assert choice.validate("") is None



# Generated at 2022-06-24 10:48:33.661966
# Unit test for constructor of class String
def test_String():
    obj = String()

