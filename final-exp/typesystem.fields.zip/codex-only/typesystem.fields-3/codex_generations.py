

# Generated at 2022-06-24 10:38:36.213535
# Unit test for constructor of class Boolean
def test_Boolean():
    x = Boolean()
    assert x.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert x.coerce_values == {"true": True, "false": False, "on": True, "off": False, "1": True, "0": False, "": False, 1: True, 0: False}
    assert x.coerce_null_values == {"", "null", "none"}

# Generated at 2022-06-24 10:38:42.466820
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    bool_true = Boolean(title = "TrueOrFalse", description = "True or false")
    assert bool_true.validate(True) == True
    assert bool_true.validate(False) == False
    assert bool_true.validate(1) == True
    assert bool_true.validate(0) == False
    assert bool_true.validate(None) == None

    bool_false = Boolean(title = "TrueOrFalse", description = "True or false", allow_null = False)
    assert bool_false.validate(True) == True
    assert bool_false.validate(False) == False
    assert bool_false.validate(1) == True
    assert bool_false.validate(0) == False

# Generated at 2022-06-24 10:38:43.801024
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(None) == None
    assert Decimal().serialize(Decimal(1.0)) == 1.0


# Generated at 2022-06-24 10:38:51.033890
# Unit test for method validate of class Union
def test_Union_validate():
    field1 = String(pattern=r'^[a-zA-Z]{3,6}$') # pattern for regular expression
    field2 = Number(multiple_of=2)
    union_field = Union([field1, field2])
    value = 'abc'
    print(union_field.validate(value))
    print(union_field.validate(5))
    print(union_field.validate(1))
    print(union_field.validate('abcdef'))
    print(union_field.validate(None))

test_Union_validate()

#---------------------------------------------------------------------
# Validate the schema
#---------------------------------------------------------------------

# Generated at 2022-06-24 10:38:56.722331
# Unit test for method serialize of class String
def test_String_serialize():
    from datetime import date, datetime
    from typesystem.unique import Uniqueness
    from typesystem import formats
    from typesystem.fields import Field, List, Dict, Tuple, Date, DateTime, Time
    from typesystem import types

    class MyObject(FormattedString):
        def __init__(self,*args,**kwargs):
            super(MyObject,self).__init__(format="uuid", *args,**kwargs)

    # Testcase1:
    # Test that serialize method of String class returns the correct
    # values for various inputs
    field = MyObject()
    value = ""
    serialized = field.serialize(value)
    assert value == serialized

    value = "2020-02-02"
    serialized = field.serialize(value)
    assert value == serialized

   

# Generated at 2022-06-24 10:39:00.095403
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field(title='', description='', default=NO_DEFAULT, allow_null=False)
    result = field.validation_error(code='')
    assert result is not None

# Generated at 2022-06-24 10:39:01.624714
# Unit test for constructor of class Decimal
def test_Decimal():
    result = Decimal(1,"1")
    assert result is not None



# Generated at 2022-06-24 10:39:07.816074
# Unit test for constructor of class Time
def test_Time():
    class TestSchema(Schema):
        field = Time(allow_blank=True)

    with pytest.raises(TypeError) as excinfo:
        TestSchema({"field": "03:32:00"})
    assert "unexpected keyword argument" in str(excinfo.value)



# Generated at 2022-06-24 10:39:10.903697
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal()
    assert(isinstance(d.validate("12.43"), float))
    assert(isinstance(d.validate("12.43"), float))
    assert(d.validate("12.43") == float(12.43))



# Generated at 2022-06-24 10:39:15.683330
# Unit test for method serialize of class String
def test_String_serialize():
    class TestString(String):
        pass
    test_field = TestString()
    assert test_field.serialize("12:30") == "12:30"


# Generated at 2022-06-24 10:39:18.403427
# Unit test for constructor of class Choice
def test_Choice():
    # Test object intantiation of class Choice
    choice_test = Choice()
    assert choice_test.errors['null'] == 'May not be null.'
    assert choice_test.errors['required'] == 'This field is required.'
    assert choice_test.errors['choice'] == 'Not a valid choice.'
    assert choice_test.choices == []
    assert choice_test.allow_null == False
    assert choice_test.coerce is None
    assert choice_test.default == None


# Generated at 2022-06-24 10:39:25.819943
# Unit test for method validate of class Const
def test_Const_validate():
    with pytest.raises(ValidationError) as error:
        field = Const(const='test',allow_null=False)
        assert field.validate('test') == 'test'
        assert field.validate(1) != 1
        assert field.validate(None,strict=False) == None
        assert field.validate(None,strict=True) == None

    with pytest.raises(ValidationError) as error:
        field = Const(const=None,allow_null=True)
        assert field.validate('test') != 'test'
        assert field.validate(1) != 1
        assert field.validate(None,strict=False) == None
        assert field.validate(None,strict=True) == None


# Generated at 2022-06-24 10:39:37.153970
# Unit test for constructor of class Number
def test_Number():
    print ("\ntesting class Number constructor")
    a = Number()

    if (
        (a.minimum is None)
        and (a.maximum is None)
        and (a.exclusive_minimum is None)
        and (a.exclusive_maximum is None)
        and (a.multiple_of is None)
        and (a.precision is None)
    ):
        print ("passed")
    else:
        print ("failed")

    print ("\ntesting class Number constructor")
    a = Number(minimum = 1,
                maximum = 10,
                exclusive_minimum = 2,
                exclusive_maximum = 9,
                multiple_of = 2,
                precision = '0.001')


# Generated at 2022-06-24 10:39:45.061493
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # This method is supposed to be implemented in the concretes
    # For example, this is the implementation of validate_or_error in class String
    # def validate_or_error(self, value, strict=False):
    #     try:
    #         value = self.validate(value, strict=strict)
    #     except ValidationError as error:
    #         return ValidationResult(value=None, error=error)
    #     return ValidationResult(value=value, error=None)
    #  So, I used an instantiation of class String to do this test
    s = String()
    test_value = 'a'
    assert s.validate_or_error(test_value) == ValidationResult(value = 'a', error = None)
    # invalid test_value
    test_value = 'abc'

# Generated at 2022-06-24 10:39:55.258655
# Unit test for method validate of class Union
def test_Union_validate():
    print("----- test_Union_validate -----")

    class type_error(Schema):
        error = Error(None, "test_type_error")

    class type_error_index(Schema):
        error = Error(None, "test_type_index")

    try:
        Union(
            [
                type_error([Message(text="test_type_error_1", code="test_type_error")]),
                type_error([Message(text="test_type_error_2", code="test_type_error")]),
                type_error_index(
                    [Message(text="test_type_index", code="test_type_index", index=["index"])]
                ),
            ]
        ).validate(None)
    except ValidationError as error:
        print(error.messages())


test

# Generated at 2022-06-24 10:39:59.238919
# Unit test for method has_default of class Field
def test_Field_has_default():
    field1 = Field()
    field2 = Field(default=2)
    assert field1.has_default() == False
    assert field2.has_default() == True


# Generated at 2022-06-24 10:40:03.472033
# Unit test for method __or__ of class Field
def test_Field___or__():
  field_1 = Field(
      title="test",
      description="test",
      default=NO_DEFAULT,
      allow_null=False
  )
  field_2 = Field(
      title="test",
      description="test",
      default=NO_DEFAULT,
      allow_null=False
  )
  union_field = field_1 | field_2
  assert union_field.__class__.__name__ == "Union"
  assert union_field.any_of[0] == field_1
  assert union_field.any_of[1] == field_2



# Generated at 2022-06-24 10:40:08.711545
# Unit test for constructor of class Number
def test_Number():
    num = Number(title='population',
                 description='the number of people in a country',
                 )
    assert num.title == 'population'
    assert num.description == 'the number of people in a country'



# Generated at 2022-06-24 10:40:10.052778
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    assert Field().validation_error("code") == None


# Generated at 2022-06-24 10:40:13.870569
# Unit test for constructor of class Number
def test_Number():
    ns = Number()
    ns = Number(minimum=0)
    ns = Number(maximum=1)
    ns = Number(exclusive_minimum=0)
    ns = Number(exclusive_maximum=1)
    ns = Number(multiple_of=1)
    ns = Number(precision='2')



# Generated at 2022-06-24 10:40:19.417973
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1=Field(title="field1",description="description about field1",default=None,allow_null=False)
    field2=Field(title="field2",description="description about field2",default=None,allow_null=False)
    field3=field1|field2
    assert field3.any_of[0]==field1
    assert field3.any_of[1]==field2
    field4=field3|field3
    assert field4.any_of[0]==field3.any_of[0]
    assert field4.any_of[1]==field3.any_of[1]


# Generated at 2022-06-24 10:40:20.587873
# Unit test for constructor of class Date
def test_Date():
    try:
        d = Date()
        assert d.format == "date"
    except AssertionError:
        print(d.format)


# Generated at 2022-06-24 10:40:25.236400
# Unit test for constructor of class Object
def test_Object():
    required = ['name', 'age']
    properties = {'name':String(required=True),
                  'age':Integer(required=True),
                  'email':String(required=False)}
    additional_properties = Boolean(required=False)
    obj = Object(properties=properties, additional_properties=additional_properties, required=required)
    assert obj is not None
    assert obj.properties is not None
    assert obj.additional_properties is not None
    assert obj.required is not None


# Generated at 2022-06-24 10:40:29.460330
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    errors = {
        "invalid": "Invalid value."
    }
    field = Field()
    field.errors = errors
    assert field.get_error_text("invalid") == "Invalid value."
    # Test for case if code is not found in error_message
    assert field.get_error_text("invalid1") == ""



# Generated at 2022-06-24 10:40:38.810071
# Unit test for constructor of class Any
def test_Any():
    a = Any()
    assert a.validate("hello")
    assert a.validate(True)
    assert a.validate(1)
    assert a.validate(["hello", "world"])
    assert a.validate({'hi': 'there'})

if __name__ == "__main__":
    test_Any()
    test_Bool_validate_or_error()
    test_Bool_error_texts()
    test_Bool_validate()

# Generated at 2022-06-24 10:40:41.332052
# Unit test for constructor of class Array
def test_Array():
    min_items = 1
    max_items = 2
    assert isinstance(min_items, int)
    assert isinstance(max_items, int)



# Generated at 2022-06-24 10:40:49.945676
# Unit test for method __or__ of class Field
def test_Field___or__():
    examples = [
        ("hej", "hej"),
        (["hej", "hej"], ["hej", "hej"]),
        (["hej", "hej"], ["hej", "hej"]),
    ]
    for example in examples:
        assert example[0] == example[1]


    class MyField(Field):
        def validate(self, value: str) -> str:
            return value

    a = MyField()
    b = MyField()

    def test_Field___or__():
        examples = [
            ([a, b], [a, b]),
            ([a, b], [a, b]),
            ([a], [a]),
        ]
        for example in examples:
            assert example[0] == example[1]




# Generated at 2022-06-24 10:40:54.609226
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    import operator
    from decimal import Decimal

    obj = Decimal(5.0)
    float_obj = float(obj)
    float_obj2 = 5.0
    if operator.eq(float_obj, float_obj2) == False:
        raise AssertionError("Failed test of Decimal.serialize")




# Generated at 2022-06-24 10:40:56.347021
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(123) == float(123)



# Generated at 2022-06-24 10:41:01.233416
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(title="String", description="A string.", allow_blank=False, trim_whitespace=False, max_length=10, min_length=5, pattern='[^,]+', format='date')
    assert string.serialize("") == ""
    assert string.serialize("null character\0") == "null character"


# Generated at 2022-06-24 10:41:10.502678
# Unit test for method validate of class String
def test_String_validate():
    from typesystem.base import Field
    from typesystem import formats
    
    FORMATS = {
        "date": formats.DateFormat(),
        "time": formats.TimeFormat(),
        "datetime": formats.DateTimeFormat(),
        "uuid": formats.UUIDFormat(),
    }
    
    Field._creation_counter=0
    assert callable(String)
    myname = String(title="My Name", max_length=10)
    assert isinstance(myname, Field)
    assert myname.validate("test") == "test"
    assert myname.validate("testtesttesttest") == "testtesttesttest"
    try:
        myname.validate("testtesttesttesttest")
        assert False, "should throw and error here"
    except:
        pass
    assert myname.validate

# Generated at 2022-06-24 10:41:17.902296
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate('') == False
    assert field.validate(0) == False
    assert field.validate(1) == True
    assert field.validate('true') == True
    assert field.validate('false') == False
    assert field.validate('on') == True
    assert field.validate('off') == False
    assert field.validate([]) == None


# Generated at 2022-06-24 10:41:18.916533
# Unit test for constructor of class Text
def test_Text():
    assert str(Text()) == "Text"


# Generated at 2022-06-24 10:41:19.465958
# Unit test for constructor of class Time
def test_Time():
    Time()


# Generated at 2022-06-24 10:41:29.135565
# Unit test for method validate of class Choice

# Generated at 2022-06-24 10:41:32.447281
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field()
    v = f.validate_or_error(1)
    print(v.value)
    print(v.error)
test_Field_validate_or_error()
print('-'*10)


# Generated at 2022-06-24 10:41:44.073072
# Unit test for constructor of class Any
def test_Any():
    assert isinstance(Any(), Any)
    assert isinstance(Any(allow_null=True), Any)
    assert isinstance(Any(default=True), Any)
    assert isinstance(Any(title="test"), Any)
    assert isinstance(Any(description="test"), Any)
    assert isinstance(Any(title="test", description="test"), Any)
    assert isinstance(Any(read_only=True), Any)
    assert isinstance(Any(write_only=True), Any)
    assert isinstance(Any(read_only=True, write_only=True), Any)
    assert isinstance(Any(enum=[]), Any)
    assert isinstance(Any(const="test"), Any)

# Generated at 2022-06-24 10:41:45.817345
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_one = Decimal()
    assert decimal_one.numeric_type == decimal.Decimal


# Generated at 2022-06-24 10:41:52.643699
# Unit test for method validate of class Array
def test_Array_validate():
    from copy import deepcopy
    field = Array(items=String())
    assert field.validate(["a", "b"])==["a", "b"]
    assert field.validate(["a", "b", "c", "d"]) ==["a", "b", "c", "d"]
    field.unique_items=True
    assert field.validate(["a", "b"])==["a", "b"]
    assert field.validate(["a", "b", "c", "d"]) ==["a", "b", "c", "d"]
    field.min_items=3
    assert field.validate(["a", "b"])==["a", "b"]

# Generated at 2022-06-24 10:41:53.747979
# Unit test for constructor of class String
def test_String():
    assert isinstance(String(), String)


# Generated at 2022-06-24 10:42:02.310110
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(
        properties={
            "a": String(max_length=10),
            "b": Boolean(),
            "c": Decimal(minimum=5),
            "d": String(enum=["good", "bad", "ugly"]),
        },
        min_properties=2,
        max_properties=3,
        required=["c", "d"],
    )

    value, error = schema.validate_or_error(
        {
            "a": "no longer than 10 characters",
            "b": True,
            "c": 5,
            "d": "good",
        }
    )
    assert error is None

# Generated at 2022-06-24 10:42:04.508576
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    # Test type of the field
    f = Field(title = "test")
    assert isinstance(f, Field)

    # Test value of the field
    assert f.validation_error(code="test")



# Generated at 2022-06-24 10:42:10.402596
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    from typesystem.types import Integer, String
    
    int_field = Integer()
    str_field = String()
    int_field_with_default = Integer(default=1)
    str_field_with_default = String(default='s')
    
    if int_field.has_default():
        assert int_field.get_default_value() == None
    else:
        assert False
        
    if str_field.has_default():
        assert str_field.get_default_value() == None
    else:
        assert False
        
    if int_field_with_default.has_default():
        assert int_field_with_default.get_default_value() == 1
    else:
        assert False
        
    if str_field_with_default.has_default():
        assert str_field

# Generated at 2022-06-24 10:42:12.188565
# Unit test for method validate of class Number
def test_Number_validate():
    s = Number()
    result = s.validate(4.4)
    assert result == 4.4



# Generated at 2022-06-24 10:42:14.146555
# Unit test for method validate of class String
def test_String_validate():
    string = String(allow_null=True)
    assert string.validate(1) == '1'



# Generated at 2022-06-24 10:42:18.061251
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field = Decimal(
            title='',
            default=NO_DEFAULT,
            allow_null=False)
    value = field.serialize(3.3)
    assert value == 3.3
    value = field.serialize(None)
    assert value is None
    value = field.serialize(decimal.Decimal(3.3))
    assert value == 3.3


# Generated at 2022-06-24 10:42:20.562826
# Unit test for constructor of class Union
def test_Union():
    # Unit test for constructor of class Union
    u = Union([Field()])

__version__ = "18.8.0"

# Generated at 2022-06-24 10:42:30.198561
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    class Boolean_test(unittest.TestCase):
         print("Unit test for method validate of class Boolean")      
         def test_case1(self):
            # Create an instance of class Boolean
            a = Boolean()
            self.assertTrue(a.validate(True) == True)
            # Create an instance of class Boolean
            b = Boolean()
            self.assertTrue(b.validate(False) == False)
            # Create an instance of class Boolean
            c = Boolean()
            self.assertTrue(c.validate(None) == None)
            # Create an instance of class Boolean
            d = Boolean()
            self.assertTrue(d.validate(1) == True)
            # Create an instance of class Boolean
            e = Boolean()
            self.assertTrue(e.validate(0) == False)
           

# Generated at 2022-06-24 10:42:31.694047
# Unit test for method serialize of class Field
def test_Field_serialize():
    from typesystem.fields import Integer

    field = Integer()
    value = 1
    assert field.serialize(value) == value

# Generated at 2022-06-24 10:42:33.492810
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(1) == 1.0
    assert Decimal().serialize(0.2) == 0.2
    assert Decimal().serialize(None) == None


# Generated at 2022-06-24 10:42:34.654985
# Unit test for method validate of class Object
def test_Object_validate():
    pass # test is passed



# Generated at 2022-06-24 10:42:46.769381
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None

    field = Field(default=0)
    assert field.get_default_value() == 0

    field = Field(default=2)
    assert field.get_default_value() == 2

    field = Field(default=2.3)
    assert field.get_default_value() == 2.3

    field = Field(default="hello")
    assert field.get_default_value() == "hello"

    field = Field(default=[1, 2, 3])
    assert field.get_default_value() == [1, 2, 3]

    field = Field(default={"a": 1, "b": 2})
    assert field.get_default_value() == {"a": 1, "b": 2}



# Generated at 2022-06-24 10:42:47.739140
# Unit test for constructor of class Object
def test_Object():
    assert Object

    a = Object(properties={'n': String()})
    assert a


# Generated at 2022-06-24 10:42:49.818773
# Unit test for method validate of class Field
def test_Field_validate():
    x = Field()
    x.validate("12", strict=True)


# Generated at 2022-06-24 10:42:51.063694
# Unit test for method validate of class Any
def test_Any_validate():
    test_obj = Any()
    test_obj.validate(None)
    test_obj.validate('hello')
    test_obj.validate({})


# Generated at 2022-06-24 10:43:02.951134
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Boolean(allow_null=False)
    b=Boolean(allow_null=False)
    assert b.validate(True)==True
    assert b.validate(False)==False
    assert b.validate(1)==True
    assert b.validate(0)==False
    assert b.validate("1")==True
    assert b.validate("0")==False
    assert b.validate("true")==True
    assert b.validate("false")==False
    assert b.validate("on")==True
    assert b.validate("off")==False
    assert b.validate("")==False
    assert b.validate("none")==False
    assert b.validate("null")==False
    # Boolean(allow_null=True)

# Generated at 2022-06-24 10:43:08.870822
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(
        choices = [(1, "a"), (2, "b"), (3, "c")]
    )
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(2).value == 2
    assert field.validate_or_error(3).value == 3


# Generated at 2022-06-24 10:43:22.208026
# Unit test for method serialize of class String
def test_String_serialize():
    string_field = String(allow_null=True, allow_blank=True)
    assert string_field.serialize(None) is None
    assert string_field.serialize('') == ''
    assert string_field.serialize('test_string') == 'test_string'

    date_field = String(format='date')
    date = date_field.serialize('2019-09-05')
    assert isinstance(date, datetime.date)
    assert date.year == 2019
    assert date.month == 9
    assert date.day == 5

    time_field = String(format='time')
    time = time_field.serialize('13:14:15')
    assert isinstance(time, datetime.time)
    assert time.hour == 13
    assert time.minute == 14
    assert time.second == 15

# Generated at 2022-06-24 10:43:32.956921
# Unit test for constructor of class Number
def test_Number():
    # initialization without parameters
    error_raised = False
    try:
        field = Number()
    except:
        error_raised = True
    assert error_raised == False
    # initialization with None parameters
    error_raised = False
    try:
        field = Number(allow_null=None, title=None, description=None,
                       minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None)
    except:
        error_raised = True
    assert error_raised == False
    # initialization with incorrect parameters value
    error_raised = False
    try:
        field = Number(allow_null="not a bool", maximum="not a number")
    except:
        error_raised = True
    assert error_raised == True
    # initialization with correct parameters value
    error_raised = False

# Generated at 2022-06-24 10:43:35.618894
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert f._creation_counter == 0
    assert f.title == ''
    assert f.description == ''
    assert f.allow_null == False


# Generated at 2022-06-24 10:43:37.121340
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime()
    assert dt.format == "datetime"


# Generated at 2022-06-24 10:43:39.668247
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(minimum=1,maximum=10,exclusive_maximum=True,exclusive_minimum=True,multiple_of=10)

test_Integer()



# Generated at 2022-06-24 10:43:46.525958
# Unit test for method serialize of class Field
def test_Field_serialize(): 
    f = Field()
    assert f.serialize(1) == 1
    assert f.serialize(1.1) == 1.1
    assert f.serialize('one') == 'one'
    assert f.serialize(True) == True
    assert f.serialize(False) == False
    assert f.serialize(None) == None


# Generated at 2022-06-24 10:43:48.192454
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f is not None
    assert f.numeric_type == float


# Generated at 2022-06-24 10:43:59.088068
# Unit test for method validate of class Object
def test_Object_validate():
    class MySchema(Schema):
        foo = Integer(default=1)
        bar = String()

    schema = MySchema()
    obj = schema.load({"foo": 10, "bar": "test", "new": 1})

    assert obj == {"foo": 10, "bar": "test", "new": 1}

    assert schema.dump(obj) == {"foo": 10, "bar": "test"}

    schema = MySchema(strict=True)

    with pytest.raises(ValidationError) as exc_info:
        schema.load({"foo": 10, "bar": "test", "new": 1})

    assert exc_info.value.messages() == [
        {"key": "invalid_property", "code": "invalid_property", "text": "Invalid property name."}
    ]



# Generated at 2022-06-24 10:44:01.594490
# Unit test for method has_default of class Field
def test_Field_has_default():
    field_instance = Field()
    result = field_instance.has_default()
    assert result == False

# Generated at 2022-06-24 10:44:10.164297
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    assert a.validate("") == ""
    assert a.validate(2) == 2
    assert a.validate(True) == True
    assert a.validate(False) == False
    assert a.validate(None) == None
    assert a.validate({"1": 2}) == {"1": 2}
    assert a.validate([1, 2]) == [1, 2]
    


# Generated at 2022-06-24 10:44:19.851879
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(
        items = String(required=True, allow_blank=False, max_length=50),
        unique_items = True,
        min_items = 1,
        max_items = 50
    )

    assert schema.validate(None) is None
    assert schema.validate("") == ValidationError.build_default(
        "type", field=schema
    )
    assert schema.validate("asdf") == ValidationError.build_default(
        "type", field=schema
    )
    error = schema.validate([])
    assert isinstance(error, ValidationError)
    assert error.messages()[0].text == "Must have at least 1 items."
    assert error.messages()[0].code == "min_items"

# Generated at 2022-06-24 10:44:30.858124
# Unit test for method validate of class Number
def test_Number_validate():
    f=Number(title="Test", minimum=1, maximum=2, precision=".2f", exclusive_minimum=None, exclusive_maximum=None)
    assert f.validate(1)==1
    assert f.validate(2)==2
    assert f.validate(1.01)==1.01
    assert f.validate(2.01)==ValidationError
    assert f.validate(1.01,strict=True)==ValidationError
    assert f.validate(2.01,strict=True)==ValidationError
    assert f.validate(0.99, strict=True)==ValidationError
    assert f.validate(0.99)==ValidationError
    assert f.validate(0.9999)==ValidationError
    assert f.validate(2.00)==2

# Generated at 2022-06-24 10:44:32.956351
# Unit test for constructor of class Any
def test_Any():
    field = Any()


# Generated at 2022-06-24 10:44:37.954353
# Unit test for method validate of class Union
def test_Union_validate():
    class unionChild(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    children = [unionChild(), unionChild()]

    u = Union(any_of=children)

    value, _ = u.validate_or_error(10)
    assert value == 10

    value, _ = u.validate_or_error(10, strict=True)
    assert value == 10

    with pytest.raises(ValidationError):
        u.validate(10.0)

    with pytest.raises(ValidationError):
        u.validate(10.0, strict=True)



# Generated at 2022-06-24 10:44:44.330496
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(name='a', choices=[('k1', 'v1')])
    assert field.choices == [('k1', 'v1')]
    field = Choice(name='a', choices=[('k1', 'v1'), ('k2', 'v2')])
    assert field.choices == [('k1', 'v1'), ('k2', 'v2')]
    field = Choice(name='a', choices=[('k1', 'v1'), 'k2'])
    assert field.choices == [('k1', 'v1'), ('k2', 'k2')]



# Generated at 2022-06-24 10:44:45.665435
# Unit test for method __or__ of class Field
def test_Field___or__():
  # Arrange
  pass



# Generated at 2022-06-24 10:44:49.056029
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None


# Generated at 2022-06-24 10:44:59.267216
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number()
    print("unit test start")
    print("---------------------------------------------------------")
    try:
        # start the unit test
        assert a.validate(10) == 10
        print("Successful")
    except AssertionError as msg:
        print("Failed", msg)
    
    print("---------------------------------------------------------")
    try:
        assert a.validate("10") == 10
        print("Successful")
    except AssertionError as msg:
        print("Failed", msg)
    
    print("---------------------------------------------------------")
    try:
        assert a.validate("10.3") == 10.3
        print("Successful")
    except AssertionError as msg:
        print("Failed", msg)
    
    print("---------------------------------------------------------")

# Generated at 2022-06-24 10:45:09.956426
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationError
    from typesystem.exceptions import ValidationError as ValidationError_
    from typesystem.fields import Integer
    from typesystem.typing import Any, AnyStr, NoReturn, Optional

    int_field = Integer()
    assert isinstance(int_field, Field)
    
    # Test for __init__ method
    assert int_field.title == ''
    assert int_field.description == ''
    assert int_field.allow_null == False
    
    # Test for has_default method
    assert int_field.has_default() == False
    
    # Test for get_default_value method
    # When self.default is not given
    assert int_field.get_default_value() is None
    # When self.default is given as a lambda

# Generated at 2022-06-24 10:45:15.589597
# Unit test for method validate of class String
def test_String_validate():
    str_bl = String(allow_blank=True)
    str_bl.validate("ab23c")
    str_bl.validate("")
    str_bl.validate(None)
    str_nl = String()
    try:
        str_nl.validate(None)
        assert False
    except ValidationError:
        assert True
    try:
        str_nl.validate("")
    except ValidationError:
        assert False
    assert str_nl.validate("23abcd") == "23abcd"
    try:
        str_nl.validate(23)
    except ValidationError:
        assert True
    str_nl_min = String(min_length=5)

# Generated at 2022-06-24 10:45:18.626486
# Unit test for method validate of class Choice
def test_Choice_validate():

    class_Choice = Choice()
    class_Choice.choices = [("choice", "choice"), ("choice2", "choice2")]
    class_Choice.allow_null = True
    assert class_Choice.validate("choice", strict=False) == "choice"
test_Choice_validate()


# Generated at 2022-06-24 10:45:27.635489
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestObject(Schema):
        property = String()
    test = TestObject()

    class TestObject(Schema):
        property = String()
    test = TestObject()

    class TestObject(Schema):
        property = String()
    test = TestObject()

    class TestObject(Schema):
        property = String()
    test = TestObject()

    class TestObject(Schema):
        array = Array(items=test)
    test = TestObject()

    data = {
        "array": [
            {"property": "value"},
            {"property": "value"},
            {"property": "value"},
            {"property": "value"},
            {"property": "value"},
            {"property": "value"},
        ]
    }
    assert test.serialize(data) == data

# Generated at 2022-06-24 10:45:29.359303
# Unit test for constructor of class Time
def test_Time():
	time1 = Time()

#Unit test for get_default_value of class Time

# Generated at 2022-06-24 10:45:34.922941
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {'name': String()}
    schema = Object(properties=properties)
    try:
        print(schema.validate(dict(name='Mark')))
    except ValidationError as error:
        print(error.messages)

test_Object_validate()

# Output
# {'name': 'Mark'}


# Generated at 2022-06-24 10:45:35.592418
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    pass


# Generated at 2022-06-24 10:45:37.871681
# Unit test for constructor of class Const
def test_Const():
    try:
        Const(None, title="foo")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-24 10:45:44.811904
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items = [int])
    assert field.validate(None) == None
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate([1,2,3]) == [1,2,3]
    with pytest.raises(ValidationError):
        field.validate([1,2,3.3])


# Generated at 2022-06-24 10:45:50.552537
# Unit test for method serialize of class Array
def test_Array_serialize():
    array = Array(items=Integer())
    test = array.serialize([3, 2, 1, 0])
    assert test == [3, 2, 1, 0]

    array = Array(items=Integer(), allow_null=True)
    test = array.serialize([3, 2, 1, 0])
    assert test == [3, 2, 1, 0]

    array = Array(allow_null=True)
    test = array.serialize([3, 2, 1, 0])
    assert test == [3, 2, 1, 0]



# Generated at 2022-06-24 10:45:56.235096
# Unit test for method validate of class Union
def test_Union_validate():
    # Check the error returned when the input value is of wrong type
    c = Union([String(enum=["backbone", "line"])], default="backbone")
    e = c.errors
    correct_error = e["union"]
    checked_error = None
    try:
        c.validate(1)
    except ValidationError as err:
        checked_error = err.messages()[0]["text"]

    assert correct_error == checked_error

    # Check the error returned when the input value is empty
    correct_error = e["null"]
    checked_error = None
    try:
        c.validate(None)
    except ValidationError as err:
        checked_error = err.messages()[0]["text"]

    assert correct_error == checked_error


# Generated at 2022-06-24 10:46:07.634099
# Unit test for constructor of class Integer
def test_Integer():
    # normal case
    assert Integer()
    assert Integer(allow_null=True)
    assert Integer(title="")
    assert Integer(description="")
    assert Integer(default=1)
    assert Integer(allow_blank=True)
    assert Integer(minimum=1)
    assert Integer(maximum=1)
    assert Integer(exclusive_minimum=1)
    assert Integer(exclusive_maximum=1)
    assert Integer(precision="1")
    assert Integer(multiple_of=1)

    # abnormal case
    try:
        assert Integer(min_length=1)
    except AttributeError:
        assert True
    try:
        assert Integer(max_length=1)
    except AttributeError:
        assert True
    try:
        assert Integer(pattern="1")
    except AttributeError:
        assert True


# Generated at 2022-06-24 10:46:19.055965
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b"])
    assert choice.validate(None) is None
    try:
        choice.validate(None, strict=True)
    except ValidationError:
        pass
    assert choice.validate("a") == "a"
    try:
        choice.validate("a", strict=True)
    except ValidationError:
        pass
    try:
        choice.validate("c")
    except ValidationError:
        pass
    try:
        choice.validate("c", strict=True)
    except ValidationError:
        pass
    try:
        choice.validate("")
    except ValidationError:
        pass
    try:
        choice.validate("", strict=True)
    except ValidationError:
        pass
    assert choice.valid

# Generated at 2022-06-24 10:46:22.461926
# Unit test for method serialize of class Field
def test_Field_serialize():
  assert Field().serialize('Ahoj světe')=='Ahoj světe'

# Generated at 2022-06-24 10:46:33.691404
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.__class__ == String
    assert s.errors == {
        "type": "Must be a string.",
        "null": "May not be null.",
        "blank": "Must not be blank.",
        "max_length": "Must have no more than {max_length} characters.",
        "min_length": "Must have at least {min_length} characters.",
        "pattern": "Must match the pattern /{pattern}/.",
        "format": "Must be a valid {format}.",
    }
    assert s.default is NO_DEFAULT
    assert s.title == ""
    assert s.description == ""
    assert s.allow_null is False
    assert s._creation_counter == 0
    assert s.allow_blank is False
    assert s.trim_whitespace is True


# Generated at 2022-06-24 10:46:35.578455
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field(default=NO_DEFAULT)
    assert field.validation_error('code')


# Generated at 2022-06-24 10:46:42.617126
# Unit test for method validate of class Const
def test_Const_validate():
    import pytest
    from aiojsonrpc2.fields import Const

    const_field = Const(1)
    assert const_field.validate(1) == 1
    with pytest.raises(ValidationError):
        const_field.validate(2)

    const_field = Const(None)
    assert const_field.validate(None) is None
    with pytest.raises(ValidationError):
        const_field.validate(1)



# Generated at 2022-06-24 10:46:48.880647
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a = Decimal(default=1.23)
    if a.serialize(1.234) == 1.2340000393390656:
        print("Test Success")
    else:
        print("Test Fail")

test_Decimal_serialize()


# Generated at 2022-06-24 10:46:53.602238
# Unit test for method validate of class Const
def test_Const_validate():
    const_field = Const(1)
    const_field.validate(1)
    try:
        const_field.validate(2)
    except ValidationError:
        pass
    else:
        raise AssertionError("ValidationError was not raised")

test_Const_validate()



# Generated at 2022-06-24 10:46:59.206547
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(0)
    assert const.validate(0) == 0
    assert const.validate(0.0) == 0.0
    assert const.validate(True) == True
    assert const.validate(False) == False
    assert const.validate([]) == []
    assert const.validate(None) == None
    assert const.validate({}) == {}
    assert const.validate(()) == ()
try:
    const.validate(1)
except ValidationError:
    assert True
else:
    assert False



# Generated at 2022-06-24 10:47:08.646857
# Unit test for constructor of class Array
def test_Array():
    arr = Array()
    assert arr.name is None
    assert not arr.allow_null
    assert arr.default is None

    arr = Array(name="foo", allow_null=True, default=[])

    expected = {
        "name": "foo",
        "allow_null": True,
        "default": [],
        "items": None,
        "additional_items": False,
        "min_items": None,
        "max_items": None,
        "unique_items": False,
    }
    assert arr.name == expected["name"]
    assert arr.allow_null == expected["allow_null"]
    assert arr.default == expected["default"]
    assert arr.items == expected["items"]
    assert arr.additional_items == expected["additional_items"]

# Generated at 2022-06-24 10:47:11.573274
# Unit test for constructor of class Text
def test_Text():
    correct_schema = Text(format="text",
                          allow_null=True,
                          max_length=None,
                          min_length=None,
                          pattern=None,
                          errors=Text().errors,
                          default=None)
    assert Text() == correct_schema


# Generated at 2022-06-24 10:47:12.863351
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    


# Generated at 2022-06-24 10:47:21.310742
# Unit test for method validate of class Union
def test_Union_validate():
	# Case 1
	data_1 = {'name': 'sport', 'value': 'soccer'}
	expected_result_1 = {'name': 'sport', 'value': 'soccer'}
	a = String()
	b = String()
	array = Array(any_of = [a, b])
	actual_result_1 = array.validate(data_1, strict = True)
	assert expected_result_1 == actual_result_1

	# Case 2
	data_2 = {'name': 'sport'}
	a = String()
	b = String()
	array = Array(any_of = [a, b])
	with pytest.raises(ValidationError):
		array.validate(data_2, strict = True)

	# Case 3

# Generated at 2022-06-24 10:47:30.721401
# Unit test for constructor of class String
def test_String():
    s = String()
    print(s.allow_blank)
    print(s.trim_whitespace)
    print(s.max_length)
    print(s.min_length)
    print(s.pattern)
    print(s.format)
    print("")

    s = String(allow_blank=True, max_length=4, min_length=2, pattern=".*", format="time")
    print(s.allow_blank)
    print(s.trim_whitespace)
    print(s.max_length)
    print(s.min_length)
    print(s.pattern)
    print(s.format)
    print("")

    # test error
    s = String(allow_blank='123')


# Generated at 2022-06-24 10:47:32.450417
# Unit test for constructor of class Const
def test_Const():
    field = Const(1)
    assert field.allow_null == False
    assert field.default == None
    assert field.const == 1
    assert field.strip == False

# Generated at 2022-06-24 10:47:42.765625
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    # Code to be tested
    class StringField(Field):
      errors = {
        'required': 'This field is required.',
        'invalid_type': 'Expected a string but received a {type_name}.',
        'blank': 'This field may not be blank.',
      }
      def validate(self, value):
          if value in (None, ''):
              raise self.validation_error('blank')
          if not isinstance(value, str):
              raise self.validation_error('invalid_type', type_name=type(value).__name__)
          return value
    # Instantiate the class to be tested
    field = StringField()
    
    # Expected value
    expected = ValidationError(text='This field is required.', code='required')

    # Call the function to be tested


# Generated at 2022-06-24 10:47:46.346791
# Unit test for method validate of class Any
def test_Any_validate():
    f = Any(allow_null=True)
    assert f.validate(None) is None
    assert f.validate("a") == "a"
    assert f.validate(1) == 1
    assert f.validate([1, 2]) == [1, 2]



# Generated at 2022-06-24 10:47:46.912006
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    pass

# Generated at 2022-06-24 10:47:49.776919
# Unit test for method validate of class Field
def test_Field_validate():

    # Testing with not implemented error
    field = Field()
    assert field.validate_or_error("") is None


# Generated at 2022-06-24 10:48:00.085156
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test 1
    test_field = Boolean()
    test_value = None
    result = test_field.validate(test_value)
    assert result == None

    # Test 2
    test_field = Boolean()
    test_value = True
    result = test_field.validate(test_value)
    assert result == True

    # Test 3
    test_field = Boolean()
    test_value = False
    result = test_field.validate(test_value)
    assert result == False

    # Test 4
    test_field = Boolean(allow_null=True)
    test_value = None
    result = test_field.validate(test_value)
    assert result == None

    # Test 5
    test_field = Boolean(allow_null=True)
    test_value = True

# Generated at 2022-06-24 10:48:00.942391
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime()

# Generated at 2022-06-24 10:48:08.984300
# Unit test for method validate of class Object

# Generated at 2022-06-24 10:48:19.973762
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    if __name__ == '__main__':
        import ast
        from typesystem.main import Schema

        # test1
        field = Boolean(null=True)
        if field.validate(None) is None:
            print("test1, passed")
        else:
            print("test1, failed")

        # test2
        field = Boolean(null=True)
        try:
            field.validate(1)
            print("test2, failed")
        except ValidationError:
            print("test2, passed")
        except Exception:
            print("test2, failed")

        # test3
        schema = Schema(title="test", properties={"foo": Boolean()})

# Generated at 2022-06-24 10:48:22.646094
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Field()]*2
    union_field = Union(any_of)
    value = None
    strict = False
    assert union_field.validate(value, strict=strict) is None



# Generated at 2022-06-24 10:48:32.117908
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)
    assert isinstance(Field().validate_or_error(""), ValidationResult)