

# Generated at 2022-06-24 10:38:41.812276
# Unit test for method validate of class Object
def test_Object_validate():
    objField = Object()
    assert objField.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert objField.validate({'a': 1, 'b': 2}, strict=True) == {'a': 1, 'b': 2}
    assert objField.validate({'a': 1, 'b': 2, 3: 3}) == {'a': 1, 'b': 2, 3: 3}
    assert objField.validate({'a': 1, 'b': 2, 3: 3}, strict=True) == {'a': 1, 'b': 2, 3: 3}
    assert objField.validate({'a': 1, 'b': 2, 3: '3'}) == {'a': 1, 'b': 2, 3: '3'}
   

# Generated at 2022-06-24 10:38:47.147505
# Unit test for method validate of class Field
def test_Field_validate():
    from typesystem.fields import String
    # Case 1: If a subclass doesn't implement the validate method, it raises a error
    try:
        Field().validate('1')
    except NotImplementedError:
        case1_pass = True
    # Case 2: If we input null value and allow_null is True, it returns null value
    case2_pass = (Field(allow_null=True).validate(None) == None)
    # Case 3: If we input null value and allow_null is False, it raises a error
    try:
        Field(allow_null=False).validate(None)
    except ValidationError as error:
        case3_pass = ('null' in error.text)
    # Case 4: If we input invalid value, it raises a error

# Generated at 2022-06-24 10:38:51.130815
# Unit test for constructor of class Text
def test_Text():
    assert Text(title="Phone Number", description="Phone Number", nullable=True, max_length=11).__dict__ == {'title': 'Phone Number', 'description': 'Phone Number', 'nullable': True, 'max_length': 11, 'enum': None, 'default': None, 'pattern': None, 'const': None, 'format': 'text', 'allow_null': True}



# Generated at 2022-06-24 10:38:55.803796
# Unit test for method validate of class Union
def test_Union_validate():
    from . import Boolean, Float, Integer, String
    assert Union(any_of=[Boolean()]).validate(0) is None
    assert Union(any_of=[Boolean()]).validate(1) is None
    assert Union(any_of=[Boolean()]).validate(-1) is None
    assert Union(any_of=[Boolean()]).validate(100) is None
    assert Union(any_of=[Boolean()]).validate(True) is True
    assert Union(any_of=[Boolean()]).validate(False) is False
    assert Union(any_of=[Boolean()]).validate("True") is None
    assert Union(any_of=[Boolean()]).validate("False") is None
    assert Union(any_of=[String()]).validate(0) is None

# Generated at 2022-06-24 10:39:06.192963
# Unit test for constructor of class Number
def test_Number():
    assert Number().numeric_type is None
    assert Number().allow_null is False
    assert Number().allow_blank is False
    assert Number().minimum is None
    assert Number().maximum is None
    assert Number().exclusive_minimum is None
    assert Number().exclusive_maximum is None
    assert Number().multiple_of is None
    assert Number().precision is None

    assert Number(title="a").title == "a"
    assert Number(description="b").description == "b"
    assert Number(default=1).default == 1

    assert Number(allow_null=True).allow_null is True
    assert Number(allow_blank=True).allow_blank is True
    assert Number(minimum=1).minimum == 1
    assert Number(maximum=1).maximum == 1
    assert Number(exclusive_minimum=1).exclusive_minimum == 1
   

# Generated at 2022-06-24 10:39:07.570054
# Unit test for constructor of class Time
def test_Time():
    t = Time(format="time")
    assert t.format == "time"


# Generated at 2022-06-24 10:39:14.943742
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean() 
    assert b.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert b.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
    }
    
    assert b.coerce_null_values == {"", "null", "none"}
    
    assert b.validate(1) == True
    assert b.validate('') == False
    assert b.validate('true') == True
    assert b.validate(None) == None

    #Changed allow_null from False to True to pass this test

# Generated at 2022-06-24 10:39:18.070604
# Unit test for constructor of class Union
def test_Union():
    from py_jobject.compat import String

    union_1_field = Union(any_of=[String(max_length=4)])
    assert union_1_field.validate('123') is not None

    union_2_field = Union(any_of=[String(min_length=10), String(max_length=4)])
    union_2_field.validate('123')



# Generated at 2022-06-24 10:39:28.580394
# Unit test for method __or__ of class Field
def test_Field___or__():
  class Field1(Field):
      def __init__(self, **kwargs):
          super().__init__(**kwargs)
  class Field2(Field):
      def __init__(self, **kwargs):
          super().__init__(**kwargs)
  f1=Field1(title="")
  f2=Field2(title="")
  print((f1|f2))
  f3=Union(any_of=f1)
  f4=Union(any_of=f2)
  print((f3|f4))
  f5=Field1(title="")
  f6=Field2(title="")
  print((f5|f6))
  f7=Union(any_of=f5)
  f8=Union(any_of=f6)

# Generated at 2022-06-24 10:39:31.424137
# Unit test for constructor of class Number
def test_Number():
    assert issubclass(Number, Field)
    assert isinstance(Number, type)
    assert isinstance(Number, typing.Type)
    number = Number()
    value = number.validate(1)
    assert value == 1
    value = number.validate(1.0)
    assert value == 1.0
    value = number.validate(None)
    assert value == None
    value = number.validate('')
    assert value == ''


# Generated at 2022-06-24 10:39:34.433461
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code = "error_code"
    assert field.validation_error(code).code is code


# Generated at 2022-06-24 10:39:43.499172
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    # check behaviour of String.serialize
    assert s.serialize("hello") == "hello"
    assert s.serialize(None) is None
    assert s.serialize(True) is True
    assert s.serialize(1000) == 1000
    assert s.serialize(1000.0) == 1000.0
    assert s.serialize([1,2,3]) == [1,2,3]
    assert s.serialize({'a':1,'b':2}) == {'a':1,'b':2}
    assert s.serialize(bytes(bytearray([1,2,3]))) == bytes(bytearray([1,2,3]))
# Unit test end

# Generated at 2022-06-24 10:39:45.032861
# Unit test for method validate of class Const
def test_Const_validate():
    class Test(Const):
        pass

    test = Test(58)
    assert test.validate(58) == 58

# Generated at 2022-06-24 10:39:51.620386
# Unit test for constructor of class Object
def test_Object():
    class Object_Test_SubSchema(Schema):
        c = String()

    class Object_Test_Schema(Schema):
        a = String()
        b = Object_Test_SubSchema
        c = Field(String)

    a = 'a'
    b = {'c': 'c'}
    c = 'c'
    test_data = {'a': a, 'b': b, 'c': c}
    expected = {'a': a, 'b': {'c': c}, 'c': c}
    assert test_data == expected
    # test the constructor of Object_Test_Schema for a case it should raise TypeError

# Generated at 2022-06-24 10:39:53.424670
# Unit test for constructor of class Time
def test_Time():
    v = Time()
    assert v.format == "time"


# Generated at 2022-06-24 10:39:55.696233
# Unit test for constructor of class Union
def test_Union():
    test_null = Null()
    test_class = Class([test_null])
    instance = Union([test_class])
    assert isinstance(instance.any_of, list)
    assert isinstance(instance.any_of[0], Class)

# Generated at 2022-06-24 10:40:00.866583
# Unit test for method validate of class String
def test_String_validate():
    s = String(min_length=2,max_length=3)
    try:
        # raise a string error
        s.validate("123")
        # raise a TypeError
        s.validate("1234")
    except ValidationError as error:
        print("Error:", error)



# Generated at 2022-06-24 10:40:03.401093
# Unit test for constructor of class Any
def test_Any():
    passed = False
    try:
        Any()
        passed = True
    except Exception:
        pass
    assert passed


# Generated at 2022-06-24 10:40:05.541658
# Unit test for constructor of class Decimal
def test_Decimal():
    dec = Decimal(title="A decimal")
    assert dec.title == "A decimal"



# Generated at 2022-06-24 10:40:06.990458
# Unit test for constructor of class Number
def test_Number():
    num = Number()
    assert(num is not None)



# Generated at 2022-06-24 10:40:11.251266
# Unit test for constructor of class Field
def test_Field():
    a = Field()
    assert isinstance(a, Field)
    assert a._creation_counter == 0
    b = Field()
    assert isinstance(b, Field)
    assert b._creation_counter == 1
    assert a._creation_counter == 0


# Generated at 2022-06-24 10:40:16.550692
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice()
    assert choices.validate("valid") == 'valid'
    assert choices.validate("") == ''
    try:
        assert choices.validate("Invalid")
    except ValidationError:
        pass
    else:
        raise AssertionError('Choice.validate did not raise ValidationError')
    assert choices.validate("") == ''
    assert choices.validate("null") == 'null'



# Generated at 2022-06-24 10:40:17.287635
# Unit test for constructor of class Date
def test_Date():
    assert isinstance(Date(), String)
    assert Date().format == "date"


# Generated at 2022-06-24 10:40:28.633805
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class mock_validate():
        def __init__(self, param):
            self.param = param
        def validate(self,value,strict):
            return value+self.param
        def validate_or_error(self,value,strict):
            return ValidationResult(value=self.validate(value,strict),error=None)
    class mock_error():
        def validate(self,value,strict):
            raise ValidationError("")
        def validate_or_error(self,value,strict):
            return ValidationResult(value=None,error=ValidationError(""))
    obj_mock_validate = mock_validate("LZJ")
    obj_mock_error = mock_error()
    validate_or_error_ret = obj_mock_validate.validate_or

# Generated at 2022-06-24 10:40:36.291691
# Unit test for constructor of class Array
def test_Array():
    array = Array()
    assert array.allow_null == False
    assert array.has_default() == False
    assert array.items is None
    assert array.additional_items == False
    assert array.min_items is None
    assert array.max_items is None
    assert array.unique_items == False


# Generated at 2022-06-24 10:40:41.100450
# Unit test for constructor of class Const
def test_Const():
    try:
        s = Const(None, allow_null=True)
    except Exception as e:
        raise e
    else:
        print("No Exception raised during unit test of class Const")

# Generated at 2022-06-24 10:40:45.641972
# Unit test for constructor of class DateTime
def test_DateTime():
    try:
        DateTime()
    except Exception as e:
        assert False, f"unexpected exception: {e}"

    try:
        DateTime(description="description", max_length=10, min_length=5)
    except Exception as e:
        assert False, f"unexpected exception: {e}"


# Generated at 2022-06-24 10:40:46.394456
# Unit test for constructor of class DateTime
def test_DateTime():
    field = DateTime()


# Generated at 2022-06-24 10:40:58.067336
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    try:
        field.validate(1)
        assert False
    except ValidationError as e:
        assert e.messages()[0].text == "Must be an array."
    
    try:
        field.validate(['a', 2])
        assert False
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].text == "Must be a string."
        assert e.messages()[0].code == "type"
        assert e.messages()[0].add_prefix(0) == "0"
        assert e.messages()[0].add_prefix(0).add_prefix(1) == "0.1"
        

# Generated at 2022-06-24 10:41:02.838281
# Unit test for constructor of class Array
def test_Array():
    array = Array(
            items=Field(), 
            additional_items=False, 
            min_items=None,
            max_items=None, 
            unique_items=True
        )
    print("Test constructor of class Array: Success")

test_Array()



# Generated at 2022-06-24 10:41:08.701117
# Unit test for method validate of class String
def test_String_validate():
    field = String(title="name", default="", allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    assert field.validate(None) == ""
    assert field.validate(None, strict=True) == None
    assert field.validate("") == ""
    assert field.validate(" a   ") == "a"
    assert field.validate(1) == None



# Generated at 2022-06-24 10:41:11.997446
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert field.has_default() == False
    field.default = 'a'
    assert field.has_default() == True


# Generated at 2022-06-24 10:41:14.405342
# Unit test for constructor of class Date
def test_Date():
    my_date = Date()
    assert(my_date.format == "date")



# Generated at 2022-06-24 10:41:19.732991
# Unit test for constructor of class Const
def test_Const():
    const = Const("test")
    try:
        const.validate("test")
        assert True
    except ValidationError as ve:
        assert False

    try:
        const.validate("fail")
        assert False
    except ValidationError as ve:
        assert True
    

# Generated at 2022-06-24 10:41:20.733618
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.format == "date"

# Generated at 2022-06-24 10:41:23.327431
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    assert field.validate(None) == None
    assert field.validate('') == ''
    assert field.validate(5) == 5
    assert field.validate(5.5) == 5.5
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({'key': 'value'}) == {'key': 'value'}
    
test_Any_validate()



# Generated at 2022-06-24 10:41:25.582050
# Unit test for constructor of class DateTime
def test_DateTime():
    x = DateTime()

    assert(x.has_default() == False)
    assert(x.allow_null == False)
    assert(x.has_default_value() == False)
    assert(x.message_template == "Invalid datetime value.")
    assert(x.format == "datetime")



# Generated at 2022-06-24 10:41:33.240624
# Unit test for constructor of class String
def test_String():
    string_field = String(default='hello')
    assert string_field.default == 'hello'
    assert string_field.allow_blank == False
    assert string_field.trim_whitespace == True
    assert string_field.max_length == None
    assert string_field.min_length == None
    assert string_field.pattern == None
    assert string_field.format == None
    assert isinstance(string_field, Field)
    assert isinstance(string_field, String)
    assert not isinstance(string_field, (Integer, Boolean, Float))
    try:
        string_field = String()
    except:
        assert True
    try:
        string_field = String(default=1)
    except:
        assert True

# Generated at 2022-06-24 10:41:36.635534
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_test = Decimal()
    assert decimal_test.serialize(1) == 1
    assert decimal_test.serialize(None) == None


# Generated at 2022-06-24 10:41:39.910118
# Unit test for method validate of class Field
def test_Field_validate():
    str_field = String(max_length=6)
    res = str_field.validate('123456')
    assert res == '123456'
    #Unit test for method validate of class String

# Generated at 2022-06-24 10:41:41.647492
# Unit test for constructor of class DateTime
def test_DateTime():
    p = DateTime()
    assert p.format == "datetime"


# Generated at 2022-06-24 10:41:44.149432
# Unit test for constructor of class Union
def test_Union():
    integer = Integer()
    u = Union([integer])
    assert u.any_of is not None
    assert u.allow_null == False


# Generated at 2022-06-24 10:41:45.817630
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    obj = 'h'
    assert field.serialize(obj) == obj


# Generated at 2022-06-24 10:41:52.312319
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["1", "12"]).validate("1") == "1"
    assert Choice(choices=["1", "12"]).validate("12") == "12"
    assert Choice(choices=["1", "12"]).validate("") == None
    assert Choice(choices=["1", "12"]).validate(None) == None

    with pytest.raises(ValidationError):
        Choice(choices=["1", "12"]).validate("6")
    with pytest.raises(ValidationError):
        Choice(choices=["1", "12"]).validate("")
    with pytest.raises(ValidationError):
        Choice(choices=["1", "12"]).validate(None)



# Generated at 2022-06-24 10:41:55.222089
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(23.05)==23.05
    assert Number(allow_null=True).validate(None)==None

# Generated at 2022-06-24 10:41:58.560891
# Unit test for method serialize of class Field
def test_Field_serialize():
    class Field1(Field):
        def validate(self, value, *,strict=False):
            return value
    fd = Field1()
    test_1 = fd.serialize("Hello world")
    assert test_1 == "Hello world"


# Generated at 2022-06-24 10:42:02.612575
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field(title="first").get_default_value() == None
    assert Field(title="first",default=1).get_default_value() == 1
    assert Field(title="first",default=NO_DEFAULT).get_default_value() == None


# Generated at 2022-06-24 10:42:05.380378
# Unit test for method validate of class Array
def test_Array_validate():
    array_validator = Array(
        items=Integer(), unique_items=False, allow_null=True, default=None
    )
    array_validator.validate([1])


# Generated at 2022-06-24 10:42:07.776118
# Unit test for constructor of class Union
def test_Union():
    test_Union = Union([Integer(),Number()],description='Test Union')
    assert test_Union.description == 'Test Union'
    assert test_Union.any_of[0].errors == Integer().errors
    assert test_Union.any_of[1].errors == Number().errors

# Generated at 2022-06-24 10:42:11.885693
# Unit test for constructor of class Array
def test_Array():
    test_obj = Array(items=[Field(type="string")], max_items=2)
    assert test_obj.max_items == 2
    test_obj.validate(["a", "b"])
    test_obj.validate([])
    test_obj.validate(["a"])
    test_obj.validate(["a", "b", "c"])

# Generated at 2022-06-24 10:42:19.463067
# Unit test for constructor of class Time
def test_Time():
    # valid value
    val = "2019-08-06T00:00:00Z"
    test_field = Time(max_length=64)
    assert test_field.validate(val) == val
    
    # invalid value
    val = "2019-08-06T00:00:00Z"
    test_field = Time(max_length=2)
    try:
        test_field.validate(val)
    except ValidationError as e:
        assert e.messages() == [Message(text="Must be 2 characters or less.", code="max_length", index=[])]


# Generated at 2022-06-24 10:42:22.688626
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field()
    result = f.validate_or_error(1, strict=True)
    assert result.value == 1
    assert result.error == None

# Generated at 2022-06-24 10:42:25.540297
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    try:
        field.validate('value', strict=True)
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 10:42:33.003804
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    booleans = Boolean(allow_null=True)
    print(booleans.validate(1))
    print(booleans.validate("true"))
    print(booleans.validate("false"))
    print(booleans.validate("on"))
    print(booleans.validate("off"))
    print(booleans.validate(True))
    print(booleans.validate(False))
    print(booleans.validate(None))
    print(booleans.validate(True))
    print(booleans.validate(False))
    print(booleans.validate("loi"))
    print(booleans.validate(true))
test_Boolean_validate()


# Generated at 2022-06-24 10:42:41.504468
# Unit test for constructor of class Float
def test_Float():
    def f():
        pass
    f = Float(title='test_Float_title', description='test_Float_description',
              precision='2')
    value = 1
    result = f.validate(value)
    assert result == value
    value = 1.2
    result = f.validate(value)
    assert result == 1.2
    value = 1.23
    result = f.validate(value)
    assert result == 1.23
    value = '1.233'
    result = f.validate(value)
    assert result == 1.23



# Generated at 2022-06-24 10:42:47.124437
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    number.validate(0)
    try:
        number.validate(None)
    except ValidationError as e:
        assert e.code == "null"
    try:
        number.validate(False)
    except ValidationError as e:
        assert e.code == "type"



# Generated at 2022-06-24 10:42:51.271579
# Unit test for method validate of class String
def test_String_validate():
    field = String(title="name", description="Name of the person", default="Ram")
    result = field.validate("Ram")
    assert result == "Ram"
    with pytest.raises(ValueError):
        field.validate(None)

# Generated at 2022-06-24 10:42:58.413531
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Field(title=None, description=None, default=NO_DEFAULT, allow_null=False)
    field2 = Field(title=None, description=None, default=NO_DEFAULT, allow_null=False)
    result = field1.__or__(other=field2)
    assert isinstance(result, Union)
    assert result.any_of == [field1, field2]

# Generated at 2022-06-24 10:43:02.509228
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal(precision = 1)
    assert d.precision == "1"
    d.validate(1)
    try:
        d.validate(1/3)
    except Exception as e:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-24 10:43:04.721936
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert field.has_default()

# Generated at 2022-06-24 10:43:06.363585
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object()
    obj.validate({})



# Generated at 2022-06-24 10:43:13.420580
# Unit test for constructor of class Text
def test_Text():
    x1 = Text()
    assert x1.format == "text", \
        "Encountered bug in function __init__ of class Text"
    assert x1.min_length is None, \
        "Encountered bug in function __init__ of class Text"
    assert x1.max_length is None, \
        "Encountered bug in function __init__ of class Text"
    assert x1.pattern is None, \
        "Encountered bug in function __init__ of class Text"



# Generated at 2022-06-24 10:43:15.239535
# Unit test for constructor of class Date
def test_Date():
    field = Date();
    assert field.format == 'date'
    assert field.allow_empty == False
    assert field.allow_null == False



# Generated at 2022-06-24 10:43:18.268825
# Unit test for method has_default of class Field
def test_Field_has_default():
    a=Field() 
    assert a.has_default()==False
    assert a.has_default()==True
test_Field_has_default()


# Generated at 2022-06-24 10:43:20.387557
# Unit test for constructor of class Text
def test_Text():
    try:
        Text()
    except Exception as e:
        assert str(e) == "Field.serialize is missing"


# Generated at 2022-06-24 10:43:25.852191
# Unit test for constructor of class Choice
def test_Choice():
    field1 = Choice(choices=['male', 'female', 'other'], required=True)
    assert field1.allow_null is False
    assert field1.choices == [('male', 'male'), ('female', 'female'), ('other', 'other')]
    field2 = Choice(choices=[("m", "Male"), ("f", "Female"), ("other", "Other")])
    assert field2.allow_null is True
    assert field2.choices == [('m', 'Male'), ('f', 'Female'), ('other', 'Other')]


# Generated at 2022-06-24 10:43:31.036109
# Unit test for method validate of class Number
def test_Number_validate():
    num_inst = Number()
    assert num_inst.validate(10) == 10
    assert num_inst.validate(10.1) == 10.1
    try:
        num_inst.validate(True)
    except:
        pass
    try:
        num_inst.validate(None)
    except:
        pass


# Generated at 2022-06-24 10:43:35.122653
# Unit test for method validate of class Any
def test_Any_validate():
    with pytest.raises(Exception) as excinfo:
        Any().validate(123)
    assert excinfo.value.args[0] == "A Field was not initialized correctly."



# Generated at 2022-06-24 10:43:42.593761
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize('2018-01-01') == datetime.date(2018,1,1)
    assert String(format="datetime").serialize('2018-01-01T12:00:00') == datetime.datetime(2018,1,1,12,00,00)
    assert String(format="time").serialize('12:00:00') == datetime.time(12,00,00)
    assert String(format="uuid").serialize('dd99f58b-f5d5-4bb2-a885-e5c52fbef83f') == uuid.UUID('dd99f58b-f5d5-4bb2-a885-e5c52fbef83f')


# Generated at 2022-06-24 10:43:44.021399
# Unit test for constructor of class Object
def test_Object():
    o = Object(properties=None,min_properties=None,max_properties=None,required=None)


# Generated at 2022-06-24 10:43:47.015464
# Unit test for constructor of class Text
def test_Text():
    field1 = Text(default="default value")
    field2 = Text(allow_null=True)
    field3 = Text(required=True)
    field4 = Text(description="Foo")
    assert field1.get_default_value() == "default value"
    assert field2.allow_null == True
    assert field3.required == True
    assert field4.get_description() == "Foo"

# Generated at 2022-06-24 10:43:47.981175
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field.get_error_text



# Generated at 2022-06-24 10:43:54.000164
# Unit test for constructor of class Field
def test_Field():
    title="Test title"
    description="Test description"
    default=123
    allow_null=True
    field=Field(title=title, description=description, default=default, allow_null=allow_null)
    assert field.title==title
    assert field.description==description
    assert field.allow_null==allow_null
    assert field.get_default_value()==default


# Generated at 2022-06-24 10:43:56.714764
# Unit test for method validate of class Choice
def test_Choice_validate():
    string_field = String()
    choice_field = Choice(choices = None)
    assert choice_field.validate('',strict=False)
    assert choice_field.validate(None)
        
test_Choice_validate()


# Generated at 2022-06-24 10:43:58.263559
# Unit test for constructor of class Float
def test_Float():
    assert(isinstance(Float(), Field))


# Generated at 2022-06-24 10:44:06.108748
# Unit test for constructor of class Float
def test_Float():
    assert Float(minimum=10.0, maximum=50.0).minimum==10.0
    assert Float(minimum=10.0, maximum=50.0).maximum==50.0
    assert Float(minimum=10.0, maximum=50.0).errors['type']=="Must be a number."
    assert Float(minimum=10.0, maximum=50.0).errors['null']=="May not be null."
    assert Float(minimum=10.0, maximum=50.0).errors['integer']=="Must be an integer."
    assert Float(minimum=10.0, maximum=50.0).errors['finite']=="Must be finite."
    assert Float(minimum=10.0, maximum=50.0).errors['minimum']=="Must be greater than or equal to {minimum}."

# Generated at 2022-06-24 10:44:10.250674
# Unit test for constructor of class Choice
def test_Choice():
    choice_field = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice_field.choices == [("a", "A"), ("b", "B")]
    assert choice_field.validate("a") == "a"
    assert choice_field.validate("b") == "b"



# Generated at 2022-06-24 10:44:12.301609
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_field = Decimal()
    assert decimal_field.numeric_type == decimal.Decimal


# Generated at 2022-06-24 10:44:22.862969
# Unit test for method validate of class Union
def test_Union_validate():
    Union_field1 = Union([Integer(),String()])
    try:
        Union_field1.validate(None)
    except ValidationError as error:
        assert error.messages()[0].text == Union.errors['null']
    else:
        assert False

    Union_field2 = Union([String(min_length=1,max_length=2),String(min_length=0,max_length=2)])

    try:
        Union_field2.validate('')
    except ValidationError:
        assert True
    else:
        assert False
    
    try:
        Union_field2.validate('123')
    except ValidationError:
        assert True
    else:
        assert False
    
    assert Union_field2.validate('12') == '12'
    assert Union_field

# Generated at 2022-06-24 10:44:28.054091
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    class Test(Field):
        def validate(self, value, *, strict):
            if not value:
                return value
        errors = {
            "empty": "value cannot be empty"
        }
    obj = Test()
    assert obj.validation_error("empty").text == "value cannot be empty"



# Generated at 2022-06-24 10:44:29.731215
# Unit test for constructor of class Number
def test_Number():
    obj1 = Number(allow_null=True)
    assert isinstance(obj1, Number)


# Generated at 2022-06-24 10:44:31.200373
# Unit test for constructor of class Boolean
def test_Boolean():
    assert isinstance(Boolean(), Boolean)



# Generated at 2022-06-24 10:44:34.285730
# Unit test for constructor of class Float
def test_Float():
    num = Float(title="Temperatur", description="The temperature...")
    assert num.title == "Temperatur"
    assert num.description == "The temperature..."


# Generated at 2022-06-24 10:44:36.770524
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    result = Decimal().serialize(4.2)
    assert result == 4.2



# Generated at 2022-06-24 10:44:41.742950
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    # given
    errors = {"error" : "This is an error"}
    code = "error"
    field = Field(error = errors, error_code = code)
    # when
    err = field.validation_error(code)
    # then
    assert err.text == errors[code] 
    assert err.code == code 

# Generated at 2022-06-24 10:44:48.008377
# Unit test for constructor of class Array
def test_Array():
    fields = Array(max_items=10, items=[
        Field(allow_null=True),
        Choice(choices=[(1, 'user1'), (2, 'user2')])
    ])
    print(fields.errors)
    print(fields.serialize(None))
    print(fields.validate(None, strict=True))

if __name__ == '__main__':
    test_Array()

# Generated at 2022-06-24 10:44:54.781908
# Unit test for method validate of class Union
def test_Union_validate():
    from nbschema import String, Number

    validator = Union([String(), Number()])
    assert validator.validate("hello") == "hello"
    assert validator.validate(10) == 10

    with pytest.raises(ValidationError):
        validator.validate(None)

    with pytest.raises(ValidationError):
        validator.validate(True)

# Generated at 2022-06-24 10:44:56.230636
# Unit test for constructor of class String
def test_String():
    string = String()
    print(string)

# Generated at 2022-06-24 10:44:57.039922
# Unit test for constructor of class Text
def test_Text():
    text_field = Text()
    assert text_field.format == "text"


# Generated at 2022-06-24 10:44:58.962380
# Unit test for constructor of class Decimal
def test_Decimal():
    x = Decimal(minimum=1)
    assert x.minimum == 1
    assert x.multiple_of == None


# Generated at 2022-06-24 10:45:01.022493
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
  field=Field()
  field.errors={'code': 'text'}
  assert field.get_error_text('code') == 'text'

# Generated at 2022-06-24 10:45:08.295621
# Unit test for method validate of class Const
def test_Const_validate():
    with pytest.raises(ValidationError) as excinfo:
        Const(const=1).validate(10)
    assert "Must be the value '1'." in str(excinfo.value)

    with pytest.raises(ValidationError) as excinfo:
        Const(const=None).validate(10)
    assert "Must be null." in str(excinfo.value)

    assert Const(const=10).validate(10) == 10



# Generated at 2022-06-24 10:45:12.830173
# Unit test for constructor of class Object
def test_Object():
    obj = Object(a=String())
    assert obj.properties['a']
    assert not obj.pattern_properties
    assert obj.additional_properties
    assert not obj.property_names
    assert not obj.min_properties
    assert not obj.max_properties
    assert not obj.required



# Generated at 2022-06-24 10:45:23.489671
# Unit test for constructor of class Object
def test_Object():
    expected_properties = {}
    expected_pattern_properties = {}
    expected_additional_properties = True
    expected_property_names = None
    expected_min_properties = None
    expected_max_properties = None
    expected_required = []

    obj_dict = {"properties": expected_properties,
                "pattern_properties": expected_pattern_properties,
                "additional_properties": expected_additional_properties,
                "property_names": expected_property_names,
                "min_properties": expected_min_properties,
                "max_properties": expected_max_properties,
                "required": expected_required
                }
    obj_field = Object(**obj_dict)

    assert obj_field.properties == expected_properties
    assert obj_field.pattern_properties == expected_pattern_properties
    assert obj_field.add

# Generated at 2022-06-24 10:45:29.856146
# Unit test for constructor of class Object
def test_Object():
    o = Object(id='id', properties={'name': 'name', 'age': 'age'})
    assert o.properties == {'name': 'name', 'age': 'age'}
    assert o.pattern_properties == {}
    assert o.additional_properties == True
    assert o.property_names == None
    assert o.min_properties == None
    assert o.max_properties == None
    assert o.required == []
    assert o.key == 'id'
    assert o.serialize == None
    assert o.deserialize == None
    assert o.allow_null

    o = Object(id="id", properties={"name": "name", "age": "age"}, allow_null=False)
    assert o.properties == {"name": "name", "age": "age"}

# Generated at 2022-06-24 10:45:35.898132
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="field title", description="field description", default=1, allow_null=True)
    assert field.title == "field title"
    assert field.description == "field description"
    assert field.default == 1
    assert field.allow_null == True
    assert field._creation_counter == Field._creation_counter
    assert field._creation_counter - 1 == Field._creation_counter - 1


# Generated at 2022-06-24 10:45:41.765831
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert (has_default(Field) is False)
    '''
    AssertionError
    assert (has_default(Field) is False)
    +  where Field = <class 'typesystem.fields.Field'>
    '''

# Generated at 2022-06-24 10:45:44.129610
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.fields import String

    f = String()
    assert(f.validate_or_error('test').value == 'test')
    assert(f.validate_or_error('test').is_valid())
    assert(f.validate_or_error(1).is_error())



# Generated at 2022-06-24 10:45:46.177314
# Unit test for method serialize of class Array
def test_Array_serialize():
    obj = Array(items=Integer(), required=False, max_properties=9)
    assert obj.serialize([1, 2, "3", 4]) == [1, 2, 3, 4]
#
#
#
#
#
#



# Generated at 2022-06-24 10:45:48.368432
# Unit test for constructor of class Union
def test_Union():
    any_of = [Int(), Float()]
    any_of_copy = [Int(), Float()]
    assert any_of == any_of_copy


# Generated at 2022-06-24 10:45:52.591662
# Unit test for method validate of class Choice
def test_Choice_validate():
    field=Choice(choices=["a", "b"])

    assert field.validate(None) == None
    assert field.validate(None) != "a"
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("b") != "c"
    pytest.raises(ValidationError, field.validate, "c")



# Generated at 2022-06-24 10:45:55.444551
# Unit test for constructor of class Choice
def test_Choice():
    c1 = Choice(choices=[("1", "1"), ("2", "2"), ("3", "3")])
    assert c1.choices == [("1", "1"), ("2", "2"), ("3", "3")]
    c2 = Choice(choices=["1", "2", "3"])
    assert c2.choices == [("1", "1"), ("2", "2"), ("3", "3")]



# Generated at 2022-06-24 10:45:56.634394
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer().numeric_type == int


# Generated at 2022-06-24 10:46:01.666727
# Unit test for method validate of class Number
def test_Number_validate():
    value = 5
    assert Number().validate(5)!=None
    assert Number().validate(5)==5
    assert Number().validate(value)!=None
    assert Number().validate(value)==5



# Generated at 2022-06-24 10:46:05.158693
# Unit test for method validate of class Const
def test_Const_validate():
    # The class Const is defined by the example see above. I try to validate 2 values in order
    # to check if the method validate works.
    if Const(const= 3).validate(2, strict=False) != 3:
        return False
    return True



# Generated at 2022-06-24 10:46:10.039237
# Unit test for method serialize of class Array
def test_Array_serialize():
    value = ["a", "b", "c"]
    result = Array(String()).serialize(value)
    assert result == ["a", "b", "c"]
    items = [String(), String(), String()]
    result = Array(items).serialize(value)
    assert result == ["a", "b", "c"]
    item = String()
    result = Array(item).serialize(value)
    assert result == ["a", "b", "c"]
# Unit test function

# Generated at 2022-06-24 10:46:16.589376
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=[("a", "Choice A"), ("b", "Choice B")])
    assert choice.choices == [("a", "Choice A"), ("b", "Choice B")]
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError, match="choice"):
        choice.validate("c")



# Generated at 2022-06-24 10:46:22.298178
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert f.title == ""
    assert f.description == ""


# Generated at 2022-06-24 10:46:28.012067
# Unit test for constructor of class DateTime
def test_DateTime():
    import datetime

    today = datetime.datetime.today()
    schema = DateTime()
    assert today.strftime('%Y-%m-%dT%H:%M:%S.%f') == schema.serialize(today.strftime('%Y-%m-%dT%H:%M:%S.%f'))
    try:
        assert today.strftime('%Y-%m-%dT%H') == schema.serialize(today.strftime('%Y-%m-%dT%H'))
    except AssertionError:
        print('Error: %s excepted %s' % (schema.serialize(today.strftime('%Y-%m-%dT%H')), today.strftime('%Y-%m-%dT%H')))


# Generated at 2022-06-24 10:46:37.074532
# Unit test for constructor of class Date
def test_Date():
    # TODO: How can I check that the integer values are within the correct range?
    assert Date.parse("1") == datetime.date(1, 1, 1)
    assert Date.parse("0001-01-01") == datetime.date(1, 1, 1)
    assert Date.parse("9999-12-31") == datetime.date(9999, 12, 31)
    assert Date.parse("-10000-01-01") == datetime.date(-10000, 1, 1)
    assert Date.parse("-9999-12-31") == datetime.date(-9999, 12, 31)
    assert Date.parse("1890-10-17") == datetime.date(1890, 10, 17)

    assert Date.serialize(datetime.date(1, 1, 1)) == "1"
    assert Date.serialize

# Generated at 2022-06-24 10:46:39.635623
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_object = Decimal()
    output = decimal_object.serialize(2)
    assert output == 2.0



# Generated at 2022-06-24 10:46:46.504649
# Unit test for constructor of class Text
def test_Text():
    text=Text()
    assert isinstance(text, Text)
    assert text.format == "text"
    assert text.allow_null == False
    assert text.default == None
    assert text.allow_blank == False
    assert text.min_length == 0
    assert text.max_length == None


# Generated at 2022-06-24 10:46:57.014662
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate('abc') is not None
    assert s.validate(None) is None

    s = String(allow_blank=True)
    assert s.validate('abc') is not None
    assert s.validate('') is not None
    assert s.validate(None) is None

    s = String(allow_null=True)
    assert s.validate('abc') is not None
    assert s.validate('') is ''
    assert s.validate(None) is None

    s = String(allow_null=True, allow_blank=True)
    assert s.validate('abc') is not None
    assert s.validate('') is ''
    assert s.validate(None) is None
    

# Generated at 2022-06-24 10:47:05.519798
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    '''
    This is a unit test for method get_default_value of class Field.
    It checks if the get_default_value method returns a string, a number, an array or a dictionary
    '''
    field = Field(default= [0, 1, 2])
    assert isinstance(field.get_default_value(), list)
    field = Field(default= {'a': 0, 'b': 1})
    assert isinstance(field.get_default_value(), dict)
    field = Field(default= 0.5)
    assert isinstance(field.get_default_value(), float)
    field = Field(default= 'str')
    assert isinstance(field.get_default_value(), str)

# Generated at 2022-06-24 10:47:07.512624
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer.numeric_type == int
    obj = Integer()
    assert obj.numeric_type == int


# Generated at 2022-06-24 10:47:18.044992
# Unit test for constructor of class Number
def test_Number():
    c = Number(title="", description="", default=NO_DEFAULT, allow_blank=False, allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, precision=None)
    c.__init__(title="", description="", default=NO_DEFAULT, allow_blank=False, allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, precision=None) 
    assert isinstance(c, Number)
    assert c.title == ""
    assert c.description == ""
    assert c.default == NO_DEFAULT
    assert c.allow_blank == False
    assert c.allow_null == False
    assert c.minimum == None
    assert c.maximum == None
   

# Generated at 2022-06-24 10:47:23.052092
# Unit test for constructor of class Const
def test_Const():
    a = Const(const = "hello")
    a.validate("hello")
    try:
        a.validate("world")
    except ValidationError as e:
        print(e)
    try:
        a.validate(None)
    except ValidationError as e:
        print(e)

# Generated at 2022-06-24 10:47:27.152282
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [String(), Object(), Number()]
    union = Union(any_of)
    assert union.validate('a') == 'a'
    assert union.validate(1) == 1
    assert union.validate({'a': 1}) == {'a': 1}
    try:
        union.validate(1.2)
    except ValidationError as e:
        assert len(e.messages()) == len(any_of)
    try:
        union.validate(1.2)
    except ValidationError as e:
        assert len(e.messages()) == len(any_of)
        assert e.messages()[0].text == 'Must be a string.'
        assert e.messages()[0].index == []

# Generated at 2022-06-24 10:47:30.491723
# Unit test for constructor of class Time
def test_Time():
    assert Time(format="time", allow_null=True) is not None



# Generated at 2022-06-24 10:47:32.667018
# Unit test for constructor of class Decimal
def test_Decimal():
    test_obj = Decimal()
    assert test_obj.numeric_type == decimal.Decimal
    assert test_obj.precision == None



# Generated at 2022-06-24 10:47:41.263922
# Unit test for method validate of class Number
def test_Number_validate():
    from typesystem.schema import Schema
    from datetime import datetime
    from decimal import Decimal

    schema = Schema({"foo":Number(maximum=10)})
    assert schema.validate({"foo":15}) == {"foo": 10}
    assert schema.validate({"foo":5}) == {"foo":5}
    @schema.validator
    def validate(data, schema_data):
        return schema_data
    assert schema.validate({"foo":15}) == {"foo":10}
    assert schema.validate({"foo":5}) == {"foo":5}



# Generated at 2022-06-24 10:47:45.281374
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    val1 = field.validate(1)
    val2 = field.validate(None)
    val3 = field.validate([])
    assert val1 == 1
    assert val2 == None
    assert val3 == []


# Generated at 2022-06-24 10:47:50.459785
# Unit test for constructor of class Boolean
def test_Boolean():
    truth = Boolean()
    assert truth.validate(True)
    assert truth.validate(False)
    assert truth.validate("True")
    assert truth.validate("True".lower())
    assert truth.validate("False")
    assert truth.validate("False".lower())
    assert truth.validate("1")
    assert truth.validate("0")
    assert truth.validate(1)
    assert truth.validate(0)
    assert truth.validate(None)
    assert truth.validate("") is False
    assert truth.validate(12) is True
    assert truth.validate(t) is True
    assert truth.validate(object) is True

# Unit test type of value is string and value is true

# Generated at 2022-06-24 10:47:52.700683
# Unit test for method validate of class Field
def test_Field_validate():
    a = Field()
    b = Field()
    assert a._creation_counter == 0
    assert b._creation_counter == 1


# Generated at 2022-06-24 10:47:58.414028
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    class TestField(Field):
        errors = {
            "invalid": "Field must be a valid {name}."
        }

    test_Field = TestField(title="TestField", description="", default=NO_DEFAULT, allow_null=False)
    code = "invalid"
    result = test_Field.validation_error(code)
    assert isinstance(result, ValidationError)


# Generated at 2022-06-24 10:48:00.213665
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    assert field.format == "text"
    assert field.allow_null == False



# Generated at 2022-06-24 10:48:01.586991
# Unit test for constructor of class Any
def test_Any():
    obj = Any()
    assert obj != None


# Generated at 2022-06-24 10:48:03.746311
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_obj = decimal.Decimal("1234")
    assert Decimal().serialize(decimal_obj) == 1234.0
# test serialize for class Decimal



# Generated at 2022-06-24 10:48:06.604185
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(None) == None


# Generated at 2022-06-24 10:48:09.922113
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(5.5) == 5.5
    assert Decimal().serialize(None) == None
    assert Decimal().serialize(5) == 5

# Generated at 2022-06-24 10:48:13.064202
# Unit test for method validate of class Object
def test_Object_validate():
    myfield = Object(properties={"myprop": Integer()}, required=["myprop"])
    assert myfield.validate({"myprop": 12}) == {"myprop": 12}
    with pytest.raises(ValidationError):
        myfield.validate({"myprop": "un nombre"})
    return



# Generated at 2022-06-24 10:48:19.381172
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typesystem.types import Boolean
    # test passing in a valid value
    integer_field = Integer()
    assert Integer.validate_or_error(integer_field, 5).value == 5
    # test passing in an invalid value
    assert ValidationError.validate_or_error(integer_field, "5").value is None
    # test passing in a default value
    boolean_field = Boolean(default=True)
    assert Boolean.validate_or_error(boolean_field, None).value is True

# Generated at 2022-06-24 10:48:29.642691
# Unit test for constructor of class Array
def test_Array():
    class Person(Structure):
        name: str
        age: int

    class ArraySchema(Structure):
        family: Array[Person] = [Person(name="Alice", age=25), Person(name="Bob", age=22)]

    schema = ArraySchema()
    assert schema.family[0].name == "Alice"
    assert schema.family[1].name == "Bob"

    try:
        schema.family[2]
        assert False, "Should have raised an IndexError"
    except IndexError:
        pass

    try:
        schema.family[0].name = "Charlie"
        assert False, "Should have raised an TypeError"
    except TypeError:
        pass

    assert isinstance(schema.__fields__["family"], Array)

# Generated at 2022-06-24 10:48:35.174212
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices = ["one", "two"])
    assert(c.choices == [('one', 'one'), ('two', 'two')])
    c = Choice(choices = [('one', 'val1'), ('two', 'val2')])
    assert(c.choices == [('one', 'val1'), ('two', 'val2')])
    c = Choice(choices = [('one', 'val1'), ('two')])