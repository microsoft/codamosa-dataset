

# Generated at 2022-06-24 10:38:46.257021
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={'name':String()}, additional_properties=True, allow_null=True)
    assert schema.validate({"name":"Ayushi"}) == {"name":"Ayushi"}
    assert schema.validate({"name":"Ayushi", "age": 20}) == {"name":"Ayushi", "age": 20}
    with pytest.raises(ValidationError):
        schema.validate([])
    with pytest.raises(ValidationError):
        schema.validate({"name":["Ayushi"]})
    with pytest.raises(ValidationError):
        schema.validate({"name":"Ayushi", "age": True})
    assert schema.validate(None) == None

# Generated at 2022-06-24 10:38:47.555157
# Unit test for constructor of class Number
def test_Number():
    assert isinstance(Number(default=0, minimum=0, maximum=100), Number)



# Generated at 2022-06-24 10:38:48.780333
# Unit test for constructor of class Array
def test_Array():
    assert hasattr(Array, "__init__")



# Generated at 2022-06-24 10:38:53.056932
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    print("Testing method get_error_text of class Field")
    # Test 1
    str1 = "A field is required"
    str2 = "A field is required"
    assert(str1 == str2)

    # Test 2
    str1 = "Maximum length of {max_length} exceeded"
    str2 = "Maximum length of {max_length} exceeded"
    assert(str1 == str2)


# Generated at 2022-06-24 10:38:57.564422
# Unit test for method validate of class Object
def test_Object_validate():
    from .test_Schema import test_schema
    from .test_Schema import Field as Schema_Field
    from .test_Schema import Object as Schema_Object
    schema_field = Schema_Field()
    schema_object = Schema_Object()
    test_json = {"test": "Test"}
    assert test_schema.validate(test_json)
    test_json = {"test": "Test", "test2": "Test2", "test3": "Test3"}
    assert test_schema.validate(test_json)
    test_json = {"test": "Test", "test2": "Test2", "test3": "Test3", "test4": "Test4"}
    assert test_schema.validate(test_json)

# Generated at 2022-06-24 10:38:58.421770
# Unit test for method validate of class Union
def test_Union_validate():
    Union(any_of=[Number()]).validate("Hello")

# Generated at 2022-06-24 10:38:59.021195
# Unit test for constructor of class Union
def test_Union():
    assert Union([String(), Integer()])



# Generated at 2022-06-24 10:39:01.537994
# Unit test for constructor of class Choice
def test_Choice():
    choices = [
        ("user", "User"),
        ("group", "Group"),
        ("other", "Other"),
    ]
    field = Choice(choices=choices)
    try:
        field.validate('user')
    except ValidationError:
        assert False
    try:
        field.validate(1) # Raise error 1
        assert False
    except ValidationError as err:
        assert err.message() == 'Must be a string.'



# Generated at 2022-06-24 10:39:03.977719
# Unit test for method serialize of class Array
def test_Array_serialize():
    schema = Array(items=String())
    serialized = schema.serialize(["a", "b"])
    assert serialized == ["a", "b"]



# Generated at 2022-06-24 10:39:11.274064
# Unit test for constructor of class String
def test_String():
    # With default values
    s = String()
    assert s.format == None
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.pattern_regex == None
    assert s.allow_blank == False
    assert s.allow_null == False
    assert s.trim_whitespace == True
    assert s.title == ""
    assert s.description == ""
    assert s.errors == s.errors

    # With user-define values
    s2 = String(format="abc", max_length=10, min_length=5, pattern="abc", allow_blank=True,
             allow_null=True, trim_whitespace=False, title="abc", description="abc", errors="abc")
    assert s2.format == "abc"
   

# Generated at 2022-06-24 10:39:19.509192
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(1)
    try:
        const.validate(2)
        assert False
    except ValidationError as e:
        assert e.messages[0].code == "const"
    assert const.validate(1) == 1

    const = Const(None, allow_null=True)
    try:
        const.validate(1)
        assert False
    except ValidationError as e:
        assert e.messages[0].code == "only_null"
    assert const.validate(None) == None



# Generated at 2022-06-24 10:39:21.173692
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(5) == 5



# Generated at 2022-06-24 10:39:27.846267
# Unit test for method validate of class Array
def test_Array_validate():
    class Error(Exception):
        pass

    class MyClass:
        def __init__(self, **kwargs: str) -> None:
            self.__dict__.update(kwargs)

    # Init
    string = String()
    text = Text()
    boolean = Boolean()
    integer = Integer()
    number = Number()
    null = Null()
    date = Date()
    datetime = DateTime()
    time = Time()
    array = Array(items=string)
    object = Object()
    obj = Object(properties={"name": string, "title": string, "live": boolean})
    schema = Array(
        items=string,
        additional_items=text,
        min_items=1,
        max_items=2,
        required=["password"],
    )

# Generated at 2022-06-24 10:39:35.975869
# Unit test for method validate of class Union
def test_Union_validate():
    assert ((
        Union(
            any_of=[
                Number(minimum=50, exclusive_minimum=True),
                Number(maximum=50, exclusive_maximum=True),
            ]
        )
        .validate(49)
        is None
    ))

    assert (
        Union(
            any_of=[
                Number(minimum=50, exclusive_minimum=True),
                Number(maximum=50, exclusive_maximum=True),
            ]
        )
        .validate(50)
        is None
    )



# Generated at 2022-06-24 10:39:44.836793
# Unit test for constructor of class Union
def test_Union():
    from marshmallow import fields

    class Person:
        def __init__(self, name: str):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

    class Member:
        def __init__(self, first_name: str, last_name: str):
            self.first_name = first_name
            self.last_name = last_name

        def __eq__(self, other):
            return (
                self.first_name == other.first_name
                and self.last_name == other.last_name
            )

    class NonMember:
        def __init__(self, name: str):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name


# Generated at 2022-06-24 10:39:47.162066
# Unit test for constructor of class Date
def test_Date():
    assert Date().format == "date"


# Generated at 2022-06-24 10:39:48.535599
# Unit test for constructor of class Float
def test_Float():
    assert issubclass(Float, Number)
    assert Float.numeric_type == float


# Generated at 2022-06-24 10:39:55.350601
# Unit test for constructor of class Boolean
def test_Boolean():
    a = Boolean()
    assert isinstance(a,Boolean)
    assert a.allow_null == False
    assert a.default == NO_DEFAULT
    assert a.description == ""
    assert a.title == ""
    assert a.coerce_null_values == ["", "null", "none"]
    assert a.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
    }



# Generated at 2022-06-24 10:40:03.078443
# Unit test for method validation_error of class Field
def test_Field_validation_error():
   #__init__
   #_init__
   def wrapper_Field_validation_error():
       try:
        field = Field()
        code = "code"
        try:
            field.validation_error(code)
        except Exception as e:
            assert False, "unexpected exception: " + str(e)
       except Exception as e:
           assert False, "unexpected exception: " + str(e)

   wrapper_Field_validation_error()

# Generated at 2022-06-24 10:40:06.928741
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.format == "text"



# Generated at 2022-06-24 10:40:14.199217
# Unit test for constructor of class Choice
def test_Choice():
    obj = Choice(choices=["a", "b", "c"])
    assert obj.choices == [("a", "a"), ("b", "b"), ("c", "c")]
    obj = Choice(choices=[("a", "x"), "b", ("c", "y")])
    assert obj.choices == [("a", "x"), ("b", "b"), ("c", "y")]
    obj = Choice(choices=[("a", 1, 2), "b", ("c", "y")])
    assert obj.choices == [("a", 1), ("b", "b"), ("c", "y")]


# Generated at 2022-06-24 10:40:15.906253
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime(description="description", title="title", format="datetime") == DateTime(description="description", title="title")



# Generated at 2022-06-24 10:40:18.969400
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal().serialize(decimal.Decimal('0')) == 0.0
    assert Decimal().serialize(None) == None
    assert Decimal().validate('0') == decimal.Decimal('0')



# Generated at 2022-06-24 10:40:26.019408
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean(title = 'My Boolean', default = False, allow_null = True)
    value = boolean.get_default_value()
    assert value == False
    boolean = Boolean(title = 'My Boolean', default = True, allow_null = True)
    value = boolean.get_default_value()
    assert value == True
    boolean = Boolean(title = 'My Boolean', default = True, allow_null = False)
    value = boolean.get_default_value()
    assert value == True
    boolean = Boolean(title = 'My Boolean', default = False, allow_null = False)
    value = boolean.get_default_value()
    assert value == False
    boolean = Boolean(title = 'My Boolean', default = NO_DEFAULT, allow_null = False)
    value = boolean.get_default_value()

# Generated at 2022-06-24 10:40:29.191475
# Unit test for constructor of class Number
def test_Number():
    N1 = Number(allow_null=False)
    N2 = Number(allow_null=True)
    N3 = Number(allow_null=False, default="1.0", minimum=0, precision="1.1")
    N4 = Number(allow_null=False, default="1.0", minimum=1, precision="1.1")
    assert N1
    assert N2
    assert N3
    assert not N4


# Generated at 2022-06-24 10:40:41.994200
# Unit test for method validate of class Choice
def test_Choice_validate():
    a = Choice(allow_null = False, choices = [(1, 'one')])
    assert a.validate(1) == 1

    a = Choice(allow_null = False, choices = [(1, 'one')])
    assert a.validate(None) == None

    with pytest.raises(ValidationError):
        a = Choice(allow_null = False, choices = [(1, 'one')])
        a.validate("one")

    with pytest.raises(ValidationError):
        a = Choice(allow_null = False, choices = [(1, 'one')])
        a.validate("")

    with pytest.raises(ValidationError):
        a = Choice(allow_null = False, choices = [(1, 'one')])
        a.validate("")


# Generated at 2022-06-24 10:40:44.772263
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(title="title")
    assert field.has_default() == False
    field = Field(title="title", default=None)
    assert field.has_default() == True

# Generated at 2022-06-24 10:40:50.065473
# Unit test for method serialize of class Field
def test_Field_serialize():
    class TestField(Field):
        def validate(self, value, *, strict=False):
            return value

    field = TestField(title='Foo', description='Bar')
    assert field.serialize(123) == 123
    assert field.serialize([1, 2, 3]) == [1, 2, 3]
    assert field.serialize({'foo': 'bar'}) == {'foo': 'bar'}
    assert field.serialize(None) == None



# Generated at 2022-06-24 10:40:59.542493
# Unit test for constructor of class DateTime
def test_DateTime():

    # New DateTime object with default values.
    assert DateTime(format="datetime") is not None

    # New DateTime object with specified values
    # TODO: (DONE) check for new DateTime object with specified values
    assert DateTime(format="date", min_length=10, pattern="^[0-9-]+$", required=True) is not None

    # Validate date in ISO 8601 format "yyyy-MM-dd"
    assert DateTime().validate('2018-11-16') == '2018-11-16'

    # Validate date with specified pattern should throw error for invalid pattern
    try:
         DateTime(format="date", min_length=10, pattern="^[0-9]+$").validate('2018-11-16')
    except ValidationError:
         assert True

    # Validate required

# Generated at 2022-06-24 10:41:02.631872
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    value = Decimal(
        title="",
        description="",
        default=0,
        allow_null=False,
    )
    ret = value.serialize(None)
    assert ret is None



# Generated at 2022-06-24 10:41:06.869826
# Unit test for constructor of class Field
def test_Field():
    # Arrange
    # Act
    myField = Field()

    # Assert
    assert type(myField) == Field
    assert myField.title == ""
    assert myField.description == ""
    assert myField.default == NO_DEFAULT
    assert myField.allow_null == False



# Generated at 2022-06-24 10:41:17.644377
# Unit test for constructor of class Field
def test_Field():
    assert Field().description == ''
    # test with all parameters
    assert  Field(title = 'Name', description = 'Name of the node', default = 1, allow_null = False).description == 'Name of the node'
    assert Field(allow_null = True).allow_null == True
    # test with no default
    assert Field().has_default() == False
    # test with default
    assert Field(default = 1).has_default() == True
    # test with no error
    assert Field().get_error_text('test') == ''
    assert Field().validation_error('test') == ValidationError(text='', code='test')
    assert Field().__dict__['errors'] == {}

# end of unit test


# Generated at 2022-06-24 10:41:27.852076
# Unit test for constructor of class Array
def test_Array():
    # Create a field
    field = Array(
        items = [Number(minimum=0), Integer(minimum=0)],
        additional_items = False,
        min_items = None,
        max_items = None,
        unique_items = False,
        name = "a",
        allow_null = True,
    )

    # Test values
    good_values = [[0, 1, 2], [0, 0.1, 2], [0, 1.0, 2.0], [0.0, 1.0, 2.0]]
    bad_values = [{"a": 0}, [0, 1], [0, 1, 2, 3], [1, 2]]

    # Validate good values
    for value in good_values:
        assert field.validate(value) == value

    # Validate bad values

# Generated at 2022-06-24 10:41:40.150701
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    f = Boolean()
    assert f.validate(True) == True
    assert f.validate(False) == False
    assert f.validate(None) == None
    assert f.validate('true') == True
    assert f.validate('True') == True
    assert f.validate('false') == False
    assert f.validate('FALSE') == False
    try:
        assert f.validate('trues') == None
    except ValidationError:
        assert True
    try:
        assert f.validate('falses') == None
    except ValidationError:
        assert True
    try:
        assert f.validate('on') == None
    except ValidationError:
        assert True
    assert f.validate('1') == True
    assert f.validate(1) == True

# Generated at 2022-06-24 10:41:48.268463
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    # Instanciation
    f = Field()
    assert f.get_default_value() == None

    # Instanciation
    f = Field(default='default')
    assert f.get_default_value() == 'default'

    # Instanciation
    f = Field(allow_null=True)
    assert f.get_default_value() == None

    # Instanciation
    f = Field(allow_null=True, default='default')
    assert f.get_default_value() == None

    # Instanciation
    f = Field(allow_null=True, default=NO_DEFAULT)
    assert f.get_default_value() == None

    # Instanciation
    default = lambda: 'default'
    f = Field(default=default)
    assert f.get_default_value() == 'default'

# Generated at 2022-06-24 10:41:51.057729
# Unit test for method serialize of class Array
def test_Array_serialize():
    stu = [dict(name=1), dict(name=2), dict(name=3)]
    # t = Array(items=[Dict(properties=dict(name=Integer()))]).serialize(stu)
    t = Array().serialize(stu)
    print(t)



# Generated at 2022-06-24 10:41:55.460126
# Unit test for method serialize of class Field
def test_Field_serialize():  # noqa
    class SomeField(Field):
        pass

    s = SomeField()
    assert s.serialize(1) == 1
    assert s.serialize(None) is None
    assert s.serialize("a") == "a"
    

# Generated at 2022-06-24 10:41:56.297073
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert time.format == 'time'


# Generated at 2022-06-24 10:42:00.229349
# Unit test for method serialize of class String
def test_String_serialize():
    test_string_obj = String(max_length=10, min_length=1,
                             format="datetime", allow_null=False)
    dt = datetime.datetime(2018, 12, 1, 12, 0, 0)
    assert test_string_obj.serialize(dt) == '2018-12-01T12:00:00'


# Generated at 2022-06-24 10:42:09.111891
# Unit test for method serialize of class Array
def test_Array_serialize():
    # init a class Array
    obj_Array = Array(None, True)

    # init a class Field
    obj_Field = Field()

    # init a class Object
    obj_Object = Object(None, False)

    # init a class String
    obj_String = String(None)

    # add item to items of Array
    obj_Array.items.append(obj_Field)

    # add item to items of Array
    obj_Array.items.append(obj_Object)

    # add item to items of Array
    obj_Array.items.append(obj_String)

    # check the result of serialize the obj_Array
    # the result should be ["1", 2, "3"]
    print(obj_Array.serialize([1, 2, "3"]))



# Generated at 2022-06-24 10:42:14.892286
# Unit test for constructor of class Number
def test_Number():
    n = Number(minimum=1.0, maximum=3.0, allow_null=False, title='Title', description='Description')
    assert n.minimum == 1.0
    assert n.maximum == 3.0
    assert n.allow_null == False
    assert n.title == 'Title'
    assert n.description == 'Description'
    assert n.has_default() == False
    assert n.numeric_type == None
    assert n.exclusive_minimum == None
    assert n.exclusive_maximum == None
    assert n.precision == None
    assert n.multiple_of == None



# Generated at 2022-06-24 10:42:19.847141
# Unit test for constructor of class Field
def test_Field():
    a = Field(title="abc", description="abc", allow_null=True, default=123)
    assert a.title == "abc"
    assert a.description == "abc"
    assert a.allow_null == True
    assert a.default == 123
    assert a._creation_counter == 0

    b = Field(title="def", description="def", allow_null=True, default=456)
    assert b.title == "def"
    assert b.description == "def"
    assert b.allow_null == True
    assert b.default == 456
    assert b._creation_counter == 1


# Generated at 2022-06-24 10:42:22.241114
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert 1 == Field(title=1, description=2, default="default").get_default_value()
    

# Generated at 2022-06-24 10:42:24.795322
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    try:
        test_obj = Boolean()
        test_obj.validate(None)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-24 10:42:26.052506
# Unit test for method serialize of class String
def test_String_serialize():
  string = '1'
  assert string.serialize == 1

# Generated at 2022-06-24 10:42:28.641605
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    """ Test validation_error (Field) """
    return_value = ValidationError(text='A validation error', code='abc')
    instance = Field(title='', description='')
    code = 'abc'

    result = instance.validation_error(code)
    assert result==return_value



# Generated at 2022-06-24 10:42:33.240864
# Unit test for constructor of class Union
def test_Union():
    assert Union(any_of = [String()]).validate("hello") == "hello"
    assert Union(any_of = [Number()]).validate(123) == 123
    assert Union(any_of = [String(),Number()]).validate(123) == 123
    assert Union(any_of = [String(),Number()]).validate("hello") == "hello"
    assert Union(any_of = [String(),Number()]).validate(True) == True


# Generated at 2022-06-24 10:42:36.199540
# Unit test for constructor of class Number
def test_Number():
    assert Number(minimum=0, maximum=1, exclusive_minimum=2, exclusive_maximum=3, multiple_of=4)
    assert Number()


# Generated at 2022-06-24 10:42:41.133269
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    import pytest
    from typesystem.fields import Field, Uniqueness
    x = Field(title="foo", description="bar", allow_null=True)
    message = x.get_error_text("invalid")

    assert message == 'invalid is not a valid value for "foo".'


# Generated at 2022-06-24 10:42:46.822182
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(123)
    # the value is None and const is not None but allow_null is still not set
    assert const.allow_null == False
    # the value is not None and const is not None but allow_null is still not set
    assert const.validate(123) == 123
    assert const.validate(234) == None

# Generated at 2022-06-24 10:42:47.997359
# Unit test for constructor of class Field
def test_Field():
    assert Field


# Generated at 2022-06-24 10:42:50.636179
# Unit test for method validate of class Any
def test_Any_validate():

    obj = Any()
    assert obj.__class__.__name__ == "Any"
    assert obj.__class__.__name__ == "Any"
    obj.validate([])
    obj.validate(["test"])
    assert obj.__class__.__name__ == "Any"
    assert not obj.allow_null
    assert obj.__class__.__name__ == "Any"
    assert obj.__class__.__name__ == "Any"



# Generated at 2022-06-24 10:43:02.673624
# Unit test for constructor of class Boolean
def test_Boolean():
    field = Boolean()
    assert field.title == ""
    assert field.description == ""
    assert field.allow_null == False
    assert field.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert field.coerce_values == {"true": True, "false": False, "on": True, "off": False, "1": True, "0": False, "": False, 1: True, 0: False}
    assert field.coerce_null_values == {"", "null", "none"}
    assert field.has_default() == False
    assert field.get_default_value() == None
    assert field.get_error_text("type") == "Must be a boolean."
    assert field.get_error_text("null") == "May not be null."

# Unit

# Generated at 2022-06-24 10:43:06.814610
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(
        title="",
        description="",
        default=NO_DEFAULT,
        allow_null=False,
    )
    assert field.has_default() == False


# Generated at 2022-06-24 10:43:14.633358
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    errors = {'foo': 'bar'}
    # test with valid input
    f = Field(errors=errors)
    f.validation_error('foo')

    # test with error key not in dict
    f = Field(errors=errors)
    try:
        f.validation_error('nothere')
        raise AssertionError('Test failed')
    except KeyError:
        pass

    # test with empty error list
    errors = {}
    f = Field(errors=errors)
    try:
        f.validation_error('foo')
        raise AssertionError('Test failed')
    except KeyError:
        pass

# Generated at 2022-06-24 10:43:21.867501
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class FieldTest(Field):
        errors = {
            "required": "Field is required",
            "invalid": "Invalid value",
        }

        def parse_value(self, value, **kwargs):
            if value is None:
                return None
            raise ValidationError("invalid")
        def validate(self, value, **kwargs):
            return self.parse_value(value)

    field = FieldTest()
    assert field.get_error_text("required") == "Field is required"
    assert field.get_error_text("invalid") == "Invalid value"



# Generated at 2022-06-24 10:43:23.735453
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal()
    assert(d.numeric_type == decimal.Decimal)




# Generated at 2022-06-24 10:43:25.156394
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(
        title="Test Field",
        description="Test Description",
        default=1
    )
    assert f.get_default_value() == 1


# Generated at 2022-06-24 10:43:26.425752
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices = [('male', 'Male'), ('female', 'Female')])
    assert(choice is not None)



# Generated at 2022-06-24 10:43:31.429769
# Unit test for constructor of class Const
def test_Const():
    try:
        test_field = Const(10)
        assert(test_field.const == 10)
    except:
        print("Test failed")
    else:
        print("Test passed")

# Generated at 2022-06-24 10:43:36.286850
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_of = [Integer(), Object(properties={"age": Integer()})]
    # Create an union field

# Generated at 2022-06-24 10:43:40.340300
# Unit test for method validate of class String
def test_String_validate():
    test = String()
    assert test.validate('a') == 'a'
    assert test.validate('null') == 'null'
    assert test.validate(None) == None
    assert test.validate('') == ''
    assert test.validate(True) == True
    assert test.validate(False) == False


# Generated at 2022-06-24 10:43:51.525575
# Unit test for constructor of class Array
def test_Array():
    array_field = Array(items=String())
    assert array_field.items == String()
    assert array_field.min_items is None
    assert array_field.additional_items == False
    assert array_field.unique_items == False
    assert array_field.allow_null == False

    assert array_field.validate(["a", "b"]) == ["a", "b"]

    array_field = Array(items=[String(), Integer()])
    assert array_field.items == [String(), Integer()]
    assert array_field.min_items == 2
    assert array_field.additional_items == False
    assert array_field.unique_items == False
    assert array_field.allow_null == False

    assert array_field.validate(["a", 1]) == ["a", 1]

    array_

# Generated at 2022-06-24 10:43:53.364265
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field.validate(object,strict=True) == NotImplementedError

# Generated at 2022-06-24 10:43:54.649574
# Unit test for method validate of class Const
def test_Const_validate():
    test_const = Const(const=12)
    print(test_const.validate(value=12))

test_Const_validate()



# Generated at 2022-06-24 10:43:59.875252
# Unit test for constructor of class String
def test_String():
    obj1 = String()
    assert obj1.__init__.__code__.co_argcount == 7
    obj2 = String(allow_null=True, allow_blank=False, trim_whitespace=False,
                   max_length=None, min_length=None, pattern=None, format=None)
    assert obj2.__init__.__code__.co_argcount == 7


# Generated at 2022-06-24 10:44:02.936610
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(None) == None
    assert d.serialize(decimal.Decimal('1.5')) == 1.5
    assert d.serialize(decimal.Decimal('1.00')) == 1.0
    
    

# Generated at 2022-06-24 10:44:05.435535
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj = Decimal()
    assert obj.serialize(decimal.Decimal(1)) == 1
    assert obj.serialize(decimal.Decimal(10)) == 10
    assert obj.serialize(None) == None



# Generated at 2022-06-24 10:44:10.134799
# Unit test for method serialize of class Field
def test_Field_serialize():
    class Person(Schema):
        name = String(format='date-time')

    # person = {'name': 'Person'}
    person = Person(name='Person')
    person_serialized = {'name': 'Person'}
    assert person.serialize() == person_serialized
    assert Person().serialize(person) == person_serialized

# Generated at 2022-06-24 10:44:11.995689
# Unit test for constructor of class Const
def test_Const():
    const = Const(3)
    assert const.validate(3) == True

# Generated at 2022-06-24 10:44:16.043348
# Unit test for constructor of class Object
def test_Object():
    with pytest.raises(TypeError, match=r"object() takes from 0 to 2 positional arguments but 3 were given"):
        Object(1,1,1)
    assert True

if __name__ == "__main__":
    test_Object()

# Generated at 2022-06-24 10:44:20.274642
# Unit test for constructor of class String
def test_String():
    print("Testing the constructor of class String")
    t = String(allow_blank = False, trim_whitespace = True, max_length = 4, min_length = 2, pattern = "")
    print("Successfully tested the constructor of class String")


# Generated at 2022-06-24 10:44:22.947509
# Unit test for constructor of class DateTime
def test_DateTime():
    try:
        DateTime()
    except Exception:
        raise AssertionError(
            "Unexpected exception in class DateTime for constructor")



# Generated at 2022-06-24 10:44:26.623494
# Unit test for constructor of class Float
def test_Float():
    assert isinstance(Float(maximum=1.0), Number)
    assert isinstance(Float(maximum="1.0"), Number)
    assert isinstance(Float(maximum=1), Number)



# Generated at 2022-06-24 10:44:34.781494
# Unit test for constructor of class Array
def test_Array():
    Field.__init__(Array())
    Array.__init__(Array())
    Array.__init__(Array(), type=str)
    Array.__init__(Array(), items=str)
    Array.__init__(Array(), items=Array())  # noqa: B010
    Array.__init__(Array(), items=[Array()])
    Array.__init__(Array(), items=[Array()], additional_items=True)
    Array.__init__(Array(), items=[Array()], additional_items=False)
    Array.__init__(Array(), items=[Array()], additional_items=Array())  # noqa: B010
    Array.__init__(Array(), items=[Array()], min_items=0)
    Array.__init__(Array(), items=[Array()], max_items=0)

# Generated at 2022-06-24 10:44:37.671796
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():# Unit test for method serialize of class Decimal
    a = 1
    b = test_Decimal_serialize
    assert a == b

# Generated at 2022-06-24 10:44:42.938250
# Unit test for constructor of class Any
def test_Any():
    from .fields import Any
    assert Any() is not None

# Generated at 2022-06-24 10:44:47.470918
# Unit test for constructor of class Const
def test_Const():
    # Basic test
    schema = Const(123)
    result = schema.validate(123)
    assert result == 123

    # Null value
    schema = Const(None)
    result = schema.validate(None)
    assert result == None

    result = schema.validate('')
    assert result == None

    # Incorrect value
    schema = Const(123)
    result = schema.validate('Hello')
    assert result == 123

    # Incorrect value 2
    schema = Const(None)
    result = schema.validate(123)
    assert result == None

# Generated at 2022-06-24 10:44:49.003374
# Unit test for constructor of class Const
def test_Const():
    field = Const(const=2)
    assert field.validate(2) == 2


# Generated at 2022-06-24 10:44:54.122495
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="field-1", description="field-1-description", default=1, allow_null=True)
    assert field.title == 'field-1'
    assert field.description == 'field-1-description'
    assert field.default == 1
    assert field.allow_null == True


# Generated at 2022-06-24 10:44:57.137845
# Unit test for constructor of class Array
def test_Array():
    arr = Array(items=String(), min_items=1, max_items=4, unique_items=False)
    print(arr.errors)
    print(arr.validate(None))

# Generated at 2022-06-24 10:45:00.896352
# Unit test for method validate of class Number
def test_Number_validate():
    # Case 1
    a = Number()
    assert a.validate(4) == 4
    # Case 2
    a = Number()
    assert a.validate(4.2) == 4.2
    # Case 3
    a = Number()
    b = None
    assert a.validate(b) == None


# Generated at 2022-06-24 10:45:04.213993
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(allow_null=True).validate(None) == None
    assert Number(allow_null=True).validate("") == None
    assert Number(allow_null=True).validate(1) == 1
    assert Number(allow_null=True).validate(1.1) == 1.1
    assert Number.validate(None) != None



# Generated at 2022-06-24 10:45:09.242729
# Unit test for method __or__ of class Field
def test_Field___or__():
    from .fields import (
        Text, 
        Choice,
    )
    from .schema import Schema
    from .structures import Choice, Union


    class PlanetField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value
# Unit tests for method validate of class PlanetField

# Generated at 2022-06-24 10:45:13.873934
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items = Integer(), min_items = 1, max_items = 1, unique_items = True)
    assert field.validate([4]) == [4]
    assert field.validate([4, 4]) == [4, 4]
    assert field.validate([2, 0]) == [2, 0]
    assert field.validate([1, 0, -1]) == [1, 0, -1]
    assert field.validate([0, 1]) == []


# Generated at 2022-06-24 10:45:16.902572
# Unit test for constructor of class Const
def test_Const():
    const_field = Const("hello there")


# Generated at 2022-06-24 10:45:22.933177
# Unit test for method validate of class Const
def test_Const_validate():
    print('\nUnit test for method validate of class Const...')
    print('\nCase 1')
    c = Const('a')
    print(c.validate('a'))
    print('\nCase 2')
    try: c.validate(1)
    except ValidationError as e: print(e)
    print('\nCase 3')
    try: c.validate(None)
    except ValidationError as e: print(e)
    
test_Const_validate()


# Generated at 2022-06-24 10:45:28.567349
# Unit test for method validate of class Any
def test_Any_validate():
    any = Any()
    assert any.validate("test", strict=False) == "test"
    assert any.validate(1, strict=False) == 1
    assert any.validate(1.4, strict=False) == 1.4
    assert any.validate(True, strict=False) == True
    assert any.validate(None, strict=False) == None
    assert any.validate(["test", 1], strict=False) == ["test", 1]
    assert any.validate({"a": 1, "b": "test"}, strict=False) == {"a": 1, "b": "test"}


# Generated at 2022-06-24 10:45:31.334486
# Unit test for method serialize of class String
def test_String_serialize():
    a = String(format="date")
    assert a.serialize(obj="1989-08-28") == "1989-08-28"



# Generated at 2022-06-24 10:45:40.108988
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b1 = Boolean()
    value = "true"
    assert b1.validate(value) == True
    value = "false"
    assert b1.validate(value) == False
    value = "on"
    assert b1.validate(value) == True
    value = "off"
    assert b1.validate(value) == False
    value = "1"
    assert b1.validate(value) == True
    value = "0"
    assert b1.validate(value) == False
    value = ""
    assert b1.validate(value) == False
    value = 1
    assert b1.validate(value) == True
    value = 0
    assert b1.validate(value) == False
    print("Unit test for method validate of class Boolean completed")


# Generated at 2022-06-24 10:45:42.908301
# Unit test for method validate of class Choice
def test_Choice_validate():
    expected= "This field is required."
    error= Choice().validation_error('required')
    error_message = error.errors[0].message
    assert error_message == expected


# Generated at 2022-06-24 10:45:48.520907
# Unit test for constructor of class Date
def test_Date():
    test_Date = Date()
    test_Date_2 = Date(description="description")
    test_Date_3 = Date(allow_null=True)
    test_Date_4 = Date("description", True)
    assert test_Date is not None
    assert test_Date_2 is not None
    assert test_Date_3 is not None
    assert test_Date_4 is not None


# Generated at 2022-06-24 10:45:49.987363
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime(required=True) == {"type":"string","format":"datetime","required":True}


# Generated at 2022-06-24 10:45:54.372577
# Unit test for method validate of class Array
def test_Array_validate():
    # Input
    f1 = Array(items=Integer(), min_items=2, max_items=3)
    # Output
    output = f1.validate([1, 2])
    print(output)

if __name__ == "__main__":
    test_Array_validate()


# Generated at 2022-06-24 10:45:55.288920
# Unit test for method validate of class Const
def test_Const_validate():
    s=Const(const=1)
    a=s.validate(1)

# Generated at 2022-06-24 10:45:59.511420
# Unit test for constructor of class Text
def test_Text():
    txt = Text()
    txt = Text(title="Text")
    txt = Text(enum=["a", "b", "c"])
    txt = Text(min_length=3)
    txt = Text(max_length=3)
    txt = Text(min_length=3, max_length=3)
    txt = Text(min_length=3, max_length=3, pattern="\d{3}")
    txt = Text(min_length=3, max_length=3, pattern="\d{3}", enum=["123"])
    txt = Text(title="Text", description="Description", default="abc")
    txt = Text(title="Text", description="Description", default="abc", enum=["abc"])



# Generated at 2022-06-24 10:46:02.227236
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field(default="something").has_default()
    assert not Field().has_default()
    assert Field(default=NO_DEFAULT).has_default()

# Generated at 2022-06-24 10:46:05.936915
# Unit test for method serialize of class Field
def test_Field_serialize():
    import copy
    field = Field(title='TestField', description='Field to test the serialization', default=10)
    assert field.serialize(0) == 0
    #assert field.serialize(field) == field
    assert field.serialize(field) == copy.deepcopy(field)

# Generated at 2022-06-24 10:46:12.487923
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(1, 2, 3)
    assert len(array.validate([1, 2, 3])) == 3

    try:
        array.validate([4, 2, 3])
    except ValidationError:
        assert True
    else:
        assert False

    items = Array(items=Integer(100, 200))
    array = Array(items=[1, 2, items])
    try:
        array.validate([1, 2, [100, 200]])
    except ValidationError:
        assert True
    else:
        assert False

    array = Array(items=[1, 2, items])
    assert len(array.validate([1, 2, [101, 201]])) == 3

    array = Array(items=[1, 2, items])

# Generated at 2022-06-24 10:46:23.695759
# Unit test for constructor of class Array
def test_Array():
    assert Array().items is None
    assert Array().additional_items is False
    assert Array().min_items is None
    assert Array().max_items is None
    assert Array().unique_items is False

    assert Array(min_items=1).min_items == 1
    assert Array(min_items=1).max_items is None
    assert Array(min_items=1).unique_items is False

    assert Array(max_items=1).min_items is None
    assert Array(max_items=1).max_items == 1
    assert Array(max_items=1).unique_items is False

    assert Array(exact_items=1).min_items == 1
    assert Array(exact_items=1).max_items == 1
    assert Array(exact_items=1).unique_items is False

    assert Array

# Generated at 2022-06-24 10:46:32.877676
# Unit test for constructor of class Field
def test_Field():
    field1 = Field(title = "Test Field", description = "Test Field Description", default = 5, allow_null = False)
    assert field1.title == "Test Field"
    assert field1.description == "Test Field Description"
    assert field1.default == 5
    assert field1.allow_null == False
    
    field2 = Field(title = "Test Field", description = "Test Field Description", default = 5, allow_null = True)
    assert field2.title == "Test Field"
    assert field2.description == "Test Field Description"
    assert field2.default == None
    assert field2.allowed_null == True
    

# Generated at 2022-06-24 10:46:36.669243
# Unit test for constructor of class String
def test_String():
    assert String(title="Title", description="description", allow_blank=False, trim_whitespace=True, \
                  max_length=None, min_length=None, pattern=None, format="format") is not None


# Generated at 2022-06-24 10:46:41.404168
# Unit test for constructor of class Any
def test_Any():
    obj = Any()
    assert obj.allow_null == False, "Allow null should be set to false."
    assert obj.title == None, "Default title should be None."
    assert obj.description == None, "Default description should be None."
    assert obj.default == None, "Default default should be None."



# Generated at 2022-06-24 10:46:44.666288
# Unit test for constructor of class Array
def test_Array():
    field = Array(title= "My Array ", description= "My description ", items=Any(), additionalItems=Any(), minItems=2, maxItems=3, uniqueItems=False)
    assert field.title == "My Array "
    assert field.description == "My description "



# Generated at 2022-06-24 10:46:49.499997
# Unit test for constructor of class Boolean
def test_Boolean():
    bool = Boolean()
    assert bool.validate(True) == True
    assert bool.validate(False) == False
    assert bool.validate(None) == None
    assert bool.validate(1) == True
    assert bool.validate(0) == False



# Generated at 2022-06-24 10:46:50.306566
# Unit test for method validate of class Union
def test_Union_validate():
    pass

# Generated at 2022-06-24 10:46:56.791394
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean(allow_null=False)
    assert b.allow_null == False
    assert b.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert b.coerce_values == {"true": True, "false": False, "on": True, "off": False, "1": True, "0": False, "": False, 1: True, 0: False}
    assert b.coerce_null_values == {"", "null", "none"}


# Generated at 2022-06-24 10:47:04.273041
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class C(Field):
        errors = {
            "invalid": "is invalid",
        }
        
        def validate(self, value, *, strict):
            if value == "abc":
                return "abc"
            raise self.validation_error(code="invalid")

    c = C()
    value = c.validate_or_error(value="abc")
    assert value.value == 'abc'
    value = c.validate_or_error(value="xyz")
    assert value.error.code == 'invalid'

# Generated at 2022-06-24 10:47:14.827378
# Unit test for constructor of class Array
def test_Array():
    array1 = Array(items=[])
    array2 = Array(items=Float(default=0.0))
    array3 = Array(items=Array(items=[],default=[]))
    array4 = Array(items=[Float(default=0.0),String(default='default')])
    array5 = Array(items=[],default=[])
    array6 = Array(items=Integer(default=0),default=[])
    array7 = Array(items=[Float(default=0.0),Integer(default=0),String(default='default'),Bool(default=False)])
    array8 = Array(items=[Float(default=0.0),Array(items=[],default=[])])
    array9 = Array(items=[Float(default=0.0),Array(items=[],default=[]),String(default='default')])
    array10

# Generated at 2022-06-24 10:47:16.542172
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field(title = "a" , description = "b", default = "c", allow_null = True)
    assert f.has_default() == True


# Generated at 2022-06-24 10:47:23.301167
# Unit test for constructor of class Boolean
def test_Boolean():
    field = Boolean(allow_null=True)
    assert field.validate(True) 
    assert field.validate(False) 
    assert field.validate(None)
    assert field.validate_or_error(True) 
    assert field.validate_or_error(False) 
    assert field.validate_or_error(None)

test_Boolean()



# Generated at 2022-06-24 10:47:31.488785
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format = 'date').serialize('07/04/2020') == '2020-07-04'
    assert String(format = 'time').serialize('15:00:00') == '15:00:00'
    assert String(format = 'datetime').serialize('07/04/2020 15:00:00') == '2020-07-04T15:00:00'
    assert String(format = 'uuid').serialize('f16ffaab-dd88-4d9b-8b43-e18fbb6b2c6d') == 'f16ffaab-dd88-4d9b-8b43-e18fbb6b2c6d'



# Generated at 2022-06-24 10:47:42.347667
# Unit test for constructor of class Array
def test_Array():
    arr = Array()

    assert arr.default_value == []
    assert arr.allow_null == False
    assert arr.items is None
    assert arr.additional_items is False
    assert arr.min_items is None
    assert arr.max_items is None
    assert arr.unique_items is False

    arr = Array(default_value = "test", allow_null = True,
    items = Integer(), additional_items = True, min_items = 5, max_items = 15, unique_items = True)

    assert arr.default_value == "test"
    assert arr.allow_null == True
    assert isinstance(arr.items, Integer)
    assert arr.additional_items is True
    assert arr.min_items == 5
    assert arr.max_items == 15
    assert arr.unique_items == True


# Generated at 2022-06-24 10:47:52.622762
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union([]).validate(None) is None
    assert Union([Any()]).validate("foo") == "foo"
    with pytest.raises(ValidationError):
        Union([Any()]).validate(None)

    assert Union([Any(), NoneField()]).validate("foo") == "foo"
    with pytest.raises(ValidationError):
        Union([String(), NoneField()]).validate("foo")

    assert Union([String(), NoneField()]).validate(None) is None
    with pytest.raises(ValidationError):
        Union([String(), NoneField()]).validate("foo")

    assert Union([String(), Any()]).validate("foo") == "foo"
    assert Union([String(), Any()]).validate(None) is None

# Generated at 2022-06-24 10:48:02.759019
# Unit test for method validate of class String
def test_String_validate():
    from typesystem.types import String
    from typesystem.exceptions import ValidationError
    s = String(max_length=4, min_length=2, pattern="^A[a-z]{2}", format="time")
    # Testing String(..., pattern='^A[a-z]{2}')
    # Success case
    try:
        assert s.validate("Abc") == "Abc"
        print("Successful input: " + "Abc")
    except ValidationError as e:
        print(repr(e))
    
    # Failure case
    try:
        s.validate("Ab")
        print("Successful input: " + "Ab")
    except ValidationError as e:
        print(repr(e))
    
    # Failure case

# Generated at 2022-06-24 10:48:11.459018
# Unit test for constructor of class DateTime
def test_DateTime():
    assert(str(DateTime())==str("<DateTime(format='datetime', nullable=True)>"))
    assert(str(DateTime(nullable= False))==str("<DateTime(format='datetime', nullable=False)>"))
    assert(str(DateTime(nullable=False, default="1985-04-12T23:20:50.52"))==str("<DateTime(format='datetime', nullable=False, default='1985-04-12T23:20:50.52')>"))



# Generated at 2022-06-24 10:48:13.121127
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    schema = Field()
    print(schema.validate_or_error(1))
    print(schema.validate_or_error(object))


# Generated at 2022-06-24 10:48:23.527459
# Unit test for method validate of class Array

# Generated at 2022-06-24 10:48:29.414528
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    try:
        field.validate(1)
        field.validate(True)
        field.validate([])
        field.validate('')
        field.validate('Hello')
        field.validate({})
        field.validate({'key': 'value'})
    except ValidationError as e:
        assert(False)
    else:
        assert(True)



# Generated at 2022-06-24 10:48:34.592219
# Unit test for method __or__ of class Field
def test_Field___or__():
    class BooleanField1(Field):
        def validate(self, value: bool, *, strict: bool = False):
            return value

    class BooleanField(Field):
        def validate(self, value: bool, *, strict: bool = False):
            return value

    class BooleanField2(Field):
        def validate(self, value: bool, *, strict: bool = False):
            return value

    assert BooleanField1() | BooleanField() | BooleanField2() is not None

