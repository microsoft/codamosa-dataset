

# Generated at 2022-06-24 10:38:35.057974
# Unit test for constructor of class Const
def test_Const():
    Const(const=1)


# Generated at 2022-06-24 10:38:42.021073
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Setup
    def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
        return 1
    Field.validate = validate
    args = {
        'value': 2,
        'strict': True,
    }

    # Exercise
    ret = Field.validate_or_error(**args)

    # Verify
    assert ret == ValidationResult(value=1, error=None)

# Generated at 2022-06-24 10:38:47.250583
# Unit test for method validate of class Number
def test_Number_validate():
    # Number - Integer
    assert Number(multiple_of=5).validate(value=15) == 15
    assert Number.validate(value=15) == 15
    assert Number().validate(value=15) == 15
    assert Number().validate(value=12) == 12
    assert Number().validate(value='12') == 12
    with pytest.raises(ValidationError):
        Number().validate(value=12.6)
    with pytest.raises(ValidationError):
        Number().validate(value='12.6')
    with pytest.raises(ValidationError):
        Number().validate(value=None)

    # Number - Float
    assert Number().validate(value=12.6) == 12.6
    assert Number().validate(value='12.6') == 12.6

# Generated at 2022-06-24 10:38:52.329091
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class MyField(Field):
        def validate(self, value, *, strict=False):
            if value == 5:
                return value
            raise ValidationError('Validation error')
    field = MyField()
    assert field.validate_or_error(5, strict=True) == ValidationResult(value=5, error=None)
    assert field.validate_or_error(4, strict=True) == ValidationResult(value=None, error=ValidationError('Validation error'))



# Generated at 2022-06-24 10:38:59.128237
# Unit test for method serialize of class Array
def test_Array_serialize():
    a = Array()
    assert a.serialize([1,2,3]) == [1,2,3]

    b = Array(items=Integer())
    assert b.serialize([1,2,3]) == [1,2,3]

    c = Array(items=[String(), Integer()])
    assert c.serialize(['abc',1]) == ['abc',1]

# Generated at 2022-06-24 10:39:01.172776
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolobj=Boolean()
    result=boolobj.validate(None)
    assert result is None

# Generated at 2022-06-24 10:39:02.928038
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert isinstance(Field.get_error_text(code=""), str)


# Generated at 2022-06-24 10:39:12.143880
# Unit test for constructor of class Number
def test_Number():
    assert Number.errors["type"] == "Must be a number."
    assert Number.errors["null"] == "May not be null."
    assert Number.errors["integer"] == "Must be an integer."
    assert Number.errors["finite"] == "Must be finite."
    assert Number.errors["minimum"] == "Must be greater than or equal to {minimum}."
    assert Number.errors["exclusive_minimum"] == "Must be greater than {exclusive_minimum}."
    assert Number.errors["maximum"] == "Must be less than or equal to {maximum}."
    assert Number.errors["exclusive_maximum"] == "Must be less than {exclusive_maximum}."
    assert Number.errors["multiple_of"] == "Must be a multiple of {multiple_of}."



# Generated at 2022-06-24 10:39:15.598850
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    f = Field()
    error = f.validation_error('error_code')
    assert type(error) == ValidationError


# Generated at 2022-06-24 10:39:22.618994
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestSchema:
        test_field = Field(format='test')
        test_field_error = Field(format='test')
        test_field_error.errors = {'test':'test error'}
        test_field_error.validate = Mock(side_effect=ValidationError('test error'))

    x = TestSchema.test_field.validate_or_error(Mock(), strict='strict')
    assert x.value == Mock()

    assert TestSchema.test_field_error.validate_or_error(Mock(), strict='strict').error.text == 'test error'


# Generated at 2022-06-24 10:39:29.012826
# Unit test for method __or__ of class Field
def test_Field___or__():
    field1 = Integer()
    field2 = Boolean()
    union = field1 | field2
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]
    field3 = Integer()
    field4 = Boolean()
    union2 = field3 | field4
    field5 = Integer()
    union3 = field1 | union2 | field5
    assert isinstance(union3, Union)
    assert union3.any_of == [field1, field3, field4, field5]



# Generated at 2022-06-24 10:39:32.039034
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    value = 1
    res = field.validate_or_error(value)
    assert res.value == value
    assert res.error == None

# Generated at 2022-06-24 10:39:34.720516
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Field(title="t", description="d", default=NO_DEFAULT, allow_null=False)
    assert f.serialize("T") == "T"



# Generated at 2022-06-24 10:39:42.718108
# Unit test for method serialize of class Array
def test_Array_serialize():
    from datetime import datetime

    obj = [datetime(1900,1,1),datetime(2021,1,1)]
    items = [DateTime(), DateTime()]
    arry = Array(items=items)
    ret = arry.serialize(obj)
    assert ret == ["1900-01-01T00:00:00","2021-01-01T00:00:00"]

    obj = [1,2,3]
    arry = Array(items=Integer())
    ret = arry.serialize(obj)
    assert ret == [1,2,3]



# Generated at 2022-06-24 10:39:53.531536
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.fields import *
    import unittest.mock

    mock_validate = unittest.mock.Mock(return_value=True)
    mock_strict = unittest.mock.Mock(return_value=False)


    def mock_init(**kwargs):
        return

    with unittest.mock.patch('typesystem.fields.Field.__init__', new=mock_init):
        field = Field(title='', description='', default=NO_DEFAULT, allow_null=False)
        assert field.validate_or_error(1, strict=mock_strict) == ValidationResult(value=True, error=None)



# Generated at 2022-06-24 10:39:59.047918
# Unit test for method validate of class Any
def test_Any_validate():
    anyval = Any()
    # Check an integer
    val = 1
    expected = val
    assert_test(anyval, val, expected)
    # Check a list
    val = [1,2,3]
    expected = val
    assert_test(anyval, val, expected)
    # Check a dict
    val = {'a':1, 'b':2, 'c':3}
    expected = val
    assert_test(anyval, val, expected)
    # Check a string
    val = 'a string'
    expected = val
    assert_test(anyval, val, expected)
    # Check a float
    val = 1.0
    expected = val
    assert_test(anyval, val, expected)
    # Check None
    val = None
    expected = val

# Generated at 2022-06-24 10:40:07.472416
# Unit test for method validate of class Array
def test_Array_validate():
    a=Array()
    a.validate([])
    a.validate(None)
    a.validate([1,2,3,"4"])

    # Test unique_items = True, unique_items = False
    b=Array(unique_items=True)
    b.validate([1,2,3,4])

    with pytest.raises(ValidationError):
        b.validate([1,2,3,4,4])

    b.validate([1,2,3,4],strict=False)
    b.validate([1,2,3,4],strict=True)

    b=Array(unique_items=False)
    b.validate([1,2,3,4,4])
    b.validate([1,2,3,4],strict=True)

# Generated at 2022-06-24 10:40:12.113102
# Unit test for constructor of class Field
def test_Field():
    f1 = Field(title="Title", description="Description", default=True, allow_null=True)
    assert f1.title == "Title"
    assert f1.description == "Description"
    assert f1.default == True
    assert f1.allow_null == True


# Generated at 2022-06-24 10:40:14.023241
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert isinstance(f, Number)
    assert (f.numeric_type == float)


# Generated at 2022-06-24 10:40:15.480695
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    value = "abc"
    assert field.validate(value, strict = False) == "abc"
    value = 123
    assert field.validate(value, strict = False) == 123



# Generated at 2022-06-24 10:40:16.676050
# Unit test for constructor of class Text
def test_Text():
    assert Text().format == "text"



# Generated at 2022-06-24 10:40:20.998493
# Unit test for constructor of class Union
def test_Union():
    with pytest.raises(AssertionError):
        Union([1, 2])
        
    a = Union([String()])
    assert a.validate("hello world") == "hello world"
    with pytest.raises(ValidationError):
        a.validate(12)
    with pytest.raises(ValidationError):
        a.validate(None)

    @validator()
    def validator1(value):
        return value + 1

    a = Union([String(), validator1])
    assert a.validate("hello world") == "hello world"
    with pytest.raises(ValidationError):
        a.validate(12)
    assert a.validate(13) == 14
    with pytest.raises(ValidationError):
        a.validate(None)



# Generated at 2022-06-24 10:40:23.578955
# Unit test for constructor of class Union
def test_Union():
    s = String()
    n = Number()
    b = Boolean()
    u = Union([s, n, b])
    u.validate('hello')
    u.validate(1)
    u.validate(True)
    try:
        u.validate(1.1)
    except ValidationError:
        pass
    assert b.allow_null
    assert s.allow_null
    assert n.allow_null
    assert u.allow_null

# Generated at 2022-06-24 10:40:28.647994
# Unit test for constructor of class Number
def test_Number():
    assert Number().__dict__ == {'allow_null': False, '_creation_counter': 0, 'minimum': None, 'maximum': None, 'exclusive_minimum': None, 'exclusive_maximum': None, 'multiple_of': None, 'precision': None, 'numeric_type': None, 'errors': {'type': 'Must be a number.', 'null': 'May not be null.', 'integer': 'Must be an integer.', 'finite': 'Must be finite.', 'minimum': 'Must be greater than or equal to {minimum}.', 'exclusive_minimum': 'Must be greater than {exclusive_minimum}.', 'maximum': 'Must be less than or equal to {maximum}.', 'exclusive_maximum': 'Must be less than {exclusive_maximum}.', 'multiple_of': 'Must be a multiple of {multiple_of}.'}}



# Generated at 2022-06-24 10:40:41.503383
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Integer(),
        additional_items=Integer(),
        min_items=3,
        max_items=5,
        unique_items=True,
    )
    assert field.validate([0, 0, 0]) == [0, 0, 0]
    assert field.validate([0, 0, 0, 1, 2]) == [0, 0, 0, 1, 2]
    assert field.validate([0, 0, 0, 1, 2, 3]) == [0, 0, 0, 1, 2, 3]


# Generated at 2022-06-24 10:40:44.507435
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class TestField(Field):
        errors={'code1': 'error1'}

    testField = TestField()
    testField.get_error_text("code1")
test_Field_get_error_text()



# Generated at 2022-06-24 10:40:45.240421
# Unit test for constructor of class Date
def test_Date():
    dat = Date()
    print(type(dat))
    print(dat)


# Generated at 2022-06-24 10:40:47.052369
# Unit test for method serialize of class Field
def test_Field_serialize():
	value = Field(type="int", allow_null=False)
	assert value.serialize("324") == 324

# Generated at 2022-06-24 10:40:58.162487
# Unit test for method validate of class Union
def test_Union_validate():
    if __name__ == "__main__":
        from datetime import datetime

    class Event:
        def __init__(self, date: datetime) -> None:
            self.date = date

    class Date(String):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(
                format="date",
                description="A date such as 2019-02-21.",
                **kwargs
            )

    class DateTime(String):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(
                format="datetime",
                description="An ISO 8601 formatted date time string.",
                **kwargs
            )

    event_schema = Union(any_of=[Date(), DateTime()])
    event_sche

# Generated at 2022-06-24 10:41:02.037135
# Unit test for constructor of class String
def test_String():
    a = String('This is a string field', 'This is a string field', 'This is the description field', '12', True, '12', '12', False, True, '12', '12', '12', '12', '12')
    print(a.__dict__)


# Generated at 2022-06-24 10:41:06.199428
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_obj = Decimal(default=0)
    assert decimal_obj.serialize(None) == None
    assert decimal_obj.serialize(0) == 0
    assert decimal_obj.serialize(10) == 10
    assert decimal_obj.serialize(10.5) == 10.5


# Generated at 2022-06-24 10:41:10.469721
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(name='a', choices=[('c', 'c')])
    c.validate('c')
    c.validate('d')
    assert(c.allow_null == False)

# Generated at 2022-06-24 10:41:11.957063
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.format == 'date'
    print('The constructor of class Date works')


# Generated at 2022-06-24 10:41:18.849314
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(minimum = -5.5, maximum = 5.5, precision = '0.2', multiple_of = 0.4).__dict__ == {'title': '', 'description': '', 'allow_null': False, 'minimum': Decimal('-5.5'), 'maximum': Decimal('5.5'), 'exclusive_minimum': None, 'exclusive_maximum': None, 'precision': '0.2', 'multiple_of': Decimal('0.4'), 'numeric_type': decimal.Decimal, '_creation_counter': Decimal._creation_counter}


# Generated at 2022-06-24 10:41:23.234124
# Unit test for constructor of class Object
def test_Object():
    field = Object()
    assert field.properties == {}
    assert field.pattern_properties == {}
    assert field.additional_properties is True
    assert field.property_names is None
    assert field.min_properties is None
    assert field.max_properties is None
    assert field.required == []


# Generated at 2022-06-24 10:41:31.698269
# Unit test for constructor of class Array
def test_Array():
    assert Array().validate([]) == []
    assert Array().validate([[], {}]) == [[], {}]

    field = Array()
    assert field.validate([]) == []
    assert field.validate([[], {}]) == [[], {}]

    # allow_null=False
    with pytest.raises(ValidationError):
        assert field.validate(None)

    field = Array(allow_null=True)
    assert field.validate(None) is None

    field = Array(items=String())
    assert field.validate(["1", "2", "3", "4"]) == ["1", "2", "3", "4"]
    assert field.validate(None) is None

    # min_items=1, max_items=3, unique_items=True

# Generated at 2022-06-24 10:41:37.869193
# Unit test for constructor of class Field
def test_Field():
    field1 = Field()
    assert field1._creation_counter == 0
    assert field1.title == ""
    assert field1.description == ""

    field2 = Field(title="title", description="field description")
    assert field2._creation_counter == 1
    assert field2.title == "title"
    assert field2.description == "field description"



# Generated at 2022-06-24 10:41:39.420099
# Unit test for method __or__ of class Field
def test_Field___or__():
    pass

    # Tests for attribute errors of class Field

# Generated at 2022-06-24 10:41:41.922796
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[(1, '2'),(2,'3'),(3,'4')])

# Tests for method validate of class Choice

# Generated at 2022-06-24 10:41:45.413955
# Unit test for constructor of class Const
def test_Const():
    fn = Const(1)
    assert isinstance(fn, Const)
    assert fn.validate(1) == 1
    assert fn.serialize(1) == 1
    assert fn.const == 1

# Generated at 2022-06-24 10:41:48.420968
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('q', 'q'), ('w', 'w')])
    choice.validate('q')
    choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate('r')
    with pytest.raises(ValidationError):
        choice.validate('')

# Generated at 2022-06-24 10:41:51.782185
# Unit test for method validate of class Any
def test_Any_validate():
  obj = Any()
  obj.validate(3)
  obj.validate(None)
  assert True




# Generated at 2022-06-24 10:41:57.578849
# Unit test for method validate of class Array
def test_Array_validate():
  a = Array(items = STRING)
  #obj = ['aaa','bbb','ccc','ddd']
  #assert a.validate(obj) == obj
  #msg = "Expected result is '['aaa','bbb','ccc','ddd']', actual result is None"
  #assert a.validate(obj) == obj, msg

  obj = ["aaa"]
  assert a.validate(obj) == obj

  a = Array(items=STRING)
  obj = []
  assert a.validate(obj) == obj

  a = Array(items=STRING)
  obj = ["aaa"]
  assert a.validate(obj) == obj


# Generated at 2022-06-24 10:42:02.073331
# Unit test for method __or__ of class Field
def test_Field___or__():
    none_ = None
    assert none_ is none_
    assert none_ is None
    assert (Field() | Field()) is not none_
    assert (Field() | Field()) is not None
    assert isinstance((Field() | Field()), Union)


# Generated at 2022-06-24 10:42:08.433927
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert isinstance(f, Field) == True
    assert f.has_default() == False
    def foo(x, y):
        return x + y
    f = Field(default=foo(1, 2))
    assert f.has_default() == True
    assert f.get_default_value() == 3
    assert isinstance(f.validation_error("required"), ValidationError) == True
    assert f.get_error_text("required") == "This field is required."



# Generated at 2022-06-24 10:42:10.253965
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    with pytest.raises(NotImplementedError):
        assert f.validate(1)


# Generated at 2022-06-24 10:42:14.015353
# Unit test for method validate of class String
def test_String_validate():
    string_field = String(max_length=5)
    assert string_field.validate('abcde') == 'abcde'
    assert string_field.validate('abcdef') == None
    assert string_field.validate(123) == None
    assert string_field.validate(None) == None

# Generated at 2022-06-24 10:42:16.988483
# Unit test for constructor of class Field
def test_Field():
    a = Field(title="A", description="description")
    # The following should pass if the class Field runs properly
    assert a.title == "A"
    assert a.description == "description"
    assert a.allow_null == False
    assert a.has_default() == False



# Generated at 2022-06-24 10:42:19.279458
# Unit test for constructor of class Date
def test_Date():
    test = Date()
    assert test.format == "date"
    



# Generated at 2022-06-24 10:42:27.282382
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Define a array field and validate value against it.
    items = [
        Integer(
            description="Some arbitrary number",
            minimum=1,
            maximum=10,
        )
    ]
    field = Array(
        description="An array of integers",
        items=items,
        min_items=1,
        max_items=10
    )
    value, errors = field.deserialize_or_error([1, 2, 3])
    # Check if serialized value is according to our items
    serialized_value = field.serialize(value)
    print(serialized_value)


# Generated at 2022-06-24 10:42:29.623583
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal(default=decimal.Decimal(1))
    assert d.serialize(decimal.Decimal(1)) == 1.0



# Generated at 2022-06-24 10:42:40.177179
# Unit test for method validate of class Object
def test_Object_validate():
    import typing
    import pytest
    from pydantic.dataclasses import dataclass
    from pydantic import BaseModel, ValidationError

    class MyModel(BaseModel):
        class Config:
            arbitrary_types_allowed = True
        properties: typing.Optional[typing.Dict[str, typing.Any]] = None

    assert MyModel(properties={'a': 1, 'b': 2}).properties == {'a': 1, 'b': 2}

    # str representation of dict
    assert MyModel(properties="{'a': 1, 'b': 2}").properties == {'a': 1, 'b': 2}

    # dict with invalid str keys
    with pytest.raises(ValidationError):
        MyModel(properties={1: 1}).properties


# Generated at 2022-06-24 10:42:43.278549
# Unit test for method validate of class Const
def test_Const_validate():
    expected = {
        "only_null": "Must be null.",
        "const": "Must be the value '{const}'."
    }

    const_field = Const(const=1)
    assert const_field.validate(value=1) == 1
    with pytest.raises(ValidationError) as exc_info:
        const_field.validate(value=2)
        assert exc_info.value.messages[0].code == 'const'
        assert exc_info.value.messages[0].text == 'Must be the value \'1\'.'



# Generated at 2022-06-24 10:42:46.821874
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    expected_value = "Value is not a multiple of {}".format(9)
    actual_value = Field().get_error_text("invalid_multiple")
    assert actual_value == expected_value



# Generated at 2022-06-24 10:42:57.705197
# Unit test for method validate of class Array
def test_Array_validate():
    items = [Length(min_length=1)]
    schema1 = Array(items=items)
    schema2 = Array(items=None)
    schema3 = Array(items=[Length(min_length=1), Length(min_length=2)])
    test1 = ["1", "2", "3"]
    test2 = ["", "", ""]
    test3 = ["1", "2"]
    test4 = ["1", "2", "3", "4", "5"]
    print(schema1.validate(test1))
    print(schema2.validate(test1))
    print(schema3.validate(test1))
    try:
        schema1.validate(test2)
        print(False)
    except ValidationError:
        print(True)

# Generated at 2022-06-24 10:43:02.628114
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(
        items=Integer(),
        min_items=2,
        max_items=3,
        unique_items=True,
    )
    data = [1, 2, 3]
    validated_data, _ = schema.validate_or_error(data)
    assert validated_data == data, validated_data

##test_Array_validate()



# Generated at 2022-06-24 10:43:12.307251
# Unit test for constructor of class String
def test_String():
    s = String(default='foo')
    assert s.has_default()
    assert s.get_default_value() == 'foo'

    s = String(default=None)
    assert s.has_default()
    assert s.get_default_value() == None

    s = String()
    assert not s.has_default()

    s = String(default=NO_DEFAULT)
    assert not s.has_default()

    s = String(default=lambda: "foo")
    assert s.has_default()
    assert s.get_default_value() == 'foo'

test_String()


# Generated at 2022-06-24 10:43:13.942662
# Unit test for method validate of class Number
def test_Number_validate():
    # Test for valid value
    assert Number().validate(1) == 1


# Generated at 2022-06-24 10:43:17.191136
# Unit test for constructor of class Time
def test_Time():
    field = Time(example="this is my example")
    assert field.example == "this is my example"
    assert field.format == "time"
    assert field.required is False
    assert field.allow_null is True


# Generated at 2022-06-24 10:43:23.987758
# Unit test for method validate of class Array
def test_Array_validate():
    items = [Integer(), Integer(), Integer()]
    array = Array(items=items, additional_items=False)

    array.validate([1, 2, 3])

    with pytest.raises((ValidationError, InvalidTypeError)):
        array.validate([1, 2, 3, 4])

    with pytest.raises((ValidationError, InvalidTypeError)):
        array.validate([1, 2, 3.1])

    with pytest.raises((ValidationError, InvalidTypeError)):
        array.validate([1, 2, None])

    with pytest.raises((ValidationError, InvalidTypeError)):
        array.validate([1, 2])

    with pytest.raises((ValidationError, InvalidTypeError)):
        array.validate([1, 2, 3, 4])

# Generated at 2022-06-24 10:43:31.839588
# Unit test for constructor of class Number
def test_Number():
    obj = Number(title="title", description="description", allow_null=False, minimum=0, maximum=10, exclusive_minimum=0, exclusive_maximum=10, precision="1/4", multiple_of=4)
    assert obj.validate(1) == 1
    assert obj.validate(1.1) == 1.0
    assert obj.validate(11) == ValidationResult(value=None, error=ValidationError(code='maximum', text='Must be less than 10.'))
    assert obj.serialize(1) == 1


# Generated at 2022-06-24 10:43:36.463073
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean()
    assert boolean.allow_null == False
    assert boolean.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
    }
    assert boolean.coerce_null_values == {"", "null", "none"}



# Generated at 2022-06-24 10:43:43.176148
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with a valid value
    valid_test_value = "Valid"
    test_union = Union([String()])
    try:
        validated_value = test_union.validate(valid_test_value)
        assert validated_value == valid_test_value
    except ValidationError:
        assert False
    
    # Test value with None
    test_union = Union([String()], allow_null=True)
    try:
        validated_value = test_union.validate(None)
        assert validated_value is None
    except ValidationError:
        assert False
    
    # Due to the Null check, there is no need to test the Validation Error cases
    
    
    
    

# Generated at 2022-06-24 10:43:51.998002
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test = Boolean()
    assert test.validate(True, strict=True) == True
    assert test.validate(False, strict=False) == False
    assert test.validate(1, strict=False) == True
    assert test.validate(0, strict=False) == False
    assert test.validate("", strict=False) == False
    assert test.validate("1", strict=False) == True
    assert test.validate("0", strict=False) == False
    assert test.validate("true", strict=False) == True
    assert test.validate("false", strict=False) == False
    assert test.validate("on", strict=False) == True
    assert test.validate("off", strict=False) == False
    
# Test for method serialize of class Boolean

# Generated at 2022-06-24 10:43:54.994396
# Unit test for method validate of class Union
def test_Union_validate():
    import pytest
    from pydantic import BaseModel

    class Model(BaseModel):
        a: Union[int, str]
        b: Union[int, str] = 'hello'

    with pytest.raises(TypeError):
        Model(a=1.0)

# Generated at 2022-06-24 10:43:56.441203
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_val = Decimal()
    assert decimal_val is not None


# Generated at 2022-06-24 10:43:59.393085
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None

    field.default = "hello"
    assert field.get_default_value() == "hello"


# Generated at 2022-06-24 10:44:03.337647
# Unit test for constructor of class Union
def test_Union():
    U = Union([Integer(), Number()], allow_null=True)
    assert U.allow_null
    assert U.any_of == [Integer(), Number()]
    assert U.errors == {"null": "May not be null.", "union": "Did not match any valid type."}

# Generated at 2022-06-24 10:44:09.897690
# Unit test for constructor of class Float
def test_Float():
    #Test if the Float class correctly prevents invalid parameters.
    try:
        a = Float(minimum=0.0, maximum=1.1, exclusive_minimum='0', exclusive_maximum='0.5', multiple_of='0.5', precision='0.1')
    except TypeError:
        pass #correct behavior
    try:
        a = Float(minimum=0.0, maximum=1.1, exclusive_minimum=2, exclusive_maximum=0.5, multiple_of='0.5', precision='0.1')
    except TypeError:
        pass #correct behavior
    try:
        a = Float(minimum=0.0, maximum=1.1, exclusive_minimum=0, exclusive_maximum='0.5', multiple_of=0.5, precision='0.1')
    except TypeError:
        pass #correct behavior


# Generated at 2022-06-24 10:44:21.547521
# Unit test for constructor of class Object
def test_Object():
    class testObject(Object):
        name : str = Property(description="Property name description",const=False)
        testField : Field = Property(description="Field description", schema=Object, const=False)
        class testClass(Object):
            name : str = Property(description="Property name description",const=False)
            value : str = Property(description="Property value description",const=False)
        testClass : testClass = Property(description="Class Description", schema=testClass, const=False)

    obj = testObject()
    # assert isinstance(obj, Field)
    # assert isinstance(obj, Object)
    assert isinstance(obj.name, Property)
    assert isinstance(obj.testField, Property)
    assert isinstance(obj.testClass, Property)
    assert isinstance(obj.testClass.name, Property)
   

# Generated at 2022-06-24 10:44:29.230170
# Unit test for method validate of class String
def test_String_validate():
    # Test String.validate method
    
    # Test simple String type
    s = String()
    assert s.validate("Hello World!") == "Hello World!"
    assert s.validate(None) == None
    assert s.validate("") == ""
    
    # Test String type with disallow blank string
    s = String(allow_blank=False)
    assert s.validate("Hello World!") == "Hello World!"
    assert s.validate(None) == None
    assert s.validate("") == None
    
    

# Generated at 2022-06-24 10:44:32.619947
# Unit test for constructor of class Union
def test_Union():
    try:
        Union(3)
        assert False
    except TypeError:
        assert True
    try:
        # any_of is not a list of Field type
        Union([1])
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 10:44:43.846533
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=String(),
        additional_items=Boolean(),
        min_items=1,
        max_items=3,
        unique_items=True,
        allow_null=True,
    )
    value = ["123", "", "abcd", "True"]
    validated = field.validate(value)
    if validated != value:
        raise ValueError
    field = Array(
        items=String(),
        additional_items=Boolean(),
        min_items=1,
        max_items=3,
        unique_items=True,
        allow_null=False,
    )
    value = ["123", "", "abcd", "True"]
    with pytest.raises(ValidationError):
        field.validate(value)

# Generated at 2022-06-24 10:44:52.608303
# Unit test for constructor of class String
def test_String():
    # string = "hello"
    # match = re.search(r'\d+\s\w+\s', string)
    # print(match)
    pattern = re.compile(r'test')
    field = String(pattern = pattern)
    print(field.pattern)
    print(field.pattern_regex)



# Generated at 2022-06-24 10:45:00.821595
# Unit test for method validate of class Field
def test_Field_validate():
    from typesystem.base import Field
    from typesystem.base import ValidationError
    from typesystem.base import ValidationResult
    from typesystem.base import Message
    from typesystem.base import ValidationError
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Uniqueness
    from typesystem.unique import Un

# Generated at 2022-06-24 10:45:05.428835
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime().__class__ == DateTime
    assert DateTime(required=True).__class__ == DateTime
    assert DateTime(required=False).__class__ == DateTime
    assert DateTime(required=True, allow_null=False).__class__ == DateTime
    assert DateTime(required=True, allow_null=True).__class__ == DateTime
    assert DateTime(required=False, allow_null=False).__class__ == DateTime
    assert DateTime(required=False, allow_null=True).__class__ == DateTime
    assert DateTime(allow_null=False).__class__ == DateTime
    assert DateTime(allow_null=True).__class__ == DateTime
    assert DateTime(max_length=Int().validate(1)).__class__ == DateTime

# Generated at 2022-06-24 10:45:13.771546
# Unit test for constructor of class Boolean
def test_Boolean():
    Bool = Boolean(title="Bool", description="Bool desc")
    assert Bool.validate(True) is True
    assert Bool.validate(False) is False

    # Initialize the Boolean class with the value true
    assert Bool.validate(True) is True

    # Initialize the Boolean class with the value false
    assert Bool.validate(False) is False

    # Initialize the Boolean class with a string and expect it to return an exception
    try:
        Bool.validate("true")
    except Exception as err:
        assert type(err) == ValidationError

    # Initialize the Boolean class with a number and expect it to return an exception
    try:
        Bool.validate(123)
    except Exception as err:
        assert type(err) == ValidationError

    # Initialize the

# Generated at 2022-06-24 10:45:18.909095
# Unit test for constructor of class String
def test_String():
    a = String(title='a', description='b', default='c', allow_null=False)
    assert a.title == 'a'
    assert a.description == 'b'
    assert a.default == 'c'
    assert a.allow_null == False


# Generated at 2022-06-24 10:45:21.486393
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    try:
        assert Field(default='nadine').get_default_value() == 'nadine'
    except:
        raise



# Generated at 2022-06-24 10:45:26.064376
# Unit test for constructor of class String
def test_String():
    s = String(
        title="test_String"
    )
    assert s.title == "test_String"


# Generated at 2022-06-24 10:45:31.622306
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(
        items=String(),
        additional_items=None,
        min_items=None,
        max_items=None,
        unique_items=False,
    )
    obj = ["a", "b", "c"]
    obj_serialized = field.serialize(obj)
    assert obj_serialized == obj



# Generated at 2022-06-24 10:45:36.897082
# Unit test for method validate of class Union
def test_Union_validate():
    print("Testing method validate of class Union")
    field = Union([String(**{}), Integer(**{})])
    value = "Hello World"
    field.validate(value)
    value = 42
    field.validate(value)
    value = None
    field.validate(value)
    print("Finished testing method validate of class Union")



# Generated at 2022-06-24 10:45:37.602526
# Unit test for constructor of class Any
def test_Any():
    any = Any()


# Generated at 2022-06-24 10:45:47.372255
# Unit test for method validate of class Array
def test_Array_validate():
    class TestField(Field):
        def _validate(self, value, *, strict=False):
            return value + '1'
    _field = Array(TestField())
    result = _field.validate(["123"])
    assert result == ['1231']
    

# Generated at 2022-06-24 10:45:56.859974
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    minimum = 1
    maximum = 5
    exclusive_minimum = 3
    exclusive_maximum = 3
    multiple_of = 0.25
    test_list_1 = [1, 1.0, minimum, exclusive_minimum, None, "", "1", 1+0.5*multiple_of]
    test_list_2 = ["1.1", 1.1, 1.1+0.5*multiple_of, 1.0+multiple_of, 1+multiple_of]
    test_list_3 = ["1.15", 1.15, 1.1+multiple_of]
    test_list_4 = [maximum, exclusive_maximum, 1.0+1.5*multiple_of]
    test_list_5 = ["6", 6, 1.0+2*multiple_of]

# Generated at 2022-06-24 10:45:59.248957
# Unit test for constructor of class Field
def test_Field():
    assert isinstance(Field(), Field)


# Generated at 2022-06-24 10:46:05.822003
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(None) is None
    assert b.validate(False) is False
    assert b.validate(True) is True
    assert b.validate(1) is True
    assert b.validate(0) is False
    assert b.validate(1.0) is True
    assert b.validate(0.0) is False
    assert b.validate('1') is True
    assert b.validate('0') is False
    assert b.validate('true') is True
    assert b.validate('false') is False
    assert b.validate('True') is True
    assert b.validate('False') is False
    assert b.validate('TRUE') is True
    assert b.validate('FALSE') is False

# Generated at 2022-06-24 10:46:10.567239
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    c=Field()
    d=Field()
    assert c.get_error_text("required") == '"This field is required."'
    assert d.errors == {'required': '"This field is required."', 'invalid': '"This field is invalid."'}

# Generated at 2022-06-24 10:46:11.682577
# Unit test for constructor of class Time
def test_Time():
    assert Time()



# Generated at 2022-06-24 10:46:21.171901
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="uuid").validate("c9bf9e57-1685-4c89-bafb-ff5af830be8a") == "c9bf9e57-1685-4c89-bafb-ff5af830be8a"
    assert String(format="uuid").serialize("c9bf9e57-1685-4c89-bafb-ff5af830be8a") == "c9bf9e57-1685-4c89-bafb-ff5af830be8a"
    assert String(format="uuid").serialize(None) == None



# Generated at 2022-06-24 10:46:26.539495
# Unit test for method validate of class Array
def test_Array_validate():
    array=Array()
    array.validate(0)
    array.validate({})
    array.validate([1,2,3])
    try:
        array.validate(1)
        assert False
    except Exception as e:
        assert True



# Generated at 2022-06-24 10:46:29.913296
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=[1, 2, 3])
    assert field.choices == [(1, 1), (2, 2), (3, 3)]



# Generated at 2022-06-24 10:46:33.976020
# Unit test for method has_default of class Field
def test_Field_has_default():
    """
    Test if the method has_default works in the defined conditions
    """
    field = Field(default=None, allow_null=True)
    result = field.has_default()
    expected_result = True
    assert result == expected_result
    assert result is not expected_result


# Generated at 2022-06-24 10:46:35.578335
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert isinstance(f, Field)


# Generated at 2022-06-24 10:46:39.681450
# Unit test for constructor of class Integer
def test_Integer():
    number_instance = Integer()
    assert isinstance(number_instance.errors, dict)
    assert number_instance.numeric_type == int
    assert number_instance.validate(1)



# Generated at 2022-06-24 10:46:41.043528
# Unit test for constructor of class DateTime
def test_DateTime():
    d = DateTime()
    assert d.format == "datetime"

# Generated at 2022-06-24 10:46:45.317861
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal()
    assert a

# Generated at 2022-06-24 10:46:49.340890
# Unit test for constructor of class Array
def test_Array():
    assert Array(
        items=String(max_length=10),
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
    )


# Generated at 2022-06-24 10:46:49.812535
# Unit test for constructor of class Time
def test_Time():
    Time()


# Generated at 2022-06-24 10:46:58.084939
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[(1, "value1"), (2, "value2"), (3, "value3")])
    # test for None
    with pytest.raises(ValidationError) as excinfo:
        c.validate(None)
    assert excinfo.match("May not be null.")
    # test for value of choice
    assert c.validate(1) == 1
    # test for a value not in choice
    with pytest.raises(ValidationError) as excinfo:
        c.validate(4)
    assert excinfo.match("Not a valid choice.")
    # test for value of choice and strict is True
    assert c.validate(1, strict=True) == 1
    # test for a value not in choice and strict is True

# Generated at 2022-06-24 10:47:00.914483
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    value = 1
    rtn = field.validate(value)
    assert value == rtn


# Generated at 2022-06-24 10:47:10.428000
# Unit test for method validate of class Object
def test_Object_validate():
    # Test function Object.validate
    #
    # This test case exercises the validate method.
    #
    # Expected behavior:
    #   The validate method should return the validated value.
    #   The validate method should raise a ValidationError if the
    #   validation fails. In that case, the message should contain
    #   additional information about the error.
     
    # Setup
    print("Object.validate")
    schema = Object(properties={
        "id": Integer(minimum=1, maximum=5),
        "favorite_song": Text(max_length=20),
    })

    # Test
    # Test 1
    value = {
        "id": 2,
        "favorite_song": "The Ramones - Pinhead",
    }
    expected_result = value
    result = schema.validate(value)


# Generated at 2022-06-24 10:47:13.247254
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(1.1) == 1.1
    assert Decimal().serialize(None) == None


# Generated at 2022-06-24 10:47:18.460933
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test method Boolean.validate by passing it arguments
    # that it is expecting to receive. 
    # We expect the method to return a boolean value True
    # or False
    if Boolean.validate("true", strict = True) == True:
        return "Pass 1"
    if Boolean.validate("false", strict = True) == False:
        return "Pass 2"
    if Boolean.validate("on", strict = True) == False:
        return "Pass 3"
    if Boolean.validate("off", strict = True) == True:
        return "Pass 4"
    if Boolean.validate("1", strict = True) == True:
        return "Pass 5"
    if Boolean.validate("0", strict = True) == False:
        return "Pass 6"

# Generated at 2022-06-24 10:47:20.490327
# Unit test for constructor of class Decimal
def test_Decimal():
    f = Decimal()
    assert f.precision is None



# Generated at 2022-06-24 10:47:26.621184
# Unit test for constructor of class Number
def test_Number():
    field = Number(
        title="Longitude",
        description="The longitude of the marker.",
        minimum=-180,
        maximum=180,
        exclusive_minimum=-180,
        exclusive_maximum=180,
        precision="1.0",
        multiple_of=5,
        allow_null=False,
    )
    # print(field.__dict__)
    # print(field.__dict__['minimum'])



# Generated at 2022-06-24 10:47:33.358007
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice(choices=["foo", "bar", "baz"]).validate("foo")
    Choice(choices=["foo", "bar", "baz"]).validate("bar")
    Choice(choices=["foo", "bar", "baz"]).validate("baz")
    with pytest.raises(ValidationError):
        Choice(choices=["foo", "bar", "baz"]).validate("qux")
    with pytest.raises(ValidationError):
        Choice(choices=["foo", "bar", "baz"]).validate("")
    with pytest.raises(ValidationError):
        Choice(choices=["foo", "bar", "baz"]).validate(None)


# Generated at 2022-06-24 10:47:41.118129
# Unit test for constructor of class Time
def test_Time():
    t = Time()
    t.validate("12:00:00")
    t.validate("12:00:00.000000")
    t.validate("12:00:00.01")
    t.validate("12:00:00.001")
    t.validate("12:00:00.0001")
    t.validate("12:00:00.00001")
    t.validate("12:00:00.000001")
    t.validate("12:00:00.0000001")
    t.validate("12:00:00.00000001")
    t.validate("12:00:00.000000001")
    t.validate("12:00:00.0000000001")
    t.validate("12:00:00.00000000001")

# Generated at 2022-06-24 10:47:42.652517
# Unit test for constructor of class Text
def test_Text():
    Text()


# Generated at 2022-06-24 10:47:52.889375
# Unit test for constructor of class Array
def test_Array():
    # test the input with multiple items
    test_items = [Integer(), String(), String()]
    test_min_items = 2
    test_max_items = 5
    test_additional_items = Integer()
    test_unique_items = True
    test_exact_items = 2
    test_object = Array(items=test_items,
                       additional_items=test_additional_items,
                       min_items=test_min_items,
                       max_items=test_max_items,
                       unique_items=test_unique_items,
                       exact_items=test_exact_items)
    assert test_object.items == test_items
    assert test_object.additional_items == test_additional_items
    assert test_object.min_items == test_min_items

# Generated at 2022-06-24 10:47:58.380163
# Unit test for constructor of class Array
def test_Array():
    import json
    import typing
    from typing import List, Dict, Any
    a_dict1: Dict[str, Any] = {
        "type": "array",
        "items": [
            {
                "type": "string"
            },
            {
                "type": "integer"
            }
        ],
        "additional_items": {
            "type": "null"
        },
        "min_items": 1,
        "max_items": 2,
        "unique_items": True
    }
    validator1 = Array.parse_obj(a_dict1)
    assert validator1 is not None

# Generated at 2022-06-24 10:48:06.350081
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class IntField(Field):
        def validate(self, value, *, strict=False):
            if value is None:
                return None
            return int(value)

    int_field = IntField()
    assert isinstance(int_field, Field)
    assert int_field.validate_or_error(0) == ValidationResult(0, None)
    assert int_field.validate_or_error(1) == ValidationResult(1, None)
    assert int_field.validate_or_error(2.0) == ValidationResult(2, None)
    assert int_field.validate_or_error(None) == ValidationResult(None, None)
    assert int_field.validate_or_error("1") == ValidationResult(1, None)
    assert int_field.validate_or

# Generated at 2022-06-24 10:48:14.755051
# Unit test for method validate of class Number
def test_Number_validate():
    errors = Number.errors
    errors['null'] = "must be null"
    x = Number(allow_null=True,errors=errors)
    assert x.validate(None) == None
    assert x.validate_or_error(None).value == None
    x = Number(errors=errors)
    assert x.validate(None).errors['null'] == "must be null"
    assert x.validate_or_error(None).errors['null'] == "must be null"
    assert x.validate(123) == 123
    assert x.validate(123) == 123
    assert x.validate(123) == 123
    assert x.validate(123) == 123
    assert x.validate(123) == 123
    assert x.validate(123) == 123
    assert x.validate(123)

# Generated at 2022-06-24 10:48:23.942185
# Unit test for constructor of class Array
def test_Array():
    print('\n**** Unit test for constructor of class Array ****')

    # test for default constructor
    print('\nTest for default constructor:')
    arr = Array()
    print('arr = ', arr)

    # test for constructor with keyword arguments
    print('\nTest for constructor with keyword arguments:')
    arr = Array(
        title='Arr',
        description='Test for class Array',
        max_items=10, 
        min_items=3,
        exact_items=None,
        unique_items=True,
        allow_null=True,  
    )
    print('arr = ', arr)

    # try to call constructor with bad arguments
    print('\nTest for constructor with bad arguments:')

# Generated at 2022-06-24 10:48:30.114059
# Unit test for method validate of class Any
def test_Any_validate():
    purpose_id_validator = Any()
    assert purpose_id_validator.validate(1000000) == 1000000
    assert purpose_id_validator.validate("bob") == "bob"
    assert purpose_id_validator.validate(True) == True
    assert purpose_id_validator.validate(None) == None
    assert purpose_id_validator.validate([]) == []
    assert purpose_id_validator.validate({}) == {}



# Generated at 2022-06-24 10:48:35.173596
# Unit test for constructor of class Text
def test_Text():
    text = Text(max_length=1024, min_length=1, allow_blank=False, title="邮箱", required=True)
    assert text.max_length == 1024
    assert text.min_length == 1
    assert text.allow_blank == False
    assert text.title == "邮箱"
    assert text.required == True
