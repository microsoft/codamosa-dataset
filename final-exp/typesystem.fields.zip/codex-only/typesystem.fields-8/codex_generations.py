

# Generated at 2022-06-24 10:38:36.904429
# Unit test for constructor of class Const
def test_Const():
    const = Const('const', allow_null=True)
    assert const.const == 'const'
    assert const.allow_null == True
    assert const.errors == Const.errors



# Generated at 2022-06-24 10:38:45.004528
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem import Integer
    i = Integer()
    # value is valid
    assert i.validate_or_error(0) == ValidationResult(value=0, error=None)
    # value is valid
    assert i.validate_or_error(0.0) == ValidationResult(value=0, error=None)
    # value is not valid
    assert i.validate_or_error(0.1) == ValidationResult(value=None, error=ValidationError(text='"0.1" is not a valid integer.', code='invalid'))
    
    
    
    


# Generated at 2022-06-24 10:38:49.595479
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    from typesystem.fields import Boolean   
    boolean_field = Boolean()
    boolean_field.validate(True, strict = True)
    boolean_field.validate(False, strict = True)
    boolean_field.validate(None, strict = False)
    boolean_field.validate('true', strict = False)
    boolean_field.validate('false', strict = False)
    boolean_field.validate('1', strict = False)
    boolean_field.validate('0', strict = False)
    boolean_field.validate('on', strict = False)
    boolean_field.validate('off', strict = False)
    
    


# Generated at 2022-06-24 10:38:50.454988
# Unit test for constructor of class Const
def test_Const():
   test = Const(const = 0)


# Generated at 2022-06-24 10:38:53.501877
# Unit test for method validate of class Const
def test_Const_validate():
    c = Const("my_const", allow_null = True)
    c.validate("my_const")
    assert c.validate("my_const") == "my_const"
    assert c.validate(None) == None


    with pytest.raises(ValidationError):
        c.validate("not my const")





# Generated at 2022-06-24 10:38:56.286381
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()

    error = field.validation_error('required')
    assert error


# Generated at 2022-06-24 10:38:57.624922
# Unit test for constructor of class Float
def test_Float():
    assert hasattr(Float, '_creation_counter')


# Generated at 2022-06-24 10:39:02.291246
# Unit test for method serialize of class Field
def test_Field_serialize():
    # Initializations
    # Testing with the value:
    value = 'my_string'
    # Expected output:
    expected = 'my_string'
    # Testing with Field
    field = Field()
    # Testing the method
    result = field.serialize(value)
    assert result == expected


# Generated at 2022-06-24 10:39:04.955667
# Unit test for method validate of class Any
def test_Any_validate():
    import pprint

    obj = Any()
    pprint.pprint(obj)
    value = 2
    assert (obj.validate(value) == value)

# Generated at 2022-06-24 10:39:11.722408
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(0.0) == 0.0
    assert Decimal().serialize(0.01) == 0.01
    assert Decimal().serialize(0.99999999) == 0.99999999
    assert Decimal().serialize(decimal.Decimal('NaN')) is None
    assert Decimal().serialize(decimal.Decimal('-Infinity')) is None
    assert Decimal().serialize(decimal.Decimal('Infinity')) is None
    assert Decimal().serialize(decimal.Decimal('0')) == 0.0
    assert Decimal().serialize(decimal.Decimal('0.01')) == 0.01
    assert Decimal().serialize(decimal.Decimal('0.99999999')) == 0.99999999
    assert Decimal().serialize(None)

# Generated at 2022-06-24 10:39:15.986603
# Unit test for method validate of class Union
def test_Union_validate():
    schema = Union([String(), Int()])
    assert schema.validate('123') == '123'
    assert schema.validate(123) == 123
    assert schema.validate(None) == None

    try:
        schema.validate(123.4)
    except ValidationError as e:
        assert e.messages[0].as_dict() == {'text': 'Must be a string.', 'code': 'type', 'index': []}
    else:
        assert False



# Generated at 2022-06-24 10:39:21.259169
# Unit test for method validate of class Union
def test_Union_validate():
    from app.schema import Schema, StringField, IntField, FloatField
    from app.validation import ValidationError
    import pytest

    def test_pass():
        schema = Schema(
            {
                "field1": Union(
                    [
                        StringField(max_length=1, min_length=1),
                        IntField(maximum=1, minimum=1),
                        FloatField(maximum=1, minimum=1),
                    ]
                )
            }
        )
        schema.validate({"field1": "s"})


# Generated at 2022-06-24 10:39:22.901288
# Unit test for method serialize of class Field
def test_Field_serialize():
    field_object=Field()
    value=field_object.serialize(1)
    assert value==1

# Generated at 2022-06-24 10:39:27.444202
# Unit test for method validate of class Object
def test_Object_validate():
    # Full test is in test_schema.py
    s = Object()
    assert s.name == "object"
    assert s.validate({"a": 1, "b": "2"}) == {"a": 1, "b": "2"}
    assert s.serialize({"a": 1, "b": "2"}) == {"a": 1, "b": "2"}
    with pytest.raises(ValidationError) as excinfo:
        s.validate({})
    assert "This field is required." == str(excinfo.value)



# Generated at 2022-06-24 10:39:31.486440
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate(None) == None
    assert string.validate('') == ''
    assert string.validate('test') == 'test'


# Generated at 2022-06-24 10:39:35.695766
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field(title="title", description="description")
    field.errors = {'code': 'text'}
    assert field.get_error_text('code') == 'text'
    # teardown
    field = None


# Generated at 2022-06-24 10:39:42.158520
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    val = Boolean()
    assert val.validate(True) == True
    assert val.validate("True") == True
    assert val.validate("true") == True
    assert val.validate("TRUE") == True
    assert val.validate("1") == True
    assert val.validate("on") == True
    assert val.validate("ON") == True
    assert val.validate("on") == True
    assert val.validate("ON") == True
    assert val.validate("none") == None
    assert val.validate(None) == None



# Generated at 2022-06-24 10:39:44.519880
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Field()
    assert f.serialize(1) == 1


# Generated at 2022-06-24 10:39:48.559315
# Unit test for method serialize of class String
def test_String_serialize():
    instance = String()
    expected = "abcd"
    assert expected == instance.serialize("abcd")


# Generated at 2022-06-24 10:39:56.471981
# Unit test for method validate of class Boolean
def test_Boolean_validate():
       # Test for more than one condition at a time
       err = Field.errors
       x = Boolean(allow_null=True, default=True)
       y = Boolean(allow_null=True, default=False)
       z = Boolean(allow_null=False)
       p=Boolean(allow_null=False, default=True)
       assert x.validate("null", strict=False) == None # test for strict
       assert y.validate("off", strict=False) == False # test for strict
       assert y.validate("1", strict=False) == True # test for strict
       assert y.validate("none", strict=False) == None # test for strict
       assert z.validate("null", strict=False) == None # test for strict
       assert x.validate("true", strict=False) == True # test for strict

# Generated at 2022-06-24 10:40:05.508708
# Unit test for method validate of class String
def test_String_validate():
    # type: () -> None
    test_String = String()

    test1 = "I am a test string"
    test2 = "42"
    test3 = "Not a string"
    test4 = 42

    # Test Input: I am a test string
    assert test_String.validate(test1) == test1

    # Test input: "42"
    assert test_String.validate(test2) == test2

    # Test input: "Not a string"
    assert test_String.validate(test3) == test3

    # Test input: 42
    assert test_String.validate(test4) == test4


# Generated at 2022-06-24 10:40:14.920543
# Unit test for constructor of class Object
def test_Object():
    # Test successful initialization of Object
    obj1 = Object()
    assert obj1.properties == {}
    assert obj1.pattern_properties == {}
    assert obj1.additional_properties == True
    assert obj1.property_names is None
    assert obj1.min_properties is None
    assert obj1.max_properties is None
    assert obj1.required == []
    assert obj1.allow_null == False
    assert obj1.default is None

    prop1 = String().tag(key="value")
    prop2 = Number().tag(key="other_value")

# Generated at 2022-06-24 10:40:21.683601
# Unit test for method validate of class Field
def test_Field_validate():
  from typesystem.exceptions import ValidationError
  from typesystem.fields import Field
  class MyField(Field):
    def validate(self, value,*args, **kwargs):
      try:
        return int(value)
      except (TypeError, ValueError):
        self.validation_error("invalid")
    
  f = MyField()
  assert f.validate(12) == 12
  try:
    f.validate("MyName")
    raise AssertionError("validate hasn't threw an exception")
  except ValidationError as e:
    assert str(e) == "invalid"

# Generated at 2022-06-24 10:40:23.593426
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=["foo", "bar"])
    assert field.choices == [("foo", "foo"), ("bar", "bar")]



# Generated at 2022-06-24 10:40:26.423246
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    val = Boolean(allow_null=True)
    assert val.validate("") == False 
    assert val.validate("1") == True 
    assert val.validate("0") == False 
    assert val.validate("on") == True 
    assert val.validate("off") == False 
    assert val.validate(1) == True 
    assert val.vali

# Generated at 2022-06-24 10:40:33.143980
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(
        title=None,
        description=None,
        default=NO_DEFAULT,
        allow_null=False,
        minimum=None,
        maximum=None,
        exclusive_minimum=None,
        exclusive_maximum=None,
        precision=None,
        multiple_of=None,
    ) == Integer(
        title=None,
        description=None,
        default=NO_DEFAULT,
        allow_null=False,
        minimum=None,
        maximum=None,
        exclusive_minimum=None,
        exclusive_maximum=None,
        precision=None,
        multiple_of=None,
    )


# Generated at 2022-06-24 10:40:33.876619
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    assert any.validate(1) == 1


# Generated at 2022-06-24 10:40:42.032510
# Unit test for method validate of class Any
def test_Any_validate():
    tests = [
        {
            "name": "1 == 1",
            "input": {"data": 1, "strict": False},
            "expected": 1,
        },
        {
            "name": "1 != False",
            "input": {"data": 1, "strict": True},
            "expected": 1,
        },
    ]
    for test in tests:
        if test["expected"] == test["input"]:
            print(f"PASS: {test['name']}")
        else:
            print(f"FAIL: {test['name']}")


test_Any_validate()



# Generated at 2022-06-24 10:40:46.441803
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    def _test():
        errors = {
            "too_short": "{title} is too short.",
            "not_string": "{title} is not a string.",
        }
        field = Field(title="Title", errors=errors)
        error = field.validation_error("too_short")
        assert error.text == "Title is too short."
    _test()


# Generated at 2022-06-24 10:40:55.938118
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice=Choice(name="testchoice", choices = ["test"], required=True)
    assert choice.validate("test") == "test"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError) as error:
        choice.validate("")
    assert "This field is required." == error.value.text
    with pytest.raises(ValidationError) as error:
        choice.validate("test1")
    assert "Not a valid choice." == error.value.text
    assert choice.validate(1) == 1


# Generated at 2022-06-24 10:40:59.216841
# Unit test for method serialize of class String
def test_String_serialize():
    obj = String()
    assert obj.serialize(1) == 1
    assert obj.serialize('1') == '1'
    assert obj.serialize(['1']) == ['1']



# Generated at 2022-06-24 10:41:09.095063
# Unit test for constructor of class Integer
def test_Integer():
    i = Integer(maximum=123)
    assert i.validate(11) == 11
    assert i.validate(123) == 123
    try:
        i.validate(124)
        assert False
    except ValidationError as e:
        assert e.code == 'maximum'
    assert i.validate_or_error(11).value == 11
    assert i.validate_or_error(123).value == 123
    assert i.validate_or_error(124).error.code == 'maximum'

    i = Integer(minimum=123)
    assert i.validate(124) == 124
    assert i.validate(123) == 123
    try:
        i.validate(122)
        assert False
    except ValidationError as e:
        assert e.code == 'minimum'

# Generated at 2022-06-24 10:41:18.269638
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import typesystem
    x = typesystem.Field(
        title='',
        description='',
        default=typesystem.NO_DEFAULT,
        allow_null=False
    )

    result_true = x.validate_or_error(
        value=1,
        strict=False
    )
    assert(result_true[0] == True)
    assert(result_true[1] == 1)

    result_false = x.validate_or_error(
        value=None,
        strict=False
    )
    assert(result_false[0] == False)
    assert(result_false[1] == None)

test_Field_validate_or_error()

# Generated at 2022-06-24 10:41:28.221627
# Unit test for constructor of class Object
def test_Object():
	obj = Object(
		properties = {'proper': Field()},
		pattern_properties = {'pattern': Field()},
		additional_properties = Field(),
		property_names = Field(),
		min_properties = 1,
		max_properties = 1,
		required = ['key1'],
		allow_null = False,
		allow_empty = False,
		error_text = '{key}',
	)
	assert obj.properties == {'proper': Field()}
	assert obj.pattern_properties == {'pattern': Field()}
	assert obj.additional_properties == Field()
	assert obj.property_names == Field()
	assert obj.min_properties == 1
	assert obj.max_properties == 1
	assert obj.required == ['key1']
	

# Generated at 2022-06-24 10:41:29.550350
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(1) == True
    assert b.validate(0) == False



# Generated at 2022-06-24 10:41:31.729524
# Unit test for method validate of class Const
def test_Const_validate():
	obj = Const(None)
	obj.validate(None)
	obj = Const(1)
	obj.validate(1)
	obj.validate(2)


# Generated at 2022-06-24 10:41:33.849139
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    assert field.validation_error("not_valid").text == "Must be valid"

# Generated at 2022-06-24 10:41:35.073661
# Unit test for constructor of class Number
def test_Number():
    assert Number()



# Generated at 2022-06-24 10:41:37.973218
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate([]) is not None
    assert field.validate([1]) is None    

# Generated at 2022-06-24 10:41:40.563761
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field(title="Name", description="The name of a thing")
    assert field.serialize("value") == "value"

# Generated at 2022-06-24 10:41:45.350099
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a = Boolean()
    b = a.validate(True)
    c = a.validate('true')
    d = a.validate('None')
    assert b == True
    assert c == True
    assert d == None
    a.__init__(*[], **{"allow_null": False})
    e = a.validate(None)
    assert e == "May not be null."



# Generated at 2022-06-24 10:41:46.672442
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert(f.numeric_type == float)



# Generated at 2022-06-24 10:41:48.184918
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field.allow_null == False
    assert field.has_default() == False


# Generated at 2022-06-24 10:41:49.330980
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "b")])
    c.validate("a")



# Generated at 2022-06-24 10:41:55.061403
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal()
    d = Decimal(precision='0.001')
    assert d.precision == '0.001'
    d.validate('1.234')
    d.validate(1.234)
    d.validate(1)
    d.validate(None)
    d.validate_or_error('1.2345').error
    d.validate_or_error(True).error
    d = Decimal(minimum=1.0)
    d = Decimal(maximum=1.0)
    d = Decimal(exclusive_minimum=1.0)
    d = Decimal(exclusive_maximum=1.0)
    d = Decimal(multiple_of=1.0)


# Generated at 2022-06-24 10:41:57.167001
# Unit test for constructor of class Decimal
def test_Decimal():
    test_Decimal = Decimal()
    assert test_Decimal.numeric_type is decimal.Decimal


# Generated at 2022-06-24 10:41:59.856320
# Unit test for constructor of class String
def test_String():
    t = String(title="test")
    assert t.title =="test"
    return



# Generated at 2022-06-24 10:42:02.492618
# Unit test for method validate of class Object
def test_Object_validate():
    # Unit test for method validate of class Object
    obj = {"key1":"abc", "key2":1}
    field = Field.validate(obj)
    # key2 must be a number convert from string
    assert field == {"key1": "abc", "key2": 1}


# Generated at 2022-06-24 10:42:03.527695
# Unit test for constructor of class Time
def test_Time():
    expected_Time = String(format="time")
    actual_Time = Time()
    assert expected_Time == actual_Time


# Generated at 2022-06-24 10:42:07.891350
# Unit test for constructor of class Array
def test_Array():
    with pytest.raises(AssertionError):
        Array(items=123, additional_items=False, min_items=2, max_items=5, unique_items=False, default=None)
        Array(items=Field(), additional_items=True, min_items=5, max_items=5, unique_items=False, default=None)
        Array(items=Field(), additional_items=False, min_items="5", max_items=5, unique_items=False, default=None)
        Array(items=Field(), additional_items=False, min_items=5, max_items="5", unique_items=False, default=None)
        Array(items=Field(), additional_items=False, min_items=5, max_items=5, unique_items=True, default=None)

# Generated at 2022-06-24 10:42:11.960772
# Unit test for method validate of class Number
def test_Number_validate():
    # Create a test case
    tc = Number()

    # Create a dictionary for arguments for method validate
    args = {'value': 2,
            'strict': False}

    # Store the results of method validate in a variable
    result = tc.validate(**args)

    # Verify that the result is correct
    assert result != None #  The result should not be null



# Generated at 2022-06-24 10:42:13.523481
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal()
    assert d.numeric_type == decimal.Decimal


# Generated at 2022-06-24 10:42:20.013850
# Unit test for constructor of class Array
def test_Array():
    array = Array(
        items=[String(), Integer()],
        additional_items=True,
        min_items=1,
        max_items=5,
        unique_items=True,
        allow_null=True,
        default="default",
        required=True,
        title="Title",
        description="Description",
    )

    assert array.items == [String(), Integer()]
    assert array.additional_items == True
    assert array.min_items == 1
    assert array.max_items == 5
    assert array.unique_items == True
    assert array.allow_null == True
    assert array.default == "default"
    assert array.required == True
    assert array.title == "Title"
    assert array.description == "Description"


# Generated at 2022-06-24 10:42:23.924557
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice(max_length=1,choices=["a","b"])
    assert c.errors=={'null': 'May not be null.','required': 'This field is required.','choice': 'Not a valid choice.'}


# Generated at 2022-06-24 10:42:29.154600
# Unit test for constructor of class Object
def test_Object():
    class Inner(Object):
        test = Integer(allow_null=False)

    class Outer(Object):
        class Meta:
            allow_null = False
        properties = Inner.properties
        pattern_properties = Inner.pattern_properties
        additional_properties = Inner.additional_properties
        property_names = Inner.property_names
        min_properties = Inner.min_properties
        max_properties = Inner.max_properties
        required = Inner.required

    assert Outer.allow_null == False
    assert Outer.properties == Inner.properties
    assert Outer.pattern_properties == Inner.pattern_properties
    assert Outer.additional_properties == Inner.additional_properties
    assert Outer.property_names == Inner.property_names
    assert Outer.min_properties == Inner.min_properties
    assert Outer.max_properties == Inner.max_properties

# Generated at 2022-06-24 10:42:34.972345
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.any_of import Union
    from typesystem import Scalar
    from typesystem import Structure
    from typesystem import String
    from typesystem import Number
    t1=Field()
    t2=Union()
    t3=Scalar()
    t4=Structure()
    t5=String()
    t6=Number()

    t7=t1|t2
    t8=t1|t3
    t9=t1|t4
    t10=t1|t5
    t11=t1|t6

    t12=t2|t1
    t13=t2|t3
    t14=t2|t4
    t15=t2|t5
    t16=t2|t6

    t17=t3|t1

# Generated at 2022-06-24 10:42:42.572587
# Unit test for constructor of class Choice
def test_Choice():
    choices_error = {
        "null": "May not be null.",
        "required": "This field is required.",
        "choice": "Not a valid choice.",
    }
    choices = [
        ("choice1", "choice1"),
        ("choice2", "choice2"),
        ("choice3", "choice3"),
        ("choice4", "choice4"),
    ]
    assert Choice(choices=choices).errors == choices_error
    assert Choice().errors == choices_error



# Generated at 2022-06-24 10:42:53.564636
# Unit test for constructor of class Union
def test_Union():
    s = String()
    i = Integer()
    u = Union([s, i])
    assert repr(u) == "<Union String/Integer>"
    assert u.validate("a") == "a"
    assert u.validate(1) == 1
    assert u.validate(True) == "True"
    with pytest.raises(ValidationError) as exc_info:
        u.validate(False)
    exc = exc_info.value
    assert len(exc.messages()) == 1
    assert exc.messages()[0].code == "union"
    assert exc.messages()[0].text == "Did not match any valid type."
    u = Union([s, i], allow_null=True)
    assert u.validate(None) is None

# Generated at 2022-06-24 10:42:55.198206
# Unit test for constructor of class Integer
def test_Integer():
    if Integer:
        return True
    else:
        return False


# Generated at 2022-06-24 10:42:58.827039
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_integer = Decimal()
    assert decimal_integer.serialize(3) == 3.0
    assert decimal_integer.serialize(None) == None
    decimal_float = Decimal()
    assert decimal_float.serialize(3.141) == 3.141


# Generated at 2022-06-24 10:43:10.065365
# Unit test for constructor of class Array
def test_Array():
    # Test 1:
    field_1 = Array(
            items = Int(),
            additional_items = False,
            min_items = 2,
            max_items = 4,
            unique_items = True,
        )
    assert field_1.items == Int()
    assert field_1.additional_items == False
    assert field_1.min_items == 2
    assert field_1.max_items == 4
    assert field_1.unique_items == True

    # Test 2:
    field_2 = Array(
            items = [Int(), String()],
            additional_items = False,
            min_items = 2,
            max_items = 4,
            unique_items = True
    )
    assert field_2.items == [Int(), String()]

# Generated at 2022-06-24 10:43:14.964373
# Unit test for constructor of class Decimal
def test_Decimal():
    value = Decimal(1, decimal.Decimal(0.01))
    if value.minimum != decimal.Decimal(1) and value.precision != decimal.Decimal(0.01):
        print("Test FAIL! Decimal constructor's parameters are not assigned correctly")
    else:
        print("Test PASS! All parameters are assigned correctly")

# Unit tests for serialize function of class Decimal

# Generated at 2022-06-24 10:43:18.993031
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field(title='', description='', default=None, allow_null=False)
    f.validate = lambda value, **kwargs: value
    f.validate_or_error('a') == ValidationResult(value='a', error=None)



# Generated at 2022-06-24 10:43:21.357648
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(format="time")
    value = string.serialize("02/12/2018")
    assert value == "02/12/2018"
# End of unit test for method serialize of class String



# Generated at 2022-06-24 10:43:24.381146
# Unit test for constructor of class Number
def test_Number():
    n = Number(2, 3)
    n.number_type = int
    assert n.number_type == int
    assert n.minimum == 2
    assert n.maximum == 3



# Generated at 2022-06-24 10:43:26.970952
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    s.validate("hello\0world")



# Generated at 2022-06-24 10:43:28.451844
# Unit test for constructor of class Text
def test_Text():
    assert Text.errors["pattern"] == "Must be valid text."
    assert Text(name="string").get_error_text("pattern") == "Must be valid text."


# Generated at 2022-06-24 10:43:31.114996
# Unit test for constructor of class Integer
def test_Integer():
    i = Integer()
    assert i.numeric_type == int


# Generated at 2022-06-24 10:43:37.142842
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.required == False, 'should be false'
    assert t.allow_null == False, 'should be false'
    assert t.format == "text", 'should be text'
    assert t.allow_blank == True, 'should be true'
    assert t.trim_whitespace == True, 'should be true'



# Generated at 2022-06-24 10:43:44.579980
# Unit test for constructor of class Time
def test_Time():
    def test_Time_constructor(**kwargs):
        Time(**kwargs)
    test_Time_constructor(optional = False, allow_null = False, format = "time")
    test_Time_constructor(optional = True, allow_null = True, format = "time")
    test_Time_constructor(optional = False, allow_null = False, format = "text")
    test_Time_constructor(optional = False, allow_null = False, format = "date")
    test_Time_constructor(optional = False, allow_null = True, format = "time")
    test_Time_constructor(optional = True, allow_null = False, format = "time")
    test_Time_constructor(optional = True, allow_null = False, format = "date")

# Generated at 2022-06-24 10:43:45.528465
# Unit test for constructor of class Const
def test_Const():
    field = Const("hello")
    assert field.const == "hello"



# Generated at 2022-06-24 10:43:48.017402
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const(5)
    try:
        field.validate(1)
    except ValidationError:
        pass
    else:
        raise Exception("Unexpected success")
    try:
        field.validate(2)
    except ValidationError:
        pass
    else:
        raise Exception("Unexpected success")



# Generated at 2022-06-24 10:43:51.701122
# Unit test for constructor of class Date
def test_Date():
    testString = Date()
    print(str(type(testString)))
    print(str(testString.errors))
    print(str(testString.allow_null))
    print(str(testString.format))
    print(str(testString.allow_empty_string))
    print(str(testString.validators))



# Generated at 2022-06-24 10:43:53.478937
# Unit test for constructor of class DateTime
def test_DateTime():
    class Test(Model):
        test = DateTime()

    assert Test.test.__class__.__name__ == 'DateTime'
    assert Test.test.__class__.__module__ == 'stronk.fields'

# Generated at 2022-06-24 10:43:56.069656
# Unit test for constructor of class Boolean
def test_Boolean():
    try:
        b = Boolean()
    except Exception as e:
        print("Exception: test_Boolean failed:", e)
        assert False
    return True


# Generated at 2022-06-24 10:43:58.356790
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean()
    assert isinstance(b, Boolean)

# Unit test to check validation result when Boolean is passed as value

# Generated at 2022-06-24 10:44:06.200864
# Unit test for method serialize of class Field
def test_Field_serialize():
    f=Field()
    assert f.serialize(None) == None
    assert f.serialize(-10) == -10
    assert f.serialize(10) == 10
    assert f.serialize(3.1415) == 3.1415
    assert f.serialize(True) == True
    assert f.serialize(False) == False
    assert f.serialize('a string') == 'a string'
    assert f.serialize(['this', 'is', 'a', 'list']) == ['this', 'is', 'a', 'list']
    assert f.serialize({'this', 'is', 'a', 'set'}) == {'this', 'is', 'a', 'set'}
    assert f.serialize((1,2,3,4)) == (1,2,3,4)

#

# Generated at 2022-06-24 10:44:09.001883
# Unit test for constructor of class Const
def test_Const():
    c = Const("Hello")
    try:
        c.validate(3)
        assert False
    except ValidationError as err:
        assert err.messages[0].code == "const"
        assert err.messages[0].text == "Must be the value 'Hello'."
        assert err.messages[0].params == {"const": "Hello"}



# Generated at 2022-06-24 10:44:14.953050
# Unit test for method validate of class Number
def test_Number_validate():
    int_number = Integer()
    float_number = Float()
    int_number_result = int_number.validate(2.0)
    float_number_result = float_number.validate(2.0)
    assert int_number_result == float_number_result
    assert int_number_result == 2.0


# Generated at 2022-06-24 10:44:18.081738
# Unit test for constructor of class Date
def test_Date():
    assert Date(format='date', required=True, description='date').format == 'date'


# Generated at 2022-06-24 10:44:24.934547
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from typing import List
    from typesystem.base import ValidationError
    from typesystem.constraints import Length
    from typesystem.fields import Field, String
    from unittest.mock import MagicMock

    class MyField(Field):
        errors = {
            "invalid": "This field is invalid.",
            "invalid_with_arg": "Field not valid: {example}.",
            "invalid_with_multiple_args": "Max length {max} and {example}.",
            "dynamic": "Length should be {0}.",
        }

        def validate(self, value):
            if value == "invalid":
                raise self.validation_error("invalid")

            if value == "invalid_with_arg":
                raise self.validation_error("invalid_with_arg")


# Generated at 2022-06-24 10:44:28.687087
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test = Boolean()
    input_test = "FALSE"
    try:
        test.validate(input_test)
    except ValidationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:44:31.489796
# Unit test for method serialize of class Field
def test_Field_serialize():
    instance = Field()
    # test the Field class
    assert isinstance(instance, Field)
    # test the method serialize of Field class
    assert isinstance(instance.serialize("my string"), str)



# Generated at 2022-06-24 10:44:42.554316
# Unit test for constructor of class Object
def test_Object():
    from marshmallow_polyfield import PolyField

    class AddressSchema(PolyField):
        type_schemas = {
            "home": Object(
                properties={
                    "city": String(required=True),
                    "country": String(required=True),
                }
            ),
            "work": Object(
                properties={
                    "city": String(required=True),
                    "country": String(required=True),
                    "department": String(required=True),
                }
            ),
            "other": Object(properties={}),
        }


# Generated at 2022-06-24 10:44:47.626690
# Unit test for constructor of class Date
def test_Date():
    test = Date()
    assert test.format == 'date'
    assert test.errors == {
        'format': 'Date should be in the format YYYY-MM-DD',
        'max_length': 'Must be no longer than 10 characters',
        'min_length': 'Must be at least 10 characters',
        'pattern': 'Date should be in the format YYYY-MM-DD',
        'null': 'May not be null',
        'required': 'This field is required',
        'type': 'Must be a string'
    }

    test = Date(allow_null=False)
    assert test.format == 'date'

# Generated at 2022-06-24 10:44:58.560855
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    '''
    Function to test the method validate of class Boolean
    '''

    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean().validate(None) == None
    assert Boolean().validate(0) == False
    assert Boolean().validate(1) == True
    assert Boolean().validate('True') == True
    assert Boolean().validate('False') == False
    assert Boolean().validate('on') == True
    assert Boolean().validate('off') == False
    assert Boolean().validate('0') == False
    assert Boolean().validate('1') == True
    assert Boolean().validate('') == False
    assert Boolean().validate('null') == None
    assert Boolean().validate('none') == None
    assert Boolean().validate('NONE') == None

# Generated at 2022-06-24 10:45:04.886055
# Unit test for constructor of class Boolean
def test_Boolean():
    B = Boolean()
    assert B.validate("True") == True
    assert B.validate("False") == False
    assert B.validate("0") == False
    assert B.validate("1") == True
    assert B.validate("") == False
    assert B.validate("on") == True
    assert B.validate("off") == False
    assert B.validate("none") == None



# Generated at 2022-06-24 10:45:05.885973
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean().validate("true") is True


# Generated at 2022-06-24 10:45:12.210674
# Unit test for constructor of class Time
def test_Time():
    with pytest.raises(AssertionError):
        Time(format="text")
    with pytest.raises(AssertionError):
        Time(format="date")
    with pytest.raises(AssertionError):
        Time(format="time", default="8:00")
    with pytest.raises(AssertionError):
        Time(format="time", required=True)

    Time(format="time", required=False)
    Time(format="time", required=None)
    Time(format="time")


# Generated at 2022-06-24 10:45:16.233712
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    # Case 1: obj is None, obj is expected to return None
    assert Decimal.serialize(Decimal,None) == None
    # Case 2: obj is not None, obj is expected to be a float
    assert isinstance(Decimal.serialize(Decimal,1), float)



# Generated at 2022-06-24 10:45:18.280087
# Unit test for method serialize of class String
def test_String_serialize():
    a = String( format="time" )
    assert(a.serialize("07:40:15") == "07:40:15")


# Generated at 2022-06-24 10:45:21.330855
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    assert Field().validation_error(code="test_error") == \
    ValidationError(code="test_error", text="test_error")


# Generated at 2022-06-24 10:45:24.967909
# Unit test for method serialize of class Field
def test_Field_serialize():
    f=Field()
    assert f.serialize(123) == 123



# Generated at 2022-06-24 10:45:28.314400
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    OBJECT_UNIQUE=Field()
    assert OBJECT_UNIQUE.get_error_text("unique")=="unique"
    
    


# Generated at 2022-06-24 10:45:37.506107
# Unit test for constructor of class Number
def test_Number():
    assert Number.numeric_type is None
    assert Number.errors == {
            "type": "Must be a number.",
            "null": "May not be null.",
            "integer": "Must be an integer.",
            "finite": "Must be finite.",
            "minimum": "Must be greater than or equal to {minimum}.",
            "exclusive_minimum": "Must be greater than {exclusive_minimum}.",
            "maximum": "Must be less than or equal to {maximum}.",
            "exclusive_maximum": "Must be less than {exclusive_maximum}.",
            "multiple_of": "Must be a multiple of {multiple_of}.",
            }



# Generated at 2022-06-24 10:45:48.701511
# Unit test for method validate of class Object
def test_Object_validate():
    test_obj = Object(properties={'name':String()})
    assert test_obj.validate({'name':'keshav'}) == {'name':'keshav'}
    assert test_obj.validate({'name':'keshav', 'age':'23'}) == {'name':'keshav', 'age':'23'}
    assert test_obj.validate({'name':'keshav', 'age':'23', 'salary':'2.4k'}) == {'name':'keshav', 'age':'23','salary':'2.4k'}
    test_obj = Object(properties={'name':String()}, additional_properties=False)

# Generated at 2022-06-24 10:45:51.346976
# Unit test for constructor of class Any
def test_Any():
    f1 = Any()
    assert f1.allow_null == False
    assert f1.default_value == None
    assert f1.allow_empty == False
    assert f1._validators == []
    assert f1.errors == dict()



# Generated at 2022-06-24 10:45:53.872032
# Unit test for method validate of class Union
def test_Union_validate():
    # given
    field = {"type": "integer"}
    child = Integer(field)
    any_of = [child]
    union = Union(any_of)
    value = 1
    # when
    result = union.validate(value)
    # then
    assert result == value



# Generated at 2022-06-24 10:45:54.609623
# Unit test for method __or__ of class Field
def test_Field___or__():
   assert True

# Generated at 2022-06-24 10:45:59.378046
# Unit test for constructor of class Boolean
def test_Boolean():
    # arrange
    expected = ''
    # act
    result = Boolean()
    # assert
    assert result.allow_null == False
    assert result.errors == {'type': 'Must be a boolean.', 'null': 'May not be null.'}

# Generated at 2022-06-24 10:46:01.912425
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    n = None
    try:
        a.validate(n)
    except ValidationError:
        raise AssertionError("validating None with Any should not raise.")
    d = {'a':'a'}
    try:
        a.validate(d)
    except ValidationError:
        raise AssertionError("validating a dictionary with Any should not raise.")


# Generated at 2022-06-24 10:46:08.237306
# Unit test for method serialize of class Field
def test_Field_serialize():
    from typesystem import types

    class TestField(types.Field):
        def serialize(self, value):
            return value

    field = TestField()
    assert field.serialize("Hello, World!") == "Hello, World!"
    assert field.serialize([1, 2, 3]) == [1, 2, 3]
    assert field.serialize([]) == []
    assert field.serialize({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.serialize({}) == {}



# Generated at 2022-06-24 10:46:11.988535
# Unit test for constructor of class Date
def test_Date():
    _Date = Date()
    assert _Date.format is "date"
    assert isinstance(_Date, Field)
    assert isinstance(_Date, String)


# Generated at 2022-06-24 10:46:17.058641
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code = "malformed"
    flag = False
    try:
        field.validation_error(code)
    except ValidationError as error:
        flag = True
        assert error.code == code
        assert error.text == "Invalid Value"
    assert flag
# Unit Test for get_error_text method of Class Field

# Generated at 2022-06-24 10:46:24.865822
# Unit test for method validate of class Union
def test_Union_validate():
    i = 1
    actual_result = Union([String("i")]).validate(i)
    assert actual_result == 'i'
    # Unit test for method validate of class Union
    def test_Union_validate():
        i = 1
        actual_result = Union([String("i")]).validate(i)
        assert actual_result == 'i'



# Generated at 2022-06-24 10:46:32.776482
# Unit test for method serialize of class Array
def test_Array_serialize():
    field_test = Array(items=String())
    assert field_test.serialize(["unit test"]) == ["unit test"]

    field_test = Array(items=Array(items=String()))
    assert field_test.serialize([["unit test"]]) == [["unit test"]]

    field_test = Array(items=String())
    assert field_test.serialize("unit test") == "unit test"

    field_test = Array(items=Array(items=String()))
    assert field_test.serialize("unit test") == "unit test"



# Generated at 2022-06-24 10:46:39.362452
# Unit test for constructor of class Number
def test_Number():
    num = Number(min_length=10, max_length=10, exclusive_minimum=0, exclusive_maximum=5, multiple_of=5, allow_null=True)
    assert num.min_length == 10
    assert num.max_length == 10
    assert num.exclusive_minimum == 0
    assert num.exclusive_maximum == 5
    assert num.multiple_of == 5
    assert num.allow_null == True


# Generated at 2022-06-24 10:46:48.034281
# Unit test for method validate of class Object
def test_Object_validate():
    value = {
        "properties": [
            {"name": "name", "type": "string"},
            {"name": "age", "type": "number"},
            {"name": "likes", "type": "array"},
        ],
        "additionalProperties": False,
    }
    value1 = Object(properties = {"name":String(required=True),"age":Number(required=True),"likes":Array(required=True)},additionalProperties = False)
    print(value1.validate(value))


# Generated at 2022-06-24 10:46:57.974486
# Unit test for constructor of class Object
def test_Object():
    validator=Object(properties={"id":Integer(), "title":String()},min_properties=0, max_properties=2, required=["title"], additional_properties=False)
    assert validator.properties == {"id":Integer(), "title":String()}
    assert validator.min_properties == 0
    assert validator.max_properties == 2
    assert validator.required == ["title"]
    assert validator.additional_properties == False

# Generated at 2022-06-24 10:47:02.381588
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj = Decimal(maximum=10)
    obj.validation_error = lambda x: ValidationError()
    assert obj.serialize(11) == None
    assert obj.serialize(None) == None
    assert obj.serialize(5) == 5


# Generated at 2022-06-24 10:47:07.906231
# Unit test for method validate of class Const
def test_Const_validate():
    s = Const(const = False, allow_null = False)
    s.validate(None) # must raise ValidationError
    s.validate(True) # must raise ValidationError
    s.validate(False)
    # For Const, allow_null is always False.
    # Thus, s.validate(None) must raise ValidationError
    # and s.validate(False) must return False.

test_Const_validate()

# Unit tests for Const errors

# Generated at 2022-06-24 10:47:14.094642
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True)
    assert Boolean().validate(False)
    assert Boolean().validate(None)
    try:
        Boolean().validate(1)
    except:
        assert True
    try:
        Boolean().validate('1')
    except:
        assert True
    assert Boolean().validate('true')
    assert Boolean().validate('on')
    assert Boolean().validate(1)
    assert Boolean().validate(0)
    assert Boolean().validate('none')
    assert Boolean().validate('null')
    assert Boolean().validate('')
    assert Boolean().validate('off')
    assert Boolean().validate('false')
    assert Boolean().validate('0')

# Generated at 2022-06-24 10:47:19.408213
# Unit test for constructor of class Any
def test_Any():
    test = Any()
    assert test.validate(3) == 3
    assert test.validate(3.3) == 3.3
    assert test.validate("three") == "three"
    assert test.validate([4, 6, 7]) == [4, 6, 7]
    assert test.validate({"one": 1, "two": 2, "three": 3}) == {"one": 1, "two": 2, "three": 3}


# Generated at 2022-06-24 10:47:21.304529
# Unit test for constructor of class String
def test_String():
    s = String()
    print(s.__dict__)



# Generated at 2022-06-24 10:47:28.974732
# Unit test for method validate of class Number
def test_Number_validate():
    val = Number()
    assert val.validate(3) == 3
    assert val.validate("3") == 3
    assert val.validate("a") == Exception("Must be a number.")
    assert val.validate("5.5") == 5.5
    assert val.validate("5.5") == 5.5
    assert val.validate("a") == Exception("Must be an integer.")
    assert val.validate("5.5") == Exception("Must be an integer.")
    assert val.validate(5.5) == Exception("Must be an integer.")

test_Number_validate()

# Generated at 2022-06-24 10:47:40.221194
# Unit test for method serialize of class Array
def test_Array_serialize():
    Array().serialize([])
    Array().serialize(None)
    Array(items=String()).serialize([])
    Array(items=String()).serialize([""])
    Array(items=String()).serialize(['','','','','','','','','','','','','','','','',''])
    Array(items=String()).serialize(None)
    Array(items=[String(), String(), String()]).serialize(['','','','','','','','','','','','','','','',''])

test_Array_serialize()

    # Unit test for method validate of class Array

# Generated at 2022-06-24 10:47:48.731824
# Unit test for constructor of class Field
def test_Field():
    a = Field()
    assert a.title == ""
    assert a.description == ""
    assert not a.has_default()
    assert not a.allow_null
    assert not hasattr(a, 'default')

    b = Field(title="Test Title", description="Test Description", default=1234, allow_null=True)
    assert b.title == "Test Title"
    assert b.description == "Test Description"
    assert b.has_default()
    assert b.allow_null
    assert b.get_default_value() == 1234

    try:
        b.validate("test_value")
        assert False
    except NotImplementedError:
        assert True
    
    try:
        b.serialize("test_value")
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 10:47:57.850522
# Unit test for constructor of class Array
def test_Array():
    a = Array(items=DateTime(format='%Y-%m-%d'), min_items=2, max_items=3, unique_items=True)
    assert list(a.errors.keys()) == ['type', 'null', 'empty', 'exact_items', 'min_items', 'max_items', 'additional_items', 'unique_items']
    assert a.items == [DateTime(format='%Y-%m-%d'), DateTime(format='%Y-%m-%d')]
    assert a.additional_items == False
    assert a.min_items == 2
    assert a.max_items == 3
    assert a.unique_items == True



# Generated at 2022-06-24 10:47:59.238815
# Unit test for method serialize of class Array
def test_Array_serialize():
    # test
    array = Array()
    array.serialize([])



# Generated at 2022-06-24 10:48:06.889827
# Unit test for constructor of class Float

# Generated at 2022-06-24 10:48:19.972106
# Unit test for method validate of class Number
def test_Number_validate():
    print("\nInside test_Number_validate")
    field = Number(
        title='Test Number',
        description='Test Number',
        maximum=5
    )

    # value passed is None and self.allow_null is False, expecting ValueError
    with pytest.raises(ValidationError):
        field.validate(value=None)

    # value passed is None and self.allow_null is True
    assert field.validate(value=None, strict=True) is None

    # value passed is '' and self.allow_null is True
    assert field.validate(value='', strict=True) is None

    # value passed is 'hello' and self.numeric_type is int expecting TypeError
    with pytest.raises(ValidationError):
        field.validate(value='hello')

    # value passed

# Generated at 2022-06-24 10:48:26.777459
# Unit test for constructor of class Object
def test_Object():
    s = Object(properties={"a":CharField(max_length=20)},property_names=String(max_length=20))
    assert s.properties == {"a":CharField(max_length=20)}
    assert s.additional_properties == True
    assert s.required == []
    assert s.property_names == String(max_length=20)
    print("test_Object SUCCESS")

# Unit tests for validate method of class Object

# Generated at 2022-06-24 10:48:36.250426
# Unit test for constructor of class String
def test_String():
    # raise an error when a strict validation is requested and a null value is supplied
    str1 = String(allow_null=False)
    with pytest.raises(ValidationError):
        str1.validate(None, strict=True)
    # raise an error when a non-string value is supplied
    with pytest.raises(ValidationError):
        str1.validate(0.3)
    # do not raise an error when a null value is supplied, when allow_null is set to True
    str2 = String(allow_null=True)
    with pytest.raises(ValidationError):
        str2.validate(None, strict=True)
    # raise an error when a null value is supplied, when allow_null is set to True
    # and strict is set to False