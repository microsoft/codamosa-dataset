

# Generated at 2022-06-24 10:38:36.117789
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title="test", default=1)
    assert field.get_default_value() == 1
    field = Field(title="test", default=decimal.Decimal("1"))
    assert field.get_default_value() == decimal.Decimal("1")
    field = Field(title="test", default=lambda: 1)
    assert field.get_default_value() == 1

# Generated at 2022-06-24 10:38:43.124998
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(age=Integer(), sex=String())
    val = field.validate({"age":20, "sex": "male"})
    assert val == {"age": 20, "sex": "male"}

    # Test the validation of Object fields
    # test the case that the input value is null and allow_null is True
    field = Object(age=Integer(allow_null=True), sex=String())
    val = field.validate({"age": None, "sex": "male"})
    assert val == {"age": None, "sex": "male"}

    # test the case that the input value is null and allow_null is False
    field = Object(age=Integer(), sex=String(allow_null=False))

# Generated at 2022-06-24 10:38:49.006141
# Unit test for constructor of class Any
def test_Any():
    any_field = Any()
    assert any_field.validate(True) == True
    assert any_field.validate(False) == False
    assert any_field.validate(123) == 123
    assert any_field.validate("hej") == "hej"

# Generated at 2022-06-24 10:38:51.019304
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field.name == "Any"
    assert field.errors == {}
    assert field.allow_null == False
    assert field.description == None


# Generated at 2022-06-24 10:38:54.502172
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean()
    assert(b.allow_null)
    b = Boolean(allow_null=False)
    assert(not b.allow_null)
    assert(b.validate(1) == True)
    assert(b.validate(-1) == True)
    assert(b.validate(0) == False)
    assert(b.validate("True") == True)
    assert(b.validate("false") == False)
    assert(b.validate("null") == None)



# Generated at 2022-06-24 10:38:56.641978
# Unit test for constructor of class Float
def test_Float():
    assert(isinstance(Field.Float(),Field.Float))


# Generated at 2022-06-24 10:39:00.750848
# Unit test for method validate of class Object
def test_Object_validate():
    print("Test method validate of class Object")
    method_validate_Object_class = "validate"
    method_validate_Object_class = method_validate_Object_class.split("_")[1].title()
    f = getattr(Object, method_validate_Object_class)

# Generated at 2022-06-24 10:39:04.646520
# Unit test for constructor of class Boolean
def test_Boolean():
    value = Boolean(title="test1", description="test2", default=True, allow_null=True)
    assert value.title == "test1"
    assert value.description == "test2"
    assert value.default == True
    assert value.allow_null == True




# Generated at 2022-06-24 10:39:06.233028
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Field()
    input = 1234
    assert f.serialize(input) == 1234

# Generated at 2022-06-24 10:39:10.524996
# Unit test for method serialize of class Field
def test_Field_serialize():
    class MyField(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return str(obj)
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return 0

    field = MyField()
    assert field.serialize(10) == "10"


# Generated at 2022-06-24 10:39:12.973217
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(1) == 1

# Generated at 2022-06-24 10:39:22.813537
# Unit test for method validate of class Array
def test_Array_validate():
    from .parser import Parser

    parser = Parser(raw_schema="""
        {
            "type": "array",
            "items": [
                {"type": "string"},
                {"type": "string"},
                {"type": "string"}
            ]
        }
    """)
    schema = parser.get_result()
    arr = schema.validate(["a", "b", "c"])
    assert arr == ["a", "b", "c"]

    try:
        schema.validate(["a", "b"])
    except ValidationError as e:
        assert e.messages()[0].code == "min_items"

    try:
        schema.validate(["a", "b", "c", "d"])
    except ValidationError as e:
        assert e.messages

# Generated at 2022-06-24 10:39:26.969496
# Unit test for constructor of class Boolean
def test_Boolean():
    field = Boolean()
    assert field.errors["type"] == "Must be a boolean."
    assert field.errors["null"] == "May not be null."
    assert field.coerce_values["true"] == True
    assert field.coerce_values["false"] == False
    assert field.coerce_values[1] == True
    assert field.coerce_values[0] == False
    assert field.coerce_null_values == {"", "null", "none"}



# Generated at 2022-06-24 10:39:31.097598
# Unit test for constructor of class Field
def test_Field():  # pragma: no cover
    test_field = Field(title="Test Field", description="Test description", default=None, allow_null=True)


# Generated at 2022-06-24 10:39:39.509752
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={'name': Text(min_length=5)})
    data = {'name': 'Andy'}
    print(schema.validate(data))
    data = {'name': 'Andy2'}
    print(schema.validate(data))
    
    
    schema = Object(properties={'city': Text()})
    data = {'name': 'Andy'}
    print(schema.validate(data))
    data = {'name': 'Andy', 'city': 'GZ'}
    print(schema.validate(data))


# Generated at 2022-06-24 10:39:45.965748
# Unit test for method __or__ of class Field
def test_Field___or__():
    from . import String
    from .union import Union
    a = String(title='a')
    b = String(title='b')
    c = String(title='c')
    d = String(title='d')
    assert (a | b) == Union(any_of=[a, b])
    assert (a | b | c) == Union(any_of=[a, b, c])
    assert (a | b | c) == (c | (b | a))
    assert (a | b | c | d) == Union(any_of=[a, b, c, d])
    assert (a | b | c | d) == ((c | d) | (a | b))



# Generated at 2022-06-24 10:39:55.380858
# Unit test for method validate of class Any
def test_Any_validate():
    from jsonschema.validators import validator_for

    field = Any()
    value, error = field.validate_or_error(False)
    assert error is None, error.messages()
    assert value == False
    value, error = field.validate_or_error(True)
    assert error is None, error.messages()
    assert value == True
    value, error = field.validate_or_error(None)
    assert error is None, error.messages()
    assert value == None
    field = Any(allow_null=False)
    value, error = field.validate_or_error(None)
    assert error is None, error.messages()
    assert value == None
    field = Any(allow_null=True)

# Generated at 2022-06-24 10:40:00.985265
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = {"name": String(required=True), "value": Integer(required=True)}
    data = dict(name="abc", value="123")
    # obj=data, items=items
    field = Array(items=Object(properties=items))
    assert field.serialize(data) == [data]
    # obj=data, items=[Object(properties=items)]
    field = Array(items=[Object(properties=items)])
    assert field.serialize(data) == [data]

    # items=[Object(properties=items)]
    data = [dict(name="abc", value=123)]
    field = Array(items=[Object(properties=items)])
    assert field.serialize(data) == data
    # items=Object(properties=items)
    data = [dict(name="abc", value=123)]
    field

# Generated at 2022-06-24 10:40:08.407902
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.title == ""
    assert field.description == ""
    assert field.allow_null == False
    assert field.default == None
    assert field.has_default() == True
    assert field.get_default_value() == None
    assert field.__dict__['_creation_counter'] == 1

    field = Field(title='title', description='description', default=5, allow_null=True)
    assert field.title == 'title'
    assert field.description == 'description'
    assert field.allow_null == True
    assert field.default == 5
    assert field.has_default() == True
    assert field.get_default_value() == 5
    assert field.__dict__['_creation_counter'] == 2


# Generated at 2022-06-24 10:40:09.957413
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime()


# Generated at 2022-06-24 10:40:12.225145
# Unit test for constructor of class Boolean
def test_Boolean():
    bool_value = Boolean()
    assert bool_value.title == ""
    assert bool_value.description == ""
    assert bool_value.allow_null == False
    assert repr(bool_value) == "Boolean()"


# Generated at 2022-06-24 10:40:15.941406
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(
        choices=[
            ("Option 1", "Option 1"),
            ("Option 2", "Option 2"),
            ("Option 3", "Option 3"),
            ("Option 4", "Option 4"),
        ]
    ).validate("Option 1") == "Option 1"


# Generated at 2022-06-24 10:40:21.899165
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test_field = Boolean()
    test_strict = True
    assert test_field.validate( 0,strict = test_strict ) == True
    assert test_field.validate(1, strict = test_strict ) == True
    assert test_field.validate( "0", strict = test_strict ) == False
    assert test_field.validate( "Lara" , strict=test_strict) == True
    assert test_field.validate( "lara" , strict=test_strict) == True
    assert test_field.validate( "True" , strict=test_strict) == True
    assert test_field.validate( "true" , strict=test_strict) == True
    assert test_field.validate( "False" , strict=test_strict) == True
   

# Generated at 2022-06-24 10:40:22.820657
# Unit test for constructor of class DateTime
def test_DateTime():
    class MyDateTime(DateTime):
        pass


# Generated at 2022-06-24 10:40:24.539236
# Unit test for method validate of class String
def test_String_validate():
    strng=String()
    st = "hello"
    assert st == strng.validate("hello")

# Generated at 2022-06-24 10:40:26.237732
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    a = Field()
    assert a.get_error_text("required") == "This field is required."


# Generated at 2022-06-24 10:40:33.018045
# Unit test for method validate of class String
def test_String_validate():
    Serializer = String(max_length=100, pattern="^\w*$", allow_blank=True)
    assert Serializer.validate('1') == '1'
    try:
        Serializer.validate('')
    except ValidationError as e:
        assert e.text == 'Must have at least 1 characters.'
    try:
        Serializer.validate(True)
    except ValidationError as e:
        assert e.text == 'Must be a string.'
    try:
        Serializer.validate('helloworldhelloworldhelloworld')
    except ValidationError as e:
        assert e.text == 'Must have no more than 100 characters.'



# Generated at 2022-06-24 10:40:36.500586
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=Integer())
    result = field.serialize([1, 2, 3])
    assert result == [1, 2, 3]



# Generated at 2022-06-24 10:40:39.292887
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() is False
    assert Field(default=True).has_default() is True
    assert Field(default=NO_DEFAULT).has_default() is False


# Generated at 2022-06-24 10:40:47.078141
# Unit test for constructor of class Array
def test_Array():    
    obj1 = Array(max_items = 5)
    assert obj1.max_items == 5
    obj2 = Array(min_items = 5)
    assert obj2.min_items == 5
    obj3 = Array(min_items = 5, max_items = 10)
    assert obj3.min_items == 5 and obj3.max_items == 10
    obj4 = Array(exact_items = 5)
    assert obj4.min_items == 5 and obj4.max_items == 5
    obj5 = Array(unique_items = True)
    assert obj5.unique_items == True
    obj6 = Array(unique_items = False)
    assert obj6.unique_items == False



# Generated at 2022-06-24 10:40:48.903262
# Unit test for method validate of class Object
def test_Object_validate():
    _object = Object()
    assert _object.validate({'first': 1}) == {'first': 1}
    assert _object.validate({}) == {}
    assert _object.validate(1) == None


# Generated at 2022-06-24 10:40:50.902876
# Unit test for method validate of class String
def test_String_validate():
    S = String()
    with pytest.raises(Exception):
        S.validate(None)
    assert S.validate("123") == "123"


# Generated at 2022-06-24 10:40:53.793722
# Unit test for method validate of class Number
def test_Number_validate():
    field = Number(
        title="First Name",
        description="The person's first name.",
        )
    example = 1
    assert field.validate(value=example) == 1



# Generated at 2022-06-24 10:40:58.633979
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class MyField(Field):
        def __init__(self, *args,**kwargs):
            super(MyField, self).__init__(*args,**kwargs)
    
    instance = MyField()
    strict = True
    try:
        instance.validate_or_error(None,strict=strict)
    except Exception as e:
        print(type(e))
        print(e)


# Generated at 2022-06-24 10:41:08.629338
# Unit test for constructor of class Any
def test_Any():
    from tetchy import Item
    from tetchy.fields import String
    a = Any()
    assert isinstance(a, Field) # It is indeed a Field
    assert a.allow_null == False # Allow null is False
    assert a.default == None # Default is None
    b = Any(allow_null=True)
    assert b.allow_null == True # Allow null is True
    c = Any(default=True)
    assert c.default == True # Default value is True
    d = Any(default=String(default="hello"))
    assert isinstance(d.default, String) # Default value is String
    assert d.default.default == "hello" # Default value of String is "hello"
    e = Any(description="description")
    assert isinstance(e.description, str) # description is indeed a string

# Generated at 2022-06-24 10:41:15.137093
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("") == ""
    assert String().serialize("abc") == "abc"
    assert String(format="time").serialize("10:20:30") == "10:20:30"
    assert String(format="time").serialize("10:20:30.123") == "10:20:30.123"

    # TODO: Add tests for other formats.



# Generated at 2022-06-24 10:41:17.644140
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj.allow_null == False
    assert obj.allow_empty == False
    assert obj.min_length == 0
    assert obj.max_length == None


# Generated at 2022-06-24 10:41:18.589292
# Unit test for constructor of class Date
def test_Date():
    test_date = Date()


# Generated at 2022-06-24 10:41:26.945386
# Unit test for method serialize of class String
def test_String_serialize():
    obj = None
    assert String.serialize(obj)==obj
    obj = "2020-01-01"
    assert String.serialize(obj)==obj
    obj = "00:00:00"
    assert String.serialize(obj)==obj
    obj = "2020-01-01 00:00:00"
    assert String.serialize(obj)==obj
    obj = "a6d9bfc3-3d3e-49c7-b8e8-2713a6ddde5f"
    assert String.serialize(obj)==obj
    obj = "some string"
    assert String.serialize(obj)==obj


# Generated at 2022-06-24 10:41:30.613227
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.allow_null == False
    assert s.default == NO_DEFAULT

    s = String(default = "")
    assert s.allow_null == False
    assert s.default == ""

    s = String(allow_null = True)
    assert s.allow_null == True
    assert s.default == None

    s = String(allow_null = True, default = "")
    assert s.allow_null == True
    assert s.default == ""



# Generated at 2022-06-24 10:41:37.669670
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        def validate(self, value, *, strict = False):
            return value
    class Field2(Field):
        def validate(self, value, *, strict = False):
            return value
    test1 = Field1()
    test2 = Field2()
    test3 = test1 | test2
    assert isinstance(test3, Union)
    assert test3.any_of == [test1, test2]



# Generated at 2022-06-24 10:41:39.613710
# Unit test for constructor of class Boolean
def test_Boolean():
    t = Boolean()
    assert t.validate(True)
    assert t.validate(False)



# Generated at 2022-06-24 10:41:41.693973
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices = [1,2,3,4]) is not None


# Generated at 2022-06-24 10:41:45.010871
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert not field.has_default()

    def default():
        return
    field = Field(default=default)
    assert field.has_default()

# Generated at 2022-06-24 10:41:46.673304
# Unit test for constructor of class Field
def test_Field():
    message = Field()
    assert str(isinstance(message, Field)) == "True"


# Generated at 2022-06-24 10:41:53.837507
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=String(pattern=r'[a-z]'),
        min_items=4,
        required=True
    )

    assert field.validate(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    
    with pytest.raises(ValidationError) as excinfo:
        field.validate([])
    assert excinfo.value.messages()[0].text == "Must have at least 4 items."

    with pytest.raises(ValidationError) as excinfo:
        field.validate(['a', 'b', 'c'])
    assert excinfo.value.messages()[0].text == "Must have at least 4 items."


# Generated at 2022-06-24 10:41:58.562695
# Unit test for constructor of class Union
def test_Union():
    a = String(required=True)
    b = DateTime(required=True)

    # Test that Union constructor initializes self.any_of correctly
    u = Union(any_of = [a, b])

    assert(a == u.any_of[0])
    assert(b == u.any_of[1])


# Generated at 2022-06-24 10:41:59.463302
# Unit test for method validate of class Array
def test_Array_validate():
    for f in Array(items=Integer()).validate([1]):
        print(type(f))

# Generated at 2022-06-24 10:42:02.566542
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(1) == 1
    assert field.serialize(True) == True
    assert field.serialize("Hello") == "Hello"
    assert field.serialize(None) == None


# Generated at 2022-06-24 10:42:06.213491
# Unit test for constructor of class Field
def test_Field():
    f = Field(title = "Field testing", description = "Field test description", default = 123)
    assert f.title == "Field testing"
    assert f.description == "Field test description"
    assert f.default == 123
    assert f.allow_null == False


# Generated at 2022-06-24 10:42:11.040910
# Unit test for constructor of class Date
def test_Date():
    test_field = Date()
    assert(test_field.format == "date")
    assert(test_field.errors == String.errors.copy())


# Generated at 2022-06-24 10:42:12.099416
# Unit test for constructor of class Integer
def test_Integer():
    Int =Integer()
    print(Int)


# Generated at 2022-06-24 10:42:14.692985
# Unit test for method validate of class Const
def test_Const_validate():
    test_const = Const(const=3)
    assert test_const.validate(3) == 3
    with pytest.raises(ValidationError):
        test_const.validate(2)

# Generated at 2022-06-24 10:42:15.864781
# Unit test for constructor of class Float
def test_Float():
    value = 1.1
    assert isinstance(value, float)


# Generated at 2022-06-24 10:42:18.387312
# Unit test for method validate of class Number
def test_Number_validate():
    result = Number().validate(12345.67)
    assert result == 12345.67

# Generated at 2022-06-24 10:42:19.905755
# Unit test for constructor of class Date
def test_Date():
    with pytest.raises(AssertionError):
        Date("")



# Generated at 2022-06-24 10:42:29.740517
# Unit test for method validate of class String
def test_String_validate():
	txt1 = String()
	txt2 = String(allow_null=True)
	txt3 = String(allow_blank=True)
	txt4 = String(trim_whitespace=True)
	txt5 = String(max_length=5)
	txt6 = String(min_length=3)
	txt7 = String(pattern="^[a-z]+$")
	txt8 = String(format="date")
	txt9 = String(allow_null=True, allow_blank=True, trim_whitespace=True, max_length=5, min_length=3, pattern="^[a-z]+$", format="date")
	
	assert txt1.validate("") == ""
	assert txt1.validate(" ") == ""

# Generated at 2022-06-24 10:42:31.485892
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(title="Field_has_default")
    assert not field.has_default()

    field.default = "default"
    assert field.has_default()

# Generated at 2022-06-24 10:42:32.851331
# Unit test for constructor of class DateTime
def test_DateTime():
    test_DateTime = DateTime()
    assert test_DateTime.allow_null == False


# Generated at 2022-06-24 10:42:45.087327
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(value=True) == True
    assert Boolean().validate(value=False) == False
    assert Boolean().validate(value=None) == None
    assert Boolean().validate(value=True) == True
    assert Boolean().validate(value=False) == False
    assert Boolean().validate(value="true") == True
    assert Boolean().validate(value="false") == False
    assert Boolean().validate(value="on") == True
    assert Boolean().validate(value="off") == False
    assert Boolean().validate(value="1") == True
    assert Boolean().validate(value="0") == False
    assert Boolean().validate(value="") == False
    assert Boolean().validate(value=1) == True
    assert Boolean().validate(value=0) == False

# Generated at 2022-06-24 10:42:54.602697
# Unit test for constructor of class String
def test_String():
    assert(String())
    assert(String(title='String'))
    assert(String(description='String'))
    assert(String(default=''))
    assert(String(allow_blank=True))
    assert(String(allow_null=True))
    assert(String(allow_blank=True, allow_null=True))
    assert(String(allow_blank=False, allow_null=False))
    assert(String(trim_whitespace=False))
    assert(String(trim_whitespace=True))
    assert(String(min_length=5))
    assert(String(max_length=5))
    assert(String(min_length=5, max_length=5))
    assert(String(pattern='[A-Za-z0-9]+'))

# Generated at 2022-06-24 10:42:56.802039
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default="This is a default value")
    assert field.get_default_value() == "This is a default value"


# Generated at 2022-06-24 10:43:05.108661
# Unit test for constructor of class String
def test_String():
    string = String(
        title = "Date",
        description = "The date for the message",
        format = "date",
        allow_blank=False,
        trim_whitespace=True,
        max_length=10,
        min_length=5
    )
    assert string.title == "Date"
    assert string.description == "The date for the message"
    assert string.format == "date"
    assert string.allow_blank == False
    assert string.trim_whitespace == True
    assert string.max_length == 10
    assert string.min_length == 5



# Generated at 2022-06-24 10:43:15.288735
# Unit test for constructor of class Const
def test_Const():
    const = Const(None)
    exceptions = []
    try:
        const.validate(123)
    except ValidationError as e:
        exceptions.append(e)
    assert len(exceptions) == 1
    assert isinstance(exceptions[0], ValidationError)
    assert str(exceptions[0]) == "Const: Must be null."
    try:
        const.validate(None)
    except ValidationError as e:
        exceptions.append(e)
    assert len(exceptions) == 1
    assert isinstance(exceptions[0], ValidationError)
    assert str(exceptions[0]) == "Const: Must be null."
    const2 = Const(None,allow_null=False)
    try:
        const2.validate(None)
    except ValidationError as e:
        exceptions

# Generated at 2022-06-24 10:43:17.448373
# Unit test for constructor of class Union
def test_Union():
    assert Union([Integer(), Number()]).any_of == [Integer(), Number()]


# Generated at 2022-06-24 10:43:20.638613
# Unit test for method validate of class Union
def test_Union_validate():
    validated, error = Union( 
        [
            Text(allow_null=True, allow_blank=False, pattern=r"\d+")
        ]
    ).validate_or_error("0000000")
    assert(validated == "0000000")



# Generated at 2022-06-24 10:43:21.753104
# Unit test for constructor of class Time
def test_Time():
    t = Time()
    assert t.format == "time"
    assert t.min_length == 0
    assert t.max_length == None


# Generated at 2022-06-24 10:43:32.663318
# Unit test for constructor of class Boolean
def test_Boolean():
  #assert a valid boolean
  try:
    assert Boolean().validate_or_error(True).value == True
    assert Boolean().validate_or_error(False).value == False
    print("\tvalidated boolean")
  except:
    print("\tFailed to assert boolean")

  #assert valid boolean as string

# Generated at 2022-06-24 10:43:33.878079
# Unit test for method validate of class Field
def test_Field_validate():
    pass
test_Field_validate()

# Generated at 2022-06-24 10:43:42.400546
# Unit test for method validate of class Object
def test_Object_validate():
    # Object.validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
    with pytest.raises(ValidationError):
        number = Number()
        string = String()
        myObject = Object(
            properties={"name":string, "number":number}, 
            required=["name"]
        )
        myObject.validate({"number":3})

    with pytest.raises(ValidationError):
        myObject = Object(
            properties={"name":string, "number":number}, 
            required=["name"]
        )
        myObject.validate([])
    with pytest.raises(ValidationError):
        myObject = Object(
            properties={"name":string, "number":number}, 
            required=["name"]
        )
       

# Generated at 2022-06-24 10:43:46.569849
# Unit test for constructor of class Array
def test_Array():
    arr = Array(min_items=10, max_items=20)
    assert arr.min_items == 10
    assert arr.max_items == 20
    assert arr.errors["max_items"] == "Must have no more than 20 items."

# Generated at 2022-06-24 10:43:52.910723
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(12) == 12
    try:
        assert number.validate(12.343) == 12.343
    except ValidationError:
        pass
    try:
        assert number.validate('12.343') == '12.343'
    except ValidationError:
        pass
    try:
        assert number.validate('true') == 'true'
    except ValidationError:
        pass
    try:
        assert number.validate('') == ''
    except ValidationError:
        pass
    try:
        assert number.validate(True) == True
    except ValidationError:
        pass



# Generated at 2022-06-24 10:43:55.692212
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    field.errors = {"code": "this is error"}
    assert field.get_error_text("code") == "this is error"

test_Field_get_error_text()

# Generated at 2022-06-24 10:43:57.933452
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.format == "date"
    date = Date(default = '2020-08-08')
    assert date.format == "date"
    try:
        date = Date(default = 'hello')
    except ValidationError as e:
        assert e.messages()[0].code == "format"


# Generated at 2022-06-24 10:44:05.888402
# Unit test for constructor of class String
def test_String():
    # Create a new object of the class String
    str_obj = String()
    assert str_obj.title == ""
    assert str_obj.description == ""
    assert hasattr(str_obj, "default") == False
    assert str_obj.allow_null == False

    str_obj = String(title="title", description="description", default="default", allow_null=True)
    assert str_obj.title == "title"
    assert str_obj.description == "description"
    assert str_obj.default == "default"
    assert str_obj.allow_null == True

    # Create a new object of the class String
    str_obj = String(allow_blank=True)
    assert str_obj.allow_blank == True
    assert str_obj.trim_whitespace == True
    assert str_obj.max

# Generated at 2022-06-24 10:44:12.177476
# Unit test for constructor of class Text
def test_Text():
    t1 = Text()
    assert t1.format == "text"
    assert t1.min_length is None
    assert t1.max_length is None
    assert t1.regex is None
    assert t1.allow_null
    assert t1.errors == String.errors
    assert t1.validate(None) == None
    with pytest.raises(ValidationError):
        t1.validate("")
    assert t1.validate("s") == "s"
    t2 = Text(min_length=0, allow_null=False)
    assert t2.min_length == 0
    assert t2.allow_null == False
    assert t2.validate("") == ""
    with pytest.raises(ValidationError):
        t2.validate(None)
    t3

# Generated at 2022-06-24 10:44:15.418892
# Unit test for constructor of class String
def test_String():
    field = String(title="age", max_length=5)
    assert field.title == "age"
    assert field.max_length == 5


# Generated at 2022-06-24 10:44:20.242330
# Unit test for constructor of class Date
def test_Date():
    with pytest.raises(AssertionError):
        Date(format = 'text')
    with pytest.raises(AssertionError):
        Date(name='my_date')
    assert Date(name='my_date', format='date').name == 'my_date'
    assert Date(name='my_date', format='date', 
                description='optional date field').description == 'optional date field'


# Generated at 2022-06-24 10:44:25.056300
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
        Test casefunction for Field.__or__
    """
    x = Int() | String()
    assert x.validate(1) == 1
    assert x.validate("abc") == "abc"
    assert x.validate(["abc"]) == None
    assert x.validate({1:2}) == None




# Generated at 2022-06-24 10:44:31.451926
# Unit test for constructor of class Array
def test_Array():

    validator = Array(items=[Integer(), Integer()])
    assert validator.items == [Integer(), Integer()]

    validator = Array(items=[Integer()])
    assert validator.items == [Integer()]

    validator = Array(items=Integer())
    assert validator.items == Integer()

    validator = Array(additional_items=Integer())
    assert validator.additional_items == Integer()


# Generated at 2022-06-24 10:44:37.532928
# Unit test for constructor of class Number
def test_Number():
    num = Number(maximum=100, allow_null=True, description='number', title='num')
    assert num.validate(1) == 1
    assert num.validate(num.allow_null) is None
    assert num.validate(num.title) is None
    assert num.validate(num.description) is None
    assert num.validate(num.maximum) == 100

test_Number()



# Generated at 2022-06-24 10:44:40.805100
# Unit test for constructor of class Date
def test_Date():
    test_date = Date()
    #print("format of test_date is: ")
    #print(test_date.format)
    assert test_date.format == "date"


# Generated at 2022-06-24 10:44:44.619826
# Unit test for constructor of class Field
def test_Field():
    def test_field(title:str,description:str):
        x = Field(title=title,description=description)
        assert x.title == title
        assert x.description == description
    test_field("title1","description1")
    test_field("title2","description2")
    test_field("title3","description3")


# Generated at 2022-06-24 10:44:55.569298
# Unit test for constructor of class Object
def test_Object():
    test_field = Object(default="test_field")
    assert test_field.default == "test_field"
    assert test_field.allow_null == False
    assert test_field.allow_coerce == False
    assert test_field.properties == {}
    assert test_field.pattern_properties == {}
    assert test_field.additional_properties == True
    assert test_field.property_names is None
    assert test_field.min_properties is None
    assert test_field.max_properties is None
    assert test_field.required == []


# Generated at 2022-06-24 10:44:58.450139
# Unit test for method validate of class String
def test_String_validate():
    f = String()
    assert f.validate('abc') == 'abc'
    assert f.validate('abc') != 123

# Generated at 2022-06-24 10:45:05.016443
# Unit test for constructor of class Field
def test_Field():
    print("Testing constructor of class Field")
    title = "New Title"
    description = "New Description"
    default = "First"
    allow_null = True
    new_field = Field(title=title,description=description,default=default,allow_null=allow_null)
    assert new_field.title == title
    assert new_field.description == description
    assert new_field.default == default
    assert new_field.allow_null == allow_null


# Generated at 2022-06-24 10:45:07.271871
# Unit test for constructor of class Const
def test_Const():
    c = Const(const=None)
    assert c is not None
    assert c.const is None
    assert c.allow_null == False

# Generated at 2022-06-24 10:45:08.953310
# Unit test for constructor of class Date
def test_Date():
    s = Date()
    assert type(s) == String

# Unit test

# Generated at 2022-06-24 10:45:11.082442
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(default=1)
    assert (field.has_default() == True)
    field = Field()
    assert (field.has_default() == False)



# Generated at 2022-06-24 10:45:13.449752
# Unit test for method validate of class Field
def test_Field_validate():
    try:
        raise NotImplementedError()
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:45:15.512748
# Unit test for method serialize of class Array
def test_Array_serialize():
    val = [1, 2, 3]
    field = Array(items=Integer())
    assert field.serialize(val) == val


# Generated at 2022-06-24 10:45:25.085298
# Unit test for constructor of class Float
def test_Float():
    # test default constructor
    f = Float()
    assert f.title == ""
    assert f.allow_null == False
    assert f.minimum == None
    assert f.maximum == None
    assert f.exclusive_minimum == None
    assert f.exclusive_maximum == None
    assert f.precision == None
    assert f.multiple_of == None
    assert f.description == ""
    assert f.numeric_type == float

# Generated at 2022-06-24 10:45:31.751979
# Unit test for constructor of class Number
def test_Number():
    a = Number(minimum=1, maximum=10, exclusive_minimum=2, exclusive_maximum=8, multiple_of=5, precision="5")
    assert a.minimum==1
    assert a.maximum==10
    assert a.exclusive_minimum==2
    assert a.exclusive_maximum==8
    assert a.multiple_of==5
    assert a.precision=="5"



# Generated at 2022-06-24 10:45:40.282532
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Get the class.
    input_class = Field
    output_class = Field
    # Get the method.
    input_method = 'validate_or_error'
    output_method = 'validate_or_error'
    # Skip tests where input is complex.
    if not isinstance(input_class, (str, type)):
        return
    output_class = input_class if output_class is None else output_class
    output_inst = output_class() if output_class else None
    def _get_obj(input_class, input_args, input_kwargs):
        input_inst = input_class() if input_class else None
        if callable(input_inst):
            input_inst = input_inst(input_args, input_kwargs)

# Generated at 2022-06-24 10:45:53.418760
# Unit test for method validate of class String
def test_String_validate():
    def test_String_validate_1():
        obj = String()
        obj.allow_null = False
        obj.allow_blank = False
        value = 'value'
        assert obj.validate(value, strict = False) == value

    def test_String_validate_2():
        obj = String()
        obj.allow_null = True
        obj.allow_blank = False
        value = None
        assert obj.validate(value, strict = False) == None

    def test_String_validate_3():
        obj = String()
        obj.allow_null = False
        obj.allow_blank = True
        value = None
        assert obj.validate(value, strict = False) == None

    def test_String_validate_4():
        obj = String()
        obj.allow_null = True

# Generated at 2022-06-24 10:45:57.988991
# Unit test for constructor of class Integer
def test_Integer():
    int_field = Integer(title="Int Field", default=0, allow_null=False, minimum=0, maximum=100)
    assert int_field.title == "Int Field"
    assert int_field.default == 0
    assert int_field.allow_null == False
    assert int_field.minimum == 0
    assert int_field.maximum == 100
    assert int_field.numeric_type == int


# Generated at 2022-06-24 10:46:08.208721
# Unit test for method validate of class Union
def test_Union_validate():
  union = Union(any_of = [])
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False
  assert union.validate(value, strict) is None
  
  
  value = None
  strict = False

# Generated at 2022-06-24 10:46:19.418012
# Unit test for constructor of class Array
def test_Array():
    # test with items is None
    new_array = Array()
    assert new_array.items is None
    assert new_array.additional_items is False
    assert new_array.min_items is None
    assert new_array.max_items is None
    assert new_array.unique_items is False

    # test with items is list
    class Object(Field):
        pass
    new_array = Array(items = [Object(), String()])
    assert new_array.items[0].__class__.__name__ == "Object"
    assert new_array.items[1].__class__.__name__ == "String"
    assert new_array.additional_items is False
    assert new_array.min_items == 2
    assert new_array.max_items == 2
    assert new_array.unique_items

# Generated at 2022-06-24 10:46:26.126846
# Unit test for method serialize of class Field
def test_Field_serialize():
    # Intialising instances
    field1 = Field()
    # Calling the class method
    serialize = field1.serialize(obj=None)
    assert serialize == None
    # asserting the types
    assert isinstance(serialize, type(None))

# Generated at 2022-06-24 10:46:28.273470
# Unit test for method validate of class Field
def test_Field_validate():
    
    field = Field()
    assert field.validate(1) == 1

# Generated at 2022-06-24 10:46:30.745732
# Unit test for constructor of class String
def test_String():
    s = String(max_length=10)
    assert s.max_length == 10
    assert s.title == ""


# Generated at 2022-06-24 10:46:41.151996
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationError, ValidationResult
    import inspect
    import os
    import sys
    import unittest

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    from typesystem.base import Array, Boolean, DateTime, Number, Object, String

    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    class InvalidField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            raise self.validation_error("invalid")



# Generated at 2022-06-24 10:46:48.645566
# Unit test for constructor of class Object
def test_Object():

    a = Field()
    b = Field()
    c = Field()

    obj = Object(
        properties={
            "a": a,
            "b": b,
            "c": c
        },
        pattern_properties={
            "d": a,
            "e": b,
            "f": c
        },
        additional_properties=False,
        property_names=Boolean(),
        min_properties=1,
        max_properties=4,
        required=["a", "b", "c"]
    )

    assert obj.properties == {"a": a, "b": b, "c": c}
    assert obj.pattern_properties == {"d": a, "e": b, "f": c}
    assert obj.additional_properties is False
    assert obj.property_names is Boolean()

# Generated at 2022-06-24 10:46:56.867509
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    if isinstance(value, bool):
        return value
    else:
        True
    if value is None and self.allow_null:
        return None
    else:
        True
    raise self.validation_error("null")
    if not isinstance(value, bool):
        return False
    else:
        True
    if strict:
        return True
    else:
        True
    if isinstance(value, str):
        return True
    else:
        True
    if self.allow_null and value in self.coerce_null_values:
        return None
    else:
        True
    return True


# Generated at 2022-06-24 10:46:58.979340
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean(allow_null=False)
    assert b.allow_null == False


# Generated at 2022-06-24 10:47:03.025591
# Unit test for constructor of class Const
def test_Const():
    """
    Tests constructor of class Const
    """
    Const(5)
    Const(5, allow_null=True)
    Const(5, allow_null=False)
    Const(None)
    Const(None, allow_null=True)



# Generated at 2022-06-24 10:47:07.446090
# Unit test for constructor of class String
def test_String():
    assert String(min_length=5).min_length == 5
    assert String(min_length=None).min_length == None
    assert String(max_length=None).max_length == None
    assert String(max_length=None, min_length=5).max_length == None

# Test for method validate() from class String with positive integer
# and negative integer min_length

# Generated at 2022-06-24 10:47:13.030647
# Unit test for method validate of class Union
def test_Union_validate():
    n = Negate(Integer(minimum=-1,maximum=1,enum=[-1,0,1]))
    ne = Negate(Integer(minimum=-1,maximum=1))
    u = Union([n,ne])
    assert u.validate(0) == 0
    assert u.validate(1) == 1
    assert u.validate(-1) == -1
    assert u.validate(2) == -2
    assert u.validate(-2) == 2 
    assert u.validate(None) == None
    try:
        assert u.validate('a') == TypeError
    except:
        pass

# Generated at 2022-06-24 10:47:14.706302
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("A", "A")])
    assert field.validate("A") == "A"
test_Choice_validate()



# Generated at 2022-06-24 10:47:15.275713
# Unit test for method __or__ of class Field
def test_Field___or__():
    pass



# Generated at 2022-06-24 10:47:21.362575
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj1 = Decimal()
    assert obj1.serialize(0) == 0
    assert obj1.serialize(2) == 2
    assert obj1.serialize(3.0) == 3.0
    assert obj1.serialize(4.20) == 4.2
    assert obj1.serialize(5.30) == 5.3



# Generated at 2022-06-24 10:47:26.980029
# Unit test for method serialize of class Array
def test_Array_serialize():
    def serialize(value):
        if isinstance(value, bool):
            return not value
        return value

    class Bool(Field):
        def serialize(self, obj):
            return serialize(obj)

    class Item(Field):
        def serialize(self, obj):
            return serialize(obj)

    array = Array(items=Item())
    assert array.serialize([True, False, True]) == [False, True, False]

    array = Array(items=[Item(), Item()])
    assert array.serialize([True, False]) == [False, True]

    array = Array(items=Item())
    assert array.serialize(None) is None

    array = Array(items=Bool())
    assert array.serialize([True, False]) == [False, True]


# Generated at 2022-06-24 10:47:30.985665
# Unit test for constructor of class Object
def test_Object():
    obj = Object()
    print(obj.properties)
    print(obj.pattern_properties)
    print(obj.additional_properties)
    print(obj.property_names)
    print(obj.min_properties)
    print(obj.max_properties)
    print(obj.required)
    print(obj.errors)



# Generated at 2022-06-24 10:47:37.709295
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    my_field = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
    my_field.errors = {"invalid_choice": "x"}
    assert my_field.validation_error('invalid_choice').text == "x"
    assert my_field.validation_error('invalid_choice').code == 'invalid_choice'



# Generated at 2022-06-24 10:47:39.825423
# Unit test for constructor of class Boolean
def test_Boolean():
    field = Boolean(allow_blank=False, allow_null=True, description="", title="")
    assert field is not None


# Generated at 2022-06-24 10:47:41.239519
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime().format == "datetime"



# Generated at 2022-06-24 10:47:45.185738
# Unit test for constructor of class Any
def test_Any():
    f1 = Any()
    assert f1.validate(3, strict=False) == 3
    assert f1.validate('ab', strict=False) == 'ab'
    assert f1.validate(None, strict=False) == None


# Generated at 2022-06-24 10:47:49.893968
# Unit test for method validate of class Any
def test_Any_validate():
    any_field = Any()
    assert any_field.validate(None) == None

    # Test when _allow_null is False
    any_field = Any(allow_null=False)
    assert any_field.validate(None) != None

test_Any_validate()


# Generated at 2022-06-24 10:47:52.814881
# Unit test for method has_default of class Field
def test_Field_has_default():
    a = Field(default=1)
    assert a.has_default() == True
    b = Field()
    assert b.has_default() == False

#Unit test for method get_default_value of class Field

# Generated at 2022-06-24 10:48:02.801250
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("") == ""
    assert String().serialize("abc") == "abc"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="time").serialize("05:00:00") == "05:00:00"
    assert String(format="datetime").serialize("2020-01-01T00:00:00") == "2020-01-01T00:00:00"

# Generated at 2022-06-24 10:48:04.963611
# Unit test for constructor of class DateTime
def test_DateTime():
    # Should not raise error
    DateTime()

# Generated at 2022-06-24 10:48:06.509865
# Unit test for method validate of class Field
def test_Field_validate():
    assert "function" in repr(Field.validate)

# Generated at 2022-06-24 10:48:14.786346
# Unit test for method validate of class Field
def test_Field_validate():
    d = Decimal()
    assert d.validate(0) == Decimal(0) , "Test 1 fail"
    assert d.validate(-5) == Decimal(-5) , "Test 2 fail"
    assert d.validate(5.5) == Decimal(5.5) , "Test 3 fail"
    assert d.validate(0.5) == Decimal(0.5) , "Test 4 fail"
    assert d.validate(0.000000000000005) == Decimal(0.000000000000005) , "Test 5 fail"
    assert d.validate(0.00000000000000000000000000005) == Decimal(0.00000000000000000000000000005) , "Test 6 fail"
    try:
        d.validate('abc')
        test7 = False
    except Exception:
        test7 = True
    assert test7

# Generated at 2022-06-24 10:48:17.268863
# Unit test for method validate of class Any
def test_Any_validate():
    print("Testing validate method of class Any")
    try:
        for x in range(10):
            p = Any()
            assert p.validate(x)==x
    except:
        return False
    return True


# Generated at 2022-06-24 10:48:21.286474
# Unit test for method validate of class Union
def test_Union_validate():
    validator = Union([Integer(), Number()])
    value = 5
    res = validator.validate(value)
    assert res == 5
    value = "string"
    with pytest.raises(ValidationError):
        validator.validate(value)



# Generated at 2022-06-24 10:48:29.859184
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal.getcontext().prec = 2
    dictionary = json.loads('{"content": "a"}', object_pairs_hook=collections.OrderedDict)
    field = Decimal(maximum=1)
    assert field.serialize(decimal.Decimal("123.456")) == 123.46
    assert field.validate_or_error(1.2) == ValidationResult(None, ValidationError("Must be less than 1."))
    assert field.validate_or_error(dictionary) == ValidationResult(None, ValidationError("Must be a number."))
    assert field.validate_or_error("123.456") == ValidationResult(123.46, None)



# Generated at 2022-06-24 10:48:37.042816
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union([Integer(), String()]).validate(123) == 123
    assert Union([Integer(), String()]).validate("abc") == "abc"

    with pytest.raises(ValidationError):
        Union([Integer(), String()]).validate(None)

    with pytest.raises(ValidationError):
        Union([Integer(), String()]).validate(123.123)

    # Raise "union" error because all children failed to validate
    with pytest.raises(ValidationError) as excinfo:
        Union([Integer(), String()]).validate(True)
    assert excinfo.value.messages()[0].code == "union"

    # Raise "type" error because only one children failed to validate