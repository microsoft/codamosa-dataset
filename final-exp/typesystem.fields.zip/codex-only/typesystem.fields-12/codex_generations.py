

# Generated at 2022-06-24 10:38:34.675095
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        Choice(choices = [(0,0), (1,1), (2,2), (3,3)]).validate(4)
    except ValidationError:
        return
    raise AssertionError

# Generated at 2022-06-24 10:38:41.178017
# Unit test for method validate of class Number
def test_Number_validate():
    sd = Number(minimum = 0, maximum = 100, precision = '.1')
    assert sd.validate(5) == 5
    assert sd.validate(5.5) == 5.5
    assert sd.validate('5.5') == 5.5
    assert sd.validate(5.57) == 5.6
    with pytest.raises(ValidationError):
        sd.validate(101)
    with pytest.raises(ValidationError):
        sd.validate(-1)
    with pytest.raises(ValidationError):
        sd.validate("abc")
    with pytest.raises(ValidationError):
        sd.validate("1abc")
    with pytest.raises(ValidationError):
        sd.validate("abc1")

# Generated at 2022-06-24 10:38:43.882809
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test_object = Boolean()
    assert test_object.validate(False) == False
    assert test_object.validate(0) == False
    assert test_object.validate("0") == False
    assert test_object.validate("") == False
    assert test_object.validate(None) == None


# Generated at 2022-06-24 10:38:45.025208
# Unit test for constructor of class Integer
def test_Integer():
    my_integer = Integer()
    assert isinstance(my_integer, Integer)



# Generated at 2022-06-24 10:38:45.974772
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert isinstance(f.numeric_type, type)

# Generated at 2022-06-24 10:38:53.056064
# Unit test for method validate of class Field
def test_Field_validate():
    errors = {
        "null": "Field may not be null.",
        "blank": "Field may not be blank.",
        "max_length": "Field may not be longer than {max_length} characters.",
        "min_length": "Field may not be shorter than {min_length} characters.",
    }
    def validate(self, value, *, strict=False):
        value = self.to_python(value)
        if not value and self.globals.required:
            raise ValidationError("This field is required.")
        return value
    Field.validate = validate
    Field.errors = errors
    f = Field(title='',description='')
    f.validate(None)


# Generated at 2022-06-24 10:39:04.824483
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(2) == 2
    assert Field().serialize(None) is None
    assert Field().serialize(1.4) == 1.4
    assert Field().serialize(False) is False
    assert Field().serialize(True) is True
    assert Field().serialize(True) is True
    assert Field().serialize(False) is False
    assert Field().serialize('') == ''
    assert Field().serialize(b'apple') == b'apple'
    assert Field().serialize({'key':'value'}) == {'key':'value'}
    assert Field().serialize(['key', 'value']) == ['key', 'value']
    assert Field().serialize('apple') == 'apple'
    assert Field().serialize('2') == '2'

# Generated at 2022-06-24 10:39:05.742507
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
  assert True


# Generated at 2022-06-24 10:39:06.769815
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice({"this is a choice": "choice"})
    assert obj.validate("this is a choice") == "choice"


# Generated at 2022-06-24 10:39:09.160937
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(description='animal')
    assert obj.validate('animal') == 'animal'
    assert obj.validate('') == ''
    assert obj.validate(None) == None
    assert obj.validate(1) == 1
    assert obj.validate(False) == False
    assert obj.validate('cat') == 'cat'
# Test to check method serialize of the class Choice

# Generated at 2022-06-24 10:39:12.709654
# Unit test for constructor of class Union
def test_Union():
    range_validator = Range(maximum=100)
    string_validator = String()
    numeric_union = Union(any_of=[range_validator, string_validator])
    with pytest.raises(ValidationError) as exc:
        numeric_union.validate("101")
    assert exc.value.code == "union"
    with pytest.raises(ValidationError) as exc:
        numeric_union.validate("a string")
    assert exc.value.code == "union"
    with pytest.raises(ValidationError) as exc:
        numeric_union.validate(101)
    assert exc.value.code == "maximum"



# Generated at 2022-06-24 10:39:22.752670
# Unit test for constructor of class Object
def test_Object():
    class Dummy(Object):
        pass
    dummy = Dummy()
    assert not hasattr(dummy, "properties")
    assert not hasattr(dummy, "pattern_properties")
    assert not hasattr(dummy, "additional_properties")
    assert not hasattr(dummy, "property_names")
    assert not hasattr(dummy, "min_properties")
    assert not hasattr(dummy, "max_properties")
    assert not hasattr(dummy, "required")

    properties = {"x": "a"}
    pattern_properties = {"y": "a"}
    additional_properties = "a"
    property_names = "a"
    min_properties = "a"
    max_properties = "a"
    required = ["a"]


# Generated at 2022-06-24 10:39:23.734577
# Unit test for method validate of class Array
def test_Array_validate():
    pass



# Generated at 2022-06-24 10:39:25.636691
# Unit test for method serialize of class String
def test_String_serialize():
    class MyString(String):
        pass
    ms = MyString()
    assert ms.serialize("hello") == "hello"



# Generated at 2022-06-24 10:39:33.620066
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean()
    assert isinstance(boolean, Boolean)
    assert hasattr(boolean, "validate")
    assert boolean.validate("True") == True
    assert boolean.validate(1) == True
    # test for validation for incorrect type passed
    with pytest.raises(ValidationError):
        boolean.validate("hello")
    # test for validation for null value
    with pytest.raises(ValidationError):
        boolean.validate(None)


# Generated at 2022-06-24 10:39:35.482935
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    t = Field(title="test")
    assert t.get_default_value() is None

# Generated at 2022-06-24 10:39:39.669240
# Unit test for constructor of class Object
def test_Object():
   assert Object(additional_properties="a") is not None
   assert Object(properties="a") is not None
   assert Object(pattern_properties="a") is not None
   assert Object(min_properties="a") is not None
   assert Object(max_properties="a") is not None
   assert Object(required="a") is not None



# Generated at 2022-06-24 10:39:42.563600
# Unit test for constructor of class Boolean
def test_Boolean():
    f = Boolean(True)
    assert f.validate(True, strict=False) == True
    assert f.validate(False, strict=False) == False
    assert f.allow_null == True
    return None


# Generated at 2022-06-24 10:39:46.932924
# Unit test for method has_default of class Field
def test_Field_has_default():
    f1 = Field()
    f2 = Field(default=5)
    assert not f1.has_default()
    assert f2.has_default()


# Generated at 2022-06-24 10:39:48.917375
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const("a",title="field",description="field")
    const = "a"
    assert field.validate(const) == const

# Generated at 2022-06-24 10:39:56.946796
# Unit test for constructor of class String
def test_String():
    str1 = String(title="string type")
    result_str1 = str1.validate("I am a string")
    expected_str1 = "I am a string"
    assert result_str1 == expected_str1
    
    str2 = String(title="string type", format="datetime")
    result_str2 = str2.validate("2019-01-01")
    expected_str2 = datetime.datetime(2019, 1, 1, 0, 0)
    assert result_str2 == expected_str2
    
    str3 = String(title="string type", format="datetime", trim_whitespace=True)
    result_str3 = str3.validate("  2019-01-01    ")
    expected_str3 = datetime.datetime(2019, 1, 1, 0, 0)

# Generated at 2022-06-24 10:40:05.089580
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(title="My age", allow_null=True).validate(None) is None
    assert Number(title="My age", description="My age must be an integer").validate(28) == 28
    assert Number(
               title="My age",
               description="My age must be a float",
               numeric_type=float,
            ).validate(28.2) == 28.2
    assert Number(
               title="My age",
               description="My age must be an integer",
               numeric_type=int,
            ).validate(28.2) == 28


# Generated at 2022-06-24 10:40:10.329467
# Unit test for method validate of class Array
def test_Array_validate():
    # Create an array field
    array_field = Array(
        items = [
            Integer(),
            String(max_length=10),
            Boolean()
        ],
        unique_items = True
    )
    
    # Test for valid input
    valid_input = ["1", 2, "hello", True]
    value, error = array_field.validate_or_error(valid_input)
    assert error == None
    assert value == [1, "hello", True]
    
    # Test for invalid input
    invalid_input = ["a", 2, "hello", True]
    value, error = array_field.validate_or_error(invalid_input)
    assert value == None
    assert error != None
    assert error.code == "invalid_type"
    
    # Test for empty input
    empty

# Generated at 2022-06-24 10:40:12.840313
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d=Decimal()
    assert d.serialize(1)==float(1)
    assert d.serialize(None)==None
test_Decimal_serialize()



# Generated at 2022-06-24 10:40:14.767907
# Unit test for constructor of class Text
def test_Text():
    test_text = Text()
    assert test_text.format == "text"


# Generated at 2022-06-24 10:40:16.956676
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import Boolean, String
    field = String() | Boolean()
    assert field.any_of == [String(), Boolean()]



# Generated at 2022-06-24 10:40:20.852423
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value*2
    x = TestField()
    assert x.validate_or_error(50).value == 100
    assert x.validate_or_error(50, strict=True).value == 100

# Generated at 2022-06-24 10:40:27.599668
# Unit test for constructor of class String
def test_String():
    temp = String(max_length = 50)
    assert temp.max_length == 50
    assert temp.errors == {'type': 'Must be a string.', 'null': 'May not be null.', 'blank': 'Must not be blank.', 'max_length': 'Must have no more than {max_length} characters.', 'min_length': 'Must have at least {min_length} characters.', 'pattern': 'Must match the pattern /{pattern}/.', 'format': 'Must be a valid {format}.'}


# Generated at 2022-06-24 10:40:32.928405
# Unit test for constructor of class Union
def test_Union():
    field = Union(
        [
            String(required=True),
            String(),
            Boolean(),
            Integer(),
            Number()
        ]
    )
    x = field.validate(False)
    print(x)
    


# Generated at 2022-06-24 10:40:41.545129
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    from typesystem import Number, String, Boolean
    from typesystem import Schema

    class A(Schema):
        # edge cases of get_default_value
        x = Number(default=1)
        y = Number(default=lambda: 1)
        z = Union([String(default=''), Boolean(default=False)])
        w = Union([Number, String])

    assert type(A()) == A
    assert set(A().keys()) == set(('x', 'y', 'z', 'w'))
    assert A().x == 1
    assert A().y == 1
    assert A().z == ''
    assert A().w is None

# Generated at 2022-06-24 10:40:50.589181
# Unit test for method validate_or_error of class Field

# Generated at 2022-06-24 10:40:52.532199
# Unit test for method validate of class String
def test_String_validate():
    with pytest.raises(NotImplementedError):
         String().validate(1)

# Generated at 2022-06-24 10:41:01.930911
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    # test null
    value = field.validate(None)
    assert value is None
    # test str
    value = field.validate('string')
    assert value == 'string'
    # test str with whitespace in the head or tail
    value = field.validate('   string     ')
    assert value == 'string'
    # test integer
    with pytest.raises(ValidationError):
        value = field.validate(123)
    # test float
    with pytest.raises(ValidationError):
        value = field.validate(0.5)
    # test bool
    with pytest.raises(ValidationError):
        value = field.validate(True)



# Generated at 2022-06-24 10:41:04.340829
# Unit test for constructor of class Any
def test_Any():
    instance = Any()
    assert instance.allow_null == False
    assert instance.name is None
    assert instance.default_value is None

# Generated at 2022-06-24 10:41:13.628265
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert a.__class__.__name__ == "Text"
    assert a.errors.keys() == {"format"}
    assert a._adapter == None
    assert a._default == None
    assert a.description == None
    assert a.enum == None
    assert a.const == None
    assert a.title == None
    assert a.allow_null == False
    assert a.manual_default == False
    assert a.validate( "ABC" ) == "ABC"
    assert a.validate( 1 ) == "1"
    assert a.validate( None ) == "None"
    assert a.validate( False ) == "False"
    assert a.validate( True ) == "True"



# Generated at 2022-06-24 10:41:21.335333
# Unit test for method validate of class Const
def test_Const_validate():
    _const = Const(const = None,
                allow_null = False,
                default = None,
                enum = None,
                title = None,
                description = None)
    assert _const.validate(value = None) == None
    _const = Const(const = None,
                allow_null = True,
                default = None,
                enum = None,
                title = None,
                description = None)
    assert _const.validate(value = None) == None
    _const = Const(const = 'Value',
                allow_null = True,
                default = None,
                enum = None,
                title = None,
                description = None)
    assert _const.validate(value = 'Value') == 'Value'

# Generated at 2022-06-24 10:41:26.730676
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Example(object):
        pass
    example = Example()
    field = Array()
    assert (field.serialize(example)) is None

    field = Array()
    assert (field.serialize(example)) is None

    field = Array()
    assert (field.serialize(example)) is None

    field = Array()
    assert (field.serialize(example)) is None

    field = Array()
    assert (field.serialize(example)) is None

    field = Array()
    assert (field.serialize(example)) is None


# Generated at 2022-06-24 10:41:27.683700
# Unit test for constructor of class Integer
def test_Integer():
    assert isinstance(Integer(), Integer)


# Generated at 2022-06-24 10:41:30.716766
# Unit test for constructor of class Const
def test_Const():
    t0 = Const(const=None, default=1)
    assert t0.const is None
    assert t0.default == 1

    t1 = Const(const=4, default=1)
    assert t1.const == 4
    assert t1.default == 1



# Generated at 2022-06-24 10:41:32.492853
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=[('1','1')]).choices is not None
    assert Choice(choices=['1']).choices is not None
        

# Generated at 2022-06-24 10:41:37.782034
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error(123).value == 123
    try:
        field.validate_or_error(123, strict=True)
    except NotImplementedError:
        pass
    else:
        assert False # pragma: no cover

# Generated at 2022-06-24 10:41:41.218581
# Unit test for method validate of class Field
def test_Field_validate():
    expected_result = "not implemented"  # pragma: no cover
    # Act
    actual_result = Field().validate()
    # Assert
    assert actual_result == expected_result

# Generated at 2022-06-24 10:41:48.716553
# Unit test for method validate of class Union
def test_Union_validate():
    try:
        Union([Number(), String()]).validate(1)
        raise Exception()
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].text == "Must be a string."
        assert e.messages()[0].code == "type"
        assert e.messages()[0].index == []
        assert e.messages()[0].key is None
        assert e.messages()[0].constraint == "type"

    try:
        Union([Number(), String()]).validate("1")
        raise Exception()
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].text == "Must be a number."
        assert e.messages()[0].code

# Generated at 2022-06-24 10:41:59.635304
# Unit test for constructor of class Decimal
def test_Decimal():
    # Test the constructor of class Decimal
    a = Decimal(minimum=1,maximum=2,exclusive_minimum=2,exclusive_maximum=1,precision=2,multiple_of=2)   
    b = Decimal(minimum=1,maximum=2,exclusive_minimum=2,exclusive_maximum=1,precision=2,multiple_of=2)
    assert a == b
    c = Decimal(minimum=2,maximum=2,exclusive_minimum=2,exclusive_maximum=1,precision=2,multiple_of=2)
    assert not (a == c)
    d = Decimal(minimum=1,maximum=1,exclusive_minimum=2,exclusive_maximum=1,precision=2,multiple_of=2)
    assert not (a == d)

# Generated at 2022-06-24 10:42:08.874532
# Unit test for method serialize of class Array
def test_Array_serialize():
    from json_schema import Array, Integer

    field = Array(items=Integer())
    value = [1, 2, 3]
    assert field.serialize(value) == value

    field = Array(items=[Integer(minimum=0), Integer(minimum=1)])
    value = [0, 1]
    assert field.serialize(value) == value

    list_of_num = [1, 2, 3]
    expected = [1, 2, 3]
    assert Array(items=Integer()).serialize(list_of_num) == expected

    list_of_str = ["a", "b", "c"]
    expected = ["a", "b", "c"]
    assert Array(items=String()).serialize(list_of_str) == expected

    list_of_bool = [True, False]
    expected

# Generated at 2022-06-24 10:42:11.662742
# Unit test for constructor of class Date
def test_Date():
    schema = Date()
    assert str(schema) == "{}"
    assert schema.allow_null == False
    assert schema.format == "date"
    assert schema.default == None
    assert schema.choices == []
    assert schema.description == None
    assert schema.title == None


# Generated at 2022-06-24 10:42:22.090702
# Unit test for method validate of class Object
def test_Object_validate():
 
        # Test for algorithm 1
        obj = {
            'a': 'a',
            'b': 'b',
            'c': 'c'
        }
        assert test_object.validate(obj) == obj
        # Test for algorithm 2
        obj = {}
        assert test_object.validate(obj) == obj
        # Test for algorithm 3
        obj = {
            'a': 'a',
            'b': 'b',
            'd': 'd'
        }
        # Here because a is not in self.required, the program will continue the loop
        # When it get to the 'd', because d is not in self.properties and not in self.pattern_properties and self.additional_properties is True,
        # So the program will add d to validated
        # When it get to the 'b', because b

# Generated at 2022-06-24 10:42:23.131716
# Unit test for constructor of class Text
def test_Text():
    field = Text(title="Text test")
    assert field.title == "Text test"
    assert field.format == "text"



# Generated at 2022-06-24 10:42:24.807654
# Unit test for method serialize of class String
def test_String_serialize():
	string_object = String()
	# Test for serialize method of String when format is date
	assert string_object.serialize(FORMATS['date'].deserialize()) == FORMATS['date'].serialize()



# Generated at 2022-06-24 10:42:27.001616
# Unit test for constructor of class Const
def test_Const():

    const = Const(const = 4)
    value = 4
    strict = True
    assert const.validate(value, strict) == value
    value = 3
    assert const.validate(value, strict) != value
    test = None
    assert const.validate(value, strict) != test



# Generated at 2022-06-24 10:42:32.043615
# Unit test for method has_default of class Field
def test_Field_has_default():
    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            pass
        def serialize(self, obj: typing.Any) -> typing.Any:
            pass

    field = TestField(title='Test Field')
    assert field.has_default() is False
    field = TestField(title='Test Field', default=None)
    assert field.has_default() is True


# Generated at 2022-06-24 10:42:33.783839
# Unit test for constructor of class Integer
def test_Integer():
    myint = Integer()
    assert myint is not None


# Generated at 2022-06-24 10:42:37.254457
# Unit test for method validate of class Number
def test_Number_validate():
    class TestNumber(Number):
        pass
    test_number = TestNumber()
    assert test_number.validate(2)==2
    assert test_number.validate("3")==3

# Generated at 2022-06-24 10:42:39.657131
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("") is not None
    assert String().validate("123") is not None


# Generated at 2022-06-24 10:42:51.186758
# Unit test for constructor of class Array
def test_Array():
    schema = Array(items = 'true')
    print(schema.items.allow_null)
    assert schema.items.allow_null == True
    print(schema)

# Generated at 2022-06-24 10:43:03.073052
# Unit test for method validate of class Object
def test_Object_validate():
    a = Object(properties={'a':Boolean()},required=['a'])
    assert a.validate({'a':True}) ==  {'a':True}
    assert a.validate({'a':'True'}) ==  {'a':True}

    a = Object(properties={'a':Boolean(allow_null=True)},required=['a'])
    assert a.validate({'a':True}) ==  {'a':True}
    assert a.validate({'a':None}) ==  {'a':None}
    with pytest.raises(ValidationError):
        a.validate({'a':'True'})
    assert a.validate({'a':''}) ==  {'a':None}

    # Check null value.

# Generated at 2022-06-24 10:43:06.109740
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    if Field().get_error_text("simple") != "simple":
        raise RuntimeError



# Generated at 2022-06-24 10:43:11.750023
# Unit test for method validate of class Object
def test_Object_validate():
    print('\nTest Object validate')
    d = {'a': 1, 'b': 2, 'c': 3}
    schema = Object(properties = {'a': Field(), 'b': Integer(), 'c': Float()})
    res = schema.validate(d)
    print(d)
    print(res)

# Generated at 2022-06-24 10:43:14.085270
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(precision='0.01') is not None

# Generated at 2022-06-24 10:43:16.734124
# Unit test for constructor of class Time
def test_Time():
    try:
        Time()
    except:
        assert 1, "Error in constructor of Time class!"
    else:
        assert 0, "Failed to raise exception in constructor of class Time!"

# Generated at 2022-06-24 10:43:18.296320
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    assert any.allow_null
    assert any.default_value is None
    assert any.description == ""
    assert any.type == "any"


# Generated at 2022-06-24 10:43:23.266076
# Unit test for constructor of class Float
def test_Float():
    my_Float = Field(title='myFloat', description='myFloat, it is a float', 
                     allow_null=False, default=None)
    assert my_Float.title == 'myFloat'
    assert my_Float.description == 'myFloat, it is a float'
    assert my_Float.allow_null == False
    assert my_Float.default == None
#Unit test for method validate of class Float

# Generated at 2022-06-24 10:43:33.492113
# Unit test for constructor of class Object
def test_Object():
    # test if default constructor works
    test_obj = Object(properties={'test': String()})
    assert(test_obj.properties == {'test': String()})
    assert(test_obj.pattern_properties == {})
    assert(test_obj.additional_properties == True)
    assert(test_obj.property_names == None)
    assert(test_obj.min_properties == None)
    assert(test_obj.max_properties == None)
    assert(test_obj.required == [])

    # test if all constructor fields work

# Generated at 2022-06-24 10:43:35.252373
# Unit test for constructor of class String
def test_String():
    field = String()
    assert field.trim_whitespace == True


# Generated at 2022-06-24 10:43:43.202864
# Unit test for method validate of class Object
def test_Object_validate():
    import json
    import pytest
    from schematics.exceptions import ConversionError
    from schematics.exceptions import DataError
    from schematics.exceptions import ValidationError
    from schematics.models import Model
    from schematics.types import BaseType
    from schematics.types import BooleanType
    from schematics.types import DictType
    from schematics.types import IntType
    from schematics.types import ListType
    from schematics.types import ModelType
    from schematics.types import StringType
    from schematics.types import UUIDType
    from schematics.transforms import blacklist
    from schematics.transforms import export_loop
    from schematics.transforms import validate


# Generated at 2022-06-24 10:43:48.802480
# Unit test for method validate of class Const
def test_Const_validate():
    test_schema = Const(3)
    assert test_schema.validate(3) == 3
    check_message = {
        "code": "const",
        "text": "Must be the value '3'.",
        }
    expected = ValidationError(check_message)
    with raises(ValidationError) as e:
        test_schema.validate(4)
    assert e.value.toDict() == expected.toDict()
    check_message = {
        "code": "only_null",
        "text": "Must be null.",
        }
    expected = ValidationError(check_message)
    with raises(ValidationError) as e:
        test_schema.validate(None)
    assert e.value.toDict() == expected.toDict()

# Unit

# Generated at 2022-06-24 10:43:56.070076
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
	f = Field()
	try:
		f.get_default_value()
	except AttributeError as e:
		print(e)
		f = Field(default=1)
		assert f.get_default_value() == 1
		f = Field(default=lambda : 2)
		assert f.get_default_value() == 2
		f = Field(default=NO_DEFAULT)
		assert f.get_default_value() == None
test_Field_get_default_value()


# Generated at 2022-06-24 10:44:00.176336
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    value = [1, 2, 3]
    assert field.validate(value) == [1, 2, 3]
    assert field.validate(None) == None
    try:
        field.validate(2)
    except ValidationError:
        pass
    else:
        raise Exception('ValidationError not raised')


# Generated at 2022-06-24 10:44:02.633015
# Unit test for method serialize of class Field
def test_Field_serialize():
    string_field = String()
    assert string_field.serialize("test") == "test"



# Generated at 2022-06-24 10:44:04.971284
# Unit test for constructor of class Union
def test_Union():
    field = Union([Integer(), Text()])
    assert isinstance(field, Field)
    assert isinstance(field, Union)
    assert field.any_of == [Integer(), Text()]


# Generated at 2022-06-24 10:44:07.346409
# Unit test for constructor of class Float
def test_Float():
    f = Float(maximum=1, minimum=2)



# Generated at 2022-06-24 10:44:10.073362
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Field.errors
    x = Decimal(title="number",description="number")
    assert x.title == "number"
    assert x.description == "number"
    assert x.numeric_type == decimal.Decimal
    assert x.errors == d



# Generated at 2022-06-24 10:44:17.053695
# Unit test for method serialize of class String
def test_String_serialize():
    #Sceneario 1: Object is None
    field = String()
    if field.serialize(None) != None:
        raise AssertionError()
    #Scenario 2: Object is str
    if field.serialize('123') != '123':
        raise AssertionError()
    #Scenario 3: Object is not str and not None
    if field.serialize(123) == 123:
        raise AssertionError()



# Generated at 2022-06-24 10:44:21.059609
# Unit test for constructor of class Integer
def test_Integer():
    test_Integer = Integer(title="test", description="test", default=None, allow_null=False)
    assert test_Integer.title == "test"
    assert test_Integer.description == "test"
    assert test_Integer.default == None
    assert test_Integer.allow_null == False


# Generated at 2022-06-24 10:44:22.250335
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text("code") == ""



# Generated at 2022-06-24 10:44:26.767915
# Unit test for constructor of class Text
def test_Text():
    #1 Testing if string is valid
    text = Text()
    # print(text)
    assert text.validate('Hello, World!') == 'Hello, World!'

    #2 Testing if string contains integer
    assert text.validate('123') == '123'



# Generated at 2022-06-24 10:44:29.184052
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert not Field(title='t', description='d').has_default()
    assert Field(title='t', description='d', default=None).has_default()

# Generated at 2022-06-24 10:44:36.283034
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        "a": Field(),
        "b": Field(),
        "c": Field(),
        "f": Field(default=3.1),
        "h": Field(default=None),
        "k": Field(default=1),
    }
    pattern_properties = {"d.*": Field(), "e(.)": Field(), "g(.*)": Field()}
    additional_properties = False
    required = ["a", "b", "c"]
    min_properties = 2
    max_properties = 3

# Generated at 2022-06-24 10:44:39.002615
# Unit test for method validate of class Const
def test_Const_validate():
    c = Const(None)
    c.validate(None)
    c = Const(4)
    c.validate(4)


# Generated at 2022-06-24 10:44:45.766139
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    if field.format != "text":
        raise AssertionError(
            'Field.format must be "text" is "{}" instead'.format(field.format)
        )



# Generated at 2022-06-24 10:44:52.719531
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """ Unit test for method get_default_value of class Field """
    title = "title"
    description = "description"
    default = "default"
    allow_null = True
    field = Field(title=title,description=description,default=default,allow_null=allow_null)
    assert field.get_default_value() == default

# Generated at 2022-06-24 10:44:59.754534
# Unit test for constructor of class Float
def test_Float():
    field = Float(
        title="Float",
        description="float number",
        allow_null=False,
        maximum=10,
        minimum=-10,
        exclusive_minimum=-9,
        exclusive_maximum=9,
        multiple_of=0.5
    )
    assert field.title == "Float"
    assert field.description == "float number"
    assert field.allow_null == False
    assert field.maximum == 10
    assert field.minimum == -10
    assert field.exclusive_minimum == -9
    assert field.exclusive_maximum == 9
    assert field.multiple_of == 0.5
# Unit test ends here



# Generated at 2022-06-24 10:45:03.873367
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    f = Field(default=3)
    assert f.get_default_value() == 3

    def default():
        return 4

    f = Field(default=default)
    assert f.get_default_value() == 4

# Generated at 2022-06-24 10:45:10.321007
# Unit test for method validate of class Union
def test_Union_validate():
    V1 = String(max_length=10)
    V2 = String(min_length=20)
    VF = String(min_length=10, max_length=30)
    scheme = Union([V1, V2, VF])
    assert scheme.validate('passed') == 'passed'
    assert scheme.validate('other_passed') == 'other_passed'
    assert scheme.validate('other_passed_other_') == 'other_passed_other_'



# Generated at 2022-06-24 10:45:12.469242
# Unit test for constructor of class Float
def test_Float():
    f1 = Float()
    f2 = Float(allow_null=False, title='blabla', description='blabla')



# Generated at 2022-06-24 10:45:16.482095
# Unit test for constructor of class Choice
def test_Choice():
    class MyChoice(Choice):
        pass
    choices = [(1,2), ('a','b')]
    x = MyChoice(choices=choices)
    expected_choices = [(1,2), ('a','b')]

    assert x.choices == expected_choices
test_Choice()


# Generated at 2022-06-24 10:45:18.156665
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert f is not None
    assert len(f.errors) == 0


# Generated at 2022-06-24 10:45:19.520984
# Unit test for constructor of class Boolean
def test_Boolean():
    # Should be able to instantiate Boolean
    Boolean()



# Generated at 2022-06-24 10:45:28.510987
# Unit test for method __or__ of class Field
def test_Field___or__(): # pragma: no cover
    import typesystem
    class_ = typesystem.Field
    instance = typesystem.Field()
    another_instance = typesystem.Field()
    assert isinstance(instance | another_instance, typesystem.Union)
    assert isinstance(instance | another_instance, typesystem.Field)



# Generated at 2022-06-24 10:45:34.536858
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices = [True, False])
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(None) is None
    assert choice.validate("") is None
    assert choice.validate(0) == True
    assert choice.validate(1) == False



# Generated at 2022-06-24 10:45:40.453066
# Unit test for constructor of class String
def test_String():
    str_field = String(title="string field", description="a string field", allow_blank=True, trim_whitespace=True, max_length=100, min_length=1, pattern=".*", format="uuid")
    assert str_field.title == "string field"
    assert str_field.description == "a string field"
    assert str_field.allow_blank
    assert str_field.trim_whitespace
    assert str_field.max_length == 100
    assert str_field.min_length == 1
    assert str_field.pattern == ".*"
    assert str_field.format == "uuid"



# Generated at 2022-06-24 10:45:43.064486
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field_1 = Field()
    field_1.errors['code'] = 'error type'
    assert field_1.validation_error('code').code == 'code'
    

# Generated at 2022-06-24 10:45:43.748428
# Unit test for constructor of class Integer
def test_Integer():
    Integer()



# Generated at 2022-06-24 10:45:45.570202
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert isinstance(field, Field)


# Generated at 2022-06-24 10:45:52.145761
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    msg = a.validate([None, None])
    assert msg == [None, None]
    msg = a.validate([1, 2])
    assert msg == [1, 2]
    msg = a.validate(["1", 2])
    assert msg == ["1", 2]
    try:
        a.validate("testing")
    except ValidationError:
        return True
    else:
        return False



# Generated at 2022-06-24 10:45:57.659235
# Unit test for method validate of class Object
def test_Object_validate():
    title = 'test_Object_validate'
    test_start_print(title)
    #object_with_string (可以傳入string)
    test_Object_validate_string(title)
    #object_without_string (不可以傳入string)
    test_Object_validate_without_string(title)
    #object_with_string_number (可以傳入string number)
    test_Object_validate_string_number(title)
    #object_without_string_number (不可以傳入string number)
    test_Object_validate_without_string_number(title)
    #object_with_string_boolean (可以傳入string boolean)
    test_Object_validate_string_

# Generated at 2022-06-24 10:46:04.201611
# Unit test for constructor of class Number
def test_Number():
    # Test case
    n = Number(minimum=10, maximum=20, exclusive_minimum=15, exclusive_maximum=25)
    assert n.minimum == 10
    assert n.maximum == 20
    assert n.exclusive_minimum == 15
    assert n.exclusive_maximum == 25
    # Test case
    m = Number(precision = '1.33')
    assert m.precision == '1.33'


# Generated at 2022-06-24 10:46:11.278072
# Unit test for constructor of class Boolean
def test_Boolean():
    b1=Boolean(title="Boolean", description="Field to identify if a value is true or false")
    assert b1.title == "Boolean"
    assert b1.description == "Field to identify if a value is true or false"
    assert b1.allow_null == False
    assert b1.allow_blank == False
    assert b1.has_default() == False
    assert b1.validate(None, strict=False) == None
    assert b1.validate(1234, strict=False) == None
    assert b1.validate(True, strict=False) == True
    assert b1.validate(False, strict=False) == False
    assert b1.validate("True", strict=False) == True
    assert b1.validate("False", strict=False) == False
    assert b1

# Generated at 2022-06-24 10:46:14.904147
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert (Integer() | String()).any_of == [Integer(), String()]
    assert (Integer() | Integer() | Integer()).any_of == [Integer(), Integer(), Integer()]

# Generated at 2022-06-24 10:46:16.782130
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field.errors == {}
    assert field.allow_null == False



# Generated at 2022-06-24 10:46:25.073466
# Unit test for method validate of class Choice
def test_Choice_validate():
    data = ["M", "F", "Male", "Female"]
    result = Choice(choices=data).validate("M")
    assert result == "M"
    result = Choice(choices=data).validate("Male")
    assert result == "Male"
    result = Choice(choices=data).validate("m")
    assert result == "m"
test_Choice_validate()    
    

# Generated at 2022-06-24 10:46:31.717470
# Unit test for method serialize of class String
def test_String_serialize():
    # Test string object without format
    string_object = String(allow_blank=False, format="")
    assert string_object.serialize("2020-07-31") == "2020-07-31"
    # Test string object with format
    string_object = String(allow_blank=False, format="date")
    assert string_object.serialize("2020-07-31") == "2020-07-31"

# test if object without format skips the function of FORMATS

# Generated at 2022-06-24 10:46:42.361461
# Unit test for constructor of class Date
def test_Date():
    # Test default class
    Field = fields.Date()
    print(f"Test default class Date: {Field}")
    # Test class with minimum
    Field = fields.Date(minimum="2020-01-01")
    print(f"Test class Date with minimum: {Field}")
    # Test class with maximum
    Field = fields.Date(maximum="2020-12-31")
    print(f"Test class Date with maximum: {Field}")
    # Test class with minLength
    Field = fields.Date(minimumLength=5)
    print(f"Test class Date with minimumLength: {Field}")
    # Test class with maxLength
    Field = fields.Date(maximumLength=100)
    print(f"Test class Date with maximumLength: {Field}")
    # Test class with minLength and maxLength

# Generated at 2022-06-24 10:46:49.122068
# Unit test for constructor of class Array
def test_Array():
    # Set archer intervals to 0 ms
    archer.utils.interval = 0
    # Test constructor of Array
    def test_Array_constructor():
        # Test items as a list
        def test_items_as_a_list():
            # Test required and unique properties
            def test_required_and_unique_properties():
                # Define a schema to be tested
                class TestSchema(Schema):
                    my_array = Array(
                        items=[
                            String(required=True, unique=True),
                            String(required=True, unique=True),
                        ]
                    )
                # Create a schema
                schema = TestSchema()
                # Define a value to be tested
                value1 = ["test1", "test2"]
                # Define a value to be tested

# Generated at 2022-06-24 10:46:50.628571
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(None) == None


# Generated at 2022-06-24 10:46:56.235925
# Unit test for constructor of class Choice
def test_Choice():
    choice=Choice(choices=['1', '2'])
    assert(choice.validate('1')=='1')
    assert(choice.validate('2')=='2')
    assert Raises(ValidationError,choice.validate,'3')
    choice=Choice(choices=[('1', 'a'), '2'])
    assert(choice.validate('1')=='1')
    assert(choice.validate('2')=='2')
    assert Raises(ValidationError,choice.validate,'3')


# Generated at 2022-06-24 10:47:05.851715
# Unit test for constructor of class Number
def test_Number():
    # case with all arguments
    test_number = Number(minimum = 0, maximum = 1, exclusive_minimum = 0, exclusive_maximum = 1, precision = "0.01", multiple_of = 1)
    assert test_number.minimum == 0
    assert test_number.maximum == 1
    assert test_number.exclusive_minimum == 0
    assert test_number.exclusive_maximum == 1
    assert test_number.precision == "0.01"
    assert test_number.multiple_of == 1

    # case without arguments
    test_number = Number()
    assert test_number.minimum == None
    assert test_number.maximum == None
    assert test_number.exclusive_minimum == None
    assert test_number.exclusive_maximum == None
    assert test_number.precision == None
    assert test_number.multiple_of == None

# Generated at 2022-06-24 10:47:06.516953
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime()

# Generated at 2022-06-24 10:47:08.357600
# Unit test for constructor of class Time
def test_Time():
    t = Time()
    assert t.format == "time"


# Generated at 2022-06-24 10:47:09.990685
# Unit test for method serialize of class String
def test_String_serialize():
    obj = 'aaa'
    str1 = String()
    assert str1.serialize(obj) == 'aaa'


# Generated at 2022-06-24 10:47:11.483105
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_field = Decimal()
    action = decimal_field.serialize(Decimal('10.00'))
    assert action == 10.00


# Generated at 2022-06-24 10:47:16.020973
# Unit test for constructor of class Number
def test_Number():
    n = Number()
    assert n.minimum == None
    assert n.maximum == None
    assert n.exclusive_minimum == None
    assert n.exclusive_maximum == None
    assert n.multiple_of == None
    assert n.precision == None


# Generated at 2022-06-24 10:47:17.104460
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.format == "text"
    assert t.description == None


# Generated at 2022-06-24 10:47:19.444315
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=["xx", "zz"])


# Generated at 2022-06-24 10:47:20.709847
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert isinstance(date, String)
    assert date.format == 'date'


# Generated at 2022-06-24 10:47:30.668057
# Unit test for constructor of class Const
def test_Const():
    
    schema_builder = Const(1)
    print(schema_builder.const)
    print(type(schema_builder))
    print(type(schema_builder.validate_or_error(1)))
    print(schema_builder.validate_or_error(2))
    print(schema_builder.validate_or_error(None))
    print(schema_builder.validate_or_error(1))
    print(schema_builder.validate_or_error(2))
    print(schema_builder.validate_or_error(1))
    print(schema_builder.validate_or_error(1))
    print(schema_builder.validate_or_error(2))
    print(schema_builder.validate_or_error(1))
   

# Generated at 2022-06-24 10:47:37.662480
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.types import String
    from typesystem.utils import validate_and_return
    error_msg = ['error','msg']
    field = String(errors=error_msg)
    validate = validate_and_return(field, 'msg')
    validate('')
    assert(validate('') == [error_msg[1],None])


# Generated at 2022-06-24 10:47:46.948549
# Unit test for constructor of class Text
def test_Text():
    assert Text(name="A name", description="Some text")
    assert Text(name="A name", description="Some text", default="Hello")
    assert Text(name="A name", description="Some text", default="").default is None
    assert Text(name="A name", description="Some text", allow_null=True)
    assert Text(name="A name", description="Some text", required=True)
    try:
        Text(name="A name", description="Some text", allow_null=False, required=True)
    except TypeError:
        pass
    assert Text(name="A name", description="Some text", allow_blank=True)
    assert Text(name="A name", description="Some text", max_length=100)

# Generated at 2022-06-24 10:47:54.746055
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    field.errors = {
        "invalid" : "Invalid"
    }
    assert field.get_error_text("invalid") == "Invalid"


# Generated at 2022-06-24 10:48:04.637157
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object()
    test_data = {
        "": {},
        "null": {},
        "true": {},
        "false": {},
        "object": {},
        "array": [],
        "number": 0,
        "string": "",
        "invalid_key": {1.2: 0, "key": True},
        "invalid_property": {"$bad_key": True},
        "empty": {},
        "max_properties": {0: 0, 1: 1, 2: 2, 3: 3},
        "object_key_error": {0.0: 0},
        "min_properties": {}
    }

# Generated at 2022-06-24 10:48:06.750660
# Unit test for constructor of class Integer
def test_Integer():
    myfield = Integer()
    assert myfield.numeric_type == int


# Generated at 2022-06-24 10:48:11.666608
# Unit test for constructor of class String
def test_String():
    field = String(max_length=50, min_length=2, pattern=r'\d+')
    assert field.max_length == 50
    assert field.min_length == 2
    assert field.pattern == r'\d+'
    assert field.pattern_regex.pattern == r'\d+'



# Generated at 2022-06-24 10:48:17.650418
# Unit test for constructor of class Float
def test_Float():
    obj = Float(minimum=1.23, maximum=24.56, exclusive_minimum=3.45, exclusive_maximum=4.56, precision="0.01")
    assert obj.minimum == 1.23
    assert obj.maximum == 24.56
    assert obj.exclusive_minimum == 3.45
    assert obj.exclusive_maximum == 4.56
    assert obj.precision == "0.01"
    assert obj.numeric_type == float


# Generated at 2022-06-24 10:48:19.665346
# Unit test for constructor of class Date
def test_Date():
    d = Date()
    assert d.format == "date"
    assert d.allow_null == False



# Generated at 2022-06-24 10:48:29.718223
# Unit test for constructor of class Union
def test_Union():
    any = String()
    none = String()
    text = String()
    number = Number()
    integer = Integer()
    boolean = Boolean()
    test = Union([any, boolean, text])
    assert test.allow_null == False
    test = Union([any, none, text])
    assert test.allow_null == True
    test = Union([text, boolean])
    assert test.allow_null == False
    test = Union([boolean, text])
    assert test.allow_null == False
    test = Union([any, number, text])
    assert test.allow_null == False
    test = Union([any, number, integer, text])
    assert test.allow_null == False
    test = Union([any, none, number, integer, text])
    assert test.allow_null == True

# Generated at 2022-06-24 10:48:34.023524
# Unit test for method validate of class Field
def test_Field_validate():
    # assert that the state of the object is correct
    f1 = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
    assert f1.allow_null == False
    assert f1.default == NO_DEFAULT
    assert f1.description == ""
    assert f1.title == ""
    assert f1.validate(5) == 5
