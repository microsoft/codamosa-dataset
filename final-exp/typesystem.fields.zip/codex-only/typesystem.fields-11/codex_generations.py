

# Generated at 2022-06-24 10:38:38.329972
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Define test inputs and expected outputs
    all_inputs = [
        (
            "FunctionInputs",
            [  # any_of
                "any_of_0",  # self
                "any_of_1",  # other
            ],
            [  # any_of
                "any_of_0",  # self
                "any_of_1",  # other
            ],
            "ReturnValue",
        )
    ]
    all_outputs = [
        "ReturnValue"
    ]

    # Define mock objects
    class MockField:
        any_of = [
            "any_of_0",
            "any_of_1",
        ]

        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 10:38:41.122518
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_field = Decimal()
    decimal_field.validate(12, strict=True)
    decimal_field.validate(0.01, strict=True)
    decimal_field.validate(-0.01, strict=True)
    decimal_field.validate(decimal.Decimal('.01'), strict=True)



# Generated at 2022-06-24 10:38:44.975379
# Unit test for constructor of class Float
def test_Float():
    with pytest.raises(AssertionError) as e:
        Float(allow_null=True, maximum=100)
    assert str(e.value) == "assert maximum is None or isinstance(maximum, (int, float, decimal.Decimal))"
    with pytest.raises(AssertionError) as e:
        Float(allow_null=True, minimum=1)
    assert str(e.value) == "assert minimum is None or isinstance(minimum, (int, float, decimal.Decimal))"



# Generated at 2022-06-24 10:38:48.854375
# Unit test for method __or__ of class Field
def test_Field___or__():
    from .fields import Integer, String, Union
    assert (Integer() | String()) == Union([Integer(), String()])
    assert (Integer() | Integer()) == Integer()
    assert (Integer() | (String() | Integer())) == Union([Integer(), String()])
    assert ((String() | Integer()) | Integer()) == Union([String(), Integer()])
    assert (String() | (String() | Integer())) == Union([String(), Integer()])



# Generated at 2022-06-24 10:38:54.630397
# Unit test for constructor of class Any
def test_Any():
    a = Any()
    assert a.validate(1) == 1
    assert a.validate(0.5) == 0.5
    assert a.validate("Hello") == "Hello"
    assert a.validate(["A", "B"]) == ["A", "B"]
    assert a.validate({"A": "B"}) == {"A": "B"}
    assert a.validate(True) == True
    assert a.validate(None) == None

test_Any()



# Generated at 2022-06-24 10:39:05.730620
# Unit test for constructor of class Field
def test_Field():
    # Test for constructor of class Field
    f1 = Field()
    assert f1._creation_counter == 0
    assert f1.title == ""
    assert f1.description == ""
    assert f1.allow_null == False
    f2 = Field(title="title",description="description",default="default",allow_null=True)
    assert f2._creation_counter == 1
    assert f2.title == "title"
    assert f2.description == "description"
    assert f2.allow_null == True
    # Test for method validate
    try:
        f2.validate(5)
    except NotImplementedError:
        assert True
    # Test for method serialize
    assert f2.serialize("obj") == "obj"
    # Test for method has_default
    assert f2.has_default

# Generated at 2022-06-24 10:39:10.251073
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a = Decimal(title="a")
    assert a.serialize(None) == None
    assert a.serialize(3)==3.0
    assert a.serialize(3.6)==3.6
    assert a.serialize(3.1)==3.1
    assert a.serialize(-55)==-55.0

# Generated at 2022-06-24 10:39:11.822767
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items = String())
    assert field.serialize(["a", "b", "c"]) == ["a", "b", "c"]


# Generated at 2022-06-24 10:39:19.590588
# Unit test for method validate of class String
def test_String_validate():
    test_string_1 = String(
        title="Test string 1",
        description="Test string 1",
        allow_null=True,
        allow_blank=True,
        trim_whitespace=True,
        max_length=10,
        min_length=3,
        pattern=r'[a-zA-Z0-9]+',
        format=""
    )

    assert test_string_1.validate("") == None
    assert test_string_1.validate("test") == "test"



# Generated at 2022-06-24 10:39:23.355861
# Unit test for method validate of class String
def test_String_validate():
    field = String(format="datetime")
    value = "2013-06-10T08:00:00Z"
    result = field.validate(value)
    assert isinstance(result, datetime.datetime)


# Generated at 2022-06-24 10:39:25.160109
# Unit test for constructor of class DateTime
def test_DateTime():
    d = DateTime(required=True, format='datetime')
    assert isinstance(d, String) and d.required


# Generated at 2022-06-24 10:39:29.238181
# Unit test for method serialize of class String
def test_String_serialize():
    if str(String().serialize(12)) == '12':
        print("test_String_serialize: success")
    else:
        print("test_String_serialize: fail")
test_String_serialize()



# Generated at 2022-06-24 10:39:33.327635
# Unit test for constructor of class Time
def test_Time():
    test_schema = Time()
    print(test_schema.errors['type'])
    #test_schema.validate("aaa")
    #assert test_schema.validate("aaa") is False
#test_Time()



# Generated at 2022-06-24 10:39:36.548736
# Unit test for constructor of class Time
def test_Time():
    try:
        assert_equal(Time().__init__.__name__, "__init__")
    except Exception as e:
        print("Unit test for Time constructor failed.", e)
    else:
        print("Unit test for Time constructor passed.")



# Generated at 2022-06-24 10:39:44.436332
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2006-12-04T14:45:00") == "2006-12-04T14:45:00"
    assert String(format="date").serialize("2000-01-01") == "2000-01-01"
    assert String(format="time").serialize("13:00:00") == "13:00:00"
    assert String(format="datetime").serialize("2000-01-01T13:00:00") == "2000-01-01T13:00:00"
    assert String(format="uuid").serialize("347e7d42-6822-45bf-8408-f37030f40afb") == "347e7d42-6822-45bf-8408-f37030f40afb"



# Generated at 2022-06-24 10:39:53.901372
# Unit test for constructor of class Choice
def test_Choice():
    new = Choice(choices = ['name', 'rows'])
    assert new.choices == [('name', 'name'), ('rows', 'rows')]
    error = 'not a dict'
    try:
        error = new.validate(name, rows)
    except:
        assert error == 'choice'
    try:
        error = new.validate(name)
    except:
        assert error == 'choice'
    try:
        error = new.validate(rows)
    except:
        assert error == 'choice'
    try:
        error = new.validate()
    except:
        assert error == 'null'



# Generated at 2022-06-24 10:40:02.126391
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Integer

    class SampleField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    field_1 = SampleField()
    field_2 = SampleField()

    assert (field_1 | field_2).any_of == [field_1, field_2]
    assert isinstance((field_1 | Integer()).any_of[-1], Integer)



# Generated at 2022-06-24 10:40:05.402287
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    result = field.validate("foo")
    assert result == "foo"


# Generated at 2022-06-24 10:40:07.197181
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    print(s)
    print(s.serialize("1"))

# Generated at 2022-06-24 10:40:10.125884
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[('yes', 'yes'), ('no', 'no')])
    assert c.choices == [('yes', 'yes'), ('no', 'no')]


# Generated at 2022-06-24 10:40:18.687065
# Unit test for method validate of class Array
def test_Array_validate():
    array_field = Array(max_items=5,min_items=6,allow_null=False)
    array_field_1 = Array(max_items=5,min_items=6,allow_null=False)
    item_1 = "1"
    item_2 = ""
    item_3 = None
    list = [item_1, item_2, item_3]
    assert array_field.validate(list) == list
    assert array_field_1.validate(list) == list
    assert array_field.validate(list) == array_field_1.validate(list)
   
    array_field_2 = Array(max_items=5,min_items=1,allow_null=False)

# Generated at 2022-06-24 10:40:28.843091
# Unit test for method validate of class Field

# Generated at 2022-06-24 10:40:40.387690
# Unit test for constructor of class String
def test_String():

    field = String(title="A Title", description="This is a description.", default= "Some default", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)

    assert field.title == "A Title"
    assert field.description == "This is a description."
    assert field.default == "Some default"
    assert field.allow_null == True
    assert field.allow_blank == True
    assert field.trim_whitespace == True
    assert field.max_length == None
    assert field.min_length == None
    assert field.pattern == None
    assert field.format == None




# Generated at 2022-06-24 10:40:48.359218
# Unit test for method validate of class Union
def test_Union_validate():
    def _generate_schema_and_value():
        schema = {
            "type": "object",
            "properties": {
                "foo": {"type": "number"},
                "bar": {"type": "boolean"},
                "qux": {"type": "string", "enum": ["a", "b"]},
            },
            "additionalProperties": {"type": "string"},
        }
        value = {"foo": 10, "bar": False, "qux": "a", "baz": "c"}
        return schema, value

    schema, value = _generate_schema_and_value()
    field = Field.from_json(schema)
    field.validate(value)

    schema, value = _generate_schema_and_value()

# Generated at 2022-06-24 10:40:56.186991
# Unit test for method validate of class Any
def test_Any_validate():
    any = Any()
    assert any.validate(0) == 0
    assert any.validate(1.1) == 1.1
    assert any.validate(True) is True
    assert any.validate(False) is False
    assert any.validate('string') == 'string'
    assert any.validate([1, 2, 3]) == [1, 2, 3]
    assert any.validate(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert any.validate(None) is None



# Generated at 2022-06-24 10:41:00.350189
# Unit test for constructor of class Any
def test_Any():
    data = ["a", "b"]
    assert isinstance(data, list)
    f = Any()
    assert isinstance(f, Any)
    valid, error = f.validate_or_error(data)
    assert error is None
    assert valid == data


# Generated at 2022-06-24 10:41:09.751179
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field:
        def __init__(self, *, title, description, default, allow_null):
            self.title, self.description, self.default, self.allow_null = title, description, default, allow_null
        def get_default_value(self):
            return self.default
        def has_default(self):
            return True
    field = Field(title="", description="", default=1, allow_null=False)
    other = Field(title="", description="", default=2, allow_null=False)
    result = field | other
    assert isinstance(result, Union)
    assert result.any_of == [field, other]
    # Any of must be unique
    assert result == (field | other | field)
    assert result.has_default() == True
    assert result.get_default_

# Generated at 2022-06-24 10:41:11.424161
# Unit test for method has_default of class Field
def test_Field_has_default():
   assert Field(title="", description="", default=NO_DEFAULT, allow_null=False).has_default() == False

# Generated at 2022-06-24 10:41:20.340733
# Unit test for constructor of class Number
def test_Number():
    a = Number()
    assert a.allow_null is False
    assert a.minimum is None
    assert a.maximum is None
    assert a.exclusive_minimum is None
    assert a.exclusive_maximum is None
    assert a.multiple_of is None
    assert a.precision is None

# Generated at 2022-06-24 10:41:20.864409
# Unit test for constructor of class Date
def test_Date():
    Date()


# Generated at 2022-06-24 10:41:21.859838
# Unit test for constructor of class Float
def test_Float():
    f = Float(max_length=2)


# Generated at 2022-06-24 10:41:23.659482
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    assert Field().validation_error(code='=') == ValidationError(text='', code='=')

# Generated at 2022-06-24 10:41:26.860018
# Unit test for method validate of class Field
def test_Field_validate():
    o = Field(title='',description='',allow_null=False)
    try:
        o.validate(value='',strict=False)
        raise AssertionError()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 10:41:34.105277
# Unit test for method serialize of class Array
def test_Array_serialize():
    from decimal import Decimal
    from datetime import datetime, timedelta
    from json import loads
    from uuid import UUID

    class DayCount(Field):
        def deserialize(self, value: str) -> int:
            return int(value[:-5])

        def serialize(self, value: str) -> str:
            return f'{value} days'
    assert Array(DayCount()).serialize([1, 2]) == ['1 days', '2 days']

    class Date(Field):
        def deserialize(self, value: str) -> datetime:
            return datetime.strptime(value, '%x')

        def serialize(self, value: datetime) -> str:
            return value.strftime('%x')

# Generated at 2022-06-24 10:41:44.031892
# Unit test for method serialize of class String
def test_String_serialize():
    s_obj = String()
    assert s_obj.serialize('2018-03-05') == '2018-03-05'
    assert s_obj.serialize('12:04:06') == '12:04:06'
    assert s_obj.serialize('2018-03-04T12:04:06') == '2018-03-04T12:04:06'
    assert s_obj.serialize('a7a8b3e3-7ee9-4d83-b919-b9642dc7d1cf') == 'a7a8b3e3-7ee9-4d83-b919-b9642dc7d1cf'


# Generated at 2022-06-24 10:41:50.816215
# Unit test for method validate of class Object
def test_Object_validate():

    obj = Object()
    value = dict()
    validated = obj.validate(value)
    assert validated is value
    
    value = []
    with pytest.raises(ValidationError):
        obj.validate(value, strict = True)
    
    obj = Object(properties = [('one', Integer())])
    value = {'one': 1}
    validated = obj.validate(value)
    assert validated is value
    
    obj = Object(properties = {'one': Integer()}, 
                pattern_properties = {'^two': Integer()}, 
                property_names = Integer(),
                allow_null = False
                )
    value = {'one': 1, 'two': 2, 'three': 3}
    validated = obj.validate(value)
    assert validated is value
    

# Generated at 2022-06-24 10:41:54.857596
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    test_input = decimal.Decimal(1.1)
    expected_output = float(1.1)
    calculated_output = Decimal().serialize(test_input)
    assert calculated_output == expected_output


# Generated at 2022-06-24 10:41:58.244866
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decim = Decimal(title='test',description='test2', allow_null=True, default=None)
    assert decim.serialize(None) == None
    assert decim.serialize(decimal.Decimal(20)) == 20.0


# Generated at 2022-06-24 10:42:08.118845
# Unit test for constructor of class Integer
def test_Integer():
    i = Integer()

# Generated at 2022-06-24 10:42:10.562589
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_field = Decimal()
    assert decimal_field.serialize(10) == 10.0
    assert decimal_field.serialize(decimal.Decimal('10')) == 10.0



# Generated at 2022-06-24 10:42:20.161308
# Unit test for method validate of class Any
def test_Any_validate():
    f = Any()
    assert f.validate(0) == 0
    assert f.validate(1) == 1
    assert f.validate(-1) == -1
    assert f.validate("hello") == "hello"
    assert f.validate("") == ""
    assert f.validate(True) == True
    assert f.validate(False) == False
    assert f.validate(None) == None
    assert f.validate([]) == []
    assert f.validate([1,2,3]) == [1,2,3]
    assert f.validate({"a": 1, "b": True}) == {"a": 1, "b": True}

# Generated at 2022-06-24 10:42:24.070535
# Unit test for method validate of class Union
def test_Union_validate():
    x = String()
    y = String(pattern="\d+")
    t = Union([x,y])
    value = "2019-09-08"
    ret = t.validate(value=value)
    return ret



# Generated at 2022-06-24 10:42:30.450361
# Unit test for constructor of class Number
def test_Number():

    # checks that object is an instance of Field
    assert isinstance(Number(), Field)
    # checks that default fields are returned
    assert Number().description == ''
    assert Number().title == ''
    # checks that the allow_null field defaults to False
    assert Number().allow_null == False
    # checks that a default value is returned
    assert Number().default == NO_DEFAULT
    # checks that numeric type is returned
    assert Number().numeric_type == None
    # checks that error messages are returned
    assert Number().errors['type'] == 'Must be a number.'
    assert Number().errors['null'] == 'May not be null.'
    assert Number().errors['integer'] == 'Must be an integer.'
    assert Number().errors['finite'] == 'Must be finite.'

# Generated at 2022-06-24 10:42:31.664701
# Unit test for constructor of class String
def test_String():
    a = String(max_length=50)
    assert a.max_length == 50

# test

# Generated at 2022-06-24 10:42:32.576870
# Unit test for method has_default of class Field
def test_Field_has_default():
    obj = Field()
    return obj.has_default() is True


# Generated at 2022-06-24 10:42:33.543968
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    assert field.validate(1) == 1

# Generated at 2022-06-24 10:42:34.605112
# Unit test for constructor of class Float
def test_Float():
    a = Float()


# Generated at 2022-06-24 10:42:46.769373
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Field1(Field):
        def validate(self, value, **kwargs):
            return value

    field = Field1()
    field.default = 'default'
    assert field.get_default_value() == 'default'

    field.default = lambda: 'default'
    assert field.get_default_value() == 'default'

    class Field2(Field):
        def validate(self, value, **kwargs):
            return value

    field = Field2()
    field.default = []
    assert field.get_default_value() == []

    field.default = lambda: []
    assert field.get_default_value() == []

    class Field3(Field):
        def validate(self, value, **kwargs):
            return value

    field = Field3()
    field.default = {}

# Generated at 2022-06-24 10:42:48.916599
# Unit test for constructor of class String
def test_String():
    stringfield = String(title='test')
    assert stringfield.title == 'test'


# Generated at 2022-06-24 10:42:50.462619
# Unit test for constructor of class Time
def test_Time():
    schema = Time()
    assert schema.format == "time"


# Generated at 2022-06-24 10:42:51.734411
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None

# Generated at 2022-06-24 10:43:02.673005
# Unit test for method validation_error of class Field
def test_Field_validation_error():
  Field_obj = Field()
  Field_obj.errors = {"required": "This field is required.", "invalid_type": "Value must be of type {type_name}."}
  code = "required"
  output = Field_obj.validation_error(code)
  assert isinstance(output, ValidationError)
  assert output.code == code
  assert output.text == Field_obj.errors[code].format(**Field_obj.__dict__)

  code = "invalid_type"
  output = Field_obj.validation_error(code)
  assert isinstance(output, ValidationError)
  assert output.code == code
  assert output.text == Field_obj.errors[code].format(**Field_obj.__dict__)

# Generated at 2022-06-24 10:43:13.209829
# Unit test for method validate of class String
def test_String_validate():
    str_field = String()
    assert str_field.validate('Hello World!') == 'Hello World!'
    assert str_field.validate('') == ''
    assert str_field.validate(None) == None
    #assert str_field.validate(123) == '123'  # For now this doesn't work, I think it should.
    try:
        str_field.validate(123)
    except Exception as e:
        assert e.code == 'type'
        assert str(e) == 'Must be a string.'
    try:
        str_field.validate(None)
    except Exception as e:
        assert e.code == 'null'
        assert str(e) == 'May not be null.'
    


# Generated at 2022-06-24 10:43:15.880806
# Unit test for constructor of class String
def test_String():
    st = String(title="name", description="not null", max_length=20)
    assert st.max_length == 20
    assert st.title == "name"
    assert st.description == "not null"


# Generated at 2022-06-24 10:43:22.777570
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = '''
    ['choices', [
        ['apple', 'Apple'],
        ['banana', 'Banana'],
        ['orange', 'Orange']
    ]]
    '''
    jsonstr = '''
    {
        "fruit": "apple"
    }
    '''
    data = json.loads(jsonstr)
    schema = json.loads(choices)
    result = SchemaValidator(schema)(data)
    assert result == data
    assert SchemaValidator(schema)({'fruit': 'banana'}) == {'fruit': 'banana'}
    assert SchemaValidator(schema)({'fruit': 'orange'}) == {'fruit': 'orange'}
    data['fruit'] = 'pear'

# Generated at 2022-06-24 10:43:24.156609
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field()
    assert f.has_default() == False

# Generated at 2022-06-24 10:43:25.884393
# Unit test for constructor of class Time
def test_Time():
    t = Time()
    assert t.format == 'time'
    assert t.validate('11:23:10') == '11:23:10'


# Generated at 2022-06-24 10:43:28.192597
# Unit test for constructor of class Object
def test_Object():
    properties = {"test":Integer()}
    Object(properties=properties)


# Generated at 2022-06-24 10:43:35.430817
# Unit test for constructor of class Field
def test_Field():
    assert (type(object_a) == type(object_b)) == True
    assert (type(object_a) == type(object_c)) == False
    assert (type(object_a) == type(object_d)) == False

object_a = Field()
object_b = Field()
object_c = Uniqueness()
object_d = formats



# Generated at 2022-06-24 10:43:36.636811
# Unit test for constructor of class Any
def test_Any():
    assert(Any().allow_null)

# Unit tests for function validate_or_error

# Generated at 2022-06-24 10:43:38.142344
# Unit test for constructor of class Time
def test_Time():

    time = Time()
    assert time.format == "time"


# Generated at 2022-06-24 10:43:44.581771
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    from typesystem.types import (
        String,
        Integer,
        Boolean,
        Float,
        Time,
        Date,
        DateTime,
        Array,
        Object,
        Number,
        Optional,
        Result,
        Schema,
        Enum,
        Pattern,
        Union,
        OneOf,
    )
    x = Field(title="", description="")
    y = String(title="", description="")
    z = Integer(title="", description="")
    m = Boolean(title="", description="")
    n = Float(title="", description="")
    p = Time(title="", description="")
    q = Date(title="", description="")
    r = DateTime(title="", description="")
    s = Array(title="", description="")

# Generated at 2022-06-24 10:43:48.802166
# Unit test for method serialize of class Field
def test_Field_serialize():
    class TestField(Field):
        def test_serialize(self, obj):
            return 'hello world'
    field = TestField()
    assert hasattr(field, 'serialize'), """Method serialize() is not implemented"""
    assert field.serialize('hello') == 'hello world', """Method serialize() does not work correctly"""

# Generated at 2022-06-24 10:43:57.135374
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_test = Decimal()
    # Testing if the value input is None
    assert decimal_test.serialize(None) == None
    # Testing if the value input is a Decimal
    assert decimal_test.serialize(decimal.Decimal(1)) == 1.0
    # Testing if the value input is a Float
    assert decimal_test.serialize(float(1)) == 1.0
    # Testing if the value input is an Integer
    assert decimal_test.serialize(int(1)) == 1.0
    # Testing if the value input is a String
    assert decimal_test.serialize(str(1)) == 1.0



# Generated at 2022-06-24 10:44:00.115213
# Unit test for constructor of class Text
def test_Text():
    assert isinstance(Text(allow_null=True, default="").default, str)
    try:
        Text(default="X")
    except AssertionError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 10:44:02.224234
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(title='', description='', default=NO_DEFAULT, allow_null=False)
    assert field.has_default() == False

# Generated at 2022-06-24 10:44:05.834019
# Unit test for constructor of class String
def test_String():
    string1 = String()



# Generated at 2022-06-24 10:44:08.556948
# Unit test for method serialize of class String
def test_String_serialize():
    str1 = String(format='uuid')
    assert str1.serialize(1234) == '1234'



# Generated at 2022-06-24 10:44:19.742047
# Unit test for method validate of class Boolean
def test_Boolean_validate(): 
    b = Boolean(title="is banana", default=True)
    assert b.validate("true") == True # Testing string argument
    assert b.validate("True") == True # Testing string argument with capital letters
    assert b.validate(1) == True # Testing integer argument
    assert b.validate(0) == False # Testing integer argument
    assert b.validate(0.5) == False # Testing float argument
    assert b.validate("on") == True # Testing string argument
    assert b.validate("off") == False # Testing string argument
    assert b.validate("1") == True # Testing string argument
    assert b.validate("0") == False # Testing string argument
    assert b.validate("") == False # Testing string argument
    assert b.validate(" ") == False # Testing string argument
    assert b

# Generated at 2022-06-24 10:44:24.221033
# Unit test for method validate of class Field
def test_Field_validate():
    class TestClass:
        def test_method(self):
            test_value = Field()
            test_strict = True
            try:
                test_value.validate(None, strict=test_strict)
            except NotImplementedError:
                assert True
            else:
                assert False

# Generated at 2022-06-24 10:44:30.589293
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Schema

    page_size = Schema(page=Integer(description='description',title='title',default=1),size=Integer(description='description',title='title',default=10))
    smart_page = Required('page',default=1)
    smart_page_size = Required('size',default=10)
    smart_page | smart_page_size
    page_size.__or__({'page': 3})


# Generated at 2022-06-24 10:44:43.336741
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(format='time')
    assert string.serialize(datetime.datetime(year=2009, month=1, day=1, hour=15, minute=30, second=45)) == '15:30:45'

String.__doc__ += """
Attributes
----------
allow_blank : bool
    If True, empty strings are allowed.
trim_whitespace : bool
    If True, any leading or trailing whitespace is stripped.
max_length : int
    The maximum length of the string.
min_length : int
    The minimum length of the string.
pattern : typing.Union[str, typing.Pattern]
    A regex pattern that the string must match.
format : str
    A known format defined by `TypeSystem`.
"""



# Generated at 2022-06-24 10:44:47.786478
# Unit test for constructor of class Boolean
def test_Boolean():
    isinstance(Boolean(), Boolean)


# Generated at 2022-06-24 10:44:51.920663
# Unit test for constructor of class Object
def test_Object():
    o = Object(
        properties={
            "name": String(),
            "age": Integer()
        },
        required={
            "name",
            "age"
        }
    )
    assert o


# Generated at 2022-06-24 10:44:53.154253
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime()


# Generated at 2022-06-24 10:45:01.108568
# Unit test for method validate of class Object
def test_Object_validate():
    # Instanciate
    properties = {'name':String(),'surname':String()}
    name = Object(properties=properties,name='name',description="Name")
    # Test validate()
    valid_inputs = [{'name':'A','surname':'B'},{'name':'A'}]
    invalid_inputs = [{'name':'a','surname':''},1]
    for v in valid_inputs:
        name.validate(v)
    for i in invalid_inputs:
        try:
            name.validate(i)
        except:
            pass
        else:
            raise AssertionError("validate() did not raise an error for invalid input {}".format(i))

test_Object_validate()


# Generated at 2022-06-24 10:45:02.483509
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate(None) == None   
    
    

# Generated at 2022-06-24 10:45:08.693207
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(const = 1, allow_null = True, description = 'Test function')
    const.validate(1)
    assert const.validate(1) == 1
    assert const.validate(None) == None
    assert const.validate(2) != 2
    assert const.validate(3) != 2
    assert const.validate("const") != "const"

# Generated at 2022-06-24 10:45:10.994232
# Unit test for constructor of class Decimal
def test_Decimal():
    D = Decimal()
    assert D.validate("123.4") == 123.4
test_Decimal()

# Generated at 2022-06-24 10:45:14.563351
# Unit test for constructor of class Union
def test_Union():
    child1 = Integer(multiple_of=3)
    child2 = Integer(multiple_of=4)
    child3 = Integer(multiple_of=5)
    Union(any_of=[child1, child2, child3])


# Generated at 2022-06-24 10:45:18.440952
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array()
    value = ['item1', 'item2']
    validated = array.validate(value)
    assert (validated==value) #If the given value is null, validation returns None


# Generated at 2022-06-24 10:45:27.601675
# Unit test for method validate of class Field
def test_Field_validate():
    # Create new class to inherit from Field
    class TestField(Field):
        errors = {
            'invalid_value': "'{value}' is not a valid value for this field."
        }

        def __init__(self, *, required: bool = False):
            self.required = required

        def validate(self, value, *, strict: bool = False):
            if value is None:
                if self.required:
                    raise self.validation_error('blank')
                else:
                    return None

            return value
    # Create a new instance of TestField
    test_field = TestField()
    # Check it
    assert test_field.required == False
    assert test_field.has_default() == False

# Generated at 2022-06-24 10:45:33.536428
# Unit test for constructor of class String
def test_String():
    with pytest.raises(AssertionError):
        String(max_length="abc")
    with pytest.raises(AssertionError):
        String(min_length="abc")
    with pytest.raises(AssertionError):
        String(pattern=1)
    with pytest.raises(AssertionError):
        String(format=1)



# Generated at 2022-06-24 10:45:40.244355
# Unit test for constructor of class String
def test_String():
    string = String(allow_blank=False, trim_whitespace=False, min_length=5, max_length=5, pattern=r"\D{5}")
    test_value_return_success(string, "12345")
    test_value_return_fail(string, "1234")
    test_value_return_fail(string, "1234567890")
    test_value_return_success(string, "123A5")
    test_value_return_success(string, "1   ")
    test_value_return_fail(string, "1")
    test_value_return_fail(string, "123AB")



# Generated at 2022-06-24 10:45:46.150358
# Unit test for constructor of class Union
def test_Union():
    u = Union([Integer(), Number()])
    assert u.allow_null is False
    assert len(u.any_of) == 2
    assert isinstance(u.any_of[0], Integer)
    assert isinstance(u.any_of[1], Number)


# Generated at 2022-06-24 10:45:51.805949
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    class DummyField(Field):
        errors = {'format': 'wrong format'}

    dummy_field = DummyField()
    assert isinstance(dummy_field.validation_error('format'), ValidationError)
    assert dummy_field.validation_error('format').text == 'wrong format'
    assert dummy_field.get_error_text('format') == 'wrong format'

# Generated at 2022-06-24 10:45:56.686037
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal = Decimal(maximum=100, minimum=1, exclusive_maximum=True, exclusive_minimum=True)
    assert decimal.validate(5, strict=True) == 5
    assert decimal.validate(5.6, strict=True) == 5.6
    assert decimal.validate(decimal.Decimal('5.56'), strict=True) == decimal.Decimal('5.56')
    assert decimal.validate(101, strict=True) == ValidationResult(None, ValidationError('Must be less than 100'))
    assert decimal.validate(0, strict=True) == ValidationResult(None, ValidationError('Must be greater than 1'))
    assert decimal.validate(5, strict=False) == 5
    assert decimal.validate('5.6', strict=False) == 5.6

# Generated at 2022-06-24 10:46:01.051017
# Unit test for constructor of class Any
def test_Any():
    f = Any()
    assert not f.allow_null
    f = Any(allow_null=True)
    assert f.allow_null


# Generated at 2022-06-24 10:46:02.040973
# Unit test for constructor of class Float
def test_Float():
    Float(minimum=0, maximum=1)



# Generated at 2022-06-24 10:46:03.359326
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f is not None


# Generated at 2022-06-24 10:46:04.321208
# Unit test for constructor of class Integer
def test_Integer():
  i = Integer()
  assert i.numeric_type == int


# Generated at 2022-06-24 10:46:16.011131
# Unit test for method validate of class Object

# Generated at 2022-06-24 10:46:22.848295
# Unit test for constructor of class Field
def test_Field():
    field1 = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
    assert field1.title == ""
    assert field1.description == ""
    assert field1.allow_null == False
    assert field1.errors == {}
    assert field1._creation_counter == 0
    assert field1.title == ""
    assert field1.description == ""
    assert field1.allow_null == False


# Generated at 2022-06-24 10:46:27.150021
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    time2 = Time("title", title="title", description="description", default="default",
                 example="example", enum=["enum"], const="const")
    time3 = Time(enum=["enum"], const="const")
    assert time2.title == "title"
    assert time2.description == "description"
    assert time2.default == "default"
    assert time2.example == "example"
    assert time2.enum == ["enum"]
    assert time2.const == "const"
    assert time3.enum == ["enum"]
    assert time3.const == "const"



# Generated at 2022-06-24 10:46:31.861940
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    test_field = Field()
    test_field.errors = {'test_error_code': 'Error message'}
    expected_output = ValidationError(text='Error message', code='test_error_code')
    assert test_field.validation_error('test_error_code') == expected_output


# Generated at 2022-06-24 10:46:42.461963
# Unit test for method serialize of class Array
def test_Array_serialize():
    pass

    # Tests for Object

# Generated at 2022-06-24 10:46:52.571354
# Unit test for method validate of class Array
def test_Array_validate():
    assert Array().validate([]) == []
    assert Array().validate([None, True, "str"]) == [None, True, "str"]
    assert Array().validate(None) is None
    assert Array().validate(None, strict=True) == []
    assert Array().validate([None, False, 1]) == [None, False, 1]
    assert Array().validate([None, True, 123]) == [None, True, 123]
    assert Array().validate([None, False, "str"]) == [None, False, "str"]
    assert Array().validate([None, True, "str"]) == [None, True, "str"]
    assert Array().validate(None) is None
    assert Array().validate(None, strict=True) == []
    assert Array().validate([None, False, 1])

# Generated at 2022-06-24 10:47:03.396603
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum = 0, maximum = 10, exclusive_minimum = 5, exclusive_maximum = 20, multiple_of = 2, allow_null = True).validate(25) == None
    assert Number(minimum = 0, maximum = 10, exclusive_minimum = 5, exclusive_maximum = 20, multiple_of = 2, allow_null = True).validate(10) == 10
    assert Number(minimum = 0, maximum = 10, exclusive_minimum = 0, exclusive_maximum = 10, multiple_of = 2, allow_null = True).validate(10) == 10
    assert Number(minimum = 0, maximum = 10, exclusive_minimum = 0, exclusive_maximum = 10, multiple_of = 2, allow_null = True).validate(0) == 0

# Generated at 2022-06-24 10:47:05.813034
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field_instance = Decimal();
    assert(None == field_instance.serialize(None))
    assert(0.0 == field_instance.serialize(0.0))


# Generated at 2022-06-24 10:47:09.085560
# Unit test for constructor of class Time
def test_Time():
    temp_str = "must be in the format 'hh:mm:ss.ffffff'"
    Time1 = Time()
    assert Time1.error_messages["format"] == temp_str


# Generated at 2022-06-24 10:47:12.527660
# Unit test for constructor of class Date
def test_Date():
    try:
        wrongDate = Date()
        # Assert throws an error as it shouldn't reach this statement
        assert(False)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 10:47:18.910906
# Unit test for constructor of class Array
def test_Array():
    list_of_fields = [(Field(int))]
    list_of_fields.append(Field(int))
    list_of_fields.append(Field(int))

    # Test that we can create an Array with a single field type
    a = Array(int)
    assert a.__dict__['min_items'] == 0

    # Test that we can create an Array with a list of field types
    a = Array(list_of_fields)
    assert a.__dict__['min_items'] == 3




# Generated at 2022-06-24 10:47:21.980843
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    validation_error = ValidationError(text="some text", code="some code")
    assert field.validation_error("some code") == validation_error



# Generated at 2022-06-24 10:47:27.205257
# Unit test for constructor of class Any
def test_Any():
    from ..fields import Any
    from ..errors import ValidationError
    a = Any()
    # should not raise ValidationError
    a.validate(None)
    a.validate(1)
    a.validate(1.0)
    a.validate(True)
    a.validate('1')
    a.validate({})
    a.validate([])

# Generated at 2022-06-24 10:47:34.024951
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    test = Boolean(allow_null = True)
    assert test.validate(None) == None
    assert test.validate(True) == True
    assert test.validate(False) == False
    assert test.validate("None") == None
    assert test.validate("") == None
    assert test.validate("1") == True
    assert test.validate("0") == False
    assert test.validate("Yes") == True
    assert test.validate("No") == False
    assert test.validate("true") == True
    assert test.validate("false") == False
    assert test.validate("on") == True
    assert test.validate("off") == False
    assert test.validate("True") == True
    assert test.validate("False") == False

# Generated at 2022-06-24 10:47:38.368516
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() is None
    assert Field(default=1).get_default_value() == 1
    assert Field(default=NO_DEFAULT).get_default_value() is NO_DEFAULT



# Generated at 2022-06-24 10:47:44.782417
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    Field.errors = {
        "format": "Invalid format.",
        "required": "This field is required.",
        "invalid": "Not a valid value.",
    }
    f = Field()
    assert f.get_error_text("format") == "Invalid format."
    assert f.get_error_text("required") == "This field is required."
    assert f.get_error_text("invalid") == "Not a valid value."



# Generated at 2022-06-24 10:47:52.542694
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array().serialize(None) is None
    assert Array().serialize([1,2,3]) == [1,2,3]
    assert Array(items=Integer()).serialize([1,2,3]) == [1,2,3]

    assert (
        Array(items=Array(items=Integer())).serialize([[1,2],[3,4,5]])
        == [[1,2],[3,4,5]]
    )

    assert Array(items=[Integer(),Integer(),Integer()]).serialize([1,2,3]) == [1,2,3]

# Generated at 2022-06-24 10:48:00.162706
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import fields
    assert(type(fields.String() | fields.Boolean()) == fields.Union)
    assert(type(fields.String() | fields.Boolean() | fields.Integer()) == fields.Union)
test_Field___or__()

    # Class: Field
    # Method: __or__
    # Error: Does not return an instance of 'Field'
    # Error: Class hierarchy: Field -> Union
    # Error: Should use superclass: Field


# Generated at 2022-06-24 10:48:03.422629
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title="Name", default=10)
    obj = object()
    assert field.get_default_value() == 10
    def fun():
        return obj
    field.default = fun
    assert field.get_default_value() is obj



# Generated at 2022-06-24 10:48:14.014595
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=["a", "b", "c"]) == (
        Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    )
    assert Choice(choices=["a", "b", "c", ("d1", "d2")]) == (
        Choice(choices=[("a", "a"), ("b", "b"), ("c", "c"), ("d1", "d2")])
    )
    assert Choice(choices=["a", "b", ("c1", "c2"), ("d1", "d2")]) == (
        Choice(choices=[("a", "a"), ("b", "b"), ("c1", "c2"), ("d1", "d2")])
    )

# Generated at 2022-06-24 10:48:18.766747
# Unit test for method validate of class String
def test_String_validate():
    string = String(allow_blank = True, trim_whitespace = True, max_length = None, min_length = None, pattern = None)
    output = string.validate('hello')
    assert output == 'hello'

# Generated at 2022-06-24 10:48:20.475780
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    assert any.__class__.__name__ == "Any"


# Generated at 2022-06-24 10:48:22.019032
# Unit test for constructor of class String
def test_String():
    s = String()
    assert isinstance(s, String)


# Generated at 2022-06-24 10:48:25.530374
# Unit test for constructor of class Number
def test_Number():
    def test_missing_precision_arg():
        try:
            Number(name="Decimal")
        except SyntaxError:
            return True
        return False
    assert test_missing_precision_arg()



# Generated at 2022-06-24 10:48:28.536023
# Unit test for constructor of class Choice
def test_Choice():
    choices = [
        ('A', 'B'), ('C', 'D'), ('E', 'F')
    ]
    c = Choice(key='choices', choices=choices, allow_null=True, required=False)
    assert c