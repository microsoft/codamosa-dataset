

# Generated at 2022-06-24 10:38:37.776451
# Unit test for constructor of class Array
def test_Array():
    array = Array(min_items=1, max_items=9, unique_items=True, allow_null=True)
    assert array.min_items == 1
    assert array.max_items == 9
    assert array.unique_items == True
    assert array.allow_null == True

    array = Array(min_items=0, max_items=None, unique_items=False, allow_null=False)
    assert array.min_items == 0
    assert array.max_items == None
    assert array.unique_items == False
    assert array.allow_null == False



# Generated at 2022-06-24 10:38:46.994742
# Unit test for method validate of class Union
def test_Union_validate():
    def check(obj, value):
        field = Union([
            String(),
            Integer(),
            Float(),
            Boolean(),
            Array(items=String()),
            Array(items=Integer()),
            Array(items=Float()),
            Array(items=Boolean()),
            Object(properties={'a': String()}),
            Object(properties={'a': Integer()}),
            Object(properties={'a': Float()}),
            Object(properties={'a': Boolean()}),
        ])
        validated, error = field.validate_or_error(value)
        assert validated == obj
        assert error is None

    check("foo", "foo")
    check(3, "3")
    check(3.2, "3.2")
    check(True, "true")

# Generated at 2022-06-24 10:38:48.873696
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(field_name='name', choices=['NONE', 'MALE', 'FEMALE'], default='')
    value = field.validate('')
    assert value is None



# Generated at 2022-06-24 10:38:52.517218
# Unit test for method validate of class Union
def test_Union_validate():
    sample_field_1 = String(min_length=5, max_length=10)
    sample_field_2 = String(min_length=5, max_length=10)
    sample_any_of = [sample_field_1, sample_field_2]
    sample_field = Union(sample_any_of)
    sample_value = "hola"
    with pytest.raises(ValidationError):
        sample_field.validate(sample_value)

# Generated at 2022-06-24 10:39:03.721302
# Unit test for constructor of class Array
def test_Array():
    temp = Array()
    assert temp.items is None
    assert temp.additional_items is False
    assert temp.min_items == None
    assert temp.max_items == None
    assert temp.unique_items == False

    temp = Array(items=None, additional_items=False, min_items=None, max_items=None, unique_items=False)
    assert temp.items is None
    assert temp.additional_items is False
    assert temp.min_items == None
    assert temp.max_items == None
    assert temp.unique_items == False

    temp = Array(items=None, additional_items=False, min_items=1, max_items=None, unique_items=False)
    assert temp.min_items == 1


# Generated at 2022-06-24 10:39:06.273164
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field.get_error_text(code='1')
    assert Field.get_error_text(code='2')
test_Field_get_error_text()


# Generated at 2022-06-24 10:39:08.322404
# Unit test for constructor of class String
def test_String():
    s = String(title="String", min_length=1, max_length=10)
    assert s is not None



# Generated at 2022-06-24 10:39:10.194015
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title='My Fields', description='My Fields', default="my_fields", allow_null=False)
    assert f.get_default_value() == 'my_fields'

# Generated at 2022-06-24 10:39:15.796540
# Unit test for method validate of class Any
def test_Any_validate():
    # Create an instance of class Any
    any_field = Any()
    # Check that the validate() method return the value passed as argument
    # in case of a number
    assert any_field.validate(10) == 10
    # Check that the validate() method return the value passed as argument
    # in case of a string
    assert any_field.validate("test") == "test"
    # Check that the validate() method return the value passed as argument
    # in case of True
    assert any_field.validate(True) == True
    # Check that the validate() method return the value passed as argument
    # in case of None
    assert any_field.validate(None) == None
    # Check that the validate() method return the value passed as argument
    # in case of an empty list
    assert any_field.validate([])

# Generated at 2022-06-24 10:39:22.783354
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal()
    assert a.errors == {
        "type": "Must be a number.",
        "null": "May not be null.",
        "integer": "Must be an integer.",
        "finite": "Must be finite.",
        "minimum": "Must be greater than or equal to {minimum}.",
        "exclusive_minimum": "Must be greater than {exclusive_minimum}.",
        "maximum": "Must be less than or equal to {maximum}.",
        "exclusive_maximum": "Must be less than {exclusive_maximum}.",
        "multiple_of": "Must be a multiple of {multiple_of}.",
    }



# Generated at 2022-06-24 10:39:28.613170
# Unit test for constructor of class Float
def test_Float():
    f = Float(minimum=1, maximum=2, exclusive_minimum=3, exclusive_maximum=4, precision=5, multiple_of=6)
    assert f.minimum == 1
    assert f.maximum == 2
    assert f.exclusive_minimum == 3
    assert f.exclusive_maximum == 4
    assert f.precision == 5
    assert f.multiple_of == 6
    assert f.allow_null == False
    assert isinstance(f, Field)


# Generated at 2022-06-24 10:39:31.084882
# Unit test for constructor of class Integer
def test_Integer():
    Integer(allow_null=True)
    try:
        Integer(allow_null=True, minimum=decimal.Decimal('1'))
    except AssertionError:
        pass
    Integer(allow_null=True, minimum=decimal.Decimal('1'), precision='1')


# Generated at 2022-06-24 10:39:40.152133
# Unit test for constructor of class Integer
def test_Integer():
    intobj = Integer()
    assert Integer.errors
    assert intobj.allow_null
    assert intobj.title == '', "Integer() should have default title as empty string"
    assert intobj.description == '', "Integer() should have default description as empty string"
    assert intobj.allow_blank is False
    assert intobj.allow_blank == False
    assert intobj.trim_whitespace is True
    assert intobj.max_length is None
    assert intobj.min_length is None
    assert intobj.pattern is None
    assert intobj.precision is None
    assert intobj.format is None
    assert intobj.multiple_of is None



# Generated at 2022-06-24 10:39:46.299267
# Unit test for constructor of class Array
def test_Array():
    assert Array()
    assert Array(
        items=None,
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
    )
    assert Array(items=None, additional_items=False, min_items=None,  max_items=10, unique_items=False)
    assert Array(items=[], additional_items=Boolean(), min_items=None, max_items=None, unique_items=False)
    assert Array(items=Integer(), additional_items=False, min_items=None, max_items=None, unique_items=False)
    assert Array(items=Integer(), additional_items=False, min_items=None, max_items=None, unique_items=True)

# Generated at 2022-06-24 10:39:49.932190
# Unit test for constructor of class Const
def test_Const():
    class TestCase(JsonSchemaTest):
        field = Const(const = 1.0)
        valid = [1.0, "1.0", 1]
        invalid = [1.1, "1.1", 2]
    
    def test_const():
        TestCase.check()

# Test case for constructor of class Const
test_Const()



# Generated at 2022-06-24 10:39:54.864824
# Unit test for method validate of class Object
def test_Object_validate():
    data = {
        'properties': {},
        'additional_properties': {'required': True, 'type': 'string'}
    }
    v = Object(**data)
    v.validate(value={'a': 'b', 'c': 'd'})
    data2 = {
        'properties': {},
        'additional_properties': {'required': True, 'type': 'string'}
    }
    v2 = Object(**data)
    v2.validate(value={'a': 1.3, 'c': 'd'})


# Generated at 2022-06-24 10:39:59.193758
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
	a = Decimal()
	assert a.serialize(None) is None
	assert type(a.serialize(2)) is float
	assert a.serialize(2) == 2

# Generated at 2022-06-24 10:40:05.124938
# Unit test for method validate of class Object
def test_Object_validate():
    class Obj(Object):
        # TODO: change to field
        x = int
        y = Boolean
        z = float
    
    x = {"x": 123, "y": True, "z": 123.0}
    
    actual_y, error_y = Obj().validate_or_error(x)
    expected_y = {"x": 123, "y": True, "z": 123.0}
    
    assert actual_y == expected_y



# Generated at 2022-06-24 10:40:05.943016
# Unit test for constructor of class Time
def test_Time():
    assert Time() is not None



# Generated at 2022-06-24 10:40:10.204533
# Unit test for constructor of class Boolean
def test_Boolean():
    assert type(Boolean(allow_null=True).allow_null) is bool
    assert type(Boolean(title="").title) is str
    assert type(Boolean(description="").description) is str
    assert type(Boolean(default=True).default) is bool


# Generated at 2022-06-24 10:40:10.946931
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert time.format == "time"


# Generated at 2022-06-24 10:40:11.512609
# Unit test for constructor of class Time
def test_Time():
    assert Time().format == "time"


# Generated at 2022-06-24 10:40:19.000667
# Unit test for constructor of class DateTime
def test_DateTime():
    #Test case: If the parameter is not right
    field = DateTime()
    field_type = field.__class__
    field_attrs = ('format', 'allow_null', 'type', 'default_value', 'choices', 'min_length', 'max_length', 'pattern')
    for attr in field_attrs:
        assert hasattr(field, attr) and getattr(field, attr) == None
    assert field_type == DateTime

    #Test case: If the parameter is right
    field = DateTime(format = "datetime", author = "honglei")
    field_type = field.__class__
    field_attrs = ('format', 'allow_null', 'type', 'default_value', 'choices', 'min_length', 'max_length', 'pattern')

# Generated at 2022-06-24 10:40:21.902672
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    err_msg = "Invalid value for field '{name}' "
    code = 'invalidValue'
    obj = Field(name='test', errors={code: err_msg})
    assert obj.get_error_text(code) == err_msg

# Generated at 2022-06-24 10:40:24.539750
# Unit test for constructor of class Boolean
def test_Boolean():
    test_field = Boolean()
    test_value = True
    assert test_field.validate(test_value, strict=False) == test_value



# Generated at 2022-06-24 10:40:32.856542
# Unit test for method has_default of class Field
def test_Field_has_default():
    class TestField(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
            Field.__init__(self, title=title, description=description, default=default, allow_null=allow_null)

        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            raise NotImplementedError()  # pragma: no cover

    assert TestField.has_default() == False


# Generated at 2022-06-24 10:40:42.642510
# Unit test for method serialize of class Array
def test_Array_serialize():
    app = Box(array_example=[["Hello"], ["world"]], array_example2=[1, 2, 3])

    schema1 = Array(
        items=[String(
            pattern="(?i)^hello$"
        )],
        additional_items=False
    )
    schema2 = Array(
        items=[String()],
        additional_items=False
    )
    schema3 = Array(
        items=[Integer()],
        additional_items=False
    )

    assert schema1.serialize(app.array_example) == app.array_example
    assert schema2.serialize(app.array_example) != app.array_example
    assert schema3.serialize(app.array_example2) == app.array_example2



# Generated at 2022-06-24 10:40:49.000077
# Unit test for constructor of class Field
def test_Field():
    title = "Title"
    description = "Description"
    default = "No default"
    allow_null = True
    field = Field(
        title = title,
        description = description,
        default = default,
        allow_null = allow_null
    )
    assert field.title == title
    assert field.description == description
    assert field.default == default
    assert field.allow_null == allow_null
    assert field._creation_counter == 0
    assert field._creation_counter == Field._creation_counter


# Generated at 2022-06-24 10:40:52.951836
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert f.title == ""
    assert f.description == ""
    try:
        f.default
    except AttributeError:
        pass
    assert f.allow_null == False


# Generated at 2022-06-24 10:40:59.673460
# Unit test for constructor of class Union
def test_Union():
    field = Union(any_of = [Integer(allow_null=False)])
    # There is no null input in Integer(), so with null input, the error
    # should be "May not be null", which is the error for "null"
    assert field.validate(None) == None
    assert field.errors['union'] == 'Did not match any valid type.'
    return True


# Generated at 2022-06-24 10:41:07.585689
# Unit test for method validate of class Object
def test_Object_validate():
    values = [dict(key = 'value')]
    if isinstance(values, dict):
        print('ok')
    else:
        print('error')
        
    for value in values:
        print(value) # print '{'key': 'value'}' 
        
    properties = dict(properties='email')
    for key, child_schema in properties.items():
        if key not in values[0]:
            print(key)
            if child_schema.has_default():
                print('ok')
            else:
                print('error')

test_Object_validate()


# Generated at 2022-06-24 10:41:18.810624
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number(minimum =0 , maximum=10)
    result = n.validate(5)
    assert result == 5
    result2 = n.validate(2)
    assert result2 == 2
    result3 = n.validate(8)
    assert result3 == 8

    result4 = n.validate(11)
    assert result4 != 11
    assert result4 == None
    result6 = n.validate(-1)
    assert result6 == None
    assert result6 != -1

    with pytest.raises(Exception) as exception:
        result5 = n.validate("2")
    assert str(exception.value) == 'Must be a number.'
    
    
    
    n = Number(allow_null=True, minimum =0 , maximum=10)

# Generated at 2022-06-24 10:41:20.158479
# Unit test for constructor of class Date
def test_Date():
    date_dict = Date(name="date").info
    return date_dict["format"] == "date"



# Generated at 2022-06-24 10:41:27.385962
# Unit test for method validate of class Array
def test_Array_validate():
    # Make schema
    schema = Array(
        items = String(max_length=3)
    )

    # Check valid data
    data = ["abc", "abcde"]
    json_schema(data, schema).validate()

    # Check invalid data
    # Value not matching schema
    with pytest.raises(ValidationError):
        data = ["abc", 2]
        json_schema(data, schema).validate()
    # Value not in list
    with pytest.raises(ValidationError):
        data = ["abc", "abcd", "abcd", "abcd"]
        json_schema(data, schema).validate()
    # Value exceeding max_length
    with pytest.raises(ValidationError):
        data = ["abc", "abcdef"]

# Generated at 2022-06-24 10:41:39.569275
# Unit test for method validate of class String
def test_String_validate():
    # Check with null
    s = String()
    result = s.validate(None)
    assert(result is None)

    s = String(allow_null=True)
    result = s.validate(None)
    assert(result is None)

    s = String(allow_blank=True)
    result = s.validate(None)
    assert(result == '')

    s = String(allow_null=True, allow_blank=True)
    result = s.validate(None)
    assert(result is None)

    # Check with string
    s = String()
    result = s.validate('')
    assert(result == '')

    s = String(allow_blank=True)
    result = s.validate('')
    assert(result == '')


# Generated at 2022-06-24 10:41:47.983385
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_field_1 = Boolean()
    assert boolean_field_1.validate('n', strict=True) == None
    assert boolean_field_1.validate(None, strict=False) == None
    try:
        boolean_field_1.validate('n')
    except ValidationError as error:
        assert error.code == 'type'
        assert 'n' in error.text
    #
    boolean_field_2 = Boolean(allow_null=True)
    assert boolean_field_2.validate(None, strict=False) == None
    assert boolean_field_2.validate('n') == None
    try:
        boolean_field_2.validate('n', strict=True)
    except ValidationError as error:
        assert error.code == 'type'

# Generated at 2022-06-24 10:41:52.972152
# Unit test for constructor of class Number
def test_Number():
    assert Number(minimum=0, maximum=50)
    assert Number(exclusive_minimum=0, exclusive_maximum=50)
    assert Number(multiple_of=4)
    assert Number(precision="0.1")


# Generated at 2022-06-24 10:41:57.465272
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() is None
    assert Field(default=1).get_default_value() == 1
    assert callable(Field(default=lambda: 1).get_default_value())
    assert Field(default=lambda: 1).get_default_value() == 1

# Generated at 2022-06-24 10:42:00.805463
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    text = 'text'
    field = Field()
    field.errors = {'code': text}
    assert field.get_error_text('code') == text

# Generated at 2022-06-24 10:42:09.900697
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    t = Boolean()
    assert t.validate(None) == None
    assert t.validate(False) == False
    assert t.validate(True) == True
    assert t.validate("true") == True
    assert t.validate("false") == False
    assert t.validate("1") ==True
    assert t.validate("0") == False
    assert t.validate("") == False
    assert t.validate(1) == True
    assert t.validate(0) == False
    assert t.validate("on") == True
    assert t.validate("off") == False
    with pytest.raises(ValidationError):
        t.validate("xyz")
    with pytest.raises(ValidationError):
        t.validate("3")

# Generated at 2022-06-24 10:42:16.839895
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Number
    from typesystem.union import Union
    a = String()
    b = String()
    c = Number()
    d = Number()

    union_instance = Union(any_of=[a,b])
    assert (a or b) == union_instance

    union_instance2 = Union(any_of=[b,c])
    assert (b or c) == union_instance2

    union_instance3 = Union(any_of=[a,b,c])
    assert (a or b or c) == union_instance3

    union_instance4 = Union(any_of=[a,b,c,d])
    assert (a or b or c or d) == union_instance4

    bad_instance = Union(any_of=[a])

# Generated at 2022-06-24 10:42:23.586940
# Unit test for method __or__ of class Field
def test_Field___or__():

    from typesystem import String, Integer, Boolean

    field1 = String(max_length=100)
    field2 = Integer()
    field3 = Boolean()

    union_field = (field1 | field2) | field3

    assert field1 in union_field.any_of
    assert field2 in union_field.any_of
    assert field3 in union_field.any_of



# Generated at 2022-06-24 10:42:25.968123
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    value1 = Decimal().serialize(None)
    value2 = Decimal().serialize(1)
    assert value1 == None
    assert value2 == 1.0


# Generated at 2022-06-24 10:42:28.253151
# Unit test for method validate of class Const
def test_Const_validate():
    constField = Const(1,description = "A constant field")
    assert constField.validate(1) is not None
    assert constField.validate(2) is None
"""
    Testing validate method of class Const
    Passing in 1 should not return null and passing in any value other than 1 should return null
"""


# Generated at 2022-06-24 10:42:29.898287
# Unit test for constructor of class String
def test_String():
    String(title="hello", description="world", default=None, allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)


# Generated at 2022-06-24 10:42:35.990341
# Unit test for constructor of class Array
def test_Array():
    obj = Array()
    assert obj.parent is None
    assert obj.type == "array"
    assert obj.allow_null is False
    assert obj.default is None
    assert obj.choices is None
    assert obj.allow_coerce is True
    assert obj.allow_strip is True
    assert obj.items is None
    assert obj.unique_items is False
    assert obj.additional_items is False
    assert obj.allow_empty is True
    assert obj.min_items is None
    assert obj.max_items is None
    assert obj.exact_items is None
    assert obj.length is None
    assert obj.allow_name is None
    assert obj.allow_regex is None
    assert obj.allow_multi is None
    assert obj.title is None
    assert obj.description is None



# Generated at 2022-06-24 10:42:37.205476
# Unit test for constructor of class Float
def test_Float():
    assert Float().numeric_type is float


# Generated at 2022-06-24 10:42:39.606614
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field().get_error_text("test erro code") == "test erro code"



# Generated at 2022-06-24 10:42:50.419898
# Unit test for constructor of class Object
def test_Object():
    class SubObject(Object):
        foo = Field(numeric_type=int, required=True)
        bar = Field(required=False)
    o = SubObject()
    assert o.name == 'object'
    assert o.errors['required'] == 'This field is required.'
    assert o.next_error_index == 1
    assert o.get_default_value() == {}
    assert o.properties['foo'].name == 'integer'
    assert o.properties['foo'].errors['required'] == 'This field is required.'
    assert o.properties['foo'].next_error_index == 1
    assert o.properties['foo'].get_default_value() == 0
    assert o.properties['bar'].name == 'string'

# Generated at 2022-06-24 10:42:54.078080
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class CustomField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value
    assert CustomField().validate_or_error("value").value == "value"
    assert CustomField().validate_or_error("value").error == None


# Generated at 2022-06-24 10:43:04.961658
# Unit test for method validate of class Array
def test_Array_validate():
    def test_Array_validate_type():
        items = Array()

        try:
            items.validate(1)
            assert False
        except ValidationError as e:
            assert e.messages[0].code == "type"
            assert e.messages[0].text == "Must be an array."

    def test_Array_validate_empty():
        items = Array()

        try:
            items.validate([])
            assert False
        except ValidationError as e:
            assert e.messages[0].code == "empty"
            assert e.messages[0].text == "Must not be empty."

    def test_Array_validate_min_items():
        items = Array(min_items=2)


# Generated at 2022-06-24 10:43:07.389531
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal = Decimal()
    assert decimal.serialize(1.0) == 1.0
    assert decimal.serialize(None) == None



# Generated at 2022-06-24 10:43:16.496000
# Unit test for method validate of class Object
def test_Object_validate():
    # Test invalid types for property properties
    try:
        validate_test = Object(properties = 1)
        assert false
    except:
        pass

    # Test invalid types for property pattern_properties
    try:
        validate_test = Object(pattern_properties = 1)
        assert false
    except:
        pass

    # Test invalid types for property additional_properties
    try:
        validate_test = Object(additional_properties = 1)
        assert false
    except:
        pass

    # Test invalid types for property property_names
    try:
        validate_test = Object(property_names = 1)
        assert false
    except:
        pass

    # Test invalid types for property min_properties
    try:
        validate_test = Object(min_properties = 1)
        assert false
    except:
        pass

    #

# Generated at 2022-06-24 10:43:26.720977
# Unit test for constructor of class Decimal
def test_Decimal():
    from typesystem import Schema
    from typesystem.types import String, Integer, Float, Decimal, Boolean, Object
    from typesystem.fields import List, Dict
    from decimal import Decimal as D

    class Fun(Schema):
        n1 = Decimal()
        n2 = Decimal(precision='0.01')
        n3 = Decimal(precision='0.1')
        n4 = Decimal(precision='1')
        n5 = Decimal(precision='10')
    schema = Fun()
    schema.validate({'n1':12345.1, 'n2':12345.1, 'n3':12345.1, 'n4':12345.1, 'n5':12345.1})
    print(schema.get_default_value())

# Generated at 2022-06-24 10:43:37.804423
# Unit test for method validate of class Const
def test_Const_validate():
    obj = {
        "const": Field(
            type="string",
            const="foo"
        )
    }
    # obj is a dict, so it can be passed into a Field constructor and will work
    # in this case, the constructor should return an object of type Field
    schema = Field(**obj)
    try:
        schema.validate({
            "const": "foo"
        })
    except ValidationError as e:
        print(e.messages())
        assert False
    try:
        schema.validate({
            "const": "bar"
        })
    except ValidationError as e:
        assert True
        print(e.messages())
        
if __name__ == "__main__":
    test_Const_validate()


# Generated at 2022-06-24 10:43:38.945455
# Unit test for constructor of class Float
def test_Float():
    obj = Float()
    assert obj.numeric_type == float



# Generated at 2022-06-24 10:43:40.626321
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    f.validate(1)
    f.validate(1.0)
    f.validate("hello")



# Generated at 2022-06-24 10:43:46.214200
# Unit test for method serialize of class String
def test_String_serialize():
    field=String(format="date",allow_blank=True)
    test=field.serialize("2018-01-01")
    assert isinstance(test,str)
    assert test=="2018-01-01"
    return True


# Generated at 2022-06-24 10:43:50.084754
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format='datetime')
    assert s.serialize(None) == None
    assert s.serialize('2019-01-01T01:01:01') == '2019-01-01T01:01:01'
# End of unit test for method serialize of class String



# Generated at 2022-06-24 10:43:53.142239
# Unit test for constructor of class Decimal
def test_Decimal():
    #setup
    d = Decimal(title='foo', description='bar')
    #test
    assert d.title == 'foo'
    assert d.description == 'bar'
    #teardown


# Generated at 2022-06-24 10:43:57.219926
# Unit test for method validate of class Any
def test_Any_validate():
    schema = Any(name="Any")
    try:
        assert schema.validate(1) == 1
        assert schema.validate(True) == True
        assert schema.validate(None) == None
        assert schema.validate(1.78) == 1.78
        assert schema.validate({"true": True}) == {"true": True}
    except ValidationError:
        raise Exception('Failing "Any" unit test')

# Generated at 2022-06-24 10:44:00.165405
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="Name", description="enter your name")
    assert field.title == "Name"
    assert field.description == "enter your name"

test_Field()


# Generated at 2022-06-24 10:44:03.475031
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    strField = String(max_length=10)
    strField._creation_counter = 6
    strField.errors = {"required": "This field is required"}
    assert strField.validation_error("required").asdict() == {"code": "required","text": "This field is required"}


# Generated at 2022-06-24 10:44:04.536621
# Unit test for constructor of class Text
def test_Text():
    assert Text().text == String().text

# Tests for the constructor of class Choice

# Generated at 2022-06-24 10:44:07.882280
# Unit test for constructor of class Const
def test_Const():
    const_test = Const(True, const=True)
    assert str(const_test) == 'Const(True)'


# Generated at 2022-06-24 10:44:09.433060
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate(1) == 1

# Generated at 2022-06-24 10:44:13.749003
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(None) is None
    assert Any().validate(True) is True
    assert Any().validate(False) is False
    assert Any().validate(10) == 10
    assert Any().validate("str") == "str"
    assert Any().validate([1, 2, 3]) == [1, 2, 3]
    assert Any().validate({'a': 1}) == {'a': 1}



# Generated at 2022-06-24 10:44:23.832939
# Unit test for constructor of class Number
def test_Number():
    assert Number()
    assert Number(allow_null=True)
    assert Number(minimum=1)
    assert Number(allow_null=True, minimum=1)
    assert Number(allow_null=True, minimum=1, maximum=1)
    assert Number(allow_null=True, minimum=1, maximum=1, precision=None)
    assert Number(allow_null=True, minimum=1, maximum=1, precision=None, multiple_of=None)
    assert Number(
        title="", description="", default=NO_DEFAULT, allow_null=False, minimum=1, maximum=1, precision=None, multiple_of=None)
    assert Number(
        title="", description="", default=NO_DEFAULT, allow_null=False, minimum=1, maximum=1, precision=None, multiple_of=None)



# Generated at 2022-06-24 10:44:26.353102
# Unit test for constructor of class Const
def test_Const():
    try:
        Const(
            allow_null = False
        )
    except:
        pass

# Generated at 2022-06-24 10:44:34.603060
# Unit test for constructor of class Object

# Generated at 2022-06-24 10:44:41.939795
# Unit test for constructor of class Object
def test_Object():
    field = Object(properties={}, pattern_properties={}, additional_properties=True, property_names=None, min_properties=None, max_properties=None, required=[])
    assert field.properties is not None
    assert field.pattern_properties is not None
    assert field.additional_properties is not None
    assert field.property_names is None
    assert field.min_properties is None
    assert field.max_properties is None
    assert field.required is not None



# Generated at 2022-06-24 10:44:50.894461
# Unit test for method validate of class Choice
def test_Choice_validate():
    class Test(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value
    test_field1 = Test()
    test_field2 = Test(choices=["A","B","C"])
    test_field3 = Test(choices=[("A", "A"),("B","B")])
    test_field4 = Test(allow_null=True)
    assert test_field1.validate(1) == 1
    assert test_field1.validate("A","strict") == "A"
    assert test_field1.validate(None,"strict") == None
    assert test_field2.validate("A") == "A"
    assert test_field2.validate("C","strict") == "C"
    assert test_

# Generated at 2022-06-24 10:44:51.919993
# Unit test for method validate of class Const
def test_Const_validate():
    Const(3).validate(3)
    Const(3).validate(2)


# Generated at 2022-06-24 10:44:53.932064
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    f = Decimal()
    obj = f.serialize(10)
    assert obj == 10.0


# Generated at 2022-06-24 10:44:56.665531
# Unit test for constructor of class DateTime
def test_DateTime():
    schema = DateTime()
    assert schema.format == "datetime"
    assert schema.error_messages == {"type": "Must be a datetime in RFC 3339 format."}


# Generated at 2022-06-24 10:45:03.674743
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    
    # test_msg = '''
    # Field.validation_error(self, code:str) -> ValidationError
    # This function is to show the error message
    # '''
    # test_result = Field.validation_error(self, code)
    # test_err = 'none'
    # assert test_result == test_err, test_msg

    test_msg = '''
    This method will output all the error code.  
    '''
    test_result = Field.validation_error(self,'code')
    test_pass = '''
    This method will output all the error code.  
    '''
    assert test_result == test_pass, test_msg
    

# Generated at 2022-06-24 10:45:06.165925
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert not field.has_default()
    field = Field(default=1)
    assert field.has_default()



# Generated at 2022-06-24 10:45:10.932530
# Unit test for constructor of class Number
def test_Number():
    assert(Number(minimum=1) != None)
    assert(Number(maximum=None) != None)
    assert(Number(exclusive_minimum=1) != None)
    assert(Number(exclusive_maximum=None) != None)
    assert(Number(multiple_of=1) != None)
    assert(Number(precision=None) != None)


# Generated at 2022-06-24 10:45:19.265220
# Unit test for method validate of class Choice
def test_Choice_validate():
    from django.core.validators import MaxValueValidator
    from django.core.validators import MinValueValidator
    from django.core.validators import MinLengthValidator
    from django.core.validators import MaxLengthValidator
    from django.core.validators import RegexValidator
    str1 = "true"
    str2 = "false"
    str3 = "abc"
    int1 = 3
    int2 = 6
    list1 = []
    list2 = [1,2,3]
    set1 = set()
    set2 = set([1,2,3])
    dict1 = {}
    dict2 = {'name':'Bob','age':25}
    tuple1 = ()
    tuple2 = (1,2,3)
    none1 = None

# Generated at 2022-06-24 10:45:28.518593
# Unit test for method validate of class String
def test_String_validate():
    a = String()
    assert a.validate('1223') is '1223'
    assert a.validate(None) is '1223'
    assert a.validate('') is '1223'
    assert a.validate('    ') is '1223'
    assert a.validate('22\0022') is '2222'
    a = String(max_length=6)
    assert a.validate('122345') is '122345'
    assert a.validate('1223456') is '1223456'
    assert a.validate('12234567') is '1223456'
    assert a.validate(None) is '122345'
    assert a.validate('') is '122345'

# Generated at 2022-06-24 10:45:38.798687
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Array
    assert Array().serialize(None) is None
    assert Array().serialize([2, "ab"]) == [2, "ab"]
    assert Array(items=Integer()).serialize([2, "ab"]) == [2, None]
    assert Array(items=Array(items=Integer())).serialize([[1, 2], ["a", "b"]]) == [[1, 2], [None, None]]

    # Integer
    assert Integer().serialize(None) is None
    assert Integer().serialize(2) == 2
    assert Integer().serialize("ab") is None
    assert Integer().serialize(3.14) is None

    # String
    assert String().serialize(None) is None
    assert String().serialize("ab") == "ab"
    assert String().serialize(2) == "2"

# Generated at 2022-06-24 10:45:41.659504
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error("hello") == ValidationResult(value="hello", error=None)

# Generated at 2022-06-24 10:45:53.463011
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class Field_Sub(Field):
        def __init__(self):
            pass
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            pass
        def serialize(self, obj: typing.Any) -> typing.Any:
            pass
    # Creation
    field = Field_Sub()
    # Test with key 'format' in dict errors
    try:
        assert field.get_error_text("format") == "Invalid format."
    except KeyError:
        print("No key 'format' in dict errors")
    # Test without key 'format' in dict errors
    field.errors = {}
    try:
        assert field.get_error_text("coucou") == ""
    except KeyError:
        print("No key 'coucou' in dict errors")

# Generated at 2022-06-24 10:45:57.301515
# Unit test for constructor of class Union
def test_Union():
    # Test single child constructor
    ints = Union([Integer()])
    is_instance(ints, Union)

    # Test multiple children constructor
    num = Union([Integer(), Number()])
    is_instance(num, Union)

    # Test children with allow_null set to True,
    allowed = Union([Boolean(allow_null=True), Number(allow_null=True)])
    is_instance(allowed, Union)

    # Test no children
    with raises(AssertionError):
        allowed = Union([])



# Generated at 2022-06-24 10:45:58.722721
# Unit test for constructor of class DateTime
def test_DateTime():
    schema = DateTime()
    assert schema.__class__.__name__ == "DateTime"
    assert schema.format == "datetime"


# Generated at 2022-06-24 10:46:00.788651
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(default = 12)
    assert field.has_default() == True  


# Generated at 2022-06-24 10:46:08.270619
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from . import Text, Integer, Field
    from typesystem import ValidationError
    f = Text()
    assert f.validation_error('required') == ValidationError(text='This field is required', code='required')
    assert f.validation_error('max_length') == ValidationError(text='Ensure this field has no more than {max_length} characters.', code='max_length')
    
    g = Integer()
    assert g.validation_error('max_value') == ValidationError(text='Ensure this value is less than or equal to {max_value}.', code='max_value')


# Generated at 2022-06-24 10:46:10.232800
# Unit test for constructor of class Const
def test_Const():
    assert Const(2).const == 2



# Generated at 2022-06-24 10:46:17.103284
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_object = Decimal()
    assert decimal_object.serialize(None) is None
    assert decimal_object.serialize(1) == 1.0
    assert decimal_object.serialize(1.123456) == 1.123456

BOOLEAN_STATES = {
    "1": True, "true": True, "on": True, "yes": True, "0": False, "false": False, "off": False, "no": False
}



# Generated at 2022-06-24 10:46:26.050088
# Unit test for constructor of class Boolean
def test_Boolean():
    # Test passing none value
    assert Boolean(allow_null=True).validate(None) == None
    try:
        assert Boolean().validate(None) == None
    except ValidationError as e:
        assert e.code=="null"

    assert Boolean().validate(True) == True
    try:
        Boolean().validate(None)
    except ValidationError as e:
        assert e.code=="null"
    try:
        Boolean().validate("3")
    except ValidationError as e:
        assert e.code=="type"



# Generated at 2022-06-24 10:46:34.923883
# Unit test for constructor of class Choice
def test_Choice():
    # construct with list of choices
    c1 = Choice(choices=[1, 2, 'a'])
    assert c1.choices == [(1, 1), (2, 2), ('a', 'a')]
    # construct with list of tuples
    c2 = Choice(choices=[(1,2), (3,4), ('a', 'b')])
    assert c2.choices == [(1, 2), (3, 4), ('a', 'b')]
    try:
        # invalid constructor
        c3 = Choice(choices=[(1,2), (3,4), ('a', 'b', 'c')])
    except AssertionError:
        pass



# Generated at 2022-06-24 10:46:38.126656
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field("", "", default = "123456")
    assert field.get_default_value() == "123456"

# Generated at 2022-06-24 10:46:42.699399
# Unit test for method validate of class Const
def test_Const_validate():
    Const1 = Const(1)
    Const_validate_test1 = Const1.validate(2)
    Const_validate_test2 = Const1.validate(1)
    assert Const_validate_test1 == None
    assert Const_validate_test2 == 1
test_Const_validate()



# Generated at 2022-06-24 10:46:47.338600
# Unit test for constructor of class Choice
def test_Choice():
    # Test that the constructor of Choice class works

    assert Choice(choices = [1,2,3]).choices == [(1,1), (2,2), (3,3)]



# Generated at 2022-06-24 10:46:49.492063
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field.get_error_text(Field(), code="c") == "c"


# Generated at 2022-06-24 10:46:52.727383
# Unit test for constructor of class Float
def test_Float():
    myInstance = Float(a=1, b=2)
    assert myInstance.a == 1 and myInstance.b == 2 and myInstance.allow_null == False


# Generated at 2022-06-24 10:46:57.674823
# Unit test for method validate of class Const
def test_Const_validate():
    x = Const(const='value')
    value = 'value'
    assert(x.validate(value) == 'value')
    value = 'value1'
    try:
        assert(x.validate(value) == 'value1')
    except ValidationError:
        return True
    return False


# Generated at 2022-06-24 10:47:00.912526
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field=Field(default=1)
    assert field.get_default_value()==1
    assert field.get_default_value()!=2


# Generated at 2022-06-24 10:47:04.106411
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert(field.get_default_value() == None)
    field2 = Field(default = "default")
    assert(field2.get_default_value() == "default")

# Generated at 2022-06-24 10:47:14.545672
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    from typesystem.fields import Field
    from typesystem import types
    from typesystem.exceptions import ValidationError

    assert getattr(Field, 'default', None) is None
    assert Field().get_default_value() is None

    class Account(types.Schema):
        username = types.String(default="noreply")

    assert Account.fields['username'].get_default_value() == "noreply"

    class Account(types.Schema):
        username = types.String(default=lambda: "noreply")

    assert Account.fields['username'].get_default_value() == "noreply"

    class Account(types.Schema):
        username = types.String(default = "noreply", allow_null = True)


# Generated at 2022-06-24 10:47:16.836424
# Unit test for constructor of class Choice
def test_Choice():
    test_object = Choice(name="test", choices=["choice_1","choice_2"])
    assert test_object.name == "test"
    assert [key for key, value in test_object.choices] == ["choice_1", "choice_2"]

test_Choice()



# Generated at 2022-06-24 10:47:25.737353
# Unit test for constructor of class Object
def test_Object():
    properties = {
        'name': String(default='john')
    }
    pattern_properties = {
        'name': String(default='john')
    }
    additional_properties = None
    property_names = None
    min_properties = 5
    max_properties = 10
    required = None
    obj = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties,
                 property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    return obj


# Generated at 2022-06-24 10:47:31.560390
# Unit test for constructor of class DateTime
def test_DateTime():
    field = DateTime()
    assert isinstance(field, String)
    assert field.validate("2020-01-01T00:00:00") == "2020-01-01T00:00:00"

# Generated at 2022-06-24 10:47:37.237478
# Unit test for constructor of class Union
def test_Union():
    any_of = [
        Integer(format="int32", allow_null=True),
        Text()
    ]
    assert Union(any_of=any_of)
    assert Union(any_of=any_of).any_of[0] == Integer(format="int32", allow_null=True)
    assert Union(any_of=any_of).any_of[1] == Text()
    assert Union(any_of=any_of).allow_null == True
    assert Union(any_of=any_of).validator_compat == False



# Generated at 2022-06-24 10:47:45.575471
# Unit test for constructor of class Array
def test_Array():
    from pydantic import ValidationError
    from pydantic import BaseModel
    from pydantic import Field
    from pydantic import AnyHttpUrl

    class Schema(BaseModel):
        url: AnyHttpUrl
    array1 = Array(items=[Field(type_=str), Field(type_=str)])
    array2 = Array(items=[Field(type_=str), Field(type_=str)], required=True)

    assert_equal(array1.validate([]), [])
    assert_equal(
        array1.validate(["apple", "orange"]), ["apple", "orange"]
    )
    assert_raises(ValidationError, array2.validate, [])
    assert_equal(array2.validate(["apple", "orange"]), ["apple", "orange"])
    assert_

# Generated at 2022-06-24 10:47:47.222968
# Unit test for constructor of class String
def test_String():
    newString = String(title="Test String")
    assert newString.title == "Test String"


# Generated at 2022-06-24 10:47:51.532819
# Unit test for constructor of class DateTime
def test_DateTime():
    dtime = DateTime(format='datetime', description='datetime', min_length=1, max_length=10, allow_null=False, default=datetime.datetime.now())
    assert isinstance(dtime, DateTime)

# Generated at 2022-06-24 10:47:53.774495
# Unit test for constructor of class Field
def test_Field():
    f1 = Field()
    assert isinstance(f1, Field) and f1.default is NO_DEFAULT and not f1.allow_null
    f2 = Field(title="Field 2", description="Description of Field 2",
               default=1, allow_null=True)
    assert isinstance(f2, Field) and f2.default is 1 and f2.allow_null


# Generated at 2022-06-24 10:48:01.547338
# Unit test for constructor of class Array
def test_Array():
    print("Testing constructor of class Array")
    min_items = 2
    max_items = 4
    items = [Field(),Field()]
    additional_items = False
    field = Array(items = items, additional_items = additional_items, max_items = max_items, min_items = min_items)
    assert field.items == items
    assert field.additional_items == additional_items
    assert field.max_items == max_items
    assert field.min_items == min_items
    print("Test for constructor of class Array passed \n")


# Generated at 2022-06-24 10:48:03.119282
# Unit test for constructor of class Integer
def test_Integer():
    a = Integer()
    assert (a.numeric_type) == int


# Generated at 2022-06-24 10:48:05.855794
# Unit test for constructor of class Time
def test_Time():
    schema = Time()
    assert schema.format == 'time'


# Generated at 2022-06-24 10:48:08.455179
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    assert any['allow_null'] == True
    assert any['title'] == None
    assert any['default'] == None


# Generated at 2022-06-24 10:48:14.933951
# Unit test for method validate of class Array
def test_Array_validate():
    import pytest
    from pydantic import BaseModel, ValidationError
    from pydantic.fields import Field

    class Foo(BaseModel):
        bar: int

    class Model(BaseModel):
        foo: typing.List[Foo]

    field = Model.__fields__["foo"]
    assert isinstance(field, Field)
    
    # below errors is the unit test
    with pytest.raises(ValidationError) as exc_info:
        Model(foo={"bar": 1})

    assert exc_info.value.errors() == [
        {
            "loc": ("foo",),
            "msg": "type error",
            "type": "type_error.list",
            "ctx": {"expected_type": "list"},
        }
    ]

# Generated at 2022-06-24 10:48:16.513099
# Unit test for constructor of class Boolean
def test_Boolean():
    expected_output = "Must be a boolean."
    actual_output = Boolean().errors['type']
    assert expected_output == actual_output


# Generated at 2022-06-24 10:48:18.403158
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    Field().validate_or_error(1, strict=False)


# Generated at 2022-06-24 10:48:26.119408
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field(title="title", description="description", default=1, allow_null=True)
    result = field.validate_or_error(1, strict=False)
    assert result.value == 1
    assert result.error == None

    result2 = field.validate_or_error(1, strict=True)
    assert result2.value == 1
    assert result2.error == None

    result3 = field.validate_or_error("a", strict=False)
    assert (result3.value == None)
    assert isinstance(result3.error, ValidationError)

    result4 = field.validate_or_error("a", strict=True)
    assert (result4.value == None)
    assert isinstance(result4.error, ValidationError)


# Generated at 2022-06-24 10:48:30.042825
# Unit test for constructor of class Text
def test_Text(): 
    t = Text()
    t = Text(min_length=3)
    t = Text(max_length=3)
    t = Text(enumeration=["a", "b"])
    t = Text(whitespace="preserve")
    t = Text(pattern=r'[0-9]')



# Generated at 2022-06-24 10:48:31.510978
# Unit test for constructor of class Date
def test_Date():
    assert isinstance(Date(format="date"), Field)
# End of unit test



# Generated at 2022-06-24 10:48:33.740257
# Unit test for constructor of class Object
def test_Object():
    print('\nTesting constructor of class Object')
    # initialize class
    obj = Object()
    if obj is not None:
        print('Field initialized')
