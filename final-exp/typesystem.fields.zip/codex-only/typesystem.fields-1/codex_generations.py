

# Generated at 2022-06-24 10:38:38.854754
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationResult
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem.types import StringType
    from decimal import Decimal
    from numbers import Real

    # Note: this function is much more complex to test than it needs to be, 
    # as it uses an object which does not have an __init__ method
    # and cannot therefore be instantiated directly. Thus, we must apply a 
    # closure to the object and return it.
    def test_object_closure(value_to_test, error_text, strict, expected_result):
        test_object = Field()
        test_object.default = value_to_test
        test_object.strict = strict
        test_object.errors = {'u': error_text}

# Generated at 2022-06-24 10:38:41.457946
# Unit test for constructor of class Union
def test_Union():
    # Setup
    field = Union([String(), Number()], description="test union")
    # Exercise
    actual = type(field)
    # Verify
    assert actual == Union


# Generated at 2022-06-24 10:38:48.252100
# Unit test for method has_default of class Field
def test_Field_has_default():
    def foo():
        return True
    field1 = Field(title="test1")
    field2 = Field(title="test2", default="default")
    field3 = Field(title="test3", default=foo)
    field4 = Field(title="test4", default=1)
    field5 = Field(title="test5", default=True)
    assert field1.has_default()==False
    assert field2.has_default()==True
    assert field3.has_default()==True
    assert field4.has_default()==True
    assert field5.has_default()==True


# Generated at 2022-06-24 10:38:49.167844
# Unit test for method validate of class Any
def test_Any_validate():
    assert(True)

# Generated at 2022-06-24 10:38:51.835443
# Unit test for method serialize of class Field
def test_Field_serialize():
    f1 = Field()

    assert f1.serialize("Json") == "Json"
    assert f1.serialize("Xml") == "Xml"
    assert f1.serialize("Json") != f1.serialize("Xml")


# Generated at 2022-06-24 10:38:57.259883
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate("3") == 3
    assert Number().validate("-3") == -3
    assert Number().validate("-3.5") == -3.5
    assert Number().validate("1E+2") == 100.0
    assert Number().validate("-100.5") == -100.5
    assert Number().validate("1e2") == 1e2
    assert Number().validate("3.14e-2") == 3.14e-2
    assert Number().validate("0x10") == 0x10
    assert Number().validate("-0xF") == -0xF

# Generated at 2022-06-24 10:39:07.346744
# Unit test for method validate of class Any
def test_Any_validate():
    #
    # initialize object
    #
    obj = Any(allow_null = True, default = None, title = '')
    #
    # test calls
    #
    assert obj.validate(3) == 3
    assert obj.validate(3.0) == 3.0
    assert obj.validate(True) == True
    assert obj.validate(False) == False
    assert obj.validate(None) == None
    assert obj.validate('abc') == 'abc'
    from datetime import datetime
    assert obj.validate(datetime.now()) == datetime.now()
    assert obj.validate([1,2,3]) == [1,2,3]
    assert obj.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-24 10:39:09.671062
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Create an instance of class Boolean
    boolean = Boolean()
    # Make the object boolean return None
    assert(boolean.validate(None) is None)


# Generated at 2022-06-24 10:39:11.425027
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
        if Decimal(10).serialize(None)!= None:
            print("unit test for method serialize of class Decimal is failed")



# Generated at 2022-06-24 10:39:21.162121
# Unit test for method validation_error of class Field
def test_Field_validation_error():
   import numbers
   f = Field()
   f.errors = {'code_1':'error'}
   assert f.validation_error('code_1') != None
   f._creation_counter = 1
   assert f._creation_counter == 1
   assert f.has_default() == False
   assert f.get_error_text('code_1') == 'error'
   assert f.serialize(0) == 0
   x = f.validate(0, strict=True)
   assert x == 0
   x = f.validate_or_error(0, strict=False)
   assert x != None
   assert x.value == 0
   assert x.error == None



# Generated at 2022-06-24 10:39:30.080466
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=[
            DateTime(),
            Boolean(),
            Dict({
                "id": Integer(),
                "name": String(),
                "colors": Array(items=String(pattern=r"^#[0-9a-fA-F]{6}$"), max_items=5),
            })
        ],
        min_items=1,
        max_items=5,
    )
    data = [
        '2019-01-01T00:00:00',
        False,
        {'id': 1234, 'name': 'Sam', 'colors': ['#e66465', '#9198e5']},
    ]
    field.validate(data)


# Generated at 2022-06-24 10:39:41.352312
# Unit test for constructor of class String
def test_String():
    try:
        s = String()
        print("Test 1: Ok!")
    except:
        print("Test 1: Error!")
    try:
        s = String(title="name",default=NO_DEFAULT)
        print("Test 2: Ok!")
    except:
        print("Test 2: Error!")
    try:
        s = String(title="name",default=None)
        print("Test 3: Ok!")
    except:
        print("Test 3: Error!")
    try:
        s = String(title="name",default=None,allow_null=True)
        print("Test 4: Ok!")
    except:
        print("Test 4: Error!")

# Generated at 2022-06-24 10:39:42.952673
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(const=None)
    assert const.validate(const=None) == None


# Generated at 2022-06-24 10:39:51.453429
# Unit test for constructor of class String
def test_String():
    field = String(title = "string", description = "string", allow_null = False, default = "default")
    assert field.allow_blank == False
    assert field.trim_whitespace == True
    assert field.max_length == None
    assert field.min_length == None
    assert field.pattern == None
    assert field.format == None
    assert field.default == "default"
    assert field.title == "string"
    assert field.description == "string"
    assert field.allow_null == False


# Generated at 2022-06-24 10:39:53.668180
# Unit test for constructor of class Integer
def test_Integer():
    myInteger = Integer()
    assert myInteger.numeric_type == int


# Generated at 2022-06-24 10:40:05.015385
# Unit test for method validate of class String
def test_String_validate():
    field = String(
        max_length=10,
        min_length=2,
        pattern="\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
        format="ipv4")
    assert field.validate("10.10.10.10") == "10.10.10.10"
    field = String(
        max_length=5,
        min_length=2,
        pattern="\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
        format="ipv4")
    assert field.validate("10.10.10.10") == "10.10.10.10"

# Generated at 2022-06-24 10:40:10.429241
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal(title = '', description = '', default = NO_DEFAULT, allow_null = False, minimum = None, maximum = None, exclusive_minimum = None, exclusive_maximum = None, precision = None, multiple_of = None)
    assert isinstance(a, Field)
    assert isinstance(a, Number)



# Generated at 2022-06-24 10:40:13.587874
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(minimum=0.001, maximum=0.999, exclusive_minimum=0.002, exclusive_maximum=0.998, precision=0.01, allow_null=False, multiple_of=0.001) is not None



# Generated at 2022-06-24 10:40:14.727735
# Unit test for constructor of class Integer
def test_Integer():
    num = Integer(title='must be a integer')



# Generated at 2022-06-24 10:40:20.959671
# Unit test for method validate of class Const
def test_Const_validate():
    try:
        obj = Const(1)
        v = obj.validate(5)
        assert False
    except ValidationError:
        pass
    else:
        assert True
    try:
        obj = Const(None)
        v = obj.validate(5)
        assert False
    except ValidationError:
        pass
    else:
        assert True
    obj = Const(1)
    v = obj.validate(1)
    assert v == 1
    obj = Const(None)
    v = obj.validate(None)
    assert v is None



# Generated at 2022-06-24 10:40:28.095579
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("true") == True
    assert field.validate("false") == False
    assert field.validate("on") == True
    assert field.validate("off") == False
    assert field.validate("1") == True
    assert field.validate("0") == False
    assert field.validate("") == False
    assert field.validate(1) == True
    assert field.validate(0) == False



# Generated at 2022-06-24 10:40:35.418116
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="This is a title",
                  description="This is the description",
                  allow_null=False)
    assert field.title == "This is a title"
    assert field.description == "This is the description"
    assert field.allow_null is False
    assert field.has_default() is False
    field = Field(title="This is a title",
                  description="This is the description",
                  allow_null=False,
                  default=NO_DEFAULT)
    assert field.default == NO_DEFAULT
    assert field.has_default() is False
    field = Field(title="This is a title",
                  description="This is the description",
                  allow_null=False,
                  default=None)
    assert field.default is None
    assert field.has_default() is True

# Generated at 2022-06-24 10:40:38.767159
# Unit test for method serialize of class Field
def test_Field_serialize():
    # Test serialize(): no exception is raised
    for i in range(10):
        if i%2==0:
            field = Integer()
        else:
            field = String()
        assert field.serialize(1)==1

# Generated at 2022-06-24 10:40:44.427489
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime(strict=True, allow_null=True, default="").default == ""
    assert DateTime(strict=True, allow_null=True, default=None).default == None
    assert DateTime(strict=True, allow_null=True, default=False).default == "False"
    assert DateTime(strict=True, allow_null=True, default="test").default == "test"


# Generated at 2022-06-24 10:40:45.515601
# Unit test for constructor of class Number
def test_Number():
    num = Number()


# Generated at 2022-06-24 10:40:57.494213
# Unit test for constructor of class String
def test_String():
    assert String().validate('Hello world') == 'Hello world'
    assert String().validate(' \t Hello world \n') == 'Hello world'
    assert String(allow_blank=True, trim_whitespace=False).validate(' \t Hello world \n') == ' \t Hello world \n'
    assert String(allow_blank=False, trim_whitespace=True).validate(' \t Hello world \n') == 'Hello world'
    assert String(allow_blank=True, trim_whitespace=True).validate(' \t Hello world \n') == 'Hello world'
    assert String(allow_null=False).validate(None) == None
    assert String(allow_null=True).validate(None) == None
test_String()



# Generated at 2022-06-24 10:41:07.715132
# Unit test for method serialize of class Array
def test_Array_serialize(): 
    obj = {'username': 'Kyl',   'password': '1234567890',
    'balance': 200, 'coins': {'gold': 5, 'silver': 10, 'bronze': 15,},}
    user_fields = {
    'username': String(max_length=30),
    'password': String(max_length=30, format='password'),
    'balance': Number(),
    'coins': Object(properties={
        'gold': Number(),
        'silver': Number(),
        'bronze': Number(),
    }),
    }
    user_schema = Object(properties=user_fields, required=user_fields.keys())
    result = user_schema.serialize(obj)
    #print(result)
    assert result['username'] == 'Kyl'

# Generated at 2022-06-24 10:41:10.324159
# Unit test for constructor of class Float
def test_Float():
    field = Float()
    assert field.numeric_type == float


# Generated at 2022-06-24 10:41:13.772118
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]


# Generated at 2022-06-24 10:41:17.076664
# Unit test for constructor of class Object
def test_Object():
    # Invalid pattern_properties
    with pytest.raises(AssertionError) as e:
        Object(pattern_properties={"name": ""})
    assert str(e.value) == "All pattern property values must be an instance of `Field`."


# Generated at 2022-06-24 10:41:17.658602
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
  pass


# Generated at 2022-06-24 10:41:20.144947
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert isinstance(a, Text)
    assert isinstance(a, Field) 
    assert a.format == 'text'

# xUnit tests for Array class

# Generated at 2022-06-24 10:41:24.981151
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.allow_null == False
    assert field.title == ""
    assert field.description == ""
    assert field.get_default_value() == None
    assert field.validation_error('code') is not None
    assert field.get_error_text('code') == ""
    assert field.has_default() == False


# Generated at 2022-06-24 10:41:26.934715
# Unit test for method validate of class Array
def test_Array_validate():
    items = [Integer(), Integer()]
    instance = Array(items)
    instance.validate([10, 20])
    # expected output: None


# Generated at 2022-06-24 10:41:28.750997
# Unit test for constructor of class Object
def test_Object():
    my_objecttest = Object(properties={'id':Integer()}, max_properties=10, required=['id'])
    my_objecttest.validate({'id':8})




# Generated at 2022-06-24 10:41:36.412155
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={'name': String(allow_null=True)})
    schema.validate(value={'name': 'abc'})
    schema.validate(value={'name': 'abc', 'age': 20})
#     schema.validate({'name': None})
    schema.validate(value={'name': 'abc', 'age': 20, '': 'test'})
    with pytest.raises(ValidationError):
        schema.validate(value={'name': None})

# Generated at 2022-06-24 10:41:39.771037
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field()
    assert f.get_default_value() == None
    f = Field(default='Default')
    assert f.get_default_value() == 'Default'
    

# Generated at 2022-06-24 10:41:48.072288
# Unit test for constructor of class Float
def test_Float():
    # Test successful validation
    assert Float().validate(5.5) == 5.5
    assert Float().validate(-5.5) == -5.5
    assert Float().validate(0.0) == 0.0
    assert Float().validate(0) == 0
    assert Float().validate(-0.0) == -0.0
    # Test failed validation
    try:
        Float().validate(True)
    except ValidationError:
        pass
    else:
        assert False
    try:
        Float().validate(None)
    except ValidationError:
        pass
    else:
        assert False
    try:
        Float().validate(float("nan"))
    except ValidationError:
        pass
    else:
        assert False

# Generated at 2022-06-24 10:41:49.055046
# Unit test for constructor of class Text
def test_Text():
    tex = Text()
    assert tex.format == 'text'



# Generated at 2022-06-24 10:41:52.125113
# Unit test for constructor of class Object
def test_Object():
    object = Object(properties={"test": "test"},
                    pattern_properties={"test": "test"},
                    additional_properties=True,
                    property_names=String(),
                    min_properties=1,
                    max_properties=1,
                    required=1)



# Generated at 2022-06-24 10:41:59.703716
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    messages = {
        "invalid_email": "The email address entered is not valid",
        "min_length": "Ensure this field has at least {min_length} characters.",
        "max_length": "Ensure this field has no more than {max_length} characters.",
        "blank": "This field may not be blank.",
        "required": "This field is required.",
    }
    field = CharField(min_length=5, max_length=5, errors=messages)
    assert field.validation_error('invalid_email').code == 'invalid_email'

# Generated at 2022-06-24 10:42:06.972603
# Unit test for method validation_error of class Field
def test_Field_validation_error():

    errors = {
        "no_such_error": "no_such_error",
        "another_error": "another_error",
    }

    # Use Field instance to call method validation_error
    field = Field(title="",description="",default=NO_DEFAULT,allow_null=False)

    field.errors = errors
    code = "no_such_error"
    # Call method and compare expected result
    assert field.validation_error(code).__dict__ == ValidationError(text="no_such_error",code="no_such_error").__dict__



# Generated at 2022-06-24 10:42:10.833735
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert isinstance(f, Float)
    assert f.numeric_type == float


# Generated at 2022-06-24 10:42:12.858176
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field().get_error_text('1') == ''

test_Field_get_error_text()


# Generated at 2022-06-24 10:42:17.360033
# Unit test for constructor of class Integer
def test_Integer():
    a = Integer()
    assert a.numeric_type is int
    a.minimum = 10
    assert a.minimum == 10
    a.maximum = 20
    assert a.maximum == 20
    a.exclusive_minimum = 30
    assert a.exclusive_minimum == 30
    a.exclusive_maximum = 40
    assert a.exclusive_maximum == 40
    a.multiple_of = 50
    assert a.multiple_of == 50


# Generated at 2022-06-24 10:42:28.256866
# Unit test for method validate of class Array
def test_Array_validate():
    items = [String(), Number()]
    additional_items = False
    min_items = 1
    max_items = 3
    unique_items = False
    
    
    # Test case of parameters
    res = Array(items = items, additional_items = additional_items, min_items = min_items, max_items = max_items, unique_items = unique_items)
    assert res.items == items
    assert res.additional_items == additional_items
    assert res.min_items == min_items
    assert res.max_items == max_items
    assert res.unique_items == unique_items
    
    # Test case of Null and Null allow Null
    res = Array(allow_null=True)
    assert res.validate(None) == None
    
    # Test case of Null and Null not allowed Null


# Generated at 2022-06-24 10:42:29.335122
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array().serialize([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 10:42:34.748043
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field()
    f_none = Field(default=None)
    f_true = Field(default=True)
    f_false = Field(default=False)
    f_zero = Field(default=0)
    f_1 = Field(default=1)
    c = Field(default=lambda: 1)
    assert f.has_default() == False
    assert f_none.has_default() == True
    assert f_true.has_default() == True
    assert f_false.has_default() == True
    assert f_zero.has_default() == True
    assert f_1.has_default() == True
    assert c.has_default() == True
test_Field_has_default()


# Generated at 2022-06-24 10:42:46.972442
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Create class Field
    class Field1(Field):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.default = '1'
        def validate(self, value, **kwargs):
            return value
        def serialize(self, obj):
            return '10'
    # Create Array type
    class Array1(Array):
        def serialize(self, obj):
            return '[10]'

    data_list = [
        {'obj':None},
        {'obj':[1,2,4],'result':'[10,10,10]'},
        {'obj':1,'result':'[10]'},
    ]
    data_list[0]['result'] = None
    for data in data_list:
        a = Array1()
       

# Generated at 2022-06-24 10:42:57.743524
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
    check Field __or__
    """
    t = Field(title="Test", description="Test", default="a")
    t1 = Field(title="Test", description="Test", default="a")
    t2 = Field(title="Test", description="Test", default="a")
    t3 = Field(title="Test", description="Test", default="a")
    t4 = Field(title="Test", description="Test", default="a")
    t5 = Field(title="Test", description="Test", default="a")
    t6 = Field(title="Test", description="Test", default="a")
    t7 = Field(title="Test", description="Test", default="a")
    t8 = Field(title="Test", description="Test", default="a")

# Generated at 2022-06-24 10:43:03.174275
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=["a", "b", "c"]).choices == [("a", "a"), ("b", "b"), ("c", "c")]
    assert Choice(choices=[["a", "b"], ["c", "d"]]).choices == [("a", "b"), ("c", "d")]
    assert Choice(choices=[("a", "b"), "c"]).choices == [("a", "b"), ("c", "c")]


# Generated at 2022-06-24 10:43:06.160477
# Unit test for constructor of class Object
def test_Object():
    properties = {
        "a": Decimal(),
        "b": Decimal(),
    }



# Generated at 2022-06-24 10:43:14.491182
# Unit test for constructor of class Number
def test_Number():
    assert Number.__init__(Number(), **{'allow_null': False})
    assert Number.__init__(
        Number(), **{'allow_null': False, 'minimum': 1, 'maximum': 100})
    assert Number.__init__(
        Number(), **{'allow_null': False, 'exclusive_minimum': 1,
                     'exclusive_maximum': 100})
    assert Number.__init__(
        Number(), **{'allow_null': False, 'multiple_of': 2})
    assert Number.__init__(
        Number(), **{'allow_null': False, 'precision': "0.001"})



# Generated at 2022-06-24 10:43:23.102763
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice(choices=["Pending","Shipped"])
    print("Test 1:")
    print("Test case: Valid choice value")
    print("Expected: Pending", "\nOutput: ",choices.validate("Pending"))
    print("Test 2:")
    print("Test case: Invalid choice value")
    try:
        print("Expected: ValidationError", "\nOutput: ", choices.validate("Out for delivery"))
    except ValidationError as error:
        print("Caught ValidationError\n",error)
    print("Test 3:")
    print("Test case: Blank choice value")
    try:
        print("Expected: ValidationError", "\nOutput: ", choices.validate(""))
    except ValidationError as error:
        print("Caught ValidationError\n",error)


# Generated at 2022-06-24 10:43:24.087782
# Unit test for constructor of class Time
def test_Time():
    t1 = Time()
    assert t1.format == 'time'



# Generated at 2022-06-24 10:43:30.824775
# Unit test for constructor of class Float
def test_Float():
    a = Float(minimum=1, maximum=10, exclusive_minimum=None, exclusive_maximum=None, precision=None, multiple_of=None)
    assert a.minimum == 1
    assert a.maximum == 10
    assert a.exclusive_minimum is None
    assert a.exclusive_maximum is None
    assert a.precision is None
    assert a.multiple_of is None


# Generated at 2022-06-24 10:43:41.044614
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Boolean(), Integer(), Float()]
    field1 = Union(any_of, name="field1")
    assert field1.validate(0) == 0
    assert field1.validate(0.0) == 0.0
    assert field1.validate(False) == False
    assert field1.validate(True) == True

    assert field1.validate(None) == None

    with pytest.raises(ValidationError) as exc_info:
        assert field1.validate(None, strict=True)
    assert exc_info.value.messages()[0].code == "null"

    with pytest.raises(ValidationError) as exc_info:
        assert field1.validate("abc")

# Generated at 2022-06-24 10:43:51.843094
# Unit test for constructor of class Integer
def test_Integer():
    print("\ntest_Integer")

    # test for default constructor
    int1 = Integer()
    print("int1:", int1)

    # test for constructor with min, max, exclusive_min, exclusive_max
    int2 = Integer(minimum=1, maximum=10, exclusive_minimum=2, exclusive_maximum=9)
    print("int2:", int2)

    # test for constructor with precision
    int3 = Integer(precision="0.01")
    print("int3", int3)

    # test for constructor with multiple_of
    int4 = Integer(multiple_of=3)
    print("int4", int4)

    # test for constructor with allow_null
    int5 = Integer(allow_null=True)
    print("int5", int5)

    # test for constructor with all parameters
   

# Generated at 2022-06-24 10:43:56.048537
# Unit test for constructor of class DateTime
def test_DateTime():

    # Check that DateTime.__init__ creates a DateTime object with passed kwargs
    assert DateTime(format="datetime", allow_empty=False, min_length=1, max_length=10, default="") == DateTime()

    # Check that DateTime.__init__ throws an AssertionError when kwargs are invalid
    with pytest.raises(AssertionError):

        # Test the case when kwarg format != 'datetime'
        DateTime(format="datetime1")

        # Test the case when kwarg allow_empty is not a bool
        DateTime(allow_empty=1)

        # Test the case when kwarg min_length is not an int
        DateTime(min_length="")

        # Test the case when kwarg max_length is not an int

# Generated at 2022-06-24 10:43:58.510910
# Unit test for constructor of class Array
def test_Array():
    items = [Number(), Number()]
    obj = Array(items, additional_items=False, min_items=2, max_items=2)
    #print("obj = ",obj)




# Generated at 2022-06-24 10:44:02.633586
# Unit test for constructor of class Choice
def test_Choice():
    for choice in ['a','b',('a','b')]:
        assert Choice(choices=choice) == 'a'
    for choice in ['a','b',('a','b')]:
        assert Choice(choices=choice).validate(choice) == 'a'

# Generated at 2022-06-24 10:44:06.735877
# Unit test for method validate of class Number
def test_Number_validate():
    x = Integer(minimum=5,maximum=10)
    test1 = x.validate(11)
    print("First test: ", test1)
    test2 = x.validate("")
    print("Second test: ", test2)
    test3 = x.validate(None)
    print("Third test: ", test3)
    test4 = x.validate("11")
    print("Fourth test: ", test4)

test_Number_validate()



# Generated at 2022-06-24 10:44:08.002315
# Unit test for constructor of class Float
def test_Float():
    assert isinstance(Float(), Float)


# Generated at 2022-06-24 10:44:09.164342
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert True


# Generated at 2022-06-24 10:44:12.334127
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number(multiple_of=4)
    assert number.validate(4) == 4
    assert number.validate(8) == 8


# Generated at 2022-06-24 10:44:22.861539
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(allow_null=True).validate(None)
    assert Number().validate(1)
    assert Number().validate(1.0)
    assert Number().validate(decimal.Decimal(1))
    assert Number(precision=".1").validate(1.2) == 1.2
    assert Number(minimum=2).validate(3)
    assert Number(exclusive_minimum=2).validate(2)
    assert Number(maximum=4).validate(3)
    assert Number(exclusive_maximum=4).validate(4)
    assert Number(multiple_of=3).validate(6)
    assert Number().validate(1.001)
    assert Number().validate(0)
    assert Number().validate(-1)
    assert Number().validate(-1.0)
    # 

# Generated at 2022-06-24 10:44:28.476932
# Unit test for constructor of class Choice
def test_Choice():
    #  @given(tuples(lists(text(alphabet=string.ascii_letters, min_size=1, max_size=10), min_size=1, max_size=10)))
    # def test_Choice(values):
    #     field = Choice(choices=values)
    #     unique_values = [value[0] for value in field.choices]
    #     assert len(unique_values) == len(field.choices)
    #     assert all(len(choice) == 2 for choice in field.choices)

    choices = ["abc", "def", "ghi"]
    field = Choice(choices=choices)
    assert field.choices == [("abc", "abc"), ("def", "def"), ("ghi", "ghi")]



# Generated at 2022-06-24 10:44:30.481034
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal()
    assert a.validate(1.0) == 1.0
    


# Generated at 2022-06-24 10:44:33.297449
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field = Decimal()
    assert field.serialize(None) == None
    assert field.serialize(0) == 0.0
    assert field.serialize(1) == 1.0
# End of unit test for method serialize of class Decimal



# Generated at 2022-06-24 10:44:35.254435
# Unit test for method validate of class Union
def test_Union_validate():
    a=Union([String(max_length=3),String(max_length=3)],required=True)
    print(a.validate('aa'))
    print(a.validate('aaaa'))

# Generated at 2022-06-24 10:44:39.911593
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class TestField(Field):
        errors = {
            'invalid_type': "You enter an invalid type"
        }

        def validate(self, value, *, strict=False):
            return True

    field = TestField()
    assert field.get_error_text('invalid_type') == "You enter an invalid type"



# Generated at 2022-06-24 10:44:44.433137
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field().validate(1) == 1
    assert Field().validate(None) is None
    assert Field().validate('some value') == 'some value'
    assert Field().validate('') == ''
    assert Field().validate(True) == True
    assert Field().validate(False) == False
    assert Field().validate(0) == 0


# Generated at 2022-06-24 10:44:47.132365
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(allow_null = True, max_length = 20, allow_blank = True)
    assert string.serialize("string") == "string"


# Generated at 2022-06-24 10:44:50.361169
# Unit test for constructor of class Number
def test_Number():
    """
    The test of constructor (__init__) for class Number
    """
    num1 = Number(minimum=4)
    assert num1.validate(4.0)==4.0
    #assert num1.validate(3.6)==None
    assert num1.validate(3.9)==3.9


# Generated at 2022-06-24 10:44:58.038106
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    import hypothesis.strategies as st
    import hypothesis.extra.numpy as hnp
    import hypothesis.extra.decimals as hd
    import hypothesis.extra.pandas as hpd

    from hypothesis import given, settings
    from decimal import Decimal as float


    def _test_Decimal_serialize(obj):
        assert Decimal(obj).serialize(10) == None if obj is None else float(obj)

    _test_Decimal_serialize(hd.decimals(allow_nan=False, allow_infinity=False))



# Generated at 2022-06-24 10:45:05.036654
# Unit test for method serialize of class Field
def test_Field_serialize():
    class TestField(Field):
        def __init__(self, title, description, default, allow_null):
            super().__init__(title=title, description=description, default=default, allow_null=allow_null)

        def validate(self, value, strict=False):
            return value

    #Case 1: no default
    f1 = TestField(title="f1", description="", default=NO_DEFAULT, allow_null=False)
    assert f1.serialize(1) == 1

    #Case2: default is None
    f2 = TestField(title="f2", description="", default=None, allow_null=False)
    assert f2.serialize(1) == 1

    #Case3: default is provided

# Generated at 2022-06-24 10:45:05.994838
# Unit test for constructor of class Date
def test_Date():
    # test_1
    a = Date()



# Generated at 2022-06-24 10:45:06.624596
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime()


# Generated at 2022-06-24 10:45:10.088294
# Unit test for method validate of class Const
def test_Const_validate():
    a = Const(1)
    assert a.validate(1) == 1
    try:
        a.validate(2)
    except ValidationError as e:
        assert e.messages()[0].code == 'const'


# Generated at 2022-06-24 10:45:13.540128
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field(
        title='This is the title',
        description='This is the description',
        default=None,
        allow_null=False,
    )
    assert field.validate('string') == 'string'

# Generated at 2022-06-24 10:45:24.066302
# Unit test for method validate of class String
def test_String_validate():
    # Test valid format:
    s = String()
    s_result = s.validate("abcd")
    assert s_result == "abcd"

    # Test invalid format:
    s = String()
    try:
        s.validate(123)
        assert False
    except ValidationError:
        assert True
    # Test invalid pattern:
    from datetime import datetime
    s = String(pattern=r'\d{4}-\d{1,2}-\d{1,2}')
    s_result = s.validate("1234-5-6")
    assert s_result == "1234-5-6"

    s = String(pattern=r'\d{4}-\d{1,2}-\d{1,2}')

# Generated at 2022-06-24 10:45:26.816748
# Unit test for method validate of class Choice
def test_Choice_validate():
    col = Choice()
    col.choices = [('1', 'a'), ('2', 'b'), ('3', 'c')]
    assert col.validate('1') == '1'
    assert col.validate('2') == '2'
    assert col.validate('3') == '3'
    assert col.validate(1) == '1'
    assert col.validate(2) == '2'
    assert col.validate(3) == '3'


# Generated at 2022-06-24 10:45:34.297236
# Unit test for constructor of class Number
def test_Number():
    n = Number(minimum=0.1, maximum=10, exclusive_minimum=1.1, exclusive_maximum=9.9, precision="0.01", multiple_of=3)
    assert n.minimum == 0.1
    assert n.maximum == 10
    assert n.exclusive_minimum == 1.1
    assert n.exclusive_maximum == 9.9
    assert n.precision == "0.01"
    assert n.multiple_of == 3



# Generated at 2022-06-24 10:45:38.271318
# Unit test for method serialize of class Field
def test_Field_serialize():
    test_field = Field()
    test_obj = object()
    test_field.serialize(test_obj)
# test of serialize method of class Field
#    assert test_field.serialize(test_obj) == test_obj
# test of has_default method of class Field
#    assert test_field.has_default() == False

# Generated at 2022-06-24 10:45:39.036339
# Unit test for constructor of class Float
def test_Float():
    Float()


# Generated at 2022-06-24 10:45:46.339611
# Unit test for method serialize of class String
def test_String_serialize():
    """Test if the serialization of string is done well"""

    s = String(title="a",description="b",allow_null=True,allow_blank=True,trim_whitespace=True,max_length=None,min_length=None,format="date")
    res = s.serialize(datetime.datetime(2019,1,1))
    if res == "01/01/2019" :
        print("Test serialize of class string passed!")
    else:
        print("Test serialize of class string failed!")

test_String_serialize()



# Generated at 2022-06-24 10:45:56.174329
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test if both self and other are Field
    def test_Field___or___Field():
        # Test if self is Null and other is Null
        from .null import Null
        from .union import Union
        self = Null()
        other = Null()
        expected = Union(any_of=[self, other])
        assert expected == (self | other)


        # Test if self is Null and other is not Null
        from .null import Null
        from .union import Union
        self = Null()
        other = Any(title="Some title", description="Some description", allow_null=True)
        expected = Union(any_of=[self, other])
        assert expected == (self | other)


        # Test if self is not Null and other is Null
        from .null import Null
        from .union import Union

# Generated at 2022-06-24 10:46:06.952207
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean(allow_null = True)
    assert b.validate(None) == None
    try:
        assert b.validate(1)
    except ValidationError:
        assert True
    else:
        assert False
    try:
        assert b.validate("true")
    except ValidationError:
        assert True
    else:
        assert False
    try:
        assert b.validate("0")
    except ValidationError:
        assert True
    else:
        assert False
    assert b.validate(1, strict = True) == True
    assert b.validate("true", strict = True) == True
    assert b.validate("0", strict = True) == False

test_Boolean_validate()

# Generated at 2022-06-24 10:46:07.533986
# Unit test for constructor of class Float
def test_Float():
    pass


# Generated at 2022-06-24 10:46:10.396873
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, String)
    assert text.format == "text"



# Generated at 2022-06-24 10:46:12.038955
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    assert s.serialize(123) == 123



# Generated at 2022-06-24 10:46:14.403638
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    f = Field()
    code = 'test'
    assert f.validation_error(code)


# Generated at 2022-06-24 10:46:24.688463
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    _num_fields = 0
    _int_fields = 0
    _float_fields = 0
    _dub_fields = 0
    _dec_fields = 0

    # Define a field object
    class Integer(Field):
        _num_fields += 1
        _int_fields += 1

        def __init__(self, *args, **kwargs):
            # Implicitly call constructor of super class
            super().__init__(*args, **kwargs)

        def validate(self, obj, strict=False):
            return int(obj)

    # Define a field object
    class Float(Field):
        _num_fields += 1
        _float_fields += 1


# Generated at 2022-06-24 10:46:27.906758
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=['1', '2']).validate('1') == '1'
    assert Choice(choices=['1', '2']).validate('3') == '3'

# Generated at 2022-06-24 10:46:34.510773
# Unit test for method serialize of class String
def test_String_serialize():
    from typesystem.serialize import to_json
    from datetime import datetime
    s = String(format="datetime")
    assert to_json(s.serialize(datetime(2020, 1, 3, 10, 5, 56))) == "2020-01-03T10:05:56.000Z"
    try:
        s.serialize("some string")
        assert False, "Expected error"
    except ValidationError as err:
        assert err.code == "format"



# Generated at 2022-06-24 10:46:45.196845
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize('2019-01-19') == '2019-01-19'
    assert String(format="date").serialize('2019-01-19') == '2019-01-19'
    assert String(format="time").serialize('00:00:00') == '00:00:00'
    assert String(format="time").serialize('00:00:00') == '00:00:00'
    assert String(format="datetime").serialize('2019-01-19T00:00:00') == '2019-01-19T00:00:00'
    assert String(format="datetime").serialize('2019-01-19T00:00:00') == '2019-01-19T00:00:00'

# Generated at 2022-06-24 10:46:47.528794
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=[("a", "1"), ("b", "2"), ("c", "3")])


# Generated at 2022-06-24 10:46:48.896934
# Unit test for constructor of class Union
def test_Union():
    assert Union(any_of=[String()])

# Generated at 2022-06-24 10:46:52.870316
# Unit test for constructor of class Integer
def test_Integer():
    class test_Integer(Integer):
        def __init__(self, **kwargs):
             super().__init__(**kwargs)
    a = test_Integer()
    assert(a.numeric_type == int)



# Generated at 2022-06-24 10:46:55.190642
# Unit test for constructor of class Any
def test_Any():
    try:
        a = Any()
    except:
        assert False
    assert True


# Generated at 2022-06-24 10:47:00.797868
# Unit test for constructor of class Field
def test_Field():
    any_field = Field(title='any field', description='any field description', default=None, allow_null=False)
    assert any_field._creation_counter==0
    assert any_field.title=='any field'
    assert any_field.description=='any field description'
    assert any_field.default==None
    assert any_field.allow_null==False


# Generated at 2022-06-24 10:47:02.251011
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(None) is None



# Generated at 2022-06-24 10:47:04.418577
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=["foo", "bar"])
    assert field.choices == [("foo", "foo"), ("bar", "bar")]



# Generated at 2022-06-24 10:47:06.079751
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default()
    assert not Field(default=NO_DEFAULT).has_default()



# Generated at 2022-06-24 10:47:13.581474
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
    #Test case 1
    #Input: Field1 or Field2
    #Expected output: Union of Field1 and Field2
    """
    from typesystem.fields import String

    def assert_fields_equal(field1, field2):
        assert field1.__dict__ == field2.__dict__

    field1 = String(title="field1", description="field1")
    field2 = String(title="field2", description="field2")
    assert_fields_equal(field1, field1 | field2 | field1)
    assert_fields_equal(field2, field2 | field1 | field2)

    expected_union = Union([field1, field2, field1])
    assert_fields_equal(expected_union, field1 | field2 | field1)



# Generated at 2022-06-24 10:47:17.816327
# Unit test for method serialize of class Array
def test_Array_serialize():
    memo = {}
    assert Array('items', '*', 'memory', memo).serialize('items') == '*'
    assert memo == {'items': '*'}
    memo = {}
    assert Array(1, 2, 'memory', memo).serialize(1) == 2
    assert memo == {1: 2}
    memo = {}
    assert Array(3, 4, 'memory', memo).serialize([3]) == [4]
    assert memo == {3: 4}
    memo = {}
    assert Array([5], [6], 'memory', memo).serialize([5]) == [6]
    assert memo == {5: 6}



# Generated at 2022-06-24 10:47:28.624686
# Unit test for constructor of class String
def test_String():
    # test String with no parameters
    noparams_string = String()
    assert noparams_string.allow_null == False
    assert noparams_string.allow_blank == False
    assert noparams_string.trim_whitespace == True
    assert noparams_string.max_length == None
    assert noparams_string.min_length == None
    assert noparams_string.pattern_regex == None
    assert noparams_string.format == None

    # test String with default parameter
    default_string = String(default="default")
    assert default_string.has_default() == True
    assert default_string.get_default_value() == "default"
    assert default_string.allow_null == False
    assert default_string.allow_blank == False

# Generated at 2022-06-24 10:47:42.057466
# Unit test for method serialize of class Array
def test_Array_serialize():
    from json import loads as json_loads
    # Test with sequence of items
    test_obj = loads(
        """[1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597,
        2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418,
        317811, 514229, 832040, 1346269, 2178309, 3524578, 5702887, 9227465,
        14930352, 24157817, 39088169, 63245986, 102334155, 165580141,
        267914296, 433494437, 701408733]"""
    )

# Generated at 2022-06-24 10:47:50.176089
# Unit test for constructor of class Union
def test_Union():
    any_of = [Field(type="string")]
    u1 = Union(any_of=any_of, name="test")
    assert isinstance(u1, Field)
    assert u1.any_of == any_of
    assert not u1.allow_null
    assert u1.errors == {"null": "May not be null.", "union": "Did not match any valid type."}



# Generated at 2022-06-24 10:47:56.066942
# Unit test for method validate of class Field
def test_Field_validate():
    field_obj = Field("", "", "", True)
    assert hasattr(field_obj, "title")
    assert hasattr(field_obj, "description")
    assert hasattr(field_obj, "default")
    assert hasattr(field_obj, "allow_null")
    assert hasattr(field_obj, "errors")
    assert hasattr(field_obj, "_creation_counter")
    assert field_obj.title=="" and field_obj.description=="" and field_obj.default==""

# Generated at 2022-06-24 10:48:03.275666
# Unit test for constructor of class DateTime
def test_DateTime():
    # Test 1
    assert DateTime() == DateTime(format="datetime")
    # Test 2
    assert DateTime(format="datetime") == DateTime(format="datetime")
    # Test 3
    assert DateTime(format="datetime") != DateTime(format="date")
    # Test 4
    assert DateTime(format="datetime") != DateTime(format="time")
    # Test 5
    assert DateTime(format="datetime") != DateTime(format="text")

# Unit test, the function validate of DateTime

# Generated at 2022-06-24 10:48:05.210210
# Unit test for constructor of class Number
def test_Number():
    a=Number(minimum=3, maximum=5)
    return a.minimum == 3 and a.maximum == 5
print("test_Number: " + str(test_Number()))



# Generated at 2022-06-24 10:48:08.171955
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=["apple", "orange"])
    assert c.choices == [("apple", "apple"), ("orange", "orange")]


# Generated at 2022-06-24 10:48:10.751398
# Unit test for constructor of class Const
def test_Const():
    const = Const(1)
    try:
        const.validate(1)
        assert True
    except:
        assert False



# Generated at 2022-06-24 10:48:12.291403
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(minimum = 1, allow_null = False, description = "Integer")


# Generated at 2022-06-24 10:48:14.146805
# Unit test for constructor of class Decimal
def test_Decimal():
    dec = Decimal(minimum=0)
    assert dec.minimum == 0


# Generated at 2022-06-24 10:48:16.956466
# Unit test for constructor of class Const
def test_Const():
    const_field = Const(3)
    assert const_field.const == 3


# Generated at 2022-06-24 10:48:20.795461
# Unit test for method __or__ of class Field
def test_Field___or__():
    value_1 = Union([Integer(), Float()])
    value_2 = Union([Integer(), Float()])
    value_3 = value_1 | value_2
    assert isinstance(value_3, Union)
    assert len(value_3.any_of) == 4



# Generated at 2022-06-24 10:48:22.750367
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    Boolean(allow_null=True).validate(None, strict=True)
    Boolean().validate(None, strict=True)



# Generated at 2022-06-24 10:48:23.390415
# Unit test for method validate of class Array
def test_Array_validate():
    pass

# Generated at 2022-06-24 10:48:29.266943
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices= ["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    try:
        choice.validate("d")
    except ValidationError:
        pass
    else:
        raise AssertionError("Should have raised")
    
    
    



# Generated at 2022-06-24 10:48:33.746432
# Unit test for method validate of class Any
def test_Any_validate():
    f = Any()
    assert f.validate(None) == None
    assert f.validate(0) == 0
    assert f.validate(0.0) == 0.0
    assert f.validate(False) == False
    assert f.validate("") == ""
    assert f.validate([]) == []
    assert f.validate({}) == {}

