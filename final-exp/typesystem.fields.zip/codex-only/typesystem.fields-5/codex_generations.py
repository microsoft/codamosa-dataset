

# Generated at 2022-06-24 10:38:41.812283
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    Field.errors = {
        "unique": "{field} must be unique.",
        "max_length": "{field} cannot be more than {max_length} characters",
        "min_length": "{field} cannot be less than {min_length} characters",
    }
    field = Field(title="title", description="description", default="default")
    assert field.validate("abc") == "abc"
    # error
    assert (
        str(field.validate("abc", strict=True).error)
        == "AssertionError: strict check failed"
    )
    #  unique
    unique = Uniqueness(field.validation_error("unique"))
    assert str(unique.validate("abc")) == "abc must be unique."
    assert unique.validate("abc", strict=True) is None
    # max_length


# Generated at 2022-06-24 10:38:47.147754
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import uuid
    f=Field(title="", description="")
    assert f.validate_or_error("hello")==ValidationResult(value="hello", error=None)

    try:
        from typesystem.unique import Uniqueness
        from typesystem.fields import String, Schema
        from typesystem.exceptions import ValidationError
        class User(Schema):
            name = String()
            email = String(unique=Uniqueness(query_filter={"email__istartswith": "batman"}))
        user=User()
        assert user.validate_or_error({"name": "batman","email": "batman@dc.com"})==ValidationResult(value={"name": "batman","email": "batman@dc.com"}, error=None)
    except:
        pass

# Unit test

# Generated at 2022-06-24 10:38:50.926423
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field = Decimal()
    obj = "9.9"
    assert field.serialize(obj) == 9.9
    obj = None
    assert field.serialize(obj) == None
    return "test_Decimal_serialize_passed"



# Generated at 2022-06-24 10:38:52.429125
# Unit test for method serialize of class String
def test_String_serialize():
    string_field = String(default='test_string')
    assert string_field.serialize('test_string') == 'test_string'

# Generated at 2022-06-24 10:38:56.093609
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.has_default() == False
    assert field.validation_error("no_default") == ValidationError("no default", "no_default")


# Generated at 2022-06-24 10:39:00.243927
# Unit test for constructor of class Number
def test_Number():
    obj = Number()
    assert obj.minimum == None
    assert obj.maximum == None
    assert obj.exclusive_minimum == None
    assert obj.exclusive_maximum == None
    assert obj.multiple_of == None
    assert obj.precision == None


# Generated at 2022-06-24 10:39:09.088272
# Unit test for constructor of class Float
def test_Float():
    import pytest

    # Valid arguments
    assert Float(title="Test", description="Test", default=10.0)

    # Invalid arguments
    with pytest.raises(AssertionError):
        Float(title="Test", description="Test", default=10.0, minimum=3)

    with pytest.raises(AssertionError):
        Float(title="Test", description="Test", default=10.0, maximum=4)

    with pytest.raises(AssertionError):
        Float(title="Test", description="Test", default=10.0, exclusive_minimum=1)

    with pytest.raises(AssertionError):
        Float(title="Test", description="Test", default=10.0, exclusive_maximum=12)


# Generated at 2022-06-24 10:39:13.022870
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean = Boolean(title="Boolean", description="Boolean")
    assert boolean.validate("true") == True
    assert boolean.validate("1") == True
    assert boolean.validate("off") == False
    assert boolean.validate("2") == None
    assert boolean.validate("false") == False
    assert boolean.validate("") == None
    assert boolean.validate("0") == False
    assert boolean.validate("on") == True
    assert boolean.validate("123") == None
    assert boolean.validate("none") == None
    assert boolean.validate("null") == None



# Generated at 2022-06-24 10:39:21.334462
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class FieldStub(Field):
        def validate(self, value: typing.Any, *, strict: bool = False):
            if not isinstance(value, int):
                raise ValidationError("Expected integer")
            return value
    field = FieldStub()
    assert field.validate_or_error(1) == ValidationResult(value=1, error=None)
    assert field.validate_or_error("a") == ValidationResult(value=None, error=ValidationError(text='Expected integer', code=None))
# Define class DatetimeField that inherit from Field, and use it in function test_check_datetime_with_good_value

# Generated at 2022-06-24 10:39:30.108365
# Unit test for method __or__ of class Field
def test_Field___or__():
    from pytest import raises
    from typesystem.fields import Field, Union,String, Number

    def test_equals():
        # arrange
        test_field = Field(title='', description='', default=None, allow_null=False)
        expected = Union(any_of=[test_field])
        # act
        actual = test_field | 5
        # assert
        assert expected == actual


    def test_title_is_not_empty_string():
        # arrange
        expected = "error"
        # act
        actual = Field(title='', description='', default=None, allow_null=False) | 5
        # assert
        assert expected == actual.title


    def test_title_is_not_empty_string_desc_is_passed():
        # arrange
        expected = "error"
        # act

# Generated at 2022-06-24 10:39:41.351396
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field()
    assert not f.has_default()
    f = Field(title='')
    assert not f.has_default()
    f = Field(description='')
    assert not f.has_default()
    f = Field(title='', description='')
    assert not f.has_default()
    f = Field(title='', description='', allow_null=False)
    assert not f.has_default()
    f = Field(title='', description='', default=NO_DEFAULT)
    assert f.has_default()
    f = Field(title='', description='', default='a')
    assert f.has_default()
    f = Field(title='', description='', allow_null=True)
    assert f.has_default()

# Generated at 2022-06-24 10:39:44.469550
# Unit test for constructor of class Any
def test_Any():
    A = Any()
    assert A.required == False
    assert A.default == None


# Generated at 2022-06-24 10:39:51.529517
# Unit test for constructor of class Integer
def test_Integer():
    # Init a Integer Object
    integer_obj = Integer(minimum=5, maximum=15, exclusive_minimum=10, exclusive_maximum=20, multiple_of=2)
    # Test the Constructor is OK
    assert integer_obj.minimum == 5
    assert integer_obj.maximum == 15
    assert integer_obj.exclusive_minimum == 10
    assert integer_obj.exclusive_maximum == 20
    assert integer_obj.multiple_of == 2



# Generated at 2022-06-24 10:39:56.093573
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=["1","2","3"])
    for choice_val in ["1", "2", "3"]:
        assert choice.validate(choice_val) == choice_val, "FAILED test_Choice"
    for choice_val in ["4", ""]:
        assert choice.validate(choice_val) == "4", "FAILED test_Choice"
    
    

# Generated at 2022-06-24 10:40:00.201726
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() is None
    assert Field(default=1).get_default_value() == 1
    assert Field(default=lambda: 2).get_default_value() == 2


# Generated at 2022-06-24 10:40:06.352299
# Unit test for constructor of class Field
def test_Field():
    assert Field._creation_counter == 0
    assert Field.errors == {}
    field = Field()
    field2 = Field()
    assert Field._creation_counter == 2
    assert field.__dict__ == {
        "title": "", 
        "description": "", 
        "allow_null": False, 
        "_creation_counter": 1}
    assert field2.__dict__ == {
        "title": "", 
        "description": "", 
        "allow_null": False, 
        "_creation_counter": 2}



# Generated at 2022-06-24 10:40:08.358723
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "a"), ("b", "b")])
    assert c.choices == [("a", "a"), ("b", "b")]

    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]



# Generated at 2022-06-24 10:40:10.161372
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    # Test case 1:
    assert 1==1



# Generated at 2022-06-24 10:40:11.988826
# Unit test for method validate of class String
def test_String_validate():
    instance = String()
    value = "a string"
    assert instance.validate(value) == value

# Generated at 2022-06-24 10:40:13.219455
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    field.validate(None)

# Generated at 2022-06-24 10:40:14.675570
# Unit test for method validate of class Const
def test_Const_validate():
    try:
        a = Const(const = 1)
        a.validate(0)
    except ValidationError:
        return True
    return False
test_Const_validate()


# Generated at 2022-06-24 10:40:15.941456
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text) == True


# Generated at 2022-06-24 10:40:18.098191
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_number = decimal.Decimal('12.32')
    decimal_number_result = Decimal().serialize(decimal_number)
    assert decimal_number_result == 12.32



# Generated at 2022-06-24 10:40:28.714251
# Unit test for constructor of class String
def test_String():
    # test 1 - allow blank
    s1 = String(allow_blank=True)
    assert s1.allow_blank == True
    assert s1.trim_whitespace == True
    assert s1.max_length == None
    assert s1.min_length == None
    assert s1.pattern == None
    assert s1.format == None
    assert s1.validate("") == ""

    # test 2 - max_length
    s2 = String(max_length=5)
    assert s2.allow_blank == False
    assert s2.trim_whitespace == True
    assert s2.max_length == 5
    assert s2.min_length == None
    assert s2.pattern == None
    assert s2.format == None

# Generated at 2022-06-24 10:40:32.727036
# Unit test for method serialize of class Field
def test_Field_serialize():
    name = Field()
    assert name.serialize('apple') == 'apple'


# Generated at 2022-06-24 10:40:40.507744
# Unit test for method validate of class Field
def test_Field_validate():
    from typesystem.base import Message, ValidationError
    from typesystem.fields import Field

    class TestField(Field):
        def __init__(self):
            super().__init__(title='', description='')

        def validate(self, value, strict=False):
            if strict:
                return value
            else:
                return 1

    try:
        t = TestField()
        t.validate(0, strict=True)
        assert False
    except ValidationError:
        pass

    assert t.validate(0, strict=False) == 1


# Generated at 2022-06-24 10:40:44.932771
# Unit test for constructor of class Const
def test_Const():
    assert Const.__init__(const=1)
    assert Const.__init__(const=0)
    assert Const.__init__(const=-1)
    assert Const.__init__(const=-0)
    assert Const.__init__(const=3.14)
    assert Const.__init__(const=-3.14)
    assert Const.__init__(const=True)
    assert Const.__init__(const=False)
    assert Const.__init__(const=None)
    assert Const.__init__(const=())
    assert Const.__init__(const=["hi"])
    assert Const.__init__(const=['hi'])
    assert Const.__init__(const={'hi'})
    assert Const.__init__(const={'hi': 'mom'})

# Generated at 2022-06-24 10:40:52.574667
# Unit test for method validate of class Field
def test_Field_validate():
    class MyField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if not isinstance(value, (int, float)):
                raise self.validation_error("type_error")

            if not isfinite(value):
                raise self.validation_error("infinite_value")

            if value > 1 or value < -1:
                raise self.validation_error("out_of_range")

    field = MyField()

    assert field.validate(0) == 0
    assert field.validate(0.0) == 0.0
    assert field.validate(-1) == -1
    assert field.validate(-1.0) == -1.0
    assert field.validate(1) == 1
    assert field.validate

# Generated at 2022-06-24 10:40:57.246691
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    try:
        field = Field()
        result = field.validate_or_error(value = 2, strict = True)
    except:
        return False
    return True

# Generated at 2022-06-24 10:40:59.540000
# Unit test for constructor of class Const
def test_Const():
    field = Const(1, title="const")
    assert field.const == 1
    field = Const(1, title="const", allow_null=True)
    assert field.const == 1
    with pytest.raises(AssertionError):
        field = Const(1, title="const", allow_null=False)


# Generated at 2022-06-24 10:41:03.558309
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code = 'code'
    expected = 'error'
    field.errors = {code, expected}
    result = field.validation_error(code)
    assert result.text == expected
    assert result.code == code



# Generated at 2022-06-24 10:41:06.026493
# Unit test for method serialize of class String
def test_String_serialize():
    value = String(format='date', allow_blank=True).serialize('2020/05/15')
    assert value == '2020-05-15'

# Generated at 2022-06-24 10:41:09.627179
# Unit test for constructor of class Number
def test_Number():
    number = Number()
    assert number.multiple_of is None
    assert number.precision is None
    assert number.maximum is None
    assert number.minimum is None
    assert number.exclusive_maximum is None
    assert number.exclusive_minimum is None
    assert number.numeric_type is None


# Generated at 2022-06-24 10:41:11.602154
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal().numeric_type, decimal.Decimal



# Generated at 2022-06-24 10:41:12.327027
# Unit test for constructor of class Time
def test_Time():
    t1 = Time()

# Generated at 2022-06-24 10:41:16.209023
# Unit test for method validate of class String
def test_String_validate():
    test_data_String = {
        "title": "title",
        "description": "description",
        "allow_blank": True,
        "trim_whitespace": True,
        "max_length": 10,
        "min_length": 1,
        "pattern": "^[0-9]\w*$",
        "format": "uuid",
    }
    obj = String(**test_data_String)
    value = "1"
    obj.validate(value)  # pass

# Generated at 2022-06-24 10:41:17.914346
# Unit test for method validate of class Field
def test_Field_validate():
    assert isinstance(Field.validate(''), NotImplementedError)

# Generated at 2022-06-24 10:41:26.277826
# Unit test for constructor of class Array
def test_Array():
    field1 = Field(name="field1")
    field2 = Field(name="field2")
    field3 = Field(name="field3")

    # Line #182
    array1 = Array(items=[field1, field2])
    assert array1.items == [field1, field2]
    array2 = Array(items=field3)
    assert array2.items == field3

    # Line #186
    # array3 = Array(items=[field1, field2], name="array1")
    # assert array3.items == [field1, field2]
    # assert array3.name == "array1"


# Generated at 2022-06-24 10:41:30.902324
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(multiple_of=2).validate(2) == 2
    assert Number(multiple_of=2).validate(4) == 4
    assert Number(multiple_of=2).validate(6) == 6
    assert Number(maximum=5).validate(5) == 5
    assert Number(maximum=5).validate(3) == 3
    assert Number(maximum=5).validate(1) == 1
    assert Number(minimum=5).validate(5) == 5
    assert Number(minimum=5).validate(7) == 7
    assert Number(minimum=5).validate(9) == 9
    assert Number(allow_blank=True, allow_null=True).validate(None) is None
    assert Number(allow_blank=True, allow_null=True).validate("") is None

# Generated at 2022-06-24 10:41:34.803932
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number(allow_null=True, maximum=5, minimum=3, multiple_of=10, precision="0.1")
    b = a.validate(1)
    assert b == None

# Generated at 2022-06-24 10:41:38.937136
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    test = Field()
    assert test.validate_or_error("test") == ValidationResult(None, None)
    assert test.validate_or_error("test", strict=True) == ValidationResult(None, None)


# Generated at 2022-06-24 10:41:40.515711
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(
        items=Field(type="string"),
    )
    assert field.serialize(["foo", "bar"]) == ["foo", "bar"]



# Generated at 2022-06-24 10:41:48.374071
# Unit test for constructor of class Array
def test_Array():
    array1 = Array()
    assert array1.errors == {
        "type": "Must be an array.",
        "null": "May not be null.",
        "empty": "Must not be empty.",
        "exact_items": "Must have {min_items} items.",
        "min_items": "Must have at least {min_items} items.",
        "max_items": "Must have no more than {max_items} items.",
        "additional_items": "May not contain additional items.",
        "unique_items": "Items must be unique.",
    }
    assert array1.items is None
    assert array1.additional_items is False
    assert array1.min_items is None
    assert array1.max_items is None
    assert array1.unique_items is False

# Generated at 2022-06-24 10:41:59.560731
# Unit test for method validate of class Object
def test_Object_validate():
    a = {
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "string"},
            "baz": {"type": "string"},
            "biz": {"type": "string"},
            "qux": {"type": "string"},
        },
        "additionalProperties": False,
    }
    b = {
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "string"},
            "baz": {"type": "string"},
            "biz": {"type": "string"},
            "qux": {"type": "string"},
        },
        "additionalProperties": True,
    }
    schema_a = Schema(a)
    schema_b

# Generated at 2022-06-24 10:42:06.148228
# Unit test for constructor of class Union
def test_Union():
  u1=Union([String(), Int()])
  assert u1.allow_null==False
  assert u1.any_of==[String(), Int()]
  assert u1.errors=={'null': 'May not be null.', 'union': 'Did not match any valid type.'}
  assert u1.max_length==None
  assert u1.min_length==None
  assert u1.pattern==None
  assert u1.str_format==None
  assert u1.value_type==None
  u2=Union([String(max_length=5), Int(min_value=5)])
  assert u2.allow_null==False
  assert u2.any_of==[String(max_length=5), Int(min_value=5)]

# Generated at 2022-06-24 10:42:13.393767
# Unit test for constructor of class Number
def test_Number():
    obj = Number()
    assert obj.minimum == None
    assert obj.maximum == None
    assert obj.exclusive_minimum == None
    assert obj.exclusive_maximum == None
    assert obj.multiple_of == None
    assert obj.precision == None
    assert obj._creation_counter == 0
    assert obj.default == None
    assert obj.allow_null == False
    assert obj.allow_blank == False
    assert obj.trim_whitespace == True
    assert obj.max_length == None
    assert obj.min_length == None
    assert obj.pattern == None
    assert obj.pattern_regex == None
    assert obj.format == None
    assert obj._creation_counter == 1



# Generated at 2022-06-24 10:42:14.833670
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() == False


# Generated at 2022-06-24 10:42:18.369203
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const("a")
    value, error = field.validate_or_error("a")
    assert value == "a"
    assert error is None
    with pytest.raises(ValidationError) as exc:
        field.validate("b")
    assert exc.value.code == "const"
    assert exc.value.message == "Must be the value 'a'."

# Generated at 2022-06-24 10:42:19.282434
# Unit test for constructor of class Const
def test_Const():
    something = 4
    assert Const(something).const == 4


# Generated at 2022-06-24 10:42:24.795117
# Unit test for constructor of class Number
def test_Number():
    a = Number(title="Number", description="Number", default = 0.0)
    assert a.minimum == None
    assert a.maximum == None
    assert a.exclusive_minimum == None
    assert a.exclusive_maximum == None
    assert a.multiple_of == None
    assert a.precision == None

# Unit tests for method validate of class Number

# Generated at 2022-06-24 10:42:26.269658
# Unit test for constructor of class Float
def test_Float():
    assert issubclass(Float, Number)
    assert Float.numeric_type == float


# Generated at 2022-06-24 10:42:29.623116
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="title", description="description", default="default", allow_null=False)
    assert field.title == "title"
    assert field.description == "description"
    assert field.default == "default"
    assert field.allow_null == False
    return field



# Generated at 2022-06-24 10:42:32.252404
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    a.validate(0)
    a.validate(1)
    a.validate(None)
    a.validate(object)
    a.validate(Any)
    



# Generated at 2022-06-24 10:42:40.023482
# Unit test for method validate of class Array
def test_Array_validate():
    items = [
        Integer(minimum=100, maximum=110),
        Integer(minimum=100, maximum=110),
    ]
    array = Array(items=items)

    value = [100, 101, 102]
    assert array.validate(value) == value
    
    value = [100, 101, 102, 103]
    try :
        array.validate(value)
        assert False
    except ValidationError as e:
        assert str(e) == "Must have 3 items."

# Generated at 2022-06-24 10:42:50.418075
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={
        "name": String(),
        "age": Integer()
    })
    value = schema.validate({"name": "Bob", "age": 42})
    
    try:
        value = schema.validate({"name": "Bob", "age": 42.5})
    except Exception as e:
        e.args[0].code
    assert e.args[0].code == 'integer'

    try:
        value = schema.validate({"name": "Bob", "age": 4.2})
    except Exception as e:
        e.args[0].code
    assert e.args[0].code == 'integer'
    
    
test_Object_validate()

# Generated at 2022-06-24 10:42:57.030041
# Unit test for constructor of class Union
def test_Union():
    """
    the test is for constructor of class Union
    input : Union(candidate_errors = [error1, error2, error3])
    expected:
    output: Union([error1, error2, error3])
    """
    error1 = None
    error2 = None
    error3 = None
    expected_output = Union([error1, error2, error3])
    error_messages = []
    output = Union(error_messages)
    assert output == expected_output

# Generated at 2022-06-24 10:42:59.180962
# Unit test for constructor of class Const
def test_Const():
    assert Const(3).const == 3
    assert Const(None).const == None
    assert Const(3).validate(3) == 3
    assert Const(1).validate(1) == 1


# Generated at 2022-06-24 10:43:01.781028
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(minimum=0.0, maximum=1.1, exclusive_minimum=0.0, exclusive_maximum=1.1, precision='0.1') is not None


# Generated at 2022-06-24 10:43:13.099894
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={"x": Field()})
    try:
        schema.validate({"x": 1, "y": 1})
    except ValidationError as error:
        assert error.messages() == [Message("Invalid property name.", index=["y"])]
    else:
        assert True == False
    schema = Object(properties={"x": Field()}, additional_properties=False)
    try:
        schema.validate({"x": 1, "y": 1})
    except ValidationError as error:
        assert error.messages() == [Message("Invalid property name.", index=["y"])]
    else:
        assert True == False
    schema = Object(properties={"x": Field()}, additional_properties=Field())

# Generated at 2022-06-24 10:43:14.453460
# Unit test for constructor of class Decimal
def test_Decimal():
    assert isinstance(Decimal().validate(1.1), decimal.Decimal) == True



# Generated at 2022-06-24 10:43:15.643452
# Unit test for constructor of class Date
def test_Date():
    a = Date()
    assert a.format == "date"



# Generated at 2022-06-24 10:43:21.551555
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Positive test
    Choice_obj = Choice(choices=["choice1", "choice2"])
    assert Choice_obj.validate("choice1") == "choice1"
    # Negative test
    with pytest.raises(ValidationError):
        Choice_obj.validate("choice3")
    with pytest.raises(KeyError):
        Choice_obj.validate([])
    # Negative test - error "type"
    with pytest.raises(ValidationError):
        Choice_obj.validate(1)
    # Negative test - error "required"
    with pytest.raises(ValidationError):
        Choice_obj.validate("")



# Generated at 2022-06-24 10:43:27.786260
# Unit test for method validate of class Union
def test_Union_validate():
    schema = Union([String(), Integer()], default="OK")
    validated, error = schema.validate_or_error("OK")
    assert validated == "OK"
    assert error is None

    validated, error = schema.validate_or_error("KO")
    assert validated == "OK"
    assert error.messages()[0].code == "type"

    validated, error = schema.validate_or_error("KO", strict=True)
    assert validated == "KO"
    assert error.messages()[0].code == "type"

    validated, error = schema.validate_or_error(42)
    assert validated == 42
    assert error is None

    validated, error = schema.validate_or_error(42, strict=True)
    assert validated == 42
    assert error is None


# Generated at 2022-06-24 10:43:29.531393
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime()
    assert dt.format == "datetime"


# Generated at 2022-06-24 10:43:38.756674
# Unit test for method validate of class Union
def test_Union_validate():
    class ID(Field):
        errors = {}
        def validate(self, value, **kwargs):
            return value
    class Name(Field):
        errors = {}
        def validate(self, value, **kwargs):
            return value
    class Email(Field):
        errors = {}
        def validate(self, value, **kwargs):
            return value

    u = Union(any_of=[ID(), Name(), Email()])
    assert u.validate(None) == None
    assert u.validate("1") == "1"
    assert u.validate("a") == "a"
    assert u.validate("a@a.com") == "a@a.com"
    try:
        u.validate(False)
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-24 10:43:44.920203
# Unit test for constructor of class Object
def test_Object():
    def test(properties, pattern_properties, additional_properties, property_names, min_properties, max_properties, required):
        try:
            obj = Object(
                properties=properties,
                pattern_properties=pattern_properties,
                additional_properties=additional_properties,
                property_names=property_names,
                min_properties=min_properties,
                max_properties=max_properties,
                required=required
            )
            print("Test Passed:")
            print(obj)
        except AssertionError:
            print("Test Failed:")
            print("properties: ", properties)
            print("pattern_properties: ", pattern_properties)
            print("additional_properties: ", additional_properties)
            print("property_names: ", property_names)
            print("min_properties: ", min_properties)

# Generated at 2022-06-24 10:43:49.069122
# Unit test for constructor of class Field
def test_Field():
    Field()
    try:
        Field(description=234)
        assert False
    except:
        assert True
    try:
        Field(title=123)
        assert False
    except:
        assert True
    try:
        Field(default=True)
        assert False
    except:
        assert True

test_Field()


# Generated at 2022-06-24 10:43:59.220585
# Unit test for constructor of class String
def test_String():
    f1 = String(allow_null=True)
    f2 = String(allow_blank=True)
    f3 = String(allow_null=True, allow_blank=True)
    f4 = String(allow_null=True, allow_blank=True, trim_whitespace=True)
    f5 = String(max_length=10)
    f6 = String(max_length=10, min_length=2)
    f7 = String(allow_null=True, allow_blank=True, pattern=r"^\d+$")
    f8 = String(format="uuid")
    f9 = String(format="date")
    f10 = String(format="time")
    f11 = String(format="datetime")
    assert f1.trim_whitespace == True
    assert f2.tr

# Generated at 2022-06-24 10:44:07.231987
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.field import Field, ValidationResult
    from typesystem.base import ValidationError

    class TestField(Field):
        errors = {"invalid": "invalid"}

        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    field = TestField()
    validation_result = field.validate_or_error("invalid")
    assert isinstance(validation_result, ValidationResult)
    assert validation_result.value == "invalid"
    assert validation_result.error is None

    validation_result = field.validate_or_error("invalid1")
    assert isinstance(validation_result, ValidationResult)
    assert validation_result.value is None
    assert isinstance(validation_result.error, ValidationError)

   

# Generated at 2022-06-24 10:44:09.282924
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    obj = Field()
    code = "test"
    res = obj.validation_error(code)
    assert ValidationError(None, code) == res

# Generated at 2022-06-24 10:44:17.750386
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(11) is 11
    assert Number().validate("11") is 11
    with pytest.raises(ValidationError) as excinfo:
        Number().validate(11.34)
    assert excinfo.value.code == "type"
    assert excinfo.value.text == "Must be a number."
    with pytest.raises(ValidationError) as excinfo:
        Number().validate("11.34")
    assert excinfo.value.code == "type"
    assert excinfo.value.text == "Must be a number."



# Generated at 2022-06-24 10:44:24.819675
# Unit test for constructor of class Object
def test_Object():
    properties = {"foo": String()}
    pattern_properties = {"^f.*": String()}
    additional_properties = String()
    property_names = String()
    min_properties = 1
    max_properties = 2
    required = ["foo"]
    obj = Object(
        properties = properties,
        pattern_properties = pattern_properties,
        additional_properties = additional_properties,
        property_names = property_names,
        min_properties = min_properties,
        max_properties = max_properties,
        required = required,
    )


# Generated at 2022-06-24 10:44:30.932713
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.format == "text"
    assert text.required == True
    assert text.default == None
    assert text.allow_null == True
    assert text.description == ""
    assert text.title == ""
    assert text.name == None
    assert text.example == None
    assert isinstance(text, Text)
    assert isinstance(text, Field)


# Generated at 2022-06-24 10:44:31.832996
# Unit test for constructor of class Date
def test_Date():
    assert Date(format='date')



# Generated at 2022-06-24 10:44:37.278240
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice.validate(Choice,None) == ValueError


    assert Choice.validate(Choice,'test') == ValidationError

test_Choice_validate()


# Generated at 2022-06-24 10:44:45.216567
# Unit test for constructor of class Array
def test_Array():
    # Test case 1
    field_1 = Array()
    assert field_1.items == None
    assert field_1.additional_items == False
    assert field_1.min_items == None
    assert field_1.max_items == None
    assert field_1.unique_items == False

    # Test case 2
    field_2 = Array(items = [Str()], additional_items = False, min_items = 2, max_items = 4, unique_items = True)
    assert type(field_2.items) == list
    assert field_2.additional_items == False
    assert field_2.min_items == 2
    assert field_2.max_items == 4
    assert field_2.unique_items == True

    # Test case 3

# Generated at 2022-06-24 10:44:46.951834
# Unit test for constructor of class Date
def test_Date():
    field = Date()
    print(field)
    print(field.__dict__)


# Generated at 2022-06-24 10:44:48.351448
# Unit test for constructor of class Any
def test_Any():
    any_class = Any()
    assert isinstance(any_class, Any)



# Generated at 2022-06-24 10:44:49.619669
# Unit test for method validate of class Any
def test_Any_validate():
    cls = Any
    meth = cls.validate
    # No tests
add_test(test_Any_validate,
    [
    ]
)



# Generated at 2022-06-24 10:44:51.153870
# Unit test for method validate of class Const
def test_Const_validate():
    tester = Const(5)
    assert tester.validate(5) == 5
    try:
        tester.validate(6)
        assert False
    except:
        assert True

# Generated at 2022-06-24 10:44:53.097010
# Unit test for method validate of class Any
def test_Any_validate():
    """
    Test validate method of class Any
    """
    schema = Any()
    assert schema.validate(None) == None
    assert schema.validate(1) == 1
    assert schema.validate(True) == True
    assert schema.validate('') == ''



# Generated at 2022-06-24 10:45:01.084787
# Unit test for constructor of class Object
def test_Object():
    class AnimalSchema(Schema):
        name = String()
        type = String()

    class DogSchema(AnimalSchema):
        name = String(required=True)
        type = String(required=True)
        color = String()

    class CatSchema(AnimalSchema):
        name = String(required=True)
        type = String(required=True)
        weight = String()

    class AnimalHouseSchema(Schema):
        owner = String(required=True)
        dogs = Array(DogSchema)
        cats = Array(CatSchema)

    assert 'owner' in AnimalHouseSchema.properties
    assert 'dogs' in AnimalHouseSchema.properties
    assert 'cats' in AnimalHouseSchema.properties
    assert len(AnimalHouseSchema.properties) == 3

# Generated at 2022-06-24 10:45:02.725059
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field();
    field.validate(123)


# Generated at 2022-06-24 10:45:05.146180
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field().validate_or_error(value=1, strict=False) is None



# Generated at 2022-06-24 10:45:08.780836
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a_decimal = Decimal(allow_null=True)
    obj = -2.4
    expected_value = obj
    received_value = a_decimal.serialize(obj)
    assert received_value == expected_value


# Generated at 2022-06-24 10:45:18.010395
# Unit test for constructor of class Array
def test_Array():
    assert_that(Array().items, None)
    assert_that(Array().additional_items, False)
    assert_that(Array().min_items, None)
    assert_that(Array().max_items, None)
    assert_that(Array().unique_items, False)

    assert_that(Array(items=[Integer(minimum=1), Integer(maximum=50)]).items, [Integer(minimum=1), Integer(maximum=50)])
    assert_that(Array(items=[Integer(minimum=1), Integer(maximum=50)]).additional_items, False)
    assert_that(Array(items=[Integer(minimum=1), Integer(maximum=50)]).min_items, 2)
    assert_that(Array(items=[Integer(minimum=1), Integer(maximum=50)]).max_items, 2)
    assert_

# Generated at 2022-06-24 10:45:21.069733
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    f=Field()
    assert f.validation_error("test").code=="test" and f.validation_error("test").text==None


# Generated at 2022-06-24 10:45:27.593888
# Unit test for constructor of class Const
def test_Const():
    schema = Const(const=42)
    assert schema.const == 42
    assert schema.validate(value=42) == 42
    with pytest.raises(ValidationError):
        schema.validate(value=43)


# Generated at 2022-06-24 10:45:38.319384
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(
        items=String(),
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
    )
    value = ['sachin','rahul','dhoni','raina','kohli']
    assert field.serialize(value) == ['sachin','rahul','dhoni','raina','kohli']
    field1 = Array(
        items=Integer(),
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
    )
    value1 = [1,2,3,4,5,6]
    assert field.serialize(value1) == [1,2,3,4,5,6]



# Generated at 2022-06-24 10:45:39.914720
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(1) == 1.0
    assert d.serialize(None) == None
    
    

# Generated at 2022-06-24 10:45:43.772677
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    from typesystem.base import Schema
    from unittest import mock

    obj = Decimal()
    schema_obj = mock.Mock(spec = Schema)

    assert(obj.serialize(1) == 1)
    assert(obj.serialize(None) == None)


# Generated at 2022-06-24 10:45:45.563753
# Unit test for constructor of class Decimal
def test_Decimal():
    field = Decimal()
    assert(field != None)


# Generated at 2022-06-24 10:45:51.992734
# Unit test for method serialize of class Array
def test_Array_serialize():
    def test(items, obj, expected):
        _field = Array(items=items)
        obj = _field.validate(obj)
        obj = _field.serialize(obj)
        assert obj == expected

    test(
        None, [], []
    )
    test(
        [Number(), String()],
        [1, "foo"],
        [1, "foo"],
    )
    test(
        [Number(), String()],
        ["foo", 1],
        [1, "foo"],
    )
    test(
        None,
        dict(a="foo", b=["foo", 1]),
        dict(a="foo", b=[1, "foo"]),
    )



# Generated at 2022-06-24 10:45:55.477667
# Unit test for method serialize of class Array
def test_Array_serialize():
    setdefault_test_field_factory(default_test_field_factory)
    obj = [1, 2, 3]
    field = Array(items=Integer())
    expected = [1, 2, 3]
    assert field.serialize(obj) == expected



# Generated at 2022-06-24 10:46:01.683066
# Unit test for method validate of class String
def test_String_validate():
    print("Start test_String_validate")
    f = String(title="name", description="surname")
    assert f.validate("abc")=="abc"
    assert f.validate("")==""
    assert f.validate(None)==None
    assert f.validate(1)==ValidationError(text="Must be a string.", code='type')
    assert f.validate(True)==ValidationError(text="Must be a string.", code='type')
    assert f.validate(False)==ValidationError(text="Must be a string.", code='type')
    print("Success test_String_validate")

# test_String_validate()



# Generated at 2022-06-24 10:46:04.718452
# Unit test for constructor of class Number
def test_Number():
    assert Number(allow_null=True) is not None
    assert Number(title="Age") is not None
    assert Number(description="The age of the person") is not None
    assert Number(allow_null=False) is not None
    assert Number(minimum=0) is not None
    assert Number(maximum=100) is not None


# Generated at 2022-06-24 10:46:16.243271
# Unit test for method validate of class Object

# Generated at 2022-06-24 10:46:17.278824
# Unit test for constructor of class Any
def test_Any():
    assert Any()


# Generated at 2022-06-24 10:46:24.410624
# Unit test for constructor of class Choice
def test_Choice():
    f = Choice(choices=[(1, 1), (1, 2), (3, 3), (3, 4)])
    try:
        f = Choice(choices=[(1, 1), 2, 3, 4])
        assert False
    except Exception as error:
        assert True


# Generated at 2022-06-24 10:46:28.229056
# Unit test for method validate of class String
def test_String_validate():
    string1 = String()
    assert string1.validate("This is a test") == "This is a test"
    try:
        string1.validate(0)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-24 10:46:29.325569
# Unit test for method validation_error of class Field
def test_Field_validation_error():
        field=Field()
        assert field.validation_error('code').code == 'code'

# Generated at 2022-06-24 10:46:37.598472
# Unit test for constructor of class Boolean
def test_Boolean():
    # testing for Boolean constructor
    bool_true = Boolean()
    bool_true.validate(value=True) # no error
    bool_true.validate(value=None) # error
    bool_true.validate(value=False) # no error
    bool_true.validate(value = False, strict = True) # no error
    bool_true.validate(value = 1, strict = True) # error
    bool_true.validate(value = 1) # no error
    bool_true.validate(value = "True") # no error
    bool_true.validate(value = "true") # no error
    bool_true.validate(value = "1") # no error
    bool_true.validate(value = "on") # no error
    bool_true.validate(value = "ON") #

# Generated at 2022-06-24 10:46:39.207242
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean(allow_null=False).validate('') == False



# Generated at 2022-06-24 10:46:42.054213
# Unit test for constructor of class Date
def test_Date():
    a = Date()
    assert a.format == "date"



# Generated at 2022-06-24 10:46:48.548242
# Unit test for method validate of class Const
def test_Const_validate():
    my_const = Const(const = 3)
    assert my_const.validate(3) == 3
    try:
        my_const.validate(4)
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:46:58.176854
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union(any_of=[String(), Integer()]).validate(None) == None, 'expected None'
    assert Union(any_of=[String(), Integer()]).validate(1) == 1, 'expected 1'
    assert Union(any_of=[String(), Integer()]).validate('1') == '1', 'expected 1'
    assert Union(any_of=[String(), Integer()]).validate('test') == 'test', 'expected test'
    assert Union(any_of=[String(), Integer()]).validate(['test']) == ['test'], 'expected [test]'
    assert Union(any_of=[String(), Integer()]).validate([1]) == [1], 'expected [1]'
    assert Union(any_of=[String(), Integer()]).validate([1.1]) == [1.1], 'expected [1.1]'


# Generated at 2022-06-24 10:47:08.023336
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    result = Boolean().validate("True")
    assert result == True  # assert that boolean is True
    result = Boolean().validate("False")
    assert result == False  # assert that boolean is False
    result = Boolean().validate("1")
    assert result == True  # assert that boolean is True
    result = Boolean().validate("0")
    assert result == False  # assert that boolean is False
    result = Boolean().validate("null")
    assert result == None  # assert that boolean is None
    result = Boolean().validate("")
    assert result == False  # assert that boolean is False
    result = Boolean().validate(None)
    assert result == None  # assert that boolean is None
    result = Boolean().validate(0)
    assert result == False  # assert that boolean is False

# Generated at 2022-06-24 10:47:16.753886
# Unit test for constructor of class Array
def test_Array():
    array = Array()
    assert array.min_items == 0
    assert isinstance(array.allow_null, bool)
    array2 = Array(min_items=1, allow_null=True, default=[1, 2, 3])
    assert array2.min_items == 1
    assert array2.allow_null == True
    assert array2.default == [1, 2, 3]
    array3 = Array(additional_items=True)
    assert array3.additional_items == True
    array4 = Array(additional_items=False)
    assert array4.additional_items == False


# Generated at 2022-06-24 10:47:28.180216
# Unit test for constructor of class String
def test_String():
    try:
        a = String()
    except:
        print("Failed")
    a = String(title="abc", description="abc")
    a.validate("a")
    a.validate("a", strict=False)
    a.serialize("a")
    try:
        a.validate(None)
    except:
        print("Failed")
    try:
        a.validate(1)
    except:
        print("Failed")
    try:
        a = String(allow_blank=True)
        a.validate(None, strict=False)
    except:
        print("Failed")
    try:
        a = String(allow_blank=False)
        a.validate(None, strict=False)
    except:
        print("Failed")

# Generated at 2022-06-24 10:47:42.023412
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    a = Field()
    assert a.allow_null == False
    assert a.title == ''
    assert a.description == ''
    assert hasattr(a, 'default') == False
    result = a.validate_or_error(123)
    assert result.error == None
    assert result.value == None
    assert result.__dict__ == {'error': None, 'value': None}
    assert result.__class__.__name__ == 'ValidationResult'
    pytest.raises(NotImplementedError, a.validate, 123)
    pytest.raises(NotImplementedError, a.serialize, 123)
    a = Field(title='title', description='description', default=NO_DEFAULT, allow_null=True)
    assert a.allow_null == True

# Generated at 2022-06-24 10:47:46.909750
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[("1", "one"), ("2", "two")]).validate("1") == "1"
    assert Choice(choices=[("1", "one"), ("2", "two")]).validate("2") == "2"
    with pytest.raises(ValidationError):
        Choice(choices=[("1", "one"), ("2", "two")]).validate("3")



# Generated at 2022-06-24 10:47:49.198578
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate("value") == "value"



# Generated at 2022-06-24 10:47:53.454915
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test for method Choice.validate
    p = Choice(choices=["A", "B"])
    assert p.validate("A") == "A"
    assert p.validate(None) == None
    with pytest.raises(ValidationError):
        p.validate("C")
    
    
    


# Generated at 2022-06-24 10:47:55.429725
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    assert field.validation_error("code") == ValidationError(text=None, code="code")

# Generated at 2022-06-24 10:47:58.025333
# Unit test for method validate of class Field
def test_Field_validate():
    demo_field = Field()
    assert demo_field.validate(4) == 4


# Generated at 2022-06-24 10:48:00.127866
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    with pytest.raises(NotImplementedError):
        f.validate(1)

# Generated at 2022-06-24 10:48:04.029252
# Unit test for constructor of class Decimal
def test_Decimal():
    class B(Decimal):
      def __init__(self, **kwargs: typing.Any):
        super().__init__(**kwargs)
        self.integer_value = kwargs.get("integer_value")
    a = B(min_length=5)
    assert(a.integer_value is None)



# Generated at 2022-06-24 10:48:14.045789
# Unit test for method validate of class Number
def test_Number_validate():
    testNumber = Number()
    # test value is None and allow_null is True
    value = None
    expectedResult = None
    actualResult = testNumber.validate(value)
    assert actualResult == expectedResult
    # test value is None and allow_null is False
    value = None
    testNumber.allow_null = False
    expectedResult = "May not be null."
    actualResult = testNumber.validate(value)
    print(actualResult)
    assert actualResult == expectedResult
    # test value is a string and strict is False
    value = "123"
    expectedResult = 123
    actualResult = testNumber.validate(value)
    assert actualResult == expectedResult
    # test value is a string and strict is True
    value = "123"
    expectedResult = "Must be a number."

# Generated at 2022-06-24 10:48:23.885530
# Unit test for constructor of class DateTime
def test_DateTime():
    """
    Test case for constructor of class DateTime.
    """
    assert isinstance(DateTime(), DateTime)

DateTime.__doc__ = String.__doc__
Date.__doc__ = String.__doc__
Time.__doc__ = String.__doc__
Text.__doc__ = String.__doc__
Object.__doc__ = Field.__doc__
Array.__doc__ = Field.__doc__
Choice.__doc__ = String.__doc__
Float.__doc__ = Number.__doc__
Integer.__doc__ = Number.__doc__
Boolean.__doc__ = Field.__doc__


# Generated at 2022-06-24 10:48:25.841080
# Unit test for constructor of class Date
def test_Date():
    date = Date()
    assert date.format == 'date'



# Generated at 2022-06-24 10:48:35.065399
# Unit test for method validate of class Const
def test_Const_validate():
    def run_validation(expected, input):
        class TestConst(Const):
            def __init__(self, const, **kwargs):
                super().__init__(const, **kwargs)
            def get_error_text(self, error):
                return error
        field = TestConst('password')
        try:
            field.validate(input)
        except ValidationError as e:
            if expected == None:
                return False
            assert e.text() == expected
        else:
            if expected == None:
                return True
            return False
    assert run_validation("only_null", None)
    assert run_validation("const", "pass")
    assert run_validation(None, "password")
    assert run_validation("const", 1)