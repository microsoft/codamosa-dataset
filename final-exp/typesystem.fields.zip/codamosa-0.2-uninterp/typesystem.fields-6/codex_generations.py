

# Generated at 2022-06-18 12:14:26.309480
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    assert choice.validate

# Generated at 2022-06-18 12:14:28.662044
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1


# Generated at 2022-06-18 12:14:34.300651
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    with pytest.raises(ValidationError):
        field.validate(None)



# Generated at 2022-06-18 12:14:41.254850
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.unions import Union
    field1 = String()
    field2 = String()
    union = field1 | field2
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]
    union = field1 | (field2 | field1)
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2, field1]
    union = (field1 | field2) | field1
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2, field1]



# Generated at 2022-06-18 12:14:42.899975
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:14:48.710718
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, *, strict=False)
    # Unit test for method validate of class Array
    def test_Array_validate():
        # Test for method validate(self, value, *, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)

        # Test for method validate(self, value, *, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)

        # Test for method validate(self, value, *, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__

# Generated at 2022-06-18 12:15:00.465868
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert String(format="datetime").serialize("2020-01-01T00:00:00") == "2020-01-01T00:00:00"
    assert String(format="datetime").serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert String(format="time").serialize("00:00:00") == "00:00:00"
    assert String(format="time").serialize

# Generated at 2022-06-18 12:15:01.985399
# Unit test for constructor of class String
def test_String():
    assert String(title="", description="", default=NO_DEFAULT, allow_null=False)


# Generated at 2022-06-18 12:15:09.814214
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.default == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.get_error_text("only_null") == "Must be null."
    assert const.get_error_text("const") == "Must be the value '{const}'."
    assert const.validate(1) == 1
    assert const.validate(2) == None
    assert const.validate(None) == None
    assert const.validate_or_error(1) == (1, None)

# Generated at 2022-06-18 12:15:21.898195
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=True) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=False) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"], strict=False) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d"], strict=True) == ["a", "b", "c", "d"]

# Generated at 2022-06-18 12:15:58.615786
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(1.0) == 1.0
    assert number.validate(1.1) == 1.1
    assert number.validate(1.5) == 1.5
    assert number.validate(1.6) == 1.6
    assert number.validate(1.9) == 1.9
    assert number.validate(2) == 2
    assert number.validate(2.0) == 2.0
    assert number.validate(2.1) == 2.1
    assert number.validate(2.5) == 2.5
    assert number.validate(2.6) == 2.6
    assert number.validate(2.9) == 2.9
    assert number.validate(3)

# Generated at 2022-06-18 12:15:59.392836
# Unit test for constructor of class Const
def test_Const():
    Const(const=1)


# Generated at 2022-06-18 12:16:10.445718
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:16:20.822934
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5, strict=True) == 1.5
    assert Number().validate(1.5, strict=False) == 1.5
    assert Number().validate(1.5, strict=True) == 1.5
    assert Number().validate(1.5, strict=False) == 1.5
    assert Number().validate(1.5, strict=True) == 1.5
    assert Number().validate(1.5, strict=False) == 1.5
    assert Number().validate(1.5, strict=True) == 1.5
    assert Number().validate(1.5, strict=False)

# Generated at 2022-06-18 12:16:25.575877
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:16:31.131557
# Unit test for method validate of class Object
def test_Object_validate():
    # test case 1
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "email": String(format="email"),
    }
    obj = Object(properties=properties)
    value = {
        "name": "John Doe",
        "age": 21,
        "email": "john@doe.com",
    }
    assert obj.validate(value) == value

    # test case 2
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "email": String(format="email"),
    }
    obj = Object(properties=properties)

# Generated at 2022-06-18 12:16:38.754542
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
    }
    schema = Object(properties=properties)
    value = {"name": "John", "age": 30}
    expected = {"name": "John", "age": 30}
    actual = schema.validate(value)
    assert actual == expected

    # Test case 2
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
    }
    schema = Object(properties=properties)
    value = {"name": "John", "age": -1}
    expected = {"name": "John", "age": -1}
    actual = schema.validate(value)
    assert actual == expected

    # Test

# Generated at 2022-06-18 12:16:48.654565
# Unit test for constructor of class Array
def test_Array():
    items = [Integer(), String()]
    additional_items = False
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items)
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.exact_items == exact_items
    assert array.unique_items == unique_items


# Generated at 2022-06-18 12:16:57.888896
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:17:02.652602
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    assert choice.validate("") is None

# Generated at 2022-06-18 12:17:25.779837
# Unit test for method validate of class Union
def test_Union_validate():
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)

    class TestString(String):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)

    class TestNumber(Number):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)

    class TestBoolean(Boolean):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)


# Generated at 2022-06-18 12:17:31.510940
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")



# Generated at 2022-06-18 12:17:41.408476
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Number()]
    union = Union(any_of)
    value = "test"
    assert union.validate(value) == "test"
    # Test case 2
    any_of = [String(), Number()]
    union = Union(any_of)
    value = 1
    assert union.validate(value) == 1
    # Test case 3
    any_of = [String(), Number()]
    union = Union(any_of)
    value = True
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].code == "union"
    # Test case 4
    any_of = [String(), Number()]
    union = Union(any_of)
    value = None
   

# Generated at 2022-06-18 12:17:53.106874
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:18:03.635214
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b", "c"]).validate("a") == "a"
    assert Choice(choices=["a", "b", "c"]).validate("b") == "b"
    assert Choice(choices=["a", "b", "c"]).validate("c") == "c"
    assert Choice(choices=["a", "b", "c"]).validate("d") == "d"
    assert Choice(choices=["a", "b", "c"]).validate("") == ""
    assert Choice(choices=["a", "b", "c"]).validate(None) == None
    assert Choice(choices=["a", "b", "c"]).validate(1) == 1

# Generated at 2022-06-18 12:18:15.335069
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=None).const == None
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const="hello").const == "hello"
    assert Const(const=[]).const == []
    assert Const(const={}).const == {}
    assert Const(const={"a": 1}).const == {"a": 1}
    assert Const(const={"a": 1, "b": 2}).const == {"a": 1, "b": 2}
    assert Const(const={"a": 1, "b": 2, "c": 3}).const == {"a": 1, "b": 2, "c": 3}
    assert Const(const=[1, 2, 3]).const == [1, 2, 3]
   

# Generated at 2022-06-18 12:18:27.395070
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(properties={"name": String()})
    assert field.validate({"name": "John"}) == {"name": "John"}
    assert field.validate({"name": "John", "age": 20}) == {"name": "John", "age": 20}
    assert field.validate({"name": "John", "age": 20}, strict=True) == {"name": "John"}
    assert field.validate({"name": "John", "age": 20}, strict=False) == {"name": "John", "age": 20}
    assert field.validate({"name": "John", "age": 20}, strict=True) == {"name": "John"}
    assert field.validate({"name": "John", "age": 20}, strict=False) == {"name": "John", "age": 20}

# Generated at 2022-06-18 12:18:37.283229
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String()]
    union = Union(any_of)
    value = "hello"
    try:
        union.validate(value)
    except ValidationError as e:
        assert False
    else:
        assert True
    # Test case 2
    any_of = [String()]
    union = Union(any_of)
    value = 1
    try:
        union.validate(value)
    except ValidationError as e:
        assert True
    else:
        assert False
    # Test case 3
    any_of = [String()]
    union = Union(any_of)
    value = None
    try:
        union.validate(value)
    except ValidationError as e:
        assert True
    else:
        assert False
    #

# Generated at 2022-06-18 12:18:48.034768
# Unit test for method validate of class String
def test_String_validate():
    assert String(max_length=10).validate("1234567890") == "1234567890"
    assert String(max_length=10).validate("12345678901") == "12345678901"
    assert String(max_length=10).validate("12345678901") == "12345678901"
    assert String(max_length=10).validate("12345678901") == "12345678901"
    assert String(max_length=10).validate("12345678901") == "12345678901"
    assert String(max_length=10).validate("12345678901") == "12345678901"
    assert String(max_length=10).validate("12345678901") == "12345678901"

# Generated at 2022-06-18 12:18:50.844448
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:19:08.008251
# Unit test for method validate of class Choice

# Generated at 2022-06-18 12:19:14.486054
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:19:18.584928
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=None).const == None
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const="").const == ""
    assert Const(const="a").const == "a"
    assert Const(const=[]).const == []
    assert Const(const=[1]).const == [1]
    assert Const(const=[1,2]).const == [1,2]
    assert Const(const={}).const == {}
    assert Const(const={"a":1}).const == {"a":1}
    assert Const(const={"a":1,"b":2}).const == {"a":1,"b":2}

# Generated at 2022-06-18 12:19:29.556407
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[('a', 'a'), ('b', 'b')])
    assert field.validate('a') == 'a'
    assert field.validate('b') == 'b'
    with pytest.raises(ValidationError):
        field.validate('c')
    with pytest.raises(ValidationError):
        field.validate('')
    with pytest.raises(ValidationError):
        field.validate(None)
    field = Choice(choices=[('a', 'a'), ('b', 'b')], allow_null=True)
    assert field.validate(None) == None
    assert field.validate('') == None
    with pytest.raises(ValidationError):
        field.validate('c')

# Generated at 2022-06-18 12:19:41.556733
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.validate("a") == "a"
    assert c.validate("b") == "a"
    assert c.validate("c") == "c"
    assert c.validate("d") == "c"
    assert c.validate("e") == "e"
    assert c.validate("") == ""
    assert c.validate(None) == None
    assert c.validate("", strict=True) == ""
    assert c.validate(None, strict=True) == None
    assert c.validate("a", strict=True) == "a"
    assert c.validate("b", strict=True) == "a"
    assert c.validate("c", strict=True) == "c"

# Generated at 2022-06-18 12:19:51.339836
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    schema = Object(properties=properties)
    data = {"name": "John", "age": 20}
    assert schema.validate(data) == data

    # Test case 2
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    schema = Object(properties=properties)
    data = {"name": "John", "age": 20, "gender": "male"}
    assert schema.validate(data) == data

    # Test case 3

# Generated at 2022-06-18 12:20:02.188900
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True, allow_blank=True)
    assert choice.validate("")

# Generated at 2022-06-18 12:20:13.112953
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['a', 'b', 'c'])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    assert choice.validate('c') == 'c'
    try:
        choice.validate('d')
    except ValidationError:
        assert True
    else:
        assert False
    try:
        choice.validate('')
    except ValidationError:
        assert True
    else:
        assert False
    choice = Choice(choices=['a', 'b', 'c'], allow_null=True)
    assert choice.validate('') == None
    assert choice.validate(None) == None

# Generated at 2022-06-18 12:20:25.503481
# Unit test for method validate of class String
def test_String_validate():
    assert String(allow_null=True).validate(None) == None
    assert String(allow_null=True, allow_blank=True).validate(None) == ""
    assert String(allow_null=True, allow_blank=True).validate("") == ""
    assert String(allow_null=True, allow_blank=True).validate(" ") == ""
    assert String(allow_null=True, allow_blank=True).validate("  ") == ""
    assert String(allow_null=True, allow_blank=True).validate("   ") == ""
    assert String(allow_null=True, allow_blank=True).validate("    ") == ""
    assert String(allow_null=True, allow_blank=True).validate("     ") == ""

# Generated at 2022-06-18 12:20:35.783271
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:20:54.722390
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:05.527149
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("") == ""
    assert choice.validate(None) == None



# Generated at 2022-06-18 12:21:17.924676
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == None
    assert b.validate(" ") == None
    assert b

# Generated at 2022-06-18 12:21:27.977558
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("3")
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True, allow_blank=True)

# Generated at 2022-06-18 12:21:38.399975
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=String(max_length=10))
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 2
    field = Array(items=String(max_length=10))
    value = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"]
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must have no more than 10 items.",
                code="max_items",
                index=[10],
            )
        ]

    # Test case 3

# Generated at 2022-06-18 12:21:46.559283
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5)

# Generated at 2022-06-18 12:21:55.309028
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=1).validate(1) == 1
    assert Number(minimum=1).validate(2) == 2
    assert Number(minimum=1).validate(0) == 0
    assert Number(minimum=1).validate(0.5) == 0.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(1.5) == 1.5

# Generated at 2022-06-18 12:22:05.270768
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("") is None
    choice = Choice(choices=["a", "b", "c"], allow_blank=True)

# Generated at 2022-06-18 12:22:10.745151
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")



# Generated at 2022-06-18 12:22:21.988681
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:34.897217
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}


# Generated at 2022-06-18 12:22:46.162752
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:57.327531
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    with pytest.raises(ValidationError):
        field.validate("d")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"