

# Generated at 2022-06-18 12:15:17.867624
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate("test") == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"

# Generated at 2022-06-18 12:15:27.641662
# Unit test for constructor of class String
def test_String():
    string = String()
    assert string.title == ""
    assert string.description == ""
    assert string.allow_null == False
    assert string.allow_blank == False
    assert string.trim_whitespace == True
    assert string.max_length == None
    assert string.min_length == None
    assert string.pattern == None
    assert string.format == None
    assert string.pattern_regex == None

# Generated at 2022-06-18 12:15:39.313870
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:15:50.583176
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3.0]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]

# Generated at 2022-06-18 12:15:57.244228
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "email": String(format="email"),
    }
    schema = Object(properties=properties)
    value = {
        "name": "John Doe",
        "age": "21",
        "email": "john@example.com",
    }
    validated = schema.validate(value)
    assert validated == {
        "name": "John Doe",
        "age": 21,
        "email": "john@example.com",
    }

    # Test case 2
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "email": String(format="email"),
    }
    schema

# Generated at 2022-06-18 12:16:03.215170
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:16:07.895782
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.unions import Union
    field1 = String(max_length=10)
    field2 = String(max_length=20)
    union = field1 | field2
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]



# Generated at 2022-06-18 12:16:18.149068
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("") == ""
    assert s.validate("a") == "a"
    assert s.validate("a\0") == "a"
    assert s.validate(" a ") == "a"
    assert s.validate("a", strict=True) == "a"
    assert s.validate("a\0", strict=True) == "a"
    assert s.validate(" a ", strict=True) == " a "
    assert s.validate(None) == ""
    assert s.validate(None, strict=True) == None
    assert s.validate(1) == "1"
    assert s.validate(1, strict=True) == "1"
    assert s.validate(1.0) == "1.0"
    assert s

# Generated at 2022-06-18 12:16:30.533996
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == None
    assert b.validate(" ") == None
    assert b

# Generated at 2022-06-18 12:16:37.543051
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Schema):
        a = Array(items=Integer())

    assert Test().serialize({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}
    assert Test().serialize({"a": [1, 2, 3.0]}) == {"a": [1, 2, 3]}
    assert Test().serialize({"a": [1, 2, None]}) == {"a": [1, 2, None]}
    assert Test().serialize({"a": [1, 2, "3"]}) == {"a": [1, 2, 3]}
    assert Test().serialize({"a": [1, 2, "3.0"]}) == {"a": [1, 2, 3]}

# Generated at 2022-06-18 12:17:09.191450
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.5)

# Generated at 2022-06-18 12:17:21.381910
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    from typesystem.unions import Union
    assert (String() | Integer()) == Union(any_of=[String(), Integer()])
    assert (String() | Integer() | String()) == Union(any_of=[String(), Integer(), String()])
    assert (String() | (Integer() | String())) == Union(any_of=[String(), Integer(), String()])
    assert (String() | (Integer() | String())) == Union(any_of=[String(), Integer(), String()])
    assert (String() | (Integer() | String())) == Union(any_of=[String(), Integer(), String()])
    assert (String() | (Integer() | String())) == Union(any_of=[String(), Integer(), String()])

# Generated at 2022-06-18 12:17:25.768589
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]



# Generated at 2022-06-18 12:17:38.111509
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = "hello"
    expected = "hello"
    actual = union.validate(value)
    assert actual == expected
    # Test case 2
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = 1
    expected = 1
    actual = union.validate(value)
    assert actual == expected
    # Test case 3
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = 1.0
    expected = ValidationError(messages=[Message(text="Must be an integer.", code="type")])
   

# Generated at 2022-06-18 12:17:48.295434
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate(None) is None
    with pytest.raises(ValidationError):
        field.validate("c")

# Generated at 2022-06-18 12:17:59.748580
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic import BaseModel
    from pydantic.error_wrappers import ValidationError
    from pydantic.validators import validator
    from typing import List, Optional

    class Model(BaseModel):
        class Config:
            validate_assignment = True

        a: int
        b: int

    class Model2(BaseModel):
        class Config:
            validate_assignment = True

        a: int
        b: int

    class Model3(BaseModel):
        class Config:
            validate_assignment = True

        a: int
        b: int

    class Model4(BaseModel):
        class Config:
            validate_assignment = True

        a: int
        b: int

    class Model5(BaseModel):
        class Config:
            validate_assignment = True

        a: int
       

# Generated at 2022-06-18 12:18:10.053510
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:18:22.453612
# Unit test for constructor of class Array
def test_Array():
    a = Array(items=String())
    assert a.items == String()
    assert a.additional_items == False
    assert a.min_items == None
    assert a.max_items == None
    assert a.unique_items == False

    b = Array(items=String(), additional_items=True)
    assert b.items == String()
    assert b.additional_items == True
    assert b.min_items == None
    assert b.max_items == None
    assert b.unique_items == False

    c = Array(items=String(), additional_items=False)
    assert c.items == String()
    assert c.additional_items == False
    assert c.min_items == None
    assert c.max_items == None
    assert c.unique_items == False


# Generated at 2022-06-18 12:18:33.529137
# Unit test for method validate of class Union
def test_Union_validate():
    from . import String
    from . import Number
    from . import Boolean
    from . import Null
    from . import ValidationError
    from . import Message
    from . import Field
    from . import Union
    from . import Integer
    from . import Any
    from . import Object
    from . import Array
    from . import Text
    from . import Date
    from . import Time
    from . import DateTime
    from . import Uniqueness
    from . import Enum
    from . import Const
    from . import Reference
    from . import Pattern
    from . import Format
    from . import Range
    from . import Length
    from . import MultipleOf
    from . import AllOf
    from . import AnyOf
    from . import OneOf
    from . import Not
    from . import Dependencies
    from . import Schema

# Generated at 2022-06-18 12:18:40.813106
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="date").serialize(datetime.date(2019, 1, 1)) == "2019-01-01"
    assert String(format="datetime").serialize("2019-01-01T00:00:00") == "2019-01-01T00:00:00"
    assert String(format="datetime").serialize(datetime.datetime(2019, 1, 1)) == "2019-01-01T00:00:00"
    assert String(format="time").serialize("00:00:00") == "00:00:00"
    assert String(format="time").serialize(datetime.time(0, 0, 0)) == "00:00:00"

# Generated at 2022-06-18 12:19:06.025192
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:19:14.884628
# Unit test for constructor of class Array
def test_Array():
    items = [Integer(), String()]
    additional_items = Boolean()
    min_items = 1
    max_items = 2
    exact_items = 2
    unique_items = True
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items)
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.unique_items == unique_items


# Generated at 2022-06-18 12:19:18.712379
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any
    # of class Union
    # This method is not tested because it is not used in the code
    pass


# Generated at 2022-06-18 12:19:29.653469
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:41.701380
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=1).allow_null == False
    assert Const(const=1, allow_null=True).allow_null == True
    assert Const(const=1, allow_null=True).const == 1
    assert Const(const=1, allow_null=False).allow_null == False
    assert Const(const=1, allow_null=False).const == 1
    assert Const(const=1, allow_null=None).allow_null == False
    assert Const(const=1, allow_null=None).const == 1
    assert Const(const=1, allow_null=0).allow_null == False
    assert Const(const=1, allow_null=0).const == 1
    assert Const(const=1, allow_null=1).allow_null == True
   

# Generated at 2022-06-18 12:19:51.428571
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["1", "2", "3"])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == "3"
    with pytest.raises(ValidationError):
        choice.validate("4")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["1", "2", "3"], allow_null=True)
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == "3"
    assert choice.validate("4") is None
    assert choice.validate("") is None

# Generated at 2022-06-18 12:20:02.357469
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:20:13.203884
# Unit test for method validate of class String
def test_String_validate():
    assert String(allow_null=True).validate(None) == None
    assert String(allow_blank=True).validate(None) == ""
    assert String(allow_blank=True).validate("") == ""
    assert String(allow_blank=True).validate(" ") == ""
    assert String(allow_blank=True).validate("\n") == ""
    assert String(allow_blank=True).validate("\t") == ""
    assert String(allow_blank=True).validate("\r") == ""
    assert String(allow_blank=True).validate("\r\n") == ""
    assert String(allow_blank=True).validate("\r\n\t ") == ""
    assert String(allow_blank=True).validate("\0") == ""

# Generated at 2022-06-18 12:20:25.799074
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSchema(Schema):
        test = Array(items=Integer())

    schema = TestSchema()
    assert schema.serialize({"test": [1, 2, 3]}) == {"test": [1, 2, 3]}
    assert schema.serialize({"test": [1, 2, 3.5]}) == {"test": [1, 2, 3]}
    assert schema.serialize({"test": [1, 2, "3"]}) == {"test": [1, 2, 3]}
    assert schema.serialize({"test": [1, 2, "3.5"]}) == {"test": [1, 2, 3]}
    assert schema.serialize({"test": [1, 2, "3.5", "4.5"]}) == {"test": [1, 2, 3, 4]}
    assert schema.serial

# Generated at 2022-06-18 12:20:28.990718
# Unit test for constructor of class Const
def test_Const():
    try:
        Const(const=None)
    except AssertionError:
        print("AssertionError")
    else:
        print("No AssertionError")

test_Const()

# Generated at 2022-06-18 12:20:47.659812
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:21:00.050424
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:09.408204
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:21:19.540437
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1
    field = Field(allow_null=True)
    assert field.get_default_value() is None
    field = Field(allow_null=True, default=1)
    assert field.get_default_value() is None
    field = Field(allow_null=True, default=lambda: 1)
    assert field.get_default_value() is None


# Generated at 2022-06-18 12:21:28.910873
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('1', '1'), ('2', '2')])
    assert choice.validate(1) == 1
    assert choice.validate(2) == 2
    assert choice.validate(3) == 3
    assert choice.validate(None) == None
    assert choice.validate("") == ""
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == "3"
    assert choice.validate("4") == "4"
    assert choice.validate("") == ""
    assert choice.validate("") == ""
    assert choice.validate("") == ""
    assert choice.validate("") == ""
    assert choice.validate("") == ""

# Generated at 2022-06-18 12:21:30.616254
# Unit test for constructor of class String
def test_String():
    assert String(title="", description="", default=NO_DEFAULT, allow_null=False)


# Generated at 2022-06-18 12:21:37.420714
# Unit test for constructor of class Const
def test_Const():
    assert Const(1).const == 1
    assert Const(1, allow_null=True).const == 1
    assert Const(1, allow_null=True).allow_null == True
    assert Const(1, allow_null=False).allow_null == False
    assert Const(1, allow_null=False).const == 1
    assert Const(1, allow_null=True).allow_null == True
    assert Const(1, allow_null=True).const == 1


# Generated at 2022-06-18 12:21:40.885792
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:21:46.869757
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
        "address": String(max_length=20),
    }
    obj = Object(properties=properties)
    value = {
        "name": "John",
        "age": 25,
        "address": "New York",
    }
    assert obj.validate(value) == value

    # Test case 2
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
        "address": String(max_length=20),
    }
    obj = Object(properties=properties)

# Generated at 2022-06-18 12:21:50.625547
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1
    field = Field(default=NO_DEFAULT)
    assert field.get_default_value() == None


# Generated at 2022-06-18 12:22:06.758559
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=10, min_length=1, pattern=None, format="test")
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.max_length == 10
    assert s.min_length == 1
    assert s.pattern == None
    assert s.format == "test"


# Generated at 2022-06-18 12:22:16.500587
# Unit test for constructor of class Const
def test_Const():
    assert Const(1).const == 1
    assert Const(1, allow_null=True).allow_null == True
    assert Const(1, allow_null=False).allow_null == False
    assert Const(1, allow_null=None).allow_null == False
    assert Const(1, allow_null=True).const == 1
    assert Const(1, allow_null=False).const == 1
    assert Const(1, allow_null=None).const == 1
    assert Const(1, allow_null=True).validate(1) == 1
    assert Const(1, allow_null=False).validate(1) == 1
    assert Const(1, allow_null=None).validate(1) == 1
    assert Const(1, allow_null=True).validate(None) == None

# Generated at 2022-06-18 12:22:27.626047
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) is None
    with pytest.raises(ValidationError):
        choice.validate("")

# Generated at 2022-06-18 12:22:36.392875
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:47.830709
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=1, allow_null=True).const == 1
    assert Const(const=1, allow_null=True).allow_null == True
    assert Const(const=1, allow_null=False).allow_null == False
    assert Const(const=1, allow_null=False).const == 1
    assert Const(const=1, allow_null=True).allow_null == True
    assert Const(const=1, allow_null=True).const == 1
    assert Const(const=1, allow_null=True).allow_null == True
    assert Const(const=1, allow_null=True).const == 1
    assert Const(const=1, allow_null=True).allow_null == True
    assert Const(const=1, allow_null=True).const

# Generated at 2022-06-18 12:22:58.560935
# Unit test for method validate of class String
def test_String_validate():
    assert String(title="test", description="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate("test") == "test"
    assert String(title="test", description="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate(None) == None
    assert String(title="test", description="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate(1) == "1"