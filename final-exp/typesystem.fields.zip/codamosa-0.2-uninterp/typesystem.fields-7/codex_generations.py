

# Generated at 2022-06-18 12:16:03.109734
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.choices == [("a", "b"), ("c", "d")]
    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]
    c = Choice(choices=[])
    assert c.choices == []
    c = Choice(choices=None)
    assert c.choices == []


# Generated at 2022-06-18 12:16:13.878117
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        pass
    class Field2(Field):
        pass
    class Field3(Field):
        pass
    class Field4(Field):
        pass
    class Field5(Field):
        pass
    class Field6(Field):
        pass
    class Field7(Field):
        pass
    class Field8(Field):
        pass
    class Field9(Field):
        pass
    class Field10(Field):
        pass
    class Field11(Field):
        pass
    class Field12(Field):
        pass
    class Field13(Field):
        pass
    class Field14(Field):
        pass
    class Field15(Field):
        pass
    class Field16(Field):
        pass
    class Field17(Field):
        pass
    class Field18(Field):
        pass
   

# Generated at 2022-06-18 12:16:24.643439
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [Integer(), Number()]
    value = 1
    strict = False
    union = Union(any_of)
    assert union.validate(value, strict=strict) == value
    # Test case 2
    any_of = [Integer(), Number()]
    value = 1.0
    strict = False
    union = Union(any_of)
    assert union.validate(value, strict=strict) == value
    # Test case 3
    any_of = [Integer(), Number()]
    value = "1"
    strict = False
    union = Union(any_of)
    try:
        union.validate(value, strict=strict)
    except ValidationError as e:
        assert e.messages()[0].code == "union"
    # Test case

# Generated at 2022-06-18 12:16:36.137746
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(max_length=10), String(max_length=20)]
    union = Union(any_of)
    value = "12345678901"
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].text == "Must be no more than 10 characters."
        assert e.messages()[0].code == "max_length"
        assert e.messages()[0].index == []
    else:
        assert False

    # Test case 2
    any_of = [String(max_length=10), String(max_length=20)]
    union = Union(any_of)
    value = "1234567890"

# Generated at 2022-06-18 12:16:46.637527
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert String(format="time").serialize(datetime.time(12, 0, 0)) == "12:00:00"
    assert String(format="datetime").serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == "2020-01-01T12:00:00"
    assert String(format="uuid").serialize(uuid.UUID("123e4567-e89b-12d3-a456-426655440000")) == "123e4567-e89b-12d3-a456-426655440000"
    assert String().serialize("test") == "test"


# Generated at 2022-06-18 12:16:56.442415
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate("true") == True
    assert field.validate("false") == False
    assert field.validate("on") == True
    assert field.validate("off") == False
    assert field.validate("1") == True
    assert field.validate("0") == False
    assert field.validate("") == False
    assert field.validate(1) == True
    assert field.validate(0) == False
    assert field.validate("null") == None
    assert field.validate("none") == None
    assert field.validate("") == False
    assert field.validate("abc") == None
    assert field

# Generated at 2022-06-18 12:17:06.909025
# Unit test for method validate of class Union
def test_Union_validate():
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)

    class TestString(String):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)

    class TestNumber(Number):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)

    class TestBoolean(Boolean):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(**kwargs)


# Generated at 2022-06-18 12:17:19.537207
# Unit test for method validate of class Number

# Generated at 2022-06-18 12:17:28.528949
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=String()).serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert Array(items=String()).serialize(None) == None
    assert Array(items=String()).serialize([]) == []
    assert Array(items=String()).serialize(["a", None, "c"]) == ["a", None, "c"]
    assert Array(items=String()).serialize(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert Array(items=String()).serialize(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]

# Generated at 2022-06-18 12:17:33.501214
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:17:50.537881
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[('a', 'b'), ('c', 'd')])
    assert c.choices == [('a', 'b'), ('c', 'd')]
    c = Choice(choices=['a', 'b'])
    assert c.choices == [('a', 'a'), ('b', 'b')]
    c = Choice(choices=[])
    assert c.choices == []
    c = Choice(choices=None)
    assert c.choices == []


# Generated at 2022-06-18 12:17:54.867515
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=String())
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 2
    field = Array(items=String())
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 3
    field = Array(items=String())
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 4
    field = Array(items=String())
    value = ["a", "b", "c"]

# Generated at 2022-06-18 12:17:57.056234
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=1)
    assert field.get_default_value() == 1

# Generated at 2022-06-18 12:18:01.745937
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]



# Generated at 2022-06-18 12:18:12.419130
# Unit test for method validate of class Array
def test_Array_validate():
    items = [
        Integer(minimum=1, maximum=10),
        Integer(minimum=1, maximum=10),
        Integer(minimum=1, maximum=10),
    ]
    array = Array(items=items, min_items=3, max_items=3)
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert array.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert array.validate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert array.validate([1, 2, 3, 4, 5, 6, 7])

# Generated at 2022-06-18 12:18:24.978529
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:29.353406
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1

# Generated at 2022-06-18 12:18:38.546041
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"

# Generated at 2022-06-18 12:18:49.821405
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=String(),
        additional_items=False,
        min_items=1,
        max_items=2,
        unique_items=True,
    )
    value = ["a", "b"]
    assert field.validate(value) == value
    value = ["a", "a"]
    with pytest.raises(ValidationError) as excinfo:
        field.validate(value)
    assert excinfo.value.messages() == [
        Message(
            text="Items must be unique.",
            code="unique_items",
            key=1,
        )
    ]
    value = ["a", "b", "c"]
    with pytest.raises(ValidationError) as excinfo:
        field.validate(value)
    assert excinfo.value.messages

# Generated at 2022-06-18 12:19:02.650837
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.unions import Union
    f1 = String()
    f2 = String()
    assert isinstance(f1 | f2, Union)
    assert isinstance(f1 | f2 | f2, Union)
    assert isinstance(f1 | f2 | f2 | f1, Union)
    assert isinstance(f1 | f2 | f2 | f1 | f2, Union)
    assert isinstance(f1 | f2 | f2 | f1 | f2 | f1, Union)
    assert isinstance(f1 | f2 | f2 | f1 | f2 | f1 | f2, Union)
    assert isinstance(f1 | f2 | f2 | f1 | f2 | f1 | f2 | f1, Union)

# Generated at 2022-06-18 12:19:14.101061
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert (Field() | Field())



# Generated at 2022-06-18 12:19:25.047813
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.0) == 1.0
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.2) == 1.2
    assert choice.validate(1.3) == 1.3
   

# Generated at 2022-06-18 12:19:37.112500
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_blank=True)
    assert choice.valid

# Generated at 2022-06-18 12:19:41.590332
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Number()]
    value = "hello"
    strict = False
    expected = "hello"
    actual = Union(any_of).validate(value, strict=strict)
    assert actual == expected
    # Test case 2
    any_of = [String(), Number()]
    value = 1
    strict = False
    expected = 1
    actual = Union(any_of).validate(value, strict=strict)
    assert actual == expected
    # Test case 3
    any_of = [String(), Number()]
    value = None
    strict = False
    expected = None
    actual = Union(any_of).validate(value, strict=strict)
    assert actual == expected
    # Test case 4
    any_of = [String(), Number()]


# Generated at 2022-06-18 12:19:47.903755
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | field1
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, field1]



# Generated at 2022-06-18 12:19:58.534964
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('a', 'a'), ('b', 'b')])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    with pytest.raises(ValidationError):
        choice.validate('c')
    with pytest.raises(ValidationError):
        choice.validate('')
    choice = Choice(choices=[('a', 'a'), ('b', 'b')], allow_null=True)
    assert choice.validate('') == None
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate('c')

# Generated at 2022-06-18 12:20:08.155894
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | field1
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, field1]
    field5 = field4 | field4
    assert isinstance(field5, Union)
    assert field5.any_of == [field1, field2, field1, field1, field2, field1]



# Generated at 2022-06-18 12:20:10.024805
# Unit test for constructor of class String
def test_String():
    assert String(title="", description="", default=NO_DEFAULT, allow_null=False)


# Generated at 2022-06-18 12:20:14.553451
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Serializer):
        field = Array(items=Integer())
    assert Test(field=[1, 2, 3]).serialize() == {"field": [1, 2, 3]}
    assert Test(field=[1, 2, 3]).serialize(strict=True) == {"field": [1, 2, 3]}



# Generated at 2022-06-18 12:20:26.799333
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Integer(),
        additional_items=Integer(),
        min_items=1,
        max_items=3,
        unique_items=True,
    )
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert field.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert field.validate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert field.validate([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-18 12:20:47.958790
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [String(), Integer()]
    array = Array(items=items)
    obj = ["a", 1]
    assert array.serialize(obj) == ["a", 1]
    obj = ["a", 1, "b"]
    assert array.serialize(obj) == ["a", 1, "b"]
    obj = ["a", 1, "b", 2]
    assert array.serialize(obj) == ["a", 1, "b", 2]
    obj = ["a", 1, "b", 2, "c"]
    assert array.serialize(obj) == ["a", 1, "b", 2, "c"]

    items = [String(), Integer()]
    array = Array(items=items, additional_items=True)
    obj = ["a", 1]

# Generated at 2022-06-18 12:21:00.406122
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=Integer()).serialize([1, 2, 3]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, 3.0]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, "3"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, "3.0"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, "3.1"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, "3.1", "4.1"]) == [1, 2, 3, 4]

# Generated at 2022-06-18 12:21:09.573535
# Unit test for constructor of class String
def test_String():
    # Test for constructor of class String
    # Test for default values
    string = String()
    assert string.title == ""
    assert string.description == ""
    assert string.allow_blank == False
    assert string.trim_whitespace == True
    assert string.max_length == None
    assert string.min_length == None
    assert string.pattern == None
    assert string.format == None
    assert string.allow_null == False
    assert string.has_default() == False
    assert string.get_default_value() == None
    assert string.get_error_text("type") == "Must be a string."
    assert string.get_error_text("null") == "May not be null."
    assert string.get_error_text("blank") == "Must not be blank."
    assert string.get_error_

# Generated at 2022-06-18 12:21:21.995462
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1
    field = String(title="Test", description="Test", default=NO_DEFAULT, allow_null=False)
    value = "test"
    strict = False
    assert field.validate(value, strict=strict) == "test"
    # Test case 2
    field = String(title="Test", description="Test", default=NO_DEFAULT, allow_null=False)
    value = "test"
    strict = True
    assert field.validate(value, strict=strict) == "test"
    # Test case 3
    field = String(title="Test", description="Test", default=NO_DEFAULT, allow_null=False)
    value = "test"
    strict = False
    assert field.validate(value, strict=strict) == "test"
    # Test case 4
   

# Generated at 2022-06-18 12:21:29.687192
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=10, min_length=5, pattern="test", format="test")
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.max_length == 10
    assert s.min_length == 5
    assert s.pattern == "test"
    assert s.format == "test"
    assert s.pattern_regex == re.compile("test")


# Generated at 2022-06-18 12:21:39.906884
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, *, strict=False)
    # Unit test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.validate_called = False

        def validate(self, value, *, strict=False):
            self.validate_called = True
            return super().validate(value, strict=strict)

    # Test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.validate_called = False

        def validate(self, value, *, strict=False):
            self.validate_called = True

# Generated at 2022-06-18 12:21:48.837816
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "b")])
    assert c.choices == [("a", "b")]
    c = Choice(choices=["a"])
    assert c.choices == [("a", "a")]
    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]
    c = Choice(choices=[("a", "b"), "c"])
    assert c.choices == [("a", "b"), ("c", "c")]
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.choices == [("a", "b"), ("c", "d")]

# Generated at 2022-06-18 12:21:56.794055
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:06.561205
# Unit test for method validate of class Choice

# Generated at 2022-06-18 12:22:10.616358
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")



# Generated at 2022-06-18 12:22:25.719882
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")



# Generated at 2022-06-18 12:22:33.712301
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    assert choice.validate

# Generated at 2022-06-18 12:22:44.432415
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("") == ""
    assert s.validate(" ") == " "
    assert s.validate("a") == "a"
    assert s.validate("a ") == "a "
    assert s.validate(" a") == " a"
    assert s.validate(" a ") == " a "
    assert s.validate("a b") == "a b"
    assert s.validate("a b ") == "a b "
    assert s.validate(" a b") == " a b"
    assert s.validate(" a b ") == " a b "
    assert s.validate("a b c") == "a b c"
    assert s.validate("a b c ") == "a b c "

# Generated at 2022-06-18 12:22:56.131580
# Unit test for method validate of class Array