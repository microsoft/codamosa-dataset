

# Generated at 2022-06-18 12:15:00.838454
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:15:06.569694
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    assert (String() | Integer()) == Union(any_of=[String(), Integer()])
    assert (String() | Integer() | String()) == Union(any_of=[String(), Integer(), String()])
    assert (String() | Integer() | String() | Integer()) == Union(any_of=[String(), Integer(), String(), Integer()])



# Generated at 2022-06-18 12:15:18.908123
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=None)
    assert const.const == None
    assert const.allow_null == True
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.validate(value=None) == None
    assert const.validate(value=1) == 1
    assert const.validate(value="1") == "1"
    assert const.validate(value=True) == True
    assert const.validate(value=False) == False
    assert const.validate(value=[1, 2, 3]) == [1, 2, 3]
    assert const.validate(value={"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:15:28.461636
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [
        String(
            min_length=1,
            max_length=10,
            pattern="^[a-zA-Z0-9]*$",
            enum=["a", "b", "c"],
            allow_null=False,
        ),
        Integer(minimum=1, maximum=10, enum=[1, 2, 3], allow_null=False),
    ]
    value = "a"
    strict = False
    expected = "a"
    actual = Union(any_of).validate(value, strict=strict)
    assert actual == expected
    # Test case 2

# Generated at 2022-06-18 12:15:40.208517
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("") == ""
    assert s.validate(" ") == ""
    assert s.validate("  ") == ""
    assert s.validate("   ") == ""
    assert s.validate("    ") == ""
    assert s.validate("     ") == ""
    assert s.validate("      ") == ""
    assert s.validate("       ") == ""
    assert s.validate("        ") == ""
    assert s.validate("         ") == ""
    assert s.validate("          ") == ""
    assert s.validate("           ") == ""
    assert s.validate("            ") == ""
    assert s.validate("             ") == ""
    assert s.validate("              ") == ""
   

# Generated at 2022-06-18 12:15:51.279479
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test for a valid choice
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    # Test for an invalid choice
    with pytest.raises(ValidationError):
        choice.validate("d")
    # Test for a null value
    with pytest.raises(ValidationError):
        choice.validate(None)
    # Test for an empty string
    with pytest.raises(ValidationError):
        choice.validate("")
    # Test for an empty string when allow_null is True
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("") == None
    # Test for an empty string when allow_null is False

# Generated at 2022-06-18 12:15:57.664982
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:16:00.169722
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Generated at 2022-06-18 12:16:05.633817
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:16:11.024160
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=None)
    assert const.const is None
    assert const.allow_null is True
    assert const.errors["only_null"] == "Must be null."
    assert const.errors["const"] == "Must be the value 'None'."

    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null is False
    assert const.errors["only_null"] == "Must be null."
    assert const.errors["const"] == "Must be the value '1'."

    const = Const(const=1, allow_null=True)
    assert const.const == 1
    assert const.allow_null is True
    assert const.errors["only_null"] == "Must be null."
    assert const.errors["const"] == "Must be the value '1'."

    const = Const

# Generated at 2022-06-18 12:16:26.664526
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]



# Generated at 2022-06-18 12:16:37.413312
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.title == ""
    assert s.description == ""
    assert s.allow_null == False
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.pattern_regex == None

# Generated at 2022-06-18 12:16:41.402982
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Generated at 2022-06-18 12:16:52.561447
# Unit test for method validate of class Object
def test_Object_validate():
    # test for method validate of class Object
    # test for case 1:
    # input:
    #   value = {'a': 1, 'b': 2}
    #   properties = {'a': Integer(), 'b': Integer()}
    #   pattern_properties = {}
    #   additional_properties = True
    #   property_names = None
    #   min_properties = None
    #   max_properties = None
    #   required = None
    #   allow_null = False
    #   strict = False
    # output:
    #   validated = {'a': 1, 'b': 2}
    value = {'a': 1, 'b': 2}
    properties = {'a': Integer(), 'b': Integer()}
    pattern_properties = {}
    additional_properties = True
    property_names = None

# Generated at 2022-06-18 12:17:03.738814
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:13.829548
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False)

# Generated at 2022-06-18 12:17:20.649954
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() is None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 2)
    assert field.get_default_value() == 2
    field = Field(default=NO_DEFAULT)
    assert field.get_default_value() is None


# Generated at 2022-06-18 12:17:31.566100
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:41.407694
# Unit test for constructor of class String
def test_String():
    # Test 1
    s = String(title="test", description="test", default="test", allow_null=True)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True

    # Test 2
    s = String(title="test", description="test", default="test", allow_null=False)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == False

    # Test 3
    s = String(title="test", description="test", default="test", allow_null=False)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"

# Generated at 2022-06-18 12:17:52.884650
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate("123") == "123"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "12"
    assert string.validate("123") != "1"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
    assert string.validate("123") != "1234"
   

# Generated at 2022-06-18 12:18:09.239251
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=String(),
        additional_items=False,
        min_items=1,
        max_items=3,
        unique_items=True,
        allow_null=False,
        default=None,
    )
    value = ["a", "b", "c"]
    validated_value = field.validate(value)
    assert validated_value == value


# Generated at 2022-06-18 12:18:21.653960
# Unit test for method validate of class Union
def test_Union_validate():
    from . import String, Number, Boolean
    from .errors import ValidationError
    from .fields import Field

    class TestUnion(Union):
        def __init__(self, **kwargs: typing.Any):
            super().__init__(any_of=[String(), Number(), Boolean()], **kwargs)

    field = TestUnion()
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(None) is None
    assert field.validate(1.1) == 1.1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:18:25.795457
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:18:36.153745
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(properties={'name': String()})
    obj.validate({'name': 'John'})
    obj.validate({'name': 'John', 'age': 20})
    obj.validate({'name': 'John', 'age': 20, 'gender': 'male'})
    obj.validate({'name': 'John', 'age': 20, 'gender': 'male', 'address': '123 Main St.'})
    obj.validate({'name': 'John', 'age': 20, 'gender': 'male', 'address': '123 Main St.', 'phone': '123-456-7890'})

# Generated at 2022-06-18 12:18:45.208856
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("c")



# Generated at 2022-06-18 12:18:58.044760
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:04.252609
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        field = Array(items=Integer())

    serializer = TestSerializer()
    assert serializer.serialize({"field": [1, 2, 3]}) == {"field": [1, 2, 3]}
    assert serializer.serialize({"field": [1, 2, 3.1]}) == {"field": [1, 2, 3]}



# Generated at 2022-06-18 12:19:13.577048
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(1.0) == 1.0
    assert number.validate(1.1) == 1.1
    assert number.validate(1.11) == 1.11
    assert number.validate(1.111) == 1.111
    assert number.validate(1.1111) == 1.1111
    assert number.validate(1.11111) == 1.11111
    assert number.validate(1.111111) == 1.111111
    assert number.validate(1.1111111) == 1.1111111
    assert number.validate(1.11111111) == 1.11111111
    assert number.validate(1.111111111) == 1.111111111

# Generated at 2022-06-18 12:19:24.574428
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b"], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    choice = Choice(choices=["a", "b"], allow_blank=True)
    assert choice.validate("") == ""

# Generated at 2022-06-18 12:19:36.604682
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("a", "a"), ("b", "b"), ("c", "c")]
    choice = Choice(choices=choices)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=choices, allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate(None) == None

# Generated at 2022-06-18 12:20:02.234082
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:20:13.214102
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:20:25.758603
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.get_error_text("only_null") == "Must be null."
    assert const.get_error_text("const") == "Must be the value '{const}'."
    assert const.get_error_text("invalid_key") == "Invalid key."
    assert const.get_error_text("invalid_property") == "Invalid property."
    assert const.get_error_text("required") == "Required property."
    assert const.get_error_text("empty") == "Must not be empty."

# Generated at 2022-06-18 12:20:35.940707
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3.0]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.9"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.99"]) == [1, 2, 3]

# Generated at 2022-06-18 12:20:39.663033
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        test = Array(items=Integer())

    serializer = TestSerializer()
    assert serializer.serialize({"test": [1, 2, 3]}) == {"test": [1, 2, 3]}



# Generated at 2022-06-18 12:20:51.660005
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    items = [String(max_length=10), Integer(minimum=0, maximum=100)]
    additional_items = False
    min_items = 2
    max_items = 2
    unique_items = False
    field = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    value = ["abc", 1]
    expected = ["abc", 1]
    actual = field.validate(value)
    assert actual == expected
    # Test case 2
    items = [String(max_length=10), Integer(minimum=0, maximum=100)]
    additional_items = False
    min_items = 2
    max_items = 2
    unique_items = False

# Generated at 2022-06-18 12:21:03.707107
# Unit test for method validate of class String

# Generated at 2022-06-18 12:21:11.486247
# Unit test for method validate of class String

# Generated at 2022-06-18 12:21:13.652294
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}


# Generated at 2022-06-18 12:21:25.638183
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean().validate(None) == None
    assert Boolean().validate("true") == True
    assert Boolean().validate("false") == False
    assert Boolean().validate("on") == True
    assert Boolean().validate("off") == False
    assert Boolean().validate("1") == True
    assert Boolean().validate("0") == False
    assert Boolean().validate("") == False
    assert Boolean().validate(1) == True
    assert Boolean().validate(0) == False
    assert Boolean().validate("null") == None
    assert Boolean().validate("none") == None
    assert Boolean().validate("") == None
    assert Boolean().validate(" ") == None
    assert Boolean().validate("a")

# Generated at 2022-06-18 12:21:41.966544
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate("test") == "test"
    assert string.validate("") == ""
    assert string.validate(None) == None
    assert string.validate("test", strict=True) == "test"
    assert string.validate("", strict=True) == ""
    assert string.validate(None, strict=True) == None
    assert string.validate("test", strict=False) == "test"
    assert string.validate("", strict=False) == ""
    assert string.validate(None, strict=False) == None
    assert string.validate("test", strict=True) == "test"
    assert string.validate("", strict=True) == ""
    assert string.validate(None, strict=True) == None

# Generated at 2022-06-18 12:21:51.295551
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:53.330014
# Unit test for constructor of class Array
def test_Array():
    assert Array(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)


# Generated at 2022-06-18 12:22:02.566913
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:10.572633
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any) -> None:
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)


# Generated at 2022-06-18 12:22:21.799459
# Unit test for method serialize of class Array
def test_Array_serialize():
    array = Array(items=String())
    assert array.serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert array.serialize(["a", None, "c"]) == ["a", None, "c"]

    array = Array(items=String(allow_null=False))
    assert array.serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert array.serialize(["a", None, "c"]) == ["a", "", "c"]

    array = Array(items=String(allow_null=False), allow_null=False)
    assert array.serialize(["a", "b", "c"]) == ["a", "b", "c"]

# Generated at 2022-06-18 12:22:24.041075
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:22:32.308495
# Unit test for method validate of class Boolean

# Generated at 2022-06-18 12:22:42.614901
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1)

# Generated at 2022-06-18 12:22:54.256670
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any):
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)
    class TestField(Field):
        def __init__(self, *, allow_null: bool = False, default: typing.Any = None, **kwargs: typing.Any):
            super().__init__