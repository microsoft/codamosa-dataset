

# Generated at 2022-06-18 12:14:55.473278
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3.0]) == [1, 2, 3]
    assert field.validate([1, 2, 3.1]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1", 4]) == [1, 2, 3, 4]
    assert field.validate([1, 2, "3.1", 4.1]) == [1, 2, 3, 4]

# Generated at 2022-06-18 12:15:06.456414
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("") == None
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:15:18.770928
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test for method validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any
    # of class Choice
    assert Choice(choices=[("a", "b"), ("c", "d")]).validate("a") == "a"
    assert Choice(choices=[("a", "b"), ("c", "d")]).validate("b") == "a"
    assert Choice(choices=[("a", "b"), ("c", "d")]).validate("c") == "c"
    assert Choice(choices=[("a", "b"), ("c", "d")]).validate("d") == "c"
    assert Choice(choices=[("a", "b"), ("c", "d")]).validate("e") == "e"

# Generated at 2022-06-18 12:15:28.350781
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(
        items=Field(type="string"),
        additional_items=Field(type="string"),
        min_items=1,
        max_items=2,
        unique_items=True,
    )
    value = ["a", "b", "c"]
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must have no more than 2 items.",
                code="max_items",
                key=None,
                index=None,
            )
        ]
    else:
        assert False

    # Test case 2

# Generated at 2022-06-18 12:15:40.155246
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:51.192190
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic import BaseModel
    from pydantic.error_wrappers import ValidationError
    from pydantic.fields import Field
    from pydantic.types import conint

    class Model(BaseModel):
        value: Union[conint(gt=0, lt=100), conint(gt=100, lt=200)]

    m = Model(value=50)
    assert m.value == 50

    m = Model(value=150)
    assert m.value == 150

    with pytest.raises(ValidationError) as exc_info:
        Model(value=0)

# Generated at 2022-06-18 12:16:02.360620
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestField(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
            super().__init__(title=title, description=description, default=default, allow_null=allow_null)

    field = TestField(title="test", description="test", default=1, allow_null=False)
    assert field.get_default_value() == 1
    field = TestField(title="test", description="test", default=None, allow_null=True)
    assert field.get_default_value() == None
    field = TestField(title="test", description="test", default=NO_DEFAULT, allow_null=False)
    assert field.get_default_value() == None
    field = Test

# Generated at 2022-06-18 12:16:12.577146
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format='date').serialize("2020-01-01") == "2020-01-01"
    assert String(format='time').serialize("12:00:00") == "12:00:00"
    assert String(format='datetime').serialize("2020-01-01T12:00:00") == "2020-01-01T12:00:00"
    assert String(format='uuid').serialize("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11") == "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"
    assert String().serialize("2020-01-01") == "2020-01-01"


# Generated at 2022-06-18 12:16:23.272989
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test case 1
    # Input:
    #   value = None
    #   allow_null = True
    # Expected output:
    #   None
    value = None
    allow_null = True
    assert Boolean(allow_null=allow_null).validate(value) == None

    # Test case 2
    # Input:
    #   value = None
    #   allow_null = False
    # Expected output:
    #   ValidationError
    value = None
    allow_null = False
    try:
        Boolean(allow_null=allow_null).validate(value)
    except ValidationError:
        pass
    else:
        assert False

    # Test case 3
    # Input:
    #   value = True
    #   allow_null = True
    # Expected output:
    #

# Generated at 2022-06-18 12:16:35.203852
# Unit test for method validate of class Union
def test_Union_validate():
    from jsonschema import ValidationError
    from jsonschema import validate
    from jsonschema.validators import Draft7Validator
    from jsonschema.validators import validator_for
    from jsonschema.validators import extend
    from jsonschema.exceptions import best_match
    from jsonschema.exceptions import RefResolutionError
    from jsonschema.exceptions import UnknownType
    from jsonschema.exceptions import SchemaError
    from jsonschema.exceptions import FormatError
    from jsonschema.exceptions import ValidationError
    from jsonschema.exceptions import ErrorTree
    from jsonschema.exceptions import best_match
    from jsonschema.exceptions import UnknownType
    from jsonschema.exceptions import SchemaError


# Generated at 2022-06-18 12:16:55.888399
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:17:04.005717
# Unit test for constructor of class Array
def test_Array():
    items = [String(), Number()]
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    field = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    assert field.items == items
    assert field.additional_items == additional_items
    assert field.min_items == min_items
    assert field.max_items == max_items
    assert field.unique_items == unique_items


# Generated at 2022-06-18 12:17:14.149282
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    from typesystem.unions import Union
    assert (String() | Integer()) == Union(any_of=[String(), Integer()])
    assert (String() | Integer() | String()) == Union(any_of=[String(), Integer(), String()])
    assert (String() | Integer() | String() | Integer()) == Union(any_of=[String(), Integer(), String(), Integer()])
    assert (String() | Integer() | String() | Integer() | String()) == Union(any_of=[String(), Integer(), String(), Integer(), String()])
    assert (String() | Integer() | String() | Integer() | String() | Integer()) == Union(any_of=[String(), Integer(), String(), Integer(), String(), Integer()])
    assert (String() | Integer() | String() | Integer() | String() | Integer() | String())

# Generated at 2022-06-18 12:17:24.846924
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:17:37.383005
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:17:44.240877
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:17:53.534188
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    from typesystem.types import Union
    field1 = String()
    field2 = Integer()
    union = field1 | field2
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]
    field3 = String()
    union2 = union | field3
    assert isinstance(union2, Union)
    assert union2.any_of == [field1, field2, field3]
    union3 = field3 | union
    assert isinstance(union3, Union)
    assert union3.any_of == [field3, field1, field2]



# Generated at 2022-06-18 12:18:02.583815
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    assert choice.validate("", strict=False) == None
    assert choice.validate(None, strict=False) == None



# Generated at 2022-06-18 12:18:04.351708
# Unit test for constructor of class String
def test_String():
    assert String(title="test", description="test", allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)


# Generated at 2022-06-18 12:18:08.674753
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const == None
    assert Const(const=1).const == 1
    assert Const(const="a").const == "a"
    assert Const(const=True).const == True
    assert Const(const=False).const == False


# Generated at 2022-06-18 12:18:40.109223
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:52.525690
# Unit test for method validate of class String
def test_String_validate():
    assert String(max_length=5).validate("12345") == "12345"
    assert String(max_length=5).validate("123456") == "12345"
    assert String(min_length=5).validate("12345") == "12345"
    assert String(min_length=5).validate("1234") == "1234"
    assert String(pattern="^[0-9]+$").validate("12345") == "12345"
    assert String(pattern="^[0-9]+$").validate("abcde") == "abcde"
    assert String(format="date").validate("2019-01-01") == "2019-01-01"
    assert String(format="date").validate("2019-01-01") == "2019-01-01"

# Generated at 2022-06-18 12:19:04.308796
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=None).const == None
    assert Const(const="hello").const == "hello"
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const=1.0).const == 1.0
    assert Const(const=[]).const == []
    assert Const(const={}).const == {}
    assert Const(const=()).const == ()
    assert Const(const=set()).const == set()
    assert Const(const=frozenset()).const == frozenset()
    assert Const(const=range(0,10)).const == range(0,10)
    assert Const(const=bytearray(b"hello")).const == bytearray(b"hello")
    assert Const

# Generated at 2022-06-18 12:19:13.796654
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False)

# Generated at 2022-06-18 12:19:20.134753
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    assert choice.validate("", strict=True) == ""



# Generated at 2022-06-18 12:19:31.944570
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:19:36.604369
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:19:45.077851
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError) as excinfo:
        choice.validate("d")
    assert excinfo.value.code == "choice"
    assert choice.validate("") == None
    with pytest.raises(ValidationError) as excinfo:
        choice.validate("")
    assert excinfo.value.code == "required"



# Generated at 2022-06-18 12:19:48.894741
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:19:53.069967
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:20:10.799695
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate of class Union
    # Test case 1
    any_of = [String()]
    union = Union(any_of)
    assert union.validate("test") == "test"

    # Test case 2
    any_of = [String()]
    union = Union(any_of)
    assert union.validate(1) == "1"

    # Test case 3
    any_of = [String()]
    union = Union(any_of)
    assert union.validate(1.0) == "1.0"

    # Test case 4
    any_of = [String()]
    union = Union(any_of)
    assert union.validate(True) == "True"

    # Test case 5
    any_of = [String()]
    union = Union(any_of)

# Generated at 2022-06-18 12:20:18.410698
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const is None
    assert Const(const=True).const is True
    assert Const(const=False).const is False
    assert Const(const=1).const == 1
    assert Const(const=1.0).const == 1.0
    assert Const(const="").const == ""
    assert Const(const="a").const == "a"
    assert Const(const=[]).const == []
    assert Const(const=[1, 2, 3]).const == [1, 2, 3]
    assert Const(const={}).const == {}
    assert Const(const={"a": 1, "b": 2}).const == {"a": 1, "b": 2}



# Generated at 2022-06-18 12:20:29.337321
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:20:38.118277
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert field.validate(None) == None
    assert field.validate("1") == "1"
    assert field.validate("2") == "2"
    try:
        field.validate("3")
    except ValidationError as e:
        assert e.code == "choice"
    try:
        field.validate("")
    except ValidationError as e:
        assert e.code == "required"
    try:
        field.validate(None, strict=True)
    except ValidationError as e:
        assert e.code == "null"

# Generated at 2022-06-18 12:20:49.868899
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:02.194456
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:21:10.663322
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:23.032691
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("") == None
    assert choice.validate("c") == None

# Generated at 2022-06-18 12:21:24.902687
# Unit test for constructor of class String
def test_String():
    assert String(title="title", description="description", default="default", allow_null=True)


# Generated at 2022-06-18 12:21:35.054693
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic import BaseModel
    from pydantic.fields import Field
    from pydantic.validators import validator
    from pydantic.types import conint, conbytes, conlist, confloat, condict, constr, conbool
    from pydantic.main import BaseModel
    from pydantic.schema import schema
    from pydantic.error_wrappers import ValidationError
    from pydantic.fields import Field
    from pydantic.types import conint, conbytes, conlist, confloat, condict, constr, conbool
    from pydantic.validators import validator
    from pydantic.utils import lenient_issubclass
    from pydantic.main import BaseModel
    from pydantic.schema import schema
    from pydantic.error_wrappers import Validation

# Generated at 2022-06-18 12:21:51.896067
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) is None

# Generated at 2022-06-18 12:21:55.157933
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=True)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True


# Generated at 2022-06-18 12:22:05.136103
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=Integer())
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, 3.0]) == [1, 2, 3]
    assert array.validate([1, 2, "3"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1"]) == [1, 2, 3]

# Generated at 2022-06-18 12:22:15.157506
# Unit test for constructor of class Const
def test_Const():
    # Test for constructor of class Const
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.default == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}
    assert const.validation_error == ValidationError
    assert const.validation_error_class == ValidationError
    assert const.validation_error_class.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}
    assert const.validation_error_class.messages == []
    assert const.validation_error_class.messages == []
    assert const.valid

# Generated at 2022-06-18 12:22:26.369600
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b"]) == ["a", "b"]
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]


# Generated at 2022-06-18 12:22:34.941977
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:46.217291
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:22:57.368312
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.0) == 1.0
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.1) == 1.1
   