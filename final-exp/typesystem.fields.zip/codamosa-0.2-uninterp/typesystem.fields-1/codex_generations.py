

# Generated at 2022-06-18 12:15:00.466136
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1
    field = String(title="", description="", default=NO_DEFAULT, allow_null=False)
    value = "hello"
    strict = False
    assert field.validate(value, strict=strict) == "hello"

    # Test case 2
    field = String(title="", description="", default=NO_DEFAULT, allow_null=False)
    value = None
    strict = False
    try:
        field.validate(value, strict=strict)
    except ValidationError as error:
        assert error.text == "Must be a string."
        assert error.code == "type"

    # Test case 3
    field = String(title="", description="", default=NO_DEFAULT, allow_null=False)
    value = None
    strict = True

# Generated at 2022-06-18 12:15:09.004023
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('1', '1'), ('2', '2')])
    assert choice.validate('1') == '1'
    assert choice.validate('2') == '2'
    assert choice.validate('3') == '3'
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('') == ''
    assert choice

# Generated at 2022-06-18 12:15:15.259352
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Integer, String
    assert (Integer() | String()).any_of == [Integer(), String()]
    assert (Integer() | String() | Integer()).any_of == [Integer(), String(), Integer()]
    assert (Integer() | (String() | Integer())).any_of == [Integer(), String(), Integer()]



# Generated at 2022-06-18 12:15:25.860637
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Union
    def test_Union_validate():
        # Test for method validate(self, value, strict=False)
        class TestUnion(Union):
            def __init__(self, **kwargs):
                super().__init__(any_of=[String(), Integer()], **kwargs)

        field = TestUnion()
        field.validate("hello")
        field.validate(123)
        with pytest.raises(ValidationError):
            field.validate(None)
        with pytest.raises(ValidationError):
            field.validate(True)
        with pytest.raises(ValidationError):
            field.validate(1.23)

# Generated at 2022-06-18 12:15:32.285080
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, *, strict=False)
    # Unit test for method validate of class Array
    def test_Array_validate():
        # Test for method validate(self, value, *, strict=False)
        class TestArray(Array):
            def __init__(self, **kwargs):
                super().__init__(**kwargs)

        # Test for method validate(self, value, *, strict=False)
        # Unit test for method validate of class Array
        def test_Array_validate():
            # Test for method validate(self, value, *, strict=False)
            class TestArray(Array):
                def __init__(self, **kwargs):
                    super().__init__(**kwargs)

            # Test for method validate(self, value, *, strict=False)
           

# Generated at 2022-06-18 12:15:43.628442
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Integer, String, Union
    from typesystem.fields import Field
    field1 = Field()
    field2 = Field()
    field3 = Field()
    field4 = Field()
    field5 = Field()
    field6 = Field()
    field7 = Field()
    field8 = Field()
    field9 = Field()
    field10 = Field()
    field11 = Field()
    field12 = Field()
    field13 = Field()
    field14 = Field()
    field15 = Field()
    field16 = Field()
    field17 = Field()
    field18 = Field()
    field19 = Field()
    field20 = Field()
    field21 = Field()
    field22 = Field()
    field23 = Field()
    field24 = Field()
    field25 = Field()

# Generated at 2022-06-18 12:15:53.460843
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: None)
    assert field.get_default_value() is None
    field = Field(default=None)
    assert field.get_default_value() is None
    field = Field(default=NO_DEFAULT)
    assert field.get_default_value() is None
    field = Field(default=NO_DEFAULT, allow_null=True)
    assert field.get_default_value() is None
    field = Field(default=NO_DEFAULT, allow_null=False)
    assert field.get_default_value() is None


# Generated at 2022-06-18 12:15:54.947565
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:16:06.125472
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.base import Field
    from typesystem.types import String
    from typesystem.types import Integer
    from typesystem.types import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | field1
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, field1]
    field5 = field1 | field2 | field1
    assert isinstance(field5, Union)
    assert field5.any_of == [field1, field2, field1]


# Generated at 2022-06-18 12:16:11.525360
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "b"), ("c", "d")])
    assert choice.validate("a") == "a"
    assert choice.validate("c") == "c"
    assert choice.validate("b") == "b"
    assert choice.validate("d") == "d"
    assert choice.validate("e") == "e"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(0.0) == 0.0
    assert choice.validate(0.1) == 0.1
    assert choice.validate(0.2) == 0.2


# Generated at 2022-06-18 12:16:34.892346
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:16:45.250385
# Unit test for constructor of class Array

# Generated at 2022-06-18 12:16:55.604600
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:16:59.481763
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") is None
    assert choice.validate("") is None



# Generated at 2022-06-18 12:17:08.673507
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:17:21.074642
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:32.683458
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:39.751914
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")



# Generated at 2022-06-18 12:17:51.065841
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("") == None
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("c")



# Generated at 2022-06-18 12:18:02.095104
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None

# Generated at 2022-06-18 12:18:35.608964
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with null value
    any_of = [String(), Integer()]
    union = Union(any_of=any_of, allow_null=True)
    assert union.validate(None) == None
    # Test with valid value
    assert union.validate('a') == 'a'
    assert union.validate(1) == 1
    # Test with invalid value
    try:
        union.validate(1.1)
        assert False
    except ValidationError as e:
        assert e.messages[0].text == 'Did not match any valid type.'


# Generated at 2022-06-18 12:18:45.770833
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    obj.validate({"name": "John", "age": 20})
    # Test case 2
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    obj.validate({"name": "John", "age": "20"})
    # Test case 3
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    obj.validate

# Generated at 2022-06-18 12:18:58.760482
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("a") == "a"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("b") == "b"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("c") == "c"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("") == ""
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate(None) == None
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate(1) == 1

# Generated at 2022-06-18 12:19:01.327988
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error(1) == ValidationResult(value=None, error=None)


# Generated at 2022-06-18 12:19:11.273482
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=String())
    assert array.validate(["a", "b"]) == ["a", "b"]
    assert array.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert array.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert array.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert array.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:19:22.844434
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:35.089559
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:19:41.866388
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value, *, strict=False):
            if value == 1:
                return value
            else:
                raise ValidationError(text="error", code="error")

    field = TestField()
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(2).error.text == "error"
    assert field.validate_or_error(2).error.code == "error"

# Generated at 2022-06-18 12:19:45.661571
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Generated at 2022-06-18 12:19:50.746041
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationResult
    from typesystem.fields import String
    field = String()
    assert field.validate_or_error("abc") == ValidationResult(value="abc", error=None)
    assert field.validate_or_error(123) == ValidationResult(value=None, error=ValidationError(text="Must be a string.", code="invalid"))


# Generated at 2022-06-18 12:20:19.147827
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.0) == 1.0
    assert choice.validate(1.1) == 1.1
    assert choice.validate("1") == "1"
    assert choice.validate("1.1") == "1.1"
   

# Generated at 2022-06-18 12:20:23.060456
# Unit test for constructor of class String
def test_String():
    assert String(title="name", description="name of the person", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)


# Generated at 2022-06-18 12:20:33.737265
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:20:44.152839
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:20:56.663289
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    field = Union([String(), Number()])
    value = "hello"
    result = field.validate(value)
    assert result == "hello"
    # Test case 2
    field = Union([String(), Number()])
    value = 1
    result = field.validate(value)
    assert result == 1
    # Test case 3
    field = Union([String(), Number()])
    value = True
    try:
        result = field.validate(value)
    except ValidationError as e:
        assert e.messages[0].code == "union"
    # Test case 4
    field = Union([String(), Number()])
    value = None
    try:
        result = field.validate(value)
    except ValidationError as e:
        assert e.messages[0].code

# Generated at 2022-06-18 12:21:07.291287
# Unit test for method validate of class Number

# Generated at 2022-06-18 12:21:19.925359
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:29.123080
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Integer()]
    value = "hello"
    strict = False
    result = Union(any_of).validate(value, strict=strict)
    assert result == value

    # Test case 2
    any_of = [String(), Integer()]
    value = "hello"
    strict = True
    result = Union(any_of).validate(value, strict=strict)
    assert result == value

    # Test case 3
    any_of = [String(), Integer()]
    value = 123
    strict = False
    result = Union(any_of).validate(value, strict=strict)
    assert result == value

    # Test case 4
    any_of = [String(), Integer()]
    value = 123
    strict = True

# Generated at 2022-06-18 12:21:39.398329
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=100, maximum=200),
        Integer(minimum=200, maximum=300),
    ]
    union = Union(any_of=any_of)
    value = 150
    assert union.validate(value) == value
    # Test case 2
    any_of = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=100, maximum=200),
        Integer(minimum=200, maximum=300),
    ]
    union = Union(any_of=any_of)
    value = 400

# Generated at 2022-06-18 12:21:48.069534
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"
    assert field.validate("test") == "test"

# Generated at 2022-06-18 12:22:19.932596
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = "hello"
    assert union.validate(value) == value

    # Test case 2
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = 1
    assert union.validate(value) == value

    # Test case 3
    any_of = [Field(type="string"), Field(type="integer")]
    union = Union(any_of)
    value = 1.0
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].text == "Did not match any valid type."
        assert e.mess

# Generated at 2022-06-18 12:22:29.394669
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c")

# Generated at 2022-06-18 12:22:39.146443
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1)

# Generated at 2022-06-18 12:22:45.834747
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None


# Generated at 2022-06-18 12:22:57.059276
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=1).validate(1) == 1
    assert Number(minimum=1).validate(2) == 2
    assert Number(minimum=1).validate(0) == 0
    assert Number(minimum=1).validate(-1) == -1
    assert Number(minimum=1).validate(-2) == -2
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(2.5) == 2.5
    assert Number(minimum=1).validate(0.5) == 0.5
    assert Number(minimum=1).validate(-1.5) == -1.5
    assert Number(minimum=1).validate(-2.5) == -2.5
    assert Number(minimum=1).validate(1.5)