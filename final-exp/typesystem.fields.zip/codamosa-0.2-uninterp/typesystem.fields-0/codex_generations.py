

# Generated at 2022-06-18 12:14:54.557643
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=0, maximum=10).validate(5) == 5
    assert Number(minimum=0, maximum=10).validate(0) == 0
    assert Number(minimum=0, maximum=10).validate(10) == 10
    assert Number(minimum=0, maximum=10).validate(0.5) == 0.5
    assert Number(minimum=0, maximum=10).validate(10.5) == 10.5
    assert Number(minimum=0, maximum=10).validate(10.5) == 10.5
    assert Number(minimum=0, maximum=10).validate(0.5) == 0.5
    assert Number(minimum=0, maximum=10).validate(10.5) == 10.5
    assert Number(minimum=0, maximum=10).validate(10.5)

# Generated at 2022-06-18 12:15:05.623711
# Unit test for method serialize of class String
def test_String_serialize():
    field = String(format='date')
    assert field.serialize('2019-01-01') == '2019-01-01'
    assert field.serialize(datetime.date(2019, 1, 1)) == '2019-01-01'
    assert field.serialize(datetime.datetime(2019, 1, 1)) == '2019-01-01'

    field = String(format='time')
    assert field.serialize('12:00:00') == '12:00:00'
    assert field.serialize(datetime.time(12, 0, 0)) == '12:00:00'
    assert field.serialize(datetime.datetime(2019, 1, 1, 12, 0, 0)) == '12:00:00'

    field = String(format='datetime')

# Generated at 2022-06-18 12:15:13.050294
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:15:24.586622
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:25.658370
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default = "default")
    assert field.get_default_value() == "default"


# Generated at 2022-06-18 12:15:36.008228
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="datetime").serialize("2019-01-01T12:00:00") == "2019-01-01T12:00:00"
    assert String(format="uuid").serialize("f3b3d8e8-9c2e-4c5a-a8b7-a8f9d8f7b3b3") == "f3b3d8e8-9c2e-4c5a-a8b7-a8f9d8f7b3b3"

# Generated at 2022-06-18 12:15:47.350109
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, **kwargs: typing.Any) -> None:
            super().__init__(items=items, **kwargs)
    class TestString(String):
        def __init__(self, *, pattern: str = None, **kwargs: typing.Any) -> None:
            super().__init__(pattern=pattern, **kwargs)
    class TestNumber(Number):
        def __init__(self, *, minimum: typing.Union[float, int] = None, maximum: typing.Union[float, int] = None, **kwargs: typing.Any) -> None:
            super().__init__(minimum=minimum, maximum=maximum, **kwargs)

# Generated at 2022-06-18 12:15:54.070110
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:16:00.020519
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:16:05.515119
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:16:28.113070
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("") == ""



# Generated at 2022-06-18 12:16:33.995541
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    print("Test case 1")
    field = Array(items=Integer())
    value = [1, 2, 3]
    result = field.validate(value)
    assert result == [1, 2, 3]

    # Test case 2
    print("Test case 2")
    field = Array(items=Integer())
    value = [1, 2, 3, "4"]
    try:
        result = field.validate(value)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must be an integer.",
                code="type",
                key=3,
            )
        ]
    else:
        assert False

    # Test case 3
    print("Test case 3")
    field = Array(items=Integer())

# Generated at 2022-06-18 12:16:43.754346
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Array
    def test_Array_validate():
        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            pass



# Generated at 2022-06-18 12:16:54.473168
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any):
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)
    # Test case 1

# Generated at 2022-06-18 12:17:04.828253
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=String(min_length=1, max_length=10),
        additional_items=False,
        min_items=1,
        max_items=3,
        unique_items=True,
    )
    value = ["a", "b", "c"]
    field.validate(value)
    value = ["a", "b", "c", "d"]
    with pytest.raises(ValidationError):
        field.validate(value)
    value = ["a", "b", "c", "a"]
    with pytest.raises(ValidationError):
        field.validate(value)
    value = ["a", "b", "c", "d"]

# Generated at 2022-06-18 12:17:16.009564
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:17:24.287788
# Unit test for constructor of class String
def test_String():
    s = String(title="title", description="description", default="default", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=1, min_length=1, pattern="pattern", format="format")
    assert s.title == "title"
    assert s.description == "description"
    assert s.default == "default"
    assert s.allow_null == True
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.max_length == 1
    assert s.min_length == 1
    assert s.pattern == "pattern"
    assert s.format == "format"


# Generated at 2022-06-18 12:17:37.021809
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda : 1)
    assert field.get_default_value() == 1
    field = Field(default=lambda : 1, allow_null=True)
    assert field.get_default_value() == 1
    field = Field(default=lambda : 1, allow_null=True)
    assert field.get_default_value() == 1
    field = Field(default=lambda : 1, allow_null=True)
    assert field.get_default_value() == 1
    field = Field(default=lambda : 1, allow_null=True)
    assert field.get_default_value() == 1

# Generated at 2022-06-18 12:17:44.058799
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:17:53.852118
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value, *, strict=False):
            return value
    field = TestField()
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(1).error is None
    assert field.validate_or_error(None).value is None
    assert field.validate_or_error(None).error is None
    assert field.validate_or_error(None, strict=True).error.code == 'null'
    assert field.validate_or_error(None, strict=True).error.text == 'This field may not be null.'


# Generated at 2022-06-18 12:18:26.051243
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String(max_length=10)
    field2 = Integer(max_value=100)
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | field2
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, field2]



# Generated at 2022-06-18 12:18:36.324307
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(1) == 1
    assert num.validate(1.0) == 1.0
    assert num.validate(1.5) == 1.5
    assert num.validate(1.5, strict=True) == 1.5
    assert num.validate(1.5, strict=False) == 1.5
    assert num.validate(1.5, strict=True) == 1.5
    assert num.validate(1.5, strict=False) == 1.5
    assert num.validate(1.5, strict=True) == 1.5
    assert num.validate(1.5, strict=False) == 1.5
    assert num.validate(1.5, strict=True) == 1.5

# Generated at 2022-06-18 12:18:46.618123
# Unit test for constructor of class Const
def test_Const():
    assert Const(1).const == 1
    assert Const(None).const == None
    assert Const(True).const == True
    assert Const(False).const == False
    assert Const("a").const == "a"
    assert Const(1.0).const == 1.0
    assert Const([]).const == []
    assert Const([1,2,3]).const == [1,2,3]
    assert Const({}).const == {}
    assert Const({"a":1}).const == {"a":1}
    assert Const({"a":1, "b":2}).const == {"a":1, "b":2}
    assert Const({"a":1, "b":2, "c":3}).const == {"a":1, "b":2, "c":3}

# Generated at 2022-06-18 12:18:48.833520
# Unit test for constructor of class String
def test_String():
    assert String(title="test", description="test", default="test", allow_null=True)


# Generated at 2022-06-18 12:19:01.605914
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String(max_length=10)
    field2 = Integer(max_value=100)
    union = field1 | field2
    assert isinstance(union, Union)
    assert len(union.any_of) == 2
    assert union.any_of[0] == field1
    assert union.any_of[1] == field2
    union = field1 | field2 | field1
    assert isinstance(union, Union)
    assert len(union.any_of) == 3
    assert union.any_of[0] == field1
    assert union.any_of[1] == field2
    assert union.any_of[2] == field1

# Generated at 2022-06-18 12:19:04.138853
# Unit test for constructor of class Const
def test_Const():
    const = Const(const = "abc")
    assert const.const == "abc"
    assert const.allow_null == False


# Generated at 2022-06-18 12:19:13.420487
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with a single child
    child = String()
    union = Union([child])
    assert union.validate("test") == "test"
    assert union.validate(123) == "123"
    assert union.validate(None) == None
    assert union.validate(True) == "True"
    assert union.validate(False) == "False"
    assert union.validate(["test"]) == "['test']"
    assert union.validate({"test": "test"}) == "{'test': 'test'}"
    assert union.validate({"test": "test"}) == "{'test': 'test'}"
    assert union.validate({"test": "test"}) == "{'test': 'test'}"

# Generated at 2022-06-18 12:19:24.369682
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String(title='title1', description='description1')
    field2 = Integer(title='title2', description='description2')
    assert isinstance(field1 | field2, Union)
    assert field1 | field2 == Union(any_of=[field1, field2])
    assert field1 | field2 == Union(any_of=[field2, field1])
    assert field1 | field2 == Union(any_of=[field1, field2, field1])
    assert field1 | field2 == Union(any_of=[field2, field1, field2])
    assert field1 | field2 == Union(any_of=[field1, field2, field1, field2])
    assert field1 | field2

# Generated at 2022-06-18 12:19:36.468894
# Unit test for method validate of class Union
def test_Union_validate():
    # Test the case where value is None and allow_null is True
    any_of = [String(max_length=10), Integer(minimum=0, maximum=10)]
    union = Union(any_of)
    assert union.validate(None) == None
    # Test the case where value is None and allow_null is False
    any_of = [String(max_length=10), Integer(minimum=0, maximum=10)]
    union = Union(any_of, allow_null=False)
    try:
        union.validate(None)
    except ValidationError as e:
        assert e.messages()[0].text == "May not be null."
    # Test the case where value is not None and allow_null is True

# Generated at 2022-06-18 12:19:46.342994
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String(max_length=10)
    field2 = Integer(minimum=0, maximum=100)
    field3 = Union([field1, field2])
    assert field3.any_of == [field1, field2]
    field4 = field1 | field2
    assert field4.any_of == [field1, field2]
    field5 = field1 | field2 | field3
    assert field5.any_of == [field1, field2, field1, field2]
    field6 = field5 | field4
    assert field6.any_of == [field1, field2, field1, field2, field1, field2]



# Generated at 2022-06-18 12:20:06.814944
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.1) == 1.1

# Generated at 2022-06-18 12:20:16.642299
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate(None) is None
    with pytest.raises(ValidationError):
        field.validate("c")

# Generated at 2022-06-18 12:20:26.994961
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(const=None, allow_null=True)
    with pytest.raises(AssertionError):
        Const(const=None, allow_null=False)
    Const(const=None, allow_null=None)
    Const(const=None)
    Const(const=True)
    Const(const=False)
    Const(const=1)
    Const(const=1.0)
    Const(const="")
    Const(const="a")
    Const(const=())
    Const(const=(1,))
    Const(const=[])
    Const(const=[1])
    Const(const={})
    Const(const={"a": 1})


# Generated at 2022-06-18 12:20:35.232564
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with a valid value
    field = Union([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    # Test with an invalid value
    with pytest.raises(ValidationError):
        field.validate(1.1)
    # Test with a null value
    with pytest.raises(ValidationError):
        field.validate(None)
    # Test with a null value and allow_null=True
    field = Union([Integer(), String()], allow_null=True)
    assert field.validate(None) is None



# Generated at 2022-06-18 12:20:46.054987
# Unit test for constructor of class Const
def test_Const():
    # Test case 1:
    #   const = None
    #   allow_null = False
    #   expected = None
    #   actual = None
    #   assert expected == actual
    const = None
    allow_null = False
    expected = None
    actual = Const(const, allow_null=allow_null)
    assert expected == actual

    # Test case 2:
    #   const = None
    #   allow_null = True
    #   expected = None
    #   actual = None
    #   assert expected == actual
    const = None
    allow_null = True
    expected = None
    actual = Const(const, allow_null=allow_null)
    assert expected == actual

    # Test case 3:
    #   const = 1
    #   allow_null = False
    #   expected = 1
   

# Generated at 2022-06-18 12:20:51.742222
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['a', 'b', 'c'])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    assert choice.validate('c') == 'c'
    with pytest.raises(ValidationError):
        choice.validate('d')



# Generated at 2022-06-18 12:21:03.844828
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3.0]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]

# Generated at 2022-06-18 12:21:08.210252
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate("true") == True
    assert field.validate("false") == False
    assert field.validate("on") == True
    assert field.validate("off") == False
    assert field.validate("1") == True
    assert field.validate("0") == False
    assert field.validate("") == False
    assert field.validate(1) == True
    assert field.validate(0) == False
    assert field.validate("null") == None
    assert field.validate("none") == None
    assert field.validate("") == False
    assert field.validate("") == False

# Generated at 2022-06-18 12:21:20.880460
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(max_length=10), String(max_length=20)]
    field = Union(any_of)
    value = "12345678901"
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages()[0].text == "Must be no more than 10 characters."
        assert e.messages()[0].code == "max_length"
        assert e.messages()[0].index == []
    else:
        assert False

    # Test case 2
    any_of = [String(max_length=10), String(max_length=20)]
    field = Union(any_of)
    value = "12345678901"

# Generated at 2022-06-18 12:21:29.555142
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1
    field = String(title='Name', description='Name of the person', default='', allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None, allow_null=False)
    value = 'abc'
    strict = False
    assert field.validate(value, strict=strict) == 'abc'
    # Test case 2
    field = String(title='Name', description='Name of the person', default='', allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None, allow_null=False)
    value = 'abc'
    strict = True
    assert field.validate(value, strict=strict) == 'abc'
    # Test case 3

# Generated at 2022-06-18 12:21:43.883042
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b", "c"]).validate("a") == "a"
    assert Choice(choices=["a", "b", "c"]).validate("b") == "b"
    assert Choice(choices=["a", "b", "c"]).validate("c") == "c"
    assert Choice(choices=["a", "b", "c"]).validate("d") == "d"
    assert Choice(choices=["a", "b", "c"]).validate("") == ""
    assert Choice(choices=["a", "b", "c"]).validate(None) == None
    assert Choice(choices=["a", "b", "c"]).validate(True) == True

# Generated at 2022-06-18 12:21:45.236201
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1


# Generated at 2022-06-18 12:21:54.479295
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=None)
    assert const.const == None
    assert const.allow_null == True
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.validate(value=None) == None
    assert const.validate(value=1) == 1
    assert const.validate(value=None, strict=True) == None
    assert const.validate(value=1, strict=True) == 1
    assert const.validate_or_error(value=None) == (None, None)
    assert const.validate_or_error(value=1) == (1, None)
    assert const.validate_or_error(value=None, strict=True) == (None, None)
    assert const.validate

# Generated at 2022-06-18 12:21:55.679241
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1


# Generated at 2022-06-18 12:22:05.578433
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {'name': String(max_length=10), 'age': Integer(minimum=0, maximum=100)}
    pattern_properties = {'^[A-Za-z]*$': String(max_length=10)}
    additional_properties = String(max_length=10)
    property_names = String(max_length=10)
    min_properties = 1
    max_properties = 10
    required = ['name', 'age']
    obj = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    value = {'name': 'John', 'age': 20, 'address': '123 Main Street'}

# Generated at 2022-06-18 12:22:15.689972
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
    assert Number().validate(1.123456789) == 1.123456789
   

# Generated at 2022-06-18 12:22:17.928608
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:22:28.757392
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.1) == 1.1
    assert Number().validate("1") == 1
    assert Number().validate("1.1") == 1.1
    assert Number().validate("1.1.1") == 1.1
    assert Number().validate("1.1.1.1") == 1.1
    assert Number().validate("1.1.1.1.1") == 1.1
    assert Number().validate("1.1.1.1.1.1") == 1.1
    assert Number().validate("1.1.1.1.1.1.1") == 1.1
    assert Number().validate("1.1.1.1.1.1.1.1") == 1.1
    assert Number().valid

# Generated at 2022-06-18 12:22:38.343511
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:46.594458
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for method validate(self, value, *, strict=False)
    # Tests if the Object class validates correctly
    # Arrange
    properties = {
        "name": String(max_length=20),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    # Act
    value = obj.validate({"name": "John", "age": 20})
    # Assert
    assert value == {"name": "John", "age": 20}

