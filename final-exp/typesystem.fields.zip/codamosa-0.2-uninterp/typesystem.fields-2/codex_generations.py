

# Generated at 2022-06-18 12:14:42.004062
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any) -> None:
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)

# Generated at 2022-06-18 12:14:54.425557
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = "hello"
    union.validate(value)
    # Test case 2
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = 1
    union.validate(value)
    # Test case 3
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = 1.1
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].code == "union"
    # Test case 4
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = None

# Generated at 2022-06-18 12:15:05.532885
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate (line 562)
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)
    # Test for method validate (line 562)
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)
    # Test for method validate (line 562)
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)
    # Test for method validate (line 562

# Generated at 2022-06-18 12:15:17.118727
# Unit test for method validate of class String
def test_String_validate():
    test_string = String()
    assert test_string.validate("Hello") == "Hello"
    assert test_string.validate("Hello", strict=True) == "Hello"
    assert test_string.validate(None) == None
    assert test_string.validate(None, strict=True) == None
    assert test_string.validate(123) == None
    assert test_string.validate(123, strict=True) == None
    assert test_string.validate(123.456) == None
    assert test_string.validate(123.456, strict=True) == None
    assert test_string.validate(True) == None
    assert test_string.validate(True, strict=True) == None
    assert test_string.validate(False) == None

# Generated at 2022-06-18 12:15:27.121432
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:15:38.793738
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [
        String(max_length=10),
        Integer(),
        Boolean(),
        Float(),
        DateTime(),
        Date(),
        Time(),
        Decimal(),
        Object(
            properties={
                "name": String(max_length=10),
                "age": Integer(),
                "is_active": Boolean(),
            }
        ),
        Array(
            items=[
                String(max_length=10),
                Integer(),
                Boolean(),
                Float(),
                DateTime(),
                Date(),
                Time(),
                Decimal(),
                Object(
                    properties={
                        "name": String(max_length=10),
                        "age": Integer(),
                        "is_active": Boolean(),
                    }
                ),
            ]
        ),
    ]
    array = Array(items=items)
   

# Generated at 2022-06-18 12:15:50.241447
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:57.065466
# Unit test for method validate of class Union
def test_Union_validate():
    from . import String
    from . import Number
    from . import Boolean
    from . import Null
    from . import ValidationError
    from . import Message
    from . import Field
    from . import Union
    from . import Any
    from . import Object
    from . import Array
    from . import Text
    from . import Date
    from . import Time
    from . import DateTime
    from . import Uniqueness
    from . import Enum
    from . import Const
    from . import OneOf
    from . import Not
    from . import AllOf
    from . import AnyOf
    from . import Reference
    from . import FormatChecker
    from . import Draft4Validator
    from . import Draft6Validator
    from . import Draft7Validator
    from . import Draft201909Validator
    from . import validates
   

# Generated at 2022-06-18 12:16:02.976969
# Unit test for constructor of class Choice
def test_Choice():
    choices = [
        ("a", "a"),
        ("b", "b"),
        ("c", "c"),
    ]
    field = Choice(choices=choices)
    assert field.choices == choices
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"
    assert field.validate("") == ""
    assert field.validate(None) == None
    assert field.validate(None, strict=True) == None
    assert field.validate("", strict=True) == ""
    assert field.validate("a", strict=True) == "a"
    assert field.validate("b", strict=True) == "b"


# Generated at 2022-06-18 12:16:13.797099
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    field = Union([String()])
    value = 'abc'
    expected = 'abc'
    actual = field.validate(value)
    assert actual == expected
    # Test case 2
    field = Union([String()])
    value = 123
    expected = 'abc'
    actual = field.validate(value)
    assert actual == expected
    # Test case 3
    field = Union([String()])
    value = None
    expected = 'abc'
    actual = field.validate(value)
    assert actual == expected
    # Test case 4
    field = Union([String()])
    value = 'abc'
    expected = 'abc'
    actual = field.validate(value)
    assert actual == expected
    # Test case 5
    field = Union([String()])
    value = 123

# Generated at 2022-06-18 12:16:34.839402
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="datetime").serialize("2019-01-01T12:00:00") == "2019-01-01T12:00:00"
    assert String(format="uuid").serialize("6ba7b810-9dad-11d1-80b4-00c04fd430c8") == "6ba7b810-9dad-11d1-80b4-00c04fd430c8"



# Generated at 2022-06-18 12:16:45.203744
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("d")
    choice = Choice

# Generated at 2022-06-18 12:16:55.520996
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == "3"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(2) == 2
    assert choice.validate(3) == 3
    assert choice.validate(0) == 0
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(True) == True

# Generated at 2022-06-18 12:17:05.963120
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Array
    def test_Array_validate():
        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)

        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)



# Generated at 2022-06-18 12:17:18.267925
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=String())
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 2
    field = Array(items=String())
    value = ["a", "b", "c", "d"]
    result = field.validate(value)
    assert result == ["a", "b", "c", "d"]

    # Test case 3
    field = Array(items=String())
    value = ["a", "b", "c", "d", "e"]
    result = field.validate(value)
    assert result == ["a", "b", "c", "d", "e"]

    # Test case 4
    field = Array(items=String())

# Generated at 2022-06-18 12:17:26.614314
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == False
    assert b.validate("abc") == None
    assert b

# Generated at 2022-06-18 12:17:38.431237
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=Integer())
    value = [1, 2, 3]
    expected = [1, 2, 3]
    actual = field.validate(value)
    assert actual == expected

    # Test case 2
    field = Array(items=Integer())
    value = [1, 2, "3"]
    expected = ValidationError(messages=[Message(text="Must be an integer.", code="type", index=[2])])
    actual = field.validate(value)
    assert actual == expected

    # Test case 3
    field = Array(items=Integer())
    value = [1, 2, 3, 4, 5, 6]
    expected = ValidationError(messages=[Message(text="Must have no more than 3 items.", code="max_items")])
    actual = field.validate

# Generated at 2022-06-18 12:17:48.873885
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("a") == "a"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("b") == "b"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("c") == "c"
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate("") == ""
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate(None) == None
    assert Choice(choices=[("a", "a"), ("b", "b")]).validate(1) == 1

# Generated at 2022-06-18 12:17:58.151111
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="datetime").serialize("2019-01-01T12:00:00") == "2019-01-01T12:00:00"
    assert String(format="uuid").serialize("123e4567-e89b-12d3-a456-426655440000") == "123e4567-e89b-12d3-a456-426655440000"



# Generated at 2022-06-18 12:18:08.569745
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=Integer())
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, 3.0]) == [1, 2, 3]
    assert array.validate([1, 2, "3"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1.0"]) == [1, 2, 3]
    assert array.validate([1, 2, "3.1.0.0"]) == [1, 2, 3]

# Generated at 2022-06-18 12:18:32.191254
# Unit test for method validate of class Object
def test_Object_validate():
    # Test with properties
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "gender": Choice(choices=["male", "female"]),
    }
    obj = Object(properties=properties)
    assert obj.validate({"name": "John", "age": 20, "gender": "male"}) == {
        "name": "John",
        "age": 20,
        "gender": "male",
    }

    # Test with pattern_properties
    pattern_properties = {
        "^[a-z]+$": String(required=True),
        "^[0-9]+$": Integer(minimum=0, maximum=100),
    }
    obj = Object(pattern_properties=pattern_properties)

# Generated at 2022-06-18 12:18:40.213049
# Unit test for method validate of class Choice

# Generated at 2022-06-18 12:18:52.730353
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(1) == 1
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.validate(1.0) == 1.0
    assert num.valid

# Generated at 2022-06-18 12:18:55.591001
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field.default = 'default'
    assert field.get_default_value() == 'default'

# Generated at 2022-06-18 12:19:03.865346
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:19:08.043795
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    assert (String() | Integer()).any_of == [String(), Integer()]
    assert (String() | Integer() | String()).any_of == [String(), Integer(), String()]
    assert (String() | (Integer() | String())).any_of == [String(), Integer(), String()]
    assert ((String() | Integer()) | String()).any_of == [String(), Integer(), String()]



# Generated at 2022-06-18 12:19:18.714259
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class TestField(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
            super().__init__(title=title, description=description, default=default, allow_null=allow_null)
    # Test case 1
    test_field = TestField(title="", description="", default=NO_DEFAULT, allow_null=False)
    assert test_field.get_default_value() is None
    # Test case 2
    test_field = TestField(title="", description="", default=1, allow_null=False)
    assert test_field.get_default_value() == 1
    # Test case 3

# Generated at 2022-06-18 12:19:29.698477
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:41.691483
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        pass
    class Field2(Field):
        pass
    class Field3(Field):
        pass
    class Field4(Field):
        pass
    class Field5(Field):
        pass
    class Field6(Field):
        pass
    class Field7(Field):
        pass
    class Field8(Field):
        pass
    class Field9(Field):
        pass
    class Field10(Field):
        pass
    class Field11(Field):
        pass
    class Field12(Field):
        pass
    class Field13(Field):
        pass
    class Field14(Field):
        pass
    class Field15(Field):
        pass
    class Field16(Field):
        pass
    class Field17(Field):
        pass
    class Field18(Field):
        pass
   

# Generated at 2022-06-18 12:19:51.428565
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("a", "a"), ("b", "b")])
    assert c.validate("a") == "a"
    assert c.validate("b") == "b"
    with pytest.raises(ValidationError):
        c.validate("c")
    with pytest.raises(ValidationError):
        c.validate("")
    c = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert c.validate("a") == "a"
    assert c.validate("b") == "b"
    assert c.validate("") == None
    assert c.validate(None) == None
    with pytest.raises(ValidationError):
        c.validate("c")

# Generated at 2022-06-18 12:20:02.734522
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 2)
    assert field.get_default_value() == 2


# Generated at 2022-06-18 12:20:13.604623
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const is None
    assert Const(const=True).const is True
    assert Const(const=False).const is False
    assert Const(const=1).const == 1
    assert Const(const=1.0).const == 1.0
    assert Const(const="1").const == "1"
    assert Const(const=[]).const == []
    assert Const(const={}).const == {}
    assert Const(const=()).const == ()
    assert Const(const=set()).const == set()
    assert Const(const=frozenset()).const == frozenset()
    assert Const(const=range(1)).const == range(1)
    assert Const(const=b"1").const == b"1"

# Generated at 2022-06-18 12:20:26.153891
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:20:36.247932
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        test = Array(items=Integer())
    serializer = TestSerializer()
    assert serializer.serialize({"test": [1, 2, 3]}) == {"test": [1, 2, 3]}
    assert serializer.serialize({"test": [1, 2, 3, 4]}) == {"test": [1, 2, 3, 4]}
    assert serializer.serialize({"test": [1, 2, 3, 4, 5]}) == {"test": [1, 2, 3, 4, 5]}
    assert serializer.serialize({"test": [1, 2, 3, 4, 5, 6]}) == {"test": [1, 2, 3, 4, 5, 6]}

# Generated at 2022-06-18 12:20:47.660034
# Unit test for method validate of class String
def test_String_validate():
    s = String(allow_blank=True)
    assert s.validate(None) == None
    assert s.validate("") == ""
    assert s.validate("abc") == "abc"
    assert s.validate(123) == "123"
    assert s.validate(123.4) == "123.4"
    assert s.validate(True) == "True"
    assert s.validate(False) == "False"
    assert s.validate(["a", "b"]) == "['a', 'b']"
    assert s.validate({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"
    assert s.validate({"a": 1, "b": 2}, strict=True) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-18 12:21:00.051223
# Unit test for constructor of class Const
def test_Const():
    const = Const(1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.default_value == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}
    assert const.validate(1) == 1
    try:
        const.validate(2)
    except ValidationError as e:
        assert e.messages()[0].text == "Must be the value '1'."
        assert e.messages()[0].code == "const"
        assert e.messages()[0].index == None
        assert e.messages()[0].key == None

# Generated at 2022-06-18 12:21:06.409435
# Unit test for constructor of class Const
def test_Const():
    const = Const(1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.default == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.get_default_value() == None
    assert const.get_error_text("only_null") == "Must be null."
    assert const.get_error_text("const") == "Must be the value '{const}'."
    assert const.has_default() == False
    assert const.validate(1) == 1
    assert const.validate_or_error(1) == (1, None)

# Generated at 2022-06-18 12:21:13.204575
# Unit test for method validate of class Union
def test_Union_validate():
    from jsonschema import validate
    from jsonschema.exceptions import ValidationError
    import pytest
    from pydantic import BaseModel, validator
    from pydantic.dataclasses import dataclass
    from pydantic.fields import Field
    from pydantic.types import conint
    from pydantic.utils import lenient_issubclass
    from typing import Any, Dict, List, Optional, Union
    from datetime import datetime
    from pydantic.dataclasses import dataclass
    from pydantic.fields import Field
    from pydantic.types import conint
    from pydantic.utils import lenient_issubclass
    from typing import Any, Dict, List, Optional, Union
    from datetime import datetime
    from pydantic.dataclasses import dataclass

# Generated at 2022-06-18 12:21:25.234566
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=Integer())
    value = [1, 2, 3]
    assert field.validate(value) == value

    # Test case 2
    field = Array(items=Integer())
    value = [1, 2, 3, "4"]
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must be an integer.",
                code="type",
                index=[3],
            )
        ]

    # Test case 3
    field = Array(items=Integer())
    value = [1, 2, 3, None]

# Generated at 2022-06-18 12:21:35.213548
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=["a", "b", "c"]).choices == [("a", "a"), ("b", "b"), ("c", "c")]
    assert Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")]).choices == [("a", "A"), ("b", "B"), ("c", "C")]
    assert Choice(choices=[("a", "A"), "b", ("c", "C")]).choices == [("a", "A"), ("b", "b"), ("c", "C")]
    assert Choice(choices=["a", ("b", "B"), "c"]).choices == [("a", "a"), ("b", "B"), ("c", "c")]

# Generated at 2022-06-18 12:21:47.517009
# Unit test for constructor of class String
def test_String():
    assert String(title="test", description="test", default="test", allow_null=True)


# Generated at 2022-06-18 12:21:55.082030
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:05.043391
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:22:14.902883
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:26.086758
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test 1
    value = None
    allow_null = True
    strict = False
    field = Boolean(allow_null=allow_null)
    assert field.validate(value, strict=strict) == None
    # Test 2
    value = None
    allow_null = False
    strict = False
    field = Boolean(allow_null=allow_null)
    try:
        field.validate(value, strict=strict)
    except ValidationError as error:
        assert error.code == "null"
    # Test 3
    value = True
    allow_null = False
    strict = False
    field = Boolean(allow_null=allow_null)
    assert field.validate(value, strict=strict) == True
    # Test 4
    value = "true"
    allow_null = False
   

# Generated at 2022-06-18 12:22:34.321862
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:45.303620
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:22:56.714090
# Unit test for method validate of class String
def test_String_validate():
    field = String(title="test", description="test", default="test", allow_null=False)
    assert field.validate("test") == "test"
    assert field.validate("") == ""
    assert field.validate(None) == None
    assert field.validate(1) == None
    assert field.validate(1.0) == None
    assert field.validate(True) == None
    assert field.validate(False) == None
    assert field.validate([]) == None
    assert field.validate({}) == None
    assert field.validate(()) == None
    assert field.validate(set()) == None
    assert field.validate(frozenset()) == None
    assert field.validate(bytearray()) == None
    assert field.validate(memoryview()) == None
