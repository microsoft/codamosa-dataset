

# Generated at 2022-06-18 12:14:58.927253
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value, *, strict):
            return value

    field = TestField()
    assert field.validate_or_error(1) == ValidationResult(value=1, error=None)
    assert field.validate_or_error(None) == ValidationResult(value=None, error=None)
    assert field.validate_or_error(1, strict=True) == ValidationResult(value=1, error=None)
    assert field.validate_or_error(None, strict=True) == ValidationResult(value=None, error=None)


# Generated at 2022-06-18 12:15:04.339205
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")



# Generated at 2022-06-18 12:15:06.780679
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error(1) == ValidationResult(value=None, error=NotImplementedError())


# Generated at 2022-06-18 12:15:19.168592
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate([]) == []
    assert field.validate(["a", "b"]) == ["a", "b"]
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:15:28.598842
# Unit test for method serialize of class String
def test_String_serialize():
    field = String(format="date")
    assert field.serialize(None) is None
    assert field.serialize("2019-01-01") == "2019-01-01"
    assert field.serialize(datetime.date(2019, 1, 1)) == "2019-01-01"
    assert field.serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == "2019-01-01"
    assert field.serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=pytz.utc)) == "2019-01-01"
    assert field.serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=pytz.timezone("Europe/Berlin"))) == "2019-01-01"


# Generated at 2022-06-18 12:15:40.364743
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Union
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Union
    class TestUnion(Union):
        def __init__(self, any_of: typing.List[Field], **kwargs: typing.Any):
            super().__init__(any_of, **kwargs)
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:51.646716
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=Integer())
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert array.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert array.validate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert array.validate([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-18 12:16:02.976639
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("abc") == "abc"
    assert s.validate("") == ""
    assert s.validate(None) == None
    assert s.validate(1) == "1"
    assert s.validate(1.1) == "1.1"
    assert s.validate(True) == "True"
    assert s.validate(False) == "False"
    assert s.validate(["a", "b", "c"]) == "['a', 'b', 'c']"
    assert s.validate({"a": "b", "c": "d"}) == "{'a': 'b', 'c': 'd'}"

# Generated at 2022-06-18 12:16:08.103123
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        field = Array(items=Integer())

    serializer = TestSerializer()
    assert serializer.serialize({"field": [1, 2, 3]}) == {"field": [1, 2, 3]}
    assert serializer.serialize({"field": [1, 2, 3.0]}) == {"field": [1, 2, 3]}
    assert serializer.serialize({"field": [1, 2, None]}) == {"field": [1, 2, None]}
    assert serializer.serialize({"field": [1, 2, "3"]}) == {"field": [1, 2, 3]}
    assert serializer.serialize({"field": [1, 2, "3.0"]}) == {"field": [1, 2, 3]}

# Generated at 2022-06-18 12:16:13.222472
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b"], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("") is None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:16:25.920741
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    with pytest.raises(ValidationError):
        field.validate(None)



# Generated at 2022-06-18 12:16:36.924853
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    assert (String() | Integer()).any_of == [String(), Integer()]
    assert (String() | Integer() | String()).any_of == [String(), Integer(), String()]
    assert (String() | Integer() | String() | Integer()).any_of == [String(), Integer(), String(), Integer()]
    assert (String() | Integer() | String() | Integer() | String()).any_of == [String(), Integer(), String(), Integer(), String()]
    assert (String() | Integer() | String() | Integer() | String() | Integer()).any_of == [String(), Integer(), String(), Integer(), String(), Integer()]

# Generated at 2022-06-18 12:16:48.321337
# Unit test for method validate of class Boolean

# Generated at 2022-06-18 12:16:57.681000
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:02.501791
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=None)
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 2)
    assert field.get_default_value() == 2


# Generated at 2022-06-18 12:17:09.770923
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=Integer()).serialize([1, 2, 3]) == [1, 2, 3]
    assert Array(items=Integer()).serialize(None) == None
    assert Array(items=Integer()).serialize([]) == []
    assert Array(items=Integer()).serialize([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert Array(items=Integer()).serialize([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-18 12:17:21.802484
# Unit test for constructor of class Array
def test_Array():
    # Test for constructor of class Array
    # Case 1: items is not None, additional_items is not None, min_items is not None, max_items is not None, exact_items is not None, unique_items is not None
    # Expect:
    # 1. items is not None
    # 2. additional_items is not None
    # 3. min_items is not None
    # 4. max_items is not None
    # 5. exact_items is not None
    # 6. unique_items is not None
    items = [Field(), Field()]
    additional_items = Field()
    min_items = 1
    max_items = 2
    exact_items = 2
    unique_items = True

# Generated at 2022-06-18 12:17:33.627887
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Serializer):
        items = Array(items=Integer())
    assert Test().serialize([1, 2, 3]) == [1, 2, 3]
    assert Test().serialize(None) == None
    assert Test().serialize([1, 2, 3.0]) == [1, 2, 3]
    assert Test().serialize([1, 2, "3"]) == [1, 2, 3]
    assert Test().serialize([1, 2, "3.0"]) == [1, 2, 3]
    assert Test().serialize([1, 2, "3.1"]) == [1, 2, 3]
    assert Test().serialize([1, 2, "3.5"]) == [1, 2, 4]

# Generated at 2022-06-18 12:17:42.526748
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=String())
    assert array.validate(["a", "b", "c"]) == ["a", "b", "c"]
    with pytest.raises(ValidationError):
        array.validate(["a", "b", 1])
    with pytest.raises(ValidationError):
        array.validate(["a", "b", None])
    with pytest.raises(ValidationError):
        array.validate(["a", "b", "c", "d"])
    with pytest.raises(ValidationError):
        array.validate(["a", "b", "c", "d", "e"])

# Generated at 2022-06-18 12:17:54.437032
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:18:23.493484
# Unit test for constructor of class Array
def test_Array():
    items = [String(), Integer()]
    additional_items = False
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items)
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.exact_items == exact_items
    assert array.unique_items == unique_items


# Generated at 2022-06-18 12:18:34.370828
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=100),
        "email": String(format="email"),
        "is_active": Boolean(default=True),
    }
    schema = Object(properties=properties)

    data = {
        "name": "John Doe",
        "age": 40,
        "email": "john@example.com",
    }
    result = schema.validate(data)
    assert result == {
        "name": "John Doe",
        "age": 40,
        "email": "john@example.com",
        "is_active": True,
    }


# Generated at 2022-06-18 12:18:44.534948
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:57.265185
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:05.137900
# Unit test for constructor of class Array
def test_Array():
    field = Array(
        items=String(),
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
        allow_null=False,
        default=None,
    )
    assert field.items == String()
    assert field.additional_items == False
    assert field.min_items == None
    assert field.max_items == None
    assert field.unique_items == False
    assert field.allow_null == False
    assert field.default == None


# Generated at 2022-06-18 12:19:15.281886
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=String())
    assert array.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert array.validate(["a", "b", "c"], strict=True) == ["a", "b", "c"]
    assert array.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert array.validate(["a", "b", "c", "d", "e"], strict=True) == ["a", "b", "c", "d", "e"]
    assert array.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]
   

# Generated at 2022-06-18 12:19:26.387941
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1)

# Generated at 2022-06-18 12:19:32.964679
# Unit test for constructor of class Array
def test_Array():
    array = Array(items=Integer(), additional_items=False, min_items=1, max_items=3, unique_items=False)
    assert array.items == Integer()
    assert array.additional_items == False
    assert array.min_items == 1
    assert array.max_items == 3
    assert array.unique_items == False


# Generated at 2022-06-18 12:19:43.449366
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items=Integer(),
        additional_items=False,
        min_items=None,
        max_items=None,
        unique_items=False,
    )
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3.0]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.0"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1"]) == [1, 2, 3]
    assert field.validate([1, 2, "3.1a"]) == [1, 2, 3]
    assert field

# Generated at 2022-06-18 12:19:50.243216
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:20:18.836523
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any) -> None:
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)


# Generated at 2022-06-18 12:20:29.686394
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:20:38.261900
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:20:48.221780
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Serializer):
        a = Array(items=Integer())

    assert Test.serialize({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}
    assert Test.serialize({"a": [1, 2, 3, 4]}) == {"a": [1, 2, 3, 4]}
    assert Test.serialize({"a": [1, 2, 3, 4, 5]}) == {"a": [1, 2, 3, 4, 5]}
    assert Test.serialize({"a": [1, 2, 3, 4, 5, 6]}) == {"a": [1, 2, 3, 4, 5, 6]}



# Generated at 2022-06-18 12:21:00.623023
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("1", "1"), ("2", "2")])
    assert field.validate("1") == "1"
    assert field.validate("2") == "2"
    with pytest.raises(ValidationError):
        field.validate("3")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert field.validate("1") == "1"
    assert field.validate("2") == "2"
    assert field.validate("") == None
    assert field.validate("3") == None

# Generated at 2022-06-18 12:21:09.732570
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(max_length=5)]
    value = "Hello"
    strict = False
    expected_output = "Hello"
    actual_output = Union(any_of).validate(value, strict=strict)
    assert actual_output == expected_output
    # Test case 2
    any_of = [String(max_length=5)]
    value = "Hello World"
    strict = False
    expected_output = "Hello World"
    actual_output = Union(any_of).validate(value, strict=strict)
    assert actual_output == expected_output
    # Test case 3
    any_of = [String(max_length=5)]
    value = "Hello World"
    strict = False
    expected_output = "Hello World"

# Generated at 2022-06-18 12:21:21.789920
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Serializer):
        field = Array(items=Integer())

    assert Test({"field": [1, 2, 3]}).serialize() == {"field": [1, 2, 3]}
    assert Test({"field": [1, 2, 3]}).serialize(strict=True) == {"field": [1, 2, 3]}
    assert Test({"field": [1, 2, 3]}).serialize(strict=False) == {"field": [1, 2, 3]}
    assert Test({"field": [1, 2, 3]}).serialize(strict=True) == {"field": [1, 2, 3]}
    assert Test({"field": [1, 2, 3]}).serialize(strict=False) == {"field": [1, 2, 3]}



# Generated at 2022-06-18 12:21:30.012824
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("a", "a"), ("b", "b")]
    choice = Choice(choices=choices)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=choices, allow_null=True)
    assert choice.validate(None) == None
    choice = Choice(choices=choices, allow_null=True, allow_blank=True)
    assert choice.validate("") == None
    assert choice.validate("") == None


# Generated at 2022-06-18 12:21:40.135921
# Unit test for method validate of class String
def test_String_validate():
    assert String(max_length=5).validate("12345") == "12345"
    assert String(max_length=5).validate("123456") == "12345"
    assert String(max_length=5).validate("12345", strict=True) == "12345"
    assert String(max_length=5).validate("123456", strict=True) == "12345"
    assert String(max_length=5).validate("12345", strict=False) == "12345"
    assert String(max_length=5).validate("123456", strict=False) == "12345"
    assert String(max_length=5).validate(None) == None
    assert String(max_length=5).validate(None, strict=True) == None
    assert String(max_length=5).valid

# Generated at 2022-06-18 12:21:44.498916
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=String())
    assert field.serialize(["a", "b"]) == ["a", "b"]
    assert field.serialize(["a", 1]) == ["a", "1"]
    assert field.serialize(["a", None]) == ["a", None]
    assert field.serialize(None) == None
    assert field.serialize([]) == []



# Generated at 2022-06-18 12:22:05.043751
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) is None
    with pytest.raises(ValidationError):
        choice.validate("d")
    choice = Choice(choices=["a", "b", "c"], allow_null=True, allow_blank=True)
    assert choice.validate

# Generated at 2022-06-18 12:22:15.106841
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=String())
    value = ["a", "b", "c"]
    assert field.validate(value) == value

    # Test case 2
    field = Array(items=String())
    value = ["a", "b", "c", 1]
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must be a string.",
                code="type",
                index=[3],
            )
        ]
    else:
        assert False

    # Test case 3
    field = Array(items=String())
    value = ["a", "b", "c", None]
    assert field.validate(value) == value

    # Test case 4

# Generated at 2022-06-18 12:22:26.261973
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(1.0) == 1.0
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.validate(1.1) == 1.1
    assert number.valid

# Generated at 2022-06-18 12:22:34.768700
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = "test"
    strict = False
    assert union.validate(value, strict=strict) == "test"

    # Test case 2
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = 1
    strict = False
    assert union.validate(value, strict=strict) == 1

    # Test case 3
    any_of = [String(), Integer()]
    union = Union(any_of)
    value = 1.0
    strict = False
    try:
        union.validate(value, strict=strict)
    except ValidationError as e:
        assert e.messages()[0].code == "union"

# Generated at 2022-06-18 12:22:46.001443
# Unit test for method validate of class String
def test_String_validate():
    # Test case 1
    field = String()
    value = "test"
    assert field.validate(value) == "test"
    # Test case 2
    field = String(allow_blank=True)
    value = ""
    assert field.validate(value) == ""
    # Test case 3
    field = String(allow_blank=True)
    value = None
    assert field.validate(value) == ""
    # Test case 4
    field = String(allow_blank=True, allow_null=True)
    value = None
    assert field.validate(value) == None
    # Test case 5
    field = String(allow_blank=True, allow_null=True)
    value = ""
    assert field.validate(value) == ""
    # Test case 6

# Generated at 2022-06-18 12:22:57.208975
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    assert choice.validate("") == None

# Generated at 2022-06-18 12:23:03.548024
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("e") == "e"
    assert choice.validate("f") == "f"
    assert choice.validate("g") == "g"
    assert choice.validate("h") == "h"
    assert choice.validate("i") == "i"
    assert choice.validate("j") == "j"
    assert choice.validate("k") == "k"
    assert choice.validate("l") == "l"