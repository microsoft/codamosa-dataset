

# Generated at 2022-06-18 12:15:16.326377
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert String(format="time").serialize(datetime.time(12, 0, 0)) == "12:00:00"
    assert String(format="datetime").serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == "2020-01-01T12:00:00"
    assert String(format="uuid").serialize(uuid.UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    assert String().serialize("test") == "test"



# Generated at 2022-06-18 12:15:26.506491
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2019-01-01") == "2019-01-01"
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="date").serialize(datetime.date(2019, 1, 1)) == "2019-01-01"
    assert String(format="date").serialize(datetime.datetime(2019, 1, 1)) == "2019-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="time").serialize(datetime.time(12, 0, 0)) == "12:00:00"

# Generated at 2022-06-18 12:15:37.892952
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any):
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)

# Generated at 2022-06-18 12:15:42.648477
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate of class Union
    # Arrange
    any_of = [String(), Number()]
    union = Union(any_of)
    value = "test"
    # Act
    result = union.validate(value)
    # Assert
    assert result == value


# Generated at 2022-06-18 12:15:53.055372
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)

    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:15:57.758267
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:16:03.709139
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("c")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True, allow_blank=True)

# Generated at 2022-06-18 12:16:07.635966
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error(1) == ValidationResult(value=None, error=None)
    assert field.validate_or_error(1, strict=True) == ValidationResult(value=None, error=None)


# Generated at 2022-06-18 12:16:14.720349
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | String()
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, String()]



# Generated at 2022-06-18 12:16:16.241580
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        test = Array(items=Integer())

    serializer = TestSerializer()
    assert serializer.serialize({"test": [1, 2, 3]}) == {"test": [1, 2, 3]}



# Generated at 2022-06-18 12:16:38.092174
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for validating an array of integers
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert field.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert field.validate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert field.validate([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-18 12:16:49.284707
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.allow_null == False
    assert s.title == ""
    assert s.description == ""
    assert s.has_default() == False
    assert s.get_default_value() == None
    assert s.get_error_text("type") == "Must be a string."
    assert s.get_error_text("null") == "May not be null."
    assert s.get_error_text("blank") == "Must not be blank."

# Generated at 2022-06-18 12:16:58.377476
# Unit test for constructor of class Const
def test_Const():
    # Test for constructor of class Const
    # Case 1: const is not None
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.default == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}
    # Case 2: const is None
    const = Const(const=None)
    assert const.const == None
    assert const.allow_null == True
    assert const.default == None
    assert const.description == None
    assert const.title == None
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}



# Generated at 2022-06-18 12:17:03.920260
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b"]).validate("a") == "a"
    assert Choice(choices=["a", "b"]).validate("b") == "b"
    assert Choice(choices=["a", "b"]).validate("c") == "c"
    assert Choice(choices=["a", "b"]).validate("") == ""
    assert Choice(choices=["a", "b"]).validate(None) == None
    assert Choice(choices=["a", "b"]).validate("a") == "a"
    assert Choice(choices=["a", "b"]).validate("b") == "b"
    assert Choice(choices=["a", "b"]).validate("c") == "c"

# Generated at 2022-06-18 12:17:14.149346
# Unit test for method serialize of class Array

# Generated at 2022-06-18 12:17:24.699161
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=0, maximum=10).validate(5) == 5
    assert Number(minimum=0, maximum=10).validate(0) == 0
    assert Number(minimum=0, maximum=10).validate(10) == 10
    assert Number(minimum=0, maximum=10).validate(0.5) == 0.5
    assert Number(minimum=0, maximum=10).validate(0.0) == 0.0
    assert Number(minimum=0, maximum=10).validate(10.0) == 10.0
    assert Number(minimum=0, maximum=10).validate(0.5) == 0.5
    assert Number(minimum=0, maximum=10).validate(0.0) == 0.0
    assert Number(minimum=0, maximum=10).validate(10.0)

# Generated at 2022-06-18 12:17:37.287389
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.allow_null == False
    assert s.title == ""
    assert s.description == ""
    assert s.has_default() == False
    assert s.get_default_value() == None
    assert s.get_error_text("type") == "Must be a string."
    assert s.get_error_text("null") == "May not be null."
    assert s.get_error_text("blank") == "Must not be blank."

# Generated at 2022-06-18 12:17:44.175694
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=0).validate(1) == 1
    assert Number(minimum=0).validate(0) == 0
    assert Number(minimum=0).validate(-1) == -1
    assert Number(minimum=0).validate(-1) == -1
    assert Number(minimum=0).validate(-1.1) == -1.1
    assert Number(minimum=0).validate(-1.1) == -1.1
    assert Number(minimum=0).validate(-1.1) == -1.1
    assert Number(minimum=0).validate(-1.1) == -1.1
    assert Number(minimum=0).validate(-1.1) == -1.1
    assert Number(minimum=0).validate(-1.1) == -1.1

# Generated at 2022-06-18 12:17:54.492782
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.choices == [("a", "b"), ("c", "d")]
    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]
    c = Choice(choices=["a"])
    assert c.choices == [("a", "a")]
    c = Choice(choices=[])
    assert c.choices == []
    try:
        c = Choice(choices=[("a", "b", "c")])
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-18 12:18:03.418108
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.validate(value=1) == 1
    assert const.validate(value=2) == 2
    assert const.validate(value=None) == None
    assert const.validate(value=1, strict=True) == 1
    assert const.validate(value=2, strict=True) == 2
    assert const.validate(value=None, strict=True) == None


# Generated at 2022-06-18 12:18:24.428643
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, "2", 3]) == [1, 2, 3]
    assert field.validate([1, "2", 3, "4"]) == [1, 2, 3, 4]
    assert field.validate([1, "2", 3, "4", "5"]) == [1, 2, 3, 4, 5]
    assert field.validate([1, "2", 3, "4", "5", "6"]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-18 12:18:35.037983
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:18:44.831202
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "one"), ("2", "two")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("1", "one"), ("2", "two")], allow_null=True)
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate(None) is None
    assert choice.validate("") is None

# Generated at 2022-06-18 12:18:57.600492
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Union
    from typesystem.fields import Any
    from typesystem.fields import Enum
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import DateTime
    from typesystem.fields import UUID
    from typesystem.fields import Number
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Any
    from typesystem.fields import Enum

# Generated at 2022-06-18 12:19:08.504917
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.0) == 1.0
    assert choice.validate(0.0) == 0.0
    assert choice.validate(0) == 0
    assert choice.valid

# Generated at 2022-06-18 12:19:11.930434
# Unit test for constructor of class Const
def test_Const():
    Const(const=None)
    Const(const=True)
    Const(const=False)
    Const(const=1)
    Const(const=1.0)
    Const(const="")
    Const(const=())
    Const(const=[])
    Const(const={})


# Generated at 2022-06-18 12:19:23.306876
# Unit test for method validate of class String
def test_String_validate():
    field = String(title="Name", description="Name of the person", allow_blank=True, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    assert field.validate("") == ""
    assert field.validate(" ") == ""
    assert field.validate("  ") == ""
    assert field.validate("   ") == ""
    assert field.validate("    ") == ""
    assert field.validate("     ") == ""
    assert field.validate("      ") == ""
    assert field.validate("       ") == ""
    assert field.validate("        ") == ""
    assert field.validate("         ") == ""
    assert field.validate("          ") == ""

# Generated at 2022-06-18 12:19:35.513358
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean().validate(None) == None
    assert Boolean().validate("true") == True
    assert Boolean().validate("false") == False
    assert Boolean().validate("on") == True
    assert Boolean().validate("off") == False
    assert Boolean().validate("1") == True
    assert Boolean().validate("0") == False
    assert Boolean().validate("") == False
    assert Boolean().validate(1) == True
    assert Boolean().validate(0) == False
    assert Boolean().validate("null") == None
    assert Boolean().validate("none") == None
    assert Boolean().validate("") == None
    assert Boolean().validate(None) == None

# Generated at 2022-06-18 12:19:45.931854
# Unit test for method serialize of class Array

# Generated at 2022-06-18 12:19:56.144450
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [
        Field(type="string"),
        Field(type="integer"),
    ]
    union = Union(any_of)
    value = "hello"
    expected = "hello"
    actual = union.validate(value)
    assert actual == expected

    # Test case 2
    any_of = [
        Field(type="string"),
        Field(type="integer"),
    ]
    union = Union(any_of)
    value = 1
    expected = 1
    actual = union.validate(value)
    assert actual == expected

    # Test case 3
    any_of = [
        Field(type="string"),
        Field(type="integer"),
    ]
    union = Union(any_of)
    value = 1.0

# Generated at 2022-06-18 12:20:14.676317
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:20:26.799454
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    assert choice.validate("") == None

# Generated at 2022-06-18 12:20:36.781369
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any):
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)
    test_array = TestArray(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)

# Generated at 2022-06-18 12:20:48.391478
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const == None
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const=1).const == 1
    assert Const(const=1.0).const == 1.0
    assert Const(const="a").const == "a"
    assert Const(const=[]).const == []
    assert Const(const={}).const == {}
    assert Const(const={"a": 1}).const == {"a": 1}
    assert Const(const={"a": 1, "b": 2}).const == {"a": 1, "b": 2}
    assert Const(const={"a": 1, "b": 2, "c": 3}).const == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:20:57.365535
# Unit test for constructor of class Array
def test_Array():
    items = [String(), Integer()]
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.unique_items == unique_items


# Generated at 2022-06-18 12:21:07.816903
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("hello") == "hello"
    assert s.validate("hello world") == "hello world"
    assert s.validate("") == ""
    assert s.validate(" ") == " "
    assert s.validate("\n") == "\n"
    assert s.validate("\t") == "\t"
    assert s.validate("\r") == "\r"
    assert s.validate("\0") == ""
    assert s.validate("\0hello") == "hello"
    assert s.validate("hello\0") == "hello"
    assert s.validate("hello\0world") == "hello\0world"
    assert s.validate("\0hello\0") == "hello"

# Generated at 2022-06-18 12:21:20.727327
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:21:29.472186
# Unit test for method validate of class String

# Generated at 2022-06-18 12:21:39.676192
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None
    assert choice.validate("") == None
    assert choice.validate("c") == "c"
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:21:45.400633
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == "3"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate("1", strict=True) == "1"
    assert choice.validate("2", strict=True) == "2"
    assert choice.validate("3", strict=True) == "3"
    assert choice.validate("", strict=True) == ""
    assert choice.validate(None, strict=True) == None



# Generated at 2022-06-18 12:21:59.721848
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:22:08.769248
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    assert choice.validate("3") == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:22:18.523012
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    test_array = TestArray()
    assert test_array.serialize(None) == None
    assert test_array.serialize([]) == []
    assert test_array.serialize([1, 2, 3]) == [1, 2, 3]
    assert test_array.serialize([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert test_array.serialize([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert test_array.serialize([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    assert test_array

# Generated at 2022-06-18 12:22:22.483137
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test for the case when self.items is a list
    items = [Integer(), String()]
    obj = [1, "a"]
    array = Array(items=items)
    assert array.serialize(obj) == [1, "a"]

    # Test for the case when self.items is None
    obj = [1, "a"]
    array = Array()
    assert array.serialize(obj) == [1, "a"]

    # Test for the case when self.items is a Field
    items = String()
    obj = ["a", "b"]
    array = Array(items=items)
    assert array.serialize(obj) == ["a", "b"]



# Generated at 2022-06-18 12:22:31.287463
# Unit test for method validate of class Object
def test_Object_validate():
    class TestObject(Object):
        properties = {
            "name": String(required=True),
            "age": Integer(minimum=0, maximum=100),
            "email": String(pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"),
        }
        additional_properties = False

    test_obj = TestObject()
    # test case 1
    test_data = {
        "name": "John",
        "age": 20,
        "email": "john@example.com",
    }
    assert test_obj.validate(test_data) == test_data

    # test case 2

# Generated at 2022-06-18 12:22:41.923235
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:53.632972
# Unit test for constructor of class Array

# Generated at 2022-06-18 12:23:01.857840
# Unit test for method validate of class Object