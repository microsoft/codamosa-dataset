

# Generated at 2022-06-18 12:14:55.474155
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    from typesystem.types import Union
    field1 = String()
    field2 = Integer()
    field3 = String()
    field4 = Integer()
    field5 = String()
    field6 = Integer()
    field7 = String()
    field8 = Integer()
    field9 = String()
    field10 = Integer()
    field11 = String()
    field12 = Integer()
    field13 = String()
    field14 = Integer()
    field15 = String()
    field16 = Integer()
    field17 = String()
    field18 = Integer()
    field19 = String()
    field20 = Integer()
    field21 = String()
    field22 = Integer()
    field23 = String()
    field24 = Integer()
    field25 = String()

# Generated at 2022-06-18 12:15:06.496413
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.choices == [("a", "b"), ("c", "d")]
    c = Choice(choices=["a", "b"])
    assert c.choices == [("a", "a"), ("b", "b")]
    c = Choice(choices=[("a", "b"), "c"])
    assert c.choices == [("a", "b"), ("c", "c")]
    c = Choice(choices=["a", ("b", "c")])
    assert c.choices == [("a", "a"), ("b", "c")]
    c = Choice(choices=[("a", "b"), ("c", "d"), ("a", "e")])

# Generated at 2022-06-18 12:15:18.769149
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate(None) is None
    with pytest.raises(ValidationError):
        choice.valid

# Generated at 2022-06-18 12:15:24.596962
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(max_length=20),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    obj.validate({"name": "John", "age": 20})

    # Test case 2
    properties = {
        "name": String(max_length=20),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    obj.validate({"name": "John", "age": -20})

    # Test case 3
    properties = {
        "name": String(max_length=20),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)

# Generated at 2022-06-18 12:15:28.962408
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String(max_length=10)
    field2 = Integer()
    field3 = Union([field1, field2])
    assert (field1 | field2) == field3
    assert (field1 | field2 | field3) == Union([field1, field2, field3])

# Generated at 2022-06-18 12:15:40.516818
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="time").serialize(datetime.time(12, 0, 0)) == "12:00:00"
    assert String(format="datetime").serialize("2020-01-01T12:00:00") == "2020-01-01T12:00:00"

# Generated at 2022-06-18 12:15:51.487292
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:15:54.069926
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [Integer(), String()]
    array = Array(items=items)
    assert array.serialize([1, "2"]) == [1, "2"]
    assert array.serialize([1, 2]) == [1, "2"]



# Generated at 2022-06-18 12:15:57.560623
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('1', 'one'), ('2', 'two')])
    assert choice.validate('1') == '1'
    assert choice.validate('2') == '2'
    with pytest.raises(ValidationError):
        choice.validate('3')
    with pytest.raises(ValidationError):
        choice.validate('')
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:16:03.534605
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=String())
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == ["a", "b", "c"]

    # Test case 2
    field = Array(items=String())
    value = ["a", "b", "c", "d"]
    result = field.validate(value)
    assert result == ["a", "b", "c", "d"]

    # Test case 3
    field = Array(items=String())
    value = ["a", "b", "c", "d", "e"]
    result = field.validate(value)
    assert result == ["a", "b", "c", "d", "e"]

    # Test case 4
    field = Array(items=String())

# Generated at 2022-06-18 12:16:22.367744
# Unit test for constructor of class Const
def test_Const():
    try:
        Const(const = 1, allow_null = True)
    except AssertionError:
        print("AssertionError: Const constructor does not allow 'allow_null' as a keyword argument")
    else:
        print("Const constructor allows 'allow_null' as a keyword argument")


# Generated at 2022-06-18 12:16:34.344589
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    assert (String() | Integer()).any_of == [String(), Integer()]
    assert (String() | Integer() | String()).any_of == [String(), Integer(), String()]
    assert (String() | Union([Integer(), String()])).any_of == [String(), Integer(), String()]
    assert (Union([String(), Integer()]) | String()).any_of == [String(), Integer(), String()]
    assert (Union([String(), Integer()]) | Union([String(), Integer()])).any_of == [String(), Integer(), String(), Integer()]
    assert (Union([String(), Integer()]) | Union([Integer(), String()])).any_of == [String(), Integer(), Integer(), String()]



# Generated at 2022-06-18 12:16:39.416509
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1
    field = Field(default=NO_DEFAULT)
    assert field.get_default_value() is None
    field = Field(default=None)
    assert field.get_default_value() is None
    field = Field(default=None, allow_null=True)
    assert field.get_default_value() is None


# Generated at 2022-06-18 12:16:50.371756
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1
    field = Field(default=1, allow_null=True)
    assert field.get_default_value() == 1
    field = Field(default=1, allow_null=False)
    assert field.get_default_value() == 1
    field = Field(default=None, allow_null=True)
    assert field.get_default_value() == None
    field = Field(default=None, allow_null=False)
    assert field.get_default_value() == None


# Generated at 2022-06-18 12:16:58.839879
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:17:00.028888
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:17:08.716015
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(min_length=1, max_length=10), Integer(minimum=1, maximum=10)]
    union = Union(any_of=any_of)
    value = "test"
    assert union.validate(value) == value
    # Test case 2
    any_of = [String(min_length=1, max_length=10), Integer(minimum=1, maximum=10)]
    union = Union(any_of=any_of)
    value = 1
    assert union.validate(value) == value
    # Test case 3
    any_of = [String(min_length=1, max_length=10), Integer(minimum=1, maximum=10)]
    union = Union(any_of=any_of)

# Generated at 2022-06-18 12:17:21.079807
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("a") == "a"
    assert String().validate("") == ""
    assert String().validate(" ") == " "
    assert String().validate("a", strict=True) == "a"
    assert String().validate("", strict=True) == ""
    assert String().validate(" ", strict=True) == " "
    assert String(allow_blank=True).validate("") == ""
    assert String(allow_blank=True).validate(" ") == " "
    assert String(allow_blank=True).validate("", strict=True) == ""
    assert String(allow_blank=True).validate(" ", strict=True) == " "
    assert String(allow_null=True).validate(None) == None

# Generated at 2022-06-18 12:17:32.661506
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:17:41.987528
# Unit test for method validate of class Union
def test_Union_validate():
    from . import String
    from . import Number
    from . import Boolean
    from . import Null
    from . import ValidationError
    from . import Message
    from . import Field
    from . import Union
    from . import Object
    from . import Array
    from . import Text
    from . import Date
    from . import Time
    from . import DateTime
    from . import Uniqueness
    from . import Any
    from . import Enum
    from . import Const
    from . import Reference
    from . import Not
    from . import OneOf
    from . import AllOf
    from . import AnyOf
    from . import Format
    from . import Pattern
    from . import MultipleOf
    from . import Range
    from . import Length
    from . import MinLength
    from . import MaxLength
    from . import MinItems
   

# Generated at 2022-06-18 12:17:54.342823
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {'only_null': 'Must be null.', 'const': "Must be the value '{const}'."}


# Generated at 2022-06-18 12:18:04.735011
# Unit test for method validate of class Object
def test_Object_validate():
    class TestObject(Object):
        properties = {
            "name": String(max_length=10),
            "age": Integer(minimum=0, maximum=100),
            "address": String(max_length=10),
        }

    test_object = TestObject()

    # test case 1
    test_data = {
        "name": "test",
        "age": 10,
        "address": "test",
    }
    assert test_object.validate(test_data) == test_data

    # test case 2
    test_data = {
        "name": "test",
        "age": 101,
        "address": "test",
    }

# Generated at 2022-06-18 12:18:16.628605
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, "3"]) == [1, 2, 3]
    assert field.validate([1, 2, "3", "4"]) == [1, 2, 3, 4]
    assert field.validate([1, 2, "3", "4", "5"]) == [1, 2, 3, 4, 5]
    assert field.validate([1, 2, "3", "4", "5", "6"]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-18 12:18:28.682221
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:18:38.174819
# Unit test for method validate of class Object
def test_Object_validate():
    # Test 1
    field = Object(
        properties={
            "name": String(max_length=10),
            "age": Integer(minimum=0, maximum=100),
        },
        required=["name"],
    )
    value = {"name": "John", "age": 20}
    assert field.validate(value) == value
    # Test 2
    field = Object(
        properties={
            "name": String(max_length=10),
            "age": Integer(minimum=0, maximum=100),
        },
        required=["name"],
    )
    value = {"name": "John", "age": -20}

# Generated at 2022-06-18 12:18:39.955626
# Unit test for constructor of class String
def test_String():
    assert String(title="test", description="test", default="test", allow_null=True)


# Generated at 2022-06-18 12:18:52.363906
# Unit test for method validate of class String
def test_String_validate():
    s = String(title="name", description="name", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    assert s.validate("") == ""
    assert s.validate("abc") == "abc"
    assert s.validate("abc", strict=True) == "abc"
    assert s.validate("abc", strict=False) == "abc"
    assert s.validate("abc", strict=True) == "abc"
    assert s.validate("abc", strict=False) == "abc"
    assert s.validate("abc", strict=True) == "abc"
    assert s.validate("abc", strict=False) == "abc"

# Generated at 2022-06-18 12:19:04.082624
# Unit test for method validate of class String

# Generated at 2022-06-18 12:19:12.756134
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [("a", "b"), ("c", "d")])
    assert choice.validate("a") == "a"
    assert choice.validate("c") == "c"
    assert choice.validate("b") == "b"
    assert choice.validate("d") == "d"
    with pytest.raises(ValidationError):
        choice.validate("e")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices = [("a", "b"), ("c", "d")], allow_null = True)
    assert choice.validate(None) == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:19:23.905694
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:49.245988
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=False)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == False
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None

# Generated at 2022-06-18 12:20:00.020276
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {'name': String(required=True), 'age': Integer(required=True)}
    pattern_properties = {'^[a-z]+$': String(required=True)}
    additional_properties = True
    property_names = None
    min_properties = None
    max_properties = None
    required = ['name', 'age']
    obj = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    value = {'name': 'John', 'age': 20, 'address': '123 Main St.'}

# Generated at 2022-06-18 12:20:10.949443
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.5) == 1.5
    assert Number().validate(1.6) == 1.6
    assert Number().validate(1.9) == 1.9
    assert Number().validate(1.99) == 1.99
    assert Number().validate(1.999) == 1.999
    assert Number().validate(1.9999) == 1.9999
    assert Number().validate(1.99999) == 1.99999
    assert Number().validate(1.999999) == 1.999999
    assert Number().validate(1.9999999) == 1.9999999
    assert Number().valid

# Generated at 2022-06-18 12:20:19.201229
# Unit test for method validate of class Number

# Generated at 2022-06-18 12:20:30.023628
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:20:38.397160
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.allow_null == False
    assert s.title == ""
    assert s.description == ""
    assert s.has_default() == False
    assert s.get_default_value() == None
    assert s.get_error_text("type") == "Must be a string."
    assert s.get_error_text("null") == "May not be null."
    assert s.get_error_text("blank") == "Must not be blank."

# Generated at 2022-06-18 12:20:50.081194
# Unit test for method validate of class Number

# Generated at 2022-06-18 12:21:02.350759
# Unit test for method validate of class String

# Generated at 2022-06-18 12:21:06.698562
# Unit test for method validate of class Boolean

# Generated at 2022-06-18 12:21:19.118443
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:21:41.599420
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:50.925486
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[('a', 'a'), ('b', 'b')])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    assert choice.validate('c') == 'c'
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1) == 1
    assert choice.validate(0) == 0
    assert choice.validate(1.0) == 1.0
    assert choice.validate(0.0) == 0.0
    assert choice.validate('1') == '1'
    assert choice.validate('0') == '0'
    assert choice

# Generated at 2022-06-18 12:21:59.453537
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.1) == 1.1
    assert Number().validate("1") == 1
    assert Number().validate("1.0") == 1.0
    assert Number().validate("1.1") == 1.1
    assert Number().validate(None) == None
    assert Number().validate("") == None
    assert Number().validate(False) == False
    assert Number().validate(True) == True
    assert Number().validate("a") == "a"
    assert Number().validate("1a") == "1a"
    assert Number().validate("a1") == "a1"
    assert Number().validate("1.a") == "1.a"


# Generated at 2022-06-18 12:22:06.316028
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:22:16.262555
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    field = Object(properties={'name': String()}, required=['name'])
    value = {'name': 'John'}
    assert field.validate(value) == {'name': 'John'}
    # Test case 2
    field = Object(properties={'name': String()}, required=['name'])
    value = {'name': 'John', 'age': 20}
    assert field.validate(value) == {'name': 'John', 'age': 20}
    # Test case 3
    field = Object(properties={'name': String()}, required=['name'])
    value = {'name': 'John', 'age': 20, 'gender': 'male'}

# Generated at 2022-06-18 12:22:20.090563
# Unit test for constructor of class Array
def test_Array():
    assert Array(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)


# Generated at 2022-06-18 12:22:29.510446
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:22:39.326356
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(1.0) == 1.0
    assert number.validate("1") == 1
    assert number.validate("1.0") == 1.0
    assert number.validate("1.1") == 1.1
    assert number.validate("-1.1") == -1.1
    assert number.validate("1.11") == 1.11
    assert number.validate("-1.11") == -1.11
    assert number.validate("1.111") == 1.111
    assert number.validate("-1.111") == -1.111
    assert number.validate("1.1111") == 1.1111
    assert number.validate("-1.1111") == -1.1111
   

# Generated at 2022-06-18 12:22:51.562468
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=["a", "b", "c"]).choices == [("a", "a"), ("b", "b"), ("c", "c")]
    assert Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")]).choices == [("a", "A"), ("b", "B"), ("c", "C")]
    assert Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")]).choices == [("a", "A"), ("b", "B"), ("c", "C")]
    assert Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")]).choices == [("a", "A"), ("b", "B"), ("c", "C")]

# Generated at 2022-06-18 12:23:00.670760
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=Integer())
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, "3"]) == [1, 2, 3]
    assert array.validate([1, 2, "3", "4"]) == [1, 2, 3, 4]
    assert array.validate([1, 2, "3", "4", "5"]) == [1, 2, 3, 4, 5]
    assert array.validate([1, 2, "3", "4", "5", "6"]) == [1, 2, 3, 4, 5, 6]