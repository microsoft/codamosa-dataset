

# Generated at 2022-06-18 12:15:20.204097
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == None
    assert b.validate("a") == None
    assert b

# Generated at 2022-06-18 12:15:26.463804
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    field1 = String()
    field2 = Integer()
    field3 = field1 | field2
    assert isinstance(field3, Union)
    assert field3.any_of == [field1, field2]
    field4 = field3 | field2
    assert isinstance(field4, Union)
    assert field4.any_of == [field1, field2, field2]



# Generated at 2022-06-18 12:15:37.790522
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:15:49.117605
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.1) == 1.1
    assert Number().validate(1.1, strict=True) == 1.1
    assert Number().validate(1.1, strict=False) == 1.1
    assert Number().validate("1.1") == 1.1
    assert Number().validate("1.1", strict=True) == 1.1
    assert Number().validate("1.1", strict=False) == 1.1
    assert Number().validate(None) == None
    assert Number().validate(None, strict=True) == None
    assert Number().validate(None, strict=False) == None
    assert Number().validate("") == None
    assert Number().validate("", strict=True) == None
    assert Number().valid

# Generated at 2022-06-18 12:15:56.496923
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:58.306368
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=[("a", "b")]).choices == [("a", "b")]
    assert Choice(choices=["a"]).choices == [("a", "a")]


# Generated at 2022-06-18 12:16:09.368400
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=100, maximum=200),
        Integer(minimum=200, maximum=300),
    ]
    union = Union(any_of)
    assert union.validate(50) == 50
    assert union.validate(150) == 150
    assert union.validate(250) == 250
    try:
        union.validate(-50)
        assert False
    except ValidationError:
        pass
    try:
        union.validate(350)
        assert False
    except ValidationError:
        pass
    try:
        union.validate("50")
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:16:19.864425
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String()]
    value = "test"
    strict = False
    expected = "test"
    actual = Union(any_of).validate(value, strict=strict)
    assert expected == actual

    # Test case 2
    any_of = [String()]
    value = None
    strict = False
    expected = None
    actual = Union(any_of).validate(value, strict=strict)
    assert expected == actual

    # Test case 3
    any_of = [String()]
    value = None
    strict = False
    expected = "May not be null."
    actual = Union(any_of).validate(value, strict=strict)
    assert expected == actual

    # Test case 4
    any_of = [String()]

# Generated at 2022-06-18 12:16:24.562609
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestSerializer(Serializer):
        items = Array(items=Integer())
    serializer = TestSerializer()
    assert serializer.serialize([1, 2, 3]) == [1, 2, 3]
    assert serializer.serialize(None) == None
    assert serializer.serialize([]) == []
    assert serializer.serialize([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert serializer.serialize([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert serializer.serialize([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-18 12:16:29.958186
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:17:03.688678
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(
        items=String(max_length=10),
        additional_items=False,
        min_items=2,
        max_items=3,
        unique_items=True,
    )
    value = ["abc", "def", "ghi"]
    assert field.validate(value) == value
    # Test case 2
    field = Array(
        items=String(max_length=10),
        additional_items=False,
        min_items=2,
        max_items=3,
        unique_items=True,
    )
    value = ["abc", "def", "ghi", "jkl"]

# Generated at 2022-06-18 12:17:13.405383
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("3")


# Generated at 2022-06-18 12:17:22.351964
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    assert choice.validate("", strict=True) == ""
    assert choice.validate(None) is None
    with pytest.raises(ValidationError):
        choice.validate(None, strict=True)



# Generated at 2022-06-18 12:17:34.735113
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(
        items = [
            String(),
            String(),
        ],
        additional_items = False,
        min_items = 2,
        max_items = 2,
        unique_items = False,
        allow_null = False,
        default = None,
    )
    value = [
        "",
        "",
    ]
    expected = [
        "",
        "",
    ]
    actual = field.validate(value)
    assert actual == expected

    # Test case 2

# Generated at 2022-06-18 12:17:42.918916
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:17:54.815402
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:18:05.248603
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format="date")
    assert s.serialize("2020-01-01") == "2020-01-01"
    assert s.serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert s.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01"
    assert s.serialize(datetime.datetime(2020, 1, 1, 0, 0, 1)) == "2020-01-01"
    assert s.serialize(datetime.datetime(2020, 1, 1, 0, 0, 1, tzinfo=pytz.UTC)) == "2020-01-01"

# Generated at 2022-06-18 12:18:17.091144
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b"]) == ["a", "b"]
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:18:29.193046
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:18:38.451695
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=String()).serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert Array(items=Integer()).serialize([1, 2, 3]) == [1, 2, 3]
    assert Array(items=Float()).serialize([1.0, 2.0, 3.0]) == [1.0, 2.0, 3.0]
    assert Array(items=Boolean()).serialize([True, False, True]) == [True, False, True]
    assert Array(items=None).serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert Array(items=None).serialize([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-18 12:19:02.543568
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Test(Serializer):
        a = Array(items=Integer())
    assert Test.serialize({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}
    assert Test.serialize({"a": [1, 2, 3.0]}) == {"a": [1, 2, 3]}
    assert Test.serialize({"a": [1, 2, "3"]}) == {"a": [1, 2, 3]}
    assert Test.serialize({"a": [1, 2, "3.0"]}) == {"a": [1, 2, 3]}
    assert Test.serialize({"a": [1, 2, "3.1"]}) == {"a": [1, 2, 3]}

# Generated at 2022-06-18 12:19:11.960879
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("") is None
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True, allow_blank=True)

# Generated at 2022-06-18 12:19:13.314849
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:19:24.266687
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:36.461169
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean().validate(None) == None
    assert Boolean().validate(1) == True
    assert Boolean().validate(0) == False
    assert Boolean().validate("true") == True
    assert Boolean().validate("false") == False
    assert Boolean().validate("on") == True
    assert Boolean().validate("off") == False
    assert Boolean().validate("1") == True
    assert Boolean().validate("0") == False
    assert Boolean().validate("") == False
    assert Boolean().validate("null") == None
    assert Boolean().validate("none") == None
    assert Boolean().validate("") == False
    assert Boolean().validate(1) == True
    assert Boolean().validate(0)

# Generated at 2022-06-18 12:19:46.786780
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test case 1
    array = Array(items=Integer())
    assert array.serialize([1, 2, 3]) == [1, 2, 3]
    # Test case 2
    array = Array(items=Integer())
    assert array.serialize(None) == None
    # Test case 3
    array = Array(items=Integer())
    assert array.serialize([]) == []
    # Test case 4
    array = Array(items=Integer())
    assert array.serialize([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # Test case 5
    array = Array(items=Integer())

# Generated at 2022-06-18 12:19:57.184649
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError) as excinfo:
        choice.validate("c")
    assert excinfo.value.code == "choice"
    assert choice.validate("") == None
    with pytest.raises(ValidationError) as excinfo:
        choice.validate("")
    assert excinfo.value.code == "required"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError) as excinfo:
        choice.validate(None)
    assert excinfo.value.code == "null"



# Generated at 2022-06-18 12:20:08.156552
# Unit test for method validate of class Choice

# Generated at 2022-06-18 12:20:17.496020
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String

    field1 = String()
    field2 = String()
    field3 = String()
    field4 = String()
    field5 = String()
    field6 = String()
    field7 = String()
    field8 = String()
    field9 = String()
    field10 = String()
    field11 = String()
    field12 = String()
    field13 = String()
    field14 = String()
    field15 = String()
    field16 = String()
    field17 = String()
    field18 = String()
    field19 = String()
    field20 = String()
    field21 = String()
    field22 = String()
    field23 = String()
    field24 = String()
    field25 = String()
    field26 = String()
    field27 = String()
   

# Generated at 2022-06-18 12:20:20.461472
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for method validate(self, value, *, strict=False)
    # of class Object
    # Arrange
    # Act
    # Assert
    pass



# Generated at 2022-06-18 12:20:39.864667
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {'name': String(max_length=10), 'age': Integer(minimum=0, maximum=100)}
    pattern_properties = {'^[0-9]+$': Integer(minimum=0, maximum=100)}
    additional_properties = False
    property_names = String(max_length=10)
    min_properties = 1
    max_properties = 2
    required = ['name']
    obj = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    value = {'name': 'John', 'age': 20}
    assert obj.validate(value) == {'name': 'John', 'age': 20}
    #

# Generated at 2022-06-18 12:20:51.790677
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:21:03.931562
# Unit test for constructor of class Array
def test_Array():
    # Test for constructor of class Array
    # Input:
    #   items: Field = None,
    #   additional_items: Field = False,
    #   min_items: int = None,
    #   max_items: int = None,
    #   exact_items: int = None,
    #   unique_items: bool = False,
    #   **kwargs: typing.Any,
    # Expected Output:
    #   Array(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False, **kwargs)
    assert Array() == Array(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)
    # Test for constructor of class Array
   

# Generated at 2022-06-18 12:21:10.692963
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.unions import Union
    field1 = String()
    field2 = String()
    field3 = String()
    union1 = field1 | field2
    union2 = field2 | field3
    union3 = field1 | field2 | field3
    assert isinstance(union1, Union)
    assert isinstance(union2, Union)
    assert isinstance(union3, Union)
    assert union1.any_of == [field1, field2]
    assert union2.any_of == [field2, field3]
    assert union3.any_of == [field1, field2, field3]


# Generated at 2022-06-18 12:21:17.052440
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert const.validate(1) == 1
    assert const.validate(2) == None


# Generated at 2022-06-18 12:21:27.541551
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "b"), ("c", "d")])
    assert choice.validate("a") == "a"
    assert choice.validate("c") == "c"
    assert choice.validate("e") == "e"
    assert choice.validate("") == ""
    assert choice.validate(None) == None
    assert choice.validate(1) == 1
    assert choice.validate(True) == True
    assert choice.validate(False) == False
    assert choice.validate(1.0) == 1.0
    assert choice.validate(1.1) == 1.1
    assert choice.validate(1.2) == 1.2
    assert choice.validate(1.3) == 1.3

# Generated at 2022-06-18 12:21:38.005667
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    assert n.validate(1) == 1
    assert n.validate(1.0) == 1.0
    assert n.validate("1") == 1
    assert n.validate("1.0") == 1.0
    assert n.validate("1.00") == 1.0
    assert n.validate("1.000") == 1.0
    assert n.validate("1.0000") == 1.0
    assert n.validate("1.00000") == 1.0
    assert n.validate("1.000000") == 1.0
    assert n.validate("1.0000000") == 1.0
    assert n.validate("1.00000000") == 1.0
    assert n.validate("1.000000000") == 1.0

# Generated at 2022-06-18 12:21:44.153627
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=True, allow_blank=True, trim_whitespace=True, max_length=10, min_length=10, pattern=None, format="test")
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True
    assert s.allow_blank == True
    assert s.trim_whitespace == True
    assert s.max_length == 10
    assert s.min_length == 10
    assert s.pattern == None
    assert s.format == "test"


# Generated at 2022-06-18 12:21:52.153548
# Unit test for constructor of class String
def test_String():
    s = String(title="name", description="name of the person", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None)
    assert s.title == "name"
    assert s.description == "name of the person"
    assert s.default == ""
    assert s.allow_null == False
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None


# Generated at 2022-06-18 12:21:59.250917
# Unit test for constructor of class Array
def test_Array():
    items = [
        String(min_length=1, max_length=10),
        Integer(minimum=0, maximum=100),
    ]
    additional_items = String(min_length=1, max_length=10)
    min_items = 2
    max_items = 10
    exact_items = None
    unique_items = True
    allow_null = True
    default = None
    description = "This is a test"
    title = "Test"

# Generated at 2022-06-18 12:22:28.161772
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    from typesystem.fields import Field
    from typesystem.fields import Boolean
    from typesystem.fields import Number
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import UUID
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Enum
    from typesystem.fields import Any
    from typesystem.fields import Link
    from typesystem.fields import Constant
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import Slug
    from typesystem.fields import String
    from typesystem.fields import Integer

# Generated at 2022-06-18 12:22:35.102553
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:22:46.435786
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test for method validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any
    # of class Choice
    # The following test is added by Yanqi
    choice = Choice(choices=[('a', 'A'), ('b', 'B')])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    try:
        choice.validate('c')
    except ValidationError:
        assert True
    else:
        assert False
    try:
        choice.validate('')
    except ValidationError:
        assert True
    else:
        assert False
    choice = Choice(choices=[('a', 'A'), ('b', 'B')], allow_null=True)
    assert choice.validate('') == None


# Generated at 2022-06-18 12:22:57.570024
# Unit test for constructor of class Const
def test_Const():
    c = Const(const=1)
    assert c.const == 1
    assert c.allow_null == False
    assert c.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert c.validate(1) == 1
    try:
        c.validate(2)
    except ValidationError as e:
        assert e.messages[0].text == "Must be the value '1'."
        assert e.messages[0].code == "const"
        assert e.messages[0].index == []
        assert e.messages[0].key == None
    try:
        c.validate(None)
    except ValidationError as e:
        assert e.messages[0].text == "Must be null."
        assert e.messages