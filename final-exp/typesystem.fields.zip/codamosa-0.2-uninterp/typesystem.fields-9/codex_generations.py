

# Generated at 2022-06-18 12:14:56.600862
# Unit test for method validate of class Union
def test_Union_validate():
    field = Union([String(), Number()])
    field.validate("hello")
    field.validate(1)
    with pytest.raises(ValidationError):
        field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(True)
    with pytest.raises(ValidationError):
        field.validate(False)
    with pytest.raises(ValidationError):
        field.validate(1.1)
    with pytest.raises(ValidationError):
        field.validate(1.0)
    with pytest.raises(ValidationError):
        field.validate(1.0)
    with pytest.raises(ValidationError):
        field.validate(1.0)

# Generated at 2022-06-18 12:15:06.944185
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=True) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=False) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=True) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=False) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c"], strict=True) == ["a", "b", "c"]
    assert field.validate

# Generated at 2022-06-18 12:15:19.328002
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == None
    assert b.validate("abc") == None
    assert b

# Generated at 2022-06-18 12:15:28.720700
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:15:40.410074
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field()
    assert field.validate_or_error(None).value is None
    assert field.validate_or_error(None).error is None
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(1).error is None
    assert field.validate_or_error(1.0).value == 1.0
    assert field.validate_or_error(1.0).error is None
    assert field.validate_or_error("1").value == "1"
    assert field.validate_or_error("1").error is None
    assert field.validate_or_error(True).value is True
    assert field.validate_or_error(True).error is None

# Generated at 2022-06-18 12:15:45.169357
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer, Float
    from typesystem.unions import Union
    assert (String() | Integer()) == Union([String(), Integer()])
    assert (String() | Integer() | Float()) == Union([String(), Integer(), Float()])
    assert (String() | Integer() | Float()) == (String() | (Integer() | Float()))
    assert (String() | Integer() | Float()) == ((String() | Integer()) | Float())
    assert (String() | Integer() | Float()) == ((String() | Integer() | Float()))
    assert (String() | Integer() | Float()) == ((String() | Integer() | Float()))
    assert (String() | Integer() | Float()) == ((String() | Integer() | Float()))
    assert (String() | Integer() | Float()) == ((String() | Integer() | Float()))

# Generated at 2022-06-18 12:15:54.553600
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class TestField(Field):
        def validate(self, value, *, strict=False):
            return value
    field = TestField()
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(1).error is None
    assert field.validate_or_error(None).value is None
    assert field.validate_or_error(None).error is None
    assert field.validate_or_error(1, strict=True).value == 1
    assert field.validate_or_error(1, strict=True).error is None
    assert field.validate_or_error(None, strict=True).value is None
    assert field.validate_or_error(None, strict=True).error is None

# Generated at 2022-06-18 12:16:06.077071
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert String(format="time").serialize(datetime.time(12, 0, 0)) == "12:00:00"
    assert String(format="datetime").serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == "2020-01-01T12:00:00"
    assert String(format="uuid").serialize(uuid.UUID("b4faee4c-9c0b-4ef8-bb6d-61b040527e3a")) == "b4faee4c-9c0b-4ef8-bb6d-61b040527e3a"



# Generated at 2022-06-18 12:16:16.489097
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.validate("test") == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"
    assert string.validate("test", strict=True) == "test"
    assert string.validate("test", strict=False) == "test"

# Generated at 2022-06-18 12:16:20.815934
# Unit test for constructor of class Array
def test_Array():
    a = Array(items=String())
    assert a.items == String()
    assert a.additional_items == False
    assert a.min_items == None
    assert a.max_items == None
    assert a.unique_items == False
    assert a.allow_null == True
    assert a.default == None
    assert a.description == None
    assert a.title == None
    assert a.name == None

# Generated at 2022-06-18 12:16:32.295126
# Unit test for method serialize of class String
def test_String_serialize():
    string = String()
    assert string.serialize("test") == "test"
    assert string.serialize(None) == None


# Generated at 2022-06-18 12:16:36.702612
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2019-01-01") == "2019-01-01"
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="date").serialize(datetime.date(2019, 1, 1)) == "2019-01-01"


# Generated at 2022-06-18 12:16:41.064448
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:16:52.288246
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    field = Object(
        properties={
            "name": String(max_length=100),
            "age": Integer(minimum=0, maximum=100),
        },
        required=["name"],
    )
    value = {"name": "John", "age": 30}
    assert field.validate(value) == value

    # Test case 2
    field = Object(
        properties={
            "name": String(max_length=100),
            "age": Integer(minimum=0, maximum=100),
        },
        required=["name"],
    )
    value = {"name": "John", "age": 30}
    assert field.validate(value) == value

    # Test case 3

# Generated at 2022-06-18 12:16:59.928165
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=True)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == True
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    assert s.pattern_regex == None

# Generated at 2022-06-18 12:17:06.454394
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:17:16.461596
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=String())
    assert field.serialize(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.serialize(None) is None
    assert field.serialize([]) == []

    field = Array(items=[String(), Integer()])
    assert field.serialize(["a", 1]) == ["a", 1]
    assert field.serialize(["a", 1, "b", 2]) == ["a", 1, "b", 2]

    field = Array(items=Integer())
    assert field.serialize([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-18 12:17:22.195900
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("") == ""
    assert choice.validate(None) == None



# Generated at 2022-06-18 12:17:28.803898
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String())
    assert field.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert field.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert field.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert field.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:17:39.780480
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:18:02.230537
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union([String(), Integer()]).validate("hello") == "hello"
    assert Union([String(), Integer()]).validate(123) == 123
    assert Union([String(), Integer()]).validate(None) == None
    assert Union([String(), Integer()]).validate(None, strict=True) == None
    assert Union([String(), Integer()]).validate(None, strict=False) == None
    assert Union([String(), Integer()]).validate(True) == True
    assert Union([String(), Integer()]).validate(True, strict=True) == True
    assert Union([String(), Integer()]).validate(True, strict=False) == True
    assert Union([String(), Integer()]).validate(False) == False
    assert Union([String(), Integer()]).validate(False, strict=True) == False

# Generated at 2022-06-18 12:18:13.013134
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:25.596053
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:28.329674
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False


# Generated at 2022-06-18 12:18:37.906734
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array(items=String())
    assert arr.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert arr.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert arr.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert arr.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:18:48.884024
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number()
    assert a.validate(1) == 1
    assert a.validate(1.1) == 1.1
    assert a.validate(None) == None
    assert a.validate("") == None
    assert a.validate(True) == None
    assert a.validate(False) == None
    assert a.validate("a") == None
    assert a.validate(1.1) == 1.1
    assert a.validate(1.1) == 1.1
    assert a.validate(1.1) == 1.1
    assert a.validate(1.1) == 1.1
    assert a.validate(1.1) == 1.1
    assert a.validate(1.1) == 1.1

# Generated at 2022-06-18 12:19:01.763097
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:11.540784
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    assert choice.validate("", strict=True) == ""
    assert choice.validate("", allow_null=True) == None
    assert choice.validate("", allow_null=True, strict=True) == None
    with pytest.raises(ValidationError):
        choice.validate(None)
    assert choice.validate(None, allow_null=True) == None

# Generated at 2022-06-18 12:19:23.048821
# Unit test for constructor of class String
def test_String():
    # Test for constructor of class String
    # Test for constructor of class String with no parameters
    test_string = String()
    assert test_string.title == ""
    assert test_string.description == ""
    assert test_string.allow_null == False
    assert test_string.allow_blank == False
    assert test_string.trim_whitespace == True
    assert test_string.max_length == None
    assert test_string.min_length == None
    assert test_string.pattern == None
    assert test_string.format == None
    assert test_string.pattern_regex == None

# Generated at 2022-06-18 12:19:35.221343
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate(None) == None
    with pytest.raises(ValidationError):
        field.validate("c")

# Generated at 2022-06-18 12:19:52.579570
# Unit test for method validate of class String

# Generated at 2022-06-18 12:20:03.451680
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with a valid value
    any_of = [String(), Integer()]
    union = Union(any_of)
    assert union.validate("test") == "test"
    assert union.validate(1) == 1
    # Test with an invalid value
    with pytest.raises(ValidationError):
        union.validate(True)
    # Test with a null value
    with pytest.raises(ValidationError):
        union.validate(None)
    # Test with a null value and allow_null=True
    union = Union(any_of, allow_null=True)
    assert union.validate(None) == None
    # Test with a null value and allow_null=True and a child that allows null
    any_of = [String(), Integer(allow_null=True)]
    union = Union

# Generated at 2022-06-18 12:20:14.217734
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:20:23.110301
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:20:28.129890
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate("true") == True
    assert b.validate("false") == False
    assert b.validate("on") == True
    assert b.validate("off") == False
    assert b.validate("1") == True
    assert b.validate("0") == False
    assert b.validate("") == False
    assert b.validate("null") == None
    assert b.validate("none") == None
    assert b.validate("") == False
    assert b.validate(1) == True
    assert b

# Generated at 2022-06-18 12:20:37.545486
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.choices == [("a", "a"), ("b", "b"), ("c", "c")]
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    assert choice.validate("") == None
    assert choice.validate(None) == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None
    assert choice.validate("") == None

# Generated at 2022-06-18 12:20:49.339706
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()
    assert number.validate(1) == 1
    assert number.validate(1.1) == 1.1
    assert number.validate(None) == None
    assert number.validate("") == None
    assert number.validate(True) == True
    assert number.validate(False) == False
    assert number.validate("1") == 1
    assert number.validate("1.1") == 1.1
    assert number.validate("1.1.1") == None
    assert number.validate("1.1.1", strict=True) == None
    assert number.validate("1.1.1", strict=False) == None
    assert number.validate(1.1, strict=True) == 1.1

# Generated at 2022-06-18 12:21:01.622943
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"

# Generated at 2022-06-18 12:21:11.236530
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:21:23.529126
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Number()]
    union = Union(any_of)
    value = 'abc'
    expected_result = 'abc'
    actual_result = union.validate(value)
    assert actual_result == expected_result
    # Test case 2
    any_of = [String(), Number()]
    union = Union(any_of)
    value = 123
    expected_result = 123
    actual_result = union.validate(value)
    assert actual_result == expected_result
    # Test case 3
    any_of = [String(), Number()]
    union = Union(any_of)
    value = 'abc'
    expected_result = 'abc'
    actual_result = union.validate(value)
    assert actual_result == expected_result
    #

# Generated at 2022-06-18 12:21:40.522211
# Unit test for constructor of class Const
def test_Const():
    # Test case 1:
    #   const = 1
    #   allow_null = False
    #   value = 1
    #   expected = 1
    const = 1
    allow_null = False
    value = 1
    expected = 1
    assert Const(const, allow_null=allow_null).validate(value) == expected

    # Test case 2:
    #   const = 1
    #   allow_null = False
    #   value = None
    #   expected = ValidationError
    const = 1
    allow_null = False
    value = None
    expected = ValidationError
    try:
        Const(const, allow_null=allow_null).validate(value)
    except ValidationError:
        assert True
    else:
        assert False

    # Test case 3:
    #   const = 1

# Generated at 2022-06-18 12:21:49.704782
# Unit test for method validate of class String

# Generated at 2022-06-18 12:21:57.837714
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=[("a", "b")]).choices == [("a", "b")]
    assert Choice(choices=["a"]).choices == [("a", "a")]
    assert Choice(choices=[("a", "b"), "c"]).choices == [("a", "b"), ("c", "c")]
    assert Choice(choices=[("a", "b"), ("c", "d"), "e"]).choices == [("a", "b"), ("c", "d"), ("e", "e")]
    assert Choice(choices=[]).choices == []
    assert Choice(choices=None).choices == []
    assert Choice(choices=["a", "b"]).choices == [("a", "a"), ("b", "b")]

# Generated at 2022-06-18 12:22:07.414134
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("c")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True, allow_blank=True)

# Generated at 2022-06-18 12:22:17.212545
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("") == None
    assert choice.validate("c") == None

# Generated at 2022-06-18 12:22:28.162600
# Unit test for method validate of class String

# Generated at 2022-06-18 12:22:37.383147
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:22:48.799986
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) is None
    assert choice.validate("") is None
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True, allow_blank=True)

# Generated at 2022-06-18 12:22:59.208078
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=1).validate(1) == 1
    assert Number(minimum=1).validate(2) == 2
    assert Number(minimum=1).validate(0) == 0
    assert Number(minimum=1).validate(0.1) == 0.1
    assert Number(minimum=1).validate(1.1) == 1.1
    assert Number(minimum=1).validate(1.0) == 1.0
    assert Number(minimum=1).validate(1.1) == 1.1
    assert Number(minimum=1).validate(1.0) == 1.0
    assert Number(minimum=1).validate(1.1) == 1.1
    assert Number(minimum=1).validate(1.0) == 1.0