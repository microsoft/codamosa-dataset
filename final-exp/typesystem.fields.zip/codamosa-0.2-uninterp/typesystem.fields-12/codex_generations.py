

# Generated at 2022-06-18 12:14:55.515874
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:15:00.279363
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Generated at 2022-06-18 12:15:08.898806
# Unit test for method validate of class Array
def test_Array_validate():
    # Test with items of type Field
    items = Field()
    array = Array(items=items)
    assert array.validate([1, 2, 3]) == [1, 2, 3]
    assert array.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert array.validate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-18 12:15:21.355010
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Union
    from typesystem.fields import Boolean
    from typesystem.fields import Number
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import UUID
    from typesystem.fields import Enum
    from typesystem.fields import Any
    from typesystem.fields import Const
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import Slug
    from typesystem.fields import Choice
    from typesystem.fields import File
    from typesystem.fields import Image
    from typesystem.fields import Integer

# Generated at 2022-06-18 12:15:26.530401
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(items=String())
    assert array.validate(["a", "b", "c"]) == ["a", "b", "c"]
    assert array.validate(["a", "b", "c", "d"]) == ["a", "b", "c", "d"]
    assert array.validate(["a", "b", "c", "d", "e"]) == ["a", "b", "c", "d", "e"]
    assert array.validate(["a", "b", "c", "d", "e", "f"]) == ["a", "b", "c", "d", "e", "f"]

# Generated at 2022-06-18 12:15:37.427516
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("1", "1"), ("2", "2")])
    assert choice.validate("1") == "1"
    assert choice.validate("2") == "2"
    with pytest.raises(ValidationError):
        choice.validate("3")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("1", "1"), ("2", "2")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    with pytest.raises(ValidationError):
        choice.validate("3")


# Generated at 2022-06-18 12:15:48.770185
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Number
    from typesystem.unions import Union
    assert (String() | Number()) == Union(any_of=[String(), Number()])
    assert (String() | Number() | String()) == Union(any_of=[String(), Number(), String()])
    assert (String() | (Number() | String())) == Union(any_of=[String(), Number(), String()])
    assert (String() | (Number() | String()) | Number()) == Union(any_of=[String(), Number(), String(), Number()])
    assert (String() | (Number() | String()) | (Number() | String())) == Union(any_of=[String(), Number(), String()])
    assert (String() | (Number() | String()) | (Number() | String()) | String()) == Union(any_of=[String(), Number(), String()])

# Generated at 2022-06-18 12:15:56.365176
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.choices == [("a", "a"), ("b", "b")]
    field = Choice(choices=["a", "b"])
    assert field.choices == [("a", "a"), ("b", "b")]
    field = Choice(choices=["a", ("b", "b")])
    assert field.choices == [("a", "a"), ("b", "b")]
    field = Choice(choices=["a", ("b", "c")])
    assert field.choices == [("a", "a"), ("b", "c")]
    field = Choice(choices=["a", ("b", "c"), "d"])

# Generated at 2022-06-18 12:16:08.561327
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:16:10.843100
# Unit test for constructor of class Const
def test_Const():
    const = Const(const=1)
    assert const.const == 1
    assert const.allow_null == False
    assert const.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Generated at 2022-06-18 12:16:33.110976
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format='date').serialize('2019-01-01') == '2019-01-01'
    assert String(format='time').serialize('12:00:00') == '12:00:00'
    assert String(format='datetime').serialize('2019-01-01T12:00:00') == '2019-01-01T12:00:00'
    assert String(format='uuid').serialize('a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11') == 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11'
    assert String().serialize('2019-01-01') == '2019-01-01'

# Generated at 2022-06-18 12:16:39.991169
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2019-01-01") == "2019-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="datetime").serialize("2019-01-01T12:00:00") == "2019-01-01T12:00:00"
    assert String(format="uuid").serialize("8f8b4a4d-4e4b-4b8e-9a2c-a7a9b9c8d7e6") == "8f8b4a4d-4e4b-4b8e-9a2c-a7a9b9c8d7e6"



# Generated at 2022-06-18 12:16:47.109846
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:16:56.829424
# Unit test for constructor of class Array
def test_Array():
    items = [
        String(min_length=1, max_length=10),
        Integer(minimum=0, maximum=100),
    ]
    additional_items = Boolean()
    min_items = 2
    max_items = 5
    exact_items = None
    unique_items = True
    array = Array(
        items=items,
        additional_items=additional_items,
        min_items=min_items,
        max_items=max_items,
        exact_items=exact_items,
        unique_items=unique_items,
    )
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.exact_items == exact_items

# Generated at 2022-06-18 12:17:07.201231
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="time").serialize("12:00:00") == "12:00:00"
    assert String(format="datetime").serialize("2020-01-01T12:00:00") == "2020-01-01T12:00:00"
    assert String(format="uuid").serialize("00000000-0000-0000-0000-000000000000") == "00000000-0000-0000-0000-000000000000"
    assert String(format="uuid").serialize("00000000-0000-0000-0000-000000000000") == "00000000-0000-0000-0000-000000000000"

# Generated at 2022-06-18 12:17:19.684525
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Array
    def test_Array_validate():
        # Test for method validate(self, value, strict=False)
        class TestArray(Array):
            def __init__(self, *args, **kwargs):
                super().__init__(**kwargs)

        field = TestArray(items=String())
        field.validate(["a", "b", "c"])

        field = TestArray(items=String(), min_items=2)
        field.validate(["a", "b", "c"])

        field = TestArray(items=String(), max_items=2)
        field.validate(["a", "b", "c"])


# Generated at 2022-06-18 12:17:27.421396
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    assert choice.validate("", strict=False) is None
    assert choice.validate(None, strict=False) is None
    choice = Choice(allow_null=True, choices=["a", "b", "c"])
    assert choice.validate(None) is None
    assert choice.validate

# Generated at 2022-06-18 12:17:32.919792
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default=1)
    assert field.get_default_value() == 1
    field = Field(default=lambda: 1)
    assert field.get_default_value() == 1


# Generated at 2022-06-18 12:17:42.137826
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:17:53.908780
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(
        items=Integer(),
        additional_items=Integer(),
        min_items=1,
        max_items=3,
        unique_items=True,
        allow_null=False,
    )
    value = [1, 2, 3]
    assert field.validate(value) == value

    # Test case 2
    field = Array(
        items=Integer(),
        additional_items=Integer(),
        min_items=1,
        max_items=3,
        unique_items=True,
        allow_null=False,
    )
    value = [1, 2, 3, 4]
    with pytest.raises(ValidationError) as excinfo:
        field.validate(value)

# Generated at 2022-06-18 12:18:16.798591
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:28.893606
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:38.293773
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    # Input:
    #   value = [1, 2, 3]
    #   items = [Integer(), Integer(), Integer()]
    #   additional_items = False
    #   min_items = None
    #   max_items = None
    #   unique_items = False
    #   allow_null = False
    #   strict = False
    # Expected output:
    #   [1, 2, 3]
    value = [1, 2, 3]
    items = [Integer(), Integer(), Integer()]
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    allow_null = False
    strict = False

# Generated at 2022-06-18 12:18:40.443183
# Unit test for constructor of class String
def test_String():
    try:
        String()
    except Exception as e:
        print(e)
        assert False
    assert True


# Generated at 2022-06-18 12:18:53.067253
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:19:04.789124
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("") == None
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:19:14.782102
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with valid data
    field = Union([String(), Number()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    # Test with invalid data
    with pytest.raises(ValidationError):
        field.validate(True)
    with pytest.raises(ValidationError):
        field.validate(None)
    # Test with nullable field
    field = Union([String(), Number()], allow_null=True)
    assert field.validate(None) is None
    # Test with strict mode
    field = Union([String(), Number()])
    with pytest.raises(ValidationError):
        field.validate(123, strict=True)
    # Test with strict mode and nullable field

# Generated at 2022-06-18 12:19:25.823022
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"

# Generated at 2022-06-18 12:19:28.437339
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const == None
    assert Const(const=1).const == 1
    assert Const(const="string").const == "string"
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const=[1, 2, 3]).const == [1, 2, 3]
    assert Const(const={"a": 1, "b": 2}).const == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:19:40.515811
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(1) == 1
    assert num.validate("1") == 1
    assert num.validate("1.0") == 1.0
    assert num.validate("1.1") == 1.1
    assert num.validate("1.1", strict=True) == 1.1
    assert num.validate("1.1", strict=False) == 1.1
    assert num.validate("1.1", strict=True) == 1.1
    assert num.validate("1.1", strict=False) == 1.1
    assert num.validate("1.1", strict=True) == 1.1
    assert num.validate("1.1", strict=False) == 1.1
    assert num.validate("1.1", strict=True) == 1

# Generated at 2022-06-18 12:20:05.868535
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for method validate(self, value, *, strict=False)
    # of class Object
    # Testing for case when value is None and self.allow_null is True
    # Expected result: return None
    properties = {"name": String(max_length=10)}
    obj = Object(properties=properties, allow_null=True)
    assert obj.validate(None) == None

    # Testing for case when value is None and self.allow_null is False
    # Expected result: raise ValidationError
    properties = {"name": String(max_length=10)}
    obj = Object(properties=properties, allow_null=False)
    with pytest.raises(ValidationError):
        obj.validate(None)

    # Testing for case when value is not None and not isinstance(value, (dict, typing.M

# Generated at 2022-06-18 12:20:12.398505
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=String(), min_items=2, max_items=3)
    field.validate(["a", "b"])
    field.validate(["a", "b", "c"])
    with pytest.raises(ValidationError):
        field.validate(["a"])
    with pytest.raises(ValidationError):
        field.validate(["a", "b", "c", "d"])



# Generated at 2022-06-18 12:20:25.167585
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "A"), ("b", "B")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    field = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    assert field.validate("") is None

# Generated at 2022-06-18 12:20:35.502153
# Unit test for constructor of class Array
def test_Array():
    a = Array(items=None, additional_items=False, min_items=None, max_items=None, exact_items=None, unique_items=False)
    assert a.items is None
    assert a.additional_items is False
    assert a.min_items is None
    assert a.max_items is None
    assert a.unique_items is False
    assert a.allow_null is False
    assert a.default is None
    assert a.description is None
    assert a.title is None
    assert a.validators == []

# Generated at 2022-06-18 12:20:47.046880
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:20:59.256422
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const is None
    assert Const(const=1).const == 1
    assert Const(const="a").const == "a"
    assert Const(const=True).const is True
    assert Const(const=False).const is False
    assert Const(const=[]).const == []
    assert Const(const={}).const == {}
    assert Const(const=()).const == ()
    assert Const(const=set()).const == set()
    assert Const(const=frozenset()).const == frozenset()
    assert Const(const=1.0).const == 1.0
    assert Const(const=1j).const == 1j
    assert Const(const=1+1j).const == 1+1j
    assert Const(const=1+1j).const == 1+1j

# Generated at 2022-06-18 12:21:08.974767
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    with pytest.raises(ValidationError):
        choice.validate(None, strict=True)
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate("", strict=True)




# Generated at 2022-06-18 12:21:21.686756
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:29.967639
# Unit test for method serialize of class Array

# Generated at 2022-06-18 12:21:36.345511
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")



# Generated at 2022-06-18 12:22:16.831063
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:22:27.836542
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    assert s.validate("abc") == "abc"
    assert s.validate("") == ""
    assert s.validate(None) == None
    assert s.validate(1) == "1"
    assert s.validate(True) == "True"
    assert s.validate(False) == "False"
    assert s.validate(1.0) == "1.0"
    assert s.validate(1.1) == "1.1"
    assert s.validate(1.1+1.1j) == "(1.1+1.1j)"
    assert s.validate(1.1+1.1j) == "(1.1+1.1j)"

# Generated at 2022-06-18 12:22:34.900052
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any) -> None:
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)

# Generated at 2022-06-18 12:22:41.248246
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "a"), ("b", "b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    with pytest.raises(ValidationError):
        field.validate("c")
    with pytest.raises(ValidationError):
        field.validate("")
    with pytest.raises(ValidationError):
        field.validate(None)



# Generated at 2022-06-18 12:22:53.197329
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_field = Choice(choices=[("a", "a"), ("b", "b")])
    assert test_field.validate("a") == "a"
    assert test_field.validate("b") == "b"
    try:
        test_field.validate("c")
        assert False
    except ValidationError:
        assert True
    try:
        test_field.validate("")
        assert False
    except ValidationError:
        assert True
    test_field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert test_field.validate(None) == None
    assert test_field.validate("a") == "a"
    assert test_field.validate("b") == "b"

# Generated at 2022-06-18 12:23:01.610554
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1
    any_of = [String(), Number()]
    union = Union(any_of)
    value = "test"
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].code == "type"
        assert e.messages()[0].index == []
        assert e.messages()[0].text == "Must be a number."
    else:
        assert False

    # Test case 2
    any_of = [String(), Number()]
    union = Union(any_of)
    value = 1
    try:
        union.validate(value)
    except ValidationError as e:
        assert e.messages()[0].code == "type"
        assert e.messages()[0].index == []
