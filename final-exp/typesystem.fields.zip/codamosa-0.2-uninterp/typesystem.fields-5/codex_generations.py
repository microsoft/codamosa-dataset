

# Generated at 2022-06-18 12:15:45.680253
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:15:54.347618
# Unit test for constructor of class Array
def test_Array():
    items = [
        String(max_length=10),
        Integer(minimum=0, maximum=100),
        Boolean(),
    ]
    additional_items = Boolean()
    min_items = 3
    max_items = 5
    unique_items = True
    array = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    assert array.items == items
    assert array.additional_items == additional_items
    assert array.min_items == min_items
    assert array.max_items == max_items
    assert array.unique_items == unique_items


# Generated at 2022-06-18 12:15:59.893488
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field.get_default_value() == None
    field = Field(default="default")
    assert field.get_default_value() == "default"
    field = Field(default=lambda: "default")
    assert field.get_default_value() == "default"


# Generated at 2022-06-18 12:16:03.828823
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)



# Generated at 2022-06-18 12:16:08.998584
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=150),
    }
    schema = Object(properties=properties)
    value = {"name": "John", "age": 30}
    assert schema.validate(value) == value

    # Test case 2
    properties = {
        "name": String(required=True),
        "age": Integer(minimum=0, maximum=150),
    }
    schema = Object(properties=properties)
    value = {"name": "John", "age": "30"}
    assert schema.validate(value) == {"name": "John", "age": 30}

    # Test case 3

# Generated at 2022-06-18 12:16:15.345694
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test with two fields
    field1 = Field()
    field2 = Field()
    union = field1 | field2
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]

    # Test with a field and a union
    field3 = Field()
    union2 = union | field3
    assert isinstance(union2, Union)
    assert union2.any_of == [field1, field2, field3]



# Generated at 2022-06-18 12:16:26.249235
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"
    assert String(format="date").serialize("2020-01-01") == "2020-01-01"

# Generated at 2022-06-18 12:16:31.967248
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(
        items=String(),
        additional_items=False,
        min_items=1,
        max_items=None,
        unique_items=False,
        allow_null=False,
        default=None,
    )
    value = ["a"]
    result = field.validate(value)
    assert result == ["a"]

    # Test case 2
    field = Array(
        items=String(),
        additional_items=False,
        min_items=1,
        max_items=None,
        unique_items=False,
        allow_null=False,
        default=None,
    )
    value = ["a", "b"]
    result = field.validate(value)
    assert result == ["a", "b"]

    # Test case 3
   

# Generated at 2022-06-18 12:16:40.168354
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert choice.validate(None) == None
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")

# Generated at 2022-06-18 12:16:51.567931
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic import BaseModel, ValidationError
    from pydantic.error_wrappers import ErrorWrapper
    from pydantic.errors import Error
    from pydantic.fields import Field
    from pydantic.main import BaseModel as BaseModel_
    from pydantic.schema import SchemaError
    from pydantic.types import AnyHttpUrl, AnyUrl, ConstrainedStr, EmailStr, HttpUrl, UrlStr
    from pydantic.validators import validator
    from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Type, TypeVar, Union
    from typing import cast as typing_cast
    from typing_extensions import Literal
    from uuid import UUID
    from datetime import datetime, date, time
    from decimal import Decimal
    from enum import En

# Generated at 2022-06-18 12:17:21.998700
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(minimum=1).validate(1) == 1
    assert Number(minimum=1).validate(2) == 2
    assert Number(minimum=1).validate(0) == 0
    assert Number(minimum=1).validate(-1) == -1
    assert Number(minimum=1).validate(-2) == -2
    assert Number(minimum=1).validate(0.5) == 0.5
    assert Number(minimum=1).validate(1.5) == 1.5
    assert Number(minimum=1).validate(2.5) == 2.5
    assert Number(minimum=1).validate(-0.5) == -0.5
    assert Number(minimum=1).validate(-1.5) == -1.5
    assert Number(minimum=1).validate(-2.5)

# Generated at 2022-06-18 12:17:33.897010
# Unit test for method validate of class String
def test_String_validate():
    assert String(allow_blank=True).validate(None) == ""
    assert String(allow_blank=True).validate("") == ""
    assert String(allow_blank=True).validate(" ") == " "
    assert String(allow_blank=True).validate("\t") == "\t"
    assert String(allow_blank=True).validate("\n") == "\n"
    assert String(allow_blank=True).validate("\r") == "\r"
    assert String(allow_blank=True).validate("\r\n") == "\r\n"
    assert String(allow_blank=True).validate("\n\r") == "\n\r"
    assert String(allow_blank=True).validate("\r\n\r\n") == "\r\n\r\n"

# Generated at 2022-06-18 12:17:37.778144
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=None).const == None
    assert Const(const=1).const == 1
    assert Const(const="a").const == "a"
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const=[1,2,3]).const == [1,2,3]
    assert Const(const={"a":1}).const == {"a":1}
    assert Const(const={"a":1, "b":2}).const == {"a":1, "b":2}


# Generated at 2022-06-18 12:17:40.973300
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String, Integer
    from typesystem.unions import Union
    assert (String() | Integer()) == Union(any_of=[String(), Integer()])
    assert (String() | Integer() | String()) == Union(any_of=[String(), Integer(), String()])



# Generated at 2022-06-18 12:17:44.608824
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any
    # of class Union
    # This method is not tested because it is not used in the code
    pass


# Generated at 2022-06-18 12:17:56.114308
# Unit test for method validate of class Union

# Generated at 2022-06-18 12:18:06.606859
# Unit test for method validate of class Union
def test_Union_validate():
    # Test for method validate(self, value, strict=False)
    # Tests if the method validate returns the correct value
    # when the value is not None
    # Input:
    #   value: not None
    #   strict: False
    # Expected output:
    #   validated value
    # Assertion:
    #   assertEqual(validated value, expected value)
    #   assertEqual(error, None)
    any_of = [String(min_length=1), Integer()]
    union = Union(any_of)
    value = "test"
    validated, error = union.validate_or_error(value)
    assert validated == value
    assert error is None

    # Test for method validate(self, value, strict=False)
    # Tests if the method validate returns the correct value
    # when

# Generated at 2022-06-18 12:18:18.457537
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for method validate(self, value, strict=False)
    # Unit test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # Test for method validate of class Array
    class TestArray(Array):
        def __init__(self, *args, **kwargs):
            super().__

# Generated at 2022-06-18 12:18:30.350654
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "A"), ("b", "B")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    with pytest.raises(ValidationError):
        choice.validate("c")
    assert choice.validate

# Generated at 2022-06-18 12:18:39.159679
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:19:02.387338
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1
    assert Const(const=None).const == None
    assert Const(const=True).const == True
    assert Const(const=False).const == False
    assert Const(const="Hello").const == "Hello"
    assert Const(const=[1,2,3]).const == [1,2,3]
    assert Const(const={"a":1,"b":2}).const == {"a":1,"b":2}
    assert Const(const={"a":1,"b":2}, title="test").const == {"a":1,"b":2}
    assert Const(const={"a":1,"b":2}, description="test").const == {"a":1,"b":2}

# Generated at 2022-06-18 12:19:03.535185
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field() | Field()



# Generated at 2022-06-18 12:19:12.485513
# Unit test for method validate of class Union
def test_Union_validate():
    # Test with one child
    child = Integer()
    any_of = [child]
    union = Union(any_of)
    assert union.validate(1) == 1
    assert union.validate("1") == 1
    assert union.validate(1.0) == 1
    assert union.validate(True) == 1
    assert union.validate(False) == 0
    assert union.validate(None) == None
    assert union.validate("") == None
    assert union.validate("a") == None
    assert union.validate(1.1) == None
    assert union.validate(1.1) == None
    assert union.validate(1.1) == None
    assert union.validate(1.1) == None
    assert union.validate(1.1) == None


# Generated at 2022-06-18 12:19:23.620218
# Unit test for method validate of class Union
def test_Union_validate():
    # Test 1
    any_of = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=0, maximum=100),
        Integer(minimum=0, maximum=100),
    ]
    field = Union(any_of=any_of)
    value = 10
    assert field.validate(value) == value
    # Test 2
    any_of = [
        Integer(minimum=0, maximum=100),
        Integer(minimum=0, maximum=100),
        Integer(minimum=0, maximum=100),
    ]
    field = Union(any_of=any_of)
    value = 101
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.messages() == [Message(text="Did not match any valid type.", code="union")]

# Generated at 2022-06-18 12:19:35.743442
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:19:43.630287
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("a", "b"), ("c", "d")])
    assert c.validate("a") == "a"
    assert c.validate("b") == "b"
    assert c.validate("c") == "c"
    assert c.validate("d") == "d"
    with pytest.raises(ValidationError):
        c.validate("e")
    with pytest.raises(ValidationError):
        c.validate("")
    with pytest.raises(ValidationError):
        c.validate(None)



# Generated at 2022-06-18 12:19:53.473383
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:20:04.499554
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=['a','b','c'])
    assert choice.validate('a') == 'a'
    assert choice.validate('b') == 'b'
    assert choice.validate('c') == 'c'
    assert choice.validate('') == ''
    assert choice.validate(None) == None
    assert choice.validate('d') == 'd'
    assert choice.validate('e') == 'e'
    assert choice.validate('f') == 'f'
    assert choice.validate('g') == 'g'
    assert choice.validate('h') == 'h'
    assert choice.validate('i') == 'i'
    assert choice.validate('j') == 'j'
    assert choice.validate('k') == 'k'

# Generated at 2022-06-18 12:20:15.033611
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:20:20.333015
# Unit test for method validate of class Union
def test_Union_validate():
    import json
    from pprint import pprint
    from jsonschema import validate
    # Define a schema, for validation.
    schema = {
        "type" : "object",
        "properties" : {
            "price" : {"type" : "number"},
            "name" : {"type" : "string"},
        },
    }
    # If no exception is raised by validate(), the instance is valid.
    validate(instance={"name" : "Eggs", "price" : 34.99}, schema=schema)
    # If validate() does not raise an exception, the instance is valid.
    validate(instance={"name" : "Eggs", "price" : "Invalid"}, schema=schema)
    # If validate() raises a ValidationError, the instance is invalid.

# Generated at 2022-06-18 12:20:32.483695
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=False)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == False


# Generated at 2022-06-18 12:20:42.273829
# Unit test for method serialize of class Array

# Generated at 2022-06-18 12:20:54.614432
# Unit test for method validate of class String
def test_String_validate():
    assert String(title='test', description='test', allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate('test') == 'test'
    assert String(title='test', description='test', allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate('test') == 'test'
    assert String(title='test', description='test', allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).validate('test') == 'test'

# Generated at 2022-06-18 12:21:05.794116
# Unit test for method validate of class Object

# Generated at 2022-06-18 12:21:12.806254
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1
    field = Array(items=Integer())
    value = [1, 2, 3]
    expected = [1, 2, 3]
    actual = field.validate(value)
    assert actual == expected

    # Test case 2
    field = Array(items=Integer())
    value = [1, 2, 3, 4, 5, 6]
    expected = [1, 2, 3, 4, 5, 6]
    actual = field.validate(value)
    assert actual == expected

    # Test case 3
    field = Array(items=Integer())
    value = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    expected = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    actual = field.validate(value)


# Generated at 2022-06-18 12:21:25.092799
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:35.055363
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:43.151855
# Unit test for method validate of class Array

# Generated at 2022-06-18 12:21:52.484747
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("a", "b"), ("c", "d")])
    assert choice.validate("a") == "a"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("e")
    with pytest.raises(ValidationError):
        choice.validate("")
    choice = Choice(choices=[("a", "b"), ("c", "d")], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("c") == "c"
    assert choice.validate(None) == None
    with pytest.raises(ValidationError):
        choice.validate("e")

# Generated at 2022-06-18 12:21:59.513428
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    value = {"name": "John", "age": 20}
    assert obj.validate(value) == value

    # Test case 2
    properties = {
        "name": String(max_length=10),
        "age": Integer(minimum=0, maximum=100),
    }
    obj = Object(properties=properties)
    value = {"name": "John", "age": -1}

# Generated at 2022-06-18 12:22:07.542387
# Unit test for constructor of class String
def test_String():
    assert String(title="title", description="description", default="default", allow_null=True)


# Generated at 2022-06-18 12:22:17.212466
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=["a", "b", "c"])
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        choice.validate("d")
    with pytest.raises(ValidationError):
        choice.validate("")
    with pytest.raises(ValidationError):
        choice.validate(None)
    choice = Choice(choices=["a", "b", "c"], allow_null=True)
    assert choice.validate("a") == "a"
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"

# Generated at 2022-06-18 12:22:28.244692
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=Integer()).serialize([1, 2, 3]) == [1, 2, 3]
    assert Array(items=Integer()).serialize(None) == None
    assert Array(items=Integer()).serialize([]) == []
    assert Array(items=Integer()).serialize(["1", "2", "3"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize(["1", "2", "3", "a"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, 3, "a"]) == [1, 2, 3]
    assert Array(items=Integer()).serialize([1, 2, 3, 4]) == [1, 2, 3, 4]

# Generated at 2022-06-18 12:22:35.151055
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("") == ""
    assert String().validate("Hello") == "Hello"
    assert String().validate(None) == None
    assert String().validate(1) == "1"
    assert String().validate(1.0) == "1.0"
    assert String().validate(True) == "True"
    assert String().validate(False) == "False"
    assert String().validate(["Hello"]) == "['Hello']"
    assert String().validate({"Hello": "World"}) == "{'Hello': 'World'}"
    assert String().validate(b"Hello") == "Hello"
    assert String().validate(bytearray(b"Hello")) == "Hello"
    assert String().validate(memoryview(b"Hello")) == "Hello"

# Generated at 2022-06-18 12:22:46.542315
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestArray(Array):
        def __init__(self, *, items: typing.Union[Field, typing.Sequence[Field]] = None, additional_items: typing.Union[Field, bool] = False, min_items: int = None, max_items: int = None, exact_items: int = None, unique_items: bool = False, **kwargs: typing.Any):
            super().__init__(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, exact_items=exact_items, unique_items=unique_items, **kwargs)
    class TestField(Field):
        def __init__(self, *, allow_null: bool = False, default: typing.Any = None, **kwargs: typing.Any):
            super().__init__

# Generated at 2022-06-18 12:22:50.969133
# Unit test for constructor of class String
def test_String():
    s = String(title="test", description="test", default="test", allow_null=False)
    assert s.title == "test"
    assert s.description == "test"
    assert s.default == "test"
    assert s.allow_null == False


# Generated at 2022-06-18 12:23:00.322782
# Unit test for method validate of class Union
def test_Union_validate():
    from jsonschema import validate
    from jsonschema.exceptions import ValidationError
    import json
    import jsonschema
    import jsonschema.exceptions
    import jsonschema.validators
    import typing
    import uuid
    from datetime import datetime
    from dataclasses import dataclass
    from typing import Any, Dict, List, Optional, Union
    from jsonschema import validate
    from jsonschema.exceptions import ValidationError
    import json
    import jsonschema
    import jsonschema.exceptions
    import jsonschema.validators
    import typing
    import uuid
    from datetime import datetime
    from dataclasses import dataclass
    from typing import Any, Dict, List, Optional, Union