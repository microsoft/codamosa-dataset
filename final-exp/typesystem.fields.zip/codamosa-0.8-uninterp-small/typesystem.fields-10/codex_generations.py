

# Generated at 2022-06-26 10:12:21.931373
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    bool_0 = Boolean()
    bool_1 = Boolean()
    bool_2 = Boolean()
    bool_3 = Boolean()
    bool_4 = Boolean()
    bool_5 = Boolean()
    bool_6 = Boolean()
    bool_7 = Boolean()
    bool_8 = Boolean()
    bool_9 = Boolean()
    bool_10 = Boolean()
    bool_11 = Boolean()
    bool_12 = Boolean()
    bool_13 = Boolean()
    bool_14 = Boolean()
    bool_15 = Boolean()
    bool_16 = Boolean()
    bool_17 = Boolean()
    bool_18 = Boolean()
    bool_19 = Boolean()
    bool_20 = Boolean()
    bool_21 = Boolean()
    bool_22 = Boolean()
    bool_23 = Boolean()
    bool_24 = Boolean()

# Generated at 2022-06-26 10:12:32.326306
# Unit test for method validate of class Union

# Generated at 2022-06-26 10:12:35.327218
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    text_0 = Text()
    text_0.validate_or_error(None, strict=False)



# Generated at 2022-06-26 10:12:41.315445
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    text_0 = Text()
    # test case 1
    if isinstance(text_0.get_default_value(), int):
        return 1
    else:
        return 0


# Generated at 2022-06-26 10:12:48.282588
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_data = ["", "a", "b", "c", "d"]
    choice_0 = Choice(choices=["a", "b", "c"])
    for test_value in test_data:
        try:
            choice_0.validate(test_value)
        except ValidationError:
            if test_value in ["a", "b", "c"]:
                raise Exception(
                    "choice_0.validate({}) raises \
                        ValidationError, when it should not".format(
                        test_value
                    )
                )
        else:
            if test_value not in ["a", "b", "c"]:
                raise Exception(
                    "choice_0.validate({}) does not raise \
                        ValidationError, when it should".format(
                        test_value
                    )
                )

# Generated at 2022-06-26 10:12:54.965991
# Unit test for method validate of class Array
def test_Array_validate():
    # test case 1
    instance = Array()
    value = []
    assert instance.validate(value) == value
    # test case 2
    value = ["a", "b", "c"]
    assert instance.validate(value) == value
    # test case 3
    value = ["a", "b", "c", "d"]
    try:
        instance.validate(value)
    except ValidationError as e:
        assert len(e.messages) == 1
        assert e.messages[0].code == "max_items"
        assert e.messages[0].text == "Must have no more than None items."
        assert e.messages[0].index == []
        assert e.messages[0].key == None
    else:
        assert False


# Generated at 2022-06-26 10:13:04.897545
# Unit test for method validate of class Number
def test_Number_validate():
    number_1 = Number()
    number_1.validate(123)
    number_1.validate('123')
    number_2 = Number(strict = True)
    number_2.validate(123)
    number_2.validate('123.4')
    number_3 = Number(allow_null = True)
    number_3.validate(None)
    number_4 = Number(allow_null = True, allow_blank = True)
    number_4.validate("")
    number_5 = Number(minimum = 10, maximum = 20)
    number_5.validate(15)
    number_6 = Number(minimum = 10, exclusive_maximum = 20)
    number_6.validate(15)
    number_7 = Number(maximum = 20, exclusive_minimum = 10)
    number_

# Generated at 2022-06-26 10:13:05.979162
# Unit test for method __or__ of class Field
def test_Field___or__():
    test_case_0()


# Generated at 2022-06-26 10:13:12.637859
# Unit test for method __or__ of class Field
def test_Field___or__():
    """
    Test method __or__ of class Field
    """
    assert True == True
    text_0 = Text()
    text_1 = Text()
    union_0 = text_0 | text_1
    field_typesystem_0 = Field()
    field_typesystem_1 = Field()
    field_typesystem_2 = Field()
    union_1 = field_typesystem_0 | field_typesystem_1 | field_typesystem_2

if __name__ == "__main__":
    test_case_0()
    test_Field___or__()

# Generated at 2022-06-26 10:13:18.546468
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    text_0 = Text()
    text_0.default = 1
    text_0.description = "description"
    text_0.title = "title"
    text_0.allow_null = False
    assert Field.get_default_value(text_0) == 1


# Generated at 2022-06-26 10:14:11.824250
# Unit test for method validate of class Choice
def test_Choice_validate():
    new_Choice = Choice()


# Generated at 2022-06-26 10:14:25.139539
# Unit test for method validate of class Union
def test_Union_validate():
    cases = []
    what = "????"
    cases.append((None, ValidationError))

    cases = []
    what = "????"
    cases.append((None, ValidationError))

    cases = []
    what = "????"
    cases.append((None, ValidationError))

    cases = []
    what = "????"
    cases.append((None, ValidationError))

    for case in cases:
        try:
            Union_validate(case[0], case[1])
        except Exception:
            print("Failed case:")
            print(case)
            print("Which was called by:")
            print(what)
            raise

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 10:14:39.188142
# Unit test for method validate of class Choice
def test_Choice_validate():
    str_0 = Choice(allow_null=True)
    str_0.validate(None, strict=False)

    str_0 = Choice(allow_null=True)
    str_0.validate(None, strict=True)

    str_0 = Choice(allow_null=False)
    str_0.validate(None)

    str_0 = Choice(allow_null=True, choices=[('a', 'a')])
    str_0.validate('a', strict=False)

    str_0 = Choice(allow_null=True, choices=[('a', 'a')])
    str_0.validate('a', strict=True)

    str_0 = Choice(allow_null=False, choices=[('a', 'a')])
    str_0.validate('a')



# Generated at 2022-06-26 10:14:45.327225
# Unit test for method validate of class Union
def test_Union_validate():
    text_0 = Text()
    text_1 = Text()
    union_0 = Union(any_of=[text_0, text_1])
    error_0 = union_0.validate("foo")
    assert error_0 is None
    error_1 = union_0.validate("bar")
    assert error_1 is None

# Generated at 2022-06-26 10:14:50.305235
# Unit test for method validate of class String
def test_String_validate():
    try:
        text_0 = Text()
        text_0.validate('asdfghjkl')
    except:
        raise Exception("Unable to validate string")


# Generated at 2022-06-26 10:15:00.276649
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array()
    schema.validate([])
    schema.validate([1, 2, 3])
    schema.validate(["a", "b", "c"])
    schema.validate([1, 2, 3], strict=True)
    schema.validate(["a", "b", "c"], strict=True)
    schema.validate(["a", "b", "c"], strict=True)
    with pytest.raises(ValidationError):
        schema.validate(3)
    with pytest.raises(ValidationError):
        schema.validate("not_an_array")
    with pytest.raises(ValidationError):
        schema.validate([1, 2, 3], strict=False)

# Generated at 2022-06-26 10:15:11.798438
# Unit test for method validate of class Choice

# Generated at 2022-06-26 10:15:23.923422
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case: Missing first argument
    args = []
    try:
        text_0 = Union(*args)
    except TypeError:
        pass

    # Test case: First argument is empty
    args = [[]]
    try:
        text_0 = Union(*args)
    except (TypeError, ValueError):
        pass
    text_0 = Union([Text()])
    text_1 = Union([Text(), Integer()])
    # Test case: First argument is not a type
    args = [[""], Text(), Integer()]
    try:
        text_0 = Union(*args)
    except TypeError:
        pass

    # Test case: First argument is not a Union
    args = [[], [Text()], Integer()]
    try:
        text_0 = Union(*args)
    except TypeError:
        pass



# Generated at 2022-06-26 10:15:25.403577
# Unit test for method serialize of class Array
def test_Array_serialize():
    inputArgs = ("string")
    expectedResult = ("string")
    result = Array(Text()).serialize(inputArgs)
    assert result == expectedResult


# Generated at 2022-06-26 10:15:37.376771
# Unit test for method validate of class Object
def test_Object_validate():
    obj_schema = Object(
            properties={
                "x": Integer(),
                "y": Integer(),
                "z": Integer(),
            },
            required=["x"]
        )

    try:
        obj_schema.validate({"x": 1, "y": 2})
        assert False, "No out"
    except ValidationError as e:
        assert isinstance(e.__cause__, ValidationError)
        assert e.__cause__.code == "required"
        assert e.__cause__.index == ["z"]
        assert e.__cause__.text == "This field is required."
        assert e.messages() == [
            Message(text="This field is required.", index=["z"], code="required")
        ]
    # Test: Invalid type

# Generated at 2022-06-26 10:15:51.760768
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default = "test_default")
    assert field.get_default_value() == "test_default"

# Generated at 2022-06-26 10:15:56.714571
# Unit test for method validate of class Array
def test_Array_validate():
    arr_0 = Array(min_items=1,unique_items=True,max_items=5,items=[],allow_null=False)
    val_0 = []
    val_1 = arr_0.validate(val_0)
    assert_equal(val_1, [])


# Generated at 2022-06-26 10:16:07.776982
# Unit test for method validate of class Array
def test_Array_validate():

    # Negative test case for Array validate
    # Tests whether validation fails on providing non list input
    # Return is false and validation error is not empty

    text_0 = Text()
    field_0 = Array(text_0)
    test_value_0 = 'abcd'
    ret_0, error_0 = field_0.validate_or_error(test_value_0)
    assert(ret_0 == 'abcd' and error_0 is not None)

    # Negative test case for Array validate
    # Tests whether validation fails on providing list of values not of item type
    # Return is false and validation error is not empty

    text_1 = Text()
    field_1 = Array(text_1)
    test_value_1 = ['abcd', 'abcd', 1]
    ret_1, error_1 = field_1

# Generated at 2022-06-26 10:16:18.199045
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Create instance of class

    bool_0 = Boolean()
    bool_0.allow_true = True
    bool_0.allow_false = True
    bool_0.allow_1 = False
    bool_0.allow_0 = True
    bool_0.allow_on = True
    bool_0.allow_off = False
    bool_0.allow_none = False
    bool_0.allow_null = False
    bool_0.allow_blank = False
    bool_0.strict = True

    # Expectation
    expected = True

    # Actual
    actual = bool_0.validate(True)

    # Unit test
    assert actual == expected


# Generated at 2022-06-26 10:16:22.153121
# Unit test for method validate of class Union
def test_Union_validate():
    text_0 = Text()
    union_0 = Union([text_0])
    test_value = "asd"
    expected_result = "asd"
    actual_result = union_0.validate(test_value)
    assert actual_result == expected_result



# Generated at 2022-06-26 10:16:30.326560
# Unit test for method validate of class Array
def test_Array_validate():
    text_0 = Text()
    text_0_list = Array(items=text_0)
    text_0_list.validate(["hello", "world"])
    text_1_list = Array(items=text_0, unique_items=True)
    text_1_list.validate(["hello", "world"])
    text_2_list = Array(items=text_0, unique_items=True)
    with raises(ValidationError):
        text_2_list.validate(["hello", "world", "hello"])



# Generated at 2022-06-26 10:16:37.841649
# Unit test for constructor of class String
def test_String():
    with pytest.raises(AssertionError):
        String(allow_blank = False, trim_whitespace = True, max_length = None, min_length = None, pattern = "", format = "")
    
    assert String(allow_blank = False, trim_whitespace = True, max_length = 3000, min_length = None, pattern = "", format = "")
    assert String(allow_blank = False, trim_whitespace = True, max_length = None, min_length = 3000, pattern = "", format = "")


# Generated at 2022-06-26 10:16:39.511180
# Unit test for method validate of class String
def test_String_validate():
    test_case_0()


# Generated at 2022-06-26 10:16:51.039948
# Unit test for method validate of class Array
def test_Array_validate():
    # Test normal case
    text = Text()
    array = Array(text)
    message = array.validate(['hi'])
    assert message == ['hi']

    # Test null case
    array = Array(text)
    try:
        message = array.validate(None)
    except ValidationError as error:
        message = error.messages[0].text
        assert message == "May not be null."

    # Test type case
    array = Array(text)
    try:
        message = array.validate(1)
    except ValidationError as error:
        message = error.messages[0].text
        assert message == "Must be an array."

    # Test empty case
    array = Array(text, min_items=1)

# Generated at 2022-06-26 10:16:56.262557
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    field_0.default = '2018-10-02'
    expected_result_0 = '2018-10-02'
    assert field_0.get_default_value() == expected_result_0



# Generated at 2022-06-26 10:17:12.916459
# Unit test for method validate of class String
def test_String_validate():
    text_0 = Text(allow_null=True, id=None, title=None, description=None)
    result_0 = text_0.validate(None)
    assert(result_0 == None)
    text_1 = Text()
    result_1 = text_1.validate(None)
    assert(result_1 == "")
    text_2 = Text(allow_blank=True)
    result_2 = text_2.validate('')
    assert(result_2 == '')
    text_3 = Text()
    result_3 = text_3.validate('')
    assert(result_3 == '')


# Generated at 2022-06-26 10:17:22.734687
# Unit test for method validate of class Number
def test_Number_validate():
    # Unit test case declaration
    decimal_0 = decimal.Decimal('NaN')
    decimal_1 = decimal.Decimal('-inf')
    decimal_2 = decimal.Decimal('inf')
    with pytest.raises(ValidationError):
        Number(precision="NaN").validate(decimal_0)
        # Unit test case execution
        with pytest.raises(ValidationError):
            Number(precision="-inf").validate(decimal_1)
            # Unit test case execution
            with pytest.raises(ValidationError):
                Number(precision="inf").validate(decimal_2)
                # Unit test case execution
                pass


# Generated at 2022-06-26 10:17:33.491845
# Unit test for constructor of class String
def test_String():
    text_0 = String()
    text_1 = String(title='this is a title',description='this is a description',default='default value')
    text_2 = String(title='this is a title',description='this is a description',default='default value',allow_null=True)
    text_3 = String(title='this is a title',description='this is a description',default='default value',allow_blank=True)
    text_4 = String(title='this is a title',description='this is a description',default='default value',trim_whitespace=False)
    text_5 = String(title='this is a title',description='this is a description',default='default value',max_length=10)

# Generated at 2022-06-26 10:17:38.987723
# Unit test for method validate of class Union
def test_Union_validate():
    text_0 = Text()
    text_1 = Text()
    union_0 = Union([text_0,text_1])
    with pytest.raises(ValidationError):
        union_0.validate(None)


# Generated at 2022-06-26 10:17:42.702967
# Unit test for method serialize of class Array
def test_Array_serialize():
    text_0 = Text()
    array_0 = Array(items=text_0, additional_items=True)
    assert array_0.serialize(["test"]) == ['test']
    assert array_0.serialize(None) == None


# Generated at 2022-06-26 10:17:47.043241
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    choice_0.validate(value=2)


# Generated at 2022-06-26 10:17:51.865838
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    text_1 = Text()
    union_0 = text_0 | text_1
    text_2 = Text()
    union_1 = union_0 | text_2



# Generated at 2022-06-26 10:17:53.590792
# Unit test for method validate of class Number
def test_Number_validate():
    num_1 = Number(5,10)
    num_1.validate(5)


# Generated at 2022-06-26 10:18:05.576352
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case: empty array
    array_0 = Array()
    test_case_0 = []
    array_0.validate(test_case_0)

    # Test case: String array
    array_1 = Array(Text())
    test_case_1 = ["copy", "copy", "copy"]
    array_1.validate(test_case_1)

    # Test case: misspelled key
    array_2 = Array(properties={"content": Text()})
    with pytest.raises(ValidationError):
        test_case_2 = {"contet": "wrong key"}
        array_2.validate(test_case_2)

    # Test case: non-string key
    array_3 = Array(properties={1: Text()})
    with pytest.raises(ValidationError):
        test

# Generated at 2022-06-26 10:18:08.835704
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    text_0 = Text()
    text_0.default = 'Text.default'
    text_0.default = 'my_default'


# Generated at 2022-06-26 10:18:27.375552
# Unit test for method validate of class String
def test_String_validate():
    name = String(max_length=50)

    try:
        name.validate('asdf')
    except:
        print("test_String_validate failed")

    try:
        name.validate(5)
        print("test_String_validate failed")
    except:
        pass


# Generated at 2022-06-26 10:18:30.968318
# Unit test for constructor of class String
def test_String():
    s = String()
    assert isinstance(s, String), "Constructor of class String should return an instance of String"


# Generated at 2022-06-26 10:18:34.188480
# Unit test for constructor of class Const
def test_Const():
    x = Const(1)
    assert x.allow_null == False and x.const == 1


# Generated at 2022-06-26 10:18:39.456962
# Unit test for method validate of class Array
def test_Array_validate():
    field = Field(description="description")
    items = [Field(title="title")]
    max_items = 10
    min_items = 2
    additional_items = False
    unique_items = True
    array = Array(field, items, min_items, max_items, additional_items, unique_items)
    value = "str"
    result = array.validate(value)
    assert result is value


# Generated at 2022-06-26 10:18:41.960478
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean(title='', description='', default=None, allow_null=False)
    boolean_0.validate(value=None)


# Generated at 2022-06-26 10:18:52.395351
# Unit test for method validate of class Choice
def test_Choice_validate():
    string_0 = String(
        pattern=r"^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$")

# Generated at 2022-06-26 10:19:04.094254
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test for Choice.validate
    choices = [0, 1, 2]
    f1 = Choice(choices)
    assert f1.validate(0) == 0
    assert f1.validate(1) == 1
    assert f1.validate(2) == 2
    
    try:
        f1.validate(3)
    except ValidationError as e:
        assert e.code == 'choice'
        assert e.text == 'Not a valid choice.'

    f1 = Choice(choices, allow_null=True)
    assert f1.validate(0) == 0
    assert f1.validate(1) == 1
    assert f1.validate(2) == 2
    assert f1.validate(None) == None


# Generated at 2022-06-26 10:19:12.745473
# Unit test for method validate of class Union

# Generated at 2022-06-26 10:19:14.255483
# Unit test for constructor of class Const
def test_Const():
    text_0 = Const(12)


# Generated at 2022-06-26 10:19:17.499532
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    field_0.get_default_value()


# Generated at 2022-06-26 10:19:32.887698
# Unit test for method validate of class Number
def test_Number_validate():
    # Test case Number to Number
    n = Number()
    n.validate(2.5)  # returns 2.5
    n.validate(-0.5)  # returns -0.5

    # Test case Number to str
    n2 = Number()
    n2.validate("1")  # returns 1

    # Test case Number to bool
    n3 = Number()
    n3.validate(True)  # raises ValidationError



# Generated at 2022-06-26 10:19:45.455398
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices_2 = [(1, 1)]
    obj_Choice = Choice(choices=choices_2)
    from django_swagger_utils.drf_server.fields.list_field import ListField
    from django_swagger_utils.drf_server.fields.integer_field import IntegerField
    obj_Choice_type = ListField(IntegerField)
    try :
        assert(obj_Choice.validate(value=[]),obj_Choice_type.validate(value=[]))
    except Exception as e:
        print(e)
