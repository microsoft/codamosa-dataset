

# Generated at 2022-06-26 10:11:29.927933
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        'person':   Object(required=["name", "email"]),
        'location': Object()
    }
    value = {'person': {'name': 'John Doe', 'email': 'john@example.org'},
             'location': {'city': 'Gotham City', 'country': 'United States'}}
    obj = Object(properties=properties)
    # print(obj.validate(value))
    # obj.validate()



# Generated at 2022-06-26 10:11:34.914483
# Unit test for method validate of class Choice
def test_Choice_validate():
    number_0 = Number()
    validator_0 = Choice()
    number_1 = Number(maximum=100)
    validator_1 = Choice(choices=[ [0, 10] ])
    validator_2 = Choice(choices=["10"])
    validator_3 = validator_1 | validator_2

    # Testcase 0
    # Call method validate of class Choice
    validator_0.validate(True)
    validator_0.validate(10)
    validator_0.validate(True, strict=True)
    validator_0.validate(10, strict=True)
    validator_0.validate(101, strict=True)

    # Testcase 1
    # Call method validate of class Choice
    # Testcase 1.1

# Generated at 2022-06-26 10:11:45.427572
# Unit test for method validate of class Array
def test_Array_validate():

    number_0 = Number()
    array_0 = Array(items=number_0, additional_items=False, min_items=None, max_items=None, unique_items=False, allow_null=False, default_value=None)
    array_0.validate(value=[1, 1])

    number_0 = Number()
    array_0 = Array(items=number_0, additional_items=False, min_items=None, max_items=None, unique_items=True, allow_null=False, default_value=None)
    array_0.validate(value=[1, 1])

    number_0 = Number()

# Generated at 2022-06-26 10:11:52.474760
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()
    assert string_0.serialize(obj=1) == 1
    string_1 = String(format="date")
    string_0.format = "time"
    string_0 = String(format="date")
    assert string_0.serialize(obj=1) == 1
    assert string_1.serialize(obj=1) == 1


# Generated at 2022-06-26 10:11:57.875191
# Unit test for constructor of class Choice
def test_Choice():
    #if (choice if isinstance(choice, (tuple, list)) else (choice, choice)) not in self.choices:
    test_case_0 = Choice()
    assert test_case_0.choices == []

    test_case_1 = Choice(choices=['choice1','choice2'])
    assert set(test_case_1.choices) == set([('choice1','choice1'),('choice2','choice2')])

    test_case_2 = Choice(choices=[('choice1', 'choice_number_1'), ('choice2', 'choice_number_2')])
    assert test_case_2.choices == [('choice1', 'choice_number_1'), ('choice2', 'choice_number_2')]



# Generated at 2022-06-26 10:11:59.958875
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    choice.validate(None)


# Generated at 2022-06-26 10:12:06.998334
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_1 = Number()
    number_2 = Number()
    number_3 = Number()
    number_4 = Number()
    number_5 = Number()
    number_6 = Number()
    number_7 = Number()
    number_8 = Number()
    number_9 = Number()
    number_10 = Number()
    number_11 = Number()
    number_12 = Number()
    number_13 = Number()
    number_14 = Number()
    number_15 = Number()
    number_16 = Number()
    number_17 = Number()
    number_18 = Number()
    number_19 = Number()
    number_20 = Number()
    number_21 = Number()
    number_22 = Number()
    number_23 = Number()
    number_24 = Number()
    number_25 = Number()

# Generated at 2022-06-26 10:12:11.097148
# Unit test for constructor of class Const
def test_Const():
    # Const(const, *, allow_null=False)
    # const: Any
    # allow_null: bool = False
    cases = [
        ("Const(const=1)", 1, False),
        ("Const(const='a', allow_null=True)", 'a', True),
        ("Const(const='abc')", 'abc', False),
        ("Const()", Field, False)
    ]
    for i in range(0, len(cases)):
        args = cases[i][0]
        const = cases[i][1]
        allow_null = cases[i][2]
        try:
            Const(const=const, allow_null=allow_null)
        except:
            print("Error: {0}".format(args))
            raise


# Generated at 2022-06-26 10:12:13.234885
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    number_1 = Number()
    union = number_0 | number_1
    assert isinstance(union, Union)


# Generated at 2022-06-26 10:12:20.844603
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False
    assert Boolean(allow_null=True).validate(True) == True
    assert Boolean(allow_null=True).validate(False) == False
    assert Boolean(allow_null=True).validate(None) == None
    assert Boolean(allow_null=True).validate("True") == True
    assert Boolean(allow_null=True).validate("False") == False
    assert Boolean(allow_null=True).validate(None) == None
    assert Boolean(allow_null=True).validate(1) == True
    assert Boolean(allow_null=True).validate(0) == False
    assert Boolean(allow_null=True).validate(None) == None

# Generated at 2022-06-26 10:12:30.817780
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    pass


# Generated at 2022-06-26 10:12:32.884852
# Unit test for constructor of class Array
def test_Array():
    arr = Array()
    assert arr is not None



# Generated at 2022-06-26 10:12:34.337294
# Unit test for method __or__ of class Field
def test_Field___or__():
    test_case_0()


# Generated at 2022-06-26 10:12:40.535718
# Unit test for method validate of class Choice
def test_Choice_validate():
    number_1 = Number()
    choice_0 = Choice()

    # Test cases for method Choice.validate
    # Testing method validate of class Choice
    # Testing null
    # expected: ValueError
    try:
        choice_1.validate(None)
    except Exception as e:
        assert type(e) == ValueError

    # Testing choice
    # expected: ValueError
    try:
        choice_1.validate(99)
    except Exception as e:
        assert type(e) == ValueError




# Generated at 2022-06-26 10:12:47.890288
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    number_0 = Number()
    expected_0 = ValidationResult(value=10, error=None)
    assert number_0.validate_or_error(value=10) == expected_0
    expected_1 = ValidationResult(value=None, error=ValidationError(text='Must be a number.', code='invalid'))
    assert number_0.validate_or_error(value='10', strict=True) == expected_1
    expected_2 = ValidationResult(value=None, error=ValidationError(text='Must be a number.', code='invalid'))
    assert number_0.validate_or_error(value=[1, 2], strict=True) == expected_2

# Generated at 2022-06-26 10:12:54.911909
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case need to be fixed, because the order of exception is random between test run
    # list(self.errors.values())[0] is not a safe way to check the exception code

    array_0 = Array()
    value_0 = [1, 2, 3]
    array_0.validate(value_0)
    array_0.validate(None)

    with pytest.raises(ValidationError) as excinfo:
        array_0.validate("")
    excinfo.match("Must be an array")

    with pytest.raises(ValidationError) as excinfo:
        array_0.validate(None, strict=True)
    excinfo.match("May not be null")

    array_1 = Array(min_items=2)

# Generated at 2022-06-26 10:13:03.425737
# Unit test for method validate of class Object
def test_Object_validate():
    """Test validate method of class Object"""
    # test case 0
    properties = {"name": String(allow_null=True)}
    x_pat = r"\d{3}[-]\d{2}[-]\d{4}"
    pattern_properties = {x_pat: String()}
    additional_properties = String()
    min_properties = 2
    max_properties = 10
    required = ["name"]
    obj = Object(
        properties=properties,
        pattern_properties=pattern_properties,
        additional_properties=additional_properties,
        min_properties=min_properties,
        max_properties=max_properties,
        required=required,
    )

    # Test case 0
    value = {"name": None, "xxx-xx-xxxx": "name1"}
    obj.validate(value)

# Generated at 2022-06-26 10:13:09.554159
# Unit test for method serialize of class Array
def test_Array_serialize():

    class TestArray(Array):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return super().serialize(obj)

    number = Number()
    array = TestArray(items=number)
    obj = [0, 1, 2, 3]
    assert array.serialize(obj) == obj


# Generated at 2022-06-26 10:13:21.396243
# Unit test for method validate of class Array
def test_Array_validate():
    number_0 = Number()
    test_case_0 = Number()
    test_case_1 = Number()
    test_case_2 = Number()
    test_case_3 = Number()
    test_case_4 = Number()
    test_case_5 = Number()
    test_case_6 = Number()
    test_case_7 = Number()
    test_case_8 = Number()
    test_case_9 = Number()
    test_case_10 = Number()
    test_case_11 = Number()
    test_case_12 = Number()
    test_case_13 = Number()
    test_case_14 = Number()
    test_case_15 = Number()
    test_case_16 = Number()
    test_case_17 = Number()
    test_case_18 = Number()
   

# Generated at 2022-06-26 10:13:32.050316
# Unit test for method validate of class Object
def test_Object_validate():
    # test case 0
    try:
        test_0 = Object()
        test_0.validate(None)
    except ValidationError as e:
        assert e.messages()[0].text == 'May not be null.'

    try:
        test_0.validate(None, strict=True)
    except ValidationError as e:
        assert e.messages()[0].text == 'May not be null.'

    try:
        test_0.validate(3.14)
    except ValidationError as e:
        assert e.messages()[0].text == 'Must be an object.'

    try:
        test_0.validate(3.14, strict=True)
    except ValidationError as e:
        assert e.messages()[0].text == 'Must be an object.'

   

# Generated at 2022-06-26 10:13:50.935094
# Unit test for method validate of class Union
def test_Union_validate():
    number_0 = Number()
    number_1 = Number()
    string_0 = String()
    string_1 = String()
    union_0 = Union([number_0])
    number_2 = Number()
    union_0.any_of.append(number_2)
    union_0.any_of.append(string_0)
    union_0.validate(string_1)
    union_0.allow_null = True
    union_0.validate(string_1)
    union_0.allow_null = False
    with pytest.raises(ValidationError):
        union_0.validate(string_1)
test_Union_validate()



# Generated at 2022-06-26 10:13:54.033217
# Unit test for constructor of class Array
def test_Array():
    assert Array(items=[Number()]).items == [Number()]

# Generated at 2022-06-26 10:14:04.402259
# Unit test for constructor of class String
def test_String():
    test_String1 = String(allow_blank=True, trim_whitespace=True, max_length=6, min_length=1)
    assert test_String1.allow_blank == True
    assert test_String1.trim_whitespace == True
    assert test_String1.max_length == 6
    assert test_String1.min_length == 1
    test_String2 = String(allow_blank=True, trim_whitespace=True, max_length=None, min_length=1)
    assert test_String2.allow_blank == True
    assert test_String2.trim_whitespace == True
    assert test_String2.max_length == None
    assert test_String2.min_length == 1

# Generated at 2022-06-26 10:14:09.201458
# Unit test for method serialize of class Array
def test_Array_serialize():
    number_0 = Number()
    list_0 = [50, 50]
    array_0 = Array(items = number_0)
    array_0.serialize(list_0)



# Generated at 2022-06-26 10:14:14.610793
# Unit test for method validate of class Array
def test_Array_validate():
    source_code = inspect.getsource(test_case_0)
    print(source_code)
    print('========')
    print('========')
    print('========')
    parsed_ast = astor.parse_file(source_code)
    print(parsed_ast)
    print('--------')
    print('--------')
    print('--------')
    transformer = Transformer()
    transformer.visit(parsed_ast)

test_Array_validate()

# Generated at 2022-06-26 10:14:18.866671
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    number_1 = Number()
    res_va_0 = Union(any_of=[number_0, number_1])


# Generated at 2022-06-26 10:14:20.686424
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("")


# Generated at 2022-06-26 10:14:23.364310
# Unit test for method serialize of class Array
def test_Array_serialize():
    test_array = Array()
    test_array_serializer = test_array.serialize(3)
    assert test_array_serializer == 3


# Generated at 2022-06-26 10:14:27.301749
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    number_1 = Number(title='My title')
    number_0.__or__(number_1)


# Generated at 2022-06-26 10:14:40.075825
# Unit test for method validate of class Array
def test_Array_validate():
    # No item
    error_messages = [
        {
            "code": "empty",
            "text": "Must not be empty."
        }
    ]
    field = Array()
    value = []
    assert field.error_messages(value) == error_messages

    # No item
    error_messages = [
        {
            "code": "type",
            "text": "Must be an array."
        }
    ]
    field = Array()
    value = True
    assert field.error_messages(value) == error_messages

    # Number item
    error_messages = []
    field = Array(items=Number())
    value = [10, 12, 13]
    assert field.error_messages(value) == error_messages

    # String item
    error_messages

# Generated at 2022-06-26 10:15:06.103574
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices=['L', 'M', 'S'])
    assert obj.validate('S') == 'S'
    assert obj.validate('M') == 'M'
    assert obj.validate('L') == 'L'
    try:
        assert obj.validate('X') == 'X'
    except Exception as error:
        assert error.args[0] == 'Not a valid choice.'


# Generated at 2022-06-26 10:15:13.529384
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    assert choice_0.validate("") == None
    assert choice_0.validate("d") == "d"

    choice_1 = Choice(choices=["1", "0"])
    assert choice_1.validate("0") == "0"

    choice_2 = Choice(choices=["1", "0"])
    assert choice_2.validate("") == None

    choice_3 = Choice(choices=["1", "0"])
    assert choice_3.validate("d") == None

if __name__ == "__main__":
    test_case_0()
    test_Choice_validate()

# Generated at 2022-06-26 10:15:25.219303
# Unit test for method validate of class Array
def test_Array_validate():
    number_1 = Number()
    string_0 = String(min_length=1, max_length=100)

    # Test case 0
    array_0 = Array(items=[number_1, string_0])
    value_0 = ["hello", 123, 456]
    with pytest.raises(ValidationError):
        array_0.validate(value_0)

    # Test case 1
    array_1 = Array(items=[number_1, string_0])
    value_1 = ["hello", 123, 456, "world"]
    with pytest.raises(ValidationError):
        array_1.validate(value_1)

    # Test case 2
    array_2 = Array(items=[number_1, string_0])
    value_2 = [123, "hello"]
    array_2

# Generated at 2022-06-26 10:15:30.000760
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    assert number_0.get_default_value() == 0


# Generated at 2022-06-26 10:15:33.959978
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    val = "abc"
    field.validate(val)
    field.validate_or_error(val)


# Generated at 2022-06-26 10:15:43.326032
# Unit test for method serialize of class Array
def test_Array_serialize():
    string = String()
    field = Array(items=string)
    obj = None
    assert field.serialize(obj) == None
    obj = [
        "val1",
        "val2",
        "val3"
    ]
    assert field.serialize(obj) == [
        "val1",
        "val2",
        "val3"
    ]


# Generated at 2022-06-26 10:15:50.635098
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_1 = Number()
    assert number_1.get_default_value() is None
    number_2 = Number(default=44)
    assert number_2.get_default_value() == 44
    number_3 = Number(allow_null=True, default=44)
    assert number_3.get_default_value() == 44
    number_4 = Number(allow_null=True, default=None)
    assert number_4.get_default_value() is None
    number_5 = Number(allow_null=True, default='')
    assert number_5.get_default_value() == ''
    number_6 = Number(allow_null=False, default='')
    assert number_6.get_default_value() == ''


# Generated at 2022-06-26 10:15:54.437187
# Unit test for constructor of class Array
def test_Array():
    number_0 = Number()
    field_0 = Array(items = number_0)
    assert field_0.items.get_default_value() == 0


# Generated at 2022-06-26 10:16:04.538300
# Unit test for method __or__ of class Field
def test_Field___or__():
    # case 0
    number_0 = Number()
    number_1 = Number()
    number_0.__or__(number_1)
    #assert False  # TODO: implement your test here
    # case 1
    number_0 = Number()
    string_1 = String()
    number_0.__or__(string_1)
    # case 2
    number_0 = Number()
    union_1 = Union([number_1, string_1])
    number_0.__or__(union_1)


# Generated at 2022-06-26 10:16:18.044541
# Unit test for method validate of class Array
def test_Array_validate():
    number_0 = Number()
    number_1 = Number(min_value=1)
    array_0 = Array()
    array_1 = Array(items=number_0)
    array_2 = Array(items=number_0, max_items=5)
    array_3 = Array(items=number_1, min_items=5, max_items=5)
    array_4 = Array(items=[number_0, number_1, number_0], min_items=5)

    assert array_0.validate([]) == []
    try:
        array_0.validate(None)
    except ValidationError:
        pass
    except Exception as e:
        raise AssertionError("Expected ValidationError but received", e)

    # Array of any length and type

# Generated at 2022-06-26 10:16:32.092920
# Unit test for method serialize of class Array
def test_Array_serialize():
    print('Test method serialize of class Array')
    number_0 = Number()
    array_0 = Array(items=number_0, required=['field_1'])
    array_0.serialize([42, 1, 2])
    


# Generated at 2022-06-26 10:16:36.891857
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
     number_0 = Number()
     assert isinstance(number_0.get_default_value(),type(None))


# Generated at 2022-06-26 10:16:41.659697
# Unit test for method __or__ of class Field
def test_Field___or__():
    number = Number()
    union = Number() | Number()
    #assert union.any_of == [number]
    assert union.any_of == [number_0]


# Generated at 2022-06-26 10:16:43.124914
# Unit test for constructor of class Choice
def test_Choice():
    choice_0 = Choice(choices = ["Hello","World"])
    assert True


# Generated at 2022-06-26 10:16:47.686768
# Unit test for method serialize of class Array
def test_Array_serialize():
    array_0 = Array(items=Number())
    number_0 = array_0.serialize([1, 2, 3, 4, 5])
    assert number_0 == [1, 2, 3, 4, 5]


# Generated at 2022-06-26 10:16:56.924716
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean()
    boolean_0.validate(value=False)
    boolean_0.validate(value=True)
    boolean_0.validate(value=None)
    boolean_0.validate(value=True)
    boolean_0.validate(value=True)
    boolean_0.validate(value=True)
    boolean_0.validate(value=False)


# Generated at 2022-06-26 10:17:10.892707
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(allow_null = True)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0 = Choice(choices = [('apple', 'APPLE'), ('banana', 'BANANA')], allow_null = True, required = True)
    print(choice_0.validate('apple'))
    print(choice_0.validate('APPLE'))
    try:
        print(choice_0.validate(None))
        raise Exception
    except ValidationError:
        pass
    choice_0 = Choice(choices = [('apple', 'APPLE'), ('banana', 'BANANA')])
    try:
        print(choice_0.validate(None))
        raise Exception
    except ValidationError:
        pass
    choice_0

# Generated at 2022-06-26 10:17:22.254301
# Unit test for constructor of class String
def test_String():
    string_field = String(allow_blank=False, trim_whitespace=False, max_length=10, min_length=2, pattern=r"\d{4}-\d{2}-\d{2}", format=None)
    assert string_field.validate(None) == None, "Validate null"
    assert string_field.validate("") == None, "Validate blank"
    assert string_field.validate("  ") == None, "Validate spaces"
    assert string_field.validate(123) == None, "Validate number"
    assert string_field.validate("  2816-12-19  ") == "2816-12-19", "Validate string"



# Generated at 2022-06-26 10:17:32.807216
# Unit test for method serialize of class Array
def test_Array_serialize():
    a = Array(items=Number(), additional_items=False, min_items=None,
           max_items=None, unique_items=False)
    assert a.serialize([1,2,3]) == [1,2,3]
    assert a.serialize([1,2,"3"]) == [1,2,"3"]
    assert a.serialize(["1","2",3]) == ["1","2",3]
    assert a.serialize(["1","2","3"]) == ["1","2","3"]
    assert a.serialize(None) == None



# Generated at 2022-06-26 10:17:38.209095
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Given
    b = Boolean()

    # When
    a = b.validate(False)

    # Then
    assert a == False
    assert b.validate(None) == None
    assert b.validate(True) == True


# Generated at 2022-06-26 10:18:07.619679
# Unit test for constructor of class Array
def test_Array():
    items = Field()
    additional_items = Field()
    min_items = 1
    max_items = 2
    unique_items = False
    array = Array(items = items, additional_items = additional_items, min_items = min_items, max_items = max_items, unique_items = unique_items)
    assert(array.items == items and array.additional_items == additional_items and array.min_items == min_items and array.max_items == max_items and array.unique_items == unique_items)



# Generated at 2022-06-26 10:18:09.195426
# Unit test for constructor of class Const
def test_Const():
    constField = Const(10)
    assert(constField.const == 10)
    

# Generated at 2022-06-26 10:18:12.937512
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    arg_0 = 777
    result_0 = choice_0.validate(arg_0)
    assert result_0 == 777


# Generated at 2022-06-26 10:18:18.595166
# Unit test for method validate of class Number
def test_Number_validate():
    number_1 = Number()
    try:
        number_1.validate(None)
        return True
    except:
        return False


# Generated at 2022-06-26 10:18:28.966641
# Unit test for method validate of class Array
def test_Array_validate():
    # number array
    number_array = Array(items=Number())
    number_1 = number_array.validate(value=[1, 2, 3])
    assert number_1 == [1, 2, 3]

    number_array = Array(items=Number(), unique_items=True)
    try:
        number_array.validate(value=[1, 1, 2, 3])
    except ValidationError as e:
        assert e.messages()[0].index == [0]
    
    # string array
    string_array = Array(items=String())
    string_1 = string_array.validate(value=['a', 'b', 'c'])
    assert string_1 == ['a', 'b', 'c']

    # boolean array
    boolean_array = Array(items=Boolean())
    boolean_

# Generated at 2022-06-26 10:18:39.395625
# Unit test for method validate of class Choice
def test_Choice_validate():
    """
    Number of test cases: 1
    Function: def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
    Branch coverage: 100.0%
    """
    number_1 = Number()
    string_1 = String()
    my_choice = Choice(choices=[[1, 1], [2, 3], ["a", "b"]], required=False)
    print(my_choice.validate(1))
    print(my_choice.validate(2))
    print(my_choice.validate("a"))
    print(my_choice.validate(5))


# Generated at 2022-06-26 10:18:50.659458
# Unit test for method validate of class Number
def test_Number_validate():
    number_1 = Number()
    assert number_1.validate(0) == 0
    number_1 = Number(minimum=1)
    assert number_1.validate(2) == 2
    number_1 = Number(maximum=10)
    assert number_1.validate(5) == 5
    number_1 = Number(exclusive_minimum=5)
    assert number_1.validate(6) == 6
    number_1 = Number(exclusive_maximum=10)
    assert number_1.validate(9) == 9
    number_1 = Number(multiple_of=2)
    assert number_1.validate(4) == 4


# Generated at 2022-06-26 10:18:58.440598
# Unit test for constructor of class Const
def test_Const():
    string_0 = Const("abc")
    assert string_0.const == "abc"
    assert string_0.allow_null == False
    assert string_0.error_messages == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}


# Test validate_or_error()

# Generated at 2022-06-26 10:19:08.415844
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice = Choice
    number_0 = Number()
    string_0 = String()
    integer_0 = Integer()
    float_0 = Float()
    decimal_0 = Decimal()
    boolean_0 = Boolean()
    choice_0 = Choice()
    choice_1 = Choice(
        choices=[(integer_0, float_0), (float_0, integer_0), (integer_0, integer_0)]
    )
    choice_2 = Choice(choices=[(integer_0, string_0), (string_0, integer_0)])
    choice_3 = Choice(choices=[(string_0, string_0), (string_0, integer_0)])
    choice_4 = Choice(choices=[(integer_0, float_0), (float_0, integer_0)])
    assert choice_3

# Generated at 2022-06-26 10:19:12.046288
# Unit test for method validate of class Number
def test_Number_validate():
    number_1 = Number()
    assert number_1.validate(1) == 1
    assert number_1.validate(1.1) == 1.1
    assert number_1.validate(1.234) == 1.234
    assert number_1.validate('abc') == 'abc'
    assert number_1.validate(None) == None
# End of test_Number_validate



# Generated at 2022-06-26 10:19:29.125582
# Unit test for method validate of class Object
def test_Object_validate():
    # Test successful validation
    field = Object(properties = {'a':Number(), 'c':Integer()})
    assert field.validate({'a':1, 'b':2}) == {'a':1, 'b':2}
    assert field.validate({'a':1}) == {'a':1}
    assert field.validate({'b':3,'c':5}) == {'b':3, 'c':5}
    assert field.validate({'c':5}) == {'c':5}

    # Test invalid validation
    # Object property values are not defined
    with raises(ValidationError, match='"Object property values are not defined."'):
        field.validate({'b':2})
    # Missing required keys

# Generated at 2022-06-26 10:19:36.933265
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test that Boolean allows null to be returned in the result.
    # Test that when input is null and allow null is true, nothing is thrown.
    number_0 = Boolean(allow_null=True)
    result_0 = number_0.validate(None)
    assert result_0 == None
    
    # Test that when input is null and allow null is false, an exception is thrown.
    number_1 = Boolean(allow_null=False)
    try:
        number_1.validate(None)
        raise AssertionError("Expected exception to be thrown")
    except ValidationError as err:
        assert err.code == "null"
    
    # Test that Boolean allows boolean to be returned in the result.
    # Test that when input is boolean, value is returned.
    number_2 = Boolean()
    result_1

# Generated at 2022-06-26 10:19:41.573430
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    number_1 = Number()
    Union_2 = number_0.__or__(number_1)
