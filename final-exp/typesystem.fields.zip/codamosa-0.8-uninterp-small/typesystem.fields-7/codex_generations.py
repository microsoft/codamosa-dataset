

# Generated at 2022-06-26 10:10:46.993851
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = Choice()
    date_time_0.validate("eNyIFUd", strict=True)
    date_time_0.validate("Kj9uk&o", strict=True)
    date_time_0.validate("", strict=False)
    date_time_0.validate("Kj9uk&o", strict=True)
    date_time_0.validate("Kj9uk&o", strict=True)
    date_time_0.validate("Kj9uk&o", strict=True)
    date_time_0.validate("Kj9uk&o", strict=True)
    date_time_0.validate("Kj9uk&o", strict=True)

# Generated at 2022-06-26 10:10:59.411617
# Unit test for method validate of class Array
def test_Array_validate():
    from . import Field, Integer, String
    from . import Char, Date, Datetime, Integer, List, Object, String

    # Test: Valid case
    date_time_1 = DateTime()
    data_1 = [
        date_time_1.deserialize("2020-04-29T00:00:00+00:00"),
        date_time_1.deserialize("2020-04-30T00:00:00+00:00"),
        date_time_1.deserialize("2020-05-01T00:00:00+00:00"),
    ]
    schema_1 = Array(items=date_time_1)
    assert schema_1.validate(data_1) == data_1

    # Test: Null case
    data_2 = None

# Generated at 2022-06-26 10:11:05.061689
# Unit test for method validate of class Object
def test_Object_validate():
    properties0 = {}
    schema0 = Object(properties=properties0)
    data0 = {
        "hello": "world",
    }
    expected0 = {
        "hello": "world",
    }
    actual0 = schema0.validate(data0)
    assert actual0 == expected0
    assert str(actual0) == str(expected0)
    assert repr(actual0) == repr(expected0)

    pattern_properties0 = {
        "hello": String(),
    }
    schema1 = Object(pattern_properties=pattern_properties0)
    data1 = {
        "hello": "world",
    }
    expected1 = {
        "hello": "world",
    }
    actual1 = schema1.validate(data1)
    assert actual1 == expected1
    assert str(actual1)

# Generated at 2022-06-26 10:11:14.135213
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for issue 29
    array = Array(
        items = [
            Integer(
                title='Page',
                description=('The number of this page in the sequence, starting '
                             'with 0 as the first page.')
            ),
            Integer(
                title=('Height'),
                description=('The height of the page, in pixels.')
            )
        ],
        min_items=1
    )
    array.validate([0, 100])
    array.validate([0, 100, 0, 100, 1, 200])
    # Test for issue 31
    array = Array(items=Integer())
    array.validate([1, 2, 3, 4, 5])


# Generated at 2022-06-26 10:11:19.158369
# Unit test for method validate of class Array
def test_Array_validate():
    field_0 = Array(items=(Boolean(),), min_items=2, max_items=2)
    try:
        field_0.validate(value=(False, True))
    except ValidationError as e:
        assert e.messages == [
            Message(
                text='',
                code='required',
                index=[1, 1],
            ),
        ]


if __name__ == "__main__":
    test_case_0()
    test_Array_validate()

# Generated at 2022-06-26 10:11:23.518492
# Unit test for method validate of class Choice
def test_Choice_validate():
    param0 = None
    choice_0 = Choice()
    choice_0.validate(param0)


# Generated at 2022-06-26 10:11:33.733846
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime(format="datetime")
    date_time_1 = DateTime(format="datetime")
    any_of = [date_time_0, date_time_1]
    union = Union(any_of)
    value = datetime.datetime.now()
    expected = value
    actual = union.validate(value)
    assert expected == actual

    date_time_2 = DateTime(format="datetime")
    date_time_3 = DateTime(format="date")
    any_of = [date_time_2, date_time_3]
    union = Union(any_of)
    value = datetime.datetime.now()
    expected = value
    actual = union.validate(value)
    assert expected == actual


# Generated at 2022-06-26 10:11:39.650391
# Unit test for method validate of class Choice
def test_Choice_validate():
    class Object(typing.NamedTuple):
        value: int

    class Number(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    field_0 = Number(choices=[(None, Object(value=2))])


# Generated at 2022-06-26 10:11:42.162990
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    date_time_0 = DateTime()
    if (isinstance(date_time_0.validate_or_error(None), ValidationResult)):
        raise Exception("Unit test for method validate_or_error of class Field failed")


# Generated at 2022-06-26 10:11:47.430828
# Unit test for method validate of class Union
def test_Union_validate():
    # set up
    # test case
    date_time_0 = DateTime()
    string_0 = String()
    field_0 = Union([date_time_0, string_0])
    field_1 = Union([date_time_0, string_0])
    assert field_0 == field_1

# Generated at 2022-06-26 10:12:17.518971
# Unit test for method validate of class Number
def test_Number_validate():
    int_0 = Integer()
    number_0 = Number()
    # Test for no exception (exception expected to be raised)
    number_0.validate(12)
    # Test for no exception (exception expected to be raised)
    number_0.validate(None)
    # Test for no exception (exception expected to be raised)
    number_0.validate("hi")
    # Test for no exception (exception expected to be raised)
    number_0.validate(10.000000)
    # Test for exception thrown of type ValidationError
    try:
        number_0.validate(True)
        assert False
    except ValidationError as e:
        # Check that exception message is equal to expected message
        assert e.message == "Must be a number."
    # Test for exception thrown of type ValidationError


# Generated at 2022-06-26 10:12:18.196278
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert False



# Generated at 2022-06-26 10:12:25.557447
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices = [(1, 2), (3, 4), (5, 6)])
    # The Choice object is created
    # The value is not a valid choice, the key value pair is not found
    # ValueError is raised
    try:
        choice_0.validate(10)
    except ValueError:
        pass
    else:
        raise AssertionError
    # The value is a valid choice, the key value pair is found
    choice_0.validate(1)
    # The value is a valid choice and a tuple, the key value pair is found
    choice_0.validate((3, 4))
    # The value is not a valid choice, the key value pair is not found
    # ValueError is raised

# Generated at 2022-06-26 10:12:29.406070
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    string_0.validate("")
    string_0.validate("")
    string_0.validate("")


# Generated at 2022-06-26 10:12:39.482595
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    string_0.errors = {
        "type": "Must be a string.",
        "null": "May not be null.",
        "blank": "Must not be blank.",
        "max_length": "Must have no more than {max_length} characters.",
        "min_length": "Must have at least {min_length} characters.",
        "pattern": "Must match the pattern /{pattern}/.",
        "format": "Must be a valid {format}.",
    }
    string_0.allow_blank = True
    string_0.trim_whitespace = True
    string_0.max_length = 4
    string_0.min_length = 2
    string_0.pattern = None
    string_0.format = "date"

    # Test for edge case edge_4


# Generated at 2022-06-26 10:12:41.618072
# Unit test for method validate of class String
def test_String_validate():
    date_time_0 = DateTime()


# Generated at 2022-06-26 10:12:46.460616
# Unit test for method validate of class Object
def test_Object_validate():
    # Create a data value to be validated.
    object_value = {"a":"a_value"}
    data_value = {"a":"a_value", "b":"b_value"}

    # Create a properties dictionary for the object to be validated.
    properties = {"a":String(), "b":String()}

    # Create object instance.
    obj = Object(properties=properties)

    # Test validate method.
    obj.validate(object_value, strict=False)


# Generated at 2022-06-26 10:12:50.395319
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    choices_lst = [
        (date_time_0, )
    ]
    choice_0 = Choice(
        allow_null = False,
        choices = choices_lst
    )
    choice_0.validate(None, strict = False)



# Generated at 2022-06-26 10:12:52.698646
# Unit test for method validate of class Number
def test_Number_validate():
    string_0 = String()
    string_0.validate("W8*UZH6")



# Generated at 2022-06-26 10:12:56.028042
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = date_time_0 | date_time_1



# Generated at 2022-06-26 10:13:39.268074
# Unit test for method validate of class Array
def test_Array_validate():
    items_0 = Object()
    Array_0 = Array(items=items_0)
    value_0 = {"a": {"b": 1}, "c": {"d": 2}}
    Array_0.validate(value=value_0, strict=False)
    value_1 = {"a": {"b1": 1}, "c": {"d": 2}}
    Array_0.validate(value=value_1, strict=False)
    value_2 = {"a": {"b": 1}, "c": {"d": 2}}
    Array_0.validate(value=value_2, strict=False)
    value_3 = {"a": {"b": 1}}
    Array_0.validate(value=value_3, strict=False)

# Generated at 2022-06-26 10:13:41.171710
# Unit test for method serialize of class String
def test_String_serialize():
    test_String_serialize_0()



# Generated at 2022-06-26 10:13:50.286731
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String(format="date")

    date_0 = date(2019, 1, 1) # Jan 1, 2019
    datetime_0 = datetime(2019, 1, 1, 0, 0, 0) # Jan 1 2019 00:00:00
    date_time_0 = date_time_0.serialize(date_0)
    date_time_1 = date_time_0.serialize(datetime_0)
    # We should return Jan 1, 2019 00:00:00
    assert(date_time_0 == date_time_1)


# Generated at 2022-06-26 10:14:02.556271
# Unit test for method validate of class Number

# Generated at 2022-06-26 10:14:05.748453
# Unit test for method __or__ of class Field
def test_Field___or__():
  date_time_0 = DateTime()
  date_time_0.__or__(date_time_0)


# Generated at 2022-06-26 10:14:12.544339
# Unit test for method validate of class Array
def test_Array_validate():
    date_time_0 = DateTime()
    field_0 = Array(items=date_time_0)
    str_1 = "2019-11-07T00:00:00Z"
    field_0.validate(value=[str_1])
    str_2 = "2019-11-07T00:00:00Z"
    str_3 = "2019-11-07T00:00:00Z"
    field_0.validate(value=[str_2, str_3])


# Generated at 2022-06-26 10:14:25.670719
# Unit test for method validate of class Array
def test_Array_validate():

    # Test #0: Ensure is raises ValidationError if given an input with minimum of two items and an input with three items
    try:
        test_array_0 = Array(min_items=2)
        test_array_0.validate([1,2,3])
        assert False
    except ValidationError:
        assert True

    # Test #1: Ensure is raises ValidationError if given an input with maximum of two items and an input with three items
    try:
        test_array_1 = Array(max_items=2)
        test_array_1.validate([1,2,3])
        assert False
    except ValidationError:
        assert True

    # Test #2: Ensure is raises ValidationError if given an input with a maximum of two items and an input with three items and also given a validator

# Generated at 2022-06-26 10:14:31.145910
# Unit test for method serialize of class Array
def test_Array_serialize():
    date_time_0 = DateTime()
    array_0 = Array(items=date_time_0)
    array_0.serialize([datetime.datetime.now()])


# Generated at 2022-06-26 10:14:34.187012
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()
    obj.validate([1,2,3])


# Generated at 2022-06-26 10:14:39.041094
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime()
    date_time_0.validate(datetime.datetime.now())


# Generated at 2022-06-26 10:15:26.860471
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    str_0 = String()
    str_1 = String()
    union = date_time_0 | str_0 | str_1
    assert isinstance(union, Union)
    assert union.any_of[0] == date_time_0, "union.any_of[0] == date_time_0"
    assert union.any_of[1] == str_0, "union.any_of[1] == str_0"
    assert union.any_of[2] == str_1, "union.any_of[2] == str_1"



# Generated at 2022-06-26 10:15:33.556510
# Unit test for method validate of class Choice
def test_Choice_validate():
    print("Test for Choice.validate...")
    choice_0 = Choice()

    value_1 = "xyz"
    strict_2 = True
    try:
        choice_0.validate(value_1, strict=strict_2)
        assert False, "Expected to raise ValidationError"
    except ValidationError as e:
        assert e.code == "required" and e.text == choice_0.get_error_text(
            e.code
        ), "Unexpected ValidationError"

    print("PASSED")



# Generated at 2022-06-26 10:15:35.571914
# Unit test for method validate of class Array
def test_Array_validate():
    items = [date_time_0]
    arr = Array(items)
    arr.validate(arr) == arr

# Generated at 2022-06-26 10:15:39.714791
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    assert date_time_0.get_default_value() == NO_DEFAULT


# Generated at 2022-06-26 10:15:47.707785
# Unit test for method validate of class Array
def test_Array_validate():
    print("Testing Array validate")
    list_0 = []
    list_1 = [0, 1, 2]
    list_2 = [1, 2]
    list_3 = [1]
    array_0 = Array(items=Integer(), max_items=3)
    print(array_0.validate(list_0))
    print(array_0.validate(list_1))
    print(array_0.validate(list_2))
    print(array_0.validate(list_3))

test_Array_validate()

# Generated at 2022-06-26 10:15:52.351219
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    date_time_0.validate(date_time_0.validate(datetime.datetime.now()))

try:
    import dateutil.parser
except ImportError:  # pragma: no cover
    dateutil = None



# Generated at 2022-06-26 10:16:00.852508
# Unit test for method validate of class Number
def test_Number_validate():
    int_0 = Integer(minimum=66)
    try:
        int_0.validate("44")
        assert False
    except ValidationError:
        assert True

    int_0.validate("78")
    int_0.validate("67")
    int_0.validate("77")
    int_0.validate("78.0")

    try:
        int_0.validate(66)
        assert False
    except ValidationError:
        assert True

    try:
        int_0.validate("77.", strict=True)
        assert False
    except ValidationError:
        assert True

    try:
        int_0.validate(108842)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-26 10:16:04.781643
# Unit test for method __or__ of class Field
def test_Field___or__():
    print("Method __or__ called for class Field")
    print("Method for class Field should be implemented!")

if __name__ == "__main__":
    test_Field___or__()


# Generated at 2022-06-26 10:16:18.082178
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    boolean_0 = Boolean()
    boolean_1 = Boolean()
    date_0 = Date()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    string_0 = String()
    boolean_2 = Boolean()
    boolean_3 = Boolean()
    string_1 = String()
    boolean_4 = Boolean()
    boolean_5 = Boolean()

    union_0 = date_time_0 | boolean_0
    assert isinstance(union_0, Union)
    assert union_0.any_of == [date_time_0, boolean_0]

    union_1 = union_0 | boolean_1

# Generated at 2022-06-26 10:16:25.413487
# Unit test for method validate of class Union
def test_Union_validate():

    # Constructor test
    date_time_0 = DateTime()
    number_0 = Number()
    union_0 = Union([date_time_0, number_0])

    assert union_0.any_of == [date_time_0, number_0]
    assert union_0.allow_null
    assert union_0.default_value is None
    assert union_0.description == ""
    assert union_0.name is None
    assert union_0.title == ""
    assert union_0.error_messages == {}

    # validate
    value_0 = "2020-06-02T15:24:26Z"
    validated_0, error_0 = union_0.validate_or_error(value_0)
    assert validated_0 == value_0
    assert error_0 is None

    value

# Generated at 2022-06-26 10:16:45.475350
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    try:
        choice_0.validate(value=True, strict=False)
    except ValidationError as e:
        if not e.code == 'choice':
            raise Exception('test failed')
        if not e.text == 'Not a valid choice.':
            raise Exception('test failed')


# Generated at 2022-06-26 10:16:49.664004
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String(allow_blank=False)
    string_0.min_length=5

    string_0.validate("str")
    string_1 = String(allow_blank=True)
    string_1.max_length=3

    string_1.validate("str")

test_String_validate()



# Generated at 2022-06-26 10:16:57.264152
# Unit test for constructor of class Const
def test_Const():

    const_0 = Const(const=None)
    assert const_0.name == "String"
    assert const_0.get_default_error_text("only_null") == "Must be null."
    assert const_0.get_default_error_text("const") == "Must be the value '{const}'."
    assert len(const_0.errors) == 2

# Generated at 2022-06-26 10:17:02.554409
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    list_0 = [1, 2, 3]
    obj_0 = array_0.validate(list_0)
    assert obj_0 is list_0



# Generated at 2022-06-26 10:17:10.875082
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number(multiple_of = 1.0, allow_null = True)
    value = None
    strict = bool()
    assert number_0.validate(value, strict = strict) == None
    number_1 = Number(multiple_of = 1.0, allow_null = True)
    value = str()
    strict = bool()
    try:
        number_1.validate(value, strict = strict)
    except ValidationError as err:
        assert err.code == "type"
        assert err.text == "Must be a number."

# Generated at 2022-06-26 10:17:21.357981
# Unit test for constructor of class String
def test_String():
    my_string = String()
    assert isinstance(my_string, String)
    assert my_string.title == ""
    assert my_string.description == ""
    assert my_string.default == None
    assert my_string.allow_null == False
    assert my_string.allow_blank == False
    assert my_string.trim_whitespace == True
    assert my_string.max_length == None
    assert my_string.min_length == None
    assert my_string.pattern == None
    assert my_string.format == None
    assert my_string.pattern_regex == None



# Generated at 2022-06-26 10:17:32.124145
# Unit test for method validate of class Object
def test_Object_validate():
    shape = Object({
        "type": Choice(choices=["circle", "rectangle"]),
        "name": String(),
    })
    shape_schema = Object({
        "type": Choice(choices=["circle", "rectangle"]),
        "name": String(),
    }, additional_properties=False)
    try:
        shape_schema.validate(shape)
    except ValidationError as e:
        print(e)

if __name__ == "__main__":
    # test_case_0()
    test_Object_validate()

# Generated at 2022-06-26 10:17:33.616118
# Unit test for constructor of class String
def test_String():
    string_0 = String()



# Generated at 2022-06-26 10:17:37.131567
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Check serialization of the field Choice
    dictionary = Choice().serialize(('00', 'Foo'))


# Generated at 2022-06-26 10:17:45.147289
# Unit test for method validate of class Array
def test_Array_validate():
    print("Testing validate of class Array")
    items_0 = [DateTime(), String(pattern="")]
    max_items_0 = None
    min_items_0 = None
    unique_items_0 = False
    additional_items_0 = True
    expected_0 = [datetime.datetime(2014, 2, 3, 0, 0), "string"]
    result_0 = Array(items=items_0, max_items=max_items_0, min_items=min_items_0, unique_items=unique_items_0, additional_items=additional_items_0).validate([datetime.datetime(2014, 2, 3, 0, 0), "string"])
    assert result_0 == expected_0

    items_1 = [DateTime(), String(pattern="")]

# Generated at 2022-06-26 10:18:22.747104
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object()
    obj.validate({})

# Generated at 2022-06-26 10:18:30.233925
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Case 0
    MY_CHOICES = [("AL", "Alabama"), ("WY", "Wyoming")]
    choice_0 = Choice(choices=MY_CHOICES, allow_null=False)
    assert choice_0.validate("AL") == "AL"
    assert choice_0.validate("WY") == "WY"

    # Case 1
    choice_1 = Choice(choices=MY_CHOICES, allow_null=False)
    try:
        choice_1.validate("OH")
        raise AssertionError('ValidationError not raised')
    except ValidationError as e:
        assert str(e) == 'Not a valid choice.'

    # Case 2
    choice_2 = Choice(choices=MY_CHOICES, allow_null=False)

# Generated at 2022-06-26 10:18:40.923249
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_object = date(year=2018, month=1, day=1)
    date_time_object = datetime(year=2018, month=1, day=1)
    date_time_0 = DateTime()
    date_time_1 = DateTime(allow_null=True)
    date_time_2 = DateTime(allow_blank=True)
    date_time_3 = DateTime(allow_null=True, allow_blank=True)
    date_time_4 = DateTime(format='rfc3339')
    date_time_5 = DateTime(format='iso8601')
    date_time_6 = DateTime(format='date_time')
    # Test validatation

# Generated at 2022-06-26 10:18:49.778496
# Unit test for method validate of class Array
def test_Array_validate():
    min_items = None
    max_items = None
    items = None
    additional_items = False
    unique_items = True
    root_field = Array(min_items=min_items, max_items=max_items, items=items, additional_items=additional_items, unique_items=unique_items)
    value = [2, 3, 4]
    try:
        result = root_field.validate(value)
    except ValidationError as validation_error:
        result = None
    assert result == value

    additional_items = True
    unique_items = False
    root_field = Array(min_items=min_items, max_items=max_items, items=items, additional_items=additional_items, unique_items=unique_items)
    value = [2, 3, 4]
   

# Generated at 2022-06-26 10:18:51.522921
# Unit test for constructor of class Const
def test_Const():
    with pytest.raises(AssertionError):
        Const(allow_null=False, const=True)


# Generated at 2022-06-26 10:19:00.942123
# Unit test for method validate of class Choice
def test_Choice_validate():
    parameter_0 = Choice()

    result = parameter_0.validate(value=None)
    assert result is None
    result = parameter_0.validate(value=None, strict=None)
    assert result is None
    result = parameter_0.validate(value=1)
    assert result is None
    result = parameter_0.validate(value=1, strict=None)
    assert result is None


# Generated at 2022-06-26 10:19:03.896186
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    assert array_0.validate(None) == None



# Generated at 2022-06-26 10:19:08.782612
# Unit test for method validate of class Array
def test_Array_validate():
    # Arrange
    array_0 = Array(allow_null = False)

    # Act
    result = array_0.validate(None)



# Generated at 2022-06-26 10:19:16.570826
# Unit test for method validate of class Array
def test_Array_validate():
    any0 = Any()
    any1 = Any()
    any0.allow_null = False
    any1.allow_null = False
    any0.default = True
    any1.default = True
    array0 = Array(items=[any0, any1])
    array0.allow_null = False
    array0.default = True
    array0.min_items = 0
    array0.max_items = True
    array0.unique_items = True
    array0.additional_items = True
    array0.get_default_value()
    array0.validate([True, True])
    array0.serialize([True, True])
    array0.validate([any0, any1])
    array0.validate([])
    array0.validate([True, False, True])


# Generated at 2022-06-26 10:19:18.185286
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Instantiate DateTime
    date_time_0 = DateTime()

    # Call method
    value = date_time_0.get_default_value()

    # Check if the returned value is equal to the expected one
    assert value == None


# Generated at 2022-06-26 10:19:33.746355
# Unit test for constructor of class String
def test_String():
    String( title="string1", description="hello" )


# Generated at 2022-06-26 10:19:46.451122
# Unit test for method validate of class Object
def test_Object_validate():
    pattern_properties_0 = {}
    additional_properties_0 = object()
    property_names_0 = object()
    required_0 = object()
    object_0 = Object(properties=pattern_properties_0, additional_properties=additional_properties_0, property_names=property_names_0, required=required_0)
    value_0 = object()
    strict_0 = object()
    try:
        result_0 = object_0.validate(value_0, strict_0)
    except ValidationError as e_0:
        pass
    assert isinstance(result_0, object)
