

# Generated at 2022-06-26 10:11:15.933149
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    date_time_0.serialize(1459785700)


# Generated at 2022-06-26 10:11:22.095810
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(
        items=DateTime(), additional_items=False, min_items=1, max_items=3
    )
    data = [3.14, 2.71]
    assert schema.validate(data) == [datetime(1970, 1, 1, 0, 0, 3), datetime(1970, 1, 1, 0, 0, 2)]
    data = ["2020-01-02T14:23:45+00:00", "1970-01-01T00:00:02+00:00"]
    assert schema.validate(data) == [datetime(2020, 1, 2, 14, 23, 45), datetime(1970, 1, 1, 0, 0, 2)]

# Generated at 2022-06-26 10:11:26.314496
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    date_time_0 = DateTime()
    assert date_time_0.validate_or_error('0') == ValidationResult(value=None, error=ValidationError(text='', code=''))


# Generated at 2022-06-26 10:11:37.355596
# Unit test for method validate of class Array

# Generated at 2022-06-26 10:11:44.768847
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for type of items
    items = String()
    items.validate("abc")
    items = Integer()
    items.validate("123")
    items = Boolean()
    items.validate("true")
    items = Float()
    items.validate("123.4")

    # Test for default value
    default_value = 0
    integer = Integer(default=default_value)
    integer.validate("")
    assert integer.get_default_value() == default_value
    float_number = Float(default=default_value)
    float_number.validate("")
    assert float_number.get_default_value() == default_value

    # Test for allow_null
    boolean = Boolean(allow_null=False)

# Generated at 2022-06-26 10:11:46.294346
# Unit test for method __or__ of class Field
def test_Field___or__():
    Field.__or__({})


# Generated at 2022-06-26 10:11:56.184255
# Unit test for method validate of class String
def test_String_validate():
    # valid case
    date_time_0 = String()
    try:
        date_time_0.validate("2019-01-01T00:00:00+08:00");
        assert True;
    except Exception as error:
        assert False;
    try:
        date_time_0.validate("2019-01-01T00:00:00+09:00");
        assert True;
    except Exception as error:
        assert False;
    try:
        date_time_0.validate("2019-01-01T00:00:00+10:00");
        assert True;
    except Exception as error:
        assert False;

# Generated at 2022-06-26 10:12:05.758952
# Unit test for method validate of class Array

# Generated at 2022-06-26 10:12:16.073760
# Unit test for method validate of class Array
def test_Array_validate():
    # Specific case: null values
    allowed_null = True
    unique_items = True
    min_items = None
    max_items = 5
    allow_extra_properties = True
    test_cases = [
        # test_case_0
        {
            "input": [1, 2, 3, 4, 5, 6],
            "output": None,
            "exceptions": ValidationError,
        },
        # test_case_1
        {"input": None, "output": None, "exceptions": ValidationError},
        # test_case_2
        {"input": "", "output": None, "exceptions": ValidationError},
    ]
    for test_case in test_cases:
        input = test_case["input"]
        output = test_case["output"]

# Generated at 2022-06-26 10:12:19.670343
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    Field_instance = Field(title = '', description = '', default = NO_DEFAULT, allow_null = False)
    result = Field_instance.get_default_value()
    # assert result is a NoneType
    assert isinstance(result, object)


# Generated at 2022-06-26 10:12:47.640899
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_0 = Date()
    any_of_0 = [date_0, date_time_0]
    union_0 = Union(any_of=any_of_0)
    date_1 = Date()
    date_2 = Date()
    any_of_1 = [date_2, date_1]
    union_1 = Union(any_of=any_of_1)
    field_0 = union_0 | union_1


# Generated at 2022-06-26 10:12:50.277762
# Unit test for method validate of class String
def test_String_validate():
    date_time_field = String(format="datetime")
    date_time_field.validate("2020-07-20T18:47:53.022Z")


# Generated at 2022-06-26 10:12:53.074265
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    # Test for method __or__ of class Field
    date_time_0 | date_time_0


# Generated at 2022-06-26 10:12:55.597346
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    assert field_0.get_default_value() == None


# Generated at 2022-06-26 10:13:03.526400
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Setup
    choice_1 = Choice()
    assert choice_1 != None
    assert choice_1.__dict__ != None

    # AssertionError: <class '__main__.Choice'>
    choice_1.__dict__ = Choice()

    # AssertionError: {}
    choice_1.__dict__ = {}
    
    # AssertionError: {}
    choice_1.__dict__ = {'choices': None}
    
    # AssertionError: {}
    choice_1.__dict__ = {'choices': None, 'allow_null': True}
    
    # AssertionError: {}
    choice_1.__dict__ = {'choices': []}
    
    # AssertionError: {}

# Generated at 2022-06-26 10:13:06.089663
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    union_0 = date_time_0 | date_time_0


# Generated at 2022-06-26 10:13:16.141114
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    choice_1 = Choice(allow_null=True, allow_blank=False)
    choice_2 = Choice(choices=[('test_choice_3', 'test_choice_3',), ('test_choice_3', 'test_choice_3',), ('test_choice_3', 'test_choice_3',)])
    choice_3 = Choice(allow_null=True, allow_blank=False, choices=[('test_choice_3', 'test_choice_3',), ('test_choice_3', 'test_choice_3',), ('test_choice_3', 'test_choice_3',)])
    try:
        choice_0.validate(value=None)
    except ValidationError:
        pass

# Generated at 2022-06-26 10:13:23.432186
# Unit test for method validate of class Array

# Generated at 2022-06-26 10:13:33.012674
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Case 0
    array_0 = Array(items=DateTime())
    assert array_0.serialize([]) == []

    # Case 1
    array_0 = Array()
    assert array_0.serialize([]) == []

    # Case 2
    array_0 = Array()
    assert array_0.serialize(["123"]) == ["123"]

    # Case 3
    array_0 = Array()
    assert array_0.serialize(["123", "123"]) == ["123", "123"]

    # Case 4
    array_0 = Array(items=DateTime())
    assert array_0.serialize([]) == []

    # Case 5
    array_0 = Array(items=DateTime())

# Generated at 2022-06-26 10:13:42.319370
# Unit test for constructor of class Array
def test_Array():
    with pytest.raises(AssertionError):
        Array(items=1)
    with pytest.raises(AssertionError):
        Array(items=[1])
    with pytest.raises(AssertionError):
        Array(additional_items=1)
    with pytest.raises(AssertionError):
        Array(min_items=1.0)
    with pytest.raises(AssertionError):
        Array(max_items=1.0)
    with pytest.raises(AssertionError):
        Array(exact_items=1.0)
    with pytest.raises(AssertionError):
        Array(unique_items=1)

# Generated at 2022-06-26 10:14:00.450363
# Unit test for constructor of class Const
def test_Const():
    # Test with an object
    const_0 = Const(const="\"/var/lib/tomcat7/java.policy\"")
    # Test with an int
    const_1 = Const(const=3)
    # Test with a boolean
    const_2 = Const(const=True)
    # Test with a float
    const_3 = Const(const=1.0)
    # Test with a string
    const_4 = Const(const="\"ssh\"")



# Generated at 2022-06-26 10:14:04.397836
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    assert field_0.get_default_value() == None


# Generated at 2022-06-26 10:14:09.130459
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    test_Field_0 = Field()
    default_value = test_Field_0.get_default_value()
    assert default_value == None


# Generated at 2022-06-26 10:14:11.792784
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_1 = DateTime()
    date_time_1.validate("2020-01-21T10:08:51.333891+00:00")


# Generated at 2022-06-26 10:14:25.463635
# Unit test for method serialize of class Array
def test_Array_serialize():
    items_0 = Boolean()
    additional_items_0 = False
    min_items_0 = -5
    max_items_0 = 9
    unique_items_0 = True
    array_0 = Array(
        required=False,
        allow_null=True,
        items=items_0,
        additional_items=additional_items_0,
        min_items=min_items_0,
        max_items=max_items_0,
        unique_items=unique_items_0,
    )
    obj_0 = [
        True,
        True,
        True,
        false,
        False,
        False,
        False,
        False,
        False,
    ]
    return_value = array_0.serialize(obj_0)
    pass


# Generated at 2022-06-26 10:14:30.833350
# Unit test for method validate of class Number
def test_Number_validate():
    assert 1 == Number(allow_blank=True, description='', title='').validate('1')
    assert 1 == Number(allow_blank=True, description='', title='').validate(1)


# Generated at 2022-06-26 10:14:40.975633
# Unit test for method validate of class Union
def test_Union_validate():
    # Local variable declarations
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    number_0 = Number()
    number_1 = Number()
    number_2 = Number()
    number_3 = Number()
    number_4 = Number()
    number_5 = Number()
    any_of_0 = [date_time_0]
    any_of_1 = [date_time_1]
    any_of_2 = [number_0]
    any_of_3 = [number_1]
    any_of_4 = [number_2]
    any_of_5 = [number_3]
    any_of_6 = [number_4]
    any_of_7

# Generated at 2022-06-26 10:14:47.952563
# Unit test for method validate of class Array
def test_Array_validate():
    boolean_0 = Boolean()
    field_0 = Array(items=boolean_0, max_items=1)
    try:
        field_0.validate(False)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must have no more than 1 items.",
                code="max_items",
                index=None,
                constraint={"max_items": 1},
            )
        ]
    try:
        field_0.validate(True)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="Must have no more than 1 items.",
                code="max_items",
                index=None,
                constraint={"max_items": 1},
            )
        ]
    boolean_0 = Boolean()


# Generated at 2022-06-26 10:14:51.129292
# Unit test for constructor of class Const
def test_Const():
    const=Const(3)
    assert const.const==3

# Unittest for constructor of class Number

# Generated at 2022-06-26 10:14:52.724701
# Unit test for constructor of class String
def test_String():
    string_0 = String()


# Generated at 2022-06-26 10:15:20.649826
# Unit test for method validate of class Array
def test_Array_validate():
    array_field_0 = Array(additional_items = False, items = [String(max_length = 2), Number(exclusive_maximum = 2), Null()], max_items = 1, min_items = 1)
    case_0_expected = ["", 0, None]
    # Assert values/types of keys expected in case 0 output
    assert isinstance(array_field_0.validate(case_0_expected), list)
    # Assert values of keys expected in case 0 output
    assert array_field_0.validate(case_0_expected) == case_0_expected


# Generated at 2022-06-26 10:15:32.139536
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    time_0 = Time()
    date_0 = Date()
    choice_0 = Choice(choices=[date_time_0, time_0, date_0])
    # Test if 'choice_0.validate' raises a 'ValidationError' exception
    # Try to validate with an invalid value
    with pytest.raises(ValidationError):
        choice_0.validate(None)
    # Test that if 'choice_0.validate' raises no exception
    # Use a valid value
    try:
        choice_0.validate(date_time_0)
    except ValidationError:
        pytest.fail("Unexpected ValidationError raised")

# Generated at 2022-06-26 10:15:35.175765
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    
    try:
        Field_0 = Field()
        Field_0.get_default_value()

    except Exception as raised_exception:
        return False

    return True

# Generated at 2022-06-26 10:15:41.151848
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_1 = DateTime()
    union_0 = Union([date_time_1])
    try:
        union_0.validate(None)
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:15:46.011556
# Unit test for method validate of class Choice
def test_Choice_validate():
    # ValueError raised.
    try:
        choice = Choice()
        choice.validate(1)
    except ValidationError as error:
        assert error.code == "choice"
    else:
        raise AssertionError("Expected ValidationError to be raised.")


# Generated at 2022-06-26 10:15:47.298010
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert 0 == 0


# Generated at 2022-06-26 10:15:58.743983
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean()
    boolean_1 = Boolean(title="", description="", default=None)
    boolean_2 = Boolean(title="", description="", default=None, allow_null=False)
    boolean_3 = Boolean(title="", description="", default=None, allow_null=True)
    boolean_4 = Boolean(title="", description="", default="", allow_null=False)
    assert boolean_0.validate("", strict=False) == True
    assert boolean_0.validate(1, strict=False) == True
    assert boolean_0.validate("", strict=True) == True
    assert boolean_1.validate(None, strict=False) == None
    assert boolean_2.validate(None, strict=False) == None

# Generated at 2022-06-26 10:16:05.850304
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [
        ('a', 'a'),
        ('b', 'b'),
        ('c', 'c'),
    ]
    f = Choice(choices=choices)
    f.validate(value='a')
    f.validate(value='b')
    f.validate(value='c')
    try:
        f.validate(value='d')
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-26 10:16:14.162693
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Create an instance of class Choice
    choice_0 = Choice()
    # Call method validate of class Choice
    try:
        choice_0.validate(True)
    except ValidationError as validation_error_0:
        print(validation_error_0)
    except TypeError as type_error_0:
        print(type_error_0)


# Generated at 2022-06-26 10:16:15.941022
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    assert (obj.get_default_value() is None)



# Generated at 2022-06-26 10:16:31.787939
# Unit test for constructor of class Const
def test_Const():
    try:
        # Arrange
        const_test = Const(const=3)
        const_test_None = Const(const=None)
        const_test_String = Const(const="test")
        const_test_bool = Const(const=True)
    except Exception:
        # Fail the test
        assert False
    # Pass the test
    assert True



# Generated at 2022-06-26 10:16:36.801057
# Unit test for constructor of class Choice
def test_Choice():
  schema_0 = Choice()
  schema_1 = Choice()
  schema_2 = Choice()
  assert(schema_0.allow_null == True)
  assert(schema_1.allow_null == True)
  assert(schema_2.allow_null == True)

# Unit tests for constructor of class DateTime

# Generated at 2022-06-26 10:16:50.109224
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Make an instance of Choice
    obj0 = Choice()
    # Unit test for field choices
    assert obj0 is not None
    # Test method validate with value = None
    value0 = None
    assert value0 is None
    with pytest.raises(ValidationError, match = "^May not be null.$"):
        obj0.validate(value0)
    # Test method validate with value = ""
    value0 = ""
    assert value0 == ""
    with pytest.raises(ValidationError, match = "^This field is required.$"):
        obj0.validate(value0)
    # Test method validate with value = "Not a valid choice."
    value0 = "Not a valid choice."
    assert value0 == "Not a valid choice."

# Generated at 2022-06-26 10:16:55.436341
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()

    union_0 = Union([date_time_0, date_time_1, date_time_2])

# Generated at 2022-06-26 10:17:00.907454
# Unit test for method validate of class Union
def test_Union_validate():
    some_of_0 = [ DateTime(), Object({})]
    union_0 = Union(some_of_0)
    value_0 = "2020-04-20T12:12:12Z"
    # Test for validate method of Class Union
    _, error_0 = union_0.validate_or_error(value_0)
    assert error_0
    assert error_0.messages()[0].code == "union"

if __name__ == "__main__":
    test_case_0()
    test_Union_validate()

# Generated at 2022-06-26 10:17:10.161897
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    union_0 = Union([date_time_0, date_time_1])
    union_0.validate("2019-01-04T12:54:57.868Z")
    union_0.validate("2019-01-04T12:54:57.868Z")
    union_0.validate("2019-01-04T12:54:57.868Z")
    print("Test 0 passed")

    date_time_2 = DateTime()
    date_time_3 = DateTime()
    union_1 = Union([date_time_2, date_time_3])
    union_1.validate("2019-01-04T12:54:57.868Z")
    union_1.validate

# Generated at 2022-06-26 10:17:22.536602
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test property choices
    test_choice_choices_0 = [(choice, choice) for choice in [] or []]
    # Test property allow_null
    test_choice_allow_null_0 = True
    # Instance of argument value before call
    test_choice_value_1 = ""
    # Instance of argument value after call
    test_choice_value_2 = ""
    # Test class argument strict
    test_choice_strict_0 = True
    # Test property choices
    test_choice_choices_1 = [(choice, choice) for choice in [] or []]
    # Test property allow_null
    test_choice_allow_null_1 = True
    # Instance of argument value before call
    test_choice_value_3 = None
    # Instance of argument value after call
    test_choice_value_

# Generated at 2022-06-26 10:17:26.358681
# Unit test for method validate of class Array
def test_Array_validate():
  array_0 = Array(allow_null=True)

  with pytest.raises(ValidationError) as e:
    array_0.validate(None)
  assert (
    str(e.value)
    == "Array was invalid for the following 1 reason(s):\n\nnull: May not be null."
  )


# Generated at 2022-06-26 10:17:30.343664
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_0.validate(date_time_1)



# Generated at 2022-06-26 10:17:43.205780
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    int_0 = Int()
    assert int_0.get_default_value() == 0
    
    date_time_0 = DateTime()
    assert date_time_0.get_default_value() == datetime.date(1970, 1, 1)

    bool_0 = Boolean()
    assert bool_0.get_default_value() == False

    float_0 = Float()
    assert float_0.get_default_value() == 0.0
    
    datetime_0 = DateTime()
    assert datetime_0.get_default_value() == datetime.datetime(1970, 1, 1, 0, 0)
    
    text_0 = Text()
    assert text_0.get_default_value() == ''
    
test_Field_get_default_value()


# Generated at 2022-06-26 10:18:07.025444
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    """
    Test case for the method validate of class Boolean
    """
    boolean_0 = Boolean()

    # TypeError: 'NoneType' object is not callable
    try:
        boolean_0.validate()
    except TypeError:
        pass

    try:
        boolean_0.validate([1, 2])
    except ValidationError:
        pass

    try:
        boolean_0.validate(1)
    except ValidationError:
        pass

    # ValidationError: Must be a boolean.
    try:
        boolean_0.validate(False)
    except ValidationError:
        pass

    # TypeError: 'NoneType' object is not callable
    try:
        boolean_0.validate([1, 2], strict=False)
    except TypeError:
        pass

    # Val

# Generated at 2022-06-26 10:18:10.445212
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices_0 = Choice()
    value_0 = True
    assert choices_0.validate(value_0) == True


# Generated at 2022-06-26 10:18:14.562110
# Unit test for method validate of class Choice
def test_Choice_validate():
    new_Choice = Choice()
    value = ""
    strict = True
    validation_result = new_Choice.validate_or_error(value, strict=strict)
    assert validation_result.error.text == 'This field is required.'


# Generated at 2022-06-26 10:18:26.747205
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array(additional_items=False, min_items=2)
    field_0 = String(max_length=10)
    array_1 = Array(additional_items=array_0, items=[field_0])
    value_0 = [["1234567890"], [[1]]]
    array_1.validate(value_0)
    value_1 = [[1], [1]]
    with pytest.raises(ValidationError):
        array_1.validate(value_1)


# Generated at 2022-06-26 10:18:35.925136
# Unit test for method validate of class Choice
def test_Choice_validate():
    print("Testing test_Choice_validate...")
    date_time_0 = DateTime()
    date_time_0.set_allow_null(True)
    date_time_0.set_default("")
    date_time_0.validate("",strict=False)
    i = 0
    print("Test case %d passed!" % i)
    i += 1
    return i


# Generated at 2022-06-26 10:18:49.281262
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(allow_null=False, allow_blank=False, choices=[(0, 0), (1, 1), (2, 2), (3, 3), (4, 4)], coerce=False, allow_coerce_none=False)
    assert choice_0.validate(0, strict=False) == 0
    assert choice_0.validate(4, strict=False) == 4
    assert choice_0.validate(None, strict=False) == None
    try:
        assert choice_0.validate(None, strict=False) == None
        assert choice_0.validate(5, strict=False) == 5

    except ValidationError as e:
        pass

test_case_0()
test_Choice_validate()

# Generated at 2022-06-26 10:18:58.284727
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=['', '', '', '', '', '', '', ''], allow_null=True)
    assert choice_0.validate('', strict=False) is None
    assert choice_0.validate(None) is None
    assert choice_0.validate(None) is None



# Generated at 2022-06-26 10:19:01.608946
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    string_1 = String()
    string_0.validate("abcd")
    string_1.validate("abcd")


# Generated at 2022-06-26 10:19:14.223242
# Unit test for method validate of class Number
def test_Number_validate():
    # Test 1: divide by zero
    try:
        Number().validate(1.0 / 0.0)
        assert False
    except ValidationError:
        assert True
    try:
        Number().validate(1.0 / -0.0)
        assert False
    except ValidationError:
        assert True
    try:
        Number().validate(0.0 / 0.0)
        assert False
    except ValidationError:
        assert True
    try:
        Number().validate(0.0 / -0.0)
        assert False
    except ValidationError:
        assert True

    # Test 2: invalid type
    try:
        Number().validate(True)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-26 10:19:15.906120
# Unit test for constructor of class String
def test_String():
    test_case_0()


# Generated at 2022-06-26 10:19:24.389570
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    try:
        result = date_time_0.get_default_value()
    except Exception:
        print('Test failed!')


# Generated at 2022-06-26 10:19:26.290883
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const(allow_null=False)
    assert (const_0.allow_null == False)


# Generated at 2022-06-26 10:19:32.791964
# Unit test for method validate of class Union
def test_Union_validate():
    try:
        date_time_0 = DateTime()
        union_0 = Union(any_of=[date_time_0])
        assert union_0.validate("test") == "test"
    except AssertionError:
        raise AssertionError("test_Union_validate fails")
    return True


# Generated at 2022-06-26 10:19:47.381042
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(items=Date(), min_items=1, unique_items=True)
    obj = [
        pendulum.datetime(2012, 11, 23, 1, 2, 3, tz="utc")
    ]
    value = schema.validate(obj)
    assert isinstance(value, list)
    assert all(isinstance(item, Date) for item in value)
    assert len(value) == 1
    assert len(value) <= 1
    assert all(item == value[0] for item in value)

    schema = Array(items=Date(), max_items=1)
    obj = [
        pendulum.datetime(2012, 11, 23, 1, 2, 3, tz="utc")
    ]
    value = schema.validate(obj)
    assert isinstance(value, list)
