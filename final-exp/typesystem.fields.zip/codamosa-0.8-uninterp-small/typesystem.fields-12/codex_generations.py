

# Generated at 2022-06-26 10:11:04.201228
# Unit test for method validate of class Choice
def test_Choice_validate():
    char_choices = [("a", "a"), ("b", "b"), ("c", "c")]
    char_choice = Choice(choices=char_choices)
    assert char_choice.validate("a") == "a"
    assert char_choice.validate("b") == "b"
    assert char_choice.validate("c") == "c"
    with pytest.raises(ValidationError):
        char_choice.validate("d")
    assert char_choice.validate("") == None


# Generated at 2022-06-26 10:11:08.002269
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_0 = Any()
    any_1 = Any()
    any_2 = Any()
    # test_case_0
    any_2 = any_0 | any_1



# Generated at 2022-06-26 10:11:11.580175
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_0 = Any(False, '', '')
    field_0 = Field(True, '', '', None)
    field_1 = Field(True, '', '', None)
    union_0 = any_0 | field_0
    union_1 = field_1 | any_0
    union_1.any_of[0] = union_0.any_of[0]
    assert union_1.any_of[0] == any_0



# Generated at 2022-06-26 10:11:14.378564
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    any_0 = Any()


# Generated at 2022-06-26 10:11:18.633450
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("A", "a"), ("B", "b"), ("C", "c"), ("D", "d")]
    choice = Choice(choices=choices)
    a = choice.validate(value="A")
    assert a == "A"
    b = choice.validate(value="B")
    assert b == "B"
    c = choice.validate(value="C")
    assert c == "C"
    d = choice.validate(value="D")
    assert d == "D"
    e = choice.validate(value="E")
    assert e == "E"
    e = choice.validate(value=None)
    assert e == None
    e = choice.validate(value="")
    assert e == ""


# Generated at 2022-06-26 10:11:25.694485
# Unit test for constructor of class Choice
def test_Choice():
    choice_0 = Choice(choices=["", "", "", "", ""], allow_blank=True)
    assert choice_0.choices == [("", ""), ("", ""), ("", ""), ("", ""), ("", "")]


# Generated at 2022-06-26 10:11:33.657059
# Unit test for method validate of class Choice
def test_Choice_validate():
    from datetime import datetime

    class C(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return int(obj)

    class D(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            return obj.isoformat()

    class Test(Model):
        a = Field()
        b = Field(null=True)
        c = C()
        d = D()

    obj = Test(
    a=1.0,
    b=None,
    c=datetime(2020, 9, 14, 14, 0, 0),
    d=datetime(2020, 12, 12, 12, 12, 12),
    )

    obj_dict = obj.dict()

    assert obj_dict['a'] == 1.0
    assert obj_dict

# Generated at 2022-06-26 10:11:40.821085
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Case A
    any_0 = Any()
    any_0.default = 'test'
    result = any_0.get_default_value()
    assert result == 'test'

    # Case A1
    any_1 = Any()
    any_1.default = 'test'
    result = any_1.get_default_value()
    assert result == 'test'


# Generated at 2022-06-26 10:11:47.234330
# Unit test for method validate of class Union
def test_Union_validate():
    print("test_Union_validate")
    any_1 = Any()
    null_0 = Null()
    any_0 = Any()
    boolean_0 = Boolean()
    string_0 = String()
    integer_0 = Integer()
    number_0 = Number()
    object_0 = Object()
    array_0 = Array()
    text_0 = Text()
    date_0 = Date()
    time_0 = Time()
    datetime_0 = DateTime()
    union_0 = Union(any_of=[any_1, null_0, any_0, boolean_0, string_0, integer_0, number_0, object_0, array_0, text_0, date_0, time_0, datetime_0])
    value = "test_value"
    actual = union_0.valid

# Generated at 2022-06-26 10:11:58.153500
# Unit test for method validate of class Union
def test_Union_validate():
    any_0 = Any()
    assert any_0.validate(1)
    assert any_0.validate([1,2,"3",4.0])
    assert any_0.validate({"a":"b"})
    assert any_0.validate(None)
    assert any_0.validate(True)
    assert any_0.validate(False)

    class DummyClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            
    assert any_0.validate(DummyClass())

    assert any_0.validate(1, strict=False)
    assert any_0.validate([1,2,"3",4.0], strict=False)
    assert any_0.validate({"a":"b"}, strict=False)

# Generated at 2022-06-26 10:12:08.862365
# Unit test for method validate of class Array
def test_Array_validate():
    test_case_0()

if __name__ == "__main__":
    test_Array_validate()

# Generated at 2022-06-26 10:12:16.082987
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Any()
    array_0 = [[1], [2], [3]]
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    array_0.append(array_0)
    any_1 = array_0[2]
    any_2 = [None, any_1, array_0]
    any_3 = array_0[8]
    any_4 = array_0[9]
    any_5 = array_0[4]
    any_6 = array_0[5]

# Generated at 2022-06-26 10:12:24.494903
# Unit test for method validate of class String
def test_String_validate():

    # Test cases from https://github.com/flask-restx/flask-restx/blob/master/tests/test_types.py#L107

    # Test case 0
    str_field_0 = String(
        title="hello",
        description="world",
        default="str",
    )

    # Test case 1
    str_field_1 = String(
        title="hello",
        description="world",
        default="str",
        allow_blank=True,
    )

    # Test case 2
    str_field_2 = String(
        title="hello",
        description="world",
        default="str",
        allow_blank=True,
        max_length=10,
    )

    # Test case 3

# Generated at 2022-06-26 10:12:35.807612
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(
        [
            Integer(minimum=0, maximum=5),
            String(min_length=1, max_length=5, pattern='(a|b)'),
        ],
        max_items=3,
    )

    # Test 1: Valid case
    schema.validate([0, 1, 2], strict=True)

    # Test 2: Invalid case
    try:
        schema.validate([0, 1, 2, 3], strict=True)
    except ValidationError as e:
        print(e)


# Generated at 2022-06-26 10:12:43.293596
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class Any(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    any_0 = Any()
    test_case_0()
    test_Field_validate_or_error_0(any_0)


# Generated at 2022-06-26 10:12:49.074008
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices_0 = Choice()
    value_0 = None
    choices_0.validate(value_0)

    choices_1 = Choice()
    value_1 = None
    choices_1.validate(value_1)



if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:12:53.324850
# Unit test for method validate of class Object
def test_Object_validate():
    any_0 = Any()
    field_0 = Field()
    field_1 = Field()
    properties_0 = {}
    properties_0["properties_0"] = field_0
    properties_0["properties_1"] = field_1
    object_0 = Object(properties=properties_0)
    value_0 = {"properties_0": "property_0", "properties_1": "property_1"}
    
    object_0.validate(value_0)


# Generated at 2022-06-26 10:13:02.188883
# Unit test for method validate of class Number
def test_Number_validate():
    int_0 = Int()
    string_0 = String()

# Generated at 2022-06-26 10:13:14.354281
# Unit test for method serialize of class Array
def test_Array_serialize():
    str_0 = String()
    integer_0 = Integer()
    array_0 = Array(items=str_0)
    array_1 = Array(items=integer_0)
    boolean_0 = Boolean()
    object_0 = Object(properties={"bar": boolean_0})
    array_2 = Array(items=object_0)
    result_0 = array_0.serialize(["foo", "bar"])
    assert result_0 == ["foo", "bar"]
    result_1 = array_1.serialize([1, 2, 3])
    assert result_1 == [1, 2, 3]
    result_2 = array_2.serialize([{"bar": True}, {"bar": False}])
    assert result_2 == [{"bar": True}, {"bar": False}]


# Generated at 2022-06-26 10:13:26.448850
# Unit test for method validate of class Array
def test_Array_validate():
    array_0_0 = [726611463.568664]
    array_0_1 = [True]
    array_0_2 = [False]
    array_0_3 = ["kecvekvyf"]
    array_0_4 = ["xvxqxqoqz"]
    array_0_5 = [None]
    array_0_6 = [5]
    array_0_7 = [{"hcwppjmx": 352930843.965412}]
    array_0 = [[array_0_0, array_0_1, array_0_2, array_0_3, array_0_4, array_0_5, array_0_6, array_0_7]]
    array_1_0 = [1279.29596917715]
    array

# Generated at 2022-06-26 10:14:02.937349
# Unit test for method validate of class Object
def test_Object_validate():
    # Any
    any_0 = Any()
    # Boolean
    boolean_0 = Boolean()
    # Integer
    integer_0 = Integer()
    # Float
    float_0 = Float()
    # Decimal
    decimal_0 = Decimal()
    # String
    string_0 = String()
    # None
    null_0 = None
    # Object
    object_0 = Object()
    # Array
    array_0 = Array()
    # Test method validate
    integer_0 = Integer(allow_null=True)
    object_0 = Object(allow_null=True, properties={}, pattern_properties=dict(), additional_properties=True)
    object_0 = Object(allow_null=True, properties={}, pattern_properties=dict(), additional_properties=True, property_names=None)
    object_0 = Object

# Generated at 2022-06-26 10:14:06.257063
# Unit test for constructor of class Const
def test_Const():
    try:
        # valid case
        const = Const(const = "Hello")
    except Exception:
        assert False


# Generated at 2022-06-26 10:14:14.248027
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Choice(allow_null=False)
    any_1 = Choice(choices=[("k0", "v0"), ("k1", "v1"), ("k2", "v2"), ("k3", "v3"), ("k4", "v4"), ("k5", "v5"), ("k6", "v6"), ("k7", "v7"), ("k8", "v8"), ("k9", "v9")], allow_null=False)
    any_2 = Choice(choices=[], allow_null=False)

# Generated at 2022-06-26 10:14:17.040858
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    any_0 = Any()
    # Don't know how to call function validate_or_error in Field


# Generated at 2022-06-26 10:14:27.023130
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(
        items = [
            String(max_length=1),
            String(max_length=2),
            String(max_length=3),
        ]
    )

    # Test case 1
    data = [
        "a",
        "bb",
        "ccc",
    ]
    expected_result = [
        "a",
        "bb",
        "ccc",
    ]
    result = field.validate(data)
    assert result == expected_result
    # Test case 2
    data = [
        "a",
        "bb",
        "ccc",
        "dddd",
    ]

# Generated at 2022-06-26 10:14:39.953809
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    _ = Boolean()
    _ = _.validate(True, strict=True)
    _ = _.validate(False, strict=True)
    _ = _.validate(None, strict=True)
    _ = _.validate(None, strict=False)
    try:
        _ = _.validate(None, strict=False)
    except ValidationError as e:
        print(e)
    try:
        _ = _.validate(None, strict=False)
    except ValidationError as e:
        print(e)
    try:
        _ = _.validate(None, strict=False)
    except ValidationError as e:
        print(e)

# Generated at 2022-06-26 10:14:45.686241
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    def check(field, value, strict, field_type):
        assert field.validate_or_error(value, strict=strict).__dict__ == {'value': value, 'error': None}
    any_0 = Any()
    check(any_0, 'a', True, Any)

# Testing the any field

# Generated at 2022-06-26 10:14:51.054044
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 1: array without items
    assert Array().validate([1, 2]) == [1, 2]
    assert Array().validate([]) == []


# Test case 2: array with items

# Generated at 2022-06-26 10:14:57.466110
# Unit test for method validate of class Number
def test_Number_validate():
    numeric_0 = Number()
    str_0 = "Some string"
    bool_0 = False
    exception_0 = None
    try:
        numeric_0.validate(str_0, strict=bool_0)
    except ValidationError as e:
        exception_0 = e
    assert exception_0 is not None
    assert exception_0.code == 'type'


# Generated at 2022-06-26 10:15:04.158339
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    any_0 = Any()
    actual = any_0.validate_or_error(None)
    if actual.value != None:
        raise RuntimeError('Unexpected value of validate_or_error: expected: None, actual: ' + str(actual.value))


# Generated at 2022-06-26 10:15:24.909851
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field=Field(title="title", description="description", default="default", allow_null=True)
    assert field.has_default() == True
    assert field.get_default_value() == "default"

    field2=Field(title="title", description="description", allow_null=True)
    assert field2.has_default() == False
    assert field2.get_default_value() == None

# Test for class

# Generated at 2022-06-26 10:15:26.280789
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_0 = Any()
    any_1 = Any()
    union_2 = any_0 | any_1


# Generated at 2022-06-26 10:15:31.260226
# Unit test for constructor of class String
def test_String():
    # Initialize the object of class String, with parameters of title, description, default and allow_null,
    string_0 = String(title="this is a title", description="This is a description", default="123", allow_null=True)
    string_0_copy = String(title="this is a title", description="This is a description", default="123", allow_null=True)

    # Check whether the instances of String class are the same.
    assert string_0 is not string_0_copy

    # Check the attributes of the String class.
    # Check the attribute of title.
    assert string_0.title == "this is a title"

    # Check the attribute of description.
    assert string_0.description == "This is a description"

    # Check the attribute of default.

# Generated at 2022-06-26 10:15:39.306779
# Unit test for method validate of class Number
def test_Number_validate():
    input_0 = None
    expected_0 = None
    
    actual_0 = Number().validate(input_0)
    assert actual_0 == expected_0

    input_1 = {"allow_null": True}
    expected_1 = None
    
    actual_1 = Number(**input_1).validate(**input_0)
    assert actual_1 == expected_1

    input_2 = {"allow_null": False}
    expected_2 = None
    
    actual_2 = Number(**input_2).validate(**input_0)
    assert actual_2 == expected_2

    input_3 = None
    expected_3 = None
    
    actual_3 = Number().validate(**input_3)
    assert actual_3 == expected_3


# Generated at 2022-06-26 10:15:49.533846
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(allow_null=True, choices=[('choice0', 'choice0'), ('choice1', 'choice1'), ('choice2', 'choice2')])
    choice_0.validate(None, strict=True)
    choice_0.validate('choice0', strict=True)
    choice_0.validate('choice1', strict=True)
    choice_0.validate('choice2', strict=True)
    assert choice_0.validate('choice2', strict=True) is None
    try:
        choice_0.validate(None, strict=False)
        assert False
    except ValidationError:
        assert True

    try:
        choice_0.validate('choice4', strict=True)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-26 10:15:59.915097
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Choice(choices=[])
    # Test passing a null value when nulls are not allowed
    try:
        any_0.validate(value=None)
        assert False
    except ValidationError:
        assert True

    # Test passing an empty string when nulls are allowed
    try:
        any_0.validate(value="")
        assert False
    except ValidationError:
        assert True
    # Test passing a null value when nulls are allowed
    result = any_0.validate(value=None, strict=False)
    assert result is None

    # Test passing an empty string when nulls are allowed
    result = any_0.validate(value="", strict=False)
    assert result == ""

    # Test passing a non null value

# Generated at 2022-06-26 10:16:02.267361
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Case: 0: Any() | Any()
    test_case_0()


# Generated at 2022-06-26 10:16:05.667880
# Unit test for method __or__ of class Field
def test_Field___or__():
    any = Any()
    string = String(max_length=1)
    union = any | string
    assert union.any_of[0] == any
    assert union.any_of[1] == string


# Generated at 2022-06-26 10:16:18.498785
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = None
    syntax_0 = Choice(choices=choices)
    value = None
    strict = True
    syntax_0.validate(value, strict=strict)
    choices = [("foo", "Foo"), ("bar", "Bar"), ("baz", "Baz")]
    syntax_0 = Choice(choices=choices)
    value = None
    strict = True
    syntax_0.validate(value, strict=strict)
    value = "foo"
    syntax_0.validate(value, strict=strict)
    value = "bar"
    syntax_0.validate(value, strict=strict)
    value = "baz"
    syntax_0.validate(value, strict=strict)
    value = "qux"

# Generated at 2022-06-26 10:16:23.048066
# Unit test for method validate of class Number
def test_Number_validate():
    # Case 0
    any_0 = Any()
    assert any_0.validate(1, strict=True) == 1
    assert any_0.validate(None, strict=True) is None
    assert any_0.validate('', strict=True) is ''
    assert any_0.validate(True, strict=True) is True


# Generated at 2022-06-26 10:17:12.084937
# Unit test for method validate of class Number
def test_Number_validate():
    code = """
    def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
        if value is None and self.allow_null:
            return None
        elif value == "" and self.allow_null and not strict:
            return None
        elif value is None:
            raise self.validation_error("null")
        elif isinstance(value, bool):
            raise self.validation_error("type")
        elif (
            self.numeric_type is int
            and isinstance(value, float)
            and not value.is_integer()
        ):
            raise self.validation_error("integer")
        elif not isinstance(value, (int, float)) and strict:
            raise self.validation_error("type")
"""

# Generated at 2022-06-26 10:17:19.761202
# Unit test for method validate of class Union
def test_Union_validate():
    # Create object instance for testing
    any_of = [Any()]
    kwargs = {}
    obj = Union(any_of, **kwargs)
    # Create value to pass to method
    value = 6
    expected = 6
    # Call method and check result
    assert(expected == obj.validate(value))


# Generated at 2022-06-26 10:17:33.112848
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Any()
    boolean_0 = Boolean()
    choice_0 = Choice()
    choice_1 = Choice(allow_null=True)
    choice_2 = Choice(allow_null=False)
    choice_3 = Choice(allow_blank=True)
    choice_4 = Choice(allow_blank=False)
    choice_5 = Choice(allow_null=True, allow_blank=True)
    choice_6 = Choice(allow_null=True, allow_blank=False)
    choice_7 = Choice(allow_null=False, allow_blank=True)
    choice_8 = Choice(allow_null=False, allow_blank=False)
    choice_9 = Choice(choices=[1,2,3])
    choice_10 = Choice(choices=[1,2,3])

# Generated at 2022-06-26 10:17:41.221915
# Unit test for method __or__ of class Field
def test_Field___or__():
    try:
        # Init Test
        any_0 = Any()

        # Clone Test
        any_0_clone = any_0.__or__()

        # Invoke Method on Clone
        any_0_clone.__or__(any_0)

    except Exception as e:
        print("Exception caught in __or__ test method")
        print(e)
        raise e


# Generated at 2022-06-26 10:17:48.378727
# Unit test for method validate of class Union
def test_Union_validate():
    # Build input
    field_1 = Any()
    field_2 = Any()
    any_of = [field_1, field_2]
    value = any_1
    # Create instance
    assert Union(any_of).validate(value) == value


# Generated at 2022-06-26 10:18:00.170755
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Any(allow_blank=True)
    any_1 = Any(allow_null=True)
    any_2 = Any(allow_blank=False)
    any_3 = Any(allow_null=False)
    assert any_0.validate_or_error("") == ValidationResult(value="", error=None)
    assert any_0.validate_or_error(None) == ValidationResult(value=None, error=None)
    assert any_1.validate_or_error("") == ValidationResult(value="", error=None)
    assert any_1.validate_or_error(None) == ValidationResult(value=None, error=None)

# Generated at 2022-06-26 10:18:09.449103
# Unit test for method validate of class Number
def test_Number_validate():
    # Args for Number
    minimum = None
    maximum = None
    exclusive_minimum = None
    exclusive_maximum = None
    precision = None
    multiple_of = None
    # Args for Field
    title = ""
    description = ""
    default = NO_DEFAULT
    allow_null = False
    # Args for test case
    strict = False
    value = None
    assert Number(minimum = minimum, maximum = maximum, exclusive_minimum = exclusive_minimum, exclusive_maximum = exclusive_maximum, precision = precision, multiple_of = multiple_of, title = title, description = description, default = default, allow_null = allow_null).validate(value, strict = strict) == None

# Generated at 2022-06-26 10:18:10.657888
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    num = Number()
    assert num.get_default_value() == 0


# Generated at 2022-06-26 10:18:13.616732
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_0 = Any()
    decimal_1 = Decimal()
    field_2 = Field(title="", description="", )
    union_3 = any_0 | decimal_1
    union_4 = field_2 | decimal_1
    union_5 = field_2 | decimal_1 | any_0
    union_6 = union_5 | any_0


# Generated at 2022-06-26 10:18:28.236288
# Unit test for method validate of class Choice
def test_Choice_validate():
    any_0 = Any()
    any_1 = Any()
    any_2 = Any()
    any_3 = Any()
    any_4 = Any()
    any_5 = Any()
    any_6 = Any()
    any_7 = Any()
    any_8 = Any()
    any_9 = Any()
    any_10 = Any()
    any_11 = Any()
    any_12 = Any()
    any_13 = Any()
    any_14 = Any()
    any_15 = Any()
    any_16 = Any()
    any_17 = Any()
    any_18 = Any()
    any_19 = Any()
    any_20 = Any()
    any_21 = Any()
    any_22 = Any()
    any_23 = Any()
    any_24 = Any()

# Generated at 2022-06-26 10:19:08.438949
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(required=True, choices=["A", "B", "C"])
    input_0 = None
    assert field.validate(input_0) == None
    input_1 = "A"
    assert field.validate(input_1) == "A"
    input_2 = "D"
    try:
        assert field.validate(input_2) == None
    except ValidationError as error:
        assert error.text == "Not a valid choice."
        assert error.code == "choice"
    input_3 = "A"
    assert field.validate(input_3) == "A"
    input_4 = "D"

# Generated at 2022-06-26 10:19:16.481903
# Unit test for method validate of class Union
def test_Union_validate():
    any_0 = Any()
    validate_0 = any_0.validate
    any_0_case_0 = None
    any_0_case_0_strict_0 = False
    any_0_case_0_strict_1 = True
    any_0_case_1 = 1
    any_0_case_1_strict_0 = False
    any_0_case_1_strict_1 = True
    any_0_case_2 = 'abc'
    any_0_case_2_strict_0 = False
    any_0_case_2_strict_1 = True
    validate_1_0 = validate_0.__call__(any_0_case_2, strict=any_0_case_2_strict_0)
    validate_1_1 = validate_

# Generated at 2022-06-26 10:19:24.317190
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const("anything", description="anything")
    assert const_0.description == "anything"
    assert const_0.const == "anything"

    const_1 = Const(True)
    assert const_1.description is None
    assert const_1.const

    const_2 = Const(None)
    assert const_2.description is None
    assert const_2.const is None



# Generated at 2022-06-26 10:19:27.496636
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_0 = Any()
    assert any_0 == any_0 | any_0

    string_0 = String()
    assert string_0 == string_0 | string_0
    assert any_0 == string_0 | any_0
    assert any_0 == any_0 | string_0


# Generated at 2022-06-26 10:19:31.692670
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    value_0 = [1, 2, 3]
    result_0 = array_0.validate(value_0)
    assert result_0 == value_0


# Generated at 2022-06-26 10:19:33.964920
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const(const=None)
    const_1 = Const(const={})
    const_2 = Const(const="")



# Generated at 2022-06-26 10:19:44.152406
# Unit test for constructor of class Const
def test_Const():
    try:
        const_0 = Const(const = "test")
        const_0.validate(value = "test")
        const_0.validate(value = "test1")
    except ValueError:
        pass
    except Exception as e:
        raise AssertionError(str(e))
    else:
        raise AssertionError("Validation error is not raised")
