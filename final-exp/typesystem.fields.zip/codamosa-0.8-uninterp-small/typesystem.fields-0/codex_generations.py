

# Generated at 2022-06-26 10:10:57.854135
# Unit test for method validate of class Union
def test_Union_validate():
    # Create a union field with a single child
    any_of_0 = []
    utc_0 = UTC()
    any_of_0.append(utc_0)
    union_0 = Union(any_of_0, allow_null=True)
    # Create a list of values to validat
    values_0 = []
    values_0.append(True) # Should trip up validation
    values_0.append(None) # Should pass validation
    values_0.append(datetime.datetime.now()) # Should trip up validation


# Generated at 2022-06-26 10:11:10.355413
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time()
    time_1 = Time()

    # Test 1: unittest
    assert time_0 == time_1

    # Test 2: unittest
    assert time_0 != time_1

    # Test 3: unittest
    assert time_0 | time_1

    # Test 4: unittest
    assert time_0 | time_1

    # Test 5: unittest
    assert time_0 | time_1

    # Test 6: unittest
    assert time_0 | time_1

    # Test 7: unittest
    assert time_0 | time_1

    # Test 8: unittest
    assert time_0 | time_1

    # Test 9: unittest
    assert time_0 | time_1

    # Test 10: unittest
    assert time

# Generated at 2022-06-26 10:11:15.482358
# Unit test for method validate of class String
def test_String_validate():
    string = String(
        allow_blank=False,
        trim_whitespace=True,
        max_length=None,
        min_length=None,
        pattern=None,
        format=None,
    )
    assert string.validate("HELLO", strict=False) == "HELLO"


# Generated at 2022-06-26 10:11:24.409991
# Unit test for method validate of class Union
def test_Union_validate():
    time_0 = Time()
    datetime_0 = DateTime()
    union_0 = Union(any_of=[time_0, datetime_0], allow_null=False)
    union_1 = union_0
    union_0.validate("2020-01-01T13:00:00Z")
    union_1.validate("2020-01-01T13:00:00Z")
    union_0.validate("2020-01-01T13:00:00+00:00")
    union_1.validate("2020-01-01T13:00:00+00:00")
    union_0.validate(datetime.datetime(2020, 1, 1, 13, 0, 0))

# Generated at 2022-06-26 10:11:29.816803
# Unit test for method validate of class Array
def test_Array_validate():
    arr = Array(
        items=Object(properties={
           'name': String(),
           'age': Int()
        })
    )
    obj = {
       'name': 'Willem',
       'age': 25
    }
    arr.validate(obj)

if __name__ == "__main__":
    test_Array_validate()

# Generated at 2022-06-26 10:11:32.365741
# Unit test for method validate of class Number
def test_Number_validate():
    Number(maximum=100)


# Generated at 2022-06-26 10:11:39.206878
# Unit test for method validate of class Array
def test_Array_validate():
    items = [
        Integer(maximum=5),
        Float(multiple_of=2),
        Object(properties={
            "a": Integer(minimum=5)
        })
    ]
    schema = Array(items=items, min_items=2, max_items=5)
    assert schema.validate([1, 0.56, {"a": 7}]) == [1, 0.56, {"a": 7}]

# Generated at 2022-06-26 10:11:46.766127
# Unit test for constructor of class Choice
def test_Choice():
    choice_obj = Choice(choices = [1,2,3])
    assert choice_obj.choices == [(1,1),(2,2),(3,3)]
    choice_obj = Choice(choices = [(1,2),(3,4),(5,6)])
    assert choice_obj.choices == [(1,2),(3,4),(5,6)]
    with pytest.raises(AssertionError) as error:
        choice_obj = Choice(choices = [(1,2),(3,4,5),(5,6)])
    assert str(error.value) == "assert all(len(choice) == 2 for choice in self.choices)"
    

# Generated at 2022-06-26 10:11:51.413060
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    time_0 = Time()
    assert time_0.get_default_value() == None

if __name__ == "__main__":
    test_case_0()
    test_Field_get_default_value()

# Generated at 2022-06-26 10:11:55.988020
# Unit test for method validate of class Union
def test_Union_validate():
    case_0 = Union([
        String(),
        String(),
        String(),
        String(),
        String(),
        String()
    ])
    case_0.validate('abc')


# Generated at 2022-06-26 10:12:38.962419
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time()
    time_1 = Time()
    time_2 = Time()
    time_3 = Time()
    time_4 = Time()
    time_5 = Time()
    time_6 = Time()
    time_7 = Time()
    time_8 = Time()
    time_9 = Time()
    time_10 = Time()
    time_11 = Time()
    time_12 = Time()
    time_13 = Time()
    time_14 = Time()
    time_15 = Time()
    time_16 = Time()
    time_17 = Time()
    time_18 = Time()
    time_19 = Time()
    time_20 = Time()
    time_21 = Time()
    time_22 = Time()
    time_23 = Time()
    time_24 = Time()

# Generated at 2022-06-26 10:12:46.597304
# Unit test for method validate of class Array
def test_Array_validate():
    value = [1,2,3]
    field = Array(min_items=1)
    field.validate(value)

    time_range = Array(min_items=2, max_items=2, unique_items=True)
    time_range.validate([1, 2])
    time_range.validate([1, 1])



# Generated at 2022-06-26 10:12:50.908191
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    print(field_0.get_default_value()) 


# Generated at 2022-06-26 10:13:00.380644
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for case 0 - Array object with default values
    array_0 = Array()
    # test for case 0.1
    try:
        result = array_0.validate(None)
        assert False == True
    except ValidationError:
        pass
    # test for case 0.2 - array of integer
    try:
        result = array_0.validate([1, 2, 3, 4])
    except ValidationError:
        assert False == True
    assert [1, 2, 3, 4] == result
    # test for case 0.3 - array of string
    try:
        result = array_0.validate(['1', '2', '3', '4'])
    except ValidationError:
        assert False == True
    assert ['1', '2', '3', '4'] == result
    #

# Generated at 2022-06-26 10:13:09.858944
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number()
    # value = None, strict = False
    # ValueError: Cannot convert None to int
    try:
        result = number_0.validate(None, False)
        print(result)
    except:
        print(traceback.format_exc())
    # value = None, strict = True
    # ValueError: Cannot convert None to int
    try:
        result = number_0.validate(None, True)
        print(result)
    except:
        print(traceback.format_exc())
    # value = 2.5, strict = False
    # 2.5
    try:
        result = number_0.validate(2.5, False)
        print(result)
    except:
        print(traceback.format_exc())
    # value = 2.5, strict

# Generated at 2022-06-26 10:13:21.025584
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    def test_case_0():
        obj = [1, 2, 3]
        validator = array_0
        assert validator.validate(obj) == [1, 2, 3]
        #TODO: what if items are not unique?
    def test_case_1():
        obj = [1, 2, 3, 4]
        validator = array_0
        min_items = validator.min_items
        max_items = validator.max_items
        assert validator.validate(obj) == [1, 2, 3, 4]
        #TODO: what if items are not unique?
    test_case_0()
    test_case_1()

# Generated at 2022-06-26 10:13:31.586595
# Unit test for method validate of class Array
def test_Array_validate():
    time_01 = Time()
    time_01_validate = Array(
        items=Time(),
        max_items=None,
        min_items=None,
        additional_items=None,
        unique_items=None
    )
    time_01_validate.validate(["12:23:34"])
    time_01_validate.validate([["12:23:34"]])
    time_01_validate.validate([None])
    # Test Case 1
    time_01 = Time()
    time_01_validate = Array(
        items=Time(),
        max_items=None,
        min_items=None,
        additional_items=None,
        unique_items=None
    )
    time_01_validate.validate("12:23:34")
    time_

# Generated at 2022-06-26 10:13:40.222399
# Unit test for method validate of class Array
def test_Array_validate():
    items = [Integer()]
    additional_items = Boolean()
    min_items = 10
    max_items = 100
    unique_items = True
    time_Array = Array(items, additional_items, min_items, max_items, unique_items)
    value = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    for i in range(0, 100000):
        time_Array.validate(value)


# Generated at 2022-06-26 10:13:45.871570
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=[1])
    assert choice_0.validate(1) == 1
    assert choice_0.validate(2) == ValidationError("choice")
    assert choice_0.validate(None) == ValidationError("null")



# Generated at 2022-06-26 10:13:48.966761
# Unit test for method serialize of class String
def test_String_serialize():
    string_obj = String()
    assert string_obj.serialize("string_obj") == "string_obj"



# Generated at 2022-06-26 10:14:15.638940
# Unit test for method validate of class Array
def test_Array_validate():
    array_1 = Array(items=String(min_length=5), min_items=1)
    try:
        array_1.validate(["12345", "12345"])
        print("SUCCESS")
    except ValidationError as e:
        print(e)
    try:
        array_1.validate(["12345", "123"])
        print("FAIL")
    except ValidationError as e:
        print(str(e.messages()[0]))
    try:
        array_1.validate([1234, "12345"])
        print("FAIL")
    except ValidationError as e:
        print(str(e.messages()[0]))

# Generated at 2022-06-26 10:14:26.546140
# Unit test for method validate of class Number
def test_Number_validate():
    from unittest import TestCase
    from decimal import Decimal
    from numbers import Number

    class Test(TestCase):
        def test_no_args(self):
            f = Number()
            self.assertEqual(f.validate("1"), 1)
            self.assertEqual(f.validate("42"), 42)
            self.assertEqual(f.validate("-42"), -42)
            self.assertEqual(f.validate("-42.0"), -42)
            self.assertEqual(f.validate("3.14"), 3.14)
            self.assertEqual(f.validate("-3.14"), -3.14)
            self.assertEqual(f.validate("1e+10"), 1e+10)

# Generated at 2022-06-26 10:14:30.132559
# Unit test for method validate of class Choice
def test_Choice_validate():
    time_0 = Time()
    time_0.validate(value=None, strict=True)



# Generated at 2022-06-26 10:14:34.581317
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time()
    time_1 = Time()
    time_2 = time_0 | time_1
    assert time_2.any_of == [time_0, time_1]


# Generated at 2022-06-26 10:14:39.868609
# Unit test for method validate of class Array
def test_Array_validate():
    time_0 = Time()
    time_1 = time_0.serialize('01:00:00')
    assert time_1 == '01:00:00'


# Generated at 2022-06-26 10:14:45.073781
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time();
    time_1 = Time();
    time_2 = time_0 | time_1
    if time_2:
        time_3 = time_0 | time_1
    else:
        time_4 = time_0 | time_1



# Generated at 2022-06-26 10:14:48.740872
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    time_0 = Time()
    assert time_0.get_default_value() == None


# Generated at 2022-06-26 10:14:50.906178
# Unit test for method validate of class String
def test_String_validate():
    test_String_obj = String(pattern='^123$')


# Generated at 2022-06-26 10:14:55.858762
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    # test case 1
    # input：value = "a"
    # expect：ValidationError
    try:
        choice.validate("a")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:15:08.952703
# Unit test for method validate of class Number
def test_Number_validate():
    int_num = Number()
    assert int_num.validate(1) == 1
    assert int_num.validate(2.0) == 2
    assert int_num.validate(2.1) == 2.1
    assert int_num.validate(True) == 1
    assert int_num.validate(False) == 0
    assert int_num.validate(None) == None

    f_num = Float()
    assert f_num.validate(1) == 1.0
    assert f_num.validate(2.0) == 2.0
    assert f_num.validate(2.1) == 2.1
    assert f_num.validate(True) == 1.0
    assert f_num.validate(False) == 0.0

# Generated at 2022-06-26 10:15:21.235575
# Unit test for method validate of class Array
def test_Array_validate():
    # Instantiate member of class Array
    time_0 = Array(
        additional_items = Time()
    )
    print("Time configured: ", time_0)
    # Invoke method validate of class Array
    validate_0 = time_0.validate()
    print("Result of validate(): ", validate_0)


# Generated at 2022-06-26 10:15:34.641232
# Unit test for method validate of class Object

# Generated at 2022-06-26 10:15:39.030620
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field(default=1).get_default_value() == 1
    assert Field().get_default_value() == None


# Generated at 2022-06-26 10:15:41.151814
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate(None) == "null"


# Generated at 2022-06-26 10:15:44.591281
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # TODO, this test should be improved
    time_field = Time()
    assert time_field.get_default_value() == 0



# Generated at 2022-06-26 10:15:46.471271
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const(const=1.0)



# Generated at 2022-06-26 10:15:52.052896
# Unit test for method validate of class Number
def test_Number_validate():
    # Value is a number
    number_0 = Number()
    assert number_0.validate(0) == 0
    # Value is a string
    number_0 = Number()
    assert number_0.validate("0") == 0
    # Value is a string but exception
    number_0 = Number()
    try:
        number_0.validate("")
        assert False
    except ValidationError:
        assert True
    # Value is a string whose length is 1
    number_0 = Number(max_length=1)
    assert number_0.validate("0") == 0
    # Value is a string whose length is 2
    number_0 = Number(max_length=1)
    try:
        number_0.validate("00")
        assert False
    except ValidationError:
        assert True
   

# Generated at 2022-06-26 10:16:00.985173
# Unit test for method validate of class String
def test_String_validate():
    # date_string = '2004-12-14'
    # date_format = '%Y-%m-%d'
    #
    # datetime_string = '2004-12-14 23:15:00'
    # datetime_format = '%Y-%m-%d %H:%M:%S'
    #
    # time_string = '23:15:00'
    # time_format = '%H:%M:%S'

    # string = '2004-12-14 23:15:00'

    date_time = datetime.datetime(2004, 12, 14, 23, 15, 00)

    # test input: 2004-12-14
    string = '2004-12-14'
    date_string = string
    date_format = '%Y-%m-%d'

# Generated at 2022-06-26 10:16:04.538796
# Unit test for method validate of class Array
def test_Array_validate():
    # Can set 'unique_items' to True and will raise error
    field = Array(unique_items = True)
    field.validate([1,2,2])


# Generated at 2022-06-26 10:16:16.249695
# Unit test for method serialize of class Array
def test_Array_serialize():
    array = Array()
    assert array.serialize(None) == None
    assert array.serialize([1, 2, 3]) == [1, 2, 3]
    array = Array(items=Number())
    assert array.serialize(None) == None
    assert array.serialize([1, 2, 3]) == [1, 2, 3]
    array = Array(items=Number(min_value=0, max_value=10))
    assert array.serialize(None) == None
    assert array.serialize([1, 2, 3]) == [1, 2, 3]
    
    

# Generated at 2022-06-26 10:16:26.092054
# Unit test for constructor of class Const
def test_Const():
    # Constructor without arguments
    test_const = Const(const = 10)
    assert test_const.const == 10


# Generated at 2022-06-26 10:16:37.935249
# Unit test for constructor of class String
def test_String():

    # "hello" is a valid value
    valid_value = "hello"
    # "null" is an invalid value
    invalid_value = "null"
    # "" is an invalid value
    invalid_value2 = ""

    # Two tests for case 1
    # Case 1: INPUT: A valid value
    # Expected: A valid value
    # INPUT: A non-valid value
    # Expected: Exception raised
    string_0 = String()
    assert string_0.validate(valid_value) == valid_value == "hello"
    exception_0 = False
    try:
        string_0.validate(invalid_value)
    except Exception:
        exception_0 = True
    assert exception_0 == True

    # Two tests for case 2
    # Case 2: INPUT: A valid value
    #

# Generated at 2022-06-26 10:16:50.485948
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Case 0: vaidate non-null and non-empty string values in the choices
    choice = Choice(choices=["apple", "orange"])
    assert choice.validate("apple") == "apple"
    assert choice.validate("orange") == "orange"

    # Case 1: vaidate a null value when allow_null is True
    choice = Choice(choices=["apple", "orange"], allow_null=True)
    assert choice.validate(None) == None

    # Case 2: vaidate a null value when allow_null is False
    with pytest.raises(ValidationError) as error:
        choice = Choice(choices=["apple", "orange"], allow_null=False)
        choice.validate(None)

    # Case 3: vaidate an empty string value when allow_null is True and

# Generated at 2022-06-26 10:17:00.776971
# Unit test for method serialize of class Array
def test_Array_serialize():
    from decimal import Decimal
    from .number import Number

    # Check that serialize returns None if obj is None.
    array = Array()
    assert array.serialize(None) == None

    # Check that serialize simply returns obj if items is not an Array or if items == None:
    array = Array()
    assert array.serialize([1, 2, 3]) == [1, 2, 3]

    array = Array(items=Number)
    assert array.serialize([1, 2, 3]) == [1, 2, 3]

    array = Array(items=[Number, String])
    assert array.serialize([1, "2", 3]) == [1, "2", 3]

    # Check that serialize returns the results of serializing each item.
    array = Array(items=[Number, String])

# Generated at 2022-06-26 10:17:04.377385
# Unit test for constructor of class String
def test_String():
    string_0 = String(title="test")

################################################################################
#                               Class Integer                                  #
################################################################################

# Generated at 2022-06-26 10:17:09.602274
# Unit test for method validate of class Choice
def test_Choice_validate():
    name = Choice(choices=[("Anna", "Anna"), ("Jake", "Jake")])
    assert name.validate("Anna") == "Anna"
    assert name.validate("Jake") == "Jake"
    with pytest.raises(ValidationError):
        name.validate("Sam")


# Generated at 2022-06-26 10:17:12.174761
# Unit test for constructor of class Const
def test_Const():
    expected_time = Time()
    Const(expected_time)



# Generated at 2022-06-26 10:17:19.837797
# Unit test for method validate of class Array
def test_Array_validate():
    time_0 = Time()
    time_0.validate(["23:59:59", "no"])
    time_0.allow_null = True
    time_0.validate(["22:59:59", None])
    time_0.validate(None)
    time_0.allow_null = False


# Generated at 2022-06-26 10:17:33.138946
# Unit test for method validate of class Array
def test_Array_validate():
    # test 1
    array_0 = Array()
    num_0 = 0
    # Input array_0.validate(num_0), return an array
    array_0.validate(num_0)

    # test 2
    array_1 = Array()
    element_list_0 = []
    # Input array_1.validate(element_list_0), return an array
    array_1.validate(element_list_0)

    # test 3
    array_2 = Array()
    index_0 = 0
    element_list_1 = ["SsOmShgSHI", "GjKdJHkdeT", "fIcPHKMtCQ"]
    element_list_2 = []
    # Input array_2.validate(element_list_1), 
    # return ["

# Generated at 2022-06-26 10:17:44.133820
# Unit test for method validate of class Object
def test_Object_validate():
    # Define input values
    a = {}
    b = []
    c = "Hello World"
    d = 1.3
    e = 1
    f = True
    g = None
    h = [1, 2, 3, 4] #This will cause an error due to invalid key type

    # Define expected outputs
    e_out_001 = {}
    e_out_002 = {}
    e_out_003 = {}
    e_out_004 = {}
    e_out_005 = {}
    e_out_006 = {}
    e_out_007 = {}
    e_out_008 = {}
    e_out_009 = {}
    e_out_010 = {}
    e_out_011 = {}

    e_out_012 = {}

    # Define test objects
    o_001 = Object

# Generated at 2022-06-26 10:17:54.000706
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    time_0 = Time()
    assert time_0.has_default() == False
    assert time_0.get_default_value() == None



# Generated at 2022-06-26 10:18:06.988140
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case
    time_0 = Time()
    time_0.unit = "ns"
    time_0.value = 2
    time_0_1 = Time()
    time_0_1.unit = "us"
    time_0_1.value = 3
    time_0_2 = Time()
    time_0_2.unit = "ms"
    time_0_2.value = 4
    time_0_3 = Time()
    time_0_3.unit = "s"
    time_0_3.value = 5
    time_0_4 = Time()
    time_0_4.unit = "m"
    time_0_4.value = 6
    time_0_5 = Time()
    time_0_5.unit = "h"

# Generated at 2022-06-26 10:18:19.880446
# Unit test for method validate of class Array
def test_Array_validate():
    # Check min_items, max_items and exact_Items
    # When values of those fields are set to be 0
    correct_list1 = [1, 2, 3]
    correct_list2 = []
    input_list1 = [1, 2, 3, 4]
    input_list2 = []
    input_list3 = [1, 2]
    array1 = Array(min_items = 0, max_items = 3, exact_Items = None)
    array2 = Array(min_items = 0, max_items = None, exact_Items = 0)
    array3 = Array(min_items = None, max_items = 2, exact_Items = None)
    array4 = Array(min_items = None, max_items = None, exact_Items = 4)
    assert array1.validate(correct_list1)

# Generated at 2022-06-26 10:18:25.581796
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Setup
    choice_0 = Choice(choices=[])

    # Assignment
    actual_outcome = choice_0.validate(value=None)

    # Validate outcome
    assert actual_outcome is None


# Generated at 2022-06-26 10:18:33.241177
# Unit test for method validate of class Choice
def test_Choice_validate():

    @dataclass
    class Data(Model):
        max_choice: int = Choice(choices=[(5,5), (2,2), (4,4), (7,7)])

    data = Data()
    assert data.max_choice == 5

    data.max_choice = 4
    assert data.max_choice == 4



# Generated at 2022-06-26 10:18:41.759989
# Unit test for method validate of class Array
def test_Array_validate():
    class Case0(typing.NamedTuple):
        field: Array

    def check(
        *,
        value: typing.Any,
        is_valid: bool,
        output: typing.Optional[typing.Any] = None,
        error: typing.Optional[ValidationError] = None,
    ):
        result = Case0(field=Field())
        result.field.validate(value)
        output = result.field.serialize(output)

        try:
            result.field.validate(value)
        except ValidationError as e:
            assert is_valid is False
            assert error == e
        else:
            assert is_valid is True
            assert result.field.serialize(value) == output


# Generated at 2022-06-26 10:18:52.309478
# Unit test for method validate of class Choice
def test_Choice_validate():
    int_1 = Integer()
    bool_1 = Boolean()
    str_1 = String()
    choice_1 = Choice()
    list_1 = List()
    dict_1 = Dict()
    any_1 = Any()
    union_1 = Union()
    num_1 = Number()
    float_1 = Float()
    choice_1 = Choice()
    choice_2 = Choice(choices=((1, "1"), (2, "2")))
    str_2 = String(min_length=3, max_length=6)
    int_2 = Integer(minimum=10, maximum=50)
    choice_3 = Choice(choices=[(1, "1"), (2, "2"), (3, "3")])
    list_2 = List(min_items=2, max_items=4)


# Generated at 2022-06-26 10:19:04.068970
# Unit test for method validate of class String
def test_String_validate():
    # Test case 0
    s = String()
    value = s.validate("yes")
    assert value == "yes"
    value = s.validate("")
    assert value == ""
    value = s.validate(None)
    assert value == "null"
    value = s.validate(1) # ValidationError
    print(type(value), value)
    assert value == "Must be a string."
    # Test case 1
    s = String(trim_whitespace=False)
    value = s.validate("\t\t yes\n")
    assert value == "\t\t yes\n"
    # Test case 2
    s = String(allow_blank=True)
    value = s.validate("")
    assert value == ""
    value = s.validate(None)
   

# Generated at 2022-06-26 10:19:15.341301
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 0
    array_0 = Array()
    assert array_0.validate([0]) == [0]
    assert array_0.validate([]) == []
    try:
        assert array_0.validate([0, 1]) == [0, 1]
    except ValidationError as error_0:
        assert error_0.messages()[0].code == "max_items"
    try:
        assert array_0.validate([0, -1]) == [0, -1]
    except ValidationError as error_1:
        assert error_1.messages()[0].code == "additional_items"
    try:
        assert array_0.validate(["a", 0]) == ["a", 0]
    except ValidationError as error_2:
        assert error_2.mess

# Generated at 2022-06-26 10:19:18.152844
# Unit test for constructor of class Const
def test_Const():
    const = Const('string')


# Generated at 2022-06-26 10:19:37.830902
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [("1", "one"), ("2", "two"), ("3", "three")]
    c = Choice(choices=choices, required=True)

    with pytest.raises(ValidationError):
        c.validate(None)

    with pytest.raises(ValidationError):
        c.validate("")
    
    with pytest.raises(ValidationError):
        c.validate("five")
    
    assert c.validate("2") == "2"

    c = Choice(choices=choices, required=False)

    assert c.validate(None) == None

    assert c.validate("") == ""

    with pytest.raises(ValidationError):
        c.validate("five")

    assert c.validate("2") == "2"


