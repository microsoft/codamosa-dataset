

# Generated at 2022-06-26 10:11:25.413448
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()
    object_1 = object_0.validate({})
    assert object_1 == {}


# Generated at 2022-06-26 10:11:35.030888
# Unit test for method __or__ of class Field
def test_Field___or__():
    object_0 = Object()
    object_1 = Object()
    assert isinstance(object_0, Field)
    assert isinstance(object_1, Field)
    object_2 = object_0 | object_1
    assert isinstance(object_2, Union)
    assert object_2.any_of == [object_0, object_1]
    object_3 = object_0 | object_2
    assert isinstance(object_3, Union)
    assert object_3.any_of == [object_0] + object_2.any_of
    object_4 = object_2 | object_3
    assert isinstance(object_4, Union)
    assert object_4.any_of == object_2.any_of + object_3.any_of



# Generated at 2022-06-26 10:11:36.751599
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Object()
    object_0 = object_0.get_default_value()


# Generated at 2022-06-26 10:11:40.724644
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object()
    try:
        object_1 = Union(any_of=[object_0])
        object_1.validate(None)
        object_1.validate(None)
    except:
        e = sys.exc_info()[1]
        print(e)


# Test case for method validate of class Text

# Generated at 2022-06-26 10:11:52.686395
# Unit test for method validate of class Array
def test_Array_validate():
    # This test fails because Array needs to have a max_items value, which is not possible
    # since Uniqueness.add throws an error. The other tests that use Uniqueness return an
    # error message, but not this one because it is caught by the parent Object.
    object = Object(
        properties={
            "my_data": Array(
                items=Integer(), unique_items=True, allow_null=True,
            )
        }
    )
    data = {
        'my_data': [1, 1, 2],
    }
    validated, error = object.validate_or_error(data)
    print("test_Array_validate is successful")


# Generated at 2022-06-26 10:11:54.584269
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    object_0 = Field()
    test_case_0()

# Generated at 2022-06-26 10:12:05.126661
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object({})
    object_1 = Object({})
    object_2 = Object({})
    object_3 = Object({})
    object_4 = Object({})
    object_5 = Object({})
    object_6 = Object({})
    object_7 = Object({})
    object_8 = Object({})
    object_9 = Object({})
    object_10 = Object({})
    object_11 = Object({})
    object_12 = Object({})
    object_13 = Object({})
    object_14 = Object({})
    list_0 = [object_7, object_11, object_14]
    object_15 = Object({})

# Generated at 2022-06-26 10:12:15.840288
# Unit test for method validate of class String
def test_String_validate():
    obj_0 = String(allow_blank=True, allow_null=True, title='', description='')
    # Expecting type ValidationError
    try:
        obj_0.validate(None, strict=True)
    except ValidationError as e:
        pass
    # Raises exception ValidationError
    try:
        obj_0.validate(None, strict=False)
    except ValidationError as e:
        assert e.code == 'blank'
    # Expecting type ValidationError
    try:
        obj_0.validate(__TEST_DATA__)
    except ValidationError as e:
        pass
    # Expecting type ValidationError
    try:
        obj_0.validate(None)
    except ValidationError as e:
        pass
    # Expecting type ValidationError

# Generated at 2022-06-26 10:12:21.193934
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()
    dict_0 = {"test": 78}
    result_0 = object_0.validate(dict_0, strict=False)
    assert result_0 == {"test": 78}


# Generated at 2022-06-26 10:12:21.994009
# Unit test for constructor of class String
def test_String():
    assert issubclass(String, Field)


# Generated at 2022-06-26 10:12:42.998724
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Object()
    object_0 | object_0
    object_0.get_default_value()


# Generated at 2022-06-26 10:12:53.385727
# Unit test for method serialize of class Array
def test_Array_serialize():
    arr = Array(items=String())
    assert arr.serialize([]) == []
    assert arr.serialize(["foo", "bar"]) == ["foo", "bar"]

    arr = Array(items=Boolean())
    assert arr.serialize([True, False]) == [True, False]

    arr = Array(items=Integer())
    assert arr.serialize([123, 0]) == [123, 0]

    arr = Array(items=Number())
    assert arr.serialize([123, 0.124]) == [123, 0.124]

    arr = Array(items=Object())

# Generated at 2022-06-26 10:13:02.253920
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()
    string_0.validate_or_error('zX8Ao7')
    print(string_0.validate_or_error('2'))
    string_0.validate_or_error('VuU')
    print(string_0.validate_or_error('aAlhR'))
    string_0.validate_or_error('4Q6')
    print(string_0.validate_or_error('0'))
    string_0.validate_or_error('Uf8')
    print(string_0.validate_or_error('f'))
    # print(string_0.validate_or_error(''))
    string_0.validate_or_error('_')

# Generated at 2022-06-26 10:13:09.358666
# Unit test for constructor of class Const
def test_Const():
    object_0 = Const(True)
    object_0 = Const(False)
    object_0 = Const(None)
    object_0 = Const(True, description="unit test")
    object_0 = Const(False, description="unit test")
    object_0 = Const(None, description="unit test")


# Generated at 2022-06-26 10:13:10.869269
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice()



# Generated at 2022-06-26 10:13:21.862353
# Unit test for method validate of class Choice
def test_Choice_validate():
    valid_data = {}
    valid_data["valid_data"] = "valid_value"
    valid_data["valid_data_1"] = valid_data["valid_data"] + "1"
    valid_data["valid_data_2"] = valid_data["valid_data"] + "2"
    valid_data["valid_data_3"] = valid_data["valid_data"] + "3"

    field = Choice(choices=[(valid_data["valid_data"], valid_data["valid_data"])])
    field.validate(valid_data["valid_data"] )

    # The following statements should throw exception:
    try:
        field.validate("invalid_value")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:13:25.311191
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_object = Field()
    test_object.default = 'test_string'
    assert (test_object.get_default_value() == 'test_string') != True


# Generated at 2022-06-26 10:13:26.364981
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice.validate(null, None) == "null"

# Generated at 2022-06-26 10:13:31.509401
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(items=Integer(allow_null=False), unique_items=True)
    try:
        schema.validate(['a'])
    except ValidationError as e:
        print(e.messages())
        print(e.message())
        print(e.message_dict())

if __name__ == "__main__":
    test_Array_validate()
    test_case_0()

# Generated at 2022-06-26 10:13:41.002752
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Choice()
    value = object_0.validate(value = None)
    assert value is None
    value = object_0.validate(value = "")
    assert value is None
    value = object_0.validate(value = "", strict = True)
    assert value is None
    object_0.allow_null = False
    value = object_0.validate(value = None, strict = False)
    assert value is None
    object_0.allow_null = False
    try:
        value = object_0.validate(value = "")
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:13:49.823828
# Unit test for method validate of class String
def test_String_validate():
    object_0 = String()


# Generated at 2022-06-26 10:14:02.409879
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    # Unit test for get_default_value method of class Field
    class Field(Field):

        def get_default_value(self):
            return getattr(self, "default", None)

        def has_default(self):
            has_default = super().has_default()
            return has_default

    Field_0 = Field()

    # Type check the default value of Field_0
    if not isinstance(Field_0.get_default_value(), object):
        print("Error: The method get_default_value of Field class is not returning a valid value. Expected a value of type: object. Got " + str(type(Field_0.get_default_value())))
    else:
        print("Passed type check method for get_default_value of Field class")

    # Type check the return value of the has_default method of

# Generated at 2022-06-26 10:14:13.468690
# Unit test for constructor of class Const
def test_Const():
    assert Const.__doc__ is not None

    # Test 1
    test_case_1 = Const("Test1")
    assert test_case_1.allow_null is False
    assert test_case_1.const == "Test1"
    assert test_case_1.required is False
    assert test_case_1.default is None
    assert test_case_1.errors["only_null"] == "Must be null."
    assert test_case_1.errors["const"] == "Must be the value 'Test1'."

    # Test 2
    test_case_2 = Const("Test2", default="Test2", allow_null=True, required=True)
    assert test_case_2.allow_null is True
    assert test_case_2.const == "Test2"
    assert test_case_2.required is True

# Generated at 2022-06-26 10:14:25.822924
# Unit test for constructor of class Array
def test_Array():
    # Test constructor with multiple parameters
    test_array_0 = Array()
    test_array_1 = Array(items=1)
    test_array_2 = Array(items=1, additional_items=1)
    test_array_3 = Array(items=1, additional_items=1, min_items=1)
    test_array_4 = Array(items=1, additional_items=1, min_items=1, max_items=1)
    test_array_5 = Array(items=1, additional_items=1, min_items=1, max_items=1, unique_items=True)
    test_array_6 = Array(items=1, additional_items=1, min_items=1, max_items=1, unique_items=True, allow_null=True)

# Generated at 2022-06-26 10:14:27.305900
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Case 0
    array_0 = Array()
    obj_0 = ["Hello","Hi","Bye"]
    assert array_0.serialize(obj_0) == obj_0


# Generated at 2022-06-26 10:14:40.105211
# Unit test for method validate of class Array
def test_Array_validate():
    object_0 = Array()
    assert_exception(ValueError, '"min_items" must be an integer', object_0, None)
    assert_exception(ValueError, '"max_items" must be an integer', object_0, None)
    assert_exception(ValueError, '"exact_items" must be an integer', object_0, None)
    object_0 = Array(min_items = 'a');
    assert_exception(ValueError, '"min_items" must be an integer', object_0, None)
    object_0 = Array(max_items = 'a');
    assert_exception(ValueError, '"max_items" must be an integer', object_0, None)
    object_0 = Array(exact_items = 'a');

# Generated at 2022-06-26 10:14:44.669377
# Unit test for constructor of class String
def test_String():
    # Tests for __init__
    from typesystem.fields import String
    from typesystem.unique import Uniqueness
    from typesystem.errors import ValidationError
    from typesystem.types.object import Object

    object_0 = Object()
    str_0 = String(title='title', description='description', default='default_value', allow_null=True)



# Generated at 2022-06-26 10:14:48.657267
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object()
    object_1 = Object()
    object_0.additional_properties = object_1
    object_0.allow_null = True
    object_1.default = None
    object_2 = Object()
    object_2.additional_properties = object_1
    object_2.allow_null = True
    object_1.default = None
    union_0 = Union([object_0, object_2])
    union_0.validate(None)



# Generated at 2022-06-26 10:14:53.314830
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()
    test_value = "test-value"
    result = string_0.serialize(test_value)
    assert result == "test-value"


# Generated at 2022-06-26 10:14:54.836100
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Object()


# Generated at 2022-06-26 10:15:05.958741
# Unit test for constructor of class Const
def test_Const():
    c = Const(10)
    c.validate(10)

    try:
        c.validate(1)
    except ValidationError:
        pass



# Generated at 2022-06-26 10:15:07.337344
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    object_0 = Boolean()
    object_0.validate(None, strict=None)


# Generated at 2022-06-26 10:15:15.102745
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array(items=None).serialize(['foo', 'bar'])
    assert Array(items=String()).serialize(['foo', 'bar'])
    assert Array(items=[String(), Optional(String())]).serialize(['foo', 'bar', None])
    try:
        assert Array(items=[String(), Optional(String())]).serialize(['foo', True, None])
        raise Exception("Did not raise ValidationError.")
    except ValidationError:
        pass

# Generated at 2022-06-26 10:15:22.723510
# Unit test for method validate of class Array
def test_Array_validate():
    test_array = Array()
    
    # Case 0
    assert test_array.validate([1, 2, 3]) == [1, 2, 3], "Case 0Failed"
    # Case 1
    assert test_array.validate(1) == ValidationError(messages=Message(text='Must be an array.', code='type')), "Case 1Failed"
    
    


# Generated at 2022-06-26 10:15:24.484047
# Unit test for constructor of class Const
def test_Const():
    object_0 = Const()
    object_1 = Const(const=None)


# Generated at 2022-06-26 10:15:29.430734
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object()
    with pytest.raises(ValidationError) as e:
        Union([object_0, object_0]).validate(None)
    assert 'Did not match any valid type.' in str(e.value)

# Generated at 2022-06-26 10:15:32.308039
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()
    assert object_0.validate({}) == {}


# Generated at 2022-06-26 10:15:39.600567
# Unit test for method validate of class Number
def test_Number_validate():
    object_0 = Number()               # __init__()
    object_1 = Number()               # __init__()
    object_2 = Number()               # __init__()
    object_3 = Number()               # __init__()
    object_4 = Number()               # __init__()
    object_5 = Number()               # __init__()
    object_6 = Number()               # __init__()
    object_7 = Number()               # __init__()
    object_8 = Number()               # __init__()
    object_9 = Number()               # __init__()
    object_10 = Number()              # __init__()
    object_11 = Number()              # __init__()
    object_12 = Number()              # __init__()
    object_13 = Number()              # __init__()
    object_

# Generated at 2022-06-26 10:15:47.672981
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array(
        items=String(),
        min_items=10,
        max_items=10,
    )

    value = [
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
        "yum",
    ]
    result = array_0.validate(value, strict=True)
    assert result == value


# Generated at 2022-06-26 10:15:51.191820
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object(properties={"a": Integer()})
    object_0.validate({ "a": 1})

test_Object_validate()


# Generated at 2022-06-26 10:16:18.236353
# Unit test for method validate of class Array
def test_Array_validate():
    # Create test object

    object_0 = Array(additional_items=False)

    assert object_0.validate([]) == []
    assert object_0.validate([1, 2, 3]) == [1, 2, 3]
    assert object_0.validate([1, 2, 3]) == [1, 2, 3]
    assert object_0.validate([[1, 2, 3]]) == [[1, 2, 3]]
    assert object_0.validate([[1, 2, 3]]) == [[1, 2, 3]]
    assert object_0.validate([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == [[1, 2, 3], [4, 5, 6], [7, 8, 9]]


# Generated at 2022-06-26 10:16:25.512924
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 0:
    number_0 = Number(allow_null=True)
    string_0 = String(allow_null=True)
    boolean_0 = Boolean(allow_null=True)
    object_0 = Object(properties={'abc': number_0, 'xyz': string_0}, allow_null=True)
    object_0.validate({"abc": 1})
    object_0.validate({"abc": 1, "xyz": "hello"})
    object_0.validate({"abc": 1, "xyz": "hello", "123": True})
    object_0.validate({"abc": 1, "xyz": "hello", "123": False})

if __name__ == "__main__":
    test_case_0()
    test_Object_validate()

# Generated at 2022-06-26 10:16:29.251580
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Field()
    value_1 = object_0.get_default_value()
    assert value_1 is None



# Generated at 2022-06-26 10:16:38.776055
# Unit test for method validate of class Array
def test_Array_validate():
    List = Array()
    assert List.validate([1]) == [1]
    assert List.validate([]) == []
    assert List.validate([1, 2]) == [1, 2]
    assert List.validate(None, strict=True) == None
    # test nullable
    assert List.validate(None, strict=False) == []
    # test min_items
    List = Array(min_items=1)
    with pytest.raises(ValidationError) as exc_info:
        List.validate([])
    assert exc_info.value.messages[0].code == 'empty'
    List = Array(min_items=5)
    with pytest.raises(ValidationError) as exc_info:
        List.validate([1, 2, 3, 4])
    assert exc

# Generated at 2022-06-26 10:16:41.581377
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    obj = Field()
    obj.get_default_value()


# Generated at 2022-06-26 10:16:51.838310
# Unit test for method validate of class Object
def test_Object_validate():
    t_Field = Field()
    t_Field.allow_null = False
    t_Field.default = None
    t_Field.validation_error = None
    t_Field.get_error_text = None
    t_Field.allow_coerce = False
    properties = {"object_0":t_Field}
    pattern_properties = None
    additional_properties = True
    property_names = None
    min_properties = None
    max_properties = None
    required = None
    object_0 = Object(properties=properties,pattern_properties=pattern_properties,
        additional_properties=additional_properties, property_names=property_names,
        min_properties=min_properties,max_properties=max_properties,required=required
    )
    test_val = {"object_0" : True}

# Generated at 2022-06-26 10:16:54.510048
# Unit test for method validate of class Number
def test_Number_validate():
    test_obj = Number(minimum=100)
    assert test_obj.validate(None) == None
    assert test_obj.validate(False) == Invalid
    assert test_obj.validate(100) == Valid
    assert test_obj.validate(-100) == Invalid
    assert test_obj.validate(100.1) == Invalid


# Generated at 2022-06-26 10:16:59.521715
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices=["foo", "bar"])
    value = obj.validate("foo")
    assert value == "foo"


# Generated at 2022-06-26 10:17:04.062234
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()
    case_0_input = {}
    case_0_output = {}
    object_0.validate(case_0_input)



# Generated at 2022-06-26 10:17:05.756852
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Choice()
    print(object_0.validate(None))


# Generated at 2022-06-26 10:17:26.998258
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object()
    object_0.properties = {}
    object_0.required = []
    object_0.additional_properties = False

    object_1 = Object()
    object_1.properties = {}
    object_1.required = []
    object_1.additional_properties = False

    union_0 = Union(any_of=[object_0, object_1])
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_0.validate({})
    union_

# Generated at 2022-06-26 10:17:30.343798
# Unit test for method validate of class Number
def test_Number_validate():
    i = 1
    object_0 = Number()
    value_0 = object_0.validate(i)
    assert value_0 == i


# Generated at 2022-06-26 10:17:43.234951
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array()
    value = 5
    try:
        array.validate(value)
    except ValidationError as exception:
        assert exception.text == "Must be an array."
        assert exception.code == "type"

    value = []
    array.min_items = 1
    try:
        array.validate(value)
    except ValidationError as exception:
        assert exception.text == "Must not be empty."
        assert exception.code == "empty"

    array.min_items = 0
    try:
        array.validate(value)
    except Exception as exception:
        assert False

    array.unique_items = True
    value = [1, 1]

# Generated at 2022-06-26 10:17:53.554534
# Unit test for method serialize of class Array
def test_Array_serialize():
    schema_json = {
        "type": "array",
        "items": {"type": "string", "format": "uri"}
    }
    schema = Schema(schema_json)
    ret_ser = schema.serialize(["string", "string2"])
    ret_des = schema.deserialize(["string", "string2"])
    assert ret_ser == ["string", "string2"]
    assert ret_des == ["string", "string2"]


# Generated at 2022-06-26 10:17:57.139664
# Unit test for method serialize of class Array
def test_Array_serialize():
    object_0 = Array()
    object_0.serialize([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-26 10:18:01.353639
# Unit test for method validate of class Choice
def test_Choice_validate():
    # This test should pass.
    string_0 = String(choice = ("1", "2", "3"), null = True)
    assert string_0.validate("3") == "3"


# Generated at 2022-06-26 10:18:03.116557
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assertField.get_default_value() == None

# Generated at 2022-06-26 10:18:10.212218
# Unit test for method validate of class Object
def test_Object_validate():
    assert Object(properties={'a': Integer()}).validate({'a': 1}), {'a': 1}
    assert Object(properties={'a': Integer()}).validate({'a': '1'}), {'a': 1}


# Generated at 2022-06-26 10:18:13.880733
# Unit test for constructor of class Array
def test_Array():
    # arrange
    items = list(range(1, 5))

    # act
    testArray = Array(items)

    # assert
    assert testArray is not None
    assert testArray.items == items

# Generated at 2022-06-26 10:18:25.007388
# Unit test for method validate of class Number
def test_Number_validate():
    object_0 = Number()
    object_0.validate(1)
    object_0.validate(-5.5)
    object_0.validate(1, strict=True)
    object_0.validate(-5.5, strict=True)
    object_0.validate('abcdefg')
    object_0.validate('abcdefg', strict=True)


# Generated at 2022-06-26 10:19:03.222212
# Unit test for method validate of class Array
def test_Array_validate():

    array_0 = Array(items=Array(),min_items=0,max_items=2,unique_items=True)
    result_0 = array_0.validate(value=[[[""],[]]],strict=True)
    assert result_0 == [[[""],[]]]

    array_1 = Array(items=Array(),min_items=0,max_items=2,unique_items=True)
    result_1 = array_1.validate(value=[[[],[]]],strict=False)
    assert result_1 == [[[],[]]]

    array_2 = Array(items=Object(),min_items=0,max_items=2,unique_items=True)
    result_2 = array_2.validate(value=[{"":None},{"":""}],strict=True)

# Generated at 2022-06-26 10:19:10.937632
# Unit test for method validate of class Union
def test_Union_validate():
    # Prepare input
    any_of = []
    value = None
    strict = False
    object_0 = Union(any_of,allow_null=True)

    # Perform the test
    with pytest.raises(ValidationError):
        object_0.validate(value, strict=strict)


# Generated at 2022-06-26 10:19:12.930016
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Choice()
    object_0.validate(None)
    #assert False # TODO: implement your test here



# Generated at 2022-06-26 10:19:26.532029
# Unit test for method validate of class Object
def test_Object_validate():
    properties_0 = {
        'name': String(required=True),
        'number': Integer,
        'active': Boolean,
        'rating': Float(precision=0.01),
    }
    object_0 = Object(properties=properties_0)
    assert object_0.validate({
        'name': 'Brian',
        'number': 15,
        'active': True,
        'rating': 4.2 
    }) == {
        'name': 'Brian',
        'number': 15,
        'active': True,
        'rating': 4.2
    }

# Generated at 2022-06-26 10:19:27.847416
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=['a', 'b', 'c'])

    assert choice is not None


# Generated at 2022-06-26 10:19:33.511542
# Unit test for constructor of class Array
def test_Array():
    items = Field()
    additional_items = Field()
    min_items = 0
    max_items = 10
    exact_items = 10
    unique_items = False
    test_array = Array(items, additional_items, min_items, max_items, exact_items, unique_items)
    assert test_array.items == items
    assert test_array.additional_items == additional_items
    assert test_array.min_items == min_items
    assert test_array.max_items == max_items
    assert test_array.unique_items == unique_items


# Generated at 2022-06-26 10:19:47.623842
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Object(description="", title="")
    # Test for the default value of the attribute field_name
    if object_0.title != "":
        raise Exception("The default value of the attribute field_name is not correct.")
    # Test for the default value of the attribute field_name
    if object_0.description != "":
        raise Exception("The default value of the attribute field_name is not correct.")
    # Test for the default value of the attribute field_name
    if object_0.fields != {}:
        raise Exception("The default value of the attribute field_name is not correct.")
    # Test for the default value of the attribute field_name
    if object_0.properties != {'description', 'title', 'fields'}:
        raise Exception(
            "The default value of the attribute field_name is not correct.")

