

# Generated at 2022-06-26 10:10:58.971002
# Unit test for method validate of class Union
def test_Union_validate():
    case_0_number = Number()
    case_0_number_0 = Number()
    case_0 = Union(any_of=[case_0_number, case_0_number_0])
    case_0_validated = case_0.validate(1.0)
    return (case_0_validated)


# Generated at 2022-06-26 10:11:00.752141
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Set up test case
    choice = Choice(choices=[(1, 1), (2, 2)])
    expected = 1

    # Run method to be tested
    result = choice.validate(expected)
    assert result == expected

if __name__ == "__main__":
    test_Choice_validate()

# Generated at 2022-06-26 10:11:04.631994
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    number_1 = Number()
    result = number_1.validate_or_error(10)


# Generated at 2022-06-26 10:11:14.708324
# Unit test for constructor of class Array
def test_Array():
    test_items1 = Number()
    test_items2 = Number()
    test_items = [test_items1,test_items2]
    test_additional_items = String()
    test_min_items = 1
    test_max_items = 2
    test_unique_items = True
    test_kwargs = {'label': 'test_label'}
    test_objs = Array(items=test_items, additional_items=test_additional_items, min_items=test_min_items, max_items=test_max_items,unique_items=test_unique_items, **test_kwargs)
    assert test_objs.items == test_items
    assert test_objs.additional_items == test_additional_items
    assert test_objs.min_items == test_min_

# Generated at 2022-06-26 10:11:21.544127
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array(items=[Number(), Number()])
    str_0 = "abc"
    #str_1 = "abc"
    int_0 = 2
    list_0 = [str_0, int_0]
    #list_1 = [str_1, int_0]
    tuple_0 = (str_0, int_0)
    #tuple_1 = (str_1, int_0)
    dict_0 = {str_0: int_0}
    #dict_1 = {str_1: int_0}
    #object_0 = Object(required=["first", "last"], properties={str_0: String(required=True), str_1: String()}, additional_properties=False)

    array_0.validate(list_0)

    #assert list_0 == list_

# Generated at 2022-06-26 10:11:25.625776
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = ["1","2","3"]
    choice_0 = Choice(choices = choices)
    print(choice_0.validate("1"))


# Generated at 2022-06-26 10:11:28.810187
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    number_0 = Number()
    try:
        number_0.validate_or_error(float(0))
    except ValueError as e:
        print(e)


# Generated at 2022-06-26 10:11:29.958800
# Unit test for method validate of class Choice
def test_Choice_validate():
    number_0 = Number()


# Generated at 2022-06-26 10:11:34.858210
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    number_0 = Number()
    assert number_0.validate_or_error(1) == ValidationResult(value=1, error=None)


# Generated at 2022-06-26 10:11:43.830457
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_0.allow_null = True
    array_0.items = None
    array_0.additional_items = False
    array_0.min_items = None
    array_0.max_items = None
    array_0.unique_items = False
    array_0.default = None
    array_0.description = None
    array_0.title = None

    # Test case 0
    value_0 = None
    strict_0 = False
    expect_0 = None
    actual_0 = array_0.validate(value_0, strict=strict_0)
    assert expect_0 == actual_0

    # Test case 1
    value_1 = "abcd"
    strict_1 = False
    expect_1 = None

# Generated at 2022-06-26 10:12:18.914594
# Unit test for method validate of class Object
def test_Object_validate():
    number_0 = Number()
    obj = Object(properties={'name':Field(), 'age':number_0, 'sex':Field(), 'education':Field()})
    # Test 1
    obj.validate({'name':'Jhon', 'age':18, 'sex':'male', 'education':'not finish high school'})
    # Test 2
    obj.validate({'name':'Jhon', 'age':'18'}) # should get an error
    # test 3
    obj.validate({'name':'Jhon', 'age':'18', 'sex':'male', 'education':'not finish high school'}) # should get an error
    # test 4
    obj.validate({'name':'Jhon', 'age':'20', 'sex':'male', 'education':'not finish high school'}) # should get

# Generated at 2022-06-26 10:12:20.664850
# Unit test for method validate of class String
def test_String_validate():
    test_str = "Hello World!"
    string_0 = String()
    assert test_str == string_0.validate(test_str)



# Generated at 2022-06-26 10:12:30.805113
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()

    # Test with value = []
    value = []
    expected = value
    actual = obj.validate(value)
    assert expected == actual, 'Wrong output for value = {}'.format(value)
    print('Passed test for value = {}'.format(value))

    # Test with value = ['a', 2, 3.0]
    value = ['a', 2, 3.0]
    expected = value
    actual = obj.validate(value)
    assert expected == actual, 'Wrong output for value = {}'.format(value)
    print('Passed test for value = {}'.format(value))

    # Test with value = ['a', 2, 3.0]
    value = ['a', 2, 3.0]
    expected = value
    actual = obj.validate(value)

# Generated at 2022-06-26 10:12:39.978236
# Unit test for method validate of class Array
def test_Array_validate():
    a1 = Array()
    test_a1_validate_result = a1.validate([])
    test_a1_validate_result_is_instance = isinstance(test_a1_validate_result, list)

    additional_items_0 = False
    a2 = Array(
        additional_items=additional_items_0
    )
    test_a2_validate_result = a2.validate([])
    test_a2_validate_result_is_instance = isinstance(test_a2_validate_result, list)

    additional_items_1 = True
    a3 = Array(
        additional_items=additional_items_1
    )
    test_a3_validate_result = a3.validate([])
    test_a3_validate_result_

# Generated at 2022-06-26 10:12:47.404840
# Unit test for method validate of class Array
def test_Array_validate():
    number_0 = Number()
    array_0 = Array(min_items=1, max_items=1, items=number_0)
    array_0.validate(value=[3.14])
    try:
        array_0.validate(value=[])
        assert False
    except ValidationError:
        pass
    try:
        array_0.validate(value=[3.14, 3.14])
        assert False
    except ValidationError:
        pass
    try:
        array_0.validate(value=[''])
        assert False
    except ValidationError:
        pass
    try:
        array_0.validate(value=[None])
        assert False
    except ValidationError:
        pass

test_Array_validate()

# Generated at 2022-06-26 10:12:53.377544
# Unit test for method serialize of class String
def test_String_serialize():
    if String().serialize("Hello") == "Hello":
        print("Function serialize of class String executed succesfully")
    else:
        print("Failed to execute Function serialize of class String")


# Generated at 2022-06-26 10:12:56.582587
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    str_1 = String()
    str_2 = String()
    union = number_0 | str_1 | str_2


# Generated at 2022-06-26 10:13:03.846954
# Unit test for method validate of class Object
def test_Object_validate():
    number_2 = Number()
    test_dict_0 = {"key_0": number_2}
    properties_0 = Field()
    test_dict_1 = {}
    pattern_properties_0 = Field()
    test_dict_2 = {}
    additional_properties_0 = True
    property_names_0 = Field()
    min_properties_0 = 0
    max_properties_0 = 0
    required_0 = []
    test_dict_3: typing.Dict[str, Field] = {}
    test_dict_4 = {"key_1": number_2}
    properties_1 = Field()
    test_dict_5 = {}
    pattern_properties_1 = Field()
    test_dict_6 = {}
    additional_properties_1 = True
    property_names_1 = Field()
    min_

# Generated at 2022-06-26 10:13:08.955580
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number()
    string_0 = String()
    Union_0 = number_0 | string_0
    assert isinstance(Union_0, Union) == True
    assert Union_0.any_of == [number_0, string_0]



# Generated at 2022-06-26 10:13:19.133085
# Unit test for method validate of class Union
def test_Union_validate():
    number_0 = Number()
    number_1 = Number()
    number_2 = Number()
    union_0 = Union([number_0, number_1, number_2])
    union_0.allow_null = True
    union_0.errors = {"null": "May not be null.", "union": "Did not match any valid type."}
    try:
        union_0.validate(None)
        assert False
    except ValidationError as e:
        assert e.messages[0].text == "May not be null."

test_Union_validate()

# Generated at 2022-06-26 10:13:56.154311
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Unit test for when value is None
    boolean = Boolean()
    assert boolean.validate(None) == None

    # Unit test for allow_null is True
    boolean = Boolean(allow_null=True)
    assert boolean.validate(None) == None
    assert boolean.validate("null") == None
    boolean.allow_null = False
    try:
        boolean.validate(None)
        assert False
    except ValidationError:
        assert True

    # Unit test for strict is True
    try:
        boolean.validate("1")
        assert False
    except ValidationError:
        assert True

    # Unit test for value is True
    assert boolean.validate(True) == True

    # Unit test for value is False
    assert boolean.validate(False) == False

    # Unit test for value is 1

# Generated at 2022-06-26 10:14:00.761164
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="time").serialize(None) == None
    assert String(format="time").serialize("") == ""

Const = typing.Literal["one", "two"]

# Generated at 2022-06-26 10:14:05.193571
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    try:
        test_case_0()
    except Exception as e:
        assert type(e) == ValidationError


# Generated at 2022-06-26 10:14:14.940969
# Unit test for method validate of class Choice
def test_Choice_validate():
    # case 0
    field_0 = Choice()
    result_0 = field_0.validate_or_error('a')
    if result_0.error.text != 'Not a valid choice.':
        print('Failed')
    else:
        print('Passed')

    # case 1
    field_1 = Choice(choices=[('a', 'b')])
    result_1 = field_1.validate_or_error('a')
    if result_1.value != 'a':
        print('Failed')
    else:
        print('Passed')

    # case 2
    field_2 = Choice(choices=[('a', 'b')], allow_null=True)
    result_2 = field_2.validate_or_error('')

# Generated at 2022-06-26 10:14:18.550966
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_instance = Field(default=1)
    result = field_instance.get_default_value()
    assert type(result) == int



# Generated at 2022-06-26 10:14:27.457363
# Unit test for method validate of class Array
def test_Array_validate():
    integer_0 = Integer()
    array_0 = Array(items=integer_0)
    integer_1 = Integer()
    array_1 = Array(items=integer_1, unique_items=True)
    integer_2 = Integer()
    array_2 = Array(items=integer_2, unique_items=True)
    integer_3 = Integer()
    array_3 = Array(items=integer_3, unique_items=True)
    boolean_0 = Boolean()
    array_4 = Array(items=boolean_0, unique_items=True)
    boolean_1 = Boolean()
    array_5 = Array(items=boolean_1, unique_items=True)
    boolean_2 = Boolean()
    array_6 = Array(items=boolean_2, unique_items=True)
    boolean_3 = Boolean

# Generated at 2022-06-26 10:14:29.251563
# Unit test for constructor of class Const
def test_Const():
    const = Const(0)
    assert const.validate(0) == 0
    try:
        assert const.validate(1) == 1
    except:
        pass


# Generated at 2022-06-26 10:14:40.520925
# Unit test for method validate of class Number
def test_Number_validate():
    number_1 = Number()
    assert number_1.validate(2) == 2
    assert number_1.validate("2") == 2
    assert number_1.validate("2.0") == 2.0
    number_2 = Number(minimum=3)
    assert number_2.validate(3) == 3
    assert number_2.validate("3.0") == 3.0
    try:
        number_2.validate(2)
    except ValidationError as e:
        assert e.code == "minimum"
        assert e.text == "Must be greater than or equal to 3."
    assert number_2.validate("2.0000000000000001") == 2.0000000000000001
    assert number_2.validate("2.000000000000000001") == 2.000000000000000001
    assert number_2.validate

# Generated at 2022-06-26 10:14:48.197799
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("1", "1111")], allow_null=True)
    assert field.validate("1") == "1"
    assert field.validate("2") == "2"
    assert field.validate("3") == "3"
    assert field.validate("4") == "4"
    assert field.validate("5") == "5"
    assert field.validate("6") == "6"
    assert field.validate("7") == "7"
    assert field.validate("8") == "8"
    assert field.validate("9") == "9"
    assert field.validate("0") == "0"


# Generated at 2022-06-26 10:14:56.082231
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number()
    try:
        number_0.validate(None)
        raise AssertionError("Failed to raise <class 'typesystem.fields.ValidationError'>")
    except ValidationError as e:
        if e.code != "null":
            raise AssertionError("Wrong validation error for null")
        if e.text != 'May not be null.':
            raise AssertionError("Wrong validation text error")
    try:
        number_0.validate(1)
    except ValidationError :
        raise AssertionError("Failed to raise <class 'typesystem.fields.ValidationError'>")

# Generated at 2022-06-26 10:15:19.500530
# Unit test for method validate of class String
def test_String_validate():

    s = String()
    isinstance(s, String)
    assert s.validate("Hello") == "Hello"
    assert s.validate("Hel lo") == "Hel lo"
    assert s.validate("") is None
    assert s.validate("Hel\0lo") == "Hel"
    assert s.validate("Hel\0lo") == "Hel"
    assert s.validate("123456789") == "123456789"
    assert s.validate("0") == "0"

    s = String(allow_blank=True)
    isinstance(s, String)
    assert s.validate("") == ""
    assert s.validate("Hel lo") == "Hel lo"
    assert s.validate("Hel\0lo") == "Hel"

# Generated at 2022-06-26 10:15:24.262363
# Unit test for method validate of class Union
def test_Union_validate():
    test = Union([Number(), String()])
    assert test.validate(4) == 4
    assert test.validate('4') == '4'
    try:
        test.validate(None)
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].code == 'null'


# Generated at 2022-06-26 10:15:36.948084
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        'my_name': Text(),
        'my_age': Number(minimum=0),
        'my_state': Choice(choices=[('AL', 'Alabama'), ('TX', 'Texas')]),
        'my_bio': Text(max_length=50),
        'my_shoe_size': Number(minimum=0, maximum=20),
        'my_favorite_numbers': Array(items=Number(minimum=0, maximum=100), min_items=0)
    }
    obj = Object(properties=properties)

# Generated at 2022-06-26 10:15:40.608683
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    isinstance(number_0.get_default_value(), (int, float))


# Generated at 2022-06-26 10:15:44.068539
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Constructor returns an instance of Field
    number_0 = Number()
    assert isinstance(number_0, Field)
    assert hasattr(number_0, "default"), "Expected attribute default to be defined"
    # Calling method get_default_value using positional arguments on instance number_0
    assert number_0.get_default_value() is None
    # Calling method get_default_value using keyword arguments on instance number_0
    assert number_0.get_default_value() is None



# Generated at 2022-06-26 10:15:51.055132
# Unit test for method validate of class Object
def test_Object_validate():
    field_0 = Number()
    field_1 = Number()
    field_2 = Number()
    object_validate = {
        "properties": {
            "data_0": field_0,
            "data_1": field_1,
            "data_2": field_2
        }
    }
    object_schema = Object(**object_validate)
    data_0 = 1
    data_1 = 2
    data_2 = 3
    result = object_schema.validate({
        "data_0": data_0,
        "data_1": data_1,
        "data_2": data_2
    })
    assert data_0 == result["data_0"]
    assert data_1 == result["data_1"]
    assert data_2 == result["data_2"]

# Generated at 2022-06-26 10:16:00.576895
# Unit test for method validate of class String
def test_String_validate():
    test_str_0 = 'a test string'
    test_str_1 = ''
    test_str_2 = 'a'
    test_str_3 = 'abc'
    test_str_4 = 'abc+++'
    test_str_5 = 'abc+++abc'
    test_str_6 = 'abc+++abc---'
    test_str_7 = 'abc+++abc---abc'
    test_str_8 = 'abc+++abc---abc+++'
    test_str_9 = 'abc+++abc---abc+++abc'
    test_str_10 = 'abc+++abc---abc+++abc---'
    test_str_11 = 'abc+++abc---abc+++abc---abc'
    test_str_12 = 'abc+++abc---abc+++abc---abc+++'

# Generated at 2022-06-26 10:16:03.894824
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number(default=123)
    assert number_0.get_default_value() == 123


# Generated at 2022-06-26 10:16:09.537472
# Unit test for method __or__ of class Field
def test_Field___or__():
    '''
    Ensure that the method __or__ works correctly
    '''
    assert number_0.__or__
    assert number_0.__or__()
    assert not isinstance(number_0, Union)


# Generated at 2022-06-26 10:16:15.022639
# Unit test for method validate of class Union
def test_Union_validate():
    number_1 = Number()
    string_2 = String()
    union_3 = Union(any_of=[number_1, string_2])

if __name__ == "__main__":
    test_Union_validate()

# Generated at 2022-06-26 10:16:40.852519
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    assert number_0.get_default_value() == None
    number_0 = Number(description='positive integer')
    assert number_0.get_default_value() == None
    number_0 = Number(title='Number')
    assert number_0.get_default_value() == None
    number_0 = Number(title='Number', description='positive integer')
    assert number_0.get_default_value() == None
    number_0 = Number(default=1)
    assert number_0.get_default_value() == 1
    number_0 = Number(default=1, description='positive integer')
    assert number_0.get_default_value() == 1
    number_0 = Number(default=1, title='Number')
    assert number_0.get_default_value() == 1

# Generated at 2022-06-26 10:16:47.714635
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=[])
    try:
        choice_0.validate('string_0')
    except ValidationError:
        pass
    else:
        raise Exception('Should raise ValidationError')
    
    choice_1 = Choice(choices=[])
    choice_1.allow_null = True
    try:
        choice_1.validate(None)
    except ValidationError:
        pass
    else:
        raise Exception('Should raise ValidationError')
    
    choice_2 = Choice(choices=[])
    choice_2.allow_null = True
    try:
        choice_2.validate('')
    except ValidationError:
        pass
    else:
        raise Exception('Should raise ValidationError')
    
    choice_3 = Choice(choices=[])
   

# Generated at 2022-06-26 10:16:50.000143
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    try:
        number_0.get_default_value()
    except AttributeError:
        pass
    else:
        raise AssertionError()

    

# Generated at 2022-06-26 10:17:00.572126
# Unit test for method validate of class Choice
def test_Choice_validate():
    float_0 = Float()
    float_1 = float_0.validate(1)
    choice_0 = Choice(choices=[(float_1, "choice1"), (2, "choice2"), (3, "choice3")])
    choice_1 = choice_0.validate(1)
    choice_2 = Choice(choices=[(1, "choice1"), (2, "choice2"), (3, "choice3")])
    choice_3 = choice_2.validate(1)
    choice_2 = Choice(choices=[(1, "choice1"), (2, "choice2"), (3, "choice3")])
    choice_4 = choice_2.validate('1')

# Generated at 2022-06-26 10:17:01.740233
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    number_0.default = 3
    assert number_0.get_default_value() == 3


# Generated at 2022-06-26 10:17:10.474320
# Unit test for method validate of class Array
def test_Array_validate():
    number_0 = Number()
    class TestArray(Array):
        def __init__(self):
            super().__init__(items=number_0)

    t_array = TestArray()
    t_array.validate([1,2,3])

    class TestArray2(Array):
        def __init__(self):
            super().__init__(items=[number_0, number_0])

    t_array2 = TestArray2()
    t_array2.validate([1,2])
    

# Generated at 2022-06-26 10:17:17.987866
# Unit test for method validate of class Choice
def test_Choice_validate():
    number_0 = Number()
    string_0 = String()
    choice_0 = Choice()
    choice_0.choices = [(number_0, string_0), (number_0, string_0), (number_0, string_0)]
    choice_0.validate(number_0)


# Generated at 2022-06-26 10:17:22.283049
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean = Boolean()
    string_0 = "a string"
    exception = None
    try:
        boolean.validate(string_0)
    except Exception as err:
        exception = err
    assert type(exception) == ValidationError


# Generated at 2022-06-26 10:17:33.479554
# Unit test for method validate of class Union
def test_Union_validate():
    # test case 0
    number = Number()
    string = String()
    array = [number, string]
    fruit = Union(array)
    expected_errors = {
        "null": "May not be null.",
        "union": "Did not match any valid type."
    }
    actual_errors = fruit.errors
    assert actual_errors == expected_errors, f"expected: {expected_errors}, actual: {actual_errors}"
    expected_validated = 3.14
    actual_validated = fruit.validate(3.14, strict=True)
    assert actual_validated == expected_validated, f"expected: {expected_validated}, actual: {actual_validated}"



# Generated at 2022-06-26 10:17:38.209839
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    assert number_0.has_default() == False
    number_1 = Number(default = 0)
    assert number_1.get_default_value() == 0


# Generated at 2022-06-26 10:17:49.948762
# Unit test for constructor of class Const
def test_Const():
    schema = Const(5)
    assert isinstance(schema, Const)
    assert schema.const == 5
    assert schema.allow_null
    assert schema.allow_unknown

# Unit tests for constructor of class Number

# Generated at 2022-06-26 10:17:52.411004
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["key_0", "key_1"]).validate(value="key_2")
    assert Choice(choices=["key_0", "key_1"]).validate(value="key_1")


# Generated at 2022-06-26 10:17:53.888422
# Unit test for method validate of class Object
def test_Object_validate():
    pass


# Generated at 2022-06-26 10:17:55.910884
# Unit test for constructor of class Const
def test_Const():
    c = Const(const = None, allow_null = True)


# Generated at 2022-06-26 10:18:07.718880
# Unit test for method validate of class Array
def test_Array_validate():
    # Arrange
    arrayTest = Array()
    arrayTestItems = [Number(), Number()]

    # Act
    arrayTest.validate([1, 2])
    arrayTest.validate([1, 2.5])
    arrayTest.validate([1.5, 2.5])
    arrayTest.validate(None)

    # Assert
    assert True

    # Arrange
    arrayTest = Array()
    arrayTestItems = [Number(), Number()]

    # Act
    arrayTest.validate([1, 2, 3])
    arrayTest.validate([1, None])
    arrayTest.validate([None, 1])
    arrayTest.validate([None, None])
    arrayTest.validate(1)

    # Assert
    assert False


# Generated at 2022-06-26 10:18:20.295737
# Unit test for method validate of class Object
def test_Object_validate():

    field = Object(
        properties = {
            "name": String(),
            "age" : Integer()
        },
        required = ["name", "age"]
    )

    # value is not an object
    try:
        field.validate(value = 2)
        assert False, "Should raise exception"
    except ValidationError as exc:
        assert exc.code == "type"
        assert exc.get_message() == "Must be an object."
        assert exc.index == []

    # value is null
    assert field.validate(value = None) == None

    # value is empty
    try:
        field.validate(value = {})
        assert False, "Should raise exception"
    except ValidationError as exc:
        assert exc.code == "empty"

# Generated at 2022-06-26 10:18:29.722505
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_0.validate(array_0.items)

    array_1 = Array(items=[])
    array_1.validate(array_1.items)

    array_2 = Array(items=1)
    array_2.validate(array_2.items)

    array_3 = Array(items="2")
    array_3.validate(array_3.items)

    array_4 = Array(items=Number())
    array_4.validate(array_4.items)
    array_4.validate(array_4.items[0])

    array_5 = Array(items=[String(), Number()])
    array_5.validate(array_5.items)
    array_5.validate(array_5.items[0])

# Generated at 2022-06-26 10:18:36.874466
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    number_0 = Number()
    expected_0 = None
    actual_0 = number_0.get_default_value()
    print("Test 0 returned: {0}".format(expected_0 == actual_0))
    assert expected_0 == actual_0
    print("\n")


# Generated at 2022-06-26 10:18:37.983307
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice()



# Generated at 2022-06-26 10:18:51.118403
# Unit test for method validate of class Number
def test_Number_validate():
    def test_Number_validate_number_0():
        """Test if the method validate of class Number throws exception when the argument is an integer"""
        field = Number()
        with pytest.raises(ValidationError) as excinfo:
            field.validate(123)
        assert "Must be a number" == str(excinfo.value)

    def test_Number_validate_number_1():
        """Test if the method validate of class Number throws exception when the argument is a float"""
        field = Number()
        with pytest.raises(ValidationError) as excinfo:
            field.validate(123.4)
        assert "Must be a number" == str(excinfo.value)


# Generated at 2022-06-26 10:19:07.494345
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array(items=Number(), unique_items=False, allow_null=False, default=None)
    assert a.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert a.validate([1, 2, 3]) == [1, 2, 3]
    assert a.validate([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5, 6]
    try:
        a.validate([1])
        assert False
    except ValidationError:
        assert True
    assert a.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]


# Generated at 2022-06-26 10:19:12.473362
# Unit test for method __or__ of class Field
def test_Field___or__():
    number_0 = Number(maximum=5)
    number_1 = Number(minimum=5)
    union_0 = number_0 | number_1
    assert union_0.any_of[0] == number_0
    assert union_0.any_of[1] == number_1


# Generated at 2022-06-26 10:19:22.465283
# Unit test for constructor of class Array
def test_Array():
    items = Field()
    additional_items = True
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    array1 = Array(items=items, additional_items=additional_items, min_items=min_items,
                   max_items=max_items, exact_items=exact_items, unique_items=unique_items)



# Generated at 2022-06-26 10:19:29.771535
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0.validate(None)
    choice_0

# Generated at 2022-06-26 10:19:33.184527
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    # Test case 0
    assert choice_0.validate(None) == None

    assert choice_0.validate({}) != None



# Generated at 2022-06-26 10:19:47.537464
# Unit test for method validate of class Choice
def test_Choice_validate():
    valid = Choice()
    assert valid.validate(1,strict=False)==None
    assert valid.validate(2,strict=False)==None
    assert valid.validate(3,strict=False)==None
    assert valid.validate(4,strict=False)==None
    assert valid.validate(5,strict=False)==None
    assert valid.validate(6,strict=False)==None
    assert valid.validate(7,strict=False)==None
    assert valid.validate(8,strict=False)==None
    assert valid.validate(9,strict=False)==None
    assert valid.validate(10,strict=False)==None
    assert valid.validate(11,strict=False)==None
    assert valid.validate