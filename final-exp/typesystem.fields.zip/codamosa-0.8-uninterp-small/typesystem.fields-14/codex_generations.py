

# Generated at 2022-06-26 10:11:05.467408
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Union(AnyOf=[])
    value = None
    strict = False
    # value type: <class 'NoneType'>
    # value: None
    try:
        field_0.validate(value, strict=strict)
    except ValidationError as exc:
        assert exc.messages[0].code == "null"
        assert exc.messages[0].text == "May not be null."
        assert exc.messages[0].field == "root"
    else:
        assert False


# Generated at 2022-06-26 10:11:11.631330
# Unit test for constructor of class Array
def test_Array():
    field_0 = Array(
        items=
        [
            Field(
                allow_null=True,
                description="A number",
                title="Number",
                type="number",
                example=0.4),
            Field(
                allow_null=True,
                default=None,
                description="A string",
                title="String",
                type="string",
                example="test")
        ],
        allow_null=True,
        default=None,
        description="An array of things",
        min_items=2,
        title="Array",
        type="array",
        example=[0.4, "test"])


# Generated at 2022-06-26 10:11:18.296883
# Unit test for method serialize of class Array
def test_Array_serialize():
    t1 = IntegerField()
    t2 = StringField()
    t3 = IntegerField()
    t4 = StringField()
    items = [t1, t2, t3, t4]
    
    arr = Array(items=items)
    input = [2, 3, 4, 5]
    result = arr.serialize(input)
    assert result == input, "Array.serialize() returns wrong result"


# Generated at 2022-06-26 10:11:23.525986
# Unit test for method validate of class Choice
def test_Choice_validate():
    field_0 = Choice()

    field_0.validate(None, strict=False)
    field_0.validate(None, strict=True)

# Unit test of method get_error_text

# Generated at 2022-06-26 10:11:32.981552
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test case for null input
    field_1 = Choice(allow_null=True)
    try:
        field_1.validate(None)
    except ValidationError:
        print("Null input is valid")
    else:
        print("Null input is invalid")

    # Test case for required input with null value
    field_2 = Choice(allow_null=False)
    try:
        field_2.validate(None)
    except ValidationError:
        print("Required null input is invalid")
    else:
        print("Required null input is valid")

    # Test case for valid string
    field_3 = Choice(allow_null=True, choices=["a", "b", "c"])

# Generated at 2022-06-26 10:11:37.909153
# Unit test for method validate of class Object
def test_Object_validate():
    with pytest.raises(ValidationError):
        field = Object(properties={
            "a": String()
        })
        value = {"a": "1", "b": 2}
        field.validate(value)



# Generated at 2022-06-26 10:11:43.739505
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    field_1 = Field()

    #__or__
    field_0 = Field()
    field_1 = Field()
    value = True
    field_0 |= field_1

    #__or__
    field_0 = Field()
    field_1 = Field()
    value = True
    field_0 | field_1

    #__or__
    field_0 = Field()
    value = True
    field_0 | Field()

    #__or__
    field_0 = Field()
    value = True
    Field() | field_0



# Generated at 2022-06-26 10:11:47.270074
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field()
    check_0 = field_0.get_default_value()
    check_1 = type(field_0.get_default_value())

    assert not check_0
    assert check_1 == type(None)


# Generated at 2022-06-26 10:11:48.798534
# Unit test for constructor of class Choice
def test_Choice():
    field_0 = Choice()
    assert isinstance(field_0, Choice)


# Generated at 2022-06-26 10:11:53.273230
# Unit test for method validate of class Array
def test_Array_validate():
    test_case_Array_validate_0()
    test_case_Array_validate_1()
    test_case_Array_validate_2()
    test_case_Array_validate_3()
    test_case_Array_validate_4()
    test_case_Array_validate_5()
    test_case_Array_validate_6()


# Generated at 2022-06-26 10:12:37.986640
# Unit test for method validate of class Array
def test_Array_validate():

    # test for case 0
    field_0 = Array()
    field_0.items = Any()
    value_0 = [0.0, '', True, [], {}, (), set()]
    field_0.validate(value_0)

    # test for case 1
    field_1 = Array()
    field_1.items = String()
    value_1 = ['', '', '', '', '', '', '']
    field_1.validate(value_1)

    # test for case 2
    field_2 = Array()
    field_2.items = Integer()
    value_2 = [0, 0, 0, 0, 0, 0, 0]
    field_2.validate(value_2)

    # test for case 3
    field_3 = Array()
    field_3.items

# Generated at 2022-06-26 10:12:50.668003
# Unit test for method validate of class Array
def test_Array_validate():
    field_0 = Array()
    value_0 = field_0.validate([1, 2, 3, 4, 5])
    assert value_0 == [1, 2, 3, 4, 5]

    field_1 = Array(additional_items=False, min_items=3, unique_items=True)
    value_1 = field_1.validate([1, 2, 3, 4, 5])
    assert value_1 == [1, 2, 3, 4, 5]

    field_2 = Array(additional_items=False, min_items=3, unique_items=True)
    try:
        value_2 = field_2.validate([1, 2, 3])
        assert False
    except ValidationError as e:
        text_0 = e.messages()[0].text
        assert text_

# Generated at 2022-06-26 10:12:58.905307
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [(1, '1'), (2, '2'), (3, '3')]
    field = Choice(choices=choices)

    value = 1
    assert field.validate(value) == value
    value = 2
    assert field.validate(value) == value
    value = 3
    assert field.validate(value) == value
    value = 4
    with pytest.raises(ValidationError):
        field.validate(value)
        # expected value to be among: [1, 2, 3]
    value = 'a'
    with pytest.raises(ValidationError):
        field.validate(value)
        # expected value to be among: [1, 2, 3]

    choices = [(1, '1'), (2, '2'), (3, '3')]
    field

# Generated at 2022-06-26 10:13:09.555022
# Unit test for method serialize of class String
def test_String_serialize():
    field_0 = Field(description='', title='')
    field_0 = String(description='', title='', max_length=None, min_length=None, pattern=None, trim_whitespace=True, allow_blank=False, allow_null=False)
    field_0 = Field(description='', title='')
    field_0 = String(description='', title='', max_length=None, min_length=None, pattern=None, trim_whitespace=True, allow_blank=False, allow_null=False)
    field_0.format = None
    field_0.format = 'time'
    field_0.format = 'date'
    field_0.format = 'datetime'
    field_0.format = 'uuid'

# Generated at 2022-06-26 10:13:21.402414
# Unit test for method serialize of class Array
def test_Array_serialize():
    field_0 = Array(items=String(default="The default value 0"), additional_items=True)
    result_0 = field_0.serialize([1, 2, 3])
    assert result_0 == ["The default value 0", "The default value 0", "The default value 0"]

    field_1 = Array(items=String(default="The default value 1"))
    result_1 = field_1.serialize([1, 2, 3])
    assert result_1 == ["The default value 1", "The default value 1", "The default value 1"]

    field_2 = Array(items=String(default="The default value 2"))
    result_2 = field_2.serialize([])
    assert result_2 == []

    field_3 = Array(items=String(default="The default value 3"), additional_items=False)
   

# Generated at 2022-06-26 10:13:26.300804
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=["A", "B"])
    assert c.choices == [("A", "A"), ("B", "B")]
    assert c.allow_null == False
    assert c.allow_blank == False
    assert c.optional == False
    assert c.default == None
    assert c.replace_none == False



# Generated at 2022-06-26 10:13:31.962114
# Unit test for method validate of class Choice
def test_Choice_validate():
    #Test case 1
    field_0 = Choice(allow_null=True)
    value = None
    try:
        field_0.validate(value)
    except ValidationError:
        pass
    else:
        assert False

    #Test case 2
    field_0 = Choice(allow_null=True)
    value = None
    try:
        field_0.validate(value)
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:13:37.697808
# Unit test for method validate of class Choice
def test_Choice_validate():
    string_list = ["1", "2", "3", "4"]
    choice_0 = Choice(choices = string_list)
    result = choice_0.validate("1")
    assert result == "1"
    result = choice_0.validate("")
    assert result is None


# Generated at 2022-06-26 10:13:41.961211
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    field_1 = Field()
    union_0 = field_0 | field_1


# Generated at 2022-06-26 10:13:49.666822
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Int(), Float()]
    value = None
    field = Union(any_of = any_of)
    field.allow_null = True
    expected = None
    actual = field.validate(value)
    assert expected == actual


# Generated at 2022-06-26 10:14:04.752264
# Unit test for method serialize of class String
def test_String_serialize():
    field_0 = String()
    obj = "45"
    result = field_0.serialize(obj)
    print(result)


# Generated at 2022-06-26 10:14:13.888120
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()

    obj.strict = True
    obj.allow_null = True
    value = None
    try:
        result = obj.validate(value)
        assert False
    except ValidationError as e:
        result = e.messages()

    obj.strict = True
    obj.allow_null = False
    value = None
    try:
        result = obj.validate(value)
        assert False
    except ValidationError as e:
        result = e.messages()

    obj.strict = False
    obj.allow_null = True
    value = None
    try:
        result = obj.validate(value)
        assert False
    except ValidationError as e:
        result = e.messages()

    obj.strict = False
    obj.allow_null = False

# Generated at 2022-06-26 10:14:21.637467
# Unit test for method validate of class Choice
def test_Choice_validate():
    field_0 = Choice(choices = ['1', '2'])
    # Test invalid value
    try:
        field_0.validate('3')
    except ValidationError as error:
        assert error.code == 'choice'
    # Test valid value
    assert field_0.validate('1') == '1'



# Generated at 2022-06-26 10:14:27.861391
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    field_1 = Field()
    field_0__or__field_1 = field_0.__or__(field_1)
    assert isinstance(field_0__or__field_1, Union)



# Generated at 2022-06-26 10:14:31.377904
# Unit test for constructor of class Const
def test_Const():
    test_case_0()

if __name__ == "__main__":
    test_Const()

# Generated at 2022-06-26 10:14:35.269877
# Unit test for method serialize of class String
def test_String_serialize():
    field_0 = String(format='date')
    obj = field_0.serialize(obj=datetime.date(2020, 9, 11))
    assert obj == '2020-09-11'


# Generated at 2022-06-26 10:14:41.745905
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object()
    obj.validate('s', strict=True)

if __name__ == '__main__':
    # test case of test_case_0
    test_case_0()
    # test case of test_case_1
    test_Object_validate()

# Generated at 2022-06-26 10:14:43.650264
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert hasattr(Field(), '__or__') and callable(getattr(Field(), '__or__'))

# OLD TESTS

# Generated at 2022-06-26 10:14:47.371614
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Field()
    value_0 = None
    strict_0 = False
    field_1 = Union(any_of=[field_0], allow_null=False)
    try:
        field_1.validate(value_0, strict=strict_0)
    except ValidationError as e:
        assert(str(e) == "May not be null.")


# Generated at 2022-06-26 10:14:53.403993
# Unit test for method validate of class Union
def test_Union_validate():
    data_0 = Union([Field(name="foo"), Field(name="bar")], name="union_0")

if __name__ == "__main__":
    test_case_0()
    test_Union_validate()

# Generated at 2022-06-26 10:15:12.051912
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    print('test_get_default_value')
    a = Field(title='test case 0')
    assert a.get_default_value() == None

    b = Field(default=1)
    assert b.get_default_value() == 1


# Generated at 2022-06-26 10:15:17.298898
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array(max_items=1)
    list_0 = ["foo", "bar"]
    try:
        array_0.validate(list_0)
    except ValidationError as ex:
        error_0 = str(ex.messages[0])
        assert error_0 == "Must have no more than 1 items.", "Test failed"


# Generated at 2022-06-26 10:15:28.644853
# Unit test for method validate of class Array
def test_Array_validate():
    items_0 = Field()
    additional_items_0 = False
    min_items_0 = None
    max_items_0 = None
    unique_items_0 = False
    allow_null_0 = False
    field_0 = Array(items=items_0, additional_items=additional_items_0, min_items=min_items_0, max_items=max_items_0, unique_items=unique_items_0, allow_null=allow_null_0)
    value_0 = "[1, 2, 3, 4, 5, 6, 7, 8, 9]"
    strict_0 = False
    value_1 = field_0.validate(value_0, strict=strict_0)
    assert value_1 == '[1, 2, 3, 4, 5, 6, 7, 8, 9]'

# Generated at 2022-06-26 10:15:30.170514
# Unit test for constructor of class Const
def test_Const():
    field_1 = Const(5)


# Generated at 2022-06-26 10:15:35.339211
# Unit test for method validate of class Array
def test_Array_validate():

    # Test for error
    field_0 = Array(items=Field(required=True))
    try:
        field_0.validate([])
    except ValidationError as error:
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "This field is required."
        assert error.messages()[0].index == []
    else:
        assert False

    # Test for error
    field_0 = Array(items=Field(required=True))
    try:
        field_0.validate(None)
    except ValidationError as error:
        assert error.messages()[0].code == "null"
        assert error.messages()[0].text == "May not be null."
        assert error.messages()[0].index == []

# Generated at 2022-06-26 10:15:44.438969
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(label='%', validators=[], choices=[], allow_null=False, allow_blank=False, default=None)
    try:
        choice_0.validate(value='True', strict=False)
        assert False, "Did not raise ValidationError"
    except ValidationError as e:
        assert str(e) == "Not a valid choice."


# Generated at 2022-06-26 10:15:47.278422
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    temp_Field = Field()
    try:
        temp_Field.default = NO_DEFAULT
        temp_Field.get_default_value()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-26 10:15:55.469059
# Unit test for method validate of class Array
def test_Array_validate():
    field_0 = Field()
    field_1 = Field(default=1)  # type: Field
    field_2 = Field(default=2)  # type: Field
    field_3 = Field(default=3)  # type: Field
    field_4 = Field(default=4)  # type: Field
    field_5 = Field(default=5)  # type: Field
    field_6 = Field(default=6)  # type: Field
    array_field_0 = Array(items=[field_1, field_2, field_3])
    try:
        array_field_0.validate([1, 2, 3])
    except ValidationError as err:
        assert(False)


# Generated at 2022-06-26 10:15:57.662786
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    field_1 = Field()

    field_0.__or__(field_1)


# Generated at 2022-06-26 10:16:01.587284
# Unit test for constructor of class Const
def test_Const():
    text = Const('Hello, world!')
    print(text)
    assert isinstance(text, Const)
    assert 'const' in text.__dict__.keys()



# Generated at 2022-06-26 10:16:17.848723
# Unit test for method validate of class Number
def test_Number_validate():
    min_0_0 = 500
    max_0_0 = 5
    number_0_0 = Number(minimum=min_0_0, maximum=max_0_0)
    value_0_0 = -3
    error_0_0 = ValidationError(text="Must be greater than or equal to 500.", code="minimum")
    result_0_0 = number_0_0.validate_or_error(value_0_0)
    assert result_0_0.error == error_0_0


# Generated at 2022-06-26 10:16:22.942164
# Unit test for method validate of class Array
def test_Array_validate():
    # Args
    input_value = ["a","b","c"]
    input_strict = False

    # Type of field_0 depends on the arguments
    field_0 = Array()

    # This is the output of a method that depends on the input arguments
    expected_output = input_value

    assert field_0.validate(input_value, strict=input_strict) == expected_output



# Generated at 2022-06-26 10:16:26.734158
# Unit test for method validate of class String
def test_String_validate():
    string_1 = String(max_length=10)
    test_value_1 = "HelloWorld"
    expected_1 = "HelloWorld"
    actual_1 = string_1.validate(test_value_1)
    assert actual_1 == expected_1


# Generated at 2022-06-26 10:16:38.122672
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case 0
    # Test case: basic test case with no additional_items no min_items and no max_items
    # Test method: validate
    # Input:
    #   1) value: [0, 1, 2]
    #   2) strict: False
    # Expected result: [0, 1, 2]
    items = Number()
    array = Array(items=items)
    array.validate([0, 1, 2])
    
    #Test case 1
    # Test case: basic test case with no additional_items no min_items and no max_items
    # Test method: validate
    # Input:
    #   1) value: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    #   2) strict: False
    # Expected result: [0

# Generated at 2022-06-26 10:16:50.539776
# Unit test for method validate of class Union
def test_Union_validate():

    #
    # invalid value is a list, which is neither an object nor a string,
    # Union is not of type null.
    #
    field_0 = Union([Field(type="number"), Field(type="null")])

    try:
        field_0.validate([6, 5])
        assert False
    except ValidationError:
        pass

    try:
        field_0.validate(None)
        assert True
    except ValidationError:
        assert False


# Generated at 2022-06-26 10:16:52.068907
# Unit test for constructor of class Choice
def test_Choice():
    choice_field = Choice()


# Generated at 2022-06-26 10:17:01.193696
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [(1, "1"), (2, "2"), (3, "3")]  # choices
    validate_return_2 = Choice(choices=choices).validate(1)  # ["1"]
    assert validate_return_2 == 1
    validate_return_5 = Choice(choices=choices).validate(6)  # ["6"]
    assert validate_return_5 == 1
    validate_return_8 = Choice(choices=choices).validate(3)  # ["3"]
    assert validate_return_8 == 3
    validate_return_14 = Choice(choices=choices).validate(4)  # ["4"]
    assert validate_return_14 == 3
    validate_return_18 = Choice(choices=choices).validate(5)  # ["5"]
    assert validate

# Generated at 2022-06-26 10:17:10.824018
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=[("foo", "bar"), ("john", "doe")])
    try:
        assert c.validate("foo") == "foo"
        assert c.validate("john") == "john"
        assert c.validate("john", strict=True) == "john"
        assert c.validate("bar") == "bar"
        assert c.validate("doe") == "doe"
        assert c.validate("", strict=True) == None
    except AssertionError:
        print("Fail")
    else:
        print("Success")



# Generated at 2022-06-26 10:17:20.309167
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Field()
    field_1 = Field()
    value_0 = field_0.validate(1)
    value_1 = field_1.validate(1)
    value_2 = field_1.validate(1)
    value_3 = field_0.validate(1)
    field_2 = Union([field_0, field_1])
    value_4 = field_2.validate(1)


# Generated at 2022-06-26 10:17:27.722087
# Unit test for method validate of class Array
def test_Array_validate():
    input_0 = [None]
    field_0 = Field()
    field_0 = Array(items=field_0)
    output_0 = field_0.validate(input_0)

    assert isinstance(output_0, list)
    assert isinstance(output_0[0], NoneType)


# Generated at 2022-06-26 10:17:41.221739
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    if 1:
        assert (field_0 | field_0)
    if 1:
        assert (field_0 | field_0)
    if 1:
        assert (field_0 | field_0)
    return 0


# Generated at 2022-06-26 10:17:55.306831
# Unit test for method validate of class Number
def test_Number_validate():
    field_1 = Number(title="field_1", description="")
    field_2 = Number(title="field_2", description="", minimum=1)
    field_3 = Number(title="field_3", description="", allow_null=True)
    field_4 = Number(title="field_4", description="", allow_null=True, maximum=1)
    field_5 = Number(title="field_5", description="", allow_null=True, exclusive_minimum=1)
    field_6 = Number(title="field_6", description="", allow_null=True, exclusive_maximum=1)
    field_7 = Number(title="field_7", description="", allow_null=True, exclusive_minimum=1, exclusive_maximum=1)

# Generated at 2022-06-26 10:18:03.335096
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=["a", "b", "c"])
    print(field.validate("a") == "a")
    print(field.validate("b") == "b")
    print(field.validate("c") == "c")
    for v in [" ", "0", "d", "", None]:
        print(v)
        try:
            field.validate(v)
        except Exception as e:
            print(e.text)

test_Choice_validate()

# Generated at 2022-06-26 10:18:16.194698
# Unit test for method validate of class String
def test_String_validate():
    field_0 = String()

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")

    try:
        field_0.validate("123")
    except Exception:
        print("exception")


# Generated at 2022-06-26 10:18:25.664444
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Union(any_of=[])
    value = None
    try:
        field_0.validate(value)
        assert False
    except ValidationError as e:
        assert isinstance(e, ValidationError)
        assert e.args == (
            "null",
            "Must be an union.",
        )


# Generated at 2022-06-26 10:18:29.812598
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Case 0
    field_0 = Field()
    assert field_0.get_default_value() == None


# Generated at 2022-06-26 10:18:34.576790
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Field()
    object_0 = Union([field_0])
    object_0.validate(None)
    object_0.validate(None)


# Generated at 2022-06-26 10:18:37.367250
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(default = "xyz")
    assert field.get_default_value() == "xyz"


# Generated at 2022-06-26 10:18:44.737231
# Unit test for constructor of class Const
def test_Const():
    field_0 = Const(12)
    field_1 = Const(12, allow_null=True)
    field_2 = Const(12, default=12)
    field_3 = Const(12, description="Some description.")
    field_4 = Const(12, title="Some title.")

# Testing class Const

# Generated at 2022-06-26 10:18:46.025987
# Unit test for method validate of class Choice
def test_Choice_validate():
    field_0 = Choice()
    param_0 = field_0.validate('a')
    assert param_0 == 'a'


# Generated at 2022-06-26 10:19:04.112401
# Unit test for method validate of class Union
def test_Union_validate():
    field_0 = Union(any_of=[])
    field_0.validate(value=1)

# Generated at 2022-06-26 10:19:05.499559
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    try:
        string_0.validate('')
    except:
        print("Failed!")


# Generated at 2022-06-26 10:19:15.449644
# Unit test for method validate of class Union
def test_Union_validate():
    # Case 0
    field_0 = Field()
    field_1 = Array(items=field_0, additional_items=False)
    field_2 = Object(properties={"a": field_0, "b": field_1})
    field_3 = Union(any_of=[field_2])
    value_3 = None
    error = field_3.validate(value_3)
    # Test case assert equal
    expected = ValidationError(messages=[Message(code='null', index=[], text='May not be null.', key=None)])
    assert error == expected

    # Case 1
    field_0 = Field()
    field_1 = Array(items=field_0, additional_items=False)
    field_2 = Object(properties={"a": field_0, "b": field_1})
   

# Generated at 2022-06-26 10:19:21.343971
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test field_choice_0
    field_choice_0 = Choice(choices=[])
    value = field_choice_0.validate(None, strict=False)
    assert value is None


# Generated at 2022-06-26 10:19:23.856629
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Field()
    field_1 = Field()
    union_0 = field_0 | field_1


# Generated at 2022-06-26 10:19:35.675166
# Unit test for method validate of class Union
def test_Union_validate():
    def test_Union_validate_true_0():
        field_0 = Union()

    def test_Union_validate_true_1():
        field_0 = Union()

    def test_Union_validate_true_2():
        field_0 = Union()

    def test_Union_validate_true_3():
        field_0 = Union()

    def test_Union_validate_false_0():
        field_0 = Union()

    def test_Union_validate_false_1():
        field_0 = Union()

    def test_Union_validate_false_2():
        field_0 = Union()

    def test_Union_validate_false_3():
        field_0 = Union()

    def test_Union_validate_false_4():
        field_0 = Union()

   