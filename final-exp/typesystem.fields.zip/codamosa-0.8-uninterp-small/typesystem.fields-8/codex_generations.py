

# Generated at 2022-06-26 10:11:03.796748
# Unit test for constructor of class Array
def test_Array():
    my_Array = Array(items=DateTime())



# Generated at 2022-06-26 10:11:14.378433
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    date_time_5 = DateTime()
    date_time_6 = DateTime()
    date_time_7 = DateTime()
    date_time_8 = DateTime()
    date_time_9 = DateTime()
    date_time_10 = DateTime()
    date_time_11 = DateTime()
    date_time_12 = DateTime()
    union_0 = date_time_0 | date_time_1
    union_1 = date_time_2 | date_time_3
    union_2 = date_time_4 | date_time_5

# Generated at 2022-06-26 10:11:19.004909
# Unit test for method validate of class Object
def test_Object_validate():
    # Local Variable Re-Definitions
    properties, pattern_properties, additional_properties, property_names, min_properties, max_properties, required, value, error_messages, validated_keys, validated, error_keys, remaining, child_value, error, item, key, text, message, child_schema = None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None
    # Perform Test
    object_0 = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    result = object_0.validate(value=value, strict=True)
    # Assertions


# Generated at 2022-06-26 10:11:27.504934
# Unit test for constructor of class Const
def test_Const():
    # Constructor of Const class
    try:
        const = Const("a")
    except Exception as e:
        print("Error encountered while constructing an object of Const class", e)
        sys.exit(1)
    print("Successfully constructed an object of Const class")

# This function calls the unit tests to test the class definition of Item

# Generated at 2022-06-26 10:11:33.899669
# Unit test for method serialize of class Array
def test_Array_serialize():
    items_0 = [None]
    additional_items_0 = None
    min_items_0 = None
    max_items_0 = None
    exact_items_0 = None
    unique_items_0 = False
    obj_0 = Array(items = items_0, additional_items = additional_items_0, min_items = min_items_0, max_items = max_items_0, exact_items = exact_items_0, unique_items = unique_items_0)
    obj_0.serialize(obj=None)
    obj_0.serialize([DateTime()])


# Generated at 2022-06-26 10:11:43.619530
# Unit test for constructor of class Choice
def test_Choice():

    # TypeError when choices is not of type list or tuple
    choices_0 = dask.delayed(str)
    try:
        Choice(choices=choices_0)
    except TypeError:
        pass
    else:
        raise Exception('Failed to raise TypeError when choices is not of type list or tuple')
    # TypeError when choices is not of type list or tuple
    choices_1 = [5]
    try:
        Choice(choices=choices_1)
    except TypeError:
        pass
    else:
        raise Exception('Failed to raise TypeError when choices is not of type list or tuple')
    # TypeError when choices is not of type list or tuple
    choices_2 = (1, 2, 3)

# Generated at 2022-06-26 10:11:48.820303
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array(max_items = 5)
    try:
        a.validate([1, 2, 3, 4, 5, 6])
    except Exception as e:
        pass


# Generated at 2022-06-26 10:11:58.755067
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(allow_null=False, default="", required=False, allow_blank=False)
    print(choice_0.validate(None, strict=False))
    print(choice_0.validate(None, strict=True))

    try:
        print(choice_0.validate(None, strict=False))
    except Exception as exception:
        print(exception.args)
    try:
        print(choice_0.validate(None, strict=True))
    except Exception as exception:
        print(exception.args)
    print(choice_0.validate(""))
    print(choice_0.validate(True))



# Generated at 2022-06-26 10:12:06.610572
# Unit test for method validate of class Array
def test_Array_validate():

    # Implementing test case 1
    array_0 = Array()
    value = []
    expected = []
    actual = array_0.validate(value)
    assert expected == actual

    # Implementing test case 2
    array_0 = Array()
    value = [1, 2, 3]
    expected = [1, 2, 3]
    actual = array_0.validate(value)
    assert expected == actual

    # Implementing test case 3
    array_0 = Array(allow_null=True)
    value = None
    expected = None
    actual = array_0.validate(value)
    assert expected == actual

    # Implementing test case 4
    array_0 = Array(allow_null=False)
    value = ""
    expected = None
    actual = array_0.validate(value)
   

# Generated at 2022-06-26 10:12:16.309971
# Unit test for constructor of class String
def test_String():
    # Case 0
    # (Typical Case)
    # default = "Empty"
    # title = "Empty"
    # is_required = False
    # allow_null = False
    # allow_blank = False
    s0 = String(
        title = "Empty",
        default = "Empty",
    )
    
    # Case 1
    # (Typical Case)
    # default = ""
    # title = "Empty"
    # is_required = False
    # allow_null = False
    # allow_blank = True
    s1 = String(
        title = "Empty",
        default = "",
        allow_blank = True,
    )
    
    # Case 2
    # (Typical Case)
    # default = ""
    # title = "Empty"
    # is_required = False
   

# Generated at 2022-06-26 10:12:33.535459
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number()
    # Test one argument
    # Case 0
    number_0.validate(1337)
    # Case 1
    try:
        number_0.validate(None)
    except ValidationError as e:
        assert e.code == 'null'
        assert e.text == 'May not be null.'


# Generated at 2022-06-26 10:12:36.764962
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    assert date_time_0.get_default_value() == None
    date_time_0.default = "Nonmo1"
    assert date_time_0.get_default_value() == "Nonmo1"



# Generated at 2022-06-26 10:12:46.125746
# Unit test for constructor of class Array
def test_Array():
    date_time_1 = DateTime()

    items_1 = date_time_1

    additional_items_1 = date_time_1

    min_items_1 = 1

    max_items_1 = 1

    exact_items_1 = 1

    unique_items_1 = True

    object_1 = {'description': 'description'}

    object_2 = {'min_items': 'min_items', 'exact_items': 'exact_items'}

    object_3 = {'max_items': 'max_items', 'exact_items': 'exact_items'}

    object_4 = {'min_items': 'min_items', 'max_items': 'max_items'}

    object_5 = {'additional_items': 'additional_items'}


# Generated at 2022-06-26 10:12:59.844916
# Unit test for method validate of class Array
def test_Array_validate():
    items_0 = Number()
    additional_items_0 = True
    max_items_0 = 2
    unique_items_0 = True
    Array_instance_0 = Array(items=items_0, additional_items=additional_items_0, max_items=max_items_0, unique_items=unique_items_0)
    validate_arguments_0 = []
    validate_arguments_0.append(["[0.0, 1.0]"])
    validate_return_0 = Array_instance_0.validate(validate_arguments_0[0])
    print(Array_instance_0.errors)
    print(validate_return_0)
    assert validate_return_0 == validate_arguments_0[0]
    validate_arguments_1 = []
    validate_arguments_

# Generated at 2022-06-26 10:13:05.968416
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test case 0
    choice_0 = Choice()
    value_0 = None
    strict_0 = True
    try:
        choice_0.validate(value_0, strict=strict_0)
    except ValidationError:
        pass


# Generated at 2022-06-26 10:13:06.912666
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    value = choice_0.validate('', strict=True)



# Generated at 2022-06-26 10:13:09.514893
# Unit test for method serialize of class String
def test_String_serialize():
    # Check if a function can be called as a method
    date_time_0 = DateTime()
    date_time_0.serialize(2.3)



# Generated at 2022-06-26 10:13:21.344083
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    date_time_0 = DateTime()
    assert date_time_0.get_default_value() is None, "Validation failed in method validate_or_error"
    assert date_time_0.has_default() is False, "Validation failed in method validate_or_error"
    assert date_time_0.get_error_text('format') == "Value '{value}' does not match {format}", "Validation failed in method validate_or_error"
    assert date_time_0.validate(None) == None, "Validation failed in method validate_or_error"
    assert date_time_0.validate(False) == None, "Validation failed in method validate_or_error"

# Generated at 2022-06-26 10:13:26.050726
# Unit test for method validate of class Number
def test_Number_validate():
    from random import random
    
    number = Number()
    test_value = [
        "hello world",
        1,
        1.1,
        random()
    ]
    for value in test_value:
        try:
            number.validate(value)
        except ValidationError:
            pass



# Generated at 2022-06-26 10:13:28.978136
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    date_time_0.has_default()
    date_time_0.get_default_value()


# Generated at 2022-06-26 10:13:51.027685
# Unit test for method validate of class Number
def test_Number_validate():
    date_time_0 = DateTime(maximum=2147483648, minimum=2)
    date_time_1 = DateTime(maximum=2147483648, minimum=2.1)
    assert isinstance(date_time_0.allow_null, bool)
    assert isinstance(date_time_0.default, NO_DEFAULT)
    assert isinstance(date_time_0.title, str)
    assert isinstance(date_time_0.description, str)
    assert date_time_0.default == date_time_1.default
    assert date_time_0.allow_blank == date_time_1.allow_blank
    assert date_time_0.maximum == 2147483648
    assert date_time_0.minimum == 2
    assert date_time_1.maximum == 214748364

# Generated at 2022-06-26 10:13:52.156894
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean()
    boolean_0.validate(1.0)


# Generated at 2022-06-26 10:13:55.272619
# Unit test for method validate of class String
def test_String_validate():
    s = String(allow_blank=True)
    assert s.validate('') is None


# Generated at 2022-06-26 10:14:00.042269
# Unit test for constructor of class Const
def test_Const():
    test_case_0()


if __name__ == "__main__":
    test_Const()

# Generated at 2022-06-26 10:14:12.340785
# Unit test for method validate of class Union
def test_Union_validate():
    try:
        TEST_INPUT_0 = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e'}
        #assert 0 not in TEST_INPUT_0
        date_time_0 = DateTime()
        string_0 = String()
        list_0 = [date_time_0, string_0]

        union_0 = Union(list_0)

        if 0 in TEST_INPUT_0:
            for item_0 in TEST_INPUT_0[0]:
                union_0.validate(item_0)
        else:
            pass
    except Exception as e:
        print(e)
    else:
        print('Success!')

# Generated at 2022-06-26 10:14:25.672650
# Unit test for constructor of class Array
def test_Array():
    # Test 0
    items = None
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    array_0 = Array(
        items=items,
        additional_items=additional_items,
        min_items=min_items,
        max_items=max_items,
        unique_items=unique_items)
    assert array_0.max_items is None
    assert array_0.additional_items is False
    assert array_0.required is False
    assert array_0.items is None
    assert array_0.min_items is None
    assert array_0.unique_items is False

    # Test 1
    items = None
    additional_items = False
    min_items = 1
    max_items = 10
    unique_items = False

# Generated at 2022-06-26 10:14:30.448787
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_case_0()
    # Case 0
    date_time_0 = DateTime()
    assert date_time_0.get_default_value() == None


# Generated at 2022-06-26 10:14:31.999230
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    field_0 = Field()
    try:
        result = field_0 | date_time_0
        assert result is not None
    except Exception as exception:
        raise AssertionError(exception)


# Generated at 2022-06-26 10:14:41.234188
# Unit test for method validate of class Array
def test_Array_validate():
    date_time_0 = DateTime()
    integer_0 = Integer()
    array_0 = Array(
        items=[],
        max_items=2,
        min_items=2,
        unique_items=False,
        additional_items=True,
    )
    array_1 = Array()

    # Test
    array_0.validate([1, 2.0])

    # Test
    array_0.validate([date_time_0])
    integer_0.validate(1)
    with raises(AssertionError):
        array_0.validate([1.0, 2.0, 3.0])
    with raises(AssertionError):
        array_0.validate([1, 1.0])

# Generated at 2022-06-26 10:14:48.102949
# Unit test for method serialize of class Array
def test_Array_serialize():
    string_0 = String()
    string_1 = String(max_length=15)
    array_0 = Array(items=string_1)
    array_1 = Array(items=array_0)
    string_2 = array_1.serialize(["hello", "world"])
    array_2 = Array(items=string_0)
    array_3 = Array(items=array_2)
    string_3 = array_3.serialize([["hello", ["world", "hello", "world", "hello", "world", "hello", "world", "hello", "world", "hello", "world", "hello", "world", "hello", "world"]]])
    string_4 = String(min_length=18)
    string_5 = String(max_length=15)

# Generated at 2022-06-26 10:15:37.319483
# Unit test for method validate of class Union
def test_Union_validate():
    input_0 = 0
    output_0 = 0
    output_1 = 1
    output_2 = 2
    output_3 = 3
    output_4 = 4
    output_5 = 5
    output_6 = 6
    output_7 = 7
    output_8 = 8
    output_9 = 9
    output_10 = 10
    output_11 = 11
    output_12 = 12
    output_13 = 13
    output_14 = 14
    output_15 = 15
    output_16 = 16
    output_17 = 17
    output_18 = 18
    output_19 = 19
    output_20 = 20
    output_21 = 21
    output_22 = 22
    output_23 = 23
    output_24 = 24
    output_25 = 25
    output_26 = 26
    output_

# Generated at 2022-06-26 10:15:47.741702
# Unit test for method validate of class Object
def test_Object_validate():
    date_time_0 = DateTime()
    object_0 = Object(properties={'m': date_time_0}, additional_properties=True)
    object_1 = Object(properties={'m': date_time_0}, additional_properties=False)
    expected = {'m': datetime.datetime(1980, 1, 1, 0, 0)}
    arg_0 = {'m': datetime.datetime(1980, 1, 1, 0, 0)}
    actual = object_0.validate(arg_0)
    assert actual == expected
    actual = object_1.validate(arg_0)
    assert actual == expected


# Generated at 2022-06-26 10:15:54.220006
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array().serialize(None) is None

    assert Array(
        items=Integer(),
    ).serialize([1]) == [1]

    assert Array(
        items=Integer(),
    ).serialize([1, 2, 3]) == [1, 2, 3]

    assert Array(
        items=Array(
            items=Integer(),
        ),
    ).serialize([[1, 2], [3]]) == [[1, 2], [3]]

    assert Array(
        items=[
            Integer(),
        ],
    ).serialize([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-26 10:16:06.767748
# Unit test for method validate of class Object
def test_Object_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime(required=True)

    object_0 = Object(
        description="An example schema.",
        title="Example Schema",
        additional_properties=date_time_0,
        pattern_properties={
            "^[a-z][0-9]*$": integer_0,
            "^[a-z][0-9]*$": boolean_0,
        },
        properties={
            "createdAt": date_time_1,
            "isAdmin": boolean_0,
            "weather": integer_0,
        },
    )

# Generated at 2022-06-26 10:16:14.551480
# Unit test for method validate of class Choice
def test_Choice_validate():
    integer_0 = Integer()
    float_0 = Float()
    string_0 = String()
    decimal_0 = Decimal()
    boolean_0 = Boolean()
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0.validate(choice_1) == choice_1


# Generated at 2022-06-26 10:16:17.959384
# Unit test for constructor of class Array
def test_Array():
    test_Array = Array(min_items = 3, max_items = 6, items = None, additional_items = True, required = ["name"], allow_null = False, default = None, description = 'Required. Unique identifier for the target chat or username of the target channel (in the format @channelusername)')


# Generated at 2022-06-26 10:16:25.370917
# Unit test for constructor of class Const
def test_Const():
    # Test parameter 1
    # Type: int
    const_1 = 0
    # Type: str
    const_1 = "Test"
    # Type: list
    const_1 = [1, 2]
    # Type: float
    const_1 = 0.5
    # Type: tuple
    const_1 = (0, 1)
    # Type: set
    const_1 = {0, 1}
    # Type: dict
    const_1 = {0: 1, 1: 0}
    # Type: bool
    const_1 = True
    # Type: None
    const_1 = None
    # Type: typing.Any
    const_1 = typing.Any
    # Type: typing.Optional
    const_1 = typing.Optional
    # Type: typing.Union
    const_1 = typing.Union
   

# Generated at 2022-06-26 10:16:30.972479
# Unit test for method validate of class Choice
def test_Choice_validate():
    arg_0 = "1"
    arg_1 = "0"
    arg_2 = None
    arg_3 = "null"
    arg_4 = ""
    arg_5 = "a"
    arg_6 = [1, 2, 3, 4, 5]
    arg_7 = [1.1, 2.2, 3.3, 4.4, 5.5]
    arg_8 = [True, False, False, True, True]
    arg_9 = [["a", 1], ["b", 2.2], ["c", 3.3], ["d", 4.4], ["e", 5.5]]
    arg_10 = "test"

    obj = Choice()


# Generated at 2022-06-26 10:16:36.023707
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_0.validate([])
    array_0.validate([1.0])
    array_0.validate(["a"])
    array_0.validate([1.0, "a"])


# Generated at 2022-06-26 10:16:43.283188
# Unit test for method __or__ of class Field
def test_Field___or__():
    i = 0
    for x in [(1, 2, 3, 4), (1, 2, 3, 4), (5, 6, 7, 8)]:
        if i == 0:
            x_0 = x
            i = i_0 = DateTime()
    assert i_0 == x_0



# Generated at 2022-06-26 10:16:55.436196
# Unit test for method validate of class Union
def test_Union_validate():
    try:
        test_case_0()
    except Exception as e:
        logger.exception(e)
        raise AssertionError("Unit test for method Union.validate failed")


# Generated at 2022-06-26 10:16:59.415215
# Unit test for method validate of class Array
def test_Array_validate():
    # Arrange
    date_time_0 = DateTime()
    items = [date_time_0]
    keyword_0 = "additional_items"
    keyword_1 = "max_items"
    keyword_2 = "min_items"
    value_0 = 3
    array_0 = Array(**{keyword_0: True, keyword_1: value_0, keyword_2: value_0, "items": items})
    value_1 = [datetime.datetime.now()]
    # Act
    result = array_0.validate(value_1)
    # Assert
    assert result == value_1


# Generated at 2022-06-26 10:17:07.099744
# Unit test for constructor of class Const
def test_Const():
    try:
        t = Const(const=None)
    except Exception:
        assert False
    t = Const(const=True)
    try:
        t = Const(const=1)
    except Exception:
        assert False
    try:
        t = Const(const="hello")
    except Exception:
        assert False


# Generated at 2022-06-26 10:17:11.149624
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(properties = {}, pattern_properties = {}, additional_properties = None, property_names = None, min_properties = None, max_properties = None, required = [])
    assert obj.validate() == None
    assert ValidationError.is_validation_error(obj.validate()) == True


# Generated at 2022-06-26 10:17:19.038479
# Unit test for method __or__ of class Field
def test_Field___or__():
    __tracebackhide__ = True
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    temp_1 = date_time_0.__or__(date_time_1)
    assert temp_1 is not None

# test_equality is added after method __or__ of class Field


# Generated at 2022-06-26 10:17:26.085280
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()


# Generated at 2022-06-26 10:17:29.082269
# Unit test for constructor of class String
def test_String():
    test_string = String()
    assert isinstance(test_string, String)


# Generated at 2022-06-26 10:17:41.185655
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    date_time_5 = DateTime()
    date_time_6 = DateTime()
    date_time_7 = DateTime()
    date_time_8 = DateTime()
    date_time_9 = DateTime()
    date_time_10 = DateTime()
    date_time_11 = DateTime()
    date_time_12 = DateTime()
    date_time_13 = DateTime()
    date_time_14 = DateTime()
    date_time_15 = DateTime()
    date_time_16 = DateTime()
    date_time_17 = DateTime()
   

# Generated at 2022-06-26 10:17:48.871191
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    result = (date_time_0 or date_time_1)
    assert isinstance(result, Union) is True
    if (isinstance(result, Union)):
        assert len(result.any_of) == 2


# Generated at 2022-06-26 10:17:53.810361
# Unit test for method validate of class Union
def test_Union_validate():
    union_0 = Union( [ String() , String() , Number() ] )

    assert union_0.validate( 'arbitrary' ) == 'arbitrary'
    assert union_0.validate( 'arbitrary' , strict = True ) == 'arbitrary'

# Generated at 2022-06-26 10:18:13.328137
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert isinstance(DateTime() | DateTime(), Union), ""



# Generated at 2022-06-26 10:18:28.094011
# Unit test for method validate of class Array

# Generated at 2022-06-26 10:18:29.633782
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime()



# Generated at 2022-06-26 10:18:36.148640
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Arrange and act
    date_time_0 = DateTime()
    actual_0 = date_time_0.get_default_value()
    expected_0 = datetime.datetime.now().isoformat()

    # Assert
    assert actual_0 == expected_0



# Generated at 2022-06-26 10:18:37.251690
# Unit test for constructor of class Const
def test_Const():
    Const(1)


# Generated at 2022-06-26 10:18:49.282491
# Unit test for constructor of class String
def test_String():
    s = String(title="name", description="", max_length=None, default=None, allow_null=False, allow_blank=False, trim_whitespace=True, pattern=None, format="")
    assert s.format == ""
    assert s.title == 'name'
    assert s.description == ""
    assert s.allow_blank == False 
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.pattern_regex == None 
    assert s.allow_null == False


# Generated at 2022-06-26 10:18:55.403779
# Unit test for method validate of class Object
def test_Object_validate():
    print('\n=== test Object validate method ===')

    # Test invalid case 0
    object_0  = Object(required=True, min_properties=0, max_properties=10, allow_null=False)
    try:
        object_0.validate(None, strict=False)
    except ValidationError:
        print(ValidationError)

    # Test invalid case 1
    object_1  = Object(required=True, min_properties=0, max_properties=10, allow_null=False)
    value = [1, 2, 3]
    try:
        object_1.validate(value, strict=False)
    except ValidationError:
        print(ValidationError)

    # Test invalid case 2

# Generated at 2022-06-26 10:19:01.798536
# Unit test for method __or__ of class Field
def test_Field___or__():
    def check_Field___or__():
        try:
            # Arguments
            date_time_0 = DateTime()
            # Functionality
            test_case_0()
            # Test passed
            return True
        except:
            return False

    # Check
    assert check_Field___or__() == True, "Error"


# Generated at 2022-06-26 10:19:14.533738
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test with a single choice
    integer_0 = Integer()
    choice_0 = Choice(choices = [integer_0])
    try:
        choice_1 = choice_0.validate(0)
    except:
        choice_1 = None
    assert choice_1 == 0

    # Test with a list of choices
    choice_2 = Choice(choices = [0, 1 ,2 ,3])
    try:
        choice_3 = choice_2.validate(2)
    except:
        choice_3 = None
    assert choice_3 == 2

    # Test with an null allowed
    choice_4 = Choice(choices = [0, 1])
    try:
        choice_5 = choice_4.validate(None)
    except:
        choice_5 = None
    assert choice_5 == None


# Generated at 2022-06-26 10:19:23.215443
# Unit test for method validate of class Object
def test_Object_validate():
    assert Object(
        properties = {},
        pattern_properties = {},
        additional_properties = False,
        property_names = None,
        min_properties = None,
        max_properties = None,
        required = None,
        default = None,
        allow_null = None,
    ).validate(value = {}) == {}



# Generated at 2022-06-26 10:19:38.099069
# Unit test for method validate of class Object
def test_Object_validate():
    dict_0 = dict_0 = {
        "a": 1,
        "b": 2,
    }

    dict_1 = dict_0 = {
        "a": 1,
        "b": 2,
        "c": 3,
    }

    dict_2 = dict_0 = {
        "a": "1",
        "b": 2,
        "c": 3,
    }

    dict_3 = dict_0 = {
        "a": 1,
        "b": "2",
        "c": 3,
    }

    dict_4 = dict_0 = {
        "a": 1,
        "b": 2,
        "c": "3",
    }
