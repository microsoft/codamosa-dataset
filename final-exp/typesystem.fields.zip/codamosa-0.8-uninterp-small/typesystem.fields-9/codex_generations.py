

# Generated at 2022-06-26 10:11:22.938414
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    array = Array()
    input_0 = None
    array_result_0 = array.validate_or_error(input_0)
    expected_array_result_0 = ValidationResult(None, None)
    assert array_result_0.value == expected_array_result_0.value and array_result_0.error == expected_array_result_0.error
    input_1 = 1
    int_result_0 = Integer().validate_or_error(input_1)
    expected_int_result_0 = ValidationResult(1, None)
    assert int_result_0.value == expected_int_result_0.value and int_result_0.error == expected_int_result_0.error
    input_2 = 'hello world'
    str_result_0 = String().validate_or_error

# Generated at 2022-06-26 10:11:32.987935
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    array_0 = Array()

    # Test case 1
    try:
        assert_equal(array_0.get_default_value(), NO_DEFAULT)
    except:
        fail_test('get_default_value of class Field did not return the expected result')
        raise

    # Test case 2
    array_0 = Array(allow_null=True)
    try:
        assert_true(array_0.get_default_value() is None)
    except:
        fail_test('get_default_value of class Field did not return the expected result')
        raise

    # Test case 3
    array_0 = Array(default=[])

# Generated at 2022-06-26 10:11:43.114870
# Unit test for method validate of class Object
def test_Object_validate():
    # Test object keys with string and non-string keys
    # Test additional_properties set to true
    field_0 = Object(additional_properties=True)
    value_0 = {"asdf": "qwerty"}
    expected_0 = {"asdf": "qwerty"}
    assert field_0.validate(value_0) == expected_0

    # Test additional_properties set to false (should throw error)
    field_1 = Object(additional_properties=False)
    value_1 = {"asdf": "qwerty"}
    expected_1 = "Invalid property name."
    try:
        field_1.validate(value_1)
    except ValidationError as e:
        assert e.messages()[0].text == expected_1
    else:
        assert False

    # Test additional_properties set

# Generated at 2022-06-26 10:11:49.237096
# Unit test for method validate of class Object
def test_Object_validate():
    properties_0 = {"key": String()}
    additional_properties_0 = String()
    max_properties_0 = 0
    test_case_0 = Object(properties=properties_0, additional_properties=additional_properties_0, max_properties=max_properties_0)
    test_data_0 = {"key": "str"}
    # Exception thrown: AssertionError("Must have no more than 0 properties.")
    try:
        test_case_0.validate(test_data_0)
    except Exception as e:
        assert "Must have no more than 0 properties." == str(e)


# Generated at 2022-06-26 10:11:53.232508
# Unit test for method serialize of class Array
def test_Array_serialize():
    array_0 = Array()
    assert [1, 2, 3] == array_0.serialize([1, 2, 3])

    array_1 = Array(items=Integer())
    assert [1, 2, 3] == array_1.serialize([1, 2, 3])

# Generated at 2022-06-26 10:11:54.936529
# Unit test for method validate of class Array
def test_Array_validate():
    obj_0 = Array()
    v0_0 = obj_0.validate(1)
    assert_equals(v0_0, [])


# Generated at 2022-06-26 10:12:02.647518
# Unit test for method validate of class Array
def test_Array_validate():
    instance = Array()
    assert instance.null == False
    assert instance.max_length == None
    assert instance.min_length == None
    assert instance.regex == None
    assert instance.allow_empty == None
    assert instance.options == None
    assert instance.choices == None
    assert instance.properties == None
    assert instance.pattern_properties == None
    assert instance.additional_properties == None
    assert instance.property_names == None
    assert instance.min_properties == None
    assert instance.max_properties == None
    assert instance.required == None
    assert instance.min_items == None
    assert instance.max_items == None
    assert instance.items == None
    assert instance.additional_items == False
    assert instance.unique_items == False
    assert instance.default_value == None


# Generated at 2022-06-26 10:12:14.584624
# Unit test for method validate of class Union
def test_Union_validate():
    # 1. Create an instance of Union
    any_of_0 = [Dict()]
    union_0 = Union(any_of=any_of_0)
    # 2. Run the method validate
    data_0 = None
    union_0.validate(data_0)

if __name__ == "__main__":
    max_size = int(sys.argv[1])
    tester = __import__(sys.argv[2]).Tester(int(max_size))
    tester.add_tests(globals())
    results = tester.run_tests()
    sys.stderr.write(json.dumps(results))
    sys.stderr.flush()

# Generated at 2022-06-26 10:12:26.142406
# Unit test for method validate of class Union
def test_Union_validate():
    items_0 = [String()]
    additional_items_0 = False
    min_items_0 = 2
    max_items_0 = 2
    exact_items_0 = 2
    unique_items_0 = False
    array_0 = Array(items = items_0, additional_items = additional_items_0, min_items = min_items_0, max_items = max_items_0, exact_items = exact_items_0, unique_items = unique_items_0)
    value_0 = [1,2]
    strict_0 = False
    Union_0 = Union(any_of = [array_0])
    Union_0.validate(value = value_0, strict = strict_0)
test_Union_validate()


# Generated at 2022-06-26 10:12:28.321996
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Validating an empty string should throw an error
    field = Choice()
    with pytest.raises(ValidationError):
        field.validate("")



# Generated at 2022-06-26 10:12:50.228636
# Unit test for method validate of class Number
def test_Number_validate():
    # Setup
    number_0 = Number()

    # Invocation
    try:
        number_0.validate({})
    except:
        pass

    try:
        number_0.validate(None)
    except:
        pass



# Generated at 2022-06-26 10:12:57.827033
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    # Test for None
    try:
        array_0.validate(None, strict=True)
        assert False
    except ValidationError:
        assert True
    # Test for empty list
    try:
        array_0.validate([], strict=True)
        assert True
    except ValidationError:
        assert False
    # Test for an integer
    try:
        array_0.validate(1, strict=True)
        assert False
    except ValidationError:
        assert True
    # Test for float
    try:
        array_0.validate(2.34, strict=True)
        assert False
    except ValidationError:
        assert True    
    # Test for a string

# Generated at 2022-06-26 10:13:09.389546
# Unit test for method validate of class Number

# Generated at 2022-06-26 10:13:12.083099
# Unit test for method serialize of class String
def test_String_serialize():
    str = String()
    assert(str.serialize("abc") == "abc")


# Generated at 2022-06-26 10:13:22.284294
# Unit test for method validate of class Number
def test_Number_validate():
    uut = Number()
    assert uut.validate(-5.5) ==  -5.5
    assert uut.validate(-4) == -4
    assert uut.validate(-1.375) == -1.375
    assert uut.validate(0) == 0
    assert uut.validate(0.0) == 0.0
    assert uut.validate(3) == 3
    assert uut.validate(3.5) == 3.5
    assert uut.validate(7.25) == 7.25
    assert uut.validate(8) == 8
    assert uut.validate(14.25) == 14.25
    assert uut.validate(15) == 15
    assert uut.validate(18.0) == 18.0
    assert uut

# Generated at 2022-06-26 10:13:25.167835
# Unit test for method __or__ of class Field
def test_Field___or__():
    array = Array()
    bool = Boolean()
    assert type(array | bool) is Union

# Generated at 2022-06-26 10:13:33.608944
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Create instance for Array class
    array_0 = Array(
        min_items=2,
        max_items=2,
        items=[
            String(max_length=1, pattern="^(0|1)$"),
            String(max_length=3, pattern="^(0|1)+$"),
        ],
    )

    # Create instance for Choice class
    choice_0 = Choice(choices=[[array_0, "A"]])

    # Validate 'choice_0'
    result = choice_0.validate([["1", "111"]])


# Generated at 2022-06-26 10:13:43.284843
# Unit test for constructor of class Const
def test_Const():
    # Case 1
    test_case = Const("a string")
    assert test_case.const == "a string"
    assert test_case.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert test_case.validator is None
    assert test_case.allow_null == False

    # Case 2
    test_case = Const("a string", allow_null=True)
    assert test_case.const == "a string"
    assert test_case.errors == {"only_null": "Must be null.", "const": "Must be the value '{const}'."}
    assert test_case.validator is None
    assert test_case.allow_null == True

    # Case 3
    test_case = Const("a string", validator=None)

# Generated at 2022-06-26 10:13:45.876965
# Unit test for constructor of class Const
def test_Const():
    json_schema = {"type": "integer"}
    field = Field.create_from_json_schema(json_schema)
    json_schema_const = {"const": 3}
    field_const = Const(3)
    assert field.validate(3) == 3
    assert field_const.validate(3) == 3
    assert field_const.validate(2) == 2

# Generated at 2022-06-26 10:13:49.002045
# Unit test for method validate of class Choice
def test_Choice_validate():
    if __name__ == '__main__':
        choice = Choice()
        choice.validate(None, strict=True)



# Generated at 2022-06-26 10:14:07.996279
# Unit test for method validate of class Object
def test_Object_validate():
    string_0 = String()
    object_0 = Object(properties={'cat':string_0})
    assert object_0.validate({'cat':'dog'}) == {'cat':'dog'}


# Generated at 2022-06-26 10:14:12.740154
# Unit test for method __or__ of class Field
def test_Field___or__():
    array_0 = Array()
    any_of = [array_0]
    union_0 = Union(any_of=any_of)
    union_1 = array_0 | union_0
    array_1 = Array()
    union_2 = union_1 | array_1
    union_2.any_of


# Generated at 2022-06-26 10:14:23.949170
# Unit test for method serialize of class String
def test_String_serialize():
    # Assume String(title, default=False, **kwargs)
    test = String(title = 'name', default=False)
    # Assume String(title, **kwargs)
    test0 = String(title = 'name')
    # Assume String(name, **kwargs)
    test1 = String(name = 'name')
    # Assume String([name, age], **kwargs)
    test2 = String([name, age])
    # Assume String(["name", "age"], **kwargs)
    test3 = String(["name", "age"])



# Generated at 2022-06-26 10:14:37.876299
# Unit test for method __or__ of class Field
def test_Field___or__():
    array_0 = Array()
    array_0_0 = Array()
    try:
        field_0 = array_0 | array_0_0
        array_0_0.validate(array_0, strict=array_0)
        field_0.validate(field_0, strict=array_0)
        field_0.has_default()
        field_0.get_default_value()

        assert True
    except:
        assert False


subclasses = Field.__subclasses__()
for subclass in subclasses:
    exec (subclass.__name__ + ".__module__ = " + __name__)
    # exec ("from " + subclass.__module__ + " import " + subclass.__name__)
    exec ("from " + subclass.__module__ + " import " + subclass.__name__)


# Generated at 2022-06-26 10:14:45.545695
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    bool_0 = Boolean()
    bool_0.allow_null = bool_0
    val = bool_0.validate(None)
    assert val is None
    bool_0.allow_null = bool_1
    val = bool_0.validate(value)
    assert val is True
    bool_0.allow_null = bool_1
    val = bool_0.validate(value_1)
    assert val is False


# Generated at 2022-06-26 10:14:49.785523
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice_instance = Choice()
    assert Choice_instance.validate(value='test_value_0') == 'test_value_0'

# Generated at 2022-06-26 10:15:00.099784
# Unit test for constructor of class Array
def test_Array():
    with pytest.raises(AssertionError):
        array_0 = Array(additional_items=None, exact_items=123, max_items=123, min_items=123, unique_items=True)

    with pytest.raises(AssertionError):
        array_0 = Array(additional_items=None, exact_items=123, max_items=123, min_items=123)

    with pytest.raises(AssertionError):
        array_0 = Array(additional_items=None, exact_items=123, max_items=123, min_items=123, unique_items=True)

    with pytest.raises(AssertionError):
        array_0 = Array(additional_items=None, exact_items=123, max_items=123, min_items=123)

# Generated at 2022-06-26 10:15:07.945914
# Unit test for method validate of class String
def test_String_validate():
    dic_0 = String()
    array_0 = Array()
    num_0 = Number()
    array_0.items = num_0
    array_1 = Array()
    obj_0 = Object()
    array_1.items = obj_0
    dic_0.validate(array_1, strict=True)
    dic_0.validate(array_1, strict=True)
    dic_0.validate(array_0, strict=True)



# Generated at 2022-06-26 10:15:10.288596
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 10:15:14.175679
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String(title = "", description = "", default = "")
    try:
        string_0.serialize("")
    except NotImplementedError:
        print("Test test_String_serialize failed: You must implement method serialize")
    else:
        print("Test test_String_serialize passed")


# Generated at 2022-06-26 10:15:38.050473
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_field_0 = Boolean()
    try:
        boolean_field_0.validate(value=None, strict=False)
    except ValidationError as exc:
        assert 'null' == exc.code
    boolean_field_1 = Boolean(allow_null=False)
    try:
        boolean_field_1.validate(value=None, strict=False)
    except ValidationError as exc:
        assert 'type' == exc.code
    boolean_field_2 = Boolean(allow_null=True, default=None)
    assert None is boolean_field_2.validate(value=None)
    boolean_field_3 = Boolean()
    try:
        boolean_field_3.validate(value=True, strict=False)
    except ValidationError as exc:
        assert 'type' == exc.code

# Generated at 2022-06-26 10:15:49.162873
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test cases to test the validate method of class Choice
    # Case 0
    # Member variables:
    # choices : [('A', '1'), ('B', '2')]
    # value : 'A'
    # expected : 'A'
    array_0 = Array()
    choices_0 = [('A', '1'), ('B', '2')]
    choice = Choice(choices_0)
    expected_0 = 'A'
    value_0 = 'A'
    actual_0 = choice.validate(value_0)
    assert actual_0 == expected_0
    # Case 1
    # Member variables:
    # choices : [('A', '1'), ('B', '2')]
    # value : 'C'
    # expected : ValidationError(text='Not a valid choice.', code='choice')

# Generated at 2022-06-26 10:15:59.792801
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_0.validate([])
    array_0.validate([0])
    array_0.validate([0, 1])
    array_0.validate([0, 1, 2])
    array_0.validate([0, 1, 2, 3])
    array_0.validate([0, 1, 2, 3, 4])
    array_0.validate([0, 1, 2, 3, 4, 5])
    array_0.validate([0, 1, 2, 3, 4, 5, 6])
    array_0.validate([0, 1, 2, 3, 4, 5, 6, 7])
    array_0.validate([0, 1, 2, 3, 4, 5, 6, 7, 8])

# Generated at 2022-06-26 10:16:03.473921
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()
    try:
        string_0.serialize(1)
    except Exception:
        pass


# Generated at 2022-06-26 10:16:10.073298
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(properties = {'first': String(), 'last': String()}, required = ['first', 'last'])
    assert obj.validate({'first': 'John', 'last': 'Doe'}) == {'first': 'John', 'last': 'Doe'}
    assert obj.validate({'first': 'John'}) == {'first': 'John'}
    assert obj.validate({}) == {}
    assert obj.validate({'first': 'John', 'last': 'Doe', 'middle': '???', 'age': '???'}) == {'first': 'John', 'last': 'Doe', 'middle': '???', 'age': '???'}

# Generated at 2022-06-26 10:16:20.495965
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_1 = Array()
    array_2 = Array()
    array_3 = Array()
    array_4 = Array()
    array_5 = Array()
    array_6 = Array()
    array_7 = Array()
    array_8 = Array()
    array_9 = Array()
    array_10 = Array()
    array_11 = Array()

    array_0.validate([])
    array_1.validate(['test'])
    array_2.validate([1])
    array_3.validate([1.0])
    array_4.validate([True])
    array_5.validate([False])
    array_6.validate([None])

# Generated at 2022-06-26 10:16:33.489101
# Unit test for method validate of class Choice
def test_Choice_validate():
    try:
        obj_0 = Choice()
        obj_0.validate(None)
        assert False
    except ValidationError:
        pass

    try:
        obj_0 = Choice(allow_null=False)
        obj_0.validate(None)
        assert False
    except ValidationError:
        pass

    try:
        obj_0 = Choice(allow_null=False)
        obj_0.validate(None, strict=True)
        assert False
    except ValidationError:
        pass

    try:
        obj_0 = Choice(allow_null=True)
        obj_0.validate(None)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-26 10:16:40.853759
# Unit test for method serialize of class String
def test_String_serialize():
    field_0 = String()
    assert field_0.serialize("qwerty") == "qwerty"

    field_0 = String(format="date")
    assert field_0.serialize("2020-04-14") == datetime.date(2020, 4, 14)

    field_0 = String(format="time")
    assert field_0.serialize("15:47:40") == datetime.time(15, 47, 40)

    field_0 = String(format="uuid")

# Generated at 2022-06-26 10:16:45.696970
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean()
    boolean_1 = Boolean()
    boolean_0.validate(None, strict=True)
    boolean_1.validate(1, strict=False)


# Generated at 2022-06-26 10:16:59.115388
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    string_1 = String(allow_blank=True)
    string_2 = String(allow_blank=True)
    string_3 = String(allow_blank=True)
    string_4 = String(allow_blank=False)
    string_5 = String(max_length=1, allow_blank=True)
    string_6 = String(max_length=1, allow_blank=True)
    string_7 = String(max_length=1, allow_blank=True)
    string_8 = String(allow_blank=False)
    string_9 = String(allow_blank=True)
    string_10 = String(allow_blank=True)
    string_11 = String(allow_blank=False)
    string_12 = String(allow_blank=True)

# Generated at 2022-06-26 10:17:13.223101
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()

    if choice_0.validate("hello world") != "hello world":
        raise Exception("test 0")

    if choice_0.validate('') != None:
        raise Exception("test 1")

    if choice_0.validate("1") != None:
        raise Exception("test 2")

    if choice_0.validate(2) != None:
        raise Exception("test 3")

    if choice_0.validate(3) != None:
        raise Exception("test 4")


# Generated at 2022-06-26 10:17:14.795507
# Unit test for method validate of class Choice
def test_Choice_validate():
    array_0 = Array()
    choice_0 = Choice()
    choice_0.validate(array_0)


# Generated at 2022-06-26 10:17:20.506534
# Unit test for method validate of class Choice
def test_Choice_validate():
    array_0 = Array()
    choice_0 = Choice()
    array_0.validate(choice_0)


# Generated at 2022-06-26 10:17:31.037936
# Unit test for method validate of class String
def test_String_validate():
    obj_value = "thisisastring"
    obj_strict = False
    expected_neo = "thisisastring"
    expected_re = "thisisastring"
    string_obj = String()
    actual_neo = string_obj.validate(obj_value, obj_strict)
    actual_re = obj_value
    print(actual_neo)
    print(actual_re)
    assert expected_neo == actual_neo
    assert expected_re == actual_re


# Generated at 2022-06-26 10:17:42.057586
# Unit test for constructor of class Choice
def test_Choice():
    print('Testing constructor of class Choice')
    
    array_0 = Array(items=[])
    boolean_0 = Boolean()
    string_0 = String()
    boolean_1 = Boolean()
    choice_0 = Choice(required=true, nullable=true, title='title_0', choices=[(boolean_0, array_0), (string_0, boolean_1)])
    print('Field: ', choice_0.get_field())
    print('Coerce Values: ', choice_0.get_coerce_values())
    print('Choices: ', choice_0.get_choices())



# Generated at 2022-06-26 10:17:48.161574
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_field = Choice(choices=['choice1','choice2'])
    assert choice_field.validate('invalid')
    assert choice_field.validate('choice1')


# Generated at 2022-06-26 10:17:50.980374
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    try:
        array_0.validate(value=[0])
        # Unit test should not throw an exception
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-26 10:17:58.442482
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("") == ""
    assert Choice(allow_null=True).validate("null") is not None
    assert Choice(allow_null=True).validate("none") == ""
    assert Choice(choices=[("", "")]).validate("") is not None
    assert Choice(choices=[("", "")]).validate("") == ""
    assert Choice(choices=[("", "")]).validate("required") == ""
    assert Choice(choices=[("", "")]).validate("choice") is not None
    assert Choice(choices=[("", "")]).validate("choice") == ""


# Generated at 2022-06-26 10:18:00.970317
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_0 = Boolean()
    boolean_0.validate(None)


# Generated at 2022-06-26 10:18:05.286369
# Unit test for method validate of class Choice
def test_Choice_validate():
    array_0 = Array()
    choice_1 = Choice()

    test_1 = choice_1.validate(array_0)


# Generated at 2022-06-26 10:18:28.263037
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    try:
        choice_0.validate(None)

    except ValidationError:
        pass
    else:
        raise RuntimeError("Expected error not raised.")

    # Missing call to self.allow_null check
    try:
        choice_0.validate(1)

    except ValidationError:
        pass
    else:
        raise RuntimeError("Expected error not raised.")

    # Missing call to self.allow_null check



# Generated at 2022-06-26 10:18:37.085702
# Unit test for method validate of class Boolean
def test_Boolean_validate():

    # Init attributes
    bool_0 = Boolean()
    
    # Assertion errors
    try:
        assert_equal(True, True, "", "")
    except AssertionError as error:
        print(error)
    
    # Call method
    try:
        bool_0.validate(None)
    except ValidationError as error:
        print(error)



# Generated at 2022-06-26 10:18:45.616253
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Test 1
    field_0 = Field()
    assert field_0.has_default() == False
    assert field_0.get_default_value() == None

    # Test 2
    field_1 = Field(default=1)
    assert field_1.has_default() == True
    assert field_1.get_default_value() == 1


# Generated at 2022-06-26 10:18:48.377720
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # TODO: Should we assert something here?
    field_0 = Field()
    field_0.get_default_value()



# Generated at 2022-06-26 10:18:52.014210
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()

# Generated at 2022-06-26 10:19:02.394414
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number()

    # Case 0
    try:
        number.validate(2.3)
        assert False
    except ValidationError:
        assert True
    except Exception:
        assert False

    # Case 1
    try:
        number.validate("")
        assert False
    except ValidationError:
        assert True
    except Exception:
        assert False

    # Case 2
    try:
        number.validate("1234")
        assert False
    except ValidationError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 10:19:09.880798
# Unit test for constructor of class Const
def test_Const():
    a = Const("a", allow_null=False)
    assert isinstance(a, Const)
    assert a.allow_null == False
    assert a.const == "a"
    assert a.default == None
    assert a.description == None
    assert a.title == None


# Generated at 2022-06-26 10:19:11.873497
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    array_0 = Array()
    assert(array_0.get_default_value() is None)


# Generated at 2022-06-26 10:19:14.557831
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()

    r = field.get_default_value()
    assert r is None


# Generated at 2022-06-26 10:19:23.543098
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    array_0 = Array()
    field_0 = Field()
    array_0_expected = None
    field_0_expected = None
    array_0_actual = array_0.get_default_value()
    field_0_actual = field_0.get_default_value()
    assert array_0_actual == array_0_expected
    assert field_0_actual == field_0_expected



# Generated at 2022-06-26 10:19:32.512324
# Unit test for constructor of class String
def test_String():
    try:
        string_0 = String()
    except TypeError:
        pass
    else:
        print('Failed')



# Generated at 2022-06-26 10:19:33.642754
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():

    array_0 = Array()
    assert array_0.get_default_value() is None



# Generated at 2022-06-26 10:19:47.682196
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number()
    str_0 = ""
    bool_0 = False
    bool_1 = True
    str_1 = "number_0"
    assert number_0.validate(str_0, strict=bool_0) is None
    assert number_0.validate(str_0, strict=bool_1) == 0
    try:
        str_2 = "INF"
        number_0.validate(str_2, strict=bool_0)
    except ValidationError:
        pass

    try:
        str_3 = "-INF"
        number_0.validate(str_3, strict=bool_0)
    except ValidationError:
        pass
