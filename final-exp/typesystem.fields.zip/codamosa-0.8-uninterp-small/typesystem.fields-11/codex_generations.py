

# Generated at 2022-06-26 10:11:43.845632
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    error_code = ""

# Generated at 2022-06-26 10:11:50.353724
# Unit test for method validate of class Object
def test_Object_validate():
    object_1 = Object()

    assert object_1.validate({"key_0": "value_0", "key_1": "value_1"}) == {"key_0": "value_0", "key_1": "value_1"}
    assert object_1.validate({"key_0": 0, "key_1": 1}) == {"key_0": 0, "key_1": 1}
    assert object_1.validate({1: 0, 2: 1}) == {1: 0, 2: 1}

    object_2 = Object(additional_properties=False)


# Generated at 2022-06-26 10:11:55.774027
# Unit test for method validate of class Choice
def test_Choice_validate():

    # Test case 0
    print ("Test case 0")
    object_0 = Choice(choices=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"])
    print (object_0.validate(value=2))



# Generated at 2022-06-26 10:11:58.769504
# Unit test for constructor of class String
def test_String():
    assert String(title = "Test String Field").title == "Test String Field"


# Generated at 2022-06-26 10:12:02.946499
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Object()
    class_0 = Class()
    object_1 = Object()
    object_2 = Object()
    object_3 = Object()
    object_4 = Object()
    object_5 = Object()
    object_6 = Object()
    object_7 = Object()
    object_8 = Object()
    a = object_0.a
    b = object_0.b
    object_0.a = object_1
    object_0.b = object_1
    object_1.a = object_0
    object_1.b = object_0
    object_2.a = object_3
    object_2.b = object_3
    object_3.a = object_2
    object_3.b = object_2
    object_4.a = object_5
    object

# Generated at 2022-06-26 10:12:12.073664
# Unit test for method serialize of class Array
def test_Array_serialize():
    str_0 = String()
    arr_0 = Array(items=str_0)
    assert arr_0.serialize(["a", "b"]) == ["a", "b"]

    arr_1 = Array(items=arr_0)
    assert arr_1.serialize([["a", "b"], ["c", "d"]]) == [["a", "b"], ["c", "d"]]



# Generated at 2022-06-26 10:12:15.257993
# Unit test for constructor of class Const
def test_Const():
    Const(1)



# Generated at 2022-06-26 10:12:27.438665
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 0
    object_0 = Object()
    object_0.field("field_0", Integer())
    object_0.field("field_1", Integer())
    object_0.field("field_2", Integer())
    object_0.field("field_3", Integer())
    object_0.field("field_4", Integer())
    object_0.field("field_5", Integer())
    object_0.field("field_6", Integer())
    object_0.field("field_7", Integer())
    object_0.field("field_8", Integer())
    object_0.field("field_9", Integer())
    object_0.field("field_10", Integer())
    object_0.field("field_11", Integer())
    object_0.field("field_12", Integer())
    object_

# Generated at 2022-06-26 10:12:28.157132
# Unit test for constructor of class Choice
def test_Choice():
    Choice()


# Generated at 2022-06-26 10:12:29.759202
# Unit test for constructor of class Array
def test_Array():
    object_0 = Array()



# Generated at 2022-06-26 10:13:33.070019
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    object_0 = Object()
    object_0.title = 'type'
    # Testing for assert ValidationResult(value=None, error=None) == object_0.validate_or_error(value=None, strict=False)
    assert ValidationResult(value=None, error=None) == object_0.validate_or_error(value=None, strict=False)
    # Testing for assert ValidationResult(value=None, error=None) == object_0.validate_or_error(value=None, strict=True)
    assert ValidationResult(value=None, error=None) == object_0.validate_or_error(value=None, strict=True)
    # Testing for assert ValidationResult(value=None, error=None) == object_0.validate_or_error(value='numeric',

# Generated at 2022-06-26 10:13:35.148484
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_1 = Choice()
    object_2 = object_1


# Generated at 2022-06-26 10:13:39.141468
# Unit test for method validate of class String
def test_String_validate():
    string_0 = String()
    if (string_0.validate(None) is None):
        print("Test case 0 passed")
    else:
        print("Test case 0 failed")
        raise Exception("Test case 0 failed")

# Generated at 2022-06-26 10:13:51.307341
# Unit test for method __or__ of class Field
def test_Field___or__():
    object_0 = Field()
    object_0.errors = object_0
    object_0.__dict__.update({str("description") : str("")})
    object_0.__dict__.update({str("errors") : object_0})
    object_0.__dict__.update({str("allow_null") : object_0})
    object_0.__dict__.update({str("__module__") : str("typesystem.fields")})
    object_0.__dict__.update({str("__doc__") : str("Base class for fields.")})
    object_0.__dict__.update({str("__dict__") : object_0})
    object_0.__dict__.update({str("default") : NO_DEFAULT})

# Generated at 2022-06-26 10:14:02.761494
# Unit test for method validate of class Number
def test_Number_validate():
    object_0 = Int(maximum = 6, minimum = -5)
    object_0.validate(1)
    object_0.validate(1.0)
    object_0.validate(1.0, True)
    object_0.validate(1.0, False)
    object_0.validate(6)
    object_0.validate(6.0)
    object_0.validate(6.0, True)
    object_0.validate(6.0, False)
    object_0.validate(-5)
    object_0.validate(-5.0)
    object_0.validate(-5.0, True)
    object_0.validate(-5.0, False)
    object_0.validate(None)

# Generated at 2022-06-26 10:14:13.668003
# Unit test for method validate of class Array
def test_Array_validate():
    array_field_0 = Array()
    field_output_0, field_error_0 = array_field_0.validate_or_error(
        [None, None, None, None]
    )
    assert field_output_0 == [None, None, None, None]
    assert field_error_0 is None
    array_field_1 = Array(items=Boolean(allow_null=True))
    field_output_1, field_error_1 = array_field_1.validate_or_error(
        [None, None, None, None]
    )
    assert field_output_1 == [None, None, None, None]
    assert field_error_1 is None

# Generated at 2022-06-26 10:14:25.636982
# Unit test for method validate of class Choice
def test_Choice_validate():
    # This test fails with error:
    #     1)  ERROR: test_Choice_validate (test_validation.TestChoice)
    #         ----------------------------------------------------------------------
    #         Traceback (most recent call last):
    #           File "/home/alex/git/python-jsonmarshal/tests/test_validation.py", line 13, in test_Choice_validate
    #             test_case_0()
    #           File "/home/alex/git/python-jsonmarshal/tests/test_validation.py", line 7, in test_case_0
    #             object_0.validate(None, strict=False)
    object_0 = Choice()
    object_0.validate(None, strict=False)




# Generated at 2022-06-26 10:14:30.368029
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Field()
    object_default = object_0.get_default_value()
    assert isinstance(object_default, object)


# Generated at 2022-06-26 10:14:34.755367
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Choice()

    # If this assert fails then Choice.validate has changed it's function signature.
    assert callable(getattr(object_0, "validate"))


# Generated at 2022-06-26 10:14:39.384379
# Unit test for constructor of class String
def test_String():
    object_0 = String(
        allow_blank = False
    )
    assert(object_0.allow_blank == False)



# Generated at 2022-06-26 10:15:17.505625
# Unit test for method validate of class String
def test_String_validate():
    print("Testcase 0 : Null Value")
    string_0 = String()
    try:
        string_0.validate(None)
        print("validate did not raise Exception")
        return 1
    except ValidationError:
        pass
    return 0


# Generated at 2022-06-26 10:15:27.179487
# Unit test for method validate of class String
def test_String_validate():
    str_0 = String()
    val_0 = str_0.validate("")
    val_1 = str_0.validate("test")
    val_2 = str_0.validate("test\0")
    val_3 = str_0.validate("\0test")
    val_4 = str_0.validate("\0\0")
    val_5 = str_0.validate("\0")
    val_6 = str_0.validate("\0")
    val_7 = str_0.validate("\0")
    val_8 = str_0.validate("\0")
    val_9 = str_0.validate("\0")
    val_10 = str_0.validate("")
    val_11 = str_0.validate("")
    val

# Generated at 2022-06-26 10:15:34.837161
# Unit test for method validate of class Number
def test_Number_validate():
    # Test case for validating that an int is a number
    assert Number().validate(1) == 1
    assert Number().validate(-1) == -1
    # Test case for validating that a string is not valid as a Number
    try:
        Number().validate('a')
        assert False
    except ValidationError:
        assert True
    # Test case for validating that an empty string is not valid as a Number
    try:
        Number().validate('')
        assert False
    except ValidationError:
        assert True
    # Test case for validating that None is not valid as a Number
    try:
        Number().validate(None)
        assert False
    except ValidationError:
        assert True
    # Test case for validating that inf is not valid as a Number

# Generated at 2022-06-26 10:15:48.035746
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_case_0()
    test1 = Field(default=10, title="title", description="description", allow_null=True)
    assert test1.get_default_value() == 10

    test2 = Field(title="title", description="description", allow_null=True)
    assert test2.get_default_value() == None

    # object
    test3 = Field(default = object, title = "title", description = "description", allow_null = True)
    # object has no __dict__, so cannot show its default value
    assert test3.get_default_value() == object

    # __dict__
    test4 = Field(default = __dict__, title = "title", description = "description", allow_null = True)
    # __dict__ has no __dict__, so cannot show its default value
    assert test

# Generated at 2022-06-26 10:15:51.046279
# Unit test for method __or__ of class Field
def test_Field___or__():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")


# Generated at 2022-06-26 10:15:55.592312
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # User-controlled input
    object_0 = Object()
    object_0._creation_counter = 0
    Field._creation_counter = 0
    object_0.default = object_0.validate
    object_0.get_default_value()


# Generated at 2022-06-26 10:16:02.370417
# Unit test for method validate of class Union
def test_Union_validate():
    from random import randint
    from discobolus import (
        Object,
        Array,
        Integer,
        String,
        Union,
        ValidationError,
        ValidationErrorMessage,
    )

    object_0 = Object(
        properties={
            "id": Integer(minimum=1, maximum=3),
            "name": String(min_length=2, max_length=4),
            "next": Union(
                any_of=[
                    Object(
                        additional_properties=False,
                        properties={
                            "value": Integer(minimum=0),
                            "name": String(min_length=1),
                        },
                    ),
                    Array(String(min_length=1), min_items=1),
                ]
            ),
        }
    )


# Generated at 2022-06-26 10:16:05.198011
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const()
    assert const_0.const is None
    assert const_0.allow_null is False
    assert const_0.allow_any is False

# Generated at 2022-06-26 10:16:09.301451
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Arrange
    object_0 = Boolean()
    # Act
    object_0.validate()
    # Assert
    # No Assert
    return 0


# Generated at 2022-06-26 10:16:13.771930
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    class_0 = Boolean()
    assert class_0.validate(True) is True
    assert class_0.validate(False) is False
    return True


# Generated at 2022-06-26 10:16:29.473254
# Unit test for method validate of class Object
def test_Object_validate():
    source = Object()
    source.validate(None)



# Generated at 2022-06-26 10:16:35.711621
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    object_0 = Field()
    #setattr(object_0, "default", NO_DEFAULT)
    rtn = object_0.has_default()
    assert rtn == False
    rtn = object_0.get_default_value()
    assert rtn == None
    return rtn


# Generated at 2022-06-26 10:16:38.544204
# Unit test for method validate of class Union
def test_Union_validate():
    obj = Union([])
    obj.validate(None)
    assert True


# Generated at 2022-06-26 10:16:47.634435
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array(items=Field(required=True), required=True)
    try:
        array_0.validate(None)
    except ValidationError as ve:
        assert ve.messages[0].text == "This field is required."
        assert ve.messages[0].code == "required"
        assert ve.messages[0].key == 0
    else:
        raise Exception("Test case failed")


# Generated at 2022-06-26 10:16:59.854266
# Unit test for method validate of class Choice
def test_Choice_validate():
    cases = []

    case_0_input_value = None
    case_0_input_strict = False
    case_0_input_exception = None
    cases.append((case_0_input_value, case_0_input_strict, case_0_input_exception))

    case_1_input_value = ''
    case_1_input_strict = False
    case_1_input_exception = ValidationError(text='Must be a valid string.', code='type')
    cases.append((case_1_input_value, case_1_input_strict, case_1_input_exception))

    case_2_input_value = None
    case_2_input_strict = True

# Generated at 2022-06-26 10:17:04.947887
# Unit test for method serialize of class Array

# Generated at 2022-06-26 10:17:07.096541
# Unit test for method serialize of class String
def test_String_serialize():
    # Parameter obj = Object
    String(format=object_0)



# Generated at 2022-06-26 10:17:19.166224
# Unit test for constructor of class String
def test_String():
    # Creating an object of class String with title, description parameter
    object_0 = String(title="String_title", description="String_description")

    # Creating an object of class String with title, description and default parameter
    object_1 = String(title="String_title", description="String_description", default="Default_value")

    # Creating an object of class String with title, description, default and allow_null parameter
    object_2 = String(title="String_title", description="String_description", default="Default_value", allow_null=True)

    # Creating an object of class String with title, description and allow_blank parameter
    object_3 = String(title="String_title", description="String_description", allow_blank=True)

    # Creating an object of class String with title, description, default and trim_whitespace parameter

# Generated at 2022-06-26 10:17:22.090477
# Unit test for constructor of class Const
def test_Const():
    object_1 = Const(const = 1)
    object_2 = Const(const = "this is a string")
    object_3 = Const(const = None)

# Generated at 2022-06-26 10:17:23.986547
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()


# Generated at 2022-06-26 10:17:34.078700
# Unit test for method serialize of class String
def test_String_serialize():
    obj = String()
    assert obj.serialize("test_value") is "test_value"


# Generated at 2022-06-26 10:17:44.404451
# Unit test for method serialize of class String
def test_String_serialize():
    object_0 = String()
    object_0.format = 'datetime'
    object_0.validate('2020-06-08T09:05:34Z') + 'y'
    object_0.serialize(object_0.validate( '2020-06-08T09:05:34Z'))
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: This test has no assertion.
    object_

# Generated at 2022-06-26 10:17:49.943673
# Unit test for method __or__ of class Field
def test_Field___or__():
    object_0 = Object()
    Union_0 = Field.__or__(object_0)
    print(Union_0)
    assert None


# Generated at 2022-06-26 10:17:58.275136
# Unit test for constructor of class String
def test_String():
    string_0 = String()
    string_0 = String(title='string_0',description='string_0')
    string_0 = String(title='string_0',description='string_0',default=None)
    string_0 = String(title='string_0',description='string_0',default='')
    string_0 = String(title='string_0',description='string_0',allow_null=True)
    string_0 = String(title='string_0',description='string_0',allow_blank=True)
    string_0 = String(title='string_0',description='string_0',min_length=2,max_length=2)


# Generated at 2022-06-26 10:18:00.581280
# Unit test for method validate of class Number
def test_Number_validate():
    # initialize the parameters
    value = float()
    # the actual test
    test_case_0()


# Generated at 2022-06-26 10:18:09.606939
# Unit test for method serialize of class Array
def test_Array_serialize():
    # case 0
    object_0 = Array(items=None)
    assert object_0.serialize([1]) == [1]

    # case 1
    object_1 = Array(items=Integer())
    assert object_1.serialize([1]) == [1]

    # case 2
    object_2 = Array(items=[Integer(), Integer()])
    assert object_2.serialize([1, 2]) == [1, 2]

    # case 3
    object_3 = Array(items=None, additional_items=False)
    assert object_3.serialize([1]) == [1]

    # case 4
    object_4 = Array(items=Integer(), additional_items=False)
    assert object_4.serialize([1]) == [1]

    # case 5

# Generated at 2022-06-26 10:18:15.154314
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(
        choices=[
            'f',
            'h',
            'i',
            'k',
            'l',
            'p',
            'u',
            'q',
            'x',
            'w',
            'r',
            'v',
            'g',
            'j',
            'b',
            'd',
            's',
            'e',
            't',
            'c',
            'o',
            'a',
            'n',
            'm',
            'y',
            'z'
        ])
    str_0 = choice_0.validate('y', strict=True)
    assert str_0 == 'y'


# Generated at 2022-06-26 10:18:28.849814
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    array_0.items = 0
    array_0.additional_items = 0
    array_0.min_items = 0
    array_0.max_items = 0
    array_0.unique_items = 0

    try:
        array_0.validate(None)
    except ValidationError:
        print("ValidationError for argument: None")
    except AssertionError:
        print("AssertionError for argument: None")
    except:
        print("Exception for argument: None")

    try:
        array_0.validate(None, 0)
    except ValidationError:
        print("ValidationError for argument: (None, 0)")
    except AssertionError:
        print("AssertionError for argument: (None, 0)")

# Generated at 2022-06-26 10:18:33.091178
# Unit test for method serialize of class String
def test_String_serialize():
    object_0 = Object()
    object_0.field_0 = String()
    object_0.field_0.serialize(u"")


# Generated at 2022-06-26 10:18:36.875446
# Unit test for method validate of class Object
def test_Object_validate():
    object_0 = Object()
    assert object_0.validate({'key': 'value'}) == {'key': 'value'}

# Generated at 2022-06-26 10:18:52.697864
# Unit test for method validate of class String
def test_String_validate():
    string0 = String()
    value0 = None
    value1 = 1
    value2 = 'a'
    value3 = True
    expected0 = None
    expected1 = '1'
    expected2 = 'a'
    expected3 = 'True'
    actual0 = string0.validate(value0, strict=false)
    actual1 = string0.validate(value1, strict=false)
    actual2 = string0.validate(value2, strict=false)
    actual3 = string0.validate(value3, strict=false)
    assert expected0 == actual0
    assert expected1 == actual1
    assert expected2 == actual2
    assert expected3 == actual3



# Generated at 2022-06-26 10:18:54.339357
# Unit test for method validate of class Union
def test_Union_validate():
    object_0 = Object()

# Generated at 2022-06-26 10:19:07.250267
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Object()
    choice_0 = Choice()
    choice_1 = Choice(allow_null=False)
    choice_2 = Choice(allow_null=True)
    choice_3 = Choice(choices=["Choice1", "Choice2"])
    choice_4 = Choice(choices=[("Choice1", ), ("Choice2", )])
    choice_5 = Choice(
        allow_null=True, choices=[("Choice1", ), ("Choice2", )]
    )

    # Test for Null
    try:
        choice_0.validate(None, strict=True)
    except Exception as error:
        print(error)
    try:
        choice_0.validate(None, strict=True)
    except Exception as error:
        print(error)

# Generated at 2022-06-26 10:19:13.016799
# Unit test for method validate of class Array
def test_Array_validate():
    obj = Array()

    assert_equal(obj.validate(['a', 'b']), ['a', 'b'])
    assert_raises_regex(ValidationError, 'Must be an array.', lambda: obj.validate('a'))
    assert_raises_regex(ValidationError, 'Must not be null.', lambda: obj.validate(None))

# Generated at 2022-06-26 10:19:26.564586
# Unit test for constructor of class Const
def test_Const():
    print("Test Const constructor")
    const_1 = Const(False, allow_null=False)
    assert True == const_1.allow_null
    assert const_1.const
    const_1 = Const(False, allow_null=False, allow_empty_string=False)
    assert False == const_1.allow_empty_string
    assert True == const_1.allow_null
    assert const_1.const
    const_1 = Const(False, allow_null=True, allow_empty_string=False)
    assert const_1.const
    const_1 = Const(False, allow_null=False, allow_empty_string=True)
    assert True == const_1.allow_empty_string
    assert False == const_1.allow_null
    assert const_1.const

# Generated at 2022-06-26 10:19:27.910876
# Unit test for method validate of class Choice
def test_Choice_validate():
    object_0 = Choice()
    object_0.validate(None, strict=True)



# Generated at 2022-06-26 10:19:28.890385
# Unit test for constructor of class String
def test_String():
    the_Field = Field()
    the_String = String()


# Generated at 2022-06-26 10:19:30.349263
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert test_case_0() is None


# Generated at 2022-06-26 10:19:33.143438
# Unit test for method __or__ of class Field
def test_Field___or__():
    object_0 = Field()
    object_1 = Field()
    object_0.__or__(object_1)


# Generated at 2022-06-26 10:19:47.537815
# Unit test for method validate of class Object
def test_Object_validate():
    # Test case 1
    object_0 = Object()
    value_0 = {
        "property": String(),
        "properties": [Object(properties={"property": String()})]
    }
    value_1 = {"property": "1", "properties": []}
    value_return_0 = object_0.validate(value_1)
    assert value_return_0 == {"property": "1", "properties": []}

    # Test case 2
    object_1 = Object(properties={
        "property": String(),
        "properties": Array()
    })
    value_2 = {"property": "1"}
    value_return_1 = object_1.validate(value_2)
    assert value_return_1 == {"property": "1", "properties": []}
