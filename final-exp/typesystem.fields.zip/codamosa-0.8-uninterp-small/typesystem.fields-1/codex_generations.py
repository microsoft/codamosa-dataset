

# Generated at 2022-06-26 10:11:00.577302
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    val_err_ret_0 = ValidationResult(value=None, error=None)
    val_err_ret_1 = ValidationResult(value=None, error=None)
    ret_0 = ValidationResult(value=None, error=None)
    ret_1 = ValidationResult(value=None, error=None)

    obj_0 = Field()
    val_err_ret_0 = obj_0.validate_or_error(value=None, strict=None)

    # Assert type of return parameter named "ValidationResult" is "ValidationResult.
    assert isinstance(val_err_ret_0, ValidationResult) 

    obj_1 = Field(title="Field", description=None, default=None, allow_null="Field")
    val_err_ret_1 = obj_1.validate_

# Generated at 2022-06-26 10:11:05.142209
# Unit test for method __or__ of class Field
def test_Field___or__():
    choice_0 = Choice()
    choice_0.any_of = [Null, Integer]
    Field.__or__(choice_0)


# Generated at 2022-06-26 10:11:15.054613
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    if string.validate(value = 'None', strict = False) != 'None':
        raise
    
    if string.validate(value = 'None', strict = False) != 'None':
        raise
    
    try:
        string.validate(value = None, strict = True)
    except Exception as error:
        if error.code != 'null':
            raise
    
    choice_0 = Choice()
    try:
        string.validate(value = choice_0, strict = False)
    except Exception as error:
        if error.code != 'type':
            raise
    
    if string.validate(value = 'None', strict = False) != 'None':
        raise
    
    if string.validate(value = 'None', strict = False) != 'None':
        raise

# Generated at 2022-06-26 10:11:19.964225
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    choice = Boolean()
    try:
        choice.validate(None)
    except ValidationError as error:
        print(error.code)
        print(error.text)

    try:
        choice.validate(1)
    except ValidationError as error:
        print(error.code)
        print(error.text)

    try:
        choice.validate(True)
    except ValidationError as error:
        print(error.code)
        print(error.text)



# Generated at 2022-06-26 10:11:23.673311
# Unit test for method validate of class Object
def test_Object_validate():
    object_field = Object()
    object_field.validate("a")


# Generated at 2022-06-26 10:11:26.949645
# Unit test for method serialize of class Array
def test_Array_serialize():
    assert Array().serialize([1]) == [1]
    assert Array().serialize([]) == []
    assert Array().serialize(None) == None


# Generated at 2022-06-26 10:11:30.276023
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    choice_0 = Choice()
    result = choice_0.get_default_value()
    assert result == None
    field_0 = Field()
    result = field_0.get_default_value()
    assert result == None


# Generated at 2022-06-26 10:11:41.967317
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()

    assert_raises_runtime_error(
        "did not match any valid type", Union(any_of=[choice_0]).validate, "1"
    )
    assert_raises_runtime_error(
        "did not match any valid type", Union(any_of=[choice_0]).validate, 1
    )
    assert_equal(
        "1", Union(any_of=[choice_0]).validate(
            (1,), strict=True
        )
    )
    assert_equal(
        "1", Union(any_of=[choice_0]).validate(
            (1,), strict=False
        )
    )



# Generated at 2022-06-26 10:11:50.311837
# Unit test for method validate of class String
def test_String_validate():
    dictionary = {
        "str1": "str1",
        "str2": "str2",
        "str3": "str3",
        "abc":   "abc",
    }

    # Test with valid arguments 
    try:
        for i in range(len(dictionary.items())):
            for k, v in dictionary.items():
                if(k == v):
                    String.validate(k, v)
                else:
                    String.validate(k, v)
    except ValidationError as e:
        assert True
    except Exception:
        assert False

    # Test with invalid arguments
    try:
        String.validate('abc', None)
    except ValidationError as e:
        assert True
    except Exception:
        assert False

    # Test with invalid arguments

# Generated at 2022-06-26 10:11:51.183523
# Unit test for constructor of class Const
def test_Const():
    case_0 = Const(1,1)
    assert case_0.allow_null == True


# Generated at 2022-06-26 10:12:12.903995
# Unit test for method validate of class Number
def test_Number_validate():
    t_number = 333
    n = Number()
    n.validate(t_number)


# Generated at 2022-06-26 10:12:21.051962
# Unit test for method serialize of class Array
def test_Array_serialize():
    array_obj = Array(items={
        'type': String(max_length=15)
    })
    obj_0 = ['foo', 'bar', 'baz']
    value_0 = array_obj.serialize(obj_0)
    assert value_0 == ['foo', 'bar', 'baz']



# Generated at 2022-06-26 10:12:31.422581
# Unit test for method validate of class Object
def test_Object_validate():
    print("****TESTING validate()****")
    obj = Object(required = ["name"])
    obj.validate({"name":2})
    print(obj.validate({"name":2}))
    print(obj.validate({"name":"aman","address":"Delhi"}))

    obj = Object(required = ["name"], properties = {"name":String()},
    pattern_properties = {"address":String()})
    print(obj.validate({"name":2}))
    print(obj.validate({"name":"aman"}))
    print(obj.validate({"name":"aman","address2":"Delhi"}))


# Generated at 2022-06-26 10:12:34.639165
# Unit test for method serialize of class String
def test_String_serialize():
    string = String(
        title = '',
        description = '',
        default = NO_DEFAULT,
        allow_null = False,
    )
    string.serialize(
        obj,
    )


# Generated at 2022-06-26 10:12:43.664148
# Unit test for method validate of class Object
def test_Object_validate():
    choice_0 = Boolean(required=True, allow_null=False, field_name="bool", description="")
    choice_0.validate("")
    properties_0 = {"bool": choice_0}
    choice_1 = Object(required=True, properties=properties_0, allow_null=False, field_name="obj", description="")
    choice_1.validate("")
    choice_2 = List(child=choice_1, max_length=5, required=True, allow_null=False, field_name="obj_list", description="")
    choice_2.validate("")

if __name__ == "__main__":
    test_case_0()
    test_Object_validate()

# Generated at 2022-06-26 10:12:46.441755
# Unit test for constructor of class String
def test_String():
    String(title="", description="", default=NO_DEFAULT, allow_null=True)



# Generated at 2022-06-26 10:12:53.795277
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()

    try:
        Union.validate(choice_0)
    except Exception as e:
        assert type(e) == TypeError
    try:
        Union.validate(choice_0, strict=True)
    except Exception as e:
        assert type(e) == TypeError

# Generated at 2022-06-26 10:12:56.584105
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    choice_0 = Choice()
    choice_0.default = [0, 1]
    choice_0.get_default_value()


# Generated at 2022-06-26 10:12:57.401965
# Unit test for method serialize of class String
def test_String_serialize():
    assert True


# Generated at 2022-06-26 10:13:03.462532
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f_0 = Field()
    if hasattr(f_0, "default"):
        assert isinstance(f_0.get_default_value(), object)
    else:
        assert f_0.get_default_value() == None


# Generated at 2022-06-26 10:13:34.105680
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Create instance of class Array
    arg_name = "items"
    arg_items = None
    arg_required = False
    arg_allow_null = True
    arg_default = None
    arg_error_messages = None
    arg_items = None
    arg_additional_items = False
    arg_min_items = None
    arg_max_items = None
    arg_exact_items = None
    arg_unique_items = False

# Generated at 2022-06-26 10:13:36.502321
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    assert choice_0.validate(None, strict=True) is None



# Generated at 2022-06-26 10:13:44.326691
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=[])
    choice_1 = Choice(choices=[])
    choice_2 = Choice(choices=[])
    choice_3 = Choice(choices=[])
    choice_4 = Choice(choices=[])
    exception = ValidationError()
    try:  # Try-block
       choice_0.validate("", strict=True)
       assert False
    except ValidationError:  # Catch-block
       exception = sys.exc_info()[1]
       assert exception.message == "May not be null."
       assert exception.code == "null"
    try:  # Try-block
       choice_1.validate((), strict=True)
       assert False
    except ValidationError:  # Catch-block
       exception = sys.exc_info()[1]

# Generated at 2022-06-26 10:13:47.908799
# Unit test for method __or__ of class Field
def test_Field___or__():
    choice_0 = Choice()
    choice_1 = Choice()
    assert choice_0 | choice_1 is not None



# Generated at 2022-06-26 10:13:50.176257
# Unit test for method __or__ of class Field
def test_Field___or__():
    case_0 = Field(title = "", description = "", allow_null = False)
    choice_0 = Choice()
    case_0 | choice_0


# Generated at 2022-06-26 10:13:59.877652
# Unit test for method validate of class Array
def test_Array_validate():
    assert Array().validate([1]) == [1]
    assert Array().validate(["hi"]) == ["hi"]
    assert Array().validate([1, 2, 3]) == [1, 2, 3]
    assert Array().validate([]) == []
    assert Array(allow_null=True).validate(None) == None
    assert Array().validate([1, "hi"]) == [1, "hi"]



# Generated at 2022-06-26 10:14:03.438973
# Unit test for constructor of class Const
def test_Const():
    const_0=Const()

# Generated at 2022-06-26 10:14:09.797382
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field_0 = Field(default=1)
    assert field_0.get_default_value() == 1
    Field._creation_counter = 0
    field_0 = Field()
    assert field_0.get_default_value() == None



# Generated at 2022-06-26 10:14:13.634627
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()
    # Call to serialize of String with argument obj =
    assert string_0.serialize() == NotImplementedError
    string_1 = String()
    # Call to serialize of String with argument obj =
    assert string_1.serialize() == NotImplementedError


# Generated at 2022-06-26 10:14:15.963440
# Unit test for constructor of class Const
def test_Const():
    const = Const()
    assert const is not None



# Generated at 2022-06-26 10:15:00.331411
# Unit test for method validate of class Number
def test_Number_validate():
    # Test cases for valid input
    # initialization
    choice_0 = Number()

    # case 1
    try:
        choice_0.validate(1, strict=False)
        choice_0.validate(1.0, strict=False)
        choice_0.validate(1.1, strict=True)
    except ValidationError:
        print("test_Number_validate test case 0 failed")

    # case 2
    try:
        choice_0.validate(decimal.Decimal(1), strict=True)
        choice_0.validate(decimal.Decimal(1.0), strict=True)
        choice_0.validate(decimal.Decimal(1.1), strict=True)
    except ValidationError:
        print("test_Number_validate test case 1 failed")

   

# Generated at 2022-06-26 10:15:03.727343
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    assert choice_0.validate(True) == True


# Generated at 2022-06-26 10:15:09.677394
# Unit test for method validate of class Object
def test_Object_validate():
    # For the validate method of class Object
    schema = Object(properties={'a':Integer()})
    data = {'a':1}
    result = schema.validate(data)
    assert result == {'a': 1}

test_case_0()
test_Object_validate()

# Generated at 2022-06-26 10:15:10.563870
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    assert choice_0.validate("") == None


# Generated at 2022-06-26 10:15:20.083218
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    choice_1 = Choice()
    choice_2 = Choice()
    choice_3 = Choice()
    choice_4 = Choice()
    choice_5 = Choice()
    choice_6 = Choice()
    choice_7 = Choice()
    choice_8 = Choice()
    choice_9 = Choice()
    choice_10 = Choice()
    choice_11 = Choice()
    choice_12 = Choice()
    choice_13 = Choice()
    choice_14 = Choice()
    choice_15 = Choice()
    choice_16 = Choice()
    choice_0.validate(1)
    choice_1.validate(1, strict = False)
    choice_2.validate(1, strict = True)
    choice_3.validate(1.0)

# Generated at 2022-06-26 10:15:28.206950
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=[("a", "A"), ("b", "B")])
    choice_1 = Choice(choices=[("a", "A"), ("b", "B")])
    choice_2 = Choice(choices=[("a", "A"), ("b", "B")])
    choice_3 = Choice(choices=[("a", "A"), ("b", "B")])
    choice_4 = Choice(choices=[("a", "A"), ("b", "B")])

    assert choice_0.validate(value="a") == "a"
    assert choice_1.validate(value="b") == "b"
    choice_2.validate(value="A")
    choice_3.validate(value="B")
    choice_4.validate(value="null")



# Generated at 2022-06-26 10:15:30.884355
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    choice_1 = Choice()
    assert choice_1.get_default_value() == None


# Generated at 2022-06-26 10:15:35.175980
# Unit test for method validate of class Choice
def test_Choice_validate():
    value = None
    choice_0 = Choice()
    result = choice_0.validate(value)

    value = None
    choice_0 = Choice()
    result = choice_0.validate(value)



# Generated at 2022-06-26 10:15:46.751749
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()
    choice_0.choices = [
        Text(),
        Time(),
    ]
    choice_1 = Choice()
    choice_1.choices = [
        DateTime(),
        Time(),
    ]
    choice_2 = Choice()
    choice_2.choices = [
        Time(),
        DateTime(),
    ]
    union = Union([
        choice_0,
        choice_1,
        choice_2,
    ])
    assert union.validate("2019-01-01T00:00:00Z") == "2019-01-01T00:00:00Z"


# Generated at 2022-06-26 10:15:47.802541
# Unit test for method validate of class Number
def test_Number_validate():
    choice_0 = Choice()
    assert choice_0.validate(None) == None


# Generated at 2022-06-26 10:16:05.198042
# Unit test for method validate of class Number
def test_Number_validate():
    choice_0 = Choice()
    choice_1 = Choice()
    int_0 = Number(allow_null=False, title='', description='')
    int_0.validate(choice_1, strict=False)


# Generated at 2022-06-26 10:16:18.154506
# Unit test for method validate of class String
def test_String_validate():
    choice_0 = Choice()
    assert choice_0.validate("abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc") == "abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc"

# Generated at 2022-06-26 10:16:19.070630
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()



# Generated at 2022-06-26 10:16:28.891215
# Unit test for method validate of class String
def test_String_validate():
    # Normal case
    if test_case_0():
        choice_0 = Choice()
        choice_0.validate(6)
        assert choice_0.stored_type() == ValidationResult
        assert choice_0.stored_value() == ValidationResult(value=6, error=None)
        assert choice_0.stored_error() is None
    # Type error
    if test_case_0():
        choice_0 = Choice()
        choice_0.validate(6.34)
        assert choice_0.stored_type() == 'ValidationError'
        assert choice_0.stored_value() is None
        assert choice_0.stored_error() == 'Must be a string.'


# Generated at 2022-06-26 10:16:36.980323
# Unit test for method validate of class Array
def test_Array_validate():

    items = String()
    additional_items = String()
    min_items = 0
    max_items = 10
    unique_items = True

    test_object = Array(
        items=items,
        additional_items=additional_items,
        min_items=min_items,
        max_items=max_items,
        unique_items=unique_items,
    )

    value = ["a", "b", "c"]
    result = test_object.validate(value)
    assert result == value

# Generated at 2022-06-26 10:16:45.104249
# Unit test for method validate of class Union
def test_Union_validate():
    # Corner case #1
    choice_0 = Choice()
    choice_0.allow_null = True
    choice_0.null_value = None
    union_0 = Union([choice_0])
    union_0.allow_null = True
    union_0.null_value = None
    union_0.validate(None)


# Generated at 2022-06-26 10:16:58.324658
# Unit test for method __or__ of class Field
def test_Field___or__():
    choice_0 = Choice()
    choice_0.NO_DEFAULT = NO_DEFAULT
    choice_0.title = "True"
    choice_0.description = ""
    choice_0.allow_null = True
    choice_0.default = None
    choice_0.errors = {"invalid_choice": "Value must be one of {choices}."}
    choice_0._creation_counter = 1
    choice_0.choices = ["bob", "alice"]

    integer_0 = Integer()
    integer_0.NO_DEFAULT = NO_DEFAULT
    integer_0.title = ""
    integer_0.description = ""
    integer_0.allow_null = False

# Generated at 2022-06-26 10:17:04.767740
# Unit test for method validate of class Array
def test_Array_validate():

    # Array cannot be null
    with pytest.raises(ValidationError) as excinfo:
        Array().validate(None)

    # Array must be a list
    with pytest.raises(ValidationError) as excinfo:
        Array().validate("abc")


# Generated at 2022-06-26 10:17:06.947879
# Unit test for method validate of class String
def test_String_validate():
    choice_1 = String()
    choice_1.validate(5)


# Generated at 2022-06-26 10:17:19.167591
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    try:
        choice_0.validate(None, strict=False)
    except Exception as ex:
        assert type(ex) == ValidationError
        assert ex.text == "May not be null."
    else:
        assert False, "validate should have raised a ValidationError"
    choice_1 = Choice()
    try:
        choice_1.validate("", strict=False)
    except Exception as ex:
        assert type(ex) == ValidationError
        assert ex.text == "This field is required."
    else:
        assert False, "validate should have raised a ValidationError"
    choice_2 = Choice()
    try:
        choice_2.validate("1", strict=False)
    except Exception as ex:
        assert type(ex) == ValidationError

# Generated at 2022-06-26 10:17:42.463072
# Unit test for method validate of class Choice
def test_Choice_validate():
    # if value is None and self.allow_null:
    #     return None
    choice_0 = Choice()
    choice_0.validate(1)
    # elif value is None:
    #     raise self.validation_error("null")
    # elif value not in Uniqueness([key for key, value in self.choices]):
    #     if value == "":
    #         if self.allow_null and not strict:
    #             return None
    #         raise self.validation_error("required")
    #     raise self.validation_error("choice")
    # return value



# Generated at 2022-06-26 10:17:46.178348
# Unit test for method __or__ of class Field
def test_Field___or__():
    choice_0 = Choice.__or__(None, None)


# Generated at 2022-06-26 10:17:56.730358
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()
    choice_1 = Choice()
    union_0 = Union()
    union_0.any_of = [choice_0, choice_1]
    union_0.allow_null = True
    union_1 = Union()
    union_1.any_of = [choice_0, choice_1]
    union_1.allow_null = True
    union_2 = Union()
    union_2.any_of = [choice_0, choice_1]
    union_2.allow_null = True
    union_3 = Union()
    union_3.any_of = [choice_0, choice_1]
    union_3.allow_null = True
    union_4 = Union()
    union_4.any_of = [choice_0, choice_1]
    union_4

# Generated at 2022-06-26 10:18:08.259829
# Unit test for method serialize of class String
def test_String_serialize():
    # TypeError: __init__() missing 2 required keyword-only arguments: 'title' and 'description'
    choice_0 = String()
    choice_1 = String(allow_null=True)
    choice_2 = String(title="", description="")
    choice_3 = String(title="", description="", default='vnih8')
    choice_4 = String(title="", description="", default='vnih8', allow_null=True)
    choice_5 = String(title="", description="", default='vnih8', allow_null=True, allow_blank=True)
    choice_6 = String(title="", description="", default='vnih8', allow_null=True, allow_blank=True, trim_whitespace=False)

# Generated at 2022-06-26 10:18:15.710022
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice(choices=[1, 2, 3, 4, 5], allow_null=True)
    # Test with value 2 and strict as false, expected result 2
    assert 2 == choice_0.validate(value=2, strict=False)
    # Test with value 6 and strict as True, expected result to raise exception
    assert choice_0.validate(value=6, strict=True)
    # Test with value "", expected is to raise exception for invalid value
    assert choice_0.validate(value="")


# Generated at 2022-06-26 10:18:26.942368
# Unit test for method serialize of class String
def test_String_serialize():
    choice_0 = Choice()
    str_0 = String()
    dict_0 = {}
    assert str_0.serialize(dict_0) == dict_0
    assert str_0.serialize(3.1415) == 3.1415
    assert str_0.serialize(choice_0) == choice_0
    assert str_0.serialize(str_0) == str_0
    assert str_0.serialize(True) == True
    assert str_0.serialize([]) == []



# Generated at 2022-06-26 10:18:39.882411
# Unit test for method validate of class Object
def test_Object_validate():
    # Case 0 - Object validate
    def _test0():
        properties = None
        pattern_properties = None
        additional_properties = True
        property_names = None
        min_properties = None
        max_properties = None
        required = None
        field = Object()
        field.validate(properties)
        field.validate(pattern_properties)
        field.validate(additional_properties)
        field.validate(property_names)
        field.validate(min_properties)
        field.validate(max_properties)
        field.validate(required)

    test0 = Test("test_Object_validate", _test0, "Case 0 - Object validate")
    test0.run()


if __name__ == "__main__":
    # Unit test for method validate of class Object
    test_Object

# Generated at 2022-06-26 10:18:51.769855
# Unit test for method serialize of class String
def test_String_serialize():
    choice_0 = Choice()
    choice_0.ixes = [0, 0]
    choice_0.cnt = 2
    choice_1 = Choice()
    choice_1.ixes = [0, 0]
    choice_1.cnt = 2
    choice_2 = Choice()
    choice_2.ixes = [0, 0]
    choice_2.cnt = 2
    choice_3 = Choice()
    choice_3.ixes = [0, 0]
    choice_3.cnt = 2
    choice_4 = Choice()
    choice_4.ixes = [0, 0]
    choice_4.cnt = 2
    choice_5 = Choice()
    choice_5.ixes = [0, 0]
    choice_5.cnt = 2
    choice_6 = Choice()

# Generated at 2022-06-26 10:18:57.661520
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()
    case_0 = [choice_0, True]
    expect_0 = False
    actual_0 = Union.validate(choice_0, case_0)
    assert expect_0 == actual_0


# Generated at 2022-06-26 10:19:02.194460
# Unit test for method validate of class Union
def test_Union_validate():
    choice_0 = Choice()
    choice_1 = Choice()
    union_0 = Union([choice_0, choice_1])
    str_0 = null
    str_1 = union_0.validate(str_0)
    assert str_1 == null


# Generated at 2022-06-26 10:19:28.832133
# Unit test for method serialize of class String
def test_String_serialize():
    test_case_1_string_var_1 = String(format='date')
    assert test_case_1_string_var_1.serialize('5') == '5'

    test_case_2_string_var_1 = String(format='date')
    assert test_case_2_string_var_1.serialize('09/07/2017') == '09/07/2017'

    test_case_3_string_var_1 = String(format='date')
    assert test_case_3_string_var_1.serialize('9-7-2017') == '9-7-2017'

    test_case_4_string_var_1 = String(format='date')
    assert test_case_4_string_var_1.serialize('2017-07-09') == '2017-07-09'

# Generated at 2022-06-26 10:19:29.549855
# Unit test for method serialize of class String
def test_String_serialize():
    string_0 = String()



# Generated at 2022-06-26 10:19:32.624670
# Unit test for constructor of class Array
def test_Array():
    print("Testing Array : Construction")
    try:
        test_case_0()
        print("Success")
    except Exception as e:
        print("Failed",e)


if __name__ == "__main__":
    test_Array()

# Generated at 2022-06-26 10:19:39.295776
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    list_0 = []
    ret = array_0.validate(list_0)
    print(ret)

    list_1 = [1,2,3]
    array_1 = Array(additional_items=True, unique_items=True, items=Boolean())
    ret = array_1.validate(list_1)
    print(ret)

    array_2 = Array(unique_items=True, items=String())
    list_2 = ["a","a"]
    try:
        ret = array_2.validate(list_2)
        print(ret)
    except ValidationError as e:
        print(e)


if __name__ == "__main__":
    test_case_0()
    test_Array_validate()