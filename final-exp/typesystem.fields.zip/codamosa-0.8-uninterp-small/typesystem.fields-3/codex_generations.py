

# Generated at 2022-06-26 10:12:15.484864
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    error = None # this line is required!

    # Unit test 1
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    excel_date_time_0 = ExcelDateTime()
    excel_date_time_1 = ExcelDateTime()
    excel_date_time_2 = ExcelDateTime()
    excel_date_time_3 = ExcelDateTime()
    excel_date_time_4 = ExcelDateTime()
    try:
        result = date_time_0.validate_or_error(value = None)
        if (result is not None):
            error = "1st test failed"
    except:
        error = "1st test failed"

# Generated at 2022-06-26 10:12:16.068550
# Unit test for constructor of class Const
def test_Const():
    Const(const = "")


# Generated at 2022-06-26 10:12:21.933577
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    # object1 is a Field
    object1 = date_time_0
    # object2 is a Field
    object2 = date_time_0
    date_time_0 | date_time_0


# Generated at 2022-06-26 10:12:35.132483
# Unit test for constructor of class Const
def test_Const():
    assert issubclass(Const, Field) == True
    const_instance_0 = Const(10)
    assert const_instance_0.const == 10
    const_instance_1 = Const(None)
    assert const_instance_1.const == None
    const_instance_2 = Const(10.5)
    assert const_instance_2.const == 10.5
    const_instance_3 = Const(False)
    assert const_instance_3.const == False
    const_instance_4 = Const(True)
    assert const_instance_4.const == True
    const_instance_5 = Const({"a":1, "b":2})
    assert const_instance_5.const == {"a":1, "b":2}
    const_instance_6 = Const([1, 2, 3, 4, 5])
   

# Generated at 2022-06-26 10:12:46.155068
# Unit test for method validate of class Array
def test_Array_validate():
    items = Field()
    additional_items = False
    min_items = None
    max_items = None
    unique_items = False
    arr = Array(items=items, additional_items=additional_items, min_items=min_items, max_items=max_items, unique_items=unique_items)
    # Test with None input
    arr.validate(None)
    # Test with a value
    arr.validate('value')


# Generated at 2022-06-26 10:12:49.271629
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    assert date_time_0.validate(None, strict=False) == None
    assert date_time_0.validate("", strict=False) == None


# Generated at 2022-06-26 10:12:56.943502
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    date_time_5 = DateTime()
    choice_0 = Choice()
    choice_0.allow_null = True
    choice_1 = Choice()
    choice_1.allow_null = True
    choice_2 = Choice()
    choice_2.allow_null = True
    choice_3 = Choice()
    choice_3.allow_null = True
    choice_4 = Choice()
    choice_4.allow_null = True
    choice_5 = Choice()
    choice_5.allow_null = True
    choice_6 = Choice()
    choice_6.allow_null = True


# Generated at 2022-06-26 10:13:03.533494
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_1 = DateTime()
    date_time_1.default = datetime(2019, 1, 1, 0, 0)
    assert date_time_1.get_default_value() == datetime(2019, 1, 1, 0, 0)


# Generated at 2022-06-26 10:13:06.089494
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    assert int == type(date_time_0)


# Generated at 2022-06-26 10:13:16.115337
# Unit test for method validate of class Number
def test_Number_validate():
    # Check if the exception is raised for invalid input
    try:
        int_0 = TypeVar('int_0')
        Number(allow_null = False, maximum = 1.0, minimum = 1.0, multiple_of = 1.0).validate(1.0)
    except ValidationError:
        pass
    else:
        assert False
    # Check if the exception is raised for invalid input
    try:
        int_1 = TypeVar('int_1')
        Number(allow_null = False, maximum = 1.0, minimum = 1.0, multiple_of = 1.0).validate(1)
    except ValidationError:
        pass
    else:
        assert False
    # Check if the exception is raised for invalid input

# Generated at 2022-06-26 10:13:35.201598
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    union_0 = date_time_0 | date_time_0


# Generated at 2022-06-26 10:13:41.362074
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test case 0
    date_time_0 = DateTime()
    array_0 = Array(items=date_time_0, additional_items=False, min_items=None, max_items=None, unique_items=False)

    # Test case 1
    date_time_1 = DateTime()
    array_1 = Array(items=[date_time_1], additional_items=False, min_items=None, max_items=None, unique_items=False)

    # Test case 2
    date_time_2 = DateTime()
    array_2 = Array(items=[date_time_2], additional_items=date_time_2, min_items=None, max_items=None, unique_items=False)

    # Test case 3
    date_time_3 = DateTime()

# Generated at 2022-06-26 10:13:46.598487
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = Field()
    date_time_0.default = "DateField"
    out_0 = date_time_0.get_default_value()
    assert out_0 == "DateField"


# Generated at 2022-06-26 10:13:51.403923
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    date_time_0.default = "2907-05-13T13:05:34.105640"
    assert date_time_0.default == "2907-05-13T13:05:34.105640"
    assert date_time_0.get_default_value() == "2907-05-13T13:05:34.105640"



# Generated at 2022-06-26 10:14:02.763279
# Unit test for method validate of class Union
def test_Union_validate():
    date_time_0 = DateTime()
    json_serialize_0 = date_time_0.serialize("2013-02-11T23:52:26.409")
    text_0 = Text()
    json_serialize_1 = text_0.serialize("hello")
    integer_0 = Integer()
    json_serialize_2 = integer_0.serialize("4")
    union_0 = Union([date_time_0, text_0, integer_0])
    validate_0 = union_0.validate("2013-02-11T23:52:26.409")
    validate_1 = union_0.validate("hello")
    validate_2 = union_0.validate("4")

if __name__ == "__main__":
    test_case_0()
    test_Union_

# Generated at 2022-06-26 10:14:13.524473
# Unit test for method validate of class Union
def test_Union_validate():
    any_of_0 = []
    any_of_0.append(String())
    any_of_0.append(Number())

    # Test case where the union is a union of a string and a number.
    union_0 = Union(any_of=any_of_0)

    assert union_0.validate(5) == 5
    assert union_0.validate("test") == "test"
    assert union_0.validate(None) is None

    # Test case where the union is a union of a string and a number.
    class TestObject(object): pass

    with pytest.raises(ValidationError) as err:
        union_0.validate(TestObject())
    assert len(err.value.messages()) == 1
    assert err.value.messages()[0].code == "union"

# Generated at 2022-06-26 10:14:25.822502
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    dict_0 = {}
    dict_0["test"] = "test"
    dict_0["dict_test"] = dict_0
    text_0 = "test"
    text_1 = ""
    text_2 = "true"
    list_0 = range(10)
    list_1 = []
    number_0 = 0
    number_1 = 1.1
    number_2 = -1.1
    number_3 = 3
    number_4 = 0.1
    number_5 = -0.1

    # Test string type
    field_0 = String(default=text_0)
    assert field_0.get_default_value() == text_0
    assert text_0 == "test"

    # Test string type with empty
    field_1 = String(default=text_1)
    assert field

# Generated at 2022-06-26 10:14:39.477619
# Unit test for method validate of class Array
def test_Array_validate():
    date_time_0 = DateTime()

    try:
        array_0 = Array(items=date_time_0)
        array_0_validate_exception_0 = None
        array_0_validate_exception_1 = None
    except ValidationError as e:
        array_0_validate_exception_0 = e
    try:
        array_0 = Array(items=[date_time_0])
        array_0_validate_exception_0 = None
        array_0_validate_exception_1 = None
    except ValidationError as e:
        array_0_validate_exception_0 = e
    array_0 = Array(items=[date_time_0, Null()])


# Generated at 2022-06-26 10:14:48.594377
# Unit test for method validate of class Array
def test_Array_validate():
    def test_case_0():
        date_time_0 = DateTime()
        array_0 = Array(items=date_time_0)

        array_1 = array_0.validate(["2018-05-08T21:28:56Z", "2020-02-25T05:32:12Z"])
        print(array_1)

        array_2 = array_0.validate((datetime(year=2004, month=3, day=12), datetime(year=2007, month=11, day=19)))
        print(array_2)

        array_3 = array_0.validate(["2018-05-08T21:28:56Z", "2018-05-01T21:28:56Z", datetime(year=2006, month=10, day=1)])


# Generated at 2022-06-26 10:14:49.806634
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test case 0
    # test case 0 should return None
    # check if the library is able to handle None input
    test_case_0()



# Generated at 2022-06-26 10:15:15.170256
# Unit test for method serialize of class Array
def test_Array_serialize():
    date_time_0 = DateTime()
    array_0 = Array(items = date_time_0)
    result = array_0.serialize([datetime.datetime(2018, 10, 10, 11, 43, 38, 699165), datetime.datetime(2018, 10, 10, 11, 43, 38, 699165)])
    assert result == ['2018-10-10T11:43:38.699165+00:00', '2018-10-10T11:43:38.699165+00:00']


# Generated at 2022-06-26 10:15:26.281540
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const(const=None)
    assert const_0.allow_null
    assert const_0.const is None
    assert const_0.messages is Const.messages
    assert const_0.const is None
    assert const_0.allow_null

    const_1 = Const(const=None, allow_null=False)
    assert not const_1.allow_null
    assert const_1.const is None
    assert const_1.messages is Const.messages
    assert const_1.const is None
    assert not const_1.allow_null

    const_2 = Const(const=1, allow_null=False)
    assert not const_2.allow_null
    assert const_2.const == 1
    assert const_2.messages is Const.messages

# Generated at 2022-06-26 10:15:28.709418
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices_0 = [("monday", "monday"), ("tuesday", "tuesday")]
    choice_0 = Choice(choices=choices_0)
    value_0 = choice_0.validate("monday")
    assert value_0 == "monday"


# Generated at 2022-06-26 10:15:37.330709
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    date_time_0 = DateTime()
    date_time_0.type = 'DateTime'
    # default_value = date_time_0.get_default_value()
    # if default_value == ' ':
    #     raise AssertionError()

    date_time_1 = DateTime()
    date_time_1.type = 'DateTime'
    date_time_1.default = ' '
    # default_value = date_time_1.get_default_value()
    # if default_value != ' ':
    #     raise AssertionError()


# Generated at 2022-06-26 10:15:43.171066
# Unit test for method serialize of class Array
def test_Array_serialize():
    array_0 = Array()
    # Uncomment below line to print all available validation errors
    # print(array_0.errors)

    array_0.items = [Integer(minimum=2, maximum=3), Integer(minimum=4, maximum=5), Integer(minimum=6, maximum=7)]
    array_0.additional_items = Boolean()
    array_0.min_items = 2
    array_0.max_items = 3
    array_0.unique_items = True

    try:
        array_0.validate([1,2,3,4])
    except ValidationError as error:
        for message in error.messages:
            print(message)
    else:
        print('Should have failed because of min_items')
        raise Exception('Should have failed because of min_items')


# Generated at 2022-06-26 10:15:50.787973
# Unit test for method validate of class Array
def test_Array_validate():
    items_0 = String()
    additional_items_0 = False
    min_items_0 = None
    max_items_0 = None
    unique_items_0 = True
    allow_null_0 = True
    array_0 = Array(allow_null=allow_null_0)
    value_0 = 13
    with pytest.raises(ValidationError, match=r"(?s).*\{\s+'code': 'type',\s+'index': \[\],\s+'message': 'Must be an array.',\s+'value': 13\s+\}.*"):
        array_0.validate(value_0)
    value_0 = None

# Generated at 2022-06-26 10:15:54.143521
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    str_0 = String()
    field_0 = date_time_0 | str_0


# Generated at 2022-06-26 10:16:00.982495
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Create a Field instance (field_0)
    date_time_0 = DateTime()
    # Call method get_default_value of field_0
    field_0_get_default_value_result = date_time_0.get_default_value()
    assert field_0_get_default_value_result is None


# Generated at 2022-06-26 10:16:04.817643
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_1 = DateTime(allow_null=False)

    date_time_1.validate(None, strict=True)
    date_time_1.validate(None, strict=False)




# Generated at 2022-06-26 10:16:11.783106
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    type_0 = Field()
    assert type_0.default == NO_DEFAULT
    assert type_0.get_default_value() == None
    type_0.default = 31
    assert type_0.default == 31
    assert type_0.get_default_value() == 31


# Generated at 2022-06-26 10:16:33.556305
# Unit test for method validate of class Number
def test_Number_validate():
    obj_Number_v_0 = Number()

    # Case 0
    obj_Number_v_0.validate(0)

    # Case 1
    obj_Number_v_0.validate(5)

    # Case 2
    obj_Number_v_0.validate(5.5)

    # Case 3
    obj_Number_v_0.validate(5.5)

    # Case 4
    obj_Number_v_0.validate(5.5)

    # Case 5
    # TODO:
    obj_Number_v_0.validate(5.5)

    # Case 6
    obj_Number_v_0.validate(5)

    # Case 7
    obj_Number_v_0.validate(5)

    # Case 8
    obj_Number_v_0

# Generated at 2022-06-26 10:16:37.854106
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Test for Field.__or__(self, other : Field) -> Union
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    field_0 = date_time_0.__or__(date_time_1)


# Generated at 2022-06-26 10:16:42.745708
# Unit test for method validate of class Number
def test_Number_validate():
    number_0 = Number()
    # Line number under test.
    assert number_0.validate(-58.9701) == -58.9701


# Generated at 2022-06-26 10:16:52.073979
# Unit test for method serialize of class Array
def test_Array_serialize():
    items_0 = String()
    test_object_0 = Array(items=items_0)
    test_obj = [
        "string_0",
        "string_1",
        "string_2",
        "string_3",
        "string_4",
        "string_5",
        "string_6",
        "string_7",
        "string_8",
        "string_9",
        "string_10",
        "string_11",
        "string_12",
        "string_13",
        "string_14",
    ]
    actual = test_object_0.serialize(test_obj)

# Generated at 2022-06-26 10:16:55.178102
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = Choice(choices=())
    date_time_1 = Choice(choices=("", None))
    date_time_2 = Choice(choices=(), allow_null=True)
    date_time_3 = Choice(choices=("", None), default=None)
    date_time_4 = Choice(choices=("", None), allow_null=True, default=None)


# Generated at 2022-06-26 10:16:58.109487
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    assert choice_0.validate('hi') == 'hi'
    assert choice_0.validate('') == ''



# Generated at 2022-06-26 10:17:11.276450
# Unit test for method validate of class Array
def test_Array_validate():
    class DateTimeItem(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def validate(self, value, *, strict=False):
            if isinstance(value, str) and value == "2020-01-01T00:00:00Z":
                return datetime(2020, 1, 1, 0, 0, 0)
            return value

        def serialize(self, value):
            return value

    date_item = DateTimeItem()
    date_array = Array(items=date_item, unique_items=True)
    _, errors = date_array.validate_or_error(["2020-01-01T00:00:00Z", "2020-01-01T00:00:00Z"])
    assert errors is not None

# Generated at 2022-06-26 10:17:22.805883
# Unit test for method validate of class Array
def test_Array_validate():

    with pytest.raises(ValidationError) as e_info:
        Array(min_items=1).validate([])
    assert e_info.value.messages == [Message(text="Must not be empty.", code="empty", index=[])]

    with pytest.raises(ValidationError) as e_info:
        Array(max_items=3).validate([1, 2, 3, 4, 5])
    assert e_info.value.messages == [Message(text="Must have no more than 3 items.", code="max_items", index=[])]

    with pytest.raises(ValidationError) as e_info:
        Array(unique_items=True).validate([1, 2, 3, 3, 4])

# Generated at 2022-06-26 10:17:26.465166
# Unit test for method serialize of class Array
def test_Array_serialize():
    array_0 = Array(additional_items=False, items=[], max_items=5)


# Generated at 2022-06-26 10:17:28.017252
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    copy_2 = date_time_0.__or__(date_time_1)


# Generated at 2022-06-26 10:17:50.635385
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time = DateTime()
    choice = Choice(date_time)
    assert choice.validate(None, strict=False) == None
    assert choice.validate(None, strict=True) == None



# Generated at 2022-06-26 10:17:51.675405
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field.__or__(None, None)


# Generated at 2022-06-26 10:17:52.743301
# Unit test for constructor of class Array
def test_Array():
    array_0 = Array()


# Generated at 2022-06-26 10:18:05.650081
# Unit test for method validate of class Choice
def test_Choice_validate():
    # validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any
    #
    # Validate and convert the given value to a valid data structure.
    #
    # Raises:
    #   ValidationError: The value is not a valid data structure.
    #
    # Returns:
    #   The converted value.

    obj = Choice(allow_null=False, choices=[("abc", "abc")])
    assert obj.validate(None, strict=False) == "abc"

    obj = Choice(allow_null=False, choices=[("abc", "abc")])
    assert obj.validate(True, strict=False) == "abc"

    obj = Choice(allow_null=False, choices=[(True, True)])
    assert obj.validate(True, strict=False) == True

# Generated at 2022-06-26 10:18:07.693666
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("") == ""


# Generated at 2022-06-26 10:18:20.256684
# Unit test for method validate of class Choice
def test_Choice_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    date_time_3 = DateTime()
    date_time_4 = DateTime()
    date_time_5 = DateTime()
    date_time_6 = DateTime()
    date_time_7 = DateTime()
    date_time_8 = DateTime()
    date_time_9 = DateTime()
    date_time_10 = DateTime()
    date_time_11 = DateTime()
    date_time_12 = DateTime()
    date_time_13 = DateTime()
    date_time_14 = DateTime()
    date_time_15 = DateTime()
    date_time_16 = DateTime()
    date_time_17 = DateTime()
   

# Generated at 2022-06-26 10:18:25.056275
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = date_time_1 | date_time_0


# Generated at 2022-06-26 10:18:39.331215
# Unit test for method validate of class Number
def test_Number_validate():
    value_0 = Number().validate(0.0)
    assert value_0 == 0.0
    value_1 = Number().validate(1.0)
    assert value_1 == 1.0
    value_2 = Number().validate(2.0)
    assert value_2 == 2.0
    value_3 = Number().validate(3.0)
    assert value_3 == 3.0
    value_4 = Number().validate(4.0)
    assert value_4 == 4.0
    value_5 = Number().validate(5.0)
    assert value_5 == 5.0
    value_6 = Number().validate(6.0)
    assert value_6 == 6.0
    value_7 = Number().validate(7.0)
    assert value_7 == 7.0

# Generated at 2022-06-26 10:18:49.320959
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test case 1:
    boolean_0 = Boolean()
    boolean_0.validate(1)

    # Test case 2:
    boolean_1 = Boolean()
    boolean_1.validate(1)

    # Test case 3:
    boolean_2 = Boolean()
    boolean_2.validate(1)

    # Test case 4:
    boolean_3 = Boolean()
    boolean_3.validate(1)

    # Test case 5:
    boolean_4 = Boolean()
    boolean_4.validate(1)



# Generated at 2022-06-26 10:18:57.662671
# Unit test for method __or__ of class Field
def test_Field___or__():
    date_time_0 = DateTime()
    date_time_template_0 = date_time_0
    date_time_1 = DateTime()
    date_time_template_1 = date_time_1

    return (date_time_template_0 | date_time_template_1)


# Generated at 2022-06-26 10:19:07.412957
# Unit test for method __or__ of class Field
def test_Field___or__():
    __or__(DateTime(), DateTime())




# Generated at 2022-06-26 10:19:14.624209
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_0 = Choice()
    value_0 = choice_0.validate(None)
    assert value_0 is None

    choice_1 = Choice(allow_null=False)
    value_1 = choice_1.validate(None)
    assert value_1 is not None
    assert isinstance(value_1, ValidationError)
    assert value_1.code == "null"

    choice_2 = Choice(allow_blank=True)
    value_2 = choice_2.validate("")
    assert value_2 is not None


# Generated at 2022-06-26 10:19:24.497396
# Unit test for method validate of class Choice
def test_Choice_validate():
    string_type_0 = String()
    string_type_1 = String()
    choices_0 = [string_type_0]
    choice_0 = Choice(choices=choices_0, default=string_type_1)
    string_0 = """45NQ:1@^YX9]N>P-_&P>%(/D/H1+G/Z"""
    result = choice_0.validate(value=string_0)
    assert string_type_1 == result


# Generated at 2022-06-26 10:19:28.490328
# Unit test for method validate of class Array
def test_Array_validate():
    date_time_0 = DateTime()
    date_time_1 = DateTime()
    date_time_2 = DateTime()
    array_0 = Array(items=date_time_0)
    array_1 = Array(items=date_time_1)
    array_2 = Array(items=date_time_2)
    array_0.validate([])


# Generated at 2022-06-26 10:19:37.217303
# Unit test for method validate of class String
def test_String_validate():
    print("Unit test for method validate of class String")
    errors = {
        "type": "Must be a string.",
        "null": "May not be null.",
        "blank": "Must not be blank.",
        "max_length": "Must have no more than {max_length} characters.",
        "min_length": "Must have at least {min_length} characters.",
        "pattern": "Must match the pattern /{pattern}/.",
        "format": "Must be a valid {format}.",
    }
    # null is not allowed
    allow_blank_0 = 'FALSE'
    trim_whitespace_0 = 'TRUE'
    max_length_0 = None
    min_length_0 = None
    pattern_0 = None
    format_0 = None
    strict_0 = 'TRUE'
   

# Generated at 2022-06-26 10:19:46.994340
# Unit test for constructor of class Array
def test_Array():
    with pytest.raises(AssertionError):
        Array(None, True, 1, 2)
    with pytest.raises(AssertionError):
        Array(None, True, 1, -2)
    assert Array(None, True, 1, 2).items == None
    assert Array(None, True, 1, 2).additional_items == True
    assert Array(None, True, 1, 2).min_items == 1
    assert Array(None, True, 1, 2).max_items == 2
