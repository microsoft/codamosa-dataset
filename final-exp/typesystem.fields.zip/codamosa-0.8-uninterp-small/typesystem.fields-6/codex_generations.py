

# Generated at 2022-06-26 10:11:37.714456
# Unit test for method serialize of class String
def test_String_serialize():
    time_0 = Time()
    ret = time_0.serialize("0")
    assert_equal(ret, "0")

    time_1 = Time(description = "description")
    ret = time_1.serialize("1")
    assert_equal(ret, "1")



# Generated at 2022-06-26 10:11:45.722409
# Unit test for method validate of class Union
def test_Union_validate():
    time_0 = Time()
    array_0 = Text()
    array_1 = Field()
    array_6 = Text()
    union_0 = Union([array_1, array_6])
    union_0.validate(array_0)
    union_0.validate(time_0)
    union_0.validate(array_0)
    array_1.validate(array_0)
    union_0.validate(array_0)
    union_0.validate(array_0)
    union_0.validate(array_0)
    union_0.validate(array_0)
    union_0.validate(array_0)
    union_0.validate(array_0)


# Generated at 2022-06-26 10:11:49.500693
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    try:
        string.validate(1)
    except :
        return True
    return False


# Generated at 2022-06-26 10:11:51.959142
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time()
    time_1 = Time()
    union_2 = time_1 | time_0
    return



# Generated at 2022-06-26 10:12:00.631701
# Unit test for method validate of class Union
def test_Union_validate():
    data_0 = Time()
    data_1 = Union([data_0])
    # Test in case strict is False, error is None
    test_value = "2020-07-20T03:33:44Z"
    expected_result = "2020-07-20T03:33:44Z"
    if data_0.validate(test_value) == expected_result:
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:12:03.267855
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    #Expected result: ValueError
    time_0 = Time()
    try:
        time_0.get_default_value()
    except ValueError:
        return True
    else:
        return False


# Generated at 2022-06-26 10:12:15.398757
# Unit test for constructor of class String
def test_String():
    sd1 = String(title='String title 1', description="String description 1")
    sd2 = String(title='String title 2', description="String description 2", allow_blank=True)
    sd3 = String(title='String title 3', description="String description 3", allow_blank=True, max_length=100)
    sd4 = String(title='String title 4', description="String description 4", allow_blank=True, max_length=100, min_length=10)
    sd5 = String(title='String title 5', description="String description 5", allow_blank=True, max_length=100, min_length=10, pattern='^\d+$')

# Generated at 2022-06-26 10:12:23.825711
# Unit test for method validate of class String
def test_String_validate():
    # String String(allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None, **kwargs)

    # 1. Test for a wrong input for max_length (max_length must be an integer)
    # Expected: an error that max_length must be an integer
    try:
        String(max_length = "Wrong input")
        assert False
    except:
        pass

    # 2. Test for a wrong input for min_length (min_length must be an integer)
    # Expected: an error that min_length must be an integer
    try:
        String(min_length = "Wrong input")
        assert False
    except:
        pass

    # 3. Test for a wrong input for pattern (pattern must be a string or a regular expression

# Generated at 2022-06-26 10:12:38.023332
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean = Boolean()
    assert boolean.validate(True) == True
    assert boolean.validate(False) == False
    assert boolean.validate(1) == True
    assert boolean.validate(0) == False
    assert boolean.validate("true") == True
    assert boolean.validate("false") == False
    assert boolean.validate("on") == True
    assert boolean.validate("off") == False
    assert boolean.validate("1") == True
    assert boolean.validate("0") == False
    assert boolean.validate("") == False
    assert boolean.validate("abc") == False # False by default (strict=False)
    assert boolean.validate(None) == None
    assert boolean.validate(None, strict = True) == None

# Generated at 2022-06-26 10:12:50.697157
# Unit test for method validate of class Union

# Generated at 2022-06-26 10:13:04.796028
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # Input Parameters
    time_0 = Time()
    time_0_value = time_0.get_default_value()
    time_0_strict = True
    # Expected Output
    time_0_expected = ValidationResult(value=None, error=time_0.validation_error("invalid"))
    # Execute Code to be Tested
    time_0_result = time_0.validate_or_error(time_0_value, strict=time_0_strict)
    # Verify Results
    assert time_0_result == time_0_expected


# Generated at 2022-06-26 10:13:15.049069
# Unit test for method validate of class String
def test_String_validate():
    field_0 = String()
    try:
        field_0.validate(value=2)
    except ValidationError as e:
        assert e.code == "type"
    else:
        assert False

    field_1 = String(allow_blank=True)
    field_1.validate(value=None)

    field_2 = String()
    try:
        field_2.validate(value="")
    except ValidationError as e:
        assert e.code == "blank"
    else:
        assert False

    field_3 = String(max_length=5)
    try:
        field_3.validate(value="123456")
    except ValidationError as e:
        assert e.code == "max_length"
    else:
        assert False


# Generated at 2022-06-26 10:13:19.670627
# Unit test for method validate of class Array
def test_Array_validate():
    error_code_0 = Array()
    try:
        error_code_0
    except Exception as exception_0:
        # Verify that it fails as expected
        assert isinstance(exception_0, AssertionError)
        return

    raise Exception("Reached an unreachable state")


# Generated at 2022-06-26 10:13:28.625038
# Unit test for method validate of class Array
def test_Array_validate():
    time_0 = Time()
    time_1 = Time('12:00:01.000')
    time_2 = Time('12:00:02.000')

    time_array = Array(items=Time(), unique_items=True)
    time_array.validate([time_0, time_1, time_2])

    with pytest.raises(ValidationError):
        time_array.validate([time_0, time_1, time_1])


# Generated at 2022-06-26 10:13:32.114763
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Case 1: Initialize a field
    field_0 = Field()
    # Case 1: Check the result
    assert field_0.get_default_value() == None



# Generated at 2022-06-26 10:13:41.997909
# Unit test for method validate of class Union
def test_Union_validate():
    time_0 = Time()

# Generated at 2022-06-26 10:13:49.354772
# Unit test for method validate of class Choice
def test_Choice_validate():
    time_0 = Time()
    choice_0 = Choice(time_0, ["0", "1"], true)
    result_0 = choice_0.validate("1", strict=false)
    assert result_0 == 1


# Generated at 2022-06-26 10:14:02.276224
# Unit test for method validate of class Array
def test_Array_validate():
    # Unit test for validating items of required integer type
    test_array = [1,2,3]
    validator = Array(Integer())
    value, error = validator.validate_or_error(test_array)

    assert value == [1,2,3]
    assert error is None

    # Unit test for validating items of required array of integer type
    test_array = [[1,2,3],[4,5,6]]
    validator = Array(Array(Integer()))
    value, error = validator.validate_or_error(test_array)

    assert value == [[1,2,3],[4,5,6]]
    assert error is None

    # Unit test for validating items of required array of object type

# Generated at 2022-06-26 10:14:13.398579
# Unit test for method validate of class Array
def test_Array_validate():
    time_0 = Time()
    time_1 = Time()
    time_2 = Time()
    time_3 = Time()
    time_4 = Time()

    time_0.hour = 1
    time_0.minute = 1
    time_0.second = 1
    time_0.microsecond = 1

    time_1.hour = 1
    time_1.minute = 1
    time_1.second = 1
    time_1.microsecond = 1

    time_2.hour = 1
    time_2.minute = 1
    time_2.second = 1
    time_2.microsecond = 1

    time_3.hour = 2
    time_3.minute = 2
    time_3.second = 2
    time_3.microsecond = 2

    time_4.hour = 2
    time

# Generated at 2022-06-26 10:14:22.785177
# Unit test for method validate of class Array
def test_Array_validate():
    class_0 = Array()
    assert class_0.validate(None) == None
    assert class_0.validate([]) == []
    assert class_0.validate(["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]) == ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]


# Generated at 2022-06-26 10:14:46.485792
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = [(1, 'one'), (2, 'two')])
    assert choice.validate(value = 1) == 1
    assert choice.validate(value = 2) == 2
    try:
        choice.validate(value = 3)
        assert False
    except ValidationError:
        assert True
    try:
        choice.validate(value = "1")
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-26 10:14:59.134978
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices = [(str(i),str(i)) for i in range(10)]) # Create a Choice object
    assert obj.validate(None, strict = False) == None # Test case where allow_null = True and value = None
    assert obj.validate(None, strict = True) == None # Test case where allow_null = True, strict = True and value = None
    assert obj.validate(5, strict = False) == 5  # Test case where strict = False and value = a valid choice
    assert obj.validate(5, strict = True) == 5  # Test case where strict = True and value = a valid choice

# Generated at 2022-06-26 10:15:06.554666
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_0 = Time()
    decimal_0 = Decimal(maximum=444444444444444444444444444444444444444444)
    time_0 | decimal_0

    time_1 = Time()
    decimal_1 = Decimal(maximum=9223372036854775808)
    time_1 | decimal_1
    

# Generated at 2022-06-26 10:15:10.045448
# Unit test for method validate of class Choice
def test_Choice_validate():
    val = Choice()
    assert val.validate("choice")=="choice"
    assert val.validate(1)==1


# Generated at 2022-06-26 10:15:16.275962
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [
        String(max_length=10, min_length=1),
        String(max_length=20, min_length=2),
        String(max_length=30, min_length=3),
    ]
    obj = ["1", "22", "333"]
    obj_serialized = ["1", "22", "333"]
    assert Array(items=items).serialize(obj) == obj_serialized


# Generated at 2022-06-26 10:15:18.163514
# Unit test for constructor of class Choice
def test_Choice():
    choices = [('A', 'B'), ('C', 'D')]
    assert Choice(choices=choices).choices == choices


# Generated at 2022-06-26 10:15:21.236684
# Unit test for method validate of class Object
def test_Object_validate():
    properties = {
        'a': Integer()
    }
    kwargs = dict()
    input = {'a': 20}
    result = Object(properties=properties).validate(input)
    assert result == input


# Generated at 2022-06-26 10:15:34.587272
# Unit test for method validate of class Choice

# Generated at 2022-06-26 10:15:48.036771
# Unit test for method validate of class Object
def test_Object_validate():
    def check_result(obj: Object, value: typing.Any, expected_result: typing.Any):
        result = obj.validate(value)
        assert result == expected_result

    # Build a property dictionary
    field_1 = String()
    field_2 = Integer()
    properties: typing.Dict[str, Field] = {
        'str': field_1,
        'int': field_2
    }
    obj_1 = Object(properties=properties)
    check_result(obj_1, {}, {})
    check_result(obj_1, {'str': 'string'}, {'str': 'string'})
    check_result(obj_1, None, None)
    string_schema = String(required=True)
    obj_2 = Object(properties={'name': string_schema})


# Generated at 2022-06-26 10:15:52.649184
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_field = Choice(choices=[('b', 'B'),('c', 'C'),('a', 'A')])
    try:
        choice_field.validate('a')
    except ValidationError as error:
        assert error.text == "Not a valid choice."
        assert error.code == "choice"


# Generated at 2022-06-26 10:16:17.251101
# Unit test for method validate of class Number
def test_Number_validate():
    num_0 = Number()
    num_0.validate(value=0.0)

    num_1 = Number()
    num_1.validate(value=1)

    num_2 = Number()
    num_2.validate(value="test_validate_cases")



# Generated at 2022-06-26 10:16:24.933176
# Unit test for method validate of class Array
def test_Array_validate():
    # Test for a valid value
    items = [String(), Integer(), Boolean()]
    array_0 = Array(items=items)
    test_value = [1, "a", True]
    assert array_0.validate(test_value) == test_value

    # Test for a valid value that is null
    items = [String(), Integer(), Boolean()]
    array_1 = Array(items=items)
    test_value = None
    assert array_1.validate(test_value) == test_value

    # Test for an invalid value
    items = [String(), Integer(), Boolean()]
    array_2 = Array(items=items)
    test_value = [1, "a", True, 2.5]

# Generated at 2022-06-26 10:16:26.286006
# Unit test for constructor of class Const
def test_Const():
    Const('test_data_0')


# Generated at 2022-06-26 10:16:32.391091
# Unit test for method validate of class String
def test_String_validate():
    from typesystem.string import String
    print("~~~~~~~TEST CASE~~~~~~~")
    test_s = String(max_length = 2, allow_null = False)
    assert(test_s.validate("12") == "12")
    print("PASS")


# Generated at 2022-06-26 10:16:39.463286
# Unit test for method validate of class Array
def test_Array_validate():
    print("Test Array validate.")

    array_0 = Array(
        items=Field(type=FieldType.INTEGER),
        additional_items=False,
        min_items=3,
        max_items=3,
    )

    try:
        array_0.validate([])

        assert False

    except ValidationError as e:
        assert e.messages(add_prefix=None, use_codes=False) == [
            "Must not be empty.",
            "Must have 3 items.",
        ]


# Generated at 2022-06-26 10:16:43.574815
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f0 = Field()
    expected = None
    actual = f0.get_default_value()
    assert actual == expected


# Generated at 2022-06-26 10:16:47.590587
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=["one", "two", "three"])
    assert field.validate("one") == "one"
    assert field.validate("one") == "one"


# Generated at 2022-06-26 10:16:59.855817
# Unit test for method validate of class Union
def test_Union_validate():
    # Variables initialization
    any_of_0 = []
    any_of_0.append(Integer(allow_null=False, default=None, description=None, format=None, title=None, maximum=None, minimum=None, multiple_of=None, default_factory=None, allow_coerce=True, error_messages={'type': 'Must be an integer.', 'null': 'May not be null.', 'minimum': 'Must be at least {minimum}.', 'maximum': 'Must be no greater than {maximum}.'}, validate_always=False))
    error_messages_0 = {}
    error_messages_0['null'] = 'May not be null.'
    error_messages_0['union'] = 'Did not match any valid type.'

# Generated at 2022-06-26 10:17:03.120093
# Unit test for method validate of class Choice
def test_Choice_validate():
    time_0 = Time()
    time_0.validate(None)



# Generated at 2022-06-26 10:17:08.407701
# Unit test for method validate of class Number
def test_Number_validate():
    # Case 0
    int_0 = Integer(allow_null = False)
    value_0 = None
    try:
        int_0.validate(value_0, strict = False)
    except:
        pass
    return 1


# Generated at 2022-06-26 10:17:23.840739
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices=['a', 'b', 'c'])
    assert obj.validate('a') == 'a'
    assert obj.validate('b') == 'b'
    assert obj.validate('c') == 'c'

    obj = Choice(choices=['a', 'b', 'c'], allow_null=True)
    assert obj.validate('a') == 'a'
    assert obj.validate('b') == 'b'
    assert obj.validate('c') == 'c'
    assert obj.validate('') == ''

    obj = Choice(choices=['a', 'b', 'c'], allow_blank=False)
    assert obj.validate('a') == 'a'
    assert obj.validate('b') == 'b'
    assert obj.validate

# Generated at 2022-06-26 10:17:34.343679
# Unit test for method validate of class Array
def test_Array_validate():
    schema_0 = Array()
    target_0 = [1, 2, 3]
    print(schema_0.validate(target_0))

    schema_1 = Array(min_items=2)
    target_1 = [1, 2, 3]
    print(schema_1.validate(target_1))

    schema_2 = Array(items=Integer(maximum=100))
    target_2 = [1, 2, 3, 4]
    print(schema_2.validate(target_2))

    schema_3 = Array(items=[Integer(), String()])
    target_3 = [1, 2, 3, 'a']
    print(schema_3.validate(target_3))


# Generated at 2022-06-26 10:17:38.536370
# Unit test for method __or__ of class Field
def test_Field___or__():
    time_1 = Time()
    time_2 = Time()
    time_3 = time_1 | time_2
    assert(isinstance(time_3, Union))


# Generated at 2022-06-26 10:17:40.734083
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=[]) == Choice(choices=[])


# Generated at 2022-06-26 10:17:55.155785
# Unit test for method validate of class Union
def test_Union_validate():
    #print('test_Union_validate')

    # Case 0:
    #  Scenario:
    #     1. value = None
    #     2. allow_null = True

    # Assertions:
    #     1. Returns None.
    time_0 = Time()
    assert Union([time_0], allow_null = True).validate(None) is None

    # Case 1:
    #  Scenario:
    #     1. value = None
    #     2. allow_null = True

    # Assertions:
    #     1. If allow_null is not equal True, an instance of ValidationError
    #        is raised.
    time_1 = Time()

# Generated at 2022-06-26 10:18:07.619258
# Unit test for method validate of class Choice
def test_Choice_validate():
    # time_1 = Time()
    time_2 = Time(format="%H:%M:%S")
    time_3 = Time(format="%H%M%S")
    time_4 = Time(format="%I:%M:%S %p")
    # time_5 = Time(format="%I%M%S %p")
    # time_6 = Time(format="%I:%M %p")
    # time_7 = Time(format="%I%M %p")
    time_8 = Time(format="%H:%M")
    time_9 = Time(format="%H%M")

    correct_result_1_1 = Time(format="%H:%M:%S").validate("01:23:45")

# Generated at 2022-06-26 10:18:20.215704
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import Time
    time_0 = Time()
    time_1 = Time()
    time_2 = Time()
    time_3 = Time()
    time_4 = Time()
    time_5 = Time()

    assert isinstance(time_0, Field), "Expected a type of Field"
    assert isinstance(time_1, Field), "Expected a type of Field"
    assert isinstance(time_2, Field), "Expected a type of Field"
    assert isinstance(time_3, Field), "Expected a type of Field"
    assert isinstance(time_4, Field), "Expected a type of Field"
    assert isinstance(time_5, Field), "Expected a type of Field"

    result_0 = time_0 | time_1
    result_1 = time_2 | time_

# Generated at 2022-06-26 10:18:22.826960
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("hello") == "hello"


# Generated at 2022-06-26 10:18:26.521626
# Unit test for constructor of class String
def test_String():
    title_0 = String()
    category_0 = String(allow_blank=False, max_length=128)
    keyword_0 = String(allow_blank=True, max_length=128)



# Generated at 2022-06-26 10:18:39.631416
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test case when value is a key in choices
    choice_0 = Choice(choices = [("key_0", "value_0"), ("key_1", "value_1")])
    choice_0.validate("key_0")
    # Test case when value is not the key in choices but blank is allowed and value is blank
    choice_1 = Choice(choices = [("key_0", "value_0"), ("key_1", "value_1")], allow_blank = True)
    choice_1.validate("")
    # Test case when value is not in choices
    with pytest.raises(ValidationError):
        choice_2 = Choice(choices = [("key_0", "value_0"), ("key_1", "value_1")], strict = True)

# Generated at 2022-06-26 10:19:01.569795
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Case 0
    bool_0 = Boolean()
    bool_0.allow_null = True
    bool_0.validate(None)
    # Case 1
    bool_1 = Boolean()
    bool_1.allow_null = True
    try:
        bool_1.validate(None)
    #except ValidationError as e:
    #    print(e)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:19:12.828030
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = [
        ("coffee", "Coffee"),
        ("tea", "Tea"),
        ("beer", "Beer"),
        ("gin", "Gin"),
    ]
    choice = Choice(choices=choices)
    assert choice.validate(choices[0][0]) == choices[0][0]
    assert choice.validate(choices[1][0]) == choices[1][0]
    assert choice.validate(choices[2][0]) == choices[2][0]
    assert choice.validate(choices[3][0]) == choices[3][0]



# Generated at 2022-06-26 10:19:26.468427
# Unit test for constructor of class Choice
def test_Choice():
    field = Choice(allow_null=True)
    assert field.errors == {"null": "May not be null.", "required": "This field is required.", "choice": "Not a valid choice."}
    assert field.choices == []

    field = Choice(allow_null=True, choices=[])
    assert field.errors == {"null": "May not be null.", "required": "This field is required.", "choice": "Not a valid choice."}
    assert field.choices == []

    field = Choice(allow_null=True, choices=["a", "b"])
    assert field.errors == {"null": "May not be null.", "required": "This field is required.", "choice": "Not a valid choice."}
    assert field.choices == [('a', 'a'), ('b', 'b')]


# Generated at 2022-06-26 10:19:36.497489
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices=[("N", "New Zealand"), ("A", "Australia"), ("B", "Brazil")])
    assert choice.validate("N") == "N"
    assert choice.validate("A") == "A"
    assert choice.validate("B") == "B"
    try:
        choice.validate("C")
        raise Exception("Expected a ValidationError when validating a value that doesn't match any of the choices")
    except ValidationError:
        pass
    try:
        choice = Choice(choices=[("N", "New Zealand"), ("A", "Australia"), ("N", "Brazil")])
        raise Exception("Expected an AssertionError when instantiating a choice field with duplicate values")
    except AssertionError:
        pass