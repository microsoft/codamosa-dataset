

# Generated at 2022-06-26 10:11:28.054094
# Unit test for method __or__ of class Field
def test_Field___or__():
    print("\nTest Method __or__ of class Field")
    print("Return type of __or__: ", type(test_case_0()))
    print("Expected: ", str(type(Union)))



# Generated at 2022-06-26 10:11:29.001268
# Unit test for method validate of class Union
def test_Union_validate():
    text_0 = Text(max_length=40)

# Generated at 2022-06-26 10:11:39.245178
# Unit test for method validate of class Union
def test_Union_validate():
    import json
    import time
    import datetime
    import dateutil.parser
    import io

    class Test_Union_validate(unittest.TestCase):
        def test_00(self):
            # Test validate of schema string:text
            text_0_instance = Text(max_length=42)
            self.assertEqual(text_0_instance.max_length, 42)
            value_0 = "iNqN3fCSVNpY6UO7iUWQ"
            result = text_0_instance.validate(value_0, strict=True)
            self.assertEqual(result, value_0)

        def test_01(self):
            # Test validate of schema string:date
            date_0_instance = Date()

# Generated at 2022-06-26 10:11:52.715776
# Unit test for method validate of class Array
def test_Array_validate():
    text_0 = Text()
    text_0_clone_0 = text_0.clone()
    text_0_clone_1 = text_0.clone()
    text_0_clone_2 = text_0.clone()
    text_0_clone_3 = text_0.clone()
    text_0_clone_4 = text_0.clone()
    text_0_clone_5 = text_0.clone()
    text_0_clone_6 = text_0.clone()
    text_0_clone_7 = text_0.clone()
    text_0_clone_8 = text_0.clone()
    text_0_clone_9 = text_0.clone()
    text_0_clone_10 = text_0.clone()
    text_0_clone_11 = text_0.clone()

# Generated at 2022-06-26 10:11:54.113236
# Unit test for constructor of class Const
def test_Const():
    assert Const(const=1).const == 1

# Generated at 2022-06-26 10:11:59.901037
# Unit test for method serialize of class String
def test_String_serialize():
    print("Test: test_String_serialize")
    text_0 = String(description="It is a string field.")
    assert text_0.serialize("abc") == "abc"
    print("Test: test_String_serialize success")


# Generated at 2022-06-26 10:12:05.062181
# Unit test for method validate of class Array
def test_Array_validate():
    a = Array()
    assert a.validate_or_error(["foo"]) is not None
    assert a.validate_or_error(["foo","bar"]) is not None
    assert a.validate_or_error(["foo","baz"]) is not None
    assert a.validate_or_error(["foo","bar","baz"]) is not None
    assert a.validate_or_error(["foo","bar","baz","abc"]) is not None


# Generated at 2022-06-26 10:12:12.379663
# Unit test for method validate of class Array
def test_Array_validate():
    # Test case Array with argument parameter unique_items equal to False
    items_1 = 4
    t = Array(items = items_1, unique_items = False)
    text = Text()
    t = Array(items = text)
    try:
        t.validate([3,3])
    except ValidationError as e:
        print(e.messages())


# Generated at 2022-06-26 10:12:18.146248
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices0 = Choice(choices=['choice'])
    result0 = choices0.validate('choice', strict=False)
    assert result0 == 'choice'


# Generated at 2022-06-26 10:12:19.780872
# Unit test for method serialize of class String
def test_String_serialize():
    text_0 = String()
    assert text_0.serialize('this is a test string') == 'this is a test string'



# Generated at 2022-06-26 10:12:57.508459
# Unit test for method validate of class String
def test_String_validate():

    # TypeError
    try:
        text_0 = String()
        obj_0 = text_0.validate(value=3)
    except TypeError:
        pass

    # ValueError
    try:
        text_0 = String()
        obj_0 = text_0.validate(value=str([]))
    except ValueError:
        pass

    # TypeError
    try:
        text_0 = String()
        obj_0 = text_0.validate(value=3)
    except TypeError:
        pass

    # TypeError
    try:
        text_0 = String()
        obj_0 = text_0.validate(value=3)
    except TypeError:
        pass

    # ValueError

# Generated at 2022-06-26 10:13:09.367330
# Unit test for method validate of class Object
def test_Object_validate():
    foo_validate_additional_properties_dict = {'item_string': 'item_string_value', 'item_bool': True, 'item_int': 1, 'item_float': 1.1, 'item_array': ['item_array_value'], 'item_object': {'item_object_obj_int': 1, 'item_object_obj_float': 1.1, 'item_object_obj_string': 'item_object_obj_string_value', 'item_object_obj_bool': True, 'item_object_obj_array': ['item_object_obj_array_value']}, 'item_null': None}
    foo_validate_additional_properties_field = Field()
    foo_validate_additional_properties_field.set_default_value(1.1)
    # Object.validate()

# Generated at 2022-06-26 10:13:13.187956
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 10:13:18.989970
# Unit test for constructor of class Const
def test_Const():
    const_0 = Const(3)



# Generated at 2022-06-26 10:13:20.578664
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert test_case_0() == None


# Generated at 2022-06-26 10:13:32.024313
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    Field = [text_0, text_1, text_2, text_3]
    import random
    random.setup()
    method_name = "__or__"
    exceptions = []
    method_arguments = []
    method_results = []
    error_cases = []
#
    text_0_copy = Text()
    text_1_copy = Text()
    text_2_copy = Text()
    text_3_copy = Text()

# Generated at 2022-06-26 10:13:39.147080
# Unit test for method validate of class String
def test_String_validate():
    # Simple test case with no parameter values
    test_case_0()
    # Simple test case with one parameter value
    test_String_validate_1()
    # Simple test case with two parameter values
    test_String_validate_2()
    # Simple test case with three parameter values
    test_String_validate_3()
    # Simple test case with four parameter values
    test_String_validate_4()
    # Test case with multiple parameter values
    # test_String_validate_5()


# Generated at 2022-06-26 10:13:42.232257
# Unit test for method serialize of class String
def test_String_serialize():
    obj = ""
    assert String().serialize(obj) == ""
    text_0 = Text()


# Generated at 2022-06-26 10:13:52.889538
# Unit test for method validate of class Union
def test_Union_validate():
    class_0 = Integer(const=1)
    class_1 = Integer(const=2)
    class_2 = Union([class_0, class_1])
    class_2.validate(2)
    class_2.validate(1)

    # Test error case "union"
    with pytest.raises(ValidationError) as error:
        class_2.validate(0)
    assert str(error.value) == "Did not match any valid type."

    # Test error case "null"
    with pytest.raises(ValidationError) as error:
        class_2.validate(None)
    assert str(error.value) == "May not be null."


# Generated at 2022-06-26 10:13:55.243206
# Unit test for method validate of class Array
def test_Array_validate():
    field_0 = Array(items=Text())
    field_0.validate([""])



# Generated at 2022-06-26 10:14:16.895041
# Unit test for method validate of class Array
def test_Array_validate():
    items_0 = None
    additional_items_0 = False
    min_items_0 = None
    max_items_0 = None
    unique_items_0 = False

    # default values
    arr_0 = Array(items=items_0, additional_items=additional_items_0, 
            min_items=min_items_0, max_items=max_items_0, unique_items=unique_items_0)
    try:
        arr_0.validate([1,2,3])
    except ValidationError as e:
        assert False, "should not raise ValidationError"
    try:
        arr_0.validate([])
    except ValidationError as e:
        assert False, "should not raise ValidationError"

# Generated at 2022-06-26 10:14:22.915105
# Unit test for method validate of class Choice
def test_Choice_validate():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()

    text_0.validate()
    text_1.validate()
    text_2.validate()
    text_3.validate()


# Generated at 2022-06-26 10:14:26.763618
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    text_1 = Text()
    field_0 = text_0 | text_1


# Generated at 2022-06-26 10:14:28.486188
# Unit test for constructor of class Const
def test_Const():
    test_case_0()


if __name__ == "__main__":
    import pytest
    import sys

    res = pytest.main(["-x", __file__] + sys.argv[1:])
    sys.exit(res)

# Generated at 2022-06-26 10:14:30.982714
# Unit test for constructor of class Const
def test_Const():
    const_ex = Const()
    if const_ex:
        pass


# Generated at 2022-06-26 10:14:33.564167
# Unit test for constructor of class Const
def test_Const():
    test_case_0() # unit test to check Const(const={None}) and Text()

# Generated at 2022-06-26 10:14:36.272079
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    text_1 = Text()
    text_0__or__text_1 = text_0.__or__(text_1)
    assert text_0__or__text_1


# Generated at 2022-06-26 10:14:40.078801
# Unit test for method validate of class String
def test_String_validate():
    text_0 = String("title", "description", False)
    text_0.validate("Hello World")


# Generated at 2022-06-26 10:14:46.359737
# Unit test for method validate of class Choice
def test_Choice_validate():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()
    text_6 = Text()
    text_7 = Text()

    text_0.validate()

    text_1.validate(1)

    text_2.validate(True)

    text_3.validate([])

    text_4.validate(())

    text_5.validate({})

    text_6.validate("")

    text_7.validate(None)



# Generated at 2022-06-26 10:14:59.102447
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Test type error
    try:
        number_0 = Integer()
        choice_0 = Choice(choices=[1, 2])
        choice_0.validate(number_0)
    except ValidationError:
        pass

    # Test type error
    try:
        string_0 = String()
        choice_1 = Choice(choices=["#", "&", "@", "%", "$"])
        choice_1.validate(string_0)
    except ValidationError:
        pass

    # Test type error
    try:
        float_0 = Float()
        choice_2 = Choice(choices=[1.01, 2.01, 3.01])
        choice_2.validate(float_0)
    except ValidationError:
        pass

    # Test type error

# Generated at 2022-06-26 10:15:17.344706
# Unit test for method validate of class Choice
def test_Choice_validate():
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_5 = Text()
    text_6 = Text()
    text_7 = Text()
    text_8 = Text()
    text_9 = Text()
    text_10 = Text()
    text_11 = Text()
    text_12 = Text()
    text_13 = Text()
    text_14 = Text()
    text_15 = Text()
    text_16 = Text()
    text_17 = Text()
    text_18 = Text()
    text_19 = Text()
    text_20 = Text()
    text_21 = Text()
    text_22 = Text()
    text_23 = Text()
    text_24 = Text()

# Generated at 2022-06-26 10:15:25.853833
# Unit test for method validate of class Choice
def test_Choice_validate():
    test_choices = ["hello", "world"]
    test_case_0 = Choice(choices = test_choices)
    test_case_1 = Choice(choices = [("hello", "world")])
    test_case_2 = Choice(choices = None)

    res_0 = test_case_0.validate("hello")
    res_1 = test_case_1.validate("hello")
    res_2 = test_case_2.validate("hello")

    assert res_0 == "hello"
    assert res_1 == "hello"
    assert res_2 == "hello"


# Generated at 2022-06-26 10:15:34.324699
# Unit test for method serialize of class Array
def test_Array_serialize():
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()

# Generated at 2022-06-26 10:15:37.253256
# Unit test for method validate of class Array
def test_Array_validate():
    text_0 = Text()
    array_0 = Array(items=text_0)


# Generated at 2022-06-26 10:15:45.278223
# Unit test for method serialize of class String
def test_String_serialize():
    # Test empty String
    text_0 = String()
    assert text_0.serialize("test") == "test"

    # Test with format
    text_1 = String(format="date")
    assert text_1.serialize("test") == "test"
    assert text_1.serialize("2018-01-01") == "2018-01-01"


# Generated at 2022-06-26 10:15:47.054684
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    number_0 = Number()
    union_0 = text_0 | number_0


# Generated at 2022-06-26 10:15:56.461678
# Unit test for method validate of class String
def test_String_validate():
    try:
        text_1 = String(title = "text_1", description = "text_1", default = "", allow_null = False)
        text_1.validate("")
        assert True
    except ValidationError:
        assert False
    try:
        text_2 = String(title = "text_2", description = "text_2", default = None, allow_null = True)
        text_2.validate("")
        assert True
    except ValidationError:
        assert False
    try:
        text_2.validate(1)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-26 10:16:07.666342
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # TC0
    text_0 = Text()
    if type(text_0.get_default_value()) != None:
        raise AssertionError
    # TCU1
    text_1 = Text(allow_null=True)
    if text_1.get_default_value() != None:
        raise AssertionError
    # TCU2
    text_2 = Text(allow_null=False)
    if text_2.get_default_value() != None:
        raise AssertionError
    # TE1
    text_3 = Text(default=1)
    if text_3.get_default_value() != 1:
        raise AssertionError
    # TE2
    text_4 = Text(default=1, allow_null=True)

# Generated at 2022-06-26 10:16:09.301856
# Unit test for method __or__ of class Field
def test_Field___or__():
    test_case_0()



# Generated at 2022-06-26 10:16:10.923324
# Unit test for method serialize of class String
def test_String_serialize():
    test_case_0()

# Generated at 2022-06-26 10:16:20.147944
# Unit test for method validate of class Object
def test_Object_validate():
    # Case 0: empty fields
    class Foo(Object):
        pass
    obj = Foo()
    result = obj.validate("test")
    assert result == "test"


# Generated at 2022-06-26 10:16:29.710663
# Unit test for constructor of class String
def test_String():
    field = String(title='title')
    assert field.title == 'title'
    assert field.description == ""
    assert not hasattr(field,"default")
    assert field.allow_null == False
    assert field.get_default_value() == None
    assert field._creation_counter == 1
    assert field.errors == {
        "type": "Must be a string.",
        "null": "May not be null.",
        "blank": "Must not be blank.",
        "max_length": "Must have no more than {max_length} characters.",
        "min_length": "Must have at least {min_length} characters.",
        "pattern": "Must match the pattern /{pattern}/.",
        "format": "Must be a valid {format}.",
    }
    assert field.allow_blank == False

# Generated at 2022-06-26 10:16:36.023845
# Unit test for method validate of class Object
def test_Object_validate():
    # create Object for test
    properties = {"name": Text()}
    obj = Object(properties = properties, required = ['name'])

    # test invalid input
    try:
        obj.validate({"name": "lulu", "age": "12"})
    except ValidationError as e:
        print("object validate test passed")



# Generated at 2022-06-26 10:16:49.735355
# Unit test for method validate of class Array
def test_Array_validate():
    test_list_0 = Array(max_items=10)
    test_list_1 = Array(min_items=1)
    test_list_2 = Array()
    test_list_3 = Array(min_items=5)
    test_list_4 = Array(max_items=1)
    test_list_5 = Array(max_items=10)
    test_list_6 = Array(min_items=1)
    test_list_7 = Array()
    test_list_8 = Array(min_items=2,max_items=3)
    test_list_9 = Array(min_items=1)
    test_list_10 = Array(max_items=10)
    test_list_11 = Array(min_items=1)
    test_list_12 = Array()
    test_

# Generated at 2022-06-26 10:16:57.600981
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Text()]
    union = Union(any_of)
    try:
        union.validate(1)
        assert False
    except ValidationError as error:
        assert error.messages()[0].code == "union"
    try:
        union.validate("test")
        union.validate("test")
    except ValidationError as error:
        assert False


# Generated at 2022-06-26 10:17:00.789084
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    n.validate("a") # raises ValidationError

# Module test for class Number

# Generated at 2022-06-26 10:17:12.143997
# Unit test for method __or__ of class Field
def test_Field___or__():
    text_0 = Text()
    m = Map()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
    text_3 = Text()
    text_4 = Text()
    text_0 = Text()
    text_1 = Text()
    text_2 = Text()
   

# Generated at 2022-06-26 10:17:21.480483
# Unit test for method validate of class Array
def test_Array_validate():
    x = Array(min_items=10)

    # Test case 0
    assert x.validate(["a"]*10) == ["a"]*10

    # Test case 1
    # assert x.validate(["a"]*2) == ["a"]*2 # type: ignore

    # Test case 2
    x = Array(items=Integer())
    assert x.validate([1,2]) == [1,2]
    # assert x.validate(["1","2"]) == ["1","2"] # type: ignore


# Generated at 2022-06-26 10:17:32.930014
# Unit test for method serialize of class Array
def test_Array_serialize():
    # Test with a field that is not an array.
    assert Text().serialize("hello") == "hello"

    # Test with a field that is an array.
    text_serializer = Text()
    array_serializer = Array(items=text_serializer)
    assert array_serializer.serialize(["hello"]) == ["hello"]

    # Test with a field that is an array and has additional fields.
    text_serializer = Text()
    array_serializer = Array(items=text_serializer, additional_items=text_serializer)
    assert array_serializer.serialize(["hello", "world"]) == ["hello", "world"]



# Generated at 2022-06-26 10:17:41.447854
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    """
    get_default_value()
    """
    try:
        # Setup
        text_0 = Text()
        text_0.default = 3
        # Exercise
        result_0 = text_0.get_default_value()
        # Verify
        assert result_0 == 3
    except (Exception, e):
        print("Exception in testcase:\n", e)

test_case_0()
test_Field_get_default_value()

# Generated at 2022-06-26 10:18:05.798399
# Unit test for constructor of class Const
def test_Const():
    # Case 1: A constant field (const) is initialized and the value of the field is set to 1
    # The value of the field must be a number
    t1 = Const(1, allow_null = True)
    # Case 2: A constant field (const) is initialized and the value of the field is set to "Hello World"
    # The value of the field must be a string
    t2 = Const("Hello World")
    # Case 3: A constant field (const) is initialized and the value of the field is set to True
    # The value of the field must be a boolean value
    t3 = Const(True, always_return = True)
    # Case 4: A constant field (const) is initialized and the value of the field is set to Null
    # The value of the field must be Null

# Generated at 2022-06-26 10:18:10.290667
# Unit test for method validate of class String
def test_String_validate():
    assert String().validate("test") is not None
    assert String().validate("") is not None
    try:
        result = String().validate(None)
    except Exception:
        pass

# Generated at 2022-06-26 10:18:21.952646
# Unit test for method validate of class Object
def test_Object_validate():
    import pytest
    properties={'name': {'type': 'string'}, 'age': {'type': 'integer'}}
    error_messages=[{'code': 'required', 'text': 'This field is required.', 'index': ['name']}]
    obj = Object(properties=properties,required=['name'])
    value = {}
    with pytest.raises(ValidationError) as e:
        result = obj.validate(value)
    assert e.value.messages == error_messages

    # unit test for method validate_or_error of class Object
    value = {}
    expected = None
    actual = obj.validate_or_error(value)
    assert expected == actual

# unit test for method add_field_to_schema of class Object

# Generated at 2022-06-26 10:18:30.541149
# Unit test for method validate of class Array
def test_Array_validate():
    array_0 = Array()
    try:
        array_0.validate([""])
    except ValidationError as err:
        pass
    except:
        raise RuntimeError("Test Failed")

    array_1 = Array()
    try:
        array_1.validate([""])
    except ValidationError as err:
        pass
    except:
        raise RuntimeError("Test Failed")

    array_2 = Array()
    try:
        array_2.validate([""])
    except ValidationError as err:
        pass
    except:
        raise RuntimeError("Test Failed")

    array_3 = Array()
    try:
        array_3.validate([""])
    except ValidationError as err:
        pass
    except:
        raise RuntimeError("Test Failed")

    array_

# Generated at 2022-06-26 10:18:36.744398
# Unit test for method __or__ of class Field
def test_Field___or__():
    field_0 = Text()
    field_1 = Text()
    unionField = field_0 | field_1
    # print(str(unionField))
    # print(str(unionField.any_of[0]))
    assert type(Union) == type(unionField)

# Generated at 2022-06-26 10:18:50.624220
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice().validate("value") == "value"
    assert Choice().validate("") == ""
    assert Choice().validate(None) == None
    assert Choice().validate("value", strict = True) == "value"
    assert Choice().validate("", strict = True) == ""
    #assert Choice().validate(None, strict = True) == None
    assert Choice(choices = ["choice0", "choice1"]).validate("choice0") == "choice0"
    #assert Choice(choices = ["choice0", "choice1"]).validate("choice2") == None
    #assert Choice(choices = ["choice0", "choice1"]).validate("choice2", strict = True) == None

# Generated at 2022-06-26 10:19:03.518098
# Unit test for method validate of class String
def test_String_validate():
    # Test case 0
    value = "String Field"
    assert len(value) == len("String Field")
    assert type(value) is type("String Field")
    assert value == "String Field"

    # Test case 1
    value = "String Field"
    assert len(value) == len("String Field")
    assert type(value) is type("String Field")
    assert value == "String Field"

    # Test case 2
    value = "String Field"
    assert len(value) == len("String Field")
    assert type(value) is type("String Field")
    assert value == "String Field"

    # Test case 3
    # Test case 3
    value = "String Field"
    assert len(value) == len("String Field")
    assert type(value) is type("String Field")

# Generated at 2022-06-26 10:19:15.126318
# Unit test for method validate of class Number
def test_Number_validate():
    # Testing input values for validating against a given range of Int type
    test_values_int = [
        (-1, 0),
        (0, 0),
        (1, 0),
        ("-1", 0),
        ("0", 0),
        ("1", 0),
        (2.5, 1),
        ("2.5", 1),
        ("a", 1),
        ("", 1),
        ("", 1),
        (None, 1),
        (True, 1),
        (False, 1),
    ]

    # Testing input values for validating against a given range of Float type

# Generated at 2022-06-26 10:19:21.026129
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Case 0
    text_0 = Text()
    text_1 = Text()
    text_2 = text_0 | text_1
    assert isinstance(text_2, Union)



# Generated at 2022-06-26 10:19:24.316132
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice_field = Choice()
    assert choice_field.validate('test') == 'test'

# Run all unit tests
test_Choice_validate()
test_case_0()


# Generated at 2022-06-26 10:19:44.587826
# Unit test for method validate of class Object
def test_Object_validate():
    o = Object()

    assert o.validate({}) is not None
    assert o.validate({}) == {}
    assert o.validate({"key": "value"}) is not None
    assert o.validate({"key": "value"}) == {"key": "value"}
    assert o.validate([]) is None
