

# Generated at 2022-06-22 05:48:08.797677
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field.validate_or_error(None, strict=False) == ValidationResult(value=None, error=ValueError('missing attribute'))

    assert Field.validate_or_error(5, strict=False) == ValidationResult(value=5, error=None)



# Generated at 2022-06-22 05:48:12.328753
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(
        name="choice",
        choices=[
            ("choice1", "Choice1"),
            ("choice2", "Choice2"),
        ],
    )
    result = choice.validate("choice1")
    assert result == "choice1"
    with pytest.raises(ValidationError) as err:
        choice.validate("choice3", strict=True)
    assert err.value.text == "Not a valid choice."
    assert err.value.code == "choice"
    result = choice.validate("", strict=True)
    assert result == "choice1"
    result = choice.validate("", strict=False)
    assert result is None



# Generated at 2022-06-22 05:48:22.478606
# Unit test for constructor of class Time
def test_Time():
    a = Time()
    assert a.allow_null == False
    assert a.default == None
    assert a.format == 'time'
    assert a.min_length == None
    assert a.max_length == None
    assert a.regex == None
    assert a.error == None
    assert a.errors == {'type': 'Invalid type, expected string.', 'null': 'Must not be null.', 'min_length': 'Must be at least {min_length} characters long.', 'max_length': 'Must be at most {max_length} characters long.', 'regex': 'Must match regular expression: {regex}.', 'format': 'Invalid format, must be time.'}



# Generated at 2022-06-22 05:48:24.350392
# Unit test for constructor of class Const
def test_Const():
    assert Const(1).const == 1
    assert Const(1, title='Test').title == 'Test'


# Generated at 2022-06-22 05:48:29.137291
# Unit test for constructor of class Field
def test_Field():
    f = Field(title = "test title", description = "test description", default = 5, allow_null = True)
    assert f.title == "test title"
    assert f.description == "test description"
    assert f.default == 5
    assert f.allow_null == True

# Generated at 2022-06-22 05:48:31.603758
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(multiple_of=3).validate(3) == (3)

test_Number_validate()



# Generated at 2022-06-22 05:48:36.049008
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field(title = "hi", description = "hi", allow_null = False)
    f1 = Field(title = "hi", description = "hi", allow_null = False, default = 123)
    assert f.has_default() == False
    assert f1.has_default() == True

# Generated at 2022-06-22 05:48:42.248690
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    code="positive"
    dict={'title': '', 'description': '', 'allow_null': False}
    field = Field(title='', description='', allow_null=False)
    value=field.validation_error(code)
    assert type(value)==type(ValidationError("code","text"))
    assert value.code==code
    assert value.text=="Value must be greater than 0."

# Generated at 2022-06-22 05:48:44.674847
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text("text") is None
# End unit test


# Generated at 2022-06-22 05:48:45.725146
# Unit test for constructor of class Field
def test_Field():
    assert isinstance(Field, object)


# Generated at 2022-06-22 05:49:04.599447
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():


    class MyField(Field):

        errors = {
            "required": "Field is required",
            "null": "Field may not be null",
            "invalid": "Invalid",
        }

        def validate(self, value, strict=False):
            if value is None:
                raise self.validation_error("null")
            if value is not None:
                raise self.validation_error("invalid")

    field = MyField()
    assert field.get_error_text("invalid") == "Invalid"
    assert field.get_error_text("null") == "Field may not be null"
    assert field.get_error_text("required") == "Field is required"


# Generated at 2022-06-22 05:49:07.444270
# Unit test for constructor of class Object
def test_Object():
    field = Object(properties={"foo": Object(properties={"a": Integer(minimum=3)})},
                   additional_properties=False)
    field.get_default_value()
    field.validate(1)
    field.validate({"foo": 2})
    field.validate({"foo": {"a": 2}})



# Generated at 2022-06-22 05:49:09.706807
# Unit test for method validate of class Field
def test_Field_validate():
    class FieldClass(Field):
        pass
    value = None
    field = FieldClass()
    field.validate(value)




# Generated at 2022-06-22 05:49:12.445216
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    assert Field.get_error_text("illegal_value") == "Illegal value."

    assert Field.get_error_text("cannot_be_null") == "Value cannot be null."

    assert Field.get_error_text("is_not_defined") == "Value is not defined."

    assert Field.get_error_text("illegal_type") == "Expected {type_}, received {value_type}"

# Generated at 2022-06-22 05:49:17.552319
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    length_field = Length(max_length=3, min_length=1)
    error = length_field.validation_error("invalid_max_length")
    assert(error.text == "Must be at most 3 characters.")
    assert(error.code == "invalid_max_length")



# Generated at 2022-06-22 05:49:26.043222
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Field is used as described in the <https://www.python-course.eu/python3_properties.php|class properties>
    field = Boolean(title="Boolean field")
    assert field.validate(False, strict=True) == False
    assert field.validate(1, strict=True) == True
    assert field.validate(0) == False
    assert field.validate(2) == True
    try:
        assert field.validate(None, strict=True) == None
    except:
        pass #case: value is None but allow_null = False
    assert field.validate(None, strict=False) == None



# Generated at 2022-06-22 05:49:29.497397
# Unit test for method serialize of class Array
def test_Array_serialize():
    class A(Serializer):
        a = fields.Integer()

    class B(Serializer):
        b = fields.List(A())

    t = B()
    result = t.serialize({"b": [{"a": 3}]})
    expected = {"b": [{"a": 3}]}
    assert result == expected

# Generated at 2022-06-22 05:49:32.746841
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # These unit tests test the method validate_or_error of class Field
    # AssertionError is raised for testing purpose
    assert False

# Generated at 2022-06-22 05:49:42.920693
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert not hasattr(field, "default")
    assert not field.has_default()
    field.default = 0
    assert field.has_default()
    assert field.default == 0
    field.default = "hello"
    assert field.has_default()
    assert field.default == "hello"
    field.default = []
    assert field.has_default()
    assert field.default == []
    field.default = {}
    assert field.has_default()
    assert field.default == {}
    field.default = tuple()
    assert field.has_default()
    assert field.default == tuple()
    field.default = None
    assert field.has_default()
    assert field.default is None


# Generated at 2022-06-22 05:49:44.360441
# Unit test for constructor of class Text
def test_Text():
    a = Text()
    assert a.format == "text"
    assert a.allow_null == False



# Generated at 2022-06-22 05:50:02.069869
# Unit test for method validate of class Array
def test_Array_validate():
    from jhvw.field import Integer, Float, String
    from jhvw.field import Boolean
    from jhvw.field import Array
    from jhvw.field import Choice

    schema = Array(items=Integer())
    schema.validate([1, 2, 3])
    schema.validate(None)

    with pytest.raises(ValidationError):
        schema.validate("x")
    with pytest.raises(ValidationError):
        schema.validate("null")
    with pytest.raises(ValidationError):
        schema.validate("False")
    with pytest.raises(ValidationError):
        schema.validate("1.2")
    with pytest.raises(ValidationError):
        schema.validate("/sfs")


# Generated at 2022-06-22 05:50:04.207960
# Unit test for constructor of class Float
def test_Float():
    # Arrange
    float_instance = Float()

    # Assert
    assert isinstance(float_instance, Float), 'The constructor of class Float does not create a Float.'



# Generated at 2022-06-22 05:50:05.848915
# Unit test for method validate of class Object
def test_Object_validate():
    val = Object().validate({})
    print(val)


if __name__ == "__main__":
    test_Object_validate()

# Generated at 2022-06-22 05:50:07.540279
# Unit test for method validate of class Const
def test_Const_validate():
        # check that value parameter is equal to const attribute
        import json

        assert Const.validate(Const(json.dumps({'key':'value'})), json.dumps({'key':'value'})) == json.dumps({'key':'value'})



# Generated at 2022-06-22 05:50:08.444122
# Unit test for constructor of class DateTime
def test_DateTime():
    dTime = DateTime()
    print("val of constructor of DateTime:", dTime)



# Generated at 2022-06-22 05:50:13.753384
# Unit test for constructor of class Time
def test_Time():
    reset_test_data()
    datetime_format = "%H:%M:%S"
    time_field = Time(format="time", time_format=datetime_format, allow_null=True)
    assert time_field.format == "time"
    assert time_field.time_format == datetime_format
    assert time_field.allow_null == True



# Generated at 2022-06-22 05:50:15.796096
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert time.format == "time"
    assert time.min_length == 1
    assert time.allow_null == False


# Generated at 2022-06-22 05:50:20.372003
# Unit test for method validate of class Array
def test_Array_validate():
    field = fields.Array()
    assert field.validate([1,2]) == [1,2]
    with pytest.raises(ValidationError):
        field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(1)


# Generated at 2022-06-22 05:50:23.240413
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    f = Field(title='', description='', default=1, allow_null=False)
    assert f.get_default_value() == 1


# Generated at 2022-06-22 05:50:24.875439
# Unit test for constructor of class Time
def test_Time():
    assert Time(format="time", title="test")
    

# Generated at 2022-06-22 05:50:36.556372
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    result = field.validate("anything")
    assert result == "anything"

# Generated at 2022-06-22 05:50:46.322770
# Unit test for constructor of class Boolean
def test_Boolean():
    # test when value is null and allow_null is True
    field = Boolean(allow_null=True)
    assert field.validate(value=None) is None
    assert field.validate_or_error(value=None) == ValidationResult(error=None, value=None)
    # test when value is null but allow_null is False
    field = Boolean(allow_null=False)
    assert field.validate(value=None) is not None
    assert field.validate_or_error(value=None) != ValidationResult(error=None, value=None)
    # test when value is not null or boolean, but allow_null is True and strict is False
    field = Boolean(allow_null=True)
    assert field.validate(value='', strict=False) is None
    assert field.validate_or_

# Generated at 2022-06-22 05:50:48.843790
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert isinstance(text, Text)
    assert isinstance(text, String)
    assert text._format == "text"


# Generated at 2022-06-22 05:50:52.662841
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    _, error = field.validate_or_error(1)
    assert error is None
test_Any_validate()


# Generated at 2022-06-22 05:50:59.957607
# Unit test for constructor of class Array
def test_Array():
    # Test the constructor is built correctly
    array_field = Array()
    assert array_field.items == None
    assert array_field.additional_items == False
    assert array_field.min_items == None
    assert array_field.max_items == None
    assert array_field.unique_items == False

    array_field2 = Array(items=None, additional_items=False, min_items=None, max_items=None, unique_items=False)
    assert array_field2.items == None
    assert array_field2.additional_items == False
    assert array_field2.min_items == None
    assert array_field2.max_items == None
    assert array_field2.unique_items == False


# Generated at 2022-06-22 05:51:05.178843
# Unit test for method validate of class Array
def test_Array_validate():
    from copy import deepcopy

    from cerberus import Validator
    from cerberus.tests import assert_fail, assert_success

    # Test for 'hint_message'
    con = Array(hint_message="hint message")
    schema = con.schema()
    assert schema == {"type": "array", "hint_message": "hint message"}

    context = {"foo": ["a", "b"]}
    v = Validator(context)

    assert_success(v.validate("foo", schema))
    # Test for 'error_messages'
    con = Array(error_messages={"min_items": "min items"})
    schema = con.schema()
    assert schema == {"type": "array", "min_items": 0, "error_messages": {"min_items": "min items"}}

# Generated at 2022-06-22 05:51:08.733733
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    test = Decimal()
    assert test.serialize(None) == None
    assert test.serialize(3) == 3.0
# End unit test for method serialize of class Decimal



# Generated at 2022-06-22 05:51:09.290343
# Unit test for constructor of class Float
def test_Float():
    x = Float()


# Generated at 2022-06-22 05:51:10.697000
# Unit test for constructor of class Decimal
def test_Decimal():
    a = Decimal()
    b = Decimal()
    assert a.validate(0.1) == 0.1
    assert b.validate("0.1") == 0.1
# End of unit test



# Generated at 2022-06-22 05:51:15.216631
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.types import String

    def field_validate_or_error_test():
        field = String(title="ssssssssssssssssssssssssssss")
        result = field.validate_or_error("")
        assert result.error is not None
        assert result.value is None

    field_validate_or_error_test()
# End of method validate_or_error for class Field



# Generated at 2022-06-22 05:51:33.354860
# Unit test for constructor of class Text
def test_Text():
    t = Text()


# Generated at 2022-06-22 05:51:37.392602
# Unit test for method serialize of class String
def test_String_serialize():
    field = String(format="time")
    value = field.serialize("13:00:00")
    assert isinstance(value, datetime.time)
    assert value.hour == 13
    assert value.minute == 0
    assert value.second == 0

# Generated at 2022-06-22 05:51:38.751532
# Unit test for constructor of class Integer
def test_Integer():
    integer = Integer()
    assert integer.numeric_type == int


# Generated at 2022-06-22 05:51:48.841529
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field == Any()
    assert field == Any(default=None)
    assert Any() == field
    assert Any(default=None) == field
    assert field == Field()
    assert Field() == field
    assert field == Field(default=None)
    assert Field(default=None) == field
    assert Any() == Field()
    assert Any(default=None) == Field(default=None)
    assert Field() == Any()
    assert Field(default=None) == Any(default=None)
    assert field != Any(default=False)
    assert Any(default=False) != field
    assert field != Field(default=False)
    assert Field(default=False) != field
    assert Any(default=False) != Field(default=False)

# Generated at 2022-06-22 05:51:54.761574
# Unit test for method validate of class Array
def test_Array_validate():
    s = Array()
    assert s.validate([1, 2, 3]) == [1, 2, 3]
    assert s.validate(None) is None

    s = Array(min_items=2)
    assert s.validate([1, 2, 3]) == [1, 2, 3]
    try:
        s.validate([1])
    except ValidationError as e:
        assert str(e) == "Must have at least 2 items."
    try:
        s.validate([])
    except ValidationError as e:
        assert str(e) == 'Must have at least 2 items.'

    s = Array(max_items=2)

# Generated at 2022-06-22 05:52:02.458492
# Unit test for method validate of class Choice
def test_Choice_validate():
    s = """
    >>> f = Choice(choices=[('key1', 'value1'), ('key2', 'value2')])
    >>> assert f.validate('key1') == 'key1'
    >>> assert f.validate('key2') == 'key2'
    >>> assert f.validate(None) == None
    >>> assert f.validate('') == None
    >>> assert f.validate(3) == None
    """
    import doctest
    doctest.run_docstring_examples(s, globals())



# Generated at 2022-06-22 05:52:06.550152
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert field.has_default() == False
    field.default = "value"
    assert field.has_default() == True


# Generated at 2022-06-22 05:52:08.320932
# Unit test for constructor of class Decimal
def test_Decimal():
    deci = Decimal()
    assert isinstance(deci, Number)
    return deci



# Generated at 2022-06-22 05:52:20.134725
# Unit test for method serialize of class Array
def test_Array_serialize():
    # default:
    schema = Array(String(min_length = 2, max_length = 10))
    obj = ['abc', 'def', 'ghi']
    o = schema.serialize(obj)
    assert o == obj
    # additional_items = False:
    schema = Array(String(min_length = 2, max_length = 10), additional_items = False)
    obj = ['abc', 'def', 'ghi']
    o = schema.serialize(obj)
    assert o == obj
    # additional_items = True:
    schema = Array(String(min_length = 2, max_length = 10), additional_items = True)
    obj = ['abc', 'def', 'ghi']
    o = schema.serialize(obj)
    assert o == obj
    # additional_items = String:
    schema

# Generated at 2022-06-22 05:52:21.197364
# Unit test for method validate of class Const
def test_Const_validate():
    instance = Const(1, allow_null = True)
    with pytest.raises(ValidationError):
        instance.validate(1)


# Generated at 2022-06-22 05:52:51.664090
# Unit test for constructor of class String
def test_String():
    try:
        String()
        assert(True)
    except:
        assert(False)


# Generated at 2022-06-22 05:52:59.695604
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    # creation counter is an attribute of the class so set it directly
    Field.creation_counter = 0
    # test cases for the method validate_or_error

# Generated at 2022-06-22 05:53:06.446270
# Unit test for constructor of class Object
def test_Object():
    #Test if a dictionary is passed as the properties argument.
    properties_dict = {'name':String()}
    type_dict = Object(properties = properties_dict)
    #Test if a list is passed as the properties argument.
    properties_list = [('name',String())]
    type_dict = Object(properties = properties_list)
    #Test if a tuple is passed as the properties argument.
    properties_tuple = (('name',String()),)
    type_dict = Object(properties = properties_tuple)
    #Test if a Field is passed as the properties argument.
    type_dict = Object(properties = String())
    #Test if a dictionary is passed as the pattern_properties argument.
    pattern_properties_dict = {'name':String()}

# Generated at 2022-06-22 05:53:07.760645
# Unit test for constructor of class Decimal
def test_Decimal():
    inst = Decimal()


# Generated at 2022-06-22 05:53:11.249275
# Unit test for constructor of class Any
def test_Any():
    assert Any().validate(None) is None
    assert Any().validate(True) is True
    assert Any().validate(2) == 2
    assert Any().validate('') == ''



# Generated at 2022-06-22 05:53:16.980317
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=[('1', 'one'), ('2', 'two')])
    assert choice.validate('2') == '2'
    assert choice.validate('') == ValidationError(text='May not be null.', code='null')
    assert choice.validate('3') == ValidationError(text='Not a valid choice.', code='choice')



# Generated at 2022-06-22 05:53:21.344185
# Unit test for method validate of class Const
def test_Const_validate():
  my_const = Const(const=10)
  assert my_const.validate(10) == 10
  assert my_const.validate(20) == 20

test_Const_validate()


# Generated at 2022-06-22 05:53:26.286559
# Unit test for method validate of class Number
def test_Number_validate():
    # Test type float
    field = Number()
    assert field.validate(value = 1.0) == 1.0
    assert field.validate(value = 1) == 1
    # Test type int
    field = Number(numeric_type = int)
    assert field.validate(value = 1) == 1



# Generated at 2022-06-22 05:53:28.935296
# Unit test for constructor of class Text
def test_Text():
    field = Text(title="Test Text")
    assert field.format == "text"


# Generated at 2022-06-22 05:53:40.673304
# Unit test for method validate of class Number
def test_Number_validate():
    n = Number()
    n.validate(31)
    n.validate(1.1)
    n.validate(-1.2)
    n.validate(-0.01)
    n.validate('1.1')
    try:
        n.validate('a')
    except ValidationError as e:
        assert e.code == 'type'
    try:
        n.validate(True)
    except ValidationError as e:
        assert e.code == 'type'
    try:
        n.validate(None)
    except ValidationError as e:
        assert e.code == 'null'
    try:
        n.validate('1\0')
    except ValidationError as e:
        assert e.code == 'type'

# Generated at 2022-06-22 05:53:58.547609
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field().validate_or_error('1') == ValidationResult(value=None, error=ValidationError(text='', code=''))
    assert Field().validate_or_error(None) == ValidationResult(value=None, error=ValidationError(text='', code=''))
    assert Field().validate_or_error('a') == ValidationResult(value=None, error=ValidationError(text='', code=''))
    assert Field().validate_or_error(False) == ValidationResult(value=None, error=ValidationError(text='', code=''))
    assert Field().validate_or_error(ValidationError(text='', code='')) == ValidationResult(value=None, error=ValidationError(text='', code=''))
    assert Field().validate_or_error

# Generated at 2022-06-22 05:54:02.483914
# Unit test for method validate of class Field
def test_Field_validate():
    _type = Field()
    try:
        _type.validate('')
        assert False
    except NotImplementedError:
        pass

# Generated at 2022-06-22 05:54:04.632836
# Unit test for constructor of class Const
def test_Const():
    try:
        a = Const(1)
        assert False
    except:
        pass



# Generated at 2022-06-22 05:54:07.164236
# Unit test for method validate of class Array
def test_Array_validate():
    array = Array(required=True, name="name", description="description", title="title", items=None)
    array.validate('test')



# Generated at 2022-06-22 05:54:09.270961
# Unit test for constructor of class Field
def test_Field():
    Field()
    Field(title="", description="", default=None, allow_null=False)

# Unit tests for methods in class Field

# Generated at 2022-06-22 05:54:16.948372
# Unit test for constructor of class Choice
def test_Choice():
    choices = [
        ("option1", "Option 1"),
        ("option2", "Option 2"),
        ("option3", "Option 3"),
    ]
    my_choice = Choice(choices=choices, allow_null=True)
    assert my_choice.choices == choices
    assert my_choice.allow_null == True
    assert my_choice.validate('option1') == 'option1'
    with pytest.raises(ValidationError):
        my_choice.validate('option4')



# Generated at 2022-06-22 05:54:18.992795
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    value = "aa"
    result = s.serialize(value)
    assert result == value


# Generated at 2022-06-22 05:54:22.804932
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(
        choices=[
            ("key1", "value1"),
            ("key2", "value2"),
            ("key3", "value3"),
        ]
    )
    assert choice.choices == [
        ("key1", "value1"),
        ("key2", "value2"),
        ("key3", "value3"),
    ]


# Generated at 2022-06-22 05:54:24.068950
# Unit test for constructor of class Union
def test_Union():

    my_union = Union(any_of=[Number(minimum=0)])
    assert my_union.any_of[0].minimum == 0



# Generated at 2022-06-22 05:54:36.041237
# Unit test for constructor of class Object
def test_Object():
    properties = {"test_property": Integer()}
    pattern_properties = {"pattern": Integer()}
    additional_properties = False
    property_names = Field()
    min_properties = 0
    max_properties = 10
    required = ["required_property"]
    instance = Object(
        properties = properties,
        pattern_properties = pattern_properties,
        additional_properties = additional_properties,
        property_names = property_names,
        min_properties = min_properties,
        max_properties = max_properties,
        required = required,
    )

    assert instance.properties == properties
    assert instance.pattern_properties == pattern_properties
    assert instance.additional_properties == additional_properties
    assert instance.property_names == property_names
    assert instance.min_properties == min_properties
    assert instance.max_properties == max

# Generated at 2022-06-22 05:55:00.751770
# Unit test for constructor of class Any
def test_Any():
    test = Any()
    assert test is not None

# Generated at 2022-06-22 05:55:10.972797
# Unit test for method has_default of class Field
def test_Field_has_default():
    from typesystem import fields
    # test1
    a = fields.Field(title="a", default=12)
    assert a.has_default()
    # test2
    b = fields.Field(title="b", default=None)
    assert b.has_default()
    # test3
    c = fields.Field(title="c")
    assert not c.has_default()
    # test4
    d = fields.Field(title="d", default=NO_DEFAULT)
    assert not d.has_default()
    # test5
    e = fields.Field(title="e", default=12, allow_null=True)
    assert e.has_default()

# Generated at 2022-06-22 05:55:13.164739
# Unit test for method serialize of class Field
def test_Field_serialize():
    from typesystem import Integer

    field = Integer(title="Integer")
    assert field.serialize(1) == 1


# Generated at 2022-06-22 05:55:14.973432
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal()


# Generated at 2022-06-22 05:55:17.579686
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field=Field()
    errors={'test':'test'}
    field.errors=errors
    code='test'
    assert field.get_error_text(code) == errors[code]
    

# Generated at 2022-06-22 05:55:22.192981
# Unit test for constructor of class Choice
def test_Choice():
    try:
        Choice(choices=[("A", "A"), "B"])
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == "an integer is required (got type str)"
    else:
        assert False, "Expecting an exception"



# Generated at 2022-06-22 05:55:25.350931
# Unit test for method has_default of class Field
def test_Field_has_default():
    field1 = Field()
    field2 = Field(default="foo")
    assert field1.has_default() == False
    assert field2.has_default() == True

# Generated at 2022-06-22 05:55:27.613185
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [
        String(),
        String(),
    ]
    u = Union(any_of=any_of)
    assert u.validate("") == ""



# Generated at 2022-06-22 05:55:37.282246
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import AnyOf
    from typesystem.fields import String
    from typesystem.fields import Union
    string_field = String()
    union_field = string_field | "foo"  # type: ignore
    assert union_field == Union(any_of=[string_field, "foo"])
    union_field = "foo" | string_field  # type: ignore
    assert union_field == Union(any_of=["foo", string_field])
    union_field = Union([AnyOf([String()])]) | "foo"  # type: ignore
    assert union_field == Union(any_of=[Union(any_of=[AnyOf([String()])]), "foo"])
    union_field = "foo" | Union([AnyOf([String()])])  # type: ignore

# Generated at 2022-06-22 05:55:40.010304
# Unit test for method serialize of class Field
def test_Field_serialize():
  field = Field()
  assert field.serialize('test_serialize') == 'test_serialize'
  return True
