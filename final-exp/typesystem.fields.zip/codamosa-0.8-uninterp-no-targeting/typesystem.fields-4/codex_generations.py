

# Generated at 2022-06-22 05:47:47.643624
# Unit test for constructor of class String
def test_String():
    test_String = String()
    assert test_String.trim_whitespace == True
    assert test_String.max_length == None
    assert test_String.min_length == None
    assert test_String.pattern == None
    assert test_String.format == None


# Generated at 2022-06-22 05:47:49.594773
# Unit test for method validate of class Array
def test_Array_validate():
    _field = Array()
    try:
        _field.validate(1)
        assert False, "Expected ValidationError"
    except ValidationError:
        pass



# Generated at 2022-06-22 05:48:00.475028
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(format="date", title="Date", description="Date").serialize("2019/06/19") == "2019-06-19"
    assert String(format="time", title="Time", description="Time").serialize("12:00") == "12:00"
    assert String(format="datetime", title="DateTime", description="DateTime").serialize("2019/06/19 12:00") == "2019-06-19T12:00"
    assert String(format="uuid", title="UUID", description="UUID").serialize("8d06bba5-e2e1-4979-9a9b-c5364b77aa64") == "8d06bba5-e2e1-4979-9a9b-c5364b77aa64"

# Generated at 2022-06-22 05:48:03.787911
# Unit test for constructor of class Object
def test_Object():
    print("Testing constructor of class Object")
    
    field = Object(description='description', title='title', nullable=True)
    assert field.description == 'description'
    assert field.title == 'title'
    assert field.allow_null == True
    
    

# Generated at 2022-06-22 05:48:10.281884
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize('str') == 'str'
    assert field.serialize(1) == 1
    assert field.serialize(['str', 1]) == ['str', 1]
    assert field.serialize({'key': 'value'}) == {'key': 'value'}
    assert field.serialize(None) is None
    field.allow_null = True
    assert field.serialize(None) is None

# Generated at 2022-06-22 05:48:12.787224
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    try:
        f.validate("dummy")
    except NotImplementedError:
        pass
    else:
        assert False
    try:
        assert f.validate("dummy", strict = False)
    except NotImplementedError:
        assert False



# Generated at 2022-06-22 05:48:17.854116
# Unit test for method validate of class Const
def test_Const_validate():
    s = Const(const=5,description="Integer",id="xxx")
    assert s.validate(5) is 5
    assert s.validate(5.0) is 5
    with pytest.raises(ValidationError):
        s.validate(6)


# Generated at 2022-06-22 05:48:20.458324
# Unit test for constructor of class Integer
def test_Integer():
    # test the Integer class
    try:
        value = Integer()
    except:
        print("Integer doesn't work")



# Generated at 2022-06-22 05:48:23.040719
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() == None
    assert Field(default=1).get_default_value() == 1
    assert Field(default=lambda: 1).get_default_value() == 1

# Generated at 2022-06-22 05:48:25.098926
# Unit test for constructor of class Integer
def test_Integer():
    test_field = Integer()
    test_field.allow_null = True
    assert test_field.allow_null == True


# Generated at 2022-06-22 05:48:43.976201
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field.get_default_value() == None or Field.get_default_value() == NO_DEFAULT

# Generated at 2022-06-22 05:48:45.880947
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate(value=2) == 2

# Generated at 2022-06-22 05:48:50.550484
# Unit test for method serialize of class Array
def test_Array_serialize():
    cls = Array()
    str_obj = "hello"
    str_result = cls.serialize(str_obj)
    assert str_result == str_obj
    #
    int_obj = 10
    int_result = cls.serialize(int_obj)
    assert int_result == int_obj
    #
    lst_obj = ["hello", "world"]
    lst_result = cls.serialize(lst_obj)
    assert lst_result == lst_obj


# Generated at 2022-06-22 05:48:56.309309
# Unit test for constructor of class Float
def test_Float():
    assert Float.numeric_type is float
    assert Float.errors is not None
    assert Float.errors.get("type",None) is not None
    assert Float.errors.get("null",None) is not None
    assert Float.errors.get("integer",None) is not None
    assert Float.errors.get("finite",None) is not None
    assert Float.errors.get("minimum",None) is not None
    assert Float.errors.get("exclusive_minimum",None) is not None
    assert Float.errors.get("maximum",None) is not None
    assert Float.errors.get("exclusive_maximum",None) is not None
    assert Float.errors.get("multiple_of",None) is not None



# Generated at 2022-06-22 05:49:05.932092
# Unit test for constructor of class DateTime
def test_DateTime():
    assert DateTime(name='', default=None, allow_null=True, required=False, nullable=False).name == ''
    assert DateTime(name='', default=None, allow_null=True, required=False, nullable=False).default == None
    assert DateTime(name='', default=None, allow_null=True, required=False, nullable=False).allow_null == True
    assert DateTime(name='', default=None, allow_null=True, required=False, nullable=False).required == False
    assert DateTime(name='', default=None, allow_null=True, required=False, nullable=False).nullable == False



# Generated at 2022-06-22 05:49:12.490897
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
  field = Field()
  assert field.validate_or_error(1).value == 1
  assert field.validate_or_error(1.0).value == 1
  assert field.validate_or_error("1").value == "1"
  assert field.validate_or_error(True).value == True
  assert field.validate_or_error(None).value == None


# Generated at 2022-06-22 05:49:24.260548
# Unit test for constructor of class Text
def test_Text():
    class T(Text):
        pass
    
    assert T.format == 'text'
    assert T.allow_null == False
    assert T.default == None
    assert T.description == None
    assert T.example == None
    assert T.error_messages == {'format': 'Must be a valid text value.',
                                'null': 'May not be null.',
                                'required': 'This field is required.',
                                'empty': 'May not be blank.',
                                'strip': 'Value must only contain whitespace.',
                                'max_length': 'Value must be {max_length} characters or less.',
                                'min_length': 'Value must be {min_length} characters or more.'}
    assert T.max_length == None
    assert T.min_length == None

# Generated at 2022-06-22 05:49:26.991133
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(title = "a", description = "b", default = "c", allow_null = False)
    assert field.has_default() == True



# Generated at 2022-06-22 05:49:29.279878
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field(title="", description="", default=NO_DEFAULT,
        allow_null=False).has_default()

# Generated at 2022-06-22 05:49:41.190826
# Unit test for constructor of class Choice
def test_Choice():
    choice_list = ['a', 'b', 'c', 'd']
    choice_list_wrong = ['a', 'b', 'c', 'e']
    choice_list_mult = [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h')]
    choice_list_mult_wrong = [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'i')]
    choice_list_is_none = None
    choice_list_is_empty = []
    choice_list_mix_correct_wrong = [('a', 'b'), ('c', 'd'), ('e', 'f'), 'g']
    choice_list_mix_wrong_correct = ['e', ('c', 'd'), ('a', 'b'), 'g']


# Generated at 2022-06-22 05:50:14.416621
# Unit test for method __or__ of class Field
def test_Field___or__():
    x = Field()
    y = Field()
    z = x | y
    assert z.any_of == [x, y]
    z = x | y | x
    assert z.any_of == [x, y, x]
    z = (x | y) | x
    assert z.any_of == [x, y, x]
    z = x | (y | x)
    assert z.any_of == [x, y, x]



# Generated at 2022-06-22 05:50:15.601475
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(None) is None


# Generated at 2022-06-22 05:50:27.265483
# Unit test for method __or__ of class Field
def test_Field___or__():
    global NO_DEFAULT
    if hasattr(NO_DEFAULT, '__dict__'):
        for attr in NO_DEFAULT.__dict__:
            if attr not in ('__init__', '__dict__', '__slots__', '__eq__', '__ne__', '__repr__', '__str__', '__setattr__', '__delattr__', '__format__', '__hash__', '__new__', '__reduce__', '__reduce_ex__', '__class__', '__sizeof__', '__dir__', '__class_getitem__', '__init_subclass__', '__subclasshook__', '__doc__', '__annotations__'):
                delattr(NO_DEFAULT, attr)
    attrs = {}

# Generated at 2022-06-22 05:50:30.792658
# Unit test for constructor of class Const
def test_Const():
    error_messages, validated = Const(10).validate_or_error(10)
    assert validated == 10



# Generated at 2022-06-22 05:50:33.704902
# Unit test for constructor of class Any
def test_Any():
    with pytest.raises(TypeError):
        Any(default = None)
    Any(default=None, allow_null=True)
    Any()

# Generated at 2022-06-22 05:50:44.422947
# Unit test for constructor of class String
def test_String():
    print ('Test constructor of String')
    attr = String()
    assert attr.title == ''
    assert attr.description == ''
    assert attr.allow_null == False
    assert attr.allow_blank == False
    assert attr.trim_whitespace == True
    assert attr.max_length == None
    assert attr.min_length == None
    assert attr.pattern == None
    assert attr.format == None
    attr = String(title='name', description='name_descr', allow_null=True, \
    allow_blank=True, trim_whitespace=False, max_length=20, min_length=5, pattern='pattern',\
    format='datetime')
    assert attr.title == 'name'
    assert attr.description == 'name_descr'

# Generated at 2022-06-22 05:50:51.209839
# Unit test for constructor of class Field
def test_Field():
    integer = Integer()
    o = Field(title='title', default=10, allow_null=True)
    assert o.default is 10
    assert o.allow_null == True
    assert o.validate_or_error(10).value == 10
    assert o.validate_or_error(20).error.text == "Value must be 10."
    assert o.validate_or_error(None).value is None



# Generated at 2022-06-22 05:51:02.396503
# Unit test for constructor of class Number
def test_Number():
    assert Number.__init__.__doc__ == """
    __init__(
        *,
        minimum: typing.Union[int, float, decimal.Decimal] = None,
        maximum: typing.Union[int, float, decimal.Decimal] = None,
        exclusive_minimum: typing.Union[int, float, decimal.Decimal] = None,
        exclusive_maximum: typing.Union[int, float, decimal.Decimal] = None,
        precision: str = None,
        multiple_of: typing.Union[int, float, decimal.Decimal] = None,
        **kwargs: typing.Any,
    ):
    """.strip()
    assert Number.numeric_type is None

# Generated at 2022-06-22 05:51:09.578758
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal = Decimal(title="test", description="test", default=5, allow_null=False)
    assert decimal.title == "test", "Test title false"
    assert decimal.description == "test", "Test description false"
    assert decimal.default == 5, "Test default false"
    assert decimal.allow_null == False, "Test allow_null false"
    assert decimal.validate(5) == 5, "Test validate false"

test_Decimal()


# Generated at 2022-06-22 05:51:17.273742
# Unit test for constructor of class Choice
def test_Choice():
    class TestChoice(Choice):
        choices = [("key1", "value1"), ("key2", "value2")]

    c1 = TestChoice()
    c2 = TestChoice(choices=[("key1", "value1")])
    c3 = TestChoice(choices=["key1"])
    c4 = TestChoice(choices=["key3"])

    assert c1.get_default_value() == None
    assert c1.choices == [("key1", "value1"), ("key2", "value2")]
    assert c1.validate(None) == None
    assert c1.validate(None, strict=True) == None
    assert c1.validate("key1") == "key1"
    assert c1.validate("key2") == "key2"
    assert c1

# Generated at 2022-06-22 05:51:38.766915
# Unit test for method validate of class Union
def test_Union_validate():
    union_json_schema = {
        "anyOf": [
            {
                "type": "object",
                "properties": {
                    "min": {"type": "number"},
                    "max": {"type": "number"},
                    "exclusiveMinimum": {"type": "boolean"},
                    "exclusiveMaximum": {"type": "boolean"}
                }
            },
            {"$ref": "#/definitions/number"}
        ]
    }

    def _construct_validator(schema: typing.Dict) -> Validator:
        field = Field.from_json_schema(schema)
        return field.validator

    union_json_schema_from_validator = _construct_validator(union_json_schema)

    def code(r):
        return r[0]


# Generated at 2022-06-22 05:51:47.090869
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field(title="", description="", default=NO_DEFAULT, allow_null=False)
    # test that error is returned
    assert(isinstance(field.validate_or_error("abc", strict = True), ValidationResult))
    assert(field.validate_or_error("abc", strict = True).value is None)
    assert (isinstance(field.validate_or_error("abc", strict = True).error, ValidationError))
    # test that no error is returned
    assert (field.validate_or_error("abc", strict = True).error is None)

# Generated at 2022-06-22 05:51:49.213134
# Unit test for constructor of class DateTime
def test_DateTime():
    a = DateTime()
    if a.format != "datetime":
        raise AssertionError()


# Generated at 2022-06-22 05:51:54.703513
# Unit test for constructor of class Choice
def test_Choice():
    choices = [("a", "A"), ("b", "B")]
    field = Choice(choices=choices, display_name="Choice", description="A Choice")
    assert field.display_name == "Choice"
    assert field.description == "A Choice"
    assert field.choices == [("a", "A"), ("b", "B")]


# Generated at 2022-06-22 05:51:58.911102
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice1 = Choice(choices=[("a", "a"), ("b", "b")])
    choice1.validate("a")
    try:
        choice1.validate("c")
    except ValidationError:
        print("c is not a valid choice")



# Generated at 2022-06-22 05:52:07.808371
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    import types
    from typesystem import fields

    field = fields.Field()
    assert field.has_default() == False

    class Foo:
        def __init__(self):
            self.value = 5
            self.called = False
        def __call__(self):
            self.called = True
            return self.value

    foo_obj = Foo()
    field = fields.Field(default=foo_obj)
    assert field.has_default() == True
    assert field.get_default_value() == 5
    assert foo_obj.called == True

    foo_func = foo_obj
    field = fields.Field(default=foo_func)
    assert field.has_default() == True
    assert field.get_default_value() == 5
    assert foo_func.called == True


# Generated at 2022-06-22 05:52:11.543881
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(None) == None
    assert Any().validate(1) == 1
    assert Any().validate('hello') == 'hello'
    assert type(Any().get_validator()) == st.Any()


# Generated at 2022-06-22 05:52:14.168644
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const(const=None, allow_null=True)
    result = field.validate(value=None)
    assert result is None


# Generated at 2022-06-22 05:52:19.218438
# Unit test for method serialize of class String
def test_String_serialize():
    assert String(title='name',description='description',default="name").serialize("name")=="name"
# Test Serialize String and String Formats
test_String_serialize()


# Generated at 2022-06-22 05:52:27.872105
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # test if value is none, value is valid if allow_null is true
    testInstance = Boolean()
    testValue = None
    assert testInstance.validate(testValue, strict=True) == None

    # test if value is none, value is valid if allow_null is false and strict is true
    testInstance = Boolean(allow_null=False)
    testValue = None
    try:
        assert testInstance.validate(testValue, strict=True)
    except ValidationError:
        pass
    else:
        print("Test validation type null failed.")

    # test if value is none, value is valid if allow_null is false and strict is false
    testInstance = Boolean(allow_null=False)
    testValue = None

# Generated at 2022-06-22 05:52:41.646337
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field(title='notebook_id', description='', allow_null=False)
    assert f.has_default() == False
    f1 = Field(title='notebook_id', description='', default='', allow_null=False)
    assert f1.has_default() == True
    f2 = Field(title='notebook_id', description='', allow_null=False)
    assert f2.has_default() == False


# Generated at 2022-06-22 05:52:54.160902
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem import Integer, Field, ValidationError
    from typesystem.base import UNDEFINED

    class MyField(Field):
        def validate(self, value, strict=False):
            if value == "error":
                raise ValidationError("error")
            return value

    field = MyField()

    result = field.validate_or_error("valid")
    assert result.value == "valid"
    assert result.error is None

    result = field.validate_or_error("error")
    assert result.value is None
    assert result.error.code == "error"
    assert str(result.error) == "error"

    field = Field()
    result = field.validate_or_error(None)
    assert result.value is None
    assert result.error is None


# Generated at 2022-06-22 05:52:56.999982
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    f = Field()
    error = f.validation_error("test")
    assert isinstance(error, ValidationError)


# Generated at 2022-06-22 05:53:01.720801
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(None) is None
    assert field.serialize(5) == 5
    assert field.serialize(5.5) == 5.5
    assert field.serialize(False) is False
    assert field.serialize(True) is True
    assert field.serialize('test') == 'test'



# Generated at 2022-06-22 05:53:04.029578
# Unit test for constructor of class Time
def test_Time():
    a = Time()
    assert(a.format == 'time')


# Generated at 2022-06-22 05:53:06.004999
# Unit test for constructor of class Field
def test_Field():
    newField = Field()
    assert newField._creation_counter == 0


# Generated at 2022-06-22 05:53:09.308237
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(minimum=1, maximum=1).numeric_type == int
    assert Integer(minimum=1, maximum=1).allow_null == False


# Generated at 2022-06-22 05:53:17.137218
# Unit test for constructor of class Any
def test_Any():
    assert Any().validate(None) is None
    assert Any().validate("test") == "test"
    assert Any().validate(1) == 1
    assert Any().validate(True) == True
    assert Any().validate(1.1) == 1.1
    assert Any().validate({"a": 1, "b": 1, "c": 1}) == {"a": 1, "b": 1, "c": 1}
    assert Any().validate(["a", "b", "c"]) == ["a", "b", "c"]


# Generated at 2022-06-22 05:53:23.477078
# Unit test for constructor of class Choice
def test_Choice():
    # choices is a list of tuples
    choices = [
        (1, "one"),
        (2, "two"),
        (3, "three"),
        (4, "four"),
        (5, "five"),
        (6, "six"),
    ]
    field = Choice(choices=choices)
    assert field.choices == choices


# Generated at 2022-06-22 05:53:29.001070
# Unit test for constructor of class Any
def test_Any():
    f = Any()
    assert not f.validate(1)
    assert not f.validate(True)
    assert not f.validate(None)
    assert not f.validate(0.0)
    assert not f.validate([ ])
    assert not f.validate({ })
    assert not f.validate('Hello')
    assert not f.validate('2017-01-01T01:02:03')



# Generated at 2022-06-22 05:54:19.004625
# Unit test for constructor of class String
def test_String():
    assert String(title="firstname", description="Firstname", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).title == "firstname"
    assert String(title="firstname", description="Firstname", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).description == "Firstname"
    assert String(title="firstname", description="Firstname", default="", allow_null=False, allow_blank=False, trim_whitespace=True, max_length=None, min_length=None, pattern=None, format=None).default == ""

# Generated at 2022-06-22 05:54:26.261138
# Unit test for constructor of class Field
def test_Field():
    f = Field()
    assert f.title == ''
    
    f = Field(title="n")
    assert f.title == 'n'
    
    f = Field(title="n", description="d")
    assert f.title == 'n'
    assert f.description == 'd'
    
    f = Field(title="n", description="d", default=1)
    assert f.title == 'n'
    assert f.description == 'd'
    assert f.default == 1
    
    f = Field(title="n", description="d", default=1, allow_null=True)
    assert f.title == 'n'
    assert f.description == 'd'
    assert f.default == 1
    assert f.allow_null == True



# Generated at 2022-06-22 05:54:29.906405
# Unit test for constructor of class Text
def test_Text():
    # test if object is instance of String
    my_string = Text()
    assert isinstance(my_string, String)
    # check whether format is text
    assert my_string.format == "text"

# Generated at 2022-06-22 05:54:31.824436
# Unit test for constructor of class Union
def test_Union():
    any_of = [String(), Integer()]
    field = Union(any_of)
    assert field.any_of == any_of
    assert field.allow_null == False 



# Generated at 2022-06-22 05:54:39.023176
# Unit test for method validate of class Number
def test_Number_validate():
    r = Number(minimum=1, maximum=10, multiple_of=3)
    test_cases = [(-1, 'null'), (1, 1), (7, 7), (9, 9), (10, 10), (11, 'maximum'), (0.2, 'type')]
    for i in range(len(test_cases)):
        test_case = test_cases[i]
        assert r.validate(test_case[0]) == test_case[1]


# Generated at 2022-06-22 05:54:44.738714
# Unit test for constructor of class Number
def test_Number():
    test_number = Number(minimum=10, maximum=20, exclusive_minimum=10, exclusive_maximum=20, multiple_of=5)
    assert test_number.minimum == 10
    assert test_number.maximum == 20
    assert test_number.exclusive_minimum == 10
    assert test_number.exclusive_maximum == 20
    assert test_number.multiple_of == 5



# Generated at 2022-06-22 05:54:45.641487
# Unit test for constructor of class Any
def test_Any():
    test_Any = Any()



# Generated at 2022-06-22 05:54:51.769211
# Unit test for constructor of class Integer
def test_Integer():
    # Assert that Integer is a subclass of Number, which is a subclass of Field.
    assert issubclass(Integer, Number)
    assert issubclass(Integer, Field)
    # Assert that numeric_type is an integer and that the default value is None
    #  since all integers can be positive, negative or zero.
    assert Integer.numeric_type == int and type(Integer.numeric_type) == int
    i = Integer()
    assert i.numeric_type == int and type(i.numeric_type) == int



# Generated at 2022-06-22 05:54:57.730929
# Unit test for constructor of class Text
def test_Text():
    email_str = "mymail@gmail.com"
    email = Text()
    assert email.validate(email_str) == email_str
    email_str2 = "mymailgmail.com"
    assert email.validate(email_str2) != email_str2 #testing the invalid email


# Unit tests for the constructor of the class Object

# Generated at 2022-06-22 05:55:05.152877
# Unit test for constructor of class Union
def test_Union():
    # Test with all fields that allow None
    field = Union([
        Integer(),
        String(),
        Null()
    ])

    assert field.allow_null is True
    validated, error = field.validate_or_error(2)
    assert validated == 2
    assert error is None
    validated, error = field.validate_or_error("test")
    assert validated == "test"
    assert error is None
    validated, error = field.validate_or_error(None)
    assert validated is None
    assert error is None

    # Test with a field that does not allow None
    field = Union([
        Integer(),
        String()
    ])

    assert field.allow_null is False
    validated, error = field.validate_or_error(2)
    assert validated == 2
    assert error is None
   