

# Generated at 2022-06-22 05:47:48.675492
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    dic = {"test": "test"}
    field = Field(**dic)
    field.errors = {"test": "test"}
    assert field.get_error_text("test") == "test"
    assert field.get_error_text("not_exist") == "KeyError: 'not_exist'"


# Generated at 2022-06-22 05:47:49.622649
# Unit test for constructor of class Date
def test_Date():
    date=Date()
    assert date.format == 'date'



# Generated at 2022-06-22 05:47:52.224414
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice1 = Choice(**{"choices": ['choice1', 'choice2', 'choice3']})
    assert choice1.validate('choice1') == 'choice1'
    assert choice1.validate('choice2') == 'choice2'
    assert choice1.validate('choice3') == 'choice3'
    with pytest.raises(ValidationError) as err:
        choice1.validate('choice4')

# Generated at 2022-06-22 05:47:55.235727
# Unit test for method validate of class Any
def test_Any_validate():
    obj = Any()
    obj.validate({})
    obj.validate("")
    obj.validate(123)

# Generated at 2022-06-22 05:48:06.411876
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number(allow_null=False).validate(10) == 10
    assert Number(allow_null=False, allow_blank=True).validate("") == None
    assert Number().validate("1.2") == 1.2
    assert Number(minimum=2.2).validate(2.2) == 2.2
    assert Number(minimum=2.2).validate(3) == 3
    assert Number(minimum=2.2, allow_null = True).validate(None) == None
    assert Number(minimum=2.2).validate(1.2) == 1.2
    assert Number(minimum=2.2, only_integer=True).validate(2.2) == 2.2
    assert Number(minimum=2.2, only_integer=True).validate(3) == 3

# Generated at 2022-06-22 05:48:14.390776
# Unit test for method serialize of class Array
def test_Array_serialize():
    def test(value):
        field = Array(description="description")
        return field.serialize(value)

    class Test:
        def __init__(self, value):
            self.value = value

        def serialize(self, field):
            return self.value

    assert test(None) == None
    assert test(["x", "y"]) == ["x", "y"]
    assert test([1, 2]) == [1, 2]
    assert test([Test("x"), Test("y")]) == ["x", "y"]



# Generated at 2022-06-22 05:48:24.825312
# Unit test for method serialize of class Array
def test_Array_serialize():
    class ArrayItem(Field):
        errors = {
            "type": "Must be an array.",
            "null": "May not be null.",
            "empty": "Must not be empty.",
            "exact_items": "Must have {min_items} items.",
            "min_items": "Must have at least {min_items} items.",
            "max_items": "Must have no more than {max_items} items.",
            "additional_items": "May not contain additional items.",
            "unique_items": "Items must be unique.",
        }


# Generated at 2022-06-22 05:48:29.711445
# Unit test for constructor of class Decimal
def test_Decimal(): # pragma: no cover
    a = Decimal(minimum=3, maximum=5, exclusive_maximum=1, exclusive_minimum=2)
    assert a.minimum == 3
    assert a.maximum == 5
    assert a.exclusive_maximum == 1
    assert a.exclusive_minimum == 2


# Generated at 2022-06-22 05:48:32.154389
# Unit test for constructor of class Float
def test_Float():
    x = Float()
    assert isinstance(x, Field)
    assert isinstance(x, Number)
    assert isinstance(x, Integer)



# Generated at 2022-06-22 05:48:34.410318
# Unit test for constructor of class Decimal
def test_Decimal():
    number = Decimal()
    assert(number.numeric_type == decimal.Decimal)


# Generated at 2022-06-22 05:49:13.841373
# Unit test for constructor of class Time
def test_Time():
    time = Time(min_length=1)



# Generated at 2022-06-22 05:49:15.234225
# Unit test for constructor of class Boolean
def test_Boolean():
    validate=Boolean()
    assert validate


# Generated at 2022-06-22 05:49:25.791443
# Unit test for constructor of class Array
def test_Array():
    field = Array(min_items=2)

    try:
        field.validate([])
        assert False
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].code == "min_items"

    assert field.validate([1, 2]) == [1, 2]
    assert field.validate([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

    field = Array(max_items=2)

    try:
        field.validate([1, 2, 3])
        assert False
    except ValidationError as e:
        assert len(e.messages()) == 1
        assert e.messages()[0].code == "max_items"

    assert field.validate([]) == []
   

# Generated at 2022-06-22 05:49:28.165009
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    with pytest.raises(NotImplementedError):
        field.validate("")


# Generated at 2022-06-22 05:49:29.004402
# Unit test for constructor of class Const
def test_Const():
    const_field = Const(const=None)
    assert const_field.const == None



# Generated at 2022-06-22 05:49:33.252179
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    default = type("Default", (), {"default": "value"})
    default.field = Field(default=default)
    assert default.field.get_default_value() == "value"



# Generated at 2022-06-22 05:49:37.262935
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f.numeric_type is float


# Generated at 2022-06-22 05:49:41.283834
# Unit test for constructor of class Text
def test_Text():
    x = Text(default="Default")
    assert x.to_primitive() == "Default"
    x.default = "another default"
    assert x.to_primitive() == "another default"


# Generated at 2022-06-22 05:49:51.771877
# Unit test for method validate of class Number
def test_Number_validate():
    valueList = [None, "", True, 1.5, -1, "1", "a", "123.5"]
    numeric_typeList = [None, int, decimal.Decimal]
    minimumList = [None, 1, decimal.Decimal(1)]
    exclusive_minimumList = [None, 1, decimal.Decimal(1)]
    maximumList = [None, 1, decimal.Decimal(1)]
    exclusive_maximumList = [None, 1, decimal.Decimal(1)]
    multiple_ofList = [None, 1, decimal.Decimal(1)]
    precisionList = [None, '1', '1.1']
    allow_nullList = [True, False]


# Generated at 2022-06-22 05:49:57.638601
# Unit test for constructor of class Date
def test_Date():
    d1 = Date()
    assert d1.title == None
    assert d1.description == None
    assert d1.default == None
    assert d1.allow_null == False
    assert d1.read_only == False
    assert d1.write_only == False
    assert d1.min_length == None
    assert d1.max_length == None
    assert d1.pattern == None
    assert d1.format == 'date'
    assert d1.choices == None



# Generated at 2022-06-22 05:50:15.734793
# Unit test for constructor of class Object
def test_Object():
    import pprint
    from typing import Union, Dict

    class Car(Object):
        make: str
        model: str
        year: Union[int, float]
        fuel: Union[str, bool] = False
        passenger: int = 0

    pp = pprint.PrettyPrinter(indent=4)

    pp.pprint([getattr(Car, attr) for attr in dir(Car)])

# Generated at 2022-06-22 05:50:18.718686
# Unit test for method validate of class String
def test_String_validate():
    string_field = String()
    result = string_field.validate("a")
    assert result == "a"


# Generated at 2022-06-22 05:50:24.774486
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    # Test that method validation_error creates an ValidationError with the given code and the error message associated with that code
    schema = String(errors={'blank': 'Cannot be blank'})
    assert schema.validation_error('blank').message.code == 'blank'
    assert schema.validation_error('blank').message.text == 'Cannot be blank'



# Generated at 2022-06-22 05:50:31.568150
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True)==True
    assert b.validate(False)==False
    assert b.validate("off")==False
    assert b.validate("on")==True
    assert b.validate("1")==True
    assert b.validate("0")==False
    assert b.validate("null")==None
    assert b.validate(None)==None
    assert b.validate("")==False

    



# Generated at 2022-06-22 05:50:42.870738
# Unit test for constructor of class Number
def test_Number():

    def test_Number_without_type(x):
        numeric_type = type(x)
        if numeric_type is int:
            numeric_type = int
        else:
            numeric_type = float
        field = Number(minimum=0, maximum=5)
        assert field.minimum == 0
        assert field.maximum == 5
        assert field.numeric_type == numeric_type
        return 

    def test_Number_with_type(x, y):
        field = Number(minimum=x, maximum=y, numeric_type=y)
        assert field.minimum == x
        assert field.maximum == y
        assert field.numeric_type == y
        return 

    x = 2
    test_Number_without_type(x)
    y = float
    test_Number_with_type(x, y)



# Generated at 2022-06-22 05:50:45.571583
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field(title='', description='', default="haha")
    assert field.get_default_value() == "haha"


# Generated at 2022-06-22 05:50:51.470352
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    Field_object = Field(title='My title',description='My description',default='',allow_null=True)
    strict = True
    ValidationResult_object = Field_object.validate_or_error(value=None, strict=strict)
    assert ValidationResult_object.value == None
    assert ValidationResult_object.error == None

# Generated at 2022-06-22 05:50:54.683025
# Unit test for constructor of class Union
def test_Union():
    field1 = String()
    field2 = Int32()
    union = Union([field1, field2])
    assert union.allow_null == True


# Generated at 2022-06-22 05:50:59.681867
# Unit test for constructor of class Const
def test_Const():
    f = Const(1)
    try:
        f.validate(None)
        assert False
    except ValidationError:
        pass
    try:
        f.validate(2)
        assert False
    except ValidationError:
        pass
    assert f.validate(1) == 1

test_Const()



# Generated at 2022-06-22 05:51:00.313333
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean()
    

# Generated at 2022-06-22 05:51:10.697511
# Unit test for constructor of class Text
def test_Text():
    t = Text()
    assert t.name == None
    assert t.format == "text"
    assert t.allow_null == False
    assert t.has_default == False
    assert t.required == False



# Generated at 2022-06-22 05:51:14.708390
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1) == 1
    assert Number().validate(1.0) == 1.0
    assert Number().validate(1.5) == 1.5
    assert Number(allow_null=True).validate(None) == None
    assert Number().validate(True) == True
    assert Number().validate(False) == False
    assert Number().validate('') == ''
    assert Number().validate('abc') == 'abc'
    assert Number(allow_null=True).validate('') == None
    assert Number(allow_null=True).validate(None) == None
    assert Number().validate({}) == {}
    assert Number(allow_null=True).validate(()) == ()
    try:
        Number().validate('abc')
    except Exception:
        pass

# Generated at 2022-06-22 05:51:18.785873
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize(2) == 2
    assert String().serialize(datetime.datetime(2020,3,20)) == datetime.datetime(2020,3,20)
test_String_serialize()

# Generated at 2022-06-22 05:51:23.636457
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(1) == True
    assert Boolean().validate('on') == True
    assert Boolean().validate('1') == True
    assert Boolean().validate(0) == False
    assert Boolean().validate('') == False
    assert Boolean().validate('off') == False
    assert Boolean().validate('0') == False
    with pytest.raises(ValidationError):
        Boolean().validate('2')


# Generated at 2022-06-22 05:51:27.387740
# Unit test for method validate of class Any
def test_Any_validate():
    schema1 = Any()
    value1 = None
    result1 = schema1.validate(value1)
    assert result1 == None

    schema2 = Any()
    value2 = True
    result2 = schema2.validate(value2)
    assert result2 == True


# Generated at 2022-06-22 05:51:31.554425
# Unit test for constructor of class Time
def test_Time():
    t = Time(description="description_test")
    assert isinstance(t.description, str)
    assert t.description == "description_test"
    assert isinstance(t.format, str)
    assert t.format == "time"
    assert t.allow_null == False
    assert t.default == None
    assert t.required == False
    assert t.empty_str_is_null == False
    assert t.examples == None

# Generated at 2022-06-22 05:51:33.691322
# Unit test for constructor of class Integer
def test_Integer():
    assert isinstance(Integer(title="My integer"), Integer)


# Generated at 2022-06-22 05:51:37.998720
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field(title='title',description='description')
    # unknown keyword argument 'strict'
    assert_raises(TypeError, lambda: field.validate())
    assert_raises(NotImplementedError, lambda: field.validate(1, strict=False))



# Generated at 2022-06-22 05:51:45.734145
# Unit test for constructor of class Array
def test_Array():
    items = [Str()]
    field = Array(items=items, allow_null=False, add_prefix='', add_metadata={})
    assert item == [field.items]
    assert field.additional_items is False
    assert field.min_items is None
    assert field.max_items is None
    assert field.exact_items is None
    assert field.unique_items is False
    assert field.allow_null is False
    assert field.add_prefix == ''
    assert field.add_metadata == {}


# Generated at 2022-06-22 05:51:51.904056
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class Test(Field):
        def validate(self, value, strict=False):
            if value == '1':
                return True
    
    instance = Test()
    success = instance.validate_or_error('1')
    assert success.value == True and success.error == None
    failure = instance.validate_or_error('2')
    assert failure.error != None and failure.value == None



# Generated at 2022-06-22 05:52:04.743363
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    code = "test"
    str(field.validation_error(code)) == f"{field.get_error_text(code)}"
    
Field.validation_error(any(Field), "test")


# Generated at 2022-06-22 05:52:14.991894
# Unit test for method has_default of class Field
def test_Field_has_default():
    class TestField:
        def __init__(self, default):
            self.default = default
    t = TestField(False)
    assert t.has_default() == True
    t = TestField(0)
    assert t.has_default() == True
    t = TestField(None)
    assert t.has_default() == True
    t = TestField(True)
    assert t.has_default() == True
    t = TestField('hi')
    assert t.has_default() == True
    t = TestField([])
    assert t.has_default() == True
    t = TestField([1])
    assert t.has_default() == True
    t = TestField(())
    assert t.has_default() == True
    t = TestField((1,))
    assert t.has_default

# Generated at 2022-06-22 05:52:19.074993
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate('a') == 'a'
    
    



# Generated at 2022-06-22 05:52:27.807471
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test_none
    expected = None
    actual = Choice(choices=[]).validate(None)
    assert actual == expected
    # test_empty_string
    expected = ""
    actual = Choice(choices=[], allow_blank=True).validate("")
    assert actual == expected
    # test_empty_string_with_allow_null
    expected = None
    actual = Choice(choices=[], allow_blank=True, allow_null=True).validate("")
    assert actual == expected
    # test_choices
    expected = "yes"
    actual = Choice(choices=["yes", "no"]).validate("yes")
    assert actual == expected
    # test_choices_with_values
    expected = "a"

# Generated at 2022-06-22 05:52:30.034053
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert isinstance(time, Time)
    assert isinstance(time, Field)
    assert isinstance(time, type)



# Generated at 2022-06-22 05:52:30.843081
# Unit test for constructor of class Time
def test_Time():
    time = Time()


# Generated at 2022-06-22 05:52:34.764391
# Unit test for method serialize of class Field
def test_Field_serialize():
    number = Integer()
    assert number.serialize(1) == 1
    assert number.serialize(None) == None
    assert number.serialize('1') == '1'

# Generated at 2022-06-22 05:52:40.320272
# Unit test for constructor of class Date
def test_Date():
    f1 = Date()
    assert f1.errors == {"type": "Must be a string.",
                    "format": "Must be in format 'date'.",
                    "required": "This field is required.",
                    "null": "May not be null."}
    assert f1.allow_null == False
    assert f1.format == "date"


# Generated at 2022-06-22 05:52:45.752719
# Unit test for constructor of class Field
def test_Field():
    field = Field(title='myField', description='myDescription')
    assert isinstance(field, Field)
    assert field.title == 'myField'
    assert field.description == 'myDescription'
    assert field._creation_counter == 0  # pragma: no cover
    assert field.has_default() is False  # pragma: no cover


# Generated at 2022-06-22 05:52:48.609400
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.title == ""
    assert field.description == ""
    assert field.allow_null == False


# Generated at 2022-06-22 05:53:00.756902
# Unit test for method validate of class Choice
def test_Choice_validate():
    from . import Choice
    ch = Choice(choices=[("a","A"),("b","B"),("c","C")])
    try:
        ch.validate("d")
    except Choice.validation_error("choice"):
        return True
    except Exception:
        return False
    return False

# Generated at 2022-06-22 05:53:03.555374
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array(items=Integer())
    field.validate("3")
    field.validate([3.5, 4.5])
    field.validate([3, "test"])


# Generated at 2022-06-22 05:53:07.760479
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from typesystem.field import Field
    from typesystem.errors import ValidationError 
    field = Field()
    err = field.validation_error("test")
    assert isinstance(err, ValidationError)


# Generated at 2022-06-22 05:53:15.618297
# Unit test for method validate of class Array
def test_Array_validate():
    field = Array()
    assert field.validate(type) == type
    assert field.validate(None) == None
    assert field.validate(5) == 5
    assert field.validate('Alice') == 'Alice'
    assert field.validate(['step0', 0, [], {}, True, False, None]) == ['step0', 0, [], {}, True, False, None]
    assert field.validate([]) == []
    field = Array(allow_null=True)
    assert field.validate(None) == None
    field = Array(allow_null=False)
    assert field.validate(1) == 1
    assert field.validate(0.5) == 0.5
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field

# Generated at 2022-06-22 05:53:20.848160
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    try:
        assert Field().get_error_text('type')=='Expected type str but got type {}.'
    except:
        print(Field().get_error_text('type'))
        print('\nExpected type str but got type {}.')


# Generated at 2022-06-22 05:53:23.818086
# Unit test for constructor of class Decimal
def test_Decimal():
    errormessage = "Assertion error, Expected initialize with excess argument"
    try:
        obj = Decimal()
    except TypeError:
        assert True
    else:
        assert False, errormessage



# Generated at 2022-06-22 05:53:26.029199
# Unit test for method validate of class Choice
def test_Choice_validate():
    field=Choice()
    assert field.validate(value="")==""
    field.allow_null=True
    assert field.validate(value="")==None



# Generated at 2022-06-22 05:53:31.290889
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [
        Number(minimum=0, maximum=100, exclusive_maximum=True),
        String(max_length=50),
    ]
    arr = Array(items=items)
    data = [0, "1"]
    assert arr.serialize(data) == [0, "1"]



# Generated at 2022-06-22 05:53:37.989583
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        title = 'title'
        description = 'description'
        errors = {}
        default = 5
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value
    field = MyField()
    value = field.get_default_value()
    assert value ==  5, "get_default_value error"

# Generated at 2022-06-22 05:53:49.768410
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer.numeric_type == int
    assert Integer.errors["type"] == "Must be a number."
    assert Integer.errors["null"] == "May not be null."
    assert Integer.errors["integer"] == "Must be an integer."
    assert Integer.errors["finite"] == "Must be finite."
    assert Integer.errors["minimum"] == "Must be greater than or equal to {minimum}."
    assert Integer.errors["exclusive_minimum"] == "Must be greater than {exclusive_minimum}."
    assert Integer.errors["maximum"] == "Must be less than or equal to {maximum}."
    assert Integer.errors["exclusive_maximum"] == "Must be less than {exclusive_maximum}."
    assert Integer.errors["multiple_of"] == "Must be a multiple of {multiple_of}."
    assert Integer._creation_counter > 0


# Generated at 2022-06-22 05:54:07.585672
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=[('123', 123)]).validate(123) == 123
    assert Choice(choices=[('123', 123)]).validate(456) == 456



# Generated at 2022-06-22 05:54:09.998295
# Unit test for constructor of class Const
def test_Const():
    v = Const(1)
    assert v.const == 1
    assert v.allow_null == False
    v = Const(1, allow_null=True)
    assert v.const == 1
    assert v.allow_null == True

# Generated at 2022-06-22 05:54:12.636958
# Unit test for constructor of class Choice
def test_Choice():
    def compare(i, j):
        if i==j:
            print("Equal value")
        else:
            print("Not equal value")
    choice = Choice()
    compare(choice.validate(None, strict=False), None)
    compare(choice.choices, [])
    assert isinstance(choice, Field)
    assert isinstance(choice, Choice)


# Generated at 2022-06-22 05:54:18.228966
# Unit test for method validate of class String
def test_String_validate():
    # create an object of the class
    a = String()
    # create a dict object to store the values
    dict = {"a": a}
    # create a string object
    value = "Hello"
    # check if the validate() method returns the same value
    assert dict["a"].validate(value) == value

# Generated at 2022-06-22 05:54:25.570195
# Unit test for constructor of class Date
def test_Date():
    string_schema = Date()
    assert isinstance(string_schema, Field)
    assert string_schema.format == "date"

    string_schema = Date(title="Test")
    assert string_schema.title == "Test"
    string_schema = Date(description="desc")
    assert string_schema.description == "desc"
    string_schema = Date(default="def")
    assert string_schema.default == "def"
    string_schema = Date(required=True)
    assert string_schema.required == True
    string_schema = Date(allow_null=True)
    assert string_schema.allow_null == True
    string_schema = Date(const="const")
    assert string_schema.const == "const"


# Generated at 2022-06-22 05:54:27.593197
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert isinstance(Decimal().serialize(None), type(None))
    assert isinstance(Decimal().serialize(1), type(1.0))



# Generated at 2022-06-22 05:54:33.675301
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union(any_of=[String()]).validate(None) == None
    assert Union(any_of=[String(), Number()]).validate(None) == None
    assert Union(any_of=[String(allow_null=False), Number()]).validate(None) != None
    assert Union(any_of=[String(), Number()]).validate(1) == 1
    assert Union(any_of=[String(), Number()]).validate(1.1) == 1.1
    assert Union(any_of=[String(), Boolean()]).validate(True) == True
    assert Union(any_of=[Array()]).validate([]) == []
    assert Union(any_of=[Object()]).validate({}) == {}
    assert Union(any_of=[String(), Number()]).validate(1) == 1

# Generated at 2022-06-22 05:54:40.007257
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(name="decimal1").validate("0.21") == 0.21
    assert Decimal(name="decimal2").validate("0.21") == 0.21
    assert Decimal(name="decimal3").serialize("1") == 1.0
    assert Decimal(name="decimal4").serialize("1") == 1.0
    assert Decimal(name="decimal5").serialize("0.21") == 0.21
    assert Decimal(name="decimal6").serialize("0.21") == 0.21
    assert Decimal(name="decimal7").validate("0.21") == 0.21
    assert Decimal(name="decimal8").validate("0.21") == 0.21
    assert Decimal(name="decimal9").serialize("1") == 1.

# Generated at 2022-06-22 05:54:41.657492
# Unit test for constructor of class Decimal
def test_Decimal():
    assert isinstance(Decimal(), Decimal)



# Generated at 2022-06-22 05:54:43.540616
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field(default='').has_default() == True
    assert Field().has_default() == False

# Generated at 2022-06-22 05:54:55.800478
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field(default='q')
    assert f.has_default() == True


# Generated at 2022-06-22 05:54:57.921314
# Unit test for method serialize of class Field
def test_Field_serialize():
    obj = Field()
    assert obj.serialize(None) == None, "Field.serialize() failed the test"

# Generated at 2022-06-22 05:54:59.880466
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    ins = Field()
    assert ins.get_error_text("error1") == ""



# Generated at 2022-06-22 05:55:09.411246
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class MyField(Field):
        def __init__(self, *, title: str = "", description: str = "", default: typing.Any = NO_DEFAULT, allow_null: bool = False):
            super().__init__(title = title, description = description, default = default, allow_null = allow_null)
    field = MyField()
    assert field.get_default_value() is NO_DEFAULT

    @typing.no_type_check
    def default_value() -> str:
        return "default"

    field = MyField(default = default_value)
    assert field.get_default_value() == "default"


# Generated at 2022-06-22 05:55:10.521411
# Unit test for constructor of class Any
def test_Any():
    assert isinstance(Any(), Field)

# Testing if Any has the same error message as Field

# Generated at 2022-06-22 05:55:16.828911
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate("true") == True
    assert Boolean().validate("null") == None
    assert Boolean().validate("Null") == None
    assert Boolean().validate("NuLL") == None
    assert Boolean().validate("NULL") == None
    assert Boolean().validate("") == False
    assert Boolean().validate(True) == True



# Generated at 2022-06-22 05:55:18.619767
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer().numeric_type == int


# Generated at 2022-06-22 05:55:29.313841
# Unit test for constructor of class Object
def test_Object():
    obj_dict = {"test_key": Integer(allow_null=False)}

    obj_test = Object(
        required=["test_key"],
        additional_properties=False,
        max_properties=1,
        min_properties=1,
        properties=obj_dict,
        allow_null=False
    )
    assert(obj_test.required == ["test_key"])
    assert(obj_test.additional_properties == False)
    assert(obj_test.max_properties == 1)
    assert(obj_test.min_properties == 1)
    assert(obj_test.properties == obj_dict)
    assert(obj_test.allow_null == False)


# Generated at 2022-06-22 05:55:31.329893
# Unit test for method validate of class String
def test_String_validate():
    str_field = String(title="str_field")
    str_field.validate(None)
    assert str_field.validate(None) == None


# Generated at 2022-06-22 05:55:36.131625
# Unit test for method serialize of class String
def test_String_serialize():
    """
    String.serialize() should not serialize to valid formatted strings
    """
    st = String()
    assert st.serialize("") == ""
    assert st.serialize("test") == "test"
    assert st.serialize("test string with space") == "test string with space"
    assert st.serialize("test string with tab and new line") == "test string with tab and new line"



# Generated at 2022-06-22 05:56:03.149143
# Unit test for constructor of class Array
def test_Array():
    a = Array(items = String())
    assert(type(a) == Array)
    assert(type(a.items) == String)
    assert(type(a.errors) == dict)
    assert(type(a.required) == bool)
    assert(type(a.allow_null) == bool)
    assert(type(a.additional_items) == bool)
    assert(type(a.min_items) == None)
    assert(type(a.max_items) == None)
    assert(type(a.unique_items) == bool)

    a = Array(items = String(), additional_items = False)
    assert(a.additional_items == False)

    a = Array(items = String(), required = False)
    assert(a.required == False)
