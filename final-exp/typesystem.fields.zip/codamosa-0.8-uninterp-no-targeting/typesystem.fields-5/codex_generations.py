

# Generated at 2022-06-22 05:47:34.581155
# Unit test for method validate of class Const
def test_Const_validate():
    assert Const(1).validate(1) == 1
    with pytest.raises(ValidationError) as e:
        Const(1).validate("2")
    assert e.value.messages()[0].code == "const"
    with pytest.raises(ValidationError) as e:
        Const(1).validate("")
    assert e.value.messages()[0].code == "const"
    with pytest.raises(ValidationError) as e:
        Const(1).validate(None)
    assert e.value.messages()[0].code == "const"
    with pytest.raises(ValidationError) as e:
        Const(1).validate(None, strict=True)
    assert e.value.messages()[0].code == "const"


# Generated at 2022-06-22 05:47:36.284317
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime(max_length=30)
    print(dt)

# Generated at 2022-06-22 05:47:40.327553
# Unit test for method validate of class Number
def test_Number_validate():
    print("Testing validate() method of class Number...")
    f = Number()
    try:
        f.validate(None, strict=False)
    except:
        print("Error validating None. Should raise an error")
    val = f.validate(10)
    if val != 10:
        print("Error validating 10. Should return 10")
    val = f.validate(10.0)
    if val != 10.0:
        print("Error validating 10.0. Should return 10.0")
    try:
        f.validate(True)
    except:
        print("Error validating True. Should raise an error")
    try:
        f.validate(10.00001)
    except:
        print("Error validating 10.00001. Should raise an error")


# Generated at 2022-06-22 05:47:42.626443
# Unit test for method serialize of class Field
def test_Field_serialize():
    a = Field()
    assert a.serialize(123) == 123

# Generated at 2022-06-22 05:47:44.887703
# Unit test for method __or__ of class Field
def test_Field___or__():
    # Setup
    class Field1(Field):
        pass
    class Field2(Field):
        pass
    field1 = Field1()
    field2 = Field2()
    # Exercise
    union = field1 | field2
    # Verify
    assert isinstance(union, Union)
    assert union.any_of == [field1, field2]

# Generated at 2022-06-22 05:47:49.624681
# Unit test for method serialize of class Array
def test_Array_serialize():
    field = Array(items=Field())
    value = ["A", "B", "C"]
    assert field.serialize(value) == value

    field = Array(items=List(items=Field()))
    value = {"A": ["B","C"], "B": ["C", "D"]}
    assert field.serialize(value) == value


# Generated at 2022-06-22 05:47:53.051875
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_obj = Decimal()
    default_numeric_type = decimal.Decimal
    assert default_numeric_type == decimal_obj.numeric_type
    assert decimal_obj.numeric_type == decimal_obj.validate(1.5)



# Generated at 2022-06-22 05:47:54.853119
# Unit test for constructor of class Const
def test_Const():
    cons = Const(1000)
    assert cons.const == 1000


# Generated at 2022-06-22 05:47:57.376691
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    error_code = 'invalid'
    f = Field()
    f.errors[error_code] = "Input value is invalid"
    assert f.get_error_text(error_code) == "Input value is invalid"


# Generated at 2022-06-22 05:48:08.396115
# Unit test for method validate of class String
def test_String_validate():
    my_str = String(max_length=5, pattern=r'[A-Z]{3}[0-9]{3}[A-Z]{3}[0-9]{3}[A-Z]{3}[0-9]{3}')
    assert my_str.validate('ABCDE') == 'ABCDE'
    assert my_str.validate('ABCDEF') == None
    assert my_str.validate('ABCDEFGHIJ') == None
    assert my_str.validate(None) == None 
    my_str2 = String(max_length=5, pattern=r'[A-Z]{3}[0-9]{3}[A-Z]{3}[0-9]{3}[A-Z]{3}[0-9]{3}')

# Generated at 2022-06-22 05:48:19.768181
# Unit test for constructor of class Any
def test_Any():
    obj = Any(allow_null=True)
    assert obj.allow_null == True



# Generated at 2022-06-22 05:48:27.098059
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    a = Boolean()
    assert a.validate(True) == True
    assert a.validate("true") == True
    assert a.validate("on") == True
    assert a.validate("1") == True
    assert a.validate("false") == False
    assert a.validate("off") == False
    assert a.validate("0") == False
    assert a.validate("") == False
    assert a.validate("asd") == False
    assert a.validate("null") == False
    assert a.validate(1) == True
    assert a.validate(0) == False
    assert a.validate(None) == None
    assert a.validate("   ") == False
    assert a.validate("") == False
    assert a.validate("true1") == False



# Generated at 2022-06-22 05:48:31.276453
# Unit test for constructor of class Object
def test_Object():
    # Case 1: normal case
    obj = Object(properties={"a": Integer(), "b": Integer()}, null=True, default=1)
    obj.validate(None)
    obj.validate({"a": 1})
    obj.validate({"b": 1})
    obj.validate({"a": 1, "b": 1})
    try:
        obj.validate({"a", 1})
        assert False
    except ValidationError:
        pass
    try:
        obj.validate({"b", 1})
        assert False
    except ValidationError:
        pass
    try:
        obj.validate({"a", 1, "b", 1})
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-22 05:48:33.118180
# Unit test for method validate of class Any
def test_Any_validate():
    # Unit tests for class Any
    # Method: validate
    # Error: no error
    obj       = Any()
    expected  = {'a': 1}
    computed  = obj.validate(value={'a': 1})
    assert computed == expected



# Generated at 2022-06-22 05:48:38.406667
# Unit test for method validate of class Field
def test_Field_validate():
    import unittest

    class FieldTests2(unittest.TestCase):
        def test_validate_1(self):
            from typesystem import Integer

            field = Integer()
            value = field.validate(10)
            assert value == 10

    t = FieldTests2()
    t.test_validate_1()


# Generated at 2022-06-22 05:48:40.648542
# Unit test for method validate of class Any
def test_Any_validate():
    x = Any()
    x.validate(None, strict=False) # -> None


# Generated at 2022-06-22 05:48:45.380902
# Unit test for method validate of class Object
def test_Object_validate():
    value1 = {"isolation_property": "transaction_scoped", "data_type": "OBJECT"}
    schema1 = Object(properties={'isolation_property': String()})
    r1 = schema1.validate(value1)
    assert r1 == {"isolation_property": "transaction_scoped"}

    # Check if default value is returned if value is missing in dictionary
    value2 = {"data_type": "OBJECT"}
    schema2 = Object(properties={'isolation_property': String(default='transaction_scoped')})
    r2 = schema2.validate(value2)
    assert r2 == {"isolation_property": "transaction_scoped"}

    # Check if validation error is observed if the type of the value is not object
    value3 = "{"

# Generated at 2022-06-22 05:48:47.345238
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    assert field.validate("test") is not None
# End of unit test


# Generated at 2022-06-22 05:48:53.838444
# Unit test for constructor of class Decimal
def test_Decimal():
    field = Decimal(minimum=100, maximum=200)

    # if (minimum is not None) and self.minimum > value:
    assert field.validate(90) # 90 < 100
    assert field.validate(110) # 110 > 100
    assert field.validate(90, True)

    # if self.maximum is not None and value > self.maximum:
    assert field.validate(220) # 220 > 200
    assert field.validate(180) # 180 < 200


# Generated at 2022-06-22 05:48:57.564523
# Unit test for constructor of class Text
def test_Text():
    text_field = Text()
    assert text_field.format == "text" and text_field.allow_null



# Generated at 2022-06-22 05:50:01.922367
# Unit test for method serialize of class Field
def test_Field_serialize():
    print("Unit test Field.serialize")

    class TypedField(Field):
        def __init__(self, type):
            super().__init__()
            self.type = type

        def validate(self, value):
            return self.type(value)

    i32 = TypedField(int)

    assert i32.serialize(1) == 1



# Generated at 2022-06-22 05:50:05.018099
# Unit test for method has_default of class Field
def test_Field_has_default():
        obj1 = Field(title='', description='', default=NO_DEFAULT, allow_null=False)
        assert obj1.has_default() == hasattr(obj1, "default")


# Generated at 2022-06-22 05:50:05.735868
# Unit test for constructor of class Integer
def test_Integer():
    x = Integer(minimum=1)
    assert x.minimum == 1


# Generated at 2022-06-22 05:50:07.251994
# Unit test for method validate of class Any
def test_Any_validate():
    b = Any()
    assert b.validate("hi") == "hi"
    assert b.validate(1) == 1


# Generated at 2022-06-22 05:50:08.209738
# Unit test for method has_default of class Field
def test_Field_has_default():
    print("test Field has_default start")
    assert Field().has_default() == False
    print("test Field has_default done")

# Generated at 2022-06-22 05:50:16.644713
# Unit test for constructor of class Boolean
def test_Boolean():
    #constructor of class Boolean
    testObj = Boolean()
    expected_result = {'allow_null': False, '_creation_counter': 0, 'title': '', 'description': ''}
    result = testObj.__dict__ 
    assert result == expected_result
    # constructor of class Boolean
    testObj = Boolean(title='string', description='string', allow_null=True)
    expected_result = {'allow_null': True, '_creation_counter': 1, 'title': 'string', 'description': 'string'}
    result = testObj.__dict__ 
    assert result == expected_result


# Generated at 2022-06-22 05:50:23.059086
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime()
    assert dt.format == "datetime"
    assert dt.allow_null is False
    assert dt.default is None
    assert dt.required is False
    assert dt.name == "datetime"
    assert dt.error_messages == String.errors
    assert dt.allow_empty is True
    assert dt.min_length is None
    assert dt.max_length is None
    assert dt.pattern is None


# Generated at 2022-06-22 05:50:26.734832
# Unit test for method validation_error of class Field

# Generated at 2022-06-22 05:50:28.628500
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(None) == None


# Generated at 2022-06-22 05:50:40.405927
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    inst = Boolean(allow_null= True)
    assert inst.validate(True, strict=True) == True
    assert inst.validate(False, strict=True) == False
    assert inst.validate(None, strict=False) == None
    assert inst.validate("false", strict=False) == False
    assert inst.validate("", strict=False) == False
    assert inst.validate("null", strict=False) == None
    assert inst.validate("", strict=True) == False
    assert inst.validate("null", strict=True) == True
    assert inst.validate("", strict=False) == False
    inst2 = Boolean()
    assert inst2.validate(True, strict=True) == True
    assert inst2.validate(False, strict=True) == False

# Generated at 2022-06-22 05:50:48.374105
# Unit test for constructor of class Text
def test_Text():
    assert Text().format == "text"



# Generated at 2022-06-22 05:50:53.468188
# Unit test for constructor of class Decimal
def test_Decimal():
    from decimal import Decimal
    from typesystem.fields import Decimal as _Decimal
    d = Decimal('-3.14')
    dd = _Decimal(minimum=d,maximum=d)
    assert dd.minimum == d
    assert dd.maximum == d


# Generated at 2022-06-22 05:51:04.515867
# Unit test for method validate of class Object
def test_Object_validate():
    # creating a student object of class Student
    # creating a student object of class Student
    student_properties = {
        "first_name": fields.Str(required=True, min_length=2, max_length=10),
        "last_name": fields.Str(required=True, min_length=2, max_length=10),
        "student_number": fields.Int(required=True, minimum=1, maximum=300),
        "courses": fields.List(fields.Str, required=True, min_items=1, max_items=4),
        "is_active": fields.Boolean(required=True),
    }

    student = fields.Object(properties=student_properties)


# Generated at 2022-06-22 05:51:11.391573
# Unit test for constructor of class Integer
def test_Integer():

    # For string which does not contain a integer number, Integer constructor cannot
    # parse it to an integer number
    with pytest.raises(ValidationError) as ve:
        Integer().validate("asdfasdf")  # pragma: no cover

    assert ve.value.code == "type"

    # For float number, Integer constructor can parse it to an integer number
    assert Integer().validate(123.0) == 123
    assert Integer().validate("123.0") == 123



# Generated at 2022-06-22 05:51:17.065648
# Unit test for constructor of class Choice
def test_Choice():
    assert len(Choice(allow_null=True).choices) == 0
    assert len(Choice(allow_null=True, choices=None).choices) == 0
    assert len(Choice(allow_null=True, choices=['a']).choices) == 1
    assert len(Choice(allow_null=True, choices=[('a', 'a')]).choices) == 1
    assert len(Choice(allow_null=True, choices=['a', 'b', 'c']).choices) == 3
    assert len(Choice(allow_null=True, choices=[('a', 'a'), ('b', 'b'), ('c', 'c')]).choices) == 3


# Generated at 2022-06-22 05:51:19.217874
# Unit test for constructor of class String
def test_String():
    s = String(title="Title of a string.", description="This is a string.")
    assert s.title == "Title of a string."
    assert s.description == "This is a string."



# Generated at 2022-06-22 05:51:27.735354
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    bool_val = Boolean()
    bool_val1 = Boolean(allow_null=True)
    bool_val2 = Boolean(allow_null=False)
    bool_val3 = Boolean(allow_null=False, title="abc", description="def", default=True)
    bool_val4 = Boolean(allow_null=True, title="abc", description="def", default=False)
    bool_val5 = Boolean(allow_null=True, title="abc", description="def", default=None)
    bool_val6 = Boolean(allow_null=True, title="abc", description="def")
    bool_val7 = Boolean(allow_null=False, title="abc", description="def")

    # Assert True
    assert bool_val.validate(True) == True
    assert bool_val1.validate(True) == True

# Generated at 2022-06-22 05:51:28.901378
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    test = Field()

    assert test.get_default_value() == None


# Generated at 2022-06-22 05:51:29.484897
# Unit test for constructor of class Const
def test_Const():
    assert Const(None).const is None



# Generated at 2022-06-22 05:51:31.647856
# Unit test for constructor of class Any
def test_Any():
    anyValue = Any()
    assert isinstance(anyValue, Any)


# Generated at 2022-06-22 05:51:50.683360
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number(minimum=4,maximum=8)
    assert a.validate(1) == 1  # raise self.validation_error("minimum")
    assert a.validate(12) == 12 # raise self.validation_error("maximum")
    assert a.validate(5) == 5

    b = Number(multiple_of=2)
    assert b.validate(3) == 3 # raise self.validation_error("multiple_of")
    assert b.validate(2) == 2
    assert b.validate(25) == 25

    c = Integer()
    assert c.validate(10.5) == 10.5 # raise self.validation_error("integer")
    assert c.validate(-2.2) == -2.2
    assert c.validate(10) == 10





# Generated at 2022-06-22 05:51:52.301752
# Unit test for method validate of class Union
def test_Union_validate():
    assert Union.validate(None, parameter=1) == 1



# Generated at 2022-06-22 05:52:02.552762
# Unit test for constructor of class String
def test_String():
    string_field = String(title="Age", description="Age Description", default='a', allow_null=True,\
     allow_blank=False, trim_whitespace=True, max_length=2, min_length=2, pattern='abc', format='date')

    assert string_field.title == "Age"
    assert string_field.description == "Age Description"
    assert string_field.get_default_value() == 'a'
    assert string_field.allow_blank == False
    assert string_field.trim_whitespace == True
    assert string_field.max_length == 2
    assert string_field.min_length == 2
    assert string_field.pattern == 'abc'
    assert string_field.format == 'date'


# Generated at 2022-06-22 05:52:03.664752
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    instance = Field()
    assert instance.get_default_value() is None


# Generated at 2022-06-22 05:52:06.611619
# Unit test for method validate of class Object
def test_Object_validate():
    obj = Object(properties={"foo": Integer()}, required=["foo"])
    obj.validate({"foo": 3})
    with pytest.raises(ValidationError):
        obj.validate({"foo": 1.1})



# Generated at 2022-06-22 05:52:09.598866
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    decimal_field = Decimal()
    assert decimal_field.serialize(None) == None
    assert decimal_field.serialize(decimal.Decimal(1.0)) == float(1)



# Generated at 2022-06-22 05:52:13.082142
# Unit test for constructor of class Const
def test_Const():
    field = Const(1, allow_null=True)
    assert field.const == 1
    assert field.allow_null == True
    return



# Generated at 2022-06-22 05:52:22.350308
# Unit test for method validate of class Union
def test_Union_validate():
    string_field = String(name="string_field", description="string_field")
    boolean_field = String(name="boolean_field", description="boolean_field")
    union_field = Union(
        name="union_field", description="union_field", any_of=[string_field, boolean_field]
    )
    assert union_field.validate("string") == "string"
    assert union_field.validate(True) == True
    assert union_field.validate({"object": "object"}) == {"object": "object"}
    assert union_field.validate({"object": "object"}) == {"object": "object"}
    assert union_field.validate(None) is None

test_Union_validate()


# Generated at 2022-06-22 05:52:24.781718
# Unit test for method serialize of class Field
def test_Field_serialize():
  assert Field().serialize("test") == "test"



# Generated at 2022-06-22 05:52:27.282884
# Unit test for constructor of class DateTime
def test_DateTime():
    data = "2018-04-27T14:14:43.926583"
    assert data == DateTime().validate(data)


# Generated at 2022-06-22 05:52:47.452480
# Unit test for constructor of class Array
def test_Array():
    item = String()
    array = Array(item)
    assert array.items == item
    assert array.additional_items == False
    assert array.min_items is None
    assert array.max_items is None
    assert array.unique_items == False

    array = Array(items=item)
    assert array.items == item
    assert array.additional_items == False
    assert array.min_items is None
    assert array.max_items is None
    assert array.unique_items == False

    array = Array(items=item, additional_items=True)
    assert array.items == item
    assert array.additional_items == True
    assert array.min_items is None
    assert array.max_items is None
    assert array.unique_items == False


# Generated at 2022-06-22 05:52:48.205544
# Unit test for constructor of class Any
def test_Any():
    assert Any("foo", title="bar") is not None


# Generated at 2022-06-22 05:52:53.156311
# Unit test for method has_default of class Field
def test_Field_has_default():
    # Test 1
    string = String()
    assert string.has_default() == False
    # Test 2
    string = String(default="abc")
    assert string.has_default() == True
    # Test 3
    string = String(default=set())
    assert string.has_default() == True

# Generated at 2022-06-22 05:53:01.829168
# Unit test for constructor of class Field
def test_Field():
    try:
        Field()
        assert False
    except:
        assert True
    try:
        Field(title=1)
        assert False
    except:
        assert True
    try:
        Field(description=1)
        assert False
    except:
        assert True
    try:
        Field(title='haha', description='haha', default=1)
        assert False
    except:
        assert True
    Field(title='haha', description='haha')
    Field(title='haha', description='haha', default=1, allow_null=True)
    return True


# Generated at 2022-06-22 05:53:04.402074
# Unit test for constructor of class Number
def test_Number():
    number_object = Number()
    assert isinstance(number_object, Number)


# Generated at 2022-06-22 05:53:09.855108
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice()
    assert choice.validate("b") == "b"
    assert choice.validate("c") == "c"
    assert choice.validate("d") == "d"
    assert choice.validate("e") == "e"
    assert choice.validate("f") == "f"


# Generated at 2022-06-22 05:53:21.683627
# Unit test for method validate of class Choice
def test_Choice_validate():
    # Small integer
    field = Choice(choices=[1,2,3])
    value = field.validate(1)
    assert value == 1
    value = field.validate(4)
    assert value is None
    # Big integer
    field = Choice(choices=[5555555555555])
    value = field.validate(5555555555555)
    assert value == 5555555555555
    value = field.validate(5)
    assert value is None
    # Float
    field = Choice(choices=[1.0])
    value = field.validate(1.0)
    assert value == 1.0
    value = field.validate(1)
    assert value is None
    # String
    field = Choice(choices=["1"])

# Generated at 2022-06-22 05:53:25.048626
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Create an instance of class Field
    field = Field()

    # Test method get_default_value
    assert field.get_default_value() == None
    assert field.get_default_value() is not None

# Generated at 2022-06-22 05:53:35.907599
# Unit test for constructor of class Array
def test_Array():
    items = Field()
    additional_items = True
    min_items = None
    max_items = None
    unique_items = False

    items = list(items) if isinstance(items, (list, tuple)) else items
    assert (
        items is None
        or isinstance(items, Field)
        or (isinstance(items, list) and all(isinstance(i, Field) for i in items))
    )
    assert isinstance(additional_items, bool) or isinstance(additional_items, Field)
    assert min_items is None or isinstance(min_items, int)
    assert max_items is None or isinstance(max_items, int)
    assert isinstance(unique_items, bool)
    print('Pass Unit test for constructor of class Array')



# Generated at 2022-06-22 05:53:39.172316
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from typesystem.fields import Field
    from typesystem.exceptions import ValidationError
    field = Field()
    assert isinstance(field.validation_error("test_code"), ValidationError)



# Generated at 2022-06-22 05:53:50.811598
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class testField(Field):
        errors = {
            ' ' : ' ',
            'required': 'required',
        }
    field = testField(title='',description='')
    assert field.get_error_text('required') == 'required'
    assert field.get_error_text(' ') == ' '


# Generated at 2022-06-22 05:54:00.974142
# Unit test for method validate of class String
def test_String_validate():
    class ExampleSchema(Schema):
        foo: str

    schema = ExampleSchema()

    @schema.validator()
    def validate_foo(schema, obj, errors):
        if obj["foo"] == "bar":
            errors["foo"].append(
                Message("Cannot set foo to bar.", code="foo_bar")
            )

    instance = schema.validated({"foo": "bar"})

    assert isinstance(instance.errors, list)
    assert len(instance.errors) == 1
    assert instance.errors[0].code == "foo_bar"
    assert instance.errors[0].type is type(None)
    assert instance.errors[0].value == "bar"
    assert instance.errors[0].path == ("foo",)



# Generated at 2022-06-22 05:54:04.701992
# Unit test for constructor of class Date
def test_Date():
    try:
        Date()
    except:
        import sys
        print("Failed to construct Date", file=sys.stderr)
        raise



# Generated at 2022-06-22 05:54:06.384992
# Unit test for method serialize of class String
def test_String_serialize():
    str = String(format = "datetime")
    expected = "2019-01-01T12:00:00"
    returned = str.serialize("2019-01-01T12:00:00")
    assert expected == returned


# Generated at 2022-06-22 05:54:11.859490
# Unit test for method validate of class Choice
def test_Choice_validate():
    number_field = Choice(choices=[1,2,3,4])
    assert(number_field.validate(2) == 2)
    assert(number_field.validate("2") == "2")
    assert(number_field.validate(None) == None)
    #assert(number_field.validate("abc") == "abc")
    assert(number_field.validate(4) == 4)


# Generated at 2022-06-22 05:54:14.653393
# Unit test for constructor of class Time
def test_Time():
    testClass = Time()
    assert testClass is not None


# Generated at 2022-06-22 05:54:21.946037
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from typesystem.fields import Any, Field, String

    # Setup variables
    any = Any()
    string = String()

    # Test
    assert any.validation_error("invalid") == ValidationError(text=None, code="invalid")
    assert string.validation_error("invalid") == ValidationError(text=None, code="invalid")
    assert any.is_valid("helloworld") == True
    assert string.is_valid("helloworld") == True


# Generated at 2022-06-22 05:54:23.948076
# Unit test for constructor of class String
def test_String():
    assert String(title="", description="", default=NO_DEFAULT, allow_null=False)


# Generated at 2022-06-22 05:54:27.439786
# Unit test for constructor of class Any
def test_Any():
    assert Any().validate('x')
    assert Any().validate(None)
    assert Any().validate_or_error('x')[0] == 'x'
    assert Any().validate_or_error(None)[0] == None
    assert Any().has_default()
    assert Any().get_default_value() == None


# Generated at 2022-06-22 05:54:38.345036
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    from typesystem.fields import (
        String,
        Integer,
        Boolean,
        Array,
        Object,
        Number,
        Constant,
        is_constant,
        is_regex,
        is_list,
        is_dict,
    )
    from typesystem import Validator, Message
    
    class TextField(String):
        errors = {
            "min_length": "'{value}' is shorter than the minimum length of {min_length}",
            "max_length": "'{value}' is longer than the maximum length of {max_length}",
            "regex": "'{value}' does not match the regular expression {regex}",
            "parse": "'{value}' is not a valid string.",
            "optional": "This field may not be null.",
        }

# Generated at 2022-06-22 05:54:48.517629
# Unit test for constructor of class Decimal
def test_Decimal():
    max_val = 10
    min_val = 0
    d_number = Decimal(maximum = max_val, minimum = min_val)
    assert d_number.maximum == max_val
    assert d_number.minimum == min_val
    assert d_number.serialize(5) == 5.0



# Generated at 2022-06-22 05:54:59.967504
# Unit test for constructor of class DateTime
def test_DateTime():
    dt1 = DateTime()
    assert dt1.format == 'datetime'
    assert dt1.strict == False
    assert dt1.allow_null == False
    assert dt1.serializer == None
    assert dt1.deserializer == None
    dt2 = DateTime(strict = True, allow_null = True, serializer = str, deserializer = int)
    assert dt2.format == 'datetime'
    assert dt2.strict == True
    assert dt2.allow_null == True
    assert dt2.serializer == str
    assert dt2.deserializer == int


# Generated at 2022-06-22 05:55:04.256574
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem import fields

    class TestField(fields.Field):
        def validate(self, value, **_):
            return value[::-1]

    assert TestField().validate_or_error("hello") ==  ValidationResult(value="olleh", error=None)

# Generated at 2022-06-22 05:55:09.726796
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean(True).validate(True) == True
    assert Boolean(True).validate(False) == False
    assert Boolean(True).validate(None) == None
    
    assert Boolean(True, allow_null = True).validate(None) == None
    assert Boolean(True, allow_null = True).validate(True) == True
    assert Boolean(True, allow_null = True).validate(False) == False
    
    assert Boolean(True, allow_null = True).validate('') == None
    assert Boolean(True, allow_null = False).validate('') == False
    
    assert Boolean(True, allow_null = True).validate('true') == True
    assert Boolean(True, allow_null = True).validate('false') == False

# Generated at 2022-06-22 05:55:13.252405
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    a = Field()
    assert a.has_default() == False
    b = Field(default=4)
    assert b.has_default() == True
    c = Field(default="test")
    assert c.has_default() == True


# Generated at 2022-06-22 05:55:15.834434
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    f = Field()
    assert f.get_error_text('error') is not None

# Generated at 2022-06-22 05:55:21.783004
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    assert string.allow_blank is False
    assert string.trim_whitespace is True
    assert string.max_length is None
    assert string.min_length is None
    assert string.pattern_regex is None
    with pytest.raises(AssertionError):
        assert string.format is None

    str_1 = string.validate('abc')
    assert str_1 == 'abc'


# Generated at 2022-06-22 05:55:31.632551
# Unit test for method serialize of class Array
def test_Array_serialize():
    print("clean up the env")
    # clean up the env
    del os.environ['schema_Array_serialize']

    print("create a new environment var")
    command_create_env = "export schema_Array_serialize='[1,2,3]'"
    os.system(command_create_env)

    # create a new environment var
    print("load the env var with method load_env")
    env = load_env()
    print("env:",env)
    array = Array()
    print("serialize the env var with method serialize")
    print(array.serialize(env['schema_Array_serialize']))
    # serialize the env var with method serialize

    print("delete the env")
    command_delete_env = "unset schema_Array_serialize"

# Generated at 2022-06-22 05:55:39.030065
# Unit test for constructor of class Decimal
def test_Decimal():
    test = Decimal()
    assert test.validation_error("type").text == "Must be a number."
    test_default = Decimal(default = "")
    assert test_default.get_default_value() == ""
    assert test.validate(1.5) == 1.5
    assert test.validate(1) == 1
    assert test.validate(True) == True
    assert test.validate(None) == None
    assert test.serialize(2) == 2.0
    assert test.serialize(None) == None



# Generated at 2022-06-22 05:55:42.013673
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    field = Field(title="", description="", allow_null=False)
    value = field.validate_or_error("1")
    assert value is not None
