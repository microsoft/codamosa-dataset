

# Generated at 2022-06-22 05:49:05.032984
# Unit test for method validate of class String
def test_String_validate():
    title = "title"
    description = "description"
    allow_blank = False
    trim_whitespace = True
    max_length = None
    min_length = None
    pattern = None
    format = None
    i = 0
    s = String(title=title, description=description, default=None)
    for i in range(1):
        s.validate(True)
    for i in range(1):
        s.validate(1)
    for i in range(1):
        s.validate(1.0)
    for i in range(1):
        s.validate("World!")
    for i in range(1):
        s.validate("")
    for i in range(1):
        s.validate(None)
    print("Test passed")


# Generated at 2022-06-22 05:49:06.117286
# Unit test for constructor of class Time
def test_Time():
    field = Time()
    assert field.format == "time"



# Generated at 2022-06-22 05:49:18.394244
# Unit test for method validate of class Array
def test_Array_validate():
    class Color(Enum):
        red = 1
        green = 2
        blue = 3

    from .schema import Schema

    model = {
        "colors": Array(items=Array(items=Color()), min_items=2, max_items=4)
    }
    schema = Schema(model)
    validate = schema.validate

    # Min/max items
    with pytest.raises(ValidationError) as exc_info:
        validate({"colors": [[]]})
    assert exc_info.value.messages == [
        Message(text="Must have at least 2 items.", code="min_items")
    ]

    with pytest.raises(ValidationError) as exc_info:
        validate({"colors": [[], []]})

# Generated at 2022-06-22 05:49:21.089630
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    Field.errors = {"not_null": "Field must not be null"}

    field = Field(allow_null=False)
    assert field.validation_error("not_null").code == "not_null"



# Generated at 2022-06-22 05:49:23.713053
# Unit test for constructor of class Field
def test_Field():
    field = Field(title = "Name", description= "", default=NO_DEFAULT, allow_null=True)
    assert isinstance(field, Field)
#test_Field()



# Generated at 2022-06-22 05:49:26.842313
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    field.default = "abc"

    assert field.has_default()

    field.default = NO_DEFAULT

    assert not field.has_default()


# Generated at 2022-06-22 05:49:37.653383
# Unit test for method validate of class Union
def test_Union_validate():
    # Union of primitives
    field = Union([String(), Integer()])
    field.validate('test')
    field.validate(1)
    with pytest.raises(ValidationError):
        field.validate(1.5)
    with pytest.raises(ValidationError):
        field.validate(False)

    # Union with nullable
    field = Union([String(allow_null=True), Integer()])
    field.validate('test')
    field.validate(1)
    field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(1.5)
    with pytest.raises(ValidationError):
        field.validate(False)

    # Union of arrays

# Generated at 2022-06-22 05:49:41.486445
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal(precision='.0001')
    assert(d.precision is '.0001')
    d = Decimal()
    assert(d.precision is None)


# Generated at 2022-06-22 05:49:46.181221
# Unit test for method validate of class Number
def test_Number_validate():
    a = Number(minimum = 2)
    assert a.validate(3) == 3
    assert a.validate("4") == 4
    try:
        a.validate("0")
    except ValidationError:
        b = True
    assert b
    print("Test : class Number")


# Generated at 2022-06-22 05:49:48.049078
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(allow_null=True, choices=[])
    assert choice.choices == []
    assert choice.validate(1) == 1
    assert choice.validate_or_error(1).value == 1



# Generated at 2022-06-22 05:50:03.202696
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    a, b, c = "a", "b", "c"
    a_default = lambda: a
    b_default = lambda: b
    c_default = c

    assert field.get_default_value() is None

    field.default = a_default
    assert field.get_default_value() == a_default()

    field.default = b_default
    assert field.get_default_value() == b_default()

    field.default = c_default
    assert field.get_default_value() == c_default

# Generated at 2022-06-22 05:50:04.343632
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    assert field.format == "text"


# Generated at 2022-06-22 05:50:06.547082
# Unit test for method validate of class Any
def test_Any_validate():
    any_field_empty_default = Any(default="")
    assert any_field_empty_default.validate("any") == "any"
    assert any_field_empty_default.validate("") == ""
    assert any_field_empty_default.validate(None) == ""
    assert any_field_empty_default.validate({}) == {}



# Generated at 2022-06-22 05:50:09.006460
# Unit test for constructor of class Union
def test_Union():
    u = Union([Boolean(), Integer(), Float()])
    assert u.any_of == [Boolean(), Integer(), Float()]
    u = Union([Boolean(allow_null=True), Integer(), Float()])
    assert u.allow_null == True


# Generated at 2022-06-22 05:50:13.294719
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    from typesystem import Integer
    field = Integer()
    assert field.validation_error('invalid') == ValidationError(text='Enter a valid number.', code='invalid')

# Generated at 2022-06-22 05:50:14.205341
# Unit test for constructor of class Const
def test_Const():
    Const(const=None)


# Generated at 2022-06-22 05:50:19.499620
# Unit test for method validate of class Const
def test_Const_validate():
    import unittest.mock as mock
    schema = Const(1)
    assert schema.validate(1) == 1
    assert schema.validate(2) == "Must be the value '1'."
    assert schema.validate(None) == "Must be null."

    schema = Const(None, allow_null=True)
    assert schema.validate(None) == None



# Generated at 2022-06-22 05:50:28.589900
# Unit test for method validate of class Union
def test_Union_validate():
    from datetime import datetime
    schema = Union([Integer(),DateTime()])
    schema.validate(10)
    schema.validate("2019-08-22T12:32:23+02:00")
    try:
        schema.validate(10.5)
        assert False
    except ValidationError:
        pass
    try:
        schema.validate("2019")
        assert False
    except ValidationError:
        pass
    try:
        schema.validate(None)
        assert False
    except ValidationError:
        pass
test_Union_validate()



# Generated at 2022-06-22 05:50:31.509836
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Int(), Float()]
    union_object = Union(any_of)
    result = union_object.validate("a")
    assert result == 0



# Generated at 2022-06-22 05:50:36.076972
# Unit test for constructor of class Integer
def test_Integer():
    from typesystem.number import Integer
    integer = Integer()
    assert integer.validate(1) == 1
    assert integer.validate("1") == 1
    assert integer.validate("1.1") == 1



# Generated at 2022-06-22 05:50:51.209590
# Unit test for constructor of class Const
def test_Const():
    f = Const(0)
    assert f.const == 0


# Generated at 2022-06-22 05:50:54.033573
# Unit test for constructor of class DateTime
def test_DateTime():
    try:
        my_format = DateTime(format="my_format")
    except ValueError as e:
        print(e)
        my_format = DateTime()
    assert my_format.format == "datetime"


# Generated at 2022-06-22 05:51:00.673908
# Unit test for constructor of class Choice
def test_Choice():
    # case 1.
    import pytest
    from hapic.error.main import ErrorBuilderInterface
    with pytest.raises(AssertionError) as ex:
        class Test:
            class Schema:
                my_choice = Choice(choices=[["a"]], required=True)

        assert ex

    # case 2.
    class Test:
        class Schema:
            my_choice = Choice(choices=[("a", "A")], required=True)



# Generated at 2022-06-22 05:51:02.603017
# Unit test for constructor of class Boolean
def test_Boolean():
    assert hasattr(Boolean, "allow_null")
    assert Boolean.allow_null == False


# Generated at 2022-06-22 05:51:04.051421
# Unit test for constructor of class Array
def test_Array():
    array_test = Array(
        items=[Field(), Field()],
        additional_items=True,
        min_items=1,
        max_items=10,
        unique_items=False,
    )

# Generated at 2022-06-22 05:51:06.039616
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f.numeric_type == float


# Generated at 2022-06-22 05:51:14.856263
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal(min_decimal_places=1,max_decimal_places=3,default = Decimal('0.0'))
    d.validate(Decimal('0.0'))
    d.validate(Decimal('0.1'))
    d.validate(Decimal('0.01'))
    d.validate(Decimal('0.001'))
    # d.validate(Decimal('0.0001'))
    d.validate(Decimal('12.23'))
    # d.validate(Decimal('12.234'))
    d.validate(Decimal('12'))
    d.validate(Decimal('-12.23'))
    d.validate(Decimal('-12'))
    d.validate(Decimal('0'))
   

# Generated at 2022-06-22 05:51:17.819913
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field = Decimal()
    obj = None
    value = field.serialize(obj)
    assert value is None


# Generated at 2022-06-22 05:51:28.779570
# Unit test for method validate of class Number
def test_Number_validate():
    test_obj = Number()
    test_obj.allow_null = True
    assert test_obj.validate(None) == None
    test_obj.allow_null = False
    test_obj.minimum = 1
    assert test_obj.validate(0) == None
    test_obj.minimum = None
    test_obj.maximum = 1
    assert test_obj.validate(2) == None
    test_obj.maximum = None
    test_obj.exclusive_minimum = 1
    assert test_obj.validate(1) == None
    test_obj.exclusive_minimum = None
    test_obj.exclusive_maximum = 1
    assert test_obj.validate(1) == None
    test_obj.exclusive_maximum = None
    test_obj.multiple_of = 1
    assert test_obj.validate

# Generated at 2022-06-22 05:51:40.739125
# Unit test for method serialize of class Array
def test_Array_serialize():
    test = Array(items = Integer(min = 5, max = 8), min_items = 3, max_items = 5)
    print(test.serialize([5,6,7,8,9]))
    test = Array(items = Integer(min = 5, max = 8), min_items = 3, max_items = 5)
    print(test.serialize([5,8,9,7]))
    test = Array(items = Integer(min = 5, max = 8), min_items = 3, max_items = 5)
    print(test.serialize([1,2,3,4,5,6,7,8]))
    test = Array(items = Integer(min = 5, max = 8), min_items = 3, max_items = 5)

# Generated at 2022-06-22 05:52:12.974714
# Unit test for constructor of class Time
def test_Time():
    f = Time()
    assert isinstance(f, Time)
    assert f.allow_null == False
    assert f.error_messages == {
        "type": "Must be a time.",
        "pattern": "Must match the pattern {regex}.",
        "empty": "Must not be blank.",
        "max_length": "Must be no more than {max_length} characters long.",
        "min_length": "Must be at least {min_length} characters long.",
        "null": "May not be null."
    }
    assert f.min_length == None
    assert f.max_length == None
    assert f.default_value == None
    assert f.regex == None
    assert f.format == "time"


# Generated at 2022-06-22 05:52:16.946240
# Unit test for method validate of class String
def test_String_validate():
    # instance of class String
    string_instance = String()

    # test case 1
    assert string_instance.validate('asdf') == 'asdf'

    # test case 2
    assert len(string_instance.errors) == 4

    # test case 3
    assert string_instance.allow_blank == False

    # test case 4
    assert string_instance.allow_null == False

    # test case 5
    assert string_instance.trim_whitespace == True


# Generated at 2022-06-22 05:52:20.684619
# Unit test for constructor of class Float
def test_Float():
    value = 2.5
    obj = Float()
    try:
        obj.validate(value)
    except ValidationError as e:
        assert False
test_Float()


# Generated at 2022-06-22 05:52:23.540430
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class TestField(Field):
        errors = {
            "test_code": "Test message"
        }
    field = TestField()
    assert field.get_error_text("test_code") == "Test message"


# Generated at 2022-06-22 05:52:34.257060
# Unit test for constructor of class Object
def test_Object():
    o = Object()
    assert o.properties == {}
    assert o.pattern_properties == {}
    assert o.additional_properties == True
    assert o.property_names == None
    assert o.min_properties == None
    assert o.max_properties == None
    assert o.required == []

    o = Object(properties={}, pattern_properties={}, additional_properties=None,
            property_names=None, min_properties=2, max_properties=3, required=["a"])
    assert o.properties == {}
    assert o.pattern_properties == {}
    assert o.additional_properties == None
    assert o.property_names == None
    assert o.min_properties == 2
    assert o.max_properties == 3
    assert o.required == ["a"]


# Generated at 2022-06-22 05:52:45.860029
# Unit test for method validate of class Object
def test_Object_validate():
    f1 = Integer(title="Age", minimum=0, maximum=150, default=18)
    f2 = String(title="Name", min_length=1, max_length=50, default="Guest")

    obj = Object(
        title="Person",
        description="A person",
        properties={
            "name": f2,
            "age": f1,
        },
        additional_properties=False,
    )

    # Compare two dictionaries ignoring the order of keys
    assert obj.validate({"name": "Guest", "age": 18}) == {
        "name": "Guest",
        "age": 18,
    }

    # Defaults are ignored
    assert obj.validate({}) == {}

    # Additional properties are rejected

# Generated at 2022-06-22 05:52:49.195787
# Unit test for constructor of class Time
def test_Time():
    test_obj = Time()
    assert test_obj.format == 'time'
    assert test_obj.allow_null == True
    assert test_obj.default == None


# Generated at 2022-06-22 05:52:53.558689
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for Object instantiation with all kwargs
    # Test for Object instantiation without all kwargs
    # Test for validate_or_error: null, type, invalid_key, required, invalid_property, empty, max_properties, min_properties
    pass



# Generated at 2022-06-22 05:52:55.162235
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer == Integer.__class__, "Integer's constructor failed!"


# Generated at 2022-06-22 05:52:56.655450
# Unit test for constructor of class Integer
def test_Integer():
    a=Integer(minimum=0,maximum=10)
    print(a.minimum)
    print(a.maximum)


# Generated at 2022-06-22 05:53:16.844828
# Unit test for method validate of class String
def test_String_validate():
    assert not isinstance(5, str)
    assert not isinstance(5.0, str)
    assert not isinstance(True, str)
    assert not isinstance({}, str)
    assert not isinstance([], str)
    assert not isinstance((), str)

    # no min_length
    field = String()
    ret = field.validate('test')
    assert ret == 'test'
    ret = field.validate('')
    assert ret == ''
    ret = field.validate(None)
    assert ret == None

    # min_length = 1
    field = String(min_length=1)
    ret = field.validate('test')
    assert ret == 'test'
    ret = field.validate('')
    assert ret == '', 'should raise error'

    # min_length =

# Generated at 2022-06-22 05:53:25.838202
# Unit test for method validate of class Array
def test_Array_validate():
    data = {'items': [{'apiVersion': 'v1', 'kind': 'ServiceAccount'}, {'apiVersion': 'v1', 'kind': 'ServiceAccount'}], 'metadata': {'labels': {'app': 'nginx-ingress', 'chart': 'nginx-ingress-1.31.1', 'component': 'controller', 'heritage': 'Helm', 'release': 'nginx-ingress'}, 'name': 'nginx-ingress-controller'}}
    a = Array(items=Object(properties={'apiVersion': String(pattern='v1'), 'kind': String()}))
    assert a.validate(data['items']) == data['items']


# Generated at 2022-06-22 05:53:26.882434
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    time1 = Time(allow_null=1)
    time2 = Time(allow_null=0)


# Generated at 2022-06-22 05:53:29.032882
# Unit test for method validate of class Const
def test_Const_validate():
    validateConst = Const(const=5)
    test_value = validateConst.validate(5)
    expected_value = 5
    assert expected_value == test_value
    try:
        validateConst.validate(6) 
    except Exception as e:
        expected_value = "Must be the value '5'."
        assert expected_value in str(e)

# Generated at 2022-06-22 05:53:30.338215
# Unit test for constructor of class Number
def test_Number():
    assert isinstance(Number(), Number)


# Generated at 2022-06-22 05:53:41.997885
# Unit test for method serialize of class String
def test_String_serialize():
    a = String(format='date')
    assert isinstance(a.serialize('2019-01-01'), str)
    assert a.serialize('2019-01-01') == '2019-01-01'
    b = String(format='time')
    assert isinstance(b.serialize('10:10'), str)
    assert b.serialize('10:10') == '10:10'
    c = String(format='datetime')
    assert isinstance(c.serialize('2019-01-01T10:10'), str)
    assert c.serialize('2019-01-01T10:10') == '2019-01-01T10:10'
    d = String(format='uuid')

# Generated at 2022-06-22 05:53:48.830881
# Unit test for method has_default of class Field
def test_Field_has_default():
    a = Field()
    b = Field()
    assert a.has_default() == False
    assert b.has_default() == False
    a.default = True
    assert a.has_default() == True
    assert b.has_default() == False
    b.default = "abcd"
    assert a.has_default() == True
    assert b.has_default() == True


# Generated at 2022-06-22 05:53:54.573990
# Unit test for constructor of class Field
def test_Field():
    # no error if one of parameters is not given
    myField = Field()
    assert myField.title == ""
    assert myField.description == ""
    assert myField.default == NO_DEFAULT
    assert myField.allow_null == False
    assert myField._creation_counter == 0
    assert myField._creation_counter == Field._creation_counter - 1
    assert not hasattr(myField, "default")

    # no error if one of parameters is given
    myField = Field(title = "this is a title")
    assert myField.title == "this is a title"
    assert myField.description == ""
    assert myField.default == NO_DEFAULT
    assert myField.allow_null == False
    assert myField._creation_counter == 1

# Generated at 2022-06-22 05:54:04.495234
# Unit test for constructor of class String
def test_String():
    test1 = String()
    assert test1.allow_blank == False
    assert test1.allow_null == False
    assert test1.default == None
    assert test1.description == ""
    assert test1.format == None
    assert isinstance(test1.max_length,type(None))
    assert isinstance(test1.min_length,type(None))
    assert test1.pattern == None
    assert test1.title == ""
    assert test1.trim_whitespace == True
    assert len(test1.errors) == 5
    assert test1.errors['type'] == "Must be a string."
    assert test1.errors['null'] == "May not be null."
    assert test1.errors['blank'] == "Must not be blank."

# Generated at 2022-06-22 05:54:07.775636
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(allow_null=False, choices=[("a", "aa"),("b","bb")])
    value = "b"
    result = field.validate(value)
    assert result == "b"


# Generated at 2022-06-22 05:54:32.497374
# Unit test for constructor of class Field
def test_Field():
    test_field = Field(title='testfield', description='test', default='')


# Generated at 2022-06-22 05:54:33.004966
# Unit test for method validate of class Union
def test_Union_validate():
    pass



# Generated at 2022-06-22 05:54:39.393893
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=[(0, 'zero'), (1, 'one')])
    assert c.choices == [(0, 'zero'), (1, 'one')]
    c = Choice(choices=[(0, 'zero'), ('1', 'one')])
    assert c.choices == [(0, 'zero'), ('1', 'one')]
    c = Choice(choices=['zero', 'one'])
    assert c.choices == [('zero', 'zero'), ('one', 'one')]
    # Can't have duplicate keys
    try:
        Choice(choices=[(0, 'zero'), (0, 'one')])
    except Exception:
        assert True
    try:
        Choice(choices=[('a', 'zero'), ('a', 'one')])
    except Exception:
        assert True
   

# Generated at 2022-06-22 05:54:46.194366
# Unit test for method validate of class Any
def test_Any_validate():
    field_1 = Any()
    assert field_1.validate(value="true") == "true"
    assert field_1.validate(value=True) == True
    assert field_1.validate(value="false") == "false"
    assert field_1.validate(value=False) == False
    assert field_1.validate(value=1) == 1
    assert field_1.validate(value=0) == 0


# Generated at 2022-06-22 05:54:54.475314
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import sys
    import os
    import pytest
    #from typesystem.fields import Field

    class Field_validate_or_error(Field):
        def validate(self, value, *, strict):
            return value

    # pass
    field = Field_validate_or_error()
    res = field.validate_or_error(1)
    assert res.value == 1
    assert res.error == None
    res = field.validate_or_error('hello')
    assert res.value == 'hello'
    assert res.error == None

    # fail
    class Field_validate_or_error(Field):
        def validate(self, value, *, strict):
            raise ValidationError('fail')

    field = Field_validate_or_error()
    res = field.validate_or_error

# Generated at 2022-06-22 05:54:56.838773
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    m = Field.get_error_text
    m(code = 'null_not_allowed')


# Generated at 2022-06-22 05:55:07.352991
# Unit test for method validate of class Array
def test_Array_validate():
    test_field = Array(
        items=Field(type="string"),
        additional_items=Field(type="number"),
        min_items=3,
        max_items=7,
        unique_items=True,
        allow_null=True,
    )
    assert test_field.validate(["1", "2", "3", "4", "5", "6", "7"]) == [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
    ]
    assert test_field.validate(["1", "2"]) == ["1", "2"]
    assert test_field.validate(["1", "2", "3"]) == ["1", "2", "3"]
    assert test_field.validate

# Generated at 2022-06-22 05:55:12.087466
# Unit test for constructor of class Const
def test_Const():
    f = Const(None)
    assert f.const is None
    f = Const(False)
    assert f.const is False
    f = Const(True)
    assert f.const is True
    f = Const(0)
    assert f.const == 0
    f = Const(1)
    assert f.const == 1
    f = Const(["a", 2])
    assert f.const == ["a", 2]
    f = Const({1: 2, 2: 3})
    assert f.const == {1: 2, 2: 3}
    f = Const({"a": 1, "b": 2})
    assert f.const == {"a": 1, "b": 2}



# Generated at 2022-06-22 05:55:21.709335
# Unit test for constructor of class Float
def test_Float():
    import decimal

    float_inst1 = Float()
    try:
        float_inst1.validate(None, strict=True)
        assert False
    except ValidationError as e:
        assert e.code == 'null'

    float_inst2 = Float(title='Area', description='The area of the given shape', allow_null=True)
    try:
        float_inst2.validate("abc", strict=True)
        assert False
    except ValidationError as e:
        assert e.code == 'type'

    float_inst3 = Float(minimum=decimal.Decimal('10.0'))
    try:
        float_inst3.validate(decimal.Decimal('9.0'), strict=True)
        assert False
    except ValidationError as e:
        assert e.code == 'minimum'

# Generated at 2022-06-22 05:55:32.674337
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test with invalid input
    input_value = None
    field = Choice(choices=[("a", "a")])
    with pytest.raises(ValidationError) as error:
        print(field.validate(input_value))
    assert error.match(r"['null']")
    # test with no exception raised
    input_value = "a"
    field = Choice(choices=[("a", "a")])
    assert field.validate(input_value) == "a"
    # test with blank name and allow_null
    input_value = ""
    field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    assert field.validate(input_value) is None
    # test with blank name and allow_null

# Generated at 2022-06-22 05:55:44.294760
# Unit test for method validate of class Union
def test_Union_validate():
    # Exception: no Fields in any_of
    any_of = []
    try:
        Union(any_of)
    except:
        assert True
    else:
        assert False

    # Exception: a Field in any_of is not a Field
    any_of = [1,2,3]
    try:
        Union(any_of)
    except:
        assert True
    else:
        assert False

    # Exception: a Field in any_of is null
    any_of = [Field(null=True)]
    try:
        Union(any_of)
    except:
        assert True
    else:
        assert False

    # Exception: same child twice in any_of
    any_of = [Field(type="string"), Field(type="string")]

# Generated at 2022-06-22 05:55:50.270092
# Unit test for constructor of class DateTime
def test_DateTime():
    s = DateTime()
    assert s.format == 'datetime'
    assert s.allow_null == True
    s = DateTime(allow_null=False)
    assert s.allow_null == False
    s = DateTime(allow_empty_string=True)
    assert s.allow_empty_string == True
    assert s.allow_null == True
    s = DateTime(allow_empty_string=True, allow_null=False)
    assert s.allow_empty_string == True
    assert s.allow_null == False

    s = DateTime(allow_empty_string=False)
    assert s.allow_empty_string == False
    assert s.allow_null == True
    s = DateTime(allow_empty_string=False, allow_null=False)

# Generated at 2022-06-22 05:55:51.741660
# Unit test for constructor of class Float
def test_Float():
    foo = Float()
    assert foo.numeric_type == float



# Generated at 2022-06-22 05:55:58.213511
# Unit test for constructor of class Decimal
def test_Decimal():
    try:
        decimal_obj = Decimal(null=True)
    except Exception as e:
        print("This is unit test for constructor of class Decimal of file field.py")
        print("Expected: No exception")
        print("Occurred:", e)
    else:
        print("This is unit test for constructor of class Decimal of file field.py")
        print("Expected: No exception")
        print("Occurred: No exception")

