

# Generated at 2022-06-22 05:47:39.772154
# Unit test for constructor of class Time
def test_Time():
    assert Time().errors["type"] == "Must be a properly formatted time."
    assert Time().errors["required"] == "This field is required."



# Generated at 2022-06-22 05:47:42.584819
# Unit test for constructor of class String
def test_String():
    d1 = String(title = "This is a string field")
    print(d1.title)


# Generated at 2022-06-22 05:47:46.805330
# Unit test for constructor of class Field
def test_Field():
    f = Field(title="t",description="d",default="default",allow_null=True)
    assert isinstance(f, Field)
    assert f.title == "t"


# Generated at 2022-06-22 05:47:56.648767
# Unit test for method validate of class Array
def test_Array_validate():
    class Dog(Serializer):
        name=String()
        age=Integer()

    class Custom(Serializer):
        arr_int=Array(items=Integer())
        arr_str=Array(items=String())
        arr_dog=Array(items=Dog())

    c=Custom()

# Generated at 2022-06-22 05:48:01.758161
# Unit test for constructor of class Number
def test_Number():
    num = Number()
    assert num.minimum == None
    assert num.maximum == None
    assert num.exclusive_minimum == None
    assert num.exclusive_maximum == None
    assert num.multiple_of == None
    assert num.precision == None

# Validating type and null of class Number

# Generated at 2022-06-22 05:48:06.449839
# Unit test for method __or__ of class Field
def test_Field___or__():
    import unittest
    from typesystem.types import Integer

    class TestUnion(unittest.TestCase):

        def test_Field___or__(self):
            integer=Integer(minimum=0)
            integer=integer+0
            self.assertEqual(integer,0)
    unittest.main()


# Generated at 2022-06-22 05:48:11.429318
# Unit test for constructor of class Field
def test_Field():
    fields = Field(title = "Test title for Field class", description = "Description for Field", default = "default value", allow_null = True)
    assert fields.title == "Test title for Field class"
    assert fields.description == "Description for Field"
    assert fields.default == "default value"
    assert fields.allow_null == True


# Generated at 2022-06-22 05:48:22.674379
# Unit test for constructor of class Text
def test_Text():
    # test some basic functionalities for the class Text
    # build a fake schema for Text in order to test
    # the class Text
    schema_text = {
        "type": "string",
        "format": "text"
    }
    # convert the schema to an object of class Text
    text = Text.from_schema(schema_text)
    # test the value that is validated by the schema
    assert text.validate("valid text") == "valid text"
    # test the value that is not validated by the schema
    with pytest.raises(ValidationError):
        text.validate(12345)
    # test the to_schema method
    schema = text.to_schema()
    assert schema == schema_text
    # test the from_schema method; the from_schema
    # method should return

# Generated at 2022-06-22 05:48:24.083739
# Unit test for constructor of class DateTime
def test_DateTime():
    DateTime(default="2020-02-20T17:00:00Z")



# Generated at 2022-06-22 05:48:32.253804
# Unit test for constructor of class Float
def test_Float():
    test_field = Float(maximum=3.3, minimum=2.2, exclusive_minimum=3.3, exclusive_maximum=2.2, multiple_of=2.0, precision='0.1')
    assert test_field.maximum == 3.3
    assert test_field.minimum == 2.2
    assert test_field.exclusive_minimum == 3.3
    assert test_field.exclusive_maximum == 2.2
    assert test_field.multiple_of == 2.0
    assert test_field.precision == '0.1'


# Generated at 2022-06-22 05:48:51.999415
# Unit test for method validate of class Any
def test_Any_validate():
    obj = Any()
    assert obj.validate(1) == 1
    assert obj.validate('foo') == 'foo'
    assert obj.validate('') == ''
    assert obj.validate(0.0) == 0.0
    assert obj.validate(None) == None
    assert obj.validate(True) == True
    assert obj.validate(False) == False
    assert obj.validate(dict()) == dict()
    assert obj.validate(set()) == set()
    assert obj.validate(list()) == list()
    assert obj.validate(typing.List) == typing.List
    assert obj.validate(typing.Dict) == typing.Dict
    assert obj.validate(typing.Set) == typing.Set

# Generated at 2022-06-22 05:49:02.594266
# Unit test for method validate of class Array
def test_Array_validate():
    items = [Int(), Str()]
    field = Array(items=items)
    data = [1, "2"]
    assert field.validate(data) == [1, "2"]
    
    field = Array(items=Str())
    data = ["1", "2"]
    assert field.validate(data) == ["1", "2"]
    
    field = Array(items=Int())
    data = [1, "2"]
    with pytest.raises(ValidationError):
        field.validate(data)
    
    field = Array(items=Int(), allow_null=True)
    data = None
    assert field.validate(data) == None

    field = Array(items=Int(), unique_items=True)
    data = [1, 1]

# Generated at 2022-06-22 05:49:05.380788
# Unit test for method serialize of class String
def test_String_serialize():
    s = String()
    s.format = 'date'
    assert s.serialize('2019-05-20') == datetime.date(2019,5,20)


# Generated at 2022-06-22 05:49:11.289416
# Unit test for method validate of class Object
def test_Object_validate():
    sample_value = {"1": "test", "2": "test2"}
    test_object = Object(properties={"test_key1":"test_value1", "test_key2":"test_value2"}, property_names=None)
    try:
        test_object.validate(sample_value)
    except ValidationError as e:
        pass


# Generated at 2022-06-22 05:49:14.160057
# Unit test for constructor of class Choice
def test_Choice():
    test_field = Choice(choices=[('1', 'One'), ('2', 'Two'), ('3', 'Three')])
    assert test_field.validate('1') == '1'
    assert test_field.validate('2') == '2'
    assert test_field.validate('3') == '3'
    assert test_field.validate('4') == '4'
    assert test_field.validate('4') == '4'
    assert test_field.validate(None) == None
# test_Choice()



# Generated at 2022-06-22 05:49:16.578919
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj = Decimal(null = True)
    assert obj.serialize(None) == None
    assert obj.serialize(15.2) == 15.2
    assert obj.serialize(15) == 15



# Generated at 2022-06-22 05:49:19.752921
# Unit test for constructor of class Number
def test_Number():
    #no error
    Number()

    # error
    with pytest.raises(AssertionError):
        Number(minimum = 1.0, maximum = 1)

    with pytest.raises(AssertionError):
        Number(minimum = 1.0, exclusive_minimum = 1)


# Generated at 2022-06-22 05:49:29.279146
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean = Boolean(allow_null=False)
    expected = ValidationResult(value = False, error = None)
    assert(boolean.validate_or_error("") == expected)
    boolean = Boolean(allow_null=True)
    assert(boolean.validate_or_error("") == expected)
    expected = ValidationResult(value = None, error = ValidationError(text = "Must be a boolean.", code = "type"))
    assert(boolean.validate_or_error("a") == expected)
    expected = ValidationResult(value = None, error = ValidationError(text = "May not be null.", code = "null"))
    assert(boolean.validate_or_error(None) == expected)



# Generated at 2022-06-22 05:49:30.596600
# Unit test for constructor of class Any
def test_Any():
    with pytest.raises(TypeError):
        Any(format = "text")


# Generated at 2022-06-22 05:49:31.317622
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    assert any


# Generated at 2022-06-22 05:50:06.703970
# Unit test for method validate of class Field
def test_Field_validate():
    d = {
        "description": "Number field",
        "default": 0
    }
    n = Number(**d)
    assert n.validate(1) == 1
    assert n.validate("1") == 1
    assert n.validate("1.1") == 1.1
    assert n.validate("9223372036854775807") == 9223372036854775807
    assert n.validate("9223372036854775808") is None
    assert n.validate("asdf") is None
    assert n.validate("-9223372036854775807") == -9223372036854775807
    assert n.validate("-9223372036854775808") is None
    assert n.validate("-0") == 0

# Generated at 2022-06-22 05:50:09.561324
# Unit test for method validate of class Any
def test_Any_validate():
    # Unlike other fields, the Any field does not produce validation errors,
    # and does not raise an exception.
    from good import Schema
    from good.schema import ValidationError

    schema = Schema(Any())
    result = schema(123)

    assert result == 123
    assert not ValidationError.check(result)

# Generated at 2022-06-22 05:50:11.198583
# Unit test for constructor of class Integer
def test_Integer():
    assert (Integer().numeric_type == int)



# Generated at 2022-06-22 05:50:22.249781
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    assert field.validate('true') == True
    assert field.validate('TRUE') == True
    assert field.validate('TrUe') == True
    assert field.validate('1') == True
    assert field.validate('on') == True
    assert field.validate(1) == True
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate('') == False
    assert field.validate('false') == False
    assert field.validate('FALSE') == False
    assert field.validate('FaLsE') == False
    assert field.validate('0') == False
    assert field.validate('off') == False
    assert field.validate

# Generated at 2022-06-22 05:50:25.545396
# Unit test for constructor of class Number
def test_Number():
    N = Number()
    assert N.validation_error("type") == ValidationError(text="Must be a number.", code="type")
    assert N.has_default() == False



# Generated at 2022-06-22 05:50:26.154511
# Unit test for constructor of class Text
def test_Text():
    assert Text()



# Generated at 2022-06-22 05:50:28.585888
# Unit test for constructor of class Field
def test_Field():
    field = Field(title="testing title",
                  description="testing description",
                  default=5,
                  allow_null=True)
    pass

# Generated at 2022-06-22 05:50:32.753022
# Unit test for constructor of class Array
def test_Array():
    field = Array(min_items = 2, max_items = 6)
    field = Array(exact_items = 3)
    field = Array(items = Integer())
    field = Array(items = [String(), Integer()])


# Generated at 2022-06-22 05:50:34.218581
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() == False
    assert Field(default=1).has_default() == True


# Generated at 2022-06-22 05:50:36.051660
# Unit test for method has_default of class Field
def test_Field_has_default():    
            field = Field(title='a',
                description='b',
                default='a',
                allow_null='b')
            assert field.has_default()==True


# Generated at 2022-06-22 05:51:10.678811
# Unit test for constructor of class DateTime
def test_DateTime():
    def test_DateTime_error(field):
        try:
            DateTime(**field)
        except AssertionError:
            return True
        return False


# Generated at 2022-06-22 05:51:15.795252
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    val1 = Field()
    #empty class
    assert val1.get_default_value() == None
    def func():
        return "Hello world"
    val1.default = func
    assert val1.get_default_value() == "Hello world"
    val1.default = 2.5
    assert val1.get_default_value() == 2.5
    val1.allow_null = True
    assert val1.get_default_value() == None

#Unit test for method has_default of class Field

# Generated at 2022-06-22 05:51:20.044684
# Unit test for constructor of class Time
def test_Time():
    t = Time(allow_null=True)
    assert t.format == "time"
    assert t.allow_null == True
    assert t.default == ""
    assert t.title == None
    assert t.description == None
    assert t.errors == {
        "type": "Must be a time.",
        "null": "May not be null.",
        "required": "This field is required.",
        "min_length": "Must have at least {min_length} characters.",
        "max_length": "Must have no more than {max_length} characters.",
        "pattern": "Invalid time format.",
        "format": "Invalid time format.",
    }




# Generated at 2022-06-22 05:51:28.405552
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    pass
    Field.errors = {}
    Boolean.errors = {"type": "Must be a boolean.", "null": "May not be null."}
    Boolean.coerce_values = {"true": True, "false": False, "on": True, "off": False, "1": True, "0": False, "": False, 1: True, 0: False}
    Boolean.coerce_null_values = {"", "null", "none"}
    Boolean.validate(Boolean,value=None, strict=False) is None
    Boolean.validate(Boolean,value=None, strict=True)
    Boolean.validate(Boolean,value=True, strict=False)
    Boolean.validate(Boolean,value=False, strict=False)
    Boolean.validate(Boolean,value=1, strict=False)


# Generated at 2022-06-22 05:51:40.484146
# Unit test for method validate of class Object
def test_Object_validate():
    # Test for new_schema
    schema = Object(
        properties={},
        pattern_properties={},
        additional_properties=True,
        property_names=None,
        min_properties=0,
        max_properties=None,
        allow_null=True,
        required=[],
        error_messages={},
    )
    # Test null
    assert schema.validate(None, strict=False) == None
    with raises(ValidationError):
        schema.validate(None, strict=True)
    # Test invalid_type
    assert schema.validate({"name": "guojing"}, strict=False) == {"name":"guojing"}
    # Test invalid_property_name
    with raises(ValidationError):
        schema.validate({2:"guojing"}, strict=False)
    # Test

# Generated at 2022-06-22 05:51:49.951794
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    # Test the case where the code is in the default errors
    field = Field()
    assert field.get_error_text("required") == "Value is required."

    # Test the case where the code is not in the default errors => text = code
    assert field.get_error_text("invalid") == "invalid"
    # Test the case where the code is not in the default errors, the text = "error"
    field.errors = {"invalid": "error"}
    assert field.get_error_text("invalid") == "error"

    # Test the case where the code is in the default errors, but the text is overwritten
    field.errors = {"required": "error"}
    assert field.get_error_text("required") == "error"
    
    


# Generated at 2022-06-22 05:52:00.881344
# Unit test for method validate of class String
def test_String_validate():
    #scenario1
    class Book:
        title: String(title="Title", max_length=30, allow_blank=False, trim_whitespace=True)
        author: String()
    book=Book()
    book.title="Harry Potter"
    book.author="J.K. Rowling"
    assert book.title == "Harry Potter"
    assert book.author == "J.K. Rowling"
    
    #scenario2
    class Book:
        title: String(title="Title", max_length=30, allow_blank=False, trim_whitespace=False)
        author: String()
    book=Book()
    book.title="    Harry Potter    "
    book.author="J.K. Rowling"
    assert book.title == "Harry Potter"

# Generated at 2022-06-22 05:52:03.657072
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(1) == 1.0
    assert Decimal().serialize(4/9) == 0.4444444444444444
    assert Decimal().serialize(None) == None



# Generated at 2022-06-22 05:52:04.801408
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate("10") == 10



# Generated at 2022-06-22 05:52:15.021929
# Unit test for constructor of class Number
def test_Number():
    minimum = 2
    maximum = 4
    exclusive_minimum = 2
    exclusive_maximum = 4
    precision = 0.5
    multiple_of = 3
    number_type = Number(minimum=minimum, maximum=maximum, exclusive_minimum=exclusive_minimum, exclusive_maximum=exclusive_maximum,
                         precision=precision, multiple_of=multiple_of, title="name", description="description", default=2, allow_null=False)
    assert number_type.minimum == minimum
    assert number_type.maximum == maximum
    assert number_type.exclusive_minimum == exclusive_minimum
    assert number_type.exclusive_maximum == exclusive_maximum
    assert number_type.precision == precision
    assert number_type.multiple_of == multiple_of
    assert number_type.allow_null == False
    assert number_type.title == "name"

# Generated at 2022-06-22 05:53:27.898080
# Unit test for method validate of class Object
def test_Object_validate():
    f1 = Boolean(name='f1')
    f2 = Boolean(name='f2')
    test_property = {"p1": f1, "p2": f2}

    o1 = Object(name='o1', properties=test_property)
    correct_value = {"p1": True, "p2": True}
    assert o1.validate(correct_value) == correct_value

    error_value = {"p1": True, "p2": "abc"}
    with pytest.raises(ValidationError):
        o1.validate(error_value)

    o2 = Object(name='o2', properties=test_property, required=["p1"])
    error_value = {"p2": True}

# Generated at 2022-06-22 05:53:31.733391
# Unit test for method validate of class Object
def test_Object_validate():
    class Employee(Object):
        properties = {"name": String(), "age": Integer()}

    with pytest.raises(ValidationError):
        Employee().validate({"name": "Greig"})


# Generated at 2022-06-22 05:53:40.497978
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["a", "b", "c"]).validate("a") == "a"
    assert Choice(choices=[("a", "hello"), ("b", "world"), ("c", "python")]).validate("a") == "a"
    c = Choice(choices=[("a", "hello"), ("b", "world"), ("c", "python")])
    assert c.validate("a") == "a"
    assert c.validate("b") == "b"
    assert c.validate("c") == "c"

# Generated at 2022-06-22 05:53:43.267992
# Unit test for method serialize of class Array
def test_Array_serialize():
    value = ['32','33']
    adr = Array(items=Integer())
    a = adr.serialize(value)
    assert a == [32,33]



# Generated at 2022-06-22 05:53:47.899807
# Unit test for method validate of class Number
def test_Number_validate():
    field = Number(allow_null=True, multiple_of=2, minimum=-1, exclusive_maximum=0)
    value = None
    expected_result = None
    result = field.validate(value)
    assert result == expected_result


# Generated at 2022-06-22 05:53:52.900546
# Unit test for method validate of class Const
def test_Const_validate():
    assert Const("foo").validate("foo") == "foo"
    with pytest.raises(ValidationError) as excinfo:
        Const("foo").validate("bar")
    assert excinfo.value.messages()[0].code == "const"
    assert Const(None).validate(None) is None
    with pytest.raises(ValidationError) as excinfo:
        Const(None).validate("foo")
    assert excinfo.value.messages()[0].code == "only_null"
    
    

# Generated at 2022-06-22 05:53:54.298154
# Unit test for constructor of class Const
def test_Const():
    const = Const(True, name="Test")
    assert const.const is True
    assert const.name == "Test"
#test_Const()


# Generated at 2022-06-22 05:53:58.936663
# Unit test for method serialize of class Array
def test_Array_serialize():
    from .mixins import JsonSchemaMixin
    from .models import Model, Field

    class TestModel(JsonSchemaMixin, Model):
        array = Array(items=Field(type="string"))

    model = TestModel(array=["one", "two"])

    assert model.array == ["one", "two"]
    assert TestModel.serialize(model) == {
        "array": ["one", "two"]
    }



# Generated at 2022-06-22 05:54:02.802568
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    instance = Field()
    code = 'test_code'
    expected = ValidationError()
    actual = instance.validation_error(code)
    assert actual == expected


# Generated at 2022-06-22 05:54:04.566112
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Field()
    assert f.serialize('test') == 'test'


# Generated at 2022-06-22 05:54:30.848294
# Unit test for constructor of class Boolean
def test_Boolean():
    b = Boolean()

# Generated at 2022-06-22 05:54:37.303283
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f.minimum is None
    assert f.maximum is None
    assert f.exclusive_minimum is None
    assert f.exclusive_maximum is None
    assert f.multiple_of is None
    assert f.precision is None
    assert f.numeric_type is float
    assert f.title == ''
    assert f.description == ''
    assert f.allow_null == False
    assert f.allow_blank == False
    assert f.trim_whitespace == True
    assert f.max_length is None
    assert f.min_length is None
    assert f.pattern is None
    assert f.format is None

# Generated at 2022-06-22 05:54:48.149178
# Unit test for constructor of class String
def test_String():
    a=String(allow_blank=True,trim_whitespace=False,max_length=10,min_length=1,pattern='(0|1)+',format=None,title='',description='')
    assert a.allow_blank == True
    assert a.trim_whitespace == False
    assert a.max_length == 10
    assert a.min_length == 1
    assert a.format == None
    assert a.pattern == '(0|1)+'
    assert a.pattern_regex.pattern == '(0|1)+'
    assert a.errors['blank'] == 'Must not be blank.'
    assert a.errors['type'] == 'Must be a string.'
    assert a.errors['null'] == 'May not be null.'

# Generated at 2022-06-22 05:54:54.111103
# Unit test for method validate of class Array
def test_Array_validate():
    
    class Doc(Document):
        schema_definition = {
            "array":[Boolean(allow_null=False)],
            "array2": Array(items=[Boolean(allow_null=False), String(allow_null=False)]),
            "array3": Array(items=String(allow_null=False), unique_items=True),
        }
    
    # Validating the field 'array'
    doc = Doc()
    doc.array = [True, True, True]
    doc.array2 = [True, False, "Hi"]
    doc.array3 = ["Hi", "Hi", "Hi"]

    try:
        checksum = doc.validate()
        print("Test passed.")
    except ValidationError as e:
        print(e)
        checksum = "Test failed."
    finally:
        print

# Generated at 2022-06-22 05:54:56.081646
# Unit test for constructor of class Date
def test_Date():
    dateInstance = Date()

# Generated at 2022-06-22 05:54:58.732718
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    val = Decimal()
    assert val.serialize(None) is None
    assert val.serialize(decimal.Decimal('1.2')) == 1.2



# Generated at 2022-06-22 05:55:05.234986
# Unit test for constructor of class String
def test_String():
# Case 1: Test __init__()
    a = String()
    assert a.title == ""
    assert a.description == ""
    assert a._creation_counter == 1
    assert a.allow_null == False
    assert a.default == NO_DEFAULT
    assert a.allow_blank == False
    assert a.trim_whitespace == True
    assert a.max_length == None
    assert a.min_length == None
    assert a.pattern == None
    assert a.format == None

# Case 2: Test __init__()
    b = String(allow_null=True, default="hello", title="my title", description="my description")
    assert b.title == "my title"
    assert b.description == "my description"
    assert b._creation_counter == 2

# Generated at 2022-06-22 05:55:06.891539
# Unit test for constructor of class Union
def test_Union():
    f = Union(any_of=[Integer, String])
    print(f)
    f = Union(any_of=[Integer, String], nullable=True)
    print(f)



# Generated at 2022-06-22 05:55:08.902976
# Unit test for method validate of class Object
def test_Object_validate():
    validate_field = Object()
    expected_validate = None
    actual_validate = validate_field.validate(data)
    assert actual_validate == expected_validate
    assert actual_validate == expected_validate
    
    



# Generated at 2022-06-22 05:55:10.894870
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    f.validate(3.3)

#


# Generated at 2022-06-22 05:55:31.347339
# Unit test for constructor of class Text
def test_Text():
    t1 = Text()
    t2 = Text(required=True)
    t3 = Text(allow_null=True)



# Generated at 2022-06-22 05:55:32.126835
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert Field() | Field() | Field()



# Generated at 2022-06-22 05:55:40.938699
# Unit test for method validate of class Union
def test_Union_validate(): #TEST
    class Person(Record):
        name = String()
        age = Integer()
    class Car(Record):
        brand = String()
        year = Integer()
    x = Union([Person, Car])
    # - check for exception
    try:
        x.validate({"name": "Albert", "age": 42})
        assert False
    except ValidationError as e:
        assert e.messages[0].code == "type"
        assert e.messages[0].text == "Must have a name of type \"string\"."
        assert e.messages[0].index == "name"
    # - check for exception

# Generated at 2022-06-22 05:55:48.718987
# Unit test for constructor of class Number
def test_Number():
    assert Number.numeric_type == None
    assert Number.errors == {"type": "Must be a number.", "null": "May not be null.", "integer": "Must be an integer.", "finite": "Must be finite.", "minimum": "Must be greater than or equal to {minimum}.", "exclusive_minimum": "Must be greater than {exclusive_minimum}.", "maximum": "Must be less than or equal to {maximum}.", "exclusive_maximum": "Must be less than {exclusive_maximum}.", "multiple_of": "Must be a multiple of {multiple_of}."}
    assert Number.minimum == None
    assert Number.maximum == None
    assert Number.exclusive_minimum == None
    assert Number.exclusive_maximum == None
    assert Number.multiple_of == None
    assert Number.precision == None
    assert Number.allow_null == False


# Generated at 2022-06-22 05:55:50.157554
# Unit test for constructor of class DateTime
def test_DateTime():
    dt_test = DateTime()
    assert dt_test.format == "datetime"


# Generated at 2022-06-22 05:56:00.706372
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.fields import String
    from typesystem.fields import Float
    from typesystem.fields import Number
    from typesystem.fields import Integer
    from typesystem.fields import Schema
    from typesystem.fields import Union
    from typesystem.schema import SchemaClass
    
    
    union = Float() | String()
    
    val_float = union.validate(1.2)
    assert isinstance(val_float, float)
    
    union = union | Integer()
    val_int = union.validate(1)
    assert isinstance(val_int, int)
    
    union = union | Number()
    val_float2 = union.validate(1.3)
    assert isinstance(val_float2, float)
    
    union = union | Schema({'a': String()})