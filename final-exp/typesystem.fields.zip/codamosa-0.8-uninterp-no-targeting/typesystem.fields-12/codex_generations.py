

# Generated at 2022-06-22 05:47:41.622436
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    class FieldTest(Field):
        errors = {
            "a": "error a",
            "b": "error b",
            "c": "error c",
            "d": "error d",
            "e": "error e"
        }
    
    fieldtest = FieldTest(allow_null=False)
    assert fieldtest.get_error_text("a") == "error a"
    assert fieldtest.get_error_text("b") == "error b"
    assert fieldtest.get_error_text("c") == "error c"
    assert fieldtest.get_error_text("d") == "error d"
    assert fieldtest.get_error_text("e") == "error e"
    assert fieldtest.get_error_text("f") == "error f"
    assert fieldtest.get_error

# Generated at 2022-06-22 05:47:43.087982
# Unit test for constructor of class DateTime
def test_DateTime():
    a = DateTime()


# Generated at 2022-06-22 05:47:47.974732
# Unit test for constructor of class Union
def test_Union():
    field1 = Integer(required = True)
    field2 = Text(required = True)
    field3 = Boolean(required = True)
    field4 = Date(required = True)
    union_field = Union([field1, field2, field3, field4], required = False)
    print("Union")


# Generated at 2022-06-22 05:47:49.371122
# Unit test for method has_default of class Field
def test_Field_has_default():
    class TestField(Field):
        default = "test"
    field = TestField()
    assert field.has_default() is True


# Generated at 2022-06-22 05:47:52.198863
# Unit test for constructor of class DateTime
def test_DateTime():
    asrt = assert_equal(
        "Need one argument.\n"
    )
    asrt(lambda: DateTime(1), "Argument is not a dict.\n")



# Generated at 2022-06-22 05:47:57.714669
# Unit test for constructor of class Array
def test_Array():
    items = [
        fields.String(),
        fields.String(),
    ]

    schema = fields.Array(items=items)
    assert isinstance(schema.items, list)
    assert isinstance(schema.items[0], fields.String)
    assert isinstance(schema.items[1], fields.String)

    schema = fields.Array(items=fields.String())
    assert isinstance(schema.items, fields.String)



# Generated at 2022-06-22 05:48:00.005832
# Unit test for constructor of class Text
def test_Text():
    with pytest.raises(ValueError):
        Text(format='not')

    assert Text(format='text').format == 'text'



# Generated at 2022-06-22 05:48:02.342524
# Unit test for method validate of class Number
def test_Number_validate():
    number = Number(minimum=10, maximum=100, exclusive_minimum=15)
    print('Unit test for method validate of class Number')
    print(number.validate(5))


# Generated at 2022-06-22 05:48:03.516767
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(10) == 10



# Generated at 2022-06-22 05:48:06.526558
# Unit test for constructor of class Object
def test_Object():
    assert Object(allow_null=True, description="description", title="title", **{})


# Generated at 2022-06-22 05:48:45.237552
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import String, Integer, Float
    str_or_int = String() | Integer()
    assert(str_or_int.validate("hello")=="hello")
    assert(str_or_int.validate(123)==123)
    assert(str_or_int.validate(123.0)==None)
    assert(str_or_int.validate(123.1)==None)
    assert(str_or_int.validate(123.4)==None)
    assert(str_or_int.validate(123.9)==None)
    str_or_float = String() | Float()
    assert(str_or_float.validate("hello")=="hello")
    assert(str_or_float.validate(123)==123.0)

# Generated at 2022-06-22 05:48:54.290167
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(minimum=1).minimum == 1
    assert Decimal(exclusive_maximum=1).exclusive_maximum == 1
    assert Decimal(maximum=1).maximum == 1
    assert Decimal(exclusive_minimum=1).exclusive_minimum == 1
    assert Decimal(multiple_of=1).multiple_of == 1
    assert Decimal(numeric_type=1).numeric_type == 1
    assert Decimal(title='testing').title == 'testing'
    assert Decimal(description='testing').description == 'testing'
    assert Decimal(allow_blank=True).allow_blank == True
    assert Decimal(allow_null=True).allow_null == True
    assert Decimal(precision='1').precision == '1'
    



# Generated at 2022-06-22 05:48:56.699018
# Unit test for constructor of class DateTime
def test_DateTime():
   assert(isinstance(DateTime(), DateTime))

# Generated at 2022-06-22 05:48:59.527313
# Unit test for method validate of class Any
def test_Any_validate():
    obj = Any()
    assert obj.validate(1) == 1
    assert obj.validate('abc') == 'abc'
    assert obj.validate(True) == True



# Generated at 2022-06-22 05:49:09.185653
# Unit test for constructor of class Boolean
def test_Boolean():
    obj = Boolean()
    assert obj.allow_null == False
    assert len(obj.coerce_null_values) == 3
    assert obj.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
        }
    assert obj.errors["type"] == "Must be a boolean."
    assert obj.errors["null"] == "May not be null."
    assert obj.title == ""
    assert obj.description == ""
    assert hasattr(obj, "_creation_counter")


# Generated at 2022-06-22 05:49:13.788148
# Unit test for constructor of class Boolean
def test_Boolean():
    # Create a boolean object
    boolean = Boolean()
    print(type(boolean))

    # Confirm the value of "coerce_null_values" which is a set
    # by convertion to list, and compare with the specific values
    assert (list(boolean.coerce_null_values) == ['', 'null', 'none'])


# Generated at 2022-06-22 05:49:15.938769
# Unit test for constructor of class Float
def test_Float():
    class TestFloat(Float):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-22 05:49:25.107319
# Unit test for constructor of class Float
def test_Float():
    myfloat = Float(minimum=1, maximum=10, exclusive_minimum=1, exclusive_maximum=10,
                    multiple_of=5, allow_null=True, title="My Float",
                    description="This field is a float.")
    assert myfloat.minimum == 1
    assert myfloat.maximum == 10
    assert myfloat.exclusive_minimum == 1
    assert myfloat.exclusive_maximum == 10
    assert myfloat.multiple_of == 5
    assert myfloat.allow_null == True
    assert myfloat.title == "My Float"
    assert myfloat.description == "This field is a float."
    assert myfloat.numeric_type == float
    assert myfloat.has_default() == False
    assert myfloat.get_default_value() == None



# Generated at 2022-06-22 05:49:28.790163
# Unit test for constructor of class Object
def test_Object():
    obj1 = Object()
    assert obj1.properties == {}
    assert obj1.pattern_properties == {}
    assert obj1.additional_properties == True
    assert obj1.property_names == None
    assert obj1.min_properties == None
    assert obj1.max_properties == None
    assert obj1.required == []



# Generated at 2022-06-22 05:49:29.856479
# Unit test for constructor of class Date
def test_Date():

    # This is a test for the constructor of Date
    assert Date()



# Generated at 2022-06-22 05:49:54.787295
# Unit test for method validate of class Field
def test_Field_validate():
    try:
        from utils import get_class_code
        repr(Field)
    except BaseException as e:
        assert False, 'Error for class Field: {}'.format(e)
    else:
        assert True

# Generated at 2022-06-22 05:49:55.988529
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    assert field.format == "text"



# Generated at 2022-06-22 05:50:07.148844
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(allow_null=True)
    assert field.validate(None) == None
    # Assert raise error when value=None and allow_null is not enabled
    with pytest.raises(ValidationError) as error:
        field = Choice(allow_null=False)
        field.validate(None)
    assert error.value.code == 'null'
    # Assert value is returned when parameter of choices is None
    assert field.validate('hello') == 'hello'
    # Assert raise error when value not presents in choices
    with pytest.raises(ValidationError) as error:
        field = Choice(choices=['hello','world'])
        field.validate('nihao')
    assert error.value.code == 'choice'
    # Assert raise error when value is '' and allow_null

# Generated at 2022-06-22 05:50:10.446243
# Unit test for constructor of class Object
def test_Object():
    a = {"title": String(), "number": Integer()}
    c = Object(properties=a)
    d = {"title": "This is a dictionary", "number": 1}

    assert c.schema == d


# Generated at 2022-06-22 05:50:12.786628
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    dec = Decimal()
    assert dec.serialize(1.1) == 1.1
    assert dec.serialize(None) == None


# Generated at 2022-06-22 05:50:14.009118
# Unit test for method __or__ of class Field
def test_Field___or__():
    assert True
    # assert False # TODO: implement your test here



# Generated at 2022-06-22 05:50:15.691508
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean(description="description", title="title", allow_null=False).description == "description"

# Generated at 2022-06-22 05:50:24.666362
# Unit test for constructor of class Number
def test_Number():
    num = Number()
    assert num.minimum is None and num.maximum is None
    assert num.exclusive_minimum is None and num.exclusive_maximum is None
    assert num.precision is None and num.multiple_of is None

    num = Number(minimum = 1, maximum = 10, exclusive_minimum = 2, exclusive_maximum = 9, precision = 0.1, multiple_of = 2)
    assert num.minimum == 1 and num.maximum == 10
    assert num.exclusive_minimum == 2 and num.exclusive_maximum == 9
    assert num.precision == 0.1 and num.multiple_of == 2


# Generated at 2022-06-22 05:50:33.997282
# Unit test for method validate of class Union
def test_Union_validate():
    #!/usr/bin/env python
    def test_Union_validate():

        # simple
        class MyUnion(Union):
            def __init__(self, **kwargs):
                # __init__ not used in test, could be anything
                super().__init__(any_of=[
                    Int(**kwargs),
                    String(**kwargs),
                ])

        MyUnion().validate(1)
        MyUnion().validate("")
        with pytest.raises(ValidationError) as excinfo:
            MyUnion().validate("a")
        assert excinfo.value.code == "minimum"

    test_Union_validate()



# Generated at 2022-06-22 05:50:40.210210
# Unit test for constructor of class Text
def test_Text():
    field: Text = Text(allow_null=True, max_length=5, min_length=5, pattern="^.+$")
    assert field.allow_null == True
    assert field.format == "text"
    assert field.max_length == 5
    assert field.min_length == 5
    assert field.pattern == "^.+$"



# Generated at 2022-06-22 05:50:53.455288
# Unit test for constructor of class Const
def test_Const():
    try:
        assert Const(1, const=1).const == 1
        assert Const(1, const=1).allow_null is False
    except AssertionError:
        print("test_Const: FAILED")



# Generated at 2022-06-22 05:50:58.759743
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format = 'datetime')
    assert s.serialize(datetime(2020, 2, 28, 1, 0, 0)) == "2020-02-28T01:00:00"
    assert s.serialize(datetime(2020, 4, 10, 12, 0, 0)) == "2020-04-10T12:00:00"

# Generated at 2022-06-22 05:51:10.143411
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object(
        properties=dict(
            field1=String(),
            field2=Integer(),
            field3=Object(properties=dict(
                field1=Integer(),
                field2=String()
            ))
        )
    )
    value = dict(
        field1='Hello',
        field2=10,
        field3=dict(
            field1=100
        )
    )
    assert field.validate(value) == dict(
        field1='Hello',
        field2=10,
        field3=dict(
            field1=100
        )
    )
    try:
        field.validate(dict(field2=10))
    except ValidationError as e:
        assert e.messages() == [dict(code="required", index=['field1'])]
        assert e

# Generated at 2022-06-22 05:51:13.327744
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(3) == 3
    assert field.serialize('3') == '3'
    assert field.serialize(True) == True


# Generated at 2022-06-22 05:51:19.587172
# Unit test for method validate of class String
def test_String_validate():
    a = String(
        allow_blank = True,
        trim_whitespace = True,
        max_length = None,
        min_length = None,
        pattern = None,
        format = None
    )
    s = "hello"
    r = a.validate(s)
    if r == s:
        print("pass")
    else:
        print("fail")

# Generated at 2022-06-22 05:51:26.044377
# Unit test for constructor of class Date
def test_Date():
    class MyDate(Date):
        pass
    
    field = MyDate()
    assert field.format == "date"
    assert field.allow_null == True
    assert field.title == None
    assert field.description == None
    assert field.enum == None
    assert field.default == None
    assert field.min_length == None
    assert field.max_length == None
    assert field.pattern == None


# Generated at 2022-06-22 05:51:26.682627
# Unit test for method __or__ of class Field
def test_Field___or__():
    pass


# Generated at 2022-06-22 05:51:31.592699
# Unit test for constructor of class Text
def test_Text():
    # These test cases are for the constructor of class Text
    # The __init__ method only initializes the base class String
    # Calls the constructor of String with format: text
    t1 = Text(description="a string that contains just text")
    assert t1.description == "a string that contains just text"
    assert t1.format == "text"



# Generated at 2022-06-22 05:51:42.773315
# Unit test for constructor of class Object
def test_Object():
    properties = {
        "first": Text()
    }
    pattern_properties = {
        "^second": Text()
    }
    additional_properties = Text()
    property_names = Text()
    min_properties = 1
    max_properties = 2
    required = ["car"]
    obj_field = Object(properties=properties, pattern_properties=pattern_properties, additional_properties=additional_properties, property_names=property_names, min_properties=min_properties, max_properties=max_properties, required=required)
    assert isinstance(obj_field, Object)
    assert obj_field.properties == properties
    assert obj_field.pattern_properties == pattern_properties
    assert obj_field.additional_properties == additional_properties
    assert obj_field.property_names == property_names
    assert obj_field.min

# Generated at 2022-06-22 05:51:44.846107
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    assert field.format == 'text'


# Generated at 2022-06-22 05:51:59.364769
# Unit test for constructor of class Boolean
def test_Boolean():
    x = Boolean()
    assert x.errors == {'type': 'Must be a boolean.', 'null': 'May not be null.'}

# Generated at 2022-06-22 05:52:11.775964
# Unit test for constructor of class Array
def test_Array():
    # basic test
    arr1 = Array()
    assert arr1.items is None
    assert arr1.additional_items is False
    assert arr1.min_items is None
    assert arr1.max_items is None
    assert arr1.unique_items is False
    assert arr1.allow_null is True
    arr1.validate([1, 2, 3, 4])

    arr2 = Array(items=Integer())
    assert isinstance(arr2.items, Integer)
    assert arr2.items.has_default() is False
    assert arr2.additional_items is False
    assert arr2.min_items is None
    assert arr2.max_items is None
    assert arr2.unique_items is False
    arr2.validate([1, 2, 3, 4])


# Generated at 2022-06-22 05:52:15.223273
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Sample1_Field(Field):
        def __init__(self):
            Field.__init__(self,default="Sample1_Field",allow_null=False)
    x = Sample1_Field()
    assert x.get_default_value() == "Sample1_Field"


# Generated at 2022-06-22 05:52:21.112447
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    #  creating the object
    obj = Field()
    obj.errors["test"] = "test me"
    text = obj.validation_error("test")
    assert text.code == "test"
    assert text.text == "test me"


# Generated at 2022-06-22 05:52:29.235635
# Unit test for constructor of class Field
def test_Field():
    assert Field._creation_counter == 0
    assert Field.errors == {}
    assert Field(title='test description', description='test description', default=NO_DEFAULT, allow_null=False)
    assert Field()
    assert Field(title='test description', description='test description', default=NO_DEFAULT, allow_null=True)
    assert Field(title='test description', description='test description')
    assert Field(title='test description')
    assert Field(description='test description')
    Field(title='test description', description='test description', default=NO_DEFAULT, allow_null=True)
    Field(title='test description', description='test description', default=NO_DEFAULT, allow_null=False)

test_Field()



# Generated at 2022-06-22 05:52:33.460044
# Unit test for method validate of class Object

# Generated at 2022-06-22 05:52:35.683171
# Unit test for method serialize of class Array
def test_Array_serialize():
    serial = Array(items=Integer())
    assert serial.serialize([1,2,3]) == [1,2,3]


# Generated at 2022-06-22 05:52:40.582174
# Unit test for constructor of class Field
def test_Field():
    field = Field(title='title', description='description', default=None, allow_null=False)
    assert field.title == 'title'
    assert field.description == 'description'
    assert field.default == None
    assert field.allow_null == False
    assert field.errors == {}
    assert field._creation_counter == 0
    

# Generated at 2022-06-22 05:52:49.325110
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice()
    value = field.validate('red')
    assert value == 'red', 'value ["red" should be "red" got "' + value + '" ]' 
    field.allow_null = True
    value = field.validate('red')
    assert value == 'red', 'value ["red" should be "red" got "' + value + '" ]' 
    value = field.validate(None)
    assert value == None, 'value [None should be None got "' + value + '" ]' 



# Generated at 2022-06-22 05:52:50.561098
# Unit test for constructor of class Text
def test_Text():
    a = Text(format='text')


# Generated at 2022-06-22 05:53:08.212861
# Unit test for constructor of class Time
def test_Time():
    expected_format = "time"
    expected_allow_null = True
    expected_default = None
    expected_allow_default = True
    expected_allow_empty = False
    expected_validator = None
    expected_serializer = None
    expected_deserializer = None
    expected_title = None
    expected_description = None
    expected_metadata = None
    expected_enum = None
    time = Time()

    assert time.format == expected_format
    assert time.allow_null == expected_allow_null
    assert time.default == expected_default
    assert time.allow_default == expected_allow_default
    assert time.allow_empty == expected_allow_empty
    assert time.validator == expected_validator
    assert time.serializer == expected_serializer
    assert time.deserializer == expected_des

# Generated at 2022-06-22 05:53:14.381654
# Unit test for method serialize of class Array
def test_Array_serialize():
    field_object = Array()
    value = ([1, 2], [3, 4])
    assert field_object.serialize(value) == value

    field_object = Array(items=[Integer()])
    value = ([1, 2], [3, 4])
    assert field_object.serialize(value) == [1, 2, 3, 4]

    field_object = Array(items=[Integer()], min_items=2)
    value = ([1, 2], [3, 4])
    assert field_object.serialize(value) == [1, 2, 3, 4]


# Generated at 2022-06-22 05:53:17.063134
# Unit test for constructor of class Choice
def test_Choice():
    choices = ["1", "2", "3"]
    choice = Choice(choices)
    assert choice.choices == [("1", "1"), ("2", "2"), ("3", "3")]


# Generated at 2022-06-22 05:53:23.676740
# Unit test for constructor of class Choice
def test_Choice():
    data = [
        (None, ["choice", "null"]),
        ("", ["choice", "null", "required"]),
        (1, ["choice", "type"]),
    ]
    for value, expected in data:
        c = Choice(choices=[1])
        actual = list(c.validate_or_error(value).error.messages.keys())
        assert actual == expected



# Generated at 2022-06-22 05:53:31.858311
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    assert Boolean().validate(None) == None

    assert Boolean().validate(True) == True
    assert Boolean().validate(False) == False

    assert Boolean().validate(0) == False
    assert Boolean().validate(1) == True
    assert Boolean().validate(42) == True
    assert Boolean().validate(0.0) == False
    assert Boolean().validate(1.0) == True
    assert Boolean().validate(42.0) == True

    assert Boolean(allow_null=True).validate(None) == None
    assert Boolean().validate(None) == None

    assert Boolean().validate('true') == True
    assert Boolean().validate('TRUE') == True
    assert Boolean().validate('True') == True
    assert Boolean().validate('false') == False
    assert Boolean().validate

# Generated at 2022-06-22 05:53:43.225434
# Unit test for method validate of class Number

# Generated at 2022-06-22 05:53:46.976333
# Unit test for method serialize of class String
def test_String_serialize():
    stringField = String(allow_blank=True)
    expected = '2020-03-03'
    result = stringField.serialize(expected)
    assert result == expected


# Generated at 2022-06-22 05:53:50.441390
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean(allow_null = True, default = False)
    assert boolean.title == ""
    assert boolean.description == ""
    assert boolean.allow_null == True
    assert boolean.get_default_value() == False



# Generated at 2022-06-22 05:53:56.686260
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    #Arrange
    string_field = String(allow_null=True)
    # Act
    result = string_field.get_error_text('invalid')
    # Assert
    assert result == "Value must be a string."
# End test for method get_error_text of class Field



# Generated at 2022-06-22 05:53:59.600329
# Unit test for constructor of class Const
def test_Const():
    Const(1, description="")
    Const(None, description="")
    Const(False, description="")


# Generated at 2022-06-22 05:54:20.143239
# Unit test for constructor of class Choice
def test_Choice():
    c=Choice(choices=[('a', 'First'), ('b', 'Second')])
    assert (c.choices==[('a', 'First'), ('b', 'Second')])


# Generated at 2022-06-22 05:54:22.689928
# Unit test for constructor of class Const
def test_Const():
    a = Const(const='')
    assert a.const==''

# Unit Test for method validate() of class Const

# Generated at 2022-06-22 05:54:34.134165
# Unit test for method validate of class Object

# Generated at 2022-06-22 05:54:35.838614
# Unit test for method validate of class Any
def test_Any_validate():
    expected_result = "abc"
    field = Any()
    result = field.validate(expected_result, strict=False)
    assert(result == expected_result)


# Generated at 2022-06-22 05:54:43.250997
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    print("\n--- Unit test for method get_error_text of class Field ---")
    class DummyField(Field):
        pass
    f = DummyField()
    print("Expected: 'null value is not allowed'")
    result = f.get_error_text('null')
    print("Output: " + result)
    assert result == 'null value is not allowed'
    print("PASSED!")

test_Field_get_error_text()



# Generated at 2022-06-22 05:54:45.405838
# Unit test for method serialize of class Field
def test_Field_serialize():
    f = Int()
    assert f.serialize(5) == 5



# Generated at 2022-06-22 05:54:50.109602
# Unit test for method has_default of class Field
def test_Field_has_default():
    string_field = String()
    assert not string_field.has_default()
    string_field1 = String(default="test")
    assert string_field1.has_default()
    string_field2 = String(default="test")
    assert string_field2.has_default()



# Generated at 2022-06-22 05:54:53.917105
# Unit test for constructor of class Number
def test_Number():
    try:
        Number(1)
        assert False
    except:
        assert True


# Generated at 2022-06-22 05:55:01.250619
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert time.errors['type'] == 'Must be a string.'
    assert time.errors['format'] == 'Must be in the format "time".'
    assert time.errors['min_length'] == 'Must be at least {min_length} characters.'
    assert time.errors['max_length'] == 'Must be no more than {max_length} characters.'
    assert time.errors['pattern'] == 'Must match the pattern "*".'


# Generated at 2022-06-22 05:55:02.676179
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize("") == ""
