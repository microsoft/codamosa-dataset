

# Generated at 2022-06-22 05:47:39.109394
# Unit test for constructor of class Union
def test_Union():
    field = Union([Any(), Any()])
    assert field.any_of[0].__class__.__name__ == "Any"
    assert field.any_of[0].allow_null == True
    assert field.any_of[1].__class__.__name__ == "Any"
    assert field.any_of[1].allow_null == True
    assert field.allow_null == True


# Generated at 2022-06-22 05:47:47.997165
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    # arrange
    field = Field()
    field.errors = {
        'code1': 'err_code1',
        'code2': 'err_code2'
    }

    # act
    err_code1 = field.get_error_text('code1')
    err_code2 = field.get_error_text('code2')
    # assert
    assert err_code1 == 'err_code1'
    assert err_code2 == 'err_code2'



# Generated at 2022-06-22 05:47:52.326214
# Unit test for method validate of class Choice
def test_Choice_validate():
    """
    Choice unittest
    """
    # test for type = str and value = choice
    choice = Choice()
    assert choice.validate("choice") == "choice"
    # test for type = null and allow_null = True
    choice = Choice(allow_null = True)
    assert choice.validate(None) == None
    # test for type = null and allow_null = False
    with pytest.raises(ValidationError):
        choice = Choice()
        choice.validate(None)
    # test for type = str and value = str and not in choices
    with pytest.raises(ValidationError):
        choice = Choice()
        choice.validate("wrongValue")
    # test for type = null and allow_null = True and allow_blank = True and strict = False

# Generated at 2022-06-22 05:47:53.922914
# Unit test for method validate of class Any
def test_Any_validate():
    value = {'hello': 'world'}
    assert Any().validate(value) == value


# Generated at 2022-06-22 05:47:55.997803
# Unit test for constructor of class Date
def test_Date():
    class Person(Schema):
        name = String()
        birthday = Date()
    assert Person.keys() == ['name', 'birthday']



# Generated at 2022-06-22 05:48:06.903397
# Unit test for constructor of class Object
def test_Object():
    s = Object()
    assert s.properties == {}
    assert s.pattern_properties == {}
    assert s.additional_properties is True
    assert s.property_names is None
    assert s.min_properties is None
    assert s.max_properties is None
    assert s.required is None

    s = Object(properties={'name': String()})
    assert s.properties == {'name': String()}
    assert s.pattern_properties == {}
    assert s.additional_properties is True
    assert s.property_names is None
    assert s.min_properties is None
    assert s.max_properties is None
    assert s.required is None

    s = Object(pattern_properties={r'^[a-z]+$': String()})
    assert s.properties == {}

# Generated at 2022-06-22 05:48:08.575405
# Unit test for constructor of class DateTime
def test_DateTime():
    d = DateTime()
    assert d.format == "datetime"
    return

# Generated at 2022-06-22 05:48:12.901913
# Unit test for constructor of class Field
def test_Field():
    title = 'test_title'
    description = 'test_description'
    default = 'test_default'
    allow_null = True
    field = Field(title=title, description=description, default=default, allow_null=allow_null)
    assert field._creation_counter == 0
    assert field.title == title
    assert field.description == description
    assert field.allow_null == allow_null
    assert field.default == default


# Generated at 2022-06-22 05:48:15.162487
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert None is None

# Generated at 2022-06-22 05:48:16.791582
# Unit test for constructor of class Any
def test_Any():
    c=Any()
    assert isinstance(c,Any)


# Generated at 2022-06-22 05:48:37.819674
# Unit test for constructor of class Decimal
def test_Decimal():
    assert isinstance(Decimal(minimum=1.0, maximum=2.0, exclusive_maximum=3.0, exclusive_minimum=4.0, multiple_of=5.0), Decimal)
    assert isinstance(Decimal(allow_blank=True, allow_null=True), Decimal)
    assert isinstance(Decimal(allow_blank=True, allow_null=True, title="", description="", default=NO_DEFAULT), Decimal)
    assert isinstance(Decimal(allow_blank=True, allow_null=True, title="", description=""), Decimal)


# Generated at 2022-06-22 05:48:39.377990
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean().validate(False) == False


# Generated at 2022-06-22 05:48:42.410977
# Unit test for method validate of class Const
def test_Const_validate(): 
    result = Const(const="pending",name="const",description="const")
    assert result.validate("pending") == "pending"


# Generated at 2022-06-22 05:48:48.289069
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean.errors == {"type": "Must be a boolean.", "null": "May not be null."}
    assert Boolean.coerce_values == {
        "true": True,
        "false": False,
        "on": True,
        "off": False,
        "1": True,
        "0": False,
        "": False,
        1: True,
        0: False,
    }
    assert Boolean.coerce_null_values == {"", "null", "none"}


# Generated at 2022-06-22 05:48:50.301500
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    if not isinstance(Decimal().serialize(12),float):
        assert False,"test_Decimal_serialize"
    else:
        assert True


# Generated at 2022-06-22 05:48:51.069288
# Unit test for constructor of class Decimal
def test_Decimal():
    Decimal(maximum=5)


# Generated at 2022-06-22 05:49:02.211286
# Unit test for method validate of class Object
def test_Object_validate():
    data = {"a":1,"b":2,"c":[4,4,4]}
    str = String(name = "String Test")
    bool = Boolean(name = "Bool Test")
    int = Integer(name = "Integer Test", minimum=0, maximum=10)
    dictField = Object(name = "Dict Field", properties = {"str":str, "bool":bool, "int":int})
    dictField.validate(data)

    # data = {"a":1,"b":2,"c":[4,4,4]}
    # str = String(name = "String Test")
    # bool = Boolean(name = "Bool Test")
    # int = Integer(name = "Integer Test", minimum=0, maximum=10)
    # dictField = Object(name = "Dict Field", properties = {"str":str, "

# Generated at 2022-06-22 05:49:02.792241
# Unit test for method validate of class Const
def test_Const_validate():
    Const(2)



# Generated at 2022-06-22 05:49:03.531335
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean()



# Generated at 2022-06-22 05:49:05.700882
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert(text.format == "text")
    assert(len(text.items) == 0)
    assert(text.allow_null == False)



# Generated at 2022-06-22 05:49:19.836657
# Unit test for constructor of class Union
def test_Union():
    testField = Union([Field(), Field(allow_null=True)])
    assert testField.allow_null

    testField = Union([String(), Field(allow_null=False)])
    assert testField.allow_null

    testField = Union([String(), Field(allow_null=True), String()])
    assert testField.allow_null



# Generated at 2022-06-22 05:49:29.515277
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    from typesystem.base import ValidationResult
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    ERROR_MESSAGE = 'This is an error message'
    class FieldSubclass(Field):
      def validate(self, value, **kwargs):
        raise ValidationError(ERROR_MESSAGE)
    subclass = FieldSubclass()
    result = subclass.validate_or_error(value='', strict=False)
    assert isinstance(result, ValidationResult)
    assert result.value is None
    assert isinstance(result.error, ValidationError)
    assert result.error.text == ERROR_MESSAGE
    assert result.error.code == 'invalid'

# Generated at 2022-06-22 05:49:30.534231
# Unit test for constructor of class Union
def test_Union():
    assert isinstance(Union([Integer(),String()], allow_null=True), Field)

# Generated at 2022-06-22 05:49:34.899178
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a = Decimal()
    assert a.serialize(100) == 100.0
    assert a.serialize(None) == None
    assert a.serialize('100') == 100.0
    
# Unit tests for class Decimal

# initial, default

# Generated at 2022-06-22 05:49:46.134695
# Unit test for method validate of class Const
def test_Const_validate():
    def get_dict(field):
        return {
            'nullable': field.nullable,
            'default': field.default,
            'const': field.const,
            'title': field.title,
            'description': field.description,
            'read_only': field.read_only,
            'write_only': field.write_only,
            'allow_null': field.allow_null,
            'validators': field.validators
        }

    # case 1
    const = Const(1)
    try:
        const.validate(1)
    except ValidationError:
        assert False
    else:
        assert True
    try:
        const.validate(0)
    except ValidationError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:49:56.277029
# Unit test for method validate of class Array
def test_Array_validate():
    import random
    import json
    import jsonschema
    from jsonschema import ValidationError
    from jsonschema import validate
    from jsonschema import Draft4Validator as Validator
    from .utils import (
        Mock,
        assert_schema_error,
    )

    # test for error
    class Mockitems(Mock):
        __qualname__ = "Mockitems"
        _expected_schema_error = [
            {
            'message': 'Additional items are not allowed',
            'pos': [5],
            },
        ]
        _expected_strict_error = [
            {
            'message': 'Additional items are not allowed',
            'pos': [5],
            },
        ]

# Generated at 2022-06-22 05:50:02.544364
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    title = "title_2"
    description = "description_2"
    default  = "default"
    allow_null  = True
    f = Field(title=title,description=description,default=default,allow_null=allow_null)
    code = "code"
    r = f.validation_error(code)
    assert isinstance(r,ValidationError)


# Generated at 2022-06-22 05:50:09.363152
# Unit test for constructor of class Const
def test_Const():
    schema = Const([1, 2, 3])
    assert schema.const == [1, 2, 3]
    assert schema.validate([1, 2, 3]) == [1, 2, 3]

    with pytest.raises(ValidationError) as e:
        schema.validate(3)
    assert e.value.messages[0].code == "const"
    assert e.value.messages[0].text == "Must be the value '[1, 2, 3]'."



# Generated at 2022-06-22 05:50:12.184573
# Unit test for constructor of class Number
def test_Number():
    class testNumber(Number):
        pass

    x = testNumber()
    assert x != None
    assert isinstance(x, testNumber)


# Generated at 2022-06-22 05:50:14.306908
# Unit test for method validate of class Union
def test_Union_validate():
    any_of = [Integer(), Number()]
    integer = Integer()
    value = 1
    integer_field = Union(any_of)

    result = integer_field.validate(value)
    # assert result == 1
    print(result)

test_Union_validate()


# Generated at 2022-06-22 05:50:59.993299
# Unit test for constructor of class Float
def test_Float():
    try:
        Float()
    except Exception:
        assert False
    try:
        Float(minimum=5, maximum=7)
    except Exception:
        assert False



# Generated at 2022-06-22 05:51:01.221596
# Unit test for constructor of class Boolean
def test_Boolean():
    # returns ValidationError with code "type"
    value = Boolean().validate_or_error(42)
    assert value.error.text == "Must be a boolean."



# Generated at 2022-06-22 05:51:04.570468
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class SomeFieldClass(Field):
        def __init__(self):
            self.default = 0

    field = SomeFieldClass()
    assert field.get_default_value() == 0



# Generated at 2022-06-22 05:51:04.937216
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    pass


# Generated at 2022-06-22 05:51:10.193868
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    checker_type = type(Field())
    field = Field()
    code = "standard_error"
    result = field.get_error_text(code)
    expected = "Standard Error"
    assert result == expected
    assert isinstance(field, checker_type)
    assert isinstance(field, Field)



# Generated at 2022-06-22 05:51:12.825426
# Unit test for constructor of class Time
def test_Time():
    try:
        Time(default='a')
    except Exception as e:
        pass
    else:
        print('test_Time failed')



# Generated at 2022-06-22 05:51:15.347383
# Unit test for constructor of class Union
def test_Union():
    assert len(Union(any_of=[Integer(), String()]).any_of) == 2



# Generated at 2022-06-22 05:51:19.399073
# Unit test for constructor of class Decimal
def test_Decimal():
    # Test1: no precision
    decimal_test = Decimal()
    assert decimal_test.minimum is None
    # Test2: precision
    decimal_test = Decimal(precision='0.01')
    assert decimal_test.minimum is None



# Generated at 2022-06-22 05:51:22.572928
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.title == ""
    assert field.description == ""
    assert field.allow_null == False
    assert field.default == None

# Generated at 2022-06-22 05:51:24.842995
# Unit test for method validate of class Any
def test_Any_validate():
    field = Any()
    value = 5
    assert field.validate(value) == value
    assert field.validate(None) is None


# Generated at 2022-06-22 05:51:38.132416
# Unit test for method validate of class Choice

# Generated at 2022-06-22 05:51:42.570272
# Unit test for constructor of class Union
def test_Union():
    assert Union([]) != None
    assert Union([String()]) != None
    assert Union([Numeric()]) != None
    assert Union([Integer()]) != None
    assert Union([Boolean()]) != None
    assert Union([Object()]) != None
    assert Union([Array()]) != None



# Generated at 2022-06-22 05:51:51.145516
# Unit test for constructor of class Object
def test_Object():
    test_dict = {
        "a": 'True',
        "b": 'False',
        "c": 'null',
    }

    properties = {
        "a": "Boolean",
        "b": "Boolean",
        "c": "Boolean",
    }
    for key, val in properties.items():
        properties[key] = eval('%s()' % val)

    obj = Object(properties=properties, required=['a', 'c'], allow_null=True)
    print(obj.validate(test_dict))


# Generated at 2022-06-22 05:52:01.982824
# Unit test for method validate of class Union
def test_Union_validate():
    from zerver.lib.types import Validator
    from zerver.lib.test_classes import ZulipBaseTest
    import json
    import pytest
    from collections import OrderedDict
    def test_validate_with_null_value():
        validator = Union([Integer(default=10), String()])
        valid = validator.validate(None)
        assert valid is None

    def test_validate_with_non_null_value():
        validator = Union([Integer(default=10), String()])
        valid = validator.validate(None)
        assert valid is None

    def test_validate_with_cases_only_matching_null_value():
        validator = Union([Integer(), String()])
        valid = validator.validate(None)
        assert valid is None


# Generated at 2022-06-22 05:52:08.045419
# Unit test for method validate of class Number
def test_Number_validate():
    # positive test
    num = Number()
    res = num.validate('12')
    assert True == isinstance(res, (int, float))

    # negative test
    res = num.validate('12.1abc')
    assert False == isinstance(res, (int, float))



# Generated at 2022-06-22 05:52:19.761626
# Unit test for method validate of class Choice
def test_Choice_validate():
    from srs.schema import Choices, Choice
    from collections import namedtuple
    from srs.coreschema import String, Integer
    from srs.errors import ValidationError
    from srs.validators import Uniqueness
    from srs.utils import read_file
    from srs.core import JSONObject, JSONArray, HTTP_200_OK, HTTP_201_CREATED
    from srs.values import Obj

    class AppObj(JSONObject):
        schema = {
            "id": Integer(default=None),
            "name": String(default=None),
            "flag": Choice(choices=[(1, "Good"), (2, "Bad")], default=None)
        }


# Generated at 2022-06-22 05:52:23.936284
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime(True, False)
    assert(isinstance(dt, DateTime))
    assert(dt.allow_null == True)
    assert(dt.allow_empty == False)
    assert(dt.pattern == None)
    assert(dt.min_length == None)
    assert(dt.max_length == None)
    assert(dt.min_value == None)
    assert(dt.max_value == None)
    assert(dt.format == "datetime")
    assert(dt.enum == None)
    assert(dt.choices == None)
    assert(dt.properties == None)
    assert(dt.pattern_properties == None)
    assert(dt.additional_properties == None)
    assert(dt.property_names == None)
    assert(dt.min_properties == None)
   

# Generated at 2022-06-22 05:52:29.455176
# Unit test for constructor of class Decimal
def test_Decimal():
    d = Decimal(
        title="asdf", description="te", default=decimal.Decimal("1.12345")
    )
    assert(not d.validate_or_error(1.12345).is_ok)
    assert(d.validate_or_error(decimal.Decimal("1.12345")).is_ok)


# Generated at 2022-06-22 05:52:30.905492
# Unit test for constructor of class Time
def test_Time():
    time_field = Time()
    eq_(time_field.format, "time")


# Generated at 2022-06-22 05:52:32.759840
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field().validate==None
test_Field_validate()



# Generated at 2022-06-22 05:52:50.754851
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    print("Unit test for method serialize of class Decimal")
    test_Decimal_serialize_value = Decimal()
    assert test_Decimal_serialize_value.serialize(None) == None
    assert test_Decimal_serialize_value.serialize(100) == 100.0


# Generated at 2022-06-22 05:52:58.710315
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    field.allow_null = True
    assert field.validate(None) == None
    assert field.validate("") == False
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("1") == True
    assert field.validate("0") == False
    assert field.validate("true") == True
    assert field.validate("false") == False
    assert field.validate("on") == True
    assert field.validate("off") == False
    assert field.validate("null") == None
    assert field.validate("none") == None
    assert field.validate("test") == False
    assert field.validate(2) == False
    assert field.validate(1) == True
    assert field.valid

# Generated at 2022-06-22 05:53:04.887446
# Unit test for constructor of class Time
def test_Time():
    # Testing all different constructor inputs
    Time1 = Time()
    Time2 = Time(strict=True)
    Time3 = Time(allow_null=None) # type: ignore
    Time4 = Time(default="test")
    Time5 = Time(strict=True, allow_null=None, default="test")
    Time6 = Time(name="test")
    Time7 = Time(strict=True, allow_null=None, default="test", name="test")


# Generated at 2022-06-22 05:53:09.608595
# Unit test for constructor of class Date
def test_Date():
    assert Date.__init__ is not Field.__init__
    assert Date.__init__.__qualname__.split('.', 2)[-1] == 'Date.<locals>.<lambda>.<locals>.<lambda>'

# Generated at 2022-06-22 05:53:15.132064
# Unit test for method validate of class Any
def test_Any_validate():
    # Test for method validate of class Any
    def validator(s:str):
        assert s == 'hello'
    test = Any()
    test.validate(12)
    test.validate(12.1)
    test.validate(True)
    test.validate([1,2,3])
    test.validate('hello')
    test.validate(validator)


# Generated at 2022-06-22 05:53:24.858084
# Unit test for method validate of class Object
def test_Object_validate():
    schema = Object(properties={'a':Integer(), 'b':Boolean()})
    assert schema.validate({'a':3, 'b':True}) == {'a':3, 'b':True}
    assert schema.validate({'a':3, 'b':'true'}) == {'a':3, 'b':True}
    with pytest.raises(ValidationError) as excinfo:
        schema.validate({'a':3, 'c':True})
    assert excinfo.value.messages() == [Message(text='Invalid property name.', code='invalid_property', index=['c'])]


# Generated at 2022-06-22 05:53:32.293767
# Unit test for method serialize of class String
def test_String_serialize():
    a = String(format = 'datetime')
    assert(a.serialize(datetime.datetime.now()) == datetime.datetime.now().timestamp())
    assert(a.serialize(datetime.datetime.utcnow()) == datetime.datetime.utcnow().timestamp())
    assert(a.serialize(datetime.datetime.now().isoformat()) == datetime.datetime.now().timestamp())
    assert(a.serialize(datetime.datetime.utcnow().isoformat()) == datetime.datetime.utcnow().timestamp())
    assert(a.serialize(datetime.datetime.now().timestamp()) == datetime.datetime.now().timestamp())

# Generated at 2022-06-22 05:53:37.273039
# Unit test for method validate of class Field
def test_Field_validate():
    from typesystem import Integer
    from unittest.mock import patch

    integer = Integer(title="Title",description="description",default=1, allow_null=True)
    with patch.object(integer, 'validate', return_value=True) as mock_method:
        integer.validate(1)
        assert mock_method.called

# Generated at 2022-06-22 05:53:49.082212
# Unit test for method validate of class Choice
def test_Choice_validate():
	choice = Choice(default=None, allow_null=True)
	assert choice.validate(None) == None
	
	choice = Choice(allow_null=False)
	assert choice.validate(None) == None
	
	choice = Choice(allow_null=True, choices=["a","b"])
	assert choice.validate("a") == "a"
	
	choice = Choice(choices=["a","b"])
	assert choice.validate("a") == "a"
	
	choice = Choice(default=None, allow_null=True)
	with pytest.raises(ValidationError):
		assert choice.validate(None)
		
	choice = Choice(allow_null=False, choices=["a","b"])

# Generated at 2022-06-22 05:54:01.238595
# Unit test for constructor of class Boolean
def test_Boolean():
    field = Boolean()
    assert field.validate(True)
    assert not field.validate(False)
    assert field.validate(None)
    # If a value is passed as argument that is null, the object is returned
    assert field.validate("")
    assert field.validate(1)
    # If the strict attribute is set, an exception is throwed if the value is not boolean
    try:
        field.validate("False", strict=True)
    except ValidationError:
        assert True
    else:
        assert False
    # For the string value "null", the method validate return the object
    assert field.validate("null")
    assert field.validate("none")
    assert field.validate("false")
    assert field.validate("0")
    assert field.validate("on")

# Generated at 2022-06-22 05:54:17.032818
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field(title = '', description = '')
    code = 'a'
    field.errors[code] = 'a'
    assert field.validation_error(code) == ValidationError(text='a', code='a')



# Generated at 2022-06-22 05:54:18.147402
# Unit test for constructor of class Any
def test_Any():
  assert(True)


# Generated at 2022-06-22 05:54:25.023990
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    errors = {}
    errors['f1 code'] = 'f1'
    errors['f2 code'] = 'f2'
    errors['f3 code'] = 'f3'
    field = Field(title = 'f1', description = 'f2', default = 'f3')
    assert(field.validation_error('f1 code') == ValidationError(text = 'f1', code = 'f1 code'))
    assert(field.validation_error('f2 code') == ValidationError(text = 'f2', code = 'f2 code'))
    assert(field.validation_error('f3 code') == ValidationError(text = 'f3', code = 'f3 code'))

# Generated at 2022-06-22 05:54:31.568001
# Unit test for constructor of class Array
def test_Array():
    try:
        Array(items=Integer())
    except AssertionError:
        is_assertion_error = True
    else:
        is_assertion_error = False
    assert is_assertion_error is False
    try:
        Array(items=None)
    except AssertionError:
        is_assertion_error = True
    else:
        is_assertion_error = False
    assert is_assertion_error is False
    try:
        Array(items=["a", "a"])
    except AssertionError:
        is_assertion_error = True
    else:
        is_assertion_error = False
    assert is_assertion_error is True
    try:
        Array(items=[Integer(), String()])
    except AssertionError:
        is_assertion_

# Generated at 2022-06-22 05:54:42.260024
# Unit test for method validate of class String
def test_String_validate():
    string = String(max_length=50)
    #This test cast blank strings to None if allow_blank=False
    assert string.validate("         ", strict=True) is None
    #This test cast blank strings to None if allow_null=False
    assert string.validate("         ", strict=False) is None
    #This test cast blank strings to '' if allow_blank=True
    string.allow_blank=True
    assert string.validate("         ", strict=False) == ''
    #This test cast blank strings to '' if allow_blank=True
    string.allow_blank=False
    assert string.validate("         ", strict=False) == '         '
    #This test don't raise exception if allow_blank=True
    string.allow_blank=True

# Generated at 2022-06-22 05:54:52.957346
# Unit test for constructor of class String
def test_String():

    assert String(allow_blank=False,trim_whitespace=True,max_length=None,min_length=None,pattern=None,format=None,title=None,description=None).allow_blank == False
    assert String(allow_blank=False,trim_whitespace=True,max_length=None,min_length=None,pattern=None,format=None,title=None,description=None).trim_whitespace == True
    assert String(allow_blank=False,trim_whitespace=True,max_length=None,min_length=None,pattern=None,format=None,title=None,description=None).max_length == None

# Generated at 2022-06-22 05:54:56.504423
# Unit test for constructor of class Field
def test_Field():
    assert Field(title="foo", allow_null=True)
    assert Field(title="foo", description="", allow_null=True)


# Generated at 2022-06-22 05:55:04.481129
# Unit test for method validate of class Array
def test_Array_validate():
    schema = Array(items=String())
    assert schema.validate(["x"]) == ["x"]
    assert schema.validate([]) == []
    with pytest.raises(ValidationError) as excinfo:
        schema.validate(["x", 1])
    assert excinfo.value.messages() == [
        {"code": "type", "message": "Must be a string.", "path": [1]}
    ]
    with pytest.raises(ValidationError) as excinfo:
        schema.validate(["x", None])
    assert excinfo.value.messages() == [
        {"code": "type", "message": "Must be a string.", "path": [1]}
    ]

    with pytest.raises(ValidationError) as excinfo:
        schema.validate(None)


# Generated at 2022-06-22 05:55:06.056700
# Unit test for constructor of class Field
def test_Field():
    F = Field(title="f", description="d", allow_null=True)
    assert F.title == "f"
    assert F.description == "d"
    assert F.allow_null == True


# Generated at 2022-06-22 05:55:11.317208
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object()
    value = field.validate({"a": 1})
    assert value == {"a": 1}
    value = field.validate({"a": 1, "b": 2})
    assert value == {"a": 1, "b": 2}


# Generated at 2022-06-22 05:55:37.460233
# Unit test for method validate of class Array
def test_Array_validate():
    class test_array(Field):
        errors = {
            "type": "Must be an array.",
            "null": "May not be null.",
            "empty": "Must not be empty.",
            "exact_items": "Must have {min_items} items.",
            "min_items": "Must have at least {min_items} items.",
            "max_items": "Must have no more than {max_items} items.",
            "additional_items": "May not contain additional items.",
            "unique_items": "Items must be unique.",
        }

# Generated at 2022-06-22 05:55:39.328079
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    assert f.validate(1) == 1


# Generated at 2022-06-22 05:55:41.913076
# Unit test for constructor of class String
def test_String():
    try:
        String(title="", description="")
    except NotImplementedError:
        return False
    return True



# Generated at 2022-06-22 05:55:52.165533
# Unit test for constructor of class Union
def test_Union():
    from . import (
        Boolean,
        Any,
        Bool,
        Bytes,
        Date,
        DateTime,
        Decimal,
        Dict,
        Email,
        Enum,
        Error,
        ErrorMessage,
        ErrorCollection,
        Errors,
        Field,
        Float,
        FormattedString,
        get_default_validate_resolver,
        get_default_validators,
        Integer,
        List,
        NoneType,
        Number,
        Object,
        String,
        Time,
        Tuple,
        TypeDefinition,
        Union,
        URL,
        UUID,
        ValidationError,
    )

# Generated at 2022-06-22 05:55:57.051745
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.title == ""
    assert s.description == ""
    assert s.allow_blank == False
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.pattern_regex == None

test_String()

