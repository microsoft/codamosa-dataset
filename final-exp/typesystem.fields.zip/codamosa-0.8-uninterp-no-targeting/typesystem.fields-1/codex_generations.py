

# Generated at 2022-06-22 05:47:42.352301
# Unit test for constructor of class Choice
def test_Choice():
    s = Choice()
    assert s.allow_null
    

# Generated at 2022-06-22 05:47:46.171822
# Unit test for method serialize of class Array
def test_Array_serialize():
    print(print_test_message("test_Array_serialize"))

    item_schema = String()
    array_schema = Array(items=item_schema)
    array_schema.serialize(["a", "b", "c"])
    print("Test passed")

# Generated at 2022-06-22 05:47:56.584122
# Unit test for constructor of class Date
def test_Date():
    string = Date()
    #Checking whether the min value is correct
    try:
        string.validate('20200101')
    except ValidationError as e:
        assert False
    #Checking whether the max value is correct
    try:
        string.validate('20201231')
    except ValidationError as e:
        assert False
    #Checking whether the error returned is correct
    try:
        string.validate('abc')
    except ValidationError as e:
        assert False
    try:
        string.validate('2020-01-01')
    except ValidationError as e:
        assert False
    try:
        string.validate('2020-01-32')
    except ValidationError as e:
        assert False

# Generated at 2022-06-22 05:48:00.270200
# Unit test for constructor of class Integer
def test_Integer():
    print("\nStarting test_Integer()")
    int_test = Integer()
    assert(int_test.numeric_type == int)


# Generated at 2022-06-22 05:48:10.615264
# Unit test for method validate of class String
def test_String_validate():
    s = String(max_length=5)
    assert s.validate("123") == "123"
    try:
        s.validate("123456")
        assert False, "Runtime Error"
    except Exception as e:
        assert type(e) == ValidationError
        assert e.code == "max_length"
    try:
        s.validate("")
        assert False, "Runtime Error"
    except Exception as e:
        assert type(e) == ValidationError
        assert e.code == "blank"
    try:
        s.validate(None)
        assert False, "Runtime Error"
    except Exception as e:
        assert type(e) == ValidationError
        assert e.code == "null"

# Generated at 2022-06-22 05:48:16.034863
# Unit test for method validate of class Field
def test_Field_validate():
    # Test that the method validate raises a NotImplementedError
    myfield = Field()
    with pytest.raises(NotImplementedError):
        myfield.validate(None, strict=False)


# Generated at 2022-06-22 05:48:19.313018
# Unit test for constructor of class Union
def test_Union():
  u = Union([String(), Integer()])
  assert type(u) == Union
  assert type(u.any_of[0]) == String
  assert type(u.any_of[1]) == Integer


# Generated at 2022-06-22 05:48:21.987584
# Unit test for method has_default of class Field
def test_Field_has_default():
    f = Field()
    assert not f.has_default()
    f = Field(default=1)
    assert f.has_default()


# Generated at 2022-06-22 05:48:27.032894
# Unit test for constructor of class Array
def test_Array():
    a = Array(min_items=1)
    assert a.min_items == 1
    assert a.max_items is None
    assert a.unique_items is False
    assert a.additional_items is True
    assert a.items is None

    a = Array(min_items=1, max_items=1, unique_items=True, additional_items=False)
    assert a.min_items == 1
    assert a.max_items == 1
    assert a.unique_items is True
    assert a.additional_items is False


# Generated at 2022-06-22 05:48:31.705533
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.validate(False) == False
    assert b.validate(True) == True
    assert b.validate('') == False


# Generated at 2022-06-22 05:48:55.873166
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class Field(Field):
        errors = {"error": "An error has been occured"}
        
        def validate(self, value, strict=False):
            if isinstance(value, int):
                return value
            raise ValidationError(text="error", code="error")
    field = Field()
    assert field.validate_or_error(1).value == 1
    assert field.validate_or_error(1.0).value == 1
    assert field.validate_or_error([1]).value == 1
    assert field.validate_or_error(None).value is None
    assert field.validate_or_error(float("nan")).value is None
    assert field.validate_or_error(float("+inf")).value is None

# Generated at 2022-06-22 05:48:59.403143
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    try:
        assert Field().validate_or_error('11223344') == "11223344"
    except Exception as e:
        msg = e
        assert msg == NotImplementedError()  # pragma: no cover


# Generated at 2022-06-22 05:49:01.662532
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    assert f.validate(0) == 0

# Generated at 2022-06-22 05:49:03.858649
# Unit test for method validate of class Number
def test_Number_validate():
    number=Number()
    assert number.validate(0)==0
    assert number.validate(1)==1

# Generated at 2022-06-22 05:49:05.140739
# Unit test for constructor of class Integer
def test_Integer():
    integer = Integer()
    assert integer.numeric_type == int


# Generated at 2022-06-22 05:49:08.028669
# Unit test for method validate of class Field
def test_Field_validate():
    # Create an instance of class Field
    # test_object = Field(title="", description="", allow_null=True)
    # This will fail as this method has not been defined yet
    assert False



# Generated at 2022-06-22 05:49:19.795921
# Unit test for constructor of class Array
def test_Array():
    import json
    import pprint
    #Data
    data = {
        'title': 'json schema',
        'type': 'object',
        'properties': {
            'name': {
                'type': 'string'
            },
            'url': {
                'type': 'string'
            },
            'keywords': {
                'type': 'array',
                'additionalItems': False,
                'items': [
                    {
                        'type': 'string'
                    },
                    {
                        'type': 'string'
                    }
                ]
            }
        },
        'required': [
            'name',
            'url',
            'keywords'
        ]
    }

    #No error

# Generated at 2022-06-22 05:49:27.537677
# Unit test for constructor of class Array
def test_Array():
    items=Field()
    min_items=0
    max_items=1000
    additional_items=True
    unique_items=False
    x=Array(items=items,min_items=min_items,max_items=max_items,additional_items=additional_items,unique_items=unique_items)
    assert (x.items==items)
    assert (x.min_items==min_items)
    assert (x.max_items==max_items)
    assert (x.additional_items==additional_items)
    assert (x.unique_items==unique_items)


# Generated at 2022-06-22 05:49:32.399979
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    from typesystem import Schema
    from typesystem import fields

    class MySchema(Schema):
        name = fields.String(max_length=3, min_length=3)

    schema = MySchema()
    assert schema['name'].get_error_text("invalid") == "must be a string"
    assert schema['name'].get_error_text("invalid_max_length") == "Ensure this field has no more than 3 characters."

# Generated at 2022-06-22 05:49:41.916047
# Unit test for method serialize of class String
def test_String_serialize():
    # Configure data for testcase
    test_String = String()
    testString_obj = '2020-01-05T11:40:48Z'
    testString_obj_expected = '2020-01-05T11:40:48Z'
    # Execute method under test
    testString_return_val = test_String.serialize(testString_obj)
    # Verify expected results
    assert testString_return_val == testString_obj_expected
    return True

# Generated at 2022-06-22 05:50:05.366850
# Unit test for constructor of class Float
def test_Float():
    f1 = Float()
    assert f1.minimum == None
    assert f1.maximum == None
    assert f1.exclu == None
    assert f1.exclu == None
    assert f1.multiple_of == None

# Test validate() method

# Generated at 2022-06-22 05:50:15.694357
# Unit test for method validate of class Choice
def test_Choice_validate():
    from datetime import datetime
    from datetime import timedelta

    # valid value
    choices = [
        ("2020-09-01 13:00:00", "A"),
        ("2020-09-01 15:00:00", "B"),
        ("2020-09-01", "C"),
    ]

    field = Choice(choices=choices)
        
    value = field.validate('2020-09-01')
    assert value == '2020-09-01'

    # allow_null == True
    field = Choice(choices=choices, allow_null=True)
        
    value = field.validate(None)
    assert value is None

    # allow_null == False, value == None
    field = Choice(choices=choices, allow_null=False)
    import pytest

# Generated at 2022-06-22 05:50:27.265302
# Unit test for method validate of class Field
def test_Field_validate():
    from typesystem import String, Number

    class MyField(Field):
        def validate(self, value, *, strict=False):
            return value + 1

    class MyMeta:
        def validate(self, value, *, strict=True):
            return value % 2 == 0

    class MyString(String):
        def validate(self, value, *, strict=False):
            if len(value) > self.max_length:
                raise ValidationError("value is too long")
            return value

    class MyNumber(Number):
        def validate(self, value, *, strict=False):
            if value < 0:
                raise ValidationError("value is too small")
            return value
    
    assert MyField().validate(10, strict=True) == 11
    assert MyMeta().validate(12, strict=True)

# Generated at 2022-06-22 05:50:30.792384
# Unit test for constructor of class Time
def test_Time():
    try:
        Time()
    except Exception as e:
        print("constructor of class Time throw exception:",e)



# Generated at 2022-06-22 05:50:36.177976
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices = ["hello", "world"])
    assert len(c.choices) == 2
    assert c.choices[0] == ("hello", "hello")
    assert c.choices[1] == ("world", "world")
    print("Success!")

test_Choice()



# Generated at 2022-06-22 05:50:37.785724
# Unit test for constructor of class Number
def test_Number():
    value = Number(minimum = 1)
    assert value.minimum == 1



# Generated at 2022-06-22 05:50:41.229090
# Unit test for constructor of class Integer
def test_Integer():
    test_field = Integer()
    assert test_field.numeric_type == int
    assert test_field.validate(10) == 10
    assert test_field.validation_error("type").code == "type"


# Generated at 2022-06-22 05:50:48.384557
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field()
    assert f.validate_or_error(1, strict=False).value == 1
    assert f.validate_or_error(1, strict=False).error is None
    assert f.validate_or_error(1, strict=False).is_valid == True
    assert f.validate_or_error(1, strict=True).value == 1
    assert f.validate_or_error(1, strict=True).error is None
    assert f.validate_or_error(1, strict=True).is_valid == True

# Generated at 2022-06-22 05:51:00.263631
# Unit test for constructor of class Decimal
def test_Decimal():
    from typesystem.number import Decimal
    from typesystem.validators import ValidationError
    from decimal import Decimal as Decimal_2
    assert Decimal(maximum=5, exclusive_maximum=5)
    assert Decimal(maximum=5, exclusive_maximum=6)
    assert Decimal(maximum=5, exclusive_maximum=6, precision="1")
    assert Decimal(maximum=5, exclusive_maximum=6, precision="0.1")
    assert Decimal(maximum=5, exclusive_maximum=6, precision="0.01")
    assert Decimal(maximum=5, exclusive_maximum=6, precision="0.001")
    assert Decimal(maximum=5, exclusive_maximum=6, precision="0.0001")
    assert Decimal(maximum=5, exclusive_maximum=6, precision="0.00001")

# Generated at 2022-06-22 05:51:02.681539
# Unit test for method serialize of class String
def test_String_serialize():
    test_object=String()
    test_object.format="date"
    if(test_object.serialize("Y-m-d")=="Y-m-d"):
        print("Pass")
    else:
        print("Fail")
    if(test_object.serialize("1997-09-28")=="28/09/1997"):
        print("Pass")
    else:
        print("Fail")


# Unit testing for method validate_or_error of class String

# Generated at 2022-06-22 05:51:25.293910
# Unit test for constructor of class Text
def test_Text():
    field = Text()
    assert field.format == "text"



# Generated at 2022-06-22 05:51:29.038708
# Unit test for method serialize of class Field
def test_Field_serialize():
    from typesystem.base import String
    s=String()
    obj='prueba'
    assert s.serialize(obj)=='prueba'
    assert s.serialize(None)=='prueba'

# Generated at 2022-06-22 05:51:39.161359
# Unit test for method validate of class Array
def test_Array_validate():
    # Test scheme: instance of class Array
    items = ListField(Field)
    additional_items = True
    min_items = None
    max_items = None
    unique_items = False
    allow_null = True
    default_value = None
    field = Array(items, additional_items, min_items, max_items, unique_items, allow_null, default_value)
    
    # Test scheme: value
    value = []
    field.validate(value)

    # Test scheme: value, strict
    value_strict = []
    field.validate(value_strict, strict=True)


# Generated at 2022-06-22 05:51:48.341810
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()

    assert d.serialize(None) == None
    assert d.serialize(1) == 1.0
    assert d.serialize(2.2) == 2.2
    assert d.serialize(decimal.Decimal(1)) == 1.0
    assert d.serialize(decimal.Decimal(1.1)) == 1.1
    assert d.serialize(True) == None
    assert d.serialize(False) == None
    assert d.serialize('1.1') == None
    assert d.serialize([1,2,'3']) == None
    assert d.serialize({"a":1}) == None

test_Decimal_serialize()


# Generated at 2022-06-22 05:51:59.552318
# Unit test for method validate of class Object
def test_Object_validate():
    
    print("\n")
    print("Testing class Object")
    print("Testing method validate")
    
    # Test case 1:
    test_object = Object(properties = {"test": Integer()})
    test_value = {"test": 1}
    test_strict = False
    test_result = test_object.validate(test_value, strict = test_strict)
    test_expected = {"test": 1}
    assert test_result == test_expected
    print("Test case 1 passed")
    
    # Test case 2:
    test_object = Object(properties = {"test": Integer()})
    test_value = "1"
    test_strict = False

# Generated at 2022-06-22 05:52:03.792709
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field(description='Test')
    assert field.get_error_text('max_length') == 'Must have no more than {max_length} characters.'



# Generated at 2022-06-22 05:52:05.754583
# Unit test for constructor of class Date
def test_Date():
    d1 = Date()
    d2 = Date(format='date')
    assert d1.format == d2.format == 'date'


# Generated at 2022-06-22 05:52:08.690207
# Unit test for constructor of class Array
def test_Array():
    with pytest.raises(AssertionError):
        Array(items=None, additional_items=False, min_items=None, max_items=None, unique_items=False, allow_null=True)


# Generated at 2022-06-22 05:52:18.300099
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
	"""This method tests for error message returned for different error codes"""
	t_field = Field(title = "", description = "")
	t_field.errors = {
		"invalid": "string {description}",
		"max_digits": "digits {description}",
		"min_digits": "digits {description}"
	}
	assert t_field.get_error_text("invalid") == "string "
	assert t_field.get_error_text("max_digits") == "digits "
	assert t_field.get_error_text("min_digits") == "digits "

# Generated at 2022-06-22 05:52:29.353687
# Unit test for constructor of class String
def test_String():
    print('\n')
    print('**************************************************************')
    print('Test No. 1')
    print('Testing the constructor of class String, with only the compulsory arguments title, description:')
    s = String(title = 'String', description = 'This is a String value')
    assert s.title == 'String'
    assert s.description == 'This is a String value'
    assert s.allow_null == False
    assert s.allow_blank == False
    assert s.trim_whitespace == True
    assert s.max_length == None
    assert s.min_length == None
    assert s.pattern == None
    assert s.format == None
    print('Passed!')

    print('\n')
    print('Test No. 2')

# Generated at 2022-06-22 05:52:44.818027
# Unit test for method serialize of class Array
def test_Array_serialize():
    arrField = Array()
    testObj = [1,2,3]
    ans = arrField.serialize(testObj)
    assert(testObj == ans)


# Generated at 2022-06-22 05:52:51.609416
# Unit test for method validate of class Choice
def test_Choice_validate():
    obj = Choice(choices=['a', 'b'])
    assert obj.validate('a') == 'a'
    assert obj.validate('b') == 'b'
    with pytest.raises(ValidationError) as error:
        obj.validate(5)
    assert str(error.value) == 'Must be a string.'
    assert error.value.code == 'type'

# Generated at 2022-06-22 05:53:02.729256
# Unit test for constructor of class Choice
def test_Choice():
    # dictionary with one element
    assert str(Eq('a')) == "Eq({'a': ['a']})"
    assert str(Eq({'a': ['a']})) == "Eq({'a': ['a']})"
    assert str(Eq([])) == "Eq({})"
    assert str(Eq(['a'])) == "Eq({'a': ['a']})"
    # dictionary with more than one element
    assert str(Eq(['a', 'b'])) == "Eq({'a': ['a'], 'b': ['b']})"
    assert Eq(['a', 'b']).keys() == Eq(['a', 'b']).difference()

    # dictionary with one element

# Generated at 2022-06-22 05:53:04.516576
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text("code") == "code"


# Generated at 2022-06-22 05:53:09.557658
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    d = Decimal()
    assert d.serialize(None)==None
    assert d.serialize(12.5)==12.5
    assert d.serialize('12.5')==12.5
# End of unit test for method serialize of class Decimal



# Generated at 2022-06-22 05:53:11.938108
# Unit test for constructor of class Float
def test_Float():
    f = Float(title="test")
    assert f.title == "test"
    assert f.numeric_type == float

# Generated at 2022-06-22 05:53:20.088819
# Unit test for method validate of class Any
def test_Any_validate():
    class TestAny(unittest.TestCase):
        def test_validate(self):
            # Test for valid input
            field = Any()
            self.assertEqual(field.validate(value = 1), 1)
            # Test for invalid input
            value = None
            field = Any(allow_null = False)
            with self.assertRaises(ValidationError):
                field.validate(value = None)
    test = TestAny()
    test.test_validate()
test_Any_validate()



# Generated at 2022-06-22 05:53:30.054305
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(1, strict=True) == 1
    assert Number().validate(123, strict=True) == 123
    assert Number().validate(-123, strict=True) == -123
    assert Number().validate(-123.456, strict=True) == -123.456
    assert Number().validate('123', strict=True) == 123
    assert Number().validate('-123', strict=True) == -123
    assert Number().validate('-123.456', strict=True) == -123.456
    assert Number().validate(1.0, strict=True) == 1.0
    assert Number().validate('1.0', strict=True) == 1.0
    assert Number().validate('a', strict=True) == ValueError
    
    
    
    

# Generated at 2022-06-22 05:53:31.512116
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(1) is 1

# Generated at 2022-06-22 05:53:43.222992
# Unit test for method validate of class Object
def test_Object_validate():
    print('-'*70)
    print('-'*70)

    print('Checking case when value is None and allow_null is True:')
    obj = Object(allow_null=True)
    assert obj.validate(None) == None

    print('Checking case when value is None and allow_null is False:')
    obj = Object(allow_null=False)
    with pytest.raises(ValidationError):
        obj.validate(None)

    print('Checking case when value is not None and allow_null is True:')
    obj = Object(allow_null=True)
    assert obj.validate('string') == 'string'

    print('Checking case when value is not None and allow_null is False:')
    obj = Object(allow_null=False)
    assert obj.validate('string')

# Generated at 2022-06-22 05:53:55.210568
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    f = Field(allow_null = True)
    assert f.validate_or_error('fds',strict = True) == 'fds'

test_Field_validate_or_error()

# Generated at 2022-06-22 05:53:59.228299
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=[('a','b')]).choices == [('a','b')]
    assert Choice(choices=['a']).choices == [('a','a')]
    


# Generated at 2022-06-22 05:54:01.672380
# Unit test for constructor of class Decimal
def test_Decimal():
    obj = Decimal()
    assert isinstance(obj, Decimal)



# Generated at 2022-06-22 05:54:03.126778
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field().get_default_value() == None


# Generated at 2022-06-22 05:54:05.438614
# Unit test for method validate of class Any
def test_Any_validate():
    any = Any()
    value = 'any_value'
    result = any.validate(value, strict=False)
    assert result == value


# Generated at 2022-06-22 05:54:07.870363
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    assert field._creation_counter == 0
    assert field.has_default() == False
    assert field.get_default_value() == None

# Generated at 2022-06-22 05:54:15.807333
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem.field import Field
    from typesystem.integer import Integer
    from typesystem.string import String
    from typesystem.union import Union
    ty = Integer(maximum=10) | String(max_length=4)
    assert isinstance(ty, Union)
    assert isinstance(ty.any_of[0], Integer)
    assert ty.any_of[0].maximum == 10
    assert isinstance(ty.any_of[1], String)
    assert ty.any_of[1].max_length == 4
#


# Generated at 2022-06-22 05:54:24.542829
# Unit test for constructor of class Time
def test_Time():
    from jsonschema.exceptions import ValidationError
    from jsonschema import validate
    import datetime
    try:
        Time()
    except Exception as e:
        # TODO: Add assert here to ensure this is a ValidationError
        assert isinstance(e, ValidationError)
        assert e.code == "type"
    try:
        Time(allow_null=True)
    except Exception as e:
        # TODO: Add assert here to ensure this is a ValidationError
        assert isinstance(e, ValidationError)
        assert e.code == "type"
    try:
        Time(allow_null=True, default="09:23:33")
    except Exception as e:
        # TODO: Add assert here to ensure this is a ValidationError
        assert isinstance(e, ValidationError)

# Generated at 2022-06-22 05:54:33.517900
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Create test field
    class TestField(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None and strict:
                raise self.validation_error(code="null")
            return value
    # Has default value
    f = TestField(title="A test field", default=42)
    assert f.get_default_value() == 42
    # Does not have default value
    f = TestField(title="A test field")
    assert f.get_default_value() is None

# Generated at 2022-06-22 05:54:34.095190
# Unit test for constructor of class Time
def test_Time():
    Time()



# Generated at 2022-06-22 05:54:59.444352
# Unit test for constructor of class Decimal
def test_Decimal():
    Decimal_obj = Decimal()
    assert Decimal_obj.numeric_type == decimal.Decimal


# Generated at 2022-06-22 05:55:01.096612
# Unit test for constructor of class Text
def test_Text():
    obj = Text()
    assert obj.format == "text"



# Generated at 2022-06-22 05:55:01.942343
# Unit test for method __or__ of class Field
def test_Field___or__():
    Field(title="field 1") | Field(title="field 2")

# Generated at 2022-06-22 05:55:07.972274
# Unit test for constructor of class Number
def test_Number():
    num = Number(title="Title", description="Description")
    assert num.title == "Title"
    assert num.description == "Description"
    assert num.allow_null == False
    assert num.minimum == None
    assert num.maximum == None
    assert num.exclusive_minimum == None
    assert num.exclusive_maximum == None
    assert num.precision == None
    assert num.multiple_of == None

    num = Number(
        title="Title",
        description="Description",
        allow_null=True,
        minimum=1,
        maximum=10,
        exclusive_minimum=3,
        exclusive_maximum=7,
        precision=1e-2,
        multiple_of=2,
    )
    assert num.title == "Title"
    assert num.description == "Description"
    assert num.allow_

# Generated at 2022-06-22 05:55:12.977092
# Unit test for constructor of class Number
def test_Number():
    test_num = Number()
    assert test_num.validate(2.2) == 2.2
    assert test_num.validate(-2.4) == -2.4 
    assert test_num.validate(0) == 0


# Generated at 2022-06-22 05:55:18.874015
# Unit test for method validate of class Array
def test_Array_validate():
    # initialize variables
    val = [1, 2, 3]
    obj = Array()
    # test method
    try:
        obj.validate(val, strict=True)
    except Exception as e:
        print("Test failed")
        print(e)
        exit(1)
    else:
        print("Test passed")
test_Array_validate()


# Generated at 2022-06-22 05:55:21.426375
# Unit test for constructor of class Date
def test_Date():
    "Unit test for constructor of class Date"
    assert Date(name="Foo").name == "Foo"


# Generated at 2022-06-22 05:55:24.004777
# Unit test for constructor of class DateTime
def test_DateTime():
    field = DateTime()
    assert field.format == "datetime"


# Generated at 2022-06-22 05:55:33.182043
# Unit test for method validate of class Number
def test_Number_validate():
    # Testing Number with null value
    number = Number(allow_null=True)
    try:
        number.validate(None, strict=False)
    except ValidationError:
        assert False
    try:
        number.validate(None, strict=True)
    except ValidationError:
        assert False

    # Testing Number with wrong type value
    try:
        number.validate("A", strict=False)
        assert False
    except ValidationError:
        assert True
    try:
        number.validate("A", strict=True)
        assert False
    except ValidationError:
        assert True

    # Testing Number with wrong type value 2
    try:
        number.validate(True, strict=False)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-22 05:55:41.169956
# Unit test for method validate of class Array
def test_Array_validate():
    # unit test for method validate of class Array
    import jsonschema
    from datetime import datetime
    from .any import Any
    from .boolean import Boolean
    from .color import Color
    from .const import Const
    from .divisibleby import DivisibleBy
    from .enum import Enum
    from .final import Final
    from .float_ import Float
    from .integer import Integer
    from .number import Number
    from .object import Object
    from .string import String

    class DummySchema(Final):
        class Options:
            fields = {"name": String(min_length=2, max_length=20)}
        name:str
        age:int
        is_alive:bool
        model:typing.Optional[str]
        scores:typing.List[int]