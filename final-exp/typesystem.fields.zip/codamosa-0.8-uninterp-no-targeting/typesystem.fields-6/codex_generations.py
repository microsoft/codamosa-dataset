

# Generated at 2022-06-22 05:47:29.390485
# Unit test for constructor of class Field
def test_Field():
    a=Field()



# Generated at 2022-06-22 05:47:41.405067
# Unit test for method validate of class Array
def test_Array_validate():
    f = Array()
    assert f.validate(None) == None
    assert f.validate(True) == True
    assert f.validate(False) == False
    assert f.validate(3.4) == 3.4
    assert f.validate(2) == 2
    assert f.validate(2) == 2
    assert f.validate(1.0) == 1.0
    assert f.validate("") == ""
    assert f.validate("2") == "2"
    assert f.validate("abc") == "abc"
    assert f.validate("abc") == "abc"
    try:
        f.validate([])
    except ValidationError as ve:
        assert ve.messages()[0].text == "Must not be empty."

# Generated at 2022-06-22 05:47:45.638979
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal(minimum=1, maximum=100, exclusive_minimum=1, exclusive_maximum=100, precision="0.000001").minimum == 1
    assert Decimal(minimum=1, maximum=100, exclusive_minimum=1, exclusive_maximum=100, precision="0.000001").maximum == 100
    assert Decimal(minimum=1, maximum=100, exclusive_minimum=1, exclusive_maximum=100, precision="0.000001").exclusive_minimum == 1
    assert Decimal(minimum=1, maximum=100, exclusive_minimum=1, exclusive_maximum=100, precision="0.000001").exclusive_maximum == 100
    assert Decimal(minimum=1, maximum=100, exclusive_minimum=1, exclusive_maximum=100, precision="0.000001").precision == "0.000001"


# Generated at 2022-06-22 05:47:48.144519
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize('this is a test') == 'this is a test'


# Generated at 2022-06-22 05:47:58.077981
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_field=Boolean()
    boolean_field.allow_null=True
    assert boolean_field.validate('1') == True
    assert boolean_field.validate('true') == True
    assert boolean_field.validate('1',strict=True) == True
    assert boolean_field.validate('true',strict=True) == True
    assert boolean_field.validate(False) == False
    assert boolean_field.validate(None) == None
    assert boolean_field.validate('',strict=True) == None
    assert boolean_field.validate('None',strict=True) == None
    assert boolean_field.validate('null') == None
    assert boolean_field.validate(None,strict=True) == None
    assert boolean_field.validate('',strict=True)

# Generated at 2022-06-22 05:47:59.489737
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert Field().validate_or_error(1).value == 1

# Generated at 2022-06-22 05:48:07.185782
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(1) == 1
    assert Any().validate(True) == True
    assert Any().validate(1.1) == 1.1
    assert Any().validate("dummy") == "dummy"
    assert Any().validate(None) == None
    assert Any().validate({"key":"dummy"}) == {"key":"dummy"}
    assert Any().validate([1,2,3]) == [1,2,3]
    

test_Any_validate()



# Generated at 2022-06-22 05:48:14.682205
# Unit test for constructor of class Float
def test_Float():
    FieldError = FieldValidationError
    f = Float(minimum=2.5, maximum=5.5, multiple_of=1.5)
    assert f.minimum == 2.5
    assert f.maximum == 5.5
    assert f.multiple_of == 1.5
    with pytest.raises(FieldError):
        f.validate(1.1)
    with pytest.raises(FieldError):
        f.validate(1.6)
    with pytest.raises(FieldError):
        f.validate(6.0)
    assert f.validate(3.0) == 3.0
    assert f.validate(4.5) == 4.5
#========================================================



# Generated at 2022-06-22 05:48:16.312734
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    string.validate(None)



# Generated at 2022-06-22 05:48:24.611926
# Unit test for method validate of class Union
def test_Union_validate():
    import json

    any_of = [
        Object({
            "id": Integer(minimum=1, exclusiveMaximum=1000),
            "name": String(min_length=1, max_length=10)
        })
    ]

    # Negative test case: returns an error if the value is not in the union
    assert Union(any_of=any_of).validate({"id": 1, "name": "user"}) == {"id": 1, "name": "user"}
    with pytest.raises(ValidationError):
        Union(any_of=any_of).validate({"id": 1, "name": "u"})



# Generated at 2022-06-22 05:49:13.535899
# Unit test for constructor of class Boolean
def test_Boolean():
    # Test 1
    test_case = Boolean(allow_null=True)
    try:
        test_case.validate(None)
        assert True
    except:
        assert False

    # Test 2
    try:
        test_case.validate(None, strict=True)
        assert False
    except:
        assert True

    # Test 3
    try:
        test_case.validate(1)
        assert True
    except:
        assert False

    # Test 4
    try:
        test_case.validate("true")
        assert True
    except:
        assert False

    # Test 5
    try:
        test_case.validate("false")
        assert False
    except:
        assert True

    # Test 6

# Generated at 2022-06-22 05:49:18.976521
# Unit test for constructor of class Date
def test_Date():
    print("Unit test for Date")
    inst = Date()
    assert inst.format == "date"
    assert inst.allow_null is True
    assert inst.default_value is None
    assert inst.errors == {"required": "This field is required."}
    print("passed")
    print()

# Test Date
test_Date()


# Generated at 2022-06-22 05:49:23.975099
# Unit test for constructor of class Date
def test_Date():
    control_field = String(format="date")
    d1 = Date()
    assert d1.format == control_field.format
    d2 = Date(title="Date")
    assert d2.title == "Date"
    assert d2.format == control_field.format
# End of unit test



# Generated at 2022-06-22 05:49:35.669565
# Unit test for method serialize of class String
def test_String_serialize():
    myString= String(format="uuid")
    # If obj is None and the current field allow null -> return None
    assert myString.serialize(None) == None
    # If self.format in FORMATS -> return result of string.serialize(obj)
    assert myString.serialize(8) == '8'
    assert myString.serialize('8') == '8'
    assert myString.serialize('8.8.8.8.8') == '8.8.8.8.8'
    # If the format is uuid -> return the uuid in string format
    assert myString.serialize(uuid.uuid4()) == str(uuid.uuid4())
    # If the format is datetime -> return the date time in string format
    assert myString.serialize(datetime.datetime.now())

# Generated at 2022-06-22 05:49:41.488900
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean(allow_null=True)
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    
test_Boolean_validate()


# Generated at 2022-06-22 05:49:49.587001
# Unit test for method validate of class Union
def test_Union_validate():
    # Test case 1:
    def test_case_1():
        class_1 = Union([Number(),Integer()])
        value_1 = 5
        result_1 = class_1.validate(value_1)
        assert type(result_1) == int
        assert result_1 == 5

    # Test case 2:
    def test_case_2():
        class_1 = Union([Number(),String()])
        value_1 = 5
        result_1 = class_1.validate(value_1)
        assert type(result_1) == int
        assert result_1 == 5

    # Test case 3:
    def test_case_3():
        class_1 = Union([Number(),Integer()])
        value_1 = 5.5
        result_1 = class_1.validate(value_1)


# Generated at 2022-06-22 05:49:51.860735
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field(title="title")
    error = field.validation_error("error")
    assert error.text == ""



# Generated at 2022-06-22 05:49:57.080163
# Unit test for method serialize of class Array
def test_Array_serialize():
    with pytest.raises(Exception):
        a = Array()
        a.serialize([1,'bar'])
    with pytest.raises(Exception):
        a = Array(items=String())
        a.serialize([1,'bar'])
    with pytest.raises(Exception):
        a = Array(items=[Integer(),String()])
        a.serialize([1,'bar',3])


# Generated at 2022-06-22 05:49:57.628655
# Unit test for constructor of class Integer
def test_Integer():
	assert Integer.numeric_type == int


# Generated at 2022-06-22 05:50:02.382257
# Unit test for method validate of class Choice
def test_Choice_validate():
    import doctest
    doctest.testmod(verbose=True)

Choice.validate(Choice, "choice1", strict=False)
##
Choice.validate(Choice, "choice3", strict=False)

##
test_Choice_validate()



# Generated at 2022-06-22 05:50:23.984437
# Unit test for constructor of class Field
def test_Field():
    f = Field(title='T1', description="A field", default=None, allow_null=False)
    assert type(f) == Field


# Generated at 2022-06-22 05:50:35.557962
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolean_field = Boolean() 
    assert boolean_field.validate(True)
    assert boolean_field.validate(False)
    assert boolean_field.validate(None) == None
    assert boolean_field.validate("true")
    assert boolean_field.validate("false")
    assert boolean_field.validate("on")
    assert boolean_field.validate("off")
    assert boolean_field.validate("1")
    assert boolean_field.validate("0")
    assert boolean_field.validate("") == False
    assert boolean_field.validate(1)
    assert boolean_field.validate(0)
    assert boolean_field.validate(8) == None
    assert boolean_field.validate(None) == None
    assert boolean_field.validate([]) == None

# Generated at 2022-06-22 05:50:36.603482
# Unit test for constructor of class DateTime
def test_DateTime():
    date_time = DateTime()
    assert date_time is not None


# Generated at 2022-06-22 05:50:38.694104
# Unit test for constructor of class Time
def test_Time():
    try:
        time = Time()
        time  # dummy to avoid pyflakes warning about unused variable
    except FieldError:
        pytest.fail("Test Failed")



# Generated at 2022-06-22 05:50:44.719058
# Unit test for method validate of class Const
def test_Const_validate():
    obj = Const(const=1)
    # Tests that a value equal to the const results in no error 
    assert obj.validate(1) == 1
    try:
        # Tests that a value unequal to the const results in a ValidationError
        obj.validate(2)
        assert False, "Didn't raise ValidationError"
    except ValidationError as err:
        assert err.messages()[0].code == "const"
    
    

# Generated at 2022-06-22 05:50:56.385330
# Unit test for constructor of class Boolean
def test_Boolean():
    # Case 1: value is True
    test_value = True
    obj = Boolean(value=test_value)
    assert obj.validate(test_value) is True

    # Case 2: value is False
    test_value = False
    obj = Boolean(value=test_value)
    assert obj.validate(test_value) is False

    # Case 3: value is None, allow_null is True
    test_value = None
    obj = Boolean(value=test_value, allow_null=True)
    assert obj.validate(test_value) is None

    # Case 4: value is None, allow_null is False
    test_value = None
    obj = Boolean(value=test_value, allow_null=False)

# Generated at 2022-06-22 05:51:07.776881
# Unit test for method validate of class Const
def test_Const_validate():
    # const = String
    field = Const(const = "test", name = "test")
    value = "test"
    assert field.validate(value) == value

    # const = Number
    field = Const(const = 123, name = "test")
    value = 123
    assert field.validate(value) == value

    # const = Boolean
    field = Const(const = True, name = "test")
    value = True
    assert field.validate(value) == value

    # const = None
    field = Const(const = None, name ="test")
    value = None
    assert field.validate(value) == value

    # const <> value
    field = Const(const = None, name = "test")
    value = "test"
    assert field.validate(value) == value


# Generated at 2022-06-22 05:51:15.529722
# Unit test for method validate of class Choice
def test_Choice_validate():
    Choice(choices=["A", "B"]).validate("A")
    assert_raises_error(ValidationError, Choice(choices=["A", "B"]).validate, "C")
    Choice(choices=[("A", "Apple"), ("B", "Banana")]).validate("A")
    assert_raises_error(ValidationError, Choice(choices=[("A", "Apple"), ("B", "Banana")]).validate, "C")
    Choice(choices=[(1, "Apple"), (2, "Banana")]).validate(1)
    assert_raises_error(ValidationError, Choice(choices=[(1, "Apple"), (2, "Banana")]).validate, "C")
    Choice(choices=[(1, "Apple"), ("2", "Banana")]).valid

# Generated at 2022-06-22 05:51:22.432053
# Unit test for constructor of class Union
def test_Union():
    s = String()
    l = Array(String())
    u = Union([s, l])
    assert u.null == s.null
    assert u.min_length == s.min_length
    assert u.max_length == s.max_length
    assert u.regex == s.regex
    assert u.pattern == s.pattern
    assert u.title == s.title
    assert u.description == s.description
    assert u.default == s.default
    assert u.allow_null == s.allow_null
    assert u.examples == s.examples
    assert u.allow_empty == s.allow_empty
    assert u.format == s.format
    assert u.enum == s.enum
    assert u.any_of == [s, l]
    assert u.not_ == s.not_

# Generated at 2022-06-22 05:51:23.604758
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice()
    assert c.validate("",strict=True) == "null"
    assert c.validate("",strict=False) == None


# Generated at 2022-06-22 05:51:45.085930
# Unit test for method validate of class Number

# Generated at 2022-06-22 05:51:46.397736
# Unit test for constructor of class Integer
def test_Integer():
    i = Integer()
    assert i.numeric_type == int


# Generated at 2022-06-22 05:51:50.715043
# Unit test for constructor of class Float
def test_Float():
    with pytest.raises(AssertionError):
        f = Float(
            minimum=(10,),
            maximum=(10,),
            exclusive_minimum=(10,),
            exclusive_maximum=(10,),
            multiple_of=(10,),
        )



# Generated at 2022-06-22 05:51:53.745058
# Unit test for method serialize of class Array
def test_Array_serialize():
    
    some_list = [1, 2]
    some_array = Array(items= [
        Int(min_value=0, max_value=9),
        Int(min_value=0, max_value=9),
    ])
    expected_result = [1, 2]
    actual_result = some_array.serialize(some_list)
    assert actual_result == expected_result



# Generated at 2022-06-22 05:51:56.273153
# Unit test for constructor of class Date
def test_Date():
    assert Date().serialize('2020-01-01') == '2020-01-01'
    with pytest.raises(ValidationError):
        Date().serialize(None)
    with pytest.raises(ValidationError):
        Date().serialize('')
    with pytest.raises(ValidationError):
        Date().serialize('2020-01-01-01')



# Generated at 2022-06-22 05:52:01.162563
# Unit test for method validate of class String
def test_String_validate():
    obj = String(title='', description='', default=NO_DEFAULT, allow_null=False)
    result = obj.validate('s')
    assert(result == 's')
    #validate_or_error
    result = obj.validate_or_error('s').value
    assert(result == 's')

# Generated at 2022-06-22 05:52:05.682202
# Unit test for constructor of class Time
def test_Time():
    """Test constructor of class Time."""
    try:
        assert Time() is not None
    except:
        raise AssertionError("The constructor of class Time cannot be called.")



# Generated at 2022-06-22 05:52:15.769533
# Unit test for constructor of class Choice
def test_Choice():
    a = Choice()
    assert type(a) == Choice
    assert a.choices == []
    assert a.allow_null == True
    assert a.allow_blank == False
    assert a.default == None
    assert a.allow_empty == True
    assert a.strict == False

    b = Choice(choices = [("1", "2"), ("2", "2")])
    assert type(b) == Choice
    assert b.choices == [("1", "2"), ("2", "2")]
    assert b.allow_null == True
    assert b.allow_blank == False
    assert b.default == None
    assert b.allow_empty == True
    assert b.strict == False



# Generated at 2022-06-22 05:52:17.873083
# Unit test for method validate of class String
def test_String_validate():
    field = String()
    result = field.validate(value = "Daffy")
    assert result == "Daffy"


# Generated at 2022-06-22 05:52:22.957288
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field(description = 'This is a field')
    error_code = 'required'
    if 'This is a field is a required field' == field.get_error_text(error_code):
        print("test_Field_get_error_text done")
    else:
        print("test_Field_get_error_text failed")

# Generated at 2022-06-22 05:52:39.643709
# Unit test for constructor of class Any
def test_Any():
    any = Any()
    if any:
        assert any.validate("1234") == "1234"
    else:
        print("test_Any() failed!")

# Generated at 2022-06-22 05:52:41.524232
# Unit test for constructor of class Time
def test_Time():
    import datetime as dt
    a =Time()
    assert a.format == 'time'


# Generated at 2022-06-22 05:52:43.977739
# Unit test for constructor of class Float
def test_Float():
    test = Float(minimum=1.0)
    assert test.minimum == 1.0


# Generated at 2022-06-22 05:52:56.463538
# Unit test for method validate of class Array
def test_Array_validate():
    from json_schema import String

    schema = Array(items=String())


# Generated at 2022-06-22 05:53:04.144758
# Unit test for method serialize of class Array
def test_Array_serialize():
    # test_Array_serialize_1
    # schema = Array(items=Integer())
    # assert schema.serialize(None) == None
    #
    # test_Array_serialize_2
    # data = [1,2,3,4]
    # schema = Array(items=Integer())
    # assert schema.serialize(data) == data
    #
    # test_Array_serialize_3
    # data = [1, 2, 3, 4]
    # schema = Array(items=String())
    # assert schema.serialize(data) == ['1', '2', '3', '4']
    pass # TODO



# Generated at 2022-06-22 05:53:07.203496
# Unit test for method validate of class String
def test_String_validate():
    string = String()
    my_cloud = 'my_cloud'
    assert string.validate(my_cloud) == my_cloud

# Generated at 2022-06-22 05:53:18.882495
# Unit test for method validate of class String
def test_String_validate():
    value = "1"
    assert String().validate(value) == "1"
    value = ""
    assert String().validate(value) == ""
    assert String(allow_blank=True).validate(value) == ""
    assert String(allow_blank=False).validate(value) == None
    value = "123"
    assert String().validate(value) == "123"
    assert String(max_length=2).validate(value) == None
    assert String(min_length=3).validate(value) == "123"
    value = "12345"
    assert String().validate(value) == "12345"
    assert String(max_length=5).validate(value) == "12345"
    assert String(max_length=3).validate(value) == None

# Generated at 2022-06-22 05:53:22.781693
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.default==NO_DEFAULT & field.allow_null==False
    assert field.title=='' & field.description==''
    assert field._creation_counter==0
    assert field is not None
    

# Generated at 2022-06-22 05:53:26.138459
# Unit test for constructor of class String
def test_String():
    field = String(max_length=10, min_length=5, format="uuid")
    assert field.max_length == 10
    assert field.min_length == 5
    assert field.format == "uuid"


# Generated at 2022-06-22 05:53:31.007395
# Unit test for constructor of class Union
def test_Union():
    # Test with valid input
    schema = Union([String(), Integer()])

    # Test with invalid input
    try:
        schema = Union([1])
    except AssertionError:
        pass
    except:
        raise Exception("Error: Test Construction method failed")


# Generated at 2022-06-22 05:55:20.852593
# Unit test for method serialize of class Array
def test_Array_serialize():
    s = Array(items = String())
    assert s.serialize(["a", "b", "c"]) == ["a", "b", "c"]



# Generated at 2022-06-22 05:55:27.220707
# Unit test for method serialize of class String
def test_String_serialize():
    class TestSchema(Schema):
        data = String(format='datetime')
        
    schema = TestSchema()

    result = schema.dump({
        "data": datetime.datetime(2020, 5, 7, 12, 34, 56),
    })
    assert result.data == "2020-05-07T12:34:56"



# Generated at 2022-06-22 05:55:30.673098
# Unit test for method validate of class Any
def test_Any_validate():
    t = Any()
    assert t.validate(1) == 1
    assert t.validate('test') == 'test'
    assert t.validate(True) == True
    assert t.validate(None) == None

# Generated at 2022-06-22 05:55:32.051090
# Unit test for constructor of class Decimal
def test_Decimal():
    print(Decimal())

test_Decimal()


# Generated at 2022-06-22 05:55:35.917359
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    class MyField(Field):
        errors = {'error1': "This is an error"}
    assert MyField().validation_error('error1').text == 'This is an error'


# Generated at 2022-06-22 05:55:46.539109
# Unit test for constructor of class Object
def test_Object():
    a = Object(properties=None, pattern_properties=None,
               additional_properties=True)
    assert a.properties == {}
    assert a.pattern_properties == {}
    assert a.additional_properties == True

    b = Object(properties={'key': bool}, pattern_properties={'pattern': 'str'},
               additional_properties=False)
    assert b.properties == {'key': bool}
    assert b.pattern_properties == {}
    assert b.additional_properties == False

    c = Object(properties={'key': bool}, pattern_properties={'pattern': 'str'},
               additional_properties={'additional': 'properties'})
    assert c.properties == {'key': bool}
    assert c.pattern_properties == {'pattern': 'str'}

# Generated at 2022-06-22 05:55:49.843803
# Unit test for method validate of class Any
def test_Any_validate():
    any_instance = Any()
    assert any_instance.validate('value', strict=False) == 'value'



# Generated at 2022-06-22 05:55:51.639377
# Unit test for constructor of class Decimal
def test_Decimal():
    try:
        Decimal()
        assert True
    except:
        assert False



# Generated at 2022-06-22 05:55:58.937545
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer(
        title="test_title",
        description="test_description",
        default="test",
        allow_null=True,
        allow_blank=True,
        trim_whitespace=True,
        max_length=None,
        min_length=None,
        pattern=None,
        format=None,
        minimum=None,
        maximum=None,
        exclusive_minimum=None,
        exclusive_maximum=None,
        precision=None,
        multiple_of=None,
    ) is not None
