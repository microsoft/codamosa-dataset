

# Generated at 2022-06-22 05:47:51.787858
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean(allow_null=True).allow_null == True
    assert Boolean(allow_blank=True).allow_blank == True
    assert Boolean(allow_blank=False).allow_blank == False
    assert Boolean(default=1).default == 1
    assert Boolean(default=False).default == False
    assert Boolean(default="a").default == "a"
    assert Boolean.validate("True", False) == True
    assert Boolean.validate(True, False) == True
    assert Boolean.validate(True, True) == True
    assert Boolean.validate("False", True) == False
    assert Boolean.validate("False", False) == False
    assert Boolean.validate("a", True) == False

# Unit tests for constructor of class Number

# Generated at 2022-06-22 05:47:52.697802
# Unit test for constructor of class Decimal
def test_Decimal():
    Decimal()
    assert True

# Generated at 2022-06-22 05:47:56.801758
# Unit test for constructor of class Field
def test_Field():
    a = Field(title="TEST TITLE", description="TEST DESCRIPTION", default=1, allow_null=False)
    assert a.title == "TEST TITLE"
    assert a.description == "TEST DESCRIPTION"
    assert a.default == 1
    assert a.allow_null == False

# Generated at 2022-06-22 05:48:07.491122
# Unit test for method validate of class Union
def test_Union_validate():
    assert Field.validate(None, None, None, None) is None
    assert Field.validate(True, None, None, None) is True
    assert Field.validate(False, None, None, None) is False
    assert Field.validate(0, None, None, None) == 0
    assert Field.validate(1, None, None, None) == 1
    assert Field.validate(0.0, None, None, None) == 0.0
    assert Field.validate(1.0, None, None, None) == 1.0
    #assert Field.validate(0.0, None, None, None) == "0"
    #assert Field.validate(1.0, None, None, None) == "1"
    assert Field.validate([], None, None, None) == []

# Generated at 2022-06-22 05:48:09.947300
# Unit test for method serialize of class String
def test_String_serialize():
    strf = String(
    title = "email",
    description = "The e-mail address of the person",
    format = "email",
    )
    if strf.serialize("haha@nus.edu.sg") == "haha@nus.edu.sg":
        print("OK")
    else:
        print("Wrong")


# Generated at 2022-06-22 05:48:15.217670
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field(title="test", description="test", default=4, allow_null=False)
    assert field.has_default() == True
    field1 = Field(title="test", description="test", default=None, allow_null=True)
    assert field1.has_default() == True


# Generated at 2022-06-22 05:48:19.466967
# Unit test for constructor of class Union
def test_Union():
    field_1 = String()
    field_2 = String()
    any_of: typing.List[Field] = [field_1, field_2]
    field_union = Union(any_of)
    assert field_union.any_of == any_of

# Generated at 2022-06-22 05:48:20.758089
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[(1, 1), (2, 2), (3, 3)])
    field.validate(1) == 1
    field.validate(2) == 2

# Generated at 2022-06-22 05:48:24.561010
# Unit test for constructor of class Float
def test_Float():
    f = Float(maximum = 123, minimum = -123, allow_null = True, exclusive_maximum = False, exclusive_minimum = False)
    print(f.maximum)
    print(f.minimum)
    print(f.allow_null)
    print(f.exclusive_maximum)
    print(f.exclusive_minimum)


# Generated at 2022-06-22 05:48:26.363190
# Unit test for constructor of class Boolean
def test_Boolean():
    x = Boolean(allow_null = True)
    assert x.allow_null == True


# Generated at 2022-06-22 05:48:45.614398
# Unit test for constructor of class Boolean
def test_Boolean():
    print('\nTest case 1: Constructor of class Boolean. Expected behavior: Allow_null: True')
    test = Boolean(allow_null=True)
    print('Result: ', test.allow_null)
    print('Pass: ', test.allow_null == True)
    
    
#Unit test for strict of method validate of class Boolean

# Generated at 2022-06-22 05:48:47.138687
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    assert Field(default=42).get_default_value() == 42


# Generated at 2022-06-22 05:48:55.460808
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    class Field1(Field):
        def validate(self, value, *, strict = False):
            return value if isinstance(value, str) else str(value)

    class Field2(Field):
        def validate(self, value, *, strict = False):
            return value if isinstance(value, int) else int(value)

    class Field3(Field):
        def validate(self, value, *, strict = False):
            return value if isinstance(value, float) else float(value)

    class Field4(Field):
        def validate(self, value, *, strict = False):
            return value if isinstance(value, bool) else bool(value)

    x = Field1()
    y = Field2()
    z = Field3()
    u = Field4()

# Generated at 2022-06-22 05:49:05.176870
# Unit test for method __or__ of class Field
def test_Field___or__():
    """Unit test for method __or__ of class Field"""

    class Person(typesystem.Schema):
        id = typesystem.Integer(minimum=1, maximum=10)
        first_name = typesystem.String()
        last_name = typesystem.String()

    pp = Person(
        {"first_name": "Erich", "id": 5, "last_name": "Kästner"},
        strict=True,
    )

    class Customer(typesystem.Schema):
        id = typesystem.Integer(format="uuid", minimum=1, maximum=10)
        first_name = typesystem.String()
        last_name = typesystem.String()


# Generated at 2022-06-22 05:49:06.511247
# Unit test for method validate of class String
def test_String_validate():
    val = String()
    assert val.validate('string') == 'string'


# Generated at 2022-06-22 05:49:08.763788
# Unit test for method validate of class Choice
def test_Choice_validate():
    field_1 = Choice(choices=[('key','value'),('key','value'),('key','value')])
    assert field_1.validate('key') == 'key'
    assert field_1.validate('bad_key') is None
    field_2 = Choice()
    assert field_2.validate('key') is None
    assert field_2.validate(None) is None


# Generated at 2022-06-22 05:49:12.175498
# Unit test for method validate of class Field
def test_Field_validate():
    f = Field()
    try:
        f.validate('invalid')
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-22 05:49:23.890230
# Unit test for constructor of class Float
def test_Float():
    test_value = 1.5

    # Test constructor with default arguments
    f = Float()
    assert f.validate(test_value) == test_value
    assert f.validate("1.5") == test_value

    # Test constructor with min = 0
    f = Float(minimum=0)
    assert f.validate(test_value) == test_value
    assert f.validate("1.5") == test_value
    
    # Test constructor with max = 2
    f = Float(maximum=2)
    assert f.validate(test_value) == test_value
    assert f.validate("1.5") == test_value

    # Test constructor with min = 0 and max = 2
    f = Float(minimum=0, maximum=2)
    assert f.validate(test_value) == test

# Generated at 2022-06-22 05:49:27.042970
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    errors = {'code':'this is a error message'}
    f = Field()
    f.errors = errors
    assert f.get_error_text('code') == 'this is a error message'


# Generated at 2022-06-22 05:49:38.935628
# Unit test for constructor of class Integer
def test_Integer():
    obj = Integer(minimum=1, maximum=5, multiple_of=5)
    assert obj.minimum == 1
    assert obj.maximum == 5
    assert obj.multiple_of == 5
    assert obj.allow_null == False
    assert obj.errors["type"] == "Must be a number."
    assert obj.errors["null"] == "May not be null."
    assert obj.errors["integer"] == "Must be an integer."
    assert obj.errors["finite"] == "Must be finite."
    assert obj.errors["minimum"] == "Must be greater than or equal to {minimum}."
    assert obj.errors["exclusive_minimum"] == "Must be greater than {exclusive_minimum}."
    assert obj.errors["maximum"] == "Must be less than or equal to {maximum}."

# Generated at 2022-06-22 05:50:00.526983
# Unit test for constructor of class DateTime
def test_DateTime():
    field = DateTime()
    assert field.format == "datetime"



# Generated at 2022-06-22 05:50:08.539090
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b=Boolean()
    assert b.validate("true") is True
    assert b.validate("false") is False
    assert b.validate("on") is True
    assert b.validate("off") is False
    assert b.validate("1") is True
    assert b.validate("0") is False
    assert b.validate("") is False
    assert b.validate(1) is True
    assert b.validate(0) is False
    assert b.validate(None) is None



# Generated at 2022-06-22 05:50:18.967672
# Unit test for constructor of class Integer
def test_Integer():
    # normal
    int_ = Integer(minimum = -10, maximum=10)
    assert int_.minimum == -10
    assert int_.maximum == 10
    assert int_.errors == {
        "type": "Must be a number.",
        "null": "May not be null.",
        "integer": "Must be an integer.",
        "finite": "Must be finite.",
        "minimum": "Must be greater than or equal to {minimum}.",
        "exclusive_minimum": "Must be greater than {exclusive_minimum}.",
        "maximum": "Must be less than or equal to {maximum}.",
        "exclusive_maximum": "Must be less than {exclusive_maximum}.",
        "multiple_of": "Must be a multiple of {multiple_of}.",
    }
    # invalid type

# Generated at 2022-06-22 05:50:20.749471
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal() is not None


# Generated at 2022-06-22 05:50:31.833838
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize(1) == 1
    assert String(format = 'date').serialize(datetime.date(2020,1,1)) == '2020-01-01'
    assert String(format = 'datetime').serialize(datetime.datetime(2020,1,1,1,1,1,1)) == '2020-01-01T01:01:01.000001'
    assert String(format = 'time').serialize(datetime.time(1,1,1,1)) == '01:01:01.000001'

# Generated at 2022-06-22 05:50:34.154673
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    obj = Decimal()
    assert obj.serialize(4.4) == 4.4



# Generated at 2022-06-22 05:50:45.086890
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Tests for method validate
    class ShortBoolean(Boolean):
        """Boolean with non-default allowed values."""
        coerce_values = {
            "yeah": True,
            "nah": False,
        }

    class NullableBoolean(Boolean):
        """Boolean with non-default null allowance."""
        allow_null = True

    class NullableBooleanWithNullValues(Boolean):
        """Boolean that allows nulls and coerces null values."""
        coerce_null_values = {"null"}

    class ShortNullableBoolean(Boolean):
        """Boolean with non-default allowed values and null allowance."""
        allow_null = True

        coerce_values = {
            "yeah": True,
            "nah": False,
        }


# Generated at 2022-06-22 05:50:49.788145
# Unit test for constructor of class Array
def test_Array():
    myArray = Array(items=Field(), additional_items=False, min_items=None,
    max_items=None, unique_items=False, required=False, allow_null=True,
    default=None)
    assert myArray.items == Field()
    assert myArray.additional_items == False
    assert myArray.min_items == None
    assert myArray.max_items == None
    assert myArray.unique_items == False


# Generated at 2022-06-22 05:50:50.369072
# Unit test for constructor of class Date
def test_Date():
    p = Date()



# Generated at 2022-06-22 05:50:53.938483
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
 
    x = Field(title = 'test', description = '123')
    x.errors = {"invalid": "Invalid value."}
    x.validation_error('invalid')


# Generated at 2022-06-22 05:51:02.836569
# Unit test for method validate of class Array
def test_Array_validate():
    string_field = String()
    number_field = Number()
    array_field = Array(items=[string_field, number_field, string_field])
    assert array_field.validate(["a", 1, "b"]) == ["a", 1.0, "b"]
    try:
        array_field.validate(["a", "b", "c", "d"])
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:51:13.408350
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any()
    assert a.validate(1) == 1
    assert a.validate(2) == 2
    assert a.validate(3) == 3
    assert a.validate(4) == 4
    assert a.validate(5) == 5
    assert a.validate(6) == 6
    assert a.validate(7) == 7
    assert a.validate(8) == 8
    assert a.validate(9) == 9
    assert a.validate(10) == 10
    assert a.validate(11) == 11
    assert a.validate(12) == 12
    assert a.validate(13) == 13
    assert a.validate(14) == 14
    assert a.validate(15) == 15
    assert a.validate(16) == 16
   

# Generated at 2022-06-22 05:51:17.288355
# Unit test for constructor of class String
def test_String():
    try:
        print("\nTesting constructor of class String")
        s = String()
    except Exception as e:
        print("Exception raised while testing constructor of class String")
        print("Exception: ", e)


# Generated at 2022-06-22 05:51:21.956993
# Unit test for method serialize of class String
def test_String_serialize():
    string = String()
    assert string.serialize(1) == 1
    datetime_format = String(format = "datetime")
    assert datetime_format.serialize(datetime.datetime.now()) == datetime.datetime.now()
    uuid_format = String(format = "uuid")
    assert uuid_format.serialize(str(uuid.uuid1())) == str(uuid.uuid1())

# Generated at 2022-06-22 05:51:23.484751
# Unit test for constructor of class Date
def test_Date():
    date=Date()
    assert date.format=="date"



# Generated at 2022-06-22 05:51:25.065930
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    assert field.serialize(None) is None


# Generated at 2022-06-22 05:51:30.024000
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_test = Decimal(title="Decimal test", minimum=1, maximum=2, multiple_of=2)
    try:
        decimal_test.validate('1')
    except:
        print("Something is wrong with the constructor of class Decimal")
    else:
        print("Test passed")

test_Decimal()



# Generated at 2022-06-22 05:51:35.632626
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    number = Decimal()
    assert number.serialize(1) == 1.0
    assert number.serialize(0) == 0.0
    assert number.serialize(None) == None
    assert number.serialize(1201.0) == 1201.0
    assert number.serialize(2e-2) == 0.02



# Generated at 2022-06-22 05:51:45.915430
# Unit test for constructor of class Object
def test_Object():
    dict = {
        "properties": None,
        "pattern_properties": None,
        "additional_properties": True,
        "property_names": None,
        "min_properties": None,
        "max_properties": None,
        "required": None,
    }
    obj = Object(dict)
    assert obj.properties == dict["properties"]
    assert obj.pattern_properties == dict["pattern_properties"]
    assert obj.additional_properties == dict["additional_properties"]
    assert obj.property_names == dict["property_names"]
    assert obj.min_properties == dict["min_properties"]
    assert obj.max_properties == dict["max_properties"]
    assert obj.required == dict["required"]


# Generated at 2022-06-22 05:51:49.592084
# Unit test for constructor of class Choice
def test_Choice():
    choices = Choice(choices = ['one', 'two', ('three', 'three')])
    assert choices.choices == [('one', 'one'), ('two', 'two'), ('three', 'three')]

# Generated at 2022-06-22 05:52:04.009769
# Unit test for method validate of class Const
def test_Const_validate():
    const_field = Const(2)
    c = const_field.validate(2)
    assert c == 2



# Generated at 2022-06-22 05:52:06.293729
# Unit test for constructor of class Any
def test_Any():
    a = Any()
    assert(str(a) == "Any()")


# Generated at 2022-06-22 05:52:07.684846
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(None) == None


# Generated at 2022-06-22 05:52:16.396468
# Unit test for method serialize of class Array
def test_Array_serialize():
    input_obj={'schema':{'type':'object','properties':{'a':{'type':'integer','title':'a','description':'a','default':0},'b':{'type':'string','title':'b','description':'b','default':'b','enum':['a','b']},'c':{'type':'array','items':{'type':'string','title':'c','description':'c','default':'c','enum':['a','b']}}}}}

# Generated at 2022-06-22 05:52:20.198989
# Unit test for method validate of class String
def test_String_validate():
    string = String(title='Test string')
    assert string.validate('Hello World') == 'Hello World'


# Generated at 2022-06-22 05:52:24.358260
# Unit test for method validate of class Choice
def test_Choice_validate():
    kwargs = {'name': 'One', 'null': True, 'default': ''}
    choices = []
    choice = Choice(**kwargs, choices=choices)
    try:
        choice.validate(None)
    except Exception as e:
        print(e)
    print('Finish the test')

test_Choice_validate()


# Generated at 2022-06-22 05:52:28.990139
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    import typesystem
    from typesystem.types import String, Number, Integer
    assert Field(title="nombre", description="nombre", default=NO_DEFAULT, allow_null=False).validate_or_error(None, strict=False).error.code == "required"


# Generated at 2022-06-22 05:52:33.473476
# Unit test for method validate of class String
def test_String_validate():
    s = String()
    try:
        s.validate(12345)
        assert False
    except:
        assert True
    try:
        s.validate(None)
        assert False
    except:
        assert True
    value = s.validate("12345")
    assert value == "12345"



# Generated at 2022-06-22 05:52:35.127833
# Unit test for constructor of class Decimal
def test_Decimal():
    f = Decimal()
    f.__init__()
    return f
# Test instance created

# Generated at 2022-06-22 05:52:47.132754
# Unit test for method validate of class Union
def test_Union_validate():
    from starlette.testclient import TestClient

    from app.schemas.todo import TaskCreate, TaskUpdate

    client = TestClient(app)
    r = client.put("/todo/1", json={"task": "test"})
    assert r.status_code == 201
    r = client.put("/todo/1", json={"task": "test2", "done": False})
    assert r.status_code == 200
    r = client.put("/todo/1", json={"task": "test3", "done": True})
    assert r.status_code == 200
    r = client.put("/todo/1", json={"task": "test4", "done": 1})
    assert r.status_code == 422

# Generated at 2022-06-22 05:53:03.929045
# Unit test for method validate of class String
def test_String_validate():
    f = String()
    value = "abcdefghijklmnopqrstuvwxyz"

    assert f.validate(value) == value

    f = String(allow_null=True)
    assert f.validate(None) is None

    f = String(allow_blank=True)
    assert f.validate("") == ""

    f = String(allow_blank=True, allow_null=True)
    assert f.validate("") == ""
    assert f.validate(None) is None

    f = String(allow_blank=True, allow_null=True, min_length=10)
    assert f.validate(None) is None
    assert f.validate("") == ""

    f = String(max_length=10)
    value = "0123456789"

    assert f

# Generated at 2022-06-22 05:53:08.763470
# Unit test for constructor of class Float
def test_Float():
    # check construction of Float
    field_object = Float(maximum=100.0)
    # check that maximum is indeed the value supplied in our constructor
    if field_object.maximum != 100.0:
        raise AssertionError("maximum is not equal to 100.0")


# Generated at 2022-06-22 05:53:17.518179
# Unit test for method validate of class Any
def test_Any_validate():
    a = Any(name="Any")

    # Test nullable
    assert a.validate(None) is None
    a.nullable = False
    try:
        a.validate(None)
    except ValidationError as e:
        assert e.messages() == [Message(code="null", text="May not be null.")]
    else:
        assert False

    # Test strict
    a.nullable = True
    a.strict = True
    assert a.validate(2.0, strict=True) == 2.0
    try:
        a.validate(2, strict=True)
    except ValidationError as e:
        assert e.messages() == [Message(code="type", text="Must be a float.")]
    else:
        assert False

    # Test no strict

# Generated at 2022-06-22 05:53:21.229984
# Unit test for method validate of class Union
def test_Union_validate():
    # Declaration of parameters which are used for method validate
   any_of: typing.List[Field] = [String(), Integer()]
   strict: bool = False
   _return: None
   
   _return = Union(any_of).validate(value=None, strict=strict)


# Generated at 2022-06-22 05:53:24.706498
# Unit test for constructor of class Decimal
def test_Decimal():
    decimal_field = Decimal(
        title="Decimal field",
        description="Decimal value",
    )
    print(decimal_field)



# Generated at 2022-06-22 05:53:35.298935
# Unit test for method validate of class Any
def test_Any_validate():
    # CONSTANTS
    method_name = "validate"
    pos_input_name = "value"
    pos_input_values = ["", 1, True, None, 1.0]
    expected_output = [1, 1, 1, None, 1.0]
    optional_input_name = "strict"
    optional_input_values = [True, False]
    expected_output_optional = [None, None]
    # METHOD
    method = getattr(Any,method_name)
    # INPUT POSITIONAL
    assert len(pos_input_values) == len(expected_output), (
    "The number of values that are given as input to the method "
    + method_name 
    + " differs from the number of expected output."
    )

# Generated at 2022-06-22 05:53:42.982859
# Unit test for method validate of class Object
def test_Object_validate():
        value = {'age': 1, 'id_name': 'John', 'month': 1, 'gender': 'M'}
        properties = {'id_name': String(minimum_length=3, max_length=20),
                      'age': Number(minimum=0, maximum=120),
                      'month':Number(minimum=1, maximum=12),
                      'gender': Choice(choices=['M','F'])}
        obj = Object(properties = properties)
        result = obj.validate(value, strict=False)
        assert(result == value)



# Generated at 2022-06-22 05:53:54.257836
# Unit test for method __or__ of class Field
def test_Field___or__():
    class MyField1(Field):
        pass
    class MyField2(Field):
        pass
    field_1a = MyField1()
    field_1b = MyField1()
    field_2a = MyField2()
    field_2b = MyField2()
    assert (field_1a | field_1b).any_of == [field_1a, field_1b]
    assert (field_2a | field_2b).any_of == [field_2a, field_2b]
    assert (field_1a | field_2a).any_of == [field_1a, field_2a]
    assert (field_1a | field_2a | field_1b).any_of == [field_1a, field_2a, field_1b]


# Generated at 2022-06-22 05:53:58.928933
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=['one', 'two', 'three'], default=None, allow_null=False, error_text={'choice': 'The choice is invalid'})
    assert field.validate(value='one') == 'one'
    with pytest.raises(ValidationError, match="The choice is invalid"):
        field.validate(value='four')



# Generated at 2022-06-22 05:54:01.298973
# Unit test for method validate of class Field
def test_Field_validate():
    assert(True)


# Generated at 2022-06-22 05:54:17.133778
# Unit test for method validate of class Union
def test_Union_validate():
    pass

# Generated at 2022-06-22 05:54:26.505451
# Unit test for constructor of class Object
def test_Object():
    # Create object without any arguments
    object_ = Object()
    assert object_.properties == {}
    assert object_.pattern_properties == {}
    assert object_.additional_properties is True
    assert object_.property_names is None
    assert object_.min_properties is None
    assert object_.max_properties is None
    assert object_.required == []

    # If properties is non null, then must be a Field
    with pytest.raises(AssertionError):
        Object(properties=5)
    
    # If pattern_properties is non null, then must be a Field
    with pytest.raises(AssertionError):
        Object(pattern_properties=5)
        
    # If additional_properties is non null, then must be a Field

# Generated at 2022-06-22 05:54:35.709762
# Unit test for constructor of class String
def test_String():
    s = String()
    assert s.format == None
    assert s.max_length == None
    assert s.pattern == None
    assert s.allow_blank == False

    s = String(max_length=10)
    assert s.format == None
    assert s.max_length == 10
    assert s.pattern == None
    assert s.allow_blank == False

    # TODO: Figure out what the type of pattern is supposed to be and test it
    s = String(max_length=10, pattern=None)
    assert s.format == None
    assert s.max_length == 10
    assert s.pattern == None
    assert s.allow_blank == False


# Generated at 2022-06-22 05:54:40.745795
# Unit test for constructor of class Const
def test_Const():
    c = Const(1)
    assert c.allow_null == False
    assert c.const == 1
    assert c.required == False
    assert c.allow_empty == True
    assert c.empty_values == []
    assert c.default == None
    assert c.default_factory == None

    c = Const("hello")
    assert c.allow_null == False
    assert c.const == "hello"
    assert c.required == False
    assert c.allow_empty == True
    assert c.empty_values == []
    assert c.default == None
    assert c.default_factory == None

    c = Const("hello", description="constant", allow_null=True, required=True, default="hello")
    assert c.allow_null == True
    assert c.const == "hello"

# Generated at 2022-06-22 05:54:45.563404
# Unit test for method serialize of class Array
def test_Array_serialize():
    class Foo(BaseModel):
        foo: Array[int]
    foo = Foo(foo=[1, 2, 3])
    assert foo.foo.serialize([1, 2, 3]) == [1, 2, 3]
    assert foo.json() == {'foo': [1, 2, 3]}



# Generated at 2022-06-22 05:54:51.937509
# Unit test for method validate of class Union
def test_Union_validate():
    u = Union([String(), Number()])
    assert u.validate("Example") == "Example"
    try:
        u.validate(1)
    except ValidationError as e:
        assert str(e.messages[0]) == "Must be a string."
    u2 = Union([String(), Number()], allow_null=True)
    assert u2.validate(None) is None
    u3 = Union([String(), Number()], allow_null=True)
    try:
        u3.validate("Example")
    except ValidationError as e:
        assert str(e.messages[0]) == "Must be a number."
    u4 = Union([String(), Number(), Boolean(allow_null=True)])
    assert u4.validate("Example") == "Example"
    assert u4.validate

# Generated at 2022-06-22 05:54:58.161964
# Unit test for method serialize of class String
def test_String_serialize():
    import datetime
    string = String(format="datetime")
    datetime_value = datetime.datetime(2017, 10, 3, 15, 20, 34, 57000)
    expected_obj = "2017-10-03T15:20:34.057Z"
    assert string.serialize(datetime_value) == expected_obj
# End unit test



# Generated at 2022-06-22 05:55:01.594663
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.__dict__ == {'default': None, 'required': False, 'allow_null': False, 'errors': {}, 'format': 'text'}


# Generated at 2022-06-22 05:55:12.979180
# Unit test for method __or__ of class Field
def test_Field___or__():
    from typesystem import TypeSystem, Schema
    from typesystem.types import String
    from typesystem.fields import List, Union
    class Book(Schema):
        title = String | List[String]
    assert isinstance(Book.title, Union)
    assert isinstance(Book.title.any_of[0], String)
    assert isinstance(Book.title.any_of[1], List)
    assert isinstance(Book.title.any_of[1].of, String)
    book_typesystem = TypeSystem(Book)
    assert book_typesystem.validate(["Harry Potter", "JK Rowling", "1997"]) == {}
    assert book_typesystem.validate({"title": ["Harry Potter", "JK Rowling", "1997"]}) == {}
    assert book_typesystem.validate(["Harry Potter"])

# Generated at 2022-06-22 05:55:16.107009
# Unit test for method serialize of class String
def test_String_serialize():
    data = String().serialize("2020-01-01")
    assert data == "2020-01-01"


# Generated at 2022-06-22 05:55:25.826119
# Unit test for constructor of class Integer
def test_Integer():
    try:
        integer = Integer()
    except Exception as e:
        assert str(e) == "non-keyword arg after keyword arg"


# Generated at 2022-06-22 05:55:27.358711
# Unit test for method has_default of class Field
def test_Field_has_default():
    field = Field()
    assert field.has_default() == False

# Generated at 2022-06-22 05:55:29.559806
# Unit test for method serialize of class String
def test_String_serialize():
  s = String(format="time")
  assert s.serialize("12:00:00") == "12:00:00"


# Generated at 2022-06-22 05:55:32.883590
# Unit test for constructor of class Object
def test_Object():
    assert Object
    assert Object.properties
    assert Object.pattern_properties
    assert Object.additional_properties
    assert Object.property_names
    assert Object.min_properties
    assert Object.max_properties
    assert Object.required
    

# Generated at 2022-06-22 05:55:36.100294
# Unit test for constructor of class Array
def test_Array():
    import pytest

    with pytest.raises(AssertionError):
        arr = Array(items=Field())
    # TODO: Add more test for class Array



# Generated at 2022-06-22 05:55:39.679656
# Unit test for method __or__ of class Field
def test_Field___or__():
    field = String() | String()
    assert isinstance(field, Union)
    assert isinstance(field.any_of[0], String)
    assert isinstance(field.any_of[1], String)



# Generated at 2022-06-22 05:55:44.250826
# Unit test for constructor of class Array
def test_Array():
    arr = Array()
    assert arr.items == None
    assert arr.additional_items == False
    assert arr.min_items == None
    assert arr.max_items == None
    assert arr.unique_items == False
    assert arr.label == None
    assert arr.help == None


# Generated at 2022-06-22 05:55:52.376197
# Unit test for constructor of class Number
def test_Number():
    aNumber = Number()
    assert aNumber is not None, "Failed to instantiate a class"
    assert aNumber.errors == {"type": "Must be a number.",
                              "null": "May not be null.",
                              "integer": "Must be an integer.",
                              "finite": "Must be finite.",
                              "minimum": "Must be greater than or equal to {minimum}.",
                              "exclusive_minimum": "Must be greater than {exclusive_minimum}.",
                              "maximum": "Must be less than or equal to {maximum}.",
                              "exclusive_maximum": "Must be less than {exclusive_maximum}.",
                              "multiple_of": "Must be a multiple of {multiple_of}."}, "Failed to instantiate the errors dictionary"
# End of unit test for constructor of class Number


# Generated at 2022-06-22 05:56:01.341756
# Unit test for method validate of class Number
def test_Number_validate():
    x = Number()
    assert(x.validate(1) == 1)
    try:
        assert(x.validate(1.2) == 1.2)
    except:
        pass
    assert(x.validate(True) == True)
    assert(x.validate(False) == False)
    assert(x.validate("1") == 1)
    assert(x.validate("-1") == -1)
    try:
        assert(x.validate("-1.2") == -1.2)
    except:
        pass
    try:
        assert(x.validate("wrong_input") == "wrong_input")
    except:
        pass

