

# Generated at 2022-06-22 05:48:32.937683
# Unit test for constructor of class Text
def test_Text():
    f = Text()
    assert f.format == "text"
    assert f.regex == None
    pattern = r"^[\w ]+$"
    f = Text(pattern=pattern)
    assert f.format == "text"
    assert f.regex == pattern
    return True


# Generated at 2022-06-22 05:48:41.229488
# Unit test for method validate of class Number
def test_Number_validate():
    assert Number().validate(10) == 10
    assert Number().validate(0) == 0
    assert Number(minimum=0).validate(10) == 10
    assert Number(minimum=0).validate(0) == 0
    assert Number(maximum=100).validate(10) == 10
    assert Number(maximum=100).validate(100) == 100
    assert Number(maximum=100).validate(50) == 50
    assert Number().validate(10.5) == 10.5
    # test for exception
    try:
        Number().validate(None)
        assert False
    except Exception:
        assert True



# Generated at 2022-06-22 05:48:49.296372
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    field.errors = {
        'required': 'Field is required',
        'min': 'Field satisfying min={min} value',
        'max': 'Field satisfying min={max} value'
    }
    code = 'min'
    field.min = 2
    field.max = None
    assert field.get_error_text(code) == 'Field satisfying min=' + str(field.min) + ' value'
    assert field.get_error_text('required') == 'Field is required'


# Generated at 2022-06-22 05:48:52.474544
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert (str(text)) == "<Text()>"
    assert (text.validate("")) == ""
    assert (text.validate("a")) == "a"


# Generated at 2022-06-22 05:48:56.249594
# Unit test for constructor of class Date
def test_Date():
    data_type = Date()
    assert data_type.format == "date"
    assert isinstance(data_type, Date)
    assert isinstance(data_type, Field)


# Generated at 2022-06-22 05:48:58.763211
# Unit test for method serialize of class String
def test_String_serialize():
    s = String(format="datetime")
    print(s.serialize(datetime.datetime.now()))



# Generated at 2022-06-22 05:49:08.029046
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    import typesystem
    str_ty = typesystem.String(max_length=5)
    field = Field()
    field.errors.update({'ERROR_CODE':"{name} value is not valid"})
    try:
        field.validation_error('ERROR_CODE')
    except Exception as e:
        assert e.args[0] == "name value is not valid"
    field.name = 'test_name'
    try:
        field.validation_error('ERROR_CODE')
    except Exception as e:
        assert e.args[0] == "test_name value is not valid"



# Generated at 2022-06-22 05:49:12.813630
# Unit test for method validate of class Number
def test_Number_validate():
    num = Number()
    assert num.validate(1) == 1
    assert num.validate(1.0) == 1.0
    assert num.validate('1') == 1
    assert num.validate('-inf') == '-inf'
    assert num.validate(-1) == -1
    assert num.validate('abc') == 'abc'


# Generated at 2022-06-22 05:49:16.342724
# Unit test for constructor of class Boolean
def test_Boolean():
    test_field = Boolean()
    test_field.allow_null = True
    test_field.errors = {"type": "Must be a boolean.", "null": "May not be null."}
    test_result = test_field.validate('test')
    assert test_result == 'test'


# Generated at 2022-06-22 05:49:17.642829
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert(type(f) == Float)


# Generated at 2022-06-22 05:49:30.568858
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(name='test', allow_null=False, choices=[('a', 'A'), ('b', 'B')])
    assert field.validate('a') is 'a'
    assert field.validate('c') is None
    assert field.validate(None) is None
    assert field.validate('') is None
    field.allow_null=True
    assert field.validate('') is None
    field.allow_null=False
    assert field.validate('') is None
    field.allow_blank=True
    assert field.validate('') is ''

#------------------------------------------------------------------------------#
# Test for method has_default() of class Choice

# Generated at 2022-06-22 05:49:41.845969
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class FieldClass(Field):
        def __init__(self, title = "", description = "", default = None, allow_null = False):
            super().__init__(title = title, description = description, default = default, allow_null = allow_null)
            self.errors = {
                "invalid": "Invalid value."
            }

        def validate(self, v: float, *, strict: bool = False) -> float:
            return float(v)

    # Test case 1
    # If there is no default, return None
    f = FieldClass(default=NO_DEFAULT)
    assert f.get_default_value() == None

    # Test case 2
    # If default is a function, return the function's output
    def default_test():
        return 10
    f = FieldClass(default=default_test)

# Generated at 2022-06-22 05:49:43.019715
# Unit test for constructor of class Any
def test_Any():
    assert Any().validate("Hello World") == "Hello World"



# Generated at 2022-06-22 05:49:53.182892
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field1 = Boolean()

# Generated at 2022-06-22 05:50:05.622106
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    boolfield = Boolean(title='Bool Field', description='This is a bool field')
    assert boolfield != None
    assert isinstance(boolfield, Boolean)

    # test value is None and allow_null is True
    orig_value = None
    expected_return = None
    actual_return = boolfield.validate(orig_value)
    assert actual_return == expected_return

    # test value is None and allow_null is False
    orig_value = None
    boolfield.allow_null = False
    expected_return = None
    actual_return = boolfield.validate(orig_value)
    assert actual_return != expected_return
    assert isinstance(actual_return, ValidationError)
    assert actual_return.code == 'null'

    # test value is not None and the type is bool

# Generated at 2022-06-22 05:50:16.154729
# Unit test for method validate of class Object
def test_Object_validate():
    import numpy as np
    class Object(Field):
        errors = {
            "type": "Must be an object.",
            "null": "May not be null.",
            "invalid_key": "All object keys must be strings.",
            "required": "This field is required.",
            "invalid_property": "Invalid property name.",
            "empty": "Must not be empty.",
            "max_properties": "Must have no more than {max_properties} properties.",
            "min_properties": "Must have at least {min_properties} properties.",
        }


# Generated at 2022-06-22 05:50:27.704054
# Unit test for constructor of class String
def test_String():
    assert(issubclass(String, Field))
    obj = String()

# Generated at 2022-06-22 05:50:39.535512
# Unit test for constructor of class Float
def test_Float():
    #initialize Float and check that all fields have been initialized correctly
    f = Float()
    assert f.allow_blank == False
    assert f.allow_null == False
    assert f.title == ""
    assert f.description == ""
    assert f.numeric_type == float
    assert f.minimum == None
    assert f.maximum == None
    assert f.exclusive_minimum == None
    assert f.exclusive_maximum == None
    assert f.multiple_of == None
    assert f.precision == None
    assert f.errors == {'type', 'null', 'finite', 'minimum', 'exclusive_minimum', 'maximum', 'exclusive_maximum', 'multiple_of'}
    assert f.creation_counter == 0
    assert f.default == NO_DEFAULT

    # initialize again, this time with some values for the fields
   

# Generated at 2022-06-22 05:50:47.336754
# Unit test for constructor of class DateTime
def test_DateTime():
    """Unit test for constructor of class DateTime"""
    with pytest.raises(AssertionError):
        try:
            DateTime(format="text")
            pytest.fail("DateTime's constructor should be failed!")
        except AssertionError as e:
            print(str(e))
            raise e

    with pytest.raises(AssertionError):
        try:
            DateTime(format="datetime", format2="datetime2")
            pytest.fail("DateTime's constructor should be failed!")
        except AssertionError as e:
            print(str(e))
            raise e

# Generated at 2022-06-22 05:50:51.627909
# Unit test for constructor of class Union
def test_Union():
    items1 = [Integer(min_value=1), Integer(min_value=2), Integer(min_value=3)]
    Union(any_of=items1)
    Union(any_of=items1, name="name")


# Generated at 2022-06-22 05:51:01.228559
# Unit test for constructor of class Time
def test_Time():
    f = Time()
    assert f.format == "time"



# Generated at 2022-06-22 05:51:03.746164
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    errors = {"errors_1":"text_1", "errors_2":"text_2"}
    obj = Field(title="this is title", description="this is description", errors=errors)
    assert obj.get_error_text("errors_2") == "text_2"

# Generated at 2022-06-22 05:51:08.460786
# Unit test for method serialize of class String
def test_String_serialize():
    obj = String()
    serialized = obj.serialize('2018-08-10 00:00:00')
    assert isinstance(serialized, str)
    assert serialized=='2018-08-10 00:00:00'
test_String_serialize()



# Generated at 2022-06-22 05:51:15.925871
# Unit test for constructor of class Field
def test_Field():
    # test_title
    title = "title"
    assert Field(title=title).title == title
    assert Field(title=title).description == ""
    assert Field(title=title, description="test_description").description == "test_description"
    assert Field(title=title, default=NO_DEFAULT).default == NO_DEFAULT
    assert Field(title=title, default=None).default == None
    assert Field(title=title).has_default() == False
    assert Field(title=title, default=NO_DEFAULT).get_default_value() == None
    assert Field(title=title, default=None).get_default_value() == None
    assert Field(title=title).validation_error("code").code == "code"
    assert Field(title=title).get_error_text("code") == "Error code"

# Generated at 2022-06-22 05:51:23.246114
# Unit test for method validate of class Union
def test_Union_validate():
    from pydantic.dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    @dataclass
    class Animal:
        name: str
    person = Person(name="tim", age=12)
    animal = Animal(name="tim")
    try:
        Union(any_of=[Person, Animal]).validate(1)
    except ValidationError as e:
        assert e.messages()[0].code == "union"

    try:
        Union(any_of=[Person, Animal]).validate('tim')
    except ValidationError as e:
        assert e.messages()[0].code == "union"


    assert Union(any_of=[Person, Animal]).validate(person) == person

# Generated at 2022-06-22 05:51:28.987566
# Unit test for method validate of class String
def test_String_validate():
  s = String()
  try:
    s.validate(None)
    assert false
  except ValidationError:
    pass
  assert s.validate('abc', strict=False) == 'abc'
  assert s.validate('abc') == 'abc'
  try:
    s.validate('')
    assert false
  except ValidationError:
    pass
  pass



# Generated at 2022-06-22 05:51:38.593987
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    errorMsg = "OK passed"
    flag = 0
    dict_e = {"type" : "Must be a boolean.", "null" : "May not be null"}
    try:
        b = Boolean()
        # Case 1
        b.validate(True)
    except:
        errorMsg = "Failed test case 1 of Boolean.validate"
        flag = 1
    assert flag == 0, errorMsg

    try:
        # Case 2
        b.validate(None)
    except:
        errorMsg = "Failed test case 2 of Boolean.validate"
        flag = 1
    assert flag == 0, errorMsg

    try:
        # Case 3
        b.validate(2)
    except:
        errorMsg = "Failed test case 3 of Boolean.validate"
        flag = 1
    assert flag

# Generated at 2022-06-22 05:51:48.779846
# Unit test for method validate of class Union
def test_Union_validate():
    schema = Union(
        [
            types.String(format="datetime", default="datetime"),
            types.String(format="date", default="date"),
            types.String(format="time", default="time"),
        ]
    )
    assert schema.validate("2019-07-07T13:52:14+02:00") == "2019-07-07T13:52:14+02:00"
    assert schema.validate("2019-07-07") == "2019-07-07"
    assert schema.validate("13:52:14+02:00") == "13:52:14+02:00"
    with pytest.raises(ValidationError) as e:
        schema.validate("foo bar")
    assert e.value.messages()[0].code == "union"
    schema

# Generated at 2022-06-22 05:51:57.116012
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(label='colors',choices=[('Red','red'),('Blue','blue'),('Green','green')], required=True)
    assert c.validate('Red') == 'Red'
    assert c.validate('red') == 'Red'
    assert c.validate('blue') == 'Blue'
    assert c.validate('Green') == 'Green'
    with pytest.raises(ValidationError):
        c.validate('orange')
    with pytest.raises(ValidationError):
        c.validate('')


# Generated at 2022-06-22 05:51:58.128357
# Unit test for constructor of class Const
def test_Const():
    const = Const(const = 1)
    assert const.validate(1) == 1


# Generated at 2022-06-22 05:52:08.508580
# Unit test for constructor of class Union
def test_Union():
    u = Union(None)
    assert u is not None

# Generated at 2022-06-22 05:52:16.043985
# Unit test for constructor of class Union
def test_Union():
    schema = Union([String(max_length=20)])
    good_values = ['good']
    for good_value in good_values:
        assert schema.validate(good_value) == good_value

    bad_values = ['', b'', 12, None]
    for bad_value in bad_values:
        with pytest.raises(ValidationError):
            schema.validate(bad_value)



# Generated at 2022-06-22 05:52:20.331992
# Unit test for method has_default of class Field
def test_Field_has_default():
	field = Field(title='', description='', default=NO_DEFAULT, allow_null=False)
	assert field.has_default() == False


# Generated at 2022-06-22 05:52:23.577306
# Unit test for constructor of class Choice
def test_Choice():
    choice = Choice(choices=[('a','b')], allow_default=False, allow_null=False)
    assert choice.choices == [('a', 'b')]
    assert choice.allow_default == False
    assert choice.allow_null == False



# Generated at 2022-06-22 05:52:25.374461
# Unit test for constructor of class Boolean
def test_Boolean():
    assert Boolean(allow_null = True, default = True)
    
    

# Generated at 2022-06-22 05:52:28.731087
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    field = Decimal()
    assert field.serialize(2) == 2
    assert field.serialize(-2) == -2
    assert field.serialize(1.23) == 1.23



# Generated at 2022-06-22 05:52:29.879411
# Unit test for method serialize of class Array
def test_Array_serialize():
    json = Array(items=String())
    assert json.serialize(["One", "Two"]) == ["One", "Two"]

# Generated at 2022-06-22 05:52:31.318917
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    assert field.validation_error

# Generated at 2022-06-22 05:52:32.705694
# Unit test for method serialize of class Field
def test_Field_serialize():
    field=Field()
    assert field.serialize(1)==1

# Generated at 2022-06-22 05:52:33.320045
# Unit test for constructor of class Any
def test_Any():
    assert Any()



# Generated at 2022-06-22 05:52:51.609717
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    fields = {'name': String(title="Name", description="User's name", default="John"), 'age':Integer(title="Age", description="User's age", default=18), }
    context = {}
    name = fields['name']
    name.validate_or_error()
    age = fields['age']
    age.validate_or_error()
    schema = Schema(fields=fields, context=context)
    schema.validate({'name': 'Doe', 'age': 19, })
    schema.validate({'name': 'Doe', })
    schema.validate({'age': 19, })
    schema.validate({'name': 'Doe', 'age': 19.1, }, strict=True)
    schema.validate({'name': 'Doe', 'age': None, }, strict=True)

# Generated at 2022-06-22 05:52:58.022247
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    with pytest.raises(ValidationError):
        field.validate("d")
    try:
        field.validate("d") == "d"
    except ValidationError as e:
        assert e.code == "choice"
        assert e.text == "Not a valid choice."



# Generated at 2022-06-22 05:53:02.643701
# Unit test for method serialize of class Array
def test_Array_serialize():
    array1 = Array(
        required = True,
        unique_items = True,
        items = [
            Integer(),
            Integer(),
        ],
        additional_items = Integer(),
        min_items = 3,
    )
    assert array1.serialize(["123", "123", "456"]) == [123, 123, 456]
    assert array1.serialize(["123", "123", "456", "789"]) == [123, 123, 456, 789]
    try:
        array1.serialize(["123", "123", "456", "456"])
        assert False
    except ValidationError:
        assert True
    try:
        array1.serialize(["123", "123"])
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-22 05:53:06.639594
# Unit test for constructor of class Decimal
def test_Decimal():
    assert Decimal().validate('1.345') == decimal.Decimal('1.345')
    assert Decimal().validate('-1') == decimal.Decimal('-1')
    assert Decimal().validate('0') == decimal.Decimal('0')
    assert Decimal().validate('.1') == decimal.Decimal('0.1')


# Generated at 2022-06-22 05:53:18.558800
# Unit test for constructor of class Object
def test_Object():
    print('Testing Constructor of class Object')
    properties = {
        "foo": String(),
        "bar": Number(),
        "baz": Boolean(),
    }
    pattern_properties = {"^x_": String()}
    additional_properties = Boolean()
    property_names = String()
    min_properties = 1
    max_properties = 10
    required = ["foo", "bar"]
    obj = Object(
        properties=properties,
        pattern_properties=pattern_properties,
        additional_properties=additional_properties,
        property_names=property_names,
        min_properties=min_properties,
        max_properties=max_properties,
        required=required,
    )
    assert obj.properties == properties
    assert obj.pattern_properties == pattern_properties
    assert obj.additional_properties == additional_properties

# Generated at 2022-06-22 05:53:20.848021
# Unit test for method has_default of class Field
def test_Field_has_default():
    #create a instance for test
    field = Field()
    assert field.has_default() == False

# Generated at 2022-06-22 05:53:24.785291
# Unit test for constructor of class Boolean
def test_Boolean():
    myBool = Boolean()
    assert(myBool.coerce_values['1'] == True)
    assert(myBool.coerce_values['true'] == True)


# Generated at 2022-06-22 05:53:31.290251
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    # Test for allowing null
    bool = Boolean(allow_null = True)
    try:
        bool.validate(1)
    except ValidationError:
        pass
    else:
        assert False
    # Test for not allowing null
    bool = Boolean(allow_null = False)
    try:
        bool.validate(1)
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-22 05:53:43.127740
# Unit test for constructor of class Array
def test_Array():
    # no parameters are passed.
    items = None
    additional_items = False
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False
    test_array = Array()

    assert test_array.items == items
    assert test_array.additional_items == additional_items
    assert test_array.min_items == min_items
    assert test_array.max_items == max_items
    assert test_array.unique_items == unique_items

    # all parameters are passed.
    items = None
    additional_items = False
    min_items = None
    max_items = None
    exact_items = None
    unique_items = False

# Generated at 2022-06-22 05:53:52.264786
# Unit test for method serialize of class Array
def test_Array_serialize():
    items = [Integer(), String()]
    field = Array(items=items, name="hi")
    # Case 1:
    obj = [1, "str"]
    result = field.serialize(obj)
    assert result == ["str", "str"]
    # Case 2:
    obj = [1]
    result = field.serialize(obj)
    assert result == [1]
    # Case 3:
    field = Array(items=Integer(), name="hi")
    obj = [1]
    result = field.serialize(obj)
    assert result == ["1"]
    


# Generated at 2022-06-22 05:54:02.917952
# Unit test for constructor of class Field
def test_Field():
    test_field = Field()
    assert(test_field.title == "")
    assert(test_field.description == "")
    assert(test_field.allow_null == False)
    assert(test_field._creation_counter == 0)

# Generated at 2022-06-22 05:54:13.013629
# Unit test for method validate of class Object
def test_Object_validate():
    class UserSchema(Schema):
        username = fields.String(required=True)
        email = fields.String(required=True)
        followers = fields.Integer()

    user_data = {
        "username": "matt",
        "email": "matt@lp.com",
        "followers": 32,
    }
    user_schema = UserSchema()
    validated_data = user_schema.validate(user_data)
    assert validated_data == {
        "username": "matt",
        "email": "matt@lp.com",
        "followers": 32,
    }
    # Unit test for method validate of class Object
    class UserSchema(Schema):
        username = fields.String(required=True)
        email = fields.String(required=True)
        followers

# Generated at 2022-06-22 05:54:15.523627
# Unit test for constructor of class Field
def test_Field():
    assert Field(title="", description="", default=NO_DEFAULT, allow_null=False)

test_Field()


# Generated at 2022-06-22 05:54:18.371036
# Unit test for constructor of class Array
def test_Array():
    assert Array().validate([1,2,3]) == [1,2,3]


# Generated at 2022-06-22 05:54:22.804741
# Unit test for constructor of class Time
def test_Time():
    t = Time(allow_null=True)
    assert t.allow_null
    assert t.errors == {'type': 'Must be a valid time.', 'null': 'May not be null.', 'required': 'This field is required.', 'invalid': 'Must be a valid time.'}
    assert t.format == 'time'
    assert t.allow_empty_string == False
    assert t.augmented is True


# Generated at 2022-06-22 05:54:27.286659
# Unit test for method __or__ of class Field
def test_Field___or__():
    test_object = Field(title = 'title', description = 'description', default = NO_DEFAULT, allow_null = False)
    assert isinstance(test_object, Field)
    assert isinstance(test_object, object)
    assert isinstance(test_object.__or__(Field(title = 'title', description = 'description', default = NO_DEFAULT, allow_null = False)), Union)



# Generated at 2022-06-22 05:54:29.211213
# Unit test for constructor of class Text
def test_Text():
    print("Testing Text() constructor")
    assert Text().__class__.__name__ == "Text"


# Generated at 2022-06-22 05:54:31.199549
# Unit test for constructor of class String
def test_String():
    my_String = String()
    assert my_String.trim_whitespace == True


# Generated at 2022-06-22 05:54:42.613756
# Unit test for method serialize of class String
def test_String_serialize():
    max_length = 4
    min_length = 2
    pattern = r'[a-zA-Z]'
    format = 'date'
    # test case 1
    obj = '18-12-2016'
    s = String(max_length = max_length, min_length = min_length, pattern = pattern, format = format)
    assert s.serialize(obj) == '2016-12-18'

    # test case 2
    obj = '18-12-2016'
    s = String(max_length = max_length, min_length = min_length, pattern = pattern)
    assert s.serialize(obj) == obj

    # test case 3
    obj = '18-12-2016'
    s = String(max_length = max_length, pattern = pattern)
    assert s.serialize(obj)

# Generated at 2022-06-22 05:54:45.042056
# Unit test for constructor of class DateTime
def test_DateTime():
    a = DateTime()
    try:
        result = a.validate("2019-03-07T16:00:00Z")
    except ValidationError as e:
        raise
    except:
        raise Exception("Unexpected exception")


# Generated at 2022-06-22 05:55:12.295327
# Unit test for constructor of class Text
def test_Text():
    text1 = Text()
    assert text1.format == "text"
    assert text1._default_error_messages == Text.errors



# Generated at 2022-06-22 05:55:15.550678
# Unit test for method serialize of class Field
def test_Field_serialize():
    field = Field()
    obj = "test"
    field.serialize(obj)


# Generated at 2022-06-22 05:55:16.977768
# Unit test for method has_default of class Field
def test_Field_has_default():
    n=Field()
    n.default=3
    assert n.has_default()==True



# Generated at 2022-06-22 05:55:20.245700
# Unit test for method validate of class Any
def test_Any_validate():
  field = Any()
  value = 'anything'
  result = field.validate(value)
  assert result == value



# Generated at 2022-06-22 05:55:25.146202
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    class Test(Field):
        def __init__(self):
            super(Test, self).__init__()

    test = Test()
    assert(test.get_default_value() == None)



# Generated at 2022-06-22 05:55:29.750776
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert isinstance(field, Field)
    assert field.title == ""
    assert field.description == ""
    assert field._creation_counter == 0
    assert field.has_default() == False
    assert callable(field.get_default_value()) == False
    assert field.get_default_value() == None


# Generated at 2022-06-22 05:55:37.664431
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice=Choice(choices=None, allow_null=True)
    assert choice.validate(None) == None
    # In case of value is none and does not allow null
    choice=Choice(choices=None, allow_null=False)
    with pytest.raises(ValidationError):
        choice.validate(None)
    assert choice.validate("x") == "x"
    assert choice.validate("y") == "y"
    # In case of value is not in the choices
    choice=Choice(choices=['x', 'y'], allow_null=False)
    with pytest.raises(ValidationError):
        choice.validate("z")



# Generated at 2022-06-22 05:55:40.457653
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    try:
        field.validate(123)
    except ValidationError:
        assert False


# Generated at 2022-06-22 05:55:42.114102
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate("test") == "test"

# Generated at 2022-06-22 05:55:45.461749
# Unit test for constructor of class Number
def test_Number():
    number=Number()

