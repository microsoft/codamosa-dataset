

# Generated at 2022-06-22 05:47:53.677085
# Unit test for method validate_or_error of class Field
def test_Field_validate_or_error():
    assert True == True



# Generated at 2022-06-22 05:47:56.691351
# Unit test for constructor of class Object
def test_Object():
    object_schema = Object(
        properties={
            "name": String(required=True)
        }
    )
    print(object_schema)


# Generated at 2022-06-22 05:48:00.309149
# Unit test for constructor of class Union
def test_Union():
    assert Union([], allow_null=True, description="Test").any_of == []
    assert Union([], allow_null=True, description="Test").allow_null == True
    assert Union([], allow_null=True, description="Test").description == "Test"

test_Union()



# Generated at 2022-06-22 05:48:11.767295
# Unit test for method __or__ of class Field
def test_Field___or__():
    import unittest
    from freezegun import freeze_time
    from test_typesystem import test_string_field
    from test_typesystem import test_int_field
    from typesystem.exceptions import ValidationError
    from typesystem.union import Union

    @freeze_time("2012-01-14")
    class TestField___or__(unittest.TestCase):
        def test_Field___or__(self):
            union = test_string_field | test_int_field

            self.assertIsInstance(union, Union)
            self.assertEqual(union.validate(1), 1)
            self.assertEqual(union.validate("1"), 1)
            self.assertEqual(union.validate("2012-01-14"), "2012-01-14")
            self.assertRaises

# Generated at 2022-06-22 05:48:15.112858
# Unit test for constructor of class String
def test_String():
    s = String(title="Gamma", description="Gamma", default="Gamma", max_length=1, min_length=1, pattern="/Gamma/")

# Generated at 2022-06-22 05:48:19.845972
# Unit test for method validate of class Const
def test_Const_validate():
    sc = Const(5)
    assert sc.validate(5) == 5
    with pytest.raises(ValidationError):
        sc.validate(4)
    with pytest.raises(ValidationError):
        sc.validate("5")
    assert sc.validate(5, strict=True) == 5


# Generated at 2022-06-22 05:48:22.136439
# Unit test for constructor of class Field
def test_Field():
    field = Field()
    assert field.title == ''
    assert field.description == ''
    assert not field.allow_null


# Generated at 2022-06-22 05:48:29.994009
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    # Create class to test
    class Field(object):
        def __init__(self, default):
            self.default = default
    # Create test case
    class TestCase(unittest.TestCase):
        def test_get_default_value_with_default_value(self):
            # Create Field
            t_field1 = Field(default=10)
            # Assert method get_default_value
            self.assertEqual(t_field1.get_default_value(), 10)
        def test_get_default_value_with_default_function(self):
            # Create Field
            t_field2 = Field(default=lambda : 10)
            # Assert method get_default_value
            self.assertEqual(t_field2.get_default_value(), 10)

# Generated at 2022-06-22 05:48:34.875308
# Unit test for method serialize of class Field
def test_Field_serialize():
    class TestField(Field):
        def serialize(self, obj: typing.Any) -> typing.Any:
            if obj == 12:
                return 7
            else:
                return obj
    # test not equal
    a = TestField()
    assert a.serialize(1) == 1
    # test equal
    assert a.serialize(12) == 7




# Generated at 2022-06-22 05:48:37.296331
# Unit test for method serialize of class Array
def test_Array_serialize():
    class TestObject(BaseModel):
        arr: typing.List[float]=None
    obj = TestObject(arr=[1,2,3])
    json_str = obj.json()
    print(json_str)
    obj2 = TestObject.loads(json_str)
    json_str2 = obj2.json()
    print(json_str2)
    assert json_str == json_str2
test_Array_serialize()


# Generated at 2022-06-22 05:48:54.640716
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean(title = "test", description = "test", default = False, allow_null = False)

    #test validate function, there are two options for value, string or bool
    #1. string
    assert boolean.validate("True") == True
    assert boolean.validate("false") == False
    assert boolean.validate("Off") == False
    assert boolean.validate("On") == True
    with pytest.raises(ValidationError) as excinfo:
        boolean.validate("test")#should raise exception

    #2. bool
    assert boolean.validate(True) == True
    assert boolean.validate(False) == False
    with pytest.raises(ValidationError) as excinfo2:
        boolean.validate(1)#should raise exception


# Generated at 2022-06-22 05:48:55.931635
# Unit test for method validate of class Field
def test_Field_validate():
    assert Field.validate(value, strict=True) == None
    assert Field.validate(value, strict=False) == None


# Generated at 2022-06-22 05:49:05.033878
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    field = Boolean()
    test_case = [
        (None, None),
        (True, True),
        ("True", True),
        (1, True),
        ("1", True),
        ("false", False),
        ("off", False),
        ("null", None),
        ("0", False),
        (0, False),
        ("", False),
        (2, ValueError),
        (" ", ValueError),
    ]

    for sample, result in test_case:
        if isinstance(result, type) is True and issubclass(result, Exception):
            with pytest.raises(result):
                field.validate(sample)
        else:
            assert field.validate(sample) == result



# Generated at 2022-06-22 05:49:13.162214
# Unit test for constructor of class Array
def test_Array():
    field1 = String()
    field2 = String()
    field3 = String()
    field4 = String()
    field5 = String()
    field6 = String()
    fields = [field1, field2, field3, field4, field5, field6]
    v = Array(min_items=6, max_items=10, items=fields, additional_items=False)
    assert v.min_items == 6
    assert v.max_items == 10
    assert v.items == fields
    assert v.additional_items == False


# Generated at 2022-06-22 05:49:15.910345
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    #setup
    field = Decimal()
    # action
    actual = field.serialize(None)
    # assert
    assert actual == None
    # action
    actual2 = field.serialize(8)
    # assert
    assert actual2 == 8.0



# Generated at 2022-06-22 05:49:25.464101
# Unit test for constructor of class String
def test_String():
    string_field = String()
    assert isinstance(string_field, Field)
    assert isinstance(string_field, String)
    assert not string_field.has_default()
    assert string_field.allow_null == False
    assert string_field.title == ''
    assert string_field.description == ''

    string_field = String(allow_null=True)
    assert isinstance(string_field, Field)
    assert isinstance(string_field, String)
    assert not string_field.has_default()
    assert string_field.allow_null == True
    assert string_field.title == ''
    assert string_field.description == ''

    string_field = String(title='dummy', description='dummy')
    assert isinstance(string_field, Field)
    assert isinstance(string_field, String)

# Generated at 2022-06-22 05:49:26.801714
# Unit test for method validate of class Const
def test_Const_validate():
    c=Const(const="a")
    x=c.validate("a")
    y=c.validate("b")
    assert x=="a" 
    assert y!="a"


# Generated at 2022-06-22 05:49:28.329036
# Unit test for constructor of class Text
def test_Text():
    try:
        Text()
    except AssertionError:
        assert False
# End of unit test



# Generated at 2022-06-22 05:49:33.081702
# Unit test for constructor of class Date
def test_Date():
    from datetime import date
    today = date.today()
    today_str = today.strftime("%Y-%m-%d")
    class MySchema(Schema):
        # Define a Date Field with 
        # name of "birthday"
        birthday = Date()
    schema = MySchema()
    schema.validate({"birthday": today_str})
    schema.serialize({"birthday": date(2000, 1, 1)})


# Generated at 2022-06-22 05:49:38.836367
# Unit test for method validate of class Choice
def test_Choice_validate():
    c = Choice(choices=["a", "b"])
    c2 = Choice(choices=["a", "b"], allow_null=True)
    assert c.validate(None, strict=True) != "null"
    assert c.validate("a") == "a"
    assert c.validate("c") != "choice"
    assert c2.validate(None) == None



# Generated at 2022-06-22 05:49:49.834425
# Unit test for constructor of class Time
def test_Time():
    T = Time(name='TEST')
    assert T.name == 'TEST'
    assert isinstance(T.pattern, re.Pattern)
    assert T.type == 'string'
    assert T.format == 'time'


# Generated at 2022-06-22 05:49:52.810711
# Unit test for method serialize of class Field
def test_Field_serialize():
    m = Field()
    n = m.serialize(1)
    assert n == 1

# Generated at 2022-06-22 05:49:56.131365
# Unit test for method validate of class Const
def test_Const_validate():
        x = Const(const="2")
        x.validate("2")


# Generated at 2022-06-22 05:50:07.264229
# Unit test for method validate of class Choice
def test_Choice_validate():
    # test case with valid value
    obj = Choice(required=False, allow_null=True, choices=[('Yes', 'True'), ('No', 'False')])
    assert obj.validate('Yes') == 'Yes'
    # test case with invalid choice
    assert obj.validate('Maybe') == 'Maybe'
    # test case with invalid type
    assert obj.validate(1) == 1
    assert obj.validate(None) == None
    # test case with invalid parameter strict
    obj2 = Choice(required=False, allow_null=True, choices=['Yes', 'No'])
    assert obj2.validate('Yes', strict=True) == 'Yes'
    # test case with invalid parameter allow_null
    obj3 = Choice(required=False, allow_null=False, choices=['Yes', 'No'])
   

# Generated at 2022-06-22 05:50:10.498948
# Unit test for constructor of class Choice
def test_Choice():
    c = Choice(choices=['a', 'b'], allow_null=True)

    assert c.choices == [('a', 'a'), ('b', 'b')]


# Generated at 2022-06-22 05:50:21.594205
# Unit test for constructor of class Object
def test_Object():
    field = Object()
    assert field.properties == dict()
    assert field.pattern_properties == dict()
    assert field.additional_properties == True
    assert field.property_names == None
    assert field.min_properties == None
    assert field.max_properties == None
    assert field.required == []
    assert field.default == None
    assert field.allow_null == False
    assert field.allow_expressions == False
    
    
    field = Object(required=['name'])
    assert field.properties == dict()
    assert field.pattern_properties == dict()
    assert field.additional_properties == True
    assert field.property_names == None
    assert field.min_properties == None
    assert field.max_properties == None
    assert field.required == ['name']
    assert field.default == None


# Generated at 2022-06-22 05:50:23.187272
# Unit test for constructor of class Float
def test_Float():
    number = Float()
    assert (number.numeric_type==float)


# Generated at 2022-06-22 05:50:25.108451
# Unit test for method has_default of class Field
def test_Field_has_default():
    assert Field().has_default() == False
test_Field_has_default()


# Generated at 2022-06-22 05:50:37.004602
# Unit test for constructor of class String
def test_String():
    a = String()
    assert a.title == ""
    assert a.description == ""
    assert a.allow_blank == False
    assert a.trim_whitespace == True
    assert a.max_length == None
    assert a.min_length == None
    assert a.pattern == None
    assert a.format == None

    a = String(allow_blank=True, trim_whitespace=False,
               max_length=5, min_length=1, pattern="[0-9]{3}", format="date")
    assert a.allow_blank == True
    assert a.trim_whitespace == False
    assert a.max_length == 5
    assert a.min_length == 1
    assert a.pattern == "[0-9]{3}"
    assert a.format == "date"



# Generated at 2022-06-22 05:50:41.278013
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    err = Field()
    err.errors = {"code": "code"}
    assert err.get_error_text("code") == "code"
    res = err.get_error_text("bad_code")
    assert res == ""
    assert err.errors == {"code": "code"}


# Generated at 2022-06-22 05:51:00.829563
# Unit test for method validate of class Object
def test_Object_validate():
    field = Object()
    assert field.validate({"a":1,"b":2,"c":3.4}) == {'a': 1, 'b': 2, 'c': 3.4}
    assert field.validate([1,2,3]) == Field.validation_error("type")
    assert field.validate(3) == Field.validation_error("type")
    assert field.validate(None) == Field.validation_error("type")


    field = Object(required=["a", "b", "c"])
    assert field.validate({"a":1,"b":2,"c":3.4}) == {'a': 1, 'b': 2, 'c': 3.4}
    assert field.validate({"a":1,"b":2}) == Field.validation_error("required")

# Generated at 2022-06-22 05:51:12.038918
# Unit test for constructor of class Boolean
def test_Boolean():
    bool = Boolean()
    assert issubclass(bool.__class__, Field)
    assert bool.validate(1) == True
    assert bool.validate('True') == True
    assert bool.validate('true') == True
    assert bool.validate('False') == False
    assert bool.validate('false') == False
    assert bool.validate('1') == True
    assert bool.validate('0') == False
    assert bool.validate('a') == None
    assert bool.validate(None) == None
    assert bool.validate('null') == None
    assert bool.validate('True', strict=True) == True
    assert bool.validate('true', strict=True) == True
    # assert bool.validate('1', strict=True) == True
    # assert bool.validate('a

# Generated at 2022-06-22 05:51:19.680727
# Unit test for method validate of class Union
def test_Union_validate():
    class Test(Union):
        def __init__(self, any_of, **kwargs):
            super().__init__(**kwargs)
            self.any_of = any_of

        def validate(self, value, **kwargs):
            print(value)

    t = Test(any_of=[Integer(), String()], name='test')
    t.validate(1)
test_Union_validate()


# Generated at 2022-06-22 05:51:22.757620
# Unit test for constructor of class Const
def test_Const():
    exception_flag = 0
    error = 0 
    try:
        Const(2.3)
    except:
        exception_flag = 1
    if exception_flag == 0:
        error = 1
    exception_flag = 0
    try:
        Const(2.3, allow_null=True, const=2.3)
    except:
        exception_flag = 1
    if exception_flag == 0:
        error = 2
    if error == 1:
        print("test_Const: ok 1")
    else:
        print("test_Const: error")


# Generated at 2022-06-22 05:51:24.561103
# Unit test for method get_error_text of class Field
def test_Field_get_error_text():
    field = Field()
    assert field.get_error_text(code='') == ''



# Generated at 2022-06-22 05:51:26.939135
# Unit test for constructor of class Float
def test_Float():
    # assert float(testFloat) == float(testFloat)
    assert float(testFloat) == float(testFloat)


# Generated at 2022-06-22 05:51:35.157539
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice()

    assert choices.validate(1) == 1
    assert choices.validate(None) == None

    choices.choices=[1,2,3]
    assert choices.validate(1) == 1

    choices.allow_null=True
    assert choices.validate(None) == None

    choices.allow_null=False
    try:
        choices.validate(None)
    except ValidationError as e:
        assert e.code == "null"
    try:
        choices.validate(4)
    except ValidationError as e:
        assert e.code == "choice"



# Generated at 2022-06-22 05:51:38.306826
# Unit test for method __or__ of class Field
def test_Field___or__():
    any_of = [Text()]
    union = Union(any_of=any_of)
    field = Text()
    field = Union(str, field)
    assert field == union


# Generated at 2022-06-22 05:51:39.337798
# Unit test for constructor of class Text
def test_Text():
    assert Text().format == "text"


# Generated at 2022-06-22 05:51:48.159971
# Unit test for constructor of class Field
def test_Field():
    assert Field(title='title', description='', default=NO_DEFAULT, allow_null=False).title == 'title'
    assert Field(title='title', description='', default=NO_DEFAULT, allow_null=False).description == ''
    assert Field(title='title', description='', default=NO_DEFAULT, allow_null=False).default == NO_DEFAULT
    assert Field(title='title', description='', default=NO_DEFAULT, allow_null=False).allow_null == False
    assert Field(title='title', description='', default=NO_DEFAULT, allow_null=False).errors == {}
# End of unit test for constructor of class Field



# Generated at 2022-06-22 05:52:14.267896
# Unit test for constructor of class Integer
def test_Integer():
    assert Integer().numeric_type == int



# Generated at 2022-06-22 05:52:25.036475
# Unit test for method validate of class String
def test_String_validate():
    Str = String(title="String",description = "A string field", allow_null=False, allow_blank=False, trim_whitespace=True, min_length=5, max_length=5, format=None)
    value = "hello"
    assert Str.validate(value) == "hello"
    value = "null"
    assert Str.validate(value) == "null"
    value = " "
    assert Str.validate(value) == " "
    value = None
    with pytest.raises(AssertionError):
        Str.validate(value)
    value = "hello!"
    with pytest.raises(AssertionError):
        Str.validate(value)


# Generated at 2022-06-22 05:52:31.319028
# Unit test for constructor of class Choice
def test_Choice():
    with pytest.raises(AssertionError):
        # should fail because of invalid input
        Choice(choices=[('hello', 'world', 'world')])

    c = Choice(choices=[('hello', 'world')])
    # This should not raise an error
    c.validate('hello')
    with pytest.raises(ValidationError):
        # This should raise an error
        c.validate('foo')


# Generated at 2022-06-22 05:52:38.453289
# Unit test for method __or__ of class Field
def test_Field___or__():
    class Field1(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    class Field2(Field):
        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            return value

    union = Field1() | Field2()
    assert isinstance(union, Union)
    assert len(union.any_of) == 2

NONE_VALUE = object()



# Generated at 2022-06-22 05:52:46.281803
# Unit test for constructor of class Boolean
def test_Boolean():
    boolean = Boolean()
    assert boolean.allow_null == False
    assert boolean.coerce_null_values == {'', 'null', 'none'}
    assert boolean.coerce_values == {'true': True, 'false': False, 'on': True, 'off': False, '1': True, '0': False, '': False, 1: True, 0: False}

    boolean = Boolean(allow_null=True)
    assert boolean.allow_null == True


# Generated at 2022-06-22 05:52:51.116240
# Unit test for method validate of class Const
def test_Const_validate():
    type_field = Const(42)
    try:
        type_field.validate(43)
    except ValidationError as e:
        print(e)
        
test_Const_validate()

test_Const_validate()


# Generated at 2022-06-22 05:52:58.378981
# Unit test for constructor of class Const
def test_Const():
    allow_null = False
    const = 4
    const_field = Const(const=const, allow_null=allow_null)

    assert const_field.errors['only_null'] == "Must be null."
    assert const_field.errors['const'] == "Must be the value '{const}'."
    assert const_field.allow_null == allow_null
    assert const_field.const == const
    assert const_field.error_formats == {}


# Generated at 2022-06-22 05:52:59.864018
# Unit test for constructor of class Boolean
def test_Boolean():
    with pytest.raises(AssertionError):
        Boolean()



# Generated at 2022-06-22 05:53:04.324743
# Unit test for constructor of class Number
def test_Number():
    func = Number(allow_null=None, default=None, title=None, description=None, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, precision=None, multiple_of=None)
    assert func is not None


# Generated at 2022-06-22 05:53:07.815737
# Unit test for constructor of class Float
def test_Float():
    f = Float(minimum=1, maximum=2)
    assert f.minimum == decimal.Decimal('1')
    assert f.maximum == decimal.Decimal('2')
    
