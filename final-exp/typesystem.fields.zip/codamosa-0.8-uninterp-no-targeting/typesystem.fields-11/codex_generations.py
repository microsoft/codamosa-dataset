

# Generated at 2022-06-22 05:47:27.355964
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    b = Boolean()
    assert b.validate(True) == True
    assert b.validate(False) == False

    assert b.validate(None) == None
    assert b.validate(None, strict=True) == None

    b = Boolean(allow_null=True)
    assert b.validate(True) == True
    assert b.validate(False) == False
    assert b.validate(None) == None

    b = Boolean(allow_null=False)
    assert b.validate(True) == True
    assert b.validate(False) == False

    assert b.validate(None) == None
    assert b.validate(None, strict=True) == None

    assert b.validate(1) == True
    assert b.validate(0) == False
    assert b.valid

# Generated at 2022-06-22 05:47:33.100610
# Unit test for constructor of class Choice
def test_Choice():
    assert Choice(choices=["a", "b"]) is not None
    assert Choice(choices=["a", "b"]).choices == [("a", "a"), ("b", "b")]
    assert Choice(choices=[("a", "aa"), ("b", "bb")]).choices == [("a", "aa"), ("b", "bb")]



# Generated at 2022-06-22 05:47:37.590698
# Unit test for constructor of class Text
def test_Text():
    text = Text()
    assert text.format == "text"
    assert text.allow_null == False
    assert text.min_length == None
    assert text.max_length == None
    assert text.regex == None



# Generated at 2022-06-22 05:47:45.568701
# Unit test for constructor of class Choice
def test_Choice():
    # Case 1 : choices is empty
    # Case 2 : choices is None
    # Case 3 : choices is [1,"a"]
    obj = Choice(choices=[1,"a"])
    assert obj.choices == [(1, 1), ('a', 'a')]
    obj = Choice(choices=[])
    assert obj.choices == []
    obj = Choice(choices=None)
    assert obj.choices == []



# Generated at 2022-06-22 05:47:52.199321
# Unit test for method validate of class Any
def test_Any_validate():
    from joj.lib.field import Any
    from joj.lib.utils import deep_update

    an_any = Any()
    # Test with float
    assert an_any.validate(1) == 1
    # Test with boolean
    assert an_any.validate(True) == True
    # Test with str
    assert an_any.validate("1") == "1"
    # Test with empty
    assert an_any.validate(None) == None



# Generated at 2022-06-22 05:47:53.814017
# Unit test for constructor of class Time
def test_Time():
    t = Time()
    assert t.format == "time"
    assert t.title == None



# Generated at 2022-06-22 05:47:56.112918
# Unit test for method get_default_value of class Field
def test_Field_get_default_value():
    field = Field()
    expected = field.get_default_value()
    assert expected == None
    

# Generated at 2022-06-22 05:47:57.121558
# Unit test for constructor of class Float
def test_Float():
    assert isinstance(Float(), Float)


# Generated at 2022-06-22 05:47:58.252808
# Unit test for constructor of class Union
def test_Union():
    result = Union([], name = "")
    assert result != None

# Generated at 2022-06-22 05:48:06.301538
# Unit test for constructor of class Field
def test_Field():
    title = "Title"
    description = "Description"
    default = None
    allow_null = True
    print("Test Field constructor: ")
    print("assert isinstance(description, str)")
    print("assert isinstance(title, str)")
    assert isinstance(description, str)
    assert isinstance(title, str)
    print("assert allow_null and default is NO_DEFAULT")
    assert allow_null and default is NO_DEFAULT
    print("Unit test for Field constructor is successful")


# Generated at 2022-06-22 05:48:16.857907
# Unit test for constructor of class Any
def test_Any():
    assert Any().validate(Any()) == Any()

# Generated at 2022-06-22 05:48:22.137070
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate(1) == 1
    assert Any().validate(None) == None
    assert Any().validate("string") == "string"
    assert Any().validate(True) == True
    assert Any().validate([1, 2, 3]) == [1, 2, 3]
    assert Any().validate({"a": 1}) == {"a": 1}



# Generated at 2022-06-22 05:48:26.693502
# Unit test for constructor of class Number
def test_Number():
    test_number = Number(title="float", minimum=1, maximum=10, multiple_of=1.1)
    print(test_number)
    print(test_number.errors)
    assert isinstance(test_number,Field)
    assert test_number.title == "float"
    assert test_number.minimun == 1
    assert test_number.maximum == 10
    assert test_number.multiple_of == 1.1
    assert isinstance(test_number.errors, dict)


# Generated at 2022-06-22 05:48:31.705308
# Unit test for method has_default of class Field
def test_Field_has_default():
  # Test if has_default is exist
  check_method_exists(Field, 'has_default')
  # Test if has_default returns boolean
  assert isinstance(Field().has_default(), bool)
  # Test if has_default is called
  
test_Field_has_default()


# Generated at 2022-06-22 05:48:32.870993
# Unit test for constructor of class Union
def test_Union():
    assert Union([String()])
    assert Union([String()]).validate("hello") == "hello"






# Generated at 2022-06-22 05:48:43.004323
# Unit test for method serialize of class String
def test_String_serialize():
    my_field = String(
        title="My title",
        description="My description",
        allow_blank=True,
        trim_whitespace=False,
        max_length=10,
        min_length=5,
        pattern="[a-z]",
        format="datetime"
    )

    assert my_field.serialize("1955-11-05T12:00:59Z") == "1955-11-05T12:00:59Z"

    my_field = String(
        title="My title",
        description="My description",
        allow_blank=True,
        trim_whitespace=False,
        max_length=10,
        min_length=5,
        pattern="[a-z]"
    )


# Generated at 2022-06-22 05:48:49.243412
# Unit test for constructor of class Decimal
def test_Decimal():
    test = Decimal()
    assert type(test.get_default_value()) == None
    assert test.validate(123456789) == 123456789
    assert test.serialize(123456789) == 123456789
    try:
        test.validate("123456789")
        assert False
    except ValidationError:
        assert True
    try:
        test.validate(None)
        assert False
    except ValidationError:
        assert True
    try:
        test.validate(True)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-22 05:49:00.282106
# Unit test for constructor of class Boolean
def test_Boolean():
    # Testing the case where no errors are thrown
    field = Boolean()
    assert field.default == False # Default should be false
    assert field.allow_null == False # Default should be false

    field = Boolean(title="abc")
    assert field.default == False # Default should be false
    assert field.allow_null == False # Default should be false

    field = Boolean(default=True)
    assert field.default == True # Default should be True
    assert field.allow_null == False # Default should be false
    assert field.title == "" # Default should be empty string

    field = Boolean(allow_null=True)
    assert field.default == False # Default should be False
    assert field.allow_null == True # Default should be True
    assert field.title == "" # Default should be empty string


# Generated at 2022-06-22 05:49:01.474199
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const(const=['a'])
    test_str = ['a']
    assert(field.validate(test_str) == test_str)

# Generated at 2022-06-22 05:49:11.434119
# Unit test for constructor of class Field
def test_Field():
  from typesystem.objects import Object
  from typesystem.fields import (Field, String, Integer, Union)
  # Case input is none
  try:
    field_none = Field()
  except TypeError:
    assert True
  else:
    assert False

  # Case input is not a Field
  try:
    field_not_field = Field(String(max_length=5))
  except TypeError:
    assert True
  else:
    assert False

  # Case input is a Field
  field_String_max_len = String(max_length=5)
  field_String_min_len = String(min_length=5)
  field_Integer = Integer()

  # Case input is multiple Fields

# Generated at 2022-06-22 05:49:45.248924
# Unit test for method validation_error of class Field
def test_Field_validation_error():
    field = Field()
    field.errors = {'error_code1':'error_text1'}
    assert field.validation_error('error_code1') == ValidationError(text='error_text1', code='error_code1',)

# Generated at 2022-06-22 05:49:47.008038
# Unit test for constructor of class Any
def test_Any():
    any_case = "case-insensitive"
    schema = Any()
    assert any_case == schema.validate(any_case)

# Generated at 2022-06-22 05:49:57.009138
# Unit test for method validate of class Number
def test_Number_validate():

    num = Number(maximum=10, minimum=2)
    assert num.validate(3) == 3
    assert num.validate(2) == 2
    assert num.validate(6) == 6

    with pytest.raises(ValidationError):
        assert num.validate(1)
    with pytest.raises(ValidationError):
        assert num.validate(11)

    assert num.validate(6, strict=False) == 6
    assert num.validate(6.5, strict=False) == 6.5
    assert num.validate("6", strict=False) == 6
    assert num.validate(-6, strict=False) == -6
    assert num.validate(-6.5, strict=False) == -6.5

# Generated at 2022-06-22 05:50:05.722786
# Unit test for method validate of class Boolean
def test_Boolean_validate():
    f1 = Boolean()
    assert f1.validate('True') is True
    assert f1.validate('1') is True
    assert f1.validate('0') is False
    assert f1.validate('False') is False
    assert f1.validate('true') is True
    assert f1.validate('false') is False
    assert f1.validate('') is False
    assert f1.validate('none') is False
    assert f1.validate('null') is False
    assert f1.validate(1) is True
    assert f1.validate(0) is False
    assert f1.validate(True) is True
    assert f1.validate(False) is False
    assert f1.validate(None) is False

# Generated at 2022-06-22 05:50:16.200062
# Unit test for constructor of class Number
def test_Number():
    var1 = 12
    var2 = 13
    var3 = 14
    var4 = 15
    var5 = 16
    var6 = 17
    var7 = 18
    var8 = str(19)

    instance_Number = Number(
        title=var1, description=var2, default=var3, allow_null=var4,
        minimum=var5, maximum=var6, exclusive_minimum=var5, exclusive_maximum=var6,
        multiple_of=var7, precision=var8)

    assert instance_Number.title == var1
    assert instance_Number.description == var2
    assert instance_Number.default == var3
    assert instance_Number.allow_null == var4
    assert instance_Number.minimum == var5
    assert instance_Number.maximum == var6
    assert instance_Number.exclusive_

# Generated at 2022-06-22 05:50:18.026649
# Unit test for method validate of class Const
def test_Const_validate():
    const = Const(const = 1)
    assert const.validate(1) == 1



# Generated at 2022-06-22 05:50:29.845141
# Unit test for method serialize of class String
def test_String_serialize():
    assert String().serialize('date') == 'date'
    assert String(format='date').serialize(datetime.date(2020,5,5)) == '2020-05-05'
    assert String(format='datetime').serialize(datetime.datetime(2020,5,5,22,0,0)) == '2020-05-05T22:00:00'
    assert String(format='time').serialize(datetime.time(22,0,0)) == '22:00:00'
    assert String(multiple_of = 3, format ='hex').serialize(3424) == '8618'
    assert String(multiple_of = 3, format ='binary').serialize(3424) == '11010000011000'

# Generated at 2022-06-22 05:50:30.743816
# Unit test for constructor of class Date
def test_Date():
    with pytest.raises(AssertionError):
        Date(format="keyword")


# Generated at 2022-06-22 05:50:31.489110
# Unit test for constructor of class Text
def test_Text():
    assert Text(title="test", description="test", type="string") is not None


# Generated at 2022-06-22 05:50:42.778422
# Unit test for method validate of class Field
def test_Field_validate():
  from typesystem import Field
  from typesystem import core_fields as fields
  from typesystem import errors
  from typesystem import types
  from typesystem import validators

  class Person(types.Schema):
    name = fields.String(
        validators=(
            validators.Enforce(pattern="[A-Za-z ]+", flags=re.UNICODE),
            validators.Length(min_length=2, max_length=10),
        ),
        required=True,
    )
    age = fields.Integer(validators=(validators.Range(min_value=0, max_value=100),))

  person = Person()
  assert person.name.validate("Bob") == "Bob"
  assert person.name.validate("Bob", strict=True) == "Bob"

# Generated at 2022-06-22 05:51:17.527092
# Unit test for method validate of class Choice
def test_Choice_validate():
    choice = Choice(choices = {"a":1, "b": 2, "c":3})
    print(choice.choices)
    print(choice.validate("b"))

test_Choice_validate()



# Generated at 2022-06-22 05:51:19.681079
# Unit test for method validate of class Number
def test_Number_validate():
    class subclass(Number):
        numeric_type = float
    my_instance = subclass()
    my_instance.validate("20")


# Generated at 2022-06-22 05:51:22.544494
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    assert field.is_valid(3) == True
    assert field.is_valid(None) == True
    assert field.is_valid("hello") == True


# Generated at 2022-06-22 05:51:28.165672
# Unit test for constructor of class Object
def test_Object():
    obj = Object(
        properties={},
        pattern_properties={},
        additional_properties=True,
        property_names=False,
        min_properties=0,
        max_properties=0,
        required=[],
    )

    assert obj.properties == {}
    assert obj.pattern_properties == {}
    assert obj.additional_properties == True
    assert obj.property_names == False
    assert obj.min_properties == 0
    assert obj.max_properties == 0
    assert obj.required == []



# Generated at 2022-06-22 05:51:35.847104
# Unit test for constructor of class Choice
def test_Choice():
    choices = [("choice 1", "choice 1"), ("choice 2", "choice 2")]
    choice = Choice(name="choice", choices=choices)
    
    assert choice.choices == choices
    assert choice.name == "choice"

    # test inputs that are not allowed
    wrong_choices = [("choice 1", "choice 1"), ("choice 2", "choice 2", "choice 3")]
    try:
        Choice(choices=wrong_choices)
    except:
        pass
    # still the same input choices
    assert Choice(choices=choices).choices == choices



# Generated at 2022-06-22 05:51:37.218585
# Unit test for constructor of class Date
def test_Date():
    assert Date().format == 'date'


# Generated at 2022-06-22 05:51:47.655711
# Unit test for constructor of class Number
def test_Number():
    assert Number(minimum = 0.0, maximum = 1.0, exclusive_minimum = 0.2, exclusive_maximum = 0.8, precision = '0.1').maximum == 1.0
    assert Number(minimum = 0.0, maximum = 1.0, exclusive_minimum = 0.2, exclusive_maximum = 0.8, precision = '0.1').minimum == 0.0
    assert Number(minimum = 0.0, maximum = 1.0, exclusive_minimum = 0.2, exclusive_maximum = 0.8, precision = '0.1').precision == '0.1'
    assert Number(minimum = 0.0, maximum = 1.0, exclusive_minimum = 0.2, exclusive_maximum = 0.8, precision = '0.1').exclusive_minimum == 0.2

# Generated at 2022-06-22 05:51:49.752449
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    assert Decimal().serialize(decimal.Decimal(1)) == 1.0



# Generated at 2022-06-22 05:51:50.994331
# Unit test for method validate of class Any
def test_Any_validate():
    assert Any().validate('test') == 'test'

test_Any_validate()


# Generated at 2022-06-22 05:51:56.003959
# Unit test for method __or__ of class Field
def test_Field___or__():
	class FieldA(Field):
		pass
		
	class FieldB(Field):
		pass
		
	union = FieldA()|FieldB()
	assert union._creation_counter == 1
	assert union.any_of[0]._creation_counter < union.any_of[1]._creation_counter


# Generated at 2022-06-22 05:52:21.999626
# Unit test for method validate of class Choice
def test_Choice_validate():
    validate_schema = Choice(name="validate_schema")
    assert validate_schema.validate("post1") == "post1"
    assert validate_schema.validate("post2") == "post2"
    assert validate_schema.validate("") == None
    


# Generated at 2022-06-22 05:52:28.246642
# Unit test for constructor of class Number
def test_Number():
    # Create an instance x of class Number
    x = Number(minimum=0, maximum=10, exclusive_maximum=False, exclusive_minimum=True)
    # Create an instance of the expected class
    y = Number(minimum=0, maximum=10, exclusive_maximum=False, exclusive_minimum=True)
    # Assert that x and y are the same
    assert x == y


# Generated at 2022-06-22 05:52:30.031163
# Unit test for constructor of class Union
def test_Union():
    # code:
    schema = Union(
        any_of=[Integer(), Float(), Boolean(), Null()]
    )
    # test:
    assert schema.any_of == [Integer(), Float(), Boolean(), Null()]
    assert schema.allow_null == True



# Generated at 2022-06-22 05:52:36.545014
# Unit test for constructor of class Integer
def test_Integer():
    test_kargs = {}
    test_integer = Integer(default=5, **test_kargs)
    assert test_integer.get_default_value() == 5
    assert test_integer.validate(5) == 5
    try:
        test_integer.validate('5')
    except ValidationError:
        pass
    else:
        assert False
    try:
        test_integer.validate('abc')
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:52:48.556854
# Unit test for method validate of class String
def test_String_validate():
    name = String(title="name",description="Name",max_length=10,format="date")
    assert name.validate("2019-01-01") == "2019-01-01"
    assert name.validate("2019-01-01",strict=True) == "2019-01-01"
    assert name.validate("2019-1-1") == "2019-1-1"
    assert name.validate("2019-1-1",strict=True) == "2019-1-1"
    assert name.validate(None) == "2019-1-1"
    assert name.validate(None,strict=True) == "2019-1-1"
    name = String(title="name",description="Name",max_length=10,format="time")

# Generated at 2022-06-22 05:52:59.864081
# Unit test for method validate of class Union
def test_Union_validate():
    schema = Union(
        [Text(), Number(), Boolean(), NoneType()], allow_null=True,
    )
    assert schema.validate(None) is None
    assert schema.validate("test") == "test"
    assert schema.validate(123) == 123
    assert schema.validate(True) is True
    assert schema.validate(False) is False
    with pytest.raises(ValidationError):
        schema.validate({})
    with pytest.raises(ValidationError):
        schema.validate(["test"])
    with pytest.raises(ValidationError):
        schema.validate(1.2)
    with pytest.raises(ValidationError):
        schema.validate(4)



# Generated at 2022-06-22 05:53:04.484584
# Unit test for method serialize of class Array
def test_Array_serialize():
    arr = Array(String())
    arr.serialize(["str1", "str2", "str3"])
    print("String test of serialize in class Array passed")

    arr1 = Array(Integer())
    arr1.serialize([1, 2, 3, 4, 5])
    print("Integer test of serialize in class Array passed")

    arr2 = Array(Number())
    arr2.serialize([1.1, 2.2, 3.3, 4.4, 5.5])
    print("Number test of serialize in class Array passed")

    arr3 = Array(Boolean())
    arr3.serialize([True, False, True, False])
    print("Boolean test of serialize in class Array passed")

    arr4 = Array(Null())
    arr4.serialize([None, None, None, None])

# Generated at 2022-06-22 05:53:11.720844
# Unit test for method validate of class Object
def test_Object_validate():
    # create a new instance of an Object
    obj = Object()
    # create an invalid value
    invalid_value = 'test'

    # validate returns an error message
    error = obj.validate(invalid_value)

    # test if error message matches the validation error
    if(error == 'Must be an object.'):
        print('Test passed')
    else:
        print('Test failed')


test_Object_validate()


# Generated at 2022-06-22 05:53:23.146881
# Unit test for method validate of class Choice
def test_Choice_validate():
    field = Choice(
        choices=[
            ("geoloc", "Geo Loc"),
            ("country", "Country"),
            ("region", "Region"),
            ("city", "City"),
            ("zip", "Zip Code"),
            ("dma", "DMA"),
            ("metro", "Metro"),
            ("state", "State"),
            ("continent", "Continent")
        ],
        allow_null = True,
        required = True,
        trim_whitespace = False
        )
    value = "geoloc"
    result = field.validate(value)    
    assert result == "geoloc"

    value = "geolocs"
    with pytest.raises(ValidationError) as exception_info:
        validate = field.validate(value)

# Generated at 2022-06-22 05:53:25.171741
# Unit test for constructor of class Date
def test_Date():
    d = Date()
    assert d.format == "date"
    assert d.parse_format == "%Y-%m-%d"



# Generated at 2022-06-22 05:53:42.726248
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime(allow_null=True,default='',min_length=1,max_length=5)
    print(dt)
# end of unit test


# Generated at 2022-06-22 05:53:44.918479
# Unit test for constructor of class Float
def test_Float():
    f = Float()
    assert f.numeric_type is float



# Generated at 2022-06-22 05:53:55.225398
# Unit test for method validate of class Array
def test_Array_validate():
    
    #test for validate with items = None
    field = Array(min_items=3, max_items=3)
    field2 = Array(min_items=1, max_items=1)
    
    #items is not provided in the input
    assert field.validate([1,2,3]) == [1,2,3]
    
    with pytest.raises(ValidationError):
        field.validate([1,2,3,4])
    with pytest.raises(ValidationError):
        field.validate([1,2])
    with pytest.raises(ValidationError):
        field.validate([1,2,3,4,5])
        
    assert field2.validate([2]) == [2]
    with pytest.raises(ValidationError):
        field

# Generated at 2022-06-22 05:53:56.929774
# Unit test for method serialize of class Field
def test_Field_serialize():
    assert Field().serialize(123) == 123

# Generated at 2022-06-22 05:54:07.665028
# Unit test for constructor of class Number
def test_Number():
    field = Number()
    if field.allow_null == False:
        print("Allow_Null is False in Class Number")
    if field.allow_null == True:
        print("Allow_Null is True in Class Number")
    if field.errors == {'type': 'Must be a number.', 'null': 'May not be null.', 'integer': 'Must be an integer.', 'finite': 'Must be finite.', 'minimum': 'Must be greater than or equal to {minimum}.', 'exclusive_minimum': 'Must be greater than {exclusive_minimum}.', 'maximum': 'Must be less than or equal to {maximum}.', 'exclusive_maximum': 'Must be less than {exclusive_maximum}.', 'multiple_of': 'Must be a multiple of {multiple_of}.'}:
        print("Errors is correct")

# Generated at 2022-06-22 05:54:08.675938
# Unit test for constructor of class DateTime
def test_DateTime():
    dt = DateTime()
    assert dt.format == 'datetime'


# Generated at 2022-06-22 05:54:11.532003
# Unit test for method validate of class Union
def test_Union_validate():
    schema = cotyledon.Schema(Union([Boolean, Text]))
    a = schema.validate(True)
    assert isinstance(a, bool)
    b = schema.validate("True")
    assert isinstance(b, str)
    c = schema.validate(0)
    assert c is None


# Generated at 2022-06-22 05:54:19.899028
# Unit test for method validate of class String
def test_String_validate():
    class Employee(types.Document):
        name = fields.String(required=True, default=None)

    class Department(types.Document):
            name = fields.StringField(primary_key=True, required=True)
    
    e = Employee()
    e.name = 'Leos'


    dept = Department()
    dept.name = 'Sales'

    assert e.name == 'Leos'
    assert type(e.name) == str
    assert dept.name == 'Sales'
    assert type(dept.name) == str


# Generated at 2022-06-22 05:54:23.153478
# Unit test for constructor of class Time
def test_Time():
    time = Time()
    assert time.validate("23:00") == "23:00"
    assert time.validate("23:01") == "23:01"

    try:
        time.validate("23:07:03")
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-22 05:54:30.639510
# Unit test for constructor of class Float
def test_Float():
    '''
    This test case is to test the constructor of the class Float
    
    :return: the status of the test case.
    '''
    instance_Float1 = Float()
    instance_Float2 = Float(minimum=5)
    instance_Float3 = Float(maximum=10)
    instance_Float4 = Float(exclusive_minimum=5)
    instance_Float5 = Float(exclusive_maximum=10)
    instance_Float6 = Float(multiple_of=5)
    instance_Float7 = Float(multiple_of=5, minimum=10)

    assert float==instance_Float1.numeric_type 
    assert 5 == instance_Float2.minimum 
    assert 10 == instance_Float3.maximum 
    assert 5 == instance_Float4.exclusive_minimum 
    assert 10 == instance_Float5.exclusive_

# Generated at 2022-06-22 05:54:42.144217
# Unit test for method validate of class Choice
def test_Choice_validate():
    assert Choice(choices=["male", "female"]).validate("male") == "male"
    assert Choice(choices=["male", "female"]).validate("female") == "female"


# Generated at 2022-06-22 05:54:43.463769
# Unit test for method validate of class Const
def test_Const_validate():
    field = Const(const='LOL')
    assert field.validate(value='LOL') == 'LOL'


# Generated at 2022-06-22 05:54:45.134985
# Unit test for constructor of class Any
def test_Any():
    field = Any()
    print(field)



# Generated at 2022-06-22 05:54:53.717211
# Unit test for method validate of class String
def test_String_validate():
    test1 = String()
    assert test1.validate("") == ""
    test2 = String(trim_whitespace = False)
    assert test2.validate("") == ""
    test3 = String(allow_blank = True)
    assert test3.validate("") == ""
    test4 = String(allow_null = True)
    assert test4.validate(None) == None
    test5 = String(max_length = 5)
    assert test5.validate("asdf") == "asdf"
    assert test5.validate("asdfasdf") == "asdfa"
    test6 = String(min_length = 2)
    assert test6.validate("asdfasdf") == "asdfasdf"
    assert test6.validate("asdf") == "asdf"


# Generated at 2022-06-22 05:55:00.127706
# Unit test for constructor of class Array
def test_Array():
    prop = Array(items = "a",additional_items = False,
                min_items = None, max_items = None, unique_items = False)
    assert isinstance(prop.items, str)
    assert prop.additional_items == False
    assert prop.min_items == None 
    assert prop.max_items == None
    assert prop.unique_items == False


# Generated at 2022-06-22 05:55:06.596216
# Unit test for method validate of class Array
def test_Array_validate():
    errors = {
        "type": "Must be an array.",
        "null": "May not be null.",
        "empty": "Must not be empty.",
        "exact_items": "Must have {min_items} items.",
        "min_items": "Must have at least {min_items} items.",
        "max_items": "Must have no more than {max_items} items.",
        "additional_items": "May not contain additional items.",
        "unique_items": "Items must be unique.",
    }

    field = Array(
        items=None,
        additional_items=False,
        min_items=None,
        max_items=None,
        exact_items=None,
        unique_items=False,
        errors=errors,
    )
    field.validate([1,2,3])

# Generated at 2022-06-22 05:55:17.241494
# Unit test for method validate of class Choice
def test_Choice_validate():
    choices = Choice(choices=[("a", "A"), ("b", "B")])
    assert choices.validate("a") == "a"
    assert choices.validate("b") == "b"
    try:
        choices.validate("c")
        assert False
    except ValidationError:
        pass

    choices = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choices.validate("a") == "a"

    choices = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)
    assert choices.validate(None) == None

    choices = Choice(choices=[("a", "A"), ("b", "B")], allow_null=True)

# Generated at 2022-06-22 05:55:20.033956
# Unit test for method validate of class Field
def test_Field_validate():
    field = Field()
    assert field.validate(value=None) is None


# Generated at 2022-06-22 05:55:23.904850
# Unit test for method validate of class Any
def test_Any_validate():
    # create an instance
    field = Any()
    assert field.validate(True) == True



# Generated at 2022-06-22 05:55:33.866377
# Unit test for constructor of class DateTime
def test_DateTime():
    a = DateTime()
    assert a == String(format="datetime")
    assert a.validate("2018-05-23T00:00:00") == "2018-05-23T00:00:00"
    assert a.validate("2018-05-23T00:00:00Z") == "2018-05-23T00:00:00Z"
    assert a.validate("2018-05-23T00:00:00.0Z") == "2018-05-23T00:00:00.0Z"
    assert a.validate("2018-05-23T00:00:00+00:00") == "2018-05-23T00:00:00+00:00"

# Generated at 2022-06-22 05:55:46.191083
# Unit test for constructor of class Date
def test_Date():
    d = Date()
    assert isinstance(d, String)
    assert d.format == "date"


# Generated at 2022-06-22 05:55:48.653617
# Unit test for method __or__ of class Field
def test_Field___or__():
  pass # TODO


FIELD_TYPES: typing.Dict[typing.Type, typing.Type] = {}



# Generated at 2022-06-22 05:55:52.437191
# Unit test for constructor of class Field
def test_Field():
    import typesystem
    Field1 = typesystem.Field(title =  "This is a field", description = "This is a description", default = "Hi", allow_null = True)
    assert(Field1.default == "Hi")
    assert(Field1.title == "This is a field")
    assert(Field1.description == "This is a description")
    assert(Field1.allow_null == True)


# Generated at 2022-06-22 05:55:56.542876
# Unit test for method serialize of class Decimal
def test_Decimal_serialize():
    a = Decimal()
    assert(a.serialize(None) == None)
    assert(a.serialize(5) == 5.0)
    assert(a.serialize("5.0") == 5.0)
