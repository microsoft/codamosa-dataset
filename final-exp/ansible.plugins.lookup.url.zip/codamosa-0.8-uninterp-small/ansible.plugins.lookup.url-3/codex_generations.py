

# Generated at 2022-06-25 11:37:49.481170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'var_options': {}, 'direct': {'_terms': ['', '', ''], 'validate_certs': 'True', 'split_lines': 'True', 'use_proxy': 'True', 'username': '', 'password': '', 'headers': '{}', 'force': 'False', 'timeout': '10', 'http_agent': 'ansible-httpget', 'force_basic_auth': 'False', 'follow_redirects': 'urllib2', 'use_gssapi': 'False', 'unix_socket': '', 'ca_path': '', 'unredirected_headers': ''}}, direct=None, var_options=None)
    lookup_module_0.run(['', '', ''], variables={})

# Generated at 2022-06-25 11:37:55.764820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # url_0 = 'https://github.com/gremlin.keys'

    import os

    print(os.path.dirname(__file__))
    lookup_module_0 = LookupModule()

    # sudo pip install mock
    # sudo pip install pytest
    # sudo pip install pytest-cov
    # sudo pip install coveralls
    # py.test --cov lookup_plugins/url.py
    # coveralls [--verbose]

# Generated at 2022-06-25 11:38:06.319402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_term_0 = ["https://github.com/gremlin.keys", "https://ip-ranges.amazonaws.com/ip-ranges.json"]
    lookup_kwargs_0 = {
        "force": "True",
        "validate_certs": "True",
        "split_lines": "True",
        "follow_redirects": "urllib2",
        "use_gssapi": "False",
        "force_basic_auth": "True",
        "http_agent": "ansible-httpget",
        "use_proxy": "False",
        "password": "hunter2",
        "username": "bob",
        "timeout": "10"
    }
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:38:10.423454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # trivial test with nothing to look for
    assert not LookupModule().run(terms=[], variables=['cache_plugin'])

    # test with a real lookup
    assert LookupModule().run(terms=['https://github.com/gremlin.keys'], variables=['cache_plugin'])

# Generated at 2022-06-25 11:38:22.201460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['https://github.com/gremlin.keys']
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:38:31.602168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('https://github.com/gremlin.keys', {'ansible_lookup_url_force': True})
    lookup_module_0.run('https://ip-ranges.amazonaws.com/ip-ranges.json', {'ansible_lookup_url_force': True})
    lookup_module_0.run('https://some.private.site.com/file.txt', {'ansible_lookup_url_force': True})
    lookup_module_0.run('https://some.private.site.com/file.txt', {'ansible_lookup_url_force': True})

# Generated at 2022-06-25 11:38:34.769008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = 'https://github.com/gremlin.keys'
  kwargs = {}
  result = LookupModule.run(terms,**kwargs)
  assert result is not None, 'Expected not None, but result was None!'


# Generated at 2022-06-25 11:38:43.950662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms_0 = 'http://docs.ansible.com/ansible/latest/modules/list_of_all_modules.html'
    variables = 'defaults/main.yml'
    ret_1 = lookup_module_0.run(terms_0, variables)

# Generated at 2022-06-25 11:38:49.103665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    #Verify that AnsibleError is raised for terms of incorrect type
    try:
        test_terms_1 = ''
        test_variables_1 = None
        lookup_module_1.run(test_terms_1, test_variables_1)
    except AnsibleError as e:
        assert "with_sequence expects a list" in to_native(e)
    except Exception as e:
        assert "Unexpected Exception raised" == to_native(e)

    try:
        test_terms_2 = {}
        test_variables_2 = None
        lookup_module_1.run(test_terms_2, test_variables_2)
    except AnsibleError as e:
        assert "with_sequence expects a list" in to_native(e)

# Generated at 2022-06-25 11:38:57.379056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = [
        ['https://gist.githubusercontent.com/grant-hutchins/f629e49f1b60e7f9c6a8/raw/9dd17f581889d93e689e982dbcceaf1aaf0341a3/fail_gist.txt'],
        ['https://gist.github.com/grant-hutchins/f629e49f1b60e7f9c6a8.git']
    ]

    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=params[0])

    with pytest.raises(AnsibleError):
        lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:39:07.844746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Check if the result is correct
    assert lookup_module_1.run(terms='dummy', variables='dummy') == []

# Generated at 2022-06-25 11:39:12.165516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
        print("Testing test_case_0 OK")
    except AssertionError as e:
        print("Testing test_case_0 FAILED: " + str(e))

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:20.637363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test cases for function run of class LookupModule
    """
    lookup_module_0 = LookupModule()
    terms_0 = ['http://www.test.com']
    ret = lookup_module_0.run(terms_0)
    assert True == isinstance(ret, list)
    assert len(ret) == 1
    assert True == isinstance(ret[0], str)
    assert len(ret[0]) == 0

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:22.191423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    lookup_module_run.run('https://bcoca.com')


# Generated at 2022-06-25 11:39:31.264001
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test cases for testing run method
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError
    from six.moves.urllib.error import HTTPError, URLError

    # Test case 0
    test_term_0 = "https://www.github.com/ansible/ansible/blob/devel/CHANGELOG.md"


# Generated at 2022-06-25 11:39:33.509247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup
    lookup_module = ansible.plugins.lookup.LookupModule()
    lookup_module = LookupModule()
    lookup_module.run()



# Generated at 2022-06-25 11:39:44.280336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError
    import pytest
    lookup_module_1 = LookupModule()
    terms = ["https://github.com/gremlin.keys"]
    variables = None
    kwargs = {"_ansible_check_mode":False,"_ansible_debug":False,"_ansible_diff":False,"_ansible_keep_remote_files":False,"_ansible_no_log":False,"_ansible_remote_tmp":"/tmp/ansible-tmp-1518151374.11-29268527369528","_ansible_selinux_special_fs":["fuse","nfs","vboxsf","ramfs"]}


# Generated at 2022-06-25 11:39:45.749736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

test_case_0()

# Generated at 2022-06-25 11:39:50.719333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    if lookup_module_1.run(['https://github.com/gremlin.keys']) is None:
        raise AssertionError

if __name__ == "__main__":
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.runmodule(argv=argv, exit=False)

# Generated at 2022-06-25 11:39:59.158633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:40:25.901023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        'https://pypi.org/project/requests-kerberos/json',
        'https://pypi.org/project/requests-gssapi/json',
    ]
    variables_1 = {}

# Generated at 2022-06-25 11:40:35.807059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u"https://raw.githubusercontent.com/ansible/ansible/stable-2.7/lib/ansible/plugins/lookup/facts.py",
             u"https://raw.githubusercontent.com/ansible/ansible/stable-2.7/lib/ansible/plugins/lookup/file.py", u"https://raw.githubusercontent.com/ansible/ansible/stable-2.7/lib/ansible/plugins/lookup/url.py"],
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:40:38.912424
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Call the API for this method
    response = LookupModule.run()

    # Some assertions of the correctness of the API response
    assert isinstance(response, tuple)
    return response

# Generated at 2022-06-25 11:40:47.310707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    from ansible.utils.display import Display
    import os

    # set display_defaults()
    Display().display_defaults()
    #######################################################
    # Beginning of paramaterized tests for method run
    #######################################################
    # Mock parameters
    terms = [
        "https://raw.githubusercontent.com/ansible/ansible/devel/.editorconfig"
    ]
    variables = None
    # invoke method
    result = lookup_module_0.run(terms, variables=variables)
    # assert the return type
    assert isinstance(result, list)
    # assert the returned value
    assert "root = true" in result

    # Mock parameters

# Generated at 2022-06-25 11:40:51.160040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    url = 'https://ip-ranges.amazonaws.com/ip-ranges.json'
    lookup_module = LookupModule()
    result = lookup_module.run(terms=url)
    print(result)


if __name__ == '__main__':
    print('test case 0')
    test_case_0()
    print('test lookup module')
    test_LookupModule_run()

# Generated at 2022-06-25 11:40:53.111661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:40:57.381944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("In test_LookupModule_run")

# Unit test method for run

# Generated at 2022-06-25 11:41:03.907394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['https://github.com/gremlin.keys']
    ret_0 = lookup_module_0.run(terms_0)
    print(ret_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:41:05.949112
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:41:06.846617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:41:27.547203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_0.run("url")


# Generated at 2022-06-25 11:41:31.456781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('http://www.example.com')


# Generated at 2022-06-25 11:41:38.631243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0, lookup_module_0, lookup_module_0}
    dict_0 = {var_0: set_0, lookup_module_0: set_0, lookup_module_0: set_0, lookup_module_0: set_0}
    var_1 = lookup_run(set_0)
    var_2 = lookup_run(dict_0)
    var_3 = lookup_run(var_0)


# Generated at 2022-06-25 11:41:47.969086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs_0 = {'url_username': var_30, 'url_password': var_15, 'force_basic_auth': var_9, 'timeout': var_14, 'validate_certs': var_11, 'use_proxy': var_8, 'follow_redirects': var_31, 'http_agent': var_32, 'use_gssapi': var_33, 'unix_socket': var_10, 'ca_path': var_34, 'unredirected_headers': var_35, 'headers': var_36}
    var_37 = [var_12]
    var_38 = lookup_run(var_37)

# Generated at 2022-06-25 11:41:50.822236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert type(lookup_module_0) == LookupModule



# Generated at 2022-06-25 11:42:00.448736
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:42:07.677109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0, lookup_module_0}
    dict_0 = {lookup_module_0: set_0}
    var_0 = lookup_run(dict_0)
    var_1 = lookup_run(lookup_module_0)




# Generated at 2022-06-25 11:42:10.954106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0)
    var_1 = lookup_module_0.run(lookup_module_0)


# Generated at 2022-06-25 11:42:19.801902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms = ['https://raw.githubusercontent.com/ansible/ansible/devel/test/test_lookup_plugin/files/gremlin.keys', 'https://raw.githubusercontent.com/ansible/ansible/devel/test/test_lookup_plugin/files/gremlin.keys'], variables = {'ansible_lookup_url_agent': 'ansible-httpget', 'ansible_lookup_url_follow_redirects': 'urllib2', 'ansible_lookup_url_force': True, 'ansible_lookup_url_timeout': 10.0})
    assert var_1 == 'ansible-httpget'


# Generated at 2022-06-25 11:42:30.812295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'ansible.cfg', 'https://raw.githubusercontent.com/ansible/ansible/devel/examples/ansible.cfg', 'https://raw.githubusercontent.com/ansible/ansible/devel/CHANGELOG' ]
    # Direct testing of lookup return values - with split_lines as default True
    # Capture return values

# Generated at 2022-06-25 11:43:10.418472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0)
    var_1 = lookup_module_0.run(lookup_module_0)
    var_2 = lookup_module_0.run(lookup_module_0)


# Generated at 2022-06-25 11:43:15.962342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {lookup_module_0, lookup_module_0, lookup_module_0}
    variables_0 = {lookup_module_0: lookup_module_0}
    kwargs_0 = {lookup_module_0: lookup_module_0}
    var_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)



# Generated at 2022-06-25 11:43:18.209408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Invalid function parameters
    with pytest.raises(TypeError):
        terms = None
        variables = None
        lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:43:23.965003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0, lookup_module_0}
    dict_0 = {lookup_module_0: set_0}
    var_0 = lookup_run(dict_0)
    var_1 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:43:31.873359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    lookup_module_0 = LookupModule()
    lookup_module_0.lookup_basedir = b'lookup_basedir'
    lookup_module_0.set_options(var_options={lookup_module_0: lookup_module_0}, direct={lookup_module_0: lookup_module_0})
    lookup_module_0.plugin_basedir = b'plugin_basedir'
    var_0 = [lookup_module_0]

# Generated at 2022-06-25 11:43:38.460237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case = lookup_module_0
    assertions = {}
    try:
        test_case.run(assertions)
    except AssertionError as e:
        print('AssertionError: ', e)
        assert False
    finally:
        print('test_LookupModule_run done')



# Generated at 2022-06-25 11:43:44.373127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    look_up_base_0 = LookupModule(None)
    lookup_module_0 = look_up_base_0
    terms_0 = ["terms", "terms"]
    variables = {lookup_module_0: terms_0}
    lookup_module_0.run(terms_0, variables)
    dict_0 = {lookup_module_0: variables}
    var_0 = look_up_base_0.run(terms_0, dict_0)
    assert var_0 == var_0

# Generated at 2022-06-25 11:43:47.152530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run({lookup_module_0}, {lookup_module_0: lookup_module_0})
    var_1 = lookup_module_0.run(lookup_module_0, {lookup_module_0: lookup_module_0})


# Generated at 2022-06-25 11:43:51.564582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {lookup_module_0: lookup_module_0}
    # Call LookupModule::run
    run_0 = lookup_module_0.run(dict_0)



# Generated at 2022-06-25 11:44:00.285118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()
    get_option_0 = LookupModule().get_option()

# Generated at 2022-06-25 11:45:19.013166
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'https://github.com/gremlin.keys',
    ]
    variables = None
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0, lookup_module_0}
    dict_0 = {lookup_module_0: set_0}
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 11:45:29.503176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # cleanup
    try:
        import os
        os.remove("test_LookupModule_run.test")
    except Exception:
        pass

    # setup
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-25 11:45:38.237381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.urls import open_url as open_url_module
    import requests
    import ssl
    lookup_module = LookupModule()
    lookup_module.get_option = lambda self, x: getattr(self, x)
    http_agent = 'ansible-httpget'
    force = False
    split_lines = True
    use_proxy = True
    validate_certs = True
    username = 'bob'
    password = 'hunter2'
    headers = {'header1': 'value1', 'header2': 'value2'}
    timeout = 10.0
    force_basic_auth = False
    follow_redirects = 'urllib2'
    use_gssapi = False
    unix_socket = None
    ca_path = None
    unredirect

# Generated at 2022-06-25 11:45:48.489172
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # default
    lookup_module_0 = LookupModule()
    set_0 = {lookup_module_0, lookup_module_0}
    dict_0 = {lookup_module_0: set_0}
    terms_0 = dict_0
    variables_0 = dict_0
    kwargs_0 = {'variables': variables_0, 'terms': terms_0}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == set_0
    # default
    lookup_module_1 = LookupModule()
    set_1 = {lookup_module_1, lookup_module_1}
    dict_1 = {lookup_module_1: set_1}
    terms_1 = dict_1
    variables_1 = dict_1

# Generated at 2022-06-25 11:45:51.204986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = test_case_0()
    # assert var_0 == expected_var_0
    var_0 = test_case_0()
    # assert var_0 == expected_var_0
    var_0 = test_case_0()
    # assert var_0 == expected_var_0


# Generated at 2022-06-25 11:45:55.138224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == {}, "Assertion failed"
    var_1 = lookup_module_0.run()
    assert var_1 == {}, "Assertion failed"
    var_2 = lookup_module_0.run()
    assert var_2 == {}, "Assertion failed"
    var_3 = lookup_module_0.run()
    assert var_3 == {}, "Assertion failed"


# Generated at 2022-06-25 11:46:04.385629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None
    assert module_0.run(module_0) == None

# Generated at 2022-06-25 11:46:07.981425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run()


# Generated at 2022-06-25 11:46:13.727985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [lookup_module_0]
    res_0 = lookup_module_0.run(term_0)
    term_1 = [lookup_module_0]
    res_1 = lookup_module_0.run(term_1)
    term_2 = [lookup_module_0]
    res_2 = lookup_module_0.run(term_2)
    term_3 = [lookup_module_0]
    res_3 = lookup_module_0.run(term_3)
    term_4 = [res_0]
    res_4 = lookup_module_0.run(term_4)

# Generated at 2022-06-25 11:46:15.350898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(set())
    var_1 = lookup_run(lookup_module_0)
    return var_0 == var_1
