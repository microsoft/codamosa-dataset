

# Generated at 2022-06-25 11:37:51.113231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:37:55.086233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as e:
        lookup_module_0.run()
    assert str(e.value) == "Received HTTP error for : HTTP Error 500: Internal Server Error"


# Generated at 2022-06-25 11:38:05.981168
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:38:13.972358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    parameters = []
    term_0 = "https://github.com/gremlin.keys"
    parameters.append(term_0)
    term_1 = "https://ip-ranges.amazonaws.com/ip-ranges.json"
    parameters.append(term_1)
    term_2 = "https://some.private.site.com/file.txt"
    parameters.append(term_2)
    term_3 = "https://some.private.site.com/file.txt"
    parameters.append(term_3)
    term_4 = "https://some.private.site.com/api/service"
    parameters.append(term_4)

# Generated at 2022-06-25 11:38:17.109932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["https://google.com"]
    assert lookup_module_0.run(terms) == "https://google.com"

# Generated at 2022-06-25 11:38:20.744312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['http://192.168.121.171:8000/index.html']

    try:
        lookup_module.run(terms)
    except AnsibleError as e:
        print(e)

# Generated at 2022-06-25 11:38:28.998891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare the parameters
    terms = [
        {
            "name": "data",
            "term": "data"
        }
    ]
    variables = None

# Generated at 2022-06-25 11:38:40.297577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result_url_0 = lookup_module_0.run('https://github.com/gremlin.keys')
    result_url_1 = lookup_module_0.run('https://ip-ranges.amazonaws.com/ip-ranges.json', split_lines=False)
    result_url_2 = lookup_module_0.run('https://some.private.site.com/file.txt', url_username='bob', url_password='hunter2')
    result_url_3 = lookup_module_0.run('https://some.private.site.com/file.txt', username='bob', password='hunter2', force_basic_auth='True')

# Generated at 2022-06-25 11:38:46.824387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Pass a string as first parameter
    lookup_module_0 = LookupModule()
    terms_str_0 = 'https://github.com/gremlin.keys'
    variable_0 = {}
    variable_0['validate_certs'] = True
    variable_0['split_lines'] = True
    variable_0['use_proxy'] = True
    variable_0['username'] = None
    variable_0['password'] = None
    variable_0['headers'] = {}
    variable_0['force'] = False
    variable_0['timeout'] = 10
    variable_0['http_agent'] = 'ansible-httpget'
    variable_0['force_basic_auth'] = False
    variable_0['follow_redirects'] = 'urllib2'

# Generated at 2022-06-25 11:38:53.014149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['https://github.com/gremlin.keys']
    try:
        lookup_module_1.run(terms_1, variables=None, **{})
    except Exception as e:
        print(e.args)

# Generated at 2022-06-25 11:39:04.369383
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    assert lookup_module_0.run(terms_0) == []

# Generated at 2022-06-25 11:39:07.238264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    lookup_module_obj.run(terms=['http://www.example.com'])

# Generated at 2022-06-25 11:39:08.630808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #  Tests so that run executes sucessfully
    lookup_module_0.run(terms=[])


# Generated at 2022-06-25 11:39:13.767871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True == False # TODO: implement your test here


# Generated at 2022-06-25 11:39:14.986759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:39:19.934694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == []



# Generated at 2022-06-25 11:39:21.106265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('http://www.google.com')

# Generated at 2022-06-25 11:39:29.855145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {
        u'use_proxy': True,
        u'timeout': 10.0,
        u'use_gssapi': False,
        u'validate_certs': True,
        u'force': False,
        u'http_agent': u'ansible-httpget',
        u'force_basic_auth': False,
        u'follow_redirects': u'urllib2',
    }
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 11:39:40.528420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['https://github.com/gremlin.keys']
    variables_1 = None
    kwargs_1 = {}
    assert isinstance(lookup_module_1.run( terms_1, variables_1, **kwargs_1), list)
    lookup_module_2 = LookupModule()
    terms_2 = ['https://ip-ranges.amazonaws.com/ip-ranges.json']
    variables_2 = None
    kwargs_2 = {}
    assert isinstance(lookup_module_2.run( terms_2, variables_2, **kwargs_2), list)
    lookup_module_3 = LookupModule()
    terms_3 = ['https://some.private.site.com/file.txt']
    variables_3

# Generated at 2022-06-25 11:39:42.911510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=terms, variables=variables, **kwargs)


# Generated at 2022-06-25 11:39:55.479626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1374.37
    str_0 = 'X-Forwarded-Proto'
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_0.run(float_0)


# Generated at 2022-06-25 11:40:01.499456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)


'''
Need to add a second variable to this test because we are using
the variable to determine a test case.
'''

# Generated at 2022-06-25 11:40:03.026082
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:40:03.652297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run(float_0)

# Generated at 2022-06-25 11:40:04.516278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == True

# Generated at 2022-06-25 11:40:09.692674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:40:15.555836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    tuple_0 = None
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)



# Generated at 2022-06-25 11:40:25.981604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # var_0 is the term for which the url is looked up.
    str_0 = None
    var_0 = str_0
    # var_1 is the dict containing the return value of connection.getheaders()
    dict_0 = {}
    var_1 = dict_0
    # var_2 is the dict containing the return value of connection.__init__()
    dict_1 = {}
    var_2 = dict_1
    # The constructor has the argument terms which is a list of strings
    list_0 = [var_0]
    float_0 = -86446.9
    str_1 = None
    tuple_0 = (str_1,)
    lookup_module_0 = LookupModule(tuple_0)
    var_3 = lookup_module_0.run(list_0, float_0)



# Generated at 2022-06-25 11:40:30.453026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1804.5077
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)


test_LookupModule_run()

# Generated at 2022-06-25 11:40:32.063475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:40:54.694985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)
    return (var_0)

# Generated at 2022-06-25 11:41:06.226122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run('https://github.com/gremlin.keys')
    assert len(var_0) == 1

# Generated at 2022-06-25 11:41:10.391636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    try:
        assert lookup_module_0.run(float_0)
    except Exception as exception_0:
        assert isinstance(exception_0, AnsibleError) == True

# Generated at 2022-06-25 11:41:15.394521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule(var_0)
        lookup_module_0.run(var_1)
    except Exception as e:
        print(e)
    # Validate exception raised and message string
    var_2 = lookup_module_0.run(var_1)
    assert var_2 == var_3


# Generated at 2022-06-25 11:41:25.303492
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule(tuple_0)
    lookup_module_1 = LookupModule(tuple_0)
    lookup_module_2 = LookupModule(tuple_0)
    lookup_module_3 = LookupModule(tuple_0)
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()

    lookup_module_2._run(float_0, float_1, float_2)
    lookup_module_3._run(float_3, float_4, float_5)
    lookup_module_0._run(float_6, float_7, float_0)
   

# Generated at 2022-06-25 11:41:38.580300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['validate_certs'] = test_case_0()
    dict_0['username'] = test_case_0()
    dict_0['password'] = test_case_0()
    dict_0['headers'] = test_case_0()
    dict_0['force'] = test_case_0()
    dict_0['timeout'] = test_case_0()
    dict_0['http_agent'] = test_case_0()
    dict_0['force_basic_auth'] = test_case_0()
    dict_0['follow_redirects'] = test_case_0()
    dict_0['use_gssapi'] = test_case_0()
    dict_0['unix_socket'] = test_case_0()

# Generated at 2022-06-25 11:41:45.263971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -886.97
    str_0 = "K91G9C&-M[8?6dCDZ93G"
    str_1 = "Ylf?o"
    tuple_0 = (str_1, str_0)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run(float_0, variables=None, **kwargs)
    assert var_0 == var_0, "Parameter 'var_0' has the wrong value."


# Generated at 2022-06-25 11:41:47.673752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -9.17915
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:41:50.103348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = None
    test_case_0()


# Generated at 2022-06-25 11:41:51.673965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:42:25.565040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(['url'])
    var_0 = lookup_module_0.run()
    assert var_0 == ['url'], "Expected [\'url\'], got " + str(var_0)


# Generated at 2022-06-25 11:42:31.209662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # get_option(self, varname)
    str_0 = None
    dict_0 = {"headers": str_0}
    tuple_0 = (str_0, dict_0)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_module_0.run()
    # TODO: add code to test returned value


# Generated at 2022-06-25 11:42:34.381447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:42:37.308344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    #str_0 = lookup_module_0.run(None, None, None, None)
    #assert str_0 == None


# Generated at 2022-06-25 11:42:40.680829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -0.001344
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:42:43.410155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {"ansible_lookup_url_force": False}
    t = type(vars)()
    l = LookupModule(t)
    assert l.run() == []

# Generated at 2022-06-25 11:42:47.150105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tuple_0 = (None,)
    lookup_module_0 = LookupModule(tuple_0)
    float_0 = -2187.843
    str_0 = None
    tuple_1 = (str_0,)
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:42:49.774544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)
    assert var_0 == None

# Generated at 2022-06-25 11:42:54.841087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    float_0 = -2187.843
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_1 = LookupModule(tuple_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['url_lookup'] = dict_0
    dict_1['url_lookup']['cache_control_no_cache'] = True
    float_1 = -2187.843
    float_2 = -2187.843
    float_3 = -2187.843
    float_4 = -2187.843
    float_5 = -2187.843
    float_

# Generated at 2022-06-25 11:42:58.094907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = -2187.843
    float_1 = float_0
    tuple_0 = (float_1,)
    float_2 = float_0
    float_3 = float_2
    float_4 = float_3
    str_0 = str(float_4)
    tuple_1 = (str_0,)
    lookup_module_0.run(tuple_0, tuple_1)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:44:18.533372
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # noinspection PyTypeChecker
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)

    # noinspection PyCallingNonCallable
    tuple_1 = lookup_module_0.run(float_0)

    assert tuple_1 == var_0

# Generated at 2022-06-25 11:44:23.494593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule((None,))
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    list_0 = [dict_0]
    list_0 = [dict_0]
    tuple_0 = (list_0, list_0, dict_0, list_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    var_0 = lookup_module_0.run(tuple_0, tuple_0)
    dict_1 = dict()
    dict_1 = dict()
    dict_1 = dict()
    dict_1 = dict()
    dict_1

# Generated at 2022-06-25 11:44:28.240383
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    test_case_1()

    # Test case 2
    #test_case_2()

    # Test case 3
    test_case_3()


test_LookupModule_run()

# Generated at 2022-06-25 11:44:29.216824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:44:31.448854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 11:44:36.905045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -2187.843
    # TODO: Generate a random str and list
    str_0 = None
    list_0 = [str_0, str_0, str_0]
    str_1 = None
    # TODO: Generate a random dict
    dict_0 = {}
    tuple_0 = (str_1,)
    lookup_module_0 = LookupModule(tuple_0)
    var_0 = lookup_run(float_0)
    lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:44:40.852378
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_case_0()

# Generated at 2022-06-25 11:44:44.661040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = -2187.843
    var_1 = None
    var_2 = (var_1,)
    lookup_module_0 = LookupModule(var_2)
    var_3 = lookup_run(var_0)


# Generated at 2022-06-25 11:44:49.073085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {
        'validate_certs': True,
        'wantlist': True
    }
    LookupModule(terms)
    return True


# Generated at 2022-06-25 11:44:53.884148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 5645.0
    str_0 = None
    tuple_0 = (str_0,)
    lookup_module_0 = LookupModule(tuple_0)
    str_1 = ''
    lookup_module_0.run(float_0)
