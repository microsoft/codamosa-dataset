

# Generated at 2022-06-25 11:37:49.514649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.get_option('validate_certs')
    lookup_module_0.get_option('use_proxy')
    lookup_module_0.get_option('username')
    lookup_module_0.get_option('password')
    lookup_module_0.get_option('headers')
    lookup_module_0.get_option('force')
    lookup_module_0.get_option('timeout')
    lookup_module_0.get_option('http_agent')
    lookup_module_0.get_option('force_basic_auth')
    lookup_module_0.get_option('follow_redirects')
    lookup_module_0.get_

# Generated at 2022-06-25 11:37:51.376457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_0.run()

# Generated at 2022-06-25 11:37:54.643536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=[], variables=None, **dict())
    except Exception as e:
        pass

# Generated at 2022-06-25 11:38:03.074205
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    terms_0 = []
    variables_0 = {}
    kwargs_0 = {u'validate_certs': True}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 == []

    terms_1 = []
    variables_1 = {u'ansible_lookup_url_ca_path': u'/etc/ssl/certs/ca-certificates.crt'}
    kwargs_1 = {u'validate_certs': True}
    ret_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    assert ret_1 == []

    terms_2 = []

# Generated at 2022-06-25 11:38:13.249972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:38:23.218839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.urls
    ansible.module_utils.urls.open_url = mock_open_url
    test_term_0 = 'https://github.com/gremlin.keys'
    test_terms_0 = [test_term_0]
    test_kwargs_0 = {}
    result_0 = lookup_module_0.run(test_terms_0, **test_kwargs_0)
    assert result_0 == ['a', 'b', 'c', 'd']
    test_kwargs_1 = {'force': True}
    result_1 = lookup_module_0.run(test_terms_0, **test_kwargs_1)
    assert result_1 == []


# Generated at 2022-06-25 11:38:32.169497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Testing with a None value for parameter terms
    try:
        lookup_module_0.run(None, None)
    # Catching and printing the exception raised by the call to method run
    except Exception as exception_0:
        print('Exception raised: {0}'.format(exception_0))
    else:
        print('Expected Exception not raised')

    # Testing with a None value for parameter variables
    try:
        lookup_module_0.run(['git://github.com/ansible/ansible-modules-extras.git'], None)
    # Catching and printing the exception raised by the call to method run
    except Exception as exception_0:
        print('Exception raised: {0}'.format(exception_0))

# Generated at 2022-06-25 11:38:37.074602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_option = MagicMock(return_value=True)
    open_url = Mock()
    lookup_module.run("test")
    open_url.side_effect = URLError("Test Error")
    lookup_module.run("test")

# Generated at 2022-06-25 11:38:42.918139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
# Parameters:
# terms: 'https://github.com/gremlin.keys'
    terms = 'https://github.com/gremlin.keys'
# variables: None
    variables = None
# kwargs: {'wantlist': True, 'split_lines': True}
    kwargs = {'wantlist': True, 'split_lines': True}
# We have to pass in an instance of the Display class
    lookup_module.display = Display()

    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:38:44.771610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    res = lookup_module_1.run(['https://ip-ranges.amazonaws.com/ip-ranges.json'], {})

# Generated at 2022-06-25 11:38:53.615482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:39:02.609486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # unit test case with version_added
    test_term_0 = "https://github.com/gremlin.keys"
    test_dict_0 = {}
    test_kwargs_0 = { 'wantlist': True }
    # unit test case without version_added
    lookup_module_0.set_options(var_options=test_dict_0, direct=test_kwargs_0)
    ret_val_0 = lookup_module_0.run(terms=test_term_0, variables=test_dict_0, **test_kwargs_0)
    assert ret_val_0


# Generated at 2022-06-25 11:39:13.969212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Read from URL
    terms = ["https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/url.py",]
    variables = None
    kwargs = {"validate_certs": True, "split_lines": True, "use_proxy": True, "username": None, "password": None, "headers": {}, "force": False, "timeout": 10, "http_agent": "ansible-httpget", "force_basic_auth": False, "follow_redirects": "urllib2", "use_gssapi": False, "unix_socket": None, "ca_path": None, "unredirected_headers": None}


# Generated at 2022-06-25 11:39:16.685795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([
        'http://example.com', # param 0
        'http://example.com' # param 1
    ])

# Generated at 2022-06-25 11:39:29.761153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    testobj = [
        [
            "https://github.com/gremlin.keys",
            {
                "tags": True,
                "validate_certs": True,
                "use_proxy": True,
                "http_agent": "ansible-httpget",
                "timeout": 10,
                "follow_redirects": "urllib2",
                "force": False,
                "use_gssapi": False,
                "force_basic_auth": False,
                "headers": {}
            }
        ]
    ]
    result = lookup_module_0.run(**testobj[0][1])

# Generated at 2022-06-25 11:39:40.502039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:39:49.052625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['https://ip-ranges.amazonaws.com/ip-ranges.json']
    variables_0 = None
    kwargs_0 = {u'force': False, u'use_proxy': True, u'username': None, u'validate_certs': True, u'http_agent': u'ansible-httpget', u'split_lines': True, u'follow_redirects': u'urllib2', u'url_password': None, u'ca_path': None, u'unix_socket': None, u'force_basic_auth': False, u'headers': {}, u'unredirected_headers': None, u'url_username': None, u'timeout': 10, u'use_gssapi': False}


# Generated at 2022-06-25 11:39:54.667873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'http_agent': 'ansible-httpget', 'timeout': 10, 'validate_certs': True, 'split_lines': True, 'follow_redirects': 'urllib2'})
    lookup_module.run(['https://ip-ranges.amazonaws.com/ip-ranges.json'])
    lookup_module.run(['https://github.com/gremlin.keys'])

# Generated at 2022-06-25 11:40:02.813995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['https://github.com/gremlin.keys']
    variables = None
    wantedlist = True
    kwargs = {'wantlist': wantedlist}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:40:11.346498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:40:21.511669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(str_0) == []

# Generated at 2022-06-25 11:40:28.546043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    import os
    import tempfile
    import pytest
    from ansible.module_utils.connection import Connection
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six.moves.urllib.parse import urljoin
    import ansible.module_utils.urls
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display


# Generated at 2022-06-25 11:40:29.518022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run()


# Generated at 2022-06-25 11:40:30.143977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False)

# Generated at 2022-06-25 11:40:35.500225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'url'
    str_1 = 'this is the content of the file'

    # the first run should return the content of the file
    assert lookup_module_0.run(terms=str_0) == str_1

    # the second run should return a 304 status code, but the content should still be the same
    assert lookup_module_0.run(terms=str_0) == str_1

# Generated at 2022-06-25 11:40:45.925701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setting up object
    lookup_module_0 = LookupModule()

    # setting up test data
    str_0 = 'docuri'
    kwargs_0 = {
        'use_proxy': True,
        'force': True,
        'validate_certs': True,
        'force_basic_auth': 'True',
        'use_gssapi': True,
        'follow_redirects': 'yes',
        'username': 'username',
        'headers': {},
        'password': 'password',
        'unix_socket': 'unix_socket',
        'unredirected_headers': [],
        'ca_path': 'ca_path'
    }
    var_0 = lookup_module_0.run(str_0, **kwargs_0)

# Generated at 2022-06-25 11:40:49.768562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run('docuri')

if 0:
    def test_case_0():
        str_0 = 'get_option'
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:40:53.404537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run('docuri')
    return var_0


# Generated at 2022-06-25 11:40:57.817586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    docuri = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(docuri)

# Generated at 2022-06-25 11:41:04.559377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    str_1 = 'terms'
    bool_0 = False
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=bool_0)
    var_0 = lookup_module_0.run(str_1, str_0)


# Generated at 2022-06-25 11:41:23.988306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'terms'
    variables = 'variables'
    lookup_module_0 = LookupModule()
    var_2 = lookup_run(str_0, variables)

# Generated at 2022-06-25 11:41:25.366883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    var_0 = lookup_run('docuri')

    assert not var_0

# Generated at 2022-06-25 11:41:30.989531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'docuri'
    lookup_module_1 = LookupModule()
    lookup_module_1.run(str_1)


# Generated at 2022-06-25 11:41:32.203063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Unit test execution

# Generated at 2022-06-25 11:41:38.666677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    if lookup_module_0.get_option('split_lines') and (not lookup_module_0.get_option('split_lines')):
        lookup_module_0.set_options(var_options=variables, direct=kwargs)

    assert lookup_module_0.run(terms=str_0) == file.read(open(str_0, 'r'))

# Generated at 2022-06-25 11:41:39.880709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'docuri'
    var_0 = lookup_module_0.run(str_0)
    print(var_0)


# Generated at 2022-06-25 11:41:42.455037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'docuri'
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 11:41:46.513752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)
    str_1 = 'docuri'
    var_1 = lookup_run(str_1)
    assert var_0 == var_1

# Generated at 2022-06-25 11:41:53.232430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # ONAP: (Test is currently commented as it probably requires a valid URL to work correctly)
    # str_0 = 'docuri'

    # ONAP: (Test is currently commented as it probably requires a valid URL to work correctly)
    # lookup_module_0.run(str_0)


# Generated at 2022-06-25 11:41:54.952632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 11:42:35.644784
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    var_0 = lookup_module_0.run(['https://raw.githubusercontent.com/ansible/ansible/v2.9/lib/ansible/modules/network/net_system/nxos.py'])
    var_1 = lookup_module_1.run(['https://raw.githubusercontent.com/ansible/ansible/v2.9/lib/ansible/modules/compute/ovirt/ovirt_auth.py'])

# Generated at 2022-06-25 11:42:39.574275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)
    assertEqual(result, expect)

# Generated at 2022-06-25 11:42:43.711796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert_equal(lookup_module_0.run(terms, variables=variables), ret)
    assert_equal(lookup_module_0.run(terms, variables=variables), ret)
    assert_equal(lookup_module_0.run(terms, variables=variables), ret)

# Generated at 2022-06-25 11:42:51.204849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    str_1 = 'pydoc'
    lookup_module_1 = LookupModule()
    str_2 = ''
    str_3 = 'pydoc'
    lookup_module_2 = LookupModule()
    tup_0 = (str_0, str_1, lookup_module_1)
    tup_1 = (str_2, str_3, lookup_module_2)
    lookup_module_3 = LookupModule()
    str_4 = ''
    str_5 = 'pydoc'
    lookup_module_4 = LookupModule()
    str_6 = ''
    str_7 = 'pydoc'
    lookup_module_5 = LookupModule()

# Generated at 2022-06-25 11:42:57.228335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string_to_parse = 'docuri'
    lookup_module = LookupModule()
    try:
        lookup = lookup_module.run(string_to_parse)
    except Exception:
        lookup = None
    assert lookup is not None, "The run method of LookupModule class failed"

# Generated at 2022-06-25 11:43:05.089205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'foobar'
    map_0 = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, map_0)
    str_2 = 'url'
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(str_2)
    str_4 = 'url'
    lookup_module_2 = LookupModule()
    lookup_module_2.run(str_4, map_0)


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:43:09.184502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:43:10.020691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test of method run of class LookupModule')
    assert func_0() == func_1()


# Generated at 2022-06-25 11:43:18.379762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'https://github.com/gremlin.keys'
    str_2 = 'ansible-httpget'
    str_3 = 'ansible_lookup_url_agent'
    str_4 = 'ansible-httpget'
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(str_1)
    var_2 = lookup_module_1.run(var_1)
    lookup_module_2 = LookupModule()
    lookup_module_2.set_socket_path("urllib3.util.IS_PYOPENSSL")
    lookup_module_1.set_socket_path("urllib3.util.IS_PYOPENSSL")

# Generated at 2022-06-25 11:43:28.577357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'docuri'
    variable_1 = None
    variable_2 = {}
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(str_1, variable_1, variable_2)
    str_2 = 'urltest'
    variable_3 = 'validate_certs'
    variable_4 = False
    variable_5 = {}
    var_2 = lookup_module_1.run(str_2, variable_1, variable_3, variable_4, variable_5)
    str_3 = 'urltest'
    variable_6 = 'validate_certs'
    variable_7 = False
    variable_8 = {}
    variable_9 = 'split_lines'
    variable_10 = False
    var_3 = lookup_module_

# Generated at 2022-06-25 11:44:47.004386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule()
    str_0 = 'http://www.google.com'
    var_0 = module_0.run(str_0)
    print(var_0)
    str_1 = 'https://www.google.com'
    var_1 = module_0.run(str_1)
    print(var_1)


# Generated at 2022-06-25 11:44:49.315290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'docuri'
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(str_1)
    assert var_1 == ['text']

# Generated at 2022-06-25 11:44:52.811556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 11:44:55.131961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0)
    assert lookup_module_0.run(str_0) == var_0

# Generated at 2022-06-25 11:45:00.998293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'docuri'
    variables_0 = {}
    lookup_module_0 = LookupModule()
    var_2 = lookup_module_run(lookup_module_0, term_0, variables_0)


# Generated at 2022-06-25 11:45:09.571120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'docuri'
    var_1 = None
    # var_1 {'docuri': 'docuri'}
    var_2 = None
    var_3 = lookup_run(str_0, {'docuri': 'docuri'})
    assert var_3 == var_1
    # var_1 {'docuri.txt': 'docuri.txt'}
    var_3 = lookup_run(str_0, {'docuri.txt': 'docuri.txt'})
    assert var_3 == var_1


# Generated at 2022-06-25 11:45:12.625616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:45:14.330506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'docuri'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(str_0)
    return var_0



# Generated at 2022-06-25 11:45:16.357788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:45:21.208720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cache_key_0 = 'https://example.com/index.html'
    str_0 = 'https://example.com/index.html'
    str_1 = 'This is a test'
    lookup_module_0 = LookupModule()
    str_2 = 'https://example.com/index.html'
    str_3 = 'This is a test'
    lookup_module_0.run(cache_key_0)
    lookup_module_0.run(str_0)
    lookup_module_0.run(str_1)
    lookup_module_0.run(str_2)
    lookup_module_0.run(str_3)