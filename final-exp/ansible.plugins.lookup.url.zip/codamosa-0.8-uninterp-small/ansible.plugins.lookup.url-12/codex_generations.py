

# Generated at 2022-06-25 11:37:49.480936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # url lookup splits lines by default
    lookup_module.run(["https://github.com/gremlin.keys"], {'item': '{{item}}'}, split_lines=True)
    # display ip ranges
    lookup_module.run(["https://ip-ranges.amazonaws.com/ip-ranges.json"], split_lines=False)
    # url lookup using authentication
    lookup_module.run(["https://some.private.site.com/file.txt"], username='bob', password='hunter2')
    # url lookup using basic authentication
    lookup_module.run(["https://some.private.site.com/file.txt"], username='bob', password='hunter2', force_basic_auth='True')
    # url lookup using headers

# Generated at 2022-06-25 11:37:59.500289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # executed: https://ip-ranges.amazonaws.com/ip-ranges.json
    lookup_module_0.run(['https://ip-ranges.amazonaws.com/ip-ranges.json'],{'ansible_httpapi_validate_certs': False, 'ansible_httpapi_use_ssl': False, 'ansible_httpapi_keep_alive': True, 'ansible_httpapi_url_password': None, 'ansible_httpapi_url_username': None, 'ansible_httpapi_timeout': 10, 'ansible_httpapi_use_gssapi': False, 'ansible_httpapi_url_timeout': None, 'ansible_httpapi_force': False})


# Generated at 2022-06-25 11:38:10.094970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('zz') == 6
    assert lookup_module_0.run('xx') == 9
    assert lookup_module_0.run('cc') == 9
    assert lookup_module_0.run('ss') == 9
    assert lookup_module_0.run('vv') == 9
    assert lookup_module_0.run('bb') == 9
    assert lookup_module_0.run('nn') == 9
    assert lookup_module_0.run('ww') == 9
    assert lookup_module_0.run('gg') == 9
    assert lookup_module_0.run('mm') == 9

# Generated at 2022-06-25 11:38:21.961697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.set_options(direct={'wantlist': True})
    lookup_module_run_0.set_options(var_options={'debug':True})
    lookup_module_run_0.set_options(direct={'force':False})
    lookup_module_run_0.set_options(direct={'validate_certs':True})
    lookup_module_run_0.set_options(direct={'force_basic_auth':False})
    lookup_module_run_0.set_options(direct={'ca_path':'ca_path'})
    lookup_module_run_0.set_options(direct={'timeout':10.0})

# Generated at 2022-06-25 11:38:27.974877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    def test_cases():
        """local test_cases_0"""

        def test_case_1():
            lookup_module_1.run(terms = [], variables = None)
            # In future we will check for return values
    test_case_1()


# Generated at 2022-06-25 11:38:31.180880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'https://www.redhat.com'
    variables = {'ansible_httpapi_url_username': 'admin', 'ansible_httpapi_url_password': 'redhat'}
    lookup_module_0.run(terms, variables)


# Generated at 2022-06-25 11:38:33.991720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run = LookupModule.run

# Generated at 2022-06-25 11:38:43.450241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:38:49.602551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'https://github.com/gremlin.keys'
    terms = [term]

    lookup_module = LookupModule()
    lookup_module.set_options = set_options
    lookup_module.get_option = get_option

    lookup_module_run = lookup_module.run(terms)

    assert lookup_module_run[0] == '-----BEGIN PGP PUBLIC KEY BLOCK-----'


# Generated at 2022-06-25 11:38:57.340569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_1 = [
        'https://download.docker.com/linux/ubuntu/dists/trusty/pool/stable/amd64/containerd.io_1.2.6-3_amd64.deb'
    ]
    variables_1 = None
    try:
        lookup_module_1.run(
            terms = term_1,
            variables = variables_1,
            wantlist = True
        )
    except Exception as e:
        print(e)


# Generated at 2022-06-25 11:39:11.608851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(
        var_options = {},
        direct = {'validate_certs': 'yes', 'use_proxy': 'yes', 'username': 'user', 'password': 'password', 'headers': {'header1':'value1', 'header2':'value2'}, 'force': 'yes', 'timeout': '50', 'http_agent': 'agent', 'force_basic_auth': 'yes', 'follow_redirects': 'all', 'use_gssapi': 'yes', 'unix_socket': '/file/system/path', 'ca_path': './ca/path', 'unredirected_headers': ['header1', 'header2'] },
    )

# Generated at 2022-06-25 11:39:14.024388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 11:39:21.426247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test_LookupModule_run
    """
    lookup_module_0 = LookupModule()
    assert len(lookup_module_0.run(terms=["terms_arg_0", "terms_arg_1", "terms_arg_2"], variables="variables_arg_0", kwarg_name_0="kwarg_value_0")) == 3, \
        "Expected 3, got {0}".format(len(lookup_module_0.run(terms=["terms_arg_0", "terms_arg_1", "terms_arg_2"], variables="variables_arg_0", kwarg_name_0="kwarg_value_0")))


# Generated at 2022-06-25 11:39:30.503921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    split_lines = True
    kwargs = dict(http_agent='ansible-httpget', force_basic_auth=False, use_proxy=True, username=None,
                  headers={}, timeout=10, url_password=None, validate_certs=True, unredirected_headers=[],
                  use_gssapi=False, force=False, unix_socket=None, follow_redirects='urllib2', ca_path=None)
    terms = ["https://example.org"]
    LookupModule.run(lookup_module_0, terms, None, **kwargs)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:39:40.552267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    in_terms = ['https://github.com/gremlin.keys']
    in_variables = ''
    in_direct = {}

# Generated at 2022-06-25 11:39:47.745043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = ['https://github.com/gremlin.keys']
    variables_0 = None
    kwargs_0 = {}
    result_0 = lookup_module_1.run(terms_0, variables_0, **kwargs_0)
    # If the returned value is not empty, the test passed, else failed
    if len(result_0) > 0:
        pass
    else:
        assert False, "Test failed: expected: %s - received: %s" % (len(result_0) > 0, False)
    return result_0

# Generated at 2022-06-25 11:39:48.850213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run is not None


# Generated at 2022-06-25 11:39:58.908106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupModule)

# Generated at 2022-06-25 11:40:03.903338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['https://github.com/gremlin.keys']
    variables_0 = {}
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0=variables_0, **kwargs_0)
    print(ret_0)

# Generated at 2022-06-25 11:40:12.231216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError
    from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError
    import requests
    import os
    import pytest

    # Create connection to fake web server
    class MockServer(object):
        def __init__(self, data_to_return):
            self.data_to_return = data_to_return
            self.headers_received = None
            self.cookies_received = None
            self.requests_received = 0


# Generated at 2022-06-25 11:40:28.452018
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:40:29.618392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:40:33.770616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(var_0, bool_1)

# Test for method set_options of class LookupModule

# Generated at 2022-06-25 11:40:36.420640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input data
    terms = list('abcd')
    terms_0 = terms
    # Output data
    ret = list(['a', 'b', 'c', 'd'])
    var_0 = run(terms_0)


# Generated at 2022-06-25 11:40:38.205466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:40:42.353061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    assert isinstance(lookup_module_0.run(), list) == True



# Generated at 2022-06-25 11:40:48.287621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #
    # set up test
    #
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0.run

    #
    # test for false
    #
    assert False

# Generated at 2022-06-25 11:40:53.690061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    
    
    
    
    

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:41:05.438052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from unittest.mock import patch

    # save original
    original_open_url = open_url
    def _open_url_side_effect(url, **kwargs):
        return kwargs

    # mock HTTPError and URLError to avoid real http requests
    with patch(__name__ + ".open_url", side_effect=_open_url_side_effect):
        with patch(__name__ + ".HTTPError"):
            with patch(__name__ + ".URLError"):
                with pytest.raises(AnsibleError) as excinfo:
                    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:41:08.204975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    assert True
    lookup_module_1 = LookupModule()
    assert True


# Generated at 2022-06-25 11:41:25.692592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(bool_0) == None



# Generated at 2022-06-25 11:41:32.960335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x_0 = True
    lookup_module_0 = LookupModule()
    x_1 = []
    x_2 = ('https://github.com/gremlin.keys', )
    x_3 = lookup_module_0.run(x_1, x_2)
    print(x_3)



# Generated at 2022-06-25 11:41:36.864953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    pkg_resources_0 = ModuleNotFoundError()
    bool_0 = True
    lookup_module_0.run(pkg_resources_0, bool_0)


# Generated at 2022-06-25 11:41:46.585370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = False
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    terms_0 = ['https://github.com/gremlin.keys', 'url lookup splits lines by default', 'item']
    display_0 = Display()
    display_1 = Display()
    display_2 = Display()
    display_3 = Display()
    display_4 = Display()
    display_5 = Display()
    display_6 = Display()
    display_7

# Generated at 2022-06-25 11:41:52.795818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'https://github.com/gremlin.keys'
    list_0 = terms = []
    list_1 = lookup_module_0.run(str_0, list_0)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 11:41:54.919009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    terms_0 = []
    assert lookup_module_0.run(terms_0) == list()



# Generated at 2022-06-25 11:41:58.968605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:42:00.915168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with bool as first arg,
    # bool as second arg
    # and bool as third arg,
    test_case_0()
    
test_LookupModule_run()

# Generated at 2022-06-25 11:42:05.208929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    bool_1 = False
    lookup_module_0.set_options(var_options=bool_1, direct=bool_0)
    lookup_module_0.run(terms=bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:42:07.381045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert callable(getattr(lookup_module, 'run', None))

    # Call LookupModule.run()
    assert lookup_module.run is not None



# Generated at 2022-06-25 11:42:45.719434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    terms_0 = ""
    variables_0 = ""
    var_1 = lookup_module_1.run(terms_0, variables_0)
    var_0 = lookup_run(bool_0)
    terms_0 = ""
    variables_0 = ""
    var_1 = lookup_module_1.run(terms_0, variables_0)

# Generated at 2022-06-25 11:42:50.467931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['https://github.com/gremlin.keys'], wantlist=True) == [['https://github.com/gremlin.keys'], ['ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIElm1+ya8eJcKQAoFlsgLl+D7Z1pBX9jK+zN6TLEa7qPw']]


# Generated at 2022-06-25 11:42:52.961262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instance of class LookupModule
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables)
    int_0 = lookup_module_0.run(terms)
    print(int_0)


# Generated at 2022-06-25 11:42:54.328763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    bool_1 = bool_0
    lookup_module_0.run([bool_1])

# Generated at 2022-06-25 11:42:56.553087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance
    str_0 = "https://github.com/gremlin.keys"
    lookup_module_1 = LookupModule()
    # Run method
    result = lookup_module_1.run(str_0)
    assert isinstance(result, list)


test_LookupModule_run()

# Generated at 2022-06-25 11:42:57.896421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(True)


# Generated at 2022-06-25 11:43:06.738652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs_122 = dict()
    kwargs_122['force_basic_auth'] = False
    kwargs_122['validate_certs'] = True
    kwargs_122['force'] = False
    kwargs_122['use_gssapi'] = False
    kwargs_122['headers'] = dict()
    kwargs_122['follow_redirects'] = 'urllib2'
    kwargs_122['unredirected_headers'] = dict()
    kwargs_122['http_agent'] = 'ansible-httpget'
    kwargs_122['unix_socket'] = None
    kwargs_122['split_lines'] = True
    kwargs_122['ca_path'] = None
    kwargs_122['use_proxy'] = True


# Generated at 2022-06-25 11:43:12.038687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    var_lookup_module_run_0 = lookup_module_run_0.run()
    lookup_module_run_0.set_options(None, var_lookup_module_run_0)
    lookup_module_run_1 = LookupModule()
    lookup_module_run_1.set_options(None, var_lookup_module_run_0)
    lookup_module_run_2 = LookupModule()
    lookup_module_run_2.set_options(None, var_lookup_module_run_0)
    lookup_module_run_3 = LookupModule()
    lookup_module_run_3.set_options(var_lookup_module_run_0, None)
    lookup_module_run_4 = LookupModule

# Generated at 2022-06-25 11:43:14.145056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_1 = LookupModule()
    exception = None
    try:
        lookup_module_1.run(bool_0)
    except Exception as exception:
        pass
    display.vvvv("look up module")

# Generated at 2022-06-25 11:43:18.990037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    terms_0 = ()
    variables_0 = ()
    var_0 = lookup_run(bool_0)
    assert var_0 == var_1
    terms_1 = ()
    variables_1 = ()
    kwargs_0 = {'direct': {}}
    var_2 = lookup_run(bool_0)
    assert var_2 == var_3
    terms_2 = ()
    variables_2 = ()
    kwargs_1 = {'direct': {}}
    var_4 = lookup_run(bool_0)
    assert var_4 == var_5
    terms_3 = ()
    variables_3 = ()
    kwargs_2 = {'direct': {}}

# Generated at 2022-06-25 11:44:42.576506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_data = True
    lookup_module_0 = LookupModule()
    str_data = "I am a test string"
    str_data_1 = "I am a test string"
    if str_data is str_data_1:
        bool_data = True
    bool_data_1 = True
    assert bool_data is bool_data_1


# Generated at 2022-06-25 11:44:45.412844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 11:44:52.454791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # run is a static method and as such can be called from outside of the class
    obj_LookupModule = LookupModule()
    obj_LookupModule.run()

test_case_0()

# Generated at 2022-06-25 11:44:57.247563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    test_str_0 = 'https://github.com/gremlin.keys'
    test_str_1 = 'https://ip-ranges.amazonaws.com/ip-ranges.json'
    test_bool_0 = True
    test_bool_1 = False
    test_dict_0 = {'header1': 'value1', 'header2': 'value2'}
    test_dict_1 = {}
    test_int_0 = 10
    test_str_2 = 'ansible-httpget'
    test_bool_2 = True
    test_bool_3 = False
    test_list_0 = ['https://github.com/gremlin.keys', 'https://ip-ranges.amazonaws.com/ip-ranges.json']
    var_1 = var

# Generated at 2022-06-25 11:44:59.783980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_run(url_0)
    except URLError as err:
        raise AssertionError('An Expected exception occurred when trying to run urllib.request.urlopen(url_0):' + repr(err))
    except Exception as err:
        raise AssertionError('An Unexpected exception occurred when trying to run urllib.request.urlopen(url_0):' + repr(err))


# Generated at 2022-06-25 11:45:06.001763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Inits
    # init1
    lookup_module_0 = LookupModule()
    terms_bool_0 = lookup_module_0.run(terms_bool_0)


# Generated at 2022-06-25 11:45:11.715468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run"))
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(bool_0)
    bool_0 = True
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(bool_0)
    bool_0 = True
    bool_1 = True
    lookup_module_1.set_options(var_options=bool_0, direct=bool_1)
    var_1 = lookup_module_1.run(bool_0)
    bool_0 = True
    bool_1 = True


# Generated at 2022-06-25 11:45:20.154182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(validate_certs=False, force=False, timeout=10, split_lines=False,
                                   use_gssapi=True, use_proxy=False)
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule(validate_certs=True, force=False, timeout=10, split_lines=True,
                                   use_gssapi=False, use_proxy=True)
    terms = 'https://github.com/ansible/ansible/blob/stable-2.-series/lib/ansible/plugins/lookup/url.py'
    lookup_module_0.run()
    lookup_module_1.run()
    lookup_module_2.run()


# Generated at 2022-06-25 11:45:24.308967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:45:26.920041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    if __name__ == "__main__":
        main()