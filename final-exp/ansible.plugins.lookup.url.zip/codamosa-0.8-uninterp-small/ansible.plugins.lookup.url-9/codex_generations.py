

# Generated at 2022-06-25 11:37:45.381840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    result = lookup_module_1.run(terms, variables, **kwargs)
    assert result == []

# Generated at 2022-06-25 11:37:49.984225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.display = Display()
    lookup_module_0.display.verbosity = 2
    lookup_module_0.run(["github.com/gremlin.keys"])

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:38:00.302804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()
    lookup_module_16 = LookupModule()

# Generated at 2022-06-25 11:38:04.326327
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #
    # Example 1
    #
    # initializing the class and then running the method run
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=['http://www.google.com'], variables={'ansible_http_agent': 'ansible-httpget'})

if __name__ == '__main__':
    # Usage: python library/ansible/plugins/lookup/url.py
    test_case_0()

# Generated at 2022-06-25 11:38:08.747914
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # ansible
    global_vars = {}
    kw_args = {}

    lookup_module.run('https://www.sourcemage.org', global_vars, **kw_args)

# Generated at 2022-06-25 11:38:10.176130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:38:22.053737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = 'https://github.com/gremlin.keys'
    variables_0 = None
    var_options_0 = variables_0
    direct_0 = None
    terms_0 = [term_0]
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, var_options=var_options_0, direct=direct_0)
    term_1 = 'https://ip-ranges.amazonaws.com/ip-ranges.json'
    variables_1 = None
    var_options_1 = variables_1
    direct_1 = None
    terms_1 = [term_1]
    kwargs_1 = {}

# Generated at 2022-06-25 11:38:26.848015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == False, "test case 0 not implemented"
    # lookup_module_0 = LookupModule()
    # lookup_module_0.run('url', 'terms', 'variables=None', )



# Generated at 2022-06-25 11:38:32.909693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'https://github.com/gremlin.keys'
    variables = {}
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 11:38:42.646089
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arguments
    terms = ['https://www.redhat.com/','https://www.ansible.com']
    variables = None
    kwargs = {}

    kwargs["validate_certs"] = True
    kwargs["use_proxy"] = True
    kwargs["username"] = "bob"
    kwargs["password"] = "hunter2"
    kwargs["headers"] = {}
    kwargs["force"] = False
    kwargs["timeout"] = 10.0
    kwargs["http_agent"] = "ansible-httpget"
    kwargs["force_basic_auth"] = False
    kwargs["follow_redirects"] = "urllib2"
    kwargs["use_gssapi"] = False

# Generated at 2022-06-25 11:38:54.344538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2)
    var_3 = lookup_run(lookup_module_2)
    var_5 = lookup_run(lookup_module_2)

if __name__ == "__main__":
    import sys
    import os
    import pytest

    pytest.main(os.path.realpath(sys.argv[0]))

# Generated at 2022-06-25 11:39:00.031553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:39:04.706703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert not var_0


# Test with parametrize

# Generated at 2022-06-25 11:39:09.210814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test test_LookupModule_run...")
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["value1", "value2"]
    print("test test_LookupModule_run finished successfully")


# Generated at 2022-06-25 11:39:14.677948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:39:18.099198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = ["The quick brown fox jumped over the lazy dog"]
    assert var_0 == var_1, "Incorrect return value while testing run method of LookupModule class"


# Generated at 2022-06-25 11:39:20.697627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:39:31.013698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #Terms can be either list or str
    var_0 = lookup_run(lookup_module_0, ["https://github.com/gremlin.keys"])

# Generated at 2022-06-25 11:39:34.488687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 0


# Generated at 2022-06-25 11:39:40.106677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init LookupModule and assign variables
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = Mock()

    # Run method and check returned value
    @patch.object(lookup_module_0, 'run')
    def test_run(run_mock):
        # Init arguments for method
        terms = 12
        variables = 12

        # Call method and check returned value
        return_value = lookup_module_0.run(terms, variables)
        pass

    test_run()

# Generated at 2022-06-25 11:39:50.028995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run()")
    lookup_module_0 = LookupModule()
    terms_0 = ''
    variables_0 = ''
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == []

# Generated at 2022-06-25 11:39:53.939268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ""
    variables = None
    try:
        test_case_0 = lookup_module_0.run(terms, variables)
    except Exception as e:
        raise e

# Generated at 2022-06-25 11:40:00.735752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var = lookup_run(
        lookup_module_0, 
        terms=['https://github.com/gremlin.keys'], 
        # wantlist=True
    )

# Generated at 2022-06-25 11:40:10.621714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['https://github.com/gremlin.keys'])

# Generated at 2022-06-25 11:40:19.802508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={u'force': False, u'http_agent': u'ansible-httpget', u'username': u'', u'ca_path': u'', u'validate_certs': True, u'force_basic_auth': False, u'follow_redirects': u'urllib2', u'headers': {}, u'use_proxy': True, u'use_gssapi': False, u'password': u'', u'unix_socket': u'', u'unredirected_headers': [], u'split_lines': True, u'force': False, u'timeout': 10})
    var_1 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:40:24.520847
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Return value of lookup.run() method
    lookup_run_return_value = dict()

    lookup_module_0 = LookupModule()

    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:40:28.296952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert isinstance(var_0, list)
    assert len(var_0) > 0



# Generated at 2022-06-25 11:40:32.176450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1_result = lookup_module_1.run(terms=['https://github.com/ansible/ansible'])
    assert lookup_module_1_result[0].strip() == "<!DOCTYPE html>"


# Generated at 2022-06-25 11:40:33.411532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options()
    term = "https://github.com/gremlin.keys"
    lookup.run(terms=term)


# Generated at 2022-06-25 11:40:38.092617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [u'http://example.com/test']
    kwargs = {}
    var_1 = lookup_module_1.run(terms, **kwargs)

# Generated at 2022-06-25 11:40:55.681743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.check_object(lookup_module_0)
    assert var_0 == None, var_0
    var_1 = lookup_module_0.run(terms)
    assert var_1 == None, var_1


# Generated at 2022-06-25 11:40:57.848520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_27 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:41:01.413983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('https://github.com/gremlin.keys')

# Generated at 2022-06-25 11:41:05.642148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == [b'This is a test file.'], "var_0 == [b'This is a test file.']"

# Generated at 2022-06-25 11:41:11.830300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'var': 'val'})
    lookup_module_0.set_options(var_options={'var': 'val'})
    terms_0 = 'ghtd'
    variables_0 = "oaqopqpmq-oulf-jvlif-vxf-pqnco-zca"
    kwargs_0 = {'direct': 'val', 'var': 'val'}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:41:13.753666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:41:19.034932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = open_url('https://github.com/gremlin.keys')
    var_2 = getattr(var_1, 'read', None)
    var_3 = call(var_2, )
    var_4 = splitlines(var_3, )
    var_5 = list(var_4, )
    var_6 = lookup_run(lookup_module_0)
    var_7 = (var_6 == var_5)
    assert var_7 == True


# Generated at 2022-06-25 11:41:20.157558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:41:25.041135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    verify_var_0 = ['1', '2', '3', '4', '5']
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == verify_var_0


# Generated at 2022-06-25 11:41:30.324970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_run(lookup_module_0) != None


# Generated at 2022-06-25 11:42:04.590917
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup
    saved_url_ssl_version = url_ssl_version
    url_ssl_version = url_ssl_version_param

    # test

    # cleanup
    url_ssl_version = saved_url_ssl_version


# Generated at 2022-06-25 11:42:05.971498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:42:10.565726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test run of method run of class LookupModule started!")
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    print("Test run of method run of class LookupModule ended!")


# Generated at 2022-06-25 11:42:19.651595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'https://raw.githubusercontent.com/ansible/ansible/devel/examples/files/ansible.cfg'
    ]
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:42:30.812320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input params
    terms = 'https://gremlin.com/gremlin.pub'
    variables = None

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=variables, direct=None)

    # Expected result

# Generated at 2022-06-25 11:42:38.836515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  import inspect
  from ansible.plugins.lookup import LookupBase
  
  lookup_module_0 = LookupModule()
  var_0 = inspect.getargspec(LookupBase.run) # 'terms' is a list
  var_1 = inspect.getargspec(LookupModule.run) # 'terms' is a str
  assert var_0 != var_1

# def test_LookupModule_run():
#   import inspect
#   from ansible.plugins.lookup import LookupBase

#   lookup_module_0 = LookupModule()
#   var_0 = inspect.getargspec(LookupBase.run) # 'terms' is a list
#   var_1 = inspect.getargspec(LookupModule.run) # 'terms' is a str
#   assert var_0 != var_

# Generated at 2022-06-25 11:42:47.866895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'ca_path': 'ca_path_4', 'unix_socket': 'unix_socket_4', 'use_gssapi': False, 'follow_redirects': 'urllib2', 'force_basic_auth': False, 'http_agent': 'ansible-httpget', 'timeout': 10.0, 'force': False, 'headers': 'headers_0', 'username': 'username_0', 'password': 'password_0', 'use_proxy': True, 'validate_certs': True})

    # When
    lookup_module_0.run('terms_0')

    # Then
    # No exception raised


# Generated at 2022-06-25 11:42:50.360611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'bcoca'
    var_0 = lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:43:00.680275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={'split_lines': False, 'use_gssapi': False, 'username': 'user_0', 'force': False, 'unix_socket': '/var/run/docker.sock', 'ca_path': '/etc/docker/ca.pem', 'use_proxy': True, 'unredirected_headers': ['authorization'], 'http_agent': 'Ansible (debian)', 'validate_certs': True, 'follow_redirects': 'urllib2', 'timeout': 10, 'password': 'Pass_0', 'force_basic_auth': False})

# Generated at 2022-06-25 11:43:07.688021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.urls import open_url
    import pytest
    from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError

    var_0 = {"validate_certs": True, "split_lines": True, "use_proxy": True, "username": "bob", "password": "hunter2", "force": True, "timeout": 10, "http_agent": "ansible-httpget", "force_basic_auth": True, "follow_redirects": "urllib2", "use_gssapi": True, "ca_path": "ca_path", "unredirected_headers": ["unredirected_headers_0"]}
    var_1 = "https://some.private.site.com/file.txt"
    var_2

# Generated at 2022-06-25 11:44:28.944094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'Expected value of variable'

# Generated at 2022-06-25 11:44:35.503743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = import_module(to_text('json'))
    var_2 = var_1.loads(var_0)
    var_3 = var_2['prefixes'][0]['service']
    var_4 = repr(var_3)
    var_5 = repr('EC2')
    var_6 = var_4 == var_5
    assert var_6

# Generated at 2022-06-25 11:44:38.669400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)




# Generated at 2022-06-25 11:44:42.829656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, 'http://www.facebook.com')
    if var_0[0].find('html') > -1:
        print('good')

# Generated at 2022-06-25 11:44:45.095818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    # str[]
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:44:50.235313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:44:57.716331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  var_options_1 = None
  direct_1 = {'use_proxy': True, 'http_agent': 'ansible-httpget', 'validate_certs': True, 'username': '', 'split_lines': True, 'ca_path': '', 'use_gssapi': False, 'url_username': '', 'follow_redirects': 'urllib2', 'force_basic_auth': False, 'url_password': '', 'timeout': 10, 'force': False, 'headers': {}, 'unix_socket': '', 'unredirected_headers': []}
  lookup_module_1.set_options(var_options_1, direct_1)
  var_terms_1 = [('https://github.com/gremlin.keys')]
  var

# Generated at 2022-06-25 11:44:59.315410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = 'https://www.google.com'
    variables = None
    ret = lookup_module.run(terms=term, variables=variables)
    print(ret)


# Generated at 2022-06-25 11:45:00.998945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var = {}
    lookup_module = LookupModule()
    result = lookup_module.run(var)
    assert result is None


# Generated at 2022-06-25 11:45:06.328609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule) is True
