

# Generated at 2022-06-25 11:37:50.935182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.connection import Connection
    Connection._has_pipelining = True
    dict_0 = {'unix_socket': '', 'url_username': '', 'url_password': '', 'validate_certs': True, 'force': False, 'http_agent': 'ansible-httpget', 'use_proxy': True, 'headers': {}, 'timeout': 10, 'use_gssapi': False, 'force_basic_auth': False, 'follow_redirects': 'urllib2', 'ca_path': ''}
    lookup_module_0 = LookupModule(dict_0)

# Generated at 2022-06-25 11:37:55.269288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [1, 2, 3]
    terms = ['http://localhost:8080/', 'https://localhost:8080/']
    variables = None

    lookup_module_0 = LookupModule(data)
    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:38:03.467715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params = {
        'force': True,
        'url': 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/plugins/lookup/url.py'
    }
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    module = ActionModule(
        argument_spec=params,
        loader=loader,
        variable_manager=variable_manager
    )

# Generated at 2022-06-25 11:38:13.707441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup example

    terms = []
    variables = None
    kwargs = {}
    # Mock object to mock ret

    lines_0 = ['https://ip-ranges.amazonaws.com/ip-ranges.json']
    lines_1 = ['https://github.com/gremlin.keys']
    lines_2 = ['https://github.com/gremlin.keys']
    lines_3 = ['https://github.com/gremlin.keys']
    lines_4 = ['https://github.com/gremlin.keys']
    lines_5 = ['https://github.com/gremlin.keys']
    lines_6 = ['https://github.com/gremlin.keys']
    lines_7 = ['https://github.com/gremlin.keys']
    lines_8 = ['https://github.com/gremlin.keys']

# Generated at 2022-06-25 11:38:22.317230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    str_0 = ''
    dict_0 = {}
    dict_0['validate_certs'] = None
    lookup_module_0.set_options(var_options=None, direct=dict_0)
    list_0 = []
    list_1 = []
    list_0.append(str_0)
    list_0.extend(list_1)

    # This raises an error because "terms" should be a list of strings,
    # but we are passing an empty list instead.
    assert lookup_module_0.run(None, list_0)

# Generated at 2022-06-25 11:38:28.673042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_1 = 'github.com'
    str_2 = '/gremlin.keys'
    list_1 = (str_1, str_2)
    dict_1 = {str_1: str_2, str_1: list_1, str_1: str_2}
    list_2 = lookup_module_0.run(list_1, dict_1)


# Generated at 2022-06-25 11:38:33.234458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'playbook.yml'
    str_1 = 'https://raw.githubusercontent.com/bcoca/server-ansible-role-requirements/master/requirements.yml'
    list_0 = []
    list_1 = []
    list_1.append(str_1)
    list_0.append(list_1)
    dict_0 = {'lookup_params': list_0, 'lookup_plugin': str_0}
    lookup_module_0 = LookupModule(dict_0)

    test_case_0()
    test_case_1()

# Generated at 2022-06-25 11:38:41.858259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run({'files/shakespeare.txt'}, {'files/shakespeare.txt': 'https://github.com/gremlin.keys'})
# Asserts that the two objects are equal.
#     assert 'http://{{ hostname }}{{ lookup(\'env\', \'OPENSHIFT_POSTGRESQL_DB_USERNAME\') }}:{{ lookup(\'env\', \'OPENSHIFT_POSTGRESQL_DB_PASSWORD\') }}@{{ hostname }}/{{ lookup(\'env\', \'OPENSHIFT_APP_NAME\') }}' == result


# Generated at 2022-06-25 11:38:42.841418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #return None
    #assert str_1 == str_1
    return None


# Generated at 2022-06-25 11:38:44.914940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({'use_proxy': True})
    lookup_module_0.set_options(var_options=[], direct={'use_proxy': True})

    assert lookup_module_0.run is not None

# Generated at 2022-06-25 11:38:51.501010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/urls.py'], {}) == ['import six']


# Generated at 2022-06-25 11:39:02.554498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['https://github.com/gremlin.keys']
    variables = {}
    kwargs = {u'validate_certs': True, u'use_proxy': True, u'username': u'bcoca', u'password': u'hunter2', u'headers': {}, u'force': False, u'timeout': 10, u'http_agent': u'ansible-httpget', u'force_basic_auth': False, u'follow_redirects': u'urllib2', u'use_gssapi': False, u'unix_socket': u'', u'ca_path': u'', u'unredirected_headers': []}
    lookup_module_1 = LookupModule()
    if not lookup_module_1.run(terms, variables, **kwargs):
        lookup_module_

# Generated at 2022-06-25 11:39:06.065940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()#input
    assert isinstance(lookup_module_0, LookupModule)


# Generated at 2022-06-25 11:39:15.957051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = yaml.safe_load(u'http://www.google.com')
    variables = yaml.safe_load(u'')
    result = lookup_module_0.run(terms, variables, validate_certs=None, split_lines=None, use_proxy=None, username=None, password=None, headers=None, force=None, timeout=None, http_agent=None, force_basic_auth=None, follow_redirects=None, use_gssapi=None, unix_socket=None, ca_path=None, unredirected_headers=None)
    assert result[0].startswith(u"<!doctype html>")
    assert result[0].endswith(u"</html>")


# Generated at 2022-06-25 11:39:21.220522
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    term_0 = 'https://raw.githubusercontent.com/hari/test/master/README.md'
    lookup_module_0.run(terms=[term_0])


# Generated at 2022-06-25 11:39:26.679200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'username':'admin'})
    lookup_module.get_option('username')
    lookup_module.run(terms='http://google.com', variables=None)


# Generated at 2022-06-25 11:39:37.945551
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:39:44.073785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ip-ranges.amazonaws.com']
    terms_1 = ['https://ip-ranges.amazonaws.com']
    variables_0 = dict()
    variables_1 = dict()
    ret_3 = lookup_module_0.run(terms_0, variables_0)
    assert not isinstance(lookup_module_0, Exception)
    ret_4 = lookup_module_0.run(terms_1, variables_1)
    assert not isinstance(lookup_module_0, Exception)

# Generated at 2022-06-25 11:39:52.254590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:39:53.904371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    print(lookup_module.run(['']))

# Generated at 2022-06-25 11:40:05.708754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['url']
    variables_0 = None
    # Invoke run of the lookup module function
    ret = lookup_module_0.run(terms_0, variables=variables_0, )


# Generated at 2022-06-25 11:40:08.944087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = "https://github.com/gremlin.keys"
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)
    lookup_module_1.run(terms=[term])


# Generated at 2022-06-25 11:40:11.844386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-25 11:40:18.557261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Replace 'pass' with the body of the test case
  lookup_module_0 = LookupModule()
  lookup_module_1 = LookupModule()
  lookup_module_2 = LookupModule()
  # test case 1
  terms = ['https://github.com/gremlin.keys']
  variables = {}
   #kwargs = {}
  ret = lookup_module_0.run(terms, variables)
  print(ret)
  #test case 2
  terms = ['https://ip-ranges.amazonaws.com/ip-ranges.json']
  variables = {}
  ret = lookup_module_1.run(terms, variables)
  print(ret)
  # test case 3
  terms = ['https://some.private.site.com/file.txt']
  variables = {}
  # kwargs =

# Generated at 2022-06-25 11:40:26.379972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    new_module_0 = {
        'headers': {},
        'use_proxy': True,
        'timeout': 10,
        'validate_certs': True,
        'http_agent': 'ansible-httpget',
        'force': False,
        'split_lines': True,
        'follow_redirects': 'urllib2',
        'force_basic_auth': False,
        'use_gssapi': False,
        'unix_socket': None,
        'ca_path': None,
        'unredirected_headers': [],
        'username': None,
        'password': None
    }

    # Var args

# Generated at 2022-06-25 11:40:31.579151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    url_to_test = 'https://raw.githubusercontent.com/ansible/ansible/devel/plugins/lookup/url.py'
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run([url_to_test])
    assert url_to_test.splitlines()[0] in lookup_module_run

# Generated at 2022-06-25 11:40:39.305092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['http://www.google.com']
    variables_0 = {}
    kwargs_0 = {}
    x_0 = LookupModule()
    x_0.set_options(var_options=variables_0, direct=kwargs_0)

    # First invocation

# Generated at 2022-06-25 11:40:44.151046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['https://github.com/gremlin.keys']
    variables_0 = None
    kwargs_0 = { }
    try:
        lookup_module_0.run(terms=term_0, variables=variables_0, **kwargs_0)
    except SystemExit:
        pass

# Generated at 2022-06-25 11:40:53.676476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['https://api.ipify.org']
    variables_0 = None
    options_0 = dict()
    options_0['validate_certs'] = True
    options_0['split_lines'] = True
    options_0['use_proxy'] = True
    options_0['force'] = False
    options_0['timeout'] = 10.0
    options_0['http_agent'] = 'ansible-httpget'
    options_0['force_basic_auth'] = False
    options_0['follow_redirects'] = 'urllib2'
    options_0['use_gssapi'] = False
    options_0['unredirected_headers'] = None

# Generated at 2022-06-25 11:40:56.887792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['https://www.github.com/gremlin.keys']
    results_0 = lookup_module_0.run(terms_0)
    assert len(results_0) == 404

# Generated at 2022-06-25 11:41:16.097732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = []
    variables_2 = {}
    kwargs_3 = {}
    assert lookup_module_0.run(terms_1, variables_2, **kwargs_3) == []

# Generated at 2022-06-25 11:41:25.810670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={'username': 'ansible'})
    lookup_module_0.set_options(var_options=None, direct={'password': 'ansible'})
    lookup_module_0.set_options(var_options=None, direct={'ca_path': 'ca_pathpath'})
    lookup_module_0.set_options(var_options=None, direct={'unix_socket': 'unix_socketpath'})
    lookup_module_0.set_options(var_options=None, direct={'headers': {'header1': 'value1', 'header2': 'value2'}})

# Generated at 2022-06-25 11:41:38.619974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:41:45.220098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_1 = "https://github.com/gremlin.keys"
    var_options_2 = {}
    direct_3 = {}
    terms_4 = [
        "https://github.com/gremlin.keys",
    ]
    return_value_5 = lookup_module_0.run(terms_4, var_options_2, **direct_3)
    return return_value_5

# Generated at 2022-06-25 11:41:55.838054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    args = dict(terms='http://www.google.com',
                use_proxy=False,
                validate_certs=True,
                split_lines=True,
                headers=dict(dict()),
                force=False,
                timeout=10,
                http_agent='ansible-httpget',
                force_basic_auth=False,
                follow_redirects='urllib2',
                use_gssapi=False,
                unredirected_headers=dict(dict()),
                variables=dict(dict()),
                *[dict(item=item) for item in []])
    kwargs = dict()

    check = lookup_module.run(**args)


# Generated at 2022-06-25 11:42:06.238163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    lookup_module_0 = LookupModule()
    terms_0 = [["https://www.example.com"], ["https://www.example.com"]]
    variables_0 = {"ansible_lookup_url_timeout" : 0.5}
    kwargs_0 = {"headers" : {"User-Agent" : "Mozilla"}, "validate_certs" : True, "use_proxy" : True}

# Generated at 2022-06-25 11:42:11.757631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = []
    wantlist_0 = False
    kwargs_0 = {'wantlist': wantlist_0}
    ret_0 = lookup_module_0.run(terms_0,variables_0,**kwargs_0)
    assert type(ret_0) == list
    assert ret_0 == []

# Generated at 2022-06-25 11:42:12.420250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert False

# Generated at 2022-06-25 11:42:20.393044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._load_name = "term"

    # Test with a valid url
    # Test with a valid url
    lookup_module_1.get_option = Mock(return_value=10)
    lookup_module_1.get_option.return_value = {'username': 'user1', 'password': 'password', 'headers': 'headers1'}
    lookup_module_1.get_option.return_value = True
    lookup_module_1.get_option.return_value = True
    lookup_module_1.get_option.return_value = 'ansible-test'
    lookup_module_1.get_option.return_value = True
    lookup_module_1.get_option.return_value = False
    lookup_module_1.get

# Generated at 2022-06-25 11:42:31.140767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    lookup_module.set_options(var_options='', direct='')
    lookup_module.run(terms='', variables='', **'')
    lookup_module.run(terms='terms', variables='')
    lookup_module.run(terms='', variables='variables')
    lookup_module.run(terms='', variables='', **'')
    lookup_module.run(terms='', variables='')
    lookup_module.run(terms='', variables='variables')
    lookup_module.run(terms='terms', variables='')
    lookup_module.run(terms='', variables='variables')
    lookup_module.run(terms='', variables='')
    lookup_module.run(terms='', variables='')
   

# Generated at 2022-06-25 11:43:08.072078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1


# Generated at 2022-06-25 11:43:13.317560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import json
    import os

    # Check the argument types
    lookup_module_1 = LookupModule()
    if sys.version_info < (3, 2):
        assert isinstance(lookup_module_1.run(terms=[]), list)
    else:
        assert isinstance(lookup_module_1.run(terms=[], args=[]), list)

    # import responses
    # import requests
    # import requests_kerberos

    # def test_case_1(responses):
    #     '''
    #     I(use_gssapi=False,url='kerberos_token.json')
    #     '''
    #     url = 'kerberos_token.json'
    #     terms = [url,]
    #     responses.add(responses.GET,

# Generated at 2022-06-25 11:43:22.802760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:43:25.617333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={"split_lines":"True"})
    lookup_module.run(terms = [])

# Generated at 2022-06-25 11:43:30.446973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = "http://ansible.com"
    ret_0 = lookup_module_0.run(terms=term_0)
    assert "{{ lookup('url', 'https://github.com/gremlin.keys', wantlist=True) }}" in ret_0

# Generated at 2022-06-25 11:43:32.770713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['https://github.com/gremlin.keys']
    variables = {}
    lookup_module_0.run(terms, variables)

test_case_0()

# Generated at 2022-06-25 11:43:37.806148
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({
        u'http_agent': u'ansible-httpget',
        u'validate_certs': True,
        u'split_lines': True,
        u'use_proxy': True
    })

    try:
        lookup_module_0.run(['https://www.amazon.com/', 'https://www.amazon.com/'])
    except URLError as e:
        # should pass
        pass

    try:
        lookup_module_0.run(['https://www.amazon.com/', 'http://www.amazon.com/'])
    except URLError as e:
        # should pass
        pass

# Generated at 2022-06-25 11:43:40.948373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["https://google.com"])

# Generated at 2022-06-25 11:43:42.828631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [0]
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables=variables_0) is None

# Generated at 2022-06-25 11:43:51.415251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        'https://ansible.com',
        'https://ansible.com/test.yml'
    ]
    variables_1 = None
    kwargs_1 = {
        '_terms': terms_1
    }
    # test with no exception raise
    try:
        lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    except:
        assert False
        return
    assert True


# Generated at 2022-06-25 11:44:44.866699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 30.0
    int_0 = -2128
    int_1 = -1832
    lookup_module_0 = LookupModule()
    lookup_module_0.run(float_0)
    var_0 = lookup_module_0.run(int_0)
    lookup_module_0.run(int_1)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:44:54.976816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 60.0
    set_1 = {float_1}
    lookup_module_1 = LookupModule(set_1)
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_run(float_0)
    str_0 = ''
    lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:45:01.669322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_run(float_0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 11:45:06.392520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(terms, variables) == ''


if __name__ == "__main__":
    print("test succeeded")

# Generated at 2022-06-25 11:45:08.494825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:45:17.127696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 11:45:20.448942
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 0: Global Variables
    try:
        float_0 = 60.0
        int_0 = -1832
        set_0 = {int_0, int_0}
        lookup_module_0 = LookupModule(set_0)
        var_0 = lookup_run(float_0)
    except Exception as e:
        display("Exception: " + str(e))
        return False
    return True

# Generated at 2022-06-25 11:45:22.652871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_module_0.run(float_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:45:26.890037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_module_run(float_0)

# Generated at 2022-06-25 11:45:30.528505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TEST_CASE_0
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:47:32.651865
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:47:35.243970
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case(s) 0
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:47:41.726761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 60.0
    int_0 = -1832
    set_0 = {int_0, int_0}
    lookup_module_0 = LookupModule(set_0)
    dictionary_0 = {}
    dictionary_1 = {"1a"};
    dictionary_2 = {"1a", "b"};
    var_0 = lookup_run(float_0, dictionary_0, dictionary_1)
    var_1 = lookup_run(float_0, dictionary_0, dictionary_2)