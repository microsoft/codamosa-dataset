

# Generated at 2022-06-22 02:48:40.121780
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand(script = 'ls -l',
                           side_effect = None,
                           priority = 4)
    assert cmd.script, 'ls -l'
    assert cmd.side_effect, None
    assert cmd.priority, 4

# Generated at 2022-06-22 02:48:41.978950
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    new_command = Command(script = "fuck git commit", output = "fuck_git_commit.py")
    
    assert new_command.__repr__() == "Command(script=fuck git commit, output=fuck_git_commit.py)"



# Generated at 2022-06-22 02:48:50.596271
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    sys.path.append('test')
    rule = Rule.from_path(os.path.join(os.path.dirname('test'), 'test_rules_precedence/test_1.py'))
    assert rule.is_match(Command('w_sl', 'The-fuck~master'))
    assert rule.is_match(Command('w_sl', 'The-fuck~'))
    assert not rule.is_match(Command('w_sl', ''))
    assert not rule.is_match(Command('w_sl', 'The-fuck'))
    assert not rule.is_match(Command('w_sl', 'The-fuck~master~'))

# Generated at 2022-06-22 02:48:57.366550
# Unit test for constructor of class Command
def test_Command():
    command = Command('echo foo', 'foo')
    assert command.script == 'echo foo'
    assert command.output == 'foo'
    assert command.script_parts == ['echo', 'foo']
    assert command.stdout == 'foo'
    assert command.stderr == 'foo'
    assert command == Command('echo foo', 'foo')
    command = command.update(output='bar')
    assert command.output == 'bar'
    assert command.stdout == 'bar'
    assert command.stderr == 'bar'


# Generated at 2022-06-22 02:49:03.085440
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    cmd1 = CorrectedCommand(script='ls', side_effect=None, priority=10)
    cmd2 = CorrectedCommand(script='ls', side_effect=None, priority=10)
    cmd3 = CorrectedCommand(script='ls', side_effect=None, priority=20)
    cmd4 = CorrectedCommand(script='ls', side_effect=None, priority=30)

    assert hash(cmd1) == hash(cmd2)
    assert hash(cmd1) != hash(cmd3)
    assert hash(cmd1) != hash(cmd4)
    assert hash(cmd2) != hash(cmd3)
    assert hash(cmd2) != hash(cmd4)
    assert hash(cmd3) != hash(cmd4)

# Generated at 2022-06-22 02:49:08.866027
# Unit test for method update of class Command
def test_Command_update():
    testOne = Command('script', 'output')
    assert testOne.update(script = 'new script') == Command('new script', 'output')
    assert testOne.update(output = 'new output') == Command('script', 'new output')
    assert testOne.update(script = 'new script', output = 'new output') == Command('new script', 'new output')


# Generated at 2022-06-22 02:49:13.805031
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('a', 1, '2') == CorrectedCommand('a', 1, '3')
    assert not CorrectedCommand('a', 1, 2) == CorrectedCommand('b', 1, 2)
    assert not CorrectedCommand('a', 1, 2) == 1


# Generated at 2022-06-22 02:49:25.900326
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .commands_cache import CommandsCache

    # "True" case
    with CommandsCache([('echo', 'echo')]) as cache:
        cache.add_rule(shell=True, name='test_rule', match=lambda old_cmd: True,
            get_new_command=lambda old_cmd: 'echo "hi"')
        rule = cache.get_rule('echo', 'echo')
        assert rule.is_match(Command('echo "hi"', 'echo "hi"'))

    # "False" case
    with CommandsCache([('echo', 'echo')]) as cache:
        cache.add_rule(shell=True, name='test_rule', match=lambda old_cmd: False,
            get_new_command=lambda old_cmd: 'echo "hi"')

# Generated at 2022-06-22 02:49:31.632070
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert 'CorrectedCommand(script=None, side_effect=None, priority=1)' == CorrectedCommand(script=None, side_effect=None, priority=1).__repr__()
    assert 'CorrectedCommand(script=a, side_effect=b, priority=1)' == CorrectedCommand(script='a', side_effect='b', priority=1).__repr__()


# Generated at 2022-06-22 02:49:36.062619
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    s = 'CorrectedCommand(script=hey, side_effect=None, priority=2)'
    assert str(CorrectedCommand(script='hey', side_effect=None, priority=2)) == s

# Generated at 2022-06-22 02:50:00.358858
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    function1 = lambda command: True
    function2 = lambda command: False
    function3 = lambda command: "THIS IS THE NEW COMMAND"
    function4 = lambda command: None

    rule = Rule(name = "test",
                match = function1,
                get_new_command = function3,
                enabled_by_default = True,
                side_effect = function4,
                priority = 3,
                requires_output = False)

    assert repr(rule) == "Rule(name=test, match={}, get_new_command={}, enabled_by_default=True, side_effect={}, priority=3, requires_output=False)"


# Generated at 2022-06-22 02:50:12.249533
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    # GIVEN Rule object
    a = Rule('name', lambda x: True, lambda x: 'x', True, lambda x, y: None, 123, True)
    b = Rule('name1', lambda x: True, lambda x: 'x1', False, lambda x, y: None, 124, True)
    c = Rule('name', lambda x: False, lambda x: 'x2', False, lambda x, y: None, 125, True)
    d = Rule('name', lambda x: True, lambda x: 'x3', True, lambda x, y: None, 126, False)
    e = Rule('name', lambda x: True, lambda x: 'x4', True, lambda x, y: None, 127, True)
    # WHEN Rule is compared to various other objects
    # THEN correct result is returned
    assert a == e
   

# Generated at 2022-06-22 02:50:17.224372
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    a = CorrectedCommand(1, 2, 3)
    assert a == CorrectedCommand(1, 2, 3)
    assert a == CorrectedCommand(1, 2, 4)
    assert not a == CorrectedCommand(1, 2, 4, 5)
    assert not a == 1


# Generated at 2022-06-22 02:50:21.644134
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    correction = CorrectedCommand(script='script', side_effect=None, priority=1)
    assert hash(correction) == hash(
        CorrectedCommand(script='script', side_effect=None, priority=1)
    ), 'CorrectedCommand hash is not equal'

# Generated at 2022-06-22 02:50:27.358214
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('asdf',None, 5) == CorrectedCommand('asdf',None, 6)
    assert not (CorrectedCommand('asdf',None,5) == CorrectedCommand('asdf2',None,5))
    assert not (CorrectedCommand('asdf',None,5) == CorrectedCommand('asdf',None,5))
    assert not (CorrectedCommand('asdf',None,5) == CorrectedCommand('asdf2',None,6))

# Generated at 2022-06-22 02:50:37.763570
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script = 'git status'
    new_command = 'git st'
    matched_rule_name = 'git-status-git-st'
    output = ''
    command = Command(script=script, output=output)
    rules_path = 'rules/git-status-git-st.py'
    rule = Rule.from_path(pathlib.Path(rules_path))
    assert rule.match(command) == True
    new_commands = rule.get_corrected_commands(command)
    for new_command in new_commands:
        assert new_command.script == 'git st'

# Generated at 2022-06-22 02:50:42.314571
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd1 = Command(script="ls", output="")
    cmd2 = Command(script="ls", output="")
    cmd3 = Command(script="ls ", output="")

    assert cmd1 == cmd2
    assert cmd1 != cmd3


# Generated at 2022-06-22 02:50:54.437273
# Unit test for constructor of class Command
def test_Command():
    """
    Test the constructor of class Command.
    """
    from .shells import shell
    c = Command('ls', '\n')
    c.update(script='ls -l')
    assert c.output == '\n'
    assert c.script == 'ls -l'
    assert c.script_parts == shell.split_command('ls -l')
    assert c == Command(script='ls -l', output='\n')
    assert c == c
    assert c != Command('ls', '\n')
    c_raw = Command.from_raw_script(['ls', '-l'])
    assert c_raw.output == '\n'
    assert c_raw.script == 'ls -l'
    logs.debug = logs.debug_off
    c1 = Command('ls', '\n')


# Generated at 2022-06-22 02:51:01.127226
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('ls', 'Hello\nworld') == Command('ls', 'Hello\nworld')
    assert Command('ls', 'Hello\nworld') != Command('ls', 'Hello')
    assert Command('ls', 'Hello\nworld') != Command('ls -l', 'Hello\nworld')
    assert Command('ls', 'Hello\nworld') != "ls"


# Generated at 2022-06-22 02:51:10.009966
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(name='test', match=lambda x: True, get_new_command=lambda x: 'ls', enabled_by_default=True, side_effect=None, priority=0, requires_output=True)
    assert repr(rule) == "Rule(name=test, match=<function <lambda> at 0x7f5d5c5c5ae8>, get_new_command=<function <lambda> at 0x7f5d5c5c5b70>, enabled_by_default=True, side_effect=None, priority=0, requires_output=True)"



# Generated at 2022-06-22 02:51:58.401708
# Unit test for constructor of class Rule
def test_Rule():
    from . import utils
    from .compat import parse

    Rule("a", utils.match_always, lambda a: "b", True, None, 1, True)



# Generated at 2022-06-22 02:52:03.292887
# Unit test for constructor of class Command
def test_Command():
    assert Command('pwd', 'pwd') == Command('pwd', 'pwd')
    assert Command('pwd', 'pwd') != Command('ls', 'ls')
    assert Command('pwd', 'pwd') != "foo"
    assert Command('pwd', 'pwd') != None

# Generated at 2022-06-22 02:52:06.301562
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    c = Command(script='ls', output='stdout')
    assert c.__repr__() == "Command(script='ls', output='stdout')"


# Generated at 2022-06-22 02:52:12.820931
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """Tests method CorrectedCommand.__hash__.

    >>> from tests.helpers import LoggedCommand

    >>> CorrectedCommand('ls', None, None).__hash__() == CorrectedCommand('ls', None, None).__hash__()
    True

    >>> CorrectedCommand('ls', None, None).__hash__() != CorrectedCommand('cd', None, None).__hash__()
    True

    """
    pass



# Generated at 2022-06-22 02:52:25.259228
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    def match_script_end1(command):  # pragma: no cover
        return command.script.endswith("1")
    rule1 = Rule("leeroy", match_script_end1, None, True, None, 0, False)
    rule2 = Rule("leeroy", match_script_end1, None, True, None, 0, False)
    assert(rule1 == rule2)

    def match_script_end2(command):  # pragma: no cover
        return command.script.endswith("2")
    rule3 = Rule("leeroy", match_script_end2, None, True, None, 0, False)
    assert(rule1 != rule3)

    rule4 = Rule("leeroy", match_script_end1, None, True, None, 0, False)
    rule4

# Generated at 2022-06-22 02:52:29.452510
# Unit test for method update of class Command
def test_Command_update():
    c = Command(script="git status", output="Hello World")
    c = c.update(script="git commit")
    assert c.script == "git commit"
    assert c.output == "Hello World"

if __name__ == '__main__':
    test_Command_update()

# Generated at 2022-06-22 02:52:40.214450
# Unit test for constructor of class Command
def test_Command():
    assert Command(
        "python -c 'import math; print 2+2'",
        '4'
    ) == Command(
        "python -c 'import math; print 2+2'",
        '4'
    )
    assert Command(
        "python -c 'import math; print 2+2'",
        '2'
    ) != Command(
        "python -c 'import math; print 2+2'",
        '4'
    )
    assert Command(
        "python -c 'print 2+2'",
        '4'
    ) != Command(
        "python -c 'import math; print 2+2'",
        '4'
    )


# Generated at 2022-06-22 02:52:44.528878
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert(Rule("", lambda x: x, lambda x: x, True, lambda x: x, 1, True) ==
           Rule("", lambda x: x, lambda x: x, True, lambda x: x, 1, True))



# Generated at 2022-06-22 02:52:48.224690
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd1 = Command("ls -al", "")
    cmd2 = Command("ls -al", "")
    cmd3 = Command("ls -al", "aaa")
    assert cmd1 == cmd2
    assert cmd1 != cmd3


# Generated at 2022-06-22 02:53:01.131375
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    from .utils import assert_equal
    from .rules import correct_cd_mkdir
    import nose.tools

    old_cmd = Command.from_raw_script([u'fuck', u'cd', u'wtf'])
    fst = CorrectedCommand(script='pwd', side_effect=None, priority=4)
    snd = CorrectedCommand(script='pwd', side_effect=None, priority=8)
    assert_equal(fst == snd, True)

    snd = CorrectedCommand(script='pwd', side_effect=correct_cd_mkdir.side_effect, priority=8)
    assert_equal(fst == snd, False)

    nose.tools.assert_is(fst == old_cmd, False)

# Generated at 2022-06-22 02:53:28.883099
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .shells import bash as shell
    a = Rule('test',lambda x: True,lambda x:x,True,None,0,True)
    b = Rule('test',lambda x: False,lambda x:x,True,None,0,True)
    test_command = Command.from_raw_script(
        ('git', 'clone', 'https://github.com/nvbn/thefuck'))
    assert a.is_match(test_command) == True
    assert b.is_match(test_command) == False

# Generated at 2022-06-22 02:53:35.782939
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .shells import bash
    from .shells.bash import split_command
    from .utils import format_commands
    r = Rule.from_path(Path('fuck/rules/always.py'))
    commands = list(r.get_corrected_commands(Command(bash.quote('git status'), 'git status')))
    assert len(commands) == 1, len(commands)
    assert commands[0].script == bash.quote('git status'), commands[0].script
    assert commands[0].side_effect is None, commands[0].side_effect
    assert commands[0].priority == r.priority, commands[0].priority
    commands = list(r.get_corrected_commands(Command(bash.quote('git status 1'), 'git status 1')))
    assert len(commands) == 1, len

# Generated at 2022-06-22 02:53:43.238281
# Unit test for constructor of class Rule
def test_Rule():
    a = Rule('test_name', 'match', 'get_new_command',
             True, 'side_effect', 10, False)
    assert(a.name == 'test_name')
    assert(a.match == 'match')
    assert(a.get_new_command == 'get_new_command')
    assert(a.enabled_by_default == True)
    assert(a.side_effect == 'side_effect')
    assert(a.priority == 10)
    assert(a.requires_output == False)


# Generated at 2022-06-22 02:53:48.525735
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command(script="hello world", output="hello world")
    assert cmd.update(script="hello", output="hello") == Command(script="hello", output="hello")
    assert cmd.update(script="hello") == Command(script="hello", output="hello world")


# Generated at 2022-06-22 02:53:58.059306
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule1 = Rule(name='name', match=None, get_new_command=None,
                 enabled_by_default=False, side_effect=None,
                 priority=0, requires_output=True)
    rule2 = Rule(name='name', match=None, get_new_command=None,
                 enabled_by_default=False, side_effect=None,
                 priority=0, requires_output=False)

    assert rule1.__eq__(rule1)
    assert not rule1.__eq__(rule2)
    assert not rule1.__eq__(None)
    assert not rule1.__eq__('string')


# Generated at 2022-06-22 02:54:03.524416
# Unit test for constructor of class Rule
def test_Rule():
    name = "test-1"
    match = lambda a: True
    get_new_command = lambda a: "echo hello"
    enabled_by_default = False
    side_effect = None
    priority = 2
    requires_output = False

    rule1 = Rule(name, match, get_new_command, enabled_by_default, side_effect, priority, requires_output)

    assert rule1.name == name
    assert rule1.match(None) == True
    assert rule1.get_new_command(None) == "echo hello"
    assert rule1.enabled_by_default == enabled_by_default
    assert rule1.priority == priority
    assert rule1.requires_output == requires_output



# Generated at 2022-06-22 02:54:06.617461
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    cmd = Command(script='foo', output='')
    assert repr(cmd) == 'Command(script=foo, output=)'



# Generated at 2022-06-22 02:54:09.320135
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    corrected = CorrectedCommand('foo', None, DEFAULT_PRIORITY)
    assert corrected.script == 'foo'
    assert corrected.side_effect is None
    assert corrected.priority == DEFAULT_PRIORITY

# Generated at 2022-06-22 02:54:21.774785
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import re
    import sys

    # This is dumb way to get the test script to work in Python 2, 3 or pypy
    # (and in Windows, too).
    this_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    py3 = sys.version_info >= (3, 0)
    if py3:
        with open(os.path.join(this_dir, 'fuck.py')) as f:
            fuck = f.read()
    else:
        with open(os.path.join(this_dir, 'fuck.py'), 'rb') as f:
            fuck = f.read().decode('utf-8')

# Generated at 2022-06-22 02:54:23.270170
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    #TODO(xion): Add test coverage for method CorrectedCommand.run
    pass


# Generated at 2022-06-22 02:54:50.911711
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    try:
        CorrectedCommand("test", "test", 0)
    except Exception as e:
        logs.error(e)

# Generated at 2022-06-22 02:55:02.588393
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    """Test method Rule.is_match."""
    def match_always(c):
        return True

    def match_never(c):
        return False

    def get_new_command(c):
        return 'new'

    def side_effect(c, s):
        pass

    r1 = Rule('name1', match_always, get_new_command, True, side_effect, 1, True)
    r2 = Rule('name1', match_never, get_new_command, True, side_effect, 1, True)
    r3 = Rule('name1', match_always, get_new_command, True, side_effect, 1, False)

    c1 = Command('', None)
    c2 = Command('cmd', 'output')

    assert r1.is_match(c1)
    assert not r2

# Generated at 2022-06-22 02:55:10.869006
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """
    Define a rule for correction by returning a list

    :return: True
    """
    def match(command):
        return True

    def get_new_command(command):
        return ["git status"]

    from .exceptions import EmptyCommand
    newCommand = CorrectedCommand("git status", lambda a, b: None, 1)

    rule = Rule("testRule", match, get_new_command, True, lambda a, b: None, 0, False)
    assert list(rule.get_corrected_commands(Command("test", None))) == [newCommand]


# Generated at 2022-06-22 02:55:13.244434
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    def side_effect(cmd, script):
        pass

    cc = CorrectedCommand('echo "hello"', side_effect, 2)
    assert 'hello' in set(map(str, [cc]))

# Generated at 2022-06-22 02:55:16.863598
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand(script='ls', side_effect=None, priority=10)
    assert cmd.script == 'ls'
    assert cmd.side_effect == None
    assert cmd.priority == 10
    assert cmd.repeat == False


# Generated at 2022-06-22 02:55:26.319715
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    cmd1 = Command('script', 'output')
    cmd2 = Command('script', 'output')
    assert cmd1 == cmd2

    def match(cmd):
        return True

    def get_new_command(cmd):
        return 'script2'

    def side_effect(cmd, new_cmd):
        pass

    r1 = Rule('name', match, get_new_command, True, side_effect, 5, True)
    r2 = Rule('name', match, get_new_command, True, side_effect, 5, True)
    assert r1 == r2



# Generated at 2022-06-22 02:55:29.218742
# Unit test for method update of class Command
def test_Command_update():
    c = Command('ls', 'hello')
    assert c.update() == c
    assert c.update(script='ls -l') == Command('ls -l', 'hello')
    assert c.update(output='there') == Command('ls', 'there')

# Generated at 2022-06-22 02:55:41.890072
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from . import fuck

    logs.debug(u'testing Method is_match of Class Rule')
    good_cmd = "echo 'hello world'"
    bad_cmd = "echo 'hello world"

    class GoodMatchRule(Rule):
        def match(self, cmd):
            return True

    class BadMatchRule(Rule):
        def match(self, cmd):
            return False

    class BadMatchException(Rule):
        def match(self, cmd):
            raise Exception

    class GoodGetNewCommand(Rule):
        def get_new_command(self, cmd):
            return cmd.output

    def test_func(function, res, name, debug=False):
        if debug:
            logs.debug("test function: {}".format(name))

# Generated at 2022-06-22 02:55:51.726523
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script = "echo 1", output = "") == Command(script = "echo 1", output = "")
    assert Command(script = "echo 1", output = "") != Command(script = "echo 2", output = "")
    assert Command(script = "echo 1", output = "") != Rule(name = "echo", match = lambda x : x.script == 'echo', get_new_command = lambda x : "echo " + '"1', enabled_by_default = True, side_effect = None, priority = 10, requires_output = True)
    assert Command(script = "echo 1", output = "") != ""


# Generated at 2022-06-22 02:55:55.495050
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand("ls", None, 1)
    assert cmd.script == "ls"
    assert cmd.side_effect == None
    assert cmd.priority == 1
    logs.info("Sucessfully tested method CorrectedCommand()")


# Generated at 2022-06-22 02:56:46.001122
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert Command("script", "output").__repr__() == \
        u'Command(script={}, output={})'.format("script", "output")


# Generated at 2022-06-22 02:56:51.374216
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
        #TODO: Add further testing
    print(Rule('reverse-echo', lambda x: True, lambda x: "echo 'olleh'", True, None, 5, True)
          .get_corrected_commands(Command("echo 'hello'", 'hello')))

# Generated at 2022-06-22 02:56:55.838222
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    match = lambda command: False
    requires_output = True
    rule = Rule(None, match, None, True, None, None, requires_output)
    assert rule.is_match(Command(script="false", output=False)) == False
    assert rule.is_match(Command(script="true", output=True)) == False

# Generated at 2022-06-22 02:57:01.455196
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
  assert CorrectedCommand('', '', '') == CorrectedCommand('', '', '')
  assert CorrectedCommand('', '', '') != CorrectedCommand('', '1', '')
  assert CorrectedCommand('', '', '') != CorrectedCommand('1', '', '')
  assert CorrectedCommand('', '', '') != CorrectedCommand('', '', '1')
  assert CorrectedCommand('1', '', '') != CorrectedCommand('', '', '')

# Generated at 2022-06-22 02:57:10.460586
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    from .utils import CommandOutput
    CorrectedCommand("f", lambda a, b: None, 1) == CorrectedCommand("f", lambda a, b: None, 2)
    CorrectedCommand("f", lambda a, b: None, 1) != CorrectedCommand("f", lambda a, b: None, 1)
    CorrectedCommand("f", lambda a, b: None, 1) != CorrectedCommand("g", lambda a, b: None, 1)
    CorrectedCommand("f", lambda a, b: None, 1) != CorrectedCommand("f", lambda a, b: None, 1, 1)



# Generated at 2022-06-22 02:57:17.049065
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command("ls", None) == Command("ls", None)
    assert Command("ls", None) != Command("ls", "")
    assert Command("ls", None) != Command("ls", "something")
    assert Command("ls", "") == Command("ls", "")
    assert Command("ls", "") != Command("ls", None)
    assert Command("ls", "") != Command("ls", "something")
    assert Command("ls", "something") == Command("ls", "something")
    assert Command("ls", "something") != Command("ls", None)
    assert Command("ls", "something") != Command("ls", "")
    assert Command("ls", None) != None
    assert None != Command("ls", None)
    assert Command("ls", None) != "something"
    assert "something" != Command("ls", None)



# Generated at 2022-06-22 02:57:21.355968
# Unit test for constructor of class Command
def test_Command():
    cmd = Command(script='ls', output='output')
    expected_cmd = Command(script='ls', output='output')
    assert(expected_cmd == cmd)


# Generated at 2022-06-22 02:57:31.777830
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    cmd_pair = [
            CorrectedCommand('/bin/ls', lambda command, script: None, 1000),
            CorrectedCommand('/bin/ls', lambda command, script: None, 1000)
            ]
    assert (cmd_pair[0] == cmd_pair[1])
    assert ((not cmd_pair[0] == None) and (not None == cmd_pair[0]))
    cmd_pair = [
            CorrectedCommand('/bin/ls -lta', lambda command, script: None, 1000),
            CorrectedCommand('/bin/ls -lta', lambda command, script: None, 1000)
            ]
    assert (cmd_pair[0] == cmd_pair[1])
    assert ((not cmd_pair[0] == None) and (not None == cmd_pair[0]))

# Generated at 2022-06-22 02:57:35.338008
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert repr(Rule('rule1', lambda command: False, lambda command: '&&', True, None, 1, True)) == 'Rule(name=rule1, match=<function <lambda> at 0x7f5a5c6a8e18>, get_new_command=<function <lambda> at 0x7f5a5c6a8e60>, enabled_by_default=True, side_effect=None, priority=1, requires_output=True)'


# Generated at 2022-06-22 02:57:42.285707
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rules_dir = pathlib.Path(__file__).resolve().parent / 'rules'
    for path in rules_dir.iterdir():
        if path.is_file() and path.name.endswith('.py'):
            rule = Rule.from_path(path)
            if 'test_failing_match' in dir(rule.match):
                assert False == rule.is_match(rule.match.test_failing_match)