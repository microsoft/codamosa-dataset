

# Generated at 2022-06-22 02:48:39.281625
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    # test for equal objects
    command1 = Command(
        script='PYTHONIOENCODING="utf-8" python',
        output='python: can\'t open file \'module.py\': [Errno 2] No such file or directory'
    )
    command2 = Command(
        script='PYTHONIOENCODING="utf-8" python',
        output='python: can\'t open file \'module.py\': [Errno 2] No such file or directory'
    )
    assert command1 == command2



# Generated at 2022-06-22 02:48:42.653959
# Unit test for method update of class Command
def test_Command_update():
    test_command = Command(script='test_script', output='test_output')
    assert test_command == test_command.update()
    test_command_new = test_command.update(script='new_script')
    assert test_command_new.script == 'new_script'
    assert test_command_new.output == test_command.output
    test_command_new1 = test_command.update(output='new_output')
    assert test_command_new1.script == test_command.script
    assert test_command_new1.output == 'new_output'

# Generated at 2022-06-22 02:48:52.646024
# Unit test for constructor of class Rule
def test_Rule():
    # test for basic case
    rule = Rule(name='test', match=lambda x: True, get_new_command=lambda x: x,
                enabled_by_default=False, side_effect=None,
                priority=1, requires_output=False)
    # test for __eq__ method
    assert rule.__eq__(Rule(name='test', match=lambda x: True,
                            get_new_command=lambda x: x,
                            enabled_by_default=False, side_effect=None,
                            priority=1, requires_output=False)) == True

# Generated at 2022-06-22 02:48:54.834042
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command('script', 'output')
    assert repr(command) == "Command(script='script', output='output')"


# Generated at 2022-06-22 02:48:58.300222
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    command = CorrectedCommand('git push', side_effect=lambda o, s: None, priority=DEFAULT_PRIORITY)
    assert command.script == 'git push'
    assert command.side_effect == (lambda o, s: None)
    assert command.priority == DEFAULT_PRIORITY

# Generated at 2022-06-22 02:49:01.711250
# Unit test for constructor of class Command
def test_Command():
    script = 'ls'
    output = 'error'
    cmd = Command(script, output)
    assert cmd.script == script
    assert cmd.output == output



# Generated at 2022-06-22 02:49:06.677571
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    command1 = Command(script="echo", output="echo")
    command2 = Command(script="echo", output="echo")
    assert command1 == command2
    command3 = Command(script="echo", output="EchO")
    assert command1 == command3


# Generated at 2022-06-22 02:49:09.182784
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    cmd = CorrectedCommand('ls', 'print()', 0)
    assert repr(cmd) == "CorrectedCommand(script='ls', side_effect='print()', priority=0)"

# Generated at 2022-06-22 02:49:17.536474
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_module = load_source(
        'test_rule',
        'thefuck/rules/test_rule.py')
    rule = Rule.from_path(Path(__file__).parent.parent.joinpath('rules','test_rule.py'))
    assert rule.is_match(Command(script='test1', output='test1')) == True
    assert rule.is_match(Command(script='test2', output='test2')) == False
    assert rule.is_match(Command(script='test1', output=None)) == False



# Generated at 2022-06-22 02:49:30.191001
# Unit test for constructor of class Rule
def test_Rule():
    """Unit test for constructor of class Rule."""
    match = lambda cmd: True
    get_new_cmd = lambda cmd: 'echo True'
    name = 'test_rule'
    side_effect = lambda cmd, new_cmd: None
    enabled_by_default = True
    priority = 1
    requires_output = True
    x = Rule(name, match, get_new_cmd, enabled_by_default, side_effect, priority, requires_output)
    assert x.name == name
    assert x.match == match
    assert x.get_new_command == get_new_cmd
    assert x.enabled_by_default == enabled_by_default
    assert x.side_effect == side_effect
    assert x.priority == priority
    assert x.requires_output == requires_output

# Generated at 2022-06-22 02:49:41.077257
# Unit test for method update of class Command
def test_Command_update():
    script = 'fuck this testing!'
    output = 'haha. you have done a great job'
    command = Command(script, output)
    assert command.update(script = 'this is testing!') == Command("this is testing!", output)
    assert command.update(output = "you have done a great job") == Command(script, "you have done a great job")
    assert command.update() == Command(script, output)


# Generated at 2022-06-22 02:49:51.053400
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    # Tests when other is Command
    command1 = Command(script="grep -R foo ~", output=None)
    assert command1.__eq__(command1)
    command2 = Command(script="grep -R foo ~", output=None)
    assert command1.__eq__(command2)
    command3 = Command(script="grep -R foo ~", output="bar")
    assert not command1.__eq__(command3)
    # Tests when other is not Command
    assert not command1.__eq__(None)
    assert not command1.__eq__("grep -R foo ~")


# Generated at 2022-06-22 02:49:53.911837
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand(script="cd -", side_effect=None, priority=0) == \
        CorrectedCommand(script="cd -", side_effect=None, priority=1)

# Generated at 2022-06-22 02:50:05.559493
# Unit test for constructor of class Rule
def test_Rule():
    # test case 1
    name = 'ls'
    match = lambda command: True
    get_new_command = lambda old_command: 'ls'
    enabled_by_default = True
    side_effect = None
    priority = 5
    requires_output = True
    rule = Rule(name, match, get_new_command, enabled_by_default, side_effect, priority, requires_output)
    assert rule.name == name
    assert rule.match == match
    assert rule.get_new_command == get_new_command
    assert rule.enabled_by_default == enabled_by_default
    assert rule.side_effect == side_effect
    assert rule.priority == priority
    assert rule.requires_output == requires_output
    assert rule.is_enabled == True

# Generated at 2022-06-22 02:50:10.195445
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    a = CorrectedCommand('echo hi', None, None)
    b = CorrectedCommand('echo hi', None, None)
    assert a.__hash__() == b.__hash__()
    b.script = 'echo bye'
    assert a.__hash__() != b.__hash__()

# Generated at 2022-06-22 02:50:22.042379
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule1 = Rule("test.py", lambda x: True, lambda x: [x.script], True, None, 0, True)
    command1 = Command("eval 'cd ~'", None)
    assert len(list(rule1.get_corrected_commands(command1))) == 1
    assert list(rule1.get_corrected_commands(command1))[0].script == "eval 'cd ~'"
    assert list(rule1.get_corrected_commands(command1))[0].priority == 0
    assert list(rule1.get_corrected_commands(command1))[0].side_effect == None

    rule2 = Rule("test.py", lambda x: True, lambda x: ["eval 'cd ~'", "eval 'cd ~'"], True, None, 0, True)

# Generated at 2022-06-22 02:50:28.954818
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .commands import Command

    def assert_run(expected_script, expected_side_effect_arg, expected_repeat,
                   side_effect, script, repeat):
        old_cmd = Command(script='old_script', output='old_output')

        corrected_cmd = CorrectedCommand(
            script=script,
            side_effect=side_effect,
            priority=0
        )

        with patch('thefuck.rules.shell') as mocked_shell, \
                patch('thefuck.rules.logs') as mocked_logs, \
                patch('thefuck.rules.os.environ', dict()), \
                patch('thefuck.rules.settings', _settings(repeat)):
            corrected_cmd.run(old_cmd)

        assert mocked_shell.put_to_history.called
        corrected_cmd.side

# Generated at 2022-06-22 02:50:34.436368
# Unit test for method update of class Command
def test_Command_update():
    command = Command('script', 'output')
    assert command == command.update()
    assert Command('new_script', 'output') == command.update(script='new_script')
    assert Command('script', 'new_output') == command.update(output='new_output')


# Generated at 2022-06-22 02:50:39.079071
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('echo hallo', None) == Command('echo hallo', None)
    assert Command('echo hallo', None) != Command('echo hello', None)
    assert Command('echo hallo', None) != Command('echo hallo', '')
    assert Command('echo hallo', None) != Command('echo hallo', None)
    assert Command('echo hallo', None) != None


# Generated at 2022-06-22 02:50:50.873356
# Unit test for constructor of class Rule
def test_Rule():
    global settings
    settings = Mock()
    assert settings.exclude_rules is not None
    assert settings.rules is not None
    assert settings.priority is not None
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.alter_history == True

    # 1st case:
    # all settings.priority is not empty, and settings.priority is not None
    settings.priority = {'test': 10}
    result = settings.priority.get('test', 20)
    assert result == 10

    # 2nd case:
    # settings.priority is None, result should use default value,
    # which is DEFAULT_PRIORITY.
    settings.priority = None
    result = settings.priority.get('test', 'test')
    assert result == 'test'

# Generated at 2022-06-22 02:51:13.319006
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    cmd1 = CorrectedCommand('script', None, 0)
    cmd2 = CorrectedCommand('script', None, 1)
    cmd3 = CorrectedCommand('script', None, 0)
    cmd4 = CorrectedCommand('script2', None, 1)
    assert cmd1 == cmd1
    assert cmd1 == cmd3
    assert cmd1 != cmd2
    assert cmd1 != cmd4

# Generated at 2022-06-22 02:51:18.502627
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('first', side_effect=0, priority=0) == \
           CorrectedCommand('first', side_effect=0, priority=1)
    assert CorrectedCommand('first', side_effect=0, priority=0) != \
           CorrectedCommand('second', side_effect=0, priority=0)

# Generated at 2022-06-22 02:51:29.780751
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import tempfile
    files = []
    def side_effect(old_cmd, new_cmd):
        nonlocal files
        fname = tempfile.NamedTemporaryFile(prefix='test_CorrectedCommand_run_',
                         suffix='_' + new_cmd, delete=False).name
        with open(fname, 'w') as f:
            f.write(new_cmd)
        files.append(fname)
    CorrectedCommand('foo', side_effect=side_effect, priority=0).run(None)
    with open(files[0]) as f:
        assert 'foo' == f.read()
    CorrectedCommand('foo && bar', side_effect=side_effect, priority=0).run(None)

# Generated at 2022-06-22 02:51:38.386302
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('fuck', '', 1) == \
           CorrectedCommand('fuck', '', 1)
    assert CorrectedCommand('fuck', '', 1) != \
           CorrectedCommand('ls', '', 1)
    assert CorrectedCommand('fuck', '', 1) != \
           CorrectedCommand('fuck', '', 2)
    assert CorrectedCommand('fuck', '', 1) != \
           CorrectedCommand('fuck', 'ls', 1)
    assert CorrectedCommand('fuck', '', 1) != \
           CorrectedCommand('fuck', '', 1, 'extra')

# Generated at 2022-06-22 02:51:42.191349
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    from os import path
    from .rules import fuck

    CorrectedCommand(script=path.abspath('/some/path.py'),
                     side_effect=fuck(get_new_command=lambda *args: None),
                     priority=1)

# Generated at 2022-06-22 02:51:55.048489
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import pytest

    # Test rule that generates single corrected command
    def test_match(command):
        return True

    def test_get_new_command(command):
        return "test_script"

    def test_side_effect(command, new_command):
        pass

    rule = Rule("test_rule", test_match, test_get_new_command, True, test_side_effect, 1, True)
    command = Command('ls -la', 'output')
    expected_corrected_command = CorrectedCommand(script='test_script', side_effect=test_side_effect, priority=1)
    generated_corrected_commands = rule.get_corrected_commands(command)
    assert expected_corrected_command == next(generated_corrected_commands)

# Generated at 2022-06-22 02:52:06.493757
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    a = Rule('ls', lambda x: True, lambda x: None, True, lambda x, y: None, 1, True)
    a1 = Rule('ls', lambda x: True, lambda x: None, True, lambda x, y: None, 1, True)
    b = Rule('ls', lambda x: True, lambda x: None, True, lambda x, y: None, 1, False)
    c = Rule('ls', lambda x: True, lambda x: None, False, lambda x, y: None, 1, True)
    d = Rule('ls', lambda x: True, lambda x: None, True, lambda x, y: None, 2, True)
    e = Rule('ls', lambda x: False, lambda x: None, True, lambda x, y: None, 1, True)

# Generated at 2022-06-22 02:52:13.004380
# Unit test for method update of class Command
def test_Command_update():
    command = Command(script='fuck', output='wrong')
    assert command.update() == Command(script='fuck', output='wrong')
    assert command.update(script='fk') == Command(script='fk', output='wrong')
    assert command.update(output='right') == Command(script='fuck', output='right')
    assert command.update(script='fk', output='right') == Command(script='fk', output='right')

# Generated at 2022-06-22 02:52:24.986987
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # Two diffrent CorrectedCommand instances,
    # CorrectedCommand1.script = echo_test, CorrectedCommand2.script = pwd
    class command1(object):
        def __init__(self):
            self.script = 'echo_test'
    CorrectedCommand1 = CorrectedCommand(script = 'echo_test', side_effect = None, priority = 1)
    CorrectedCommand2 = CorrectedCommand(script = 'pwd', side_effect = None, priority = 1)

    # Once run method is called, it should return 'echo_test', then return 'pwd'
    assert(CorrectedCommand1.run(command1()) == 'echo_test')
    assert(CorrectedCommand2.run(command1()) == 'pwd')

test_CorrectedCommand_run()

# Generated at 2022-06-22 02:52:26.933759
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script="ls -l",
                     side_effect=None,
                     priority=5)

# Generated at 2022-06-22 02:52:45.516493
# Unit test for method update of class Command
def test_Command_update():
    # t = Command("ls", "~/dir")
    # assert t.update(output = "~/dir/file") == Command("ls", "~/dir/file")
    # assert t == Command("ls", "~/dir")

    t = Command("ls", None)
    assert t.update(output = "~/dir/file") == Command("ls", "~/dir/file")
    assert t == Command("ls", None)


# Generated at 2022-06-22 02:52:49.854721
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    p = CorrectedCommand(script="git add .", side_effect=None, priority=1)
    assert repr(p) == u'CorrectedCommand(script=git add ., side_effect=None, priority=1)'



# Generated at 2022-06-22 02:52:55.691151
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command.from_raw_script('ls') == Command.from_raw_script('ls')
    assert Command.from_raw_script('ls') != 1
    assert Command.from_raw_script('ls') != 'ls'
    assert Command.from_raw_script('cat foo.txt') != Command.from_raw_script('cat bar.txt')


# Generated at 2022-06-22 02:53:01.935798
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    with logs.debug():
        corrected_cmd = CorrectedCommand(script='git commit --amend', side_effect=lambda a,b: None, priority=1)
        assert repr(corrected_cmd) == u'CorrectedCommand(script=git commit --amend, side_effect=<function <lambda> at 0x7f1884e8a8c0>, priority=1)'


# Generated at 2022-06-22 02:53:05.066329
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    script = "script"
    output = "output"
    cmd = Command(script, output)
    assert repr(cmd) == "Command(script={}, output={})".format(script, output)


# Generated at 2022-06-22 02:53:10.083614
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('a', 'b') == Command('a', 'b')
    assert Command('a', 'b') != Command('a', 'c')
    assert Command('a', 'b') != Command('c', 'b')
    assert Command('a', 'b') != 'a'



# Generated at 2022-06-22 02:53:18.349039
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():

    def match(command):
        return True

    def get_new_command(command):
        return 'new'

    def side_effect(command, new_command):
        pass

    rule1 = Rule('rule1', match, get_new_command,
     True, side_effect, 1, True)
    rule2 = Rule('rule1', match, get_new_command,
     True, side_effect, 1, True)
    assert rule1 == rule2
    assert not rule1 == 'rule1'

# Generated at 2022-06-22 02:53:19.234343
# Unit test for constructor of class Command
def test_Command():
    command = Command(script='ls', output='ls')
    assert command.script == 'ls'
    assert command.output == 'ls'

# Generated at 2022-06-22 02:53:31.239378
# Unit test for constructor of class Rule
def test_Rule():
    def match(command):
        return True
    def get_new_command(command):
        return 'ls'
    side_effect = None
    priority = 3
    enabled_by_default = True
    rule = Rule('ls', match, get_new_command,
                enabled_by_default, side_effect,
                priority)
    # Test rule.name
    assert rule.name == 'ls'
    # Test rule.match
    assert rule.match(Command('ls', None))
    assert not rule.match(Command('cd', None))
    # Test rule.get_new_command
    get_new_commands = rule.get_new_command(Command('ls', None))
    assert get_new_commands == 'ls'
    # Test rule.enabled_by_default
    assert rule.enabled_by_default

# Generated at 2022-06-22 02:53:37.601210
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('echo 1', None, None) == CorrectedCommand('echo 1', None, None)
    assert CorrectedCommand('echo 1', None, None) != CorrectedCommand('echo 2', None, None)
    assert CorrectedCommand('echo 1', None, None) != CorrectedCommand('echo 1', '', None)
    assert CorrectedCommand('echo 1', None, None) != 'echo 1'

# Generated at 2022-06-22 02:54:08.344942
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule("mv", lambda x: x.script == 'mv test/haha', lambda x: 'mv haha/test', True, None, 1000, True)
    assert repr(rule) == 'Rule(name=mv, match=<function <lambda> at 0x7f8ce166c6a8>, get_new_command=<function <lambda> at 0x7f8ce166c6e0>, enabled_by_default=True, side_effect=None, priority=1000, requires_output=True)'


# Generated at 2022-06-22 02:54:15.982139
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import os
    class Command(object):
        script = "ls"
    old_cmd = Command()
    script = "ls -al"
    def side_effect(old_cmd, script):
        assert old_cmd == Command()
        assert script == "ls -al"
    CorrectedCommand(script, side_effect, 1).run(old_cmd)
    assert os.getenv('PYTHONIOENCODING') is not None

# Generated at 2022-06-22 02:54:24.952040
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c1 = CorrectedCommand(script='ls', side_effect=None, priority=None)
    c2 = CorrectedCommand(script='ls', side_effect=None, priority=5)
    c3 = CorrectedCommand(script='ls', side_effect=lambda a, b: None, priority=None)
    c4 = CorrectedCommand(script='cat', side_effect=None, priority=None)
    c5 = CorrectedCommand(script='ls', side_effect='some_effect', priority=None)
    c6 = CorrectedCommand(script='ls', side_effect=None, priority=None)

    assert c1 == c6
    assert c1 != c2
    assert c1 != c3
    assert c1 != c4
    assert c1 != c5



# Generated at 2022-06-22 02:54:36.149572
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .output_readers import get_output
    from .shells import shell
    from . import settings
    from .exceptions import EmptyCommand

    # unit test for ignore_rules
    def match_test1(command):
        return True

    def get_new_command_test1(command):
        return 'ls'

    def side_effect_test1(command, corrected_command):
        pass

    def match_test2(command):
        return True

    def get_new_command_test2(command):
        return 'ls'

    def side_effect_test2(command, corrected_command):
        pass


# Generated at 2022-06-22 02:54:45.737036
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    try:
        CorrectedCommand(None, None, None).__eq__(None)
    except NotImplementedError:
        pass
    else:
        assert False

    assert CorrectedCommand('1', '2', '3') == CorrectedCommand('1', '2', '3')
    assert CorrectedCommand('1', '2', '3') != CorrectedCommand('1', '2', '5')
    assert CorrectedCommand('1', '2', '3') != CorrectedCommand('1', '4', '3')
    assert CorrectedCommand('1', '2', '3') != CorrectedCommand('5', '2', '3')



# Generated at 2022-06-22 02:54:48.491315
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert CorrectedCommand(script='echo', side_effect=None, priority=1).__repr__() == 'CorrectedCommand(script=echo, side_effect=None, priority=1)'



# Generated at 2022-06-22 02:55:01.177317
# Unit test for constructor of class Rule
def test_Rule():
    from . import rules
    rule = Rule("fuck", rules.match, rules.get_new_command,
                True, rules.side_effect, 1, True)
    assert rule.name == "fuck"
    assert rule.match == rules.match
    assert rule.get_new_command == rules.get_new_command
    assert rule.enabled_by_default == True
    assert rule.side_effect == rules.side_effect
    assert rule.priority == 1
    assert rule.requires_output == True
    assert rule.is_enabled == True
    assert rule.is_match("if [ -d ~/file ];then rm -r ~/file;fi")

# Generated at 2022-06-22 02:55:08.792175
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c = CorrectedCommand(script="aa", side_effect=None, priority=1)
    assert c == CorrectedCommand(script="aa", side_effect=None, priority=1)
    assert c == CorrectedCommand(script="aa", side_effect=None, priority=2)
    assert c != CorrectedCommand(script="aa", side_effect=lambda x, y: None, priority=1)
    assert c == ("aa", None, 1)
    assert c != ("aa", None, 2)
    assert c != 1

# Generated at 2022-06-22 02:55:18.724200
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """ Test of the method `get_corrected_commands` of the class `Rule`
    """
    from thefuck import shells, utils
    from thefuck.rules import (any_command,
                               get_new_command,
                               get_priority)

    #
    # Test with returns a string instead of a list
    #

    # Test without side effect
    rule = Rule('name',
                any_command,
                get_new_command(r'ls'),
                True,
                None,
                get_priority(0),
                False)
    correct_command = CorrectedCommand(script='ls',
                                       side_effect=None,
                                       priority=0)

    #
    # Test with side effect
    #

    # Test without side effect

# Generated at 2022-06-22 02:55:24.734998
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    script1 = 'command'
    output1 = 'output'
    script2 = 'command'
    output2 = 'output'
    assert Command(script1, output1).__eq__(Command(script2, output2)) is True
    assert Command(script1, output1).__eq__('') is False


# Generated at 2022-06-22 02:56:20.048637
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    from .rules import some
    rule = Rule.from_path(Path(some.__file__))
    assert repr(rule) == \
        'Rule(name=some, match=<function match at 0x10270df28>, ' \
        'get_new_command=<function get_new_command at 0x10270df50>, ' \
        'enabled_by_default=True, side_effect=None, priority=5, ' \
        'requires_output=True)'


# Generated at 2022-06-22 02:56:32.316535
# Unit test for constructor of class Command
def test_Command():
    assert Command(script='ls', output='stdout').script == 'ls'
    assert Command(script='ls', output='stdout').output == 'stdout'
    # Test for deprecated field `stdout`
    assert Command(script='ls', output='stdout').stdout == 'stdout'
    # Test for deprecated field `stderr`
    assert Command(script='ls', output='stderr').stderr == 'stderr'
    assert Command(script='ls', output='stdout').script_parts == ['ls']
    assert (Command(script='ls', output='stdout') ==
            Command(script='ls', output='stdout'))
    assert (Command(script='ls', output='stdout').update(script='pwd') ==
            Command(script='pwd', output='stdout'))


# Generated at 2022-06-22 02:56:35.868426
# Unit test for method update of class Command
def test_Command_update():
    c = Command("c.py", "a.txt")
    assert c.update(script='new.py') == Command("new.py", "a.txt")
    assert c.update(output='b.txt') == Command("c.py", "b.txt")

# Generated at 2022-06-22 02:56:40.113837
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    script = 'echo test'
    side_effect = 'echo test2'
    c1 = CorrectedCommand(script, side_effect, 1)
    c2 = CorrectedCommand(script, side_effect, 2)
    assert c1.__eq__(c2)
    assert c1.__hash__() == c2.__hash__()


# Generated at 2022-06-22 02:56:52.138283
# Unit test for method update of class Command
def test_Command_update():
    script = 'echo "algo" > test'
    out = 'algo'
    c = Command(script, out)

    new_c = c.update(script = 'echo "outra coisa" > test2')
    assert new_c.script == 'echo "outra coisa" > test2'
    assert new_c.output == 'algo'
    assert new_c.priority == c.priority

    new_c = c.update(output = 'outra coisa')
    assert new_c.script == script
    assert new_c.output == 'outra coisa'
    assert new_c.priority == c.priority

    new_c = c.update(script = 'echo "outra coisa" > test2', output = 'outra coisa')

# Generated at 2022-06-22 02:57:01.695935
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Verifies that get_corrected_commands works correctly"""
    rule = Rule('test_rule', None, None, True, None,
                0, True)

    script = 'test_get_corrected_commands command'
    command = Command(script, 'test_rule_output')

    def get_new_command_fn(command):
        assert command == Command(script, 'test_rule_output')
        return ['cp', script, script + '1']

    rule.get_new_command = get_new_command_fn

    corrected_commands = rule.get_corrected_commands(command)
    expected_script = Command(script, 'test_rule_output')
    expected_command1 = CorrectedCommand('cp', None, 1)

# Generated at 2022-06-22 02:57:12.546085
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Fix case where get_new_command is not a list
    def get_new_command(command):
        return [command.script]
    name = 'test_one'
    match = lambda x: True
    enabled = True
    side_effect = None
    requires_output = False
    priority = DEFAULT_PRIORITY
    rule = Rule(
        name=name,
        match=match,
        get_new_command=get_new_command,
        enabled_by_default=enabled,
        side_effect=side_effect,
        priority=priority,
        requires_output=requires_output)
    command = Command(script='echo "ok"', output=None)
    for i, corrected_command in enumerate(rule.get_corrected_commands(command)):
        assert corrected_command.priority == i

# Generated at 2022-06-22 02:57:14.913504
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd = Command('script', 'output')
    assert cmd == Command('script', 'output')
    assert not (cmd == Command('script2', 'output'))
    assert not (cmd == Command('script', 'output2'))



# Generated at 2022-06-22 02:57:19.395076
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1 = Command("abc", "abc")
    c2 = Command("abc", "abc")
    c3 = Command("abc", "abcd")
    assert c1 == c2
    assert c1 != c2
    assert c1 != c3


# Generated at 2022-06-22 02:57:31.094912
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .backports.tempfile import NamedTemporaryFile
    from .shells import bash
    # Put echo in settings.aliases
    settings.aliases.append("echo")
    # Get the name of the last command in bash history
    with NamedTemporaryFile() as f:
        bash.history_filename = f.name
        bash.put_to_history("echo command")
    # Get the last command in bash history
    last_command = bash.get_from_history(-1)
    # Make sure the command has been added to bash history
    assert last_command == "echo command"

    # Assert that the command is a bash command
    assert isinstance(last_command, basestring)
    # Create a Command with the last command
    cmd = Command.from_raw_script(last_command)

    # Make sure the command