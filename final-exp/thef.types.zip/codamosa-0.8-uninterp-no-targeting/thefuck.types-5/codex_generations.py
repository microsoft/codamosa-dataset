

# Generated at 2022-06-22 02:48:39.230290
# Unit test for constructor of class Rule
def test_Rule():
    def match(command):
        return True
    def get_new_command(command):
        return None
    side_effect = None
    priority = 10
    requires_output = True
    requires_output = True
    rule = Rule(name="hello", match=match, get_new_command=get_new_command,
                enabled_by_default=True, side_effect=side_effect,
                priority=priority, requires_output=requires_output)
    assert rule.name == "hello"
    assert rule.match == match
    assert rule.get_new_command == get_new_command
    assert rule.enabled_by_default == True
    assert rule.side_effect == None
    assert rule.priority == 10
    assert rule.requires_output == True



# Generated at 2022-06-22 02:48:48.909915
# Unit test for constructor of class Command
def test_Command():
    assert Command('foo', 'bar') == Command('foo', 'bar')
    assert Command('foo', 'bar') != Command('bar', 'foo')
    assert Command('foo', 'bar') != 'foo'
    assert Command(script='foo', output='bar').script == 'foo'
    assert Command(script='foo', output='bar').output == 'bar'
    assert Command(script='foo', output='bar').update(script='foo1') != Command(script='foo', output='bar')
    assert Command(script='foo', output='bar').update(script='foo1').script == 'foo1'
    assert Command.from_raw_script(['foo']).script == 'foo'
    assert Command.from_raw_script(['foo']).output == 'bar'


# Generated at 2022-06-22 02:48:55.412205
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script='test', output='test') \
        == Command(script='test', output='test')
    assert Command(script='test', output='test') \
        != Command(script='test', output='test2')
    assert Command(script='test', output='test') \
        != Command(script='test2', output='test')


# Generated at 2022-06-22 02:49:00.745183
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    logs.debug(u'Testing method is_match of class Rule')
    cmd = Command(script=u'echo 1', output=u'1')
    rule = Rule(name=u'name1', match=lambda _: True, get_new_command=lambda _: [u'echo 1'],
                enabled_by_default=True, side_effect=lambda _, __: None,
                priority=1, requires_output=False)
    assert rule.is_match(cmd)
    logs.debug(u'Finished testing method is_match of class Rule')



# Generated at 2022-06-22 02:49:08.819335
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert Rule(name="name", match=lambda x: False, get_new_command=lambda x: x,
                enabled_by_default=False, side_effect=lambda x, y: None,
                priority=2, requires_output=True) == eval(repr(Rule(name="name", match=lambda x: False, get_new_command=lambda x: x,
                enabled_by_default=False, side_effect=lambda x, y: None,
                priority=2, requires_output=True)))


# Generated at 2022-06-22 02:49:17.537320
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from StringIO import StringIO
    from thefuck.main import prepare_settings

    settings = prepare_settings(False, True, 'cp', 'python', False, False, None, True, None, False)
    command = Command(script='cd /tmp/', output='')
    corrected_command = CorrectedCommand(script='a', side_effect=None, priority=None)
    sys.stdout, old_stdout = StringIO(), sys.stdout
    corrected_command.run(command)
    assert sys.stdout.getvalue() == command.script + 'a'
    sys.stdout = old_stdout

# Generated at 2022-06-22 02:49:29.509582
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Create a mock of function match
    def mock_match(x):
        return x is x

    # Create a mock of the Rule class
    mock_rule = Rule(name=None, match=mock_match, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None)

    # Create mock objects of command
    mock_command_1 = Command(script=None, output=None)
    mock_command_2 = Command(script=None, output=None)

    assert(mock_rule.is_match(mock_command_1) == True)
    assert(mock_rule.is_match(mock_command_2) == False)


# Generated at 2022-06-22 02:49:41.670039
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    """CorrectedCommand.run(command)

    Command: Test command
    Shell: bash
    Shell command: "fuck"

    Test that CorrectedCommand.run(command) returns:
    "fuck Test command || fuck --repeat fuck Test command"

    """
    from . import conf
    conf.settings.repeat = True
    conf.settings.debug = False
    from .shells import bash
    from .utils import get_alias

    test_cmd = "Test command"
    test_alias = get_alias()
    expected_out = bash.or_(test_cmd, "{} --repeat {} {}".format(test_alias, test_alias,
                                                                 bash.quote(test_cmd)))

    correct_cmd = CorrectedCommand(script=test_cmd, side_effect=None, priority=1)

    assert correct_cmd._get

# Generated at 2022-06-22 02:49:53.965461
# Unit test for constructor of class Rule
def test_Rule():
    match_1 = lambda command: True
    match_2 = lambda command: False
    get_new_command_1 = lambda command: 'command_1'
    get_new_command_2 = lambda command: 'command_2'
    side_effect_1 = lambda command, cmd: None
    side_effect_2 = lambda command, cmd: None
    priority_1 = 100
    priority_2 = 200
    requires_output_1 = False
    requires_output_2 = True


# Generated at 2022-06-22 02:49:56.774527
# Unit test for constructor of class Command
def test_Command():
    command = Command.from_raw_script(['fuck', 'ls'])
    assert command.script == 'ls'
    assert command.output == ''


# Generated at 2022-06-22 02:50:11.373575
# Unit test for method update of class Command
def test_Command_update():
    c = Command(script = "ls", output='ls')
    assert c.update().script == "ls"
    assert c.update(script = "ls -l").script == "ls -l"
    assert c.update(output = "ls -l").output == "ls -l"
    assert c.update(script = "ls -l", output = "ls -l").script == "ls -l"
    assert c.update(script = "ls -l", output = "ls -l").output == "ls -l"


# Generated at 2022-06-22 02:50:23.099462
# Unit test for constructor of class Command
def test_Command():
    """Unit test for `Command` class."""

    def test_initialization(script, output):
        """Tests initialization of `Command` class."""
        command = Command(script, output)
        logs.debug(u'Checking if `command` '
                   u'has correct values after initialization.')
        assert command.script == script, \
            u'`script` field has unexpected value ' \
            u'after initialization.'
        assert command.output == output, \
            u'`output` field has unexpected value ' \
            u'after initialization.'
        logs.debug(u'`command` is OK after initialization.\n')

    test_initialization('ls', None)
    test_initialization('ls', '')
    test_initialization('ls', 'some output')


# Generated at 2022-06-22 02:50:30.344215
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule(
        name='a',
        match=lambda x: True,
        get_new_command=lambda x: 'echo',
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True
    ) == Rule(
        name='a',
        match=lambda x: True,
        get_new_command=lambda x: 'echo',
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True
    )

# Generated at 2022-06-22 02:50:37.990315
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    c = CorrectedCommand("fuck my command", None, 0)
    c2 = CorrectedCommand("fuck my command", None, 0)
    c3 = CorrectedCommand("fuck my command", None, 0)
    assert hash(c) == hash(c2)
    assert hash(c) == hash(c3)
    c4 = CorrectedCommand("fuck my command", None, 1)
    assert hash(c) != hash(c4)

test_CorrectedCommand___hash__()


# Generated at 2022-06-22 02:50:45.933197
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Unit test for method get_corrected_commands of class Rule."""
    def match(cmd):
        return True

    def get_new_command(cmd):
        return ['ls']

    def side_effect(cmd, new_cmd):
        pass

    rule = Rule('ls', match, get_new_command, True, side_effect)
    gen = rule.get_corrected_commands(Command(script = '', output = ''))
    next(gen)

# Generated at 2022-06-22 02:50:48.011081
# Unit test for method __repr__ of class Command
def test_Command___repr__():
	inst = Command("a", "b")
	assert eval(inst.__repr__( )) == inst


# Generated at 2022-06-22 02:50:54.924450
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    """Unit test for method __eq__ of class CorrectedCommand."""
    corrected_command_1 = CorrectedCommand(
        script='script',
        side_effect=None,
        priority=0,
    )
    corrected_command_2 = CorrectedCommand(
        script='script',
        side_effect=None,
        priority=0,
    )
    assert corrected_command_1 == corrected_command_2



# Generated at 2022-06-22 02:51:01.233403
# Unit test for method update of class Command
def test_Command_update():
    cmd1 = Command('ls', 'output')
    cmd1 = cmd1.update(script='atrrib')
    cmd2 = Command('ls', 'output')
    cmd2.script = 'attrib'
    cmd3 = Command('atrrib', 'output')
    assert cmd1 == cmd2 and cmd1 != cmd3

# Generated at 2022-06-22 02:51:11.243969
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    """
    >>> def match(command):
    ...     return True
    >>> def get_new_command(command):
    ...     return 'ls'
    >>> def side_effect(command, new_command):
    ...     pass
    >>> Rule('test_rule', match, get_new_command, True, side_effect, 1, True).__repr__()
    'Rule(name=test_rule, match=<function match at 0x...>, get_new_command=<function get_new_command at 0x...>, enabled_by_default=True, side_effect=<function side_effect at 0x...>, priority=1, requires_output=True)'
    """


# Generated at 2022-06-22 02:51:14.218654
# Unit test for constructor of class Command
def test_Command():

    script = 'ls'
    output = 't'

    command = Command(script, output)

    assert command.script == script
    assert command.output == output


# Generated at 2022-06-22 02:51:25.727801
# Unit test for method update of class Command
def test_Command_update():
    command1 = Command(script='asd', output='asd')
    command2 = command1.update(script='ff')
    assert command1.script == 'asd'
    assert command1.output == 'asd'
    assert command2.script == 'ff'
    assert command2.output == 'asd'
    return True

# Generated at 2022-06-22 02:51:31.658906
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script="echo 1", output="1") == Command(script="echo 1", output="1")
    assert Command(script="echo 1", output="1") == Command(script="echo 1", output="1")
    assert Command(script="echo 1", output="1") == Command(script="echo 1", output="1")



# Generated at 2022-06-22 02:51:35.456451
# Unit test for constructor of class Command
def test_Command():
    test_command = Command(script=shell.from_shell('foo bar'), output='foobar')
    assert test_command.script == shell.from_shell('foo bar')
    assert test_command.output == 'foobar'


# Generated at 2022-06-22 02:51:43.558571
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
  rule = Rule("name", lambda: True, lambda: True, True, lambda: True, 10, True)
  assert repr(rule) == "Rule(name=name, match=<function <lambda> at 0x7ff6f099c938>, get_new_command=<function <lambda> at 0x7ff6f099c758>, enabled_by_default=True, side_effect=<function <lambda> at 0x7ff6f099c8c8>, priority=10, requires_output=True)"


# Generated at 2022-06-22 02:51:54.297508
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .const import DEFAULT_PRIORITY
    from .shells import shell
    from .utils import get_output

    # build a command
    raw_script = ['/bin/echo', 'Hello world!', '&&', 'sleep', '10']
    cmd = Command.from_raw_script(raw_script)

    # create a minimal rule
    def match(command):
        return True
    def get_new_command(command):
        return 'echo "Hello world!"'
    rule = Rule('test_rule', match, get_new_command,
                True, None, DEFAULT_PRIORITY, True)

    # test
    assert rule.is_match(cmd)



# Generated at 2022-06-22 02:52:05.894516
# Unit test for constructor of class Rule
def test_Rule():
    test_match = lambda command: command.script == 'fuck'
    test_get_new_command = lambda command: 'new command'
    test_side_effect = lambda command, script: None
    test_priority = 1
    test_requires_output = True

    r = Rule(name='test_rule', match=test_match,
                  get_new_command=test_get_new_command,
                  enabled_by_default=True,
                  side_effect=test_side_effect,
                  priority=test_priority,
                  requires_output=test_requires_output)


# Generated at 2022-06-22 02:52:18.144364
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Unit test for method get_corrected_commands of class Rule"""
    from .utils import get_corrected_commands
    from .output_readers import NO_OUTPUT
    from .shells import split_command
    from .conf import command_prefix
    script_parts = split_command('`echo pwd`')
    script = ' '.join(script_parts)
    command = Command(script=script,
                      output=NO_OUTPUT)
    old_commands = []
    for corrected_command in get_corrected_commands(command):
        old_commands.append(corrected_command.script)
    new_command = old_commands[0]
    script_parts = split_command(new_command)
    new_script = script_parts[1][1:-1]
    assert new

# Generated at 2022-06-22 02:52:20.345621
# Unit test for constructor of class Rule
def test_Rule():
    assert Rule("rule1", lambda: True, lambda: "", True, None, 1, True)

# Generated at 2022-06-22 02:52:31.220406
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    """Unit test for method __eq__ of class Command"""

    script = 'ls'
    output = 'd'
    # create instance of class Command
    command = Command(script, output)

    assert command == command
    assert not (command != command)

    # the same values of instance attributes
    assert command == Command(script, output)
    assert not (command != Command(script, output))

    # different values of instance attributes
    assert not (command == Command(script, 'ls'))
    assert command != Command(script, 'ls')
    assert not (command == Command('ls', output))
    assert command != Command('ls', output)
    assert not (command == Command('ls', 'ls'))
    assert command != Command('ls', 'ls')


# Generated at 2022-06-22 02:52:34.357963
# Unit test for method update of class Command
def test_Command_update():
    command = Command(script='ls', output='ls')
    command.update(script='pwd', output='')
    assert repr(command) == 'Command(script=pwd, output=)'

# Generated at 2022-06-22 02:52:51.981811
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert hash(CorrectedCommand(script='script', side_effect='side_effect', priority='priority')) != hash(CorrectedCommand(script='script1', side_effect='side_effect', priority='priority'))


# Generated at 2022-06-22 02:53:04.162114
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    a = CorrectedCommand(script='', side_effect=[], priority=1)
    b = CorrectedCommand(script='', side_effect=[], priority=2)
    c = CorrectedCommand(script='', side_effect=[], priority=1)
    d = CorrectedCommand(script='', side_effect=[], priority=2)

    assert a == c
    assert b == d
    assert a != b

    assert hash(a) == hash(c)
    assert hash(b) == hash(d)
    assert hash(a) != hash(b)

    commands = set()
    commands.add(a)
    commands.add(b)
    commands.add(c)
    commands.add(d)

    assert len(commands) == 2



# Generated at 2022-06-22 02:53:10.556693
# Unit test for method is_match of class Rule
def test_Rule_is_match():
     r = Rule(name = "test_Rule_is_match", match = lambda x: True, get_new_command = lambda x: "echo hello", enabled_by_default = True, side_effect = None, priority = 0, requires_output = False)
     c = Command(script = "echo hello", output = None)
     assert r.is_match(command = c) == True


# Generated at 2022-06-22 02:53:22.431263
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    from .shells.posix import split_command
    from .shells.windows import split_command as win_split_command

# Generated at 2022-06-22 02:53:25.321068
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('ls', None) == Command('ls', None)
    assert not Command('ls', None) == 'Command()'


# Generated at 2022-06-22 02:53:31.867271
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    def fn():
        pass
    r1 = Rule('name1', fn , fn , True, fn,1,True)
    r2 = Rule('name2', fn , fn , True, fn,1,True)
    assert(r1 != r2)

    r2 = Rule('name1', fn , fn , True, fn,1,True)
    assert(r1 == r2)

# Generated at 2022-06-22 02:53:34.799386
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    script = "sudo"
    output = "something"
    command = Command(script, output)
    assert repr(command) == u'Command(script={}, output={})'.format(script, output)


# Generated at 2022-06-22 02:53:38.504118
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    cmd = Command(script='abc',output='abc')
    assert repr(cmd) == 'Command(script=abc, output=abc)'


# Generated at 2022-06-22 02:53:46.807710
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_module = load_source('test-rule', 'fixture/test/test_rule.py')
    rule = Rule(name='test-rule',
            match=rule_module.match,
            get_new_command=rule_module.get_new_command,
            enabled_by_default=True,
            side_effect=None,
            priority=0,
            requires_output=rule_module.requires_output)
    assert rule.is_match(Command('ls -la', 'total 4\n-rw-r--r-- 1 kr kr 0 Nov  3 00:58 a\n'))

# Generated at 2022-06-22 02:53:52.781176
# Unit test for constructor of class Command
def test_Command():
    command = Command(script='ls', output='ls')
    assert command.script == command.output
    assert command.script_parts == ['ls']

    command = Command(script='ls -l|grep lol', output='ls -l')
    assert command.script != command.output
    assert command.script_parts == ['ls', '-l', '|', 'grep', 'lol']

# Generated at 2022-06-22 02:54:11.243377
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    CorrectedCommand('test_script', 'test_side_effect', 'test_priority')

# Generated at 2022-06-22 02:54:17.544286
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule('name', lambda command: True, lambda command: '',
                True, lambda command, script: None, 1, True) == \
           Rule('name', lambda command: True, lambda command: '',
                True, lambda command, script: None, 1, True), \
           'Rule.__eq__ should ignore priority'

# Generated at 2022-06-22 02:54:18.765033
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    a = CorrectedCommand("a", "b", "c")
    assert repr(a) == "CorrectedCommand(script=a, side_effect=b, priority=c)"

# Generated at 2022-06-22 02:54:21.943903
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert ({CorrectedCommand('foo', lambda x, y: None, 1),
             CorrectedCommand('foo', lambda x, y: None, 2)} ==
            {CorrectedCommand('foo', lambda x, y: None, 1)})

# Generated at 2022-06-22 02:54:23.981753
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert Command('__repr__()', '__repr__()').__repr__() == 'Command(script=__repr__(), output=__repr__())'


# Generated at 2022-06-22 02:54:33.988719
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    sample = lambda : None
    sample.match = lambda _: True
    sample.get_new_command = lambda _: 'a'
    sample.side_effect = lambda _1, _2: None
    sample.priority = 0
    sample.requires_output = True

    a = Rule(name='a', **sample.__dict__)
    b = Rule(name='b', **sample.__dict__)
    c = Rule(name='c', **sample.__dict__)
    assert (a == b) == False
    assert (b == b) == True
    assert (b == c) == False

# Generated at 2022-06-22 02:54:46.124251
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import os
    import shutil
    import tempfile
    command = Command(script='echo "foo"', output='foo')
    pathname = tempfile.mkdtemp()

    def side_effect(command, script):
        with open(os.path.join(pathname, 'script'), 'w') as f:
            f.write(script)
        with open(os.path.join(pathname, 'cmd'), 'w') as f:
            f.write(command.script)
    CorrectedCommand(script='echo "bar"', side_effect=side_effect,
                     priority=1).run(command)

# Generated at 2022-06-22 02:54:48.412433
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    c = CorrectedCommand('test', 'test', 1)
    # test hash of CorrectedCommand
    assert hash(c) == hash(('test','test'))

# Generated at 2022-06-22 02:54:55.431748
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    CorrectedCommand(script='vim test.py', side_effect=None, priority=100).__repr__() == "CorrectedCommand(script=vim test.py, side_effect=None, priority=100)"
    CorrectedCommand(script='echo 44', side_effect=None, priority=100).__repr__() == "CorrectedCommand(script=echo 44, side_effect=None, priority=100)"

# Generated at 2022-06-22 02:55:00.578682
# Unit test for constructor of class Rule
def test_Rule():
    assert Rule(name='name', match=lambda command : True, get_new_command=lambda command : 'new command', enabled_by_default=True, side_effect=lambda old_command, new_command : print(old_command, new_command), priority=1, requires_output=True)


# Generated at 2022-06-22 02:55:28.449464
# Unit test for constructor of class Command
def test_Command():
    command = Command('ls -l', 'ls -l')
    assert command.script == 'ls -l'
    assert command.output == 'ls -l'



# Generated at 2022-06-22 02:55:36.469508
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_module = load_source('test', './tests/rules/test_empty_script.py')
    rule = Rule.from_path('./tests/rules/test_empty_script.py')
    rule._is_match = rule_module.match
    command = Command(script='command', output='output')
    assert rule.is_match(command)

test_suite = (test_Rule_is_match,)

# Generated at 2022-06-22 02:55:48.633043
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    import pytest
    from .output_readers import NoOutput
    from .rules.general import run_through_alias
    c = CorrectedCommand(script=u"echo 'a'", side_effect=None, priority=1)
    assert c.__hash__() == CorrectedCommand(script=u"echo 'a'", side_effect=None, priority=2).__hash__()
    assert c.__hash__() != CorrectedCommand(script=u"echo 'b'", side_effect=None, priority=2).__hash__()
    assert c.__hash__() != CorrectedCommand(script=u"echo 'b'", side_effect=None, side_effect=run_through_alias, priority=2).__hash__()

# Generated at 2022-06-22 02:55:53.921054
# Unit test for constructor of class Command
def test_Command():
    assert Command(script = 'echo "hello world"', output = 'hello world') == \
        Command(script = 'echo "hello world"', output = 'hello world')
    assert Command(script = 'echo "goodbye world"', output = 'goodbye world') != \
        Command(script = 'echo "hello world"', output = 'hello world')


# Generated at 2022-06-22 02:55:55.896996
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('echo "hello"', None) == Command('echo "hello"', None)



# Generated at 2022-06-22 02:55:59.918916
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script='ls', output='ls') == Command(script='ls', output='ls')
    assert Command(script='ls', output='ls') != Command(script='ls', output='pwd')
    assert Command(script='ls', output='ls') != 'Command(script=ls, output=ls)'


# Generated at 2022-06-22 02:56:12.226656
# Unit test for constructor of class Command
def test_Command():
    cmd = Command.from_raw_script(['ls', '-al'])
    assert cmd.script == '/bin/ls -al'
    assert cmd.output == 'total 16\ndrwxr-xr-x  4 root root 4096 Apr  7 07:28 .\ndrwxr-xr-x 32 root root 4096 Apr  7 07:28 ..\ndrwxr-xr-x  2 root root 4096 Apr  7 07:28 bin\ndrwxr-xr-x  2 root root 4096 Apr  7 07:28 usr\n'
    assert cmd.script_parts == ['/bin/ls', '-al']
    assert cmd.update(script='/bin/ls -al') == \
        Command.from_raw_script(['/bin/ls','-al'])



# Generated at 2022-06-22 02:56:18.314944
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():

    def get_new_command(command):
        if command.script=='git status':
            return 'git commit -a'
        else:
            return []

    rule = Rule('testrule', lambda cmd: cmd.script=='git status', get_new_command,
                 True, None, 0, True)
    
    # Add some unit test code here

    return rule

# Generated at 2022-06-22 02:56:21.089216
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    a = Command(script='a', output='a')
    b = Command(script='b', output='b')
    assert a == b
test_Command___eq__()

# Generated at 2022-06-22 02:56:33.575148
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    """
    Ensure that CorrectedCommand can be correctly represented
    """
    # When a CorrectedCommand is initialized
    c = CorrectedCommand('f', None, 1)
    # Then its representation should be correct
    assert c.__repr__() == u'CorrectedCommand(script=f, side_effect=None, priority=1)'

    # Or with a side effect
    import re
    se = lambda cmd, cor_cmd: print(re.sub(cmd.script, cor_cmd, 'test'))
    c = CorrectedCommand('f', se, 1)
    assert c.__repr__() == u'CorrectedCommand(script=f, side_effect=<function <lambda> at 0x[0-9a-f]+>, priority=1)'
    assert c.__eq__(c)

    # Or with a different

# Generated at 2022-06-22 02:57:32.610874
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    from .tests.utils import assert_equal
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))
    assert_equal(Command(script='ls', output='ls'),
                 Command(script='ls', output='ls'))



# Generated at 2022-06-22 02:57:34.630877
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    import operator

    CorrectedCommand('script_1', 'side_effect_1', 'priority_1').__hash__() == \
    CorrectedCommand('script_1', 'side_effect_1', 'priority_2').__hash__()

# Generated at 2022-06-22 02:57:38.727769
# Unit test for constructor of class Rule
def test_Rule():
    def match(cmd):
        return True

    def get_new_command(cmd):
        return 'new command'

    def side_effect(cmd, new_cmd):
        pass

    rule = Rule('name', match, get_new_command, False, side_effect, 1, True)

    assert rule.name == 'name'
    assert rule.match(None) == True
    assert rule.get_new_command(None) == 'new command'
    assert rule.enabled_by_default == False
    assert rule.side_effect(None, None) == None
    assert rule.priority == 1
    assert rule.requires_output == True

# Generated at 2022-06-22 02:57:48.319357
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from . import fucks
    from .const import DEFAULT_SIDE_EFFECT

    def get_new_command(command):
        return command.script

    def side_effect(command, new_command):
        pass

    cmd = Command(u'some_cmd', u'output')
    rule = Rule(u'name', lambda c: True,
                get_new_command, True, side_effect,
                DEFAULT_PRIORITY, True)

    res = list(rule.get_corrected_commands(cmd))
    assert res == [CorrectedCommand(script=u'some_cmd', side_effect=side_effect, priority=1)]

    res = list(rule.get_corrected_commands(cmd.update(output=None)))
    assert res == []


# Generated at 2022-06-22 02:57:56.272295
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command.from_raw_script(['ls', '-alh']) == \
        Command.from_raw_script(['ls', '-alh'])
    assert Command.from_raw_script(['ls', '-alh']) != \
        Command.from_raw_script(['ls', '-la'])
    assert Command.from_raw_script(['ls', '-alh']) != 'foo'



# Generated at 2022-06-22 02:58:01.418404
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert Rule(name="a", match="b", get_new_command="c",
                enabled_by_default=True, side_effect="d",
                priority=1, requires_output=True).__repr__() == \
        'Rule(name=a, match=b, get_new_command=c, ' \
        'enabled_by_default=True, side_effect=d, ' \
        'priority=1, requires_output=True)'

# Generated at 2022-06-22 02:58:02.148872
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('aaa', object(), 0)

# Generated at 2022-06-22 02:58:07.907960
# Unit test for constructor of class Rule
def test_Rule():
    from .rules import always_yes
    r = Rule.from_path(pathlib.Path('/home/travis/.pyenv/versions/3.5.0/lib/python3.5/site-packages/thefuck/rules/always_yes.py'))
    assert r == Rule(always_yes.name, always_yes.match,
                   always_yes.get_new_command,
                   getattr(always_yes, 'enabled_by_default', True),
                   getattr(always_yes, 'side_effect', None),
                   settings.priority.get(always_yes.name, DEFAULT_PRIORITY),
                   getattr(always_yes, 'requires_output', True))


# Generated at 2022-06-22 02:58:15.783307
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .exceptions import EmptyCommand
    from .shells.bash import split as bash_split
    from .shells import shell
    import sys
    import io
    import pathlib
    import os
    import unittest
    import contextlib
    import configparser
    import shutil
    import errno
    import tempfile
    import logging
    import subprocess
    import pwd

    class SimulateShell(object):
        def __init__(self, name):
            self.name = name

        def from_shell(self, cmd):
            return cmd

        def quote(self, string):
            if string is None:
                return None
            string = string.replace('/', os.path.sep)
            return u'"{}"'.format(string)

        def split_command(self, cmd):
            return bash_

# Generated at 2022-06-22 02:58:26.431026
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import io_mock
    io_mock.enable()
    old_cmd = Command.from_raw_script(['echo', 'foo'])
    CorrectedCommand(script='echo foo', side_effect=None, priority=0).run(old_cmd)
    # Shouldn't break anything before running the command
    assert io_mock.stdout() == ''
    # Shouldn't print anything (as side effect)
    assert io_mock.stdout() == ''

    CorrectedCommand(script='echo bar', side_effect=None, priority=0).run(old_cmd)
    # Shouldn't break anything before running the command
    assert io_mock.stdout() == ''
    # Shouldn't print anything (as side effect)
    assert io_mock.stdout() == ''
