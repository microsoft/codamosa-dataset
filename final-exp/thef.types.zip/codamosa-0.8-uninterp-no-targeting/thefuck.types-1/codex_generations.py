

# Generated at 2022-06-22 02:48:36.808539
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert CorrectedCommand("1","2", 0).__hash__() == CorrectedCommand("1","2", 0).__hash__()
    assert CorrectedCommand("1","2", 0).__hash__() != CorrectedCommand("1","3", 0).__hash__()
    assert CorrectedCommand("1","2", 0).__hash__() != CorrectedCommand("1","2", 1).__hash__()
    assert CorrectedCommand("1","2", 0).__hash__() != CorrectedCommand("2","2", 0).__hash__()

# Generated at 2022-06-22 02:48:38.622137
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    def match(c):
        return True
    r = Rule('name', match, None, True, None, -1, False)
    c = Command('command', 'output')
    assert r.is_match(c)
    return True


# Generated at 2022-06-22 02:48:42.512544
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert repr(CorrectedCommand(script="rm -rf /",
                                 side_effect=None,
                                 priority=1)) == \
                                 "CorrectedCommand(script=rm -rf /, side_effect=None, priority=1)"


# Generated at 2022-06-22 02:48:45.778276
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert CorrectedCommand('script', 'side_effect', 1).__hash__() == \
           CorrectedCommand('script', 'side_effect', 2).__hash__()



# Generated at 2022-06-22 02:48:57.368929
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule(name='some_rule', match=None, get_new_command=None,
                enabled_by_default=True, side_effect=None,
                priority=0, requires_output=False) == Rule(name='some_rule', match=None, get_new_command=None,
                enabled_by_default=True, side_effect=None,
                priority=0, requires_output=False)

# Generated at 2022-06-22 02:49:09.460182
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .rules.git_push_fetch import match
    rule = Rule(
                name = 'git-push-fetch',
                match = match,
                get_new_command = '',
                enabled_by_default = True,
                side_effect = '',
                priority = 5000,
                requires_output = False
              )
    def assert_match(script, output, expect):
        command = Command(script, output)
        actual = rule.is_match(command)
        assert actual == expect, 'Rule not matched'

    assert_match('', None, False)
    assert_match('', '', False)
    assert_match('git push', 'fatal', True)
    assert_match('git add .', 'fatal', False)
    assert_match('git push', 'fatal', True)

# Generated at 2022-06-22 02:49:15.301753
# Unit test for method update of class Command
def test_Command_update():
    script = 'cd /home'
    output = 'cd: No such file or directory'
    command = Command(script, output)
    assert command.update(script='cd /home', output='cd: No such file or directory') == command
    assert command.update(script='cd /home/') != command
    assert command.update(script='cd /etc/') != command


# Generated at 2022-06-22 02:49:24.783347
# Unit test for method update of class Command
def test_Command_update():
    command = Command('ls', None)
    command = command.update(script='foo', output='bar')
    assert command.script == 'foo'
    assert command.output == 'bar'
    command = command.update(script='bar', output=None)
    assert command.script == 'bar'
    assert command.output == 'bar'
    command = command.update(script=None)
    assert command.script == 'bar'
    assert command.output == 'bar'
    command = command.update(output=None)
    assert command.script == 'bar'
    assert command.output == 'bar'

# Generated at 2022-06-22 02:49:26.668367
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('a', 'b', 'c') == CorrectedCommand('a', 'b', 'd')



# Generated at 2022-06-22 02:49:31.669775
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    script = 'this should be a script'
    def test_side_effect(old_cmd, script):
        assert script == 'this should be a script'
    corrected_cmd = CorrectedCommand(script, side_effect=test_side_effect, priority=0)
    corrected_cmd.run(Command(script, 'output?'))

# Generated at 2022-06-22 02:49:54.060930
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert Command(script='ls', output='').__repr__() == \
        u'Command(script=ls, output=)'


# Generated at 2022-06-22 02:49:58.048000
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cc = CorrectedCommand('Test script', None, 0)
    assert cc.script == 'Test script'
    assert cc.side_effect is None
    assert cc.priority == 0
    assert cc._get_script() == 'Test script'

# Generated at 2022-06-22 02:50:06.402735
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    class DummyRule(Rule):
        pass
    rule = DummyRule('',
                     match = lambda cmd: True,
                     get_new_command = lambda cmd: '',
                     enabled_by_default = True,
                     side_effect = None,
                     priority = DEFAULT_PRIORITY,
                     requires_output = True)
    command = Command('', '')
    assert rule.is_match(command)
    assert rule.requires_output and command.output is None
    command = Command('', '')
    rule.requires_output = False
    assert rule.is_match(command)

# Generated at 2022-06-22 02:50:09.026702
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script="pwd",output="s")
    assert repr(command) == u"Command(script=pwd, output=s)"



# Generated at 2022-06-22 02:50:10.726894
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand("echo test", None, 1)



# Generated at 2022-06-22 02:50:15.073574
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule('name', 'match', 'get_new_command', True, 'side_effect', 1, True) != \
        Rule('name', 'match', 'get_new_command', True, 'side_effect', 2, True)

# Generated at 2022-06-22 02:50:25.872833
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """
    Unit test for method get_corrected_commands of class Rule
    """
    from .tests.fixtures.rules.test_rule_get_corrected_commands import test_rule

    class CommandMock(object):
        def __init__(self, script, output=None):
            self.script = script
            self.output = output

    def get_corrected_commands(script, output):
        return list(test_rule.get_corrected_commands(CommandMock(script, output)))


# Generated at 2022-06-22 02:50:35.712973
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert repr(Rule(
        name='echo',
        match='match',
        get_new_command='get_new_command',
        enabled_by_default='enabled_by_default',
        side_effect='side_effect',
        priority='priority',
        requires_output='requires_output'
    )) == 'Rule(name=echo, match=match, get_new_command=get_new_command, ' \
          'enabled_by_default=enabled_by_default, side_effect=side_effect, ' \
          'priority=priority, requires_output=requires_output)'

# Generated at 2022-06-22 02:50:40.075186
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .shells import bash, zsh, fish
    import os
    import sys
    import subprocess

    sys.argv = ['fuck']

    # Clean or create temp file
    temp_file_name = '/tmp/fuck_test.txt'
    if os.path.isfile(temp_file_name):
        os.remove(temp_file_name)
    open(temp_file_name, 'a').close()

    # Test steps:
    # 1. run command `echo test > /tmp/fuck_test.txt`
    # 2. check that temp file not empty
    # 3. run `fuck` with command `echo test2 > /tmp/fuck_test.txt`,
    #    write to stdout fixed command
    # 4. read fixed command from stdout
    # 5. run fixed command
    # 6.

# Generated at 2022-06-22 02:50:51.990866
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .rules import is_git_repository, is_git_config_value
    from .rules import get_git_repository_path
    from .rules import get_git_config_value
    from .rules import get_git_repository_config_value
    from .rules import git_add_remote_repository

    # Test git repository
    rule = Rule('fake', is_git_repository, get_git_repository_path, True, None, 0, False)
    cmd1 = Command("cd /root/alias\ncd /tmp/alias\ncd /tmp/alias\ncd /tmp/alias", "cd /tmp/alias")

# Generated at 2022-06-22 02:51:14.405384
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    # Given a CorrectedCommand,
    corrected_cmd = CorrectedCommand(
        script="script",
        side_effect=lambda old_cmd, script: print(script),
        priority=42)
    # When I call __hash__ on this CorrectedCommand,
    first_hash = corrected_cmd.__hash__()
    # And if I call __hash__ on a CorrectedCommand with
    # the same script and side_effect as the previous one,
    test_corrected_cmd = CorrectedCommand(
        script="script",
        side_effect=lambda old_cmd, script: print(script),
        priority=42)
    second_hash = test_corrected_cmd.__hash__()
    # Then two CorrectedCommands with the same script and side_effect
    # should be equal.
    assert first_hash == second_

# Generated at 2022-06-22 02:51:19.922692
# Unit test for constructor of class Command
def test_Command():
    script = 'ls Test_File'
    output = 'ls: cannot access Test_File: No such file or directory'
    command = Command(script, output)
    assert(command.script == script)
    assert(command.output == output)
    assert(command.script_parts == ['ls', 'Test_File'])


# Generated at 2022-06-22 02:51:24.142788
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('test', 'test') == Command('test', 'test')
    assert Command('test', 'test') != Command('test', 'test1')
    assert Command('test', 'test1') != Command('test1', 'test')
    assert Command('test', 'test') != None


# Generated at 2022-06-22 02:51:36.312673
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .utils import get_alias
    from .shells import shell
    from .utils import TempHome
    from .doit_cmd import DoItCmd
    from .tests import temp_home
    import click

    CMD = '{alias} a'.format(alias=get_alias())
    STDOUT = 'a aa'
    STDERR = ''

    # Unit test for method is_match of class Rule in case rule_name not exists in command

# Generated at 2022-06-22 02:51:41.479537
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import sys
    #sys.stdout = sys.__stdout__
    #print(sys.stdout.__class__)
    #print(sys.__stdout__.__class__)
    sys.path.insert(0, '/Users/bwpe1/ltt/.fun')
    from plugins.librispeech_downloader import download_unit as librispeech_downloader
    sys.path.insert(0, '/Users/bwpe1/ltt/.fun/plugins')
    from librispeech_downloader import download_unit as librispeech_downloader
    from .output_readers import get_output
    from .shells import shell
    from .conf import settings
    from .utils import get_alias
    from . import logs
    import os
    import sys

# Generated at 2022-06-22 02:51:47.749851
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    repr(Command(script='the_script', output='the_output'))\
        .find('Command(script=the_script, output=the_output)')\
        != -1
    repr(Command(script='the_script', output=None))\
        .find('Command(script=the_script, output=None)')\
        != -1

# Generated at 2022-06-22 02:51:55.009265
# Unit test for constructor of class Rule
def test_Rule():
    testrule = Rule('name', lambda x: x + 5, lambda x: x -5, True, None, 10, True)
    assert testrule.name == 'name'
    assert testrule.match(5) == 10
    assert testrule.get_new_command(10) == 5
    assert testrule.enabled_by_default == True
    assert testrule.side_effect == None
    assert testrule.priority == 10
    assert testrule.requires_output == True

# Generated at 2022-06-22 02:52:02.189928
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert hash(CorrectedCommand('ls', None, None)) == hash(CorrectedCommand('ls', None, None))
    assert hash(CorrectedCommand('ls', None, None)) != hash(CorrectedCommand('ls', None, 0))
    assert hash(CorrectedCommand('ls', None, None)) != hash(CorrectedCommand('ls', 0, None))
    assert hash(CorrectedCommand('ls', None, None)) != hash(CorrectedCommand('ls', 0, 0))

# Generated at 2022-06-22 02:52:03.466538
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand("test", "None", 2)
    assert cmd.script == "test"
    assert cmd.side_effect == "None"
    assert cmd.priority == 2

# Generated at 2022-06-22 02:52:05.690295
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    CorrectedCommand("a", "b", "c").__repr__()


# Generated at 2022-06-22 02:52:18.911801
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    script = 'ls'
    side_effect = lambda old_cmd, script: None
    priority = 1
    cmd = CorrectedCommand(script, side_effect, priority)
    assert repr(cmd) == u'CorrectedCommand(script=ls, side_effect=<function <lambda> at 0x2aaaf31df840>, priority=1)'


# Generated at 2022-06-22 02:52:21.867189
# Unit test for constructor of class Command
def test_Command():
	script = 'ls'
	output = 'output'
	cmd = Command(script, output)
	assert cmd.script == script
	assert cmd.output == output


# Generated at 2022-06-22 02:52:33.371901
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule1 = Rule(name='rule1',
                 match=lambda x: 0,
                 get_new_command=lambda x: 0,
                 enabled_by_default=0,
                 side_effect=lambda x: 0,
                 priority=1,
                 requires_output=0)
    rule2 = Rule(name='rule1',
                 match=lambda x: 0,
                 get_new_command=lambda x: 0,
                 enabled_by_default=0,
                 side_effect=lambda x: 0,
                 priority=1,
                 requires_output=1)

# Generated at 2022-06-22 02:52:45.718191
# Unit test for constructor of class Command
def test_Command():
    """Test for constructor of class Command."""
    #empty input
    test_input = ""
    print("Test case 1----------------------")
    print("Test input: " + test_input)
    print("Expected output: ", end="")
    print("EmptyCommand")
    print("Actual output: ", end="")
    try:
        Command.from_raw_script(test_input)
    except EmptyCommand:
        print("EmptyCommand")

# Test case 2
    test_input = "ls"
    print("Test case 2----------------------")
    print("Test input  : " + test_input)
    print("Expected output:", end="")
    print("ls")
    print("Actual output: ", end="")
    Command.from_raw_script(test_input).script

# Test case 3
   

# Generated at 2022-06-22 02:52:52.665067
# Unit test for constructor of class Rule
def test_Rule():
    r = Rule('name', lambda x: True, lambda x: 'new_script',
             True, lambda cmd, scr: None, -1, False)
    assert r.name == 'name'
    assert r.match('command')
    assert r.get_new_command('command') == 'new_script'
    assert r.enabled_by_default
    assert r.side_effect is not None
    assert r.priority == -1
    assert not r.requires_output

# Generated at 2022-06-22 02:52:58.433305
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd1 = Command(script="ls", output="output 1")
    cmd2 = Command(script="ls", output="output 2")
    cmd3 = Command(script="ls", output="output 2")
    assert cmd1 != cmd2
    assert cmd1 != cmd3
    assert cmd2 == cmd3

test_Command___eq__()

# Generated at 2022-06-22 02:53:02.546916
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand("git ac", side_effect=None, priority=2)
    assert cmd.script == "git ac"
    assert cmd.side_effect == None
    assert cmd.priority == 2

# Generated at 2022-06-22 02:53:07.947406
# Unit test for method update of class Command
def test_Command_update():
    script = u'echo "hello"'
    output = u'hello'
    c = Command(script, output)
    assert c.update() == c
    assert c.update(script=u'echo "goodbye"') == Command(u'echo "goodbye"', output)
    assert c.update(output=u'goodbye') == Command(script, u'goodbye')


# Generated at 2022-06-22 02:53:14.794808
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    from .rules.general import manual
    assert rule.__repr__() == 'Rule(name=manual, match=<function match at 0x10d4a2950>, get_new_command=<function get_new_command at 0x10d4a2ae8>, enabled_by_default=True, side_effect=None, priority=10, requires_output=True)'


# Generated at 2022-06-22 02:53:26.862155
# Unit test for constructor of class Command
def test_Command():
    script = 'ls -la'
    output = "total 0\n"
    command = Command(script, output)
    assert command.script == script
    assert command.output == output
    assert command.script_parts == ['ls', '-la']

    command = Command(script, output)
    assert command.update(script="ls") == Command("ls", output)
    assert command.update(output="") == Command(script, "")
    assert command.update(script="ls", output="") == Command("ls", "")
    assert command.update(script="ls", output="") == Command("ls", "")

    assert Command.from_raw_script(['ls', '-la']) == Command("ls -la", "total 0\n")
    assert Command.from_raw_script(['ls', '-la']).script

# Generated at 2022-06-22 02:53:57.709184
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # Given
    from .conf import settings
    settings.alter_history = False
    settings.repeat = False
    settings.debug = False
    shell.put_to_history = lambda cmd: None
    side_effect = lambda old_cmd, cmd: None
    priority = 0
    script = 'date'
    corrected_command = CorrectedCommand(script, side_effect, priority)
    import sys
    stdout_original = sys.stdout
    sys.stdout = stdout_mock = MagicMock()
    old_cmd = Command(None, None)

    # When
    corrected_command.run(old_cmd)

    # Then
    sys.stdout = stdout_original
    stdout_mock.write.assert_called_once_with(script)



# Generated at 2022-06-22 02:54:03.371262
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1 = Command('a', 'b')
    c2 = Command('a', 'b')
    assert c1 == c2, "equal"

    c3 = Command('a', 'b')
    c4 = Command('a', 'c')
    assert not(c3 == c4), "not equal"



# Generated at 2022-06-22 02:54:10.809455
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    def match(cmd):
        return True
    def get_new_command(cmd):
        return 'b'
    rule0 = Rule('a', match, get_new_command, True, None, 0, False)
    rule1 = Rule('a', match, get_new_command, True, None, 0, False)
    assert rule0 == rule1
    rule2 = Rule('a', match, get_new_command, False, None, 0, False)
    assert rule0 != rule2


# Generated at 2022-06-22 02:54:18.532551
# Unit test for constructor of class Command
def test_Command():
    c = Command('echo hello world', 'hello world')
    assert c.script == 'echo hello world'
    assert c.output == 'hello world'

    assert c.script_parts == ['echo', 'hello world']

    c2 = c.update(output='hi')
    assert not c is c2
    assert c == c2
    assert c2.output == 'hi'


# Generated at 2022-06-22 02:54:21.427614
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command('echo "Hello World"', None)
    cmd2 = cmd.update(script='echo "Hello World2"')
    assert cmd2.script == 'echo "Hello World2"'


# Generated at 2022-06-22 02:54:29.425089
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    from .utils import InputCommand

    # test 'equal' command
    c1 = Command('a', 'b')
    c2 = Command('a', 'b')
    assert c1 == c2

    # test 'not equal' command
    c1 = Command('a', 'b')
    c2 = Command('a', 'd')
    assert c1 != c2

    # test 'not' Command
    c1 = Command('a', 'b')
    assert c1 != InputCommand('a')


# Generated at 2022-06-22 02:54:36.986523
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert Rule(name='one',
                match=lambda x: x,
                get_new_command=lambda x: x,
                enabled_by_default=False,
                side_effect=lambda x, y: x,
                priority=9001,
                requires_output=False).__repr__() == 'Rule(name=one, match=<function <lambda> at 0x106788050>, get_new_command=<function <lambda> at 0x106788668>, enabled_by_default=False, side_effect=<function <lambda> at 0x1067886e0>, priority=9001, requires_output=False)'



# Generated at 2022-06-22 02:54:47.621309
# Unit test for constructor of class Rule
def test_Rule():
    def match(cmd):
        pass
    def get_new_command(cmd):
        pass
    def side_effect(cmd, script):
        pass

    test_rule = Rule(
            name='test_rule',
            match=match,
            get_new_command=get_new_command,
            enabled_by_default=False,
            side_effect=side_effect,
            priority=1,
            requires_output=True
            )
    assert test_rule.name == 'test_rule'
    assert test_rule.match == match
    assert test_rule.get_new_command == get_new_command
    assert test_rule.enabled_by_default == False
    assert test_rule.side_effect == side_effect
    assert test_rule.priority == 1
    assert test_rule.requires_output

# Generated at 2022-06-22 02:54:55.173977
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .test.test_rule_use_sudo import match, get_new_command
    rule = Rule('Test', match, get_new_command, True, None, 0, True)
    command = Command('echo', None)
    corrected_commands = list(rule.get_corrected_commands(command))
    assert len(corrected_commands) == 1
    assert corrected_commands[0].script == 'sudo echo'

# Generated at 2022-06-22 02:54:58.945307
# Unit test for constructor of class Command
def test_Command():
    c = Command("ls","lsls\n")
    assert c.script == "ls"
    assert c.output == "lsls\n"


# Generated at 2022-06-22 02:55:43.665614
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command('hello world', 'output')
    assert repr(command) == "Command(script='hello world', output='output')"


# Generated at 2022-06-22 02:55:45.013251
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('test_script', 1, 2)
#test_CorrectedCommand()

# Generated at 2022-06-22 02:55:54.105480
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    #
    # Variables
    #

    description_1 = 'CorrectedCommand(script={}, side_effect={}, priority={})'
    script_1 = 'ls'
    side_effect_1 = None
    priority_1 = 1
    result_1 = 'CorrectedCommand(script=ls, side_effect=None, priority=1)'

    #
    # Run
    #

    cmd1 = CorrectedCommand(script_1, side_effect_1, priority_1)

    #
    # Tests
    #

    assert repr(cmd1) == result_1

# Generated at 2022-06-22 02:56:05.151873
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import subprocess
    import os
    import shutil
    import tempfile

    cur_dir = os.getcwd()

    def create_test_rule_file(script=None, priority=None):
        if priority:
            priority = '{0} = {1}\n'.format("priority", priority)

        if not script:
            script = u"return {'command': 'New command'}"

        # Create temporary file
        fd, path = tempfile.mkstemp(suffix=".py")
        # Write data to temporary file

# Generated at 2022-06-22 02:56:12.982696
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule('name', lambda command: True, lambda command: 'new command',
                True, None, 1, False)
    assert rule.__repr__() == 'Rule(name=name, match=<function <lambda> at 0x7f430e9b72f0>, get_new_command=<function <lambda> at 0x7f430e9b73b8>, enabled_by_default=True, side_effect=None, priority=1, requires_output=False)'


# Generated at 2022-06-22 02:56:18.673663
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    """Unit test for method is_match of class Rule"""

    class MyRule(Rule):
        def match(self, command):
            return True

    r = MyRule("rule1", lambda x : x, lambda x : x, True , lambda x,y : None , -1 , True)
    assert r.is_match(Command("ls", "test")) == True

# Generated at 2022-06-22 02:56:27.814248
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    from .conf import defaults
    assert repr(
        Rule(
            name='name',
            match='match',
            get_new_command='get_new_command',
            enabled_by_default=True,
            side_effect='side_effect',
            priority=defaults.priority['test'],
            requires_output=True,
        )
    ) == 'Rule(name=name, match=match, get_new_command=get_new_command, ' \
         'enabled_by_default=True, side_effect=side_effect, ' \
         'priority=1, requires_output=True)'

# Generated at 2022-06-22 02:56:31.821810
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    result = str(CorrectedCommand('script', 'side_effect', 1))
    expected = 'CorrectedCommand(script=script, side_effect=side_effect, priority=1)'
    assert result == expected


# Generated at 2022-06-22 02:56:34.082386
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script='abc', output='abc')
    assert command.__repr__() == "Command(script=abc, output=abc)"


# Generated at 2022-06-22 02:56:37.026144
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    s = "a"
    def side_effect(command, script):
        pass
    CorrectedCommand(s, side_effect, 10)
    CorrectedCommand(s, side_effect, 10)
    CorrectedCommand(s, side_effect, 20)

# Generated at 2022-06-22 02:58:05.671987
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script='ls -l', output='output') ==\
           Command(script='ls -l', output='output')



# Generated at 2022-06-22 02:58:12.697177
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script=u'ls', output='') == Command(script=u'ls', output='')
    assert Command(script=u'ls', output='') != Command(script=u'ls', output='1')
    assert Command(script=u'ls', output='') != Command(script=u'ls1', output='')
    assert Command(script=u'ls', output='') != Command(script=u'ls1', output='1')
    assert Command(script=u'ls', output='') != 'blah'


# Generated at 2022-06-22 02:58:25.202496
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """Tests `__hash__` method of class `CorrectedCommand`

    :rtype: bool

    """
    # Command scripts from "fixers" module
    c1 = CorrectedCommand('git', '', '')
    c2 = CorrectedCommand('git', '', '')
    c3 = CorrectedCommand('git', '', '')
    c4 = CorrectedCommand('git pull', '', '')
    c5 = CorrectedCommand('git pull', '', '')
    c6 = CorrectedCommand('git commit', '', '')

    if c1.__hash__() == c2.__hash__():
        return True
    else:
        return False

    if c1.__hash__() != c3.__hash__():
        return True
    else:
        return False
