

# Generated at 2022-06-22 02:48:43.819893
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(
        'test',
        lambda command: True,
        lambda command: '',
        False,
        None,
        -1,
        False
    )
    assert repr(rule) == 'Rule(name=test, match=<function <lambda> at 0x7fae4ff4bde8>, get_new_command=<function <lambda> at 0x7fae4ff4b598>, enabled_by_default=False, side_effect=None, priority=-1, requires_output=False)'



# Generated at 2022-06-22 02:48:53.134471
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # Simplified: Just test that method run calls the sys module
    #   as expected, regardless of the underlying implementation.
    old_cmd = Command('old_cmd')
    corrected_cmd = CorrectedCommand('corrected_cmd', lambda x, y: None, 1)

    # Python 3: Mock methods on sys.stdout
    # Python 2: http://stackoverflow.com/a/25878796/189897
    def mock_sys_stdout_write(data):
        mock_sys_stdout_write.data = data
        return len(data)
    mock_sys_stdout_write.data = ''


# Generated at 2022-06-22 02:49:00.941632
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .fixers import (
        is_alias_without_cd,
        is_prefix_cd_to_directory,
        is_substitute_cd_with_cd,
        is_substitute_cd_with_pushd,
        is_substitute_dirs_with_dirs,
    )

    def match_command_with_rule(command, rule):
        return rule.is_match(Command.from_raw_script(command))

# Generated at 2022-06-22 02:49:03.518970
# Unit test for method update of class Command
def test_Command_update():
    assert Command(script='foo', output='bar').update(script='baz') == Command(script='baz', output='bar')


# Generated at 2022-06-22 02:49:07.288201
# Unit test for constructor of class Command
def test_Command():
    assert Command(6, 7) == Command(6, 7)
    assert Command(6, 7) != Command(8, 7)
    assert Command(6, 7) != Command(6, 8)


# Generated at 2022-06-22 02:49:19.422011
# Unit test for constructor of class Rule
def test_Rule():
    # testing normal case
    # input
    name = 'test'
    match = lambda command: False
    get_new_command = lambda command: 'test'
    enabled_by_default = True
    side_effect = lambda command, new_command: None
    priority = 1
    requires_output = False
    # expected
    expct_name = 'test'
    expct_match = lambda command: False
    expct_get_new_command = lambda command: 'test'
    expct_enabled_by_default = True
    expct_side_effect = lambda command, new_command: None
    expct_priority = 1
    expct_requires_output = False
    # actual

# Generated at 2022-06-22 02:49:30.786450
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    """Test for `CorrectedCommand.run` method.

    This test covers following cases:
     1. Run of command with `side_effect` = `None`
        1.1 With `settings.alter_history` = `True`
        1.2 With `settings.alter_history` = `False`
     2. Run of command with `side_effect` defined
        2.1 With `settings.alter_history` = `True`
        2.2 With `settings.alter_history` = `False`

    """
    class Mock_shell:
        """Mock object for `shell` module."""
        class Mock_or_:
            """Mock object for `shell.or_`."""
            def __init__(self, old_script, repeat_fuck):
                self.old_script = old_script
                self.repeat

# Generated at 2022-06-22 02:49:36.756682
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    old_cmd = Command('ls -la /tmp', None)
    side_effect = lambda old_cmd, script: logs.debug(
        u'Side effect for script={}'.format(script))
    correct_cmd = CorrectedCommand('ls -l', side_effect, 1)
    correct_cmd.run(old_cmd)

# Generated at 2022-06-22 02:49:38.650804
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    CorrectedCommand('foo', 'bar', 3) == CorrectedCommand('foo', 'bar', 5)



# Generated at 2022-06-22 02:49:39.981180
# Unit test for constructor of class Command
def test_Command():
    assert Command(script='ls -la', output='output')



# Generated at 2022-06-22 02:49:54.221426
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script="Hello World", output="Hello World") == \
    Command(script="Hello World", output="Hello World")


# Generated at 2022-06-22 02:49:55.712993
# Unit test for constructor of class Command
def test_Command():
    script = 'fuck'
    output = 'test'
    assert Command(script, output).script == 'fuck'

# Generated at 2022-06-22 02:50:07.244793
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import os
    import sys
    from .shells import shell
    from .const import DEFAULT_PRIORITY
    # A dummy rule with side_effect
    rule = Rule('rule_test', str.startswith, str.split, 1, lambda c, s: c, DEFAULT_PRIORITY, True)
    corrected_command = CorrectedCommand('a', rule, DEFAULT_PRIORITY)
    stdout = sys.stdout

# Generated at 2022-06-22 02:50:16.698439
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    r1 = Rule(
        name="test_rule",
        match=lambda x: True,
        get_new_command=lambda x: "new command",
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True
    )
    r2 = Rule(
        name="test_rule",
        match=lambda x: True,
        get_new_command=lambda x: "new command",
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True
    )
    assert r1 == r2



# Generated at 2022-06-22 02:50:27.151194
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    a = Rule('name', lambda x: True, lambda y: '',
             True, lambda n: n, 3, True)
    b = Rule('name', lambda x: True, lambda y: '',
             True, lambda n: n, 3, True)
    c = Rule('name1', lambda x: True, lambda y: '',
             True, lambda n: n, 3, True)
    d = Rule('name', lambda x: False, lambda y: '',
             True, lambda n: n, 3, True)
    e = Rule('name', lambda x: True, lambda y: '',
             False, lambda n: n, 3, True)
    f = Rule('name', lambda x: True, lambda y: '',
             True, lambda n: n, 3, False)

# Generated at 2022-06-22 02:50:39.296485
# Unit test for constructor of class Rule
def test_Rule():
    """test for Rule constructor.

    match
    :type match: (Command) -> bool
    :type get_new_command: (Command) -> (basestring | [basestring])
    :type enabled_by_default: boolean
    :type side_effect: (Command, basestring) -> None
    :type priority: int
    :type requires_output: bool
    """
    test_module = load_source('test', 'fixers/test.py')
    # test_module = imp.load_source('test.py', )
    rule = Rule('test', test_module.match, 
                test_module.get_new_command, False,
                test_module.side_effect, 1, True)
    assert(rule.name == 'test')
    assert(rule.match == test_module.match)


# Generated at 2022-06-22 02:50:51.520635
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    '''Tests the run-method of CorrectedCommand
    '''
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    try:
        out = StringIO()
        err = StringIO()
        sys.stdout = out
        sys.stderr = err
        repeat_script = 'thefuck --repeat --force-command "sudo make install"'
        or_script = shell.or_('sudo make install', repeat_script)
        expected_out = '{}'.format(or_script)
        corrected_command = CorrectedCommand('sudo make install', None, 1)
        corrected_command.run(Command('', ''))
        assert out.getvalue() == expected_out
    finally:
        sys.stdout = orig_stdout
        sys.stderr = orig_

# Generated at 2022-06-22 02:50:57.305684
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    from thefuck.rules import arithmetic_operations
    rule_module = load_source(arithmetic_operations.__name__, arithmetic_operations.__file__)
    rule = Rule.from_path(rule_module.__file__)
    rule2 = rule.update(name='another_name')
    assert rule == rule2


# Generated at 2022-06-22 02:51:09.122456
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    """Unit test for method __repr__ of class `Rule`."""
    # TODO: refactor method __repr__
    rule = Rule(
        u'foo',
        lambda x: True,
        lambda x: x,
        True,
        lambda x, y: None,
        123,
        False,
    )

# Generated at 2022-06-22 02:51:14.037517
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    command_1 = CorrectedCommand('greet me', lambda *args: None, 1)
    command_2 = CorrectedCommand('greet me', lambda *args: None, 1)
    assert command_1 == command_2
    assert not command_1 == 5
    assert command_1 != 5

# Generated at 2022-06-22 02:51:55.353216
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    match = lambda c: True
    get_new_command = lambda c: 'echo 1'
    side_effect = lambda c, s: None
    requires_output = True

    rule = Rule(name='lorem', match=match, get_new_command=get_new_command,
                enabled_by_default=True, side_effect=side_effect,
                priority=1, requires_output=requires_output)

    assert repr(rule) == 'Rule(name=lorem, match=<function <lambda> at 0x1090e0e18>, get_new_command=<function <lambda> at 0x109169158>, enabled_by_default=True, side_effect=<function <lambda> at 0x109169200>, priority=1, requires_output=True)'


# Generated at 2022-06-22 02:52:06.835594
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert repr(Rule("__f_fuck_alias", "alias f='fuck'", "alias f='fuck'",
            True, "side_effect", DEFAULT_PRIORITY, True)) \
            == "Rule(name=__f_fuck_alias, match=alias f='fuck', get_new_command=alias f='fuck', enabled_by_default=True, side_effect=side_effect, priority=0, requires_output=True)"

# Generated at 2022-06-22 02:52:14.942838
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule('name', lambda command: True, lambda command: 'ls', True,
                lambda command, new_command: None, DEFAULT_PRIORITY, True)
    assert rule.__repr__() == 'Rule(name=name, match=<function <lambda> at 0x10a5f5510>, get_new_command=<function <lambda> at 0x10a5f5730>, enabled_by_default=True, side_effect=<function <lambda> at 0x10a5f57b8>, priority=0, requires_output=True)'

# Generated at 2022-06-22 02:52:24.986864
# Unit test for constructor of class Rule
def test_Rule():
    try:
        rule_module = load_source('test', 'tests/rules/working_rule.py')
    except Exception:
        pass
    rule = Rule.from_path(Path('tests/rules/working_rule.py'))
    assert rule.name == 'working_rule'
    assert rule.get_new_command == rule_module.get_new_command
    assert rule.match == rule_module.match
    assert rule.side_effect == rule_module.side_effect
    assert rule.priority == settings.priority['working_rule']
    assert rule.requires_output == True
    assert rule.enabled_by_default == True

# Generated at 2022-06-22 02:52:27.340328
# Unit test for constructor of class Rule
def test_Rule():
    Rule("test_rule", lambda x: True, lambda x: "ls",
         True, None, 1, True)



# Generated at 2022-06-22 02:52:37.673933
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1 = Command(script='find /', output='/find')
    c2 = Command(script='find /', output='/find')
    c3 = Command(script='find /', output='/find2')
    c4 = Command(script='find /', output=None)
    c5 = Command(script='find /', output='')
    c6 = Command(script='find /', output='')

    assert c1 == c2
    assert c1 != c3
    assert c1 != c4
    assert c4 == c5
    assert c1 != c5
    assert c5 == c6
    assert c1 != c6



# Generated at 2022-06-22 02:52:50.056534
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    """Test for method __eq__ of class CorrectedCommand"""
    method_name = 'CorrectedCommand.__eq__'
    CorrectedCommand_instance = CorrectedCommand('script', 'side_effect', 'priority')
    CorrectedCommand_instance_2 = CorrectedCommand('script', 'side_effect', 'priority')
    CorrectedCommand_instance_3 = CorrectedCommand('script', 'side_effect', 'priority')
    assert (CorrectedCommand_instance == CorrectedCommand_instance_2) is True, '{} assert #1 has failed!'.format(method_name)
    assert (CorrectedCommand_instance == CorrectedCommand_instance_3) is True, '{} assert #2 has failed!'.format(method_name)

# Generated at 2022-06-22 02:52:55.019829
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script="ls -la;", output="-rw-rw-r-- 1 u u 0 2012-01-01 13:37")
    assert repr(command) == 'Command(script=ls -la;, output=-rw-rw-r-- 1 u u 0 2012-01-01 13:37)'


# Generated at 2022-06-22 02:52:58.642435
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    from . import CorrectedCommand
    CorrectedCommand(script='fuck', side_effect=lambda command, output: None, priority=100).__repr__()
# Done unit test for method __repr__ of class CorrectedCommand


# Generated at 2022-06-22 02:53:07.655402
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1=Command('ls -1',None)
    c2=Command('ls -1',None)
    assert(c1==c2)
    c1=Command('ls -1','')
    c2=Command('ls -1',None)
    assert(c1==c2)
    c1=Command('ls -1','abc')
    c2=Command('ls -1','')
    assert(c1==c2)
    c1=Command('ls -1','abc')
    c2=Command('ls -1','def')
    assert(not c1==c2)


# Generated at 2022-06-22 02:53:40.005227
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script="echo hello world", side_effect=None, priority=8)


# Generated at 2022-06-22 02:53:44.425809
# Unit test for constructor of class Rule
def test_Rule():
    rule = Rule(match = lambda command: True,
                get_new_command = lambda command: command.script,
                side_effect = lambda old_cmd, new_cmd: None,
                priority = DEFAULT_PRIORITY,
                enabled_by_default = True,
                name = 'foolproof',
                requires_output = True)
    assert isinstance(rule, Rule)
    assert rule.match(Command('ls', ''))


# Generated at 2022-06-22 02:53:50.633850
# Unit test for method update of class Command
def test_Command_update():
    """Test method update of class Command."""
    command = Command.from_raw_script(['echo', 'this', 'is', 'a', 'test'])
    assert command.update(script='echo this is only a test') == \
        Command('echo this is only a test', 'this is only a test')


# Generated at 2022-06-22 02:53:52.467014
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script='echo Hello', side_effect=None, priority=42)

# Generated at 2022-06-22 02:54:00.439412
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c = CorrectedCommand(script='test_script', side_effect=None, priority=1)
    c2 = CorrectedCommand(script='test_script', side_effect=None, priority=1)
    c3 = CorrectedCommand(script='test_script', side_effect=None, priority=2)
    c4 = CorrectedCommand(script='other_script', side_effect=None, priority=1)
    assert c == c
    assert c == c2
    assert c != c3
    assert c != c4


# Generated at 2022-06-22 02:54:05.868374
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    # Given
    CorrectedCommandTestObject = CorrectedCommand('add hello world', None, 0)
    CorrectedCommandTestObjectRepr = CorrectedCommandTestObject.__repr__()

    # When
    CorrectedCommandTestObjectString = str(CorrectedCommandTestObject)

    # Then
    assert CorrectedCommandTestObjectString == CorrectedCommandTestObjectRepr

# Generated at 2022-06-22 02:54:11.435461
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    # Test with simple command
    a = Command(script='ls -a', output='ok')
    assert a.__repr__() == 'Command(script=ls -a, output=ok)'
    # Test with complex command
    b = Command(script='find . -print | sort', output='ok')
    assert b.__repr__() == 'Command(script=find . -print | sort, output=ok)'


# Generated at 2022-06-22 02:54:21.775003
# Unit test for method update of class Command
def test_Command_update():
    script = '/bin/echo "hello world"'
    output = '/bin/echo\nhello world'
    command = Command(script, output)

    new_script = '/bin/echo "bonjour le monde"'
    new_command = command.update(script=new_script)

    assert command.script == script
    assert command.output == output
    assert command.script_parts == ['/bin/echo', '"hello world"']

    assert new_command.script == new_script
    assert new_command.output == output
    assert new_command.script_parts == ['/bin/echo', '"bonjour le monde"']

# Generated at 2022-06-22 02:54:34.070781
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    """
    Test the method run of CorrectedCommand
    """
    import tempfile
    mydict = {}
    mydict['history'] = []
    def my_side_effect(old_cmd, script):
        mydict['history'].append(script)
    def my_put_to_history(script):
        mydict['history'].append(script)
    def my_quote(script):
        return script
    def my_or_(a, b):
        return a + b
    shell.put_to_history = my_put_to_history
    shell.quote = my_quote
    shell.or_ = my_or_
    class my_settings(object):
        repeat = False
        alter_history = True
        debug = True
        force_command = True
    settings = my_settings()
    old_

# Generated at 2022-06-22 02:54:39.207253
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    """Unit test for method __repr__ of class Command"""
    command = Command(script='test_script', output='test_output')
    assert repr(command) == u'Command(script=test_script, output=test_output)'



# Generated at 2022-06-22 02:55:46.112837
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('a', None, 1)



# Generated at 2022-06-22 02:55:57.964051
# Unit test for method update of class Command
def test_Command_update():
    assert Command(
        script='ls -la',
        output='/bin/ls -la'
    ).update(
        script='ls -l'
    ) == Command(
        script='ls -l',
        output='/bin/ls -la'
    )
    assert Command(
        script='ls -la',
    ).update(
        script='ls -l'
    ) == Command(
        script='ls -l',
    )
    assert Command(
        script='ls -la',
        output='/bin/ls -la'
    ).update(
    ) == Command(
        script='ls -la',
        output='/bin/ls -la'
    )

# Generated at 2022-06-22 02:55:59.689618
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script='echo "hello"', side_effect=None, priority=1)


# Generated at 2022-06-22 02:56:04.849682
# Unit test for constructor of class Rule
def test_Rule():
    def foo():
        pass

    def bar():
        pass

    m1 = Rule('meh', foo, bar, False, None, None, True)
    m2 = Rule('meh', foo, bar, False, None, None, True)

    assert m1 == m2


# Generated at 2022-06-22 02:56:17.181614
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .shells import get_alias
    from . import history
    from .const import BadCommand
    from .rules import (
        remove_sudo,
        add_sudo,
        add_sudo_user,
        add_sudo_runas
    )
    old_cmd = Command.from_raw_script(['sudo', 'ls', '-lha'])
    old_cmd2 = Command.from_raw_script(['ls', '-lha'])
    old_cmd3 = Command.from_raw_script(['sudo', 'ls', '-lha'])
    old_cmd4 = Command.from_raw_script(['sudo', '-u', 'root', 'ls', '-lha'])

# Generated at 2022-06-22 02:56:19.670877
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command('ls', None)
    assert repr(command) == "Command(script=ls, output=None)"


# Generated at 2022-06-22 02:56:22.899986
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
   correct_cmd = CorrectedCommand(script="echo 'hello'", side_effect=None, priority=3)
   assert correct_cmd.script == "echo 'hello'"
   assert correct_cmd.priority == 3
   assert correct_cmd.side_effect == None

# Generated at 2022-06-22 02:56:26.126183
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command('ls -l', None)) == 'Command(script=ls -l, output=None)'



# Generated at 2022-06-22 02:56:37.066101
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    class ShortOutput(object):
        def __init__(self, text):
            self.text = text

        def __str__(self):
            return self.text

    class LongOutput(object):
        def __init__(self, text):
            self.text = text

        def __str__(self):
            return self.text

    assert Command('echo 1', ShortOutput('1\n')).__eq__(Command('echo 1', ShortOutput('1\n')))
    assert not Command('echo 1', ShortOutput('1\n')).__eq__(Command('echo 2', ShortOutput('1\n')))
    assert not Command('echo 1', ShortOutput('1\n')).__eq__(Command('echo 1', ShortOutput('2\n')))
    assert Command('echo 1', LongOutput('1\n')).__

# Generated at 2022-06-22 02:56:40.644486
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert CorrectedCommand(script="script", side_effect=lambda a,b:None, priority=1).__repr__() == 'CorrectedCommand(script=script, side_effect=<function <lambda> at 0x7ff8d11b1410>, priority=1)'

