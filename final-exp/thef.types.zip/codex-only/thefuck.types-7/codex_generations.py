

# Generated at 2022-06-24 07:39:20.910186
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .shells import bash
    from .shells.posix import DEFAULT_ALIAS
    from .utils import enable_repeat_with_side_effect, disable_repeat_with_side_effect

    alias = DEFAULT_ALIAS
    original_cmd = u'{} {}'.format(alias, 'pip install zsh')
    original_cmd_components = original_cmd.split()
    def side_effect(old_cmd, new_cmd):
        old_cmd_components = old_cmd.script.split()
        assert old_cmd_components[0] == alias
        assert old_cmd_components[1:] == original_cmd_components[1:]
        new_cmd_components = new_cmd.split()
        assert new_cmd_components[0] == alias
        assert new_cmd_comp

# Generated at 2022-06-24 07:39:30.910414
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    # EmptyCommand instance to use in tests
    empty_command = Command(script=None, output=None)
    # Asserts True for equal commands
    assert Command(script='ls', output='myOutput') == Command(script='ls', output='myOutput')
    # Asserts False for unequal commands on script
    assert not Command(script='ls', output='myOutput') == Command(script='ls2', output='myOutput')
    # Asserts False for unequal commands on output
    assert not Command(script='ls', output='myOutput') == Command(script='ls', output='myOutput2')
    # Asserts False for different types of objects
    assert not Command(script='ls', output='myOutput') == Command(script='ls', output=None)
    # Asserts True for object of type EmptyCommand

# Generated at 2022-06-24 07:39:40.853454
# Unit test for constructor of class Rule
def test_Rule():
    # Test constructor of class Rule
    test_path = pathlib.Path("test_file")
    rule = Rule("test_name", 
                lambda command: True, 
                lambda command: "", 
                True, 
                None, 
                1, 
                True)
    assert rule.from_path(test_path).__repr__() == 'Rule(name=test_name, match=<function <lambda> at 0x7f5a870b7c80>,' \
                                                   ' get_new_command=<function <lambda> at 0x7f5a870b7d90>,' \
                                                   ' enabled_by_default=True, side_effect=None, priority=1,' \
                                                   ' requires_output=True)'

# Generated at 2022-06-24 07:39:47.282271
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    def _test_Command___repr__(command, rexp):
        assert re.match(rexp, repr(command))

    command_args_list = [
        # command_script, command_stdout, expected_regexp
        (u'ls -l', u'', r"Command\(script=ls -l, output=''\)"),
        (u'ls -l', u'|', r"Command\(script=ls -l, output='\|'\)"),
        (u"ls -l '|'", u'', r"Command\(script=ls -l '\|', output=''\)"),
        (u"ls -l '|'", u'|', r"Command\(script=ls -l '\|', output='\|'\)"),
    ]


# Generated at 2022-06-24 07:39:50.271111
# Unit test for method update of class Command
def test_Command_update():
    command = Command("ls", None)
    new_command = command.update(script="ls -l")
    assert new_command.script == "ls -l"
    assert command.script == "ls"

# Generated at 2022-06-24 07:40:01.890739
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    import inspect
    import os.path

    def get_rule(name):
        path = os.path.join(os.path.dirname(__file__), 'rules', name)
        return Rule.from_path(path)

    def get_rule_function(function, name):
        """Returns rule function."""
        source_path = os.path.join(os.path.dirname(__file__), 'rules',
                                   name + '.py')
        source_code = open(source_path, 'r').read()
        exec(source_code, {}, {'function': function})
        return function

    def test_rule(name):
        rule = get_rule(name)

# Generated at 2022-06-24 07:40:13.156100
# Unit test for constructor of class Command
def test_Command():
    c1 = Command.from_raw_script(['git', 'commit', '-m', '''"hello world"'''])
    c2 = Command.from_raw_script(['echo', '-e', '"hello\nworld"'])
    assert c1.output == 'git commit -m "hello world"\n'
    assert c2.output == 'echo -e "hello\nworld"\n'
    c1_new = c1.update(script='echo -e "hello\nworld"')
    c2_new = c2.update(script='git commit -m "hello world"')
    assert c1 == c1
    assert c2 == c2
    assert c1 != c2
    assert c1_new != c1
    assert c1_new == c2

# Generated at 2022-06-24 07:40:21.465414
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from . import mocks
    from .output_readers import make_io_reader

    class TestRule(Rule):
        def __init__(self):
            self.is_match_called = False
            super(TestRule, self).__init__(
                name='test_rule',
                match=lambda c: self.is_match_called,
                get_new_command=lambda c: "test_command",
                enabled_by_default=True,
                side_effect=None,
                priority=1,
                requires_output=True)

        def match(self, command):
            self.is_match_called = True
            return True

    test_rule = TestRule()
    assert not test_rule.is_match_called
    command = Command.from_raw_script(['ls', 'test'])
   

# Generated at 2022-06-24 07:40:28.798641
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import tempfile
    import io
    import sys
    import os

    my_tempdir = tempfile.mkdtemp()
    print(my_tempdir)
    my_filename = "my_file.txt"
    my_path = os.path.join(my_tempdir, my_filename)

    f = io.open(my_path, mode='w', encoding='utf-8')

    old_stdout = sys.stdout
    sys.stdout = f

    script = 'python path/to/test.py'
    rule = Rule('test_rule','match','get_new_command')
    corrected_command = CorrectedCommand(script, side_effect=None, priority=1)
    corrected_command.run(None)

    sys.stdout = old_stdout
    f.close()


# Generated at 2022-06-24 07:40:35.222297
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .utils import mock
    old_cmd = Command(script='ls', output='.')
    cmd = CorrectedCommand('rm -rf .', lambda o, n: None, 0)
    with mock.patch('sys.stdout', new=mock.Mock()) as mock_stdout:
        with mock.patch('thefuck.shells.shell.put_to_history') as \
                mock_put_to_history:
            cmd.run(old_cmd)
            assert mock_stdout.write.called_once_with('rm -rf .')
            assert mock_put_to_history.called_once_with('rm -rf .')

# Generated at 2022-06-24 07:40:44.774264
# Unit test for constructor of class Rule
def test_Rule():
    name = "test"
    match = lambda rule: False
    get_new_command = lambda command: "command"
    enabled_by_default = True
    side_effect = lambda command, new_command: None
    priority = 1
    requires_output = True
    test = Rule(name, match, get_new_command, enabled_by_default, side_effect, priority, requires_output)
    assert test.name == "test"
    assert test.match == match
    assert test.get_new_command == get_new_command
    assert test.enabled_by_default == True
    assert test.side_effect == side_effect
    assert test.priority == 1
    assert test.requires_output == requires_output


# Generated at 2022-06-24 07:40:47.028076
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert CorrectedCommand(script='cd /tmp', side_effect=False, priority=0).__repr__() == 'CorrectedCommand(script=cd /tmp, side_effect=False, priority=0)'


# Generated at 2022-06-24 07:40:53.497838
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    a = CorrectedCommand('asdf', None, None)
    b = CorrectedCommand('asdf', None, None)
    c = CorrectedCommand('asdf', 'asdf', None)
    d = CorrectedCommand('asfd', None, None)
    e = CorrectedCommand('asdf', 'asdf', None)

    assert a == b
    assert not a == c
    assert not a == d
    assert c == e

# Generated at 2022-06-24 07:40:56.553277
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    c = CorrectedCommand(script='test_script', side_effect='test_side_effect', priority=1)
    assert c.__repr__() == 'CorrectedCommand(script=test_script, side_effect=test_side_effect, priority=1)'


# Generated at 2022-06-24 07:41:08.914068
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    ident = lambda x: lambda y: x
    ident2 = lambda x, y: lambda z: z
    rule = Rule('name', ident(True), ident2(1, 2), True, None, 1, True)
    rule2 = Rule('name', ident(True), ident2(1, 2), True, None, 1, True)
    assert rule == rule2
    rule3 = Rule('name', ident(False), ident2(1, 2), True, None, 1, True)
    assert rule != rule3
    rule4 = Rule('name', ident(True), ident2(1, 3), True, None, 1, True)
    assert rule != rule4
    rule5 = Rule('name', ident(True), ident2(1, 2), False, None, 1, True)
    assert rule != rule5

# Generated at 2022-06-24 07:41:20.416143
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    assert CorrectedCommand(
        script=u'script',
        side_effect=lambda old_cmd, new_cmd: None,
        priority=0
    ) == CorrectedCommand(
        script=u'script',
        side_effect=lambda old_cmd, new_cmd: None,
        priority=0
    )
    assert CorrectedCommand(
        script=u'script',
        side_effect=lambda old_cmd, new_cmd: None,
        priority=0
    ) != CorrectedCommand(
        script=u'script',
        side_effect=lambda old_cmd, new_cmd: None,
        priority=1
    )

# Generated at 2022-06-24 07:41:30.362799
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
  import unittest
  import unittest.mock
  from . import settings
  from .shells import shell
  from . import logs
  from .output_readers import get_output
  
  # Initialization of input data
  script = "test"
  old_cmd = Command(script, get_output(script, script))
  side_effect_action = "nothing"
  new_script = script + ".fuck"
  priority = 0
  fixed_cmd = CorrectedCommand(script=new_script, side_effect=side_effect_action, priority=priority)
  
  #print("###" + new_script + "###")

  # Unit test for method run of class CorrectedCommand with settings.alter_history == False
  settings.alter_history = False

# Generated at 2022-06-24 07:41:36.726429
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .shells import bash as shell
    shell.get_history = lambda: [u'fuck']
    shell.put_to_history = lambda x: None

    # no repeat
    settings.repeat = False
    # no force
    settings.force_command = None
    ccmd = CorrectedCommand(script=u'the_script',
                            side_effect=None,
                            priority=0)
    logs.debug = lambda x: None
    sys.stdout.write = lambda x: None
    ccmd.run(Command(script=u'the_script', output=u'the_output'))
    assert sys.stdout.write.call_args == call('the_script')

    # with repeat
    settings.repeat = True

# Generated at 2022-06-24 07:41:40.390202
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule = Rule("rule1", match, get_new_command,
                 enabled_by_default, side_effect,
                 priority, requires_output)

    command = Command("test", "test")

    assert(rule.is_match(command) == True)


# Generated at 2022-06-24 07:41:50.412194
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    def match(x):
        return x[0]
    def get_new_command(x):
        return x[1]
    def side_effect(ab):
        pass
    r1 = Rule(
        'test',
        match,
        get_new_command,
        enabled_by_default=False,
        side_effect=side_effect,
        priority=0,
        requires_output=False
    )
    r2 = Rule(
        'test2',
        match,
        get_new_command,
        enabled_by_default=False,
        side_effect=side_effect,
        priority=0,
        requires_output=False
    )

# Generated at 2022-06-24 07:42:01.990036
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Unit test for method get_corrected_commands of class Rule"""
    def match(command):
        '''match'''
        return True

    def get_new_command(command):
        '''get_new_command'''
        return 'newcommand'

    side_effect = None
    rule = Rule('rule1', match, get_new_command, True, side_effect,
                0, False)
    with pytest.raises(Exception) as excinfo:
        rule.get_corrected_commands(Command('oh my', None))
    excinfo.match("Side effect error")
    side_effect = lambda command, script: print(script)
    rule = Rule('rule1', match, get_new_command, True, side_effect,
                0, False)

# Generated at 2022-06-24 07:42:07.801861
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    assert CorrectedCommand(script="do something", side_effect=None, priority=10) == CorrectedCommand(script="do something", side_effect=None, priority=10), CorrectedCommand(script="do something", side_effect=None, priority=10)
    assert CorrectedCommand(script="do something", side_effect=None, priority=10) != CorrectedCommand(script="do something", side_effect=None, priority=1), CorrectedCommand(script="do something", side_effect=None, priority=1)



# Generated at 2022-06-24 07:42:19.522892
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    """This tests CorrectedCommand.run

    :rtype: None

    """
    import re
    # this temporarily changes the script value 
    # so that the function can return a testable value
    # instead of actually runnin the command
    orig_stdout_write = sys.stdout.write
    def mock_stdout_write(s):
        CorrectedCommand.script = s
        return None
    sys.stdout.write = mock_stdout_write

    test_cmd = 'test_cmd'
    orig_cmd = Command(test_cmd, None)
    test_se = lambda old_command, new_command: None
    test_priority = 1
    correct_cmd = CorrectedCommand(test_cmd, test_se, test_priority)


# Generated at 2022-06-24 07:42:27.107201
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-24 07:42:28.364078
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('', '', 1)

# Generated at 2022-06-24 07:42:31.725218
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    a = CorrectedCommand("test", None, 0)
    b = CorrectedCommand("test2", None, 0)
    c = CorrectedCommand("test", None, 0)

    assert a != b
    assert a == c

# Generated at 2022-06-24 07:42:34.086392
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    c = Command('ls', 'lala');
    assert repr(c) == 'Command(script=ls, output=lala)'


# Generated at 2022-06-24 07:42:39.739468
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command = Command(script='git status', output='On branch master')

    def match(command):
        return command.script == 'git status'

    rule = Rule(name='GitRule', match=match, get_new_command=None,
                enabled_by_default=True, side_effect=None,
                priority=1, requires_output=True)

    assert rule.is_match(command) == True

# Generated at 2022-06-24 07:42:47.853691
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    def match(cmd):
        return cmd != None
    def get_new_command(cmd):
        return cmd.script
    def side_effect(cmd, s):
        pass
    r1 = Rule(name='test1', match=match, get_new_command=get_new_command,
              enabled_by_default=True, side_effect=side_effect,
              priority=DEFAULT_PRIORITY, requires_output=True)
    r2 = Rule(name='test2', match=match, get_new_command=get_new_command,
              enabled_by_default=False, side_effect=side_effect,
              priority=DEFAULT_PRIORITY, requires_output=True)

# Generated at 2022-06-24 07:42:51.512112
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    corrected_command = CorrectedCommand(script="git push origin master", side_effect=None, priority=1)
    assert corrected_command.__repr__() == "CorrectedCommand(script=git push origin master, side_effect=None, priority=1)"


# Generated at 2022-06-24 07:42:52.882613
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    CorrectedCommand(script='ls', side_effect=None, priority=50).__hash__()

# Generated at 2022-06-24 07:42:57.642817
# Unit test for constructor of class Rule
def test_Rule():
    assert Rule("test_rule", lambda cmd: True, lambda cmd: "something", False, None, 1, False) == Rule("test_rule", lambda cmd: True, lambda cmd: "something", False, None, 1, False)

# Generated at 2022-06-24 07:42:59.400651
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    result = repr(Command('ls', 'output'))
    assert result == "Command(script='ls', output='output')"


# Generated at 2022-06-24 07:43:03.290593
# Unit test for constructor of class Command
def test_Command():
    # test for initializing command with given values
    command = Command(script='fuck', output='I')
    if command.script != 'fuck' or command.output != 'I':
        raise Exception('test_Command: get_command: fails')
    return True

# Generated at 2022-06-24 07:43:11.904769
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand(script='rm',
                            side_effect=None,
                            priority=10) == CorrectedCommand(script='rm',
                                                             side_effect=None,
                                                             priority=1)
    assert CorrectedCommand(script='rm',
                            side_effect=None,
                            priority=10) == CorrectedCommand(script='rm',
                                                             side_effect=None,
                                                             priority=1)
    assert CorrectedCommand(script='ls',
                            side_effect=None,
                            priority=10) != CorrectedCommand(script='rm',
                                                             side_effect=None,
                                                             priority=1)

# Generated at 2022-06-24 07:43:16.480407
# Unit test for constructor of class Rule
def test_Rule():
    from .rules import no_command
    from .const import get_rules_path
    
    path = get_rules_path() / 'no_command.py'
    rule_module = Rule.from_path(path)
    assert(rule_module.name == 'no_command')
    assert(rule_module.get_new_command == no_command.get_new_command)
    assert(rule_module.side_effect == no_command.side_effect)
    


# Generated at 2022-06-24 07:43:18.483207
# Unit test for constructor of class Rule
def test_Rule():
    path= pathlib.Path('rules/apt-get.py')

# Generated at 2022-06-24 07:43:22.946068
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    a = CorrectedCommand('a', None, None)
    b = CorrectedCommand('a', None, None)
    c = CorrectedCommand('a', None, None)
    assert a == b
    assert b == c
    assert c == a


# Generated at 2022-06-24 07:43:27.945173
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert (
        Rule('a', 'b', 'c', True, 'e', 1, True).__repr__()
        == 'Rule(name=a, match=b, get_new_command=c, enabled_by_default=True, '
        'side_effect=e, priority=1, requires_output=True)'
    )

# Generated at 2022-06-24 07:43:36.869782
# Unit test for constructor of class Rule
def test_Rule():
    from . import all_rules
    # Test for a rule which does not have side_effect
    rule1 = Rule('libload', all_rules.libload.match, all_rules.libload.get_new_command,
                 True, None, 15, True)
    assert rule1
    assert rule1.name == 'libload'
    assert rule1.match == all_rules.libload.match
    assert rule1.get_new_command == all_rules.libload.get_new_command
    assert rule1.enabled_by_default == True
    assert rule1.side_effect == None
    assert rule1.priority == 15
    assert rule1.requires_output == True
    # Test for a rule which has side_effect

# Generated at 2022-06-24 07:43:39.650667
# Unit test for constructor of class Command
def test_Command():
    cmd = Command(script='ls -l', output='')
    assert cmd.script == 'ls -l'
    assert cmd.output == ''


# Generated at 2022-06-24 07:43:43.715790
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert "Command(script={}, output={})".format(
        "fuck", "fuck") == Command(
            script = "fuck",
            output = "fuck").__repr__()

# Generated at 2022-06-24 07:43:46.359367
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script="some_script", output=None)
    assert(repr(command) == "Command(script=some_script, output=None)")


# Generated at 2022-06-24 07:43:47.584597
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    command = CorrectedCommand('python', lambda x, y: None, None)
    assert command.script == 'python'

# Generated at 2022-06-24 07:43:51.086258
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    """
    >>> from thefuck.conf import settings
    >>> settings.alter_history = True
    >>> CorrectedCommand('pwd', '', 42).run('pwd')
    pwd
    """


_RULES = None



# Generated at 2022-06-24 07:43:54.440275
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    command = CorrectedCommand("echo hello", None, 3)
    assert repr(command) == 'CorrectedCommand(script=echo hello, side_effect=None, priority=3)'


# Generated at 2022-06-24 07:44:00.614877
# Unit test for constructor of class Command
def test_Command():
    import pytest
    c = Command('everything ok', 'everything is ok')
    assert c.script == 'everything ok'
    assert c.output == 'everything is ok'
    assert c.script_parts == ['everything', 'ok']
    assert c.update(script='ok') != c
    assert c.update(script='ok').script == 'ok'
    with pytest.raises(EmptyCommand):
        Command.from_raw_script([])

# Generated at 2022-06-24 07:44:07.015515
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_name = "rule_name"
    script = "script"
    new_script = "new_script"
    command = Command(script,"output")
    rule = Rule(name=rule_name,
                match=None,
                get_new_command=lambda x: new_script,
                enabled_by_default=False,
                side_effect=None,
                priority=1,
                requires_output=True)
    corrected_command = rule.get_corrected_commands(command).next()
    assert corrected_command.script == new_script
    assert corrected_command.priority == 1

# Generated at 2022-06-24 07:44:13.494982
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('command', 'output') == Command('command', 'output')
    assert Command('command', 'output') != Command('command1', 'output')
    assert Command('command', 'output') != Command('command', 'output1')
    assert Command('command', 'output') != 'string'
    assert Command('command', 'output') != 1
    assert Command('command', 'output') != []
    assert Command('command', 'output') != {}
    assert Command('command', 'output') != None


# Generated at 2022-06-24 07:44:15.705628
# Unit test for constructor of class Command
def test_Command():
    c = Command(script = 'echo $PATH', output = 'abc')
    assert c.script == 'echo $PATH'
    assert c.output == 'abc'


# Generated at 2022-06-24 07:44:20.818555
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    cmd = Command('ls', None)
    cc = CorrectedCommand('ls', None, 100)
    import builtins
    with builtins.open('/dev/null', 'a') as stdout:
        with builtins.open('/dev/null', 'a') as stderr:
            with builtins.open('/dev/null', 'w') as stdin:
                builtins.logs = logs = logs.Logs()
                builtins.shell = shell = shell.Shell(logs, stdout, stderr, stdin)
                cc.run(cmd)



# Generated at 2022-06-24 07:44:32.779068
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    def match(cmd):
        return True

    def get_new_command(cmd):
        return 'new'

    rule = Rule(name='test', match=match, get_new_command=get_new_command,
                enabled_by_default=False, side_effect=None,
                priority=0, requires_output=True)

    cmd = Command(script='ls', output='/Users')

    assert rule.is_match(cmd)

    # Test case where rule requires output but output is None
    def match(cmd):
        return cmd.output is not None

    rule = Rule(name='test', match=match, get_new_command=get_new_command,
                enabled_by_default=False, side_effect=None,
                priority=0, requires_output=True)


# Generated at 2022-06-24 07:44:40.190140
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    import unittest

    class CorrectedCommandTestCase(unittest.TestCase):
        # unit tests for constructor of CorrectedCommand.
        def test_constructor_works_when_corrected_command_has_side_effect(self):
            side_effect = lambda command, new_command: None

            CorrectedCommand(script="foo", side_effect=side_effect, priority=1)

        def test_constructor_works_when_corrected_command_does_not_have_side_effect(self):
            CorrectedCommand(script="foo", side_effect=None, priority=1)

        def test_constructor_works_when_priority_is_zero(self):
            CorrectedCommand(script="foo", side_effect=None, priority=0)

    return CorrectedCommandTestCase

# Generated at 2022-06-24 07:44:48.646629
# Unit test for method is_match of class Rule
def test_Rule_is_match():

    class RuleBase():
        def match(self, command):
            return True

    script = "sed -n '1p'"
    output = 'sed: -Eon option is no longer supported, -n is now a separate option'
    pattern = 'sed: -Eon option is no longer supported'

    rule = Rule.from_path(pathlib.Path('plugins/sed.py'))

    match = rule.is_match(Command(script, output))
    assert 1 == match

    assert rule.is_match(Command(script, script)) == 0


# Generated at 2022-06-24 07:44:51.187245
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('script', 'output') == Command('script', 'output')
    assert Command('script', 'output') != Command('other_script', 'output')
    assert Command('script', 'output') != Command('script', 'other_output')
    assert Command('script', 'output') != 'other'


# Generated at 2022-06-24 07:45:01.638391
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Unit test to be runned with nose."""
    expected_output = 'ls -l /tmp'
    expected_fixed_output = ['ls -l /tmp/', 'ls -la /tmp']
    match = lambda x: x.script == expected_output
    get_new_command = lambda x: expected_fixed_output
    side_effect = lambda x, y: None
    priority = DEFAULT_PRIORITY
    requires_output = True
    rule = Rule(name='test_rule',
                match=match, get_new_command=get_new_command,
                enabled_by_default=True, side_effect=side_effect,
                priority=priority, requires_output=requires_output)

# Generated at 2022-06-24 07:45:05.248039
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    dummy_cmd = Command('dummy_cmd', 'dummy_out')
    CorrectedCommand('dummy_corr', None, 3).run(dummy_cmd)

# Generated at 2022-06-24 07:45:15.621919
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert (CorrectedCommand(script='a', side_effect=None, priority=1) ==
            CorrectedCommand(script='a', side_effect=None, priority=1))
    assert (CorrectedCommand(script='a', side_effect=None, priority=1) ==
            CorrectedCommand(script='a', side_effect=None, priority=2))
    assert (CorrectedCommand(script='a', side_effect=None, priority=1) ==
            CorrectedCommand(script='a', side_effect='a', priority=1))
    assert (CorrectedCommand(script='a', side_effect=None, priority=1) ==
            CorrectedCommand(script='b', side_effect=None, priority=1))

# Generated at 2022-06-24 07:45:22.809153
# Unit test for constructor of class Rule
def test_Rule():
    path = pathlib.Path('path/to/rule.py')
    rule_module = load_source('name', str(path))
    rule = Rule.from_path(path)
    assert rule.name == 'name'
    assert rule.match == rule_module.match
    assert rule.get_new_command == rule_module.get_new_command
    assert rule.enabled_by_default == True
    assert rule.side_effect == None
    assert rule.priority == DEFAULT_PRIORITY
    assert rule.requires_output == True


# Generated at 2022-06-24 07:45:34.396828
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import unittest
    from .exceptions import FailedCommand
    from .output_readers import get_output

    class TestCorrectedCommand(unittest.TestCase):
        """Unit test for method run of class CorrectedCommand."""
        def test_run_pass(self):
            new_cmd = CorrectedCommand(script='test', side_effect=None, priority=0)
            old_cmd = Command(script='test', output='test\n')
            self.assertEqual(new_cmd.run(old_cmd), None)
            self.assertEqual(old_cmd.script, 'test')

        def test_run_fail(self):
            new_cmd = CorrectedCommand(script='test', side_effect=None, priority=0)

# Generated at 2022-06-24 07:45:45.064455
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import pytest
    # Assert that side_effects are called
    side_effects = []
    def side_effect(old_cmd, new_cmd):
        side_effects.append((old_cmd, new_cmd))
    CorrectedCommand('a', side_effect, 4).run('b')
    CorrectedCommand('a', None, 4).run('b')
    assert side_effects == [('b', 'a')]
    # Assert that run uses priority as weight
    with pytest.raises(Exception) as e:
        CorrectedCommand('a', None, '4').run('b')
    assert str(e.value) == "CorrectedCommand's priority must be an int, not '4'"
    # Assert that run uses put_to_history from shell
    from .shells import shell
    shell.put_to

# Generated at 2022-06-24 07:45:49.250768
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    r = Rule("rule1", lambda cmd: True, lambda cmd: "command", True, None, 2, True)
    assert repr(r) == "Rule(name=rule1, match=<function <lambda> at 0x7ff9a9f28598>, get_new_command=<function <lambda> at 0x7ff9a9f285f0>, enabled_by_default=True, side_effect=None, priority=2, requires_output=True)"


# Generated at 2022-06-24 07:45:50.878016
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command('ls', '\n')) == "Command(script=u'ls', output=u'\\n')"


# Generated at 2022-06-24 07:45:59.064203
# Unit test for constructor of class Rule
def test_Rule():
    def match(command): pass
    def get_new_command(command): pass
    def side_effect(old_cmd, new_cmd): pass
    r = Rule('name', match, get_new_command, True, side_effect, 1, True)
    assert r.name == 'name'
    assert r.match == match
    assert r.get_new_command == get_new_command
    assert r.enabled_by_default == True
    assert r.side_effect == side_effect
    assert r.priority == 1
    assert r.requires_output == True


# Generated at 2022-06-24 07:46:09.656397
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .utils import Replacer
    from .shells import shell

    with Replacer() as r:
        r.replace_attr('thefuck.rules.shell', 'from_shell',
                       lambda s: s)
        r.replace_attr('thefuck.rules.get_output',
                       'get_output', lambda a, b: 'stderr')

        def match(command):
            assert command.script == 'git diff'
            return False

        assert Rule(name='',
                    match=match,
                    get_new_command=lambda c: c.script,
                    enabled_by_default=True,
                    side_effect=None,
                    requires_output=True) \
            .is_match(Command('git diff', 'stderr')) is False


# Generated at 2022-06-24 07:46:14.796426
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule_a = Rule("a", "match", "get_new_command", True, "side_effect", 1, True)
    rule_b = Rule("b", "match", "get_new_command", True, "side_effect", 1, True)
    rule_c = Rule("c", "match", "get_new_command", True, "side_effect", 1, True)
    rule_c.match = "match2"
    assert rule_a == rule_b
    assert rule_b != rule_c
    assert rule_a != rule_c


# Generated at 2022-06-24 07:46:20.775333
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    """
    Tests method __repr__() of class Rule
    """
    rule = Rule("abc", "abc", "abc", True, "abc", 3, True)
    assert(rule.__repr__() == "Rule(name=abc, match=abc, get_new_command=abc, enabled_by_default=True, side_effect=abc, priority=3, requires_output=True)")

# Generated at 2022-06-24 07:46:23.294016
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    c = CorrectedCommand("ls", lambda x, y: None, 0)
    assert c.__hash__() == hash(("ls", lambda x, y: None))

# Generated at 2022-06-24 07:46:25.393115
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert str(Command(script = 'script', output = 'output')) == "Command(script='script', output='output')"


# Generated at 2022-06-24 07:46:29.823424
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('script', 'output') == Command('script', 'output')
    assert Command('script', 'output') != Command('script1', 'output')
    assert Command('script', 'output') != Command('script', 'output1')


# Generated at 2022-06-24 07:46:36.261610
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    from .rules import fuck
    from .shells import zsh
    from .shells.posix import split_command
    def test():
        f = fuck.fuck
        s = zsh.zsh
        c = CorrectedCommand('fuck', 'echo No typo found.', 3)
        t = u"CorrectedCommand(script='fuck', side_effect='echo No typo found.', priority=3)"
        return (c.__repr__() == t)
    assert test() is True

# Generated at 2022-06-24 07:46:44.676280
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    def side_effect(cmd, scp):
        print(cmd, scp)

    with logs.set_level(logs.DEBUG):
        r = Rule.from_path(pathlib.Path('thefuck/rules/apt-get.py'))
        c = Command.from_raw_script(['echo', 'error apt-get xxxx'])
        c1 = Command.from_raw_script(['sudo', 'echo', 'error apt-get xxxx'])
        assert(r.is_match(c))
        assert(r.is_match(c1))

# Generated at 2022-06-24 07:46:54.926564
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Test for method get_corrected_commands of class Rule."""
    def match(command):
        return True

    def get_new_command(command):
        return ['some command', 'some other command']

    def side_effect(command, new_command):
        return None

    test_rule = Rule('test', match, get_new_command,
                     True, side_effect, 5, True)
    test_command = Command('ls', 'ls')
    test_corrected_commands = [
        CorrectedCommand(script='some command', side_effect=side_effect, priority=5),
        CorrectedCommand(script='some other command', side_effect=side_effect, priority=10)]
    assert list(test_rule.get_corrected_commands(test_command)) == test_corrected_commands

# Generated at 2022-06-24 07:47:05.836994
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    class Rule:
        def __init__ (self, string, list_of_commands, side_effect):
            self.name = string
            self.get_new_command = list_of_commands
            self.side_effect = side_effect
    rule1 = Rule("r1", [lambda cmd: "r1c1"], None)
    rule2 = Rule("r2", lambda cmd: "r2c", None)
    rule3 = Rule("r3", [lambda cmd: "r3c1", lambda cmd: "r3c2", lambda cmd: "r3c3"], None)
    rule4 = Rule("r4", [lambda cmd: "r4c1", lambda cmd: "r4c2"], lambda cmd, sc: "side4")

# Generated at 2022-06-24 07:47:12.394133
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from . import utils
    from .shells import shell
    from .conf import settings
    from .rules import stdout_stderr_to_file

    settings.alter_history = False
    settings.debug = False

    Rule_stdout_stderr_to_file = Rule.from_path(utils.get_data(stdout_stderr_to_file))

    old_cmd = Command(script='ls -al|grep *.py', output=None)
    corrections = list(Rule_stdout_stderr_to_file.get_corrected_commands(old_cmd))

    assert len(corrections) == 2
    assert corrections[0].script == 'ls -al|grep *.py > temp_stdout 2> temp_stderr'
    assert corrections[0].priority == 1

# Generated at 2022-06-24 07:47:13.587347
# Unit test for method run of class CorrectedCommand

# Generated at 2022-06-24 07:47:23.525075
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from io import StringIO
    from thefuck.rules.search_man import get_new_command as _get_new_command
    from thefuck.rules.search_man import side_effect as _side_effect
    import unittest

    class Rule(object):
        side_effect = _side_effect
        get_new_command = _get_new_command

    class Command(object):
        script = 'fuck make'
        output = 'suck make'

    class Settings(object):
        repeat = False
        alter_history = False

    class TestCorrectedCommand(unittest.TestCase):
        def test_run(self):
            # We use StringIO to simulate stdout of the command
            fake_stdout = StringIO()
            old_stdout = sys.stdout
            sys.stdout = fake_std

# Generated at 2022-06-24 07:47:27.552977
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    r = Rule('a', 1, 2, 3, 4, 5, 6)
    assert repr(r) == 'Rule(name=a, match=1, get_new_command=2, enabled_by_default=3, side_effect=4, priority=5, requires_output=6)'

# Unit tests for method from_path of class Rule

# Generated at 2022-06-24 07:47:30.459049
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert str(Rule('rule_name', None, None, True, None, DEFAULT_PRIORITY, True)) == \
           'Rule(name=rule_name, match=None, get_new_command=None, ' \
           'enabled_by_default=True, side_effect=None, ' \
           'priority=5, requires_output=True)'


# Generated at 2022-06-24 07:47:39.637437
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand(script='ls', side_effect=None, priority=1) == \
           CorrectedCommand(script='ls', side_effect=None, priority=2)
    assert CorrectedCommand(script='ls', side_effect=None, priority=1) == \
           CorrectedCommand(script='ls', side_effect=lambda x, y: None, priority=2)
    assert CorrectedCommand(script='ls', side_effect=lambda x, y: None, priority=1) == \
           CorrectedCommand(script='ls', side_effect=lambda x, y: None, priority=2)
    assert CorrectedCommand(script='ls', side_effect=None, priority=1) != \
           CorrectedCommand(script='ll', side_effect=None, priority=2)

# Generated at 2022-06-24 07:47:45.944588
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command = Command.from_raw_script(['pip', 'install', 'apipkg'])
    rule = Rule(
        name='rule_name',
        match=lambda c: True,
        get_new_command=lambda c: u'pip install apipkg --pre',
        enabled_by_default=True,
        side_effect=None,
        priority=DEFAULT_PRIORITY,
        requires_output=None
    )
    expected = [CorrectedCommand(script='pip install apipkg --pre', side_effect=None, priority=DEFAULT_PRIORITY)]
    assert set(rule.get_corrected_commands(command)) == set(expected)

# Generated at 2022-06-24 07:47:48.572488
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    corrected_command = CorrectedCommand(script = 'echo 1', side_effect = None, priority = 0)
    hash(corrected_command)

# Generated at 2022-06-24 07:47:52.199427
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    """Test __repr__ of CorrectedCommand.
    """

    cCommand = CorrectedCommand('echo hello', None, 1)
    assert cCommand.__repr__() == 'CorrectedCommand(script=echo hello, side_effect=None, priority=1)'


# Generated at 2022-06-24 07:48:02.045038
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import unittest
    from unittest.mock import Mock
    test_get_alias = Mock('test_fuck.utils.get_alias')
    test_get_alias.return_value = 'fuck'

    test_shell_or = Mock('test_fuck.shell.or_')
    test_shell_or.return_value = 'test_shell_or_return'

    test_shell_put_to_history = Mock('test_fuck.shell.put_to_history')

    test_shell_quote = Mock('test_fuck.shell.quote')
    test_shell_quote.return_value = 'test_shell_quote_return'

    test_logs_debug = Mock('test_fuck.logs.debug')

    class MockSys(object):
        stdout = Mock('sys.stdout')
        std

# Generated at 2022-06-24 07:48:07.205578
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert Rule("test", "test", "test", True, None, 2, True).__repr__() == "Rule(name=test, match=test, get_new_command=test, enabled_by_default=True, side_effect=None, priority=2, requires_output=True)"


# Generated at 2022-06-24 07:48:09.746460
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command.from_raw_script(['find', '.'])
    assert cmd.update(script='find /', output='/') == \
        Command(script='find /', output='/')
    assert cmd.update(script='find /', output='/') != \
        Command(script='find /var', output='/var')



# Generated at 2022-06-24 07:48:16.821660
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    pass
    # assert hash(CorrectedCommand(script='', side_effect=None, priority=1)) == hash(CorrectedCommand(script='', side_effect=None, priority=2))
    # assert hash(CorrectedCommand(script='', side_effect=None, priority=1)) == hash(CorrectedCommand(script='', side_effect=(lambda a,b: None), priority=1))
    # assert hash(CorrectedCommand(script='', side_effect=None, priority=1)) == hash(CorrectedCommand(script='a', side_effect=None, priority=1))
    # assert hash(CorrectedCommand(script='a', side_effect=None, priority=1)) == hash(CorrectedCommand(script='a', side_effect=None, priority=2))
    # assert hash(CorrectedCommand(script='a', side_effect

# Generated at 2022-06-24 07:48:20.373641
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command(script='cd', output='o')) == 'Command(script=cd, output=o)'



# Generated at 2022-06-24 07:48:25.420817
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c = CorrectedCommand("pip install .venv", "", "")
    c2 = CorrectedCommand("pip install .venv", "", "")
    c3 = CorrectedCommand("hardinstall .venv", "", "")
    assert c == c2
    assert c != c3


# Generated at 2022-06-24 07:48:31.009926
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    match_dummy = lambda cmd: True
    not_match_dummy = lambda cmd: False
    rule = Rule(name='rule_name', match=match_dummy, get_new_command=lambda cmd: 'a', enabled_by_default=False, side_effect=None, priority=1, requires_output=True)
    rule2 = Rule(name='rule_name', match=not_match_dummy, get_new_command=lambda cmd: 'a', enabled_by_default=False, side_effect=None, priority=1, requires_output=True)

    cmd = Command(script='command_script', output='command_output')
    cmd2 = Command(script='command_script', output=None)

    assert rule.is_match(cmd) == True
    assert rule.is_match(cmd2) == False


# Generated at 2022-06-24 07:48:39.409251
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    from . import const
    from .exceptions import NoRuleMatched

    correctedCommand = CorrectedCommand(script=u'mkdir $HOME/.fzf', side_effect=None, priority=const.DEFAULT_PRIORITY)
    assert type(correctedCommand.__hash__()) is int, "Hash not int"

    correctedCommand = CorrectedCommand(script=u'mkdir $HOME/.fzf', side_effect=NoRuleMatched("no rule matched"), priority=const.DEFAULT_PRIORITY)
    assert type(correctedCommand.__hash__()) is int, "Hash not int"


# Generated at 2022-06-24 07:48:41.380317
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    CorrectedCommand("script", "side_effect", "priority")
    # should not throw any exception

# Generated at 2022-06-24 07:48:52.274591
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import subprocess
    class MockCommand(object):
        def __init__(self, script, output):
            self.script = script
            self.output = output
    old_cmd = MockCommand('fake-script', 'fake-stderr')
    orig_sys_stdout = sys.stdout

# Generated at 2022-06-24 07:48:59.728822
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    import settings
    import sys
    from .shells import shell
    from nose.tools import ok_, assert_equal, assert_not_equal, assert_false
    settings.repeat = True
    settings.alter_history = False
    # test cases
    c1 = CorrectedCommand("ls", None, 5)
    c2 = CorrectedCommand("ls | wc -l", None, 5)
    c3 = CorrectedCommand("clear", None, 5)
    c4 = CorrectedCommand("cat 1.txt", None, 5)
    c5 = CorrectedCommand("ls", None, 5)

    assert_equal(c1.priority, 5)
    assert_equal(c1.script, "ls")
    assert_equal(c1.side_effect, None)
    assert_equal(c1.priority, 5)
   

# Generated at 2022-06-24 07:49:04.533403
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script=u"/usr/bin/fuck", output=u"/usr/bin/fuck")
    assert repr(command) == u"Command(script={}, output={})".format(u"/usr/bin/fuck", u"/usr/bin/fuck")


# Generated at 2022-06-24 07:49:11.658446
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    old_command = Command(script='hello world', output='hello world')
    new_command1 = CorrectedCommand(script='hello world',
                                    side_effect=None, priority=1)
    assert new_command1 == new_command1
    assert not new_command1 == old_command
    new_command2 = CorrectedCommand(script='hello world',
                                    side_effect=None, priority=2)
    assert new_command1 == new_command2
    new_command3 = CorrectedCommand(script='hello world',
                                    side_effect='not None', priority=1)
    assert new_command1 != new_command3
    new_command4 = CorrectedCommand(script='Hello world',
                                    side_effect=None, priority=1)
    assert new_command1 != new_command4

# Unit test