

# Generated at 2022-06-24 07:39:21.380968
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .conf import settings
    from .utils import get_output
    from .shells import shell
    from .output_readers import get_output
    from .exceptions import EmptyCommand
    from .command import Command
    shell_split_command = shell.split_command
    def split_command(line):
        return shell_split_command(line)
    Rule = Rule
    Command = Command
    get_output = get_output
    split_command = split_command

    # create a test rule
    rule = Rule(name='test_rule',
                match=lambda cmd: True,
                get_new_command=lambda cmd: cmd.script,
                enabled_by_default=True,
                side_effect=None,
                priority=0,
                requires_output=False)


    # test for false of not match when no

# Generated at 2022-06-24 07:39:31.210363
# Unit test for constructor of class Rule
def test_Rule():
    assert id(Rule(name = "hej", match = None, get_new_command = None, enabled_by_default = None, side_effect = None, priority = None, requires_output = None)) == id(Rule(name = "hej", match = None, get_new_command = None, enabled_by_default = None, side_effect = None, priority = None, requires_output = None))
    assert id(Rule(name = "hej", match = None, get_new_command = None, enabled_by_default = None, side_effect = None, priority = None, requires_output = None)) != id(Rule(name = None, match = None, get_new_command = None, enabled_by_default = None, side_effect = None, priority = None, requires_output = None))
    
    

# Generated at 2022-06-24 07:39:40.448876
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import unittest
    import sys

    class CorrectedCommandRunTestCase(unittest.TestCase):
        def test_run(self):

            class MockCorrectedCommand:
                def __init__(self):
                    self.script = "script_test"
                    self.side_effect = None
                    self.priority = 1

            from thefuck import settings
            settings.repeat = False
            settings.alter_history = False
            mock_corrected_command = MockCorrectedCommand()

            with self.assertRaises(SystemExit) as cm:
                mock_corrected_command.run("old_cmd")
                self.assertEqual(cm.exception.code, "script_test")

    unittest.main()

# Generated at 2022-06-24 07:39:47.965864
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import unittest
    class TestRule(unittest.TestCase):
        def setUp(self):
            def match_correct(cmd):
                return True
            def match_incorrect(cmd):
                return False
            self.rule_correct = Rule("correct", match_correct, None, None, None, None, None)
            self.rule_incorrect = Rule("incorrect", match_incorrect, None, None, None, None, None)
            self.command = Command("SOMETHING", "SOMETHING ELSE")

        def test_correct(self):
            self.assertTrue(self.rule_correct.is_match(self.command))
        def test_incorrect(self):
            self.assertFalse(self.rule_incorrect.is_match(self.command))

    import sys

# Generated at 2022-06-24 07:39:50.988008
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('ls', None, 0)
    CorrectedCommand('ls', 'side_effect', 0)
    CorrectedCommand('ls', 'side_effect', 1)

    CorrectedCommand(u'ls', None, 0)

# Generated at 2022-06-24 07:39:56.644996
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    first = CorrectedCommand('script', None, 1)
    second = CorrectedCommand('script', None, 1)
    assert first == second

    third = CorrectedCommand('script', 'second', 1)
    assert first != third

    fourth = CorrectedCommand('script', None, 2)
    assert first != fourth


# Generated at 2022-06-24 07:40:01.400466
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(u'fuck my mom', None, None, None, None, None, None)
    assert rule.__repr__() == 'Rule(name=fuck my mom, match=None, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None)'


# Generated at 2022-06-24 07:40:06.191060
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert Rule(name='name',
                match='match',
                get_new_command='get_new_command',
                enabled_by_default='enabled_by_default',
                side_effect='side_effect',
                priority='priority',
                requires_output='requires_output') == \
        eval(repr(Rule(name='name',
                       match='match',
                       get_new_command='get_new_command',
                       enabled_by_default='enabled_by_default',
                       side_effect='side_effect',
                       priority='priority',
                       requires_output='requires_output')))
test_Rule___repr__()

# Generated at 2022-06-24 07:40:13.476533
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    def side_effect():
        return
    def match():
        return True
    def get_new_command(command):
        return command

    rule = Rule(name="rule", match=match, get_new_command=get_new_command,
                enabled_by_default=False, side_effect=side_effect,
                priority=10, requires_output=True)

# Generated at 2022-06-24 07:40:20.477899
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule = Rule('name', 'match', 'get_new_command', 'enabled_by_default', 'side_effect', 'priority', 'requires_output')
    rule2 = Rule('name', 'match', 'get_new_command', 'enabled_by_default', 'side_effect', 'priority', 'requires_output')
    rule3 = Rule('name2', 'match', 'get_new_command', 'enabled_by_default', 'side_effect', 'priority', 'requires_output')
    rule4 = 'other class'

    assert rule == rule2
    assert not rule == rule3
    assert not rule == rule4

# Generated at 2022-06-24 07:40:21.849781
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert eval(repr(Command(script='ls', output='ls'))) == \
           Command(script='ls', output='ls')



# Generated at 2022-06-24 07:40:24.141879
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command(script='echo 5', output='5')) == 'Command(script=echo 5, output=5)'



# Generated at 2022-06-24 07:40:29.554666
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import unittest
    from .rules.coffeescript import match
    cmd = Command(script='test', output=None)
    rule = Rule(name='coffeescript', match=match, get_new_command=None,
                enabled_by_default=True, side_effect=None,
                priority=DEFAULT_PRIORITY, requires_output=True)
    assert rule.is_match(cmd) is False, 'Should return False for Rule.is_match'


# Generated at 2022-06-24 07:40:36.665642
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_script = 'ls -al'
    test_command = Command.from_raw_script(test_script.split())
    test_get_new_command = lambda c: ['newcommand1', 'newcommand2']
    test_side_effect = lambda c, s: None
    test_priority = 100
    test_priority_newcommand1 = 101
    test_priority_newcommand2 = 102
    test_rule = Rule(
        name='test_rule',
        match=lambda c: True,
        get_new_command=test_get_new_command,
        enabled_by_default=True,
        side_effect=test_side_effect,
        priority=test_priority,
        requires_output=True)

# Generated at 2022-06-24 07:40:42.325532
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert CorrectedCommand('script', 'side_effect', 'priority').__repr__() == "CorrectedCommand(script=script, side_effect=side_effect, priority=priority)"
    assert CorrectedCommand('script', 'side_effect', '').__repr__() == "CorrectedCommand(script=script, side_effect=side_effect, priority=)"

# Generated at 2022-06-24 07:40:43.630254
# Unit test for constructor of class Command
def test_Command():
    command = Command.from_raw_script(['ls'])
    assert(command.script == 'ls')


# Generated at 2022-06-24 07:40:46.446152
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command('script', 'output')) == "Command(script='script', output='output')"


# Generated at 2022-06-24 07:40:54.373419
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1 = Command('foo bar', 'echo')
    c2 = Command('foo bar', 'echo')
    assert c1 == c2
    assert not c1 != c2

    # different script
    c3 = Command('foo bar ---', 'echo')
    assert not c1 == c3
    assert c1 != c3

    # different output
    c4 = Command('foo bar', 'echo ---')
    assert not c1 == c4
    assert c1 != c4

    # not a command instance
    assert not c1 == 123
    assert c1 != 123


# Generated at 2022-06-24 07:40:56.887290
# Unit test for constructor of class Command
def test_Command():
    script = "cd ~"
    output = "not_used"
    a = Command(script, output)
    assert a.script == script
    assert a.output == output


# Generated at 2022-06-24 07:41:01.384945
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    c = CorrectedCommand(script='asdf', side_effect=None, priority=0)
    assert c.script == 'asdf'
    assert c.side_effect is None
    assert c.priority == 0


# Generated at 2022-06-24 07:41:13.118459
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import io
    from mock import Mock, patch
    from thefuck.utils import which

    mock_stdout = io.StringIO()
    mock_stderr = io.StringIO()
    mock_sys = Mock(stdout=mock_stdout, stderr=mock_stderr)

    with patch('sys.stdout', mock_stdout):
        with patch('sys.stderr', mock_stderr):
            with patch('sys.modules', {'sys': mock_sys}):
                with patch('sys.path', ['.']):
                    with patch('__builtin__.open', Mock()):
                        with patch('thefuck.main.settings',
                                   Mock(alter_history=True)):
                            CorrectedCommand('echo "test"', None, 0).run(None)

# Generated at 2022-06-24 07:41:20.846600
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # add a test for Rule.get_corrected_commands
    com = Command(script='sudo apt install git',output='command not found')
    rule = Rule(name = 'test_rule',
                match=(lambda x: len(x.script_parts) > 2),
                get_new_command=(lambda x: 'sudo apt-get install git'),
                enabled_by_default=False,
                side_effect=True,
                priority=10,
                requires_output=False)
    result = rule.get_corrected_commands(com)
    assert tuple(result)[0].script=='sudo apt-get install git'

# Generated at 2022-06-24 07:41:26.586380
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    def test_rule(cmd, output):
        return 'test-rule'

    def test_side_effect(cmd, output):
        return 'test-side-effect'

    cmd = Command('test-script', 'test-output')
    ccmd = CorrectedCommand(cmd, test_rule, test_side_effect, 1)
    ccmd.run(cmd)

# Generated at 2022-06-24 07:41:28.230529
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand(script='bow', side_effect=None, priority=1)
    assert cmd.script == 'bow'
    assert cmd.priority == 1

# Generated at 2022-06-24 07:41:29.636619
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command('echo 1', '1')
    assert command.__repr__() == 'Command(script=echo 1, output=1)'



# Generated at 2022-06-24 07:41:31.484047
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command("script", "output")) == 'Command(script=script, output=output)'


# Generated at 2022-06-24 07:41:39.149141
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(
        name=u'rm',
        match=lambda command: command.script_parts[0] == 'rm',
        get_new_command=lambda command: u'rm {}'.format(
            command.script_parts[1]),
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True)
    assert repr(rule) == 'Rule(name=rm, match=<function <lambda> at 0x7fd4c8e3f400>, get_new_command=<function <lambda> at 0x7fd4c8e31298>, enabled_by_default=True, side_effect=None, priority=1, requires_output=True)'


# Generated at 2022-06-24 07:41:41.477657
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand(script='1', side_effect='2', priority='3') \
           == CorrectedCommand(script='1', side_effect='2', priority='5')



# Generated at 2022-06-24 07:41:43.742812
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command(script = "ls", output = "")
    assert cmd.update(script = "git branch").script == "git branch"
    assert cmd.update(script = "git branch").output == ""

# Generated at 2022-06-24 07:41:45.379591
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command('script', 'output')
    assert repr(command) == 'Command(script=script, output=output)'


# Generated at 2022-06-24 07:41:50.959128
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    cc1 = CorrectedCommand('a', 2, 3)
    cc2 = CorrectedCommand('a', 2, 5)
    cc3 = CorrectedCommand('b', 2, 3)
    cc4 = CorrectedCommand('a', 3, 3)
    cc5 = CorrectedCommand('a', 2, 3)
    assert cc1 == cc1
    assert cc1 == cc2
    assert cc1 == cc5
    assert cc1 != cc3
    assert cc1 != cc4

# Generated at 2022-06-24 07:41:57.856276
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule('rule', match=None, get_new_command=None,
                enabled_by_default=1, side_effect=None, priority=10,
                requires_output=None)
    assert rule.__repr__() == 'Rule(name=rule, match=None, get_new_command=None, ' \
        'enabled_by_default=1, side_effect=None, priority=10, requires_output=None)'


# Generated at 2022-06-24 07:42:00.252216
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    temp = Command('echo hello', 'hello')
    assert temp.__repr__() == u'Command(script=echo hello, output=hello)'

# Generated at 2022-06-24 07:42:07.985447
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Rule that tries to match always
    match_rule = Rule('test rule', lambda x: True, lambda x: '', True, None, 2, False)
    test_command = Command('', None)
    assert match_rule.is_match(test_command)
    assert match_rule.is_match(test_command.update(output='fail'))

    # Rule requires output
    match_rule_output = Rule('test rule', lambda x: True, lambda x: '', True, None, 2, True)
    assert match_rule_output.is_match(test_command.update(output='fail'))
    assert match_rule_output.is_match(Command('', None)) is False

# Generated at 2022-06-24 07:42:10.924238
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd1 = Command('ls', None)
    cmd2 = Command('ls', None)
    assert cmd1 == cmd2
    cmd3 = Command('ls', 'ab')
    assert cmd1 != cmd3


# Generated at 2022-06-24 07:42:18.656534
# Unit test for constructor of class Rule
def test_Rule():
    rule_module = load_source('name', '/path/to/module.py')
    name = "name"
    rule_module.match = lambda x: True
    rule_module.get_new_command = lambda x: ["hello"]
    rule_module.side_effect = lambda x, y: print(x.script)
    print(Rule.from_path('/path/to/module.py'))


# Generated at 2022-06-24 07:42:22.155486
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand('good', None, None) == CorrectedCommand('good', None, None)
    assert CorrectedCommand('good', None, None) != CorrectedCommand('bad', None, None)
    assert CorrectedCommand('good', None, None) != ("bad",)


# Generated at 2022-06-24 07:42:28.829570
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    """Unit test for method __repr__ of class Rule."""
    rule = Rule(name='x', required_output=True,
                match=lambda x: x.stdout == 'x',
                get_new_command=lambda x: x.script + '1',
                enabled_by_default=True,
                side_effect=lambda x, y: print(x, y),
                priority=1)
    assert repr(rule) == \
        "Rule(name='x', match=<function <lambda> at 0x>, "\
        "get_new_command=<function <lambda> at 0x>, " \
        "enabled_by_default=True, side_effect=<function <lambda> at 0x>, " \
        "priority=1, requires_output=True)"


# Generated at 2022-06-24 07:42:39.266311
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    def get_new_command(command):
        return command.script.split()[1]

    rule = Rule(name='test_Rule_get_corrected_commands',
                match=lambda x: True,
                get_new_command=get_new_command,
                enabled_by_default=True,
                side_effect=lambda _, __: None,
                priority=1,
                requires_output=True)

    cmd = Command(script='git commit -m "test"', output='git commit -m "test"')

    corrected_commands = list(rule.get_corrected_commands(cmd))

    assert len(corrected_commands) == 1

    corrected_command = corrected_commands[0]

    assert corrected_command._get_script() == 'commit'

# Generated at 2022-06-24 07:42:42.032139
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    old_cmd = Command('ls', 'output')
    correctedCommand = CorrectedCommand('pwd', None, 5)
    correctedCommand.run(old_cmd)

# Generated at 2022-06-24 07:42:45.009724
# Unit test for constructor of class Command
def test_Command():
    assert Command.from_raw_script([]) == Command(script='', output=None)
    assert Command.from_raw_script(['git', 'status']) == Command(script=u'git status', output=u'git status\n')

# Generated at 2022-06-24 07:42:51.589937
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule = Rule("name", lambda x: True, lambda x: x,
                False, None, 0, False)
    assert rule.is_match(Command("", None))

    rule.requires_output = True
    assert not rule.is_match(Command("", None))
    assert rule.is_match(Command("", ""))

    rule.match = lambda x: False
    assert not rule.is_match(Command("", ""))

    with pytest.raises(Exception):
        rule.match(Command("", ""))



# Generated at 2022-06-24 07:42:54.689238
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    cmd1 = Command(script='command1', output='output1')
    cmd2 = Command(script='command2', output='output2')
    assert cmd1 == cmd1
    assert cmd1 != cmd2


# Generated at 2022-06-24 07:42:59.069044
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    corrected_command = CorrectedCommand(script=u'cd /var/log', side_effect=None, priority = 50)
    expected = u'CorrectedCommand(script='  + u'cd /var/log' + ', side_effect=' + str(None) + ', priority=' + str(50) + ')'
    assert(repr(corrected_command) == expected)

test_CorrectedCommand()

# Generated at 2022-06-24 07:43:00.903010
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script='fuck ', side_effect=None, priority=8)


# Generated at 2022-06-24 07:43:08.005461
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    path_file = 'tests/fixtures/rules/alternatives.py'
    rule = Rule.from_path(pathlib.Path(path_file))
    assert rule.__repr__() == "Rule(name='alternatives', match=<function match at 0x10c4e4ea0>, get_new_command=<function get_new_command at 0x10c4e4ef8>, enabled_by_default=True, side_effect=None, priority=5, requires_output=True)"



# Generated at 2022-06-24 07:43:14.115986
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    # pylint:disable=missing-docstring
    # pylint: disable=protected-access
    # pylint: disable=unnecessary-lambda
    corrected_command = CorrectedCommand(script='ls',
                                         side_effect=lambda old_cmd, new_cmd: None,
                                         priority=1)
    actual = corrected_command.__repr__()
    expected = u'CorrectedCommand(script=ls, side_effect=<function <lambda> at 0x7f4119a2b400>, priority=1)'
    assert actual == expected



# Generated at 2022-06-24 07:43:21.456676
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    cc = CorrectedCommand('ls', None, 0)
    global ran
    ran = False
    old_cmd = Command('asd', 'output')
    def side_effect(command, script):
        assert command == old_cmd
        assert script == cc.script
        global ran
        ran = True
    cc.side_effect = side_effect
    cc.run(old_cmd)
    assert ran

import pytest

# Generated at 2022-06-24 07:43:25.130909
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    o1 = CorrectedCommand(script='test', side_effect='test', priority='test')
    o2 = CorrectedCommand(script='test', side_effect='test', priority='test')
    assert o1.__hash__() == o2.__hash__()

# Generated at 2022-06-24 07:43:26.543282
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    comm = Command(script='ls -l', output=None)
    result = "Command(script=ls -l, output=None)"
    assert str(comm) == result


# Generated at 2022-06-24 07:43:29.527911
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert repr(CorrectedCommand(script='abc', side_effect=None, priority=1)) == \
           u"CorrectedCommand(script=abc, side_effect=None, priority=1)"


# Generated at 2022-06-24 07:43:35.399013
# Unit test for method update of class Command
def test_Command_update():
    """Tests method update of class Command by checking it return the exact value of each fields."""
    cmd = Command(script='script', output='stdout')
    new_cmd = cmd.update(script='new_script')
    if new_cmd.script == 'new_script' and new_cmd.output == cmd.output:
        logs.debug("Method update of class Command is functioning correctly")
        return True
    else:
        logs.debug("Method update of class Command is not functioning correctly")
        return False


# Generated at 2022-06-24 07:43:41.261543
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    """Returns `True` only if rule `name` is enabled in settings."""
    def match1(self):
        return True

    def get_new_command1(self):
        return "aa"
    enabled_by_default1 = True
    side_effect1 = None
    priority1 = 5
    requires_output1 = True
    r1 = Rule('a', match1, get_new_command1, enabled_by_default1, side_effect1, priority1, requires_output1)
    def match2(self):
        return True

    def get_new_command2(self):
        return "aa"
    enabled_by_default2 = True
    side_effect2 = None
    priority2 = 5
    requires_output2 = True

# Generated at 2022-06-24 07:43:52.436419
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    old_cmd = Command(script='fuck', output='No match')

    # 1. case: side_effect is not None
    side_effect_called = False
    def side_effect(old_cmd, new_script):
        assert old_cmd == Command(script='fuck', output='No match')
        assert new_script == 'bar'
        nonlocal side_effect_called
        side_effect_called = True
    corrected_cmd = CorrectedCommand(script='bar', side_effect=side_effect, priority=1)
    corrected_cmd.run(old_cmd)
    assert side_effect_called

    # 2. case: side_effect is None
    corrected_cmd = CorrectedCommand(script='bar', side_effect=None, priority=1)
    corrected_cmd.run(old_cmd)

    # 3. case

# Generated at 2022-06-24 07:43:55.728149
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    cmd = Command("su -c \"pip install --upgrade pip\"", "")
    assert cmd.__repr__() == "Command(script=su -c \"pip install --upgrade pip\", output=)"


# Generated at 2022-06-24 07:43:59.253729
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script='xz -cd afile.xz | tar xf -', output='tar xf -')
    assert repr(command) == "Command(script='xz -cd afile.xz | tar xf -', output='tar xf -')"


# Generated at 2022-06-24 07:44:04.711477
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():

    from . import core
    from . import rules

    from . import const
    from . import utils

    fixed_cmd = rules.Rule("test", core.match_command, lambda x: ['sample command'], True, None, const.DEFAULT_PRIORITY, True)

    fixed_cmds = fixed_cmd.get_corrected_commands("sample command")

    assert(utils.get_alias())



# Generated at 2022-06-24 07:44:08.905776
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    a = CorrectedCommand('git commit -m "new"', (lambda *args: None), 1)
    assert repr(a) == 'CorrectedCommand(script=git commit -m "new", side_effect=<function <lambda> at 0x00000000030C1048>, priority=1)'

# Generated at 2022-06-24 07:44:13.716871
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
	test_1 = CorrectedCommand(script='test', side_effect=None, priority=0)
	test_2 = CorrectedCommand(script='test', side_effect=None, priority=0)
	test_3 = CorrectedCommand(script='test1', side_effect=None, priority=0)
	assert test_1 == test_2
	assert test_1 != test_3

# Generated at 2022-06-24 07:44:17.402627
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    command1 = Command('script1', 'output1')
    command2 = Command('script2', 'output2')
    command3 = Command('script1', 'output1')
    assert command1 == command3, \
        'Instances of class Command are equal! ' \
        '__eq__() method of class Command is not working!'


# Generated at 2022-06-24 07:44:23.096650
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand('fuck', None, 1)
    # Test that initial script is correct
    assert (cmd.script == 'fuck'), 'Constructor of CorrectedCommand does not set script to initial value'
    # Test that side_effect is None
    assert (cmd.side_effect is None), 'Constructor of CorrectedCommand does not set side_effect to initial value'
    # Test that priority is 1
    assert (cmd.priority == 1), 'Constructor of CorrectedCommand does not set priority to initial value'

# Generated at 2022-06-24 07:44:32.676674
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    def get_new_command(command):
        return command.script
    rule = Rule("GitRule", lambda *args: True, get_new_command, True, None, 1, False)
    assert str(rule) == 'Rule(name=GitRule, match=<function <lambda> at 0x7f6e03056aa0>, '\
                        'get_new_command=<function <lambda> at 0x7f6e03056b70>, '\
                        'enabled_by_default=True, side_effect=None, priority=1, '\
                        'requires_output=False)'


# Generated at 2022-06-24 07:44:40.141943
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from . import history
    from . import fs
    from .shells.posix import Git
    from .shells import Shell
    import tempfile
    old_cmd = Command('echo "foo"', 'foo')

    # write a simple shell script that just echoes 'bar'
    fd, tmpfile = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write("echo 'bar'")
    os.chmod(tmpfile, 0o755)

    # add a local alias to override the alias file to use the tempfile
    shell.env['FCK_ALIAS_DIR'] = ''
    fckalias = 'fck () { {}; }'.format(tmpfile)

    # enable history and force-command

# Generated at 2022-06-24 07:44:47.800613
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    """Unit test for method run of class CorrectedCommand"""
    for cmd in CorrectedCommand.__subclasses__():
        print("test_CorrectedCommand_run: cmd = {}".format(cmd))
        if cmd == CorrectedCommand:
            continue
        print("test_CorrectedCommand_run: run = {}".format(cmd.run))
    assert False

if False:
    print("testing CorrectedCommand.run()")
    test_CorrectedCommand_run()
    assert False

#

# Generated at 2022-06-24 07:44:58.588824
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .exceptions import FuckUnknownOption
    from .output import Output
    from .shells import shell

    @classmethod
    def test_match(cls, command):
        return command.output.endswith('option --foo')

    rule = Rule(name='test_rule', match=test_match, get_new_command=lambda c: [],
                enabled_by_default=True, side_effect=None, priority=200,
                requires_output=True)


# Generated at 2022-06-24 07:45:04.711628
# Unit test for constructor of class Rule
def test_Rule():
    name = "name"
    match = lambda x: True
    get_new_command = lambda x: [x]
    enabled_by_default = True
    side_effect = lambda x: None
    priority = 0
    requires_output = True

    r = Rule(name, match, get_new_command, enabled_by_default, side_effect, priority, requires_output)
    # check the type
    assert isinstance(r, Rule)
    # check the equivalence
    assert r == Rule(name, match, get_new_command, enabled_by_default, side_effect, priority, requires_output)
    # check the type for a return value
    assert isinstance(r.is_enabled, bool)
    # check the type for a return value
    assert isinstance(r.is_match(None), bool)
   

# Generated at 2022-06-24 07:45:09.181084
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """ __hash__ of CorrectedCommand should be repeatable. """
    assert CorrectedCommand(script='ls', side_effect=None, priority=42).__hash__() == \
        CorrectedCommand(script='ls', side_effect=None, priority=42).__hash__()

# Generated at 2022-06-24 07:45:11.670029
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert(str(Command("I am a script", "I am output")) == "Command(script=I am a script, output=I am output)")


# Generated at 2022-06-24 07:45:16.599966
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    class Mock(object):
        script = ""

    cmd1 = CorrectedCommand(script="foo", side_effect=None, priority=42)
    cmd2 = CorrectedCommand(script="foo", side_effect=None, priority=42)
    cmd3 = CorrectedCommand(script="foo", side_effect="abc", priority=42)
    cmd4 = CorrectedCommand(script="bar", side_effect=None, priority=42)
    cmd5 = CorrectedCommand(script="foo", side_effect=None, priority=24)
    cmd6 = Mock()

    assert cmd1 == cmd2
    assert cmd1 != cmd3
    assert cmd1 != cmd4
    assert cmd1 != cmd5
    assert cmd1 != cmd6



# Generated at 2022-06-24 07:45:20.735877
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    cmd = CorrectedCommand(script='git fetch origin -v', side_effect=None, priority=5)
    test_str = u'CorrectedCommand(script=git fetch origin -v, side_effect=None, priority=5)'
    assert repr(cmd) == test_str

# Generated at 2022-06-24 07:45:22.650645
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c = CorrectedCommand('', None, 0)
    assert c == c
    assert not (c != c)



# Generated at 2022-06-24 07:45:33.969422
# Unit test for constructor of class Rule
def test_Rule():
    # pathlib.Path needed to mock class TestRule
    from unittest.mock import patch
    from pathlib import Path
    with patch('pathlib.Path', autospec=True) as mock_path:
        mock_path.return_value.name = 'TestRule.py'
        test_rule = Rule.from_path(Path('TestRule.py'))

        assert test_rule.name == 'TestRule'
        assert test_rule.match([])
        assert test_rule.get_new_command() == 'ls'
        assert test_rule.enabled_by_default == True
        assert test_rule.side_effect == None
        assert test_rule.priority == DEFAULT_PRIORITY
        assert test_rule.requires_output == True


# Generated at 2022-06-24 07:45:44.888943
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    class RuleMock(Rule):
        def __init__(self, name, match, get_new_command,
                     enabled_by_default, side_effect,
                     priority, requires_output):
            pass

    class MatchMock(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    class GetNewCommandMock(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    class SideEffectMock(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

   

# Generated at 2022-06-24 07:45:47.488587
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    #create Command object
    script = "hi"
    output = "hello"
    command = Command(script, output)
    #check that the function returns the correct output
    assert(command.__repr__() == "Command(script={}, output={})".format(script, output))


# Generated at 2022-06-24 07:45:50.574812
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule(None, None, None, None, None, None, None) \
        == Rule(None, None, None, None, None, None, None)

    assert not (Rule(None, None, None, None, None, None, None) \
        == 'a')
    

# Generated at 2022-06-24 07:45:54.416461
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    class old_cmd:
        script = 'echo'
    class settings:
        repeat = False
        alter_history = False
        debug = False
    test_cmd = CorrectedCommand('echo "old command!"', None, 0)
    test_cmd.run(old_cmd)
    assert sys.stdout.getvalue() == 'echo "old command!"'

    settings.repeat = True
    test_cmd.run(old_cmd)
    assert sys.stdout.getvalue() == 'echo "old command!" || echo "old command!"'

# Generated at 2022-06-24 07:45:57.449368
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert CorrectedCommand('script', 'side_effect', 'priority').__hash__() == (
        'script', 'side_effect'
    ).__hash__()

# Generated at 2022-06-24 07:46:08.114336
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    def _test_Rule_is_match(match, requires_output, output, expected):
        rule = Rule('test', match, None, None, None, None, requires_output)
        cmd = Command('', output)
        logs.debug('O: {}'.format(output))
        assert rule.is_match(cmd) == expected

    # Test with output and output required by rule
    _test_Rule_is_match(lambda x: True, True, '123', True)
    # Test with output and output not required by rule
    _test_Rule_is_match(lambda x: True, False, '123', True)
    # Test with no output and output required by rule
    _test_Rule_is_match(lambda x: True, True, None, False)
    # Test with no output and output not required by rule
    _test

# Generated at 2022-06-24 07:46:15.305087
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from . import rules as test_rules
    from . import rules
    from . import shells
    
    def check_rule(rule_name):
        #print(rule_name)
        rule = getattr(test_rules, rule_name)
        match_cmds = getattr(test_rules, rule_name + '_match')
        not_match_cmds = getattr(test_rules, rule_name + '_not_match')
        r = Rule(rule_name, rule.match, rule.get_new_command, rule.enabled_by_default,
                 rule.side_effect, priority=DEFAULT_PRIORITY, requires_output=rule.requires_output)
        for cmd in match_cmds:
            cmd = shells.shell.split_command(cmd)

# Generated at 2022-06-24 07:46:18.898976
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    correct_cmd = CorrectedCommand("fuck", None, 2)
    assert correct_cmd.__repr__() == "CorrectedCommand(script=fuck, side_effect=None, priority=2)"

# Generated at 2022-06-24 07:46:21.539418
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    from . import runner
    from .runner import get_rules

    runner.init()
    rules = get_rules()
    assert rules[0] == rules[0]

# Generated at 2022-06-24 07:46:22.936848
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    script = 'foo'
    CorrectedCommand(script)


# Generated at 2022-06-24 07:46:26.045837
# Unit test for method __repr__ of class Command
def test_Command___repr__():
        """Unit test for method __repr__ of class Command"""
        cmd = Command('script1', 'output1')
        assert cmd.__repr__() == u'Command(script=script1, output=output1)'


# Generated at 2022-06-24 07:46:32.215147
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command(u'ls -l', u'Done')
    correct_cmd = cmd.update(script=u'ls -al')

    assert(cmd.script == u'ls -l')
    assert(cmd.output == u'Done')
    assert(correct_cmd.script == u'ls -al')
    assert(correct_cmd.output == u'Done')

# Generated at 2022-06-24 07:46:35.682004
# Unit test for constructor of class Command
def test_Command():
    command = Command("I am a script", "I am output")
    assert isinstance(command, Command)
    assert command.script == "I am a script"
    assert command.output == "I am output"


# Generated at 2022-06-24 07:46:39.212210
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    s = 'python script.py'
    side_effect = lambda x, y: None
    assert CorrectedCommand(s, side_effect, 1) == CorrectedCommand(s, side_effect, 2)

# Generated at 2022-06-24 07:46:49.196277
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import sys
    import mock
    import subprocess
    from .shells.posix import shell
    from .shells.posix import shell as shellold
    from .shells.posix import shell as _posix_shell
    from .shells.posix import shell_type
    from tools.testing import mock_open, patch, reset_sys_executable, reset_sys_stdin

    # monkey patching shell module
    shell._history = {}
    shell._aliases = {}
    shell.get_alias = lambda: 'fuck'
    shell.quote = lambda x: '"{}"'.format(x)
    shell.or_ = lambda *a: ' '.join(a)

    def orig_get_shell_type(executable=None):
        return shell_type.Posh

    # monkey patching shell module
   

# Generated at 2022-06-24 07:46:59.148188
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    def _test_cmd_run(old_cmd, new_cmd, side_effect,
                    settings_alter_history, settings_repeat,
                    expected_put, expected_print):
        """Universal function for all the test of method run of class CorrectedCommand.

        :type old_cmd: Command
        :type new_cmd: CorrectedCommand
        :type side_effect: (Command, basestring) -> None
        :type settings_alter_history: bool
        :type settings_repeat: bool
        :type expected_put: basestring
        :type expected_print: basestring

        """
        def _side_effect(o, n):
            assert o == old_cmd
            assert n == new_cmd.script
            logs.debug('side_effect ran')
            seen_side_effect[0] = True

        logs

# Generated at 2022-06-24 07:47:07.495503
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule = Rule(name='name',
                match=lambda command: True,
                get_new_command=lambda command: None,
                enabled_by_default=True,
                side_effect=None,
                priority=100,
                requires_output=True)
    rule1 = Rule(name='name',
                 match=lambda command: True,
                 get_new_command=lambda command: None,
                 enabled_by_default=True,
                 side_effect=None,
                 priority=100,
                 requires_output=True)
    assert rule == rule1
    assert not rule == None

# Generated at 2022-06-24 07:47:10.271374
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    command = CorrectedCommand(script='foobar',
                               side_effect=None,
                               priority=99)
    assert repr(command) == 'CorrectedCommand(script=foobar, side_effect=None, priority=99)'


# Generated at 2022-06-24 07:47:21.807215
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import tempfile
    import time
    import os
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()
    tmpfile_name = tmpfile.name
    old_cmd_script = 'echo "old_cmd_script" > ' + tmpfile_name
    old_cmd = Command(script=old_cmd_script, output='output')
    new_cmd_script = 'echo "new_cmd_script" > ' + tmpfile_name
    new_cmd = CorrectedCommand(script=new_cmd_script, side_effect=None, priority=1)
    new_cmd.run(old_cmd)
    time.sleep(0.1)
    with open(tmpfile_name, 'r') as f:
        assert f.read() == 'new_cmd_script\n'

# Generated at 2022-06-24 07:47:29.013151
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    scripts = [
        'foo',
        'bar',
        'baz',
    ]
    side_effects = [
        None,
        'effect',
        None,
    ]
    priorities = [
        1,
        2,
        3,
    ]

    # Cases with same scripts and side_effects but different priorities
    hashes = [
        CorrectedCommand(scripts[0], side_effects[0], priorities[0]).__hash__(),
        CorrectedCommand(scripts[0], side_effects[0], priorities[1]).__hash__(),
    ]
    assert hashes[0] == hashes[1], '__hash__() must ignore priorities'

    # Cases with same scripts but different side_effects

# Generated at 2022-06-24 07:47:36.152824
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script = 'foo bar'
    corrected_scripts = ['foo2 bar2', 'foo3 bar3']
    command = Command(script, '')
    corrected_commands = [CorrectedCommand(s, None, 1) for s in corrected_scripts]
    side_effect = None
    priority = 1
    rule = Rule('TEST',
                lambda c: c.script == script and True,
                lambda c: corrected_scripts,
                True, side_effect, priority, True)
    assert [c for c in rule.get_corrected_commands(command)] == corrected_commands

# Generated at 2022-06-24 07:47:38.693637
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand('test', None, 100)
    assert cmd.script is 'test'
    assert cmd.side_effect is None
    assert cmd.priority is 100


# Generated at 2022-06-24 07:47:41.925304
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd_test = CorrectedCommand('test', None, 5)
    assert cmd_test.script == 'test'
    assert cmd_test.side_effect == None
    assert cmd_test.priority == 5



# Generated at 2022-06-24 07:47:52.374418
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    """Unit test for constructor of class CorrectedCommand.

    Purposely, the instance variables are stored in self.

    Also test that repeat runs self.script again?
    """
    from . import settings
    from .explain import explain, ExplainError
    from .main import main
    from .shells import shell
    from .const import DEFAULT_PRIORITY
    import os
    import sys

    # Unit test CorrectedCommand.__init__()
    self = CorrectedCommand
    assert self.script == None
    assert self.side_effect == None
    assert self.priority == None
    # Unit test CorrectedCommand()
    self = CorrectedCommand("", None, 0)
    assert self.script == ""
    assert self.side_effect == None
    assert self.priority == 0

    self = CorrectedCommand("", None, None)

# Generated at 2022-06-24 07:47:56.606939
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert CorrectedCommand(script="ls",
                            side_effect=None,
                            priority=1234).__hash__() == \
           CorrectedCommand(script="ls",
                            side_effect=None,
                            priority=4321).__hash__()

# Generated at 2022-06-24 07:48:00.498446
# Unit test for constructor of class Command
def test_Command():
    cmd = Command('xrandr --panning 2880x1800+0+0 1.5x1.5', None)
    assert str(cmd) == 'Command(script=xrandr --panning 2880x1800+0+0 1.5x1.5, output=None)'


# Generated at 2022-06-24 07:48:03.361694
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    cmd = Command('git status', None)
    side_effect = lambda c, cmd: False
    cr_cmd = CorrectedCommand('git status --short', side_effect, 1000)
    cr_cmd.run(cmd)

# Generated at 2022-06-24 07:48:06.404390
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand("--priority", "--side_effect", "--script")
    out = CorrectedCommand("--priority", "--side_effect", "--script")
    assert cmd == out
    assert cmd.__hash__() == out.__hash__()

if __name__ == "__main__":
    test_CorrectedCommand()

# Generated at 2022-06-24 07:48:11.636026
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    """
    unittest(test_CorrectedCommand___eq__)
    """
    c1 = CorrectedCommand(script=u'ls', side_effect=None, priority=1)
    c2 = CorrectedCommand(script=u'ls', side_effect=None, priority=2)
    assert c1 == c2


# Generated at 2022-06-24 07:48:19.298321
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    module=types.ModuleType('test_rule_get_corrected_commands')
    def fake_match(command):
        return True
    def fake_get_new_command(command):
        return 'com1', 'com2'
    module.match = fake_match
    module.get_new_command = fake_get_new_command
    rule = Rule('test', module.match, module.get_new_command, True, None, 1, False)
    fake_command = Command('fake_command', None)
    com1 = CorrectedCommand('com1', None, 1)
    com2 = CorrectedCommand('com2', None, 2)
    assert list(rule.get_corrected_commands(fake_command)) == [com1, com2]

# Generated at 2022-06-24 07:48:26.944046
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule("name", lambda x: True, lambda x: "yay!", True, None, 1, False)
    assert rule.__repr__() == 'Rule(name=name, match=<function <lambda> at 0x7f723bf3d840>, get_new_command=<function <lambda> at 0x7f723bf3d8c8>, enabled_by_default=True, side_effect=None, priority=1, requires_output=False)'


# Generated at 2022-06-24 07:48:29.493620
# Unit test for constructor of class Command
def test_Command():
    cmd = Command(script='ls', output='1 2 3\n')
    assert cmd.script == 'ls'
    assert cmd.output == '1 2 3\n'


# Generated at 2022-06-24 07:48:35.486160
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Tests the method `get_corrected_commands` of class Rule.

    This method returns new `CorrectedCommand` instances,
    based on a `Rule` instance.

    Args:

    """
    # load rule
    # rule_path = os.path.abspath(os.path.join(
    rule_path = os.path.join(
        os.path.dirname(__file__),
        'rules',
        'git_push_pwd_master.py')

# Generated at 2022-06-24 07:48:44.684570
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # mock of class Command
    class Command(object):
        def __init__(self, script, output):
            self.script = script
            self.output = output
    # mock of class Shell
    import mock
    shell = mock.Mock()
    shell.or_ = lambda s, t: s
    shell.quote = lambda s: s
    shell.put_to_history = lambda s: s
    logs.debug = lambda s: s
    # mock of class Settings
    import mock
    settings = mock.Mock()
    settings.alter_history = False
    # mock of class CorrectedCommand
    class CorrectedCommand(object):
        def __init__(self, script, side_effect, priority):
            self.script = script
            self.side_effect = side_effect
            self.priority = priority
    #

# Generated at 2022-06-24 07:48:55.137661
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule(
        name="name",
        match=lambda *args: True,
        get_new_command=lambda *args: "new command",
        enabled_by_default=True,
        side_effect=lambda *args: None,
        priority=1,
        requires_output=False
    ).__eq__(
        Rule(
            name="name",
            match=lambda *args: True,
            get_new_command=lambda *args: "new command",
            enabled_by_default=True,
            side_effect=lambda *args: None,
            priority=1,
            requires_output=False
        )
    )

# Generated at 2022-06-24 07:49:03.241000
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    r = Rule(name='', match='', get_new_command='', enabled_by_default=True, side_effect='', priority=1, requires_output=True)
    new_command = 'git config --global core.pager \"less -r\"'
    corrected_command = CorrectedCommand(script=new_command, side_effect=None, priority=1)
    commands = r.get_corrected_commands(new_command)
    for c in commands:
        assert c == corrected_command

# Generated at 2022-06-24 07:49:05.512758
# Unit test for constructor of class Command
def test_Command():
    # empty string should raise EmptyCommand
    with pytest.raises(EmptyCommand):
        Command.from_raw_script([])


# Generated at 2022-06-24 07:49:12.153752
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """Unit test for method __hash__ of class CorrectedCommand"""
    import pytest

    test_data = [
        {
            'script': 'echo test',
            'side_effect': None,
            'priority': 1
        },
        {
            'script': 'echo test1',
            'side_effect': None,
            'priority': 1
        },
        {
            'script': 'echo test',
            'side_effect': None,
            'priority': 5
        },
    ]

    objects = [CorrectedCommand(**kwargs) for kwargs in test_data]
    for i, j in [(0, 2), (1, 2)]:
        assert objects[i] == objects[j]
        assert objects[i].__hash__() == objects[j].__hash__()