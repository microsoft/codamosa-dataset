

# Generated at 2022-06-24 07:39:14.000278
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    c = CorrectedCommand(script="script X", side_effect=None, priority=1)
    assert c.script == "script X"
    assert c.side_effect == None
    assert c.priority == 1


# Generated at 2022-06-24 07:39:16.574807
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    CorrectedCommand(script='foo', side_effect=None, priority=0).__hash__()

# Generated at 2022-06-24 07:39:23.675347
# Unit test for method is_match of class Rule
def test_Rule_is_match():

    """This function is a dummy function used instead of the real `rule.match`
    function during the unit test.

    """
    def dummy_match(command):
        pass

    rule = Rule('dummy', dummy_match, lambda x: '', True,
                lambda x, y: None, 0, True)

    def tests():

        class Command_Test:

            def __init__(self, output=None):
                self.output = output
                self.script = output

        class Command_Test_2:

            def __init__(self, output, script):
                self.output = output
                self.script = script

        yield (Command_Test, True)
        yield (Command_Test_2, "OK")

    for command, result in tests():
        rule.match = lambda c: command(c) == result

# Generated at 2022-06-24 07:39:26.300993
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert hash(CorrectedCommand('script', None, 0)) == hash(('script', None))



# Generated at 2022-06-24 07:39:30.457998
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    corrected_command = CorrectedCommand('command', None, 0)
    assert(corrected_command.script == 'command')
    assert(corrected_command.side_effect is None)
    assert(corrected_command.priority == 0)


# Generated at 2022-06-24 07:39:32.784669
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command(script='script', output='output')) == 'Command(script=script, output=output)'


# Generated at 2022-06-24 07:39:38.086335
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    os.environ['PYTHONIOENCODING'] = 'UTF-8'
    from .shells import shell
    from .conf import settings
    from .exceptions import EmptyCommand
    from .output_readers import get_output
    from .utils import format_raw_script, get_alias
    from . import logs
    from . import translation
    from . import ui
    from . import compat

    def side_effect(f_old_cmd, f_new_cmd):
        pass

    priority = 1
    script = 'rm -rf /'
    corrected_command = CorrectedCommand(script=script, side_effect=side_effect, priority=priority)
    output = get_output(script, script)
    old_command = Command(script=script, output=output)

# Generated at 2022-06-24 07:39:41.533929
# Unit test for method update of class Command
def test_Command_update():
    c = Command('ls', '-la')
    c1 = c.update(script='ls -la')
    c2 = Command('ls -la', '-la')
    assert c1 == c2
    assert c1 is not c2
    assert c == c
    assert c is not None



# Generated at 2022-06-24 07:39:48.080035
# Unit test for constructor of class Rule
def test_Rule():
    from .rules.apt_autoremove import match, get_new_command
    rule = Rule(name = "apt_autoremove", match = match, get_new_command = get_new_command,
                enabled_by_default = True, side_effect = None, priority = 10, requires_output = True)
    assert(rule.name == "apt_autoremove")
    assert(rule.match == match)
    assert(rule.get_new_command == get_new_command)
    assert(rule.enabled_by_default == True)
    assert(rule.side_effect == None)
    assert(rule.priority == 10)
    assert(rule.requires_output == True)


# Generated at 2022-06-24 07:39:50.767760
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    newCommand = Command("a b c", "d e f")
    assert newCommand.__repr__() == "Command(script=a b c, output=d e f)"



# Generated at 2022-06-24 07:39:54.758198
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert repr(Command(script=u'git status', output=u'On branch master')) \
        == u"Command(script=u'git status', output=u'On branch master')"


# Generated at 2022-06-24 07:40:03.303335
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # Alter history for logging purposes
    settings.alter_history = True
    # Enable repeat for logging purposes
    settings.repeat = True
    # Disable debug for logging purposes
    settings.debug = False

    # Test command:
    cmd = Command(script='echo foo', output='foo')

    # Test CorrectedCommand, with side effect:
    cc_side_effect = CorrectedCommand(script='echo bar',
                                      side_effect=lambda cmd, script: logging.debug(f'corrected to: {script}'),
                                      priority=1)
    # Test CorrectedCommand, without side effect:
    cc_no_side_effect = CorrectedCommand(script='echo baz',
                                         side_effect=None,
                                         priority=1)

    logging.debug('Expected side effect:')

# Generated at 2022-06-24 07:40:11.808806
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    c = CorrectedCommand(script='a', side_effect=None, priority=1)
    assert c == CorrectedCommand(script='a', side_effect=None, priority=2)
    assert c != CorrectedCommand(script='b', side_effect=None, priority=1)
    assert c != CorrectedCommand(script='b', side_effect=None, priority=2)
    assert c != CorrectedCommand(script='a', side_effect=lambda: None, priority=1)
    assert c != CorrectedCommand(script='a', side_effect=lambda: None, priority=2)



# Generated at 2022-06-24 07:40:14.493064
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    command_1 = CorrectedCommand("git push", None, 2)
    command_2 = CorrectedCommand("git push -f", None, 1)
    assert repr(command_1) == 'CorrectedCommand(script=git push, side_effect=None, priority=2)'
    assert repr(command_2) == 'CorrectedCommand(script=git push -f, side_effect=None, priority=1)'


# Generated at 2022-06-24 07:40:16.516198
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    assert Command(script="ls -l", output="/home").__repr__() == "Command(script=ls -l, output=/home)"

# Generated at 2022-06-24 07:40:21.520817
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """Test for method __hash__ of class CorrectedCommand."""
    command1 = CorrectedCommand('fuck', None, 1)
    command2 = CorrectedCommand('fuck', None, 1)
    command3 = CorrectedCommand('fuck', 1, 1)
    command4 = CorrectedCommand('fuck', 1, 1)

    assert command1.__hash__() == command2.__hash__()
    assert command3.__hash__() == command4.__hash__()
    assert command1.__hash__() != command3.__hash__()


# Generated at 2022-06-24 07:40:22.905904
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand(script="git push", side_effect=None, priority=5)

# Generated at 2022-06-24 07:40:27.374419
# Unit test for constructor of class Command
def test_Command():
    assert Command('ls', None) == Command('ls', None)
    assert ('ls', None) != Command('ls', None)

    c = Command('ls', None)
    assert c == c.update()
    assert Command('ls', 'hallo') == c.update(output='hallo')
    assert Command('ls', None) == c.update(script='ls')



# Generated at 2022-06-24 07:40:32.223368
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    c1 = Command(script='ls', output='<output>')
    c2 = Command(script='ls -la', output='<output>')
    c3 = Command(script='ls', output='output')
    assert c1 == c1
    assert c1 != c2
    assert c2 != c3
    assert c2 != 3
    assert c2 == Command('ls -la', '<output>')


# Generated at 2022-06-24 07:40:38.595181
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand('echo "foo+"', None, 0)
    assert cmd.script == 'echo "foo+"'
    assert cmd.priority == 0
    assert cmd.side_effect is None
    assert cmd == CorrectedCommand('echo "foo+"', None, 10)
    assert cmd != CorrectedCommand('echo "foo+"', 'echo "bar"', 0)
    assert cmd != CorrectedCommand('echo "foo++"', None, 0)

# Generated at 2022-06-24 07:40:47.695867
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    path = pathlib.Path(__file__) / 'test_data' / 'rules'
    path.mkdir(exist_ok=True)
    (path / 'rule_with_name_that_ends_with_py.py').write_text('match = lambda cmd: True')
    (path / 'rule_without_name_py.py').write_bytes(b'match = lambda cmd: True')
    rule_module = load_source('rule_module', str(path))
    rule_module.module_name = 'rule_module'
    rule_module.match = lambda cmd: True
    rule_module.get_new_command = lambda cmd: 'echo correct'
    rule_module.side_effect = lambda cmd, new_cmd: None
    rule_module.priority = 0
    rule_module.enabled_by_default

# Generated at 2022-06-24 07:40:57.362156
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    name = os.path.join(os.path.dirname(__file__), 'rules', 'apt_get_install.py')
    r1 = Rule.from_path(pathlib.Path(name))
    r2 = Rule.from_path(pathlib.Path(name))

    assert r1 != r2
    assert r1.__eq__(r2)
    assert r2.__eq__(r1)

    # We do not do an in-depth comparison of functions.
    # Testing equality of the same functions is sufficient.
    #
    # If the functions are different, the rule is different.
    r2 = r1.update(match=lambda cmd: False)
    assert r1 != r2
    assert not r1.__eq__(r2)
    assert not r2.__eq__(r1)

# Generated at 2022-06-24 07:41:05.415119
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command('foo bar', 'bazz') == Command('foo bar', 'bazz')
    assert Command('foo bar', 'bazz') != Command('foo bar', 'bazz way')
    assert Command('foo bar', 'bazz') != Command('foo bar way', 'bazz')
    assert Command('foo bar', 'bazz') != Command('foo bar way', 'bazz way')
    assert Command('foo bar', 'bazz') != object()


# Generated at 2022-06-24 07:41:14.122506
# Unit test for method update of class Command
def test_Command_update():
    command = Command(script = 'ls', output = 'ls')
    new_command = command.update(script = 'touch')
    assert new_command.script == 'touch'
    assert new_command.output == 'ls'
    assert new_command.script_parts == ['touch']

    command = Command(script = 'ls', output = 'ls')
    new_command = command.update()
    assert new_command.script == 'ls'
    assert new_command.output == 'ls'
    assert new_command.script_parts == ['ls']


# Generated at 2022-06-24 07:41:24.201271
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_rule_module = load_source('test_rule', str(settings.rules_path / 'test_rule.py'))
    test_rule = Rule(name=test_rule_module.name,
                     match=test_rule_module.match,
                     get_new_command=test_rule_module.get_new_command,
                     enabled_by_default=getattr(test_rule_module,
                                                'enabled_by_default', True),
                     side_effect=getattr(test_rule_module, 'side_effect', None),
                     priority=settings.priority.get('test_rule', DEFAULT_PRIORITY),
                     requires_output=getattr(test_rule_module, 'requires_output', True))
    test_cmd = Command(script=u'echo something', output=u'nothing')
   

# Generated at 2022-06-24 07:41:30.891041
# Unit test for constructor of class Rule
def test_Rule():
    """Test case for Rule constructor."""
    assert Rule('name', lambda cmd: True, lambda cmd: '', True, lambda *_: None, 0, True) == Rule('name', lambda cmd: True, lambda cmd: '', True, lambda *_: None, 0, True)
    assert Rule('name', lambda cmd: True, lambda cmd: '', True, lambda *_: None, 0, True) != Rule('name2', lambda cmd: True, lambda cmd: '', True, lambda *_: None, 0, True)

test_Rule()


# Generated at 2022-06-24 07:41:39.147944
# Unit test for constructor of class Rule

# Generated at 2022-06-24 07:41:41.730979
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule = Rule('name', 'match', 'get_new_command', True, None, 4, True)
    inp = Command('script', 'output')
    exp = False
    assert (rule.is_match(inp) == exp)

# Generated at 2022-06-24 07:41:46.886059
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from pytest import raises

    from . import utils
    from .shells import shell

    tmpdir = utils.get_tempdir()

    class TestCommand(Command):
        def update(self, **kwargs):
            return TestCommand(**kwargs)

    # default settings
    old_cmd = TestCommand(script='old cmd', output='output')
    CorrectedCommand('new cmd', None, 0).run(old_cmd)

    # side_effect
    assert not shell.history

# Generated at 2022-06-24 07:41:50.410398
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    r1 = Rule('name1', lambda comm: True, lambda comm: '', True, None,5, True)
    r2 = Rule('name1', lambda comm: True, lambda comm: '', True, None,5, True)
    assert r1 == r2


# Generated at 2022-06-24 07:41:52.867704
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    script = 'ls'
    output = '-'
    command = Command(script, output)
    assert command.__repr__() == "Command(script='ls', output='-')"


# Generated at 2022-06-24 07:42:03.547753
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    def match(command):
        return True
    def get_new_command(command):
        return 'echo "something"'

    rule = Rule('test', match, get_new_command, False, None, 0, False)
    comm = Command('pkgctl','pkgctl')
    c_comm = CorrectedCommand('echo "something"', None, 0)
    assert c_comm == next(rule.get_corrected_commands(comm))
    def get_new_command(command):
        return ['echo "something"', 'echo "else"']

    rule = Rule('test', match, get_new_command, False, None, 0, False)
    comm = Command('pkgctl','pkgctl')
    c_comm = CorrectedCommand('echo "something"', None, 0)

# Generated at 2022-06-24 07:42:06.880098
# Unit test for constructor of class Rule
def test_Rule():
    # test for Rule()
    Rule("fuck", True, 1, 2, 3, 4)
    Rule("fuck", False, True, False, 4, 5, 6)
    # test for Rule.from_path()
    Rule.from_path("/usr/local/bin/fuck")

# Generated at 2022-06-24 07:42:08.613634
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    command = Command(script='command', output='output')
    assert str(command) == "Command(script='command', output='output')"


# Generated at 2022-06-24 07:42:12.252296
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    a = CorrectedCommand('bash.fuck', 'side_effect', 'priority')
    assert str(a) == u'CorrectedCommand(script=bash.fuck, side_effect=side_effect, priority=priority)'



# Generated at 2022-06-24 07:42:23.221263
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # test the condition of setting PYTHONIOENCODING
    test_cmd = CorrectedCommand('ls', None, 0)
    with shell.patch_environ(PYTHONIOENCODING='latin1'):
        test_cmd.run(Command('command', 'output'))

    # test of run() method
    old_cmd = Command('fuck', None)
    history_list = []
    shell.put_to_history = history_list.append
    # test for setting PYTHONIOENCODING
    with shell.patch_environ(PYTHONIOENCODING='latin1'):
        test_cmd.run(old_cmd)
    assert len(history_list) == 1
    # test for command is not added to history

# Generated at 2022-06-24 07:42:34.570102
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .fake import FakeOutput
    from .history import History
    from . import rules
    
    history = History()
    history.append(Command(script='git push origin master', output=''))
    history.append(Command(script='git push --set-upstream origin master', output=''))
    
    rule = rules.Rule(name='', match=lambda cmd: (cmd.script == "git push origin master") and (cmd.output == ""), get_new_command=lambda cmd: "git push --set-upstream origin master", enabled_by_default=True, side_effect=None, priority=1, requires_output=True)

# Generated at 2022-06-24 07:42:41.605323
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    a = CorrectedCommand('foo', None, 10)
    b = CorrectedCommand('foo', None, 10)
    c = CorrectedCommand('bar', None, 10)
    d = CorrectedCommand(None, None, 10)

    assert a == b
    assert hash(a) == hash(b)
    assert a != c
    assert a != d
    assert hash(a) != hash(c)
    assert hash(a) != hash(d)
    assert hash(c) != hash(d)

# Generated at 2022-06-24 07:42:51.044005
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    def match(rule):
        return True
    def get_new_command(rule):
        return "echo HelloWorld"
    def side_effect(rule,old_cmd,new_cmd):
        return

    rule = Rule(
        "rule",
        match,
        get_new_command,
        True,
        side_effect,
        1,
        True)

    result = repr(rule)

# Generated at 2022-06-24 07:42:53.693159
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    f = CorrectedCommand(script='script', side_effect='side_effect', priority='priority')
    g = CorrectedCommand(script='script', side_effect='side_effect', priority='priority')
    assert f.__hash__() == g.__hash__()

# Generated at 2022-06-24 07:42:58.864161
# Unit test for method update of class Command
def test_Command_update():
    """Test that `update` method works properly."""
    assert Command('ls', 'output').update() == Command('ls', 'output')
    assert Command('ls', 'output').update(script='cd') == Command('cd', 'output')
    assert Command('ls', 'output').update(output='out') == Command('ls', 'out')
    assert Command('ls', 'output').update(script='cd', output='out') == Command('cd', 'out')

# Generated at 2022-06-24 07:43:07.176037
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert (CorrectedCommand('1', lambda a, b: None, 1) ==
            CorrectedCommand('1', lambda a, b: None, 1))
    assert (CorrectedCommand('1', lambda a, b: None, 1) !=
            CorrectedCommand('2', lambda a, b: None, 1))
    assert (CorrectedCommand('1', lambda a, b: None, 1) !=
            CorrectedCommand('1', lambda a, b: None, 2))
    assert (CorrectedCommand('1', lambda a, b: None, 1) !=
            CorrectedCommand('1', lambda a, b: None, 1))

# Generated at 2022-06-24 07:43:10.625545
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule('nihao', lambda x: x, lambda x: x, False, lambda x, y: x, 2, True) == Rule('nihao', lambda x: x, lambda x: x, False, lambda x, y: x, 2, True)

# Generated at 2022-06-24 07:43:13.096446
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    corrected_command = CorrectedCommand('fuck', 'test')
    assert corrected_command == CorrectedCommand('fuck', 'test')
    assert hash(corrected_command) == hash(CorrectedCommand('fuck', 'test'))

# Generated at 2022-06-24 07:43:24.275506
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from . import shells
    from .rules import apt_get, brew_install, pip_install, yum_install, apt_get_auto_remove
    rule1 = Rule(name='apt-get',
                 match=apt_get.match,
                 get_new_command=apt_get.get_new_command,
                 enabled_by_default=True,
                 side_effect=None,
                 priority=0,
                 requires_output=True)
    rule2 = Rule(name='brew-install',
                 match=brew_install.match,
                 get_new_command=brew_install.get_new_command,
                 enabled_by_default=True,
                 side_effect=None,
                 priority=0,
                 requires_output=True)

# Generated at 2022-06-24 07:43:34.461423
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    import subprocess
    # If debug is True, shell.or_ will always return the repeat_fuck command
    class Empty_side_effect(object):
        def __init__(self, shell_or):
            self.shell_or = shell_or
        def __call__(self, old_cmd, new_cmd):
            return
    # Set side_effect as empty so that we can test if the shell.or() is called
    corrected_command = CorrectedCommand(script='pwd', side_effect=Empty_side_effect(shell.or_), priority=1)
    # Set the debug to true and repeat to true
    settings.alter_history = False
    settings.repeat = True
    settings.debug = True
    # The script is expected to be: pwd || {f} --debug --repeat --force-command "pwd"


# Generated at 2022-06-24 07:43:46.267433
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    command1 = CorrectedCommand("hello", None, None)
    command2 = CorrectedCommand("hello", None, None)
    command3 = CorrectedCommand("bye", None, None)
    command4 = CorrectedCommand("bye", None, None)
    command5 = CorrectedCommand("hello", None, None)
    command6 = CorrectedCommand("hello", None, None)
    assert command1 == command2
    assert command1 == command5
    assert command2 == command5
    assert command1 == command6
    assert command2 == command6
    assert command5 == command6
    assert command3 == command4
    assert command1 != command3
    assert command1 != command4
    assert command2 != command3
    assert command2 != command4
    assert command5 != command3
    assert command5 != command4

# Generated at 2022-06-24 07:43:56.706068
# Unit test for constructor of class Command
def test_Command():
    command = Command(
        script="ls -lh /usr/bin",
        output="total 44K\n-rwxr-xr-x 1 root root  34K Feb 11 18:52 fuser\n-rwxr-xr-x 1 root root 2.0K Feb 11 18:52 fusermount\n-r-xr-xr-x 1 root root 9.1K May  6  2014 fzf\n-rwxr-xr-x 1 root root 3.2K Feb 11 18:52 killall\n")
    assert command.script == "ls -lh /usr/bin"

# Generated at 2022-06-24 07:44:06.093599
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", "echo 1", "echo 1")
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", "echo 1", "echo 2")
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", "echo 1", None)
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", None, "echo 1")
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", None, None)
    assert CorrectedCommand("echo 1", "echo 1", "echo 1") == CorrectedCommand("echo 1", None, "echo 2")
    assert CorrectedCommand

# Generated at 2022-06-24 07:44:15.934962
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rules = [
        ('match', lambda *x: True),
        ('get_new_command', lambda *x: u'echo 1'),
        ('side_effect', lambda *x: None),
        ('enabled_by_default', True),
        ('priority', 1),
        ('requires_output', True),
    ]
    c0 = Rule(name='test', **dict(rules))
    c1 = Rule(name='test', **dict(rules + [('enabled_by_default', False)]))
    c2 = Rule(name='test', **dict(rules + [('name', 'test2')]))
    c3 = Rule(name='test', **dict(rules + [('match', lambda *x: False)]))

# Generated at 2022-06-24 07:44:18.390635
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    assert hash(CorrectedCommand('a', 'b', 1)) == hash(CorrectedCommand('a', 'b', 3))
    assert hash(CorrectedCommand('a', 'b', 1)) != hash(CorrectedCommand('c', 'b', 1))

# Generated at 2022-06-24 07:44:21.999694
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    a = Rule('name', 'match', 'get_new_command', 'enabled_by_default', 'side_effect', 'priority', 'requires_output')
    assert a.__repr__() == "Rule(name='name', match='match', get_new_command='get_new_command', enabled_by_default='enabled_by_default', side_effect='side_effect', priority='priority', requires_output='requires_output')"


# Generated at 2022-06-24 07:44:27.007863
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    cc = CorrectedCommand('script', 'side_effect', 'priority')
    assert cc.__repr__() == u'CorrectedCommand(script=script, side_effect=side_effect, priority=priority)'
    assert isinstance(cc.__repr__(), str)

# Generated at 2022-06-24 07:44:33.626974
# Unit test for method __repr__ of class Command
def test_Command___repr__():
    script = 'ls -la'
    output = 'ls: cannot access -la: No such file or directory'
    cmd = Command(script, output)
    res = "Command(script={}, output={})".format(script, output)
    if(cmd.__repr__() != res):
        raise AssertionError("The expected answer is:\"" + res + "\", but it is \"" + cmd.__repr__() + "\"")


# Generated at 2022-06-24 07:44:38.176440
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule("name", "match", "get_new_command", "enabled_by_default", "side_effect", "priority", "requires_output")
    assert rule.__repr__() == 'Rule(name=name, match=match, get_new_command=get_new_command, enabled_by_default=enabled_by_default, side_effect=side_effect, priority=priority, requires_output=requires_output)'

# Generated at 2022-06-24 07:44:44.538275
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    def match(cmd):
        return 'test' in cmd.script_parts

    class Empty(object):
        pass

    assert Rule(1, match, 1, 1, 1, 1, 1).is_match(Empty()) == False
    empty = Empty()
    empty.script = 'test'
    assert Rule(1, match, 1, 1, 1, 1, 1).is_match(empty) == True


# Generated at 2022-06-24 07:44:54.137016
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(
      name='test_rule',
      match=lambda x: True,
      get_new_command=lambda x: "echo test",
      enabled_by_default=True,
      side_effect=lambda x: None,
      priority=1,
      requires_output=True
    )
    assert repr(rule is 'Rule(name=test_rule, match=<function <lambda> at 0x10a1bf400>, '
      'get_new_command=<function <lambda> at 0x10a1bf748>, enabled_by_default=True, '
      'side_effect=None, priority=1, requires_output=True)')



# Generated at 2022-06-24 07:45:03.252975
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """ Test Rule.get_corrected_commands
    """
    from .rules.utils import get_new_command

    def match(cmd):
        return True

    expected_scripts = [
        CorrectedCommand('echo $PWD', None, 6),
        CorrectedCommand('echo $HOME', None, 9),
        CorrectedCommand('echo $HOME', None, 12),
    ]

# Generated at 2022-06-24 07:45:11.716695
# Unit test for method update of class Command
def test_Command_update():
    import unittest
    class Test_Command_update(unittest.TestCase):
        def test(self):
            script = 'git status a'
            output = 'On branch master\nnothing to commit, working tree clean'
            command = Command(script, output)
            newcommand = command.update(script='git status b')
            self.assertEquals(newcommand.script, 'git status b')
            self.assertEquals(newcommand.output, output)

    unittest.main(module=__name__, argv=[sys.argv[0], '-v'])

# Generated at 2022-06-24 07:45:12.944664
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert repr(CorrectedCommand(None, None, None)) == 'CorrectedCommand(script=None, side_effect=None, priority=None)'

# Generated at 2022-06-24 07:45:22.676991
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    # Setup
    from .rules import AlwaysRunRule as always_run_rule
    rule = Rule(name='AlwaysRunRule',
                match=always_run_rule.match,
                get_new_command=always_run_rule.get_new_command,
                enabled_by_default=always_run_rule.enabled_by_default,
                side_effect=always_run_rule.side_effect,
                priority=always_run_rule.priority,
                requires_output=always_run_rule.requires_output)

    # Test

# Generated at 2022-06-24 07:45:28.428401
# Unit test for constructor of class Rule
def test_Rule():
    r1 = Rule(
        name='aname',
        match=lambda x: True,
        get_new_command=lambda x: 'a',
        enabled_by_default=False,
        side_effect=None,
        priority=1,
        requires_output=True
    )
    assert(r1.name == 'aname')
    assert(r1.match(1) == True)
    assert(r1.get_new_command(1) == 'a')
    assert(r1.enabled_by_default == False)
    assert(r1.side_effect == None)
    assert(r1.priority == 1)
    assert(r1.requires_output == True)



# Generated at 2022-06-24 07:45:30.652424
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    assert repr(CorrectedCommand('ls -al', None, 20)) == "CorrectedCommand(script='ls -al', side_effect=None, priority=20)"

# Generated at 2022-06-24 07:45:33.969406
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    correct_cmd = CorrectedCommand('fake comand', None, 0)
    assert correct_cmd.script == 'fake comand'
    assert correct_cmd.priority == 0



# Generated at 2022-06-24 07:45:41.570954
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    from .rules import fuck_of_the_day
    assert (Rule('fuck_of_the_day', fuck_of_the_day.match, fuck_of_the_day.get_new_command, True, fuck_of_the_day.side_effect, 40, True)
            ==
            Rule('fuck_of_the_day', fuck_of_the_day.match, fuck_of_the_day.get_new_command, True, fuck_of_the_day.side_effect, 40, True))


# Generated at 2022-06-24 07:45:43.183825
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    CorrectedCommand('script', 'side_effect', 1)


# Generated at 2022-06-24 07:45:51.991962
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    assert Rule('name', 'match', 'get_new_command', 'enabled_by_default', \
                'side_effect', 'priority', 'requires_output') \
        == Rule('name', 'match', 'get_new_command', 'enabled_by_default', \
                'side_effect', 'priority', 'requires_output')
    assert Rule('name', 'match', 'get_new_command', 'enabled_by_default', \
                'side_effect', 'priority', 'requires_output') \
        != Rule('name1', 'match', 'get_new_command', 'enabled_by_default', \
                'side_effect', 'priority', 'requires_output')

# Generated at 2022-06-24 07:46:03.104788
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.powershell import Powershell
    from .shells.xonsh import Xonsh
    from .utils import get_alias
    import re

    def test_alias_output(shell, alias_output_re, alias_re):
        assert re.match(alias_re, alias_output_re), \
               'alias doesn\'t match the regex {}'.format(repr(alias_re))
        # alias will be like that:
        #     `alias fuck="PYTHONIOENCODING=utf-8 python -m thefuck
        #      --repeat --alter-history --exclude-rule '...' '--debug'
        #      --wait 0.8 ...`
       

# Generated at 2022-06-24 07:46:12.409960
# Unit test for method update of class Command
def test_Command_update():
    c = Command(script="cat a.txt", output="test")
    assert c.update(script="cat a.txt", output="test") == c
    assert c.update(script="cat a.txt", output="test") == Command(script="cat a.txt", output="test")
    assert c.update(script="cat a.txt", output="test2") != c
    assert c.update(script="cat a.txt", output="test2") == Command(script="cat a.txt", output="test2")
    assert c.update(script="cat b.txt", output="test") != c
    assert c.update(script="cat b.txt", output="test") == Command(script="cat b.txt", output="test")
    assert c.update(script="cat b.txt", output="test2") != c

# Generated at 2022-06-24 07:46:21.698370
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    from .tests import fsh
    assert Rule('ls', fsh.always_match, fsh.always_ls(), True, None, 1000, True) == Rule('ls', fsh.always_match, fsh.always_ls(), True, None, 1000, True)
    assert Rule('ls', fsh.always_match, fsh.always_ls(), True, None, 1000, True) != Rule('ls', fsh.always_match, fsh.always_ls(), True, None, 1000, False)
    assert Rule('ls', fsh.always_match, fsh.always_ls(), True, None, 1000, True) != 2


# Generated at 2022-06-24 07:46:26.609199
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    from .utils import hashable
    cc0 = CorrectedCommand('0', None, 0)
    cc1 = CorrectedCommand('0', None, 1)
    hashable(cc0)
    assert hash(cc0) == hash(cc1)
    cc2 = CorrectedCommand('1', None, 0)
    hashable(cc2)
    assert hash(cc0) != hash(cc2)



# Generated at 2022-06-24 07:46:30.283163
# Unit test for method update of class Command
def test_Command_update():
    cmd = Command(script="a", output="b")
    result = cmd.update(script="c")
    expected = Command(script="c", output="b")
    assert result == expected

# Generated at 2022-06-24 07:46:33.088125
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    correctedCommand = CorrectedCommand(script="", side_effect=None, priority=0)
    assert correctedCommand.__hash__() == ("", None).__hash__()

# Generated at 2022-06-24 07:46:41.548910
# Unit test for constructor of class Rule
def test_Rule():
    def match(text):
        return text == 'hi'

    def get_new_command(text):
        return 'hello'

    def side_effect(text):
        return None

    rule = Rule("hi_rule", match, get_new_command, True, side_effect=side_effect)
    assert rule.name == 'hi_rule'
    assert rule.match("hi") is True
    assert rule.get_new_command("hi") == 'hello'
    assert rule.enabled_by_default is True
    assert rule.side_effect("hi") == None


# Generated at 2022-06-24 07:46:48.789238
# Unit test for method update of class Command
def test_Command_update():
    """Unit test for method update of class Command"""
    cmd = Command('ls', 'file.txt')
    cmd2 = cmd.update(script='ls -l', output='file2.txt')
    assert cmd != cmd2, 'Rule was not updated!'
    assert cmd.script == 'ls', "Rule's script wasn't changed"
    assert cmd2.script == 'ls -l', "Rule's script was changed"
    assert cmd.output == 'file.txt', "Rule's output wasn't changed"
    assert cmd2.output == 'file2.txt', "Rule's output was changed"


# Generated at 2022-06-24 07:46:55.406068
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert CorrectedCommand(script='', side_effect=None,
            priority=0) == CorrectedCommand(script='',
            side_effect=None, priority=1)
    assert CorrectedCommand(script='', side_effect=None,
            priority=0) != CorrectedCommand(script='a',
            side_effect=None, priority=0)
    assert CorrectedCommand(script='', side_effect=None,
            priority=0) != Command(script='', output='')

# Generated at 2022-06-24 07:46:58.734270
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    with logs.debug_time('COMPARE'):
        lhs = Rule.from_path(settings.rule_dir / 'ignore.py')
        rhs = Rule.from_path(settings.rule_dir / 'ignore.py')
        assert lhs.__eq__(rhs)

# Generated at 2022-06-24 07:47:02.760082
# Unit test for method update of class Command
def test_Command_update():
    c1 = Command('ls | cat', 'Hello')
    c2 = c1.update(script='ls')
    assert c1.script != c2.script
    assert c1 == c2


# Generated at 2022-06-24 07:47:04.224796
# Unit test for constructor of class Command
def test_Command():
    test_Command = Command("ls -a", "")
    assert test_Command.script == "ls -a"
    assert test_Command.output == ""


# Generated at 2022-06-24 07:47:07.622400
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    assert CorrectedCommand(script='script',
                            side_effect=None,
                            priority=123) == \
           CorrectedCommand(script='script',
                            side_effect=None,
                            priority=321)



# Generated at 2022-06-24 07:47:15.018205
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    rule = Rule(name='a', match='m', get_new_command='g',
                enabled_by_default=True, side_effect='s',
                priority=7, requires_output=True)
    assert rule.__repr__() == \
        'Rule(name=a, match=m, get_new_command=g, ' \
        'enabled_by_default=True, side_effect=s, ' \
        'priority=7, requires_output=True)'



# Generated at 2022-06-24 07:47:19.407084
# Unit test for constructor of class CorrectedCommand

# Generated at 2022-06-24 07:47:22.830546
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    corrected_command = CorrectedCommand(script='ls', side_effect=None, priority=10)
    assert(corrected_command.script == 'ls')
    assert(corrected_command.side_effect == None)
    assert(corrected_command.priority == 10)


# Generated at 2022-06-24 07:47:33.257148
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .test import match_test_rule
    from .output_readers import output_reader
    from .utils import no_output
    import os
    import shutil
    import tempfile
    import unittest

    class TestRuleIsMatch(unittest.TestCase):

        def setUp(self):
            self.pwd = tempfile.mkdtemp()
            os.chdir(self.pwd)
            output_reader.update(
                test_file=(shell.from_shell, no_output))

        def tearDown(self):
            shutil.rmtree(self.pwd)

        def test_in_path_before_other(self):
            """Test for a bug in which rule is_match
               uses the wrong command name
               if you write an alias called 'fuck'.
            """

# Generated at 2022-06-24 07:47:37.343400
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    assert Command(script='ls', output='') == \
        Command(script='ls', output='')
    assert Command(script='ls', output='') != \
        Command(script='ls', output='ls:')


# Generated at 2022-06-24 07:47:45.391109
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule1 = Rule(
        name="test1",
        match=lambda x: True,
        get_new_command=lambda x: "test1",
        enabled_by_default=True,
        side_effect=lambda x, y: True,
        priority=1,
        requires_output=True,
    )

    rule2 = Rule(
        name="test2",
        match=lambda x: True,
        get_new_command=lambda x: "test2",
        enabled_by_default=True,
        side_effect=lambda x, y: True,
        priority=2,
        requires_output=False,
    )


# Generated at 2022-06-24 07:47:52.200073
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    assert CorrectedCommand('script', 'side effect', 1) == CorrectedCommand('script', 'side effect', 2)
    assert hash(CorrectedCommand('script', 'side effect', 1)) == hash(CorrectedCommand('script', 'side effect', 2))
    assert CorrectedCommand('script', 'side effect', 1) != CorrectedCommand('script', 'side effect', 2)
    assert CorrectedCommand('script', 'side effect', 1) != CorrectedCommand('script', 'side effect', 2)

# Generated at 2022-06-24 07:47:55.616866
# Unit test for constructor of class CorrectedCommand
def test_CorrectedCommand():
    cmd = CorrectedCommand(script="exit 1", side_effect=None, priority=3)
    assert cmd.script == "exit 1"
    assert cmd.side_effect is None
    assert cmd.priority == 3

# Generated at 2022-06-24 07:47:58.159700
# Unit test for method update of class Command
def test_Command_update():
    c = Command(script='ls', output='')
    d = c.update(script='dir')
    assert d.script == 'dir'
    assert d.output == ''


# Generated at 2022-06-24 07:48:04.065973
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    # Set up
    # Get arguments for method CorrectedCommand.__repr__
    script = "git commit -m 'updated readme'"
    side_effect = lambda old_cmd, script: None
    priority = 100
    # Call the method
    self = CorrectedCommand(script, side_effect, priority)
    result = self.__repr__()
    # Verify the result
    assert 'CorrectedCommand(script=git commit -m \'updated readme\', side_effect=<function <lambda> at 0x106694400>, priority=100)' == result


# Generated at 2022-06-24 07:48:11.833539
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    """Test __hash__ method of class CorrectedCommand.

    >>> new_command=CorrectedCommand("ls", lambda cmd, script: None, 0)
    >>> new_command_copy=CorrectedCommand("ls", lambda cmd, script: None, 1)
    >>> new_command == new_command_copy
    True
    >>> new_command is new_command_copy
    False
    >>> new_command.__hash__()
    new_command_copy.__hash__()
    """


# Generated at 2022-06-24 07:48:14.378403
# Unit test for constructor of class Command
def test_Command():
    command=Command("ls -la", "Output")
    assert command.script == "ls -la", "Script failed"
    assert command.output == "Output", "Output failed"


# Generated at 2022-06-24 07:48:21.395476
# Unit test for constructor of class CorrectedCommand

# Generated at 2022-06-24 07:48:31.778793
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    a = CorrectedCommand('ls', lambda x, y: None, 1)
    b = CorrectedCommand('ls', lambda x, y: None, 1)
    c = CorrectedCommand('ls', lambda x, y: None, 2)

    # hash equality
    assert a == b
    assert hash(a) == hash(b)
    assert a != c
    assert hash(a) != hash(c)
    assert b != c
    assert hash(b) != hash(c)

    d = CorrectedCommand('cd', lambda x, y: None, 1)
    # different side_effects
    assert a != d
    assert hash(a) != hash(d)

    e = CorrectedCommand('ls', lambda x, y: None, 2)
    # same command, different priority
    assert a != e
    assert hash(a)

# Generated at 2022-06-24 07:48:36.612546
# Unit test for method update of class Command
def test_Command_update():
    a = Command(script='foo', output='bar')
    assert a == a.update()

    b = a.update(script='baz')
    assert b != a
    assert b.script == 'baz'

    c = b.update(output='bat')
    assert c != b
    assert c.output == 'bat'

# Generated at 2022-06-24 07:48:42.086635
# Unit test for method __hash__ of class CorrectedCommand
def test_CorrectedCommand___hash__():
    c1 = CorrectedCommand('script', 'side_effect', 1)
    c2 = CorrectedCommand('script', 'side_effect', 2)
    c3 = CorrectedCommand('script1', 'side_effect', 1)
    assert c1.__hash__() == c2.__hash__()
    assert c1.__hash__() != c3.__hash__()

# Generated at 2022-06-24 07:48:43.713241
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    """Unit test for method __repr__ of class CorrectedCommand"""
    pass # FIXME


# Generated at 2022-06-24 07:48:45.985162
# Unit test for method __repr__ of class Rule
def test_Rule___repr__():
    assert repr(Rule("name", "match", "get_new_command", "enabled_by_default", "side_effect", "priority", "requires_output")) == "Rule(name=name, match=match, get_new_command=get_new_command, enabled_by_default=enabled_by_default, side_effect=side_effect, priority=priority, requires_output=requires_output)"


# Generated at 2022-06-24 07:48:50.837621
# Unit test for method __repr__ of class CorrectedCommand
def test_CorrectedCommand___repr__():
    class CorrectedCommand1(CorrectedCommand):
        def __init__(self, script, side_effect, priority):
            self.script = script
            self.side_effect = side_effect
            self.priority = priority
    CorrectedCommand1('git commit', 2, 3).__repr__()
    return 'OK'

# Generated at 2022-06-24 07:48:58.893832
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Test Rule.get_corrected_commands()"""
    import unittest
    def norepeat(cmd):
        return Rule('norepeat', None, lambda x: ['foo'], True, None, 1, False)
    def repeat(cmd):
        return Rule('repeat', None, lambda x: ['foo'], True, None, 1, False)
    def norepeat_list(cmd):
        return Rule('norepeat_list', None, lambda x: [], True, None, 1, False)
    def repeat_list(cmd):
        return Rule('repeat_list', None, lambda x: [], True, None, 1, False)

# Generated at 2022-06-24 07:49:09.013763
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    cmd1 = CorrectedCommand(script='git push', side_effect=None, priority=1)
    cmd2 = CorrectedCommand(script='git push', side_effect=None, priority=2)
    cmd3 = CorrectedCommand(script='git push', side_effect=None, priority=1)
    cmd4 = CorrectedCommand(script='git pull', side_effect=None, priority=1)
    cmd5 = CorrectedCommand(script='git push', side_effect=None, priority=1)

    assert cmd1 == cmd2
    assert cmd1 == cmd3
    assert cmd1 == cmd4
    assert cmd1 == cmd5
    assert cmd2 == cmd3
    assert cmd2 == cmd4
    assert cmd2 == cmd5
    assert cmd3 == cmd4
    assert cmd3 == cmd5
    assert cmd4 == cmd5

# Generated at 2022-06-24 07:49:16.875172
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .rules import shellcheck, xargs
    from .shells import posix
    rule_shellcheck = Rule.from_path(rule_path_shellcheck)
    rule_xargs = Rule.from_path(rule_path_xargs)
    assert rule_shellcheck.is_match(Command.from_raw_script(['ls']))
    assert rule_xargs.is_match(Command.from_raw_script(['ls']))


rule_path_shellcheck = pathlib.Path(os.path.abspath(__file__)).parent.joinpath('rules', 'shellcheck.py')
rule_path_xargs = pathlib.Path(os.path.abspath(__file__)).parent.joinpath('rules', 'xargs.py')