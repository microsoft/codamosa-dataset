

# Generated at 2022-06-26 07:11:14.890315
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_5 = '*Yz&%N'
    int_0 = 0
    int_1 = 0
    command_0 = Command('gulp build:dev', str_5)
    correctedCommand_0 = CorrectedCommand('gulp build:dev', None, 0)
    list_0 = (correctedCommand_0,)
    rule_0 = Rule('', test_case_0, list_0, 0, 0, int_0, 0)
    list_1 = rule_0.get_corrected_commands(command_0)
    if (list_1[0] is not correctedCommand_0):
        print('Test failed')


# Generated at 2022-06-26 07:11:21.718427
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_0 = ';6^oN=J$n'
    str_1 = '>G&s_9*'
    command_1 = Command(str_0, str_1)
    str_0 = '<1R&'
    str_1 = 'O3D#t'
    command_2 = Command(str_0, str_1)
    str_0 = 'y ]_ER:FzVb)W'
    str_1 = 'G$!omhp_NgN'
    command_3 = Command(str_0, str_1)

# Generated at 2022-06-26 07:11:29.543908
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    path_0 = pathlib.Path('./fuckit/data/rules/git/git.py')
    rule_0 = Rule.from_path(path_0)
    str_0 = 'git commit -am "fix shit"'
    str_1 = 'git commit -am "fix shit"'
    command_0 = Command(str_0, str_1)
    str_2 = 'git commit -am "fix shit"'
    corrected_command = CorrectedCommand(script=str_2, side_effect=None, priority=1)
    CorrectedCommand(script=str_2, side_effect=None, priority=1).run(command_0)

# Generated at 2022-06-26 07:11:41.595185
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'C834?*EJC1T$<N-L'
    str_1 = 'q3O54QP=0_/a$W.J;O'
    command_0 = Command(str_0, str_1)
    rule_0 = Rule('rule_0', None, None, True, None, 1, True)
    corrected_command_0 = CorrectedCommand(str_1, None, 7)
    corrected_command_1 = CorrectedCommand(str_1, None, 7)
    corrected_command_2 = CorrectedCommand(str_1, None, 7)
    list_0 = [corrected_command_0, corrected_command_1, corrected_command_2]
    itr_0 = rule_0.get_corrected_commands(command_0)
    list_

# Generated at 2022-06-26 07:11:44.053712
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # dict_0 = {}
    # dict_0 = {}
    return


# Generated at 2022-06-26 07:11:55.388666
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {}
    dict_0['enabled_by_default'] = True
    dict_0['requires_output'] = False
    dict_0['match'] = test_case_0
    dict_0['name'] = str_1
    dict_0['get_new_command'] = test_case_0
    dict_0['side_effect'] = test_case_0
    dict_0['priority'] = priority
    rule_0 = Rule(**dict_0)
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    dict_0 = {}
    dict_0['script'] = str_0
    dict_0['side_effect'] = test_case

# Generated at 2022-06-26 07:12:02.164943
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    dict_0 = {u'script': u'', u'output': None}
    rule_0 = Rule('', '', '', False, None, 0, True)
    command_0 = Command('', '')
    command_1 = Command('', '', '')
    method_0 = rule_0.is_match
    result_0 = method_0(command_0=command_0)
    assert result_0 is False



# Generated at 2022-06-26 07:12:09.505771
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_2 = 'Q.rdn^n=m:}&\\'
    rule_0 = Rule(str_2, __lambda_4, __lambda_5, False, __lambda_6, 9, True)
    args = (command_0, )
    res = rule_0.is_match(command_0)
    if res is not None:
        if res:
            print('Test case 1 passed')
        else:
            print('Test case 1 failed')


# Generated at 2022-06-26 07:12:15.108504
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    dict_0 = {}
    correct_commands_generator = CorrectedCommand.get_corrected_commands(command_0)
    print(correct_commands_generator)

# Generated at 2022-06-26 07:12:20.139917
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule('rule_0', 'rule_1', 'rule_2', True, 'rule_3',
                  DEFAULT_PRIORITY, True)
    command_0 = Command('/usr/bin/find', None)
    assert rule_0.is_match(command_0)



# Generated at 2022-06-26 07:12:39.404658
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "[]\nj38,\r"
    str_1 = 'j\r\'rZ?[3'
    command_0 = Command(str_0, str_1)
    str_2 = 'r'
    class Class3:
        def __init__(self, arg_0, arg_1, arg_2, arg_3=False, arg_4=None, arg_5=None, arg_6=None):
            self.__str_0 = arg_0
            self.__str_1 = arg_1
            self.__str_2 = arg_2
            self.__bool_0 = arg_3
            self.__none_0 = arg_4
            self.__none_1 = arg_5
            self.__none_2 = arg_6

# Generated at 2022-06-26 07:12:50.753052
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    statement_0 = 'statement_0'
    statement_1 = 'statement_1'

    # '''Create a test environment for Rule class'''
    rule_0 = Rule(statement_0, statement_1, statement_0, statement_0, statement_1, statement_1, statement_0)

    # '''Test method Rule.is_match of class Rule''' with parameter test_Command_0
    str_0 = '"g6\x14\x7f:31\x0cT\x17x'
    str_1 = 'g6\x14\x7f:31\x0cT\x17x'
    command_0 = Command(str_0, str_1)
    # Invoke method Rule.is_match of class Rule with rule_0 and argument command_0
    result_boolean_0

# Generated at 2022-06-26 07:12:56.093313
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 's=schnauze'
    str_1 = 'B+Z:X#CKc'
    command_0 = Command(str_0, str_1)
    str_2 = 'G:Z{M'
    str_3 = 'D$}<K'
    command_1 = Command(str_2, str_3)
    str_4 = '#3fqg_={wGxD'
    str_5 = '{aUZp6'
    command_2 = Command(str_4, str_5)
    rule_0 = Rule(str_0, str_1, str_2, str_3, str_4, str_5, str_2)
    corrected_command_0 = CorrectedCommand(str_0, str_1, str_3)
   

# Generated at 2022-06-26 07:13:01.819901
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'bywA,$'
    str_1 = 'XX%\x0bXK'
    str_2 = '0|3C(az@f&J='
    path_0 = Path(str_0)
    # path_0.relative_to(path_1)
    command_0 = Command(str_1, str_2)
    # rule_0 = Rule.from_path(path_0)
    # rule_0.is_match(command_0)


# Generated at 2022-06-26 07:13:04.158843
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    arg_0 = Command('rm', None)
    arg_1 = Rule('dummy', None, None, True, None, None)
    CorrectedCommand('rm -i', None, None)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 07:13:05.663282
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    test_case_0()

# Unit test after refactoring of class Rule

# Generated at 2022-06-26 07:13:16.670125
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_2 = '5uN`vG|TO,'
    str_3 = 't105|hhs$ITD;2D'
    command_1 = Command(str_2, str_3)
    str_4 = '5uN`vG|TO,'
    str_5 = 't105|hhs$ITD;2D'
    command_2 = Command(str_4, str_5)
    str_6 = '5uN`vG|TO,'
    str_7 = 't105|hhs$ITD;2D'

# Generated at 2022-06-26 07:13:24.095063
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Test get_corrected_commands"""
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    str_2 = 'EAoFc%'
    str_3 = 'jK4v*t1'
    str_4 = 'M**'
    str_5 = '7sKs'
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_2, command_0.__eq__, lambda command_1: str_3, True, name=str_4, phase=100, enabled_by_default=True, side_effect=lambda command_1, str_5: command_0.update(script=str_5), priority=5, requires_output=True)
    corrected

# Generated at 2022-06-26 07:13:33.814349
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    try:
        str_0 = '5uN`vG|TO,'
        str_1 = 't105|hhs$ITD;2D'
        command_1 = Command(str_0, str_1)
        dict_0 = {}
        rule_1 = Rule('', dict_0, dict_0, True, dict_0, 1, True)
        rule_0 = Rule('', dict_0, dict_0, True, dict_0, 1, True)
    except Exception as e:
        logs.error(str(e))
        logs.error(str(sys.exc_info()))


# Generated at 2022-06-26 07:13:40.561753
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_2 = 'b8mHn?<R!w)lFJdq'
    str_3 = 't105|hhs$ITD;2D'
    command_1 = Command(str_2, str_3)
    str_4 = 't105|hhs$ITD;2D'
    rule_0 = Rule(str_4, command_0)
    set_0 = set()
    def_0 = set_0
    rule_0.match = def_0
    set_1 = set()
    def_1 = set_1
    rule_0.get_new_command

# Generated at 2022-06-26 07:13:59.883040
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = ',-'
    str_1 = '7JE'
    str_2 ='3Y-1^'
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_0,  str_1, str_2, str_2, str_2, str_2, str_2)
    CorrectedCommand.get_corrected_commands(rule_0, command_0)
    pass

# Generated at 2022-06-26 07:14:01.309854
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    assert False


# Generated at 2022-06-26 07:14:06.961479
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    from .rules.random_rule import random_rule
    from .shells import get_aliases
    from .conf import settings

    command = Command('git commit', 'commit')

    corrected_command = CorrectedCommand('git commit -v', random_rule.side_effect, 0)
    with get_aliases():
        settings.debug = True
        corrected_command.run(command)



# Generated at 2022-06-26 07:14:15.934082
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_2 = 'te`st'
    str_3 = 'cp'
    str_4 = "'"
    str_5 = '~'
    str_6 = "'"
    str_7 = 'test@test.test'
    str_8 = '#test_test'
    str_9 = '#test test'
    str_10 = 'invalid'
    str_11 = 'test.test'
    rule_0 = Rule(str_8, test_case_0, str_5, False, str_9, 1, False)

# Generated at 2022-06-26 07:14:24.257457
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    try:
        rule = Rule('foo', 'bar', 'baz', True, None, DEFAULT_PRIORITY, True)
        new_commands = rule.get_new_command(None)
        x = next(rule.get_corrected_commands(None))
    except StopIteration:
        x = None

    x_ref = CorrectedCommand(script='bar', side_effect=None, priority=1)
    assert x == x_ref

if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:14:35.683723
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '_l&Qy+d,`fH1'
    command_0 = Command(str_0, str_0)
    arg_0 = command_0
    rule_0 = Rule('name', lambda command: (command.script[0] in '?<>()$=+-*{}\\') == True, lambda command: command.script, False, None, DEFAULT_PRIORITY, True)
    rule_1 = Rule('name', lambda command: (command.script[0] in '?<>()$=+-*{}\\') == True, lambda command: command.script, False, None, 10, True)

# Generated at 2022-06-26 07:14:42.254595
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {}
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    dict_0 = {}
    str_2 = '/{}/'.format(sys.executable)
    str_3 = '/{}/'.format(sys.executable)
    dict_0 = {}
    dict_0['match'] = lambda command, rule: str_2 in command.script
    dict_0['get_new_command'] = lambda command, rule: [rule.name + ": " + command.script]
    dict_0['priority'] = 50
    rule_0 = Rule(dict_0)
    dict_0 = {}

# Generated at 2022-06-26 07:14:53.545908
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'r_D"2EHm;s1'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    str_1 = 'l)l__Bhht90:FzM'
    str_2 = 'T{r*hD;QO^!s'
    str_3 = '(*e$J-u^7n'
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}

# Generated at 2022-06-26 07:15:02.633362
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'i"x'
    str_1 = 'FO'
    command_0 = Command(str_0, str_1)
    str_2 = 'o0'
    str_3 = '3('
    command_1 = Command(str_2, str_3)
    int_0 = 0
    rule_0 = Rule('D', None, None, False, None, int_0, False)
    list_0 = []
    list_0 += [command_0]
    set_0 = set(list_0)
    set_1 = rule_0.get_corrected_commands(set_0)
    assert set_0 == set_1
    list_1 = []
    list_1 += [command_1]
    set_2 = set(list_1)

# Generated at 2022-06-26 07:15:08.884126
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # setup
    test_case_0()
    rule_0 = Rule(str_0, str_1, str_1, True, str_0, int_0, True)
    command_0 = Command(str_0, str_1)

    # test
    assert rule_0.is_match(command_0) == True


# Generated at 2022-06-26 07:15:39.448752
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = settings.rules[0]
    command_0 = settings.commands[0]
    assert rule_0.is_match(command_0) is False

# Generated at 2022-06-26 07:15:42.645009
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = 'jJ=l9;<'
    str_1 = 'bY^z*92'
    str_2 = '2rml5'
    rule_0 = Rule.from_path(str_0)
    command_0 = Command(str_1, str_2)
    corrected_command_0 = CorrectedCommand(rule_0, command_0, str_2)
    CorrectedCommand.run(corrected_command_0, command_0)


# Generated at 2022-06-26 07:15:45.524772
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule('name', 'match', 'get_new_command', True, 'side_effect', 'priority', 'requires_output')
    command_0 = Command('script', 'output')
    result_0 = rule_0.is_match(command_0)


# Generated at 2022-06-26 07:15:53.857836
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '~;1VO9)n_^$P#'
    str_1 = '%p1|nY&'
    command_0 = Command(str_0, str_1)
    corrected_command_0 = CorrectedCommand(command_0, None, 0)
    try:
        corrected_command_0.run(command_0)
    except:
        sys.stderr.write('Exception caught: ' + str(sys.exc_info()[0]))


# Generated at 2022-06-26 07:16:05.213747
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    script_0 = '^1j/r1|'
    side_effect_0 = None
    corrected_command_0 = CorrectedCommand(script_0, side_effect_0, 4)
    corrected_command_1 = CorrectedCommand(script_0, side_effect_0, 4)
    corrected_command_2 = CorrectedCommand(script_0, side_effect_0, 4)
    corrected_command_3 = CorrectedCommand(script_0, side_effect_0, 4)
    corrected_command_4 = CorrectedCommand(script_0, side_effect_0, 4)
    corrected_command

# Generated at 2022-06-26 07:16:12.038491
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'eRm[~nIp'
    str_1 = '"1z('
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_0, str_1)
    list_0 = rule_0.get_corrected_commands(command_0)
    print(list_0)
    print(list_0.__class__)


# Generated at 2022-06-26 07:16:22.751086
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'D:\\Coding\\PyCharm\\test1\\data\\'
    str_1 = '\'pip-8.0.1-py2.py3-none-any.whl\''
    int_0 = 0
    command_0 = Command(str_0, str_1)
    str_2 = 'pip install ' + str_1
    corrected_command_0 = CorrectedCommand(str_2, None, int_0)
    sub_folder = 'fixers'
    rule_0 = Rule.from_path(path.joinpath(path.joinpath(path.joinpath(path.joinpath(path.joinpath(path.cwd(), 'git'), 'fuck'), 'git'), 'fuck'), sub_folder, 'missing_quote.py'))

# Generated at 2022-06-26 07:16:35.204175
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '/usr/bin/ruby'
    str_1 = '  ruby  '
    command_0 = Command(str_0, str_1)

    rule_0 = Rule('test0_rule', None, None, False, None, 0, False)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['test0_rule'] = rule_0

    # Try to match the rule
    answer_0 = rule_0.is_match(command_0)

    # Verifying if rule matched the command and the dicts are updated
    if not answer_0:
        return
    if (dict_1 != dict_0) or (dict_2 != dict_0):
        return



# Generated at 2022-06-26 07:16:40.494767
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    str_2 = '0F/;Q#{x'
    str_3 = 'IjK"/X9P`8:&,U'
    rule_0 = Rule(str_2, None, None, None, None, 0, True)
    dict_0 = {}


# Generated at 2022-06-26 07:16:52.487828
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)

    def match(cmd):
        return True

    def get_new_command(cmd):
        return [cmd.script + '_fixed']

    rule_0 = Rule(None, match, get_new_command, False, None, 1, False)
    new_commands = list(rule_0.get_corrected_commands(command_0))
    logs.debug(u'new_commands={}'.format(new_commands))

    assert new_commands == [
        CorrectedCommand('5uN`vG|TO,_fixed', None, 2),
    ]



# Generated at 2022-06-26 07:17:27.187974
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = ['foo', 'bar']
    str_0 = 'yG6Py@hNf\rk"?8J'
    str_1 = '~o4+;5JQk:=@[%<1\'"`+=S)8W'
    var_1 = Command(str_0, str_1)
    str_3 = 'O<pG~W`{8OSv?I/;J'
    int_0 = 2
    str_4 = 'Y}N\rgS+'
    var_2 = Rule('foo', var_0, str_3, int_0, str_4, int_0, int_0)
    var_3 = var_2.get_corrected_commands(var_1)
    test_case_0()


# Generated at 2022-06-26 07:17:34.387181
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """
    CorrectedCommandList
    """
    dict_0 = {}
    str_0 = 'zV~#w|ZW|-q3'
    command_0 = Command(str_0, None)
    rule_0 = Rule(None, None, None, None, None, None, None)
    correct_cmd_list_0 = rule_0.get_corrected_commands(command_0)
    #
    assert list(correct_cmd_list_0)[0] == CorrectedCommand(None, None, 1)



# Generated at 2022-06-26 07:17:35.596875
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_0()



# Generated at 2022-06-26 07:17:41.648621
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'qKj'
    str_1 = '8Q1]b'
    command_1 = Command(str_0, str_1)
    rule_0 = Rule(str_0, method_0, method_1, True, method_2, -902, True)
    bool_1 = rule_0.is_match(command_1)
    assert bool_1 == True


# Generated at 2022-06-26 07:17:47.938742
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '/etc/'
    str_1 = 'lib32'
    str_2 = 'rn'
    str_3 = '/usr/bin/nginx'
    pos_0 = str_3.find(str_2)
    str_4 = '/usr/bin/nginx'
    str_5 = '1'
    str_6 = '2'
    str_7 = '3'
    str_8 = '4'
    str_9 = '5'
    str_10 = '6'
    str_11 = '7'
    str_12 = '8'
    str_13 = '9'
    str_14 = '0'
    str_15 = 'q'
    str_16 = 'w'
    str_17 = 'e'
    str_18 = 'r'


# Generated at 2022-06-26 07:17:58.610642
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    def side_effect_0(arg_0, arg_1):
        sys.stdout.write(arg_1)

    def match_0(arg_0):
        return True

    def get_new_command_0(arg_0):
        return 'new_command'

    rule_0 = Rule('<module>', match_0, get_new_command_0, True, side_effect_0, 2, True)
    str_0 = 'I2a{E^L-9Ym'
    str_1 = 'Bt'
    command_0 = Command(str_0, str_1)
    str_2 = 'new_command'
    str_3 = 'corrected_command'
    str_4 = 'new_command'

# Generated at 2022-06-26 07:17:59.658268
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
	test_case_0()


# Generated at 2022-06-26 07:18:05.756415
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test
    rule_0 = Rule('', '', '', False, None, 0, False)
    dict_2 = {}
    dict_3 = {}
    command_0 = Command('', '')
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    # Assert
    assert corrected_commands_0 == (CorrectedCommand('', None, 1),)

# Generated at 2022-06-26 07:18:13.160237
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    num_0 = 0
    corrected_command_0 = CorrectedCommand(str_0, None, num_0)
    # TypeError: __init__() takes exactly 4 arguments (3 given)
    corrected_command_0 = CorrectedCommand(str_0, None, num_0, None)


# Generated at 2022-06-26 07:18:20.292861
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    file_0 = '/'
    rule_0 = Rule.from_path(file_0)
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    rule_0.get_corrected_commands(command_0)


if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:18:59.421655
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {'A': 0.0, 'B': 1.0, 'C': 2.0}
    str_0 = 'j'
    str_1 = 'G'
    str_2 = '{}'.format(str_1)
    str_3 = 'QVu'
    str_4 = '{}/{}'.format(str_3, str_0)
    command_0 = Command(str_4, str_2)
    str_5 = 'a'
    str_6 = '{}/{}'.format(str_5, str_5)
    command_1 = Command(str_6, str_2)
    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0, 0, False)
    str_

# Generated at 2022-06-26 07:19:09.467390
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '_'
    str_1 = '~'
    str_2 = 'Q'
    str_3 = ':'
    str_4 = 'N'
    str_5 = 'x'
    str_6 = 'Y'
    str_7 = 'j'
    str_8 = 'j'
    str_9 = 's'
    str_10 = 'F'
    str_11 = 'F'
    str_12 = 'A'
    str_13 = '['
    str_14 = 'B'
    str_15 = 'W'
    str_16 = 'D'
    str_17 = 'l'
    str_18 = 'J'
    str_19 = 'm'
    str_20 = 'v'
    str_21 = 'G'
    str_

# Generated at 2022-06-26 07:19:20.770134
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    dict_1 = {}
    dict_1['compare'] = '5uN`vG|TO,'
    dict_1['get_new_command'] = 't105|hhs$ITD;2D'
    dict_1['enabled_by_default'] = False
    dict_1['side_effect'] = None
    dict_1['priority'] = 2
    dict_1['requires_output'] = True

# Generated at 2022-06-26 07:19:27.531580
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '3T_2s:s4{XR+'
    str_1 = 'n'
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_0, '6U\x7f-d\x03z8b0^5', 'V;m92CJ', True,
                  None, 3, True)
    corrected_command_0 = rule_0.get_corrected_commands(command_0)
    assert len(corrected_command_0) == 1


# Generated at 2022-06-26 07:19:34.474592
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'e4#4H1W;X+p0!1<3q'
    Command_0 = Command(str_0, str_0)
    str_1 = 'f{M_C'
    Rule_0 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 1, True)
    rule_array_0 = [Rule_0]
    str_2 = 'Bjx;'
    Rule_1 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 1, True)
    rule_array_1 = [Rule_1, Rule_0]
    rule_array_2 = [Rule_0, Rule_0]
    ret_val_0 = Rule_0.get_correct

# Generated at 2022-06-26 07:19:40.971587
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    t0 = (Command('cd /tmp', None), 0)
    t1 = (Command('cd /tmp', 'fatal: Not a git repository'), 0)
    t2 = (Command('echo $PATH', None), 0)
    t3 = (Command('git commit', None), 0)
    t4 = (Command('git commit', 'On branch master'), 0)
    t5 = (Command('git commit', 'nothing to commit, working directory clean'), 0)
    t6 = (Command('git status', 'fatal: Not a git repository'), 0)
    t7 = (Command('git status', 'nothing to commit (working directory clean)'), 0)
    t8 = (Command('ls', 'ls: cannot access /tmp/foobar: No such file or directory'), 0)

# Generated at 2022-06-26 07:19:51.669674
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '0z9ZCS\b[{'
    str_1 = 'k0"M<,I *V7D$l;W'
    command_0 = Command(str_0, str_1)

    rule_0 = Rule(name='test_rule_0',
                  match=test_case_0,
                  get_new_command=test_case_0,
                  enabled_by_default=True,
                  side_effect=test_case_0,
                  priority=1,
                  requires_output=True)
    CorrectedCommand_0 = CorrectedCommand(script='replace_me',
                                          side_effect=None,
                                          priority=1)

# Generated at 2022-06-26 07:20:01.302442
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '5uN`vG|TO,'
    str_1 = 't105|hhs$ITD;2D'
    command_0 = Command(str_0, str_1)
    def func_0_get_new_command(command):
        return command.script
    rule_0 = Rule('rule_0', func_0_get_new_command, func_0_get_new_command, True, func_0_get_new_command, 1, True)
    list_0 = list(rule_0.get_corrected_commands(command_0))
    if len(list_0) == 1:
        print('1 OK')
    else:
        print('1 FAIL\n%s' % list_0)


# Generated at 2022-06-26 07:20:12.823158
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'Ey'
    str_1 = '2'
    str_2 = 'lLH$'
    str_3 = '$I:ZN'
    str_4 = 'd'
    str_5 = 'sx/A'
    str_6 = 'e'
    str_7 = 'z'
    str_8 = 'y'
    str_9 = ' '
    str_10 = 'p'
    str_11 = ','
    str_12 = 'Kxv@;'
    str_13 = 'V}Jh'
    str_14 = '_!H8j'
    str_15 = 'pT'
    str_16 = 'k'
    str_17 = 'g'
    str_18 = 'G?b'

# Generated at 2022-06-26 07:20:23.235063
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule(name='', match=None, get_new_command=None, enabled_by_default=False, side_effect=None, priority=1, requires_output=False)
    rule_1 = Rule(name='', match=None, get_new_command=None, enabled_by_default=False, side_effect=None, priority=1, requires_output=False)
    int_0 = 0
    bool_0 = rule_1.is_match(command_0)
    str_1 = 'tI105|hhs$ITD;2D'
    command_1 = Command(str_0, str_1)
    bool_1 = rule_1.is_match(command_1)
    bool_2 = rule_0.is_match(command_0)
    bool_3 = rule_0