

# Generated at 2022-06-26 07:11:03.231790
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case = 'C'
    if test_case == 'A':
        priority_0 = -89379
        side_effect_0 = None
        script_0 = 'untitled_case'
        corrected_command_0 = CorrectedCommand(script_0, side_effect_0, priority_0)
    elif test_case == 'B':
        priority_1 = -83452
        side_effect_1 = None
        script_1 = 'untitled_case'
        corrected_command_1 = CorrectedCommand(script_1, side_effect_1, priority_1)
    elif test_case == 'C':
        priority_2 = -87839
        side_effect_2 = None
        script_2 = 'untitled_case'

# Generated at 2022-06-26 07:11:10.704727
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule(str_0, command_0.match, command_0.get_new_command, command_0.enabled_by_default, command_0.side_effect, command_0.priority, command_0.requires_output)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:11:15.937458
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '$\x14'
    command_0 = Command(str_0, '-')
    rule_0 = Rule(str_0, 'rule_match_0', 'rule_get_new_command', 'rule_enabled_by_default', 'rule_side_effect', 'rule_priority', 'rule_requires_output')
    rule_0.get_corrected_commands(command_0)



# Generated at 2022-06-26 07:11:22.285531
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'K^wS\x14\x1a\x00\x0fj'
    str_1 = '\x0c\x0e\x15\x14\x0e\x0f\x1e\x1d\x0c\x15\x1a'
    str_2 = 'H\x1b\x1f\x0e\x1d\x04\x1e\x1a\n\x01\x1e'
    side_effect_0 = Rule.from_path(str_0).side_effect
    priority_0 = Rule.from_path(str_1).priority
    command_0 = Command(str_2, str_1)

# Generated at 2022-06-26 07:11:31.161574
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    name_0 = 'h\x1d5\x1a\x19\x1e\x0e'
    match_0 = 'x?{P\x1b\x1f#'
    get_new_command_0 = '\rzr\t'
    enabled_by_default_0 = False
    side_effect_0 = '@ \t\nC"\x11\x0f\x11\x1f'
    priority_0 = 0
    requires_output_0 = True
    rule_0 = Rule(name_0, match_0, get_new_command_0, enabled_by_default_0,
                  side_effect_0, priority_0, requires_output_0)
    name_1 = 'J l\x0cX'

# Generated at 2022-06-26 07:11:37.623874
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    int_0 = 0
    str_0 = 'v>g&h[7<u#'
    corrected_command_0 = CorrectedCommand(str_0, None, int_0)
    corrected_command_1 = CorrectedCommand(str_0, None, int_0)
    bool_0 = corrected_command_1 == corrected_command_0
    assert bool_0 == True



# Generated at 2022-06-26 07:11:43.835704
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule_0 = Rule(command_0, command_0, command_0, command_0, command_0, command_0, command_0)
    rule_1 = Rule(command_0, command_0, command_0, command_0, command_0, command_0, command_0)
    rule_2 = Rule(command_0, command_0, command_0, command_0, command_0, command_0, command_0)
    assert(rule_0 == rule_1)
    assert(rule_0 == rule_2)
    assert(rule_1 == rule_2)

# Generated at 2022-06-26 07:11:52.958210
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    float_0 = -8.2531056E7
    float_1 = -1.837428E-12
    str_0 = '^+b}m'
    str_1 = '1&oyC'
    command_0 = Command(float_0, float_1)
    command_1 = Command(str_0, float_1)
    command_2 = Command(str_0, float_1)
    assert not (command_0 == command_1)
    assert not (command_0 == command_2)
    assert command_1 == command_2



# Generated at 2022-06-26 07:12:04.418125
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_2 = -75.04
    str_2 = 'L-=F E_?5/D`#=t\x0c'
    command_2 = Command(float_2, str_2)
    float_1 = -75.04
    str_1 = 'L-=F E_?5/D`#=t\x0c'
    command_1 = Command(float_1, str_1)
    float_0 = -75.04
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    rule_1 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 2, True)
    result_1 = rule_

# Generated at 2022-06-26 07:12:10.927831
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    correctedCommand_0 = CorrectedCommand(float_0, str_0)
    float_1 = -4074.64
    str_1 = 'L-=F E_?5/D`#=t\x0c'
    correctedCommand_1 = CorrectedCommand(float_1, str_1)


# Generated at 2022-06-26 07:12:35.493384
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'K\\>XQ0\\u'
    rule_0 = Rule(str_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0)
    command_0 = Command(str_0, str_0)
    str_1 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:12:36.930072
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # TODO: implement this
    pass



# Generated at 2022-06-26 07:12:43.859264
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = '/jT\x1f\x11xc|Z+]\x1e\x00\x13\n\x0cQ\x1fq,\x1b\x05\x0c\x1fI'
    rule_0 = Rule.from_path(path_0)
    command_0 = Command()
    corrected_command_0 = CorrectedCommand()
    corrected_commands = rule_0.get_corrected_commands(command_0)
    assert corrected_commands == [corrected_command_0]
    # assert rule_0.get_corrected_commands(command_0) == [corrected_command_0]
    # assert rule_0.get_corrected_commands(command_0) == [corrected_command_0]
    # assert rule_

# Generated at 2022-06-26 07:12:53.680329
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '`\x7f@\x16\x01S\x1f!\x0c'
    method_0 = Command.from_raw_script
    command_0 = method_0(str_0)
    class_0 = Rule
    file_0 = pathlib.Path('/home/hell/.config/thefuck/rules/git_push.py')
    rule_0 = class_0.from_path(file_0)
    result = rule_0.get_corrected_commands(command_0)
    assert result == None, 'Expected None, but got: ' + repr(result)


# Generated at 2022-06-26 07:13:02.611850
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import unittest
    from .vendor.mock import patch
    from .exceptions import NoRuleMatched
    from .rules import match_nothing
    from .shells import split_command, from_shell

    rule_0 = Rule(name='name_0', match=match_nothing, get_new_command=split_command,
                  enabled_by_default=False, side_effect=None,
                  priority=False, requires_output=False)
    command_0 = Command.from_raw_script(('foo --bar=val',))
    with patch('freckles.rules.match_nothing', return_value=True):
        unittest.TestCase().assertTrue(rule_0.is_match(command_0))


# Generated at 2022-06-26 07:13:09.096974
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('', '', '', False, '', 0, True)
    with logs.debug_time(u'Trying rule: {}'.format('', )):
        assert not rule_0.match(command_0)


# Generated at 2022-06-26 07:13:16.262253
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)

    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0,
                  -16951, False)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:13:21.856573
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    str_1 = '8N_\x00-aTqT+O/'
    rule_0 = Rule(str_1, command_0.output, float_0, test_case_0, float_0, float_0)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:13:28.034779
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command(1, '1')
    rule_0 = Rule(1, 1, 1, True, 1, 1, True)
    CorrectedCommand_0 = CorrectedCommand(1, 1, 1)
    rule_0.get_corrected_commands(command_0)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:13:37.652519
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    CorrectedCommand_0 = CorrectedCommand('C@CEA2A9>H`\tFKD', None, None)
    CorrectedCommand_1 = CorrectedCommand('7VJF[T9X*V28J@8', None, None)
    CorrectedCommand_2 = CorrectedCommand('-', None, None)
    tuple_0 = CorrectedCommand_0, CorrectedCommand_1, CorrectedCommand_2
    tuple_1 = CorrectedCommand_0, CorrectedCommand_1, CorrectedCommand_2

# Generated at 2022-06-26 07:13:55.010028
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Arrange
    priority_0 = 0
    side_effect_0 = None
    str_0 = 'SjKi5'
    get_new_command_0 = None # TODO
    enabled_by_default_0 = None
    match_0 = None # TODO
    str_1 = '@oBu'
    rule_0 = Rule(str_1, match_0, get_new_command_0, enabled_by_default_0, side_effect_0, priority_0, False)
    float_0 = -2.6265805
    str_2 = 'GJ+jW`r\r^Zm-AwJ#'
    command_0 = Command(float_0, str_2)
    # Act
    result = rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:13:58.884368
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command_0 = Command('test', None)
    rule_0 = Rule.from_path(pathlib.Path('/home/piotrek/code/python/fuck-the-configuration/thefuck/rules/cd_parent.py'))
    assert rule_0.is_match(command_0)


# Generated at 2022-06-26 07:14:02.427842
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule(str_0, float_0, float_0, float_0, float_0, float_0, float_0)
    CorrectedCommand(str_0, float_0, float_0)


# Generated at 2022-06-26 07:14:07.688811
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    corrected_command_0 = CorrectedCommand(float_0, None, 1)
    corrected_command_0.run(command_0)

test_case_0()

# Generated at 2022-06-26 07:14:14.032587
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    str_1 = 'fD<}gs3b|^1rU)oi"\x0c'
    correctedcommand_0 = CorrectedCommand(float_0, test_case_0, str_1)
    correctedcommand_0.run(command_0)
    correctedcommand_0.run(command_0)

# Generated at 2022-06-26 07:14:17.580509
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    assert(Rule.is_match(Rule, Command)) == True
    assert(Rule.is_match(Rule, Command)) == True
    assert(Rule.is_match(Rule, Command)) == True
    assert(Rule.is_match(Rule, Command)) == True


# Generated at 2022-06-26 07:14:28.585486
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    lst_0_Tuple_0 = (1581,)
    lst_0_Tuple_1 = (3842.25502495,)
    lst_0_Tuple_2 = (6115.72,)
    lst_0_Tuple_3 = (9272.85931835,)
    lst_0_Tuple_4 = (6778.2,)
    lst_0_Tuple_5 = (2895.59614912,)
    lst_0_Tuple_6 = (7462.31305218,)
    lst_0_Tuple_7 = (5376.67751784,)
    lst_0_Tuple_8 = (8778.57283607,)
    lst_0_Tuple_9 = (4744.71642663,)
   

# Generated at 2022-06-26 07:14:34.217029
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)

    # Execution starts here:
    # Rule.is_match(command_0)
    # AssertionError: exception not thrown

    return


# Generated at 2022-06-26 07:14:40.181418
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '{w6U`T6(2;m1q.+n{'
    float_0 = 0.535399457346
    command_0 = Command(str_0, float_0)
    str_1 = 'WYH}'
    bool_0 = True
    bool_1 = True
    rule_instance_0 = Rule(str_1, bool_0, bool_1, float_0, float_0, float_0, float_0)
    rule_instance_1 = rule_instance_0.get_corrected_commands(command_0)



# Generated at 2022-06-26 07:14:49.597332
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -352.87
    str_0 = '2;P#U~f.n|\x07'
    command_0 = Command(float_0, str_0)
    str_1 = 'No fixing method for rule {}'
    rule_0 = Rule(str_0, str_0, str_0, bool(1), None, int(1), bool(1))
    rule_0.get_new_command = (lambda command: logs.error(str_1.format(rule_0.name)))
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:03.939146
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    match_0 = False
    match_1 = True
    match_2 = True
    match_3 = False
    match_4 = False
    match_5 = True
    rule_0 = Rule('', match_0, False, False, False, False)
    rule_1 = Rule('', match_1, True, True, False, False)
    rule_2 = Rule('', match_2, True, True, True, True)
    rule_3 = Rule('', match_3, False, True, True, True)
    rule_4 = Rule('', match_4, False, False, False, True)
    rule_5 = Rule('', match_5, True, True, False, True)
    command_0 = Command(0, 0)
    result_0 = rule_0.is_match(command_0)
   

# Generated at 2022-06-26 07:15:14.893104
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 4127.24
    str_0 = ' j?5I\x0c\r\r\rV\x0c@\rF\x0cL-=F E_?5/D`#=t\x0cP\\R\x15\t'
    command_0 = Command(float_0, str_0)
    rules_path = pathlib.Path(u'E:/fuck-example/rules-text.txt')
    rule_0 = Rule.from_path(rules_path)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    for i in range(10):
        list_0 = []
        for __ in corrected_commands_0:
            list_0.append(__)

# Generated at 2022-06-26 07:15:19.992665
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -23.7517
    str_0 = ':KeklI"Cp'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('', '', '', False, '', 0, False)
    corrected_command_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:26.207414
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -3049.2384
    str_0 = '--debug'
    side_effect_0 = shell.put_to_history
    priority_0 = 1
    corrected_command_0 = CorrectedCommand(float_0, side_effect_0, priority_0)
    corrected_commands_0 = frozenset([corrected_command_0])
    corrected_commands_1 = Rule.get_corrected_commands(corrected_command_0)
    assert not corrected_commands_1.isdisjoint(corrected_commands_0)


# Generated at 2022-06-26 07:15:31.519227
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = ';<K.R%2'
    int_0 = 0
    int_1 = 0
    rule_0 = Rule(str_0, None, None, True, None, int_0, True)
    command_0 = Command(str_0, int_1)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:42.247009
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    tuple_0 = (-67.80, -59.16, -72.49, -31.14, -60.44, -30.90, 41.22, 40.40, 40.29, 40.88)
    some_dict = command_0.update(script=tuple_0)
    CorrectedCommand(tuple_0, None, -65.56, -77.18, -77.58, -85.80, -66.35, -58.75, -70.02, -85.15, None, -83.20, -47.66, -67.90, -52.39, -72.49, -31.14, -70.05, -56.07, -66.81, -85.34, -83.51, 1)
    False

# Generated at 2022-06-26 07:15:49.413798
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    print('Test get_corrected_commands')

    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    print(command_0)
    print(command_0.script)
    rule = Rule('text', 'text', 'text', 'text', 'text', 'text', 'text')
    print(rule)
    print(rule.name)
    print(rule.match)
    print(rule.get_new_command)
    print(rule.enabled_by_default)
    print(rule.side_effect)
    print(rule.priority)
    print(rule.requires_output)

# Generated at 2022-06-26 07:15:53.930230
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    correctedcommand_0 = CorrectedCommand(str_0, None, -4074.64)
    correctedcommand_0.run(command_0)



# Generated at 2022-06-26 07:16:05.313287
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    bool_0 = bool(0)
    int_0 = settings.priority.get(bool_0, DEFAULT_PRIORITY)
    float_0 = -4074.64
    side_effect_0 = None
    rule_0 = Rule(str_0, int_0, float_0, bool_0, side_effect_0, int_0, bool_0)
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    int_0 = 2
    corrected_command_0 = CorrectedCommand(float_0, side_effect_0, int_0)
    list_0 = [corrected_command_0]

# Generated at 2022-06-26 07:16:17.754508
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import math
    import os
    import re
    from . import shell

    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    list_0 = [command_0]
    float_1 = -4074.64
    str_1 = 'L-=F E_?5/D`#=t\x0c'
    command_1 = Command(float_1, str_1)
    str_2 = 'fuck'
    str_3 = 'fuck'
    str_4 = 'fuck'
    str_5 = 'fuck'
    str_6 = 'fuck'
    str_7 = 'fuck'
    str_8 = 'fuck'
   

# Generated at 2022-06-26 07:16:40.330417
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 'I@Sx\x0crY'
    str_0 = 'd!H\x0c'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('fuck', None, None, False, None, None, True)
    rule_1 = Rule('fuck', None, None, True, None, None, False)
    correctedCommand_0 = CorrectedCommand('fuck', None, None)
    correctedCommand_1 = CorrectedCommand('fuck', None, None)
    correctedCommand_2 = CorrectedCommand('fuck', None, None)
    correctedCommand_3 = CorrectedCommand('fuck', None, None)
    correctedCommand_4 = CorrectedCommand('fuck', None, None)
    correctedCommand_5 = CorrectedCommand('fuck', None, None)
    correctedCommand_6

# Generated at 2022-06-26 07:16:52.279226
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    str_1 = '?O+N\n(\t=G\t'
    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0, 88, True)
    str_2 = 'C:\\Documents and Settings\\Administrator\\Application Data\\Mozilla\\Firefox\\Profiles\\sxn01g75.default\\prefs.js'
    command_1 = Command(str_2, str_1)


# Generated at 2022-06-26 07:16:55.225026
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert True # TODO: implement your test here


DEFAULT_RULES_DIR = pathlib.Path(__file__).parent / 'rules'
DEFAULT_CUSTOM_RULES_DIR = pathlib.Path('~/.config/fuck/rules').expanduser()



# Generated at 2022-06-26 07:17:01.854990
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = -1924.58
    str_0 = 'dX.x]\x1b|\nM7h'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0, 0, True)
    assert rule_0.is_match(command_0) == True



# Generated at 2022-06-26 07:17:13.234712
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 2
    str_0 = 'fixme'
    str_1 = 'I4y@\x03tT8W'
    str_2 = 'I4y@\x03tT8W'
    str_3 = 'fixme'
    bool_0 = False
    bool_1 = False
    int_1 = -1
    function_0 = Rule.match
    function_1 = Rule.get_new_command
    rule_0 = Rule(str_0, function_0, function_1, bool_0, str_1, int_0, bool_1)
    int_2 = 2
    str_4 = 'fixme'
    str_5 = 'fixme'
    str_6 = 'I4y@\x03tT8W'

# Generated at 2022-06-26 07:17:17.165972
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    arg0 = Rule('test', bool, bool, bool, bool, bool, int)
    arg1 = Command('test', 'test')
    res0 = arg0.get_corrected_commands(arg1)
    assert res0 is not None


# Generated at 2022-06-26 07:17:21.791528
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule(None, None, None, None, None, None, None)
    CorrectedCommand.get_corrected_commands(rule_0, command_0)


# Generated at 2022-06-26 07:17:22.708399
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_0()


# Generated at 2022-06-26 07:17:28.306369
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    str_1 = 'A$6%<2\n\x15I^#j;Pz'
    corrected_commands = CorrectedCommand(str_1, None, 7834)
    rule_0 = Rule('rule_0', None, None, False, None, None, False)
    corrected_commands = rule_0.get_corrected_commands(command_0)
    assert corrected_commands is not None


# Generated at 2022-06-26 07:17:30.946007
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_1 = 'dI+y8Pk/-!@^o&wv<p'
    command_1 = Command(False, str_1)


# Generated at 2022-06-26 07:18:09.123591
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule(float_0, str_0, boolean_0, boolean_0, str_0, int_0, boolean_0)
    new_commands = int_0
    corrected_command_0 = CorrectedCommand(str_0, str_0, int_0)
    corrected_command_0.__hash__()
    corrected_command_0.__repr__()
    corrected_command_0.__eq__(corrected_command_0)
    corrected_command_0.run(command_0)
    return (rule_0.get_corrected_commands(command_0))


# Generated at 2022-06-26 07:18:19.590746
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    CorrectedCommand(script='', side_effect=0, priority=0)
    PriorityQueue()
    int_0 = OrderedDict()
    float_1 = Rule(name='', match=0, get_new_command=0, enabled_by_default=True, side_effect=0, priority=0, requires_output=True)
    float_1.get_corrected_commands(command_0)
    # NOTE: a lot of other tests that should be written


# Generated at 2022-06-26 07:18:25.617948
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    bool_0 = False
    str_0 = '^\x03'
    command_0 = Command(bool_0, str_0)

    str_1 = 'RuleNotMatchedError'
    try:
        logs.rule_not_matched(command_0, str_1, command_0)
    except:
        pass


# Generated at 2022-06-26 07:18:37.287843
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    print('in test_Rule_get_corrected_commands')


# Generated at 2022-06-26 07:18:39.077645
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:18:47.515881
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    name_0 = 'gY7`u:%'
    match_0 = lambda command: command.script == '/bin/false'
    get_new_command_0 = lambda command: command.script
    enabled_by_default_0 = True
    side_effect_0 = lambda command, new_command: print (command.output)
    priority_0 = -2.716
    requires_output_0 = True
    rule_0 = Rule(name_0, match_0, get_new_command_0,
                  enabled_by_default_0, side_effect_0,
                  priority_0, requires_output_0)
    script_0 = '/bin/false'
    output_0 = 'F]p%{zV7h@[\x0fR8-yW>r'

# Generated at 2022-06-26 07:18:54.845988
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path_0 = pathlib.Path('path.py')
    rule_0 = Rule.from_path(path_0)
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    bool_0 = rule_0.is_match(command_0)
    assert isinstance(bool_0, bool)
    assert bool_0


# Generated at 2022-06-26 07:19:05.433154
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script_0 = 'M<\x0f\x1a_2zZv\x0e!1\x19'
    side_effect_0 = lambda command, script: None
    priority_0 = -14.867645068285635
    corrected_command_0 = CorrectedCommand(script_0, side_effect_0, priority_0)
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule(None, None, None, None, None, None, None)
    generator_0 = rule_0.get_corrected_commands(command_0)
    expection_0 = False

# Generated at 2022-06-26 07:19:16.124627
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    str_1 = 'test_fixtures/rules/module_0.py'
    rule_0 = Rule.from_path(str_1)
    bool_0 = rule_0.is_match(command_0)
    log_0 = getattr(logs, "debug")
    list_0 = [float_0, command_0.output]
    log_0(list_0)
    str_2 = 'test_fixtures/rules/module_0.py'
    rule_1 = Rule.from_path(str_2)

# Generated at 2022-06-26 07:19:26.999024
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    int_0 = 2058
    str_1 = 'T@RyK?YF\x0c_C'
    rule_0 = Rule(int_0, str_1, str_0, str_0, str_1, int_0, int_0)
    rule_1 = Rule(int_0, str_0, str_0, str_0, str_1, int_0, int_0)
    str_2 = 'T@RyK?YF\x0c_C'

# Generated at 2022-06-26 07:20:42.475226
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    float_1 = -1023.838
    float_2 = -1448.893
    float_3 = -220.13
    float_4 = -0.846117
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    str_1 = '\x89\x10\xe4\xda\xe0\xebl\xbd\xbd\xae\x12"\x9d\xf9\x86\x1a\x86\xf8\xfe\xd9\xac#\x7f\x8a\xe7\x04'

# Generated at 2022-06-26 07:20:49.286927
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -4074.64
    str_0 = 'L-=F E_?5/D`#=t\x0c'
    command_0 = Command(float_0, str_0)
    priority_0 = 5570.087277513024
    correctedcommand_0 = CorrectedCommand(command_0.script, command_0.output, priority_0)