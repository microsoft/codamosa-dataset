

# Generated at 2022-06-26 07:11:10.269997
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    path_0 = pathlib.Path('localrules/example.py')
    rule_0 = Rule.from_path(path_0)

    path_1 = pathlib.Path('localrules/example.py')
    rule_1 = Rule.from_path(path_1)

    var_0 = rule_0.__eq__(rule_1)


# Generated at 2022-06-26 07:11:14.278042
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_0 = 'if [ $? -eq 0 ]'
    float_0 = -1906.1483
    command_0 = Command(str_0, float_0)
    dict_0 = dict()
    dict_0[str_0] = [str_0, float_0]
    var_0 = Rule(str_0, command_0, dict_0, True, dict_0, 0, True)
    dict_0[str_0] = [float_0, str_0]
    var_1 = Rule(float_0, command_0, dict_0, False, dict_0, 0, True)
    var_2 = var_0.__eq__(var_1)
    assert not var_2
    var_3 = var_0.__eq__(var_0)
    assert var_

# Generated at 2022-06-26 07:11:20.324266
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '`8A'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_1 = Command(str_1, float_1)
    corrected_command_0 = CorrectedCommand(command_0, corrected_command_0.run, corrected_command_0.priority)
    corrected_command_0.run(command_1)

if __name__ == '__main__':
    test_case_0()
    test_CorrectedCommand_run()

# Generated at 2022-06-26 07:11:27.953432
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Arguments
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = 'cd'
    str_2 = 'cd'
    rule_0 = Rule(str_1, str_2, str_1, False, str_0, -40.9, True)
    # Function call
    str_3 = rule_0.get_corrected_commands(command_0)
    var_0 = str_3


# Generated at 2022-06-26 07:11:32.477369
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = float('-0.0')
    float_1 = float('inf')
    float_2 = float('inf')
    str_0 = '$'
    str_1 = 'abc'
    str_2 = '@'
    str_3 = 'a'
    command_0 = Command(str_3, float_2)
    str_4 = '?q{'
    str_5 = '}'
    str_6 = str_4 + str_5
    str_7 = 'a'
    list_0 = []
    list_0.append(str_7)
    list_0.append(str_6)
    var_0 = shell.split_command(str_6)
    command_1 = Command(str_6, float_1)

# Generated at 2022-06-26 07:11:36.363985
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'asdf'
    str_1 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_1, float_0)
    rule_0 = Rule(str_0, None, None, None, None, None, None)

    corrected_commands_0 = rule_0.get_corrected_commands(command_0)

    for corrected_command_0 in corrected_commands_0:
        corrected_command_0.script
        corrected_command_0.priority
        corrected_command_0.__repr__()


# Generated at 2022-06-26 07:11:42.786543
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^echo "hello"'
    float_0 = -0.002090388887903442
    command_0 = Command(str_0, float_0)
    var_0 = Command(str_0, float_0)
    rule_0 = Rule(str_0, var_0, command_0, var_0, command_0, var_0, var_0)
    var_1 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:11:50.310006
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .rules import alias_cd
    from .exceptions import EmptyCommand
    with logs.debug_time('test_Rule_is_match'):
        try:
            str_0 = '^cd (.*)'
            float_0 = -1050.5449
            command_0 = Command(str_0, float_0)
            rule_0 = alias_cd
            res = rule_0.is_match(command_0)
        except EmptyCommand:
            print('EmptyCommand')
        except Exception:
            print('Exception')


# Generated at 2022-06-26 07:11:57.754187
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # create instance of class Rule
    obj = Rule('', lambda x: True, lambda y: '', True, lambda a, b: None, 1, True)
    # test with Command
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    res = obj.get_corrected_commands(command_0)
    # test with Command
    str_1 = '--debug'
    int_0 = -23
    command_1 = Command(str_1, int_0)
    res_0 = obj.get_corrected_commands(command_1)


# Generated at 2022-06-26 07:12:04.372307
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    path_0 = pathlib.Path('/tmp/f/rules/replace_alias.py')
    var_0 = Rule.from_path(path_0)
    path_1 = pathlib.Path('/tmp/f/rules/replace_alias.py')
    var_1 = Rule.from_path(path_1)
    bool_0 = var_0 == var_1
    print(bool_0)


# Generated at 2022-06-26 07:12:21.387848
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # assert re.findall(r'[0-9a-zA-Z]{3,7}', '12345678')
    # assert re.findall(r'[0-9]{3,7}', '12345678')
    # assert re.findall(r'[0-9a-zA-Z]{3,7}', 'abcdef')
    # assert re.findall(r'[0-9a-zA-Z]{3,7}', 'asxddffg')
    # assert re.findall(r'\s{3,7}', '   ')
    assert re.findall(r'\s{3,7}', '   ')
    assert re.findall(r'\s{3,7}', '       ')
    assert re.find

# Generated at 2022-06-26 07:12:27.707109
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'localrules/example.py'
    pl_0 = pathlib.Path(str_0)
    obj_0 = Rule.from_path(pl_0)
    obj_1 = Command('localrules/example.py', 'localrules/example.py')
    obj_2 = obj_0.get_corrected_commands(obj_1)
    class_0 = obj_2.__class__
    str_1 = 'generator'
    str_2 = class_0.__name__
    int_0 = cmp(str_1, str_2)
    assert int_0 == 0



# Generated at 2022-06-26 07:12:36.892336
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    def test_0():
        str_0 = 'localrules/example.py'
        path_0 = Path(str_0)
        rule_0 = Rule.from_path(path_0)
        cmd_0 = Command.from_raw_script(['echo', '123'])
        assert rule_0.is_match(cmd_0) is True
        commands_0 = rule_0.get_corrected_commands(cmd_0)
        assert isinstance(commands_0, Iterable) is True
        return
    test_0()


# Generated at 2022-06-26 07:12:39.347191
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
  assert (Rule.from_path(Path(__file__)).get_corrected_commands(Command(
      script="test_cmd", output="test_output")) == str([]))

# Generated at 2022-06-26 07:12:42.485773
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
  Rule_instance_0 = Rule.from_path('localrules/example.py')
  Command_instance_0 = Rule.get_new_command(Rule_instance_0, 'localrules/example.py')


# Generated at 2022-06-26 07:12:47.476294
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rules_dir = pathlib.Path(__file__).parent.parent / 'rules'
    rule_paths = sorted(rules_dir.glob("*.py"))
    for path in rule_paths:
        rule = Rule.from_path(path)
        if rule.priority == 0:
            continue
        scripts = rule.get_new_command(Command("echo -n", None))
        for script in scripts:
            corrected_command = CorrectedCommand(script=script, side_effect=None, priority=rule.priority)
            assert corrected_command.priority == rule.priority


# Generated at 2022-06-26 07:12:57.998982
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:12:59.495578
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    print('Test method run of class CorrectedCommand')
    return None



# Generated at 2022-06-26 07:13:01.213079
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    ru = Rule.from_path(pathlib.Path(str_0))
    assert ru is not None


# Generated at 2022-06-26 07:13:13.415142
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule.from_path(pathlib.Path(str_0))
    cmd_0 = Command.from_raw_script(['sl'])
    corr_cmd_0 = CorrectedCommand('ls', None, 100)
    corr_cmd_1 = CorrectedCommand('ls', None, 200)
    corr_cmd_2 = CorrectedCommand('ls', None, 300)
    corr_cmd_3 = CorrectedCommand('ls', None, 400)
    corr_cmd_4 = CorrectedCommand('ls', None, 500)
    corr_cmd_5 = CorrectedCommand('ls', None, 600)
    corr_cmd_6 = CorrectedCommand('ls', None, 700)
    corr_cmd_7 = CorrectedCommand('ls', None, 800)

# Generated at 2022-06-26 07:13:30.960433
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = Rule.from_path(pathlib.Path('localrules/example.py'))
    CorrectedCommand_0 = CorrectedCommand(script='echo "Fixed command"', side_effect=None, priority=1)

    yield CorrectedCommand_0, str_0.get_corrected_commands(Command('echo "broken command"', 'broken command'))


# Generated at 2022-06-26 07:13:34.399131
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'localrules/example.py'
    assert str_0 == 'localrules/example.py'

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 07:13:39.553388
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # WARNING: That is ONLY a test case, do not copy-paste this to your own code
    rule_path = 'localrules/example.py'
    rule_obj = Rule.from_path(rule_path)
    command_str = 'rm -Rf directory'
    command_obj = Command.from_raw_script(shell.split_command(command_str))
    Corrected_command_obj = rule_obj.get_corrected_commands(command_obj).next()
    print(Corrected_command_obj)


# Generated at 2022-06-26 07:13:41.475494
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'localrules/example.py'
    Rule.from_path(str_0)


# Generated at 2022-06-26 07:13:45.003611
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    from .rules import example
    path = pathlib.Path('localrules/example.py')
    rule = Rule.from_path(path)
    command = Command.from_raw_script(['cd'])
    rule.is_match(command)

# Generated at 2022-06-26 07:13:55.961152
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import textwrap
    expected_0 = 'cd /tmp'
    expected_1 = None
    expected_2 = 'cd /tmp'
    expected_3 = 'cd /var/log'
    expected_4 = 'cd /var/log'
    expected_5 = '/tmp'
    expected_6 = 'df'
    expected_7 = 'df -h'
    expected_8 = 'df -h'
    expected_9 = 'df -k'
    expected_10 = 'df -k'
    expected_11 = 'ls -l'
    expected_12 = 'ls -la'
    expected_13 = 'ls -la'
    expected_14 = 'ls -la'
    expected_15 = 'ls -la'
    expected_16 = 'ls -la'
    expected_17 = 'ls'
    expected

# Generated at 2022-06-26 07:14:00.567868
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import pathlib
    path = pathlib.Path(str_0)
    rule = Rule.from_path(path)
    command = Command.from_raw_script(['git', 'add', '--update'])
    assert set(rule.get_corrected_commands(command)) == \
           set([CorrectedCommand(script='git add -u', side_effect=None,
                                 priority=5)])


# Generated at 2022-06-26 07:14:04.429131
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path = pathlib.Path(str_0)
    rule = Rule.from_path(path)
    command = Command(None, None)
    assert rule.is_match(command)


# Generated at 2022-06-26 07:14:06.103157
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'localrules/example.py'
    str_1 = str_0



# Generated at 2022-06-26 07:14:11.652064
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    def fn_1(arg_1):
        return Rule.from_path(arg_1)
    fn_1(str_0).get_corrected_commands('Command(script=\'\', output=\'\')')
    fn_1(str_0).get_corrected_commands('Command(script=\'\', output=\'\')')
    str_2 = 'localrules/example.py'


# Generated at 2022-06-26 07:14:35.061969
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path0 = pathlib.Path(str_0)
    rule0 = Rule.from_path(path0)
    assert rule0.is_match(command) == True


# Generated at 2022-06-26 07:14:41.933122
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'localrules/example.py'
    # prepare data
    path = Path(str_0)
    # exception case: no import
    rule = Rule.from_path(path)
    command = Command('command', 'output')
    res = rule.get_corrected_commands(command)
    # assert
    assert_res = [CorrectedCommand('command', side_effect=None, priority=100000)]
    assert res == assert_res, 'Assertion failed!'
    # exception case: no alias
    rule = Rule.from_path(path)
    command = Command('command', 'output')
    res = rule.get_corrected_commands(command)
    # assert
    assert_res = [CorrectedCommand('command', side_effect=None, priority=100000)]

# Generated at 2022-06-26 07:14:43.520559
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_0()


# Generated at 2022-06-26 07:14:52.135419
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import rules
    import testcase.rules
    reload(rules)
    reload(testcase.rules)

    testcase_0 = testcase.rules.testcase_is_match('test_case_0')
    rule_0 = rules.Rule.from_path(testcase_0.rule_path)# change the rule path
    command_0 = Command.from_raw_script(testcase_0.command_raw_script)
    match = rule_0.match(command_0)

# Generated at 2022-06-26 07:14:53.066218
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    pass


# Generated at 2022-06-26 07:14:59.594503
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = Rule.from_path(str_0)
    str_1 = str(str_0)
    class_0 = Command
    str_2 = 'touch ~/hello.txt'
    str_3 = ''
    str_4 = 'touch ~/hello.txt'
    str_5 = 'touch ~/hello.txt'
    str_6 = 'touch ~/hello.txt'
    int_0 = 10
    int_1 = 1
    int_2 = 1
    int_3 = 5


# Generated at 2022-06-26 07:15:01.381113
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert (Rule.get_corrected_commands(Rule(), Command()) ==
            Rule().get_corrected_commands(Command()))


# Generated at 2022-06-26 07:15:06.139684
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_rule = Rule.from_path(str_0)
    test_command = Command(str_1, str_2)
    test_rule.get_corrected_commands(test_command)


# Generated at 2022-06-26 07:15:10.952083
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    Rule.from_path('localrules/example.py')

# Generated at 2022-06-26 07:15:14.330514
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    try:
        Rule.from_path('localrules/example.py')
    except Exception:
        logs.exception(u"Rule {} failed to load", sys.exc_info())


# Generated at 2022-06-26 07:15:59.791545
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:16:04.530541
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    int_0 = 0
    rule_0 = Rule('', lambda x: False, lambda x: '', True, lambda x, y: None, 0, True)
    dict_var_0 = dict()
    dict_var_0['var_0'] = rule_0.get_corrected_commands
    dict_var_0['var_1'] = rule_0.get_corrected_commands(command_0)
    dict_var_0['var_2'] = rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:16:09.723780
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'a/b'
    var_0 = Rule.from_path(str_0)
    str_1 = 'y/z'
    command_0 = Command(str_0, str_1)
    var_1 = var_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:16:17.214344
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    var_0 = command_0.__repr__()
    rule_0 = Rule(str_0, Hash.match, Rule.get_new_command, True, None, 0, True)
    var_1 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:16:25.384590
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 55
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    str_0 = 'T'
    str_1 = '^cd (.*)'
    str_2 = '^cd (.*)'
    str_3 = '^[fF]uck (.*)'
    command_0 = Command(str_2, float_0)
    def side_effect(old_cmd, new_cmd):
        print(new_cmd)

    rule_0 = Rule(str_0, lambda x: bool(x), lambda x: list(x), bool(0), side_effect, int_0, bool(1))
    rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:16:36.799792
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = -1050.5449
    str_0 = '^cd (.*)'
    command_0 = Command(str_0, float_0)
    str_1 = '''def match(command):
    return False'''
    str_2 = '''def get_new_command(command):
    return 'asdf'

'''
    rule_0 = Rule(str_0, str_1, str_2, True, None, 0, True)
    var_0 = rule_0.is_match(command_0)
    var_0 = rule_0.is_match(command_0)
    var_0 = rule_0.is_match(command_0)
    var_0 = rule_0.is_match(command_0)
    var_0 = rule_0.is_match

# Generated at 2022-06-26 07:16:41.254153
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command('cd .', '.')
    rule_0 = Rule('cd_dot', lambda command: (command.script == 'cd .'), lambda command: ['cd ' + command.output], True, None, 500, False)
    corrected_command_0 = rule_0.get_corrected_commands(command_0).__next__()
    str_0 = corrected_command_0.__repr__()
    print(str_0)


# Generated at 2022-06-26 07:16:52.070010
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_1 = Command(str_1, float_1)
    int_1 = -184
    def side_effect(*arg_1):
        if len(arg_1) > 0:
            float_2 = float(arg_1[0])
            float_2 = float_2 - float_2
        else:
            float_2 = float_2
        float_2 = float_2 + float_2
        return float_2
    rule_1 = Rule('', '', '', True, side_effect, int_1, False)
    rule_1.is_match(command_1)


# Generated at 2022-06-26 07:16:58.187680
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'The quick brown fox jumps over the lazy dog'
    Rule_0 = Rule(str_0, lambda a : True, lambda a : 'The quick brown fox jumps over the lazy dog', False, lambda a : True, 0, True)
    str_1 = 'The quick brown fox jumps over the lazy dog'
    float_0 = -1050.5449
    command_0 = Command(str_1, float_0)
    corrected_command_0 = CorrectedCommand('The quick brown fox jumps over the lazy dog', True, 6)
    lst_0 = [corrected_command_0]
    assert Rule_0.get_corrected_commands(command_0) == lst_0


# Generated at 2022-06-26 07:17:09.704977
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = -128.865
    base_str_0 = 'n$mzm1>|&tnXpf1'
    var_0 = Rule.from_path(base_str_0)
    var_1 = Command(base_str_0, float_0)
    var_2 = var_0.is_match(var_1)
    var_3 = Command(base_str_0, float_0)
    var_4 = var_0.is_match(var_3)
    var_5 = Command(base_str_0, float_0)
    var_6 = var_0.is_match(var_5)
    var_7 = Command(base_str_0, float_0)
    var_8 = var_0.is_match(var_7)
    var

# Generated at 2022-06-26 07:18:02.218648
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    rule_0 = Rule(str_1, str_1, str_1, str_1, str_1, str_1, str_1)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:18:10.284991
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = 'cd (.*)'
    match_0 = re.compile(str_1)
    str_2 = '^cd (.*)'
    def get_new_command_0(arg_0):
        var_0 = arg_0.script
        var_1 = arg_0.output
        return var_0
    bool_0 = True
    int_0 = 6
    bool_1 = True
    rule_0 = Rule(str_2, match_0, get_new_command_0, bool_0, None, int_0, bool_1)

# Generated at 2022-06-26 07:18:17.128162
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    rule_0 = Rule(str_0, command_0.__eq__, command_0.__repr__, str_0, float_0)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:18:23.436963
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    correctedcommand_0 = CorrectedCommand(str_0, command_0.__repr__, float_0)
    correctedcommand_0.run(command_0)
    return

# Generated at 2022-06-26 07:18:24.873731
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert Rule.get_corrected_commands()


# Generated at 2022-06-26 07:18:30.414092
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    rule_0 = Rule(str_1, Rule.from_path, Command.from_raw_script, float_0, float_1, float_1, float_1)
    var_0 = rule_0.is_match(command_0)


# Generated at 2022-06-26 07:18:36.088935
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Use the function and assert that actual == expected
    # assert Rule(name=None, match=None, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None).get_corrected_commands(command=None) == None
    raise NotImplementedError


# Generated at 2022-06-26 07:18:41.117202
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    var_0 = list(Rule(str_0, None, None, True, None, 0, True).get_corrected_commands(command_0))
    assert var_0 == []


# Generated at 2022-06-26 07:18:48.642870
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '/usr/local/bin/fuck'
    float_0 = 0.082280
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_1 = Command(str_1, float_1)
    str_2 = '/usr/local/bin/fuck'
    float_2 = 0.082280
    command_2 = Command(str_2, float_2)
    class_0 = Rule(str_0, command_0, command_1, False, command_2, 10, True)

# Generated at 2022-06-26 07:18:59.431170
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = 'cd (.*)'
    match_0 = Rule.__dict__.get('match')
    get_new_command_0 = Rule.__dict__.get('get_new_command')
    side_effect_0 = Rule.__dict__.get('side_effect')
    rule_0 = Rule(str_1, match_0, get_new_command_0, True, side_effect_0, 100, True)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    for x in corrected_commands_0:
        print(x)


# Generated at 2022-06-26 07:20:00.124640
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    b_0 = -1050.5449
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_1 = Command(str_1, float_1)
    float_1 = command_1.output
    str_2 = '^cd (.*)'
    float_2 = -1050.5449
    command_2 = Command(str_2, float_2)
    str_3 = '^cd (.*)'
    float_3 = -1050.5449
    command_3 = Command(str_3, float_3)
    str_4 = '^cd (.*)'
    float_4

# Generated at 2022-06-26 07:20:06.144266
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():

    # init
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)

    float_1 = -30.647269
    str_1 = '^git (.*)'
    command_1 = Command(str_1, float_1)

    str_2 = '^git push'
    float_2 = -823.3319595
    command_2 = Command(str_2, float_2)

    # test
    str_3 = u'/home/fibonacci/src/pyfuck/tests/fixtures/rules/git.py'
    result = list(Rule.from_path(str_3).get_corrected_commands(command_2))

# Generated at 2022-06-26 07:20:15.779222
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '__'
    float_0 = -64.477
    command_0 = Command(str_0, float_0)
    rule_0 = Rule(str_0, rule_match, rule_get_new_command, True, rule_side_effect, 865, True)
    rule_1 = rule_0.from_path(path_0)
    corrected_commands_0 = rule_1.get_corrected_commands(command_0)
    for corrected_command_0 in corrected_commands_0:
        assert (corrected_command_0 == corrected_command_0)


# Generated at 2022-06-26 07:20:20.134850
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '^cd (.*)'
    float_0 = 992.2
    command_0 = Command(str_0, float_0)
    bool_0 = var_0.is_match(command_0)
    assert bool_0 == false


# Generated at 2022-06-26 07:20:23.648038
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    list_0 = []
    var_0 = Rule.get_corrected_commands(command_0, list_0)


# Generated at 2022-06-26 07:20:29.699810
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    def func_0(arg_0):
        return []
    func_1 = lambda arg_0: []
    int_0 = 0
    bool_0 = True
    rule_0 = Rule(str_1, func_0, func_1, bool_0, None, int_0, bool_0)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:20:41.345125
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '^(.*)'
    float_0 = -348.638
    command_0 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_1 = Command(str_1, float_1)
    str_2 = '^cd (.*)'
    float_2 = -1050.5449
    command_2 = Command(str_2, float_2)
    str_3 = '^cd (.*)'
    float_3 = -1050.5449
    command_3 = Command(str_3, float_3)
    str_4 = '^cd (.*)'
    float_4 = -1050.5449
    command_4 = Command(str_4, float_4)
   

# Generated at 2022-06-26 07:20:48.693326
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '^cd (.*)'
    float_0 = -1050.5449
    command_1 = Command(str_0, float_0)
    str_1 = '^cd (.*)'
    float_1 = -5195.88167
    command_2 = Command(str_1, float_1)
    list_1 = [command_1, command_2]
    var_2 = set(list_1)
    str_2 = '^cd (.*)'
    float_2 = -7822.63392
    command_3 = Command(str_2, float_2)
    bool_0 = command_3.__eq__(command_3)
    str_3 = '^cd (.*)'
    float_3 = -7822.63392

# Generated at 2022-06-26 07:20:52.840750
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = pathlib.Path("/etc", "issue")
    str_0 = path_0.name
    bool_0 = True
    float_0 = 100.0030
    bool_1 = False
    str_1 = '^cd (.*)'
    float_1 = -1050.5449
    command_0 = Command(str_1, float_1)
    int_0 = command_0.priority
    str_2 = 'fuck'
    rule_0 = Rule(str_0, bool_0, get_new_command, bool_1, side_effect, int_0,
                  bool_0)
    rule_0.get_corrected_commands(command_0)
    # Rule did not raise any exception
