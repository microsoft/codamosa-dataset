

# Generated at 2022-06-26 07:11:10.519093
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    match_0 = Rule.is_match
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    # Test case with arguments: (command_0)
    assert False == match_0(command_0)


# Generated at 2022-06-26 07:11:19.068189
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = pathlib.Path('/home/travis/build/nvbn/thefuck')
    int_0 = 54
    function_0 = lambda: None
    int_1 = 10
    int_2 = 1
    rule_0 = Rule(str_0, function_0, function_0, True, function_0, int_0, False)
    str_1 = 'echo "echo" && exit'
    corrected_command_0 = CorrectedCommand(str_1, function_0, int_1)
    list_0 = [corrected_command_0]
    assert list(rule_0.get_corrected_commands(command_0)) == list_0

    function_1 = lambda: 'echo'

# Generated at 2022-06-26 07:11:29.458757
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_1 = 542.0
    str_1 = 'mnE^!=i+o\x0c!qCEY'
    command_1 = Command(float_1, str_1)
    rule_1 = Rule('tZ@wWZ', u'\x0f\xe9"\x0f?\x0c\x06\x0c\x06\x1d\x1f\n', u'ngM@!+yE', True, u'\x0f\xe9"\x0f?\x0c\x06\x0c\x06\x1d\x1f\n', 4, True)
    CorrectedCommand_1 = rule_1.get_corrected_commands(command_1)

# Generated at 2022-06-26 07:11:32.483180
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    try:
        test_case_0()
    except Exception as err:
        logs.exception(err)

# Generated at 2022-06-26 07:11:38.398448
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = 903.8
    str_0 = 'P'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('rule_0', None, None, True, None, 0, False)
    if not rule_0.is_match(command_0):
        raise RuntimeError('Test failed')



# Generated at 2022-06-26 07:11:48.566778
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    float_0 = -0.5257788
    int_1 = 6
    str_0 = 'U-88;U$dvz8W6"u'
    str_1 = 'qD)_V\rBVP}-r;|oT['
    str_2 = '+_'
    rule_0 = Rule(str_1, str_1, str_0, True, int_1, int_1, True)
    rule_1 = Rule(str_0, str_0, str_1, True, int_1, int_1, True)
    rule_2 = Rule(str_0, str_2, str_2, True, int_1, int_1, False)

# Generated at 2022-06-26 07:11:56.296977
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    float_1 = 542.0
    str_1 = 'mnE^!=i+o\x0c!qCEY'
    rule_0 = Rule(float_1, str_1, float_0, float_1, float_1, float_1, float_0)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:12:04.232793
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('name_4', 'match_4', 'get_new_command_4', 'enabled_by_default_4', 'side_effect_4', 'priority_4', 'requires_output_4',)
    bool_0 = rule_0.is_match(command_0)
    assert bool_0


# Generated at 2022-06-26 07:12:09.781485
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule_0 = Rule(str_0, 'B&N#?5C}`W.%8@9#+', bool_0, float_0, float_0, float_0, bool_0)
    rule_1 = Rule('_F&', float_0, bool_0, str_0, bool_0, bool_0, bool_0)
    if isinstance(rule_0, Rule):
        pass
    rule_2 = Rule(str_0, bool_0, bool_0, bool_0, bool_0, str_0, bool_0)


# Generated at 2022-06-26 07:12:19.869344
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 115
    str_0 = 'j\x0bc\x7f^&jKg\x7f^D!fH'
    command_0 = Command(int_0, str_0)
    float_0 = 335.0
    rule_0 = Rule(int_0, test_case_0, test_case_0, False, test_case_0, int_0, False)
    actual_value = list(rule_0.get_corrected_commands(command_0))
    
    #assert len(actual_value) == 1
    assert type(actual_value) == list
    assert type(actual_value[0]) == CorrectedCommand
        



# Generated at 2022-06-26 07:12:33.142795
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # first test case
    test_case_0()
    '''
    print Rule.is_match(
        str_0,
        str_1
    )
    '''


# Generated at 2022-06-26 07:12:43.372943
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    int_0 = int()
    int_1 = int()
    int_2 = int()
    int_3 = int()
    int_4 = int()
    int_5 = int()
    int_6 = int()
    int_7 = int()
    int_8 = int()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()

# Generated at 2022-06-26 07:12:48.042695
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Arrange
    rule = Rule()
    command = Command()
    # Act
    ret = rule.get_corrected_commands(command)
    # Assert
    assert ret == expected_result


# Generated at 2022-06-26 07:12:52.940033
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    try:
        Rule.get_corrected_commands(None)
    except TypeError:
        return True
    else:
        raise Exception('Failed to detect wrong number of args in '
                        'Rule.get_corrected_commands method')

if __name__ == '__main__':
    if test_Rule_get_corrected_commands():
        print('Test passed')

# Generated at 2022-06-26 07:12:59.031480
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    Rule_instance_0 = Rule( str_0 >> str_1,
        object_0.__eq__, object_0.__eq__, str_1 <= str_0, object_0.__eq__, str_1 / str_0, bool_0)
    Rule_instance_1 = Rule( str_0 >> str_1,
        object_0.__eq__, object_0.__eq__, str_1 <= str_0, object_0.__eq__, str_1 / str_0, bool_0)
    Rule_instance_2 = Rule( str_0 >> str_1,
        object_0.__eq__, object_0.__eq__, str_1 <= str_0, object_0.__eq__, str_1 / str_0, bool_0)

# Generated at 2022-06-26 07:13:04.261751
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str = 'B&N#?5C}`W.%8@9#+'
    str2 = '_F&'
    str3 = '_F&'
    if str > str2:
        print('ssssssssss')


# Generated at 2022-06-26 07:13:07.106014
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_1 = '8'
    str_2 = 'B&N#?5C}`W.%8@9#+'
    str_0 = '_F&'


# Generated at 2022-06-26 07:13:17.366914
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Assert: AssertionError: CorrectedCommand(script='$(f() { echo -n "{\"msg\": \"some_v3_var\", \"some_v1_var\": false, \"some_v2_var\": false}"; } && f)', side_effect=None, priority=100) == CorrectedCommand(script=None, side_effect=None, priority=100)
    assert(CorrectedCommand(script='$(f() { echo -n "{\"msg\": \"some_v3_var\", \"some_v1_var\": false, \"some_v2_var\": false}"; } && f)', side_effect=None, priority=100) == CorrectedCommand(script=None, side_effect=None, priority=100))


# Generated at 2022-06-26 07:13:24.529713
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    that, str_0, let, str_1 = (
        get_alias(),  # type: basestring
        '*$!6O\\%A>$P)\\J\\,ZH'[::-1],  # type: basestring
        '.',  # type: basestring
        '{S,*Rm`%c<_9]YUs~'  # type: basestring
    )

# Generated at 2022-06-26 07:13:32.237722
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule = Rule(str_0, str_0, str_0, True, str_0, -1322132754, False)
    cmd = Command(str_0, str_0)
    correct_cmds = list(rule.get_corrected_commands(cmd))
    if len(correct_cmds) != 1:
        logs.exception(u"Incorrect number of corrected commands {} vs {}"
                       .format(len(correct_cmds), 1))


# Generated at 2022-06-26 07:13:51.901352
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_1 = '\n        Command.from_raw_script(self.script_parts).script)\n\n    '
    str_2 = '\n        Command.from_raw_script(self.script_parts).script)\n\n    '
    str_3 = '\n        Rule.get_new_command(self, Command.from_raw_script(self.script_parts).script)\n\n    '
    str_4 = '\n        Command.from_raw_script(self.script_parts).script)\n\n    '
    str_5 = '\n        Rule.get_new_command(self, Command.from_raw_script(self.script_parts).script)\n\n    '

# Generated at 2022-06-26 07:13:55.649827
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    rule_0 = Rule.from_path(str_0)


# Generated at 2022-06-26 07:14:02.709933
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    class_0 = Rule

# Generated at 2022-06-26 07:14:06.525077
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    command = Command('', '')
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    CorrectedCommand(str_0, None, 0).run(command)


# Generated at 2022-06-26 07:14:07.298028
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:14:16.175111
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_1 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_2 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_3 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_4 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '

# Generated at 2022-06-26 07:14:18.603841
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Should be a MethodType
    assert(type(Rule.get_corrected_commands) is MethodType)


# Generated at 2022-06-26 07:14:23.957717
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    var_1 = CorrectedCommand('', '', 0)
    str_0 = '\n    assert Rule(str_0, Rule.match, Rule.get_new_command, True, Rule.side_effect, 0, True) == Rule(str_1, Rule.match, Rule.get_new_command, True, Rule.side_effect, 0, True)\n    '


# Generated at 2022-06-26 07:14:27.022653
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    
    # Call method on an arbitrary object of type Rule
    # with arbitrary objects of type Command as input
    result = Rule.get_corrected_commands(Command)
    assert result is not None


# Generated at 2022-06-26 07:14:30.294705
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    Rule.get_corrected_commands(test_case_0())

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 07:14:39.913064
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    assert Rule.is_match() == 0;


# Generated at 2022-06-26 07:14:51.704106
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # str_3 is an example of a Rule object
    str_1 = 'cd ..'
    str_2 = '.\n            print Rule.is_match(\n                str_0,\n                str_1\n            )\n            '
    str_3 = 'cd ..'
    str_4 = CorrectedCommand(side_effect=test_case_0,script='./.\n            print Rule.is_match(\n                str_0,\n                str_1\n            )\n            ',priority=1)
    str_5 = CorrectedCommand(side_effect=test_case_0,script='cd ..',priority=1)
    str_6 = './.\n            print Rule.is_match(\n                str_0,\n                str_1\n            )\n            '
    str_7

# Generated at 2022-06-26 07:14:58.121594
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    # Creation of rule instance
    Rule_0 = Rule(str_0, match_0, get_new_command_0, enabled_by_default, side_effect_0, priority, DEFAULT_PRIORITY)
    assert bool_0 == bool_1
    assert bool_0 == bool_2


# Generated at 2022-06-26 07:15:03.606813
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command_0 = Command(script='rm /usr/local/bin/fuck', output='rm: /usr/local/bin/fuck: No such file or directory')
    str_0 = 'rm /usr/local/bin/fuck'
    str_1 = 'rm: /usr/local/bin/fuck: No such file or directory'
    result_0 = Rule.is_match(str_0, str_1)
    result_1 = Rule.from_path('rm_file').is_match(command_0)
    print(result_1)


# Generated at 2022-06-26 07:15:12.843135
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    str_1 = '\n    assert Rule(str_2, str_3, str_4, str_5, str_6, str_7, str_8) == Rule(str_9, str_10, str_11, str_12, str_13, str_14, str_15)\n    str_16 = str_17\n    str_18 = str_19\n    str_20 = str_21\n    str_22 = str_23\n    str_24 = str_25\n    str_26 = str_27\n    str_28 = str_29\n    str_30 = str_31\n    '


# Generated at 2022-06-26 07:15:15.817437
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    # str_0 is "Rule(name={}, match={}, get_new_command={}, enabled_by_default={}, side_effect={}, priority={}, requires_output={})"
    str_0 = '\n    print Rule.__eq__(\n        str_0,\n        str_1\n    )\n    '


# Generated at 2022-06-26 07:15:23.934599
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_1 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    CorrectedCommand.run(str_0, str_1)
    # Assert:
    str_2 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    assert str_0 == str_2


# Generated at 2022-06-26 07:15:26.266085
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    # Testing with different arguments
    assert Rule.__eq__(str_0, str_1)

    assert Rule.__eq__(str_1, str_0)


# Generated at 2022-06-26 07:15:28.327972
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    print(Rule.from_path('get_new_command'))


# Generated at 2022-06-26 07:15:32.760882
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    if not True:
        print('Warning: no test for Rule.is_match')
    else:
        Rule_0 = Rule
        Command_0 = Command
        unicode_0 = str_0 = str
        bool_0 = Rule_0.is_match(Command_0.from_raw_script([unicode_0()]))

# Generated at 2022-06-26 07:15:53.938595
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    r_1 = Rule.from_path(pathlib.Path('.'))
    r_2 = Rule.from_path(pathlib.Path('.'))
    str_1 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    r_3 = Rule.from_path(pathlib.Path('.'))
    str_2 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_3 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '


# Generated at 2022-06-26 07:16:05.312896
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:16:13.873415
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    rule_0 = Rule(str_0, str_1, str_2, bool_0, str_3, int_0, bool_1)
    rule_1 = Rule(str_4, str_5, str_6, bool_2, str_7, int_1, bool_3)
    rule_1 = Rule(str_8, Rule.from_path(path_0), get_new_command, bool_4, str_9, int_2, bool_5)


# Generated at 2022-06-26 07:16:18.636581
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    assert (Rule.is_match(
            '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    ',
            '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '))


# Generated at 2022-06-26 07:16:21.660438
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = Rule()
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    float_0 = float()
    float_1 = float()


# Generated at 2022-06-26 07:16:24.628256
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    class_w_attr_0 = Rule(str_0, str_1, str_2, str_3, str_4, str_5, str_6)
    assert class_w_attr_0.get_corrected_commands(str_7)


# Generated at 2022-06-26 07:16:31.086502
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    str_1 = '\n    print Rule.is_match(\n        str_0,\n        str_1\n    )\n    '
    assert_equals(Rule.is_match(str_0, str_0), None)


# Generated at 2022-06-26 07:16:31.743190
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    pass

# Generated at 2022-06-26 07:16:36.902769
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    infile = open('/Users/nicholas/Documents/dev/fuckitpy/tests/rules/test.py', 'r')
    lines = [];
    for line in infile:
        lines.append(line)
    infile.close()
    # assert_equal(expected, Rule.__eq__(self, other))
    raise NotImplementedError


# Generated at 2022-06-26 07:16:40.068000
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command = Command(str_0, str_1)
    rule = Rule(str_1, str_2, str_3, str_4, str_5, str_6, str_7)
    result = rule.is_match(command)
    assert result is bool_0
    return result


# Generated at 2022-06-26 07:16:59.019553
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_1 = 151.0
    str_1 = 'mXDKs;!\n!\x0b:O'
    command_1 = Command(float_1, str_1)
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)

    # rule is not required to match case always
    str_4 = 'Ef"^m<!G-p'
    if command_1.output == str_4:
        return False
    # rule side effect
    str_5 = 'jKk-B.+\x0c=G\x0bRJ.^4YE'
    if command_0.output == str_5:
        return False
   

# Generated at 2022-06-26 07:17:03.097646
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'L#[\tp{(w<D'
    command_0 = Command(str_0, str_0)
    rule_0 = Rule(str_0, None, None, False, None, None, None)
    assert rule_0.is_match(command_0) is False



# Generated at 2022-06-26 07:17:14.567878
# Unit test for method is_match of class Rule

# Generated at 2022-06-26 07:17:23.536107
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    rule_0 = Rule('priority', 'match', 'get_new_command', True, None,
                  DEFAULT_PRIORITY, True)
    list_0 = [CorrectedCommand('script', None, DEFAULT_PRIORITY),
              CorrectedCommand('script', None, (2 * DEFAULT_PRIORITY))]
    list_1 = rule_0.get_corrected_commands(command_0)
    if (list_1 != list_0):
        raise AssertionError('Expected {}, but got {}'.format(list_0, list_1))


# Generated at 2022-06-26 07:17:28.436210
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """Test case for Rule.get_corrected_commands."""
    rule_0 = Rule(name='',
                  match=None,
                  get_new_command=None,
                  enabled_by_default=None,
                  side_effect=None,
                  priority=0,
                  requires_output=None)
    command_0 = Command(script='', output='')
    corrected_command = rule_0.get_corrected_commands(command_0)
    assert isinstance(corrected_command, generator)
    logs.set_debug_level(0)


# Generated at 2022-06-26 07:17:37.782918
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_1 = 391.5
    rule_0 = Rule('name_0', match, get_new_command,
                  enabled_by_default, side_effect,
                  priority, requires_output)
    command_1 = Command(float_1, str_0)
    priority_0 = int_0
    corrected_command_0 = CorrectedCommand(script, side_effect, priority_0)
    # Test object.get_corrected_commands()
    corrected_command_1 = rule_0.get_corrected_commands(command_1)
    assert (corrected_command_0 == corrected_command_1)


# Generated at 2022-06-26 07:17:38.981258
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert True


# Generated at 2022-06-26 07:17:45.415365
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    float_1 = 941.0
    str_1 = '}o6%5^5)MIYw'
    rule_0 = Rule(str_1, lambda command_0: True, lambda command_0: '--version', True, None, float_1, False)
    priority_0 = rule_0.get_corrected_commands(command_0)
    return priority_0.__next__().priority



# Generated at 2022-06-26 07:17:50.469994
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    CorrectedCommand(float_0, None, float_0).run(Command(float_0, str_0))

# Generated at 2022-06-26 07:17:53.507457
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import unittest
    import tempfile


# Generated at 2022-06-26 07:18:05.774618
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)

    str_1 = 'mnE^!=i+o\x0c!qCEY'
    rule_0 = Rule(str_1, lambda : True, lambda : str_0, True, lambda : None, 542, True)

    test_case_0(command_0, rule_0)

# Generated at 2022-06-26 07:18:09.596647
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command('', './bin/fuck')
    rule_0 = Rule.from_path(pathlib.Path(
        '/usr/local/bin/thefuck/thefuck/rules/no_command.py'))
    assert list(rule_0.get_corrected_commands(command_0)) == [
        CorrectedCommand('command', None, 100)]



# Generated at 2022-06-26 07:18:22.546595
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    str_1 = 'e ]u'
    str_2 = '#7(|o'
    str_3 = 'v%)x'
    str_4 = '6S:8'
    str_5 = 'F9/.Gb'
    str_6 = '>y#Q'
    str_7 = '\t)I~'
    str_8 = '\x1f\n'
    str_9 = 'Tk\t'
    str_10 = '$ZpY'
    str_11 = "6Ia.w"
    int_0 = 754

# Generated at 2022-06-26 07:18:27.889371
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_1 = Rule(name='test_rule_0', match=test_case_0, get_new_command=test_case_0, enabled_by_default=False, side_effect=test_case_0, priority=854, requires_output=True)
    command_0 = Command(float_0, str_0)
    result_0 = rule_1.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:18:38.981337
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 0.9141184163488252
    float_1 = 0.0031530657632591613
    float_2 = 0.9362134728220722
    float_3 = float_1
    float_4 = 0.17355365224771624
    str_1 = 'j&\x12\x0e\x00\x01F&*\x18\x04\x01-\x10\x1b\x06(\x18\x0f\x0f\x1d\x1b10\x0c\x0eQ\x1f\x1c\x1e\x1d\x0f\x06\x06'
    command_0 = Command(float_0, str_1)

    # Start of user code rule.get

# Generated at 2022-06-26 07:18:43.360106
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from os.path import join, dirname
    from pathlib import Path
    rule_path = Path(join(dirname(__file__), 'rules', 'git_hg_ext.py'))
    rule = Rule.from_path(rule_path)
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    rule.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:18:48.167413
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = 0.0
    str_0 = '`wT\x0cg}'
    command_0 = Command(float_0, str_0)
    float_1 = 1.0
    str_1 = '9Z[\x0b'
    command_1 = Command(float_1, str_1)
    float_2 = 2.0
    str_2 = '$'
    command_2 = Command(float_2, str_2)




# Generated at 2022-06-26 07:18:53.592804
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'fucks given'
    command_0 = Command(str_0, None)
    def match(command):
        return command.output == 'fucks given'
    rule_0 = Rule(str_0, match, None, None, None, None, None)
    rule_0.is_match(command_0)


# Generated at 2022-06-26 07:19:03.430492
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    class_0 = Rule("name", lambda : True, lambda command: [command.script, 'fuck', '{0} {1}'.format(command.script, command.output)], False, None, 10, True)
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    generator_1 = class_0.get_corrected_commands(command_0)
    corrected_command = generator_1.next()
    corrected_command = generator_1.next()
    corrected_command = generator_1.next()
    corrected_command = generator_1.next()

# Generated at 2022-06-26 07:19:08.889033
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = -73.0
    str_1 = 'i{zS/sW'
    command_1 = Command(float_0, str_1)
    rule_0 = Rule(rule_name=True, rule_match=True, rule_get_new_command=True, rule_enabled_by_default=True, rule_side_effect=True, rule_priority=False, rule_requires_output=True)
    corrected_command_1 = rule_0.get_corrected_commands(command_1)



# Generated at 2022-06-26 07:19:33.582832
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('name_0', 'match_0', 'get_new_command_0', 'enabled_by_default_0', 'side_effect_0', 'priority_0')
    corrected_command_0 = CorrectedCommand('script_0', 'side_effect_1', 'priority_1')
    corrected_command_1 = CorrectedCommand('script_0', 'side_effect_1', 'priority_1')
    corrected_command_2 = CorrectedCommand('script_0', 'side_effect_1', 'priority_1')
    corrected_command_3 = CorrectedCommand('script_0', 'side_effect_1', 'priority_1')
    corrected_command_4 = CorrectedCommand('script_0', 'side_effect_1', 'priority_1')

# Generated at 2022-06-26 07:19:40.420925
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'n@>;S3:q.X'
    rule_0 = Rule(str_0, str_0, str_0, True, str_0, 945, True)
    str_1 = 'v`0C0e'
    float_0 = 735.0
    command_0 = Command(str_1, float_0)
    list_0 = []
    corrected_command_0 = CorrectedCommand(str_1, str_0, 945)
    list_0.append(corrected_command_0)
    corrected_command_1 = CorrectedCommand(float_0, str_0, 945)
    list_0.append(corrected_command_1)
    corrected_command_2 = CorrectedCommand(str_0, str_0, 945)
    list_0

# Generated at 2022-06-26 07:19:47.282118
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)

    rule_0 = Rule('name', None, None, bool_0, bool_0, int_0, bool_0)

    assert rule_0.get_corrected_commands(command_0) == list_0


# Generated at 2022-06-26 07:19:57.681380
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('lPc%K\xa0:W8', lambda command: command.script_parts[0] == 'git' and command.script_parts[1] == 'remote' and command.script_parts[2] in ('add', 'rm') and command.script_parts[4] == '--tags', lambda command: command.script_parts[:4] + ['--tags'] + command.script_parts[4:], True, None, 2, True)

    command_0 = Command('git remote add --tags origin git@github.com:nvbn/thefuck.git', 'fatal: remote origin already exists.')
    assert rule_0.is_match(command_0)

# Generated at 2022-06-26 07:20:03.569428
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test arguments:
    path_0 = path.join(path.abspath(path.dirname(__file__)), '..', 'rules', 'git.py')
    rule_0 = Rule.from_path(path_0)
    rule_0 = Rule.from_path(path_0)
    command_0 = Command('q+a$b)Q.@*m=', '^R[.+fU')
    # Function to test:
    output = rule_0.get_corrected_commands(command_0)
    # Assertions (or exceptions):
    assert output == 'git'

# Generated at 2022-06-26 07:20:12.629707
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '=szb'
    command_0 = Command(str_0, 'X9Mt')
    str_1 = '=szb'
    command_1 = Command(str_1, 'X9Mt')
    rule_0 = Rule(str_0, str_1, str_1, (str_1 == str_1), 'X9Mt', 0, (str_1 == str_1))
    rule_0.get_corrected_commands(command_0)
    rule_0.get_corrected_commands(command_1)


# Generated at 2022-06-26 07:20:23.148370
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    logging.basicConfig(
        level=logging.DEBUG,
        filename='test_Rule.log',
        filemode='w',
        format='%(asctime)s %(levelname)s %(message)s',
    )
    float_0 = 542.0
    str_0 = 'mnE^!=i+o\x0c!qCEY'
    command_0 = Command(float_0, str_0)
    corrected_commands = [(Rule(str_0, 'match', 'get_new_command', false, 'side_effect', 'priority', true)).get_corrected_commands(command_0)]
    expected_corrected_commands = [CorrectedCommand('script', 'side_effect', 'priority')]
    assert corrected_commands == expected_corrected_commands



# Generated at 2022-06-26 07:20:30.537153
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Define these variables
    float_0 = 472.0
    str_0 = '4,iAa>7%c"b'
    command_0 = Command(float_0, str_0)
    float_1 = 881.41
    str_1 = '-8W(d\x13\x29@\x10D`4t'
    command_1 = Command(float_1, str_1)
    rule_0 = Rule(name='', match='', get_new_command='', enabled_by_default=True, side_effect=None, priority=450, requires_output=True)
    corrected_commands_0 = rule_0.get_corrected_commands(command_1)

    # Verify the number of commands in corrected_commands_0
    corrected_commands_0_list

# Generated at 2022-06-26 07:20:36.745836
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    case_0 = 'Fuck me harder'
    rules_0 = Rule('fuck_me_harder',
                   float_0, float_0, float_0, float_0)
    command_0 = Command(case_0, case_0)
    expected_0 = ['WHY WOULD I DO THAT?']

    actual_0 = rules_0.get_corrected_commands(command_0)

    assert actual_0 == expected_0

# Generated at 2022-06-26 07:20:45.639016
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # prepare case
    setattr(settings, 'rules', None)
    setattr(settings, 'alter_history', None)
    setattr(settings, 'priority', None)
    setattr(settings, 'repeat', None)
    setattr(settings, 'debug', None)
    setattr(settings, 'exclude_rules', None)
    test_case_0()
    rule_0 = Rule(str_0, None, None, True, None, 666, True)
    # run test
    ret_value = rule_0.get_corrected_commands(command_0)
    # assert test
    #assert isinstance(ret_value, collections.Iterable)
