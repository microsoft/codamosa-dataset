

# Generated at 2022-06-26 07:11:29.229912
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    import mock
    with mock.patch('commands_cache.cache') as mock_cache:
        with mock.patch('rules.Rule.from_path') as mock_from_path:
            with mock.patch('rules.settings') as mock_settings:
                mock_settings.path = []
                mock_settings.rules = []
                mock_settings.priority = []
                mock_settings.exclude_rules = []
                mock_settings.log_level = 'ERROR'
                mock_settings.repeat = True
                mock_settings.alter_history = True
                mock_settings.require_output = True
                mock_settings.debug = True
                mock_from_path.return_value = False
                mock_cache.return_value = False
                mock_from_path.return_value = None

# Generated at 2022-06-26 07:11:41.507879
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command_0 = Command(dict_0, dict_0)
    rule_0 = Rule(dict_0, dict_1, dict_0, True, dict_1, int_0, True)
    rule_1 = Rule(dict_0, dict_1, dict_0, True, dict_1, int_0, True)
    rule_2 = Rule(dict_0, dict_1, dict_0, True, dict_1, int_0, True)
    assert_equal(rule_2.is_match(command_0), True)
    rule_2 = Rule(dict_0, dict_1, dict_0, True, dict_1, int_0, False)
    assert_equal(rule_1.is_match(command_0), True)

# Generated at 2022-06-26 07:11:49.807832
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Create Rule_0
    str_0 = 'r'
    def match(command):
        return True
    def get_new_command(command):
        return str_0
    def side_effect(command, script):
        pass
    rule_0 = Rule('f', match, get_new_command, True, side_effect, 0, True)

    # Create Command_0
    command_0 = Command('n', str_0)

    assert rule_0.is_match(command_0)


# Generated at 2022-06-26 07:11:52.780904
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    arguments = {}
    returned_0 = Rule.get_corrected_commands(**arguments)


# Generated at 2022-06-26 07:11:59.148317
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('', lambda command: command.output is not None,
                  lambda x: u'docker-compose run --rm web bash -c "flake8 {}"'.format(x.script),
                  True, lambda *args: None, 1, True)
    rule_1 = Rule('', lambda command: command.output is not None,
                  lambda x: u'docker-compose run --rm web bash -c "isort {}"'.format(x.script),
                  True, lambda *args: None, 1, True)
    command_0 = Command(u'flake8 .', u'flake8 .')
    assert len(rule_0.get_corrected_commands(command_0)) == 1
    assert len(rule_1.get_corrected_commands(command_0)) == 1


# Generated at 2022-06-26 07:12:08.725708
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {}
    dict_1 = {dict_0: dict_0, dict_0: dict_0, dict_0: dict_0}
    dict_2 = {dict_0: dict_0, dict_0: dict_0}
    dict_3 = {dict_0: dict_0, dict_0: dict_0, dict_0: dict_0}
    corrected_command_0 = CorrectedCommand(dict_0, dict_1, dict_0)
    corrected_command_1 = CorrectedCommand(dict_2, dict_3, dict_0)
    corrected_commands = [corrected_command_0, corrected_command_1]
    rule_0 = Rule(dict_0, dict_1, dict_2, dict_0, dict_1, dict_0, dict_0)
    actual

# Generated at 2022-06-26 07:12:18.816993
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    logging.info( "Testing get_corrected_commands of class Rule")

    # Test #1:
    PATH_TO_RULE = 'rules/__init__.py'
    rule_0 = Rule.from_path(PATH_TO_RULE)
    assert rule_0 == rule_0.get_corrected_commands(rule_0)
    # Test #2:
    PATH_TO_RULE = 'rules/__init__.py'
    rule_0 = Rule.from_path(PATH_TO_RULE)
    assert rule_0 == rule_0.get_corrected_commands(rule_0)

    logging.info( "Passed test_get_corrected_commands of class Rule")

# Generated at 2022-06-26 07:12:23.866017
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('default_rule', lambda command: isinstance(command, Command), lambda command: command, False, None, 80, False)
    corrected_command_0 = rule_0.get_corrected_commands(Command('default_rule', 'default_rule'))
    corrected_command_1 = rule_0.get_corrected_commands(Command('default_rule', 'default_rule'))


# Generated at 2022-06-26 07:12:30.096481
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    correct_rule_0 = Rule('L[^0-9.]*py', 45, Rule.from_path, True, 'L[^0-9.]*py')
    assert correct_rule_0.is_match([])
    correct_rule_0 = Rule('L[^0-9.]*py', 45, Rule.from_path, True, 'L[^0-9.]*py')
    assert not correct_rule_0.is_match([])
    correct_rule_0 = Rule('L[^0-9.]*py', 45, Rule.from_path, True, 'L[^0-9.]*py')
    assert correct_rule_0.is_match([])

# Generated at 2022-06-26 07:12:37.810628
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {}
    dict_1 = {dict_0: dict_0, dict_0: dict_0, dict_0: dict_0}
    rule_0 = Rule(dict_0, dict_0, dict_1, dict_0, dict_0, dict_0, dict_0)
    command_0 = Command(dict_0, dict_0)
    set_0 = {rule_0.get_corrected_commands(command_0)}


# Generated at 2022-06-26 07:12:57.708288
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_1 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_2 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_3 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_4 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_5 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_6 = CorrectedCommand(script='', side_effect=None, priority=0)
    var_7 = CorrectedCommand(script='', side_effect=None, priority=0)

# Generated at 2022-06-26 07:13:09.227769
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test Case #0
    var_0 = Command('ls', 'a\nb\nc')
    var_1 = Rule('', lambda x: True, lambda x: 'a', True, None, DEFAULT_PRIORITY, True)
    var_2 = CorrectedCommand('a', None, DEFAULT_PRIORITY)
    assert var_1.get_corrected_commands(var_0) == [var_2]

    # Test Case #1
    var_1 = Rule('', lambda x: True, lambda x: ['a', 'b'], True, None, DEFAULT_PRIORITY, True)
    var_2 = CorrectedCommand('a', None, DEFAULT_PRIORITY * 1)
    var_3 = CorrectedCommand('b', None, DEFAULT_PRIORITY * 2)

# Generated at 2022-06-26 07:13:13.242772
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Testing of instance
    var_112 = {}
    var_0 = Rule.from_path(pathlib.Path('cement_rule.py'))
    var_0.is_match(var_112)



# Generated at 2022-06-26 07:13:22.133550
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test case with precondition:
    # rule = Rule(name='name', match=None, get_new_command=None,
    #             enabled_by_default=False, side_effect=None,
    #             priority=0, requires_output=False)
    # assert rule.get_corrected_commands(command=None)
    # Unit test for method get_corrected_commands of class Rule
    var_0 = Rule(name='name', match=None, get_new_command=None,
                 enabled_by_default=False, side_effect=None,
                 priority=0, requires_output=False)
    try:
        var_0.get_corrected_commands(command=None)
    except Exception as var_1:
        raise AssertionError(var_1) from var_1


# Generated at 2022-06-26 07:13:30.480446
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    test_cls = Rule('abc', lambda a: a,
                    lambda a: a, True,
                    lambda a, b=True: b,
                    1, True)
    test_inst = test_cls
    var_0 = {
        'test_cls': test_cls,
        'test_inst': test_inst
    }
    test_res = test_inst.is_match(Command('abc', 'abc'))
    assert test_res == True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 07:13:33.921082
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = Rule( name="abbr-user-host", match=None, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None)
    var_1 = Command( script="blah", output=None)
    var_2 = var_0.get_corrected_commands( var_1)
    assert var_2 is not None


# Generated at 2022-06-26 07:13:37.290196
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    Rule_obj_0 = Rule('g', 'g', 'g', True, 'g', 0, True)
    Command_obj_0 = Command('g', 'g')
    Rule_obj_0.is_match(Command_obj_0)


# Generated at 2022-06-26 07:13:43.839786
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:13:53.791944
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = Rule('rule_0', match, get_new_command, True, None, 5,
                 True)
    var_1 = Command('command_1', 'output_1')
    var_2 = CorrectedCommand('script_2', None, 10)
    var_3 = CorrectedCommand('script_3', None, 20)
    var_4 = CorrectedCommand('script_4', None, 30)
    var_5 = CorrectedCommand('script_5', None, 40)
    var_6 = var_0.get_corrected_commands(var_1)
    if var_6 == {var_2, var_3, var_4, var_5}:
        return 0
    else:
        return 1


# Generated at 2022-06-26 07:14:02.565297
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rules = []
    for path in settings.rule_dir.iterdir():
        if path.name.endswith('.py') and path.is_file():
            rules.append(Rule.from_path(path))
    assert len(rules) > 20
    for rule in rules:
        assert isinstance(rule, Rule)
        # Test rule: exclude
        if rule.name == 'exclude':
            assert not rule.is_match(Command.from_raw_script(['fuck']))
            assert not rule.is_match(Command.from_raw_script(['ls']))
            assert not rule.is_match(Command.from_raw_script(['make']))
            assert not rule.is_match(Command.from_raw_script(['M-x', 'conquer-world']))
        # Test rule:

# Generated at 2022-06-26 07:14:19.972809
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from . import rules
    from .conf import settings
    from .exceptions import EmptyCommand

    # A simple rule that replaces "echo" with "echo -n".
    # With `repeat=True` it appends an attempt to run fuck with
    # the same command in case the corrected command fails again.
    class Echo(rules.Rule):
        def match(self, command):
            return command.script_parts[0].endswith('echo')

        def get_new_command(self, command):
            return command.script.replace('echo', 'echo -n', 1)

    settings.alter_history = False
    settings.repeat = True
    settings.rules = rules.DEFAULT_RULES
    settings.priority = {}
    settings.exclude_rules = []
    settings.bad_words = []

# Generated at 2022-06-26 07:14:25.534381
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """
    Test cases:
    Method returns generator with corrected commands.
    """
    log = logs.get_logger()
    var_0 = Rule.from_path()
    var_1 = var_0.get_corrected_commands()
    log.debug('Got value for get_corrected_commands: {}'.format(var_1))


# Generated at 2022-06-26 07:14:27.671143
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = test_case_0()

test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:14:34.001999
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_1 = Rule(name='var_1', match=None, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None)
    var_2 = Command(script='var_2', output=None)
    x = var_1.get_corrected_commands(var_2)
    return x


# Generated at 2022-06-26 07:14:34.946777
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert 0


# Generated at 2022-06-26 07:14:41.869548
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    for loop_counter in range(10):
        # Assigning UniRule to test_Rule_get_corrected_commands
        # Passes argument to the rule 
        # Create instance of the CorrectedCommand class 
        # Create instance of the command class
        var_1 = [var_0[loop_counter]]
        var_2 = Rule(var_0[loop_counter], var_1[loop_counter], var_2[loop_counter], var_3[loop_counter], var_4[loop_counter], var_5[loop_counter], var_6[loop_counter])
        # Call method to get the corrected command
        var_7 = var_2.get_corrected_commands(var_7[loop_counter])
        var_8 = var_7.next()
        assert type(var_8) == Corrected

# Generated at 2022-06-26 07:14:51.578957
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule = Rule(name = 'rule',
                match = (lambda command: True),
                get_new_command = (lambda command: 'script'),
                enabled_by_default = True,
                side_effect = None,
                priority = 100,
                requires_output = True)
    command = Command(script='script', output=None)
    res = [CorrectedCommand(script = 'script',
                            side_effect = None,
                            priority = 100), ]
    test_case_0['var_0'] = rule.get_corrected_commands(command)
    assert test_case_0['var_0'] == res


# Generated at 2022-06-26 07:15:01.284493
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = Command(script = 'C:\\Program Files\\Git\\cmd\\git.exe status -sb', output = '## master\r\n M thefuck\\shells\\generic.py\r\n M thefuck\\rules\\git.py\r\n')

# Generated at 2022-06-26 07:15:07.543782
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_1 = Command('git fetch --all', '')
    var_4 = Rule.get_corrected_commands(var_1, var_1)
    var_5 = var_4[0]
    var_6 = int()
    var_7 = var_5.run(var_1)
    return var_7


# Generated at 2022-06-26 07:15:15.592891
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test case 0 of 1
    var_0 = Rule(name='random', match=lambda: True, get_new_command=lambda: 'some_command', enabled_by_default=True, side_effect=None, priority=10, requires_output=True)
    var_1 = Command(script='some_command', output=None)
    var_2 = var_0.get_corrected_commands(var_1)
    var_3 = CorrectedCommand(script='some_command', side_effect=None, priority=10)
    assert var_2.__next__() == var_3

# Generated at 2022-06-26 07:15:27.913182
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {'\u0007': u'sys'}
    dict_1 = {u'script': u'import sys', u'output': u'sys'}
    command_0 = Command(dict_0['\u0007'], dict_1['output'])
    rule_0 = Rule(dict_1['script'], dict_1['output'], dict_0['\u0007'], dict_0['\u0007'], dict_1['script'], dict_0['\u0007'], dict_0['\u0007'])
    dict_1['script']('import sys')
    dict_1['script'](command_0)
    dict_0['\u0007']('import sys')


# Generated at 2022-06-26 07:15:33.486882
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = True
    str_1 = True
    int_0 = 1
    int_1 = 1
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_0, str_1, str_0, str_0, str_1, int_0, int_1)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:40.535276
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_1 = "xS'"
    dict_1 = {str_1: str_1}
    bool_1 = True
    command_1 = Command(bool_1, bool_1)
    correctedcommand_0 = CorrectedCommand(str_1, command_1, bool_1)
    correctedcommand_0.run(command_1)
    correctedcommand_0 = CorrectedCommand(str_1, command_1, bool_1)
    correctedcommand_0.run(command_1)


# Generated at 2022-06-26 07:15:45.133288
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert Rule.get_corrected_commands(None, Command(None, None)) == []

# ! No examples found for System.Exception
# ! No examples found for System.Runtime.CompilerServices.TrueModule
# ! No examples found for System.Reflection.Metadata.DebugMetadataHeader
# ! No examples found for System.Reflection.RuntimeAssembly
# ! No examples found for System.Reflection.RuntimeModule

# Generated at 2022-06-26 07:15:54.481899
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "S'"
    bool_0 = True
    command_0 = Command(bool_0, bool_0)
    corrected_command_0 = CorrectedCommand(command_0, rule_0, list_0)
    corrected_command_1 = CorrectedCommand(list_0, list_0, rule_0)
    rule_0 = Rule(str_0, command_0, list_0, command_0, list_0, list_0, bool_0)
    list_0 = [corrected_command_0, corrected_command_1]
    assert rule_0.get_corrected_commands(command_0) == list_0

# Generated at 2022-06-26 07:16:02.033553
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    shell.reset_encoding()
    script = "fuck"
    dict_0 = {script: script}
    command_0 = Command.from_raw_script(script)
    command_1 = Command(script, script)
    var_0 = command_1.update(**dict_0)
    rule_0 = Rule(script, script, script, True, script, 0, True)
    assert rule_0.is_match(command_0)

if __name__ == '__main__':
    test_case_0()
    test_Rule_is_match()

# Generated at 2022-06-26 07:16:11.044031
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'Nh@U^7V[cT6TK7VpG'
    dict_0 = {str_0: str_0}
    bool_0 = True
    command_0 = Command(bool_0, bool_0)
    rule_0 = Rule(str_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    rule_1 = rule_0.update(**dict_0)
    rule_0.is_match(command_0)


# Generated at 2022-06-26 07:16:14.300234
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:16:23.842251
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "y"
    dict_0 = {str_0: str_0}
    int_0 = 0
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18 = dict_17
    dict_19 = dict

# Generated at 2022-06-26 07:16:31.240535
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import argparse
    parser = argparse.ArgumentParser()
    dict_0 = {'default': False, 'action': 'store_true'}
    parser.add_argument("--case-0", **dict_0)
    args = parser.parse_args()

    if args.case_0:
        test_case_0()

if __name__ == "__main__":
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:16:46.745866
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    a_corrected_command_0 = CorrectedCommand("r'\"r\"'", None, 1)
    str_0 = "r'\"r\"'"
    command_0 = Command(str_0, str_0)
    rule_0 = Rule("name", test_case_0, test_case_0, True, test_case_0, 1, True)
    var_0 = rule_0.get_corrected_commands(command_0)
    var_0 = CorrectedCommand(script=str_0, side_effect=None, priority=1)
    assert abs(var_0 - a_corrected_command_0) <= 0.0001


# Generated at 2022-06-26 07:16:54.088756
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "s!:"
    str_1 = "T?I"
    str_2 = "Y#W"
    bool_0 = False
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, tuple_0, tuple_1]
    command_0 = Command(str_0, str_1)
    rule_0 = Rule(str_0, match, get_new_command, bool_0, tuple_1, int_0, bool_1)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:17:03.650167
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "1Dv"
    str_1 = "syI"
    int_0 = 1
    command_0 = Command(str_1, str_0)
    def func_0(command_0):
        return True
    def func_1(command_0):
        return str_1
    def func_2(command_0, str_2):
        return None
    rule_0 = Rule(str_1, func_0, func_1, True, func_2, int_0, True)
    var_0 = rule_0.get_corrected_commands(command_0)
    assert var_0


# Generated at 2022-06-26 07:17:10.828558
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    num_0 = -0x8a29
    side_effect_0 = lambda command_0, num_0: None
    rule_0 = Rule('abhQX', None, None, None, side_effect_0, num_0, None)
    command_0 = Command(None, None)
    var_0 = rule_0.get_corrected_commands(command_0)
    assert var_0.next().script is None


# Generated at 2022-06-26 07:17:16.217067
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .rules.reverse_alias import get_new_command
    rule_0 = Rule('', None, get_new_command, True, None, 0, True)
    str_0 = ''
    command_0 = Command(str_0, str_0)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:17:24.703616
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "m"
    str_1 = "2[Y1#F"

    @staticmethod
    def method_2(command_0):
        return command_0.stdout

    @staticmethod
    def method_0(command_0):
        return command_0.stderr

    @staticmethod
    def method_1(command_0):
        return command_0.script_parts

    priority_0 = 0
    rule_0 = Rule(str_0, method_2, method_0, True, method_1, priority_0, False)
    str_2 = " &"
    str_3 = "echo 'No, fuck you!'"
    str_4 = "Yes, I know!"
    command_1 = Command(str_2, str_3)

# Generated at 2022-06-26 07:17:29.612856
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = pathlib.Path('/')
    rule_0 = Rule.from_path(path_0)
    command_0 = Command.from_raw_script((False,))
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    assert not next(corrected_commands_0)


# Generated at 2022-06-26 07:17:40.847422
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "xS'"
    dict_0 = {str_0: str_0}
    bool_0 = True
    exec_0 = CorrectedCommand(str_0, None, True)
    command_0 = Command(bool_0, bool_0)
    rule_0 = Rule(str_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    var_0 = rule_0.get_corrected_commands(command_0)
    var_1 = rule_0.get_corrected_commands(var_0)
    var_2 = rule_0.get_corrected_commands(var_1)
    var_3 = rule_0.get_corrected_commands(var_2)
    # get_corrected_commands

# Generated at 2022-06-26 07:17:46.046134
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'match'
    function_0 = getattr(settings, str_0, None)
    rule_0 = Rule('j', function_0, lambda x_0, x_1: x_0, False, None, 0, True)
    bool_0 = True
    command_0 = Command(bool_0, bool_0)
    rule_0.is_match(command_0)


if __name__ == '__main__':
    test_case_0()
    test_Rule_is_match()

# Generated at 2022-06-26 07:17:57.493908
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-"
    str_1 = "xS'"
    str_2 = str_1
    str_3 = str_2
    str_4 = "v7pWl}\8#m*=_b?%m;tV-:t8s"
    str_5 = str_4

# Generated at 2022-06-26 07:18:20.499578
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command('5U\'', 'U\'')
    rule_0 = Rule(None, None, None, None, None, None, None)
    var_0 = rule_0.get_corrected_commands(command_0)
    str_0 = '"\'\\\'\'"'
    dict_0 = {str_0: str_0}
    command_1 = Command(None, '5U\'')
    rule_1 = Rule(None, None, None, None, None, None, None)
    var_1 = rule_1.get_corrected_commands(command_1)


# Generated at 2022-06-26 07:18:28.000215
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {}
    dict_1 = {'script':'', 'side_effect':None, 'priority':0}
    command_0 = Command("", "")
    rule_0 = Rule("", test_Rule_get_corrected_commands, test_Rule_get_corrected_commands, True, None, 0, True)
    var_0 = rule_0.get_corrected_commands(command_0)
    # assert var_0 == corrected_commands


# Generated at 2022-06-26 07:18:30.917870
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule('', '', '', '', '', '', '')
    command_0 = Command('', '')
    str_0 = rule_0.is_match(command_0)

# Generated at 2022-06-26 07:18:38.982221
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # var_0 is assigned decimal value '0' here
    var_0 = 0.0

    # var_0 is assigned decimal value '0.0' here
    var_0 = 0.0
    bool_0 = False
    str_1 = "m7^u"
    str_2 = "tGZ@"
    str_3 = "xxQ9"
    str_4 = "DjH|"
    var_1 = [str_1, str_2, str_3, str_4]



# Generated at 2022-06-26 07:18:47.461214
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {'a': 'a'}
    int_0 = 0
    tuple_0 = (int_0,)
    class_0 = Command
    int_1 = 0
    tuple_1 = (int_1,)
    dict_1 = {'1': '1'}
    int_2 = 0
    tuple_2 = (int_2,)
    dict_2 = {'d': 'd'}
    class_1 = CorrectedCommand
    rule_0 = Rule(None, None, None, None, None, None, None)
    command_0 = class_0(bool(0), bool(0))
    rule_0.get_corrected_commands(command_0)
    command_1 = class_0(bool(0), bool(0))
    rule_0.get_corrected_comm

# Generated at 2022-06-26 07:18:54.012655
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "TsU"
    command_0 = Command(True, True)
    rule_0 = Rule(str_0, True, True, True, True, True, True)
    var_0 = rule_0.get_corrected_commands(command_0)
    assert len(var_0) == 1


if __name__ == '__main__':
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:19:00.485554
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = "xS'"
    dict_0 = {str_0: str_0}
    bool_0 = True
    command_0 = Command(bool_0, bool_0)
    rule_0 = Rule(str_0, None, None, bool_0, None, -9, bool_0)
    var_1 = rule_0.is_match(**dict_0)
    # Final output of call
    var_1 = None


# Generated at 2022-06-26 07:19:10.111075
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "</G"
    str_1 = "ylU"
    tuple_0 = (str_0, str_1)
    str_2 = "&!u"
    str_3 = "5O+"
    tuple_1 = (str_2, str_3)
    str_4 = "b'G"
    str_5 = "xS'"
    tuple_2 = (str_4, str_5)
    dict_0 = {tuple_0: tuple_1, tuple_2: tuple_2}
    bool_0 = True
    command_0 = Command(bool_0, bool_0)
    rule_0 = Rule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, False)
    var_0 = rule_0.get

# Generated at 2022-06-26 07:19:15.722082
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    string_0 = '\t\x10`\x7f'
    var_0 = Rule(string_0, lambda: (True), lambda: ([string_0]))
    string_1 = '\t\x10`\x7f'
    var_1 = Command(string_1, string_1)
    var_2 = var_0.get_corrected_commands(var_1)


# Generated at 2022-06-26 07:19:23.546464
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule("S", test_case_0, test_case_0, True, test_case_0, 0, True)
    command_0 = Command(True, True)
    iterable_0 = rule_0.get_corrected_commands(command_0)
    iterable_1 = rule_0.get_corrected_commands(command_0)
    if not iterable_0 == iterable_1:
        return(True)
    else:
        return(False)

# Generated at 2022-06-26 07:19:46.478219
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = '/usr/bin/python'
    str_1 = '/usr/bin/python3'

    # test case with str script, no side_effect
    command = Command(str_0, None)
    corrected = CorrectedCommand(script=str_1, side_effect=None, priority=1)
    corrected.run(command)

    # test case with tuple script, side_effect
    tuple_script = (str_1, 'echo "Python 3 is way better"')
    command = Command(str_0, "/usr/bin/python")
    corrected = CorrectedCommand(script=tuple_script, side_effect=None, priority=1)
    corrected.run(command)


# Generated at 2022-06-26 07:19:56.800344
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'this is a string'
    str_1 = 'this is another test string'
    str_2 = 'this is a test string'
    str_3 = ''
    rule_0 = Rule(str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    cmd_0 = CorrectedCommand(str_0, str_0, str_0)
    print(cmd_0)
    print(str(cmd_0) == "CorrectedCommand(script='this is a string', side_effect='this is a string', priority='this is a string')")
    cmd_1 = CorrectedCommand(str_1, str_0, str_0)
    print(cmd_1)
    print

# Generated at 2022-06-26 07:20:03.189967
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    class Mock_get_corrected_commands_Rule:
        def __init__(self):
            self.script = 'aws'
            self.side_effect = lambda x, y: 1
            self.priority = 1

    class Mock_get_corrected_commands_Rule_1:
        def get_new_command(self, command):
            return [self.script]

    class Mock_get_corrected_commands_Rule_2:
        def get_new_command(self, command):
            return [Mock_get_corrected_commands_Rule(),
                    Mock_get_corrected_commands_Rule()]


# Generated at 2022-06-26 07:20:10.093308
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    matched = False
    str_0 = ''
    rule_0 = Rule(str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    for corrected_cmd in rule_0.get_corrected_commands(command_0):
        assert not corrected_cmd.priority
        matched = True
        break
    assert matched

# Generated at 2022-06-26 07:20:20.965041
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'rule_0'
    str_1 = 'cmd_1'
    str_2 = 'cmd_2'
    str_3 = 'cmd_3'

    # str_4 does nothing
    def side_effect(cmd, new_cmd):
        return None

    def get_new_command(command):
        return [str_1, str_2, str_3]

    rule_0 = Rule(str_0, get_new_command, get_new_command, get_new_command,
                  side_effect, str_0, str_0)
    command = Command(str_0, str_0)
    var_0 = rule_0.get_corrected_commands(command)
    var_1 = var_0[0]
    assert var_1.script == str_1
   

# Generated at 2022-06-26 07:20:24.709776
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = ''
    rule_0 = Rule(str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    var_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:20:25.540060
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    pass



# Generated at 2022-06-26 07:20:30.052249
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Setup
    str_0 = ''
    list_0 = []
    rule_0 = Rule(str_0, str_0, list_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    # Exercise
    var_0 = rule_0.get_corrected_commands(command_0)
    # Verify
    assert isinstance(var_0, list)


# Generated at 2022-06-26 07:20:35.295171
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = ''
    rule_0 = Rule(str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    var_0 = rule_0.is_match(command_0)


# Generated at 2022-06-26 07:20:41.698012
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = ''
    rule_0 = Rule(str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    command_0 = Command(str_0, str_0)
    s_var_0 = rule_0.get_corrected_commands(command_0)


if __name__ == '__main__':
    test_Rule_get_corrected_commands()