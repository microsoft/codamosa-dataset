

# Generated at 2022-06-26 07:11:12.957288
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    case_0_args = [Command('FIzS9>T', ['s8$v]R&%w;4Jh<zG:1T9'])]
    test_case_0(case_0_args)


if __name__ == '__main__':
    test_Rule_is_match()

# Generated at 2022-06-26 07:11:20.617862
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # AssertionError: CorrectedCommand(script=None, side_effect=None, priority=0) != CorrectedCommand(script=None, side_effect=None, priority=0)
    str_0 = 'mT|fOzwZ6q_p6&l=e'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule('method', test_case_0, test_case_0, True, test_case_0, DEFAULT_PRIORITY, True)
    CorrectedCommand_0 = rule_0.get_corrected_commands(command_0)
    CorrectedCommand_1 = rule_0.get_corrected_commands(command_0)
    assert CorrectedCommand_0 != CorrectedCommand

# Generated at 2022-06-26 07:11:26.724429
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command_0 = Command('a', 'b')
    rule_0 = Rule('a', lambda command: command.script == 'a', lambda command: 'b', True, None, -1, True)
    rule_0.is_match(command_0)
    assert rule_0.name == 'a'


if __name__ == '__main__':
    test_case_0()
    test_Rule_is_match()

# Generated at 2022-06-26 07:11:31.420505
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = Rule('yb*6r3jqiy67DuuU', test_case_0, test_case_0, True, test_case_0, 0, True)

    # Test case for method get_corrected_commands of class Rule
    # Test case for method get_corrected_commands of class Rule
    command_0 = Command('h4dVvdn4qApUM7n', 'z')
    corrected_command_0 = CorrectedCommand('u', test_case_0, 0)
    corrected_command_1 = CorrectedCommand('H9i', test_case_0, 0)
    corrected_command_2 = CorrectedCommand('gNz', test_case_0, 0)

    # Test case for method get_corrected_commands of class Rule
    # Test case for method get_

# Generated at 2022-06-26 07:11:35.423161
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path_0 = pathlib.Path('/')
    rule_0 = Rule.from_path(path_0)
    command_0 = Command('', '')
    assert not rule_0.is_match(command_0)


# Generated at 2022-06-26 07:11:44.440646
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'hYG0[Ao``_`y$x3`4*#'
    bool_0 = False
    list_0 = ['', '', True]
    rule_0 = Rule(str_0, bool_0, list_0, bool_0, bool_0, bool_0, bool_0)
    command_0 = Command('', '')
    value_0 = rule_0.is_match(command_0)
    str_1 = 'C@Lo8`xM`Fv`YQMLD-#'
    bool_1 = True
    list_1 = [str_1, str_1, bool_1]
    rule_1 = Rule(str_1, bool_1, list_1, bool_1, bool_1, bool_1, bool_1)
    command

# Generated at 2022-06-26 07:11:51.876431
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 'zG`\\'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    assert command_0 is not None
    rule_0 = Rule.from_path(pathlib.Path(str_0))
    assert rule_0 is not None
    bool_0 = rule_0.is_match(command_0)
    assert bool_0 is False


# Generated at 2022-06-26 07:11:52.878326
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    pass


# Generated at 2022-06-26 07:12:04.283847
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('name', None, None, False, None, 0, True)
    command_0 = Command('<PATH>', '<DIR>')
    corrected_command_0 = CorrectedCommand(command_0.script, rule_0.side_effect, rule_0.priority)
    corrected_command_1 = CorrectedCommand('<DIR>', rule_0.side_effect, rule_0.priority * 2)
    corrected_command_2 = CorrectedCommand('<DIR>', rule_0.side_effect, rule_0.priority * 3)
    corrected_command_3 = CorrectedCommand('<DIR>', rule_0.side_effect, rule_0.priority * 4)

# Generated at 2022-06-26 07:12:14.939694
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = Rule('t4vU=n6uyBbDa\\Fy-*q', str_0, Command.from_raw_script, str_0, str_0, str_0, str_0)
    command_0 = Command('t4vU=n6uyBbDa\\Fy-*q', 't4vU=n6uyBbDa\\Fy-*q')
    for corrected_command_0 in str_0.get_corrected_commands(command_0):
        assert isinstance(corrected_command_0, CorrectedCommand)
        assert isinstance(corrected_command_0.script, str)
        assert isinstance(corrected_command_0.side_effect, type(None))
        assert isinstance(corrected_command_0.priority, int)

# Unit

# Generated at 2022-06-26 07:12:38.813340
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '_g7\"rB\\y"mG'
    long_0 = int(331155)
    char_0 = 's'
    class_0 = get_alias()
    buffer_0 = bytearray(35)
    buffer_0.append(127)
    buffer_0.append(126)
    buffer_0.append(47)
    buffer_0.append(29)
    buffer_0.append(39)
    buffer_0.append(4)
    buffer_0.append(110)
    buffer_0.append(122)
    buffer_0.append(107)
    buffer_0.append(108)
    buffer_0.append(100)
    buffer_0.append(101)
    buffer_0.append(94)
    buffer_0.append

# Generated at 2022-06-26 07:12:45.131319
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = {'0': '0', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6', '7': '7', '8': '8', '9': '9'}
    rule_0 = Rule(str_0, str_1, None, True, list, int_0, True)
    command_0 = Command(str_0, dict_0)
    list_0 = rule_0.get_corrected_commands(command_0)
    assert_true(list_0 == list_1)

# Generated at 2022-06-26 07:12:52.459418
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Imports rule `one` we previously added to the config
    rule_0 = Rule.from_path(pathlib.Path('/tmp/one.py'))
    command_0 = Command('echo "Hello world"', None)
    iterator = rule_0.get_corrected_commands(command_0)
    iterator.__next__().run(command_0)

test_case_0()
test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:13:01.907754
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test 1: case where returning generator is empty
    #         test is expected to fail
    str_0 = 'c'
    list_0 = [str_0]
    dict_0 = {str_0: str_0}
    original_Command = Command(str_0, dict_0)
    original_Rule = Rule(str_0, list_0, list_0, str_0, str_0, str_0, list_0)
    # test is expected to fail for the code below
    try:
        for possible_Command in original_Rule.get_corrected_commands(original_Command):
            pass
    except StopIteration:
        pass
    # Test 2: case where it returns a list
    #         test is expected to fail
    str_1 = 'x'
    str_2 = 'i-'


# Generated at 2022-06-26 07:13:05.091859
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '6'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    script_0 = 'y7se9'
    priority_0 = 33
    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0, priority_0, True)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:13:16.136986
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command2 = Command(None, None)
    dict_0 = {'Pz.C{3': 'Dp\\'}
    command1 = Command('Pz.C{3', dict_0)
    string1 = 'Pz.C{3'
    dict_1 = {string1: string1}
    command0 = Command(string1, dict_1)
    corrected_command1 = CorrectedCommand('Pz.C{3', None, 0)
    corrected_command0 = CorrectedCommand(string1, None, 0)
    corrected_command2 = CorrectedCommand('Pz.C{3', None, 10)
    corrected_command3 = CorrectedCommand('Pz.C{3', None, 0)

# Generated at 2022-06-26 07:13:16.858716
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    pass


# Generated at 2022-06-26 07:13:20.312186
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('D{YzdP.K', None, None, True, None, 84, True)
    command_0 = Command('Aw{&rJh|R+b:', None)
    assert rule_0.get_corrected_commands(command_0) is not None


# Generated at 2022-06-26 07:13:23.813312
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule(10, test_case_0, test_case_0, False, False, 9, False)
    command_0 = Command(15, 14)
    repr_0 = repr(rule_0)


# Generated at 2022-06-26 07:13:30.336764
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # Instantiation of parameters
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'

    # Instantiation of arguments
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)

    # Call of method of the class CorrectedCommand
    CorrectedCommand.run(command_0)

# Generated at 2022-06-26 07:13:49.727087
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Test rule match
    #
    # def match(self, command):
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    str_1 = 'kTZ*WeHQ;z'
    dict_1 = {str_1: str_1}
    command_1 = Command(str_1, dict_1)
    str_2 = 'Xa+]2QhG,rE}'
    dict_2 = {str_2: str_2}
    command_2 = Command(str_2, dict_2)
    str_3 = 'f%2;#opz4m~2Hx&F'
    dict_

# Generated at 2022-06-26 07:13:59.481174
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:14:06.702106
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule(str_0, str_0, str_0, True, str_0,
                  DEFAULT_PRIORITY, True)
    assert rule_0.get_corrected_commands(command_0) in [[], []]

test_case_0()

# Generated at 2022-06-26 07:14:12.768939
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    clear_rules = True # <-- Set this variable to True/False to test both cases
    rule_0 = Rule('str_0', test_case_0, test_case_0, clear_rules,
                  test_case_0, 0, True)
    command_0 = Command('str_0', {'str_0': 'str_0'})
    match_0 = rule_0.is_match(command_0)
    if match_0:
        raise RuntimeError


# Generated at 2022-06-26 07:14:19.499829
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_1 = 'EwRBPaHJHBaA'
    str_2 = 'LJ9%SD!1.!fZ'
    int_0 = 3
    int_1 = 4
    str_3 = 'B9EoBg7$Y1Sc'
    str_4 = 'C0WU&c6Uy^bH'
    int_2 = 11
    str_5 = '0mq3stx*IsBh'
    int_3 = 12
    str_6 = '*v4$4Pj.w3qF'
    int_4 = 3
    int_5 = 14
    int_6 = 6
    int_7 = 0
    int_8 = 16
    str_7 = 'fmk9XH$=*hDZ'
    str_

# Generated at 2022-06-26 07:14:22.174322
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    temp_path = pathlib.Path(settings.config_dir) / 'temp.py'

# Generated at 2022-06-26 07:14:29.708923
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script = 'Test string'
    side_effect = None
    priority = 13
    new_command = CorrectedCommand(script, side_effect, priority)

    match = lambda cmd: True
    get_new_command = lambda cmd: new_command

    rule = Rule('name', match, get_new_command, True, None, 1, True)

    command = Command('', dict())
    assert(next(rule.get_corrected_commands(command)) == new_command)

# Generated at 2022-06-26 07:14:38.990109
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    int_0 = 0
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    list_0 = ['t4vU=n6uyBbDa\\Fy-*q']

    def get_new_command(command):
        return list_0

    rule_0 = Rule('', None, get_new_command, True, None, int_0, True)
    list_1 = []
    for command in list_0:
        list_1.append(
            CorrectedCommand(command, None, rule_0.priority * (rule_0.priority + 1)))

    assert rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:14:45.436571
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    # NOTE: The following variables are only used as a parameter for the
    # test_case_0 function.
    # str_1 = 't4vU=n6uyBbDa\\Fy-*q'
    # dict_1 = {str_1: str_1}
    # command_1 = Command(str_1, dict_1)
    i_1 = CorrectedCommand(str(0), test_case_0, 0)
    i_1.run(command_0)

# Generated at 2022-06-26 07:14:56.817542
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from . import test_data
    from .tools import find_rule_by_name

    for test_case in test_data.TEST_CASES:
        correct_commands = list(test_case.correct_commands)
        rule = find_rule_by_name(test_case.rule_name)

        for corrected_command in rule.get_corrected_commands(test_case.command):
            assert corrected_command in correct_commands, \
                'Rule.get_corrected_commands() produced wrong corrected command: ' \
                '{} is not in {}.'.format(corrected_command, correct_commands)

            correct_commands.remove(corrected_command)


# Generated at 2022-06-26 07:15:07.404358
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule(str(), bool(), bool(), bool(), bool(), bool(), bool())
    command_0 = Command(str(), dict())
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:15.590500
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = pathlib.Path('/')
    rule_0 = Rule.from_path(path_0)
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    corrected_command_0 = CorrectedCommand(str_0, None, None)
    tuple_0 = (corrected_command_0)
    assert rule_0.get_corrected_commands(command_0) == tuple_0


# Generated at 2022-06-26 07:15:22.508284
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '9(Wy`6c)V'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule('8Z1', '<>', ';I:B', dict_0, dict_0, dict_0, dict_0)
    CorrectedCommand = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:32.682443
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'c%y5_5x(PpDlF5#i-YZ'
    str_1 = 'MvC8=HWq3$@gx!x-U6i'
    str_2 = '&_6z7l?G'
    str_3 = 'GTf4y735_2$tIyuSz*c'
    str_4 = '9X_Fg#2QOd'
    dict_0 = {str_0: str_3, str_1: str_1}
    command_0 = Command(str_2, dict_0)
    rule_0 = Rule(str_0, None, None, False, None, None, False)
    dict_1 = {}

# Generated at 2022-06-26 07:15:43.101445
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '9U6+Mz6^~UY'

# Generated at 2022-06-26 07:15:47.175746
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'dZr{r]@=aA5H&3}q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 0, True)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:56.428761
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = ">Z}p"
    str_1 = "bSumy&"
    dict_0 = {str_0: str_1}
    command_0 = Command("<w3L:tD}l@?*~#F`K(", dict_0, "R|'<@L'.(u?7", ":.Sj[7X")
    str_2 = "'}`KAEpyNg#l_<LQw~K:Ui"
    str_3 = "!@D$'K{(xm8n>`e?6~2o6U"
    dict_1 = {str_2: str_3}
    command_1 = Command("F=fEu", dict_1, "PjX7P+", "l,TH")
    dict_2

# Generated at 2022-06-26 07:16:08.953567
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    for _ in range(10):
        str_0 = '8O5j9YMn\\&*\\'
        dict_0 = {str_0: str_0}
        command_0 = Command(str_0, dict_0)
        str_1 = 'HEF6KjOP:&Cg@'
        dict_1 = {str_1: str_1}
        command_1 = Command(str_1, dict_1)
        str_2 = 'D*'
        dict_2 = {str_2: str_2}
        command_2 = Command(str_2, dict_2)
        str_3 = 'wC*8ZPJ'
        dict_3 = {str_3: str_3}
        command_3 = Command(str_3, dict_3)
        str

# Generated at 2022-06-26 07:16:20.092256
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command('2B(N#6U', 'gE(a_3A')
    rule_0 = Rule(command_0.get_corrected_commands(command_0), '#0u4tB_',
        command_0, 'l7TdT3q', command_0, command_0, '|d)*>M')
    rule_1 = Rule(command_0.get_corrected_commands(command_0), '|d)*>M',
        command_0, 'l7TdT3q', command_0, command_0, '#0u4tB_')
    assert rule_0 != rule_1
    assert rule_1.get_corrected_commands(command_0) == rule_1.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:16:26.878279
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    """
    Test case for method get_corrected_commands of class Rule
    """
    # Declare variables
    rule_0 = Rule('rule_0', None, None, True, None, 1, True)
    command_0 = Command('command_0', 'output_0')
    str_0 = '{c}'
    rule_0.get_new_command = lambda c: str_0.format(c=c)
    int_0 = 1

    # Call function
    for n, cmd in enumerate(rule_0.get_corrected_commands(command_0)):
        int_1 = n + int_0
        assert cmd.priority == int_1 * rule_0.priority, \
            "Expected {}, got {}".format(int_1 * rule_0.priority, cmd.priority)


# Generated at 2022-06-26 07:16:50.581731
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('name0', 'match0', 'get_new_command0', 'enabled_by_default0',
                  'side_effect0', 'priority0', 'requires_output0')
    command_0 = Command('str0', 'dict0')

    # def get_corrected_commands(self, command):
    #     new_commands = self.get_new_command(command)
    #     if not isinstance(new_commands, list):
    #         new_commands = (new_commands,)
    #     for n, new_command in enumerate(new_commands):
    #         yield CorrectedCommand(script=new_command,
    #                                side_effect=self.side_effect,
    #                                priority=(n + 1) * self.priority)

    # def get

# Generated at 2022-06-26 07:16:51.725224
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_0()


# Generated at 2022-06-26 07:16:58.555915
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    if sys.version_info >= (3, 0):
        import unittest
        class TestCase_0(unittest.TestCase):
            @classmethod
            def setUpClass(cls):
                test_case_0()
            def test_0(self):
                # Tries to get a rule from a path
                self.assertNotEqual(
                    Rule.from_path(''), None)
        class TestCase_1(unittest.TestCase):
            @classmethod
            def setUpClass(cls):
                test_case_0()
            def test_0(self):
                # Command input:
                # None
                # Output should be:
                # None
                self.assertEqual(
                    Rule.get_corrected_commands(''), None)

# Generated at 2022-06-26 07:17:00.891150
# Unit test for method is_match of class Rule
def test_Rule_is_match():

    assert_equal(
        True,
        rule_0.is_match(command_0)
    )


# Generated at 2022-06-26 07:17:11.713454
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Rule.get_corrected_commands
    str_0 = 'O^c%}@{p[|O'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 1, False)
    corrected_commands_0 = list(rule_0.get_corrected_commands(command_0))
    assert corrected_commands_0
    # -
    assert corrected_commands_0[0].script == str_0
    assert corrected_commands_0[0].side_effect == test_case_0
    assert corrected_commands_0[0].priority == 1

# Generated at 2022-06-26 07:17:18.236749
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = dict()
    rule_0 = Rule()
    command_0 = Command(dict_0, dict_0)
    get_corrected_commands_0 = rule_0.get_corrected_commands(command_0)

    dict_0 = dict()
    command_0 = Command(dict_0, dict_0)
    rule_0 = Rule()
    get_corrected_commands_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:17:26.556807
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('O%cZ', lambda command: command.output is None, lambda command: (
        command.update(script=shell.quote(command.script)).script,
        command.update(script=shell.quote(command.script)).script), True,
                   lambda command, script: setattr(command, 'script',
                                                   script),
                   DEFAULT_PRIORITY, True)
    command_0 = Command('X^"', 'r*iCc%_R')
    corrected_commands = list(rule_0.get_corrected_commands(command_0))
    assert len(corrected_commands) == 2
    assert corrected_commands[0].script == shell.quote(command_0.script)
    assert corrected_commands[1].script == shell.quote(command_0.script)

# Generated at 2022-06-26 07:17:33.756498
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = str_1 = '1'
    rule_0 = Rule(str_0, str_0, str_1, str_1, str_0, str_0, str_1)
    command_0 = Command(str_0, str_1)
    str_2 = str(rule_0.get_corrected_commands(command_0))
    str_3 = '<generator object Rule.get_new_command at '
    assert str_2.startswith(str_3)


# Generated at 2022-06-26 07:17:44.061219
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = '/usr/bin/fuck'
    int_0 = 32745
    dict_0 = {
        'fuck': '/usr/bin/fuck'
    }
    dict_1 = {
        'fuck': '/usr/bin/fuck',
        'PATH': '/usr/bin:/bin:/usr/sbin:/sbin'
    }
    str_1 = 'fuck git push'
    list_0 = [
        'fuck',
        'git',
        'push'
    ]
    str_2 = 'git push'
    str_3 = 'git push --force'
    str_4 = 'fuck git push --force'
    str_5 = '/usr/bin/fuck git push --force'

# Generated at 2022-06-26 07:17:56.598183
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    str_1 = '!  p)Ea<<1Kl4'
    str_2 = '\\'
    dict_0 = {str_0: str_0}
    list_0 = [str_1, str_2]
    rule_0 = Rule(str_0, list_0, dict_0, True, 1, 1, True)
    rule_0.get_new_command = lambda command: list_0
    command_0 = Command(str_0, dict_0)
    dict_1 = rule_0.get_corrected_commands(command_0)
    dict_1_0 = dict_1[0]
    str_3 = dict_1_0.script
    assert str_1

# Generated at 2022-06-26 07:18:28.836703
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    list_0 = [str_0, '.', '.', '.', '.']
    list_1 = [str_0, '.', '.', '.', '.']
    list_2 = [str_0, '.', '.', '.', '.']
    list_3 = [str_0, '.', '.', '.', '.']
    list_4 = [str_0, '.', '.', '.', '.']
    list_5 = [str_0, '.', '.', '.', '.']
    list_6 = [str_0, '.', '.', '.', '.']

# Generated at 2022-06-26 07:18:39.346060
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_1 = 'DF#<)0vt))e&NRy:HG\\'
    str_2 = '.ZmHnZ]*1)e'
    dict_0 = {str_1: str_2}
    command_0 = Command(str_2, dict_0)
    rule_0 = Rule.from_path(pathlib.Path('/D/A1/OZ/wS_S'))
    rule_1 = Rule(str_2, rule_0.match, rule_0.get_new_command, False, None, 0, False)
    rule_0.get_corrected_commands(command_0)
    rule_1.get_corrected_commands(command_1)


# Generated at 2022-06-26 07:18:45.212010
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'x`'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)

    rule_0 = Rule(str_0, test_Rule_match, test_Rule_get_new_command, False, test_Rule_side_effect, DEFAULT_PRIORITY, False)
    if not (rule_0.is_match(command_0) is None):
        logs.error('AssertionError')


# Generated at 2022-06-26 07:18:49.582135
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = 'b|S;>TXQ-=K^G:3q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    corrected_command_0 = CorrectedCommand(str_0, None, 0)
    corrected_command_0.run(command_0)



# Generated at 2022-06-26 07:18:55.325669
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('rule_0', test_case_0, 1, test_case_0, 1, test_case_0, True)
    command_0 = Command('', '')
    assert list(rule_0.get_corrected_commands(command_0)) == []
    logs.debug(rule_0.get_corrected_commands(command_0))
    assert True


# Generated at 2022-06-26 07:19:05.726079
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'bGw7:5k5{\\N7<O'
    command_0 = Command(str_0, str_0)
    str_1 = 'hP_:H;b75A'
    str_2 = '8*v3q4Wi\\4)'
    list_0 = [str_2, str_1]
    str_3 = '8*v3q4Wi\\4)'
    def func_0(command_0):
        return list_0
    rule_0 = Rule(str_1, func_0, func_0, False, (command_0, str_1), 12, True)
    list_1 = rule_0.get_corrected_commands(command_0)
    assert len(list_1) == 2

# Generated at 2022-06-26 07:19:13.064228
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '3fWA2KKgcmh4J^HtRWB-t4vU=n6uyBbDa\\Fy-*q'
    str_1 = '0f0T-T7V8p1MzLu!i/x-Q'
    dict_0 = {str_0: str_0}
    dict_1 = {str_1: str_1}
    command_0 = Command(str_0, dict_0)
    command_1 = Command(str_0, dict_1)
    corrected_command_0 = CorrectedCommand(command_1, None, None)
    corrected_command_1 = CorrectedCommand(command_0, None, None)
    corrected_command_2 = CorrectedCommand(command_1, None, None)
    corrected_command_3 = Correct

# Generated at 2022-06-26 07:19:24.322012
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Assert type of command, Rule, Command and CorrectedCommand
    str_0 = 'F7c%?Y<8Kt'
    dict_0 = {str_0: str_0}
    dict_1 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule = Rule("", "", "", "", "", "", "")
    rule.get_new_command(command_0)
    command_1 = Command(str_0, dict_1)
    rule.is_match(command_1)
    # Assert tuple for corrected commands is returned,
    # and all elements in the tuple are CorrectedCommand
    corrected_commands = rule.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:19:31.392278
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule = Rule(
        'foo',
        match=lambda cmd: True,
        get_new_command=lambda cmd: 'bar',
        enabled_by_default=True,
        side_effect=None,
        priority=1,
        requires_output=True,
    )
    output = [
        CorrectedCommand(script='bar', side_effect=None, priority=1),
    ]
    assert list(rule.get_corrected_commands(Command('baz', ''))) == output


if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:19:35.872413
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = ':y_Nw'
    str_1 = '-X/P&'
    float_0 = float(19.3853)
    str_2 = '2_C6,u'
    str_3 = '`DVzT'
    str_4 = '-Lp('
    str_5 = 'n'
    str_6 = "7;(4=4c%^'S"
    float_1 = float(33.093)
    str_7 = ')>ZJh'
    float_2 = float(2.45949)
    rule_0 = Rule(str_0, match, get_new_command, True, side_effect, DEFAULT_PRIORITY, True)
    assert_equals(rule_0.is_match(command_0), True)

# Generated at 2022-06-26 07:20:38.580418
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule('', '', '', False, '', -90, True)
    rule_0.is_match(command_0)

# vim:st=4 sts=4 sw=4 et syntax=python

# Generated at 2022-06-26 07:20:46.450710
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 't4vU=n6uyBbDa\\Fy-*q'
    dict_0 = {str_0: str_0}
    command_0 = Command(str_0, dict_0)
    repeated_io_error_0 = OSError(errno=errno.EPERM, filename=str_0)
    rule_0 = Rule(str_0, test_case_0, test_case_0, False, test_case_0, repeated_io_error_0, False)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:20:52.758128
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'FpYs*oWF3urM~-L'
    dict_0 = {str_0: str_0}
    int_0 = 0
    command_0 = Command(str_0, dict_0)
    # test 1
    rule_0 = Rule(str_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    function_0 = rule_0.get_corrected_commands
    assert_raises(TypeError, function_0, command_0)

