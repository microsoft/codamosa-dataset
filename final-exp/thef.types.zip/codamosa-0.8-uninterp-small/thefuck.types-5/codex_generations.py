

# Generated at 2022-06-26 07:11:10.223899
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path = pathlib.Path('/home/cphillips/dev/python/fuck/tests/fixtures/match_rule.py')
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0 = Rule.from_path(path)
    bool_0 = rule_0.is_match(command_0)
    assert bool_0 == True


# Generated at 2022-06-26 07:11:18.892389
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    boolean_0 = True
    str_0 = ")"

# Generated at 2022-06-26 07:11:26.625110
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = 1388.88735
    int_0 = 4631
    command_0 = Command(int_0, float_0)
    rule_0 = Rule('Rule', lambda command: command.script == int_0,
                  lambda command: command.script, True, None, None, False)
    list_0 = rule_0.get_corrected_commands(command_0)

    if __name__ == '__main__':
        test_case_0()
        test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:11:30.261519
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    command_1 = Command(int_0, float_0)
    command_2 = Command(int_0, float_0)
    command_3 = Command(int_0, float_0)
    command_4 = Command(int_0, float_0)
    command_5 = Command(int_0, float_0)

    # AssertionError: Parameter 'self' has no 'name' attribute
    assert command_1 == command_2


# Generated at 2022-06-26 07:11:34.795965
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    command_1 = Command(int_0, float_0)
    assert command_0 == command_1


# Generated at 2022-06-26 07:11:44.091118
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script_0 = 4710
    side_effect_0 = 9863
    priority_0 = 7676
    correct_command_0 = CorrectedCommand(script_0, side_effect_0, priority_0)
    name_0 = 4300
    match_0 = 5481
    get_new_command_0 = 8936
    enabled_by_default_0 = 5271
    side_effect_1 = 8280
    priority_1 = 4406
    requires_output_0 = 2978
    rule_0 = Rule(name_0, match_0, get_new_command_0, enabled_by_default_0, side_effect_1, priority_1, requires_output_0)
    command_0 = Command(script_0, enabled_by_default_0)
    rule_0.get_corrected_

# Generated at 2022-06-26 07:11:54.862142
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    expected_value_0 = True
    expected_value_1 = False
    expected_value_2 = True
    expected_value_3 = False
    actual_value_0 = (command_0 == command_0)
    actual_value_1 = (command_0 == command_0)
    actual_value_2 = (command_0 == command_0)
    actual_value_3 = (command_0 == command_0)
    assert expected_value_0 == actual_value_0
    assert expected_value_1 == actual_value_1
    assert expected_value_2 == actual_value_2
    assert expected_value_3 == actual_value_3
    print('command.py: test_Command___eq___0: PASSED')

# Generated at 2022-06-26 07:11:59.840727
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    corrected_command_0 = CorrectedCommand(command_0, int_0, 1358.698511)
    corrected_command_0.run(command_0)


# Generated at 2022-06-26 07:12:06.953125
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4
    float_0 = 1.0
    rule_0 = Rule(int_0, test_case_0, test_case_0, int_0, test_case_0, int_0, int_0)
    command_0 = Command(int_0, float_0)
    correctedcommand_0 = CorrectedCommand(float_0, test_case_0, int_0)
    assert rule_0.get_corrected_commands(command_0) == correctedcommand_0


# Generated at 2022-06-26 07:12:09.856414
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 07:12:22.883703
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    ma_3 = "gV9c!_H.i"
    bool_3 = bool(ma_3)
    bool_1 = bool_3
    str_3 = 'lulz'
    if bool_1:
        str_1 = str_3
        str_2 = str_1
        bool_2 = bool_1
        str_1 = str_2
        str_2 = str_1
        str_1 = str_2


# Generated at 2022-06-26 07:12:26.809800
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    command_0 = Command('less +F', 'bar')
    command_1 = Command('less +F', 'bar')
    bool_0 = command_0 == command_1
    command_2 = Command('', 'bar')
    bool_1 = command_1 == command_2
    
    assert bool_0
    assert not bool_1


# Generated at 2022-06-26 07:12:29.205974
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_name = 'Rule_get_corrected_commands'
    sys.stdout.write(test_case_name)


# Generated at 2022-06-26 07:12:34.522266
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule.from_path(pathlib.Path('.fuckingrules/nothing.py'))
    cmd_0 = Command.from_raw_script(['git', 'log'])
    res_0 = rule_0.is_match(cmd_0)
    assert res_0


# Generated at 2022-06-26 07:12:44.241770
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Create a new Rule with parameters:
    # name = 'test_name'
    # match = 'test_match'
    # get_new_command = 'test_get_new_command'
    # enabled_by_default = 'test_enabled_by_default'
    # side_effect = 'test_side_effect'
    # priority = 'test_priority'
    # requires_output = 'test_requires_output'
    test_Rule = Rule('test_name', 'test_match', 'test_get_new_command',
                     'test_enabled_by_default', 'test_side_effect',
                     'test_priority', 'test_requires_output')

    # Create a new Command with parameters:
    # script = 'test_script'
    # output = 'test_output'

# Generated at 2022-06-26 07:12:56.346541
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import os
    import sys
    import shlex
    from .output_readers import get_output
    from .shells import shell
    from .conf import settings
    from .const import DEFAULT_PRIORITY
    from .exceptions import EmptyCommand
    from .utils import get_alias, format_raw_script
    from .output_readers import get_output

    get_alias()
    format_raw_script()
    get_output()
    settings.priority.get()
    shell.split_command()
    get_output()
    shell.from_shell()
    DEFAULT_PRIORITY
    EmptyCommand
    settings.priority.get()
    get_alias()
    get_output()
    get_output()
    shell.or_()
    settings.alter_history
    sys.stdout.write()


# Generated at 2022-06-26 07:13:03.898722
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    global bool_0, str_0

    # type: () -> None
    def test_case_0():
        str_1 = '\\'
        str_2 = '],.{#OZ(Y|'
        str_3 = 't`iC@I0-:'
        bool_1 = True


    # type: () -> None
    def test_case_1():
        bool_2 = True
        int_0 = 0
        int_1 = -166
        str_4 = '5_1j"S*|>'
        str_5 = ',^:l)'


    # type: () -> None
    def test_case_2():
        str_6 = 'Xlh:0`@Y[}'
        int_2 = -6

# Generated at 2022-06-26 07:13:05.005750
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    pass
    # TODO: implement


# Generated at 2022-06-26 07:13:16.103893
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = 'HI'
    str_1 = 'I'
    str_2 = '{'
    str_3 = 'I'
    str_4 = '&'
    str_5 = str_4
    str_6 = 'g'
    str_7 = 'r'
    str_8 = 'n'
    str_9 = 'a'
    str_10 = 'n'
    str_11 = 't'
    str_12 = 'f'
    str_13 = 'u'
    str_14 = 'c'
    str_15 = 'k'
    str_16 = '-'
    str_17 = 'c'
    str_18 = 'h'
    str_19 = 'e'
    str_20 = 'c'
    str_21 = 'k'
    str

# Generated at 2022-06-26 07:13:23.763616
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:13:36.306674
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    int_1 = 4631
    str_1 = 'l0'
    command_1 = Command(int_1, str_1)
    int_2 = 4631
    str_2 = 'l0'
    command_2 = Command(int_2, str_2)


# Test case generator methods


# Generated at 2022-06-26 07:13:43.968787
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from . import rules
    from .rules import test
    rule_0 = rules.Rule.from_path(test)
    command_0 = Command(1199, 1299)
    def get_new_command(command):
        return command.script
    rule_0.get_new_command = get_new_command

    # Asserts if the expected and actual values are not equal
    assert list(rule_0.get_corrected_commands(command_0)) == [CorrectedCommand(1199, None, 200)]


# Generated at 2022-06-26 07:13:50.140998
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path_0 = os.path.join(os.path.dirname(__file__), '..', 'rules', 'alias_fuck.py')
    rule_0 = Rule.from_path(path_0)
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0.is_match(command_0)


# Generated at 2022-06-26 07:13:59.782849
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = -7155
    float_0 = 0.5147
    int_1 = -823888
    int_2 = 885179
    int_3 = -3265
    int_4 = -59137
    float_1 = 0.39116
    float_2 = 0.2815
    float_3 = 0.63384
    float_4 = 0.21962
    float_5 = 0.26853
    str_0 = 'd'
    str_1 = '8)w'
    str_2 = 'U1T'
    str_3 = 'a'
    str_4 = 'r2<Y'
    int_5 = -504493
    int_6 = -517873
    command_0 = Command(str_4, int_4)
    rule_0

# Generated at 2022-06-26 07:14:06.196948
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_command_0 = Command('echo "hello"', 'hello')
    test_rule_0 = Rule('Hello', lambda command: True, 'get_new_command', True, None, DEFAULT_PRIORITY, True)
    try:
        test_rule_0.get_corrected_commands(test_command_0)
    except Exception:
        logs.exception('Exception when calling Rule.get_corrected_commands')


# Generated at 2022-06-26 07:14:15.424943
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .conf import settings
    from .utils import shell
    from . import logs
    from . import tests
    from .shells import base
    from .shells import bash
    from .shells import fish
    from .shells import zsh
    from .const import ENCODING
    from .output_readers import get_output
    from .shells import shell
    from .shells import base
    from .shells import bash
    from .shells import fish
    from .shells import zsh
    from .exceptions import EmptyCommand
    from .exceptions import InvalidCommandFormat
    from .output_readers import get_output
    from .fixers import get_corrected_commands
    import os
    import re
    import sys
    import tempfile
    import unittest
    from .rules import FuckItException


# Generated at 2022-06-26 07:14:26.173364
# Unit test for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:14:37.169680
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():

    float_0 = -3.08419661825
    float_1 = -2.87956152804
    float_2 = -2.84960925281
    float_3 = -2.25427672444
    float_4 = -1.01421086054
    float_5 = -0.502093972212
    float_6 = -0.455506845982
    float_7 = -0.131855226253
    float_8 = -0.100973194384
    float_9 = -0.0100974065221
    float_10 = 0.0100974065221
    float_11 = 0.100973194384
    float_12 = 0.131855226253
    float_13 = 0.455506845982

# Generated at 2022-06-26 07:14:40.297653
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule(int,
                  bool,
                  bool,
                  bool,
                  bool,
                  0,
                  bool)
    try:
        rule_0.is_match(Command)
        assert True
    except:
        assert False


# Generated at 2022-06-26 07:14:41.174790
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert True


# Generated at 2022-06-26 07:15:07.820710
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 7541
    float_0 = 3085.5948483
    command_0 = Command(int_0, float_0)
    rule_0 = Rule(int_0, int_0, int_0, int_0, int_0)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    assert type(corrected_commands_0) is types.GeneratorType


# Generated at 2022-06-26 07:15:13.505899
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)

    rule_0 = Rule('name 0', match=None, get_new_command=None, enabled_by_default=None, side_effect=None, priority=None, requires_output=None)
    assert rule_0.is_match(command_0)


# Generated at 2022-06-26 07:15:19.361371
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command.from_raw_script([])
    rule_0 = Rule('rule_0', lambda command_1: False,
                  lambda command_1: [], True, lambda command_1, script_1: None,
                  settings.default_priority, True)
    try:
        rule_0.get_corrected_commands(command_0)
    except Exception as inst:
        print(inst)


# Generated at 2022-06-26 07:15:27.083763
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    # rule_0 is a Rule object
    rule_0 = Rule(u'foo', u'bar', u'spline', True, None, DEFAULT_PRIORITY, True)
    # tuple_0 is a tuple object
    tuple_0 = (CorrectedCommand(u'spline', None, (1 * DEFAULT_PRIORITY)),)
    # tuple_1 is a tuple object
    tuple_1 = rule_0.get_corrected_commands(command_0)
    # tuple_2 is a tuple object
    tuple_2 = (CorrectedCommand(u'spline', None, 2 * DEFAULT_PRIORITY),)
    # tuple_3 is a tuple object
   

# Generated at 2022-06-26 07:15:37.856038
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 4777
    int_1 = 7304
    int_2 = 696
    int_3 = 4821
    int_4 = 737
    float_0 = 0.4699
    float_1 = 0.2417
    float_2 = 0.4351
    float_3 = 0.9079
    float_4 = 0.3368
    Command_0 = Command(int_0, float_0)
    Command_1 = Command(int_1, float_1)
    Command_2 = Command(int_2, float_2)
    Command_3 = Command(int_3, float_3)
    Command_4 = Command(int_4, float_4)

# Generated at 2022-06-26 07:15:42.535742
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule('t[0-9]*', 'match', 'get_new_command', True, 'side_effect', 1, True)
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    bool_0 = rule_0.is_match(command_0)


# Generated at 2022-06-26 07:15:49.590137
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_4 = 28561
    bool_0 = False
    float_1 = 0.540168
    str_1 = 'Rule'
    command_0 = Command(int_4, float_1)
    corrected_command_0 = CorrectedCommand(str_1, float_1, bool_0)
    corrected_command_0_list = [corrected_command_0]

    rule_0 = Rule(str_1, float_1, float_1, float_1, float_1, float_1, float_1)
    corrected_command_0_list_0 = rule_0.get_corrected_commands(command_0)

    if (corrected_command_0_list[0] != corrected_command_0_list_0[0]):
        print("parsing error")
        sys.exit

# Generated at 2022-06-26 07:15:58.236412
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = -1034
    str_0 = ''.join(['1', '.'])
    boolean_0 = False
    CorrectedCommand_0 = CorrectedCommand(str_0, boolean_0, int_0)
    int_1 = 1
    CorrectedCommand_1 = CorrectedCommand(str_0, boolean_0, int_1)
    list_0 = [CorrectedCommand_0, CorrectedCommand_1]
    Rule_0 = Rule('rule_0', test_case_0, test_case_0, False, False, 1, True)
    assert Rule_0.get_corrected_commands(Command(int_0, str_0)) == list_0, 'AssertionError'


# Generated at 2022-06-26 07:16:10.414491
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    int_1 = -8868
    float_1 = 6682.012662
    command_1 = Command(int_1, float_1)
    int_2 = -6106
    float_2 = 8810.74982
    command_2 = Command(int_2, float_2)
    int_3 = -3382
    float_3 = 9104.81672
    command_3 = Command(int_3, float_3)
    int_4 = -5407
    float_4 = 1322.120882
    command_4 = Command(int_4, float_4)
    unicode_5 = u'jWxrcvS'


# Generated at 2022-06-26 07:16:17.562096
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    path_0 = pathlib.Path('/home/benjamin/.thefuck/thefuck/rules/arch_linux.py')
    rule_0 = Rule.from_path(path_0)
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    bool_0 = rule_0.is_match(command_0)
    assert bool_0


# Generated at 2022-06-26 07:16:37.732528
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0 = Rule(int_0, int_0, int_0, int_0, int_0, int_0)
    corrected_command_0 = rule_0.get_corrected_commands(command_0)
    assert corrected_command_0 is not None


# Generated at 2022-06-26 07:16:43.367402
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert command_0.output is not None
    assert command_0.script is not None
    assert command_0.script_parts is not None
    assert command_0.stdout is not None
    assert command_0.stderr is not None
    assert command_0.script_parts is not None
    assert command_0 == command_0
    assert command_0 is not None
    assert command_0.__eq__(command_0)
    assert command_0.update() is not None
    assert command_0.__repr__() is not None
    assert command_0.update() is not None
    assert command_0.__repr__() is not None
    assert command_0.update() is not None
    assert command_0.__repr__() is not None
    assert command_0.update() is not None

# Generated at 2022-06-26 07:16:50.379686
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    str_0 = '`'
    rule_0 = Rule(str_0, test_case_0, test_case_0, True, test_case_0, 8187, True)
    assert isinstance(rule_0.get_corrected_commands(command_0), Iterable)


# Generated at 2022-06-26 07:16:57.909712
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    Command.from_raw_script = lambda *args: Command(*args)
    from .utils import get_prefixed_fucks, get_corrected_commands
    from .rules import (args_command, has_alias,
                        has_sudo_error, has_no_such_command,
                        shell_type, has_no_such_file,
                        replace_command, has_sudo,
                        save_f_arg, has_fuck)
    from .shells import POSIX, Bash, Zsh
    import pytest

    Rule.from_path = lambda *args: Rule(*args)
    Rule.is_match = lambda *args: True
    Rule.get_new_command = lambda *args: 'new {}'.format(args[0].script)


# Generated at 2022-06-26 07:17:09.618230
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Call the method with different arguments
    # 
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    str_0 = 'test'
    dict_0 = dict()
    dict_0['test'] = str_0
    dict_0['test_1'] = str_0
    dict_0['test_2'] = str_0
    dict_0['test_3'] = str_0
    dict_0['test_4'] = str_0
    dict_0['test_5'] = str_0
    dict_0['test_6'] = str_0
    dict_0['test_7'] = str_0
    dict_0['test_8'] = str_0

# Generated at 2022-06-26 07:17:14.387775
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    print('Testing is_match')

    # test_case_0
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    try:
        Rule.is_match(command_0)

    except Exception:
        assert False

    return



# Generated at 2022-06-26 07:17:20.115353
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0 = Rule.from_path(pathlib.Path('/home/benkurtovic/PycharmProjects/autofuck/autofuck/rules/f_ck.py'))
    pri_0 = rule_0.is_match(command_0)
    assert pri_0 == False



# Generated at 2022-06-26 07:17:27.746866
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    str_0 = 'test_Rule_get_corrected_commands'
    int_1 = 245
    rule_0 = Rule(str_0, match, get_new_command, enabled_by_default, side_effect, int_1, requires_output)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    corrected_command_0 = next(corrected_commands_0)
    corrected_command_1 = next(corrected_commands_0)
    corrected_command_2 = next(corrected_commands_0)
    corrected_command_3 = next(corrected_commands_0)
# Unit test

# Generated at 2022-06-26 07:17:38.587952
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule = Rule(
        name='name_0',
        match=lambda command: True,
        get_new_command=lambda command: 'new_command_0',
        side_effect=lambda command, new_command: None,
        priority=8)
    int_0 = 1572
    float_0 = 2678.593
    command_0 = Command(int_0, float_0)

    corrected_command_0 = rule.get_corrected_commands(command_0).__next__()

    assert isinstance(corrected_command_0, CorrectedCommand)
    assert corrected_command_0 == CorrectedCommand(
        script='new_command_0',
        side_effect=lambda command, new_command: None,
        priority=8)



# Generated at 2022-06-26 07:17:42.043191
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = test_case_0()
    int_0 = 6538
    rule_0 = Rule(int_0, None, None, None, None, None, None)
    rules_0 = rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:18:27.575228
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = Rule.from_path('test/test_data/test_rules/test_test_case_12')
    int_0 = 1944.5
    command_0 = Command.from_raw_script([int_0])
    CorrectedCommand_0 = CorrectedCommand(int_0, str_0.side_effect, str_0.priority)
    Rule_0 = Rule('test_test_case_12', str_0.match, str_0.get_new_command,
                  True, str_0.side_effect, str_0.priority, True)

    # test class CorrectedCommand
    CorrectedCommand_1 = CorrectedCommand(int_0, str_0.side_effect, str_0.priority)

    # check if the returned commands are CorrectedCommand instances

# Generated at 2022-06-26 07:18:34.585519
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('rule_0', lambda command: None, lambda corrected_command: None, True, lambda command, corrected_command: None, 4065, True)
    command_0 = Command(0, 'command_0')
    sum((CorrectedCommand(corrected_command_0.script, corrected_command_0.side_effect, corrected_command_0.priority) for corrected_command_0 in rule_0.get_corrected_commands(command_0)))


# Generated at 2022-06-26 07:18:44.265821
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    float_0 = 25.24479859
    float_1 = -23.3
    int_0 = 3716
    int_1 = -30
    int_2 = 3713
    int_3 = 3713
    function_0 = lambda command_0 : command_0 == command_0
    function_1 = lambda command_0 : command_0 == command_0
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_5['priority'] = float_0
    dict_4['priority'] = float_1
    dict_3['priority'] = int_0
    dict_2['priority'] = int_1
    dict_1['priority'] = int_2
   

# Generated at 2022-06-26 07:18:46.683310
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Setup for the test
    rule_0 = Rule()
    command_1 = Command()

    # Testing the method
    rule_0.is_match(command_1)


# Generated at 2022-06-26 07:18:54.846274
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command.from_raw_script(['ls', '-la'])
    rule_0 = Rule.from_path(pathlib.Path('ls.py'))
    corrected_commands_0 = list(rule_0.get_corrected_commands(command_0))
    script_0 = corrected_commands_0[0].script
    print(script_0)
    assert script_0 == 'ls -l --color=auto'

if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:19:00.821458
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0 = Rule('', '', '', True, '', 4, True)
    # Function get_corrected_commands is not available for Rule
    assert_raises(NotImplementedError, rule_0.get_corrected_commands, command_0)


# Generated at 2022-06-26 07:19:04.017823
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)


# Generated at 2022-06-26 07:19:10.020541
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    rule_0 = Rule.from_path(settings.rules_path[0])
    correct_0 = rule_0.get_corrected_commands(command_0)
    print(rule_0, correct_0)
    return 0

# Print the doc if runned by python interpreter
if __name__ == '__main__':
    import os, sys
    help(os, sys)

# Generated at 2022-06-26 07:19:21.216481
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '+sxG>/0'
    str_1 = '$^<&+@\\'
    int_0 = 9659
    float_0 = 636.8155
    str_2 = 'f2'
    str_3 = '|S'
    str_4 = 'T8'
    str_5 = 'H: '
    str_6 = 'QZ'
    str_7 = 'a'
    str_8 = 'f-G'
    str_9 = 'Ma'
    str_10 = '9'
    bool_0 = True
    def function_0(argument_0):
        if ((argument_0 is not None) and (isinstance(argument_0.output, float))):
            return True
        else:
            return False


# Generated at 2022-06-26 07:19:27.368566
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule = Rule('', None, None, False, None, 3, False)
    command_0 = Command(4631, 7993.5546)
    expected = Rule.get_corrected_commands(rule, command_0)
    actual = (CorrectedCommand(script=4631, side_effect=None, priority=3),)
    assert expected == actual, 'failedRule.get_corrected_commands:%s' % repr(expected)


# Generated at 2022-06-26 07:20:53.390109
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 4631
    float_0 = 1388.88735
    command_0 = Command(int_0, float_0)
    print(Rule.is_match)
    # test for TypeError exception
    with pytest.raises(TypeError):
        Rule.is_match(command_0)


# Generated at 2022-06-26 07:20:58.378554
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    float_0 = float('2.282045')
    int_0 = int('9')
    str_0 = str(')\tjh")\tnmA')
    command_0 = Command(script = int_0, output = float_0)
    rule_0 = Rule(name = str_0, match = None, get_new_command = None, enabled_by_default = None, side_effect = None, priority = None, requires_output = None)
    for corrected_command_0 in rule_0.get_corrected_commands(command_0):
        pass