

# Generated at 2022-06-26 07:11:11.061949
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    from .shells import get_default_shell
    from .output_readers import NullReader
    from .utils import get_current_shell
    path_0 = Path('/tmp/fixer/tests/basic.py')
    rule_0 = Rule.from_path(path_0)
    old_cmd_0 = Command.from_raw_script([])
    logs.debug_time = MagicMock()
    logs.rule_failed = MagicMock()
    result = rule_0.get_corrected_commands(old_cmd_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 07:11:16.897281
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    int_0 = 1080
    corrected_command_0 = CorrectedCommand(int_0, None, None)
    corrected_command_1 = CorrectedCommand(int_0, None, None)

    rule_0 = Rule(corrected_command_0, corrected_command_1)
    rule_1 = Rule(corrected_command_0, corrected_command_1)

    bool_0 = rule_0 == rule_1
    bool_1 = rule_1 == rule_0



# Generated at 2022-06-26 07:11:19.339061
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule('argcount', None, None, False, None, 0, False)
    command_0 = Command(script=None, output=None)
    assert rule_0.is_match(command_0) == False



# Generated at 2022-06-26 07:11:26.175730
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    command_0 = Command('/usr/bin/python -c \'print "hello"\'', 'hello\n')
    rule_0 = Rule('test-rule', test_case_0, test_case_0, True, test_case_0, 1, True)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    for c in corrected_commands_0:
        logs.debug(u'{}'.format(c))


# Generated at 2022-06-26 07:11:29.744925
# Unit test for method __eq__ of class Command
def test_Command___eq__():
    int_0 = 103
    dict_0 = None
    str_0 = "{5':"
    command = Command(int_0, dict_0, str_0)
    bool_0 = False
    if (not(command == bool_0)):
        test_case_0()


# Generated at 2022-06-26 07:11:33.609812
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = {}
    rule_0 = Rule('str_0', int_0, int_0, False, int_0, 0, False)
    corrected_command_0 = CorrectedCommand('str_0', None, 'str_0')
    str_0 = rule_0.is_match(corrected_command_0)
    assert str_0 == False



# Generated at 2022-06-26 07:11:39.188538
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    dict_0 = None
    str_0 = '.'
    rule_0 = Rule(dict_0, None, str_0, str_0, str_0, dict_0, dict_0)
    assert not rule_0.is_match(dict_0)
    assert rule_0.is_match(str_0)


# Generated at 2022-06-26 07:11:45.584849
# Unit test for method is_match of class Rule

# Generated at 2022-06-26 07:11:56.357131
# Unit test for method __eq__ of class Rule
def test_Rule___eq__():
    int_0 = 1080
    int_1 = 1080
    int_2 = 285
    str_0 = "{5':"
    str_1 = "{5':"
    rule_0 = Rule(int_0, int_1, int_2, False, str_0, int_0, False)
    rule_1 = Rule(int_1, int_1, int_2, False, str_0, int_0, False)
    rule_2 = Rule(int_1, int_1, int_2, False, str_0, int_0, False)
    rule_3 = Rule(int_2, int_1, int_1, False, str_0, int_0, False)

# Generated at 2022-06-26 07:11:57.528177
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    test_case_0()

# Generated at 2022-06-26 07:12:11.423403
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '/tmp/fixer/tests/basic.py'
    var_0 = []
    var_0.append(CorrectedCommand(None, None, None))
    print(var_0[0])

# Generated at 2022-06-26 07:12:13.118899
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert Rule.get_corrected_commands() == None


# Generated at 2022-06-26 07:12:15.786679
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    assert isinstance(Rule, object)
    str_0 = '/tmp/fixer/tests/basic.py'
    var_0 = []


# Generated at 2022-06-26 07:12:25.546622
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    var_1 = CorrectedCommand(script=str_0, side_effect=lambda x, y: None, priority=1)
    var_2 = CorrectedCommand(script=str_0, side_effect=lambda x, y: None, priority=1)
    var_3 = CorrectedCommand(script=str_0, side_effect=lambda x, y: None, priority=0)
    var_4 = CorrectedCommand(script=str_0, side_effect=str_0, priority=1)
    var_5 = CorrectedCommand(script=str_0, side_effect=var_4, priority=1)
    var_6 = None
    var_7 = 1
    var_8 = CorrectedCommand(script=str_0, side_effect=lambda x, y: None, priority=1)

# Generated at 2022-06-26 07:12:37.727681
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '/tmp/fixer/tests/basic.py'

# Generated at 2022-06-26 07:12:45.792868
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '/tmp/fixer/tests/basic.py'
    str_1 = '/tmp/fixer/tests/basic.py'
    str_2 = '/tmp/fixer/tests/basic.py'
    var_0 = []
    var_1 = []
    var_2 = []
    var_0 = load_source('basic', str_0)
    var_1 = load_source('basic', str_1)
    var_2 = load_source('basic', str_2)
    var_3 = Rule(var_0, var_1, var_2, 2, True, 2, True)
    str_3 = 'basic'
    str_4 = 'basic'
    str_5 = 'basic'
    var_4 = Command(str_3, str_4)

# Generated at 2022-06-26 07:12:47.801180
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    assert 1



# Generated at 2022-06-26 07:12:49.230500
# Unit test for method __eq__ of class CorrectedCommand
def test_CorrectedCommand___eq__():
    assert (var_0.__eq__(var_0) == True)


# Generated at 2022-06-26 07:12:59.694460
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = '<function <lambda> at 0x7f38eec0c0d0>'
    var_0 = Rule.from_path(os.path.join(os.path.dirname(__file__), '../rules/case.py'))
    # AssertionError: assert not False
    # assert not False
    str_1 = '<function <lambda> at 0x7f38eec0c0d0>'
    str_2 = '<function <lambda> at 0x7f38eec0c0d0>'
    var_1 = Rule.from_path(os.path.join(os.path.dirname(__file__), '../rules/case.py'))
    assert not var_1.get_corrected_commands(None) == var_0.get_correct

# Generated at 2022-06-26 07:13:11.726613
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    var_0 = Rule()
    var_1 = Command()
    var_2 = CorrectedCommand(var_1, var_0, 1)
    var_3 = 'get_corrected_commands'
    var_4 = (
        lambda var_0, var_1: var_2,
    )
    var_5 = var_0.get_corrected_commands(var_1)
    var_6 = (var_2,)
    var_7 = var_5
    var_7 = var_6
    var_6 = var_6
    var_5 = var_5
    var_7 = var_6
    var_7 = var_5
    var_6 = var_6
    var_5 = var_5
    var_7 = var_6
    var_7 = var_5


# Generated at 2022-06-26 07:13:28.716175
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule(None, None, None, False, None, None, False)
    command_0 = Command(None, None)
    get_corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    #get_corrected_commands_0 = iter(get_corrected_commands_0)
    #get_corrected_commands_0.next()


# Generated at 2022-06-26 07:13:36.982834
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule(str_0, dict_0, int_0, dict_0, dict_0, dict_0, dict_0)
    command_0 = Command('\xe7\x97\x9b\xe9\x9f\xbf\xe9\xaa\x8c', None)
    corrected_command_0 = CorrectedCommand(10729, dict_0, dict_0)

    corrected_command_0_output = rule_0.get_corrected_commands(command_0)

    # Exception test for get_corrected_commands with Exception raised
    assert corrected_command_0_output == corrected_command_0


# Generated at 2022-06-26 07:13:39.891515
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0, command_0 = Rule(), Command()
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:13:44.273052
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test case 1
    rule_0 = Rule("", test_case_0, test_case_0)
    command_0 = Command("", "")

    # Run the test
    # corrected_command_0 = rule_0.get_corrected_commands(command_0)



# Generated at 2022-06-26 07:13:50.909596
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    rule_0 = Rule('rule_0', dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    command_0 = Command(float_0, float_0)
    rule_1 = Rule(float_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    corrected_command_0 = rule_1.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:13:57.255965
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_0 = "("
    int_0 = 653
    str_1 = "2"
    rule_0 = Rule(str_0, int_0, int_0, int_0, int_0, int_0, int_0)
    command_0 = Command(str_0, str_1)
    var_0 = rule_0.get_corrected_commands(command_0)
    var_1 = next(var_0)



# Generated at 2022-06-26 07:13:59.899193
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    import inspect
    from . import rules

    for rule_name in map(lambda x: x.name, inspect.getmembers(rules)):
        rule = Rule(name=rule_name)
        assert not rule.get_corrected_commands(None)

# Generated at 2022-06-26 07:14:01.298164
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    test_case_0()



# Generated at 2022-06-26 07:14:11.439537
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)

    int_1 = 0
    int_2 = 6
    int_3 = 0
    int_4 = 2
    int_5 = 0
    float_0 = 0.191
    float_1 = 0.191
    float_2 = 0.191
    object_0 = Rule(int_1, int_2, int_3, int_4, int_5, float_0, float_1, float_2)

    try:
        object_0.is_match(corrected_command_0)
        assert False
    except Exception:
        assert True

## Unit tests for the function is_match

# Generated at 2022-06-26 07:14:16.713550
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    str_0 = b'DdJ9T\x85\xd0\xdd\xf7\x05\xe4'
    boolean_0 = 0
    int_0 = 1000
    int_1 = 100
    float_0 = 2.31
    int_2 = 0
    set_0 = {int_0, int_1, float_0}
    corrected_command_0 = CorrectedCommand(set_0, boolean_0, int_2)
    corrected_command_0.run(str_0)

# Generated at 2022-06-26 07:14:36.630506
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = dict()
    dict_0['A'] = 48
    dict_0['B'] = 47
    dict_0['C'] = 46
    dict_0['D'] = 45
    dict_0['E'] = 44
    dict_0['F'] = 43
    dict_0['G'] = 42
    dict_0['H'] = 41
    dict_0['I'] = 40
    dict_0['J'] = 39
    dict_0['K'] = 38
    dict_0['L'] = 37
    dict_0['M'] = 36
    dict_0['N'] = 35
    dict_0['O'] = 34
    dict_0['P'] = 33
    dict_0['Q'] = 32
    dict_0['R'] = 31
    dict_0['S'] = 30
   

# Generated at 2022-06-26 07:14:40.348556
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1420
    dict_0 = None
    str_0 = '@'
    command_0 = Command(int_0, dict_0)
    rule_0 = Rule(dict_0, test_case_0, test_case_0, True, test_case_0, int_0, str_0)
    rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:14:44.904418
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_0.run(int_0)


# Generated at 2022-06-26 07:14:56.236670
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    script = 'script'
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    side_effect = None
    priority = 0
    requires_output = True
    # START_OF_EXTERNAL_CODE_REMOVE
    def get_new_command(old_cmd):
        return [old_cmd.script]
    # END_OF_EXTERNAL_CODE_REMOVE
    int_1 = 1080
    dict_1 = None
    str_1 = "{5':"
    corrected_command_1 = CorrectedCommand(int_1, dict_1, str_1)
    side_effect = None
    priority = 0
    requires_output = True
   

# Generated at 2022-06-26 07:15:00.101420
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    command_0 = Command("command", "{}" )
    rule_0 = Rule("rule_0", rule_0.match, rule_0.get_new_command, True, None, 1, rule_0.requires_output)
    rule_0.is_match(command_0)


# Generated at 2022-06-26 07:15:06.103716
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = dict()
    dict_0[u'EMC0'] = None
    dict_0[u'vN0'] = None
    dict_0[u'8SSU'] = u'f\x9a\xab\x8b'
    dict_0[u'Zc0'] = u'!EP\x98\x9d\x8b'
    dict_0[u'kh0'] = u'\x8d\x00\x00\x00\x00\x8a,\x00\x00'
    dict_0[u'U6'] = None
    dict_0[u'x\x0c'] = True
    dict_0[u'_\x84'] = u'\x9f\xab\x8b'

# Generated at 2022-06-26 07:15:15.392604
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    file_path = pathlib.Path(__file__)
    file_dir = file_path.parent
    rule_file_path = file_dir.joinpath("rules/git_push_current_branch.py")
    rule = Rule.from_path(rule_file_path)

    if isinstance(rule, Rule):
        command_0 = Command(script=[], output=None)
        if rule.is_match(command_0):
            corrected_command = rule.get_corrected_commands(command_0)
            print(type(corrected_command))
        else:
            print("Cannot match command")
    else:
        print("Cannot load rule")


# Generated at 2022-06-26 07:15:19.844590
# Unit test for method is_match of class Rule

# Generated at 2022-06-26 07:15:25.058592
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    command_0 = Command("script", "output")
    rule_0 = Rule("name", None, None, True, None, False, None)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:15:31.607659
# Unit test for method run of class CorrectedCommand
def test_CorrectedCommand_run():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    command_0 = Command("#! /usr/bin/env python", "")

    # Testing if command_0 is of type Command
    if not isinstance(command_0, Command):
        return False

    corrected_command_0.run(command_0)
    return True


# Generated at 2022-06-26 07:15:48.266271
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    print(u'test_Rule_get_corrected_commands')
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_1 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_2 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_3 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_4 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_5 = CorrectedCommand(int_0, dict_0, str_0)

# Generated at 2022-06-26 07:15:53.319052
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    for rule in _load_rules():
        if not rule.is_match(arg_0):
            assert False, 'Rule.is_match() test failed'


# Generated at 2022-06-26 07:15:55.728252
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert(Rule.get_corrected_commands is not None)
    # TODO:  Test logic for method get_corrected_commands of class Rule

# Generated at 2022-06-26 07:15:58.875346
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    script_0 = list()
    output_0 = '$'
    rule_0 = Rule()
    command_0 = Command(script_0, output_0)
    test_case_0()


# Generated at 2022-06-26 07:16:05.258603
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    str_1 = 'he\rll\r'
    list_0 = [str_1]
    rule_0 = Rule(str_1, list_0, list_0, get_output, str_1, str_1, get_output)
    command_0 = Command(str_1, str_1)
    rule_0.get_corrected_commands(command_0)


# Generated at 2022-06-26 07:16:07.324480
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # TODO: Create unit test for method get_corrected_commands of class Rule
    pass


# Generated at 2022-06-26 07:16:14.694001
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    path_0 = "fuckit is best rule"
    rule_0 = Rule.from_path(path_0)
    command_0 = Command(2, None)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)
    bool_0 = isinstance(corrected_commands_0, list)

# Generated at 2022-06-26 07:16:24.146138
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)

    tuple_0 = (corrected_command_0, corrected_command_0, corrected_command_0)

    int_1 = 1080
    dict_1 = None
    str_1 = "{5':"
    corrected_command_1 = CorrectedCommand(int_1, dict_1, str_1)
    
    rule_0 = Rule(str_1, str_0, int_0, dict_1, str_1, int_0, int_1)

    command_0 = Command("echo milhouse", None)

    # rule_0.get_corrected_commands(command_0)

    # assert((tuple

# Generated at 2022-06-26 07:16:32.021740
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    with logs.debug_time('test_Rule_get_corrected_commands == started'):
        rule_0 = Rule.from_path(settings.get_rule_path('apply'))
        rule_1 = Rule.from_path(settings.get_rule_path('export'))
        list_0 = [rule_0, rule_1]
        for element_0 in list_0:
            list_1 = []
            for element_1 in list_1:
                pass


# Generated at 2022-06-26 07:16:36.799275
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = Command("", "")
    str_0 = " {'0':"
    rule_0 = Rule(str_0, None, None, False, None, 0, False)
    corrected_command_0 = rule_0.get_corrected_commands(int_0)
    del corrected_command_0


# Generated at 2022-06-26 07:16:59.589862
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Tests for get_corrected_commands
    print("Testing get_corrected_commands:")
    import options
    import os
    import re
    import imp
    import pathlib
    import sys
    import random
    import scripts.lib.rules
    import scripts.lib.rules.has_alias

    if settings.debug:
        settings.alter_history = True
        settings.repeat = True
    else:
        settings.alter_history = False
        settings.repeat = True

    command_0 = Command(str_0, str_1)
    is_match_0 = rule_0.is_match(command_0)
    if not is_match_0:
        sys.exit(1)
    corrected_commands_0 = rule_0.get_corrected_commands(command_0)

# Generated at 2022-06-26 07:17:09.462366
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Initialize Rule Object with rule_module.requires_output as True
    str_0 = "^!{Add a text here to be added at end of sentence.#}$"
    str_1 = "^!{Add a text here to be added at end of sentence.#}$"
    bool_0 = True
    str_2 = "^!{Add a text here to be added at end of sentence.#}$"
    bool_1 = True
    rule_obj = Rule(str_0, str_1, bool_0, bool_1)
    # Assertion Error : invalid command is passed.
    try:
        rule_obj.is_match(str_2)
    except:
        pass

# Generated at 2022-06-26 07:17:19.287286
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    int_1 = -629
    dict_1 = (None,)
    str_1 = "Cannot parse command: "
    corrected_command_1 = CorrectedCommand(int_1, dict_1, str_1)
    int_2 = -1862
    dict_2 = None
    str_2 = '6666'
    corrected_command_2 = CorrectedCommand(int_2, dict_2, str_2)
    int_3 = -1041
    dict_3 = None
    str_3 = 'ecommerce'

# Generated at 2022-06-26 07:17:27.324359
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = dict()
    dict_0 = {'': 'l"\\"3c%k8mKUy-6w,n6T=Q]|sWf+Z(>'}
    get_new_command_0 = dict_0
    priority_0 = '=2sKL|>PvCp&6-"A1;{pG{NPKj!xw""R'
    match_0 = None
    enabled_by_default_0 = 'r;*t<\\y7xQ/|\\!3)@4h?C5Z7z,_+R'
    side_effect_0 = None
    name_0 = 'e#%_:chpczixnh<{-m]?mTYQD$Pt2.y)>'
    rule_0

# Generated at 2022-06-26 07:17:35.900289
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    rule_0 = Rule(str_0, str_0, str_0, False, str_0, int_0, False)
    rule_1 = Rule(str_0, str_0, str_0, False, str_0, int_0, False)

    # Test method with type 'Command'
    with pytest.raises(Exception):
        rule_1.get_corrected_commands(command = 'Command')


# Generated at 2022-06-26 07:17:45.450576
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    
    int_1 = 1080
    dict_1 = None
    str_1 = "{5':"
    corrected_command_1 = CorrectedCommand(int_1, dict_1, str_1)
    
    int_2 = 1080
    dict_2 = None
    str_2 = "{5':"
    corrected_command_2 = CorrectedCommand(int_2, dict_2, str_2)
    
    int_3 = 1080
    dict_3 = None
    str_3 = "{5':"
    corrected_command_3 = CorrectedCommand(int_3, dict_3, str_3)
    

# Generated at 2022-06-26 07:17:48.955135
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    assert Rule.get_corrected_commands(dict_0, command_0) == None


# Generated at 2022-06-26 07:17:56.640326
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    # Setup
    int_0 = 1080
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, str_0, str_0)
    command_0 = Command(corrected_command_0, int_0)
    rule_0 = Rule(int_0, str_0, str_0, int_0, int_0, int_0, int_0)
    # Actual
    actual_0 = rule_0.is_match(command_0)
    # Assertion
    assert actual_0 == int_0
    # Cleanup


# Generated at 2022-06-26 07:18:07.453751
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = None
    dict_1 = None
    str_0 = "K3qc%)"
    str_1 = "NZP#R"
    str_2 = "z{'0D1V"
    str_3 = "s-1@,"
    dict_2 = {}
    dict_2["F{zASD+V"] = False
    dict_2["w{zASD+V"] = True
    dict_2["gB-;&Kj+3"] = False
    dict_2["`[K=Nu8$Q"] = False
    dict_2["a-;&Kj+3"] = True
    dict_2["`hq|U`+{S"] = True
    dict_2["-*o]|'y4j"] = False

# Generated at 2022-06-26 07:18:19.901197
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = -73
    dict_0 = list()
    str_0 = "]"
    command_0 = Command(dict_0, str_0)
    set_0 = {command_0}
    function_0 = set_0.pop
    int_1 = 0
    boolean_0 = True
    priority_0 = CorrectedCommand.priority
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_1 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_2 = CorrectedCommand(int_0, dict_0, str_0)
    corrected_command_3 = CorrectedCommand(int_0, dict_0, str_0)

# Generated at 2022-06-26 07:18:58.494766
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    basestring_0 = get_corrected_commands(rule, command)
    if CorrectedCommand is not basestring_0:
        print("test_Rule_get_corrected_commands: Failed: {} is not a CorrectedCommand".format(basestring_0))



# Generated at 2022-06-26 07:19:06.113853
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    int_0 = 2
    dict_0 = None
    str_0 = "rule"
    str_1 = "rule"
    rule_0 = Rule(int_0, dict_0, str_0, str_0, str_1, str_1, str_1)
    command_0 = Command(str_1, str_1)
    str_2 = "rule"
    corrected_command = CorrectedCommand(str_2, str_1, str_1)
    print(rule_0.is_match(command_0))


# Generated at 2022-06-26 07:19:12.293699
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    Rule_0 = Rule(str_0, list_0, tuple_0, float_0, dict_0, float_0, float_0)
    CorrectedCommand_0 = Rule_0.get_corrected_commands(command_0)
    CorrectedCommand_1 = CorrectedCommand(script_0, side_effect_0, priority_0)

    # assert that CorrectedCommand_0 is of type CorrectedCommand type
    assert isinstance(CorrectedCommand_0, CorrectedCommand)
    # assert that CorrectedCommand_0 is of type CorrectedCommand type
    assert isinstance(CorrectedCommand_1, CorrectedCommand)


# Generated at 2022-06-26 07:19:22.901701
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = -4
    tuple_0 = (7,)
    set_0 = {1, 1, 2}
    corrected_command_0 = CorrectedCommand(int_0, tuple_0, set_0)
    rule_0 = Rule("", "{_", corrected_command_0.__eq__,
                  corrected_command_0.__gt__,
                  corrected_command_0.side_effect,
                  corrected_command_0.priority, tuple_0)
    command_0 = Command("", "")
    corrected_command_1 = rule_0.get_corrected_commands(command_0)

if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:19:31.645274
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    int_0 = 1080
    dict_0 = None
    str_0 = "{5':"
    corrected_command_0 = CorrectedCommand(int_0, dict_0, str_0)
    str_1 = "rule_"
    bool_0 = True
    function_0 = rule_.match
    function_1 = rule_.get_new_command
    iterable_0 = [function_0, function_1]
    command_0 = Command(*iterable_0)
    function_2 = rule_.side_effect
    bool_1 = False
    int_1 = -513
    rule_0 = Rule(str_1, function_0, function_1, bool_0, function_2, int_1, bool_1)
    tuple_0 = (corrected_command_0,)
    iterable_1 = rule

# Generated at 2022-06-26 07:19:38.900648
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    get_new_command, str_0, dict_0, int_0 = None, "", "", 1080
    match = dict_0
    command_0 = Command(str_0, dict_0)
    rule_0 = Rule(str_0, match, get_new_command, dict_0, dict_0, dict_0, dict_0)
    actual = rule_0.get_corrected_commands(command_0)
    expected = iter([CorrectedCommand(str_0, dict_0, dict_0)])
    Assert.equal(expected, actual)

if __name__ == '__main__':
    test_case_0()
    test_Rule_get_corrected_commands()

# Generated at 2022-06-26 07:19:51.029733
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # noinspection PyUnusedLocal
    def side_effect_rule_get_corrected_commands(command_0, script_0):
        # noinspection PyUnresolvedReferences
        str_0 = str(script_0)
    # noinspection PyUnusedLocal
    def match_rule_get_corrected_commands(command_0):
        # noinspection PyUnresolvedReferences
        int_0 = int(command_0)
    # noinspection PyUnusedLocal
    def get_new_command_rule_get_corrected_commands(command_0):
        # noinspection PyUnresolvedReferences
        dict_0 = dict(command_0)

# Generated at 2022-06-26 07:19:59.959394
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    dict_0 = None
    rule_0 = Rule(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    dict_1 = {
        'priority': 824,
    }
    corrected_command_0 = CorrectedCommand(dict_1)
    list_0 = [
        corrected_command_0,
    ]
    value_0 = rule_0.get_corrected_commands(dict_0)
    value_1 = list_0
    if value_0 is not None:
        condition_0 = value_0 == value_1
    else:
        condition_0 = False
    return condition_0



# Generated at 2022-06-26 07:20:04.387087
# Unit test for method is_match of class Rule
def test_Rule_is_match():
    rule_0 = Rule("{'0':" , test_0_match, test_0_get_new_command, True, test_0_side_effect, test_0_priority, True)
    cmd_0 = Command("{'0':" , None)
    flag_0 = rule_0.is_match(cmd_0)
    assert (flag_0 == True)


# Generated at 2022-06-26 07:20:06.641732
# Unit test for method get_corrected_commands of class Rule
def test_Rule_get_corrected_commands():
    # Test case #0
    test_case_0()

