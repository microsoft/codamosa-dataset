

# Generated at 2022-06-22 13:40:40.902344
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='Test', version='1.0')
    assert len(c) == 3


# Generated at 2022-06-22 13:40:48.594789
# Unit test for function set_constant
def test_set_constant():
    def test_func():
        pass

    vars = {}
    set_constant('test_string', 'value_string', vars)
    set_constant('test_integer', 1, vars)
    set_constant('test_func', test_func, vars)

    assert vars['test_string'] == 'value_string'
    assert vars['test_integer'] == 1
    assert vars['test_func'] == test_func

# Generated at 2022-06-22 13:40:57.337117
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant((1, 2, 3), 'Test message', 'version')
    # Check if TypeError is raised for wrong type
    try:
        _DeprecatedSequenceConstant((1, 2, 3), 1, 'version')
        raise AssertionError('_DeprecatedSequenceConstant constructor must raise TypeError TypeError if msg is not type string')
    except TypeError:
        pass
    try:
        _DeprecatedSequenceConstant((1, 2, 3), 'Test message', 1)
        raise AssertionError('_DeprecatedSequenceConstant constructor must raise TypeError TypeError if version is not type string')
    except TypeError:
        pass

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:41:07.835346
# Unit test for function set_constant
def test_set_constant():
    global _ACTION_IMPORT_PLAYBOOK, _ACTION_IMPORT_ROLE
    global _ACTION_IMPORT_TASKS, _ACTION_INCLUDE
    global _ACTION_INCLUDE_ROLE, _ACTION_INCLUDE_TASKS
    global _ACTION_SETUP
    global _ACTION_ALL_INCLUDES, _ACTION_ALL_INCLUDE_IMPORT_TASKS
    global _ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES, _ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    global _ACTION_ALL_INCLUDE_ROLE_TASKS, _ACTION_ALL_INCLUDE_TASKS
    global _ACTION_FACT_GATHERING
    global CONFIGURABLE_PLUGINS
   

# Generated at 2022-06-22 13:41:10.571322
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "test", "2.10")) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], "test", "2.10")[2] == 3

# Generated at 2022-06-22 13:41:12.740741
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 13:41:15.180454
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], 'msg', 'version')) == 2


# Generated at 2022-06-22 13:41:17.664867
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant(list(range(1, 10)), None, None)
    assert len(l) == 9

# Generated at 2022-06-22 13:41:25.691123
# Unit test for function set_constant
def test_set_constant():
    _const_dict = {}
    _const_dict['first_constant'] = 42
    _const_dict['second_constant'] = '43'
    _const_dict['third_constant'] = True
    for name, value in _const_dict.items():
        set_constant(name, value, export=_const_dict)
        assert _const_dict[name] == value

# Generated at 2022-06-22 13:41:33.202426
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class _ContainerConstantStub(object):
        def __init__(self):
            self.items = ['one', 'two', 'three']

    container = _ContainerConstantStub()
    deprecated_sequence = _DeprecatedSequenceConstant(container.items, 'Test message', '2.2')
    assert len(container.items) == len(deprecated_sequence)



# Generated at 2022-06-22 13:41:39.246044
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(test) == 3
    assert test[1] == 'b'

# Generated at 2022-06-22 13:41:45.311974
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    set_constant('TEST_LIST', ['item1', 'item2', 'item3'])
    list_constant = _DeprecatedSequenceConstant(value=TEST_LIST, msg="This is a deprecated constant", version='2.12')
    assert len(list_constant) == 3


# Generated at 2022-06-22 13:41:51.259671
# Unit test for function set_constant
def test_set_constant():
    import sys
    if 'ansible.config.constants' in sys.modules:
        del sys.modules['ansible.config.constants']
    from ansible.config.constants import set_constant
    constant_data = dict()
    set_constant('ANSIBLE_TEST_CONSTANT', 3, constant_data)
    assert constant_data['ANSIBLE_TEST_CONSTANT'] == 3
    set_constant('ANSIBLE_TEST_CONSTANT', 'hello', constant_data)
    assert constant_data['ANSIBLE_TEST_CONSTANT'] == 'hello'


# MISC PYTHON BEHAVIOR SETTINGS ###

# Generated at 2022-06-22 13:41:57.265160
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert globals()['foo'] == 'bar'
    set_constant('foo', 'bar')
    assert globals()['foo'] == 'bar'
    set_constant('foo', 'baz')
    assert globals()['foo'] == 'baz'
    assert globals()['foo'] == 'baz'

# Generated at 2022-06-22 13:41:58.608325
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 2)
    assert foo == 2


# Generated at 2022-06-22 13:42:01.833515
# Unit test for function set_constant
def test_set_constant():
    def foo():
        pass

    set_constant('foo', foo, export=vars())
    assert(foo == foo)

# Generated at 2022-06-22 13:42:08.589380
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = "This option is deprecated and will be removed in a future release. Deprecated since 2.10."
    _test = _DeprecatedSequenceConstant(value=["foo", "bar", "baz"], msg=expected, version="2.10")
    assert _test[_test.__len__() - 1] == "baz"
    assert _test[1] == "bar"

# Generated at 2022-06-22 13:42:13.051075
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.parsing import _DeprecatedSequenceConstant

    dsc = _DeprecatedSequenceConstant([1,2,3],"test message","v2.10")
    assert dsc[1] == 2


# Generated at 2022-06-22 13:42:16.712661
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    dsc = _DeprecatedSequenceConstant([1,5,7], 'msg', '1.0')
    assert dsc[0] == 1
    assert dsc[1] == 5
    assert dsc[2] == 7



# Generated at 2022-06-22 13:42:19.155633
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq = _DeprecatedSequenceConstant(('a'), 'msg', 'version')
    assert dep_seq[0] == 'a'

# Generated at 2022-06-22 13:42:32.924844
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.utils._text import to_bytes

    out = io.StringIO()
    sys.stderr = out
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test', '3.0')

    dsc[-1]
    assert out.getvalue() == ' [DEPRECATED] Test, to be removed in 3.0\n'
    out.seek(0)
    out.truncate(0)

    dsc[3]


# Generated at 2022-06-22 13:42:37.623879
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.2')
    assert test
    assert len(test) == 3
    assert test[1] == 2
    assert test[2] == 3
    assert test[0] == 1


# Generated at 2022-06-22 13:42:42.323381
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    len(list(_DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.8')))
    # already deprecated
    # len(list(_DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.8')))


# Generated at 2022-06-22 13:42:48.584338
# Unit test for function set_constant
def test_set_constant():
    import ansible
    assert ansible.constants.FOO == 'bar'
    assert ansible.constants.COMPATIBLE_PROXY_TYPE == ('proxy', )
    assert ansible.constants.CACHE_PLUGIN_FILENAME == 'fact_caching'
    assert ansible.constants.COMMAND_WARNINGS == ('always', 'once', 'never', 'true', 'false')

# Generated at 2022-06-22 13:42:52.301976
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "hello", "1.0")) == 3


# Generated at 2022-06-22 13:42:54.800777
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(value=('v0', 'v1'), msg='msg', version='version') == ('v0', 'v1')

# Generated at 2022-06-22 13:43:06.032248
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = (1, 2)
    test_msg = 'This is deprecated.'
    test_version = '1.0'

    # len_class will be an instance of class _DeprecatedSequenceConstant
    len_class = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # len_class should be a Sequence type
    assert isinstance(len_class, Sequence)
    # len_class must contain value of 2
    assert len_class.__len__() == 2
    # After this method is called, it should display a deprecation warning.
    # In order to verify this, we need to set a flag to True
    # once the warning gets displayed.
    global _len_flag
    _len_flag = None


# Generated at 2022-06-22 13:43:09.253752
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant((1, 2), 'msg', 'version').__len__() == 2
    assert _DeprecatedSequenceConstant((1, 2), 'msg', 'version').__getitem__(1) == 2


# Generated at 2022-06-22 13:43:15.826752
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = 'test'
    msg = 'This is deprecated'
    version = '2.0'
    assert _DeprecatedSequenceConstant(value, msg, version)._value == value
    assert _DeprecatedSequenceConstant(value, msg, version)._msg == msg
    assert _DeprecatedSequenceConstant(value, msg, version)._version == version

# Generated at 2022-06-22 13:43:20.055322
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant([], "", "1.0")
    length = len(s)
    assert length == 0
    assert length == len(s)
    assert s[0] is None

# Generated at 2022-06-22 13:43:35.137729
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test construction of class _DeprecatedSequenceConstant
    t = _DeprecatedSequenceConstant((1,2,3), 'this is a test', '2.0')

    # Test __len__
    assert(len(t) == len((1,2,3)))

    # Test __getitem__
    assert(t[0] == (1,2,3)[0])

# Generated at 2022-06-22 13:43:46.058794
# Unit test for function set_constant
def test_set_constant():
    """
    The following constants are generated from the configuration file,
    ansible.cfg, when setting up the ansible environment.
    """
    # Keep in sync with DEFAULT_HASH_BEHAVIOUR of ansible-config
    assert DEFAULT_HASH_BEHAVIOUR == 'replace'  # noqa

    # Keep in sync with PRIVATE_DATA_DIR of ansible-config
    assert PRIVATE_DATA_DIR == u'~/.ansible/private'

    # These constants rely on a defined value of DEFAULT_HASH_BEHAVIOUR,
    # hence they are generated here instead of in the configuration file.
    assert NEW_VAULT_IDENTITY_LIST is True  # noqa
    assert POST_VALIDATE_IDENTITY_LIST is True  # noqa



# Generated at 2022-06-22 13:43:50.007947
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ['item1', 'item2', 'item3']

    dsc = _DeprecatedSequenceConstant(test_list, 'msg', 'version')

    assert len(dsc) == len(test_list)



# Generated at 2022-06-22 13:43:53.159930
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant((1, 2, 'a'), 'msg', 'version')
    assert len(test_obj) == 3


# Generated at 2022-06-22 13:43:55.649943
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = [1,2,3]
    b = _DeprecatedSequenceConstant(a, "", "")
    assert len(b) == len(a)



# Generated at 2022-06-22 13:43:56.936828
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # __getitem__(y)
    pass


# Generated at 2022-06-22 13:44:01.733024
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """
    Test for method _DeprecatedSequenceConstant
    """

    sequence = _DeprecatedSequenceConstant(['foo', 'bar'], "Example message", "Example version")
    assert sequence[0] == 'foo' and sequence[1] == 'bar'
    assert len(sequence) == 2


# Generated at 2022-06-22 13:44:09.755312
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'myversion'
    value = [u'a', u'b']
    _deprecated = _DeprecatedSequenceConstant(value, msg, version)
    assert _deprecated.__getitem__(0) == u'a'
    assert _deprecated.__getitem__(1) == u'b'
    assert _deprecated[0] == u'a'
    assert _deprecated[1] == u'b'


# Generated at 2022-06-22 13:44:13.154452
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'this is a test'
    version = '5.0'
    value = ['foo', 'bar']

    t = _DeprecatedSequenceConstant(value, msg, version)
    assert t[0] == 'foo'



# Generated at 2022-06-22 13:44:15.937554
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='', version='')
    assert constant[1] == 2


# Generated at 2022-06-22 13:44:39.019428
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=['test'], msg='This is a test', version='version')) == 1

# Generated at 2022-06-22 13:44:42.435831
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.12')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.12')[1] == 2

# Generated at 2022-06-22 13:44:48.980942
# Unit test for function set_constant
def test_set_constant():
    assert(set_constant('HELLO', 'world', {}) == {'HELLO': 'world'})
    assert(set_constant('HELLO', 'world', {'ANSIBLE_CONFIG': 'test'}) ==
           {'ANSIBLE_CONFIG': 'test', 'HELLO': 'world'})

# Generated at 2022-06-22 13:44:57.370172
# Unit test for function set_constant
def test_set_constant():
    from ansible.utils.collection_loader import AnsibleCollectionNotFound
    test_dict = {}

    set_constant("test_name", "test_value", test_dict)

    assert "test_name" in test_dict
    assert test_dict["test_name"] == "test_value"
    try:
        collection_not_found = AnsibleCollectionNotFound("test_value")
        set_constant("test_name", collection_not_found, test_dict)
    except TypeError as e:
        assert "not JSON serializable" in str(e)

# Generated at 2022-06-22 13:45:08.141496
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # import unittest
    def method_equal(a_object,b_object):
        return (a_object.__dict__ == b_object.__dict__)

    # define the testing objects
    class a(object):
        def __init__(self,value,msg,version):
            self._value = value
            self._msg = msg
            self._version = version

    class b(object):
        def __init__(self,value,msg,version):
            self._value = value
            self._msg = msg
            self._version = version


    # assert equal
    assert(method_equal(_DeprecatedSequenceConstant(a,b,c), a))

# Generated at 2022-06-22 13:45:17.182143
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Unit test for method __getitem__ of class _DeprecatedSequenceConstant"""
    test_value = [0, 1, 2]
    test_msg = "test_msg"
    test_version = "test_version"
    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_instance.__getitem__(0) == 0
    assert test_instance.__getitem__(1) == 1
    assert test_instance.__getitem__(2) == 2

# Generated at 2022-06-22 13:45:28.157643
# Unit test for function set_constant
def test_set_constant():
    consts = {}
    set_constant('foo', 'bar', consts)
    assert consts['foo'] == 'bar'
    set_constant('one', 1, consts)
    assert consts['one'] == 1

# CONSTANTS WHICH DEPEND ON SETTINGS ###

# location of the 'host file'
DEFAULT_HOST_LIST = '~/ansible_hosts'

# behavior to deal with host file entries which cannot be resolved
DEFAULT_UNRESOLVED_VARS_BEHAVIOR = 'warn'

# The following are for backwards compatibility
HOST_LIST = DEFAULT_HOST_LIST
UNRESOLVED_VARS_BEHAVIOR = DEFAULT_UNRESOLVED_VARS_BEHAVIOR

# The following are possible choices for the

# Generated at 2022-06-22 13:45:31.392705
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    actual = _DeprecatedSequenceConstant([0, 1, 2], 'warning', '2.10')
    assert len(actual) == 3


# Generated at 2022-06-22 13:45:34.788180
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    length = len(_DeprecatedSequenceConstant(value=[1,2,3], msg='msg', version='version'))
    assert length == 3


# Generated at 2022-06-22 13:45:37.506135
# Unit test for function set_constant
def test_set_constant():
    assert(ANSIBLE_CONFIG == TEST_ANSIBLE_CONFIG)
    assert(LIBRARY == TEST_LIBRARY)
    assert(DEFAULT_HOST_LIST == [])

# Generated at 2022-06-22 13:46:30.871748
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], msg='', version='x')) == 3

# Generated at 2022-06-22 13:46:37.275838
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['1', '2', '3', '4']
    msg = 'This option is deprecated and will be removed in a later release'
    version = 'ansible 2.9'

    seq_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(seq_constant) == 4
    assert seq_constant[0] == '1'

# Generated at 2022-06-22 13:46:38.317357
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(REJECT_EXTS, tuple)

# Generated at 2022-06-22 13:46:41.316391
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1,2,3], '', '')
    assert seq[1] == 2


# Generated at 2022-06-22 13:46:52.440083
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_to_be_removed_in_version_2021_1 = _DeprecatedSequenceConstant(
        value=(_ACTION_INCLUDE + _ACTION_INCLUDE_ROLE + _ACTION_INCLUDE_TASKS + _ACTION_IMPORT_TASKS),
        msg='Usage of deprecated constant ACTION_ALL_INCLUDE_IMPORT_TASKS', version='2.12')
    assert isinstance(deprecated_to_be_removed_in_version_2021_1, Sequence)
    assert isinstance(deprecated_to_be_removed_in_version_2021_1, _DeprecatedSequenceConstant)
    assert deprecated_to_be_removed_in_version_2021_1._value == _ACTION_INCLUDE + _ACTION_INCLU

# Generated at 2022-06-22 13:46:57.316021
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dummy = _DeprecatedSequenceConstant('a', 'b', 'c')
    assert dummy._value == 'a'
    assert dummy._msg == 'b'
    assert dummy._version == 'c'
    assert dummy[0] == 'a'

# Generated at 2022-06-22 13:46:59.664066
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(value=[], msg='message', version='2.5')
    assert constant[0] == None


# Generated at 2022-06-22 13:47:12.724602
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils.six.moves import reduce
    def test_class(seq_cls):
        assert issubclass(seq_cls, Sequence)
        assert hasattr(seq_cls, '_value')
        assert hasattr(seq_cls, '_msg')
        assert hasattr(seq_cls, '_version')

    test_class(add_metaclass(type)(_DeprecatedSequenceConstant)([1,2,], '', ''))
    test_class(_DeprecatedSequenceConstant([1,2,], '', ''))

# Generated at 2022-06-22 13:47:16.320738
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant(['a', 'b'], 'msg', '2.9')
    assert len(value) == 2
    assert value[1] == 'b'


# Generated at 2022-06-22 13:47:19.419213
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant('test_sequence', 'msg', 'version')
    try:
        len(test_sequence)
    except Exception as e:
        print(e)

# Generated at 2022-06-22 13:49:31.951931
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "msg"
    version = 1
    value = [1, 2, 3]
    ans = _DeprecatedSequenceConstant(value, msg, version)
    assert len(ans) == len(value)

# Generated at 2022-06-22 13:49:40.845041
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class TestObject:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __getattr__(self, name):
            return None

    old_display = TestObject(warning=lambda x: None)
    setattr(__import__('ansible.utils', fromlist=('display')), 'Display', old_display)

    with open("/dev/null", 'a') as fd:
        import sys
        old_stderr = sys.stderr
        sys.stderr = fd


# Generated at 2022-06-22 13:49:44.389708
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = ('test', )
    test_msg = 'test_msg'
    test_version = '1.2.3'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == 1


# Generated at 2022-06-22 13:49:47.715848
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant(("test1", "test2"), "test_msg", "test_ver")

    assert t[0] == "test1"
    asser

# Generated at 2022-06-22 13:49:56.445712
# Unit test for function set_constant
def test_set_constant():
    global test_constant_1, test_constant_2, test_constant_3

    set_constant('test_constant_1', 1, export=vars())
    set_constant('test_constant_2', 2)
    assert 'test_constant_1' in globals().get('export', {})
    assert test_constant_1 == 1
    assert test_constant_2 == 2

    # Testing a constant which is already set
    test_constant_3 = 3
    set_constant('test_constant_3', 4)
    assert test_constant_3 == 3

# Generated at 2022-06-22 13:50:00.149583
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import ensure_list
    expect = len(ensure_list(DEFAULT_HOST_LIST))
    value = len(_DeprecatedSequenceConstant(DEFAULT_HOST_LIST, 'message', '2.4'))
    assert expect == value

# Generated at 2022-06-22 13:50:04.300380
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # invalid case
    try:
        d = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test', '2.0')
        d['a']
    except ValueError:
        pass  # expected
    # valid case
    d = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test', '2.0')
    assert d[2] == 3


# Generated at 2022-06-22 13:50:06.252041
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(seq) == 3


# Generated at 2022-06-22 13:50:16.046670
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        assert setting.value == getattr(config, setting.name)

# Backwards compatibility
_CONN_ENV_PREFIX = 'ANSIBLE_'
_DEFAULT_BECOME_METHOD = 'sudo'
_DEFAULT_REMOTE_PASS = 'sshpass'
_DEFAULT_PRIVATE_KEY_FILE = '~/.ssh/id_rsa'
_DEFAULT_SUDO_EXE = '/usr/bin/sudo'
_DEFAULT_SUDO_FLAGS = '-H'
_DEFAULT_SU_EXE = '/bin/su'
_DEFAULT_SU_FLAGS = '-c'
_DEFAULT_SSH_TRANSFER_METHOD = 'smart'
_DEFAULT_TIMEOUT = 10
_DEFAULT_SCP_

# Generated at 2022-06-22 13:50:19.981034
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'test__DeprecatedSequenceConstant___len__', '2.0')
    assert len(c) == len(c._value)