

# Generated at 2022-06-22 13:40:40.852303
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), '', '')) == 2



# Generated at 2022-06-22 13:40:53.035270
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.vars.unsafe_proxy import UnsafeProxy

    deprecated_msg = 'the seq constant is deprecated'
    deprecated_version = '2.4'
    seq = [1, 2, 3]
    seq_constant = _DeprecatedSequenceConstant(seq, deprecated_msg, deprecated_version)
    assert seq_constant[0] == 1
    assert seq_constant[1] == 2
    assert seq_constant[2] == 3

    try:
        seq_constant[3]
    except IndexError:
        assert True
    else:
        assert False

    stdout_old = sys.stdout
    sys.stdout = io.StringIO()
    seq_constant[0]
    msg = sys.stdout.getvalue()

# Generated at 2022-06-22 13:40:58.141236
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.display import Display
    from io import StringIO
    import sys
    test_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        dsc = _DeprecatedSequenceConstant([3,4,5], 'test message', '2.10')
        dsc[1]
        output = out.getvalue().strip()
        assert output == '[DEPRECATED] test message, to be removed in 2.10'
    finally:
        sys.stdout = test_stdout

# Generated at 2022-06-22 13:40:59.485391
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence = _DeprecatedSequenceConstant(99, 'msg', 'version')
    assert len(deprecated_sequence) == 1
    assert deprecated_sequence[0] == 99

# Generated at 2022-06-22 13:41:02.002365
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testcase = _DeprecatedSequenceConstant([1, 2, 3], 'dummy msg', 'dummy version')

    assert len(testcase) is 3

# Generated at 2022-06-22 13:41:11.205600
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    before = "This variable name has been removed in Ansible 2.4, the variable name is now 'ansible_shell_executable'. See https://docs.ansible.com/ansible/2.4/reference_appendices/config.html#ansible-configuration-settings for details"
    after = "This variable name has been removed in Ansible 2.4, the variable name is now 'ansible_shell_executable'. See https://docs.ansible.com/ansible/latest/reference_appendices/config.html#ansible-configuration-settings for details"

# Generated at 2022-06-22 13:41:21.775712
# Unit test for function set_constant
def test_set_constant():
    c = {}
    set_constant('ansible_max_failed_percentage', 10, c)
    assert c['ansible_max_failed_percentage'] == 10
    set_constant('ansible_max_failed_percentage', 'a', c)
    assert c['ansible_max_failed_percentage'] == 'a'
    set_constant('ansible_max_failed_percentage', '{{asdf}}', c)
    assert c['ansible_max_failed_percentage'] == '{{asdf}}'
    set_constant('ansible_max_failed_percentage', '10', c)
    assert c['ansible_max_failed_percentage'] == 10
    set_constant('ansible_max_failed_percentage', '"10"', c)

# Generated at 2022-06-22 13:41:31.330707
# Unit test for function set_constant
def test_set_constant():
    config = {
        'a': '1',
        'b': '{{a}}',
        'c': '{{b}}',
        'd': '{{c}}',
        'e': '{{d}}',
        'f': '{{e}}',
        'g': '{{f}}',
        'h': '{{g}}',
    }
    for k,v in config.items():
        set_constant(k,v,export=locals())

    # verify that the templating works
    assert locals()['a'] == '1'
    assert locals()['b'] == '{{a}}'
    assert locals()['c'] == '1'
    assert locals()['d'] == '1'
    assert locals()['e'] == '1'
    assert locals()['f'] == '1'

# Generated at 2022-06-22 13:41:36.470134
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Set
    value = [1, 2, 3]
    msg = "test message"
    version = "test version"

    # Action
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    # Assert
    assert dsc[1] == 2



# Generated at 2022-06-22 13:41:39.349654
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Call method
    constant = _DeprecatedSequenceConstant((), '', '')
    try:
        constant[1]
    except IndexError:
        pass

# Generated at 2022-06-22 13:41:45.257961
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    one = _DeprecatedSequenceConstant((1, 2, 3), 'foo', 'bar')
    assert one[1] == 2

# Generated at 2022-06-22 13:41:48.405853
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant((1, 2, 3), 'test', '0.0')
    assert a.__getitem__(0) == 1


# Generated at 2022-06-22 13:41:51.116566
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='1.0')
    assert len(seq) == 3

# Generated at 2022-06-22 13:41:54.010199
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_class = _DeprecatedSequenceConstant([1, 2, 3, 4], 'Testing deprecated message', '2.9')
    assert len(test_class) == 4

# Generated at 2022-06-22 13:42:04.667421
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Check __len__ works correctly
    c = _DeprecatedSequenceConstant([1, 2, 3], 'some message', 'some version')
    assert len(c) == 3
    # Check __len__ works correctly even if __getitem__ returns a list
    c = _DeprecatedSequenceConstant([[1, 2, 3], [4, 5, 6]], 'some message', 'some version')
    assert len(c) == 2
    # Check __len__ works correctly even if __getitem__ returns a _DeprecatedSequenceConstant
    c = _DeprecatedSequenceConstant([_DeprecatedSequenceConstant([1, 2, 3], 'some message', 'some version')], 'some message', 'some version')
    assert len(c) == 1


# Generated at 2022-06-22 13:42:12.781255
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    v = 'value'
    m = 'message'
    d = _DeprecatedSequenceConstant(v, m, __version__)
    assert d._value == v
    assert d._msg == m
    assert d._version == __version__

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-22 13:42:17.227755
# Unit test for function set_constant
def test_set_constant():
    ''' assert the return value for function set_constant is equal to {'test_constant': 'test_value'} '''

    test_dict = {}
    set_constant('test_constant', 'test_value', test_dict)
    assert test_dict == dict(test_constant='test_value')

# Generated at 2022-06-22 13:42:23.223694
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # The test example is an integer list
    value = [1, 2, 3]
    msg = "test_msg"
    version = "1.5"
    test_example = _DeprecatedSequenceConstant(value, msg, version)
    # test __len__ function
    assert test_example.__len__() == len(value)
    # test __getitem__ function
    assert test_example.__getitem__(1) == value[1]

# Generated at 2022-06-22 13:42:27.739638
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    CONSTANT = _DeprecatedSequenceConstant([1, 2, 3], 'test', 'version')
    assert len(CONSTANT) == 3
    assert CONSTANT[1] == 2
    assert CONSTANT == [1, 2, 3]

# Generated at 2022-06-22 13:42:31.062448
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_instance = _DeprecatedSequenceConstant(value=[0, 1, 2, 3, 4, 5], msg='foo', version='2.9')

    assert len(seq_instance) == 6


# Generated at 2022-06-22 13:42:46.020831
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], "", "")[0] == []
    assert len(_DeprecatedSequenceConstant([], "", "")) == 0
    assert _DeprecatedSequenceConstant(["my_string"], "", "")[0] == ["my_string"]
    assert len(_DeprecatedSequenceConstant(["my_string"], "", "")) == 1
    assert _DeprecatedSequenceConstant(["my_string", 5], "", "")[1] == 5
    assert len(_DeprecatedSequenceConstant(["my_string", 5], "", "")) == 2
    assert _DeprecatedSequenceConstant({"my_string": "my_string"}, "", "")[0] == {'my_string': 'my_string'}

# Generated at 2022-06-22 13:42:50.239543
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar', export=globals())
    set_constant('foo2', 'bar2', export=globals())
    assert foo == 'bar'
    assert foo2 == 'bar2'

# Generated at 2022-06-22 13:42:58.241930
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dummy_value = [1,2,3]
    msg = 'This is a test'
    version = '1.1'
    test_obj = _DeprecatedSequenceConstant(dummy_value, msg, version)
    assert test_obj._value == dummy_value
    assert test_obj._msg == msg
    assert test_obj._version == version

if __name__ == '__main__':
    # Run the unit test
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:42:59.205582
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'dummy_msg', 'dummy_version')) == 2

# Generated at 2022-06-22 13:43:08.684214
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Check the behavior of _DeprecatedSequenceConstant.__getitem__ for valid inputs

    # Initialize a variable to hold a value which is the result returned by _DeprecatedSequenceConstant.__getitem__.
    actual_result = None
    # Initialize a variable to hold a value which is used to test if the result returned by _DeprecatedSequenceConstant.__getitem__ is correct.
    expected_result = None
    # Initialize a variable to hold the message which is used to test the behavior of _DeprecatedSequenceConstant.__getitem__.
    msg = 'Test case failed.'
    # Initialize a variable to hold the version which is used to test the behavior of _DeprecatedSequenceConstant.__getitem__.
    version = '2.4.0'


# Generated at 2022-06-22 13:43:11.285736
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list(range(10)), 'msg', 'version')) == 10

# Generated at 2022-06-22 13:43:20.559948
# Unit test for function set_constant
def test_set_constant():
    conf_value = 'config_value'
    default_value = 'default_value'
    test_value = 'test_value'

    set_constant('conf_value', conf_value)
    set_constant('default_value', default_value)

    assert conf_value == conf_value
    assert default_value == default_value
    try:
        assert test_value == test_value
        assert False, 'test_value should never have been be True'
    except NameError:
        assert True


# Generated at 2022-06-22 13:43:28.334335
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(('a', 'b'))
    assert isinstance(constant, Sequence)
    assert len(constant) == 2
    constant = _DeprecatedSequenceConstant(('a',))
    assert len(constant) == 1
    assert constant[0] == 'a'


# FIXME: remove these
# For backwards compatibility
ACTION_DEBUG_VARS = _ACTION_DEBUG
ACTION_IMPORT_PLAYBOOK_VARS = _ACTION_IMPORT_PLAYBOOK
ACTION_IMPORT_ROLE_VARS = _ACTION_IMPORT_ROLE
ACTION_IMPORT_TASKS_VARS = _ACTION_IMPORT_TASKS
ACTION_INCLUDE_VARS = _ACTION_INCLUDE_VARS

# Generated at 2022-06-22 13:43:36.215251
# Unit test for function set_constant
def test_set_constant():
    # testing setting a constant
    data = {}
    set_constant('BAR', 'bar', export=data)
    assert data['BAR'] == 'bar'

    # testing setting a constant to a jinja2 template
    data = {}
    set_constant('BAR', '{{ foo }}', export=data)
    assert data['BAR'] == '{{ foo }}'

    # testing setting a constant with a templatable jinja2 value
    data = {}
    set_constant('BAR', '{{ foo }}', export=data)
    data = dict(foo='bar')
    assert data['BAR'] == 'bar'

# Generated at 2022-06-22 13:43:37.488704
# Unit test for function set_constant
def test_set_constant():
    # TODO
    pass

# Generated at 2022-06-22 13:43:43.999302
# Unit test for function set_constant
def test_set_constant():
    var_name = 'test_foo_bar'
    value = 'baz'
    my_dict = {}

    set_constant(var_name, value, my_dict)

    assert my_dict[var_name] == value



# Generated at 2022-06-22 13:43:54.883949
# Unit test for function set_constant
def test_set_constant():
    # This test case is used to review the function set_constant
    # Create a string variable for testing.
    test_str = "str"
    result_str = ""
    # Create a boolean variable for testing.
    test_bool = True
    result_bool = False
    # Create an interger variable for testing.
    test_int = 1
    result_int = 0
    # Create a list variable for testing.
    test_list = [test_str]
    result_list = []
    # Create a dict variable for testing.
    test_dict = {"test_str": test_str}
    result_dict = {}
    # Create a set variable for testing.
    test_set = set(test_list)
    result_set = set()
    # Create a variable that can not be converted to a variable.
    test_

# Generated at 2022-06-22 13:43:57.367789
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_obj = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert len(class_obj) == 3
    item = class_obj[1]     # Test __getitem__
    assert item == 2

# Generated at 2022-06-22 13:44:03.560762
# Unit test for function set_constant
def test_set_constant():
    global __version__
    assert __version__ == '2.10.1'

    set_constant('__version__', '2.10.2', export=globals())
    assert __version__ == '2.10.2'

    __version__ = '2.10.1'



# Generated at 2022-06-22 13:44:10.418443
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test constructor of _DeprecatedSequenceConstant
    msg = 'Module "unittest_module" is deprecated'
    value = ('unittest_module', )
    version = '2.7'
    obj = _DeprecatedSequenceConstant(value, msg, version)

    # test __len__(self)
    obj.__len__()

    # test __getitem__(self, y)
    obj.__getitem__(0)



# Generated at 2022-06-22 13:44:21.036892
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Make sure the class works correctly by verifying that the default
    # (in other words, empty) message and version get set correctly
    test_obj = _DeprecatedSequenceConstant([], '', '')
    assert test_obj._msg == '', '_DeprecatedSequenceConstant class did not initialize _msg correctly.'
    assert test_obj._version == '', '_DeprecatedSequenceConstant class did not initialize _version correctly.'
    # Make sure the class works correctly by verifying that the message
    # and version get set correctly
    test_obj = _DeprecatedSequenceConstant([], 'test_msg', 'test_version')
    assert test_obj._msg == 'test_msg', '_DeprecatedSequenceConstant class did not initialize _msg correctly.'

# Generated at 2022-06-22 13:44:23.745059
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    SEQ = _DeprecatedSequenceConstant([], "", "")
    SEQ._value = [1, 2, 3]
    assert len(SEQ) == 3

# Generated at 2022-06-22 13:44:28.587180
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'this is msg', '2.8')) == 3
    assert _DeprecatedSequenceConstant([1,2,3], 'this is msg', '2.8')[1] == 2


# Generated at 2022-06-22 13:44:31.338305
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1,2], "this is a test", "version 1.0")
    assert len(a) is 2
    assert a[0] is 1
    assert a[1] is 2

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:44:38.444741
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
  deprecated_sequence_constant = _DeprecatedSequenceConstant([2, 3, 5, 5], 'msg', 'version')
  assert deprecated_sequence_constant[0] == 2
  assert deprecated_sequence_constant[1] == 3
  assert deprecated_sequence_constant[2] == 5
  assert deprecated_sequence_constant[3] == 5


# Generated at 2022-06-22 13:44:52.842175
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a deprecation warning message.'
    version = '2.10.0'
    ds = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(ds) == 3
    assert ds[1] == 'b'
    ds = _DeprecatedSequenceConstant('abc', msg, version)
    assert len(ds) == 3
    assert ds[0] == 'a'
    assert ds[1] == 'b'
    assert ds[2] == 'c'

# Generated at 2022-06-22 13:44:57.206855
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')

    assert 1 == dsc[0]
    assert 2 == dsc[1]
    assert 3 == dsc[2]

# Generated at 2022-06-22 13:45:06.743812
# Unit test for function set_constant
def test_set_constant():
    import imp
    import sys

    mod_name = "test_set_constant"
    set_constant("MOD_NAME_ANSIBLE_CONSTANTS", mod_name, export={})
    mod = imp.new_module(mod_name)
    sys.modules[mod_name] = mod

    try:
        set_constant("TEST_SET_CONSTANT", 1, export=mod.__dict__)
        assert mod.__dict__['TEST_SET_CONSTANT'] == 1
    finally:
        del sys.modules[mod_name]

# Generated at 2022-06-22 13:45:10.201255
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR', export=globals())
    assert globals()['FOO'] == 'BAR'
    del globals()['FOO']

# Generated at 2022-06-22 13:45:18.609036
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Test message'
    deprecated = _DeprecatedSequenceConstant(value=None, msg=msg, version='1.0')

    # content of _DeprecatedSequenceConstant is None
    assert isinstance(deprecated, _DeprecatedSequenceConstant)
    assert not deprecated

    deprecated = _DeprecatedSequenceConstant([], msg=msg, version='1.0')
    # content of _DeprecatedSequenceConstant is []
    assert isinstance(deprecated, _DeprecatedSequenceConstant)
    assert len(deprecated) == 0

# Generated at 2022-06-22 13:45:25.689046
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test class with values that can be used with __len__
    test_seq = [1,2,3,4]
    assert len(_DeprecatedSequenceConstant(test_seq, 'msg', 'version')) == 4
    # Test class with values that cannot be used with __len__
    test_seq = 1
    assert len(_DeprecatedSequenceConstant(test_seq, 'msg', 'version')) == 1


# Generated at 2022-06-22 13:45:28.977012
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_constant = _DeprecatedSequenceConstant(('val1', 'val2'), "Deprecated message", "version")

    # Assert that method __len__ raises no exception.
    assert len(deprecated_constant) == 2, "Deprecated message, to be removed in version"

# Generated at 2022-06-22 13:45:33.269365
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    result = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], 'Test', '2.0')
    assert len(result) == 5


# Generated at 2022-06-22 13:45:34.270226
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], "Message", "Version")[1] == 2

# Generated at 2022-06-22 13:45:46.899061
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('test', 'value', export=test_dict)
    assert test_dict['test'] == 'value'

# test that the config was processed properly
assert(DEFAULT_BECOME_PASS == None)
assert(DEFAULT_REMOTE_PASS == None)
assert(DEFAULT_SUBSET == None)
assert(INTERNAL_RESULT_KEYS == tuple(add_internal_fqcns(('add_host', 'add_group'))))
assert(RESTRICTED_RESULT_KEYS == tuple(add_internal_fqcns(('ansible_rsync_path', 'ansible_playbook_python', 'ansible_facts'))))
assert(TREE_DIR == None)
assert(__version__ == 'AWX %s' % VERSION)


# Generated at 2022-06-22 13:46:04.686489
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sc = _DeprecatedSequenceConstant([1, 2, 3], 'dummy', '1.1')
    assert isinstance(sc, Sequence), "sc should be a subclass of Sequence"

    # The following line should emit the deprecation warning
    len(sc)

    # The following line should also emit a deprecation warning
    assert sc[1] == 2

# Generated at 2022-06-22 13:46:09.208840
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert isinstance(_DeprecatedSequenceConstant((1,2), 'test', '2.0'), Sequence)
    assert len(_DeprecatedSequenceConstant((1,2), 'test', '2.0')) == 2
    assert _DeprecatedSequenceConstant((1,2), 'test', '2.0')[1] == 2


# Generated at 2022-06-22 13:46:21.943786
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from io import StringIO
    from contextlib import contextmanager
    import sys

    # Redirect the standard error stream to a StringIO object
    @contextmanager
    def std_out_err_redirector(stringio_obj):
        stdout = sys.stdout
        stderr = sys.stderr
        sys.stdout = stringio_obj
        sys.stderr = stringio_obj
        yield
        sys.stdout = stdout
        sys.stderr = stderr

    test_object = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    test_stringio = StringIO()

    set_constant('test_object', test_object)
    set_constant('test_stringio', test_stringio)


# Generated at 2022-06-22 13:46:26.835209
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test!'
    version = '1.0'
    test_array = ['value1', 'value2']
    x = _DeprecatedSequenceConstant(test_array, msg, version)
    assert len(x) == len(test_array)
    assert x[0] == test_array[0]

# Generated at 2022-06-22 13:46:30.324384
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'Some message'
    value = _DeprecatedSequenceConstant((1, 'a'), msg, '2.9')
    assert value[1] == 'a'


# Generated at 2022-06-22 13:46:33.310371
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="test")
    assert obj.__getitem__(0) == 1

# Generated at 2022-06-22 13:46:46.244268
# Unit test for function set_constant
def test_set_constant():
    def assert_setting(setting, value):
        assert getattr(config, setting) == value

    def assert_constant(name, value):
        assert globals()[name] == value

    for setting in config.data.get_settings():
        assert_constant(setting.name, setting.value)
        assert_setting(setting.name, setting.value)

    config.load_file('tests/test.cfg')
    # Test config reset
    for setting in config.data.get_settings():
        if setting.name == 'CONFIG_FILE':
            # Test config file config
            assert_constant(setting.name, setting.value)
            assert_setting(setting.name, setting.value)

# Generated at 2022-06-22 13:46:48.020789
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), 'msg', 'version')) == 3

# Generated at 2022-06-22 13:46:55.446412
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test:
        def debug(self, msg):
            self.msg = msg
    test = Test()

    val = [1, 2, 3]
    msg = 'foo'
    version = 'bar'

    x = _DeprecatedSequenceConstant(val, msg, version)
    assert len(x) == len(val)
    assert test.msg == '[DEPRECATED] %s, to be removed in %s' % (msg, version)

# Generated at 2022-06-22 13:46:58.131508
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[1] == 2


# Generated at 2022-06-22 13:47:34.964163
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(('a', 'b', 'c'), 'test', '2.11')[0] == 'a'
    assert _DeprecatedSequenceConstant(('a', 'b', 'c'), 'test', '2.11')[1] == 'b'
    assert _DeprecatedSequenceConstant(('a', 'b', 'c'), 'test', '2.11')[2] == 'c'


# Generated at 2022-06-22 13:47:37.389088
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(('test', ), 'test message', '2.11')
    assert constant[0] == 'test'

# Generated at 2022-06-22 13:47:44.468240
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "FOO"
    version = "2.11"
    value = list(range(2, 5))
    const = _DeprecatedSequenceConstant(value, msg, version)
    assert const[0] == value[0]
    assert const[1] == value[1]
    assert const[2] == value[2]
    assert const[0:2] == value[0:2]



# Generated at 2022-06-22 13:47:48.772660
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    Unit test for method __getitem__ of class _DeprecatedSequenceConstant
    '''
    v = _DeprecatedSequenceConstant([1,2,3], "msg", 1.0)
    assert v[0] == 1
    assert v[1] == 2
    assert v[2] == 3

# Generated at 2022-06-22 13:47:50.689261
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'test_msg', 'test_version')) == 3, 'test error'

# Generated at 2022-06-22 13:47:54.120678
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['foo', 'bar'], 'msg', '2.10')) == 2
    assert _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', '2.10')[0] == 'foo'

# Generated at 2022-06-22 13:48:01.873067
# Unit test for function set_constant
def test_set_constant():
    D = dict()
    set_constant('foo', True, D)
    assert D['foo'] is True

test_set_constant()

# FIXME: this should be wrapped in a function and called from
# configure.ac at build time, using something like the following
# but I can't seem to get those ./configure vars in python:
#
# AC_DEFINE([ANSIBLE_VERSION], [$(VERSION)], [Ansible version])

# NOTE: for the C version of this, we instead use the AC_SUBST(VERSION)
# macro in configure.ac, as well as AC_DEFINE_UNQUOTED([ANSIBLE_VERSION_FULL],
# "$VERSION").  This is more efficient, since it will always be defined
# to the exact git string at build time, and thus doesn't need to be


# Generated at 2022-06-22 13:48:11.106405
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
# Build a list of tuples with the test values.
    pairs = [(['a', 'b', 'c', 'd'], 'msg', 'ver'),
             ([4, 8, 15, 16, 23, 42], 'msg', 'ver'),
             ([None, True, False, 'str', 1, [4, 8, 15]], 'msg', 'ver')]

# Repeat for all tuples the test.
    for pair in pairs:
        test = _DeprecatedSequenceConstant(pair[0], pair[1], pair[2])
        result = len(test)
        expected_result = len(pair[0])
# Check that result matches expected_result.
        assert result == expected_result


# Generated at 2022-06-22 13:48:16.655519
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert d[0] == 'a'
    assert d[-1] == 'b'


# Generated at 2022-06-22 13:48:22.993737
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test __len__ of _DeprecatedSequenceConstant"""
    # Test simple case
    my_list1 = _DeprecatedSequenceConstant(value=[1,2,3],
                                           msg='__len__ test',
                                           version='2.8')
    assert len(my_list1) == 3
    # Test extended slice
    my_list2 = _DeprecatedSequenceConstant(value=[1,2,3,4,5,6],
                                           msg='__len__ test',
                                           version='2.8')
    assert len(my_list2[1:4]) == 3

# Generated at 2022-06-22 13:49:39.814503
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = []
    a = _DeprecatedSequenceConstant(value, msg, version)
    assert a._msg == msg
    assert a._version == version
    assert a._value == value
    assert a[:] == value[:]
    assert a == value


### --- Deprecation time!


# Generated at 2022-06-22 13:49:42.092737
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert result._value == []
    assert result._version == 'version'
    assert result._msg == 'msg'
    assert len(result) == 0

# Generated at 2022-06-22 13:49:47.324795
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    msg = 'testing...'
    version = '1.2'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version



# Generated at 2022-06-22 13:49:49.850926
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.5')
    assert len(t) == 3

# Generated at 2022-06-22 13:49:53.140912
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['foo'], 'test', '2.9')) == 1
    assert len(_DeprecatedSequenceConstant((), 'test', '2.9')) == 0

# Generated at 2022-06-22 13:49:56.151489
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.9')
    assert dep_seq[0] == 1

# Generated at 2022-06-22 13:49:58.304220
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    A = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(A) == 3


# Generated at 2022-06-22 13:50:00.708113
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ssc = _DeprecatedSequenceConstant(('value_1', 'value_2', 'value_3'), 'test_message', '2.2')
    assert len(ssc) == 3

# Generated at 2022-06-22 13:50:03.415750
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 56)
    assert test_constant == 56
    set_constant('test_constant2', 'hello world')
    assert test_constant2 == 'hello world'


# Generated at 2022-06-22 13:50:06.785238
# Unit test for function set_constant
def test_set_constant():
    """
    This is a function to unit test the set_constant function.
    The set_constant function is supposed to correctly set constants
    and return resolved options dict.
    """
    mydict = {}
    set_constant('test', 'value', mydict)
    assert mydict['test'] == 'value'
    #assert mydict['test'] == 'value1'  # negative test case