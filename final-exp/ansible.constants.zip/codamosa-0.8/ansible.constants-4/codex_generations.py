

# Generated at 2022-06-22 13:40:52.562527
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(('a', 'b'), "test", "30.0")._value == ('a', 'b')
    assert _DeprecatedSequenceConstant(['a', 'b'], "test", "30.0")._value == ['a', 'b']
    assert _DeprecatedSequenceConstant(['a', 'b'], "test", "30.0")._msg == "test"
    assert _DeprecatedSequenceConstant(['a', 'b'], "test", "30.0")._version == "30.0"
    assert len(_DeprecatedSequenceConstant(('a', 'b'), "test", "30.0")) == 2
    assert _DeprecatedSequenceConstant(('a', 'b'), "test", "30.0")[0] == 'a'
    assert _Dep

# Generated at 2022-06-22 13:40:54.830993
# Unit test for function set_constant
def test_set_constant():
    fake_export = {}
    set_constant('foo', 'bar', fake_export)
    assert fake_export.get('foo') == 'bar'


# Generated at 2022-06-22 13:41:00.747103
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        import __builtin__
        builtins = __builtin__
    except ImportError:
        import builtins
    assert len(_DeprecatedSequenceConstant(builtins.list(), 'testing', '2.9')) == len(builtins.list())


# Generated at 2022-06-22 13:41:02.389623
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'test', '9999.9')
    for i in range(len(seq)):
        assert seq[i] == i + 1

# Generated at 2022-06-22 13:41:04.416268
# Unit test for function set_constant
def test_set_constant():
    global RESTRICTED_RESULT_KEYS
    RESTRICTED_RESULT_KEYS = "test"
    set_constant('RESTRICTED_RESULT_KEYS', 'elite')
    assert RESTRICTED_RESULT_KEYS == 'elite'

# Generated at 2022-06-22 13:41:09.850993
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test when deprecated
    message = u'Deprecated message'
    version = u'v1'
    data = [1, 2, 3]
    dep_seq = _DeprecatedSequenceConstant(data, message, version)
    assert len(data) == len(dep_seq)
    assert 3 == dep_seq.__len__()

    # Test when not deprecated
    dep_seq._version = ''
    assert len(data) == dep_seq.__len__()



# Generated at 2022-06-22 13:41:16.687856
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    seq_constant = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert len(seq_constant) == 3
    assert seq_constant[2] == 3
    assert seq_constant._msg == "msg"
    assert seq_constant._version == "version"
    assert seq_constant._value == (1, 2, 3)



# Generated at 2022-06-22 13:41:27.894937
# Unit test for function set_constant
def test_set_constant():
    foo = {}
    for x in config.data.get_settings():
        set_constant(x.name, x.value, foo)
    assert foo['DEFAULT_BECOME_PASS'] == DEFAULT_BECOME_PASS

for dep in config.DEPRECATIONS:
    _deprecated(dep['msg'], dep['version'])
    constant = dep['constant']
    _ = globals()[constant]
    if isinstance(_, Sequence):
        globals()[constant] = _DeprecatedSequenceConstant(_, dep['msg'], dep['version'])
    else:
        globals()[constant] = dep['msg']  # should be string now

del config

# Generated at 2022-06-22 13:41:33.766131
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant(['a','b','c'], 'msg', 'version')
    print(l[2])
    print(len(l))
    print(l[:])

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-22 13:41:37.686642
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    v = _DeprecatedSequenceConstant(['hello', 'world'], 'message', 'version')
    assert len(v) == 2
    assert v[0] == 'hello'
    assert v[1] == 'world'



# Generated at 2022-06-22 13:41:43.775986
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = _DeprecatedSequenceConstant([], '', '')
    assert len(l) == 0
    assert l[0] is None



# Generated at 2022-06-22 13:41:49.058791
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    constant = _DeprecatedSequenceConstant('test', 'this is a test', '2.4')
    assert len(constant) == 4
    assert constant[0] == 't'
    assert constant[1] == 'e'
    assert constant[2] == 's'
    assert constant[3] == 't'

# Generated at 2022-06-22 13:41:52.104263
# Unit test for function set_constant
def test_set_constant():
    dest = dict()
    set_constant("this_is_a_test", "blah", export=dest)
    assert dest["this_is_a_test"] == "blah"

# Generated at 2022-06-22 13:41:56.219507
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0
    assert len(_DeprecatedSequenceConstant((), '', '')) == 0
    assert len(_DeprecatedSequenceConstant('', '', '')) == 0


# Generated at 2022-06-22 13:41:58.516019
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'testing', vars())
    assert vars()['TEST_CONSTANT'] == 'testing'

# Generated at 2022-06-22 13:42:03.791503
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([], 'test', '2.10')

LOCALHOST_WARNING_DEPRECATED = _DeprecatedSequenceConstant(LOCALHOST, 'The value of LOCALHOST_WARNING is deprecated. '
                                                            'It will be removed in version 2.10 and should not be used.', '2.10')

# Generated at 2022-06-22 13:42:16.281015
# Unit test for function set_constant
def test_set_constant():
    # This is only meant to cover the bits of code that are not covered by the config unit tests
    set_constant('TEST_CONSTANT1', 'value1')
    set_constant('TEST_CONSTANT2', 'value2', locals())
    set_constant('TEST_CONSTANT3', 'value3', globals())
    assert TEST_CONSTANT1 == 'value1'
    assert locals()['TEST_CONSTANT2'] == 'value2'
    assert globals()['TEST_CONSTANT3'] == 'value3'
    # Clean up
    del TEST_CONSTANT1
    del locals()['TEST_CONSTANT2']
    del globals()['TEST_CONSTANT3']

# Generated at 2022-06-22 13:42:19.447398
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_const = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert seq_const.__len__() == len([1,2,3])


# Generated at 2022-06-22 13:42:23.737307
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "has been deprecated"
    version = "2.10"
    sequence_constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(sequence_constant) == 3

# Generated at 2022-06-22 13:42:36.611210
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import nose

    config = ConfigManager()

    # Generate constants from config
    for setting in config.data.get_settings():
        # make sure we always get the default value for tests,
        # regardless of any local config files.
        msg = 'unset'
        version = 'unset'
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render(vars())
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not templatable

# Generated at 2022-06-22 13:42:48.250337
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    version = '2.9'
    msg = 'This is for test only.'
    a = _DeprecatedSequenceConstant(['1','2','3'], msg=msg, version=version)
    assert isinstance(a, Sequence)
    assert a[1] == '2'
    assert len(a) == 3

# Generated at 2022-06-22 13:42:52.413592
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(('1', '2', '3'), "test", "2.0")
    assert seq[1] == '2'

# Generated at 2022-06-22 13:42:54.478931
# Unit test for function set_constant
def test_set_constant():
    set_constant('name', 'value')
    assert globals()['name'] == 'value'

# Generated at 2022-06-22 13:42:59.299315
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list = ['a', 'b', 'c']
    constant = _DeprecatedSequenceConstant(list, "msg", "1")
    assert constant[0] == 'a'
    assert constant[2] == 'c'
    assert constant[1] == 'b'


# Generated at 2022-06-22 13:43:01.048287
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_constant = _DeprecatedSequenceConstant(list(), msg=None, version=None)
    assert len(seq_constant) == 0

if __name__ == '__main__':
    # Unit test
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-22 13:43:07.052387
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # `_DeprecatedSequenceConstant` class object with no values
    a = _DeprecatedSequenceConstant([], '', '')

    # `_DeprecatedSequenceConstant` class object with values
    b = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], '', '')

    # testing the `_DeprecatedSequenceConstant` class object
    assert len(a) == 0
    assert len(b) == 5



# Generated at 2022-06-22 13:43:10.754560
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')[0] == 1


# Generated at 2022-06-22 13:43:13.553947
# Unit test for function set_constant
def test_set_constant():
    set_constant('EXAMPLE', 'bar')
    assert EXAMPLE == 'bar'

# Generated at 2022-06-22 13:43:19.026078
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(('a', 'b'), 'message', 'version')
    assert len(c) == 2
    c = _DeprecatedSequenceConstant(['a', 'b'], 'message', 'version')
    assert len(c) == 2


# Generated at 2022-06-22 13:43:26.783793
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('ANSIBLE_FOO', 'bar', export)
    assert export['ANSIBLE_FOO'] == 'bar'
    set_constant('ANSIBLE_BAR', True, export)
    assert export['ANSIBLE_BAR'] is True
    set_constant('ANSIBLE_BAZ', [1, 2, 3], export)
    assert export['ANSIBLE_BAZ'] == [1, 2, 3]
    set_constant('ANSIBLE_QUX', {'a': True, 'b': False}, export)
    assert export['ANSIBLE_QUX'] == {'a': True, 'b': False}

if __name__ == "__main__":
    test_set_constant()

# Generated at 2022-06-22 13:43:49.128065
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant('test', 'this is a warning', '2.9.9')
    assert t[0] == 't'


# Generated at 2022-06-22 13:43:53.559689
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    val = ['test']
    msg = 'deprecation message'
    ver = 'version'
    dsc = _DeprecatedSequenceConstant(value=val, msg=msg, version=ver)
    assert dsc[0] == 'test'



# Generated at 2022-06-22 13:43:54.970570
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

# Generated at 2022-06-22 13:44:01.401132
# Unit test for function set_constant
def test_set_constant():
    # Test without 'export' argument
    set_constant('TEST_SET_CONSTANT_1', 1)
    del TEST_SET_CONSTANT_1
    # Test with 'export' argument
    export = {}
    set_constant('TEST_SET_CONSTANT_2', 2, export)
    assert export['TEST_SET_CONSTANT_2'] == 2

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-22 13:44:09.002568
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], msg='warning message', version='0.0')
    assert x._value == [1, 2, 3]
    assert x._msg == 'warning message'
    assert x._version == '0.0'
    assert len(x) == 3
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3


# Generated at 2022-06-22 13:44:09.983082
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(None, None, None).__len__() is None

# Generated at 2022-06-22 13:44:13.652976
# Unit test for function set_constant
def test_set_constant():
    ''' _load_config: test_set_constant() '''
    set_constant('TEST_KEY', 'TEST_VALUE')
    assert TEST_KEY == 'TEST_VALUE'


# FIXME: remove this once we no longer use the old config

# Generated at 2022-06-22 13:44:21.040179
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    import sys
    import io

    # Create a StringIO object for stdout
    stdout_io = io.StringIO()
    sys.stdout = stdout_io

    # Create a StringIO object for stderr
    stderr_io = io.StringIO()
    sys.stderr = stderr_io

    # Execute _DeprecatedSequenceConstant.__getitem__
    constants = _DeprecatedSequenceConstant([1, 2], 'msg', '1.0')
    constants[0]

    # Verify that stdout has a expected value
    assert stdout_io.getvalue() == ""

    # Verify that stderr has a expected value
    assert stderr_io.getvalue() == ' [DEPRECATED] msg, to be removed in 1.0\n'

    # Close stdout

# Generated at 2022-06-22 13:44:26.232019
# Unit test for function set_constant
def test_set_constant():
    assert HOST_KEY_CHECKING


if DEFAULT_SUBSET is None:
    # we do not yet support subsets in multiple strategy plugins, so this is a
    # workaround to make sure they are not set by default
    if PLAYBOOK_STRATEGY != 'free':
        DEFAULT_SUBSET = PLAYBOOK_STRATEGY
    elif TASK_STRATEGY != 'free':
        DEFAULT_SUBSET = TASK_STRATEGY
    else:
        DEFAULT_SUBSET = 'linear'


# Generated at 2022-06-22 13:44:32.735937
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Use arbitrary, non-string value for msg and version
    # Without Ansible Display class to rely on, this test just
    # verifies the deprecated class doesn't raise an exception
    test_msg = 12345
    test_version = 67890
    test_value = [1, 2, 3, 4]

    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert len(test_instance) == len(test_value)
    assert test_instance[1] == test_value[1]



# Generated at 2022-06-22 13:45:01.622953
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest
    d = _DeprecatedSequenceConstant([1,2,3], 'test message', '2.11')
    assert d[0] == 1

# Generated at 2022-06-22 13:45:04.435056
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', True)
    assert vars().get('TEST_SET_CONSTANT') is True

# Generated at 2022-06-22 13:45:10.023752
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test message', '2.9')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert len(dsc) == 3
    assert __version__ < '2.9'
    assert __version__ >= '2.9'

# Generated at 2022-06-22 13:45:15.283276
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    random_msg = 'some_message'
    msg_obj = _DeprecatedSequenceConstant([1, 2, 3], random_msg, '2.0')
    assert msg_obj[1] == 2
    assert msg_obj[2] == 3


# Generated at 2022-06-22 13:45:26.502580
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import warnings
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    instance = _DeprecatedSequenceConstant(['1', '2'], 'msg', 'version')
    assert '1' == instance[0]
    assert '2' == instance[1]
    assert is_sequence(instance)
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        assert '1' == instance[0]
        assert '2' == instance[1]
        assert is_sequence(instance)
        assert 1 == len(w)

# Generated at 2022-06-22 13:45:28.648559
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_msg = "this is a test"
    deprecated_version = "1.2.3"
    deprecated_list = _DeprecatedSequenceConstant([1, 2, 3], deprecated_msg, deprecated_version)
    assert len(deprecated_list) == 3
    assert deprecated_list[0] == 1
    assert deprecated_list[1] == 2

# Generated at 2022-06-22 13:45:32.651917
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'test data')
    assert ANSIBLE_TEST_CONSTANT == 'test data'

# Generated at 2022-06-22 13:45:35.392428
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], "msg", "1.0")
    assert len(c) == 3


# Generated at 2022-06-22 13:45:45.903879
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # pylint: disable=unused-variable
    new_class_dict = {'value': 11, 'msg': 'test msg', 'version': '1.10'}
    try:
        new_object = _DeprecatedSequenceConstant(**new_class_dict)
    except AssertionError:
        raise AssertionError('AssertionError raised, cannot construct object of class _DeprecatedSequenceConstant')
    if not isinstance(new_object, _DeprecatedSequenceConstant):
        raise AssertionError('newly constructed object not of class _DeprecatedSequenceConstant')
    # pylint: enable=unused-variable

# Generated at 2022-06-22 13:45:47.512156
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CALLBACK_WHITELIST == ("default",)

# Generated at 2022-06-22 13:46:45.136210
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import mock
    dep = _DeprecatedSequenceConstant([1, 2, 3], msg='my_message', version='1.0')
    with mock.patch('sys.stderr.write') as mock_write:
        assert dep[1] == 2
    mock_write.assert_called_once_with(' [DEPRECATED] my_message, to be removed in 1.0\n')


# Generated at 2022-06-22 13:46:52.968615
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(list(range(10)), "A message", "1.0")
    _DeprecatedSequenceConstant((0, 1, 2, 3), "A message", "1.0")
    _DeprecatedSequenceConstant(set(range(10)), "A message", "1.0")
    _DeprecatedSequenceConstant({0, 1, 2, 3}, "A message", "1.0")
    _DeprecatedSequenceConstant(dict(name="foo", location="bar"), "A message", "1.0")


# Generated at 2022-06-22 13:46:57.262061
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    list = [1, 2, 3]
    d = _DeprecatedSequenceConstant(list, msg, version)
    assert len(d) == 3

# Generated at 2022-06-22 13:47:09.896424
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['test']
    msg = 'this is a test'
    version = '2.0'
    x = _DeprecatedSequenceConstant(value, msg, version)
    assert len(x) == 1
    assert x[0] == 'test'

    # tests the action names
    assert len(_ACTION_DEBUG) == 1
    assert len(_ACTION_IMPORT_PLAYBOOK) == 1
    assert len(_ACTION_IMPORT_ROLE) == 1
    assert len(_ACTION_IMPORT_TASKS) == 1
    assert len(_ACTION_INCLUDE) == 1
    assert len(_ACTION_INCLUDE_ROLE) == 1
    assert len(_ACTION_INCLUDE_TASKS) == 1
    assert len(_ACTION_INCLUDE_VARS) == 1

# Generated at 2022-06-22 13:47:12.895596
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([0, 1, 2, 3], "foo", "bar")
    assert len(sequence) == 4


# Generated at 2022-06-22 13:47:18.019454
# Unit test for function set_constant
def test_set_constant():
    '''
    Test that set_constant is working as expected
    '''
    export = {}

    set_constant("foo", "foo", export)
    assert export['foo'] == "foo"

    set_constant("bar", "bar", export)
    assert 'bar' in export and export['bar'] == "bar"



# Generated at 2022-06-22 13:47:24.441848
# Unit test for function set_constant
def test_set_constant():

    # check whether a constant is set correctly
    set_constant('name', 'value')
    assert 'name' in vars() and vars()['name'] == 'value'

    # check whether a constant is overwritten correctly
    set_constant('name', 'new_value')
    assert 'name' in vars() and vars()['name'] == 'new_value'

test_set_constant()

# Generated at 2022-06-22 13:47:36.822056
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'foo bar', '1.4')
    assert len(x) == 3
    assert x[1] == 2
    assert x[0:2] == [1, 2]
    # test the deprecation warning
    x = _DeprecatedSequenceConstant([1, 2, 3], 'foo bar', '1.4')
    assert len(x) == 3, 'Len failed when deprecation warning has been shown'
    assert x[1] == 2, 'Indexing failed when deprecation warning has been shown'
    assert x[0:2] == [1, 2], 'Slicing failed when deprecation warning has been shown'

# Generated at 2022-06-22 13:47:44.858267
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    import os
    outfile = tempfile.NamedTemporaryFile()
    outfile.write("[defaults]\nfoo = bar\nzoo = {{ foo }}")
    outfile.flush()

    config = ConfigManager(['-c', outfile.name])
    for setting in config.data.get_settings():
        set_constant(setting.name, setting.value)

    assert foo == 'bar'
    assert zoo == 'bar'
    os.remove(outfile.name)


# Generated at 2022-06-22 13:47:53.244556
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'The test message'

    dep_tests = [
        # expected value, message, version, sequence constant
        (2, msg, '2.8', _DeprecatedSequenceConstant([1, 2, 3], msg, '2.8')),
        (1, msg, '2.8', _DeprecatedSequenceConstant([1], msg, '2.8')),
    ]

    for expected, msg, version, dep in dep_tests:
        # Check that correct value is returned
        assert dep[1] == expected
        # Check that warning is given
        assert dep._msg == msg
        # Check that version is correct
        assert dep._version == version

# Generated at 2022-06-22 13:49:51.312478
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    Test the __getitem__ method of the _DeprecatedSequenceConstant class

    Test data:
    value = ['test', 'data']
    msg = "test message"
    version = "test version"

    ExpectedResult:
    When a value is fetched from the class instance, the appropriate warning is displayed
    '''

    message = "test message"
    version = "test version"
    value = ['test', 'data']

    expected_result = ' [DEPRECATED] test message, to be removed in test version\n'

    dep_obj = _DeprecatedSequenceConstant(value, message, version)
    dep_obj[0]

    import sys
    assert sys.stderr.getvalue() == expected_result


# Generated at 2022-06-22 13:49:55.807922
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant(value=[x for x in range(3)], msg='warning message', version='2.11')
    assert len(d) == 3
    assert d[0] == 0 and d[1] == 1 and d[2] == 2

# Generated at 2022-06-22 13:50:02.933016
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Create a simple class to test
    class A(object):
        def __init__(self, value):
            self._value = value

        def __len__(self):
            return len(self._value)

    a = A([1, 2, 3])

    # Length of class A is 3
    assert len(a) == 3

    # Instantiate _DeprecatedSequenceConstant with length 3
    # and value [1, 2, 3]
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test message', 'v2.9')

    # Length of deprecated sequence constant is 3
    assert len(dsc) == 3



# Generated at 2022-06-22 13:50:04.848873
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = 'my message'
    instance = _DeprecatedSequenceConstant(list(), expected, '2.10')
    assert instance[0] ==  None


# Generated at 2022-06-22 13:50:08.320998
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    my_val = ["a", "b", "c"]
    obj = _DeprecatedSequenceConstant(my_val, msg, version)
    assert obj[1] == my_val[1]
    assert obj[-1] == my_val[-1]

# Generated at 2022-06-22 13:50:10.879061
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1,2,3], 'some text', 'some version')
    assert seq[1] == 2



# Generated at 2022-06-22 13:50:15.405660
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = add_internal_fqcns(['deprecated_sequence_constant_value', ])
    dsc = _DeprecatedSequenceConstant(seq, '', '3.1')
    assert dsc[0] == 'deprecated_sequence_constant_value'
    assert len(dsc) == 1

# Generated at 2022-06-22 13:50:22.764402
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "foo"
    version = "1.0"
    value = "foo"

    value_sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(value_sequence, _DeprecatedSequenceConstant)
    assert len(value_sequence) == len(value)

    value = [1, 2, 3]
    value_sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(value_sequence, _DeprecatedSequenceConstant)
    assert len(value_sequence) == len(value)


# Generated at 2022-06-22 13:50:24.984910
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(value=(1, 2, 3), msg='', version='')

# Generated at 2022-06-22 13:50:35.345889
# Unit test for function set_constant
def test_set_constant():
    from ansible.config.manager import Setting
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    import sys
    import os

    # Check that it's setting constants correctly
    set_constant('FOO1', 'BAR1')
    set_constant('FOO2', 'BAR2', builtins.__dict__)
    set_constant('FOO3', 'BAR3', sys.modules[__name__].__dict__)

    assert FOO1 == 'BAR1'
    assert FOO2 == 'BAR2'
    assert FOO3 == 'BAR3'

    # Check that it's not overwriting constants
    FOO4 = 'BAR4'