

# Generated at 2022-06-22 13:40:41.708644
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3


# Generated at 2022-06-22 13:40:53.773731
# Unit test for function set_constant
def test_set_constant():
    global ACME
    set_constant('ACME', 'acme', export=vars())
    assert ACME == 'acme'


# Aliases to deprecated constants
ACTION_DEBUG = _DeprecatedSequenceConstant(_ACTION_DEBUG, "Use ACTION_DEBUG instead of ACTION_DEBUG_VARS", '2.13')
ACTION_DEBUG_VARS = _ACTION_DEBUG
ACTION_IMPORT_PLAYBOOK = _ACTION_IMPORT_PLAYBOOK
ACTION_IMPORT_ROLE = _ACTION_IMPORT_ROLE
ACTION_IMPORT_TASKS = _ACTION_IMPORT_TASKS
ACTION_INCLUDE = _ACTION_INCLUDE
ACTION_INCLUDE_ROLE = _ACTION_INCLUDE_ROLE
ACTION_INCLUDE_TASKS = _ACTION_INCLUDE_T

# Generated at 2022-06-22 13:40:56.040732
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "This is a msg", "5.0")
    assert len(seq) == 3


# Generated at 2022-06-22 13:40:58.871118
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1,2,3], 'msg', 'v1')
    assert constant[1] == 2


# Generated at 2022-06-22 13:41:08.813755
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    classname = _DeprecatedSequenceConstant.__name__
    msg = 'This is a warning message for testing'
    version = '2.9'
    constant = _DeprecatedSequenceConstant([1, 2, 3], msg, version)

    # Test if 'constant' is a subclass of Sequence
    assert isinstance(constant, Sequence), \
        '{classname} object should be a subclass of Sequence'.format(classname=classname)

    # Test if the length of the 'constant' is 3
    assert len(constant) == 3, \
        '{classname} object should have 3 elements'.format(classname=classname)

    # Test if the first element of 'constant' is 1

# Generated at 2022-06-22 13:41:16.578737
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', 'test_version')
    assert len(constant) == 3
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3
    assert constant._msg == 'test_msg'
    assert constant._version == 'test_version'

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:41:24.687079
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_msg = "testing message"
    test_version = "2.0"
    test_seq_constant = _DeprecatedSequenceConstant([1, 2], test_msg, test_version)

    # Test with valid input
    value = test_seq_constant[1]
    assert (value == 2)

    # Test with invalid input
    value = test_seq_constant[0]
    assert (value == 1)


# Generated at 2022-06-22 13:41:32.648279
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert 'ANSIBLE_TEST_CONSTANT' in vars()
    assert vars()['ANSIBLE_TEST_CONSTANT'] == 'foo'

# Add fqcn to constants
ANSIBLE_MODULE_UTILS = add_internal_fqcns(('ansible.module_utils.', 'ansible.module_utils', ))
MODULE_REQUIRE_ARGS = _DeprecatedSequenceConstant(MODULE_REQUIRE_ARGS, 'Using the deprecated `MODULE_REQUIRE_ARGS` constant.  Please update your playbooks to use the `MODULE_REQUIRE_ARGS` property on the module_utils class as a sequence.', '2.8')

# provide a backwards compat for ansible.constants.MODULE

# Generated at 2022-06-22 13:41:45.733837
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    assert len(test) == 3
    assert test[0] == 'a'
    assert test[1] == 'b'
    assert test[2] == 'c'


# TODO: move to module_utils/connection_loader.py
# TODO: should we warn about non-str bool_no_log after deprecating ansible.module_utils.basic?

# Generated at 2022-06-22 13:41:50.972694
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(['1'], "msg", "1.0")
    assert s[0] == '1'
    s = _DeprecatedSequenceConstant((1, 2, 3, 4), "msg", "1.0")
    assert s[1] == 2

# Generated at 2022-06-22 13:42:02.060677
# Unit test for function set_constant
def test_set_constant():
    # Create a dict/class for testing
    test = {}

    # Set constants and run tests
    set_constant('HOSTNAME', 'localhost', export=test)
    if not test['HOSTNAME'] == 'localhost':
        raise AssertionError()

    set_constant('PORT', 22, export=test)
    if not test['PORT'] == 22:
        raise AssertionError()

    set_constant('PORT', 80, export=test)
    if not test['PORT'] == 80:
        raise AssertionError()

# Generated at 2022-06-22 13:42:06.073022
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    dep_value = _DeprecatedSequenceConstant(value=value, msg="msg", version="99.0")
    assert dep_value[1] == 2



# Generated at 2022-06-22 13:42:11.467135
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['foo', 'bar']
    msg = 'Some message'
    version = '2.11'

    dep_const = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dep_const) == len(value)


# Generated at 2022-06-22 13:42:14.801171
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    example_list = ['a', 'b', 'c']
    d = _DeprecatedSequenceConstant(example_list, "foo bar", "2.5")
    assert len(d) == 3

# Generated at 2022-06-22 13:42:23.267487
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from collections import namedtuple
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    Setting = namedtuple('Setting', 'name value type origin')

    # List of settings

# Generated at 2022-06-22 13:42:28.544179
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2, 3]
    msg = 'msg'
    version = 'v3'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)


# Generated at 2022-06-22 13:42:39.795995
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # create a list of data
    sample_list = ["item1", "item2", "item3"]

    # create a _DeprecatedSequenceConstant object and call method len on it
    _deprecated_sequence_constant = _DeprecatedSequenceConstant(sample_list, "dummy_msg", "dummy_version")
    lenghth_of_deprecated_sequence_constant = len(_deprecated_sequence_constant)

    # test that the len of the class is equal to the len of the data
    assert lenghth_of_deprecated_sequence_constant == len(sample_list)

# unit test for method __getitem(y) of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:42:42.233361
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')



# Generated at 2022-06-22 13:42:46.174288
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Dummy: pass
    s = Dummy()
    s.__len__ = lambda: 3
    d = _DeprecatedSequenceConstant(s, "", "")
    assert len(d) == 3


# Generated at 2022-06-22 13:42:59.502574
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _Test(object):
        def __init__(self):
            self.warn_message = []

        def deprecated(self, msg, version):
            self.warn_message.append(msg)

    # test the user of __getitem__
    for data in (('message', 'version'), ('other message', 'other version')):
        # new object
        warn_message = []
        test_obj = _Test()
        # init _DeprecatedSequenceConstant object with above data
        dsc = _DeprecatedSequenceConstant(range(10), data[0], data[1])
        # set the same test_obj to dsc by modify it
        dsc._version = test_obj
        # use __getitem__
        dsc[0]
        # get the test result

# Generated at 2022-06-22 13:43:03.018560
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 42)
    assert ANSIBLE_TEST_CONSTANT == 42


# Generated at 2022-06-22 13:43:07.734138
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['one', 'two', 'three']
    msg = 'This is a test message'
    version = '2.7'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant._msg == msg
    assert deprecated_sequence_constant._value == value
    assert deprecated_sequence_constant._version == version

# Generated at 2022-06-22 13:43:10.991880
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'this is a test message', '2.0')) == 3

# Generated at 2022-06-22 13:43:19.467841
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class __DeprecatedSequenceConstant___getitem__Test(unittest.TestCase):
        def test___getitem___normal(self):
            self.assertEqual(_DeprecatedSequenceConstant(value=[3, 2, 1], msg='deprecated', version='2.9').__getitem__(1), 2)

    unittest.main()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 13:43:24.408661
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('CONSTANT', 'value') == dict(CONSTANT='value')
    assert set_constant('CONSTANT', 'value', {}) == {'CONSTANT': 'value'}
    assert set_constant('CONSTANT', 'value', {'CONSTANT': 'value'}) == {'CONSTANT': 'value'}
    assert set_constant('CONSTANT2', 'value', {'CONSTANT': 'value'}) == {'CONSTANT': 'value', 'CONSTANT2': 'value'}
    assert set_constant('CONSTANT', 2, {}) == {'CONSTANT': 2}
    assert set_constant('CONSTANT', 2, {'CONSTANT': "2"}) == {'CONSTANT': 2}

# Make a version of all

# Generated at 2022-06-22 13:43:33.501852
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_cases = [
        # (msg, version, value, expected)
        ('foo', '1.0', [1, 2, 3], 1),
        ('foo', '1.0', (1, 2, 3), 1),
        ('foo', '1.0', {'foo': 1}, 1),
        ("foo", "1.0", 3.2, 3),
    ]
    for (msg, version, value, expected) in test_cases:
        dsc = _DeprecatedSequenceConstant(value, msg, version)
        actual = dsc[0]
        assert actual == expected

# Generated at 2022-06-22 13:43:35.812518
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'msg'
    version = 'version'
    x = _DeprecatedSequenceConstant([], msg, version)
    assert len(x) > 0


# Generated at 2022-06-22 13:43:41.310484
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t = _DeprecatedSequenceConstant([1,2,3], 'test', '2.10')
    assert len(t) == len([1,2,3])
    assert t[0] == 1
    assert t[1] == 2
    assert t[2] == 3

# Generated at 2022-06-22 13:43:44.257697
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('foo', 'bar', constants)
    assert constants['foo'] == 'bar'


# HELPER FUNCTIONS ###

# Generated at 2022-06-22 13:43:55.149154
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['foo', 'bar']
    msg = 'testing msg'
    version = 'testing version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    if dsc[0] != 'foo' or dsc[1] != 'bar':
        raise AssertionError('DeprecatedSequenceConstant not working. Got: %s' % dsc)
    if len(dsc) != 2:
        raise AssertionError('DeprecatedSequenceConstant not working. Got: %s' % len(dsc))

test__DeprecatedSequenceConstant()

# FIXME: when done with play_context changes, this can be removed

# Generated at 2022-06-22 13:44:06.995103
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'Your use of this class is deprecated'
    version = '2.10'
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 13:44:15.485666
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """ _DeprecatedSequenceConstant.__len__() """

    # _DeprecatedSequenceConstant.__len__() will not show warning message
    origin_len = len(_ACTION_ALLOW_WRITABLE_FILESYSTEMS)

    # _DeprecatedSequenceConstant.__len__() should show warning message
    len(_ACTION_ALLOW_WRITABLE_FILESYSTEMS)

    # should show warning message again
    len(_ACTION_ALLOW_WRITABLE_FILESYSTEMS)

    # _DeprecatedSequenceConstant.__len__() will not show warning message
    new_len = len(_ACTION_ALLOW_WRITABLE_FILESYSTEMS)

    assert origin_len == new_len

# Generated at 2022-06-22 13:44:17.219727
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test 1
    _DeprecatedSequenceConstant(['one', 'two'], "msg", "2.9")


# Generated at 2022-06-22 13:44:30.121065
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_string', 'happy_string')
    set_constant('test_num', 123)
    set_constant('test_list', ['foo', 'bar'])

    assert test_string == 'happy_string'
    assert test_num == 123
    assert test_list == ['foo', 'bar']


if config.get_config_value('paths', 'tree', __file__) is not None:
    TREE_DIR = config.get_config_value('paths', 'tree', __file__)

if config.get_config_value('DEFAULT', 'become_pass', None) is not None:
    DEFAULT_BECOME_PASS = config.get_config_value('DEFAULT', 'become_pass', None)


# Generated at 2022-06-22 13:44:33.285088
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_a = ['a', 'b', 'c']
    dsc_a = _DeprecatedSequenceConstant(list_a, "message", "1.6")
    assert dsc_a[0] == 'a'
    assert dsc_a[1] == 'b'
    assert dsc_a[2] == 'c'
    assert dsc_a[-1] == 'c'
    assert dsc_a[-2] == 'b'
    assert dsc_a[-3] == 'a'


# Generated at 2022-06-22 13:44:37.877899
# Unit test for function set_constant
def test_set_constant():
    name = 'test_set_constant'
    value = 'test_value'
    export = {}
    set_constant(name, value, export)
    assert export[name] == value

# Generated at 2022-06-22 13:44:40.960319
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    lst = _DeprecatedSequenceConstant([1,2,3], None, None)
    assert lst[0] == 1
    assert lst[2] == 3



# Generated at 2022-06-22 13:44:43.590786
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=(1, 2, 3), msg='deprecated msg', version='2.0').__getitem__(1) == 2

# Generated at 2022-06-22 13:44:48.722750
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='test')
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3



# Generated at 2022-06-22 13:45:00.717720
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import issequence
    from ansible.module_utils.common.collections import Sequence
    assert len(C.MODULE_COMMON_ARGUMENTS) == len(_DeprecatedSequenceConstant(C.MODULE_COMMON_ARGUMENTS, '', ''))
    assert isinstance(C.MODULE_COMMON_ARGUMENTS, Sequence)
    assert issequence(C.MODULE_COMMON_ARGUMENTS)
    assert issequence(C.MODULE_COMMON_ARGUMENTS) is True
    assert C.MODULE_COMMON_ARGUMENTS[0] == '_raw_params'
    assert C.MODULE_COMMON_ARGUMENTS[1] == '_uses_shell'
    assert C.MODULE_COMMON_

# Generated at 2022-06-22 13:45:11.280493
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ["a", "b", "c"]
    deprecated_msg = "msg"
    deprecated_version = "version"
    object_ = _DeprecatedSequenceConstant(value, deprecated_msg, deprecated_version)
    assert object_[0] == "a"
    assert object_[1] == "b"
    assert object_[2] == "c"


# Generated at 2022-06-22 13:45:15.335186
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'Test', '2.10')
    assert len(sequence) == 3


# Generated at 2022-06-22 13:45:18.274908
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'Testing _DeprecatedSequenceConstant', '2.0')
    b = _DeprecatedSequenceConstant(('Error:', 'Failed'), 'Some message', '2.0')
    assert(a[0] == 1 and a[1] == 2 and a[2] == 3)
    assert(b[0] == 'Error:' and b[1] == 'Failed')
    assert(len(a) == 3 and len(b) == 2)

# Generated at 2022-06-22 13:45:24.011160
# Unit test for function set_constant
def test_set_constant():
    def_export = {}
    set_constant('CONSTANT', 5, export=def_export)
    assert def_export['CONSTANT'] == 5


__all__ = tuple(k for k, v in locals().items() if not k.startswith('_'))
__all__ = add_internal_fqcns(__all__)

# Generated at 2022-06-22 13:45:26.249822
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='1.0')
    assert len(x) == 3

# Generated at 2022-06-22 13:45:31.363395
# Unit test for function set_constant
def test_set_constant():
    # Test string, integer and boolean
    set_constant('ansible_test_string', 'foobar', export=globals())
    assert ansible_test_string == 'foobar'
    set_constant('ansible_test_integer', 12, export=globals())
    assert ansible_test_integer == 12
    set_constant('ansible_test_boolean', False, export=globals())
    assert ansible_test_boolean is False

# end set_constant

# Generated at 2022-06-22 13:45:35.166557
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_TREE_DIR is None
    set_constant('DEFAULT_TREE_DIR', '/foo/bar')
    assert DEFAULT_TREE_DIR == '/foo/bar'

# Generated at 2022-06-22 13:45:42.058136
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(10, 'Test Value', 'Test Version')
    assert len(test_obj) == 10
    assert test_obj[1] == 'Test Value'


# do not remove the line below, it is needed for the docs build
# since this file is not referenced directly, it's not added to the module
# list in module_utils.__init__.py, so it needs to be added manually here
__all__ = ('config', 'test__DeprecatedSequenceConstant', )

# Generated at 2022-06-22 13:45:54.569175
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test None is returned if the value is None
    dsc = _DeprecatedSequenceConstant(None, "Any message", "Any version")
    assert dsc[0] is None
    assert dsc[1] is None

    # Test that correct index value is returned
    list_value = [1, 2, 3, 4]
    dsc = _DeprecatedSequenceConstant(list_value, "Any message", "Any version")
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[3] == 4

    # Test the default value of -1 is used if the index is not valid
    assert dsc[5] == 4
    assert dsc[-1] == 4

# Generated at 2022-06-22 13:46:06.944181
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class MockDisplay(object):
        def __init__(self):
            self.output = []

        def deprecated(self, msg, version='2.12'):
            self.output.append(msg)

    try:
        from ansible.utils.display import Display
    except Exception as e:
        setattr(Display, 'warning', MockDisplay().deprecated)

    test_value = range(10)
    test_msg = 'test message'
    test_version = '2.12'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 0
    assert test_obj[-1] == 9
    # getitem should deprecate, so we should see 1 warning message
    assert len(Display.warning.output) == 1
   

# Generated at 2022-06-22 13:46:24.563986
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        # use 'value' as some dummy string and msg, version as some random integers
        depr_sq = _DeprecatedSequenceConstant(value = 'test', msg = 1234, version = 4567)
        # assert Successful instantiation of class
        assert(True)
    except Exception:
        # assert Fail of instantiation of class
        assert(False)


# Generated at 2022-06-22 13:46:37.337313
# Unit test for function set_constant
def test_set_constant():

    # Use __builtin__ to avoid polluting function namespace
    import __builtin__
    import sys

    # Test defaults brought in via config
    assert __builtin__.DEFAULT_ASSEMBLE_SYMLINK_TREES == 'no'
    assert __builtin__.DEFAULT_BECOME == 'no'
    assert __builtin__.DEFAULT_BECOME_ASK_PASS == 'no'
    assert __builtin__.DEFAULT_BECOME_EXE is None
    assert __builtin__.DEFAULT_BECOME_METHOD == 'sudo'
    assert __builtin__.DEFAULT_BECOME_PASS is None
    assert __builtin__.DEFAULT_BECOME_USER == 'root'
    assert __builtin__.DEFAULT_CHECK_MODE == 'no'
    assert __

# Generated at 2022-06-22 13:46:49.440325
# Unit test for function set_constant
def test_set_constant():
    set_constant('_TEST_STRING_CONSTANT', 'foo')
    assert _TEST_STRING_CONSTANT == 'foo'

    set_constant('_TEST_INT_CONSTANT', 1)
    assert _TEST_INT_CONSTANT == 1

    set_constant('_TEST_DICT_CONSTANT', dict(a=1, b=2))
    assert _TEST_DICT_CONSTANT == dict(a=1, b=2)

    set_constant('_TEST_LIST_CONSTANT', [1, 2])
    assert _TEST_LIST_CONSTANT == [1, 2]

    set_constant('_TEST_BOOL_CONSTANT', False)
    assert _TEST_BOOL_CONSTANT is False

   

# Generated at 2022-06-22 13:46:51.761469
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test_msg', version='test_version')
    assert test_constant[2] == 3

# Generated at 2022-06-22 13:46:55.655007
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant((1, 2, 3), 'test', '2.9')
    assert(len(seq) == 3)

# Generated at 2022-06-22 13:47:07.335103
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class X():
        def __init__(self):
            self._value = (1, 2, 3)
            self._msg = 'my msg'
            self._version = '2.9'
            self.x = _DeprecatedSequenceConstant(self._value, self._msg, self._version)

        def test_run(self):
            assert self.x._value == (1, 2, 3)
            assert self.x._msg == 'my msg'
            assert self.x._version == '2.9'
            assert self.x.__getitem__(1) == 2
            try:
                import sys
                assert sys.stderr.write == ' [DEPRECATED] my msg, to be removed in 2.9\n'
            except Exception:
                pass

    a = X()
    a.test_

# Generated at 2022-06-22 13:47:19.595016
# Unit test for function set_constant
def test_set_constant():
    foo = {'a': 'A'}
    set_constant('foo', 'FOO', foo)
    set_constant('foo', {'b': 'B'})
    assert foo['foo'] == 'FOO'
    globals()['foo'] = {'c': 'C'}
    set_constant('foo', 'FOO')
    assert foo == {'c': 'C', 'foo': 'FOO'}
    assert globals()['foo'] == 'FOO'


# DEPRECATED SETTINGS - migrate to the right place
if config.data._parser.has_option('defaults', 'accelerate_port'):
    _deprecated("[defaults] accelerate_port is now [accelerate] accelerate_port", version='2.11')
    ACCELERATE_PORT = to_

# Generated at 2022-06-22 13:47:27.515694
# Unit test for function set_constant
def test_set_constant():
    set_constant('__test', 'testing')
    assert globals()['__test'] == 'testing'
    set_constant('__num', 55)
    assert globals()['__num'] == 55
    return bool(globals()['__test'] == 'testing' and globals()['__num'] == 55)

# Display deprecation warning for deprecated constants

for constant in dir():
    if constant.startswith('DEFAULT_'):
        if '_DEPRECATED' in constant:
            _deprecated(globals()[constant], version='v4.0')

# if we are in a check mode, we don't want a pager
if CHECK_MODE:
    PAGER = None

# FIXME: remove once the dependent code is removed

# Generated at 2022-06-22 13:47:30.493360
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(('first', 'second'), 'This is deprecated', 'ansible 2.10')
    assert constant[0] == 'first'
    assert constant[1] == 'second'

# Generated at 2022-06-22 13:47:32.302283
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # do nothing, this method is tested above in the constants that use it.
    pass

# Generated at 2022-06-22 13:47:50.978589
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], '', '')) == 2
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0


# Generated at 2022-06-22 13:47:52.828809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[0, 1, 2], msg='test', version='test')) == 3

# Generated at 2022-06-22 13:47:56.414539
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = 'test value'
    msg = "deprecated message"
    version = "2.10"
    deprecated = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated) == len(value)



# Generated at 2022-06-22 13:47:57.930655
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 3)
    assert FOO == 3

# Generated at 2022-06-22 13:48:03.560812
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys

    # Mock out display.Display
    class DisplayMock(object):
        def __init__(self):
            self.was_called = False

        def deprecated(self, msg, version):
            sys.stderr.write(' [DEPRECATED] %s, to be removed in %s\n' % (msg, version))
            self.was_called = True

    # Mock out display.Display.deprecated
    _display = DisplayMock()
    DSC = _DeprecatedSequenceConstant(('msg', ), _display, 'version')

    # Call method __getitem__ and assert that the instance of class DisplayMock was called
    returned_value = DSC[0]
    assert returned_value == 'msg'
    assert _display.was_called



# Generated at 2022-06-22 13:48:11.355540
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    msg = "A warning message"
    version = "v3.0"
    # _DeprecatedSequenceConstant should print the warning message only once
    # when calling its method
    test_value = [AnsibleUnsafeText(u'foo'), AnsibleUnsafeText(u'bar')]
    test_object = _DeprecatedSequenceConstant(test_value, msg, version)
    assert len(test_object) == 2
    assert test_object[0] == AnsibleUnsafeText(u'foo')
    assert test_object[1] == AnsibleUnsafeText(u'bar')

# Generated at 2022-06-22 13:48:16.038302
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.0')) == 3


# Generated at 2022-06-22 13:48:21.409544
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    Test for the method _DeprecatedSequenceConstant.__len__()

    Test if _DeprecatedSequenceConstant.__len__() raises
    a _deprecated() warning.

    @covers: _DeprecatedSequenceConstant.__len__
    """
    val = _DeprecatedSequenceConstant(value=[1,2,3], msg='testing', version='9999')
    val.__len__()


# Generated at 2022-06-22 13:48:25.121351
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], "Warning message", "3.0")
    assert len(s) == 3, "_DeprecatedSequenceConstant.__len__ does not work"


# Generated at 2022-06-22 13:48:29.711842
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'This is a test message', '2.9')
    assert len(d) == 3
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3

# Generated at 2022-06-22 13:49:06.464355
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant(1, "MSG", "2.2")
    assert len(s) == 1

# Generated at 2022-06-22 13:49:09.199635
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'test message', 'test version')
    assert dsc[0] == 1


# Generated at 2022-06-22 13:49:12.400525
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dc = _DeprecatedSequenceConstant((1, 2, 3), 'some message', 'some version')
    for i in range(3):
        assert dc[i] == i + 1, 'failed on index %s' % i

# Generated at 2022-06-22 13:49:17.318529
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # sequence to test
    test_sequence = [1, 2, 3]

    msg = "test message"
    version = "test version"

    # prepare test object
    obj = _DeprecatedSequenceConstant(test_sequence, msg, version)

    # test __getitem__
    assert obj[1] == 2


# Generated at 2022-06-22 13:49:19.154604
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

# Generated at 2022-06-22 13:49:21.805926
# Unit test for function set_constant
def test_set_constant():
    name = 'test_var'
    value = 99
    set_constant(name, value, export=globals())
    assert globals()[name] == value

# Generated at 2022-06-22 13:49:23.432612
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'test')
    assert vars()['test'] == 'test'


# Generated at 2022-06-22 13:49:30.909867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Ensure that _DeprecatedSequenceConstant contains a list of string
    dummy_value = 'dummy_value'
    dummy_msg = 'dummy_msg'
    dummy_version = 'dummy_version'
    dsc_object = _DeprecatedSequenceConstant(dummy_value, dummy_msg, dummy_version)
    assert isinstance(dsc_object, Sequence) and isinstance(dsc_object, _DeprecatedSequenceConstant)
    assert len(dsc_object) == len(dummy_value)
    assert str(dsc_object[0]) == str(dummy_value)

# FIXME: split out into a proper plugin class
# NOTE: this is just to pass in the API to the plugin's init() method
# also used to pass around the ansible_module object to get callback refs


# Generated at 2022-06-22 13:49:33.478871
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')
    assert len(d) == 3


# Generated at 2022-06-22 13:49:39.554578
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "msg"
    version = "version"
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Check that class properly is a subclass of Sequence
    assert issubclass(_DeprecatedSequenceConstant, Sequence)