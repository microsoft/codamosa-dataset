

# Generated at 2022-06-22 13:40:45.656549
# Unit test for function set_constant
def test_set_constant():
    set_constant("var", "value")
    assert var == "value"



# Generated at 2022-06-22 13:40:48.421263
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c1 = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.8')
    assert len(c1) == 3


# Generated at 2022-06-22 13:40:54.496094
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dep_list = ('test1', 'test2', 'test3')
    msg = 'test message'
    version = '2.9.9'
    dep = _DeprecatedSequenceConstant(dep_list, msg, version)
    assert len(dep) == len(dep_list)
    assert dep[0] == 'test1'
    assert dep[-1] == 'test3'
    assert len(dep) == len(dep_list)


# Generated at 2022-06-22 13:41:02.111699
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class FakeDisplay:
        def __init__(self):
            pass
        def deprecated(self, msg, version=None):
            pass
    value = []
    msg = "Deprecation Warning"
    version = "2.4"
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert obj[0] == value[0]



# Generated at 2022-06-22 13:41:05.749911
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Create an object, assign a value and call method __len__
    sequence = _DeprecatedSequenceConstant([1, 2, 3], "The message", "2.0")
    result = sequence.__len__()

    # Assert result to expected
    assert result == 3

# Generated at 2022-06-22 13:41:13.992419
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Unit test for method __getitem__ of class _DeprecatedSequenceConstant."""
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        """Unit test for method __getitem__ of class _DeprecatedSequenceConstant."""

        @patch('ansible.utils.constants.DeprecatedWarning')
        def test__DeprecatedSequenceConstant___getitem__(self, mock_DeprecatedWarning):
            """Test case for method __getitem__ of class _DeprecatedSequenceConstant."""
            value = ['foo', 'bar']
            msg = 'This option is deprecated'
            version = '2.5'
            _DeprecatedSequenceConstant(value, msg, version)

# Generated at 2022-06-22 13:41:20.218707
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import datetime
    ver = '2.12'
    msg = "The foo module is deprecated"
    d = _DeprecatedSequenceConstant(sys.modules, msg, ver)
    assert d['datetime'], "Failed to return the datetime module"
    assert d['datetime'].__name__ == 'datetime'
    assert "Failed to display warning message in the _getitem__ method"

# Generated at 2022-06-22 13:41:30.695879
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """test NotPermittedValue object"""
    from unittest import TestCase
    from unittest.mock import patch

    def setUpModule():
        global t
        t = _DeprecatedSequenceConstant(value=('banana',), msg='message', version='0.0.0')
        global mock
        mock = patch.object(t, '_deprecated')

    def test_getitem_calls_deprecated(self):
        with mock as mock_deprecated:
            assert t[0] == 'banana'
            assert mock_deprecated.call_count == 2

    def test_getitem_calls_deprecated_with_args(self):
        with mock as mock_deprecated:
            assert t[0] == 'banana'
            assert mock_deprecated.call_count == 2
            mock

# Generated at 2022-06-22 13:41:38.555438
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This will be removed in a later release"
    version = "2.8"
    test_value = [1, 2, 3, 4]
    test_constant = _DeprecatedSequenceConstant(test_value, msg, version)
    # Test length
    len_value = len(test_constant)
    assert len_value == len(test_value)
    # Test iteration
    for i in test_constant:
        assert i in test_value

# Generated at 2022-06-22 13:41:51.669741
# Unit test for function set_constant
def test_set_constant():
    _test_constant = 'test_constant'
    assert _test_constant not in locals().keys()
    for item in ('test_new_constant','test_invalid','1test','test-invalid','invalid-test','test!','test[','test]','test{','test}','test(','test)',
                 'test@','test#','test$','test%','test&','test?','test:','test"','test\\','test/','test<','test>'):
        if item in locals().keys():
            locals().pop(item)
    assert _test_constant not in locals().keys()

    set_constant('_test_constant', 'test_string')
    assert _test_constant in locals().keys()

    set_constant(_test_constant, 'test_str')


# Generated at 2022-06-22 13:41:58.117788
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    instance = _DeprecatedSequenceConstant(('ansible', 'mazu'), 'msg', 'version')
    assert instance[0] == 'ansible'
    assert instance[1] == 'mazu'



# Generated at 2022-06-22 13:42:02.497958
# Unit test for function set_constant
def test_set_constant():

    from ansible.module_utils.common.constants import set_constant
    constants_dict = {}
    set_constant('foo', 'bar', export=constants_dict)
    assert constants_dict == {'foo': 'bar'}

# Generated at 2022-06-22 13:42:08.135943
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.5')
    assert len(obj) == 3
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3


# Generated at 2022-06-22 13:42:16.377864
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
        msg = "The following variables are deprecated and will be removed in Ansible 2.9: ansible_ssh_user, ansible_ssh_host"
        version = "2.9"
        test_deprecated_seq_obj = _DeprecatedSequenceConstant(['ansible_ssh_user', 'ansible_ssh_host'], msg, version)
        assert test_deprecated_seq_obj[0] == 'ansible_ssh_user' and test_deprecated_seq_obj[1] == 'ansible_ssh_host'


# Generated at 2022-06-22 13:42:23.146888
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Setup
    test_value = ['ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible','ansible']
    test_instance = _DeprecatedSequenceConstant(value=test_value,
                                                msg="Don't use this.",
                                                version='2.10')

    # Exercise
    for i in range(len(test_value)):
        assert test_instance[i] == test_value[i]

    # Verify
    # Nothing to verify.
    # Cleanup
    # Nothing to cleanup.

# Generated at 2022-06-22 13:42:30.758714
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant_list = ('ansible_connection', 'ansible_ssh_user')
    msg = 'the option "ansible_ssh_user" is deprecated, use "ansible_user" instead'
    version = '2.10'
    sequence = _DeprecatedSequenceConstant(deprecated_constant_list, msg, version)
    assert len(sequence) == len(deprecated_constant_list)
    assert sequence[0] == deprecated_constant_list[0]

# Generated at 2022-06-22 13:42:36.371891
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "message"
    seq = (1, 2, 3)
    version = "1.2.3"
    dsc = _DeprecatedSequenceConstant(seq, msg, version)
    assert len(dsc) == 3
    assert dsc[1] == 2


# Generated at 2022-06-22 13:42:38.086980
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant(_ACTION_ALL_INCLUDE_TASKS, '', '')[0]

# Generated at 2022-06-22 13:42:40.727575
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(['a', 'b'], "test", "2.1")

# Generated at 2022-06-22 13:42:46.296415
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = 'ansible_ssh_common_args'
    version = '2.12'
    msg = "ansible_ssh_common_args is deprecated since 2.8, use ansible_ssh_common_args instead"
    sequence = _DeprecatedSequenceConstant([], msg, version)
    length = len(sequence)
    assert length == 0


# Generated at 2022-06-22 13:42:56.424895
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")

    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 13:43:05.422765
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(['0', '1', '2', '3', '4'], 'msg', 'version')
    assert d[0] == '0'
    assert d[1] == '1'
    assert d[2] == '2'
    assert d[3] == '3'
    assert d[4] == '4'
    assert d[-5] == '0'
    assert d[-4] == '1'
    assert d[-3] == '2'
    assert d[-2] == '3'
    assert d[-1] == '4'


# Generated at 2022-06-22 13:43:07.340282
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = 1
    value = _DeprecatedSequenceConstant([1], "msg", "version")[0]
    assert value == expected


# Generated at 2022-06-22 13:43:11.251231
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.0')
    assert test_sequence.__getitem__(1) == 2

# Generated at 2022-06-22 13:43:20.158965
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test'
    version = '2.9'
    s = ['test']
    d = _DeprecatedSequenceConstant(s, msg, version)
    assert d[0] == 'test'
    assert len(d) == 1
    # Since this class does not support key errors, follow type doesn't matter
    # assert d['1'] == 'test'
    # assert len(d) == 1
    # assert d['name'] == 'test'
    # assert len(d) == 1

# Generated at 2022-06-22 13:43:22.842403
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1,2,3], 'test_msg', '2.9')
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3

# Generated at 2022-06-22 13:43:26.545190
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(None, None, None)
    assert len(dsc) == 0

# Generated at 2022-06-22 13:43:34.968353
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    tests = [
        (['name1'], 'msg', '2.9'),
        (['name1', 'name2'], 'msg', '2.9'),
        (['name1', 'name2', 'name3'], 'msg', '2.9'),
    ]

    for test in tests:
        dsc = _DeprecatedSequenceConstant(test[0], test[1], test[2])
        assert len(dsc) == len(test[0])
        for i in range(len(test[0])):
            assert dsc[i] == test[0][i]

# Generated at 2022-06-22 13:43:39.383063
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'this is a warning', '2.9')
    assert seq[0] == 'a'
    assert seq[-1] == 'c'
    assert len(seq) == 3

# Generated at 2022-06-22 13:43:43.211801
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    erroneous_options = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')
    assert len(erroneous_options) == 2
    assert erroneous_options[0] == 'a'
    assert erroneous_options[1] == 'b'

# Generated at 2022-06-22 13:44:07.907435
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo', export=test_dict)
    assert test_dict['ANSIBLE_TEST_CONSTANT'] == 'foo'
    set_constant('ANSIBLE_TEST_CONSTANT', 'bar', export=test_dict)
    assert test_dict['ANSIBLE_TEST_CONSTANT'] == 'bar'


# Set up the rest of the non-config derived constants
set_constant('CONFIGURABLE_PLUGINS', frozenset(CONFIGURABLE_PLUGINS))
set_constant('DOCUMENTABLE_PLUGINS', frozenset(DOCUMENTABLE_PLUGINS))


# Generated at 2022-06-22 13:44:12.366162
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my_list = [1, 2, 3]
    my_msg = 'This message is deprecated'
    my_version = 'my_version'

    assert len(my_list) == len(_DeprecatedSequenceConstant(my_list, my_msg, my_version))



# Generated at 2022-06-22 13:44:16.827415
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_message = 'Test message'
    test_version = '1.2.3'
    test_value = ()
    test_object = _DeprecatedSequenceConstant(test_value, test_message, test_version)
    if len(test_object) is not 0:
        raise AssertionError
    if test_object[0] is not None:
        raise AssertionError

# Generated at 2022-06-22 13:44:28.971281
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MockWarning(object):
        def __init__(self):
            self.calls = []

        def __call__(self, msg, version):
            self.calls.append((msg, version))

    mock_warning = MockWarning()

    _warning = mock_warning

    value = ('one', 'two', 'three')
    msg = 'test msg'
    version = 'test version'
    seq = _DeprecatedSequenceConstant(value, msg, version)

    assert mock_warning.calls == []

    for idx, item in enumerate(value):
        assert seq[idx] == item
        assert mock_warning.calls == [(msg, version)]
        mock_warning.calls = []



# Generated at 2022-06-22 13:44:30.952184
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(value = ['a','b','c'], msg = 'msg', version = '2.0')
    assert c[0] == 'a'
    assert c[1] == 'b'
    assert c[2] == 'c'


# Generated at 2022-06-22 13:44:37.931377
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test:
        def __init__(self, val):
            self.val = val

        def __len__(self):
            return len(self.val)

    test = Test([1, 2, 3])
    assert len(test) == 3
    assert len(_DeprecatedSequenceConstant(test, 'msg', '1.0')) == 3



# Generated at 2022-06-22 13:44:41.997644
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3, 4], "msg", "version")
    assert len(d) == 4
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3
    assert d[3] == 4

# Generated at 2022-06-22 13:44:48.226329
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test if _DeprecatedSequenceConstant works correctly when index is
    #   not greater than the value length
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test if _DeprecatedSequenceConstant raises IndexError when index is greater
    #   than the value length
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')
    try:
        test_obj[3]
        assert False, '_DeprecatedSequenceConstant fails to raise IndexError'
    except IndexError:
        pass



# Generated at 2022-06-22 13:44:49.982941
# Unit test for function set_constant
def test_set_constant():
    ''' test setting constants '''
    try:
        set_constant('FOO', "bar")
        assert FOO == "bar"
    except Exception:
        raise Exception('set_constant function failed to set a constant')

test_set_constant()

# Generated at 2022-06-22 13:44:54.740464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ok = _DeprecatedSequenceConstant([1,2,3], 'msg', '1.0')
    assert len(ok) == 3
    assert ok[1] == 2
    assert ok._value == [1,2,3]
    assert ok._msg == 'msg'
    assert ok._version == '1.0'

# Generated at 2022-06-22 13:45:26.165791
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'v1')
    assert 1 == constant[0]
    assert 2 == constant[1]
    assert 3 == constant[2]
    try:
        constant[3]
        assert False
    except IndexError:
        pass

# Generated at 2022-06-22 13:45:33.298568
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([], 'test', '2.9')



# Generated at 2022-06-22 13:45:36.369631
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    actual = _DeprecatedSequenceConstant(('a', 'b',), 'msg', '1.0')
    assert actual[0] == 'a'
    assert actual[1] == 'b'



# Generated at 2022-06-22 13:45:37.557853
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testcase = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(testcase) == 3



# Generated at 2022-06-22 13:45:41.413224
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    hello_world = _DeprecatedSequenceConstant(
            ['hello', 'world'],
            'Using deprecated hello world',
            '2.3')
    assert len(hello_world) == 2
    assert hello_world[0] == 'hello'

# Generated at 2022-06-22 13:45:54.382725
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 'value', vars())
    assert vars()['TEST_SET_CONSTANT'] == 'value'
    del vars()['TEST_SET_CONSTANT']

# Additional constants
dummy = _DeprecatedSequenceConstant(DEFAULT_BECOME_PASS, 'constant DEFAULT_BECOME_PASS is deprecated, use config option become_pass instead', '2.11')
DEFAULT_BECOME_PASS = dummy
dummy = _DeprecatedSequenceConstant(DEFAULT_REMOTE_PASS, 'constant DEFAULT_REMOTE_PASS is deprecated, use config option remote_pass instead', '2.11')
DEFAULT_REMOTE_PASS = dummy
VERSION = __version__

# Generated at 2022-06-22 13:46:02.523455
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test__DeprecatedSequenceConstant:
        def __init__(self):
            self.msg = 'msg'
            self.version = 'version'
            self.myobj = _DeprecatedSequenceConstant(['that', 'item'], self.msg, self.version)

        def test__getitem__(self):
            self.assertEqual('that', self.myobj[0])

    tester = Test__DeprecatedSequenceConstant()
    tester.test__getitem__()


# Generated at 2022-06-22 13:46:07.796313
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(value=[1,2,3], msg='this is a test msg', version='2.10')
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    _deprecated('this is a test msg', '2.10')

# Generated at 2022-06-22 13:46:20.476865
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, i):
            self.i = i
        def __repr__(self):
            return 'Test(%d)' % self.i

    class TestCollection(Sequence):
        def __init__(self, items):
            self._items = items
        def __len__(self):
            return len(self._items)
        def __getitem__(self, i):
            return self._items[i]

    collection = TestCollection([
        Test(0),
        Test(1),
        Test(2),
        Test(3),
    ])

    constant = _DeprecatedSequenceConstant(collection, 'this is deprecated', '2.9')

    assert constant[1] is collection[1]
    assert constant[1].i == 1



# Generated at 2022-06-22 13:46:26.829712
# Unit test for function set_constant
def test_set_constant():
    set_constant("TEST_CONSTANT_ONE", "test_1")
    set_constant("TEST_CONSTANT_TWO", "test_2")
    set_constant("TEST_CONSTANT_THREE", "test_3", export={})
    return "TEST_CONSTANT_ONE" in locals() and "TEST_CONSTANT_TWO" in globals() and "TEST_CONSTANT_THREE" not in locals() and "TEST_CONSTANT_THREE" not in globals()
assert test_set_constant()


# generate deprecated sequence constants

# Generated at 2022-06-22 13:47:22.379915
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')[1] == [1, 2, 3][1]

# Generated at 2022-06-22 13:47:29.624869
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    from ansible.utils.display import Display
    from io import StringIO

    messages = [
        'MESSAGE1',
        'MESSAGE2',
    ]
    versions = [
        '1.0.0',
        '2.0.0',
    ]

    output_buffer = StringIO()
    display = Display()
    display.verbosity = 2
    display.deprecated = lambda x, y: output_buffer.write(' [DEPRECATED] %s to be removed in %s\n' % (x, y))
    sys.stderr = output_buffer

    for x in range(0, len(messages)):
        _DeprecatedSequenceConstant(['A', 'B', 'C'], messages[x], versions[x])[0]
        assert output_buffer

# Generated at 2022-06-22 13:47:36.450666
# Unit test for function set_constant
def test_set_constant():
    v = {}
    set_constant('foo', 'bar', export=v)
    assert v['foo'] == 'bar'
    v = {}
    set_constant('foo', 'bar', export=v)
    assert v['foo'] == 'bar'
    v = {}
    set_constant('foo', 'bar', export=v)
    assert v['foo'] == 'bar'

# Generated at 2022-06-22 13:47:46.461099
# Unit test for function set_constant
def test_set_constant():
    assert CONFIG_FILE == '/etc/ansible/ansible.cfg'
    assert DEFAULT_ASK_PASS
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert DEFAULT_MODULE_NAME == 'command'
    assert DEFAULT_MODULE_PATH is None
    assert DEFAULT_PRIVATE_KEY_FILE == '~/.ssh/id_rsa'
    assert DEFAULT_REMOTE_USER == 'root'
    assert DEFAULT_SUDO == True
    assert DEFAULT_SUDO_EXE == 'sudo'
    assert DEFAULT_SUDO_FLAG == '-S'
    assert DEFAULT_SUDO

# Generated at 2022-06-22 13:47:56.495849
# Unit test for function set_constant
def test_set_constant():
    test_constants = dict()

    set_constant('a', '1', test_constants)
    set_constant('b', '2', test_constants)
    set_constant('c', '3', test_constants)

    assert test_constants.get('a') == '1'
    assert test_constants.get('b') == '2'
    assert test_constants.get('c') == '3'


TREE_DIR = TREE_DIR or 'cachedir'

# TODO: needs more work and doesn't work with run_once
_SENSITIVE_VARS = ('ansible_password', 'ansible_ssh_pass', 'ansible_become_pass')
# TODO: needs more work and doesn't work with run_once
_BLACKLIST_PLUGINS

# Generated at 2022-06-22 13:48:02.358761
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'
    assert vars()['FOO'] == 'BAR'
    set_constant('BAZ', 'BAZ', globals())
    assert vars()['BAZ'] == 'BAZ'
    # TODO: we did not set these in tests/__init__.py
    set_constant('BOOTSTRAPPING_WITH_ASK_PASS', True)
    assert BOOTSTRAPPING_WITH_ASK_PASS is True
    set_constant('PARAMIKO_RECORD_HOST_KEYS', True)
    assert PARAMIKO_RECORD_HOST_KEYS is True

# Generated at 2022-06-22 13:48:05.179873
# Unit test for function set_constant
def test_set_constant():
    ''' Test that constants are properly set

    :return: None
    '''
    # Test invalid cases
    set_constant(None, None)
    # Test valid cases
    set_constant('ANSIBLE_CONFIG', '/etc/ansible/ansible.cfg')


MAX_TIMEOUT_TEST = 3.0
PIPE_TIMEOUT_TEST = 1.0

# UNIT TESTS FOR CONFIG MANAGER #

# Generated at 2022-06-22 13:48:06.450313
# Unit test for function set_constant
def test_set_constant():
    set_constant('testing', 'hello')
    assert testing == 'hello'

# Generated at 2022-06-22 13:48:10.475485
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(["a"], "deprecation message", "version")
    assert c[0] == "a"
    assert len(c) == 1
    assert list(c) == ["a"]

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-22 13:48:19.644996
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''Unit test for __len__ method of class _DeprecatedSequenceConstant'''

    test_string = "test-string"
    test_msg = "Deprecated message"
    test_version = "1.1.1"
    test_sequence_constant = _DeprecatedSequenceConstant(test_string,
                                                         test_msg,
                                                         test_version)

    assert len(test_sequence_constant) == len(test_string)

# Generated at 2022-06-22 13:50:17.519911
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    result = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(result) == 3

# Generated at 2022-06-22 13:50:24.799798
# Unit test for function set_constant
def test_set_constant():
    global DEFAULT_BECOME_PASS
    set_constant('DEFAULT_BECOME_PASS', 'test', vars())
    assert DEFAULT_BECOME_PASS == 'test'

# Deprecated Constants
DEPRECATED_HOST_LIST = _DeprecatedSequenceConstant(value=LOCALHOST, msg='ansible.constants.LOCALHOST is deprecated, use ansible.constants.DEFAULT_LOCAL_HOST or ansible.constants.LOCALHOST_ERROR_MSG', version='2.12')

# Generated at 2022-06-22 13:50:28.988197
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant([1,2,3], 'msg', '2.2')
    assert len(l) == 3


# Generated at 2022-06-22 13:50:32.592172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_object = _DeprecatedSequenceConstant([1,2,3], 'msg', '0.0')
    assert seq_object[0] == 1
    assert seq_object[1] == 2
    assert seq_object[2] == 3
    assert len(seq_object) == 3

# Generated at 2022-06-22 13:50:36.419926
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(('a', 'b'), msg='msg', version='version')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert len(seq) == 2
    c, d = seq
    assert c == 'a' and d == 'b'
    assert seq.count('a') == 1


# Generated at 2022-06-22 13:50:44.603971
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.collections import Sequence

    test_value = ('test0', 'test1', 'test2')
    test_msg = 'test_msg'
    test_version = 'test_version'

    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert isinstance(test_obj, Sequence)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version

    assert len(test_obj) == 3

    res = test_obj[0]
    assert res == 'test0'

    res = test_obj[1]
    assert res == 'test1'

