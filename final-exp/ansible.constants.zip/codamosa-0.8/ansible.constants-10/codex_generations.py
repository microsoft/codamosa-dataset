

# Generated at 2022-06-22 13:40:50.285146
# Unit test for function set_constant
def test_set_constant():

    # Set to known values
    set_constant('ANSIBLE_MODULE_ARGS_IGNORE_UNKNOWN_KEYS', True)
    assert ANSIBLE_MODULE_ARGS_IGNORE_UNKNOWN_KEYS is True
    set_constant('ANSIBLE_MODULE_ARGS_IGNORE_UNKNOWN_KEYS', False)
    assert ANSIBLE_MODULE_ARGS_IGNORE_UNKNOWN_KEYS is False

    set_constant('ANSIBLE_PROCESS_ISOLATED', True)
    assert ANSIBLE_PROCESS_ISOLATED is True
    set_constant('ANSIBLE_PROCESS_ISOLATED', False)
    assert ANSIBLE_PROCESS_ISOLATED is False


# Generated at 2022-06-22 13:40:55.158409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([], '', '4.4').__len__() == 0
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '4.4').__len__() == 3
    assert _DeprecatedSequenceConstant((1, 2, 3), '', '4.4').__len__() == 3


# Generated at 2022-06-22 13:41:00.699663
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(value=[], msg='', version='')
    assert len(x) == 0
    assert x[0] == 0
    assert x._value == x[0]
    assert x._msg == ''
    assert x._version == ''

# Generated at 2022-06-22 13:41:06.096433
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def _test_my_class():
        c = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.9')
        assert len(c) == 3
        assert c[0] == 1 and c[1] == 2 and c[2] == 3

    for x in range(100):
        _test_my_class()

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:41:10.532614
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('foo', 'bar', d)
    assert d == dict(foo='bar')
    set_constant('foo', 'baz', d)
    assert d == dict(foo='bar')  # if it existed, it didn't change
    set_constant('foo2', 'baz', d)
    assert d == dict(foo='bar', foo2='baz')

# Generated at 2022-06-22 13:41:16.274144
# Unit test for function set_constant
def test_set_constant():
    assert BUILD_CACHE_SIZE == 20
    assert CALLBACK_WHITELIST == ('default', 'debug')

DEFAULT_ELEMENTS_PATH = [
    '%s/library' % DEFAULT_MODULE_PATH,
    '%s/module_utils' % DEFAULT_MODULE_PATH,
]

# Generated at 2022-06-22 13:41:25.290677
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

    set_constant('FOO', 'baz')
    assert FOO == 'baz'


# FIXME: we should not be doing this stuff in defaults.py
#
# Enable backwards compat with action plugins defined in action_plugins/
#
# action_plugins are external to the module_utils/ directory, so we need to add the
# proper FQCN for them.

# FIXME: remove this once import_specifics from is removed from the manager
#        and the manager no longer calls them with the command-line argument.
import ansible.plugins.action.normal
import ansible.plugins.action.debug
import ansible.plugins.action.include
import ansible.plugins.action.meta
import ansible.plugins.action.set_fact


# Generated at 2022-06-22 13:41:28.106600
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert len(t) == len('value')

# Generated at 2022-06-22 13:41:38.120020
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'ver')
    try:
        x = obj[1]
    except Exception as e:
        raise AssertionError('unexpected exception: {}'.format(repr(e)))
    assert x == 2
    try:
        x = obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('expected IndexError')
    try:
        x = obj[-1]
    except IndexError:
        pass
    else:
        raise AssertionError('expected IndexError')


# Generated at 2022-06-22 13:41:47.648751
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    param_msg = 'test deprecated sequence constant'
    param_version = '2.0'
    param_value = (1, 2, 3)
    test_obj = _DeprecatedSequenceConstant(param_value, param_msg, param_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:41:57.047797
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_str = 'test'
    test_msg = 'Message showing why deprecation is there.'
    test_version = '2018.4.4'

    test = _DeprecatedSequenceConstant(test_str, test_msg, test_version)
    assert len(test_str) == len(test)  # pylint: disable=E1110
    assert test[0] == test_str[0]


# Generated at 2022-06-22 13:42:00.826846
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant('ansible-test', 'msg', '2.0')
    assert dsc[0:2] == 'ansible-test'[0:2]


# Generated at 2022-06-22 13:42:07.824972
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_msg = 'test message'
    test_version = 'v1.0'
    test_value = 'test value'

    try:
        import mock
    except ImportError:
        return True

    with mock.patch('__builtin__.__import__', return_value=mock.MagicMock()):
        from ansible.utils.plugin_docs import _DeprecatedSequenceConstant

    with mock.patch('ansible.utils.plugin_docs.Display.deprecated') as mock_deprecated:
        test_seq = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
        len(test_seq)
        mock_deprecated.assert_called_once_with(test_msg, version=test_version)
        mock_deprecated.reset_mock()

    return True

# Generated at 2022-06-22 13:42:13.564073
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence = _DeprecatedSequenceConstant([1,2,3], 'message', 'version')
    assert len(sequence) == 3
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:42:19.652219
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_tuple = (1, 2, 3)
    test_msg = 'some message about the deprecation'
    test_version = 'version in which the deprecation should be removed'
    test_deprecated_sequence_constant = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)

    assert len(test_deprecated_sequence_constant) == len(test_tuple)


# Generated at 2022-06-22 13:42:25.694674
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_const_value = _DeprecatedSequenceConstant(
        value=['test_list_item1', 'test_list_item2'],
        msg='test deprecated message',
        version='test version')
    assert test_const_value[0] == 'test_list_item1'
    assert test_const_value[1] == 'test_list_item2'

# Generated at 2022-06-22 13:42:27.476860
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'Foo', '1.2.3')
    assert len(c) == 3

# Generated at 2022-06-22 13:42:30.010374
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'ignore', 'ignore')
    assert len(c) == 3


# Generated at 2022-06-22 13:42:32.684412
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(c) == 3


# Generated at 2022-06-22 13:42:36.271448
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    o = _DeprecatedSequenceConstant(['a'], 'msg', 'version')
    assert len(o) == 1
    assert o[0] == 'a'

# Generated at 2022-06-22 13:42:45.916979
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test.'
    version = '2.5'
    dsc = _DeprecatedSequenceConstant([1,2,3], msg, version)
    assert dsc.__len__() == 3
    assert dsc.__getitem__(1) == 2

# Generated at 2022-06-22 13:42:52.356352
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', '1.0')
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 13:42:55.926077
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(('a', 'b'), 'foobar', '1.2.3')
    assert isinstance(c, Sequence)
    assert len(c) == 2


# Generated at 2022-06-22 13:43:03.957096
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def get_value(obj, idx):
        return obj[idx]
    exp_msg = 'Test msg'
    exp_ver = 'v1.0'
    exp_val = ['1', '2', '3']
    dsc = _DeprecatedSequenceConstant(exp_val, exp_msg, exp_ver)
    assert dsc[0] == exp_val[0]
    assert dsc[1] == exp_val[1]
    assert dsc[2] == exp_val[2]


# Generated at 2022-06-22 13:43:05.853467
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant((1,2,3),'hello', latest_version('2.16'))
    assert isinstance(s, Sequence)
    assert len(s) is 3
    assert s[0] is 1
    assert s[2] is 3
    assert s[1] is 2

# Generated at 2022-06-22 13:43:12.545835
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from jinja2 import Template

    import sys
    import cStringIO

    test_string = "test string"
    test_version = "2.9"

    # Capture output in memory
    old_stderr = sys.stderr
    sys.stderr = cStringIO.StringIO()

    # Generate new _DeprecatedSequenceConstant object
    _DeprecatedSequenceConstant(test_string, test_string, test_version)

    # Retrieve output
    captured_output = sys.stderr.getvalue()

    # Load output into template
    t = Template(captured_output)

    # Assert output matches
    assert t.render(msg=test_string, version=test_version) == '[DEPRECATED] test string, to be removed in 2.9\n'

    # Restore output

# Generated at 2022-06-22 13:43:23.757252
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    CONNECTION_TYPES = _DeprecatedSequenceConstant(
        ['smart', 'ssh', 'paramiko', 'ssh2', 'local'],
        "Connection types have been converted to plugins.",
        "2.8"
    )
    assert CONNECTION_TYPES == ['smart', 'ssh', 'paramiko', 'ssh2', 'local']


# FIXME: probably needs to go
CONNECTION_TYPES = _DeprecatedSequenceConstant(
    ['ssh', 'paramiko', 'smart'],
    "Connection types have been converted to plugins.",
    "2.8"
)

# FIXME: probably needs to go

# Generated at 2022-06-22 13:43:35.545433
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MockDisplay():
        def __init__(self):
            self.msg = ''

        def deprecated(self, msg, version):
            self.msg = msg

    import sys
    import io
    import contextlib

    message = 'This is a fake message. Do not panic!'
    version = 'Fake version'
    original_stderr = sys.stderr
    original_display = sys.modules['ansible.utils.display.Display']
    original_warn = sys.modules['ansible.module_utils.basic.warnings']


# Generated at 2022-06-22 13:43:38.844805
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1], 'test message', '2.3')
    assert len(a) == 1


# Generated at 2022-06-22 13:43:49.038102
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from io import StringIO
    from ansible import constants

    import sys
    sys_stderr = sys.stderr
    sys.stderr = StringIO()
    test_list = [1, 2, 3]
    test_msg = "testing set_constant"
    test_version = '2.8'

    test_instance = _DeprecatedSequenceConstant(test_list, test_msg, test_version)

    assert test_instance.__getitem__(0) == 1
    res_stderr = sys.stderr.getvalue()[:-1]  # strip out newline
    sys.stderr = sys_stderr

    assert res_stderr == u' [DEPRECATED] testing set_constant, to be removed in 2.8'

# Generated at 2022-06-22 13:44:04.055890
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant((1, 2, 3), 'testing', 2.0)
    assert isinstance(constant, Sequence)
    assert len(constant) == 3


# Generated at 2022-06-22 13:44:07.039492
# Unit test for function set_constant
def test_set_constant():
    new_export = {}
    set_constant('foo', 'bar', export=new_export)
    assert new_export['foo'] == 'bar'


# Generated at 2022-06-22 13:44:09.359544
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_NEST_DIR', '/foo/bar')
    assert ANSIBLE_NEST_DIR == '/foo/bar'

# Generated at 2022-06-22 13:44:12.459234
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence = _DeprecatedSequenceConstant([], 'abc', '2.2')
    assert sequence
    assert len(sequence) == 0
    assert sequence[0] == []


# Generated at 2022-06-22 13:44:17.364244
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_list = [1, 2, 3, 4]
    test_obj = _DeprecatedSequenceConstant(test_list, "test message", "2.10")

    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3
    assert test_obj[3] == 4

# Generated at 2022-06-22 13:44:22.100481
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', export=test_dict)
    assert test_dict['foo'] == 'bar'


# DEFAULT TASK DISPLAY ###

# Generated at 2022-06-22 13:44:25.566942
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant(list('abc'), 'abc def', '1.0')
    assert d[0] == 'a'
    assert len(d) == 3

# Generated at 2022-06-22 13:44:33.895400
# Unit test for function set_constant
def test_set_constant():
    # Test bool
    set_constant('TEST_BOOL_TRUE', 'yes')
    assert TEST_BOOL_TRUE is True
    set_constant('TEST_BOOL_FALSE', 'No')
    assert TEST_BOOL_FALSE is False
    set_constant('TEST_BOOL_TRUE_VAL', 'True')
    assert TEST_BOOL_TRUE_VAL is True
    set_constant('TEST_BOOL_FALSE_VAL', 'false')
    assert TEST_BOOL_FALSE_VAL is False
    set_constant('TEST_BOOL_ERROR', 'not a boolean')
    assert TEST_BOOL_ERROR is False

# Generated at 2022-06-22 13:44:44.932112
# Unit test for function set_constant
def test_set_constant():
    import mock
    import sys
    from six import string_types
    from ansible.config.manager import ConfigManager
    from ansible.utils import type_defs

    config = ConfigManager()
    # testing constants
    set_constant('TEST_CONSTANT', 'test_constant')
    assert sys.modules[__name__].TEST_CONSTANT == 'test_constant'
    # testing bool conversion
    set_constant('TEST_BOOL', 'yes')
    assert sys.modules[__name__].TEST_BOOL
    # testing int conversion
    set_constant('TEST_INT', '5')
    assert sys.modules[__name__].TEST_INT == 5
    # testing float conversion
    set_constant('TEST_FLOAT', '0.5')

# Generated at 2022-06-22 13:44:49.828062
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = [1, 2, 3]
    constant = _DeprecatedSequenceConstant(sequence, "msg", "version")
    assert len(constant) == len(sequence)
    assert constant[2] == sequence[2]

# Generated at 2022-06-22 13:45:49.551663
# Unit test for function set_constant
def test_set_constant():
    import copy
    global DEFAULT_HOST_LIST
    DEFAULT_HOST_LIST_orig = copy.copy(DEFAULT_HOST_LIST)
    set_constant('DEFAULT_HOST_LIST', [])
    assert DEFAULT_HOST_LIST == []
    # Set back to original
    set_constant('DEFAULT_HOST_LIST', DEFAULT_HOST_LIST_orig)
    assert DEFAULT_HOST_LIST == DEFAULT_HOST_LIST_orig


_DEPRECATED_ACTION_NAMES = (
    'command', 'shell', 'raw', 'script', 'win_command', 'win_shell'
)
# The following are deprecated action names

# Generated at 2022-06-22 13:45:52.769683
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'message test'
    version = 'version test'
    seq_const = _DeprecatedSequenceConstant([0, 1], msg, version)

    assert seq_const[0] == 0
    assert seq_const[1] == 1


# Generated at 2022-06-22 13:45:57.004944
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'

    dsc = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'



# Generated at 2022-06-22 13:46:03.805840
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(value=['ansible', 'ansible', 'ansible'], msg='replace with ansible', version='2.9')
    assert len(dsc) == 3
    assert dsc[0] == 'ansible'
    assert dsc[1] == 'ansible'
    assert dsc[2] == 'ansible'


# Generated at 2022-06-22 13:46:09.412979
# Unit test for function set_constant
def test_set_constant():
    # Basic usage
    set_constant('ANSIBLE_MODULE_SETUP', False)
    assert ANSIBLE_MODULE_SETUP is False

    # Useful when constants depend on each other
    set_constant('ANSIBLE_FORKS', 5)
    set_constant('ANSIBLE_MAX_PROCESSES', ANSIBLE_FORKS)
    assert ANSIBLE_MAX_PROCESSES == 5



# Generated at 2022-06-22 13:46:13.982866
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert len(c) == 3
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3

# Generated at 2022-06-22 13:46:19.124100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant((0, 1, 2), 'Message', 'Version')
    assert len(sequence) == 3
    assert sequence[0] == 0
    assert sequence[1] == 1
    assert sequence[2] == 2


# Generated at 2022-06-22 13:46:22.291553
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 1)
    assert len(s) == 3
    s.__len__()


# Generated at 2022-06-22 13:46:24.108061
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant([0,1,2,3], '', '')
    assert x[1] == 1


# Generated at 2022-06-22 13:46:36.523270
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest
    class __DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def setUp(self):
            import sys
            self._stderr = sys.stderr
            self.stderr_content = ''
            sys.stderr = self
        def __getattr__(self, name):
            return getattr(self._stderr, name)
        def write(self, message):
            self.stderr_content += message
        def tearDown(self):
            import sys
            sys.stderr = self._stderr
    suite = unittest.TestSuite()
    suite.addTest(__DeprecatedSequenceConstant___getitem__('test__DeprecatedSequenceConstant___getitem__'))
    test_result = unittest.Text

# Generated at 2022-06-22 13:48:20.915505
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(value="test_value", msg="test_message", version='0')
    assert test_obj._value == "test_value"
    assert test_obj._msg == "test_message"
    assert test_obj._version == '0'

# Generated at 2022-06-22 13:48:26.528734
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_msg = 'this is a test message'
    test_version = '2.9'
    test_value = [1,2,3]

    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == len(test_value)
    assert test_object[0] == test_value[0]

# Generated at 2022-06-22 13:48:29.612238
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(value=['foo', 'bar'], msg='foobar', version='0.1')
    assert len(constant) == 2


# Generated at 2022-06-22 13:48:36.207830
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    test_warning = "unittest test warning message"
    test_version = "2.9"
    test_constant = _DeprecatedSequenceConstant(["Unittest"], test_warning, test_version)
    assert test_constant[0] == "Unittest"


# Generated at 2022-06-22 13:48:38.115759
# Unit test for function set_constant
def test_set_constant():
    dest_dict = dict()
    set_constant("hello", "world", dest_dict)
    assert dest_dict["hello"] == "world"

# Generated at 2022-06-22 13:48:41.361144
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    p = _DeprecatedSequenceConstant((1,2,3), "msg", "version")
    assert len(p) == 3



# Generated at 2022-06-22 13:48:44.373795
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert value[0] == 1
    assert value[1] == 2
    assert value[2] == 3

# Generated at 2022-06-22 13:48:50.958819
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    orig_seq = ['foo', 'bar']
    dsc = _DeprecatedSequenceConstant(orig_seq, 'test', '2.9')
    assert dsc[1] == 'bar'
    assert len(dsc) == 2
    # __getitem__ deprecated, but not invoked if indexing by slice.
    assert dsc[1:] == ['bar']
    assert len(dsc[1:]) == 1

# Generated at 2022-06-22 13:49:02.342855
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Here we are testing the sequence constant  _ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES = _ACTION_INCLUDE_ROLE + _ACTION_IMPORT_ROLE.
    # This test is to verify that _ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES is actually a sequence object and has 2 elements
    d = _DeprecatedSequenceConstant(_ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES, "msg", "2.12.0")
    assert len(d) == 2
    assert d[0] == "include_role" and d[1] == "import_role"

# Generated at 2022-06-22 13:49:07.362056
# Unit test for function set_constant
def test_set_constant():
    # Test a simple setting
    set_constant('foo', 'bar')
    assert foo == 'bar'
    # Test a templated setting
    set_constant('baz', '{{foo}}')
    assert baz == 'bar'
    # Test a templated setting that is a dictionary
    set_constant('qux', '{"foo":"{{foo}}"}')
    assert qux == {"foo":"bar"}