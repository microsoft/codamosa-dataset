

# Generated at 2022-06-22 13:40:53.566106
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 'TEST_SET_CONSTANT_VALUE')
    assert globals()['TEST_SET_CONSTANT'] == 'TEST_SET_CONSTANT_VALUE'

# DEPRECATIONS ###

# I guess this is fine to be here
DEFAULT_HASH_BEHAVIOUR = 1

# Deprecate old constants (reason=removal, version=major)
if config.data.DEFAULT_HASH_BEHAVIOUR == 0:
    DEFAULT_HASH_BEHAVIOUR = 0
    _deprecated("ansible.constants.DEFAULT_HASH_BEHAVIOUR is deprecated and will be changed to 1 in the future", version='2.0')

# Deprecated constants (reason=moved, version=minor)
ACTION_

# Generated at 2022-06-22 13:40:56.963861
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['foo']
    test_msg = 'Foo is deprecated'
    test_version = '2.9'

    test_const = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert test_const[0] == test_value[0]


# Generated at 2022-06-22 13:40:59.898135
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_seq = [1, 2, 3, 4]
    msg = 'This is a warning message'
    version = '2.7'
    test_obj = _DeprecatedSequenceConstant(test_seq, msg, version)

    import sys
    stderr = sys.stderr
    sys.stderr = None
    try:
        test_obj[3]
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 13:41:01.890848
# Unit test for function set_constant
def test_set_constant():
    test_export = {}
    set_constant('foo', 'bar', export=test_export)
    assert test_export['foo'] == 'bar'
    set_constant('foo', 'baz', export=test_export)
    assert test_export['foo'] == 'baz'

# Generated at 2022-06-22 13:41:06.891613
# Unit test for function set_constant
def test_set_constant():
    local = {}
    set_constant('FOO', 'bar', export=local)
    assert local['FOO'] == 'bar'


# constants derived from the config
BECOME_ERROR_STRINGS = (
    "This module requires %s, but it is not installed.  If %s is installed, check that %s is in the PATH",
    "To use the '%s' become method, %s must be installed on the target host",
)
BECOME_METHODS = config.data.get_config_value('become', 'become_methods')
BECOME_MISSING_STRINGS = tuple(config.data.get_config_value('become', 'missing_message'))
DEFAULT_SUDO_USER = config.data.get_config_value('become', 'default_user')
DE

# Generated at 2022-06-22 13:41:09.324276
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2, 3, 4]
    dsc = _DeprecatedSequenceConstant(value, 'test', '1.0')
    assert len(dsc) == len(value)


# Generated at 2022-06-22 13:41:10.792281
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), 'Test', 'Unknown')) == 2


# Generated at 2022-06-22 13:41:18.242587
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert (len(add_internal_fqcns(('foo', 'bar'))) == 2)
    assert (len(add_internal_fqcns(('foo', 'bar'), warning='foo')) == 2)
    assert (len(add_internal_fqcns(('foo', 'bar'), removal_version='foo')) == 2)
    assert (len(_DeprecatedSequenceConstant(value=('foo', 'bar'), msg='foo', version='foo')) == 2)

# Generated at 2022-06-22 13:41:28.452549
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import pytest
    with pytest.raises(AttributeError):
        _DeprecatedSequenceConstant([], 'msg', 'version').append('new')
    assert 1 not in _DeprecatedSequenceConstant(range(2), 'msg', 'version')
    assert 2 not in _DeprecatedSequenceConstant(range(2), 'msg', 'version')
    assert 3 in _DeprecatedSequenceConstant(range(4), 'msg', 'version')
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0
    assert len(_DeprecatedSequenceConstant([1], 'msg', 'version')) == 1


# Generated at 2022-06-22 13:41:30.093117
# Unit test for function set_constant
def test_set_constant():
    assert constant.constant_name == 'constant_value'


# Generated at 2022-06-22 13:41:35.418745
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant(value='test', msg='1', version='1')
    assert(len(test_sequence) == 4)

# Generated at 2022-06-22 13:41:37.960435
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', True)
    assert globals()['ANSIBLE_TEST_CONSTANT'] is True

# Generated at 2022-06-22 13:41:44.886856
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test.'
    version = '2.5.0'
    value = ['a', 'b', 'c']
    test = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test) == len(value)
    assert test[0] == value[0]
    assert test[2] == value[2]

# Generated at 2022-06-22 13:41:48.649284
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.six import string_types
    msg = u"This is a deprecated message"
    version = u"2.9.1"
    # This test makes a instance of class _DeprecatedSequenceConstant
    # with value of msg and version, and test type of length and value.
    test_constant = _DeprecatedSequenceConstant("a", msg, version)
    assert isinstance(test_constant, Sequence)
    assert len(test_constant) == 1
    assert isinstance(test_constant[0], string_types)
    assert test_constant[0] == "a"

# Generated at 2022-06-22 13:41:53.409084
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="Please use bar instead of foo.", version="2.5")
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[1] == 2


# Generated at 2022-06-22 13:42:01.833443
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io

    captured_output = io.StringIO()
    sys.stdout = captured_output

    a = _DeprecatedSequenceConstant(['a', 'b'], 'some message', '2.8')
    assert a[0] == 'a'
    captured_output.seek(0)
    assert captured_output.read().rstrip() == ' [DEPRECATED] some message, to be removed in 2.8'
    captured_output.close()



# Generated at 2022-06-22 13:42:08.186906
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'ignored', 'ignored')
    assert(len(dsc) == 3)
    assert(list(dsc) == [1, 2, 3])
    assert(dsc[2] == 3)
    assert(dsc[1:2] == [2])

# Generated at 2022-06-22 13:42:11.051434
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'ver')) == 3


# Generated at 2022-06-22 13:42:16.661654
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    dsc = _DeprecatedSequenceConstant(value=[1,2], msg="msg", version="version")

    assert isinstance(dsc, Sequence)

    assert dsc[0] == 1
    assert dsc[1] == 2
    try:
        dsc[2]
    except IndexError as e:
        assert e.args == ("list index out of range", )

# Generated at 2022-06-22 13:42:20.369197
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_str = 'test string'
    _DeprecatedSequenceConstant(test_str, 'test', '1.0')
    assert len(_DeprecatedSequenceConstant(test_str, 'test', '1.0')) == len(test_str)

# Generated at 2022-06-22 13:42:32.925421
# Unit test for function set_constant
def test_set_constant():
    set_constant('CONSTANT', 'value')
    assert 'value' == CONSTANT

    set_constant('CONSTANT_TEMPLATE', 'value', dict(TEMPLATE_VAR='value'))
    assert 'value' == CONSTANT_TEMPLATE
    assert 'value' == CONSTANT_TEMPLATE.replace('TEMPLATE_VAR', 'value')


# Generated at 2022-06-22 13:42:38.878004
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'This is a test message', '2.9')
    assert len(x) == 3
    assert x[0] == 'a'
    assert x[1] == 'b'
    assert x[2] == 'c'


# Generated at 2022-06-22 13:42:43.250338
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    const = _DeprecatedSequenceConstant(['deprecated'], '', '')
    assert isinstance(const, Sequence)
    assert isinstance(const, _DeprecatedSequenceConstant)
    assert const
    assert repr(const)
    assert str(const)

# Generated at 2022-06-22 13:42:52.975621
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ["a", "b"]
    msg = u"This is a test message!"
    version = "2.12"
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert(obj._value == ["a", "b"])
    assert(obj._msg == u"This is a test message!")
    assert(obj._version == "2.12")
    assert(len(obj) == 2)
    assert(obj[0] == "a")
    assert(obj[1] == "b")

# Generated at 2022-06-22 13:42:57.023273
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequence) == len(value)



# Generated at 2022-06-22 13:43:01.925996
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Arrange
    message = "foo"
    version = "bar"
    sequence = ['a', 'b', 'c']
    dep = _DeprecatedSequenceConstant(sequence, message, version)

    # Act
    # Assert
    assert dep[0] == 'a'



# Generated at 2022-06-22 13:43:04.623623
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test(object):
        def __init__(self):
            self.value = '1'

        def __getitem__(self, y):
            return self.value

    test = Test()
    __version__ = '2.0.0'

    _deprecated_sequence_constant = _DeprecatedSequenceConstant(test, '', '2.0.0')
    assert _deprecated_sequence_constant[0] == '1'


# Generated at 2022-06-22 13:43:08.324833
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([], None, None).__len__() == 0
    assert _DeprecatedSequenceConstant(['one'], None, None).__len__() == 1
    assert _DeprecatedSequenceConstant(['one', 2], None, None).__len__() == 2

# Generated at 2022-06-22 13:43:11.893338
# Unit test for function set_constant
def test_set_constant():
    ''' Test the set_constant function '''
    vars = {}
    set_constant('foo', 'bar', vars)
    assert vars['foo'] == 'bar'

# Generated at 2022-06-22 13:43:14.593009
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    result = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(result) == 3

# Generated at 2022-06-22 13:43:27.664015
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant((1, 2, 3), 'msg', '2.9')
    assert( a[1] == 2 )


# Generated at 2022-06-22 13:43:33.006451
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_test = _DeprecatedSequenceConstant(['one', 'two'], 'foo', 2.0)
    assert class_test._value == ['one', 'two']
    assert len(class_test) == 2
    assert class_test[0] == 'one'
    assert class_test[1] == 'two'

# Generated at 2022-06-22 13:43:37.359003
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'foo'
    version = '2.0'
    test_array = (1, 2, 3)
    dsc = _DeprecatedSequenceConstant(value=test_array, msg=msg, version=version)
    assert len(dsc) == len(test_array)
    assert dsc[1] == test_array[1]

# Unit test to cover the complete code base
# The test will cover more code coverage percentage

# Generated at 2022-06-22 13:43:44.087798
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    const = (1, 2, 3, 4)
    msg = 'A Message'
    version = '2.12'
    const_obj = _DeprecatedSequenceConstant(const, msg, version)
    # Test access of __len__() method
    assert len(const_obj) == 4
    # Test access of __getitem__() method
    assert const_obj[0] == const[0]

# Generated at 2022-06-22 13:43:53.416980
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # The following test should be replaced after https://github.com/ansible/ansible/issues/33837
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import plugin_loaders
    plugin_loaders.update(AnsibleCollectionLoader)
    c = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', 'test version')
    assert c[0] == 1  # index
    assert c[0:2] == [1, 2]  # slice
    assert c[0:2:1] == [1, 2]  # extended slice

test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 13:43:55.845970
# Unit test for function set_constant
def test_set_constant():
    export = {}
    name = 'ABCD'
    value = '1234'
    set_constant(name, value, export)
    assert name in export

# Generated at 2022-06-22 13:43:57.892195
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ds = _DeprecatedSequenceConstant('abcd', 'msg', 'version')
    assert len(ds) == len('abcd')

# Generated at 2022-06-22 13:44:00.605885
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dps = _DeprecatedSequenceConstant((), '', '2.11')
    assert len(dps) == 0


# Generated at 2022-06-22 13:44:10.873358
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys

    set_constant('test_value', (1, 2, 3))
    sys.stderr.write = lambda x: x  # fake method so sys.stderr.write doesn't error

    test_case = _DeprecatedSequenceConstant(test_value, 'some message', 'some version')

    # test that __getitem__ returns the test_value
    assert test_case[1] == test_value[1]
    # test that __getitem__ prints a deprecation message
    assert test_case[1] == test_value[1]
    assert test_case[1] == test_value[1]

# Generated at 2022-06-22 13:44:13.570133
# Unit test for function set_constant
def test_set_constant():
    global __file__
    set_constant('__file__', __file__)
    assert __file__ != __file__
    CONFIG_FILE = __file__
    assert __file__ == CONFIG_FILE

# Generated at 2022-06-22 13:44:38.721009
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = "foo"
    version = "2.9"
    assert _DeprecatedSequenceConstant(value, msg, version)[1] == value[1]



# Generated at 2022-06-22 13:44:46.932473
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest

    class Test__DeprecatedSequenceConstant(unittest.TestCase):

        def test__DeprecatedSequenceConstant(self):
            test_instance = _DeprecatedSequenceConstant(value=list(), msg='msg', version='version')
            self.assertEqual(len(test_instance), 0)
            self.assertFalse('test' in test_instance)

            test_instance = _DeprecatedSequenceConstant(value=list(range(10)), msg='msg', version='version')
            self.assertEqual(len(test_instance), 10)
            self.assertFalse('test' in test_instance)

            test_instance = _DeprecatedSequenceConstant(value=('test', 'foo'), msg='msg', version='version')

# Generated at 2022-06-22 13:44:51.732502
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['hello', 'world'], 'a message', '2.10')) == 2
    assert len(_DeprecatedSequenceConstant(('hello', 'world'), 'a message', '2.10')) == 2

# Generated at 2022-06-22 13:44:53.408674
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([], 'test', '1.2')
    assert len(s) == 0

# Generated at 2022-06-22 13:45:06.743923
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def test_object(_obj, _msg, _version):
        _deprecated_obj = _DeprecatedSequenceConstant(_obj, _msg, _version)
        _len = len(_obj)
        assert len(_deprecated_obj) == _len
        assert _deprecated_obj[_len-1] == _obj[_len-1]

    _test_msg = "my warning message"
    _test_version = "2.8"
    _test_list = [1, 2, 3]
    _test_tuple = (1, 2, 3)
    _test_set = {1, 2, 3}

    test_object(_test_list, _test_msg, _test_version)
    test_object(_test_tuple, _test_msg, _test_version)

# Generated at 2022-06-22 13:45:18.816346
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'foo')
    assert globals()['test'] == 'foo'
    set_constant('test2', 'bar', locals())
    assert locals()['test2'] == 'bar'
    globals()['test3'] = set_constant('test3', 'foobar')
    assert globals()['test3'] == 'foobar'
    locals()['test4'] = set_constant('test4', 'barfoo', locals())
    assert locals()['test4'] == 'barfoo'
    # Remove constants from global/local namespace
    del globals()['test']
    del globals()['test3']
    del test2
    del test4

# LOAD CONSTANTS DEPENDING ON OTHER CONSTANTS

DEPRECATED_BOOL_INI_CONFIGS

# Generated at 2022-06-22 13:45:24.603544
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Initialize object of class _DeprecatedSequenceConstant
    obj = _DeprecatedSequenceConstant([100, 200], 'deprecated', 'version')

    # Calling __getitem__ method with index 0
    assert obj[0] == 100

    # Calling __getitem__ method with index 1
    assert obj[1] == 200



# Generated at 2022-06-22 13:45:32.523577
# Unit test for function set_constant
def test_set_constant():
    set_constant('UNIT_TEST_STRING', 'test')
    assert UNIT_TEST_STRING == 'test'
    set_constant('UNIT_TEST_INT', 1)
    assert UNIT_TEST_INT == 1
    set_constant('UNIT_TEST_LIST', ['a', 1, 'c'])
    assert UNIT_TEST_LIST == ['a', 1, 'c']
    set_constant('UNIT_TEST_DICTIONARY', {'key': 'value'})
    assert UNIT_TEST_DICTIONARY == {'key': 'value'}
    set_constant('UNIT_TEST_BOOLEAN_TRUE', True)
    assert UNIT_TEST_BOOLEAN_TRUE == True
    set_const

# Generated at 2022-06-22 13:45:45.162606
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'a message', 'a version')
    assert 3 == len(c)
    assert 2 == c[1]
    c[1] = 'a'
    c.append('b')
    c.extend('c')
    assert ['a', 'b', 'c'] == c
    assert 1 == c.count('a')
    assert 'a' != c.index('a')
    del c[1]
    assert ['a', 'c'] == c
    assert 'a' == c.pop()
    assert 'c' == c.pop()
    assert [] == c
    c.clear()
    assert [] == c
    c.append('b')
    c.insert(0, 'a')
    assert ['a', 'b'] == c
    c

# Generated at 2022-06-22 13:45:55.530722
# Unit test for function set_constant
def test_set_constant():
    '''test_set_constant: asserts for constants for ansible'''
    config.run()
    for setting in config.data.get_settings():
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render(vars())
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not templatable

            value = ensure_type(value, setting.type)

        assert(vars()[setting.name] == value)

# Generated at 2022-06-22 13:46:42.217612
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.utils.display import Display
    import sys
    import io

    instance = _DeprecatedSequenceConstant('foo', 'msg', 'version')
    assert len(instance) == 3

    _warning('test1')
    _warning('test2')
    _warning('test3')

    _deprecated('foo', 'bar')
    _deprecated('bar', 'baz')
    _deprecated('baz', 'qux')

    # All warnings are printed in the order they are triggered
    sys.stderr = io.StringIO()
    instance = _DeprecatedSequenceConstant('foo', 'msg', 'version')
    len(instance)
    sys.stderr = io.StringIO()
    instance = _DeprecatedSequenceConstant('foo', 'msg', 'version')
    len(instance)


# Generated at 2022-06-22 13:46:46.012945
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert [1, 2, 3] == _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')  # test if method __getitem__ returns expected value



# Generated at 2022-06-22 13:46:47.783285
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('foo', 'bar'), 'msg', 'version')) == 2

# Generated at 2022-06-22 13:46:59.708431
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # add fake constants to dict
    set_constant('MY_STRING', 'this is a string')
    set_constant('MY_INTEGER', 1)
    set_constant('MY_LIST', ['a', 'b', 'c'])
    set_constant('MY_LIST2', ['d', 'e', 'f'])

    # create test object
    obj = _DeprecatedSequenceConstant(['MY_LIST', 'MY_LIST2'], 'test', '2.9')

    # run test
    assert len(obj) == 6
    assert obj[0] == 'a'
    assert obj[1] == 'b'
    assert obj[2] == 'c'
    assert obj[3] == 'd'
    assert obj[4] == 'e'

# Generated at 2022-06-22 13:47:02.566405
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    assert len(_DeprecatedSequenceConstant(test_value, None, None)) == len(test_value)


# Generated at 2022-06-22 13:47:15.740138
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    import sys
    # make sure the module is not imported when running this test
    sys.modules.pop('ansible.constants', None)
    from ansible.constants import _DeprecatedSequenceConstant

    # _DeprecatedSequenceConstant(self, value, msg, version)
    d = _DeprecatedSequenceConstant([], 'my message', '2.10')
    assert isinstance(d, Sequence)
    assert len(d) == 0
    d.append('foo')
    assert len(d) == 1
    d += ['bar', 'baz']
    assert len(d) == 3
    assert d[0] == 'foo'
    assert d[1] == 'bar'
    assert d[2] == 'baz'

# Generated at 2022-06-22 13:47:26.411986
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    msg = 'foo'
    version = '2.0'
    deprecated_value = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_value) == len(value)
    assert deprecated_value[0] == value[0]

# FIXME: remove once play_context mangling is removed
# FIXME: make me use the names in the config
# TODO: this should be a class?
# TODO: break out default ssh config into separate dict

# Generated at 2022-06-22 13:47:30.449615
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    color_codes = _DeprecatedSequenceConstant(COLOR_CODES, 'msg', '1.0')
    assert color_codes['black'] == u'0;30'
    assert color_codes['normal'] == u'0'

# Generated at 2022-06-22 13:47:43.592447
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def assert_deprecated_sequence_constant(method_name):
        # Call method and check deprecation warning.
        # TODO: wrap this in a context manager to assert that the warning is logged only once
        _DeprecatedSequenceConstant(value, msg, version).method_name()

    # Setup
    value = []
    msg = 'some message'
    version = '2.0'

    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)

    # Test
    assert_deprecated_sequence_constant('__len__')
    assert_deprecated_sequence_constant('__getitem__')

test__DeprecatedSequenceConstant()

# backwards compatibility aliases
# TODO: remove next release
CHECK_MODE_DEFAULT = CHECK_MODE
HOST_KEY_CHECK

# Generated at 2022-06-22 13:47:45.942388
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'sample message', '2.2')
    assert len(c) == 3
    assert len(c) == 3

del config

# Generated at 2022-06-22 13:49:15.711484
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'This is a test', '2.9')
    assert dsc[0] == 'a'
    assert dsc.__getitem__(0) == 'a'

# Generated at 2022-06-22 13:49:19.486955
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dc = _DeprecatedSequenceConstant(['hello', 'world'], 'msg', 'version')
    assert len(dc) == 2
    assert dc[0] == 'hello'
    assert dc[1] == 'world'


# Generated at 2022-06-22 13:49:28.398685
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['foo', 'bar']
    msg = 'This is a test'
    version = '0.0.1'

    deps_seq_const = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deps_seq_const) == 2
    assert deps_seq_const[0] == 'foo'
    assert deps_seq_const[1] == 'bar'


set_constant('C', COLOR_CODES, export=vars())
set_constant('BECOME_METHODS', config.get_config_value('DEFAULT_BECOME_METHOD'), export=vars())
set_constant('DEFAULT_MODULE_UTILS_PATH', config.get_config_value('DEFAULT_MODULE_UTILS_PATH'), export=vars())
set_

# Generated at 2022-06-22 13:49:38.752647
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = (1, 2, 3)
    test_msg = 'Test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3
    assert len(test_obj) == 3
    assert test_obj[100] == 'test_rval'

__all__ = [add_internal_fqcns(x for x in dir() if not x.startswith('_'))]

if __name__ == "__main__":
    import pytest
    myargs = [__file__, '-v', '-s']

# Generated at 2022-06-22 13:49:41.709168
# Unit test for function set_constant
def test_set_constant():
    # set_constant("TEST_CONSTANT", 42)
    # assert TEST_CONSTANT == 42

    # This should raise an error
    try:
        set_constant("TEST_CONSTANT", 42)
    except NameError:
        pass
    else:
        raise AssertionError("Should have raised error")

# Generated at 2022-06-22 13:49:44.488383
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import unittest

    class Test__DeprecatedSequenceConstant___len__(unittest.TestCase):
        def test__len__(self):
            d = _DeprecatedSequenceConstant([1, 2, 3], "test message", "2.9")
            self.assertEqual(d.__len__(), 3)

    unittest.main()

# Generated at 2022-06-22 13:49:56.325390
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('foo', 'bar', constants)
    assert constants == {'foo': 'bar'}


# FIXME: deprecated list

# Generated at 2022-06-22 13:49:59.106521
# Unit test for function set_constant
def test_set_constant():

    # set_constant should not return a value
    # which is what we are testing here by asserting the return value is None
    assert not set_constant('test', {'test': 'test'})


# Generated at 2022-06-22 13:50:01.448394
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=dict(),msg='foo',version='bar')) == 0
    assert len(_DeprecatedSequenceConstant(value=list(),msg='foo',version='bar')) == 0

# Generated at 2022-06-22 13:50:07.803581
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import types
    from ansible.module_utils.common.collections import is_sequence

    # create a small list
    test_list = [1, 2, 3]

    # create a stub stdout
    class Output(object):
        content = None

        def write(self, s):
            self.content = s
    stdout = Output()
    sys.stdout = stdout

    # create a _DeprecatedSequenceConstant object
    obsolete = _DeprecatedSequenceConstant(test_list, 'not to be used', 'deprecated')

    # test that the object returns the correct value
    assert test_list[0] == obsolete[0]

    # test that the object prints a deprecation warning