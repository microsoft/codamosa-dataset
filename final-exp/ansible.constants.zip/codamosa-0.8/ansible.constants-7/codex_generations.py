

# Generated at 2022-06-22 13:40:53.774881
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class UnitTestException(Exception):
        pass
    class _FakeDisplay(object):
        def __init__(self):
            self.msgs = []

        def deprecated(self, msg, version):
            self.msgs.append((msg, version))

    try:
        import sys
        del sys.modules['ansible.utils.display']
        from ansible.utils.display import Display

        old_display = Display()
        Display._singleton = _FakeDisplay()

        msg, version = 'foo', 'bar'
        value = _DeprecatedSequenceConstant(['baz'], msg, version)

        assert 'baz' == value[0]

        assert len(Display._singleton.msgs) == 1
        assert (msg, version) == Display._singleton.msgs[0]
    finally:
        Display

# Generated at 2022-06-22 13:40:59.124591
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected = 3
    length = len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version'))
    assert expected == length


# Generated at 2022-06-22 13:41:08.962295
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    with mock.patch('ansible.utils.fqcn.add_internal_fqcns', return_value=['test__DeprecatedSequenceConstant___getitem__']) as mock_add_internal_fqcns, \
            mock.patch('ansible.utils.display.Display.deprecated') as mock_display_deprecated, \
            mock.patch('ansible.utils.constants._warning') as mock_warning:
        value = ['test__DeprecatedSequenceConstant___getitem__']
        msg = 'test'
        version = '2.9'
        test_instance = _DeprecatedSequenceConstant(value, msg, version)
        test_instance.__getitem__(0)

# Generated at 2022-06-22 13:41:15.180600
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    value2 = _DeprecatedSequenceConstant(value, 'message', '1.1')
    assert len(value) == len(value2)
    assert value[0] == value2[0]
    assert value[1] == value2[1]
    assert value[2] == value2[2]


# Generated at 2022-06-22 13:41:17.149326
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['1'], 'msg', 'version')) == 1


# Generated at 2022-06-22 13:41:20.806309
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    len_of_seq = len(_DeprecatedSequenceConstant((), None, None))
    assert len_of_seq == 0

# Generated at 2022-06-22 13:41:26.105647
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant([0, 1, 2], 'test', '1.0')
    assert len(test_sequence) == 3

    test_sequence = _DeprecatedSequenceConstant([], 'test', '1.0')
    assert len(test_sequence) == 0


# Generated at 2022-06-22 13:41:29.477636
# Unit test for function set_constant
def test_set_constant():
    test_dict = dict()
    set_constant('fake_constant', 'fake_value', export=test_dict)
    assert test_dict['fake_constant'] == 'fake_value'
    assert test_dict['fake_constant'] == globals()['fake_constant']

# Generated at 2022-06-22 13:41:35.312075
# Unit test for function set_constant
def test_set_constant():
    '''Function set_constant :: Verify setting of a constant'''
    this_locals = locals()
    constant_value = 42
    set_constant('TEST_CONSTANT', 42, this_locals)

    assert this_locals['TEST_CONSTANT'] == constant_value



# Generated at 2022-06-22 13:41:38.285555
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_constant = _DeprecatedSequenceConstant([1, 2, 3], 'deprecated message', 'version')
    assert len(seq_constant) == 3

# Generated at 2022-06-22 13:41:50.924199
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def compare(msg, version, lst, idx, expected):
        d = _DeprecatedSequenceConstant(lst, msg, version=version)
        actual = d.__getitem__(idx)
        assert actual == expected

    compare('msg', '1.0', [1, 2, 3], 2, 3)
    compare('msg', '1.0', [(1, 2), (3, 4)], 1, (3, 4))
    try:
        compare('msg', '1.0', [1, 2, 3], 4, 5)
    except IndexError:
        pass



# Generated at 2022-06-22 13:41:53.270177
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert isinstance(obj, _DeprecatedSequenceConstant)

# Generated at 2022-06-22 13:41:56.229120
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3, 4], 'message', 'version')[1] == 2


# Generated at 2022-06-22 13:41:57.489671
# Unit test for function set_constant
def test_set_constant():
    foo = {}
    set_constant('foo', 5, export=foo)
    set_constant('foo', 'bar', export=foo)
    assert foo['foo'] == 'bar'

# Generated at 2022-06-22 13:42:00.493021
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')) == 2


# Generated at 2022-06-22 13:42:03.137001
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'Test', 'Test')
    if len(d) != 3:
        raise AssertionError()

# Generated at 2022-06-22 13:42:16.479150
# Unit test for function set_constant
def test_set_constant():
    data = {'a': 1, 'b': 2, 'c': 3}
    run_data = {}
    for k, v in data.items():
        set_constant(k, v, run_data)
    assert data == run_data

VAULT_VERSION = _DeprecatedSequenceConstant(tuple(str(VAULT_VERSION_MIN)),
                                            "VAULT_VERSION as a list will be removed in a future release, please use VAULT_VERSION_MIN and VAULT_VERSION_MAX",
                                            '2.15')

# The following are deprecated
DEFAULT_MODULE_NAME = _DeprecatedSequenceConstant('command', 'DEFAULT_MODULE_NAME will be removed in a future Ansible release, please use MODULE_REQUIRE_ARGS', '2.15')

# Generated at 2022-06-22 13:42:20.222204
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['test']
    msg = 'test'
    version = 'test update_version'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    deprecated_sequence_constant.__len__()


# Generated at 2022-06-22 13:42:22.564998
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test warning', 'version')) == 3

# Generated at 2022-06-22 13:42:34.586709
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:42:42.418950
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sut = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert len(sut) == 2


# Generated at 2022-06-22 13:42:52.194633
# Unit test for function set_constant
def test_set_constant():
    # Tests that the function set_constant adds a constant to the
    # global namespace

    # Remove the constant "__test_constant" from the global namespace
    # and make sure that it doesn't exist
    if "__test_constant" in globals():
        del globals()["__test_constant"]
    assert "__test_constant" not in globals()

    # Create a test constant and ensure that the constant was added to
    # the global namespace
    set_constant("__test_constant", 1)
    assert "__test_constant" in globals()

# Generated at 2022-06-22 13:42:57.512878
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    CONSTANT_ONE = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    CONSTANT_TWO = _DeprecatedSequenceConstant((1,2,3), 'msg', 'version')

    assert len(CONSTANT_ONE) == 3 == len(CONSTANT_TWO)


# Generated at 2022-06-22 13:43:02.661044
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(['1','2','3','4'], 'test', 'version')
    assert len(deprecated_sequence_constant) == 4
    assert deprecated_sequence_constant[0] == '1'
    assert deprecated_sequence_constant[3] == '4'

# Generated at 2022-06-22 13:43:05.078329
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import pytest

    v = _DeprecatedSequenceConstant([], '', '')
    assert len(v) == 0



# Generated at 2022-06-22 13:43:07.957942
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    message = "the message"
    version = "the version"
    the_list = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(the_list, message, version)
    assert len(dsc) == 3

# Generated at 2022-06-22 13:43:21.312872
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Invalid config key.'
    version = '2.4'

    value = []
    warnings = []

    def _warning(msg):
        warnings.append(msg)

    _doc = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(_doc, Sequence)
    assert len(_doc) == 0

    value = ['a', 'b']
    _doc = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(_doc, Sequence)
    assert len(_doc) == 2

    value = ['a', 'b']
    _doc = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(_doc, Sequence)
    assert len(_doc) == 2


# Generated at 2022-06-22 13:43:23.751231
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([], "Test message", "v2.9")
    assert len(constant) == 0
    assert constant[0] is None


# Generated at 2022-06-22 13:43:26.653915
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([], 'message', '2.0')
    assert len(seq) == 0

# Generated at 2022-06-22 13:43:36.718514
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import unittest
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    class Test__DeprecatedSequenceConstant(unittest.TestCase):

        def test___getitem__(self):
            with stdoutIO() as s:
                seq_test = _DeprecatedSequenceConstant(value=['test'], msg='test message', version='2.0')
                seq_test.__getitem__(0)
                output = s.getvalue().strip()

# Generated at 2022-06-22 13:43:44.087263
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], "msg", "version")) == 2


# Generated at 2022-06-22 13:43:45.505296
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(value=(1, 2), msg="msg", version="version")
    assert len(constant) == 2


# Generated at 2022-06-22 13:43:56.284934
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'foo'
    version = 'bar'
    value = 1234
    v = _DeprecatedSequenceConstant(value, msg, version)
    assert v._msg.startswith('foo, to be removed in')
    assert v._version == 'bar'


# Now, after all the configs have been loaded, we fix up some
# non-constants with their defaults

# DEFAULT_CACHE_PLUGIN = 'memory'
# DEFAULT_CACHE_PLUGIN = config.get_config_value('DEFAULT_CACHE_PLUGIN')

# DEFAULT_CACHE_PLUGIN = 'jsonfile'
DEFAULT_CACHE_PLUGIN = 'memory'

DEFAULT_CACHE_TIMEOUT = 3600
# DEFAULT_CACHE_TIMEOUT

# Generated at 2022-06-22 13:43:59.040324
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant(tuple(), 'This is a test message', '2.9')
    assert len(test_obj) is 0

# Generated at 2022-06-22 13:44:05.430823
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Arrange
    msg = 'abc'
    version = '1.2.3'
    obj = _DeprecatedSequenceConstant(tuple(range(2)), msg, version)
    expect_res = 2
    # Act
    res = len(obj)
    # Assert
    assert res == expect_res


# Generated at 2022-06-22 13:44:07.812393
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'


# Runtime test for function set_constant

# Generated at 2022-06-22 13:44:09.404690
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST', True)
    assert TEST

# Generated at 2022-06-22 13:44:15.177791
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test"
    version = "2.12"
    constant = _DeprecatedSequenceConstant("test".split(), msg, version)
    assert len(constant) == 3, 'len of test __DeprecatedSequenceConstant should be 3'
    assert constant[0] == "test", "value of test __DeprecatedSequenceConstant should be 'test'"

# Generated at 2022-06-22 13:44:18.834710
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'sample message', '1.0')
    assert s[0] == 1
    assert s[1] == 2
    assert s[2] == 3
    assert s[-1] == 3
    assert s[-2] == 2
    assert s[-3] == 1



# Generated at 2022-06-22 13:44:30.724022
# Unit test for function set_constant
def test_set_constant():
    set_constant('blah', 'blah')
    assert blah == 'blah'

# constants which have deprecated names

# Generated at 2022-06-22 13:44:45.938069
# Unit test for function set_constant
def test_set_constant():
    # Do before we reset ansible.constants
    set_constant('mytest', 'myval', export=vars())
    assert mytest == 'myval'
    assert mytest is ansible.constants.mytest
    ansible.constants.mytest = 'notmyval'
    assert mytest == 'notmyval'
    assert mytest is ansible.constants.mytest
    set_constant('mytest', 'myval', export=vars())
    assert mytest == 'myval'
    assert mytest is ansible.constants.mytest
    del ansible.constants.mytest
    assert not hasattr(ansible.constants, 'mytest')
    assert not hasattr(ansible.constants, 'mytest')

# cleanup namespace from settings and create clean namespace for plugins

# Generated at 2022-06-22 13:44:49.387594
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['test', 'a'], 'Test', '2.8')) == 2


# Generated at 2022-06-22 13:44:54.697191
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import is_sequence
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test-msg', '99.9.9')
    assert isinstance(dsc, Sequence)
    assert is_sequence(dsc)
    assert len(dsc) == 3


# Generated at 2022-06-22 13:45:00.408310
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = "This is a deprecated test."
    version = "2.9"
    object_ = _DeprecatedSequenceConstant(value, msg, version)
    for index, item in enumerate(value):
        assert object_[index] == item


# Generated at 2022-06-22 13:45:04.028382
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg='the length is 3', version='1.0').__len__() == 3


# Generated at 2022-06-22 13:45:13.148128
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    obj = _DeprecatedSequenceConstant(l, "msg", "version")
    assert obj.__getitem__(0) == l[0]
    assert obj.__getitem__(1) == l[1]
    assert obj.__getitem__(2) == l[2]
    try:
        assert obj.__getitem__(10) == l[10]
    except:
        print("test__DeprecatedSequenceConstant___getitem__ pass")
    else:
        raise RuntimeError("test__DeprecatedSequenceConstant___getitem__ Fail")


# Generated at 2022-06-22 13:45:17.770914
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3


# Generated at 2022-06-22 13:45:28.738322
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(['1', '2', '3'], 'msg', 'version')
    _DeprecatedSequenceConstant((2, 3, 4), 'msg', 'version')
    _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    _DeprecatedSequenceConstant([], 'msg', 'version')
    _DeprecatedSequenceConstant((), 'msg', 'version')
    _DeprecatedSequenceConstant(['1', '2', '3'], 'msg', 'version')
    _DeprecatedSequenceConstant((2, 3, 4), 'msg', 'version')
    _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    _Dep

# Generated at 2022-06-22 13:45:38.933394
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1,2,3], 'this is a test', '0.0.1')
    assert x._value == [1, 2, 3]
    assert x._msg == 'this is a test'
    assert x._version == '0.0.1'

if __name__ == "__main__":
    import sys
    import os
    from ansible.utils.path import unfrackpath

    sys.path.insert(0, os.path.dirname(unfrackpath(__file__)))

    test__DeprecatedSequenceConstant()
    print("OK")

# Generated at 2022-06-22 13:45:51.224406
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    from ansible.config.settings import DEFAULT_ACTION_PLUGIN_PATH
    from ansible.constants import _ACTION_INCLUDE, _ACTION_INCLUDE_TASKS, _ACTION_INCLUDE_ROLE

    _msg = 'Deprecated setting in config. WARNING: ansible.constants.DEFAULT_ACTION_PLUGIN_PATH is deprecated, use ansible.config.settings.DEFAULT_ACTION_PLUGIN_PATH instead.'
    _version = '2.10'

    _deprecated_sequence_constant = _DeprecatedSequenceConstant(DEFAULT_ACTION_PLUGIN_PATH, _msg, _version)

    assert isinstance(_deprecated_sequence_constant, _DeprecatedSequenceConstant)
    assert isinstance(_deprecated_sequence_constant, Sequence)


# Generated at 2022-06-22 13:46:05.016883
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant('a b c'.split(), 'test', '2.0')
    assert len(seq) == 3
    assert seq[1] == 'b'
    assert 'b' in seq
    assert 'x' not in seq
    assert ' '.join(seq) == 'a b c'
    assert seq[-1] == 'c'
    assert seq[1:3] == ['b', 'c']
    assert seq.count('b') == 1

# Generated at 2022-06-22 13:46:07.673817
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant(range(10), 'hello', '1.0')
    assert d.__len__() == 10



# Generated at 2022-06-22 13:46:20.097824
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], "", "")
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3
    assert len(constant) == 3



# TODO: remove once plugins have moved over to defaults

# Generated at 2022-06-22 13:46:22.226302
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    length = 2
    value = [1, 2]
    msg = 'Deprecated'
    version = '1.0'
    deprecatedSequenceConstant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecatedSequenceConstant) == length


# Generated at 2022-06-22 13:46:23.761881
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len('test') == len(_DeprecatedSequenceConstant('test', 'test', 'test'))



# Generated at 2022-06-22 13:46:25.635926
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
        assert len(_DeprecatedSequenceConstant([1,2], 'test message', 'version 123')) == 2

# Generated at 2022-06-22 13:46:38.271071
# Unit test for function set_constant
def test_set_constant():
    local_dict = {}
    set_constant('FOO', 'BAR', local_dict)
    assert local_dict['FOO'] == 'BAR'
    local_dict = {}
    set_constant('FOO', ['BAR'], local_dict)
    assert local_dict['FOO'] == ['BAR']
    local_dict = {}
    set_constant('FOO', {'BAR': 'BAZ'}, local_dict)
    assert local_dict['FOO'] == {'BAR': 'BAZ'}
    local_dict = {}
    set_constant('FOO', 1, local_dict)
    assert local_dict['FOO'] == 1
    local_dict = {}
    set_constant('FOO', False, local_dict)

# Generated at 2022-06-22 13:46:48.109614
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test no exception
    d = _DeprecatedSequenceConstant([], '', '')
    # test raise exception
    try:
        d = _DeprecatedSequenceConstant(None, '', '')
    except Exception:
        assert True
    try:
        d = _DeprecatedSequenceConstant(None, None, '')
    except Exception:
        assert True
    try:
        d = _DeprecatedSequenceConstant(None, '', None)
    except Exception:
        assert True
    try:
        d = _DeprecatedSequenceConstant(None, None, None)
    except Exception:
        assert True


# Generated at 2022-06-22 13:46:50.823973
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ds = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.0')
    assert len(ds) == 3
    assert ds[0] == 1

# Generated at 2022-06-22 13:46:55.449491
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "This is a test", "1.1")
    assert len(seq) == 3
    assert seq[1] == 2


# Generated at 2022-06-22 13:47:09.260887
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 'test 1')
    set_constant('TEST_SET_CONSTANT2', 1)
    set_constant('TEST_SET_CONSTANT3', [])
    assert TEST_SET_CONSTANT == 'test 1'
    assert TEST_SET_CONSTANT2 == 1
    assert TEST_SET_CONSTANT3 == []

# Generated at 2022-06-22 13:47:14.737121
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_element = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='2.13')
    assert len(list_element) == 3

    tuple_msg = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='tuple_msg', version='2.13')
    assert len(tuple_msg) == 3

# Generated at 2022-06-22 13:47:20.805076
# Unit test for function set_constant
def test_set_constant():
    # Create a temporary dictionary
    export = {}
    # Set the constant in the temporary dictionary
    set_constant('TESTING', '123', export)
    # Assert that the value has been set by expecting it to exist in the dictionary
    assert 'TESTING' in export
    # Assert that the value is correct
    assert export.get('TESTING') == '123'

# Generated at 2022-06-22 13:47:25.436369
# Unit test for function set_constant
def test_set_constant():
    global test_constant_name, test_constant_value
    test_export = {}
    set_constant('test_constant_name', 'test_constant_value', test_export)
    assert test_export['test_constant_name'] == 'test_constant_value'

# Generated at 2022-06-22 13:47:36.562499
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class SomeClass:
        def __init__(self):
            msg = 'This is a deprecated message'
            version = '1.x'
            self._value = ('a', 'b', 'c', 'd')
            self.deprecated = _DeprecatedSequenceConstant(self._value, msg, version)

        def test(self):
            return self.deprecated

    some_class = SomeClass()
    assert len(some_class.test()) == len(some_class._value)
    assert some_class.test()[0] == some_class._value[0]
    assert some_class.test()[1] == some_class._value[1]

# Generated at 2022-06-22 13:47:40.814645
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert x[0] == 'a'
    assert x[1] == 'b'


# Generated at 2022-06-22 13:47:48.011872
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = (1, 2, 3)
    msg = 'Please stop using this constant, it is being deprecated'
    version = '2.12'
    test_object = _DeprecatedSequenceConstant(value, msg, version)
    assert test_object._value == value and test_object._msg == msg and test_object._version == version
    assert str(test_object) == str(value)

    value = u'abc'
    msg = 'Please stop using this constant, it is being deprecated'
    version = '2.12'
    test_object = _DeprecatedSequenceConstant(value, msg, version)
    assert test_object._value == value and test_object._msg == msg and test_object._version == version
    assert str(test_object) == str(value)

    value = u'abc'
    msg

# Generated at 2022-06-22 13:47:52.018588
# Unit test for function set_constant
def test_set_constant():

    # Test that we can set a constant
    set_constant('TEST', 'my test constant')
    assert TEST == 'my test constant'

    # Test that we can override a constant
    set_constant('TEST', 'my other test constant')
    assert TEST == 'my other test constant'

# Generated at 2022-06-22 13:47:56.343389
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pdb; pdb.set_trace()
    seq = _DeprecatedSequenceConstant(['one', 'two', 'three'], 'hello', '1.0')
    assert seq[0] == 'one', "__getitem__ of class _DeprecatedSequenceConstant should return a value of the _value attribute"

# Generated at 2022-06-22 13:48:03.049891
# Unit test for function set_constant
def test_set_constant():
    set_constant('a_string', 'string')
    set_constant('a_int', 42)
    set_constant('a_float', 42.0)
    set_constant('a_bool', True)
    set_constant('a_none', None)
    set_constant('a_list', ['foo', 42])
    set_constant('a_dict', {'foo': 42})

    assert a_string == 'string'
    assert a_int == 42
    assert a_float == 42.0
    assert a_bool is True
    assert a_none is None
    assert a_list == ['foo', 42]
    assert a_dict == {'foo': 42}

    assert 'test_set_constant' in globals()
    assert 'a_string' in globals()

# Generated at 2022-06-22 13:48:22.692280
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', True)
    assert(test == True)


# Ansible version

# Generated at 2022-06-22 13:48:34.985531
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    assert test_dict.get('ANSIBLE_DEBUG') is None
    set_constant('ANSIBLE_DEBUG', True, test_dict)
    assert test_dict['ANSIBLE_DEBUG']
    set_constant('ANSIBLE_SYSTEM_WARNINGS', True, test_dict)
    assert test_dict['ANSIBLE_SYSTEM_WARNINGS']

if DEFAULT_BECOME_METHOD is None and DEFAULT_BECOME is True and DEFAULT_BECOME_USER is not None:
    DEFAULT_BECOME_METHOD = 'sudo'

ALLOWED_TRANSITIVE_HOST_KEYS = ('ansible_ssh_host', 'ansible_host', 'inventory_hostname', 'inventory_hostname_short', 'groups', 'groups_list')

# PLUGIN PATH

# Generated at 2022-06-22 13:48:39.081914
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b']
    msg = 'test'
    version = '6.0'
    c = _DeprecatedSequenceConstant(value, msg, version)
    assert len(c) == len(value)
    assert c[0] == value[0]

# Generated at 2022-06-22 13:48:51.027270
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''Test method __getitem__ of class _DeprecatedSequenceConstant'''
    test_cases = [
        # TestCase(E, [W1], [W2], ...)
        #
        # E: expected result
        # W1, ...: warning messages
        TestCase(1, ['This is test warning 1']),
        TestCase(2, ['This is test warning 2'])
    ]

    for test_case in test_cases:
        value = [0, 1, 2]
        msg = 'test__DeprecatedSequenceConstant___getitem__'
        version = 'test__DeprecatedSequenceConstant___getitem__'
        s = _DeprecatedSequenceConstant(value, msg, version)


# Generated at 2022-06-22 13:48:54.836948
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert test_obj.__len__() == 2


# Generated at 2022-06-22 13:48:58.539565
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='testing', version='testing')
    assert len(seq) == 3


# Generated at 2022-06-22 13:49:00.974312
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(a) == 3
    assert a[1] == 2

# Generated at 2022-06-22 13:49:05.376825
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant(['an', 'array', 'of', 'strings'], 'Some message', 'never')
    assert test_object[0] == 'an'
    assert test_object[2] == 'of'


# Generated at 2022-06-22 13:49:06.870023
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'test', '1.0')) == 3

# Generated at 2022-06-22 13:49:12.356368
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(['one', 'two', 'three', 'four'], 'unittest', 3)
    assert constant[1] == 'two'
    assert constant[-1] == 'four'
    assert constant[0:3] == ['one', 'two', 'three']
    assert constant[::2] == ['one', 'three']
    assert constant[::-1] == ['four', 'three', 'two', 'one']
    assert constant[1:1] == []

# Generated at 2022-06-22 13:49:34.621276
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    setattr(_DeprecatedSequenceConstant, '_value', 'usr/local/bin')
    setattr(_DeprecatedSequenceConstant, '_msg', 'please do not use my feature')
    setattr(_DeprecatedSequenceConstant, '_version', '2.0')
    assert _DeprecatedSequenceConstant('usr/local/bin', 'please do not use my feature', '2.0') == 'usr/local/bin'

# Generated at 2022-06-22 13:49:42.437179
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(value=[1,'2',3], msg='Sample msg', version='2.4')
    assert len(constant) == 3
    assert constant[1] == '2'


# TODO: remove DEPRECATED_BECOME_METHODS and DEPRECATED_BECOME_INFO
BECOME_INFO_KEYS = ('become_user', 'become_pass', 'become_exe', 'become_flags')


# Generated at 2022-06-22 13:49:45.473704
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')
    assert len(seq) == 2
    assert seq[1] == 'b'

# Generated at 2022-06-22 13:49:56.796544
# Unit test for function set_constant
def test_set_constant():
    assert ACTION_DEBUG is _ACTION_DEBUG
    assert ACTION_IMPORT_PLAYBOOK is _ACTION_IMPORT_PLAYBOOK
    assert ACTION_IMPORT_ROLE is _ACTION_IMPORT_ROLE
    assert ACTION_IMPORT_TASKS is _ACTION_IMPORT_TASKS
    assert ACTION_INCLUDE is _ACTION_INCLUDE
    assert ACTION_INCLUDE_ROLE is _ACTION_INCLUDE_ROLE
    assert ACTION_INCLUDE_TASKS is _ACTION_INCLUDE_TASKS
    assert ACTION_INCLUDE_VARS is _ACTION_INCLUDE_VARS
    assert ACTION_META is _ACTION_META
    assert ACTION_SET_FACT is _ACTION_SET_FACT
    assert ACTION_HAS_CMD is _

# Generated at 2022-06-22 13:49:59.888684
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant(('foo', 'bar'), 'Deprecation message', '2.9')
    assert test_constant[0] == 'foo'
    assert test_constant[1] == 'bar'

# Generated at 2022-06-22 13:50:04.062907
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('ANSIBLE_CONFIG', None)
    except Exception as e:
        raise AssertionError("Failed to set constant: %s" % to_text(e))

    try:
        ANSIBLE_CONFIG is None
    except Exception as e:
        raise AssertionError("Failed to set constant: %s" % to_text(e))


# Generated at 2022-06-22 13:50:07.505004
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq_const = _DeprecatedSequenceConstant(['ansible.builtin.apt', 'ansible.legacy.apt'], "", "")
    assert dep_seq_const[0] == 'ansible.builtin.apt'


# Generated at 2022-06-22 13:50:09.069139
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(value=(1,2,3), msg='testing', version='testing').__len__()

# Generated at 2022-06-22 13:50:13.911328
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def test(msg):
        global _deprecated
        old_deprecated = _deprecated

# Generated at 2022-06-22 13:50:19.856477
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def msg(m, version):
        return "msg %s %s" % (m, version)

    def version(v):
        return "version %s" % (v)

    value = ['1', '2']
    x = _DeprecatedSequenceConstant(value, msg, version)
    assert x['0'] == '1'
    assert len(x) == 2

# Generated at 2022-06-22 13:50:38.293313
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    alist = [1, 2, 3]
    deprecated_list = _DeprecatedSequenceConstant(alist, "this is a warning", "2.11")

    assert len(alist) == len(deprecated_list)
    assert deprecated_list[1] == alist[1]


if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()