

# Generated at 2022-06-22 13:40:47.290181
# Unit test for function set_constant
def test_set_constant():
    # Make a copy of the dict
    export = dict({})
    set_constant('CONSTANT', 'value', export)
    assert export['CONSTANT'] == 'value'
    assert 'CONSTANT' in export
    assert 'value' in export.values()

test_set_constant()

# Generated at 2022-06-22 13:40:50.023496
# Unit test for function set_constant
def test_set_constant():
    '''
    Tests the set_constant function for constants
    '''
    value = 'test'
    set_constant('test', value)
    assert value == test
    assert value is test

# Generated at 2022-06-22 13:40:52.083356
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(list(), '', '1.0').__len__()


# Generated at 2022-06-22 13:40:54.536452
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', {'a': 'b'})
    assert TEST_SET_CONSTANT == {'a': 'b'}

# Generated at 2022-06-22 13:40:57.809248
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = [1, 2, 3]
    b = _DeprecatedSequenceConstant([1, 2, 3], 'a is deprecated', version="v3.3.0")
    assert len(a) == len(b), "len of b should be 3"
    assert b[0] == 1, "b[0] should be 1"

# Generated at 2022-06-22 13:41:08.077349
# Unit test for function set_constant
def test_set_constant():
    import tempfile

    tmp_ini = tempfile.NamedTemporaryFile(mode='w', delete=False)
    try:
        tmp_ini.write("[test]\ntest = foo\n")
        tmp_ini.flush()

        test = config.load_config_file(tmp_ini.name)
        assert test
        assert 'test' in test.sections()

        set_constant('test', config.get_config_value('test', 'test'))
        assert test == vars()['test']
    finally:
        tmp_ini.close()

        # Remove tmp_ini file
        import os
        os.unlink(tmp_ini.name)


if config.data.get_config_value('core', 'action_plugins'):
    ACTION_PLUGIN_PATH = config.data.get_

# Generated at 2022-06-22 13:41:20.164604
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.six import PY3, binary_type
    if PY3:
        import io
        data_stream_in = io.StringIO()  # for python3, io.StringIO() is needed
    else:
        import StringIO
        data_stream_in = StringIO.StringIO()  # for python2, StringIO.StringIO() is needed
    msg = "msg"
    version = "2.0"
    obj = _DeprecatedSequenceConstant(data_stream_in, msg, version)
    assert obj[0] == data_stream_in[0]
    if PY3:
        data_stream_in = io.BytesIO()  # for python3, io.BytesIO() is needed
    else:
        data_stream_in = StringIO.StringIO()  #

# Generated at 2022-06-22 13:41:25.252857
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([], 'test_string', '1.0')
    assert obj._msg == 'test_string'
    assert obj._version == '1.0'
    assert isinstance(obj._value, list)
    assert obj._value == []

# Generated at 2022-06-22 13:41:31.689915
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from unittest import TestCase
    from ansible.module_utils.parsing.convert_bool import BOOLEAN_FALSE
    test_case = TestCase()
    msg = u'This is a test'
    version = u'v2.9'
    test_instance = _DeprecatedSequenceConstant(BOOLEAN_FALSE, msg, version)
    test_case.assertEqual(test_instance._value, BOOLEAN_FALSE)
    test_case.assertEqual(test_instance._msg, msg)
    test_case.assertEqual(test_instance._version, version)

# Generated at 2022-06-22 13:41:44.828961
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestClass(object):
        def __init__(self):
            set_constant('DEP_STR', 'string')
            set_constant('DEP_ILLEGAL', 'var:')

            set_constant('DEP_LIST', 'DEP_STR, DEP_ILLEGAL')
            set_constant('DEP_LIST_SI', 'DEP_STR, DEP_ILLEGAL, a.legal.var')
            set_constant('DEP_LIST_NOEVAL', 'DEP_STR, DEP_ILLEGAL, a.not.defined.var')
            set_constant('DEP_LIST_NOPREFIX', 'DEP_STR, DEP_ILLEGAL, DEP_STR')


# Generated at 2022-06-22 13:41:49.607638
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'do not use', '2.0')) == 3



# Generated at 2022-06-22 13:41:53.076768
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert(len(dsc) == 3)

# Unit tests for constant ANSIBLE_COLLECTIONS

# Generated at 2022-06-22 13:41:57.718431
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ['a', 'b', 'c']
    msg = 'this is deprecated'
    version = '2.13'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == 'a'

# Generated at 2022-06-22 13:42:03.753480
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'old_constant is deprecated, please use new_constant'
    version = '2.0'
    value = (1, 2, 3)
    constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(constant) == len(value)
    assert constant[0] == value[0]
    assert constant[-1] == value[-1]



# Generated at 2022-06-22 13:42:07.599791
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), "test", "2.80")) == 3



# Generated at 2022-06-22 13:42:13.509669
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1,2,3,4], "test warning message", "version")
    assert len(obj) == 4
    assert obj[0] == 1
    assert obj[2] == 3

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-22 13:42:16.279127
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert obj.__getitem__(1) == 2


# Generated at 2022-06-22 13:42:24.004837
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'a is a list', '2.5') == [1, 2, 3]


# NOTE: these are more-or-less private/core constants,
# please do not add things here unless they are really
# core constants.  This file should import any constants
# from other files if they are used here.


# Generated at 2022-06-22 13:42:28.637545
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'the world has ended'
    version = '2.9'
    value = [123, 'xyz']
    seq_const_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert seq_const_obj[1] == 'xyz'

# Generated at 2022-06-22 13:42:33.589895
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    instance = _DeprecatedSequenceConstant([], '', '')
    assert len(instance) == 0

    instance = _DeprecatedSequenceConstant((1, 2), '', '')
    assert len(instance) == 2
    assert instance[0] == 1
    assert instance[-1] == 2

# Generated at 2022-06-22 13:42:42.522305
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CALLBACK_WHITELIST == frozenset(('default', 'timer'))
    assert ANSIBLE_CONFIG == '/etc/ansible/ansible.cfg'
    assert ANSIBLE_NOCOWS == 0
    assert ANSIBLE_NOCOLOR == '0'
    assert ANSIBLE_NOCOWS == 0
    assert ANSIBLE_STDOUT_CALLBACK == 'default'

# Generated at 2022-06-22 13:42:46.515827
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 13:42:55.875531
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # A deprecated sequence can be iterated like any other sequence
    for action in _ACTION_ALL_INCLUDE_IMPORT_TASKS:
        assert action in ('include', 'include_tasks', 'import_tasks', 'include_role', 'import_role')

    # Deprecation warning is triggered when sequence is accessed directly
    try:
        len(_ACTION_ALL_INCLUDE_IMPORT_TASKS)
        assert False, 'Expected DeprecationWarning'
    except DeprecationWarning:
        pass



# Generated at 2022-06-22 13:43:00.790717
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(['1', '2', '3'], 'test', '2.0')
    assert len(x) == 3
    try:
        _DeprecatedSequenceConstant([], 'test', '2.0')
    except AssertionError:
        pass



# Generated at 2022-06-22 13:43:04.810371
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_value = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert deprecated_value[0] == 1
    assert deprecated_value[1] == 2
    assert deprecated_value[2] == 3


# Generated at 2022-06-22 13:43:05.875397
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(list(range(3)), 'msg', 'version')
    assert len(c) == 3


# Generated at 2022-06-22 13:43:09.933251
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def mock_deprecated(msg, version):
        print('[DEPRECATED] %s, to be removed in %s' % (msg, version))

    _deprecated = mock_deprecated
    test = _DeprecatedSequenceConstant('foo', 'bar', 'baz')
    test[0]
    test[1]


# Generated at 2022-06-22 13:43:22.274671
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO_INT', 10)
    set_constant('FOO_STRING', "10")
    set_constant('FOO_FLOAT', 10.0)
    set_constant('FOO_BOOL_TRUE', True)
    set_constant('FOO_BOOL_FALSE', False)
    set_constant('FOO_BOOL_BOGUS', "shouldBeBool")
    set_constant('FOO_BOGUS', "shouldBeAnInt")
    set_constant('FOO_BOGUS_2', "42")
    assert FOO_INT == 10
    assert FOO_STRING == "10"
    assert FOO_FLOAT == 10.0
    assert FOO_BOOL_TRUE
    assert not FOO_BOOL

# Generated at 2022-06-22 13:43:23.769016
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant((1, 2, 3), 'This is a test', '1.10.0')

# Generated at 2022-06-22 13:43:29.050674
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant(1, '', '1.1')
    assert isinstance(deprecated, Sequence)
    assert len(deprecated) == 1
    assert deprecated[0] == 1


# Generated at 2022-06-22 13:43:44.268029
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    m = 'msg'
    v = 'version'
    c = _DeprecatedSequenceConstant(value='value', msg=m, version=v)
    assert 'value' == c[0]
    assert m == _DeprecatedSequenceConstant.msg
    assert v == _DeprecatedSequenceConstant.version


# Generated at 2022-06-22 13:43:47.332436
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # define a message which is used for the test
    msg = 'msg_test'
    version = 'version_test'
    # define an object of class _DeprecatedSequenceConstant
    a = _DeprecatedSequenceConstant([0, 1], msg, version)
    assert a[1] == 1
    # define a second object of class _DeprecatedSequenceConstant
    b = _DeprecatedSequenceConstant([2, 3], msg, version)
    assert b[0] == 2


# Generated at 2022-06-22 13:43:51.156469
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], "this is a test", "1.0")
    assert deprecated_sequence_constant[0] == 1
    assert len(deprecated_sequence_constant) == 3

# Generated at 2022-06-22 13:43:53.931174
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(value=[1,2,3], msg='123', version='1.1').__len__() == 3


# Generated at 2022-06-22 13:43:56.772330
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'ver')
    assert sequence_constant[0] == 'a'
    assert sequence_constant[1] == 'b'



# Generated at 2022-06-22 13:44:09.315468
# Unit test for function set_constant
def test_set_constant():
    '''
    Test set_constant function for valid name and export,
    and for invalid name.
    '''
    global RESTRICTED_RESULT_KEYS
    set_constant('RESTRICTED_RESULT_KEYS', ('foo'))
    assert 'RESTRICTED_RESULT_KEYS' in export
    assert RESTRICTED_RESULT_KEYS == ('foo', 'ansible_rsync_path', 'ansible_playbook_python', 'ansible_facts')

    try:
        set_constant(None, 'foo')
    except TypeError:
        pass
    else:
        assert False

# allow DeprecatedSequenceConstant to be used to warn on deprecations
setattr(__builtins__, 'DeprecatedSequenceConstant', _DeprecatedSequenceConstant)

# Generated at 2022-06-22 13:44:14.067954
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.0')
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3
    try:
        c[3]
        assert False, 'Expected exception not raised'
    except IndexError:
        pass


# Generated at 2022-06-22 13:44:17.644709
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = []
    msg = u"Hola"
    version = "2.9"
    test_object = _DeprecatedSequenceConstant(value, msg, version)
    assert test_object._value == value
    assert test_object._msg == msg
    assert test_object._version == version


# Generated at 2022-06-22 13:44:21.323858
# Unit test for function set_constant
def test_set_constant():
    assert 'SSH_CONTROL_PATH_DIR' in vars()
    assert SSH_CONTROL_PATH_DIR == u'/tmp'

# Generated at 2022-06-22 13:44:24.003538
# Unit test for function set_constant
def test_set_constant():
    foo = 'bar'
    test_set = {}
    set_constant('foo', foo, export=test_set)
    assert test_set['foo'] == foo

# Generated at 2022-06-22 13:44:55.204380
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_ = _DeprecatedSequenceConstant([1,'2'], 'msg', '1.0')
    assert class_.__len__() == 2
    assert class_.__getitem__(1) == '2'

# Generated at 2022-06-22 13:45:01.779358
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_value = ['test1', 'test2']
    list_object = _DeprecatedSequenceConstant(list_value, 'test_msg', '2.11')

    assert list_object[0] == 'test1'
    assert list_object[1] == 'test2'
    assert len(list_object) == 2

# Generated at 2022-06-22 13:45:07.196770
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3, 4]
    test_msg = "Test string"
    test_version = "1.0.0"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 13:45:11.137677
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert d[0] == 1
    assert d[1] == 2
    assert d.__getitem__(slice(1)) == [2]

# Generated at 2022-06-22 13:45:18.389394
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "The following deprecated feature is set in ansible.cfg: 'param_name'. " \
          "It will be removed in Ansible 2.11. To silence this message, set '" \
          "param_name' to an empty string."
    version = '2.11'
    sequence = _DeprecatedSequenceConstant(['test'], msg, version)

    assert sequence[0] == 'test'
    assert len(sequence) == 1

# Generated at 2022-06-22 13:45:24.169228
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'test message'
    version = 'test version'
    value = ['test1', 'test2']
    test_obj = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)
    assert test_obj[0] == 'test1'
    assert test_obj[1] == 'test2'



# Generated at 2022-06-22 13:45:28.116457
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class EmptySequence():
        def __len__(self):
            return 0

    empty = EmptySequence()
    dsc = _DeprecatedSequenceConstant(empty, 'msg', 'version')

    assert len(dsc) == len(empty)
    assert len(dsc) == 0


# Generated at 2022-06-22 13:45:28.977430
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS == None

# Generated at 2022-06-22 13:45:41.083031
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest
    from ansible.module_utils.common.collections import Sequence
    from ansible.errors import AnsibleDeprecationWarning

    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="don't use it", version="2.9")

    with pytest.warns(AnsibleDeprecationWarning, match="don't use it"):
        assert dsc[0] == 1

    with pytest.warns(AnsibleDeprecationWarning, match="don't use it"):
        assert dsc[1] == 2

    with pytest.warns(AnsibleDeprecationWarning, match="don't use it"):
        assert dsc[2] == 3

    with pytest.raises(IndexError):
        dsc[3]

# Generated at 2022-06-22 13:45:49.297609
# Unit test for function set_constant
def test_set_constant():
    '''
    Validate set_constant function.
    '''
    my_dict = {}
    set_constant('test_constant', 'test_value', export=my_dict)
    assert my_dict['test_constant'] == 'test_value'
    set_constant('test_int', 23, export=my_dict)
    assert my_dict['test_int'] == 23

# Generated at 2022-06-22 13:47:00.720373
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def mock_deprecated(msg, version):
        return msg, version
    my_fqcn = add_internal_fqcns(('example', ))[1]
    msg, version = _DeprecatedSequenceConstant(
        [1, 2],
        msg='"%s" is deprecated' % my_fqcn,
        version='2.10'
    ).__getitem__(0)
    assert msg == '"example" is deprecated'
    assert version == '2.10'

# Generated at 2022-06-22 13:47:13.683402
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def getitem(value, types, index):
        if isinstance(value, types):
            return value[index]
        return None

    class BaseTest(object):
        def __init__(self, value, msg, version, index, types):
            self.value = _DeprecatedSequenceConstant(value, msg, version)
            self.index = index
            self.types = types

        def __getitem__(self, key):
            return getitem(self.value, self.types, key)

        def check_message(self):
            _msg = getitem(self.value, self.types, self.index)
            return self.value._msg in _msg if isinstance(_msg, basestring) else False


# Generated at 2022-06-22 13:47:18.651169
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.compat import _DeprecatedSequenceConstant
    msg = "example message"
    version = "4.4.0"
    seq_const_obj = _DeprecatedSequenceConstant("example data", msg, version)
    assert(seq_const_obj[0] == "e")

# Generated at 2022-06-22 13:47:20.683630
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("constant", True) == {'constant':True}


# Generated at 2022-06-22 13:47:23.603010
# Unit test for function set_constant
def test_set_constant():
    # Set global const
    set_constant('test', 'val')
    # Check if global const
    assert(test == 'val')

# Generated at 2022-06-22 13:47:26.598200
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Using this will cause a traceback'
    version = '2.8'
    value = [1, 2, 3]
    sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequence) == len(value)



# Generated at 2022-06-22 13:47:33.877472
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "As of Ansible 2.9, this option has been renamed to 'example_option'"
    version = "2.10"
    compare_value = [1, 2, 3]
    val = _DeprecatedSequenceConstant(compare_value, msg, version)
    assert val[0] == compare_value[0]
    assert val[1] == compare_value[1]
    assert val[2] == compare_value[2]


# Generated at 2022-06-22 13:47:37.545016
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep_seq_const = _DeprecatedSequenceConstant('test', 'test', 'test')
    assert len(dep_seq_const) == 4
    assert dep_seq_const[0] == 't'

# Generated at 2022-06-22 13:47:44.036882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_msg = "This is deprecated"
    deprecated_version = "2.9.0"
    list_seq = _DeprecatedSequenceConstant(['a', 'b'], deprecated_msg, deprecated_version)
    assert len(list_seq) == 2
    assert list_seq[0] == 'a'
    assert list_seq[1] == 'b'

# Generated at 2022-06-22 13:47:52.722307
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class _DeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    sequences = ['a', 'b']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(sequences, 'msg', '2.0')

    assert deprecated_sequence_constant[0] == 'a'
    assert deprecated_sequence_constant[1] == 'b'
    assert len(deprecated_sequence_constant) == 2

# Generated at 2022-06-22 13:50:07.864524
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = [1,2,3]
    dsc = _DeprecatedSequenceConstant(a, 'msg', 'version')
    assert dsc[1] == 2

test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 13:50:09.100146
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '') == []



# Generated at 2022-06-22 13:50:13.961840
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test method __len__ of class _DeprecatedSequenceConstant"""
    newlist = list()
    newlist.append(1)
    newlist.append(2)
    newlist.append(3)
    assert len(_DeprecatedSequenceConstant(newlist, "test message", "test version")) == len(newlist)

# Generated at 2022-06-22 13:50:16.175813
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 13:50:23.195741
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class DummyClass:
        def __init__(self):
            self.msg = "msg"
            self.version = "version"
            self.value = "value"
            self.generic_result = None

        # Unit test for method __getitem__ of class DummyClass
        def test___getitem__(self):
            self.generic_result = _DeprecatedSequenceConstant.__getitem__(self, self.value)

    obj = DummyClass()
    obj.test___getitem__()
    return obj.generic_result


# Generated at 2022-06-22 13:50:33.937887
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible import constants
    import os
    import tempfile
    tmp_path = tempfile.mkdtemp()
    # test 1
    dsc = _DeprecatedSequenceConstant((1,2), "test", "2.8")
    assert dsc[0] == 1
    # test 2
    dsc = _DeprecatedSequenceConstant((3,4), "test", "2.8")
    assert dsc[1] == 4
    # test 3
    dsc = _DeprecatedSequenceConstant([1,2], "test", "2.8")
    assert dsc[0] == 1
    # test 4
    dsc = _DeprecatedSequenceConstant([3,4], "test", "2.8")
    assert dsc[1] == 4

# Generated at 2022-06-22 13:50:37.157582
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3, 4]
    m = _DeprecatedSequenceConstant(l, "msg", "version")
    assert m[0] == 1
    assert m[1] == 2
    assert m[2] == 3
    assert m[3] == 4
