

# Generated at 2022-06-22 13:40:44.130603
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([], msg='MSG', version=__version__)
    assert constant._value == []
    assert constant._msg == 'MSG'
    assert constant._version == __version__

# Generated at 2022-06-22 13:40:48.112411
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_var = {'foobar': 'norf'}
    c = _DeprecatedSequenceConstant(test_var, "MSG", "VERSION")
    assert len(c) == len(test_var)


# Generated at 2022-06-22 13:40:50.806114
# Unit test for function set_constant
def test_set_constant():

    global FOO, BAR

    set_constant('FOO', 1)
    assert FOO, 1

    set_constant('BAR', 1, globals())
    assert globals()['BAR'], 1

# Generated at 2022-06-22 13:40:53.649606
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(['foo', 'bar'], 'Deprecation message', '3.0')
    assert len(constant) == 2



# Generated at 2022-06-22 13:40:55.920252
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(a) == len(a._value)


# Generated at 2022-06-22 13:40:59.515408
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant((0,1), "", "")
    assert dsc[0] == 0
    assert dsc[1] == 1


# Generated at 2022-06-22 13:41:00.455131
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1], '', '')) == 1


# Generated at 2022-06-22 13:41:05.623687
# Unit test for function set_constant
def test_set_constant():
    import os

    set_constant('MY_CONSTANT', 42)
    assert os.environ.get('ANSIBLE_MY_CONSTANT') == '42'
    del os.environ['ANSIBLE_MY_CONSTANT']

    set_constant('MY_CONSTANT', 42, export=globals())
    assert MY_CONSTANT == 42
    assert os.environ.get('ANSIBLE_MY_CONSTANT') == '42'
    del os.environ['ANSIBLE_MY_CONSTANT']
    delglobals()['MY_CONSTANT']


# Generated at 2022-06-22 13:41:13.911690
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest as ut
    ut.TestCase().assertTrue(isinstance(_DeprecatedSequenceConstant([1,2,3], 'warn', 'v2'), Sequence))
    # Test of the __len__ method of the class _DeprecatedSequenceConstant.
    # If the __len__ method of the class _DeprecatedSequenceConstant is called then it will display a deprecated warning.
    ut.TestCase().assertEqual(len(_DeprecatedSequenceConstant([1,2,3], 'warn', 'v2')),3)
    # Test of the __getitem__ method of the class _DeprecatedSequenceConstant.
    ut.TestCase().assertTrue(isinstance(_DeprecatedSequenceConstant([1,2,3], 'warn', 'v2')[0],type(1)))

# test for function _deprecated

# Generated at 2022-06-22 13:41:15.509223
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(['a', 'b'], 'message', 'version')

# Generated at 2022-06-22 13:41:30.095789
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class FakeDisplay(object):
        def __init__(self):
            self.deprecated_call_count = 0
        def deprecated(self, msg, version):
            self.deprecated_call_count += 1

    fake_display = FakeDisplay()
    original_display = globals().get('Display', None)
    globals()['Display'] = fake_display

    fake_sequence_constant = _DeprecatedSequenceConstant(('foo'), 'deprecated message', '2.5')
    assert fake_sequence_constant[0] == 'foo'
    assert fake_sequence_constant._msg == 'deprecated message'
    assert fake_sequence_constant._version == '2.5'
    assert fake_display.deprecated_call_count == 1


# Generated at 2022-06-22 13:41:33.539835
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(c) == 3


# Generated at 2022-06-22 13:41:37.465510
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a'], '', '')[0] == 'a'
    assert [item for item in _DeprecatedSequenceConstant(['a'], '', '')] == ['a']


# Generated at 2022-06-22 13:41:50.655863
# Unit test for function set_constant
def test_set_constant():
    class MyClass(object):
        pass

    class MyOtherClass(object):
        pass

    # test that constants work with simple types
    set_constant('test_int_constant', 42, MyClass)
    assert MyClass.test_int_constant == 42

    set_constant('test_float_constant', 42.42, MyClass)
    assert MyClass.test_float_constant == 42.42

    set_constant('test_str_constant', 'string', MyClass)
    assert MyClass.test_str_constant == 'string'

    set_constant('test_unicode_constant', u'unicode', MyClass)
    assert MyClass.test_unicode_constant == u'unicode'

    set_constant('test_bool_constant', True, MyClass)

# Generated at 2022-06-22 13:41:52.615167
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.2')[2] == 3

# Generated at 2022-06-22 13:42:04.087128
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class __test__test__test__test__test__test__test__test__test__test__test__test__test__test__test__test__test__test__test__test(object):
        # this class is created to test method __getitem__ of class _DeprecatedSequenceConstant
        def __init__(self, mock_version, mock_value, mock_msg):
            # the mock function which is being called when calling dsc['mock_key']
            def mock_deprecated(mock_msg, mock_version):
                mock_deprecated.mock_called = True
            mock_deprecated.mock_called = False

            # the mock function which is being called when calling dsc.__len__()
            def mock_len(mock_value):
                return len(mock_value)

            self.dsc

# Generated at 2022-06-22 13:42:13.210416
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', 'test version')
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3
    d_empty = _DeprecatedSequenceConstant([], 'test msg', 'test version')
    assert d_empty == []
    assert d_empty[0] is None
    assert d_empty[-1] is None


# Generated at 2022-06-22 13:42:15.683530
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'ver')(1)
    assert result == 'b'

# Generated at 2022-06-22 13:42:17.712959
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], None, None)) == 0


# Generated at 2022-06-22 13:42:20.076347
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    constant = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')
    assert len(constant) == 3


# Generated at 2022-06-22 13:42:34.799399
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def _display(msg):
        return 'msg: %s' % msg

    def _get_versions(version):
        return ('%s.%s' % (version.split('.')[0], version.split('.')[1]))

    import sys
    original_stderr = sys.stderr

    class StderrBuffer(object):
        def write(self, s):
            self.buffer = s


# Generated at 2022-06-22 13:42:41.873130
# Unit test for function set_constant
def test_set_constant():
    a = {}
    set_constant('test', [1, 2, 3], a)
    if not 'test' in a or a.get('test') != [1, 2, 3]:
        raise AssertionError("Failed to set a dictionary value using set_constant()")

_DEFAULT_IS_LIGHTWEIGHT = DEFAULT_IS_LIGHTWEIGHT
DEFAULT_IS_LIGHTWEIGHT = False

# Generated at 2022-06-22 13:42:48.478243
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def run_test(value, msg, version):
        d = _DeprecatedSequenceConstant(value, msg, version)
        assert d[0] == value[0]
        assert d[1] == value[1]

    # setup test
    value = (1, 2)
    msg = ('elements should be tuples of strings', )
    version = '2.0'

    # run test
    run_test(value, msg, version)

# Generated at 2022-06-22 13:43:01.552679
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    for value in [
        (),
        [],
        [1, 2, 3],
        (1, 2, 3),
    ]:
        for version in [
            '3.0',
            '3.1',
            '3.2',
            '3.3',
            '4.0',
        ]:
            for msg in [
                'Use a dict instead',
                'Dicts are more awesome than lists',
                'Foo bar baz',
            ]:
                obj = _DeprecatedSequenceConstant(value, msg, version)
                if not isinstance(value, tuple):
                    assert isinstance(obj, list)
                else:
                    assert isinstance(obj, tuple)
                assert obj.__getitem__(0) == obj[0]
                assert obj.__getitem__(1)

# Generated at 2022-06-22 13:43:04.765938
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'test string'
    dep_const = _DeprecatedSequenceConstant(('test', 'string'), msg, '2.13')
    assert dep_const[1] == 'string'

# Generated at 2022-06-22 13:43:07.998003
# Unit test for function set_constant
def test_set_constant():
    global TEST_CONSTANT
    set_constant('TEST_CONSTANT', 'value')
    assert TEST_CONSTANT == 'value'
    set_constant('TEST_CONSTANT', True)
    assert TEST_CONSTANT is True


# Generated at 2022-06-22 13:43:11.567504
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(test_object) == 3


# Generated at 2022-06-22 13:43:14.489511
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('testvar', 2) == {'testvar': 2}


# Generated at 2022-06-22 13:43:25.062172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for str in COMPATIBLE_SERIALIZATIONS
    assert len(_CONNECTION_PLUGIN_PATH) == 2
    assert _CONNECTION_PLUGIN_PATH[0] == "ansible.plugins.connection"
    assert _CONNECTION_PLUGIN_PATH[1] == "ansible.plugins.connection.network_cli"
    # Test for list in COMPATIBLE_SERIALIZATIONS
    assert len(_DEFAULT_BECOME_METHODS) == 4
    assert _DEFAULT_BECOME_METHODS[0] == 'sudo'
    assert _DEFAULT_BECOME_METHODS[1] == 'su'
    assert _DEFAULT_BECOME_METHODS[2] == 'pbrun'

# Generated at 2022-06-22 13:43:32.006251
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant(['a', 1, 'b', 2, ], 'test_msg', '2.12')
    assert value[0] == 'a'
    assert value[1] == 1
    assert value[2] == 'b'
    assert value[3] == 2
    assert value[4] is None
    assert len(value) == 4
    assert value[-1] == 2


# Generated at 2022-06-22 13:43:39.724759
# Unit test for function set_constant
def test_set_constant():
    assert C.FOO == 334
    assert C.GARBAGE == []

# Generated at 2022-06-22 13:43:50.845107
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_KEY', 'TEST_VALUE', vars())
    assert vars()['TEST_KEY'] == 'TEST_VALUE'
    set_constant('TEST_KEY', 'TEST_VALUE2', vars())
    assert vars()['TEST_KEY'] == 'TEST_VALUE2'


# now all the deprecated names
for deprecated_name in config.deprecated_names():
    # get the new option name, and use that to look up the value
    new_name = config.deprecated_names()[deprecated_name]
    set_constant(deprecated_name, vars()[new_name], vars())

# Generated at 2022-06-22 13:43:59.547949
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test with Sequence
    message = "bar"
    version = '2.8'
    result = _DeprecatedSequenceConstant(['foo'], message, version)
    assert isinstance(result, Sequence)
    # Test with list
    result = _DeprecatedSequenceConstant(list(['foo']), message, version)
    assert isinstance(result, Sequence)
    # Test with tuple
    result = _DeprecatedSequenceConstant((list(['foo'])), message, version)
    assert isinstance(result, Sequence)
    # Test __len__
    assert len(result) == len(['foo'])
    # Test __getitem__
    assert result[0] == result._value[0]
    # Test with invalid type

# Generated at 2022-06-22 13:44:06.344932
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = u"This method has been deprecated. see https://github.com/ansible/ansible/issues/12345"
    version = "2.8"

    assert _DeprecatedSequenceConstant([1, 2, 3], msg, version)[1] == 2
    assert _DeprecatedSequenceConstant("abc", msg, version)[1] == "b"

# Generated at 2022-06-22 13:44:13.612216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class __DeprecatedSequenceConstant___getitem__TestCase(unittest.TestCase):
        def test__DeprecatedSequenceConstant___getitem__(self):
            msg = 'test msg'
            version = 'test version'
            value = (1, 2, 3)
            item = 1

            dsc = _DeprecatedSequenceConstant(value, msg, version)
            assert type(dsc) is _DeprecatedSequenceConstant
            assert len(dsc) == len(value)
            assert dsc[item] == value[item]

# Generated at 2022-06-22 13:44:17.329075
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    L = ['a', 'b', 'c']
    msg = 'This is a test message'
    version = '1.2.3'
    obj = _DeprecatedSequenceConstant(L, msg, version)

    assert len(obj) == 3, 'Length of list should be 3.'


# Generated at 2022-06-22 13:44:30.163434
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}

    # test scalar / string
    set_constant('test_option', 'sample_string', export=test_dict)
    assert test_dict['test_option'] == 'sample_string'

    # test scalar / boolean
    set_constant('test_option', True, export=test_dict)
    assert test_dict['test_option'] is True

    # test list
    set_constant('test_option', ['item1', 'item2', 'item3'], export=test_dict)
    assert test_dict['test_option'][0] == 'item1'
    assert test_dict['test_option'][1] == 'item2'
    assert test_dict['test_option'][2] == 'item3'

    # test dict

# Generated at 2022-06-22 13:44:35.284956
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    expected = ('a', 'b', 'c')
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'Something', '2.9')
    assert len(dsc) == len(expected)
    for idx, item in enumerate(dsc):
        assert item == expected[idx]

# Generated at 2022-06-22 13:44:39.557044
# Unit test for function set_constant
def test_set_constant():
    x = {}
    set_constant('FOO', 42, export=x)
    assert x['FOO'] == 42
    set_constant('FOO', '43', export=x)
    assert x['FOO'] == '43'

# Generated at 2022-06-22 13:44:43.672556
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test len of object class
    object_ = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(object_) == 3

    # Test len of class
    assert _DeprecatedSequenceConstant.__len__(object_) == 3


# Generated at 2022-06-22 13:44:52.078377
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected = 3
    given = _DeprecatedSequenceConstant([1, 2, 3], 'Not Available', 'X.X')

    assert len(given) == expected


# Generated at 2022-06-22 13:45:05.024683
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test if __init__ works as expected
    msg = 'test1'
    deprecated_constant = _DeprecatedSequenceConstant(('a', 'b'), msg, '1.1')
    assert deprecated_constant._value == ('a', 'b')
    assert deprecated_constant._msg == msg
    assert deprecated_constant._version == '1.1'

    # Test if object behaves as its value
    assert deprecated_constant[1] == 'b'

    # Test if object deprecates when called
    import mock
    with mock.patch('ansible.config.constants.Display') as display:
        deprecated_constant[1]
        display.deprecated.assert_called_once_with(msg, version='1.1')
        assert display.warning.call_count == 0

    # Test if binded local

# Generated at 2022-06-22 13:45:08.918580
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestDeprecatedSequenceConstant(Sequence):
        pass
    TestDeprecatedSequenceConstant([], 'hello_world', '2.8')

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:45:10.945801
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # All code paths covered by tests
    return True



# Generated at 2022-06-22 13:45:17.078330
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'test_msg'
    version = '2.4'
    test_data = ('A', 'B', 'C')
    test_obj = _DeprecatedSequenceConstant(test_data, msg, version)

    assert len(test_obj) == len(test_data)
    assert test_obj[2] == test_data[2]

# Generated at 2022-06-22 13:45:20.141748
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sc1 = _DeprecatedSequenceConstant(value = [1, "two", 3], msg = "test message", version = "1.9")
    sc1[1]
    len(sc1)

# Generated at 2022-06-22 13:45:27.884463
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test __getitem__ on '_DeprecatedSequenceConstant' object
    # (1) Test with the object having an index present
    obj_1 = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert obj_1[1] == 2
    # (2) Test with the object not having an index present
    obj_2 = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    try:
        assert obj_2[4]
    except IndexError:
        pass


# Generated at 2022-06-22 13:45:32.118023
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert seq[1] == 2

# Generated at 2022-06-22 13:45:34.977597
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "Warning Message", "Version Message")
    assert len(dsc) == 3
    assert dsc[1] == 2

# Generated at 2022-06-22 13:45:40.007414
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    r = _DeprecatedSequenceConstant([4, 5, 6], 'foo', '2.6')
    assert len(r) == 3
    assert r[0] == 4
    assert r[1] == 5
    assert r[2] == 6

# Unit test the MAGIC_VARIABLE_MAPPING dict

# Generated at 2022-06-22 13:45:59.007291
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    class MyDeprecatedSequenceConstant(Sequence, object):
        ''' dummy class for using in test '''
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]

    a_list = [1, 2, 3]
    my_sequence_constant = MyDeprecatedSequenceConstant(a_list, 'my_msg', 'my_version')
    assert my_sequence_constant[0] == 1
    assert my_sequence_constant[1] == 2
    assert my_sequence_constant

# Generated at 2022-06-22 13:46:00.635825
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant('value', 'msg', 'version')

# Generated at 2022-06-22 13:46:06.803474
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Test method _DeprecatedSequenceConstant.__getitem__
       with a Sequence instance as input.
    """
    msg = "This is a warning message"
    version = "2.8"
    mylist = _DeprecatedSequenceConstant([1, 2], msg, version)

    assert mylist[0] == 1
    assert mylist[1] == 2

# Generated at 2022-06-22 13:46:09.086338
# Unit test for function set_constant
def test_set_constant():
    test_constant_value = 'Test Constant'
    set_constant('test_constant', test_constant_value)
    assert test_constant == test_constant_value

# Generated at 2022-06-22 13:46:13.983619
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a DeprecatedSequenceConstant test message.'
    version = '2.9'
    seq = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], msg, version)
    assert seq[2] == 3



# Generated at 2022-06-22 13:46:19.832593
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "this is a test"
    version = "2.0"
    test_value = ('test1', 'test2', 'test3')
    test_object = _DeprecatedSequenceConstant(test_value, msg, version)
    assert len(test_object) == len(test_value)


# Generated at 2022-06-22 13:46:29.181747
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_values = [('a', 'b', 'c'),
                   (1, 2, 3),
                   (1.1, 1.2, 1.3),
                   (None, None, None),
                   (True, False, True),
                   (1, 2, '3')]
    for test_value in test_values:
        actual = _DeprecatedSequenceConstant(test_value[0], test_value[1], test_value[2])
        # 'actual' should be an object with the value of test_value[0], and should have length 1
        assert(actual[0] == test_value[0])
        assert(len(actual) == 1)

# Generated at 2022-06-22 13:46:36.164285
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """ Test __len__ of _DeprecatedSequenceConstant """
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    test_list ='test_list'
    test_msg = 'test_msg'
    test_version = 'test_version'
    a = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(a) == len(test_list)

# Generated at 2022-06-22 13:46:46.703863
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import pytest

    # DeprecatedSequenceConstant object
    deprecated_sequence_constant_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.6')

    if not isinstance(len(deprecated_sequence_constant_obj), int):
        pytest.fail("Expected <class 'int'>, but got <class '%s'>" % type(len(deprecated_sequence_constant_obj)))

    if len(deprecated_sequence_constant_obj) != 3:
        pytest.fail("Expected 3, but got %s " % len(deprecated_sequence_constant_obj))


# Generated at 2022-06-22 13:46:50.908997
# Unit test for function set_constant
def test_set_constant():

    set_constant('test_set_constant', True)
    assert 'test_set_constant' in globals()
    assert 'test_set_constant' in locals()
    assert globals()['test_set_constant']
    assert locals()['test_set_constant']

# Generated at 2022-06-22 13:47:27.452747
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_MODULE_ARGS == {"param1": "a", "param2": "b"}
    assert TEST_VAR == "a"
    assert TEST_LIST == ["a", "b"]
    assert TEST_DICT == {"a": "b"}
    assert TEST_BOOL == True

# fix up the deprecated constants such that their values are resolved
# during runtime, to avoid issues where they are not resolved during
# the initial config parsing stage
for constant_name, (msg, version) in config.data.get_deprecated_constants().items():
    value = globals()[constant_name]
    if isinstance(value, Sequence):
        globals()[constant_name] = _DeprecatedSequenceConstant(value, msg, version)

# Generated at 2022-06-22 13:47:39.512967
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', "I'm a string!")

    assert 'test_constant' in globals()
    assert globals()['test_constant'] == "I'm a string!"

# import module_utils path for Ansible 2.4 compat
# FIXME: remove once support for Ansible 2.4 is dropped
try:
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE  # task_vars
except ImportError:
    try:
        from ansible.utils.boolean import boolean  # task_vars
    except ImportError:
        # kludge to make sure on_par with 2.5+
        BOOLEANS_TRUE = boolean.BOOLEANS_TRUE

# Generated at 2022-06-22 13:47:44.434024
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = (1,2,3)
    msg = "Don't do that"
    version = '2.0'
    len_seq = len(value)
    dep_seq = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dep_seq) == len_seq



# test boolean constants

# Generated at 2022-06-22 13:47:47.895949
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2]
    msg = 'msg'
    version = 'version'
    d = _DeprecatedSequenceConstant(value, msg, version)
    assert len(d) == len(value)


# Generated at 2022-06-22 13:47:53.038373
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(('k1', 'k2'), 'test_msg', 'test_version')
    assert len(test_obj) == 2
    assert test_obj[0] == 'k1'
    assert test_obj[1] == 'k2'
    test_obj[0] = 'test'
    assert test_obj[0] == 'test'

# Generated at 2022-06-22 13:47:57.629371
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant = _DeprecatedSequenceConstant(value=['test', 'value'], msg='Test message', version='2.1')
    assert len(deprecated_constant) == 2
    assert deprecated_constant[0] == 'test'
    assert deprecated_constant[1] == 'value'

# Generated at 2022-06-22 13:48:00.779326
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    my_sequences = _DeprecatedSequenceConstant([0, 1, 2, 3], '', '')
    assert my_sequences[0] == 0, "test__DeprecatedSequenceConstant___getitem__ failed"
    assert my_sequences[-1] == 3, "test__DeprecatedSequenceConstant___getitem__ failed"


# Generated at 2022-06-22 13:48:05.288519
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(ACTION_ALL_INCLUDES) == 2
    assert isinstance(ACTION_ALL_INCLUDES[0], string_types)
    assert isinstance(ACTION_ALL_INCLUDES[1], string_types)

# Generated at 2022-06-22 13:48:06.842047
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([], 'test message', '2.2')[0] == []

# Generated at 2022-06-22 13:48:13.565985
# Unit test for function set_constant
def test_set_constant():
    for name, value in config.data.get_settings():
        assert vars()[name] == value
        set_constant(name, value)
        assert vars()[name] == value



# Generated at 2022-06-22 13:49:15.964463
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = '2.8'
    value = ['1', '2']

    msg_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(msg_constant) == 2
    assert msg_constant[0] == '1'


# Generated at 2022-06-22 13:49:20.465561
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2, 3]
    msg = 'a message'
    version = 'a version'
    # initialization
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    # __len__
    assert(dsc.__len__() == len(value))


# Generated at 2022-06-22 13:49:29.073095
# Unit test for function set_constant
def test_set_constant():
    import os

    try:
        default_roles_path = ROLES_PATH
        set_constant('ROLES_PATH', '/path/to/ansible/roles')
        assert ROLES_PATH == '/path/to/ansible/roles', "constant update fail, got %s instead of %s" \
            % (ROLES_PATH, '/path/to/ansible/roles')

        set_constant('ROLES_PATH', default_roles_path)
        assert ROLES_PATH == default_roles_path, "constant update from default fail, got %s instead of %s" \
            % (ROLES_PATH, default_roles_path)
    except:
        set_constant('ROLES_PATH', default_roles_path)
        raise



# Generated at 2022-06-22 13:49:31.996986
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([], '', '2.0')
    assert len(x) == 0


# Generated at 2022-06-22 13:49:37.568202
# Unit test for function set_constant
def test_set_constant():
    # unit test for function set_constant
    # Even if these assertions fail, do not change them. The constants'
    # values in this file were made to match certain values in config.ini
    # to verify set_constant() worked properly.
    assert DEFAULT_BECOME_METHOD == 'sudo'
    assert DEFAULT_REMOTE_USER == 'root'
    assert HOST_KEY_CHECKING == True
    assert REMOTE_PORT == 22

# Generated at 2022-06-22 13:49:44.233412
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Dummy:
        def __getitem__(s, i):
            return s.__dict__[i]
        def __setitem__(s, i, v):
            s.__dict__[i] = v
        def keys(s):
            return s.__dict__.keys()
        def values(s):
            return s.__dict__.values()
    dummy = Dummy()
    dummy['test_value'] = 42

    for _value in range(0, 10):
        dm = _DeprecatedSequenceConstant(_value, 'deprecation message', '2.10')
        assert isinstance(dm, Sequence)
        assert len(dm) == _value
        assert dm[0] == _value
        if _value > 0:
            assert dm[-1] == (_value - 1)

# Generated at 2022-06-22 13:49:56.062598
# Unit test for function set_constant
def test_set_constant():
    import os
    import tempfile

    def _make_config(settings, path=None):
        '''Create a config file with specified settings'''
        if path is None:
            h, path = tempfile.mkstemp()
            os.close(h)
        else:
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(dirname)
        with open(path, 'w') as f:
            lines = []
            for key, value in settings.items():
                if isinstance(value, string_types):
                    lines.append('%s = "%s"\n' % (key, value))
                else:
                    lines.append('%s = %s\n' % (key, value))

            f.writelines(lines)
        return path

   

# Generated at 2022-06-22 13:49:58.228222
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='test')) == 3


# Generated at 2022-06-22 13:50:00.561348
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    # Verify that __len__ was called and returned 3
    assert(len(dsc) == 3)
    # Verify that __getitem__ was called and returned 1
    assert(dsc[0] == 1)

# Generated at 2022-06-22 13:50:03.273048
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = []
    msg = "TEST"
    version = "TEST"
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert obj.__getitem__(0) == value[0]
