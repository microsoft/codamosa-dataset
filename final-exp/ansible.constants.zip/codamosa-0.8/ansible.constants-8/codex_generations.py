

# Generated at 2022-06-22 13:40:41.709543
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc.__getitem__(1) == 'b'


# Generated at 2022-06-22 13:40:53.774243
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test template: ([init], [expected_return_len], [expected_return_getitem])
    tests = [
        ([[], '', 0], 0, []),
        ([[1, 2, 3], '', 0], 3, [1, 2, 3]),
        ([[1, 2, 3], '', 10], 3, [1, 2, 3])
    ]
    for test in tests:
        try:
            obj = _DeprecatedSequenceConstant(*test[0][0], msg=test[0][1], version=test[0][2])
        except Exception as e:  # TODO: should be more specific
            print("FAILED to create _DeprecatedSequenceConstant: %s" % str(e))
            return False

# Generated at 2022-06-22 13:41:06.921835
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # Initialize the _DeprecatedSequenceConstant object
    test_msg = "This is a test"
    test_version = '2.8'
    test_value = [1, 2, 3, 4]

    test_ds = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # Copy the private attr value of test_ds to another var
    test_attr_value = test_ds._value
    assert test_attr_value == test_value

    # Copy the private attr msg of test_ds to another var
    test_attr_msg = test_ds._msg
    assert test_attr_msg == test_msg

    # Copy the private attr version of test_ds to another var
    test_attr_version = test_ds._version
    assert test_attr_version == test_

# Generated at 2022-06-22 13:41:08.734701
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1)
    assert a == 1
    set_constant('b', 'c')
    assert b == 'c'

# Generated at 2022-06-22 13:41:14.633636
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(['bob', 'jim', 'alice'], 'this is a test...', '0.0.0')

    assert len(sequence) == 3
    assert sequence[1] == 'jim'
    assert repr(sequence) == repr(['bob', 'jim', 'alice'])

# Generated at 2022-06-22 13:41:22.509334
# Unit test for function set_constant
def test_set_constant():
    # Test positive case: setting the value in the constants
    set_constant('ANSIBLE_TEST_SET_CONSTANT_INTERNAL_VAR', '123')
    assert ANSIBLE_TEST_SET_CONSTANT_INTERNAL_VAR == '123'
    # Test negative case: updating the value in the constants
    set_constant('ANSIBLE_TEST_SET_CONSTANT_INTERNAL_VAR', '456')
    assert ANSIBLE_TEST_SET_CONSTANT_INTERNAL_VAR != '123'
    assert ANSIBLE_TEST_SET_CONSTANT_INTERNAL_VAR == '456'

# Generated at 2022-06-22 13:41:25.091124
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['first', 'second'], 'test msg', '4.0')
    assert seq[0] == 'first'

# Generated at 2022-06-22 13:41:32.239153
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class Test(object):
        def __init__(self, value, msg, version):
            self.value = value
            self.msg = msg
            self.version = version

    test = Test(value=[1, 2, 3], msg="This is a test", version="2.0")
    _DeprecatedSequenceConstant(test.value, test.msg, test.version)


# Generated at 2022-06-22 13:41:35.881808
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'Test', '2.0')
    assert len(a._value) == 3
    assert len(a) == 3


# Generated at 2022-06-22 13:41:42.200299
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')._value == ['a', 'b']
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')._msg == 'msg'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')._version == 'version'

# Generated at 2022-06-22 13:41:48.048339
# Unit test for function set_constant
def test_set_constant():
    global DEFAULT_HOST_LIST
    set_constant('DEFAULT_HOST_LIST', '/tmp')
    assert DEFAULT_HOST_LIST == '/tmp'

# Generated at 2022-06-22 13:41:52.848614
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = "test msg"
    test_version = "test version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_value) == len(test_obj)

# Generated at 2022-06-22 13:41:57.122147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep = _DeprecatedSequenceConstant(('a', 'c'), 'should be obsolete', '2.9')
    assert dep[0] == 'a' and dep[1] == 'c'
    assert len(dep) == 2

# Generated at 2022-06-22 13:42:00.061031
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(['a','b','c'], 'Test', '2.0')
    assert len(a) == 3

# Generated at 2022-06-22 13:42:04.828909
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    depr_seq = _DeprecatedSequenceConstant(value=None, msg=None, version=None)
    assert depr_seq.__class__.__name__ == '_DeprecatedSequenceConstant'
    assert hasattr(depr_seq, '_value')
    assert hasattr(depr_seq, '_msg')
    assert hasattr(depr_seq, '_version')

# Generated at 2022-06-22 13:42:10.148175
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "Test msg"
    version = "2.2"
    dsc = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    dsc.__getitem__(1)


# Generated at 2022-06-22 13:42:17.275548
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "The action plugin attribute 'run_once' is deprecated in favour of 'first_run_only'"
    version = "2.13"
    seq = _DeprecatedSequenceConstant([1, 2], msg, version)
    # test __len__ as used in ansible/module_utils/basic.py:877
    assert len(seq) == 2
    # test __getitem__ as used in ansible/module_utils/basic.py:915
    assert seq[0] == 1

# Generated at 2022-06-22 13:42:19.197632
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_ = [1, 2, 3]
    constant = _DeprecatedSequenceConstant(list_, 'msg', 'version')
    assert constant[0] == 1
    return

# Generated at 2022-06-22 13:42:22.102987
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['test'], 'test', '2.11')) == 1

# Generated at 2022-06-22 13:42:24.596385
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check that class _DeprecatedSequenceConstant is a subclass of Sequence
    assert issubclass(_DeprecatedSequenceConstant, Sequence)

# Generated at 2022-06-22 13:42:34.407379
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test if _DeprecatedSequenceConstant(value, msg, version) can get value by calling __getitem__ method
    # prepare data
    value = [1, 2, 3]
    msg = 'msg'
    version = 'version'
    # do test
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant.__getitem__(1) == value[1]



# Generated at 2022-06-22 13:42:46.856623
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from unittest import TestCase
    from StringIO import StringIO
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant

    # try to specify a message for a test of deprecated sequence constant
    class TestMessage(TestCase):
        def setUp(self):
            self.out = StringIO()
            # python2
            self.old_stdout = sys.stdout
            sys.stdout = self.out
            # python3
            self.old_stderr = sys.stderr
            sys.stderr = self.out

        # try to test if a message of deprecation is printed in case of
        # using a get method of deprecated sequence constant
        def test__DeprecatedSequenceConstant___getitem__(self):
            msg = 'This is a message'

# Generated at 2022-06-22 13:43:00.115972
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'constant value')
    assert ANSIBLE_TEST_CONSTANT == 'constant value'

# Mark certain options as deprecated and define deprecation versions

# Generated at 2022-06-22 13:43:06.678819
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.constants import _DeprecatedSequenceConstant
    assert _DeprecatedSequenceConstant([1, 2], "msg", "version")[0] == 1
    # NOTE: the next raise IndexError is needed because the underlying sequence [1,2] only has two elements
    try:
        _DeprecatedSequenceConstant([1, 2], "msg", "version")[9]
        assert False, "Should have raise IndexError"
    except IndexError:
        pass


# Generated at 2022-06-22 13:43:10.701963
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant(('hello', 'world'), "msg", "version")
    assert len(t) == 2


# Generated at 2022-06-22 13:43:18.363530
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    test_val = [1, 2, 3]

    # case 1
    dsc = _DeprecatedSequenceConstant(test_val, 'test_msg', '2.9')
    assert dsc[1] == 2

    # case 2
    dsc = _DeprecatedSequenceConstant(test_val, None, None)
    assert dsc[1] == 2


# Generated at 2022-06-22 13:43:20.168216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert constant[0] == 1


# Generated at 2022-06-22 13:43:21.681991
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], 'msg', '0.0.0') == []
    assert _DeprecatedSequenceConstant([1], 'msg', '0.0.0') == [1]

# Generated at 2022-06-22 13:43:27.870840
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "foobar", "1.1")
    assert dsc[0] == 1
    assert dsc[2] == 3
    assert len(dsc) == 3
    set_constant('FOO', dsc)
    import sys
    assert sys.stderr.write.called

# Generated at 2022-06-22 13:43:29.269945
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    cs = _DeprecatedSequenceConstant((1,2,3), 'This is a unit test', '2.10')
    assert cs[0] == 1


# Generated at 2022-06-22 13:43:35.138195
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([], "", "")
    assert len(d) == 0

    d = _DeprecatedSequenceConstant(['a', 'b'], "", "")
    assert len(d) == 2


# Generated at 2022-06-22 13:43:46.059047
# Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:43:48.765481
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant([1,2,3], 'a warning message', '2.9').__len__()


# Generated at 2022-06-22 13:43:58.065154
# Unit test for function set_constant
def test_set_constant():
    test = {}
    set_constant('test_setting', 'setting_value', test)
    assert test['test_setting'] == 'setting_value'


# LEGACY DEPRECATION WARNINGS ###

# Ansible 1.2
if DEFAULT_HASH_BEHAVIOUR == 'merge' and not config.data.get('hash_behaviour', 'replace').lower() in ['merge', 'replace']:
    _deprecated("DEFAULT_HASH_BEHAVIOUR is deprecated, use 'hash_behaviour' option instead", '2.9')

# Ansible 2.0

# Generated at 2022-06-22 13:44:03.877520
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(['a', 'b'], 'test_msg', 'test_version')
    assert len(c) == 2
    assert c[0] == 'a'
    assert c[1] == 'b'


# Generated at 2022-06-22 13:44:07.637682
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Setup
    constant = _DeprecatedSequenceConstant(
        value=['foo', 'bar'],
        msg="foo bar",
        version="0.0.1",
    )

    # Test
    len(constant)

# Generated at 2022-06-22 13:44:15.423940
# Unit test for function set_constant
def test_set_constant():
    # test function set_constant
    test_vars = {}
    set_constant('foo', 'bar', export=test_vars)
    assert test_vars['foo'] == 'bar'

    # test string template
    assert DEFAULT_BECOME_PASS == u'{{default_become_pass}}'
    assert DEFAULT_REMOTE_PASS == u'{{default_remote_pass}}'
    assert DEFAULT_SUBSET == u'{{default_subset}}'
    assert ANSIBLE_CONFIG == u'{{ansible_config}}'

    # test list template
    assert isinstance(JINJA2_EXTENSIONS, (list, tuple))



# Generated at 2022-06-22 13:44:22.133315
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = []
    for i in range(4):
        test_value.append("test_value" + str(i))

    test_msg = "test_msg"
    test_version = "test_version"

    d0 = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert d0.__len__() == 4
    assert d0.__getitem__(1) == "test_value1"

    d1 = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    d1[0] = "new_value"
    assert d1[0] == "new_value"
    assert len(d1) == 4

    test_value2 = [1, 2, 3, 4]
    d2 = _DeprecatedSequence

# Generated at 2022-06-22 13:44:30.454603
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test case when value is a list
    value = [u'something']
    msg = u'test message'
    version = u'test version'
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) == len(obj)

    # Test case when value is a tuple
    value = tuple([u'something'])
    msg = u'test message'
    version = u'test version'
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) == len(obj)

# Generated at 2022-06-22 13:44:32.120784
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([42,], msg='test', version='1.0')
    assert len(s) == 1

# Generated at 2022-06-22 13:44:42.133540
# Unit test for function set_constant
def test_set_constant():
    value = 'test'
    set_constant('test_constant', value)
    try:
        assert test_constant == value
    except NameError:
        raise AssertionError("The global variable 'test_constant' does not have the correct value (" + str(value) + ")")


# Generated at 2022-06-22 13:44:48.126456
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert test_object[0] == 'a'
    assert test_object[1] == 'b'
    assert test_object[2] == 'c'
    assert test_object[-1] == 'c'
    assert test_object[-2] == 'b'
    assert test_object[-3] == 'a'
    assert len(test_object) == 3

    try:
        assert test_object[3]
        assert False
    except IndexError:
        assert True

    try:
        assert test_object[-4]
        assert False
    except IndexError:
        assert True


# Generated at 2022-06-22 13:44:51.992504
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = ['c', 'b', 'd']
    dsc = _DeprecatedSequenceConstant(seq, 'test', '2.10')
    assert len(seq) == len(dsc)
    assert len(seq) == 3


# Generated at 2022-06-22 13:44:55.204038
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant([1, 2, 3], "This is a test message", "0.0.1")
    assert len(deprecated) == 3
    assert deprecated[2] == 3


# Generated at 2022-06-22 13:45:01.216589
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1,2,3]
    msg = "test"
    version = "2.0"
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)


# Generated at 2022-06-22 13:45:12.997960
# Unit test for function set_constant
def test_set_constant():
    ensure_type('ANSIBLE_CONFIG_MODULE', string_types)


# generate the list of systems with a problem with default pipelining
PIPELINE_VULNERABLE_SYSTEMS = ()
try:
    # this is older, may still work, but is not safe
    PIPELINE_VULNERABLE_SYSTEMS += ('apt',)
    # this one is known to be vulnerable
    PIPELINE_VULNERABLE_SYSTEMS += ('dnf',)
except Exception:
    pass

# When enabled, this option allows you to use `&&` and `||` to
# compose shell commands, see this example:
COMMAND_STACK_TEMPLATE = config.get_config_value('command_stack_template', default='{{ cmd_1 }}; {{ cmd_2 }}')



# Generated at 2022-06-22 13:45:17.606794
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    global _ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    assert(_ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS[0] == 'include_tasks')


# Generated at 2022-06-22 13:45:28.646832
# Unit test for function set_constant
def test_set_constant():
    ''' set_constant is called by ConfigManager so this test is here '''
    config = {'test': {'test_setting': 'test_value'}}
    new_dict = {}
    set_constant('test', config, new_dict)
    assert new_dict['test']['test_setting'] == 'test_value'

# for backwards compat only
DEFAULT_ROLES_PATH = tuple(DEFAULT_ROLES_PATH)
DEFAULT_MODULE_PATH = tuple(DEFAULT_MODULE_PATH)
DEFAULT_MAX_FAIL_PERCENTAGE = int(DEFAULT_MAX_FAIL_PERCENTAGE)
DEFAULT_SYSLOG_FACILITY = str(DEFAULT_SYSLOG_FACILITY)
ANSIBLE_CONFIG = str(ANSIBLE_CONFIG)


# Generated at 2022-06-22 13:45:33.532934
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq = _DeprecatedSequenceConstant((1, 2), 'test_msg', 'version')
    assert dep_seq[0] == 1
    assert dep_seq[1] == 2

# Generated at 2022-06-22 13:45:37.398825
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dummy_list = ['dummy', 'list']
    _DeprecatedSequenceConstant(dummy_list, 'message', '2.9')
    assert len(_DeprecatedSequenceConstant(dummy_list, 'message', '2.9')) == len(dummy_list)

# Generated at 2022-06-22 13:45:47.409887
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'ver')
    assert value[-1] == 'b'
    assert value[0] == 'a'


# Generated at 2022-06-22 13:45:56.642429
# Unit test for function set_constant
def test_set_constant():

    min_size = 8

    def check_value(name, val, type):
        assert isinstance(val, type), '{0} should be {1}, is {2}'.format(name, type, type(val))
        assert len(name) > min_size, '{0} should be longer than {1}'.format(name, min_size)

    constants = vars()
    for name, val in config.data.get_settings():
        if name in constants and not isinstance(val, unicode):
            check_value(name, val, type(constants[name]))

    assert BOOLEANS_TRUE == BOOL_TRUE
    assert BOOLEANS_TRUE is BOOL_TRUE


# Generated at 2022-06-22 13:45:59.951049
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1,2,3], msg='test', version='1.0')
    assert constant[0] == 1


# Generated at 2022-06-22 13:46:05.262063
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert 'b' == _DeprecatedSequenceConstant(('a', 'b', 'c'), 'warn', '4.0')[1]
    assert 'b' == _DeprecatedSequenceConstant(('a', 'b', 'c'), 'warn', '4.0')[-2]


# Generated at 2022-06-22 13:46:06.760085
# Unit test for function set_constant
def test_set_constant():
    assert len(DOCUMENTABLE_PLUGINS) == 15

# Generated at 2022-06-22 13:46:09.371050
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class_instance = _DeprecatedSequenceConstant(
        value=[1],
        msg='This message is for warning',
        version='2.8'
    )
    assert class_instance[0] == 1

# Generated at 2022-06-22 13:46:13.933766
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'A warning'
    version = '2.8.0'
    value = 'value'
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    assert dsc.__len__() == 1


# Generated at 2022-06-22 13:46:25.085969
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # testing item access via index works
    v = _DeprecatedSequenceConstant(value=(1, 2, 3), msg="msg", version="version")

    assert v[0] == 1
    assert v[1] == 2
    assert v[2] == 3
    # testing for negative index
    assert v[-1] == 3
    assert v[-2] == 2
    assert v[-3] == 1

    # testing item access via slice works

    # testing for positive index
    assert v[1:2] == [2]
    assert v[1:3] == [2, 3]
    assert v[1:-1] == [2]
    assert v[1:-2] == []
    assert v[1:] == [2, 3]
    assert v[:2] == [1, 2]
    assert v

# Generated at 2022-06-22 13:46:27.811392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    actual = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')[1]
    assert actual == 2

# Generated at 2022-06-22 13:46:34.581180
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_constant = _DeprecatedSequenceConstant([1, 2, 3], "test constant", "2.1")
    len_test_constant = len_test_constant = len(test_constant)
    assert len_test_constant == 3
    assert test_constant[0] == 1
    assert test_constant[1] == 2
    assert test_constant[2] == 3

# Generated at 2022-06-22 13:46:57.128280
# Unit test for function set_constant
def test_set_constant():
    ''' verify that set_constant sets variables as expected '''

    test_dict = {}
    # Set a value and verify it is set
    set_constant('ANSIBLE_TEST', 'foo', export=test_dict)
    assert test_dict['ANSIBLE_TEST'] == 'foo'

    # Set a second value and verify both values are present
    set_constant('ANSIBLE_TEST2', 'bar', export=test_dict)
    assert test_dict['ANSIBLE_TEST'] == 'foo'
    assert test_dict['ANSIBLE_TEST2'] == 'bar'

# Generated at 2022-06-22 13:47:02.077094
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['a','b']
    msg = 'unit test'
    version = '1.2.3'
    deprecated = _DeprecatedSequenceConstant(value, msg, version)
    if len(deprecated) != len(value):
        raise AssertionError("len of _DeprecatedSequenceConstant is not equal to len of value")

# Generated at 2022-06-22 13:47:03.572500
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('foo', 'bar') == {}

# Generated at 2022-06-22 13:47:09.316688
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'test msg'
    version = 'test version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 13:47:13.728247
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(['a', 'b'], 'message', '2.0')
    assert repr(a) == repr(['a', 'b'])
    assert a[0] == 'a'
    assert len(a) == 2

# Generated at 2022-06-22 13:47:16.975057
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(test_object) == 3


# Generated at 2022-06-22 13:47:26.081359
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test get a tuple directly
    value = (1, 2)
    msg = "This is a test message."
    version = "2.12"
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert(seq[0] == 1)
    assert(seq[1] == 2)

    # Test convert a list to tuple
    value = [1, 2]
    msg = "This is a test message."
    version = "2.12"
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert(seq[0] == 1)
    assert(seq[1] == 2)


# Generated at 2022-06-22 13:47:34.603750
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', (1, 0)) == [1, 2, 3]
    # Test len method
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', (1, 0))) == 3
    # Test getitem method
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', (1, 0))[0] == 1


# FIXME: we need to drop this internally, but have to maintain it for external plugins

# Generated at 2022-06-22 13:47:40.072923
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This constant is deprecated, to be removed in Ansible 2.0'
    seq = _DeprecatedSequenceConstant(tuple(range(10)), msg, '2.0')
    assert isinstance(seq, Sequence)
    assert len(seq) == 10
    assert seq[0] == 0



# Generated at 2022-06-22 13:47:42.834631
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')) == 3


# Generated at 2022-06-22 13:48:16.917169
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3

# Generated at 2022-06-22 13:48:19.601471
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=['test1'], msg='test', version='test')
    assert dsc.__getitem__(0) == 'test1'

# Generated at 2022-06-22 13:48:22.367396
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(['a','b','c'], 'msg', 'ver')
    assert len(a) == 3


# Generated at 2022-06-22 13:48:28.305301
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest

    # accepts Sequence instance
    seq = _DeprecatedSequenceConstant(value='to be deprecated', msg='Test message', version='2.9')
    assert seq[0] == 't'

    # raises exception TypeError on invalid parameter
    with pytest.raises(TypeError):
        seq[0:1]

# Generated at 2022-06-22 13:48:32.292473
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1,2,3], "test", "1.0")
    assert len(dsc) == 3
test__DeprecatedSequenceConstant___len__()


# Generated at 2022-06-22 13:48:34.787024
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1,2,3], 'This is a test', '2.10')
    assert len(s) == 3


# Generated at 2022-06-22 13:48:46.572590
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.0'

    list_of_numbers = [1, 2, 3]
    test_obj_list_of_numbers = _DeprecatedSequenceConstant(value=list_of_numbers, msg=msg, version=version)

    # Test if test_obj_list_of_numbers is a class object of type _DeprecatedSequenceConstant
    assert isinstance(test_obj_list_of_numbers, _DeprecatedSequenceConstant)

    # Test if test_obj_list_of_numbers has length of the value passed to it
    assert len(test_obj_list_of_numbers) == len(list_of_numbers)

    # Test if test_obj_list_of_numbers has the same value at a particular index than the

# Generated at 2022-06-22 13:48:51.156674
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test case 1, Call method with valid inputs
    _test_obj = _DeprecatedSequenceConstant([1, 2], 'hello', '1.1')
    expected_result = 1
    actual_result = _test_obj[0]
    assert expected_result == actual_result


# Generated at 2022-06-22 13:48:53.468729
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    o = _DeprecatedSequenceConstant([1, 2, 3], None, None)
    assert o[1] == 2

# Generated at 2022-06-22 13:48:59.061014
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "this is a test message"
    test_list = [1,2,3,4]
    version = "4.4"
    test = _DeprecatedSequenceConstant(test_list, msg, version)
    assert len(test) == 4
    assert test[2] == 3

# Generated at 2022-06-22 13:49:58.304901
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant((1, 2, 3), "foo", version="2.0")
    assert isinstance(a, Sequence)
    assert len(a) == 3
    assert a[0] == 1



# Generated at 2022-06-22 13:50:00.908040
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result = _DeprecatedSequenceConstant((1, 2), 'Test Message', '1.0')
    assert result._value == (1, 2)
    assert result._msg == 'Test Message'
    assert result._version == '1.0'
    assert result.__getitem__(1) == 2
    assert result.__len__() == 2



# Generated at 2022-06-22 13:50:07.530917
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'TEST_CONSTANT')
    assert 'TEST_CONSTANT' in globals()


# FIXME: this will be removed in 2.12
EXPAND_OFFLINE_VARIABLES = config.get_config_value('EXPAND_OFFLINE_VARIABLES')
if EXPAND_OFFLINE_VARIABLES is None:
    # FIXME: do not use defaults like this
    EXPAND_OFFLINE_VARIABLES = True

if 'EXPAND_OFFLINE_VARIABLES' in config.data:
    _deprecated(config.data['EXPAND_OFFLINE_VARIABLES'].__deprecated__, '2.12')


# Generated at 2022-06-22 13:50:10.562885
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3


# Generated at 2022-06-22 13:50:12.685289
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'bar')[1] == 2


# Generated at 2022-06-22 13:50:16.090336
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is False
    assert ANSIBLE_CACHE_PLUGIN == 'memory'


# Deprecate settings that have moved, but let them be used until they are removed

# Generated at 2022-06-22 13:50:18.952838
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(range(4), "test", "2.4")) == 4


# Generated at 2022-06-22 13:50:20.790082
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant(("A", "B"), "msg", "version")[0]


# Generated at 2022-06-22 13:50:25.761782
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestClass:
        test_var = _DeprecatedSequenceConstant((1, 2), 'Test message', '0.0')

        def __len__(self):
            return len(self.test_var)

        def __getitem__(self, y):
            return self.test_var[y]

    t = TestClass()
    assert t[0] == 1
    assert t[1] == 2
    assert len(t) == 2



# Generated at 2022-06-22 13:50:31.034241
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "test message"
    version = "test verion"
    value = [1,2,3]
    t = _DeprecatedSequenceConstant(value, msg, version)
    t.__len__()
    t.__getitem__(1)
