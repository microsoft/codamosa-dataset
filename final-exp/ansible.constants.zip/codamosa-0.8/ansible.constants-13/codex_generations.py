

# Generated at 2022-06-22 13:40:47.422573
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is warning message."
    version = "2.14"
    test_value = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert len(test_value) == 3
    assert test_value[0] == 1

# Generated at 2022-06-22 13:40:49.787302
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.10')
    assert len(obj) == 3
    assert obj[1] == 2

# Generated at 2022-06-22 13:40:56.710607
# Unit test for function set_constant
def test_set_constant():
    _test_dict = {}
    _test_value = "test_value"
    set_constant('TEST_DATA', _test_value, _test_dict)
    assert _test_dict['TEST_DATA'] == _test_value

MAGIC_VARIABLE_MAPPING = _DeprecatedSequenceConstant(
    MAGIC_VARIABLE_MAPPING,
    msg='The MAGIC_VARIABLE_MAPPING constant is deprecated and will be removed from Ansible in version 2.11',
    version='2.11'
)

# Generated at 2022-06-22 13:41:07.592345
# Unit test for function set_constant
def test_set_constant():
    import copy
    from ansible.config.manager import ConfigManager
    from ansible.utils import context_objects as co

    # set up the config
    config = ConfigManager()
    global_vars = copy.deepcopy(vars())

    # set the constants
    for setting in config.data.get_settings():
        set_constant(setting.name, setting.value)

    # create the context
    context = co.CLIContext()
    context.CLIARGS = {}

    # compare run context to global vars
    compare_context_to_global = True
    for key, value in vars().items():
        if key == 'global_vars':
            continue
        if key in global_vars and value != global_vars[key]:
            compare_context_to_global = False
            break



# Generated at 2022-06-22 13:41:15.076048
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import logging
    class _LoggingHandler(logging.Handler):
        def __init__(self, *args, **kwargs):
            super(_LoggingHandler, self).__init__(*args, **kwargs)
            self.messages = []

        def emit(self, record):
            self.messages.append(record.msg)

    logging.basicConfig(level='DEBUG')
    logger = logging.getLogger('TEST')
    handler = _LoggingHandler()
    handler.setLevel('DEBUG')
    logger.addHandler(handler)
    dsc = _DeprecatedSequenceConstant([1,2], 'msg', '2.2')
    assert len(dsc) == 2
    assert dsc[1] == 2
    assert 'msg' in handler.messages[0]

# Generated at 2022-06-22 13:41:20.929601
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['foo', 'bar']
    test_msg = 'This is a test'
    test_version = '1.0'
    test_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_constant) == len(test_value)
    assert test_constant[0] == test_value[0]
    assert test_constant[1] == test_value[1]

# Generated at 2022-06-22 13:41:25.043215
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_PERSISTENT_CONNECT_RETRY_TIME', 600, export=vars())
    assert vars()['ANSIBLE_PERSISTENT_CONNECT_RETRY_TIME'] == 600

# Generated at 2022-06-22 13:41:36.143740
# Unit test for function set_constant
def test_set_constant():
    config1 = ConfigManager()
    for warn in config1.WARNINGS:
        _warning(warn)
    assert config1.data.DEFAULT_HOST_LIST == config.data.DEFAULT_HOST_LIST

# Set this to true to allow build-time optimizations to work
BUILTIN_CONSTANTS = True

set_constant('DOCUMENTABLE_PLUGINS', DOCUMENTABLE_PLUGINS, export=globals())
set_constant('CONFIGURABLE_PLUGINS', CONFIGURABLE_PLUGINS, export=globals())
set_constant('IGNORE_FILES', IGNORE_FILES, export=globals())

# Generated at 2022-06-22 13:41:45.377543
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Create object to test
    sample_msg = "sample msg"
    sample_version = "sample version"
    value = [1,2,3,4,5]
    obj = _DeprecatedSequenceConstant(value, sample_msg, sample_version)

    # Test object
    assert obj[0] == value[0]
    assert obj[1] == value[1]
    assert obj[2] == value[2]
    assert obj[3] == value[3]
    assert obj[4] == value[4]


# Generated at 2022-06-22 13:41:47.688192
# Unit test for function set_constant
def test_set_constant():
    data = {}
    set_constant('FOO', 'BAR', export=data)
    assert data['FOO'] == 'BAR'
    data = {}
    set_constant('FOO', ['1', '2', '3'], export=data)
    assert data['FOO'] == ['1', '2', '3']

# Generated at 2022-06-22 13:42:01.326140
# Unit test for function set_constant
def test_set_constant():
    # Test that the resulting dict is a subset of the current globals
    new_constants = set(vars()) - set(globals())

    for constant in new_constants:
        assert constant in globals(), "Error in test, trying to set_constant a constant that was not previously defined"
        assert type(globals()[constant]) is type(vars()[constant]), "Error in test, trying to set_constant a constant that was a different type"

test_set_constant()

# Generated at 2022-06-22 13:42:03.300495
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
   assert _DeprecatedSequenceConstant(['unit'], 'msg', 'version').__len__() == 1


# Generated at 2022-06-22 13:42:15.834740
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Mock_display():
        def __init__(self):
            self.value = 'warning'
            self.version = '2.13'

        def deprecated(self, msg, version):
            assert self.value == 'warning'
            assert self.version == '2.13'

    v1 = _DeprecatedSequenceConstant('warning', '2.13')
    try:
        from ansible.utils.display import Display
        d = Display()
        d.deprecated = Mock_display
        v1['warning']
    except Exception:
        import sys
        sys.stderr.write(' [WARNING] %s, to be removed in %s\n' % ('warning', '2.13'))


# Generated at 2022-06-22 13:42:19.733102
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(('a', 'b'), 'this is a deprecated message', '0.0.1')
    assert constant[0] == 'a'
    assert constant[1] == 'b'
    assert len(constant) == 2

# Generated at 2022-06-22 13:42:28.108183
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # define the message and the version that the user will be warned about
    message = 'The first test string'
    version = '1.1'

    # define the sequence to be used
    sequence = ['hello', 'world', '!']

    # define the deprecated constant
    testSequence = _DeprecatedSequenceConstant(sequence, message, version)

    assert testSequence[0] == 'hello'
    assert testSequence[1] == 'world'
    assert testSequence[2] == '!'


# Generated at 2022-06-22 13:42:40.729542
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test tuple
    msg = 'test tuple'
    dep_value = _DeprecatedSequenceConstant((1,2), msg, '2.0')
    assert len(dep_value) == 2
    assert dep_value[0] == 1

    # test list
    msg = 'test list'
    dep_value = _DeprecatedSequenceConstant([1,2], msg, '2.0')
    assert len(dep_value) == 2
    assert dep_value[0] == 1

    # test set
    msg = 'test set'
    dep_value = _DeprecatedSequenceConstant({1,2}, msg, '2.0')
    assert len(dep_value) == 2
    assert dep_value[0] == 1

    # test frozenset
    msg = 'test frozenset'
    dep

# Generated at 2022-06-22 13:42:47.335251
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant('example', 'Message', '1.3')
    assert len(obj) == 7
    assert obj[0] == 'e'
    assert obj[1] == 'x'
    assert obj[2] == 'a'
    assert obj[3] == 'm'
    assert obj[4] == 'p'
    assert obj[5] == 'l'
    assert obj[6] == 'e'

# Generated at 2022-06-22 13:42:49.917995
# Unit test for function set_constant
def test_set_constant():
    new_settings = {}
    set_constant('TEST', 1, new_settings)
    assert new_settings['TEST'] == 1

# Generated at 2022-06-22 13:42:58.975691
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Setup
    test_value = [1, 2, 3]
    test_msg = 'Testing Message'
    test_version = '1.2.3'

    # Action
    test_sequence = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # Verify
    assert len(test_sequence) == len(test_value)
    for n in range(len(test_value)):
        assert test_sequence[n] == test_value[n]

# Generated at 2022-06-22 13:43:01.306655
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'this is an example', '0.1')
    assert len(a) == 3

# Generated at 2022-06-22 13:43:14.542514
# Unit test for function set_constant
def test_set_constant():
    old_value = ANSIBLE_NOCOWS
    new_value = not ANSIBLE_NOCOWS
    set_constant('ANSIBLE_NOCOWS', new_value)
    assert ANSIBLE_NOCOWS == new_value
    set_constant('ANSIBLE_NOCOWS', old_value)
    assert ANSIBLE_NOCOWS == old_value

# Generated at 2022-06-22 13:43:25.095687
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    old_version = 'if you wanted to use it for your own purposes, you probably need to write your own plugin.'
    deprecated_items = ('deprecated_item_1', 'deprecated_item_2', 'deprecated_item_3')
    value_tuple = ('new_item_1', 'new_item_2', 'new_item_3')
    deprecated_msg = 'Using deprecated item %s, to be removed in 2.13. ' + old_version
    value = _DeprecatedSequenceConstant(value_tuple, deprecated_msg, '2.13')
    # Check the len function deprecated
    deprecated_len = len(value)
    assert len(value_tuple) == deprecated_len
    # Check the len function deprecated
    deprecated_item = value[0]
    assert value_tuple[0] == deprecated_

# Generated at 2022-06-22 13:43:35.883393
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    Assert that:
    * _DeprecatedSequenceConstant can be instantiated.
    * _DeprecatedSequenceConstant can be called with a sequence and a string.
    * _DeprecatedSequenceConstant can be called with a sequence and a string to get the length of the sequence.
    """

    # Test that _DeprecatedSequenceConstant can be instantiated.
    test_deprecated_constant = _DeprecatedSequenceConstant(value=[1], msg="Test Deprecated constant", version="Test")

    # Test that _DeprecatedSequenceConstant can be called with a sequence and a string.
    length = len(test_deprecated_constant)

    # Test that _DeprecatedSequenceConstant can be called with a sequence and a string to get the length of the sequence.
    assert length == 1

# Generated at 2022-06-22 13:43:39.337016
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(u'a', 'b', {u'a': 'c'}) == {u'a': 'c'}

# Generated at 2022-06-22 13:43:45.972599
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """Test _DeprecatedSequenceConstant"""
    test_obj = _DeprecatedSequenceConstant('foo', 'bar', 'baz')
    assert isinstance(test_obj, _DeprecatedSequenceConstant)
    assert test_obj._value == 'foo'
    assert test_obj._msg == 'bar'
    assert test_obj._version == 'baz'
    assert test_obj[0] == 'f'
    assert len(test_obj) == 3
    _deprecated('bar', 'baz')

# Generated at 2022-06-22 13:43:56.385039
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    class NewList(list):
        pass

    a = NewList()

    # basic test for _DeprecatedSequenceConstant.__init__():
    test_obj = _DeprecatedSequenceConstant(a, 'test', '2.0')
    assert test_obj._value == a
    assert test_obj._msg == 'test'
    assert test_obj._version == '2.0'

    # test for "len" support:
    assert len(test_obj) == 0

    # test for "getitem" support:
    assert test_obj[0] is None

    # test for displaying deprecation msg
    assert _warning.called
    assert _warning.call_args == (('[DEPRECATED] test, to be removed in 2.0', ),)

# Generated at 2022-06-22 13:44:08.610682
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(bin_ansible_callbacks, list)
    assert isinstance(bin_ansible_connection, string_types)
    assert isinstance(bin_ansible_inventory, string_types)
    assert isinstance(bin_ansible_playbook, string_types)
    assert isinstance(bin_ansible_pull, string_types)
    assert isinstance(bin_ansible_vault, string_types)
    assert isinstance(bin_ansible, string_types)
    assert isinstance(bin_ansible_doc, string_types)
    assert isinstance(bin_ansible_galaxy, string_types)
    assert isinstance(bin_ansible_test, string_types)
    assert isinstance(bin_ansible_console, string_types)

# Generated at 2022-06-22 13:44:16.865155
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value1 = [1, 2, 3, 4]
    test_value2 = {'a':12, 'b':34, 'c':56}
    test_value3 = (7, 8, 9, 10)

    assert _DeprecatedSequenceConstant(test_value1, 'test msg', '1.0').__len__() == len(test_value1)
    assert _DeprecatedSequenceConstant(test_value2, 'test msg', '1.0').__len__() == len(test_value2)
    assert _DeprecatedSequenceConstant(test_value3, 'test msg', '1.0').__len__() == len(test_value3)


# Generated at 2022-06-22 13:44:23.526856
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['one', 'two', 'three']
    test_msg = 'this is a test warning message'
    test_version = '2.1'
    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_instance) == 3
    assert test_instance[1] == 'two'

# Generated at 2022-06-22 13:44:27.244309
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(["foo", "bar"], 'msg', 'version')
    assert obj[0] == 'foo'
    assert obj[1] == 'bar'


# Generated at 2022-06-22 13:44:43.508144
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant([1,2,3], "", "")
    if t[0] != 1:
        raise AssertionError("test_DeprecatedSequenceConstant_getitem failed")
    if t[1] != 2:
        raise AssertionError("test_DeprecatedSequenceConstant_getitem failed")
    if t[2] != 3:
        raise AssertionError("test_DeprecatedSequenceConstant_getitem failed")
    try:
        if t[3] == 4:
            raise AssertionError("test_DeprecatedSequenceConstant_getitem failed")
    except IndexError:
        pass


# Generated at 2022-06-22 13:44:51.254384
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert hasattr(test, '_value')
    assert hasattr(test, '_msg')
    assert hasattr(test, '_version')
    assert len(test) == 0
    assert test[:] == []
    assert test[0:] == []
    assert test[:0] == []
    assert test[-1:] == []


# Generated at 2022-06-22 13:44:52.923474
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    v = _DeprecatedSequenceConstant([1,2], 'foo', '3.0')
    assert v.__len__() == 2
    assert v.__getitem__(1) == 2

# Generated at 2022-06-22 13:45:06.287835
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():  # pylint: disable=too-many-return-statements
    """ Test that __getitem__ of class _DeprecatedSequenceConstant works """
    import sys
    from ansible.utils.display import Display

    class MockDisplay(Display):
        ''' Used to override Display._display function to store the message in self._deprecated class attribute '''
        def __init__(self):
            super(MockDisplay, self).__init__()
            self._deprecated = []

        def deprecated(self, msg, version=None, removed=False):
            self._deprecated.append(msg)

    # Prepare mock
    mock_display = MockDisplay()
    sys.modules['ansible.utils.display'] = mock_display

    # Mock test 1
    mock_value1 = "Mock value"

# Generated at 2022-06-22 13:45:13.148778
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for vtype in (list, tuple):
        for msg in ('foo', 'bar'):
            for version in ('1.0', '2.0'):
                for value in (vtype(), vtype([0]), vtype([0, 1, 2])):
                    dsc = _DeprecatedSequenceConstant(value, msg, version)
                    assert len(value) == len(dsc)

test__DeprecatedSequenceConstant___len__()



# Generated at 2022-06-22 13:45:25.779700
# Unit test for function set_constant
def test_set_constant():
    # Reset
    vars()['TEST_CONSTANT'] = None

    # Set
    set_constant('TEST_CONSTANT', 'foobar')
    assert vars()['TEST_CONSTANT'] == 'foobar'

    # Override
    set_constant('TEST_CONSTANT', 'barfoo')
    assert vars()['TEST_CONSTANT'] == 'barfoo'


# Backward compatibility
set_constant('DEFAULT_TRANSPORT', config.data['DEFAULT_TRANSPORT'])
set_constant('DEFAULT_TRANSPORT_HAS_PER_HOST_OVERRIDE', config.data['DEFAULT_TRANSPORT_HAS_PER_HOST_OVERRIDE'])

# Generated at 2022-06-22 13:45:31.013444
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    old_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        x = _DeprecatedSequenceConstant((1, 2, 3), msg='Test', version='X.Y')
        assert x[1] == 2
        sys.stderr.seek(0)
        assert sys.stderr.read() == ' [DEPRECATED] Test, to be removed in X.Y\n'
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-22 13:45:43.401340
# Unit test for function set_constant
def test_set_constant():

    assert isinstance(CACHED_TREE_DIR, string_types)

    # assert isinstance(C, bool)
    # assert isinstance(DEBUG, bool)
    # assert isinstance(DEFAULT_ASK_SUDO_PASS, bool)
    # assert isinstance(DEFAULT_BECOME_ASK_PASS, bool)
    # assert isinstance(DEFAULT_KEEP_REMOTE_FILES, bool)
    # assert isinstance(DEFAULT_SUDO, bool)
    # assert isinstance(DEFAULT_SUDO_EXE, bool)
    # assert isinstance(DEFAULT_SUDO_FLAGS, bool)
    # assert isinstance(DEFAULT_SUBSET, bool)
    # assert isinstance(DISPLAY_SKIPPED_HOSTS, bool)
    # assert isinstance

# Generated at 2022-06-22 13:45:47.743625
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    const = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert const[0] == 'a'
    assert const[2] == 'c'



# Generated at 2022-06-22 13:45:52.055450
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "Use 'include_role' instead of deprecated 'import_role' for %s"
    c = _DeprecatedSequenceConstant((), msg, '2.14')
    assert len(c) == 0
    _deprecated.called = False
    assert not _deprecated.called


# Generated at 2022-06-22 13:46:08.290845
# Unit test for function set_constant
def test_set_constant():
    constants = vars()
    assert constants['HOST_KEY_CHECKING'] is True
    assert constants['COW_SELECTION'] == "beavis.zen"

# Generated at 2022-06-22 13:46:21.003940
# Unit test for function set_constant
def test_set_constant():
    """Global defaults can be re-written by CLI options, which are in turn overridden by all other means."""
    # this is a bit hacky and brittle, but if one of the defaults constants changes, we need to
    # be able to unit test that set_constant works correctly.
    test_constants = {
        'DEFAULT_ASK_PASS': (None, 'a string', 'a string'),
        'DEFAULT_BECOME_ASK_PASS': (False, True, False),
        'DEFAULT_KEEP_REMOTE_FILES': (False, 'false', True),
        'DEFAULT_REMOTE_TMP': ('$HOME/.ansible/tmp', '/path/to/files', '/path/to/files'),
    }

    # loop through all defaults and test that we can override them inside of a dict

# Generated at 2022-06-22 13:46:24.631783
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'this is a test message'
    version = '2.9'
    values = [1,2,3]
    deprecated_object = _DeprecatedSequenceConstant(values, msg, version)
    assert(len(deprecated_object) == len(values))


# Generated at 2022-06-22 13:46:31.872744
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    original = [192, '0', '0', '1', '80']
    wrong = [192, '0', '-1', '1', '80']
    msg = "test_config._DeprecatedSequenceConstant()"
    version = "1.0"

    test = _DeprecatedSequenceConstant(original, msg, version)
    assert test == original

    test = _DeprecatedSequenceConstant(wrong, msg, version)
    assert test == wrong

# Generated at 2022-06-22 13:46:35.759133
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_const = _DeprecatedSequenceConstant(('foo', 'bar'), 'test msg', '2.10')
    assert len(seq_const) == 2


# Generated at 2022-06-22 13:46:47.843968
# Unit test for function set_constant
def test_set_constant():
    test_set = set()
    test_set.add('ANSIBLE_CONFIG')
    # ANSIBLE_CONFIG is set as a module constant
    assert config.config_file == config.get_config_value(config.config_file)
    assert config.module_name in ['command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                                  'ansible.windows.win_shell', 'raw']
    assert isinstance(MAGIC_VARIABLE_MAPPING, dict)
    assert MAGIC_VARIABLE_MAPPING['connection'] == ('ansible_ssh_host', 'ansible_host') and \
           MAGIC_VARIABLE_MAPPING['network_os'] == ('ansible_network_os', )

# Generated at 2022-06-22 13:46:51.321151
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_seqcon = _DeprecatedSequenceConstant([], "message", "version")
    assert test_seqcon._value == []
    assert test_seqcon._msg == "message"
    assert test_seqcon._version == "version"

# Generated at 2022-06-22 13:46:56.758833
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('TEST_A', 'a') == {'TEST_A': 'a'}
    assert set_constant('TEST_B', 'b') == {'TEST_A': 'a', 'TEST_B': 'b'}

# Generated at 2022-06-22 13:46:58.716608
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 13:47:11.642196
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "This is a test."
    test_version = "1.0"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version


# Generated at 2022-06-22 13:47:43.837531
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(list(range(8)), 'msg', 'v1.0')
    assert len(obj) == 8


# Generated at 2022-06-22 13:47:45.593350
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2


# Generated at 2022-06-22 13:47:49.212938
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c', 'd'], 'test', '1.0')
    assert dsc[0] == 'a'
    assert len(dsc) == 4

# Generated at 2022-06-22 13:47:52.139107
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    cmptest = _DeprecatedSequenceConstant(value='test_value', msg='test_msg', version='test_version')
    assert isinstance(cmptest.__len__(), int)


# Generated at 2022-06-22 13:47:55.786038
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(
        _ACTION_ALL_INCLUDE_TASKS,
        'This is deprecated',
        version='2.8'
    ) == _ACTION_ALL_INCLUDE_TASKS

# Generated at 2022-06-22 13:47:59.743566
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.cfg import constant
    seq = _DeprecatedSequenceConstant(constant.VALID_ACTIONS, 'my message', 'my version')
    assert len(seq) == len(constant.VALID_ACTIONS)
    assert seq[0] == constant.VALID_ACTIONS[0]
    assert seq[1] == constant.VALID_ACTIONS[1]

# Generated at 2022-06-22 13:48:10.891617
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class FakeDisplay(object):
        def deprecated(self, msg, version=''):
            print('deprecated: %s' % msg)

    class FakeDisplayImport(object):
        def __getattr__(self, name):
            return FakeDisplay()

    class FakeSys:
        stderr = FakeDisplayImport()

    def _deprecated(msg, version):
        print(msg)

    value = [1, 2, 3]
    msg = 'This is msg'
    version = '2.8'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    deprecated_sequence_constant.__len__()
    deprecated_sequence_constant.__getitem__(0)
    assert deprecated_sequence_constant[0] == value[0]



# Generated at 2022-06-22 13:48:19.428086
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    arg = _DeprecatedSequenceConstant(value='foo', msg='Deprecated message', version='2.9')
    if len(arg) != len('foo'):
        raise AssertionError
    if arg[0] != 'f':
        raise AssertionError

if __name__ == "__main__":
    pass
    # Code to execute if called from command-line
    test__DeprecatedSequenceConstant()
    print("Success")

# Generated at 2022-06-22 13:48:21.735397
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert len(a) == 2

# Generated at 2022-06-22 13:48:26.619287
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    lst = ['a', 'b']
    msg = 'This is a test'
    version = '1.0'
    dsc = _DeprecatedSequenceConstant(lst, msg, version)
    assert len(dsc) == len(lst)
    assert dsc[0] == 'a'



# Generated at 2022-06-22 13:49:32.995547
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "test", "1.2")
    assert isinstance(dsc, Sequence)
    assert len(dsc) == 3
    assert dsc[0] == dsc[-1] == dsc[1] == 1


# Generated at 2022-06-22 13:49:35.644288
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'This is a warning message', '2.8')
    constant[0]
    len(constant)

# Generated at 2022-06-22 13:49:41.256955
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestClass(object):
        def __init__(self):
            self.msg = 'test'
            self.version = '2.7'
            self.value = 'test'
            self.deprecated = _DeprecatedSequenceConstant(self.value, self.msg, self.version)

        def __call__(self):
            assert self.deprecated.__len__() == len(self.value)
            assert self.deprecated.__getitem__(0) == self.value[0]

    test = TestClass()
    test()

# Generated at 2022-06-22 13:49:43.191487
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')) == 3



# Generated at 2022-06-22 13:49:54.615058
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test empty list
    empty_list = _DeprecatedSequenceConstant([], "test", "2.13")
    assert empty_list is not None
    assert len(empty_list) == 0

    # Test list with elements
    sized_list = _DeprecatedSequenceConstant(["one", "two", "three"], "test", "2.13")
    assert sized_list is not None
    assert len(sized_list) == 3
    assert sized_list[0] == "one"
    assert sized_list[1] == "two"
    assert sized_list[2] == "three"

# Make sure it is accessible from jinja
from ansible.vars.clean import strip_internal_keys as _strip_internal_keys
strip_internal_keys = _strip_internal_keys



# Generated at 2022-06-22 13:49:57.317748
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], "Test msg", "2.0")
    assert s.__len__() == 3



# Generated at 2022-06-22 13:49:59.742734
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(('a', 'b'), 'test', '2.0')
    assert len(seq) == 2


# Generated at 2022-06-22 13:50:03.004495
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([], 'test', '2.10')
    assert obj._value == []
    assert obj._msg == 'test'
    assert obj._version == '2.10'
    assert obj.__class__.__name__ == '_DeprecatedSequenceConstant'

# Generated at 2022-06-22 13:50:06.736661
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_list = _DeprecatedSequenceConstant([1, 2, 3], "Test for __len__", "2020")
    assert len(deprecated_list) == 3, "__len__() of class _DeprecatedSequenceConstant must be 3"


# Generated at 2022-06-22 13:50:08.973681
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1)
    set_constant('b', 1, export=locals())
    assert a == 1
    assert b == 1
