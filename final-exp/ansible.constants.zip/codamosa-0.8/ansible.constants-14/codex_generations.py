

# Generated at 2022-06-22 13:40:46.641262
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test__DeprecatedSequenceConstant___len___msg', 'test__DeprecatedSequenceConstant___len___version')) == 3


# Generated at 2022-06-22 13:40:50.526090
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_constant = _DeprecatedSequenceConstant(value=['test', 'message'],
                                               msg='this is a test', version='2.0')
    ans = 2
    sol = len(seq_constant)
    assert sol == ans

# Generated at 2022-06-22 13:40:56.475110
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('HI', 'hello') == dict(HI='hello')
    assert set_constant('HELLO', ['how', 'are', 'you']) == dict(HELLO=['how', 'are', 'you'])
    assert set_constant('NEWTHING', 'true') == dict(NEWTHING='true')
    assert set_constant('ANSIBLE_FOO', 'bar') == dict(ANSIBLE_FOO='bar')



# Generated at 2022-06-22 13:41:00.451548
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor raises error for non-sequence data
    try:
        _DeprecatedSequenceConstant('string', 'msg', 'version')
        assert False
    except TypeError:
        assert True

    # Test constructor raises error for non-string message
    try:
        _DeprecatedSequenceConstant([], 1, 'version')
        assert False
    except TypeError:
        assert True

    # Test constructor raises error for non-string version
    try:
        _DeprecatedSequenceConstant([], 'msg', 1)
        assert False
    except TypeError:
        assert True

# Unit tests for constants

# Generated at 2022-06-22 13:41:07.550517
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant((1, 2, 3), 'Test Message', '2.3')
    assert len(a) == 3
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3

    b = _DeprecatedSequenceConstant([10, 20, 30], 'Test Message2', '2.3')
    assert len(b) == 3
    assert b[0] == 10
    assert b[1] == 20
    assert b[2] == 30

# Generated at 2022-06-22 13:41:09.324343
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], "msg", "version")) == 3


# Generated at 2022-06-22 13:41:11.862465
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "Test Message."
    version = "2.2"
    assert _DeprecatedSequenceConstant([], msg, version)

# Generated at 2022-06-22 13:41:13.456785
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(("foo", "bar"), "test", "1.0")
    assert len(x) == 2


# Generated at 2022-06-22 13:41:20.891062
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import sys
    if sys.version_info >= (3, 4):
        from unittest.mock import patch
    else:
        from mock import patch
    with patch('ansible.constants.Display') as mock_display:
        dsc = _DeprecatedSequenceConstant(['abc', 'def', 'ghi'], 'Context', '1.2.3')
        assert len(dsc) == 3
        assert dsc[1] == 'def'
        mock_display.deprecated.assert_called_once_with('Context', version='1.2.3')

# Generated at 2022-06-22 13:41:30.784571
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT_TRUE', True)
    set_constant('TEST_SET_CONSTANT_FALSE', False)
    set_constant('TEST_SET_CONSTANT_STRING', 'test')
    set_constant('TEST_SET_CONSTANT_INT', 0)
    set_constant('TEST_SET_CONSTANT_DICT', {'a': 'b'})

    assert TEST_SET_CONSTANT_TRUE
    assert not TEST_SET_CONSTANT_FALSE
    assert TEST_SET_CONSTANT_STRING == 'test'
    assert TEST_SET_CONSTANT_INT == 0
    assert TEST_SET_CONSTANT_DICT == {'a': 'b'}

# Generated at 2022-06-22 13:41:38.284758
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant([], '', '')
    try:
        value[0]
    except Exception as e:
        # IndexError should be raised
        if 'list' not in str(e):
            raise
    else:
        raise AssertionError('Expected Exception was not raised')

# Generated at 2022-06-22 13:41:43.033171
# Unit test for function set_constant
def test_set_constant():
    set_constant("test_constant", "test")
    assert test_constant == "test"


# FIXME: remove once play_context mangling is removed
# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-22 13:41:50.433743
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _constant_value = ('a', 'b', 'c')
    _constant_msg = "Original message"
    _constant_version = "Original version"
    _constant = _DeprecatedSequenceConstant(_constant_value, _constant_msg, _constant_version)
    _constant_len = len(_constant_value)
    assert len(_constant) == _constant_len
    return True


# Generated at 2022-06-22 13:41:56.680999
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_var', 'test_value', export=globals())
    assert globals().get('test_var') == 'test_value'
    set_constant('test_var', 'new_value', export=globals())
    assert globals().get('test_var') == 'new_value'
    del globals()['test_var']



# Generated at 2022-06-22 13:42:06.203467
# Unit test for function set_constant
def test_set_constant():
    # Test for plain values
    set_constant('plain', True)
    assert plain
    assert plain is True
    set_constant('plain', False)
    assert plain
    assert plain is False
    set_constant('plain', None)
    assert plain
    assert plain is None

    set_constant('plain', 42)
    assert plain
    assert plain == 42
    set_constant('plain', 1.0)
    assert plain
    assert plain == 1.0

    set_constant('plain', u"test")
    assert plain
    assert plain == u"test"

    set_constant('plain', u"test\nfoo")
    assert plain
    assert plain == u"test\nfoo"

    # Test for templatable string
    set_constant('templ', "{{True}}")
   

# Generated at 2022-06-22 13:42:09.234151
# Unit test for function set_constant
def test_set_constant():
    set_constant('test1', 'test2', export={})
    assert 'test1' in globals()
    assert test1 == 'test2'

# Generated at 2022-06-22 13:42:14.937585
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    items = ['item1', 'item2', 'item3']
    constant = _DeprecatedSequenceConstant(items, 'Unit test', '1.2')
    assert constant[0] == 'item1'
    assert constant[1] == 'item2'
    assert constant[2] == 'item3'



# Generated at 2022-06-22 13:42:17.227993
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3, 4], 'foo', 'bar')
    assert len(test_obj) == 4
    for i in (0, 1, 2, 3):
        assert test_obj[i] == i+1

# Generated at 2022-06-22 13:42:24.444523
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import Sequence
    import sys

    class MockDisplay(Display):
        """Provides methods that are used by the Display class to output information to the user."""

        def __init__(self):
            self.deprecated_msgs = []
            self.warnings = []

        def deprecated(self, msg, version=None, removed=False):
            """Outputs a deprecation message and/or a warning regarding the removal of a feature.

            :param msg: A message to be printed to the user.
            :type msg: str
            :param version: The version that the deprecation is targeted for.
            :type version: str
            :param removed: If the feature has been removed or not.
            :type removed: bool
            """
           

# Generated at 2022-06-22 13:42:36.933638
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # Test validation of 'value' argument
    try:
        _DeprecatedSequenceConstant(None, None, None)
    except AssertionError:
        value_msg = "Test _DeprecatedSequenceConstant validations: 'value'"
        assert value_msg
    else:
        print("Test _DeprecatedSequenceConstant validations: 'value' failed")

    # Test validation of 'msg' argument
    try:
        _DeprecatedSequenceConstant('a', None, None)
    except AssertionError:
        msg_msg = "Test _DeprecatedSequenceConstant validations: 'msg'"
        assert msg_msg
    else:
        print("Test _DeprecatedSequenceConstant validations: 'msg' failed")

    # Test validation of 'version' argument

# Generated at 2022-06-22 13:42:47.240388
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class ClassTest(object):
        def __init__(self):
            self.value = None
            self.counter = 0

        def __len__(self):

            if self.counter == 0:
                self.value = [1, 2, 3, 4, 5]

            self.counter += 1

            return len(self.value)

    class Test__DeprecatedSequenceConstant(object):

        def test_description(self):

            class_test = ClassTest()

            msg = u'a message test'
            version = 1.0
            _DeprecatedSequenceConstantTest = _DeprecatedSequenceConstant(class_test, msg, version)

            assert len(_DeprecatedSequenceConstantTest) == 5
            assert len(_DeprecatedSequenceConstantTest) == 5

# Generated at 2022-06-22 13:42:57.403294
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_str
    value = [u"apple", u"banana", u"carrot"]
    msg = "This list should be deprecated."
    version = "2.9"
    deprecated_sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(deprecated_sequence, Sequence)
    assert to_str(deprecated_sequence) == u"[u'apple', u'banana', u'carrot']"

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:43:07.890618
# Unit test for function set_constant
def test_set_constant():
    # Test assigning the right type
    FOO = None
    set_constant('FOO', True)
    assert FOO is True
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', [])
    assert FOO == []
    set_constant('FOO', {})
    assert FOO == {}
    set_constant('FOO', ())
    assert FOO == ()
    # Test assigning wrong type
    FOO = None
    try:
        set_constant('FOO', None, export={'FOO': 'bar'})
    except TypeError:
        pass
    assert FOO == 'bar'
    FOO = None

# Generated at 2022-06-22 13:43:21.269027
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('host_key_checking', False, export=test_dict)
    assert isinstance(test_dict['host_key_checking'], bool), 'host_key_checking should be a bool'
    assert test_dict['host_key_checking'] is False
    assert len(test_dict) == 1


# These are no longer configurable
set_constant('DEFAULT_LIBRARY_PATH', '/usr/share/ansible:%s' % os.path.join(os.environ.get('HOME', ''), '.ansible/plugins/modules'))
set_constant('DEFAULT_MODULE_PATH', '/usr/share/ansible/plugins/modules')

# Generated at 2022-06-22 13:43:28.334592
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class _Test_DeprecatedSequenceConstant(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            super(_Test_DeprecatedSequenceConstant, self).__init__(value, msg, version)

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]

    assert len(_Test_DeprecatedSequenceConstant([1, 2, 3, 4], 'msg', 'version')) == 4
    assert _Test_DeprecatedSequenceConstant([1, 2, 3, 4], 'msg', 'version')[2] == 3

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:43:30.455258
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(value=(1,2,3), msg='msg', version='version')
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3


# Generated at 2022-06-22 13:43:35.660626
# Unit test for function set_constant
def test_set_constant():

    # This is to check that set_constant sets the value in locals
    def set_constant_test(name, value):
        export = locals()
        set_constant(name, value, export)
        return export

    assert set_constant_test('name', 'value1') == {'name': 'value1'}
    assert set_constant_test('name', 'value2') == {'name': 'value2'}

# Generated at 2022-06-22 13:43:38.242133
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant([], '', '')
    assert a._value == []

# Generated at 2022-06-22 13:43:41.541715
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(
        ('',),
        msg='_DeprecatedSequenceConstant.__len__', version='2.5')
    assert len(dsc) == 1



# Generated at 2022-06-22 13:43:45.430935
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1, 2, 3]
    msg = "Ansible broke"
    version = "2.10"
    deprecated = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated) == 3
    assert deprecated[0] == 1

# Generated at 2022-06-22 13:43:55.997703
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([0, 1, 2, 3, 4], None, None)[1] == 1
    assert _DeprecatedSequenceConstant([0, 1, 2, 3, 4], None, None)[-1] == 4
    assert _DeprecatedSequenceConstant([0, 1, 2, 3, 4], None, None)[1:3] == [1, 2]


# Generated at 2022-06-22 13:43:59.151184
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(["a", "b"], 'msg', '1.0')
    assert len(seq) == 2
    assert(seq[0], seq[1]) == ("a", "b")

# Generated at 2022-06-22 13:44:01.736829
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(l) == 0


# Generated at 2022-06-22 13:44:13.611935
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Make sure the class _DeprecatedSequenceConstant have the same behavior as class list
    # First let's get the value of some key in the MAGIC_VARIABLE_MAPPING, since the value of
    # MAGIC_VARIABLE_MAPPING is a tuple and we want to get the first element of it
    value = list(MAGIC_VARIABLE_MAPPING.values())[0][0]

    # Print the value of the first element of one key in the MAGIC_VARIABLE_MAPPING
    print(value)

    # Create an instance of the class _DeprecatedSequenceConstant
    dsc = _DeprecatedSequenceConstant(value, "This is a test.", "2.9")

    # Verify the class can output the same result as list
    assert len(dsc) == len

# Generated at 2022-06-22 13:44:16.706006
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Arrange
    d = _DeprecatedSequenceConstant([1, 2, 3], "msg", "1.0")
    # Act
    r = len(d)
    # Assert
    assert r == 3



# Generated at 2022-06-22 13:44:27.652720
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(
        ['a', 'b', 'c'],
        'Using a, b, and c is deprecated',
        '2.2'
    )

    assert(len(x) == 3)
    assert(x[0] == 'a')
    assert(x[1] == 'b')
    assert(x[2] == 'c')

    # Trigger the deprecation warning.
    list(x)
    iter(x)
    bytes(x)
    tuple(x)

if __name__ == "__main__":
    # Run unit tests by calling itself.
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:44:29.776498
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test', 'value') == dict(test='value')



# Generated at 2022-06-22 13:44:33.711935
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    d = _DeprecatedSequenceConstant(l, 'test message', 'test version')

    if d[0] != l[0] or d[1] != l[1] or d[2] != l[2]:
        raise Exception("test__DeprecatedSequenceConstant___getitem__: __getitem__ method of class _DeprecatedSequenceConstant not working properly")


# Generated at 2022-06-22 13:44:44.815902
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('test', 'mytest', export=export)
    assert export['test'] == 'mytest'
    assert globals()['test'] == 'mytest'

    try:
        set_constant('set_constant', 'invalidate', export=export)
    except Exception:
        pass
    else:
        raise AssertionError('set_constant did not raise exception with invalid constant')

    try:
        set_constant(None, 'invalidate', export=export)
    except Exception:
        pass
    else:
        raise AssertionError('set_constant did not raise exception with invalid constant')

    try:
        set_constant('1test', 'invalidate', export=export)
    except Exception:
        pass
    else:
        raise Assertion

# Generated at 2022-06-22 13:44:52.087286
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('_TEST_CONSTANT', True) == vars()
    assert vars()['_TEST_CONSTANT']
    assert set_constant('_TEST_CONSTANT', False) == vars()
    assert not vars()['_TEST_CONSTANT']
    del vars()['_TEST_CONSTANT']


# FIXME: remove when we don't need to pickle this object anymore

# Generated at 2022-06-22 13:45:08.491250
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a sample DeprecatedSequenceConstant for unittest"
    version = "2.9"
    sample = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert len(sample) == 3
    assert sample[0] == 1
    assert sample[1] == 2
    assert sample[2] == 3



# Generated at 2022-06-22 13:45:10.842992
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'value', export=globals())
    assert globals()['test'] == 'value'

# Generated at 2022-06-22 13:45:23.532861
# Unit test for function set_constant
def test_set_constant():

    def check_constant(export, name, value):
        assert name in export
        assert export[name] == value

    export = {}
    set_constant("test1", "test1", export=export)
    check_constant(export, "test1", "test1")
    set_constant("test2", ["test2"], export=export)
    check_constant(export, "test2", ["test2"])
    set_constant("test3", {"test3": "test3"}, export=export)
    check_constant(export, "test3", {"test3": "test3"})
    set_constant("test4", True, export=export)
    check_constant(export, "test4", True)


# Generated at 2022-06-22 13:45:29.238440
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_seq = [1, 2, 3]
    msg = 'This is a test warning'
    version = '1.0.0'
    t = _DeprecatedSequenceConstant(test_seq, msg, version)

    # test __len__
    assert len(t) == 3

    # test __getitem__
    assert t[1] == 2

    # test exceptions
    try:
        t[10]
    except IndexError:
        pass


# Generated at 2022-06-22 13:45:33.762968
# Unit test for function set_constant
def test_set_constant():
    """This is a unit test for function set_constant."""
    namespace = {}
    set_constant('FOO', 'bar', namespace)
    assert namespace['FOO'] == 'bar'



# Generated at 2022-06-22 13:45:40.303507
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def mock_deprecated(msg, version):
        ''' mock-up method to verify that _deprecated is invoked '''
        # it is sufficient to assert, that this method is called once
        assert msg == 'This option is deprecated'
        assert version == '2.2'
        return

    _deprecated = mock_deprecated

    seq = _DeprecatedSequenceConstant(['abc123'], 'This option is deprecated', '2.2')
    assert seq[0] == 'abc123'

# Generated at 2022-06-22 13:45:49.552510
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'you should not use this'
    version = '2.11'
    my_list = ['one', 'two']
    dsc = _DeprecatedSequenceConstant(my_list, msg, version)
    assert dsc[0] == my_list[0], '_DeprecatedSequenceConstant[0] was not equal to the value of the original list'
    assert dsc[1] == my_list[1], '_DeprecatedSequenceConstant[1] was not equal to the value of the original list'

# Generated at 2022-06-22 13:45:51.249561
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(sequence, 'test warning', '2.8')
    assert dsc[1] == sequence[1]

# Generated at 2022-06-22 13:45:54.676157
# Unit test for function set_constant
def test_set_constant():
    global DEFAULT_BECOME_PASS
    set_constant('DEFAULT_BECOME_PASS', 'foo')
    assert DEFAULT_BECOME_PASS == 'foo'



# Generated at 2022-06-22 13:45:57.704688
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test warning', 'version 1.0')
    assert dsc[0] == 1
    assert dsc[1] == 2



# Generated at 2022-06-22 13:46:27.501246
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('A', 'B'), 'foo', 'bar')) == 2


# Generated at 2022-06-22 13:46:31.392983
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_list = _DeprecatedSequenceConstant(["test_item"], "test_message", "test_version")
    assert len(deprecated_list) == 1
    assert deprecated_list[0] == "test_item"

# Generated at 2022-06-22 13:46:36.421088
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    constant = _DeprecatedSequenceConstant(value, msg, version)

    assert constant._msg == msg
    assert constant._value == value
    assert constant._version == version

# Generated at 2022-06-22 13:46:39.530868
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('FOO', 'BAR', export)
    assert export['FOO'] == 'BAR'


# Generated at 2022-06-22 13:46:50.738554
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    DEPRECATED_SEQUENCE_CONSTANT_VALUE = ['a', 'b', 'c']
    DEPRECATED_SEQUENCE_CONSTANT_MSG = 'DEPRECATED_SEQUENCE_CONSTANT_MSG'
    DEPRECATED_SEQUENCE_CONSTANT_VERSION = 'DEPRECATED_SEQUENCE_CONSTANT_VERSION'
    DEPRECATED_SEQUENCE_CONSTANT = _DeprecatedSequenceConstant(DEPRECATED_SEQUENCE_CONSTANT_VALUE, DEPRECATED_SEQUENCE_CONSTANT_MSG, DEPRECATED_SEQUENCE_CONSTANT_VERSION)
    assert DEPRECATED_SEQUENCE_CONSTANT[0] == 'a'
    assert DEPRECATED_SEQUENCE_CONSTANT[1]

# Generated at 2022-06-22 13:46:54.923634
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a test message.'
    version = '2.9'
    value = ['test']

    assert list(_DeprecatedSequenceConstant(value, msg, version)) == value

# Generated at 2022-06-22 13:47:05.154087
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    warnings = []
    class WarnClass(object):
        def __init__(self, l):
            self.l = l
        def deprecated(self, msg, version=''):
            self.l.append(msg)

    c = _DeprecatedSequenceConstant([0, 1, 2], 'foo', 'bar')
    c.__len__ = lambda: len(warnings)
    c.__getitem__ = lambda x: warnings[x]

    dc = WarnClass(warnings)
    c.display = dc

    assert c[0] == 0
    assert warnings == ['foo, to be removed in bar']

    warnings = []
    c[0] = 'a'
    assert warnings == ['foo, to be removed in bar']


# Generated at 2022-06-22 13:47:11.807875
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my_msg = 'This is a test message'
    my_version = '1.1.1'
    my_seq = _DeprecatedSequenceConstant([1, 2, 3], my_msg, my_version)
    assert(len(my_seq) == 3)
    assert(my_seq[0] == 1)



# Generated at 2022-06-22 13:47:17.350787
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Some message'
    version = '1.0.0'
    x = _DeprecatedSequenceConstant([1,2,3], msg, version)
    assert len(x) == 3
    version = '1.0.1'
    x = _DeprecatedSequenceConstant([1,2,3], msg, version)
    assert len(x) == 3

# Generated at 2022-06-22 13:47:21.164067
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [0]
    msg = "test__DeprecatedSequenceConstant___len__"
    version = "1.0"
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 1

# Generated at 2022-06-22 13:48:34.923996
# Unit test for function set_constant
def test_set_constant():
    constant_names = ('DEFAULT_SUBSET', 'DEFAULT_PASSWORD_CHARS')

    for name in constant_names:
        assert name in globals(), 'name %s is not in globals()' % name


# make sure we have no duplicate constants
# HINT: do not define a constant with the same name as an option!
if len(set(config.data.get_settings())) != len(config.data.get_settings()):
    raise Exception('duplicate constants defined in config!')

# LEGACY SUPPORT CODE ###
BECOME_METHODS = [
    'sudo',
    'sudo-user',
    'su',
    'pbrun',
    'pfexec',
    'dzdo',
    'pmrun',
    'runas',
]

# TODO: clean

# Generated at 2022-06-22 13:48:46.737466
# Unit test for function set_constant
def test_set_constant():
    # Setting constants that have no origin
    try:
        set_constant('ANSIBLE_UNKNOWN_CONSTANT', 'test', globals())
    except:
        raise AssertionError('Failed to set unknown constant')

    # Setting constants that have an origin
    try:
        set_constant('ANSIBLE_IGNORE_FILES', 'test', globals())
    except:
        raise AssertionError('Failed to set constant with an origin')
    del globals()['ANSIBLE_IGNORE_FILES']
    del globals()['ANSIBLE_UNKNOWN_CONSTANT']

test_set_constant()

# now set deprecated sequences based on values above

# Generated at 2022-06-22 13:48:50.065826
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert deprecated_sequence_constant[0] == 1


# Generated at 2022-06-22 13:48:56.618727
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('a', 'b')
    msg = 'c'
    version = '0.0.0'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant._value == ('a', 'b')

# Generated at 2022-06-22 13:49:00.713927
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Create instance of class _DeprecatedSequenceConstant
    dsc = _DeprecatedSequenceConstant([1,2,3,'a','b','c'], 'test of _DeprecatedSequenceConstant', '2.8')

    # Test method __len__
    l = len(dsc)
    assert l == 6

# Generated at 2022-06-22 13:49:06.463379
# Unit test for function set_constant
def test_set_constant():
    assert test_constant.C.BATMAN == 'robin'
    assert test_constant.C.BATMAN != 'joker'
    assert test_constant.C.BATMAN == 'robin'

test_constant = type('test_constant', (object,), {})()
set_constant('BATMAN', 'robin', test_constant.__dict__)
test_set_constant()

# Generated at 2022-06-22 13:49:12.546261
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        from ansible.utils.display import Display
        display = Display()
    except Exception:
        import sys
        display = None
        sys.stderr.write(' [WARNING] %s\n' % ('Display class not available'))

    assert isinstance(_DeprecatedSequenceConstant(['a'], '', version='2.11'), Sequence)

    _deprecated('', '') if display is None else display.deprecated('', version='')

# Generated at 2022-06-22 13:49:15.911187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert(len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0)
    assert(_DeprecatedSequenceConstant([1], 'msg', 'version')[0] == 1)

# Generated at 2022-06-22 13:49:18.950065
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1,2,3], 'dummy', 'dummy')
    assert len(d) == 3


# Generated at 2022-06-22 13:49:22.694119
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    DEPRECATED_CONSTANT_LIST = _DeprecatedSequenceConstant(['a','b','c','d','e'], "Test len() deprecated message", '1.0')
    assert len(DEPRECATED_CONSTANT_LIST) == 5
