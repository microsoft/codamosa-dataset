

# Generated at 2022-06-22 13:40:50.447917
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_example = _DeprecatedSequenceConstant(tuple(), 'oneline msg', '2.10')
    assert repr(deprecated_example) == '<_DeprecatedSequenceConstant: oneline msg, to be removed in 2.10>'
    assert len(deprecated_example) == 0
    assert deprecated_example[0] is None


# Generated at 2022-06-22 13:40:54.408907
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert dsc._value == 'value'
    assert dsc._msg == 'msg'
    assert dsc._version == 'version'
    assert len(dsc) == 5

# Generated at 2022-06-22 13:41:06.963831
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([], '', '')[0] is None
    assert _DeprecatedSequenceConstant(['foo'], '', '')[0] == 'foo'

    assert _DeprecatedSequenceConstant([], '', '')[1] is None
    assert _DeprecatedSequenceConstant(['foo', 'bar'], '', '')[1] == 'bar'

    assert _DeprecatedSequenceConstant([], '', '')[-1] is None
    assert _DeprecatedSequenceConstant(['foo', 'bar'], '', '')[-1] == 'bar'

    assert _DeprecatedSequenceConstant([], '', '')[-2] is None
    assert _DeprecatedSequenceConstant(['foo', 'bar'], '', '')[-2] == 'foo'

    assert _DeprecatedSequ

# Generated at 2022-06-22 13:41:14.717491
# Unit test for function set_constant
def test_set_constant():
    '''test the set_constant function'''
    assert 'FOO_BAR_BAZ' not in locals()
    assert 'FOO_BAR_BAZ' not in globals()
    set_constant('FOO_BAR_BAZ', 'qwertyuiop', export=globals())
    assert 'FOO_BAR_BAZ' in globals()
    assert FOO_BAR_BAZ == 'qwertyuiop'


# Set the FILE_TRANSFER_DIR for backwards compat, but also allow
# it to be overriden in the config
_deprecated_msg = 'The ``FILE_TRANSFER_DIR`` configuration setting is deprecated and will be removed in Ansible 2.13, use ``file_transfer_dir`` instead'

# Generated at 2022-06-22 13:41:21.273665
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='version')

    # Tests without any deprecated msg
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3

    # Tests with deprecated msg
    global _deprecated
    def _deprecated(msg, version):
        assert msg == 'msg'
        assert version == 'version'
    assert seq[0] == 1
    # Restore _deprecated original function
    _deprecated = globals()['_deprecated']

# Generated at 2022-06-22 13:41:25.139353
# Unit test for function set_constant
def test_set_constant():
    # Two constants with different values
    assert ANSIBLE_CONFIG != IGNORE_FILES
    # Two constants with same value
    assert DEFAULT_BECOME_PASS is DEFAULT_REMOTE_PASS

# Generated at 2022-06-22 13:41:36.298458
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.config.constants import APPEND_TO_ANSIBLE_MODULE_ARGSPEC

    test_obj = _DeprecatedSequenceConstant(['a', 'b'], 'test_msg', '1.3')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'

    test_obj = _DeprecatedSequenceConstant(APPEND_TO_ANSIBLE_MODULE_ARGSPEC, 'test_msg', '1.3')
    assert test_obj[0] == 'ansible_test_arg'
    assert test_obj[1] == 'ansible_test_arg_inherited'



# Generated at 2022-06-22 13:41:38.773240
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    r = _DeprecatedSequenceConstant([1,2,3], "msg", "version")
    assert len(r) == 3


# Generated at 2022-06-22 13:41:43.085837
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant(value=[1, 2], msg='Test', version='2.7')
    assert test[0] == 1
    assert test[1] == 2



# Generated at 2022-06-22 13:41:47.613458
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_LIBRARY == config.data['ANSIBLE_LIBRARY']
    assert DEFAULT_HOST_LIST == config.data['DEFAULT_HOST_LIST']
    assert DEFAULT_PRIVATE_KEY_FILE == config.data['DEFAULT_PRIVATE_KEY_FILE']
    assert DEFAULT_SUDO_USER == config.data['DEFAULT_SUDO_USER']
    assert DEFAULT_SUDO_PASS == config.data['DEFAULT_SUDO_PASS']
    assert DEFAULT_SYSLOG_FACILITY == config.data['DEFAULT_SYSLOG_FACILITY']
    assert DEFAULT_SUDO_EXE == config.data['DEFAULT_SUDO_EXE']

# Generated at 2022-06-22 13:41:54.824521
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', '2.0') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', '2.0')) == 2


# Generated at 2022-06-22 13:41:58.733481
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='hello', version=__version__)
    assert len(dsc) == 3
    assert dsc[0] == 1
    # FIXME: test side effect of deprecation warning


# Generated at 2022-06-22 13:42:03.218436
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(value=[1,2], msg='Test', version='3.0')
    assert isinstance(test, Sequence)
    assert len(test) == 2
    assert test[0] == 1
    assert test[1] == 2


# Generated at 2022-06-22 13:42:08.446890
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    tmp = _DeprecatedSequenceConstant(list(), 'message', 'version')
    assert len(tmp) == 0
    tmp._value.append("do not lose me")
    assert len(tmp) == 1


# Generated at 2022-06-22 13:42:12.360852
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(list(range(10)), 'some msg', 'some version')
    actual = len(seq)
    expected = 10
    assert actual == expected


# Generated at 2022-06-22 13:42:16.568007
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # First test for deprecation
    msg = "this is a test of _DeprecatedSequenceConstant"
    version = "2.9"
    test = _DeprecatedSequenceConstant([], msg, version)
    assert test == [], test


# Generated at 2022-06-22 13:42:21.313201
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_messages = []

    def my_warning_message(msg):
        test_messages.append(msg)

    _deprecated = my_warning_message

    v = _DeprecatedSequenceConstant([1, 2, 3], 'test message', 'version test')
    v[1]
    assert test_messages == [' [DEPRECATED] test message, to be removed in version test']

# Generated at 2022-06-22 13:42:33.109602
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == 'test/ansible.cfg'


# These are the config constants that are allowed in config templates

# Generated at 2022-06-22 13:42:36.655761
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == 3

# Generated at 2022-06-22 13:42:48.477840
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'something deprecated'
    version = '2.11'
    version_with_quotes = "'2.11'"
    version_with_dots = '2.11.0'
    version_when_missing = 'unknown'
    version_with_space = '2.11 '
    value = ['foo', 'bar', 'baz']
    sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert sequence._msg == msg
    assert sequence._version == version
    assert sequence._value == value
    assert sequence.__len__() == len(value)
    assert sequence.__getitem__(0) == value[0]
    assert sequence.__getitem__(1) == value[1]
    assert sequence._msg.startswith('something deprecated')

# Generated at 2022-06-22 13:42:59.191076
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="msg", version="1.2.3")
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 13:43:00.601922
# Unit test for function set_constant
def test_set_constant():
    set_constant('this', 'that')
    assert this == 'that'

# Generated at 2022-06-22 13:43:01.745251
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "test test", "test version")
    assert len(dsc) == 3


# Generated at 2022-06-22 13:43:02.973282
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant(('test_data',), 'test_msg', 'test_version')
    assert test_constant[0] == 'test_data'

# Generated at 2022-06-22 13:43:06.720714
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    l = _DeprecatedSequenceConstant(["test1", "test2"], "test", "2.10")
    assert len(l) == 2
    assert l[0] == to_text("test1")

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-22 13:43:11.095186
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(('value1',), 'msg', '2.0')
    assert c[0] == 'value1'


# Generated at 2022-06-22 13:43:18.364059
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = (True, False, True)
    msg = 'This is a test message'
    version = '2.3'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == True
    assert dsc[1] == False
    assert dsc[2] == True
    assert len(dsc) == 3

# Generated at 2022-06-22 13:43:20.965404
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', '2.5')
    assert len(seq) == 2


# Generated at 2022-06-22 13:43:23.742989
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.2.0')
    assert 3 == len(obj)


# Generated at 2022-06-22 13:43:29.529314
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant(('foo', ), 'MESSAGE', 'VERSION')
    assert len(d) == 1
    d = _DeprecatedSequenceConstant({}, 'MESSAGE', 'VERSION')
    assert len(d) == 0


# Generated at 2022-06-22 13:43:42.133288
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], 'msg', '1.2.3')) == 0

# Generated at 2022-06-22 13:43:44.565803
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('key', 'value', export=constants)
    assert constants['key'] == 'value'



# Generated at 2022-06-22 13:43:55.448400
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('foo', 42, export=export)
    set_constant('bar', 'ansible', export=export)
    assert export['foo'] == 42
    assert export['bar'] == 'ansible'


# DEPRECATED OPTION CONVERSIONS ###

# FIXME: remove once we're past 2.12
_DEP_HASH_BEHAVIOUR = config.get_config_value('hash_behaviour')

if _DEP_HASH_BEHAVIOUR != 'merge':
    _warning("'hash_behaviour={0}' is deprecated, use 'hash_behaviour=merge'".format(_DEP_HASH_BEHAVIOUR))
    HASH_BEHAVIOUR = 'merge'

# FIXME: remove once we're past 2.12
_DEP_

# Generated at 2022-06-22 13:43:59.242830
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    foo = _DeprecatedSequenceConstant(['foo', 'bar', 'baz'], 'msg1', 'v1')
    assert len(foo) == 3
    assert foo[0] == foo[2] == 'foo'
    assert foo[1] == 'bar'

# Generated at 2022-06-22 13:44:09.992830
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import cStringIO

    msg = "the brown fox jumps over the lazy dog"
    version = "2.8"
    abc = _DeprecatedSequenceConstant('abc', msg, version)

    real_stdout = sys.stdout
    sys.stdout = cStringIO.StringIO()

    result = abc[0]
    output = sys.stdout.getvalue().strip()

    sys.stdout.close()
    sys.stdout = real_stdout

    assert result == 'a'
    assert output == ' [DEPRECATED] %s, to be removed in %s' % (msg, version)



# Generated at 2022-06-22 13:44:16.222230
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'XXX is deprecated.'
    version = '41.42.43'
    test_object = _DeprecatedSequenceConstant([u'a', u'b', u'c'], msg, version)
    if test_object[0] != u'a':
        raise AssertionError()
    if test_object[-1] != u'c':
        raise AssertionError()


# Generated at 2022-06-22 13:44:21.156464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg, version = 'Test msg', 'Test version'
    value = 'value'

    d = _DeprecatedSequenceConstant(value, msg, version)
    assert d._value == value
    assert d._msg == msg
    assert d._version == version

# Generated at 2022-06-22 13:44:22.984802
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([], '', '')
    assert constant[0] is None

# Generated at 2022-06-22 13:44:25.270006
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg="", version="")) == 0

# Generated at 2022-06-22 13:44:33.740984
# Unit test for function set_constant
def test_set_constant():
    assert C.CONFIGURING_NAME == 'ansible'
    assert C.LOCALHOST == ['127.0.0.1', 'localhost', '::1']
    assert C.ANSIBLE_NOCOWS == 1
    assert C.ANSIBLE_CONFIG == '/test/ansible.cfg'


# for backwards compatibility to Ansible 1.X

# Generated at 2022-06-22 13:45:03.117966
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(["a", "b"], "dummy", "dummy").__getitem__(0) == "a"
    assert _DeprecatedSequenceConstant(["a", "b"], "dummy", "dummy").__getitem__(1) == "b"


# Generated at 2022-06-22 13:45:05.024777
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant((1, 2, 3), 'message', 'version')[1] == 2

# Generated at 2022-06-22 13:45:08.918325
# Unit test for function set_constant
def test_set_constant():
    local_dict = {}
    set_constant('ANSIBLE_CONFIG', 'config.ini', export=local_dict)
    assert 'ANSIBLE_CONFIG' in local_dict
    assert local_dict['ANSIBLE_CONFIG'] == 'config.ini'

# Generated at 2022-06-22 13:45:13.150234
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'some mesg'
    version = '100.100.100'
    obj = _DeprecatedSequenceConstant([1, 2], msg, version)
    assert obj[0] is 1
    assert obj[1] is 2


# Generated at 2022-06-22 13:45:17.770517
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(('123', '456'), 'msg', 'version')
    assert len(dsc) == 2
    assert dsc[0] == '123'
    assert dsc[1] == '456'

# Generated at 2022-06-22 13:45:25.995095
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from nose.tools import assert_equal, assert_raises

    # _DeprecatedSequenceConstant should have the same functionality as tuple
    a = (1, 2, 3, 4, 5)
    b = _DeprecatedSequenceConstant(a, "", "2.4")
    assert_equal(len(a), len(b))
    try:
        len(b)
    except DeprecationWarning:
        assert_false("_DeprecatedSequenceConstant should not cause DeprecationWarning when len(self) is called")



# Generated at 2022-06-22 13:45:27.376746
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    actual = len(_DeprecatedSequenceConstant(value=('foo',), msg="err msg", version="2.0"))
    expected = 1
    assert actual == expected

# Generated at 2022-06-22 13:45:30.697918
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # type: () -> None
    test_input = (1, 2)
    test_instance = _DeprecatedSequenceConstant(test_input, "test", "version")
    assert len(test_instance) == 2
    assert len(test_instance._value) == 2


# Generated at 2022-06-22 13:45:37.213245
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Constructor of _DeprecatedSequenceConstant
    test = _DeprecatedSequenceConstant(value="123", msg="Testing", version="ansible 2.3")

    # testing __len__ method
    assert len(test) == 3

    # testing __getitem__ method
    assert test[0] == "1"

    # test isinstance with Sequence
    assert isinstance(test, Sequence)

# Generated at 2022-06-22 13:45:50.177240
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _FakeClass(object):
        # Makes the class looks like a module
        __package__ = 'ansible.constants'
        __file__ = 'ansible/constants/__init__.py'

        # Makes the instance looks like a module
        def __init__(self):
            self.__name__ = 'ansible.constants'
            self.__doc__ = ''
            self.__package__ = 'ansible.constants'
            self.__file__ = 'ansible/constants/__init__.py'

        # Suppress pylint warning: Access to a protected member _DeprecatedSequenceConstant of a client class (protected-access)
        # pylint: disable=W0212

# Generated at 2022-06-22 13:46:47.121643
# Unit test for function set_constant
def test_set_constant():
    test_ns = {}
    set_constant('test_key', 'test_value', test_ns)
    assert test_ns['test_key'] == 'test_value'

# Generated at 2022-06-22 13:46:49.932431
# Unit test for function set_constant
def test_set_constant():
    data = {}
    set_constant('a', 2.0, export=data)
    assert data == {'a': 2.0}



# Generated at 2022-06-22 13:46:59.285473
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def seq_const_len():
        return len(_DeprecatedSequenceConstant([1, 2, 3], "test_msg", "test_version"))
    def seq_const_getitem():
        return _DeprecatedSequenceConstant([1, 2, 3], "test_msg", "test_version")[1]
    if seq_const_len() != 3:
        print("ERROR: len of _DeprecatedSequenceConstant is not 3")
    if seq_const_getitem() != 2:
        print("ERROR: getitem of _DeprecatedSequenceConstant is not 2")

# Generated at 2022-06-22 13:47:02.077541
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test constructor for class _DeprecatedSequenceConstant
    assert isinstance(_DeprecatedSequenceConstant((), 'test msg', 'test_version'), _DeprecatedSequenceConstant)

# Generated at 2022-06-22 13:47:09.539028
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    name = "value"
    value = [True, False]
    msg = "message"
    version = "1.0"
    test_obj = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)

    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]

# Generated at 2022-06-22 13:47:18.974043
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    DEFAULT_HOST_LIST = _DeprecatedSequenceConstant(value=LOCALHOST, msg='DEFAULT_HOST_LIST is deprecated as of Ansible 2.3. ' +
                                                                         'Use DEFAULT_LOCALHOST or DEFAULT_LOCALHOST_LINE instead. As of Ansible 2.4, DEFAULT_HOST_LIST will be removed.', version='2.4')

    assert len(DEFAULT_HOST_LIST) == 3
    assert DEFAULT_HOST_LIST[0] == '127.0.0.1'


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:47:21.522098
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 1, 1).__getitem__(0) == 1


# Generated at 2022-06-22 13:47:29.235307
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """
    _DeprecatedSequenceConstant_'s __getitem__ method should return the
    value of _DeprecatedSequenceConstant._value's __getitem__, and call the
    _deprecated method for the _DeprecatedSequenceConstant instance in the
    case of _DeprecatedSequenceConstant__getitem__ being called if the
    _DeprecatedSequenceConstant's _version is less than the
    _DeprecatedSequenceConstant's _value's version
    """
    class TestVersion(object):
        def __init__(self, version):
            self.version = version

        def __lt__(self, other):
            return self.version < other.version

    def _fake_deprecated(msg, version):
        assert msg == "msg"
        assert version == "1.0"


# Generated at 2022-06-22 13:47:31.222709
# Unit test for function set_constant
def test_set_constant():
    ns = {}
    set_constant('HELLO', 'world', export=ns)
    assert ns['HELLO'] == 'world'

# Generated at 2022-06-22 13:47:35.693514
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([1, 2, 3, 4], 'deprecated message', '2.9')
    assert len(constant) == 4
    assert constant[1] == 2


# Generated at 2022-06-22 13:49:54.032832
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('foo', 'bar', constants)
    assert constants['foo'] == 'bar'
    set_constant('foo', 'bar2', constants)
    assert constants['foo'] == 'bar'
    set_constant('bar', 'baz')
    assert globals()['bar'] == 'baz'



# Generated at 2022-06-22 13:50:03.089033
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_value = ('a', 'b', 'c')
    test_msg = 'test constant deprecated'
    test_version = '1.0'
    test_sequence_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert len(test_sequence_constant) == 3
    assert test_sequence_constant[0] == 'a'
    assert test_sequence_constant[1] == 'b'
    assert test_sequence_constant[2] == 'c'

    deprecated_messages = [u" [DEPRECATED] test constant deprecated, to be removed in 1.0",
                           u" [DEPRECATED] test constant deprecated, to be removed in 1.0",
                           u" [DEPRECATED] test constant deprecated, to be removed in 1.0"]



# Generated at 2022-06-22 13:50:05.663409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Configure the test
    test_instance = _DeprecatedSequenceConstant([1, 2, 3], "Not a real warning", 1.0)

    # Run the test
    result = len(test_instance)

    # Verify appropriate result
    assert result == 3



# Generated at 2022-06-22 13:50:08.947292
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dummy_value = ['value1', 'value2']
    msg = 'This is a test message.'
    version = '2.4'

    ds = _DeprecatedSequenceConstant(dummy_value, msg, version)

    assert len(ds) == 2



# Generated at 2022-06-22 13:50:14.906242
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', 'test version')
    assert dsc[0] == 1
    assert dsc[-1] == 3
    assert dsc[1:2] == [2]
    assert dsc[-2:] == [2, 3]
    assert dsc[1:] == [2, 3]
    assert dsc[:-1] == [1, 2]


# Generated at 2022-06-22 13:50:21.724288
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([], 'test', '1.0')
    assert constant['undefined'] is None
    constant[0] = 'test0'
    assert constant[0] == 'test0'
    constant = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], 'test', '1.0')
    assert constant['undefined'] is None
    assert constant[-1] == 5
    assert constant[3] == 4


# Generated at 2022-06-22 13:50:32.567135
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS == 'sudo'
    assert DEFAULT_PASSWORD_CHARS == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'
    assert DEFAULT_REMOTE_PASS == 'sshpass'
    assert DEFAULT_SUBSET == 'all'
    assert COLLECTION_PTYPE_COMPAT['module'] == 'modules'
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')