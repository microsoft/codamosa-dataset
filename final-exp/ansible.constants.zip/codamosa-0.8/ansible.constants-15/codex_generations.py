

# Generated at 2022-06-22 13:40:41.222560
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(tuple(), '', '')
    assert constant.__len__() == 0

# Generated at 2022-06-22 13:40:50.325995
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # _DeprecatedSequenceConstant is a subclass of Sequence, so we can use Sequence to construct a sequence object.
    sequence = [1, 2, 3]
    # Construct a _DeprecatedSequenceConstant object
    deprecate_sequence_constant = _DeprecatedSequenceConstant(
        sequence, 'This is a warning message.', '1.0'
    )
    # Get the first element of _DeprecatedSequenceConstant object
    first_element = deprecate_sequence_constant[0]
    assert first_element == 1


# Generated at 2022-06-22 13:40:54.253714
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'a', 'b')
    assert len(a) == 3
    assert a[1] == 2
    assert a.__getitem__(1) == 2
    assert a.__len__() == 3

# Generated at 2022-06-22 13:40:55.567060
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    return _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 13:40:59.457757
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='test', version='2.9')
    len(x)
    x[0]

# Generated at 2022-06-22 13:41:01.525635
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant((0, 1, 2), 'msg', 'version')[1] == 1

# Generated at 2022-06-22 13:41:05.619678
# Unit test for function set_constant
def test_set_constant():
    d = dict()
    set_constant('FOO', 'BAR', export=d)
    assert d['FOO'] == 'BAR'


# ANSI control sequences
RESET_SEQ = u"\033[0m"
COLOR_SEQ = u"\033[%s;%sm"



# Generated at 2022-06-22 13:41:07.876519
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert a[1] == 2
    assert len(a) == 3


# Generated at 2022-06-22 13:41:09.324413
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(((0, 1, 2),), '', '')) == 2

# Generated at 2022-06-22 13:41:16.578731
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test the __getitem__ and __len__ method of _DeprecatedSequenceConstant
    x = _DeprecatedSequenceConstant(['aaa', 'bbb'], 'msg', 'version')
    assert len(x) == 2
    assert x[0] == 'aaa' and x[1] == 'bbb'


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 13:41:28.024474
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = [1,2,3]
    sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert sequence_constant._msg == msg
    assert sequence_constant._version == version
    assert sequence_constant._value == value
    assert sequence_constant[0] == 1
    assert sequence_constant[1] == 2
    assert sequence_constant[2] == 3
    assert len(sequence_constant) == 3

# Generated at 2022-06-22 13:41:37.163978
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # values that can be easily evaluated to true or false
    false_values = ("false", "False", "0", 0, None, [])
    true_values = ("true", "True", "1", 1, ['stuff'])

    for value in false_values:
        assert not _DeprecatedSequenceConstant(value, "this is an error message", "this is a version")
    for value in true_values:
        assert _DeprecatedSequenceConstant(value, "this is an error message", "this is a version")


# Generated at 2022-06-22 13:41:50.393723
# Unit test for function set_constant
def test_set_constant():
    # Set the constant value for an existing key, and check that it changed.
    old_value = locals()['DEFAULT_BECOME_PASS']
    assert DEFAULT_BECOME_PASS != "the new value"
    set_constant('DEFAULT_BECOME_PASS', "the new value")
    assert DEFAULT_BECOME_PASS == "the new value"

    # Reset the value.
    set_constant('DEFAULT_BECOME_PASS', old_value)
    assert DEFAULT_BECOME_PASS == old_value

    # Set the constant value for an new key, and check that it exists.
    assert not locals().has_key('NEW_KEY')
    set_constant('NEW_KEY', "the new value")
    assert locals().has_key('NEW_KEY')

# Generated at 2022-06-22 13:41:53.552123
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    t = [1, 2, 3]
    test = _DeprecatedSequenceConstant(t, 'test', '1.0')

    assert len(t) == len(test)
    assert test[1] == 2

# Generated at 2022-06-22 13:41:57.045989
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = [5,6,7,8]
    dsc = _DeprecatedSequenceConstant(l, 'msg', 'version')
    assert len(dsc) == len(l)

# Generated at 2022-06-22 13:42:02.148661
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ['a', 'b']
    msg = 'This is a deprecated test.'
    version = '1.9'
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert seq[0] == 'a'
    assert seq[1] == 'b'


# Generated at 2022-06-22 13:42:11.824455
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(list(), "test", "2.10")
    assert len(dsc) == 0
    dsc._value.append(1)
    assert len(dsc) == 1
    dsc._value.append(2)
    assert len(dsc) == 2
    # Negative testing
    dsc._value = 42
    try:
        len(dsc)
    except Exception as e:
        assert e.message == "object of type 'int' has no len()"


# Generated at 2022-06-22 13:42:18.355852
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 13:42:21.520121
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'a', 'b')[2] == 3


# Generated at 2022-06-22 13:42:23.173779
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    return _DeprecatedSequenceConstant(value=1, msg='test', version='test')


# Generated at 2022-06-22 13:42:36.322229
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('ZOO', False) is None
    assert set_constant('ZOO', True) is None
    assert set_constant('ZOO', None) is None
    assert set_constant('ZOO', []) is None
    assert set_constant('ZOO', {}) is None
    assert set_constant('ZOO', 0) is None
    assert set_constant('ZOO', 1) is None
    assert set_constant('ZOO', 0.1) is None
    assert set_constant('ZOO', 0.0) is None
    assert set_constant('ZOO', "string") is None

# Generated at 2022-06-22 13:42:42.142488
# Unit test for function set_constant
def test_set_constant():
    def _set_constant(name, value, export=vars()):
        return set_constant(name, value, export)

    _set_constant('a', True)
    assert a is True
    _set_constant('b', True, locals())
    assert b is True
    _set_constant('c', True, globals())
    assert c is True



# Generated at 2022-06-22 13:42:55.014266
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common.text.converters import to_bytes, to_native
    set_constant('TEST_CONSTANT', 'TEST', export=vars())
    # variables is a module variable, not a function variable
    assert vars()['TEST_CONSTANT'] == 'TEST'

    # Test the type conversion, see issue #38805
    set_constant('TEST_CONSTANT', to_bytes(u'TEST', 'utf-8', nonstring='passthru'), export=vars())
    assert vars()['TEST_CONSTANT'] == 'TEST'
    set_constant('TEST_CONSTANT', to_native('TEST'), export=vars())
    assert vars()['TEST_CONSTANT'] == 'TEST'

# Generated at 2022-06-22 13:42:56.163984
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = ['a', 'b', 'c']
    x = _DeprecatedSequenceConstant(x, 'msg', 'version')
    assert len(x) == 3


# Generated at 2022-06-22 13:43:02.294788
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    # When retrieving first item
    assert test_obj[0] == 1
    # When retrieving last item
    assert test_obj[2] == 3
    # When retrieving out of range index
    try:
        test_obj[3]
        assert False
    except IndexError:
        assert True

# Generated at 2022-06-22 13:43:08.064850
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def assert_type(value, expected_type):
        assert isinstance(value, expected_type)

    assert_type(_DeprecatedSequenceConstant(range(5), 'msg', 'version'), _DeprecatedSequenceConstant)

    # test __len__
    len(_DeprecatedSequenceConstant(range(5), 'msg', 'version'))

    # test __getitem__
    _DeprecatedSequenceConstant(range(5), 'msg', 'version')[0]

# Generated at 2022-06-22 13:43:10.455256
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('FOO', 'BAR') == globals()

# Generated at 2022-06-22 13:43:22.631206
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    DEFAULT = [
        'ansible.module_utils.basic.AnsibleModule',
        'ansible.module_utils.urls.open_url',
        'ansible.module_utils.urls.fetch_url',
        'ansible.module_utils.basic.AnsibleFallbackNotFound',
    ]
    assert sorted(_DeprecatedSequenceConstant(DEFAULT, msg="", version="2.10").__getitem__(slice(None))) == sorted(DEFAULT)
    assert _DeprecatedSequenceConstant(DEFAULT, msg="", version="2.10").__getitem__(-1) == 'ansible.module_utils.basic.AnsibleFallbackNotFound'

# Generated at 2022-06-22 13:43:31.672515
# Unit test for function set_constant
def test_set_constant():
    values = dict(
        foo='bar',
        baz=5,
        lst=[1, 2, 3],
        tup=('c', 'd', 'e'),
        dct=dict(a='foo', b='bar'),
        num=5.0,
    )

    for k, v in values.items():
        set_constant(k, v)

    for k, v in values.items():
        assert vars()[k] == v

# Generated at 2022-06-22 13:43:37.413280
# Unit test for function set_constant
def test_set_constant():
    const_data = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {'foo': 'bar'},
    }

    export = {}
    for name, value in const_data.items():
        set_constant(name, value, export)

    # Check if the values are set in the export dict
    for name, value in const_data.items():
        assert name in export
        assert export[name] == value

# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-22 13:43:51.519004
# Unit test for function set_constant
def test_set_constant():
    from tempfile import mkdtemp
    from shutil import rmtree
    import os


# Generated at 2022-06-22 13:43:55.060813
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(value=[], msg='test message', version='1.9')
    assert dsc is not None
    assert len(dsc) == 0
    assert dsc[0] is None



# Generated at 2022-06-22 13:44:03.653417
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 1, vars())  # pylint: disable=undefined-variable
    assert foo == 1, 'basic set_constant failed'

    set_constant('bar', '{{ 1 + 2 }}', vars())  # pylint: disable=undefined-variable
    assert bar == 3, 'set_constant template failed'

    set_constant('baz', '{{ 1 + x }}', {'x': 2})
    assert baz == 3, 'set_constant func arg override fail'

# Generated at 2022-06-22 13:44:08.127920
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(value=[1,2,3], msg="fake message", version="1.0")
    assert test[0] == 1
    assert test[1] == 2
    assert test[2] == 3
    assert len(test) == 3

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:44:10.742164
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    klass = _DeprecatedSequenceConstant(value=[], msg='', version='')
    assert len(klass) == 0

# Generated at 2022-06-22 13:44:14.387311
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected = len(CONFIGURABLE_PLUGINS) + len(_ACTION_ALL_INCLUDE_TASKS)
    actual = len(_DeprecatedSequenceConstant(CONFIGURABLE_PLUGINS + _ACTION_ALL_INCLUDE_TASKS, "", ""))
    assert actual == expected

# Generated at 2022-06-22 13:44:19.386968
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # "a, b" -> list with two strings: "a" and "b"
    x = _DeprecatedSequenceConstant(value=["a", "b"], msg="test", version="1.0")
    assert x[0] == "a"
    assert x[1] == "b"
    assert x[-1] == "b"
    assert x[-2] == "a"
    assert x[0:1] == ["a"]
    assert x[1:2] == ["b"]

# Generated at 2022-06-22 13:44:30.796193
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'


COMMON_CONNECTION_VARS = _DeprecatedSequenceConstant(COMMON_CONNECTION_VARS, 'COMMON_CONNECTION_VARS is deprecated and will be removed in 2.8', '2.8')
CONFIGURABLE_PLUGINS = _DeprecatedSequenceConstant(CONFIGURABLE_PLUGINS, 'CONFIGURABLE_PLUGINS is deprecated and will be removed in 2.8', '2.8')
DEPRECATED_BOOLEANS = _DeprecatedSequenceConstant(BOOLEANS_TRUE, 'DEPRECATED_BOOLEANS is deprecated and will be removed in 2.8', '2.8')

# Generated at 2022-06-22 13:44:33.101944
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant('ABCDE', 'foo', '1.3')
    assert len(seq) == 5



# Generated at 2022-06-22 13:44:44.145868
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class FakeDisplay:
        def warning(self, msg):
            fake_msg = "foo"
            assert msg == fake_msg

    import sys

    _save_display = sys.modules.get('ansible.utils.display')
    sys.modules['ansible.utils.display'] = FakeDisplay()

    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'bar', '2.5')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    sys.modules.pop('ansible.utils.display')

    if _save_display:
        sys.modules['ansible.utils.display'] = _save_display



# Generated at 2022-06-22 13:44:59.698449
# Unit test for function set_constant
def test_set_constant():
    assert type(DEFAULT_BECOME_PASS) is str
    assert type(DEFAULT_PASSWORD_CHARS) is str
    assert type(DEFAULT_REMOTE_PASS) is str
    assert type(DEFAULT_SUBSET) is str
    assert type(TREE_DIR) is str
    assert type(VAULT_VERSION_MAX) is float
    assert type(VAULT_VERSION_MIN) is float
    assert type(__version__) is str
    assert type(DEFAULT_ASK_PASS) is bool
    assert type(DEFAULT_KEEP_REMOTE_FILES) is bool
    assert type(DEFAULT_NO_LOG) is bool
    assert type(DEFAULT_NO_TARGET_SYSLOG) is bool
    assert type(DEFAULT_SUDO_PASS) is str
    assert type

# Generated at 2022-06-22 13:45:03.064951
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(['x'], 'msg', '1.0')
    assert len(obj) == 1

# Generated at 2022-06-22 13:45:06.022815
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(('item1', 'item2'), 'should be ignored', 'the same version')
    assert len(c) == 2



# Generated at 2022-06-22 13:45:08.186208
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test', 0, {}) == {}
    assert set_constant('test', 0) == vars()

# Generated at 2022-06-22 13:45:20.395401
# Unit test for function set_constant
def test_set_constant():
    def check(name, expected_value, export):
        assert export[name] == expected_value, "host_record_as_fact set to %s instead of %s" % (str(export[name]), expected_value)

    set_constant('host_record_as_fact', 'yes', export=vars())
    check('host_record_as_fact', True, vars())
    set_constant('host_record_as_fact', 'no', export=vars())
    check('host_record_as_fact', False, vars())

# END OF CONSTANTS ###


# COMPILE REGEX ENTRIES ###
INVALID_INTERNAL_NAMES = re.compile(r'^__.+__$')
_COMPILED_INTERPRETER_PATTERNS = []


# Generated at 2022-06-22 13:45:26.079914
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence_constant = _DeprecatedSequenceConstant((1, 2, 3), 'test', 'test')
    assert len(sequence_constant) == 3
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'test', 'test')
    assert len(sequence_constant) == 3


# Generated at 2022-06-22 13:45:32.222285
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'ansible_connection will be replaced by connection'
    version = '2.10'
    value = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(value) == 3
    assert value[2] == 'c'
    assert value[:2] == ['a', 'b']
    assert value + [4, 5] == ['a', 'b', 'c', 4, 5]
    assert value * 2 == ['a', 'b', 'c', 'a', 'b', 'c']
    assert 3 in value
    assert 'b' in value

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:45:35.393855
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert 1 == len(_DeprecatedSequenceConstant([1, 2, 3], "a", "b"))
    assert 2 == _DeprecatedSequenceConstant([1, 2, 3], "a", "b")[1]

# Generated at 2022-06-22 13:45:48.109414
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(ANSIBLE_NOCOLOR, bool)
    assert isinstance(ANSIBLE_FORCE_COLOR, bool)

if ANSIBLE_FORCE_COLOR:
    C.DEFAULT_STDOUT_CALLBACK = 'yaml'
    C.DEFAULT_STDOUT_CALLBACK = 'minimal'

if not ANSIBLE_NOCOLOR:
    try:
        from ansible.plugins.callback.default import CallbackModule
        C.DEFAULT_STDOUT_CALLBACK = 'yaml'
    except Exception:
        # we don't want errors to prevent nocolor from working
        pass
else:
    C.DEFAULT_STDOUT_CALLBACK = 'minimal'

# NOTE: LEGACY_VAULT_PASSWORD_FILE in ansible.cfg is handled
#       in lib/ans

# Generated at 2022-06-22 13:45:54.457563
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = ('val1', 'val2')
    msg = 'msg'
    version = 'version'
    dst = _DeprecatedSequenceConstant(seq, msg, version)
    assert dst._value == seq
    assert dst._msg == msg
    assert dst._version == version
    assert dst[0] == seq[0]
    assert dst[1] == seq[1]
    assert len(dst) == len(seq)


# Generated at 2022-06-22 13:46:11.504664
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test that it works for a __len__ of 0
    c = _DeprecatedSequenceConstant([], '', '')
    assert len(c) == 0

    # Test that it works for a __len__ of 1
    c = _DeprecatedSequenceConstant([1], '', '')
    assert len(c) == 1
    assert c[0] == 1

    # Test that it works for a __len__ of greater than 1
    c = _DeprecatedSequenceConstant([1, 2, 3, 4], '', '')
    assert len(c) == 4
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3
    assert c[3] == 4
    assert c[-5] == 1
    assert c[-4] == 2

# Generated at 2022-06-22 13:46:17.659387
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constants_module = __import__('ansible.constants')
    assert isinstance(_DeprecatedSequenceConstant(constants_module.MODULE_REQUIRE_ARGS, 'Backport of deprecation warning for MODULE_REQUIRE_ARGS', '2.9'), _DeprecatedSequenceConstant)



# Generated at 2022-06-22 13:46:21.002580
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(constant) == 3
    assert constant[0] == 1

# Generated at 2022-06-22 13:46:25.096369
# Unit test for function set_constant
def test_set_constant():
    const_dict = {}
    set_constant('const_int', 5, export=const_dict)
    set_constant('const_str', 'value', export=const_dict)
    assert const_dict.get('const_int', None) == 5
    assert const_dict.get('const_str', None) == 'value'

# Generated at 2022-06-22 13:46:29.483450
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg='test', version='test')) == 0
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='test')) == 3


# Generated at 2022-06-22 13:46:32.509672
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 5)
    assert vars()['test_constant'] == 5


# FIXME: replace with constants
HOSTVARS_VARIABLE = u'hostvars'

# Generated at 2022-06-22 13:46:36.315248
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    with pytest.raises(SystemExit):
        _DeprecatedSequenceConstant(('string', ), 'msg', 'version').__len__()


# Generated at 2022-06-22 13:46:48.343689
# Unit test for function set_constant
def test_set_constant():
    '''
    The first test sets constants using set_constant
    The second test uses a different method and confirms the constants are not equal
    '''

    CONSTANTS_TEST = {}
    set_constant("ANSIBLE_TEST", "ANSIBLE_TEST", CONSTANTS_TEST)

    assert(CONSTANTS_TEST['ANSIBLE_TEST'] == "ANSIBLE_TEST")
    assert(CONSTANTS_TEST != globals())


# Fixup any false-ish values that should actually be None

if not DEFAULT_BECOME_PASS:
    DEFAULT_BECOME_PASS = None
if not DEFAULT_REMOTE_PASS:
    DEFAULT_REMOTE_PASS = None

# verify that the vault IDs in the config file are valid
vault_ids = []


# Generated at 2022-06-22 13:46:51.751686
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testvalue = [1,2,3]
    constant = _DeprecatedSequenceConstant(testvalue, "message", "version")
    assert len(constant) == len(testvalue)
    assert len(constant) == 3

# Generated at 2022-06-22 13:46:59.754364
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    fake_value = None
    fake_msg = None
    fake_warning = None
    fake_version = None
    test_object = _DeprecatedSequenceConstant(fake_value, fake_msg, fake_version)
    assert test_object is not None
    assert fake_value == test_object._value
    assert fake_msg == test_object._msg
    assert fake_version == test_object._version
    assert hasattr(test_object, '__len__')


# Generated at 2022-06-22 13:47:14.576651
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(
        value=['a','b','c'], msg='Test', version='2.8'
    )
    assert len(x) == 3
    assert x[1] == 'b'

# Generated at 2022-06-22 13:47:19.201562
# Unit test for function set_constant
def test_set_constant():
    _TEST_VARS = {}
    set_constant('name', 'value', export=_TEST_VARS)
    assert _TEST_VARS.get('name') == 'value'


# FIXME: Remove with migration of PlayContext to Config

# Generated at 2022-06-22 13:47:26.151144
# Unit test for function set_constant
def test_set_constant():
    # 0. Normal path test to ensure deployment of a variable works.
    set_constant('test_var', 'test_value')
    assert 'test_value' == globals()['test_var']

    # 1. Test that a variable is not overwritten while deployed.
    set_constant('test_var', 'test_value_1')
    assert 'test_value_1' == globals()['test_var']


if __name__ == "__main__":
    test_set_constant()

# Generated at 2022-06-22 13:47:29.199783
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant('test', 'test warn', '3.0')
    assert(constant[0] == 'test')

# Generated at 2022-06-22 13:47:40.746851
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Display:
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings += [msg]

    class A:
        C = _DeprecatedSequenceConstant("v", "m", "1")

        def B(self, v=""):
            self.C[0] = v

    a = A()
    a.B()
    assert a.C[0] == "v"

    d = Display()
    A.B = Display().deprecated("m", version="1")
    a.B()
    assert a.C[0] == "v"
    assert a.warnings == [' [DEPRECATED] m, to be removed in 1']

# Generated at 2022-06-22 13:47:43.921499
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "a message"
    version = "2.0"
    d = _DeprecatedSequenceConstant([1, 2 ,3], msg, version)
    assert len(d) == 3



# Generated at 2022-06-22 13:47:53.812363
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    class TempClass(_DeprecatedSequenceConstant):
        def __init__(self, name, value, msg, version, module_name):
            super(TempClass, self).__init__(value=value, msg=msg, version=version)
            self._name = name
            self._module_name = module_name

        def __iter__(self):
            _deprecated(self._msg, self._version)
            return iter(self._value)

        def _is_boolean(self, value):
            return value in BOOLEANS_TRUE

        def _is_string(self, value):
            return isinstance(value, string_types)

        def _is_dict(self, value):
            return isinstance(value, dict)


# Generated at 2022-06-22 13:48:00.807265
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest

    example_old_value = "blah"
    example_new_value = "foo"
    example_message = "This is a test"
    example_msg = "This is a test"
    example_version = "2.2"
    test_obj = _DeprecatedSequenceConstant(example_old_value, example_msg, example_version)
    assert test_obj[0] == example_old_value
    test_obj = _DeprecatedSequenceConstant(example_new_value, example_msg, example_version)
    with pytest.warns(DeprecationWarning):
        assert test_obj[0] == example_new_value

# Generated at 2022-06-22 13:48:10.139322
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MyTest:
        def __init__(self):
            self.messages = list()

        def deprecated(self, msg, version):
            self.messages.append(msg)

    mt = MyTest()

    # Test that it works with a list
    t = _DeprecatedSequenceConstant(list(), u'my message', u'my version')
    assert t[1] == None
    assert len(mt.messages) == 0

    # Test that it works with a tuple
    t = _DeprecatedSequenceConstant(tuple(), u'my message', u'my version')
    assert t[1] == None
    assert len(mt.messages) == 0

# Generated at 2022-06-22 13:48:22.328633
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    my_sequence = ['value1', 'value2', 'value3']
    my_sequence_constant = _DeprecatedSequenceConstant(my_sequence, 'this is a warning', 2.10)
    assert my_sequence[0] == my_sequence_constant[0]
    assert my_sequence[1] == my_sequence_constant[1]
    assert my_sequence[2] == my_sequence_constant[2]
    assert my_sequence[-1] == my_sequence_constant[-1]
    assert my_sequence[-2] == my_sequence_constant[-2]
    assert my_sequence[-3] == my_sequence_constant[-3]
    assert my_sequence[1:3] == my_sequence_constant[1:3]

# Generated at 2022-06-22 13:48:50.453162
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert 3 == len(x)

# Generated at 2022-06-22 13:48:56.058912
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2]
    msg = "This is deprecated"
    version = "2.9.0"
    sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert sequence_constant[0] == 1

# Generated at 2022-06-22 13:49:00.037481
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'warning', '2.9')
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3
    assert len(c) == 3


# Generated at 2022-06-22 13:49:04.313739
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sample = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(sample, msg='foo', version='2.8')
    assert len(dsc) == len(sample)
    assert dsc[1] == sample[1]

# Generated at 2022-06-22 13:49:09.392625
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    value = (2, 3)
    msg = "Hello World"
    version = "2.9"
    constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(constant) == len(value)
    assert constant[0] == value[0]
    assert constant[1] == value[1]

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 13:49:14.720444
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''Unit test for constructor of class _DeprecatedSequenceConstant'''
    sequence = ["foo", "bar"]
    dep_sequence = _DeprecatedSequenceConstant(sequence, msg='This is a test', version='2.10')

    assert dep_sequence._value == sequence
    assert dep_sequence._msg == 'This is a test'
    assert dep_sequence._version == '2.10'


# Generated at 2022-06-22 13:49:19.194430
# Unit test for function set_constant
def test_set_constant():
    DUMMY_VALUE = 'dummy_value'
    DUMMY_NAME = 'dummy_name'
    set_constant(DUMMY_NAME, DUMMY_VALUE)
    assert vars()[DUMMY_NAME] == DUMMY_VALUE

# Generated at 2022-06-22 13:49:21.507887
# Unit test for function set_constant
def test_set_constant():
    import sys

    set_constant('test_constant', True, sys.modules[__name__].__dict__)
    assert test_constant is True

# Generated at 2022-06-22 13:49:26.918438
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test_sequence__DeprecatedSequenceConstant(self):
            self.assertEqual(len(_DeprecatedSequenceConstant((1, 2, 3), msg="msg", version="version")), 3)
            self.assertEqual(_DeprecatedSequenceConstant((1, 2, 3), msg="msg", version="version")[2], 3)
    unittest.main()

# Generated at 2022-06-22 13:49:32.739088
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(None, '', '')

    # Unit test for method __init__
    assert isinstance(test, Sequence)

    # Unit test for method __len__
    assert test.__len__() == 0

    # Unit test for method __getitem__
    assert test.__getitem__(None) is None


# Generated at 2022-06-22 13:50:24.333087
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(value=1, msg='my_msg', version='my_version')
    assert len(c) == 1


# Generated at 2022-06-22 13:50:26.218408
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1,2], 'msg', 'version')
    assert len(constant) == 2


# Generated at 2022-06-22 13:50:29.812166
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(value=1, msg='test msg', version='test ver')

# Generated at 2022-06-22 13:50:31.636961
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert len(dsc) == 3

# Generated at 2022-06-22 13:50:33.433572
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant('abc', 'xyz', '1.0')
    assert obj[0] == 'a'

# Generated at 2022-06-22 13:50:34.938342
# Unit test for function set_constant
def test_set_constant():
    set_constant('MY_CONSTANT', 42)
    assert MY_CONSTANT == 42