

# Generated at 2022-06-22 13:40:45.246632
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def test(value, version, msg):
        val = _DeprecatedSequenceConstant(value, msg, version)
        assert val._value == value
        assert val._msg == msg
        assert val._version == version

    test([], "2.0", "deprecated message")
    test(["a", "b"], "2.1", "deprecated message")

# Generated at 2022-06-22 13:40:54.576915
# Unit test for function set_constant
def test_set_constant():

    conf = dict(
        ANSIBLE_CONFIG='foo.yml',
        DEFAULT_HOST_LIST='bar.txt',
        UNKNOWN_VARIABLE='FOO',  # this variable should not be set
    )

    # reset the config's WARNINGS, since we're testing warnings below
    config.WARNINGS = []

    for key in config.data.get_settings():
        set_constant(key.name, key.value, conf)
    assert len(config.WARNINGS) == 0
    assert conf['ANSIBLE_CONFIG'] == ANSIBLE_CONFIG
    assert conf['DEFAULT_HOST_LIST'] == DEFAULT_HOST_LIST
    assert 'UNKNOWN_VARIABLE' not in conf

# Generated at 2022-06-22 13:40:56.472970
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert len(c) == 2


# Generated at 2022-06-22 13:41:04.215491
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.display import Display
    display = Display()
    assert _DeprecatedSequenceConstant(range(1, 3), 'some message', '2.0').__getitem__(0) == range(1, 3).__getitem__(0)
    assert _DeprecatedSequenceConstant(range(1, 3), 'some message', '2.0').__getitem__(0) == range(1, 3).__getitem__(0)
    assert display.deprecated.call_count == 2

# Generated at 2022-06-22 13:41:07.917422
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """test the __getitem__ method of class _DeprecatedSequenceConstant"""
    d = _DeprecatedSequenceConstant('a', 'test', '2.9')
    assert d[0] == 'a'

# unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:41:14.916340
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    val = _DeprecatedSequenceConstant([1, 2, 3], 'warn msg', 'version')
    assert val[0] == 1
    assert val[1] == 2
    assert val[2] == 3
    try:
        val[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 13:41:17.888898
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='test msg', version='1.2.3')) == 3

# Generated at 2022-06-22 13:41:24.866776
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'foo')
    assert 'FOO' in globals(), globals()
    assert globals()['FOO'] == 'foo'
    set_constant('BAR', 42)
    assert 'BAR' in globals(), globals()
    assert globals()['BAR'] == 42


# Generated at 2022-06-22 13:41:28.684889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep_list = _DeprecatedSequenceConstant([1, 3, 7], 'Unit test message', '1.0')
    assert len(dep_list) == 3
    assert dep_list[2] == 7

# Generated at 2022-06-22 13:41:41.951482
# Unit test for function set_constant

# Generated at 2022-06-22 13:41:49.584796
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['test']
    msg = 'msg'
    version = '1.2.3'
    d = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(d, Sequence)
    assert callable(d.__len__)
    assert d.__len__() == 1
    assert len(d) == 1

# Generated at 2022-06-22 13:41:55.670720
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var = _DeprecatedSequenceConstant(value='10', msg='test message', version='version 2')
    assert len(var) == 2
    assert var[1] == '0'

# Note: the following are deprecated dicts for legacy reasons, but should be
# removed in Ansible 2.3. The code in the config manager should be used now
# instead.

# For full information, see the :ref:`configuration file docs<setting-file-locations>`.

#: Configuration/runtime options for Ansible itself.
#: .. deprecated:: 2.2
#:    Use `ansible.config.manager.ConfigManager.get_config_obj` instead
settings = config.get_config_obj()

#: Configuration/runtime options for Ansible plugins.
#: .. deprecated:: 2.2
#:    Use `ansible

# Generated at 2022-06-22 13:41:57.628845
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'Error', 'version')) == 3

# Generated at 2022-06-22 13:42:02.016323
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(value=['a','b','c'],msg='This is a test', version='original')
    try:
        len(test_obj)
        assert False
    except:
        assert True

# Generated at 2022-06-22 13:42:08.032950
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], 'Message', '2.3')._value == []
    assert _DeprecatedSequenceConstant([], 'Message', '2.3')._msg == 'Message'
    assert _DeprecatedSequenceConstant([], 'Message', '2.3')._version == '2.3'

# Generated at 2022-06-22 13:42:13.264330
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def test(a, b):
        assert a == b
        print('.', end='')

    test(len( _DeprecatedSequenceConstant( (1, 2), "msg", "version") ), 2)
    print()

# Testcase for class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:42:14.757312
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1], 'msg', 'version')) == 1

# Generated at 2022-06-22 13:42:17.810056
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant([0, 1, 2], "test_msg", "test_version")
    assert len(test_obj) == 3


# Generated at 2022-06-22 13:42:20.433642
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'foo'
    version = '1.0'
    value = 'foo'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert value == test_obj[0]

# Generated at 2022-06-22 13:42:24.873580
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "Test message"
    version = "Test version"
    dsc = _DeprecatedSequenceConstant(("a", "b"), msg, version)

    assert 'b' == dsc[1]
    assert dsc[0] == 'a'



# Generated at 2022-06-22 13:42:38.180744
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(seq) == 3
    assert seq[1] == 2


# Generated at 2022-06-22 13:42:40.780950
# Unit test for function set_constant
def test_set_constant():

    set_constant('FOO', 'hello')

    assert FOO == 'hello'



# Generated at 2022-06-22 13:42:42.522191
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'test_deprecation_warning', '2.1')) == 2

# Generated at 2022-06-22 13:42:45.651777
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_input = _DeprecatedSequenceConstant((1, 2), 'test message', 'test version')
    assert(len(test_input) == 2)


# Generated at 2022-06-22 13:42:48.155304
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'ver')
    assert len(a) == 3

# Generated at 2022-06-22 13:43:01.259189
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test that _DeprecatedSequenceConstant is an instance of Sequence
    assert isinstance(Sequence(('a', 'b', 'c')), Sequence)
    assert isinstance(Sequence(set(['a', 'b', 'c'])), Sequence)
    assert isinstance(Sequence(('a', 'b', 'c')), type([]))
    assert isinstance(Sequence(xrange(3)), type([]))

    # Test that _DeprecatedSequenceConstant is a subclass of list
    assert issubclass(_DeprecatedSequenceConstant, Sequence)
    assert issubclass(_DeprecatedSequenceConstant, type([]))

    assert _DeprecatedSequenceConstant(('a', 'b', 'c'), "Deprecated message", "2.9")

if __name__ == "__main__":
    test__

# Generated at 2022-06-22 13:43:05.551725
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    sequences = (_DeprecatedSequenceConstant((), "", ""),
                 _DeprecatedSequenceConstant((1, 2, 3), "", ""),
                 _DeprecatedSequenceConstant(range(0, 5), "", ""))

    for sequence in sequences:
        assert len(sequence) == len(sequence._value)

# Generated at 2022-06-22 13:43:08.586989
# Unit test for function set_constant
def test_set_constant():
    ''' Ensure no constants are set to None '''
    for k, v in vars().items():
        if k.startswith('DEFAULT_'):
            if v is None:
                assert False, "Constants appear to be set to None: %s" % k

# Generated at 2022-06-22 13:43:21.665800
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', True)
    assert 'a' in vars()
    assert vars()['a'] is True

if __version__ < '2.0':
    MAGIC_VARIABLE_MAPPING['inventory_hostname'] = ('inventory_hostname',)
    MAGIC_VARIABLE_MAPPING['group_names'] = ('group_names',)
    MAGIC_VARIABLE_MAPPING['groups'] = ('groups',)

# map of deprecated option names and the replacement option names

# Generated at 2022-06-22 13:43:23.551717
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1,2,3], '', '')
    assert len(x) == 3


# Generated at 2022-06-22 13:43:37.413532
# Unit test for function set_constant
def test_set_constant():
    class Out():
        def __init__(self):
            self.result = {}

        def __setitem__(self, name, value):
            self.result[name] = value
    out = Out()
    set_constant('foo', 'bar', export=out.__dict__)
    assert out.result['foo'] == 'bar'

# Generated at 2022-06-22 13:43:42.618877
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.test.test_constants import ANSWER
    from ansible.test.test_constants import MESSAGE
    from ansible.test.test_constants import VERSION

    return isinstance(_DeprecatedSequenceConstant(ANSWER, MESSAGE, VERSION), Sequence)


# Generated at 2022-06-22 13:43:45.345482
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(list(range(1, 8)), 'test', '0.0')
    assert len(c) == 7



# Generated at 2022-06-22 13:43:56.190984
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import is_sequence

    seq_constant = _DeprecatedSequenceConstant([1, 2, 3], "something", "2.8")

    assert is_sequence(seq_constant)
    assert len(seq_constant) == 3
    assert seq_constant[0] == 1
    assert seq_constant[1] == 2
    assert seq_constant[2] == 3

module_prefix = '.ansible.module_utils.'
ACTION_PLUGIN_PATH = module_prefix + 'actions'
CACHE_PLUGIN_PATH = module_prefix + 'cache'
CALLBACK_PLUGIN_PATH = module_prefix + 'callbacks'
CLICONF_PLUGIN_PATH = module_prefix + 'cliconf'
CONNECTION_

# Generated at 2022-06-22 13:43:59.718043
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(('foo',), 'test_message', 'v1.0')
    assert len(constant) == 2

    # Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 13:44:07.258376
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    object1 = _DeprecatedSequenceConstant([1, 2], 'test', '3.0')
    len(object1)
    object1 = _DeprecatedSequenceConstant([1, 2], 'test', '3.0')
    len(object1)
    object1 = _DeprecatedSequenceConstant([1, 2], 'test', '3.0')
    len(object1)


# Generated at 2022-06-22 13:44:16.692739
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constants = _DeprecatedSequenceConstant([], 'test', '2.10')
    assert len(constants) == 0
    assert constants[0] is None


# TODO: DEPRECATION WARNING: There is a constant `ACTION_ALL_INCLUDE_IMPORT_TASKS` which is being added to the `ACTION_ALLOW_UNSAFE` constant
# for backwards compatibility. This behavior will be removed in version 2.10.

# Generated at 2022-06-22 13:44:20.786471
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version='2.8')
    assert len(obj) == 3



# Generated at 2022-06-22 13:44:23.075379
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('name', 'value', export=d)
    assert d['name'] == 'value'

# Generated at 2022-06-22 13:44:32.280058
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], "", "")) == 0
    assert len(_DeprecatedSequenceConstant(tuple(), "", "")) == 0
    assert len(_DeprecatedSequenceConstant("", "", "")) == 0
    assert len(_DeprecatedSequenceConstant({}, "", "")) == 0
    assert len(_DeprecatedSequenceConstant(1, "", "")) == 0
    assert len(_DeprecatedSequenceConstant(False, "", "")) == 0
    assert len(_DeprecatedSequenceConstant(True, "", "")) == 0
    assert len(_DeprecatedSequenceConstant({'key': 'value'}, "", "")) == 0


# Generated at 2022-06-22 13:44:59.551841
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ["a", "b", "c", "d", "e"]
    test_instance = _DeprecatedSequenceConstant(test_list, 'test_msg', '2.0')
    assert len(test_list) == len(test_instance)


# Generated at 2022-06-22 13:45:03.816800
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], msg='test', version='test')
    assert len(test_object) == 3
    assert test_object[0] == 1


# Generated at 2022-06-22 13:45:07.925422
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    val = [1, 2, 3]
    msg = 'TEST MESSAGE'
    version = 'v1.0'
    s = _DeprecatedSequenceConstant(val, msg, version)
    assert len(s) == 3



# Generated at 2022-06-22 13:45:11.373392
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'test_DeprecatedSequenceConstant_len'
    version = '2.2'
    assert len(_DeprecatedSequenceConstant([1,2,3], msg, version)) == 3


# Generated at 2022-06-22 13:45:14.817526
# Unit test for function set_constant
def test_set_constant():
    set_constant("ANSIBLE_INVENTORY", "inventory.py")
    assert ANSIBLE_INVENTORY != "inventory.py"

# Generated at 2022-06-22 13:45:26.334338
# Unit test for function set_constant
def test_set_constant():
    import os
    import tempfile
    global TREE_DIR
    if not TREE_DIR:
        TREE_DIR = tempfile.mkdtemp()
    os.chdir(TREE_DIR)

    def clean_global_constant(name):
        global TREE_DIR
        if name in globals():
            del globals()[name]

    # check that string value is converted to bool
    clean_global_constant(u'FOO')
    set_constant(u'FOO', u'True')
    assert isinstance(FOO, bool)

    # check that string value is converted to int
    clean_global_constant(u'FOO')
    set_constant(u'FOO', u'42')
    assert isinstance(FOO, int)

    # check that string value is preserved

# Generated at 2022-06-22 13:45:28.010522
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = to_text("msg")
    version = to_text("version")
    expected = to_text("expected")
    result = _DeprecatedSequenceConstant(expected, msg, version)
    assert result[0] == expected


# Generated at 2022-06-22 13:45:30.621488
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = ['apple', 'banana']
    a = _DeprecatedSequenceConstant(l, 'example message', '2.10')
    assert a[0] == 'apple'
    assert a[1] == 'banana'



# Generated at 2022-06-22 13:45:35.075264
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_dsc = _DeprecatedSequenceConstant(
        value=['a', 'b', 'c', 'd'],
        msg='foo message',
        version='bar version'
    )
    assert 4 == len(test_dsc)

# Generated at 2022-06-22 13:45:38.207346
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    v = _DeprecatedSequenceConstant([1, 2], '', '')
    assert v[0] == 1
    assert v[-1] == 2



# Generated at 2022-06-22 13:46:48.470697
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    import sys
    import os

    old_stderr = sys.stderr
    old_color = Display.COLORS
    sys.stderr = open(os.devnull, 'w')
    Display.COLORS = False

# Generated at 2022-06-22 13:46:51.920748
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    print(_DeprecatedSequenceConstant([], '', '')[0])
    try:
        print(_DeprecatedSequenceConstant([], '', '')[1])
    except IndexError:
        print('OK')


# Generated at 2022-06-22 13:46:57.041935
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Make sure that Sequence constant is accessible by index
    result = _ACTION_ALL_INCLUDE_IMPORT_TASKS[0]
    assert result.startswith("ansible.builtin.include")



# Generated at 2022-06-22 13:47:09.616851
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Constant _ACTION_DEBUG__GET_ITEM__ as a sequence
    ACTION_DEBUG_SEQ = list(_ACTION_DEBUG)

    # Instantiate _DeprecatedSequenceConstant with _ACTION_DEBUG
    # and a message
    MSG = 'Test _DeprecatedSequenceConstant.__getitem__()'
    _DEPR_SEQ_CONST = _DeprecatedSequenceConstant(ACTION_DEBUG_SEQ, MSG, '2.6')

    # Call the method under test
    RES = _DEPR_SEQ_CONST[0]

    # Verify the result
    assert RES == ACTION_DEBUG_SEQ[0], \
        'Error, the result differs from the expected value'

    # Verify that the warning was displayed
    assert _warning.called, \
        'Error, warning was not displayed by the method'

   

# Generated at 2022-06-22 13:47:14.621119
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_name = 'var_name'
    msg = 'this is a test message'
    version = '1.0'

    # Test if class _DeprecatedSequenceConstant works.
    obj = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert len(obj) == 3


# Generated at 2022-06-22 13:47:17.880790
# Unit test for function set_constant
def test_set_constant():
    class _ExportClass():
        pass

    export = _ExportClass()
    set_constant('foo', 'bar', export=export)
    assert export.foo == 'bar'

# Generated at 2022-06-22 13:47:27.587057
# Unit test for function set_constant
def test_set_constant():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    d = {}
    set_constant('CONFIG_WARNINGS', ['warning1', 'warning2'], export=d)
    assert d['CONFIG_WARNINGS'] == ['warning1', 'warning2']
    set_constant('CONFIG_WARNINGS', AnsibleUnsafeText('test'), export=d)
    assert isinstance(d['CONFIG_WARNINGS'], AnsibleUnsafeText)
    assert d['CONFIG_WARNINGS'] == 'test'
    set_constant('DEFAULT_BECOME_PASS', None, export=d)
    assert d['DEFAULT_BECOME_PASS'] is None
    set_constant('DEFAULT_BECOME_PASS', '{{ ansible_become_pass }}', export=d)


# Generated at 2022-06-22 13:47:30.168592
# Unit test for function set_constant
def test_set_constant():
    test_constant = 'A string'
    set_constant('CONSTANT', test_constant, vars())

    assert vars()['CONSTANT'] == test_constant

# Generated at 2022-06-22 13:47:35.179774
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Create an instance of class _DeprecatedSequenceConstant
    test_seq = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', '2.10')

    # Test method __len__
    assert len(test_seq) == 3



# Generated at 2022-06-22 13:47:43.839408
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(("test1", "test2"), "test", "test") == ("test1", "test2")
    assert _DeprecatedSequenceConstant(("test1", "test2"), "test", "test")._value == ("test1", "test2")
    assert _DeprecatedSequenceConstant(("test1", "test2"), "test", "test")._msg == "test"
    assert _DeprecatedSequenceConstant(("test1", "test2"), "test", "test")._version == "test"

# Generated at 2022-06-22 13:48:51.985635
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_msg = 'This message is for test __len__'
    test_version = '1.0'
    test_value = [1, 2, 3]
    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_value) == len(test_instance)


# Generated at 2022-06-22 13:48:59.549236
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('FOO', 'BAR', constants)
    assert constants['FOO'] == 'BAR'


if DEFAULT_BECOME_PASS is None:
    DEFAULT_BECOME_PASS = DEFAULT_PASSWORD
if DEFAULT_REMOTE_PASS is None:
    DEFAULT_REMOTE_PASS = DEFAULT_PASSWORD

# FIXME: remove after deprecation

# Generated at 2022-06-22 13:49:02.637099
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.0')) == 3


# Generated at 2022-06-22 13:49:05.226121
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant((1, 2, 3), 'dummy warning', '1.0.1')
    assert len(seq) == 3



# Generated at 2022-06-22 13:49:07.662351
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(value=('one', 'two'), msg='test', version='1.0')
    assert len(constant) == 2


# Generated at 2022-06-22 13:49:09.644346
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], 'msg', '1.0')) == 2

# Generated at 2022-06-22 13:49:20.295018
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Unit test to check that the _DeprecatedSequenceConstant class adds a deprecation notice
    # if the __getitem__ method is called on a sequence constant
    #
    # This method will generate a deprecation notice and test that it is generated.

    # Create a sequence constant
    test_sequence_constant = _DeprecatedSequenceConstant(['fake_value_1', 'fake_value_2'], 'test_msg', 'test_version')

    # Ask for an item in the sequence. The deprecation notice should be generated
    # by this command.
    test_item = test_sequence_constant.__getitem__(0)

    # Check that the item returned is the one expected, which is 'fake_value_1'
    assert test_item == 'fake_value_1'



# Generated at 2022-06-22 13:49:24.234344
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'This is a test message'
    version = '2.14'
    value = [1, 2, 3]
    deprecated_constant = _DeprecatedSequenceConstant(value, msg, 'version')
    assert len(value) == len(deprecated_constant)


# Generated at 2022-06-22 13:49:30.774754
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class FakeDisplay():
        def __init__(self):
            self.displayed_data = []

        def deprecated(self, msg, version=None):
            self.displayed_data.append((msg, version))

    display = FakeDisplay()
    replacement_constant_value = _DeprecatedSequenceConstant(['test1', 'test2'], 'The value is going to be replaced in 2.11', '2.11')
    assert replacement_constant_value[1] == 'test2'
    assert display.displayed_data[0][0] == 'The value is going to be replaced in 2.11'
    assert display.displayed_data[0][1] == '2.11'



# Generated at 2022-06-22 13:49:36.818228
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'testing'
    test_version = 1.0
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == len(test_value)
    assert test_object[0] == test_value[0]
    assert test_object[2] == test_value[2]