

# Generated at 2022-06-20 13:43:43.993712
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Test __getitem__ of _DeprecatedSequenceConstant"""
    test_item = 'test_item'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_class = _DeprecatedSequenceConstant([test_item], test_msg, test_version)
    assert test_class[0] == test_item


# Generated at 2022-06-20 13:43:54.198527
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """
    :return:
    """
    msg = "test_msg"
    version = "2017.3.7"
    test_value = ("t1", "t2")
    test_dsc = _DeprecatedSequenceConstant(test_value, msg, version)
    assert test_dsc.__len__() == 2
    assert test_dsc.__getitem__(1) == "t2"



# Generated at 2022-06-20 13:43:57.049048
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant(['a'], '', '2.0')[0]
    assert result == 'a', '_DeprecatedSequenceConstant.__getitem__() should return "a"'

# Generated at 2022-06-20 13:44:00.033959
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3, 4]
    test_msg = "a deprecated msg"
    test_version = "2.7.0"
    test_deprecated_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_value) == len(test_deprecated_constant)


# Generated at 2022-06-20 13:44:08.700489
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.six import assertCountEqual
    from ansible.utils._text import to_text

    def compare_result(result, expected):
        #assertCountEqual is not used as it can't be used for strings
        for value in expected:
            assert value in result, 'Unexpected value. Expected one of {} but got {}'.format(expected, result)
        for value in result:
            assert value in expected, 'Unexpected value. Expected one of {} but got {}'.format(expected, result)

    value = ['foo', 'bar']
    obj = _DeprecatedSequenceConstant(value, 'A warning', '2.10')
    assert isinstance(obj, Sequence)
    compare_result(obj[0], ['foo'])


# Generated at 2022-06-20 13:44:12.845049
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_instance = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='warning!', version='2.9')
    assert len(test_instance) == 3
    assert test_instance[0] == 1

# Generated at 2022-06-20 13:44:17.749512
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    _DeprecatedSequenceConstant: tested method __len__
    """
    sequence_constant = _DeprecatedSequenceConstant(
        ['test_value_1', 'test_value_2', 'test_value_3'], 'test_msg', 'test_version')

    assert len(sequence_constant) == 3

# Generated at 2022-06-20 13:44:22.922905
# Unit test for function set_constant
def test_set_constant():
    # Test for normal use cases
    set_constant('foo', 'normal')
    assert foo == 'normal'

    # Test for case when default value is a template
    set_constant('foo', '{{bar}}')
    assert foo == '{{bar}}'

    # Test for case when default value is a template and yaml is available
    set_constant('foo', '{{bar}}', {'bar': 'yes'})
    assert foo == 'yes'

del test_set_constant

# Generated at 2022-06-20 13:44:27.398921
# Unit test for function set_constant
def test_set_constant():
    """
    >>> constants.set_constant('foo', 'bar')
    >>> constants.foo
    'bar'
    >>> constants.set_constant('baz', [1,2,3])
    >>> constants.baz
    [1, 2, 3]
    """


# Generated at 2022-06-20 13:44:30.408955
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(['test', 1, 2], "This is a message", '2.8')
    assert len(obj) == 3
    assert obj[0] == 'test'

# Generated at 2022-06-20 13:44:41.299390
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_const = _DeprecatedSequenceConstant(
        [1, 2, 3],
        'three is deprecated',
        '2.0'
    )
    assert seq_const[1] == 2

# Generated at 2022-06-20 13:44:52.214934
# Unit test for function set_constant
def test_set_constant():
    # create a dummy function and populate it with constants
    def my_func():
        pass
    set_constant('CONST_1', 'const_1_value', my_func.__dict__)
    set_constant('CONST_2', 'const_2_value', my_func.__dict__)
    # check that it was populated and the values are correct
    assert my_func.__dict__['CONST_1'] == 'const_1_value'
    assert my_func.__dict__['CONST_2'] == 'const_2_value'

# Documentation strings for the version constants
DEFAULT_ERROR_ON_LOOKUP_ERROR_MSG = u"""
If this option is set to ``True``, lookups that fail will generate errors instead of being
ignored and returned as empty strings.
""".strip()

# Generated at 2022-06-20 13:44:58.768623
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        # Ensure the constant is defined
        if setting.scope == 'constant':
            assert setting.name in globals()
            assert globals()[setting.name] == setting.value


# function to convert a string to a bool

# Generated at 2022-06-20 13:45:01.430355
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant(tuple(), 'some message', 'some version')
    len(t)


# Generated at 2022-06-20 13:45:04.904728
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant((1, 2, 3), 'MSG', '2.9')
    assert s[0] == 1
    assert len(s) == 3

# Generated at 2022-06-20 13:45:13.602867
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils._text import to_bytes

    # test that types match as expected
    assert(type(ANSIBLE_TEST_DATA_ROOT) == type('s'))
    assert(type(ANSIBLE_TEST_DATADIR) == type('s'))
    assert(type(ANSIBLE_TEST_MODULEDIR) == type(u'u'))
    assert(type(ANSIBLE_CACHE_PLUGIN_CONN) == type('s'))
    assert(type(DEFAULT_VAULT_IDENTITY_LIST) == type([]))
    assert(type(CONFIGURABLE_PLUGINS) == type([]))

    # test that value matches

# Generated at 2022-06-20 13:45:17.759718
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    some_list = ['a', 'b', 'c']
    constants_test = _DeprecatedSequenceConstant(some_list, 'this is a test', '99.99')
    assert constants_test[0] == 'a'
    assert constants_test[1] == 'b'
    assert constants_test[2] == 'c'


# Generated at 2022-06-20 13:45:22.094745
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant((0, 1, 2), 'msg', '0.0')
    assert len(dsc) == 3


# Generated at 2022-06-20 13:45:26.079418
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    tester = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert tester[0] == 'foo'
    assert tester[1] == 'bar'
    assert tester[-1] == 'bar'


# Generated at 2022-06-20 13:45:31.934475
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check that if no errors are raised, the instance is well constructed
    _DeprecatedSequenceConstant([], '', '')

    # Check that if assign the private attribute _value a non-iterable value, an error is raised
    try:
        instance = _DeprecatedSequenceConstant('', '', '')
    except TypeError:
        pass

# Generated at 2022-06-20 13:45:47.466895
# Unit test for function set_constant
def test_set_constant():
    data = {}
    name = 'FOO'
    set_constant(name, 'bar', data)
    assert name in data


DEFAULT_UNDEFINED_VAR_BEHAVIOR = ('warn' if not config.data.get_config_value('error_on_undefined_vars') else 'error')
UNDEFINED_VAR_MSG = u"The variable file %s was not found.\n"

# FIXME: these should be added to a core callback plugin
TIMER_KEYS = ('start', 'end', 'delta', 'msg')
TIMER_DATA = {
    'start': None,
    'end': None,
    'delta': None,
    'msg': None
}


# Generated at 2022-06-20 13:45:49.310068
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    val = _DeprecatedSequenceConstant([], 'test', '2.10')
    assert len(val) == 0
    assert val[0] is None


# Generated at 2022-06-20 13:45:56.451840
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_HASH_BEHAVIOUR == 'merge'
    assert ANSIBLE_HASH_BEHAVIOUR == ANSIBLE_MERGE_BINARY_FILES

    assert ANSIBLE_MODULE_ARGS == {'extra_arg_one': True}
    assert ANSIBLE_MODULE_ARGS == ANSIBLE_MODULE_EXTRA_ARGS



# Generated at 2022-06-20 13:46:02.516556
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    const = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.1')
    assert len(const) == 3



# Generated at 2022-06-20 13:46:10.365955
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def test():
        return 'foo'
    a = _DeprecatedSequenceConstant((1, test), None, None)
    b = a[1]
    try:
        assert b() == 'foo'
    except AssertionError as e:
        raise AssertionError("'b' should return 'foo': %s" % e)


# Generated at 2022-06-20 13:46:14.853188
# Unit test for function set_constant
def test_set_constant():
    from ansible.config.manager import Setting
    from ansible import constants as C
    from ansible.module_utils.six import PY3
    import sys

    # Reset the config then create a new config with a test Setting
    config.reset()
    config.data = config._ConfigData(data=[Setting(name='DEFAULT_TEST_CONSTANT', type=str, default='', origin='default'), ])
    del C.DEFAULT_TEST_CONSTANT

    # set_constant should add a new constant to C
    set_constant('DEFAULT_TEST_CONSTANT', 'foo')
    assert C.DEFAULT_TEST_CONSTANT == 'foo'
    # set_constant should overwrite an existing constant
    set_constant('DEFAULT_TEST_CONSTANT', 'bar')

# Generated at 2022-06-20 13:46:18.735603
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '1.0')
    assert len(dsc) == 3

    # trigger the deprecated message
    assert dsc[2] == 3


# Unit tests for ConfigManager

# Generated at 2022-06-20 13:46:29.798738
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    DEPRECATED_ANSIBLE_HOST_PATTERN = 'host_regex'
    DEPRECATED_ANSIBLE_HOST_PATTERN_MSG = ('The variable "host_regex" is deprecated, use "host_pattern" instead')
    DEPRECATED_ANSIBLE_HOST_PATTERN_VERSION = '2.10'
    DEPRECATED_ANSIBLE_HOST_PATTERN_VALUE = u'^YOUR_HOSTS_DOMAIN_SUFFIX$'
    test_val = _DeprecatedSequenceConstant([DEPRECATED_ANSIBLE_HOST_PATTERN_VALUE], DEPRECATED_ANSIBLE_HOST_PATTERN_MSG, DEPRECATED_ANSIBLE_HOST_PATTERN_VERSION)
    assert test_val[0] == DE

# Generated at 2022-06-20 13:46:36.441003
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1,2,3], 'This is a _DeprecatedSequenceConstant test message.', '2.10')
    assert len(constant) == 3
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3
    assert constant[-1] == 3
    assert constant[-2] == 2
    assert constant[-3] == 1


# Generated at 2022-06-20 13:46:38.999305
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my_const = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', '2.9')
    return my_const[1] == 2 and len(my_const) == 3

# Generated at 2022-06-20 13:46:46.764825
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant(['a', 'b'], 'message', 'version_number')
    assert len(l) == 2


# Generated at 2022-06-20 13:46:56.283937
# Unit test for function set_constant
def test_set_constant():
    import sys
    import ansible
    config = ansible.cli.daemon.Config().parse()

    config.settings = {
        'iterable1': ['foo', 'bar', 'baz'],
        'iterable2': (1, 2, 3),
        'string1': 'foo',
        'string2': 'bar',
        'int1': '1234',
        'int2': '5678',
        'bool1': 'True',
        'bool2': 'False',
    }

    for name, value in config.settings.items():
        set_constant(name, value)

    set_constant('VERSION', ansible.__version__)
    set_constant('reject_exts', REJECT_EXTS)
    set_constant('__file__', __file__)


# Generated at 2022-06-20 13:47:06.903890
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    l = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(l, "warning message", "2.2")
    assert dsc[0] == 1 and dsc[1] == 2 and dsc[2] == 3

    try:
        dsc[4]
    except IndexError:
        pass
    else:
        raise AssertionError("_DeprecatedSequenceConstant does not raise IndexError when index is out of bounds")



# Generated at 2022-06-20 13:47:15.649821
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test empty list
    x = _DeprecatedSequenceConstant([], 'Test msg', '1.0')
    assert len(x) == 0
    with pytest.raises(IndexError):
        x[0]
    # Test list with values
    x = _DeprecatedSequenceConstant(['test1', 'test2'], 'Test msg', '1.0')
    assert len(x) == 2
    assert x[0] == 'test1'
    assert x[1] == 'test2'
    with pytest.raises(IndexError):
        x[2]

# Generated at 2022-06-20 13:47:23.096435
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # __len__ should return the length of the value and log a warning
    t = _DeprecatedSequenceConstant([1, 2, 3], 'Testing 1, 2, 3', 'version 2')
    assert len(t) == 3

# Generated at 2022-06-20 13:47:26.583773
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert dsc[0] == []


# Generated at 2022-06-20 13:47:38.748640
# Unit test for function set_constant
def test_set_constant():
    assert getattr(_DeprecatedSequenceConstant, '__getitem__') == _DeprecatedSequenceConstant.__getitem__

# this is to keep things simple in the code
local_action = add_internal_fqcns((to_text(config.get_config_value('DEFAULT', 'local_action', value_type='ini')), ))

# Plugin configuration
for plugin_type in DOCUMENTABLE_PLUGINS:
    _config = config.get_config_value(plugin_type, plugin_type, raw=True) or {}
    setattr(config, plugin_type, _config)



# Generated at 2022-06-20 13:47:41.960358
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    v = _DeprecatedSequenceConstant(value = [1,2,3], msg = 'test', version = '1.2.3')

    # Test __len__
    assert len(v) == 3

    # Test __getitem__
    assert v[1] == 2

# Generated at 2022-06-20 13:47:45.669326
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ''' make sure the constructor works correctly '''

    dsc = _DeprecatedSequenceConstant([1, 2, 3], msg='mymsg', version='myversion')
    assert dsc._value == [1, 2, 3]
    assert dsc._msg == 'mymsg'
    assert dsc._version == 'myversion'



# Generated at 2022-06-20 13:47:52.907697
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('a', 'b', 'c')
    msg = "This is deprecated"
    version = "2.1"
    constant = _DeprecatedSequenceConstant(value, msg, version)
    assert constant[0] == 'a'
    assert constant[1] == 'b'
    assert constant[2] == 'c'
    try:
        constant[3]
    except IndexError:
        pass

# Generated at 2022-06-20 13:48:15.585837
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    from ansible.utils.display import Display
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    class DisplayTest(Display):
        def __init__(self, msg):
            self.msg = msg
            self.warn_count = 0
        def warning(self, msg):
            assert msg == self.msg
            self.warn_count += 1
    display_test = DisplayTest(' [DEPRECATED] DeprecatedWarning: DeprecatedWarning: to be removed in 17.5')
    msg = 'DeprecatedWarning: to be removed in 17.5'
    seq_const = _DeprecatedSequenceConstant(BOOLEANS_TRUE, msg, '17.5')
    assert len(seq_const) == len(BOOLEANS_TRUE)
   

# Generated at 2022-06-20 13:48:20.999583
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant((1, 2), 'test', '2.10').__len__() == 2
    assert _DeprecatedSequenceConstant((1, 2), 'test', '2.10')[0] == 1
    assert _DeprecatedSequenceConstant(u'abc', 'test', '2.10')[2] == u'c'
    assert _DeprecatedSequenceConstant(u'abc', 'test', '2.10').__len__() == 3

del config

# Generated at 2022-06-20 13:48:32.360722
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    from ansible.module_utils.common.text.converters import to_native

    class FakeDisplay:
        def __init__(self):
            self.output = ""

        def deprecated(self, msg, version):
            self.output = "Deprecation warning: " + msg + ", to be removed in " + version

    # Normal Behaviour
    fake_display = FakeDisplay()
    _DeprecatedSequenceConstant(['test1', 'test2'], "It's bad", "the future").__getitem__(1)
    assert to_native(fake_display.output) == "Deprecation warning: It's bad, to be removed in the future"

    # Bad type as msg parameter
    fake_display = FakeDisplay()

# Generated at 2022-06-20 13:48:39.735921
# Unit test for function set_constant
def test_set_constant():
    module = dict()
    set_constant("ANSIBLE_CONFIG", "/etc/ansible/ansible.cfg", module)
    assert module["ANSIBLE_CONFIG"] == "/etc/ansible/ansible.cfg"



# Generated at 2022-06-20 13:48:44.839743
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test msg'
    version = 'test version'
    value = ('test1', 'test2')
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert obj._msg == msg
    assert obj._version == version
    assert obj._value == value
    assert list(obj) == list(value)


# Generated at 2022-06-20 13:48:49.603673
# Unit test for function set_constant
def test_set_constant():
    # Test for adding a new constant and value
    set_constant('PLUGIN_PATH', 'directory')
    assert PLUGIN_PATH == 'directory'
    # Test overriding a constant that already exists
    set_constant('PLUGIN_PATH', 'new_directory')
    assert PLUGIN_PATH == 'new_directory'

# Generated at 2022-06-20 13:48:53.280084
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant = _DeprecatedSequenceConstant(value=[], msg="This constant is deprecated", version="2.9")
    assert len(deprecated_constant) == 0
    assert deprecated_constant[0] == None



# Generated at 2022-06-20 13:49:04.371094
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_seq = ('foo', 'bar', 'baz')
    test_msg = 'foo'
    test_version = '3.0.0'
    test_obj = _DeprecatedSequenceConstant(value=test_seq, msg=test_msg, version=test_version)
    assert test_obj._value == test_seq
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_seq)
    assert test_obj[0] == test_seq[0]
    assert test_obj[1] == test_seq[1]
    assert test_obj[2] == test_seq[2]

# Generated at 2022-06-20 13:49:11.680100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import contextlib
    import ansible.constants as constants

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        _test_value = ['foo', 'bar', 'baz']
        test_msg = "Produced by test__DeprecatedSequenceConstant___getitem__"

# Generated at 2022-06-20 13:49:21.160699
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test valid input
    value = [1, 2, 3]
    msg = 'test'
    version = '2.0'
    deprecated_sequence_constant_object = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant_object) == len(value)
    assert deprecated_sequence_constant_object[0] == value[0]
    assert deprecated_sequence_constant_object[-1] == value[-1]

    # Test invalid input
    try:
         deprecated_sequence_constant_object[len(deprecated_sequence_constant_object)]
         assert False
    except IndexError:
         pass

# Generated at 2022-06-20 13:49:45.310488
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], 'msg', '2.0')
    assert len(seq) == 5

# Generated at 2022-06-20 13:49:47.417994
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')[1] == 2

# Generated at 2022-06-20 13:49:51.305071
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence_constant = _DeprecatedSequenceConstant(value=[],msg='msg',version='version')
    assert test_sequence_constant[0] is None
    assert test_sequence_constant[1] is None


# Generated at 2022-06-20 13:49:55.877004
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert type(x) == _DeprecatedSequenceConstant
    assert x._value == [1, 2, 3]
    assert x._msg == 'msg'
    assert x._version == 'version'

# Generated at 2022-06-20 13:50:05.873631
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestDeprecatedSequenceConstant:
        def test_len(self):
            assert len(_DeprecatedSequenceConstant(['a', 'b'], 'test_msg', '0.0')) == 2
            assert len(_DeprecatedSequenceConstant((), 'test_msg', '0.0')) == 0

        def test_getitem(self):
            assert _DeprecatedSequenceConstant(['a', 'b'], 'test_msg', '0.0')[0] == 'a'
            assert _DeprecatedSequenceConstant(('c', 'd'), 'test_msg', '0.0')[:2] == ('c', 'd')

    class TestDeprecatedSequenceConstantMockingDeprecated:
        def test_len(self):
            from ansible.utils.display import Display

# Generated at 2022-06-20 13:50:15.556345
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('FOO', 'BAR', export=d)
    assert d == {'FOO': 'BAR'}


# FIXME: rework this to use the new plugin config classes

# For plugins that support checking their config, this is the list of
# config names that, if incorrect, can cause Ansible to fail.
#
# For example, if the connection plugin has this in its check_config()
# method:
#
#    if self.get_config('some_option') is None:
#        return False
#
# but 'some_option' is not in the CRITICAL_PLUGIN_CONFIGS list, then
# if this plugin's some_option is not defined in the config, a warning
# will be displayed and Ansible will continue running. If
# 'some_option' is

# Generated at 2022-06-20 13:50:19.054590
# Unit test for function set_constant
def test_set_constant():
    set_constant("ABC", True)
    assert ABC
    del ABC
    set_constant("BAC", [1, 2, 3])
    assert BAC == [1, 2, 3]
    del BAC

if HAS_JINJA2_NATIVE_TYPES:
    # Backwards compat with 2.9
    class AnsibleJinja2NativeType(Jinja2NativeType):
        pass

# Generated at 2022-06-20 13:50:29.917957
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.constants import MODULE_REQUIRE_ARGS
    assert isinstance(MODULE_REQUIRE_ARGS, _DeprecatedSequenceConstant)
    assert MODULE_REQUIRE_ARGS[0] == 'command'
    assert MODULE_REQUIRE_ARGS[1] == 'win_command'
    assert MODULE_REQUIRE_ARGS[2] == 'ansible.windows.win_command'
    assert MODULE_REQUIRE_ARGS[3] == 'shell'
    assert MODULE_REQUIRE_ARGS[4] == 'win_shell'
    assert MODULE_REQUIRE_ARGS[5] == 'ansible.windows.win_shell'
    assert MODULE_REQUIRE_ARGS[6] == 'raw'
    assert MODULE_REQUIRE_ARGS[7] == 'script'


# Generated at 2022-06-20 13:50:38.464623
# Unit test for function set_constant
def test_set_constant():
    import unittest
    import sys
    import os

    os.environ['ANSIBLE_CONFIG_MODULE_PATH'] = '%s/test/unit/ansible_test/_data/config' % os.path.dirname(__file__)

    class TestSetConstant(unittest.TestCase):

        def test_set_constant(self):
            set_constant('CONSTANT_FROM_CONFIG_FILE', 'value from config file')
            self.assertTrue(hasattr(sys.modules[__name__], 'CONSTANT_FROM_CONFIG_FILE'))
            delattr(sys.modules[__name__], 'CONSTANT_FROM_CONFIG_FILE')

# Generated at 2022-06-20 13:50:42.379281
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'this will be used in future', 'v2.8')
    assert len(dsc) == 3
    assert dsc[2] == 3


# Backwards compat as this is how constants were exposed before
Constants = globals()

# Generated at 2022-06-20 13:51:30.301070
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = 'test_msg'
    version = '1.0'
    con = _DeprecatedSequenceConstant(value, msg, version)
    assert value[0] == con[0]
    assert value[1] == con[1]
    assert value[2] == con[2]


# Generated at 2022-06-20 13:51:32.687556
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test1 = _DeprecatedSequenceConstant((1, 2, 3), "test1", "test1")
    assert len(test1) == 3



# Generated at 2022-06-20 13:51:41.669953
# Unit test for function set_constant
def test_set_constant():
    set_constant('AN_INTEGER', 42)
    set_constant('A_STRING', 'a_string')
    set_constant('A_FLOAT', 42.3)
    set_constant('A_BOOLEAN_TRUE', True)
    set_constant('A_BOOLEAN_FALSE', False)
    set_constant('A_LIST', [1,2])
    set_constant('A_DICT', {'a':1, 'b':2})

    assert AN_INTEGER == 42
    assert A_STRING == 'a_string'
    assert abs(A_FLOAT - 42.3) < 0.00001
    assert A_BOOLEAN_TRUE is True
    assert A_BOOLEAN_FALSE is False

# Generated at 2022-06-20 13:51:44.850913
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expectedItem = 1
    actualItem = _DeprecatedSequenceConstant([0, 1, 2, 3], "foo", "3.0")[1]
    assert expectedItem == actualItem

# Generated at 2022-06-20 13:51:54.601100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def getitem_test(c, i, v):
        assert id(c[i]) == id(v)

    # test if each element of the class is an immutable value
    value = ('hello world',)
    msg = 'this is a message for unit test'
    version = '1.0'

    c = _DeprecatedSequenceConstant(value, msg, version)
    assert id(c) != id(value)
    assert len(c) == len(value)
    for i, v in enumerate(value):
        yield getitem_test, c, i, v

    # test if it raises an exception when index out of range
    pytest.raises(IndexError, c.__getitem__, len(value))

# Generated at 2022-06-20 13:52:04.127492
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import types

    options = {'msg': "This is a test", 'version': "2.5", 'value': [5, 4, 3, 2, 1]}
    try:
        version = sys.version_info
    except:
        version = sys.version_info
    if version.major == 2:
        c = types.ClassType(sys.modules[__name__].__name__, (object,), {})
    else:
        c = type(sys.modules[__name__].__name__, (object,), {})
    c.warning = lambda msg: options.update({'msg': msg})
    sys.modules[__name__]._warning = c.warning
    # correct test

# Generated at 2022-06-20 13:52:06.341942
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert len(constant) == 3
    return True


# Generated at 2022-06-20 13:52:13.264315
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import os
    import tempfile
    import sys

    saved_stderr = sys.stderr
    try:
        r, w = os.pipe()
        sys.stderr = os.fdopen(w, 'w')
        _DeprecatedSequenceConstant(value=[], msg="msg", version=__version__)().__getitem__(0)
    finally:
        sys.stderr = saved_stderr

    with open(r, 'r') as pipe:
        assert 'msg to be removed in' in pipe.read()

# Generated at 2022-06-20 13:52:16.762738
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'not used', 'not used')
    assert x[0] == 1


# Generated at 2022-06-20 13:52:19.110067
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_class = _DeprecatedSequenceConstant("Hello World", "msg", "version")
    assert test_class[0] == "H"
