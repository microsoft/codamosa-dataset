

# Generated at 2022-06-20 13:43:42.835114
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.9')
    assert(value[1] == 2)
    assert(len(value) == 3)

# Generated at 2022-06-20 13:43:45.699826
# Unit test for function set_constant
def test_set_constant():
    def test():
        set_constant('FOO', 'BAR')
        assert FOO == 'BAR'
    test()
    locals().pop('test', None)
    globals().pop('FOO', None)

# Generated at 2022-06-20 13:43:47.169887
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant('abc', 'Test message', "2.0")
    assert a[2] == 'c'



# Generated at 2022-06-20 13:43:58.357134
# Unit test for function set_constant
def test_set_constant():
    # Do not remove, this function is used as unit test for function set_constant
    set_constant('FOO', 'bar')
    set_constant('ANSIBLE_COW_SELECTION', 'random')
    set_constant('ANSIBLE_KEEP_REMOTE_FILES', True)
    set_constant('ANSIBLE_MANAGED', 'Ansible has managed this file since {file_changed_at}')


# ADDITIONAL CONSTANTS ###


# Generated at 2022-06-20 13:44:00.706284
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class TestSequence(object):
        def __len__(self):
            return 3
    test_sequence = TestSequence()
    dsc = _DeprecatedSequenceConstant(test_sequence, 'test message', '0.0')
    assert len(dsc) == len(test_sequence)



# Generated at 2022-06-20 13:44:03.690188
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert 'foo' in _DeprecatedSequenceConstant((1, 2, 'foo'), u'Some warning message', '2.9')

# Generated at 2022-06-20 13:44:05.376407
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([], '', '2.9')
    c[0]  # pylint: disable=pointless-statement


# Generated at 2022-06-20 13:44:07.309877
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(value = (1, 2, 3), msg = 'This is deprecated', version = '2.4')
    assert len(seq) == 3
    assert seq[1] == 2

# Generated at 2022-06-20 13:44:08.677162
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    my_const = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert my_const[0] == 'v'

# Generated at 2022-06-20 13:44:14.580707
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Arrange
    msg = 'My msg'
    version = '1.2.6'
    value = ['a', 'b', 'c']

    # Act
    obj = _DeprecatedSequenceConstant(value, msg, version)
    length = len(obj)

    # Assert
    assert length == 3


# Generated at 2022-06-20 13:44:23.536508
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'test', None)
    assert value[0] == 'a'
    assert value[1] == 'b'
    assert value[-1] == 'c'
    assert value[:] == ('a', 'b', 'c')
    assert value[1:] == ('b', 'c')


# Generated at 2022-06-20 13:44:27.298692
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """ Unit tests for method _DeprecatedSequenceConstant.__getitem__ """
    c = _DeprecatedSequenceConstant(value=['a'], msg="msg", version="version")
    assert c[0] == 'a'

# Generated at 2022-06-20 13:44:35.556848
# Unit test for function set_constant
def test_set_constant():

    new_setting = ConfigManager.setting('host_key_checking', 'bool', False)
    new_setting.value = 1

    assert new_setting.value == 1

    # Set the value to a bool of False
    config.data.update_setting(new_setting, False)

    # Ensure the variable is set to a bool of False
    assert bool(new_setting.value) is False

    # Set the value to a string of 'False'
    config.data.update_setting(new_setting, 'False')

    # Ensure the variable is set to a bool of False
    assert bool(new_setting.value) is False

    # Set the value to a string of 'false'
    config.data.update_setting(new_setting, 'false')

    # Ensure the variable is set to a bool of False

# Generated at 2022-06-20 13:44:40.846699
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], msg="test_msg", version="test_version")
    assert len(dsc) == 3


# Generated at 2022-06-20 13:44:52.038252
# Unit test for function set_constant

# Generated at 2022-06-20 13:45:03.790125
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MockedDisplay:
        def __init__(self):
            self.msg = ''
        def deprecated(self, msg, version):
            self.msg = msg

    from ansible.utils.display import Display
    Display._instance = MockedDisplay()

    v = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', '2.10')
    v[1]
    assert isinstance(v, Sequence)
    assert len(v) == 3
    assert v[1] == 2
    assert Display._instance.msg == 'test msg, to be removed in 2.10'

# Generated at 2022-06-20 13:45:07.474236
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'value')
    set_constant('_foo', 'value')
    set_constant('FOO', 'value', locals())
    set_constant('__foo', 'value', locals())

# Generated at 2022-06-20 13:45:13.498340
# Unit test for function set_constant
def test_set_constant():
    vars = {}
    set_constant("foo", [1, 2, 3], vars)
    set_constant('baz', "{{ 1 | int * 2 }}", vars)
    assert vars['foo'] == [1, 2, 3]
    assert vars['baz'] == 2

# Generated at 2022-06-20 13:45:18.558067
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test__(self):
            x = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'This is a test', '1.0.0')
            assert 'a' in x
            assert 'b' in x
            assert 'c' in x
            assert 'd' not in x
            assert len(x) == 3
    unittest.main()

# Generated at 2022-06-20 13:45:22.884722
# Unit test for function set_constant
def test_set_constant():

    test_var = {}
    set_constant('FOO', 'BAR', test_var)
    assert test_var['FOO'] == 'BAR'

    set_constant('FOO', 'BAR2', test_var)
    assert test_var['FOO'] == 'BAR'

# Generated at 2022-06-20 13:45:40.097985
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Setup
    test_value = ('foo', 'bar')
    test_msg = 'This is a test'
    test_version = '2.0'
    depr = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # test slice
    assert depr[1:] == test_value[1:]

    # test integer with imports present
    with patch('ansible.constants.deprecated') as mock_deprecated:
        assert depr[0] == test_value[0]
        mock_deprecated.assert_called_once_with(test_msg, version=test_version)


# Generated at 2022-06-20 13:45:48.926193
# Unit test for function set_constant
def test_set_constant():
    # Test to overwrite a constant and raise an error.
    try:
        set_constant('ANSIBLE_CONFIG', 'my.cfg')
        raise AssertionError('Overwriting a constant should raise an error')
    except RuntimeError:
        pass

    # Test to add a new constant to globals().
    const = 'MY_CONST'
    set_constant(const, 'test1', export=globals())
    assert globals()[const] == 'test1'

    # Test to add a new constant to a custom dict.
    my_constants = {}
    set_constant(const, 'test2', export=my_constants)
    assert my_constants[const] == 'test2'

# Generated at 2022-06-20 13:45:57.147426
# Unit test for function set_constant
def test_set_constant():
    import os
    assert DOCUMENTABLE_PLUGINS == DOCUMENTABLE_PLUGINS
    assert set_constant('TEST_CONSTANT', 1) is None
    assert TEST_CONSTANT == 1
    assert VAULT_VERSION_MAX == VAULT_VERSION_MAX
    assert set_constant('TEST_CONSTANT', os.getcwd(), vars()) == os.getcwd()
    assert TEST_CONSTANT == os.getcwd()


# Generated at 2022-06-20 13:46:02.237457
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='version')
    x[0]

# Generated at 2022-06-20 13:46:06.366137
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    data = _DeprecatedSequenceConstant((1, 2, 3,), 'msg', 'version')
    assert data[2] == 3


# Generated at 2022-06-20 13:46:18.899446
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test cases: list
    basic_getitem_cases = (
        # case - sequence input, expecting normal return
        ([0, 1, 2], 1, '', ''),
        # case - sequence input, expecting normal return with msg/version
        ([0, 1, 2], 2, '#msg', '#version'),
    )
    for case in basic_getitem_cases:
        value, y, msg, version = case
        result = _DeprecatedSequenceConstant(value, msg, version).__getitem__(y)
        assert result == value[y]

    # Test cases: tuple

# Generated at 2022-06-20 13:46:26.420574
# Unit test for function set_constant
def test_set_constant():
    '''
    >>> import sys
    >>> if sys.version_info.major >= 3:
    ...     import builtins
    ...     globals()['__builtins__'] = builtins
    >>> 'ANSIBLE_DISPLAY_SKIPPED_HOSTS' in globals()
    True
    >>> ANSIBLE_DISPLAY_SKIPPED_HOSTS
    True
    >>> ANSIBLE_DISPLAY_SKIPPED_HOSTS = False
    >>> 'ANSIBLE_DISPLAY_SKIPPED_HOSTS' in globals()
    True
    >>> ANSIBLE_DISPLAY_SKIPPED_HOSTS
    False
    '''
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 13:46:30.765611
# Unit test for function set_constant
def test_set_constant():
    # This is necessary because nose does a bytecode purge
    from ansible.constants import set_constant
    set_constant('ANSIBLE_TEST', 42, export=vars())
    assert ANSIBLE_TEST == 42

# Generated at 2022-06-20 13:46:35.557907
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    if not getattr(__builtins__, '__ANSIBLE_TESTING__', False):
        raise AssertionError("Can only be used in unit tests")
    d = _DeprecatedSequenceConstant(['1', '2', '3'], "testing", {})
    assert len(d) == 3

# Generated at 2022-06-20 13:46:38.068094
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'test', '2.0')
    assert len(dsc) == 3
    assert dsc[1] == 2

# Generated at 2022-06-20 13:46:51.944010
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_cases = (
        (('foo', 'bar'), 'this is a test', 'FUTURE'),
        ([1, 2, 3], 'this is another test', '0.1')
    )

    for value, msg, version in test_cases:
        dsc = _DeprecatedSequenceConstant(value, msg, version)
        assert len(dsc) == len(value)


# Generated at 2022-06-20 13:46:53.768151
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant([1,2,3],'msg','2.4')
    assert len(l) == 3


# Generated at 2022-06-20 13:46:58.149805
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'

    dsc = _DeprecatedSequenceConstant([1, 2, 3, 4], msg, version)

    # test in range
    res = dsc[1]
    assert res == 2

    # test out of range
    try:
        dsc[10]
    except IndexError:
        pass
    else:
        assert False

    # test slice
    res = dsc[1:3]
    assert res == [2, 3]

# Generated at 2022-06-20 13:47:01.639077
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([], 'warn', '1.2')
    assert seq[0] == seq._value[0]

# Generated at 2022-06-20 13:47:07.100433
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'This is a warning message'
    version = '2.10'
    value = [1,2,3]
    constant = _DeprecatedSequenceConstant(value,msg,version)
    assert len(constant)==len(value)


# Generated at 2022-06-20 13:47:18.727373
# Unit test for function set_constant
def test_set_constant():
    import os

    def _test_constant(value, expected):
        set_constant('test_constant', value)
        import __main__
        assert __main__.test_constant == expected, 'Failed to set constant for %s. (expected: %s, got: %s)' % (repr(value), expected, __main__.test_constant)

    _test_constant(10, 10)
    _test_constant(10.5, 10.5)
    _test_constant('10', '10')
    _test_constant(True, True)
    _test_constant(False, False)
    _test_constant(None, None)

# Generated at 2022-06-20 13:47:30.701675
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    import unittest
    from ansible.utils.display import Display
    from ansible.utils.display_common import DisplayCommon

    class Test__DeprecatedSequenceConstant(unittest.TestCase):

        # setUp
        # call parent constructor
        # _ActionBase has init which raises exception if DisplayCommon does not exist
        # that way we do not have to mock DisplayCommon in the test
        #
        super(Test__DeprecatedSequenceConstant, self).__init__()

        # mock DisplayCommon class
        Display.display = DisplayCommon()

        # mock _display.warning
        Display.deprecated = lambda x, y: True


# Generated at 2022-06-20 13:47:33.500371
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ds = _DeprecatedSequenceConstant('', '', '')
    if len(ds) == 0:
        pass
    ds.__getitem__(0)

# Generated at 2022-06-20 13:47:36.808716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    depr_seq_const = _DeprecatedSequenceConstant([0, 1, 2], 'msg', 'version')
    assert depr_seq_const[1] == 1



# Generated at 2022-06-20 13:47:45.532824
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg_test = _DeprecatedSequenceConstant((1, ), 'msg_test', '1.0')
    assert msg_test._msg == 'msg_test'
    assert msg_test._version == '1.0'
    assert (1, ) == msg_test._value
    assert len(msg_test) == 1
    assert msg_test[0] == 1

set_constant('DEFAULT_BECOME_PASS', DEFAULT_BECOME_PASS)
set_constant('DEFAULT_PASSWORD_CHARS', DEFAULT_PASSWORD_CHARS)
set_constant('DEFAULT_REMOTE_PASS', DEFAULT_REMOTE_PASS)
set_constant('DEFAULT_SUBSET', DEFAULT_SUBSET)

# Generated at 2022-06-20 13:48:11.385079
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'hello')
    assert foo == 'hello'
    assert vars()['foo'] == 'hello'
    test2 = {}
    set_constant('bar', 'world', test2)
    assert vars()['bar'] is None
    assert test2['bar'] == 'world'

# Generated at 2022-06-20 13:48:13.393137
# Unit test for function set_constant
def test_set_constant():
    locals = {}
    set_constant('FOO', 'testval', locals)
    assert locals['FOO'] == 'testval'

# Generated at 2022-06-20 13:48:22.268907
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([], 'msg', '1.0')
    assert len(constant) == 0

    constant = _DeprecatedSequenceConstant([1,2,3], 'msg', '1.0')
    assert len(constant) == 3


# Generated at 2022-06-20 13:48:25.285970
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    _DeprecatedSequenceConstant(['a', 'b'], msg, version)[0]


# Generated at 2022-06-20 13:48:31.527503
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test __init__()
    obj = _DeprecatedSequenceConstant(['test'], "test message", "1.2")
    assert obj._value == ['test']
    assert obj._msg == 'test message'
    assert obj._version == '1.2'

    # test __len__()
    assert len(obj) == 1

    # test __getitem__()
    assert obj[0] == 'test'



# Generated at 2022-06-20 13:48:35.426153
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3, 4], '', '')
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3
    assert seq[3] == 4



# Generated at 2022-06-20 13:48:39.457746
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert(len(s) == 3), 'len(s) != 3'



# Generated at 2022-06-20 13:48:42.361919
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'blah', '1.0')
    assert len(s) == 3

# Generated at 2022-06-20 13:48:46.305344
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1,2,3], 'test_message', '2.4')
    assert len(deprecated_sequence_constant) == 3

__all__ = tuple(globals().keys())

# Generated at 2022-06-20 13:48:55.022400
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class DummyCallerInfo(object):
        info = 'tasks/main.yml:5'

    def _deprecated(msg, version):
        raise AssertionError()

    old_deprecated = _deprecated

    def _test(_value, _msg, _version):
        dsc = _DeprecatedSequenceConstant(_value, _msg, _version)
        assert dsc._value == _value
        assert dsc._msg == _msg
        assert dsc._version == _version
        # This will call __getitem__ of dsc
        assert dsc[0] == _value[0]
        # This will raise AssertionError when calling _deprecated
        try:
            list(dsc)
        except AssertionError:
            pass

# Generated at 2022-06-20 13:49:23.607374
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_sequence = [10, 20, 30]
    deprecated_sequence_constant_object = _DeprecatedSequenceConstant(test_sequence, 'test_message', '2.9')
    assert len(test_sequence) == len(deprecated_sequence_constant_object)
    for index in range(len(test_sequence)):
        assert test_sequence[index] == deprecated_sequence_constant_object[index]


# Generated at 2022-06-20 13:49:28.389587
# Unit test for function set_constant
def test_set_constant():
    assert C.DEFAULT_CA_PATH == '/etc/ssl/certs/'


# FIXME: move to config manager

# Generated at 2022-06-20 13:49:37.704830
# Unit test for function set_constant
def test_set_constant():
    _test_constants = {'a': 1, 'b': 'foo', 'c': True}
    for k, v in _test_constants.items():
        set_constant(k, v)
    for k, v in _test_constants.items():
        assert v == globals()[k]


# FIXME: remove once play_context mangling is removed
# Create constants for aliases found in MAGIC_VARIABLE_MAPPING
for values in MAGIC_VARIABLE_MAPPING.values():
    for value in values[1:]:
        set_constant(value, values[0])

# also set the base constant for each connection plugin to be used as a default

# Generated at 2022-06-20 13:49:42.511147
# Unit test for function set_constant
def test_set_constant():
    # test with existing variable
    existing_variable = 'ANSIBLE_CONFIG'
    variable_value = '/path/to/ansible.cfg'
    set_constant(existing_variable, variable_value)
    assert vars()[existing_variable] == variable_value

    # test with new variable
    new_variable = 'ANSIBLE_TEST'
    variable_value = 'test'
    set_constant(new_variable, variable_value)
    assert vars()[new_variable] == variable_value

# Generated at 2022-06-20 13:49:46.361151
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(constant=['a', 'b', 'c'], msg='This is a test message', version='2.10')

# Generated at 2022-06-20 13:49:50.235751
# Unit test for function set_constant
def test_set_constant():
    assert BECOME_METHOD == 'sudo'
    assert DEFAULT_UNDEFINED_VAR_BEHAVIOR == ('warn', 'smart')
    assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'


# Generated at 2022-06-20 13:49:53.825215
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant('hello', 'message', 'version')
    assert x[0] == 'h'
    assert x[5] == 'o'
    assert x[-1] == 'o'

# Generated at 2022-06-20 13:49:58.296626
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'Test message'
    version = '1.0.0'
    mock_value = 'test_value'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(mock_value, msg, version)
    assert deprecated_sequence_constant.__getitem__(0) == 't'

# Generated at 2022-06-20 13:50:01.514894
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test __len__ method of class _DeprecatedSequenceConstant"""
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3


# Generated at 2022-06-20 13:50:03.711240
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert len(sequence) == 3

# Generated at 2022-06-20 13:50:34.811546
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ('a', 'b', 'c', 'd')
    dsc1 = _DeprecatedSequenceConstant(value, 'aaaaa', '2.9.9')
    assert dsc1[1] == 'b'
    assert dsc1[2:4] == ('c', 'd')
    # _DeprecatedSequenceConstant is a subclass of Sequence, so it has all attributes of Sequence
    assert hasattr(dsc1, '__contains__')
    assert hasattr(dsc1, '__iter__')
    assert hasattr(dsc1, 'index')


# Generated at 2022-06-20 13:50:37.986767
# Unit test for function set_constant
def test_set_constant():
    set_constant('Foo', 'foo')
    assert Foo == 'foo'
    set_constant('Bar', 'bar')
    assert Bar == 'bar'

# TODO: someday move this to a more sane location

# Generated at 2022-06-20 13:50:42.489862
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # create test object
    test_object = _DeprecatedSequenceConstant([1, 2, 3, 4], "Test message", "2.0")

    # start tests
    assert test_object[0] == 1
    assert test_object[1] == 2
    assert test_object[2] == 3
    assert test_object[3] == 4


# Generated at 2022-06-20 13:50:46.758740
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    message = 'This value is deprecated'
    version = '2.12'
    data = [4, 7, 45]
    deprecated_constant = _DeprecatedSequenceConstant(data, message, version)
    assert(isinstance(deprecated_constant, Sequence))
    assert(deprecated_constant._value == data)
    assert(deprecated_constant._msg == message)
    assert(deprecated_constant._version == version)



# Generated at 2022-06-20 13:50:47.767280
# Unit test for function set_constant
def test_set_constant():
    assert ADDITIONAL_LOOKUP_PLUGINS is None


# Generated at 2022-06-20 13:50:58.238006
# Unit test for function set_constant
def test_set_constant():
    # Make sure DEFAULT_HOST_LIST exists and has the string type.
    set_constant("DEFAULT_HOST_LIST", "localhost")
    assert("DEFAULT_HOST_LIST" in vars())
    assert(isinstance(DEFAULT_HOST_LIST, string_types))
    # Make sure DEFAULT_HOST_LIST exists and has the correct type.
    set_constant("DEFAULT_HOST_LIST", ["localhost"])
    assert("DEFAULT_HOST_LIST" in vars())
    assert(isinstance(DEFAULT_HOST_LIST, Sequence))
    # Make sure DEFAULT_HOST_LIST exists and has the correct type.
    set_constant("DEFAULT_HOST_LIST", {'localhost': '127.0.0.1'})

# Generated at 2022-06-20 13:51:01.661022
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(value=tuple(), msg="msg", version=__version__)
    assert seq[0] == tuple()[0]
    seq = _DeprecatedSequenceConstant(value=["str"], msg="msg", version=__version__)
    assert seq[0] == ["str"][0]

# Generated at 2022-06-20 13:51:05.550966
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_list = ['1', '2', '3']
    test_obj = _DeprecatedSequenceConstant(test_list, 'test message', 'test version')
    assert test_obj[1] == '2'


test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-20 13:51:06.720359
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert(foo == 'bar')


# Generated at 2022-06-20 13:51:09.251070
# Unit test for function set_constant
def test_set_constant():
    ''' test_set_constant: ensure setting constants works as expected '''
    assert __version__ == VERSION
    assert not ALL_SUBSETS
    assert not ANY_SUBSET
    assert 'cows' not in DEFAULT_COW_SELECTION

# TODO: replace with os.path.sep

# Generated at 2022-06-20 13:52:05.088057
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from tempfile import mkdtemp
    import os
    import os.path
    import shutil
    import sys

    # Create a temporary directory and add it to the module search path
    tmpdir = mkdtemp()
    sys.path.insert(0, tmpdir)

    # Create a file named ansible/utils/display.py
    os.makedirs(os.path.join(tmpdir, 'ansible', 'utils'))

# Generated at 2022-06-20 13:52:11.297118
# Unit test for function set_constant
def test_set_constant():
    import pytest

    config2 = ConfigManager()
    for setting in config2.data.get_settings():
        value = setting.value
        if isinstance(value, string_types) and value.startswith('{{') and value.endswith('}}'):
            try:
                t = Template(value)
                value = t.render(vars())
            except Exception:
                pass  # not templatable

            value = ensure_type(value, setting.type)

        # Get value from this script
        globals_value = globals().get(setting.name)

        # Check that it matches the value from the current config
        assert globals_value == value


# Now load the configurable plugins

# Generated at 2022-06-20 13:52:17.486582
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_seq = _DeprecatedSequenceConstant([0, 1, 2], 'test msg', '1.11')
    assert len(deprecated_seq) == 3
    assert deprecated_seq[0] == 0

del config


# Check the version of Ansible we're running.
# A list of minimum and maximum acceptable versions is passed in.
# If the current version is outside the range a SystemExit exception is raised.

# Generated at 2022-06-20 13:52:19.150076
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version')) == 3

# Generated at 2022-06-20 13:52:25.262053
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Negative Test
    sut = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.2')
    assert len(sut) == 3

    # Positive Test
    sut = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.2')
    assert len(sut) == 3

# Generated at 2022-06-20 13:52:28.180306
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'bar')
    assert dsc[0] == 1
    assert dsc[1:] == [2, 3]



# Generated at 2022-06-20 13:52:30.623140
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant((1, 2), 'testing len', '2.8')
    assert len(test_obj) == 2

# Generated at 2022-06-20 13:52:40.138846
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    from ansible.module_utils.six import PY3

    # Test for HAS_ITER method, where __len__() should raise AttributeError
    if PY3:
        from collections import UserList
        class UserList2(UserList):
            def __getitem__(self, i):
                return i
        testList = UserList2(range(10))

        dep = _DeprecatedSequenceConstant(testList, 'test', '2.0')
        with pytest.raises(AttributeError):
            dep.__len__()
    else:
        class UserList2(list):
            def __getitem__(self, i):
                return i
        testList = UserList2(range(10))
        dep = _DeprecatedSequenceConstant(testList, 'test', '2.0')

# Generated at 2022-06-20 13:52:44.011264
# Unit test for function set_constant
def test_set_constant():
    # type: () -> None
    """Make sure set_constant doesn't modify the original dictionary."""
    def my_dict():
        # type: () -> Dict[str, Any]
        return {'foo': 'bar'}

    set_constant('my_dict', my_dict)
    assert my_dict() == {'foo': 'bar'}

# Generated at 2022-06-20 13:52:47.726167
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test to see if __getitem__ and __len__ are working properly
    x = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version_x")
    assert len(x) == 3
    assert x[1] == 2
    assert x[2] == 3
    assert x[0] == 1
    # Test to see if the _deprecated method was called correctly
    assert config.WARNINGS == [" [DEPRECATED] msg, to be removed in version_x"]