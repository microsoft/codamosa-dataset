

# Generated at 2022-06-20 13:43:43.044865
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_cases = [
        ('one', ['one'], 1),
        (['one','two'], ['one', 'two'], 2),
    ]

    for value, expected, expected_len in test_cases:
        dsc = _DeprecatedSequenceConstant(value, 'message', 'version')
        assert dsc == expected
        assert len(dsc) == expected_len


# Generated at 2022-06-20 13:43:47.321185
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_name = '_DeprecatedSequenceConstant'
    value = [1, 2, 3]
    version = '2.8'
    msg = ' is deprecated'
    c = _DeprecatedSequenceConstant(value, msg, version)
    if (len(c) == len(value) and c[0] == value[0] and c[1] == value[1] and c[2] == value[2]):
        print(class_name+" OK")
    else:
        print(class_name+" FAILED")


# Generated at 2022-06-20 13:43:52.936890
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    set_constant('DEBUG', True)
    set_constant('MODULE_REQUIRE_ARGS', add_internal_fqcns(('shell', 'raw')))

    assert MODULE_REQUIRE_ARGS[0] == 'shell'
    assert MODULE_REQUIRE_ARGS[1] == 'raw'

# Generated at 2022-06-20 13:43:54.739407
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(value=1, msg='test', version='test')
    assert a[0] == 1


# Generated at 2022-06-20 13:44:01.637395
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is deprecated'
    version = '2.0'
    value = [1,2,3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert len(dsc) == 3


# TODO: remove these once all of the deprecates are removed
CONNECTION_PLUGIN_NAMES = _DeprecatedSequenceConstant(add_internal_fqcns(('local', 'smart', 'ssh', 'winrm', 'paramiko_ssh', 'chroot', 'nxos_ssh', 'docker', 'netconf')), "CONNECTION_PLUGIN_NAMES is deprecated", '2.10')
SHARED_LOADER_AT

# Generated at 2022-06-20 13:44:04.310214
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    ssc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(ssc) == 3



# Generated at 2022-06-20 13:44:10.361257
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DSC = _DeprecatedSequenceConstant(value=(1,2,3), msg="Testing _DeprecatedSequenceConstant...", version="1.0")
    if len(_DSC) != len((1,2,3)):
        raise AssertionError("test__DeprecatedSequenceConstant(): constructor of class _DeprecatedSequenceConstant failed 'len' check, {} vs {}".format(len(_DSC), len((1,2,3))))
    if _DSC[0] != (1,2,3)[0]:
        raise AssertionError("test__DeprecatedSequenceConstant(): constructor of class _DeprecatedSequenceConstant failed 'getitem' check, {} vs {}".format(_DSC[0], (1,2,3)[0]))

test__DeprecatedSequenceConstant()

# FIXME

# Generated at 2022-06-20 13:44:13.446242
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('FAKE', 'FAKE')
        assert False
    except NameError as e:
        assert True

# Generated at 2022-06-20 13:44:26.808892
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_ = _DeprecatedSequenceConstant

    obj = class_(['foo', 'bar', 'baz'], 'This is deprecated', '2.0')
    assert len(obj) == 3

    assert obj[0] == 'foo'
    assert obj[1] == 'bar'
    assert obj[2] == 'baz'

# Backward compatibility with old constants
LOCALHOST_WARNING = (
    'Returning localhost instead of 127.0.0.1 in versions < 2.5 is deprecated. The option to return localhost will be'
    ' removed in 2.5. You need to explicitly specify 127.0.0.1 instead of localhost.'
)

# Generated at 2022-06-20 13:44:30.248628
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_obj = _DeprecatedSequenceConstant(value=['foo'],
                                            msg='Deprecated',
                                            version='2.0')
    assert len(class_obj) == 1
    assert class_obj[0] == 'foo'

# Generated at 2022-06-20 13:44:39.512290
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1,2,3,4,5]
    test_msg = "test for method __getitem__ of class _DeprecatedSequenceConstant"
    test_version = "1.0"
    temp = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert temp[2] == test_value[2]


# Generated at 2022-06-20 13:44:43.253612
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == len([1, 2, 3])
    assert dsc[1] == 2


# Generated at 2022-06-20 13:44:54.334875
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert 'FOO' in globals()
    assert globals()['FOO'] == 'BAR'

    set_constant('ANSIBLE_FOO', 'BAR')
    assert 'ANSIBLE_FOO' in globals()
    assert globals()['ANSIBLE_FOO'] == 'BAR'

    set_constant('ANSIBLE_FOO2', 'BAR2')
    assert 'ANSIBLE_FOO2' in globals()
    assert globals()['ANSIBLE_FOO2'] == 'BAR2'

    set_constant('FOO2', 'BAR2')
    assert 'FOO2' in globals()
    assert globals()['FOO2'] == 'BAR2'


# MAIN #########################

# the

# Generated at 2022-06-20 13:44:56.018083
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1], 'msg', '1.0')
    assert d[0] == 1


# Generated at 2022-06-20 13:45:04.807611
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Ensure that _DeprecatedSequenceConstant is a subclass of Sequence.
    assert issubclass(_DeprecatedSequenceConstant, Sequence)

    # Create the _DeprecatedSequenceConstant object and use the length function.
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'hello', 'test')
    assert len(obj) == 3

    # Create the _DeprecatedSequenceConstant object and use the indexing function.
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'hello', 'test')
    assert obj[0] == 1

# Generated at 2022-06-20 13:45:08.938171
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    msg = "Deprecation message"
    version = "2.10"
    value = (1, 2, 3)
    val = _DeprecatedSequenceConstant(value, msg, version)
    assert len(val) == len(value)
    assert isinstance(len(val), (int, long))


# Generated at 2022-06-20 13:45:19.024321
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test__DeprecatedSequenceConstant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test__DeprecatedSequenceConstant._value == test_value
    assert test__DeprecatedSequenceConstant._msg == test_msg
    assert test__DeprecatedSequenceConstant._version == test_version

# Generated at 2022-06-20 13:45:28.931938
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'a string')
    assert TEST_CONSTANT == 'a string'
    set_constant('TEST_CONSTANT', 'the same string')
    assert TEST_CONSTANT == 'the same string'
    set_constant('TEST_CONSTANT', 'different string')
    assert TEST_CONSTANT == 'different string'
    set_constant('TEST_CONSTANT', 42)
    assert TEST_CONSTANT == 42
    set_constant('TEST_CONSTANT', [1, 2, 3, 4])
    assert TEST_CONSTANT == [1, 2, 3, 4]
    set_constant('TEST_CONSTANT', {'a': 1, 'b': 2})

# Generated at 2022-06-20 13:45:31.754272
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence = _DeprecatedSequenceConstant(MAGIC_VARIABLE_MAPPING, 'test message', 'version')
    assert deprecated_sequence[0] == 'ansible_connection'

# Generated at 2022-06-20 13:45:34.186461
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3, 4], 'Test message', '1.0')
    assert len(seq) == 4

# Generated at 2022-06-20 13:45:42.159436
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Test _DeprecatedSequenceConstant.__getitem__()"""
    o = _DeprecatedSequenceConstant([1, 2, 3], '')
    result = o[1]
    assert result == 2


# Generated at 2022-06-20 13:45:46.014689
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_object = _DeprecatedSequenceConstant(value=['ansible', 'ansible-lint'], msg='test_DeprecatedSequenceConstant_len', version='2.9')
    result = test_object.__len__()
    expected_result = 2
    assert result == expected_result

# Generated at 2022-06-20 13:45:50.361017
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import is_sequence
    deprecated_tuple = _DeprecatedSequenceConstant((1, 2, 3), 'This is deprecated', '2.0')
    assert deprecated_tuple[0] == 1
    assert deprecated_tuple[1] == 2
    assert deprecated_tuple[2] == 3
    assert len(deprecated_tuple) == 3
    assert is_sequence(deprecated_tuple)

# Generated at 2022-06-20 13:45:58.042377
# Unit test for function set_constant
def test_set_constant():

    test_dict = {}
    set_constant('test_key', 'test_value', test_dict)
    assert test_dict['test_key'] == 'test_value'

    set_constant('other_key', 'other_value', test_dict)
    assert 'test_key' in test_dict
    assert test_dict['other_key'] == 'other_value'

# Test the validity of the MAGIC_VARIABLE_MAPPING dictionary.
# This also serves as a simple example of use for the dict.

# Generated at 2022-06-20 13:46:01.624330
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], msg='toto', version='12.2')

# Generated at 2022-06-20 13:46:07.747153
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(['test'], 'test-msg', '2.9')
    assert c[0] == 'test'

test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-20 13:46:12.647802
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = (1, 2, 3)
    msg = "test_msg"
    version = "test_version"
    test_instance = _DeprecatedSequenceConstant(test_value, msg, version)
    assert len(test_instance) == len(test_value)

# Generated at 2022-06-20 13:46:17.887030
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(
        [0, '1', 2, '3'],
        'this is a test',
        '1.0'
    )
    assert seq[0] == 0
    assert seq[1] == '1'
    assert seq[2] == 2
    assert seq[3] == '3'

# Generated at 2022-06-20 13:46:26.140121
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''
    test__DeprecatedSequenceConstant() in this file is not a test which will be run by unit test framework,
    it is only for test _DeprecatedSequenceConstant class in this file.
    '''
    from ansible.module_utils.common.collections import Sequence
    test_object = _DeprecatedSequenceConstant(["a", "b", "c"], "msg", "version")
    assert isinstance(test_object, Sequence)
    assert test_object[0] == "a"
    assert test_object[1] == "b"
    assert test_object[2] == "c"
    assert test_object[-1] == "c"
    assert tuple(test_object) == ("a", "b", "c")

# Generated at 2022-06-20 13:46:29.406836
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence = _DeprecatedSequenceConstant(('a', 'b'), 'Deprecated sequence', 'v1.1')
    assert deprecated_sequence[0] == 'a'

# Generated at 2022-06-20 13:46:36.745283
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'testing', '2.9')
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3


# Generated at 2022-06-20 13:46:39.495251
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(value=frozenset(('a', 'b', 'c')), msg='msg', version='version')
    assert len(a) == 3
    assert a[1] == 'b'

# Generated at 2022-06-20 13:46:43.329124
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_instance) == len(test_value)



# Generated at 2022-06-20 13:46:46.420623
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(('a'), 'test', '1.0')
    assert len(obj) == 1


# Generated at 2022-06-20 13:46:52.993902
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def test(msg, version, value, expected_len):
        instance = _DeprecatedSequenceConstant(value, msg, version)
        assert len(instance) == expected_len

    test('test_msg', 'test_version', [0, 1, 2], 3)
    test('test_msg', 'test_version', {'x': 1}, 1)

# Generated at 2022-06-20 13:46:54.918185
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2], msg="foo", version="0.0.1")) == 2

# Generated at 2022-06-20 13:46:57.559828
# Unit test for function set_constant
def test_set_constant():
    if set_constant('answer', 42) != set_constant('answer', 42):
        raise AssertionError('Answer is not equal to 42')

    if set_constant('answer', 41) == set_constant('answer', 42):
        raise AssertionError('Answer is equal to 42')

# Generated at 2022-06-20 13:47:01.795889
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('test_constant', 'test_value', export)
    assert export['test_constant'] == 'test_value'

# Generated at 2022-06-20 13:47:12.084045
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == config.file_name
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert DOCUMENTABLE_PLUGINS == tuple(add_internal_fqcns(('strategy', 'lookup', 'shell', 'cliconf', 'connection', 'netconf', 'vars', 'httpapi', 'become', 'callback', 'inventory', 'module', 'cache')))

# Generated at 2022-06-20 13:47:15.304429
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    const = _DeprecatedSequenceConstant(['a', 'b'], 'test message', '2.9')
    assert ('a', 'b') == tuple(const)

# Generated at 2022-06-20 13:47:28.763066
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_list = ['a', 'b', 'c']
    test_msg = 'msg'
    test_version = '1'
    test_object = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert(test_object[1] == 'b')
    assert(test_object[-1] == 'c')


# Generated at 2022-06-20 13:47:33.368257
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1,2,3]
    test_msg = 'testing'
    test_version = '2.0'
    temp = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert temp.__getitem__(1) == test_value[1]


# Generated at 2022-06-20 13:47:36.346557
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence = _DeprecatedSequenceConstant([1,2,3], "You should not use a list here", "2.0")
    assert len(deprecated_sequence) == 3

# Generated at 2022-06-20 13:47:40.348217
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], None, None)[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], None, None)[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], None, None)[2] == 3

# Generated at 2022-06-20 13:47:45.794404
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant((1, 2, 3), "Some message", "some version")
    assert x[1] == 2



# Generated at 2022-06-20 13:47:57.392439
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'this is a test message'
    version = '2.10'
    quoted_msg = "'%s'" % msg
    quoted_version = "'%s'" % version
    try:
        import ansible.module_utils.parsing.convert_bool as convert_bool
    except Exception:
        import sys, os
        TEST_DIR = os.path.dirname(os.path.realpath(__file__))
        ANSIBLE_LIB_DIR = os.path.dirname(TEST_DIR)
        sys.path.append(ANSIBLE_LIB_DIR)
        import ansible.module_utils.parsing.convert_bool as convert_bool
    assert type(convert_bool.BOOLEANS_TRUE).__name__ == 'frozenset'

# Generated at 2022-06-20 13:48:10.723152
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_MODULE_UTILS == 'ansible.module_utils'
    assert ANSIBLE_LIBRARY == 'ansible.modules.actions'
# end of test_set_constant

# get the version string from the ansible release file
__version__ = config.version

####################
#  PLUGIN LISTS    #
####################

# list of directories where plugins can be found (loaded from config)
C.DEFAULT_MODULE_PATH = []
C.DEFAULT_MODULE_PATH = list(C.DEFAULT_MODULE_PATH)
C.DEFAULT_MODULE_PATH.extend(['/usr/share/ansible/plugins/modules', C.DEFAULT_MODULE_PATH[0] + '/plugins/modules'])

C.DEFAULT_ACTION_PLUGIN_PATH

# Generated at 2022-06-20 13:48:13.150740
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(['foo', 'bar', 'baz'], 'message', '2.0')
    assert constant[1] == 'bar'


# Generated at 2022-06-20 13:48:20.497945
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ansible_version = __version__
    msg = "Deprecated"
    version = "2.3"
    value = [1,2,3,4]

    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert test_obj._value == value
    assert len(test_obj) == 4
    assert test_obj[1] == 2

# Generated at 2022-06-20 13:48:27.384795
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = 'test_value'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_msg == test_obj._msg
    assert test_version == test_obj._version


# Generated at 2022-06-20 13:48:40.964204
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOOBAR', 'BAZ')
    assert FOOBAR == 'BAZ'

# FIXME: remove once v2 is deprecated
DEFAULT_HOST_LIST = 'ansible_managed'
VERSION = __version__
SORTED_HOSTS_GROUP = 'all'

# Generated at 2022-06-20 13:48:44.215289
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert 'foo' == d[0]
    assert 'bar' == d[1]


# Generated at 2022-06-20 13:48:45.838782
# Unit test for function set_constant
def test_set_constant():
    num = 10
    set_constant('CONST_NUM', num)
    assert CONST_NUM == num

# Generated at 2022-06-20 13:48:49.484800
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert (len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "version")) == 3)
    assert (_DeprecatedSequenceConstant((1, 2, 3), "msg", "version")[2] == 3)

# Generated at 2022-06-20 13:48:52.484796
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq =  _DeprecatedSequenceConstant(value=('foo', 'bar', 'baz'), msg='This is a test msg.', version='2.9')
    assert len(seq) == 3

# Generated at 2022-06-20 13:49:05.271378
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys

    # Test when the warning is printed
    x = 42
    dc = _DeprecatedSequenceConstant([1, 2, 3], 'expand', '2.9')
    sys.stderr = ''
    assert dc[1] == 2
    assert sys.stderr == ' [DEPRECATED] expand, to be removed in 2.9\n'

    # Test when the warning is not printed
    sys.stderr = ''
    assert dc[1] == 2
    assert sys.stderr == ''

    # Test when the warning is printed
    x = 42
    dc = _DeprecatedSequenceConstant([1, 2, 3], 'expand', '2.9')
    sys.stderr = ''
    assert dc.__len__() == 3

# Generated at 2022-06-20 13:49:10.889454
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(['1', '2'], 'msg', 'version')
    assert c[0] == '1'
    assert c[1] == '2'


# Generated at 2022-06-20 13:49:12.935473
# Unit test for function set_constant
def test_set_constant():
    assert remove_internal_keys(CONFIG_HASH_KEYS) == list(config.data.values())

# Generated at 2022-06-20 13:49:16.110469
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant([], "test", "1.0")
    assert test._value == []
    assert test._msg == "test"
    assert test._version == "1.0"

# Generated at 2022-06-20 13:49:21.656864
# Unit test for function set_constant
def test_set_constant():
    import os
    import tempfile

    test_file = tempfile.mktemp()
    os.environ['ANSIBLE_CONFIG'] = test_file
    config = ConfigManager()
    set_constant('foo', 'bar')
    set_constant('baz', 'qux')

    for setting in config.data.get_settings():
        assert getattr(config, setting.name) == setting.value

# Generated at 2022-06-20 13:50:06.745649
# Unit test for function set_constant
def test_set_constant():
    import ansible.constants as C
    C.set_constant('TESTING', True, locals())
    assert('TESTING' in locals())
    assert(C.TESTING == True)


# Generated at 2022-06-20 13:50:10.538000
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert c
    assert c._msg == 'msg'
    assert c._value == []
    assert c._version == 'version'


# Generated at 2022-06-20 13:50:18.329437
# Unit test for function set_constant
def test_set_constant():
    global ANSIBLE_MODULE_CALLABLE_WHITELIST
    global ANSIBLE_MODULES_PATH
    global ANSIBLE_MODULE_ARGS
    global ANSIBLE_RETRY_FILES_ENABLED
    global ANSIBLE_PERSISTENT_CONNECT_TIMEOUT
    global ANSIBLE_RETRY_FILES_SAVE_PATH
    global ANSIBLE_ROLE_REQUIREMENTS_PATH
    global ANSIBLE_ROLES_PATH
    global ANSIBLE_SSH_ARGS
    global ANSIBLE_STDOUT_CALLBACK
    global ANSIBLE_TEST_PYTHON
    global ANSIBLE_TEST_PYTHON_INTERPRETER


# Generated at 2022-06-20 13:50:26.280648
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    abort_on_prompts = _DeprecatedSequenceConstant(value=True, msg="using the 'abort_on_prompts' setting", version='2.11')
    assert abort_on_prompts == True

    intercept_scripts = _DeprecatedSequenceConstant(value=['/bin/echo this is a test', '/bin/true'],
                                                    msg="using the 'intercept_scripts' setting", version='2.11')
    assert len(intercept_scripts) == 2

# Generated at 2022-06-20 13:50:29.390315
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_constant = _DeprecatedSequenceConstant([1, 2, 3], "3 is deprecated", 3)
    assert(len(deprecated_constant) == 3)


# Generated at 2022-06-20 13:50:36.147296
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    for k, v in DEFAULT_SUDO_EXE.items():
        assert k in ('sudo', 'sudo_exe', 'sudo_flags', 'become', 'become_exe', 'become_method', 'become_flags')
        assert isinstance(v, (_DeprecatedSequenceConstant, list))
        if isinstance(v, _DeprecatedSequenceConstant):
            assert len(v) == 1
        else:
            assert len(v) == 2

test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:50:37.874612
# Unit test for function set_constant
def test_set_constant():
    test_const = {}
    set_constant('foo', 'bar', test_const)
    assert test_const['foo'] == 'bar'



# Generated at 2022-06-20 13:50:40.153523
# Unit test for function set_constant
def test_set_constant():
    assert TASK_DEBUG is False
    set_constant('TASK_DEBUG', True)
    assert TASK_DEBUG is True



# Generated at 2022-06-20 13:50:42.268058
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant([1, 2, 3], u"msg", u"version")
    assert len(t) == 3
    return True


# Generated at 2022-06-20 13:50:45.104840
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_CONFIG_AUTO_RESOLVE_OUTPUT_TO', 'local', export=globals())
    assert ANSIBLE_CONFIG_AUTO_RESOLVE_OUTPUT_TO == 'local'



# Generated at 2022-06-20 13:53:05.023745
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert obj[0] == 'a'
    assert obj[1] == 'b'



# Generated at 2022-06-20 13:53:09.033543
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    _DC = _DeprecatedSequenceConstant(BOOLEANS_TRUE, "msg", "2.10")
    for x in _DC:
        assert x in BOOLEANS_TRUE

# Generated at 2022-06-20 13:53:17.888155
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    import os

    # Test with old style config file
    fd, path = tempfile.mkstemp()
    try:
        config_content = '[defaults]\nroles_path=foo\n'
        os.write(fd, config_content.encode('utf-8'))
        config.set_config_file(path)
        set_constant('roles_path', 'bar')
        assert roles_path == 'foo'
    finally:
        os.close(fd)
        os.unlink(path)

    # Test with new style config file
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-20 13:53:19.746577
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant((1,2,3), "msg", "version")
    assert len(dsc) == 3
    assert dsc[1] == 2

# Generated at 2022-06-20 13:53:23.995491
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert isinstance(_DeprecatedSequenceConstant(value=(), msg='m', version='x'), Sequence)
    assert len(_DeprecatedSequenceConstant(value=(), msg='m', version='x')) == 0
    assert len(_DeprecatedSequenceConstant(value=(1,), msg='m', version='x')) == 1
    assert len(_DeprecatedSequenceConstant(value=(1,2), msg='m', version='x')) == 2


# Generated at 2022-06-20 13:53:29.701612
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Tests: _DeprecatedSequenceConstant.__getitem__

    This test should be moved to test/unit/utils/module_docs_fragments/doc_strings.py
    """
    # Arrange
    msg = "some message"
    version = "some version"
    deprecated_sequence_constant = _DeprecatedSequenceConstant([], msg, version)

    # Act
    deprecated_sequence_constant.__getitem__(0)

    # Assert

# Generated at 2022-06-20 13:53:31.154344
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant(tuple(), '', ''), Sequence)


# Generated at 2022-06-20 13:53:33.611450
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant = _DeprecatedSequenceConstant('test', 'test', 'test')
    assert len(sequence_constant) == len('test')
    assert sequence_constant[0] == 't'