

# Generated at 2022-06-20 13:43:42.497094
# Unit test for function set_constant
def test_set_constant():
    # test constant named "test" with value of "foo"
    set_constant('test', 'foo')
    assert test == 'foo'

# Generated at 2022-06-20 13:43:44.975090
# Unit test for function set_constant
def test_set_constant():
    global FOO
    set_constant('FOO', 'baz')
    assert FOO == 'baz'

# Generated at 2022-06-20 13:43:53.829403
# Unit test for function set_constant
def test_set_constant():
    global DEFAULT_BECOME_PASS
    global DEFAULT_REMOTE_PASS
    set_constant('DEFAULT_BECOME_PASS', '$y$$')
    assert DEFAULT_BECOME_PASS == '$y$$'
    set_constant('DEFAULT_REMOTE_PASS', '$y$$')
    assert DEFAULT_REMOTE_PASS == '$y$$'


# Generated at 2022-06-20 13:43:58.841962
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="deprecating", version="2.0")
    assert x._value == [1, 2, 3]
    assert x._msg == "deprecating"
    assert x._version == "2.0"

    assert len(x) == 3
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3

# Generated at 2022-06-20 13:44:01.171863
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([], 'Mock message', '1.1')

# Generated at 2022-06-20 13:44:09.303052
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import sys
    import os
    import tempfile
    import shutil
    import contextlib

    @contextlib.contextmanager
    def std_redirector(stdout=None, stderr=None):
        '''
        Temporarily redirect sys.stdout and sys.stderr by temporarily replacing them with a temp file
        '''
        oldout = sys.stdout
        olderr = sys.stderr

        newout = sys.stdout = tempfile.TemporaryFile()
        newerr = sys.stderr = tempfile.TemporaryFile()


# Generated at 2022-06-20 13:44:12.181277
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    assert l == _DeprecatedSequenceConstant(l, 'msg', 'version')[:]

# Generated at 2022-06-20 13:44:13.608117
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # TODO
    assert True



# Generated at 2022-06-20 13:44:15.914158
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant('abcd', 'message', '3.0')
    assert len(seq) == 4


# Generated at 2022-06-20 13:44:23.295528
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my_iterable = [5, 4, 3]
    my_deprecated_sequence_constant = _DeprecatedSequenceConstant(my_iterable, "The message", "2.0")
    assert len(my_deprecated_sequence_constant) == len(my_iterable)
    assert len(my_deprecated_sequence_constant) == 3



# Generated at 2022-06-20 13:44:30.288832
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test = _DeprecatedSequenceConstant((1, 2, 3), "test", "1.0")
    assert len(test) == 3
    assert test[1] == 2
    assert test[-1] == 3


# Generated at 2022-06-20 13:44:34.280781
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert len(d) == 3

# Generated at 2022-06-20 13:44:38.628820
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "This is test", "0.0.0.0")
    assert list(dsc) == [1, 2, 3]
    assert len(dsc) == 3
    assert dsc[0] == 1

# Generated at 2022-06-20 13:44:48.221826
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # test for a deprecation
    class DummyClass:
        def deprecated(self, msg, version):
            self.msg = msg
            self.version = version

    dummy = DummyClass()
    set_constant('dummy', dummy)
    msg = 'foobar'
    version = '1.1.1'
    value = ('bar', )
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'bar'
    assert dummy.msg == msg
    assert dummy.version == version

# Generated at 2022-06-20 13:44:57.967765
# Unit test for function set_constant
def test_set_constant():
    def test_env(name, value):
        import os
        os.environ[name] = value
        config.parse_only_existing_values()
        if 'ANSIBLE_' + name.upper() in os.environ:
            assert config[name] == value
        else:
            assert config[name] != value

    if not config.has_setting('gathering', 'implicit') and config.setting_is_changed('gathering', 'implicit'):
        # explicitly test this check
        config.settings.gathering.implicit = True  # setting_is_changed should return True
        assert config.setting_is_changed('gathering', 'implicit') == False  # setting_is_changed should return False

    # run the test with custom settings
    config.settings.gathering.implicit = True
    config.settings

# Generated at 2022-06-20 13:45:04.719711
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = _DeprecatedSequenceConstant(value=['a', 1], msg='this is a warning', version='3.0')
    assert isinstance(test_value, _DeprecatedSequenceConstant)
    assert isinstance(test_value, Sequence)
    assert test_value[0], 'a'
    assert test_value[1], 1
    assert test_value.__len__(), 2

# Generated at 2022-06-20 13:45:07.595787
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    mocked_value = []
    test_value = _DeprecatedSequenceConstant(mocked_value, "msg", "version")
    assert test_value[0] == mocked_value[0]



# Generated at 2022-06-20 13:45:14.200393
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def create_and_test_sequence(_expected_type):
        _msg = "This is a test of _DeprecatedSequenceConstant"
        _version = "2.0"
        _test_value = ["a", "test", "list"]

        _test_sequence = _DeprecatedSequenceConstant(_test_value, _msg, _version)

        assert(isinstance(_test_sequence, _expected_type))
        assert(len(_test_sequence) == len(_test_value))
        assert(_test_sequence[0] == _test_value[0])

    yield (create_and_test_sequence, list)
    yield (create_and_test_sequence, tuple)

# Generated at 2022-06-20 13:45:17.544621
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ('a', 'b')
    msg = 'list is deprecated'
    version = '2.8'
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert len(seq) == 2
    _deprecated.assert_called_once_with(msg, version)



# Generated at 2022-06-20 13:45:27.597666
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MyException(Exception):
        def __init__(self, message, version):
            super(MyException, self).__init__(message)
            self.version = version

    try:
        MyException('msg', '2.11')
        raise ValueError('unexpected exception type')
    except Exception as e:
        if not isinstance(e, MyException):
            raise ValueError('unexpected exception type')
        if e.message != 'msg':
            raise ValueError('unexpected exception message: ' + repr(e.message))
        if e.version != '2.11':
            raise ValueError('unexpected exception version: ' + repr(e.version))

# Generated at 2022-06-20 13:45:38.376342
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg='foo', version='1').__len__() == 3

# Generated at 2022-06-20 13:45:43.129807
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ('value1', 'value2')
    c = _DeprecatedSequenceConstant(value, msg, version)
    assert len(c) == 2
    assert c[0] == 'value1'
    assert c[1] == 'value2'

# Generated at 2022-06-20 13:45:44.790282
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3


# Generated at 2022-06-20 13:45:57.232189
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class FakeDisplay(object):
        def __init__(self):
            self.called = False

        def deprecated(self, message, version=None):
            self.called = True

    msg = "This message should be displayed"
    version = '2.0'

    seq = ['a', 'b', 'c']
    dep_seq = _DeprecatedSequenceConstant(seq, msg, version)

    assert dep_seq[0] == 'a'

    # Make sure Display.deprecated is called
    display = FakeDisplay()
    _warning(msg)
    _deprecated(msg, version)
    assert display.called



# Generated at 2022-06-20 13:46:03.292889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.5'
    sequence = [1, 2]
    test_instance = _DeprecatedSequenceConstant(sequence, msg, version)
    assert len(test_instance) == 2
    assert test_instance[1] == 2

# Generated at 2022-06-20 13:46:10.258490
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_seq = ('test_item')
    test_msg = 'Hello'
    test_version = '1.1'

    test_obj = _DeprecatedSequenceConstant(test_seq, test_msg, test_version)

    assert len(test_obj) == 1
    assert test_obj[0] == 'test_item'

# Generated at 2022-06-20 13:46:22.021570
# Unit test for function set_constant
def test_set_constant():
    # set_constant should convert all strings to unicode.
    set_constant('MY_STRING', 'foo')
    assert isinstance(MY_STRING, to_text)
    assert MY_STRING == 'foo'

    # set_constant should not modify an existing unicode value.
    MY_STRING = to_text('foo')
    set_constant('MY_STRING', MY_STRING)
    assert isinstance(MY_STRING, to_text)
    assert MY_STRING == 'foo'

    # set_constant should handle values that are not strings.
    set_constant('MY_NUMBER', 1)
    assert type(MY_NUMBER) == int
    assert MY_NUMBER == 1

    # set_constant should handle dictionary values.
    # ({'key': 'value'

# Generated at 2022-06-20 13:46:30.149558
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    val = [1, 2, 3]
    msg = "A test message"
    version = '0.0'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(val, msg, version)
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[0] == 1
    assert not hasattr(deprecated_sequence_constant, "append")


# Generated at 2022-06-20 13:46:35.906429
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class SampleClass:
        def __len__(self):
            return 2
        def __getitem__(self, y):
            return str(y)

    msg = 'this is deprecated'
    version = '2.8'
    instance = _DeprecatedSequenceConstant(SampleClass(), msg, version)
    assert len(instance) == 2
    assert instance[2] == '2'

# Generated at 2022-06-20 13:46:40.745710
# Unit test for function set_constant
def test_set_constant():
    hello = "world"
    set_constant("hello", "world")
    assert hello == "world"

if DEFAULT_BECOME_PASS is None:
    set_constant('DEFAULT_BECOME_PASS', DEFAULT_REMOTE_PASS)

if DEFAULT_REMOTE_PASS is None:
    set_constant('DEFAULT_REMOTE_PASS', DEFAULT_BECOME_PASS)

# Generated at 2022-06-20 13:47:09.974612
# Unit test for function set_constant
def test_set_constant():
    import ast
    import sys

    if sys.version_info[0] == 3:
        assert(COLOR_CODES['black'] == '0;30' and COLOR_CODES['normal'] == '0')
    else:
        assert(isinstance(COLOR_CODES['black'], unicode) and isinstance(COLOR_CODES['normal'], unicode))

    # No easy way to assert for this, but we can at least make sure it doesn't completely break
    export = {}
    set_constant('notbroken', 'test_value', export=export)
    assert(export['notbroken'] == 'test_value')


# Make sure symbols are exported
__all__ = [x for x in list(globals()) if not x.startswith('_')]

# Generated at 2022-06-20 13:47:16.533425
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Assert that if we try to use a deprecated sequence constant, we get the warning.
    class UnitMock():
        def warning(self, msg):
            self.msg = msg

    unit = UnitMock()
    constant = _DeprecatedSequenceConstant(('foo', ), 'bar', 'baz')

    with unit.patch("ansible.utils.display.Display.warning"):
        constant.__len__()

    assert unit.msg == 'bar, to be removed in baz'



# Generated at 2022-06-20 13:47:29.804368
# Unit test for function set_constant
def test_set_constant():
    ''' test setting constants '''

    # Reset the constants
    global TREE_DIR
    global MODULE_REQUIRE_ARGS
    TREE_DIR = None
    MODULE_REQUIRE_ARGS = tuple(add_internal_fqcns(('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                                                    'ansible.windows.win_shell', 'raw', 'script')))

    set_constant('TREE_DIR', '/tmp/')
    assert TREE_DIR == '/tmp/'

    set_constant('MODULE_REQUIRE_ARGS', ('ping', ))
    assert MODULE_REQUIRE_ARGS == ('ping', )

# Generated at 2022-06-20 13:47:36.964136
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(list(range(10)), 'getitem test', '0.0')
    assert s[2] == 2
    # TODO: arguments should be hardcoded, need to decide about new place for test constant
    assert s[-1] == 9
    assert s[-2] == 8
    assert s[:5] == list(range(5))
    assert s[5:] == list(range(5, 10))
    assert s[:-3] == list(range(7))
    assert s[1:-1:2] == [1, 3, 5, 7]


# Generated at 2022-06-20 13:47:45.624165
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant((1, 2, 3), "foo", "2.9")
    assert x[1] == 2


# Ensure we have not forgotten any configuration items.
# This is done by comparing the constants set above
# with the configuration items available in the config subdirectory.

# pylint: disable=unused-import
from ansible.config.defaults import *
# pylint: enable=unused-import

config_constants = set(globals().keys())
config_constants.difference_update(set(__all__))

# it's okay for these not to be in the defaults
# pylint: disable=unused-import
# pylint: disable=redefined-builtin
from ansible.constants import __all__ as constants_all
# pylint: enable

# Generated at 2022-06-20 13:47:48.712503
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'TEST_VALUE')
    assert 'TEST_VALUE' == TEST_CONSTANT


# Generated at 2022-06-20 13:47:54.691208
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = (1, 2, 3)
    test_msg = 'test message'
    test_version = '2.9'

    test = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_value) == len(test)


# Unit tests for constants, cannot be done at the module level

# Generated at 2022-06-20 13:47:57.316315
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class_ = _DeprecatedSequenceConstant(
        value=['a'],
        msg='test',
        version='test'
    )
    assert len(class_) == 1


# Generated at 2022-06-20 13:48:06.983430
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ()
    msg = 'test_deprecation'
    version = '2.14'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == 0
    assert dsc[0] is None

# Generated at 2022-06-20 13:48:10.076201
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '3.0')
    assert len(s) == 3


# Generated at 2022-06-20 13:48:55.430210
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import types

    # Test that the code works as expected
    msg = 'This is a deprecated message'
    version = '1.0'
    target = _DeprecatedSequenceConstant(['a'], msg, version)
    assert isinstance(target, _DeprecatedSequenceConstant)
    assert len(target) == 1
    assert target[0] == 'a'

    # Test that the code works as expected
    target = _DeprecatedSequenceConstant((1, 2, 3), msg, version)
    assert isinstance(target, _DeprecatedSequenceConstant)
    assert len(target) == 3
    assert target[2] == 3

    # Test that the code works as expected
    target = _DeprecatedSequenceConstant(set([1, 2, 3]), msg, version)

# Generated at 2022-06-20 13:48:59.005916
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(value=['a'],
                                           msg='This is deprecated',
                                           version='2.8')
    assert len(constant) == 1
    assert constant[0] == 'a'

# Generated at 2022-06-20 13:49:05.471031
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence = _DeprecatedSequenceConstant(('1', '2', '3'), 'Test message', '2.0')
    assert len(deprecated_sequence) == 3
    assert deprecated_sequence[0] == '1'
    for index in (1, 2):
        assert deprecated_sequence[index] == str(index + 1)
    assert len(deprecated_sequence) == 3

# Generated at 2022-06-20 13:49:08.781684
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_object = _DeprecatedSequenceConstant(value=("a", "b"), msg="a message", version="2.8")
    if len(test_object) != len(("a", "b")):
        raise AssertionError("'__len__' method of '_DeprecatedSequenceConstant' class is not working properly")

# Generated at 2022-06-20 13:49:20.800731
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def _check(obj, msg, version):
        assert obj._msg == msg
        assert obj._version == version
        assert not isinstance(obj, _DeprecatedSequenceConstant)
        assert len(obj) == len([1, 2, 3])
        assert obj[1] == [1, 2, 3][1]
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    _check(obj, 'msg', 'version')
    obj = obj + [4, 5]
    _check(obj, 'msg', 'version')
    obj = obj * 5
    _check(obj, 'msg', 'version')
    assert obj[2:7:2] == [1, 2, 3] * 2 + [4]



# Generated at 2022-06-20 13:49:27.276060
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Setup test values
    test_name = '_test_name'
    test_value = [1, 2]
    test_msg = 'test message'
    test_version = '1.0'

    # Create test object
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # Test getitem method
    assert test_obj[0] == 1

    # Test getitem method on last element
    assert test_obj[1] == 2

# Generated at 2022-06-20 13:49:28.549372
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass



# Generated at 2022-06-20 13:49:37.699398
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_ANSIBLE_SSH_ARGS', '-C -o ControlMaster=auto -o ControlPersist=60s')
    assert ANSIBLE_ANSIBLE_SSH_ARGS == '-C -o ControlMaster=auto -o ControlPersist=60s'


# for backwards compatibility
DEFAULT_HOST_LIST = LOCALHOST
DEFAULT_DEBUG = False
DEFAULT_SUDO_PASS = None
DEFAULT_SUDO = False
DEFAULT_SUDO_USER = 'root'
DEFAULT_ASK_SUDO_PASS = False
DEFAULT_ASK_PASS = False
DEFAULT_REMOTE_USER = None
DEFAULT_PRIVATE_KEY_FILE = None
DEFAULT_TIMEOUT = 10
DEFAULT_POLL_INTERVAL = 15
DEFAULT_

# Generated at 2022-06-20 13:49:44.793061
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.six import string_types

    # Test if function set_constant set constants correctly
    set_constant("CONST_STR", "const_string")
    set_constant("CONST_LIST", ["const", "list"])
    set_constant("CONST_TUPLE", ("const", "tuple"))
    set_constant("CONST_DICT", {"const": "dict"})
    set_constant("CONST_BOOL", False)
    set_constant("CONST_INT", 1)
    set_constant("CONST_FLOAT", 1.1)

    # Test if constants are set correctly
    assert CONST_STR == "const_string"

# Generated at 2022-06-20 13:49:47.046141
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], "test message", "test version")
    assert len(deprecated_sequence_constant) == 3

# Generated at 2022-06-20 13:51:09.857762
# Unit test for function set_constant
def test_set_constant():
    expected = {'foo': 'bar', 'baz': 'qux', 'qux': 'qux'}
    result = {}
    set_constant('foo', 'bar', result)
    assert result == expected
    set_constant('baz', 'qux', result)
    assert result == expected
    set_constant('qux', 'foo', result)
    assert result != expected

# Generated at 2022-06-20 13:51:12.281360
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value       = ('abc',)
    msg         = 'this is a warning message'
    version     = '2.0'
    test_object = _DeprecatedSequenceConstant(value, msg, version)
    assert(len(test_object) == len(value))


# Generated at 2022-06-20 13:51:21.339451
# Unit test for function set_constant

# Generated at 2022-06-20 13:51:27.071066
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class TestDeprecatedSequenceConstant(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            _DeprecatedSequenceConstant.__init__(self, value, msg, version)
            self.deprecation_warnings = []

    # Generate a constant with given value
    testConstant = TestDeprecatedSequenceConstant(value=['a'], msg="deprecation warning", version="2.1")

    # Call __len__() method of testConstant
    len_value = testConstant.__len__()

    # Assert if len_value is equal to 1
    assert len_value == 1


# Generated at 2022-06-20 13:51:30.541239
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    data = ['a', 'b', 'c']
    msg = 'this is a message'
    version = '2.6'
    obj = _DeprecatedSequenceConstant(data, msg, version)
    assert_equal(obj[0], data[0])


# Generated at 2022-06-20 13:51:33.946236
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('test_fq_name', 'test_fq_value', export=test_dict)
    assert test_dict['test_fq_name'] == 'test_fq_value'

# Generated at 2022-06-20 13:51:42.161434
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test for TYPE
    assert isinstance(_DeprecatedSequenceConstant([1, 2], 'msg', 'version'), Sequence)

    # test when we have multiple elements in the list
    list_test = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert list_test[0] == 1
    assert list_test[1] == 2

    # test when we have only one element in the list
    list_test1 = _DeprecatedSequenceConstant([1], 'msg', 'version')
    assert list_test1[0] == 1

    # test whether it is generating the right message
    list_test2 = _DeprecatedSequenceConstant([1, 2], 'message', 'version')
    list_test2[0]


# Generated at 2022-06-20 13:51:45.322339
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(["a","b","c"], "msg", "version")
    assert d[0] == "a"


# Generated at 2022-06-20 13:51:49.016091
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', '1')

    assert 'test' in globals()
    assert globals()['test'] == u'1'

    globals().pop('test')
    assert 'test' not in globals()



# Generated at 2022-06-20 13:51:52.737704
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 2)
    set_constant('FOO', 2, vars())
    assert FOO == 2
    assert vars()['FOO'] == 2

    set_constant('BAR', 30)
    assert BAR == 30