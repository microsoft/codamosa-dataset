

# Generated at 2022-06-20 13:43:47.094932
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.errors import AnsibleDeprecationWarning
    import warnings
    warnings.simplefilter('error', AnsibleDeprecationWarning)

    msg = "some string"
    version = "1.2.3"

    try:
        _DeprecatedSequenceConstant([1], msg, version)[0]
        assert False, "__getitem__() did not throw a AnsibleDeprecationWarning"
    except AnsibleDeprecationWarning:
        # __getitem__() throws a AnsibleDeprecationWarning, as expected
        pass
    except Exception as e:
        assert False, "{} was thrown instead of a AnsibleDeprecationWarning".format(type(e).__name__)
    finally:
        warnings.resetwarnings()



# Generated at 2022-06-20 13:43:57.008139
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''
    Instantiate the class and check if the _value type, _msg, _version
    is preserved
    '''
    msg = u'This is a test message'
    version = '2.10'
    valid_values = [None, [], {}, '', u'', 1, 1.1, True, False]

    for value in valid_values:
        dsc_obj = _DeprecatedSequenceConstant(value, msg, version)
        assert isinstance(dsc_obj, Sequence)
        assert value == dsc_obj._value
        assert msg == dsc_obj._msg
        assert version == dsc_obj._version



# Generated at 2022-06-20 13:44:06.522941
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('test1', 'foo', export=test_dict)
    assert test_dict == {'test1': 'foo'}
    set_constant('test2', ['foo', 'bar'], export=test_dict)
    assert test_dict == {'test1': 'foo', 'test2': ['foo', 'bar']}
    # replace existing value
    set_constant('test2', 'bar', export=test_dict)
    assert test_dict == {'test1': 'foo', 'test2': 'bar'}

# Generated at 2022-06-20 13:44:10.677812
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = ['test']
    a = _DeprecatedSequenceConstant(l, "msg", "2.9")
    assert(len(l) == len(a))


# Generated at 2022-06-20 13:44:17.215129
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Test when msg contains non-ASCII characters
    def test_case_1():
        sut = _DeprecatedSequenceConstant(['value1'], u'\u3044\u3044\u3044', '4.0.0')
        result = sut[0]
        assert result == 'value1'

    test_case_1()


test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-20 13:44:20.344441
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant(list(range(10)), "msg", "version")
    assert sequence_constant[3] == 3, (sequence_constant[3], 3)
    assert sequence_constant[9] == 9, (sequence_constant[9], 9)

# Generated at 2022-06-20 13:44:25.703060
# Unit test for function set_constant
def test_set_constant():
    result = dict(ANSIBLE_CACHE_PLUGIN_CONNECTION='/tmp')
    set_constant('ANSIBLE_CACHE_PLUGIN_CONNECTION', '/tmp', result)
    assert result['ANSIBLE_CACHE_PLUGIN_CONNECTION'] == '/tmp'


# ... and finally some sanity checks
assert ANSIBLE_CONFIG is not None, "config file not found: %s" % ANSIBLE_CONFIG
if not HAS_CRYPTOGRAPHY:
    _warning("The cryptography Python module is not installed. "
             "Encryption capabilities will not be available.")

# Generated at 2022-06-20 13:44:29.269039
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('TEST_CONSTANT', 'TEST_VALUE', test_dict)
    assert test_dict.get('TEST_CONSTANT') == 'TEST_VALUE'


# Generated at 2022-06-20 13:44:31.389673
# Unit test for function set_constant
def test_set_constant():
    set_constant("TEST_CONSTANT", True)
    assert TEST_CONSTANT is True

# Generated at 2022-06-20 13:44:36.683416
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', u'3.0')
    expected_len__value = 3
    expected_getitem__value = 3
    assert len(sequence_constant) == expected_len__value
    assert sequence_constant[2] == expected_getitem__value

# Generated at 2022-06-20 13:44:51.934341
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Verifies that _WARNING is returned
    msg = 'This is a deprecated message'
    version = '2.3'
    value = ['1', '2', '3']
    constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(constant) == 3
    assert constant[0] == '1'
    assert constant[1] == '2'
    assert constant[2] == '3'


# Make the deprecated constants
set_constant('DEFAULT_SUDO_PASS', _DeprecatedSequenceConstant(DEFAULT_BECOME_PASS,
                                                              'DEFAULT_SUDO_PASS is no longer used, please use DEFAULT_BECOME_PASS instead',
                                                              '2.6'))

# Generated at 2022-06-20 13:45:06.275451
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Test 1:
    # Test that retrieving an item from a _DeprecatedSequenceConstant object
    # will cause a DeprecationWarning.
    # Expected values:
    #     - dep_seq_const.val.__getitem__.warning.call_count == 1
    #     - dep_seq_const[0] == some_value

    dep_seq_const = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'ver')
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        retval = dep_seq_const[0]
        assert w[0].category == DeprecationWarning
        assert len(w) == 1
        assert w[0].message.args[0] == 'msg, to be removed in ver'
    assert ret

# Generated at 2022-06-20 13:45:12.074896
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = '2.0'
    value = ['1', '2', '3']
    deprecated_sequence = _DeprecatedSequenceConstant(value, msg, version)

    assert len(deprecated_sequence) == 3
    assert deprecated_sequence[0] == 1
    assert deprecated_sequence[1] == 2
    assert deprecated_sequence[2] == 3

    assert deprecated_sequence._msg == msg
    assert deprecated_sequence._version == version

# Generated at 2022-06-20 13:45:16.767576
# Unit test for function set_constant
def test_set_constant():
    vars()['ANSIBLE_FOO_BAR'] = None
    set_constant('ANSIBLE_FOO_BAR', 32)
    assert ANSIBLE_FOO_BAR == 32


CONNECTION_PLUGINS = tuple(CONNECTION_PLUGINS.split(','))

# Generated at 2022-06-20 13:45:28.215300
# Unit test for function set_constant
def test_set_constant():
    assert CONNECTION_RETRIES_DEFAULT == '30'
    assert CONNECTION_RETRIES == 5
    assert DEBUG == True
    assert INVENTORY == '/dev/null'
    assert DEFAULT_VAULT_IDENTITY_LIST == ('ansible_ssh_user', 'ansible_user', 'ansible_become_user')
    assert MODULE_CACHE == '/tmp/.ansible-module-cache'
    assert LOOKUP_CACHE == '/tmp/.ansible-lookup-cache'

# now that we've got these imported (and some are functions),
# we can look up the constants used in the logic below
try:
    from ansible.utils.module_docs import BLACKLIST_EXTS
    BLACKLIST_EXTS += REJECT_EXTS
except ImportError:
    BLACKLIST_EXTS = RE

# Generated at 2022-06-20 13:45:36.874059
# Unit test for function set_constant
def test_set_constant():
    assert CONFIG_FILE == './cfg/ansible.cfg'
    assert DATA_DIR == './data'
    assert HOST_KEY_CHECKING == False


# Attempt to handle braindead distros
# FIXME: create more braindead systems, kill them
CUSTOM_SYSCTL_PATH = None

try:
    import platform
    UNAME = platform.uname()
    DISTRO = UNAME[0]
    DIST_VERSION = UNAME[2]

    # FIXME: this is starting to become braindead
    if DISTRO == "Darwin":
        CUSTOM_SYSCTL_PATH = '/usr/sbin'
except ImportError:  # platform is not always available
    pass



# Generated at 2022-06-20 13:45:39.480124
# Unit test for function set_constant
def test_set_constant():
    global TREE_DIR
    TREE_DIR = 'test'
    assert TREE_DIR == 'test'

# Unit tests for function _warning

# Generated at 2022-06-20 13:45:47.053650
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dummy_value = ['dummy_value1', 'dummy_value2']
    dummy_msg = 'this is a dummy msg'
    dummy_version = 'dummy_version'

    # initialize DeprecatedSequenceConstant class
    dsc = _DeprecatedSequenceConstant(dummy_value, dummy_msg, dummy_version)
    assert len(dsc) == 2
    assert dsc[0] == 'dummy_value1'
    assert dsc[1] == 'dummy_value2'



# Generated at 2022-06-20 13:45:53.776448
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg='msg', version='1.0')
    assert d[0] == 'a'
    assert d[1] == 'b'
    assert d[2] == 'c'
    assert d[-1] == 'c'



# Generated at 2022-06-20 13:45:58.154757
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ('foo', 'bar', 'baz')
    msg = 'baz is deprecated'
    version = '2.9'
    deprecated = _DeprecatedSequenceConstant(value, msg, version)

    assert deprecated[0] == 'foo'
    assert deprecated[1] == 'bar'
    assert deprecated[2] == 'baz'

# Generated at 2022-06-20 13:46:08.846560
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    key = 'key'
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)
    assert deprecated[key] == value[key]

# Generated at 2022-06-20 13:46:11.130998
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list(range(3)), 'message', 'version_number')) == 3

# Generated at 2022-06-20 13:46:14.640834
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert sequence_constant.__getitem__(0) == 'value'

# Generated at 2022-06-20 13:46:17.356335
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(list(range(10)), 'Test message', '2.11')
    assert dsc[5] == 5


# Generated at 2022-06-20 13:46:19.993227
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([], None, None)[0] == []
    assert _DeprecatedSequenceConstant([1,2,3], None, None)[2] == 3


# Generated at 2022-06-20 13:46:25.779828
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.12')
    len(seq) == 3

# Generated at 2022-06-20 13:46:37.673207
# Unit test for function set_constant
def test_set_constant():
    # set a scalar variable within a namespace then read it back
    namespace = __builtins__
    set_constant('TEST_SCALAR_VAR', 'test scalar variable', export=namespace)
    assert 'TEST_SCALAR_VAR' in namespace
    assert namespace['TEST_SCALAR_VAR'] == 'test scalar variable'

    # set a hash variable within a namespace then read it back
    namespace = __builtins__
    set_constant('TEST_HASH_VAR', {'test': 'hash variable'}, export=namespace)
    assert 'TEST_HASH_VAR' in namespace
    assert namespace['TEST_HASH_VAR'] == {'test': 'hash variable'}

    # set a list variable within a namespace then read it back
    namespace = __built

# Generated at 2022-06-20 13:46:40.659174
# Unit test for function set_constant
def test_set_constant():
    ''' Unit test for function set_constant '''
    constant_value = 1
    export = {}
    set_constant('CONSTANT', constant_value, export)
    assert export['CONSTANT'] == constant_value

# Generated at 2022-06-20 13:46:43.718998
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert len(value) == 3


# Generated at 2022-06-20 13:46:53.188145
# Unit test for function set_constant
def test_set_constant():
    class A(object): # pylint: disable=R0903
        pass

    class B(A):
        pass

    def test(A):
        a = A()
        set_constant('a', a)
        assert 'a' in vars()
        if isinstance(a, B):
            assert vars()['a'] is a
            assert not 'b' in vars()
        elif isinstance(a, A):
            assert not vars()['a'] is a
            assert 'b' in vars()
        else:
            raise AssertionError

    test(A)
    test(B)



# Generated at 2022-06-20 13:47:10.484474
# Unit test for function set_constant
def test_set_constant():
    x = {}
    set_constant('FOO', 'foo', export=x)
    assert x['FOO'] == 'foo'
    set_constant('BAR', 'bar', export=x)
    assert x['FOO'] == 'foo'
    assert x['BAR'] == 'bar'


# FIXME: remove once play_context mangling is removed
MAGIC_VARIABLE_REWRITE = {}
for key, var_names in MAGIC_VARIABLE_MAPPING.items():
    for var_name in var_names:
        MAGIC_VARIABLE_REWRITE[var_name] = key

# Generated at 2022-06-20 13:47:18.802461
# Unit test for function set_constant
def test_set_constant():
    assert run_command == u'ls -l'
    assert ANSIBLE_NOCOWS != u'1'
    assert ANSIBLE_FORCE_COLOR is True
    assert C.DEFAULT_SUDO_USER == u'root'
    assert C.DEFAULT_SUBSET == u''

test_set_constant()

# these are all somewhat internal and should not be used outside of the
# action plugins and Ansible core, but this was the easiest place to put
# them while they're still here.  The more they are used, the more they
# should be moved out of this file.
QQQ_STR_ARG = '-a'
QQQ_BOOLEAN = True
QQQ_INTEGER = 0
QQQ_SOMEDICT = dict(foo='bar')
QQQ_

# Generated at 2022-06-20 13:47:21.414312
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_const = _DeprecatedSequenceConstant((), '', '')
    assert seq_const.__getitem__(0) == None


# Generated at 2022-06-20 13:47:28.675337
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Tests are not available over here.
    # This test is to ensure that the class is detected properly.
    dsc = _DeprecatedSequenceConstant(value=[], msg='Testing', version='2.8')
    assert len(dsc) == 0
    assert dsc[0:] == []

# vim: set expandtab ts=4 sts=4 sw=4 fileencoding=utf-8:

# Generated at 2022-06-20 13:47:31.056721
# Unit test for function set_constant
def test_set_constant():
    local_export = {}
    set_constant('FOO', 'bar', export=local_export)
    assert local_export['FOO'] == 'bar'

# Generated at 2022-06-20 13:47:33.739868
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert len(c) == 3
    assert c[1] == 2

# Generated at 2022-06-20 13:47:37.944295
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant(('ansible.builtin.copy', 'ansible.module_utils.basic.copy'), 'test', '2.10')
    assert test_object[0] == 'ansible.builtin.copy'


# Generated at 2022-06-20 13:47:43.389566
# Unit test for function set_constant
def test_set_constant():
    a = {}
    set_constant('foo', 'bar', export=a)
    set_constant('foo2', 'bar', export=a)
    set_constant('foo3', 'bar', export=a)
    set_constant('foo4', 'bar', export=a)
    assert 'foo' in a
    assert 'foo2' in a
    assert 'foo3' in a
    assert 'foo4' in a

# Generated at 2022-06-20 13:47:45.644979
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([], "msg", "version")
    assert x[0] is None

# Generated at 2022-06-20 13:47:54.560635
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(('a', 'b'), 'msg', '1.0')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert len(dsc) == 2
    assert list(dsc) == ['a', 'b']

if __name__ == '__main__':
    import sys
    import warnings

    warnings.simplefilter('always')
    test__DeprecatedSequenceConstant()

    print('OK')
    sys.exit(0)

# Generated at 2022-06-20 13:48:17.225213
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Testing _DeprecatedSequenceConstant', '2.8')
    assert list(dsc) == [1, 2, 3]
    assert len(dsc) == 3
    assert 1 in dsc
    assert 4 not in dsc
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3
    assert dsc[-2] == 2
    assert dsc[-3] == 1
    assert dsc[1:2] == [2]

# Generated at 2022-06-20 13:48:21.954411
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(value='', msg='', version='')
    obj_dict = vars(obj)
    assert callable(obj_dict['__len__'])

# Generated at 2022-06-20 13:48:28.518495
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class A(object):
        def __repr__(self):
            return "A"

    a = A()
    a_list = [A(), A()]
    a_list_var = _DeprecatedSequenceConstant(a_list, msg='test_msg', version='test_version')

    assert a_list_var[0] == a
    assert a_list_var[1] == a


# Generated at 2022-06-20 13:48:32.754790
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sut = _DeprecatedSequenceConstant([1, 2, 3], 'test message', 'test version')
    assert sut[0] == 1
    assert sut[1] == 2
    assert sut[2] == 3
    assert sut[-1] == 3



# Generated at 2022-06-20 13:48:39.205474
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['test'], 'test', 1.0)) == 1
    assert _DeprecatedSequenceConstant(['test'], 'test', 1.0)[0] == 'test'

# Generated at 2022-06-20 13:48:42.912191
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    depseqconst = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'ver')
    assert depseqconst[0] == 'a'
    assert depseqconst[1] == 'b'

# Generated at 2022-06-20 13:48:46.639444
# Unit test for function set_constant
def test_set_constant():
    vars_dict = {}
    set_constant('passwd', 'abc', export=vars_dict)
    assert vars_dict['passwd'] == 'abc'


# Generated at 2022-06-20 13:48:50.370205
# Unit test for function set_constant
def test_set_constant():
    local_dict = {}
    set_constant('TEST_CONST', 'test', export=local_dict)
    assert local_dict['TEST_CONST'] == 'test'
    assert locals()['TEST_CONST'] != 'test'



# Generated at 2022-06-20 13:48:53.633898
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1,2,3], 'test', '1.0')
    assert len(obj) == 3


# Generated at 2022-06-20 13:49:06.187923
# Unit test for function set_constant
def test_set_constant():
    # Reset the config
    config.data = ConfigManager._parse_config_file()

    # Reset the export
    export = {}

    # Setting a string
    value = 'is a test'
    set_constant('STRING_TEST', value)
    assert config.STRING_TEST == value
    assert ALLOW_WORLD_READABLE_TMPFILES is False

    # Setting a boolean
    value = True
    set_constant('BOOLEAN_TEST', value)
    assert config.BOOLEAN_TEST == value

    # Passing in a custom export
    value = 'is a new test'
    set_constant('STRING_TEST', value, export)
    assert config.STRING_TEST != value
    assert export['STRING_TEST'] == value


test_set_

# Generated at 2022-06-20 13:49:54.461832
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant(['a', 'b'], 'test', '0.0')
    assert result[0] == 'a'
    assert result[1] == 'b'
    assert result[-1] == 'b'


# Generated at 2022-06-20 13:50:02.148793
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test string
    a = _DeprecatedSequenceConstant('qwerty', 'test', '1.0')
    assert a[3] == 'r'

    # test list
    b = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')
    assert b[1] == 2

    # test dict
    c = _DeprecatedSequenceConstant({'q':1, 'w':2}, 'test', '1.0')
    assert c['q'] == 1


# Generated at 2022-06-20 13:50:05.504871
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[_ACTION_INCLUDE_TASKS], msg='blah', version='1.1.1')
    assert dsc[0] == _ACTION_INCLUDE_TASKS


# Generated at 2022-06-20 13:50:07.763473
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'some message', '2.10')
    assert len(x) == 3

# Generated at 2022-06-20 13:50:10.988118
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(['a', 'b'], 'foo', 'bar')
    assert len(constant) == 2


# Generated at 2022-06-20 13:50:13.180395
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # TODO: This needs to be made more robust
    assert _DeprecatedSequenceConstant([1,2,3], "Test", "2.9")[0] == 1

# Generated at 2022-06-20 13:50:19.510697
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant() when value is a tuple.
    msg = "This is a test for _DeprecatedSequenceConstant() when value is a tuple."
    version = "2.9"
    obj = _DeprecatedSequenceConstant(('a', 'b', 'c') , msg, version)
    assert obj[2] == 'c'

    # Test for _DeprecatedSequenceConstant() when value is a list.
    msg = "This is a test for _DeprecatedSequenceConstant() when value is a list."
    version = "2.9"
    obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert obj[2] == 'c'



# Generated at 2022-06-20 13:50:22.917993
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(('a', 'b'), 'message', 'version')
    assert len(dsc) == 2

# Generated at 2022-06-20 13:50:30.244586
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value_test = ['cows', 'sheep']
    msg_test = "This is deprecated"
    version_test = '2.8'

    test_object = _DeprecatedSequenceConstant(value_test, msg_test, version_test)
    assert(test_object._value == value_test)
    assert(test_object._msg == msg_test)
    assert(test_object._version == version_test)
    assert(test_object.__len__() == 2)
    assert(test_object.__getitem__(0) == 'cows')
    assert(test_object.__getitem__(1) == 'sheep')

# Generated at 2022-06-20 13:50:38.278556
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # invalid type for y
    try:
        obj = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
        obj['abc']
    except TypeError as e:
        assert "list indices must be integers, not str" in str(e)
    else:
        assert False

    # invalid value for y
    try:
        obj = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
        obj[3]
    except IndexError as e:
        assert "list index out of range" in str(e)
    else:
        assert False


# Generated at 2022-06-20 13:52:21.377941
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')[0] == []

# Generated at 2022-06-20 13:52:27.232307
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_ = _DeprecatedSequenceConstant
    assert [(2, 4), (7, 9, 11)] == class_([(2, 4), (7, 9, 11)], "Test msg", "1.1.1")
    assert False == isinstance(class_([(2, 4), (7, 9, 11)], "Test msg", "1.1.2"), int)


# Generated at 2022-06-20 13:52:33.097540
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.six import PY3
    seq = ('test', 'test2')
    dsc = _DeprecatedSequenceConstant(seq, 'testmsg', 'testversion')
    index = 1
    if PY3:
        assert dsc[index] == seq[index]
    else:
        assert dsc.__getitem__(index) == seq.__getitem__(index)

# Generated at 2022-06-20 13:52:35.903119
# Unit test for function set_constant
def test_set_constant():
    global MY_CONSTANT
    set_constant('MY_CONSTANT', 'FOO', globals())
    assert MY_CONSTANT == 'FOO'


# Generated at 2022-06-20 13:52:43.660478
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Case 1. Check that the method works properly
    constants1 = {'deprecated_constant_name': _DeprecatedSequenceConstant(['1', '2', '3'], 'Test deprecated constant', '2.8.0')}
    assert constants1['deprecated_constant_name'][0] == '1'
    assert constants1['deprecated_constant_name'][1] == '2'
    assert constants1['deprecated_constant_name'][2] == '3'

    # Case 2. Check that the method raises IndexError if out of bounds index is specified
    try:
        constants1['deprecated_constant_name'][4]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError should be raised but not')

# Generated at 2022-06-20 13:52:46.088172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['1', '2', '3']
    msg = 'test'
    version = '2.0'
    c = _DeprecatedSequenceConstant(value, msg, version)
    assert c._value == value
    assert c._msg == msg
    assert c._version == version

# Generated at 2022-06-20 13:52:48.559579
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([], "message", "version")
    assert len(s) == 0


# Generated at 2022-06-20 13:52:58.434691
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    ok = [True]

    class CollectingWarning(object):
        msgs = []
        def write(self, msg):
            self.msgs.append(msg)

    import sys
    saved_stderr = sys.stderr
    sys.stderr = CollectingWarning()

    try:
        seq = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='Test Message', version='2.2')
        if seq[0] != 1:
            ok[0] = False
        if seq[1] != 2:
            ok[0] = False
        if seq[2] != 3:
            ok[0] = False
        if len(seq) != 3:
            ok[0] = False
    finally:
        msg = b''.join(sys.stderr.msgs).dec

# Generated at 2022-06-20 13:53:07.160154
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = list('abc')
    msg = 'abc'
    version = '1.0'
    d = _DeprecatedSequenceConstant(value, msg, version)
    assert d.__getitem__(1) == 'b'
    assert d.__getitem__((1,)) == [value[1]]
    assert d.__getitem__((1, 2)) == [value[1], value[2]]
    assert d.__getitem__(slice(2)) == value[2:]
    assert d.__getitem__(slice(1, 2)) == value[1:2]
    assert d.__getitem__(slice(2, 1)) == value[2:1]


# Generated at 2022-06-20 13:53:09.437669
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], "message", "version")
    assert constant[1] == 2
