

# Generated at 2022-06-20 13:43:44.983974
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated = _DeprecatedSequenceConstant(
        tuple("ab"),
        "Testing the __getitem__ method of _DeprecatedSequenceConstant class",
        "1.0.0",
    )
    assert len(deprecated) == 2
    assert deprecated[0] == "a"
    assert deprecated[1] == "b"
    assert deprecated[0:1] == tuple("a")
    assert deprecated[1:2] == tuple("b")
    assert deprecated[0] == deprecated[0]
    assert deprecated[1] == deprecated[1]
    assert deprecated[0] != deprecated[1]
    assert len(deprecated[0:1]) == 1
    assert len(deprecated[1:2]) == 1
    assert deprecated[0:1] != deprecated[1:2]



# Generated at 2022-06-20 13:43:47.840323
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Case when string is empty
    assert _DeprecatedSequenceConstant('', 'msg', 'version').__len__() == 0
    # Case with string that does not contain only digits
    assert _DeprecatedSequenceConstant('abc', 'msg', 'version').__len__() == 3

# Generated at 2022-06-20 13:43:58.694615
# Unit test for function set_constant
def test_set_constant():
    ''' test that set_constant is working as expected '''
    _base = {}
    set_constant('blah', 'foo', export=_base)
    assert _base['blah'] == 'foo'

DEFAULT_PRIVATE_ROLE_VARS_PLUGIN = ('safe_yaml', )
PRIVATE_ROLE_VARS_PLUGINS = ('safe_yaml', 'encrypted_yaml', )

# This is a proper subset of PRIVATE_ROLE_VARS_PLUGINS
# It is not possible to access variable files matching this
# with the variable precedence rules.
# These plugins are intended to be used with include_role and
# that context allows full access to variable files in the
# directories regardless of precedence.
# See issue #32589, this change is also based on the principle that


# Generated at 2022-06-20 13:44:08.098997
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from collections import namedtuple
    from ansible.module_utils.common.collections import Sequence

    # Tests for method __getitem__
    # Returns x[y]
    TestCase = namedtuple('TestCase', ['value', 'msg', 'version', 'index', 'expected'])

    seq = _DeprecatedSequenceConstant(['a', 'b'], 'msg', '1.2.3')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    try:
        seq[-1]
        assert False
    except IndexError:
        assert True


# Generated at 2022-06-20 13:44:12.367293
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep_seq_cons = _DeprecatedSequenceConstant([1, 2, 3], "This is a test", "2.9")
    assert len(dep_seq_cons) == 3
    assert dep_seq_cons[0] == 1


# Generated at 2022-06-20 13:44:18.643578
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import unittest
    class _Test__DeprecatedSequenceConstant___len__(unittest.TestCase):
        def test__DeprecatedSequenceConstant___len__(self):
            self.assertEqual(len(DEFAULT_HOST_LIST), 1)
            self.assertEqual(len(DEFAULT_MODULE_NAME), 1)
    unittest.main(module=__name__, exit=False)


# Generated at 2022-06-20 13:44:26.702883
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "The test_key has been deprecated"
    version = '0.99'
    test_data = ['A', 'B', 'C']
    test_obj = _DeprecatedSequenceConstant(test_data, msg, version)
    for index in range(len(test_data)):
        assert test_obj[index] == test_data[index]

# Generated at 2022-06-20 13:44:29.090894
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1,2,3], "test", "2.9")
    assert len(c) == 3


# Generated at 2022-06-20 13:44:31.818147
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_list = _DeprecatedSequenceConstant((1, 2, 3), msg='msg', version='version')
    assert(len(deprecated_list) == 3)



# Generated at 2022-06-20 13:44:39.220927
# Unit test for function set_constant
def test_set_constant():
    value = set_constant.__globals__['DEFAULT_HOST_LIST']
    def_value_str = '127.0.0.1,'

    # test default_host_list
    assert value == def_value_str


# Type handling

# Used by ansible.playbook.role.definition to mark role/import task params
# as no_log at a parser level.
# TODO: is this still needed?

# Generated at 2022-06-20 13:44:45.337154
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert(foo == 'bar')


# Generated at 2022-06-20 13:44:50.969531
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'deprecated'
    version = '2.0'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-20 13:44:55.160279
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant_value = ['test', 'test2']
    msg = 'debug msg'
    version = '2.0'
    constant = _DeprecatedSequenceConstant(constant_value, msg, version)
    assert len(constant) == 2
    assert constant[0] == 'test'
    assert constant[1] == 'test2'

# Generated at 2022-06-20 13:44:59.260110
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1,2], 'this is deprecated', '2.4')
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2


# Generated at 2022-06-20 13:45:10.712445
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import copy
    import collections
    test_list = ['one', 'two', 'three']
    test_tuple = tuple(test_list)
    # length of list and tuple must be the same
    assert len(test_list) == len(test_tuple)
    # check that length of _DeprecatedSequenceConstant is the same as of list
    assert len(test_list) == len(_DeprecatedSequenceConstant(test_list, 'Test', '2.0'))
    # check that length of _DeprecatedSequenceConstant is the same as of tuple
    assert len(test_tuple) == len(_DeprecatedSequenceConstant(test_tuple, 'Test', '2.0'))
    # check that length of _DeprecatedSequenceConstant is the same as of list which is converted to tuple
    assert len

# Generated at 2022-06-20 13:45:12.186253
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-20 13:45:20.690067
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_string', 'foo', export=vars())
    assert vars()['test_string'] == 'foo'

    set_constant('test_int', 1, export=vars())
    assert vars()['test_int'] == 1

    set_constant('test_float', 1.1, export=vars())
    assert vars()['test_float'] == 1.1

    set_constant('test_list', ['foo','bar'], export=vars())
    assert vars()['test_list'] == ['foo','bar']

    set_constant('test_dict', {'foo': 'bar'}, export=vars())
    assert vars()['test_dict'] == {'foo': 'bar'}


# Generated at 2022-06-20 13:45:35.525693
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Replace with a mock object for test purposes
    from ansible.utils.display import Display
    Display.warning = lambda *x: x  # noqa

    s = _DeprecatedSequenceConstant((1, 2, 3), "msg1", "version1")
    assert s[0] == 1
    assert s[1] == 2
    assert s[2] == 3
    assert len(s) == 3

    s = _DeprecatedSequenceConstant([1, 2, 3], "msg2", "version2")
    assert s[0] == 1
    assert s[1] == 2
    assert s[2] == 3
    assert len(s) == 3


# Plugins subdirectories and their initialization functions
PLUGIN_PATH_CACHE = {}
PLUGIN_PATH_CACHE_TIME = {}


# Generated at 2022-06-20 13:45:39.389509
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t1 = _DeprecatedSequenceConstant([1,2,3], 'test', 'n/a')
    assert len(t1) == 3
    assert [1,2,3] == t1[0:3]

# Generated at 2022-06-20 13:45:44.754769
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test1', 'test2']
    test_msg = 'test_msg'
    test_version = 'test_version'
    result = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(result) == len(test_value)
    assert result[0] == test_value[0]


# Generated at 2022-06-20 13:45:53.222882
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert 'TEST_CONSTANT' in globals()
    assert globals()['TEST_CONSTANT'] == 'test'



# Generated at 2022-06-20 13:45:57.433081
# Unit test for function set_constant
def test_set_constant():
    # Overwriting a setting with the same value should be silent
    set_constant('ANSIBLE_REMOTE_TEMP', '{{ANSIBLE_REMOTE_TEMP}}')

    # Overwriting a setting with a new value should produce a warning
    set_constant('ANSIBLE_REMOTE_TEMP', '/boo/')

# Generated at 2022-06-20 13:46:04.857701
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Create an object of class _DeprecatedSequenceConstant
    deprecated_object = _DeprecatedSequenceConstant(('c1', 'c2'), 'msg', 'ver')
    assert deprecated_object._value == ('c1', 'c2')
    assert deprecated_object._msg == 'msg'
    assert deprecated_object._version == 'ver'
    assert len(deprecated_object) == 2
    assert deprecated_object[1] == 'c2'

test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:46:14.094216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        msg = 'foo'
        version = '7.0.0'
        d = _DeprecatedSequenceConstant(list(range(10)), msg, version)

        d[0]
        d[-1]
        d[2:5]
        d[::2]
        d[::-1]
        d[:]

        for i in [d[i] for i in range(len(d))]:
            pass
    except Exception:
        assert False



# Generated at 2022-06-20 13:46:17.675250
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2], '', '')) == 2

# Generated at 2022-06-20 13:46:25.136294
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    import shutil
    import os
    import sys

    # Make temp directory
    temp_dir = tempfile.mkdtemp()

    # Make ansible.cfg file
    config_file = os.path.join(temp_dir, "ansible.cfg")
    with open(config_file, "wt") as f:
        f.write("[defaults]\n")
        f.write("constant_value = 42")

    # Hack sys.path so we can load the 'ansible' package in the next step
    sys.path.insert(0, temp_dir)

    # Import ansible
    import ansible
    import ansible.constants

    # Restore sys.path
    sys.path.pop(0)

    # Clean up temp directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-20 13:46:37.512122
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    from ansible.module_utils.six import StringIO

    class Display(object):

        def __init__(self):
            self.stdout = StringIO()

    import sys
    sys.modules['ansible.utils.display'] = Display()
    import ansible.utils.display as display

    constants = config.data

    # test _ACTION_DEBUG
    setattr(display, 'stdout', StringIO())
    constants['ACTION_DEBUG'] = _DeprecatedSequenceConstant(_ACTION_DEBUG, "ACTION_DEBUG is deprecated, use ACTION_ALLOWED_IN_DATABASES instead", "2.9")
    try:
        len(constants['ACTION_DEBUG'])
        err = False
    except Exception:
        err = True
    assert not err
    assert len(constants['ACTION_DEBUG']) == 1

# Generated at 2022-06-20 13:46:39.716428
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1,2,3], None, None)) == 3
    assert _DeprecatedSequenceConstant([1,2,3], None, None)[0] == 1

# Generated at 2022-06-20 13:46:41.643945
# Unit test for function set_constant
def test_set_constant():
    t = set()
    set_constant('t', 1, t)
    assert t == {'t': 1}

# Generated at 2022-06-20 13:46:46.607012
# Unit test for function set_constant
def test_set_constant():
    reset_constants()
    set_constant('FOO', True)
    set_constant('BAR', False, export=globals())
    import ansible
    assert ansible.constants.FOO is True
    assert ansible.constants.BAR is True



# Generated at 2022-06-20 13:47:08.935903
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('A', 1, export)
    set_constant('B', '2', export)
    set_constant('C', ['3', '4'], export)
    set_constant('D', '{{ A }}', export)
    set_constant('E', '{% if A is defined %}{{ A }}{% else %}{{ C }}{% endif %}', export)
    set_constant('F', '{% if A is not defined %}{{ A }}{% else %}{{ C }}{% endif %}', export)
    set_constant('G', '{% if A is not defined and C is defined %}{{ A }}{% else %}{{ C }}{% endif %}', export)

# Generated at 2022-06-20 13:47:16.663733
# Unit test for function set_constant
def test_set_constant():
    # dict for constants
    export = dict()
    # test for string value
    set_constant('string', 'sample', export)
    assert export['string'] == 'sample'
    # test for integer value
    set_constant('integer', '123', export)
    assert export['integer'] == 123
    # test for boolean value
    set_constant('boolean', 'True', export)
    assert export['boolean'] == True
    # test for tuple value
    set_constant('tuple', '1,2,3', export)
    assert export['tuple'] == (1, 2, 3)



# Generated at 2022-06-20 13:47:28.588389
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import is_sequence

    assert isinstance(_DEFAULT_SUDO_PASS, Sequence)
    _deprecated.called = 0

    _DEFAULT_SUDO_PASS.__getitem__(0)
    assert _deprecated.called == 1

    _DEFAULT_SUDO_PASS.__getitem__(0)
    assert _deprecated.called == 2

    assert is_sequence(_DEFAULT_SUDO_PASS)

# TODO: move this to a different location that is easier to test

# Generated at 2022-06-20 13:47:29.979908
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0


# Generated at 2022-06-20 13:47:32.909923
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class_obj = _DeprecatedSequenceConstant("value_str", "msg_str", "version_str")
    assert(len("value_str") == class_obj.__len__())

# Generated at 2022-06-20 13:47:36.261251
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test Message', '2.1')
    dsc.__len__()
    dsc.__getitem__(0)

# Generated at 2022-06-20 13:47:43.569023
# Unit test for function set_constant
def test_set_constant():
    global CONFIG_OVERRIDE_VARS
    CONFIG_OVERRIDE_VARS = []
    set_constant('CONFIG_OVERRIDE_VARS', ['test'])
    assert CONFIG_OVERRIDE_VARS == ['test']


# NOT CONSTANTS
DISTINCT_URLS = []
# Keys that cannot be overridden by values set in config
RESTRICTED_KEYS = frozenset(('_ansible_opts',))

# this is the templar environment, used to keep track of currently loading template files
TEMPLATE_TRACE_FILE = None

# Generated at 2022-06-20 13:47:51.480772
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Arrange
    test_sequence = ("a", "b", "c")
    mock_msg = "test message"
    mock_version = "test version"

    # Act
    _DeprecatedSequenceConstant(test_sequence, mock_msg, mock_version)

    # Assert
    assert len(test_sequence) == len(_DeprecatedSequenceConstant(test_sequence, mock_msg, mock_version))


# Generated at 2022-06-20 13:47:53.199691
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import sys
    if sys.version_info.major > 2:
        x = _DeprecatedSequenceConstant([1, 2, 3], "warning", "2.10")
        assert x == [1, 2, 3]
        assert len(x) == 3

# Generated at 2022-06-20 13:48:00.743396
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test a valid call
    test_sequence = _DeprecatedSequenceConstant(value=(1, 2), msg='Test', version='2.9')
    assert len(test_sequence) == 2, 'Expected 2, got %s' % len(test_sequence)

    # Test that deprecation message is displayed
    import sys
    import io

    # Save the stdout, stderr and redirect it to our own
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    test_sequence = _DeprecatedSequenceConstant(value=(1, 2), msg='Test', version='2.9')
    len(test_sequence)
    message = sys.stderr.getvalue().strip()



# Generated at 2022-06-20 13:48:11.384753
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for length in range(10):
        assert length == len(_DeprecatedSequenceConstant(list(range(length)), 'test message', "ansible 2.9"))


# Generated at 2022-06-20 13:48:15.393136
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='testing _DeprecatedSequenceConstant', version='2.0')
    assert len(constant) == 3
    assert constant[0] == 'a'
    assert constant[1] == 'b'
    assert constant[2] == 'c'


# Generated at 2022-06-20 13:48:18.293666
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    length = 3
    c = _DeprecatedSequenceConstant([1] * length, msg='test', version='3.0')
    assert len(c) == length



# Generated at 2022-06-20 13:48:30.279684
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Constructor
    dsc = _DeprecatedSequenceConstant(['A', 'B'], 'Deprecated Msg', 'Version')
    # Constructor '_DeprecatedSequenceConstant' returns an object of class _DeprecatedSequenceConstant
    assert isinstance(dsc, _DeprecatedSequenceConstant)
    # Constructor '_DeprecatedSequenceConstant' returns an object which has the property '_value'
    assert hasattr(dsc, '_value')
    # Value of '_value' is a tuple of length 2
    assert len(dsc._value) == 2
    # Constructor '_DeprecatedSequenceConstant' returns an object which has the property '_msg'
    assert hasattr(dsc, '_msg')
    # Value of '_msg' is a string 'Deprecated Msg'
   

# Generated at 2022-06-20 13:48:36.456611
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # __len__ should return the length of self._value
    a = _DeprecatedSequenceConstant([], 'a', '1.3')
    assert len(a) == 0
    b = _DeprecatedSequenceConstant([1], 'b', '2.0')
    assert len(b) == 1
    c = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'c', '3.0')
    assert len(c) == 3


# Generated at 2022-06-20 13:48:40.476700
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert isinstance(MAGIC_VARIABLE_MAPPING['connection'], _DeprecatedSequenceConstant)
    assert MAGIC_VARIABLE_MAPPING['connection'][0] in COMMON_CONNECTION_VARS

# Generated at 2022-06-20 13:48:43.078411
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'Test message', '2.0')) == 2


# Generated at 2022-06-20 13:48:48.244106
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = '2.0'
    value = [1,2,3]
    test_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_constant) == len(value)
    assert test_constant[0] == value[0]

# Generated at 2022-06-20 13:48:59.106930
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    import io
    import sys

    capturedOutput = io.StringIO()
    sys.stderr = capturedOutput

    testVal = ['a', 'b', 'c']
    testInstance = _DeprecatedSequenceConstant(testVal, 'test', '2.0')
    assert testInstance[0] == testVal[0]
    assert testInstance[1] == testVal[1]
    assert testInstance[2] == testVal[2]

    sys.stderr = sys.__stderr__



# Generated at 2022-06-20 13:49:02.003002
# Unit test for function set_constant
def test_set_constant():
    _var = {}
    set_constant('a', 'b', _var)
    assert _var['a'] == 'b'

# Generated at 2022-06-20 13:49:20.583760
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from collections import deque
    d = deque()
    d.append('stuff')
    d.append('things')
    deprecated_sequence_constant = _DeprecatedSequenceConstant(d, 'this is not to be used', '2.8')
    # check that this is a true instance of _DeprecatedSequenceConstant
    assert(isinstance(deprecated_sequence_constant, _DeprecatedSequenceConstant))
    # check that this properly indexes into the deque
    assert(deprecated_sequence_constant[0] == 'stuff')
    assert(deprecated_sequence_constant[-1] == 'things')
    # check that it works with slices too
    assert(tuple(deprecated_sequence_constant[:]) == ('stuff', 'things'))

# Generated at 2022-06-20 13:49:23.985181
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-20 13:49:26.269579
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ssc = _DeprecatedSequenceConstant([1,2,3], "Some message", "1.0")
    assert len(ssc) == 3


# Generated at 2022-06-20 13:49:36.573662
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest
    import sys

    def mock_warning(msg):
        assert msg == ' "deprecated_key" is deprecated in Ansible 2.8 and will be removed in version 2.11 , ' \
                       'using it anyway.'
        sys.stderr.write('Mocked: %s\n' % (msg))

    value = ['foo', 'bar']
    message = 'deprecated_key is deprecated in Ansible 2.8 and will be removed in version 2.11'
    version = '2.11'
    deprecated_value = _DeprecatedSequenceConstant(value, message, version)

    # test normal call
    assert deprecated_value[1] == 'bar'

    # test mocked call

# Generated at 2022-06-20 13:49:41.821210
# Unit test for function set_constant
def test_set_constant():
    assert not hasattr(__builtins__, 'test')
    set_constant('test', 'hello')
    assert __builtins__['test'] == 'hello'

# Make the magic variables available as a sequence to make OrderingConfigurable work
MAGIC_VARIABLES = MAGIC_VARIABLE_MAPPING.keys()

# Pre-cache these to avoid repeated lookups
MAGIC_VARIABLES_CACHE = dict()



# Generated at 2022-06-20 13:49:48.488300
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), 'msg', 'version')) == 2
    assert len(_DeprecatedSequenceConstant([1, 2], 'msg', 'version')) == 2
    assert len(_DeprecatedSequenceConstant({'a': 1, 'b': 2}, 'msg', 'version')) == 2


# Generated at 2022-06-20 13:49:56.535844
# Unit test for function set_constant
def test_set_constant():
    new_constants = {
        'CONSTANT_BOOL': True,
        'CONSTANT_INT': 0,
        'CONSTANT_DICT': {'foo': 'bar'},
        'CONSTANT_STRING': "test string",
        'CONSTANT_TUPLE': (True, False),
        'CONSTANT_LIST': ["test", "test2", "test3"],
    }

    for name, value in new_constants.items():
        set_constant(name, value)
        assert value == vars()[name]

# Generated at 2022-06-20 13:50:03.793217
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'Test Message', '2.10')
    assert len(seq) == 3
    assert seq[1] == 2
    try:
        seq[4]
        raise AssertionError('should have raised IndexError exception')
    except IndexError:
        pass

# backward compat
DOCUMENTABLE_PLUGIN_KINDS = DOCUMENTABLE_PLUGINS
ACTION_ALLOW_EXTRA_ARGS = _ACTION_ALLOWS_RAW_ARGS

# Generated at 2022-06-20 13:50:05.419285
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant('value', 'msg', 'v1.0')[0] == 'v'

# Generated at 2022-06-20 13:50:07.936242
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")

    assert s[1] == 2
    assert s[-1] == 3

# Generated at 2022-06-20 13:50:25.453680
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_object = _DeprecatedSequenceConstant(value=[1,2], msg='test', version='test')
    assert len(test_object) == 2

# Generated at 2022-06-20 13:50:35.039442
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj_1 = _DeprecatedSequenceConstant([1, 2, 3], 'list', 'ansible 2.4')
    # _DeprecatedSequenceConstant object should have __len__ and __getitem__ methods
    assert hasattr(test_obj_1, '__len__') == True
    assert hasattr(test_obj_1, '__getitem__') == True
    # __len__ should return the length of the list passed in while instantiating
    assert len(test_obj_1) == 3
    # __getitem__ should return the index value
    assert test_obj_1[1] == 2
    # object should not have an attribute named _value
    assert hasattr(test_obj_1, '_value') == False
    # object should not have an attribute named _msg

# Generated at 2022-06-20 13:50:37.912979
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = _DeprecatedSequenceConstant(value=['foo', 'bar'], msg='test message', version='X.Y.Z')
    assert len(test_list) == 2



# Generated at 2022-06-20 13:50:46.054031
# Unit test for function set_constant
def test_set_constant():
    export = {}
    name = 'ANSIBLE_FOO'
    value = 'ok'
    set_constant(name, value, export=export)

    assert export[name] == value


# FIXME: this is a temporary hack until we refactor the constructor
conf_version = config.version

# FIXME: this should really live in a function so we can update it on the fly
# (also move the default globals into that function)
# Also should be a bit smarter about formatting for use in the API docs

# Default avail global variables

# Generated at 2022-06-20 13:50:47.800365
# Unit test for function set_constant
def test_set_constant():
    local_vars = {}
    set_constant('FOO', 1, export=local_vars)
    assert local_vars['FOO'] == 1

# Generated at 2022-06-20 13:50:52.461705
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class Test__DeprecatedSequenceConstant(object):
        def test___init__(self):
            pass

    msg = ("Test__DeprecatedSequenceConstant"
           "succeeded when it should have failed")
    assert (Test__DeprecatedSequenceConstant() is None
            ), msg



# Generated at 2022-06-20 13:50:57.257790
# Unit test for function set_constant
def test_set_constant():
    local_env = {}
    set_constant('test_setting', 'test_value', export=local_env)
    return local_env.get('test_setting') == 'test_value'


# avoid circular deps
from ansible import errors
error = None
# Note: this must be referenced explicitly in code, see #26299

# Generated at 2022-06-20 13:51:04.500205
# Unit test for function set_constant
def test_set_constant():
    set_constant('_TEST_CONSTANT', 'test')
    if _TEST_CONSTANT != 'test':
        raise AssertionError('setting a constant does not work')
    del _TEST_CONSTANT
test_set_constant()

# detect if we're running during an ansible unit test
ansible_test = True
try:
    import ansible.constants
    if ansible.constants.__file__.endswith('constants.pyc'):
        ansible_test = True
    elif ansible.constants.__file__.endswith('constants.py'):
        ansible_test = False
except ImportError:
    ansible_test = False


# Generated at 2022-06-20 13:51:11.098336
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from unittest import TestCase
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    sio = StringIO()

    class _TestCase(_TestCase):
        def __init__(self, *args, **kwargs):
            _TestCase.__init__(self, *args, **kwargs)

            self.addCleanup(self.restore_warnings)
            self.addCleanup(setattr, self, '_stdout', getattr(self, '_stdout'))
            self.addCleanup(setattr, self, '_stderr', getattr(self, '_stderr'))

# Generated at 2022-06-20 13:51:16.781859
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _MockDeprecatedSequenceConstant(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

    msc = _MockDeprecatedSequenceConstant(value = 'abc', msg = 'abc', version = 'abc')
    assert msc[1] == 'b'

# Generated at 2022-06-20 13:51:37.616396
# Unit test for function set_constant
def test_set_constant():
    for func in [set_constant]:
        assert func('FOO', 'BAR') == {'FOO': 'BAR'}
        assert func('FOO', 1) == {'FOO': 1}

# Generated at 2022-06-20 13:51:40.411750
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list = [1, 2, 3, 4, 5]
    _dsc = _DeprecatedSequenceConstant(list, 'msg', 'version')
    for i in list:
        assert i == _dsc.__getitem__(list.index(i))

# Generated at 2022-06-20 13:51:49.881223
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class check():
        def __init__(self):
            self.msg = 'msg'
            self.data = [1, 2, 3]
            self.version = '2.9'

    data = check()
    _DeprecatedSequenceConstant(data.data, data.msg, data.version)

# Use collection name in place of deprecated 'modules' ptype
if P.get_config(C.COLLECTION_PTYPE, None) == 'module':
    collection_name = COLLECTION_PTYPE_COMPAT.get(getattr(P.get_config(C.COLLECTION_PTYPE, None), 'collection_type', None))
    set_constant('collection_type', collection_name)

# Generated at 2022-06-20 13:51:52.415336
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ds = _DeprecatedSequenceConstant(list(range(10)), 'Test msg', '2.10')
    assert len(ds) == 10


# Generated at 2022-06-20 13:51:54.563788
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.8')
    assert seq[0] == 'a'


# Generated at 2022-06-20 13:52:04.086472
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    try:
        from unittest import mock
    except ImportError:
        import mock

    from ansible.errors import AnsibleDeprecationWarning

    class Test_DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def test_DeprecatedSequenceConstant___getitem___no_deprecation_warning(self):
            '''
            The _DeprecatedSequenceConstant class can be instantiated without
            any deprecation warning being printed.
            '''
            with mock.patch.object(sys.stderr, 'write') as mock_write:
                depr_seq_const = _DeprecatedSequenceConstant(('foo',), 'message', 'version')


# Generated at 2022-06-20 13:52:05.678987
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant((1,2), 'two_values!', '1.99'), Sequence)

# Generated at 2022-06-20 13:52:09.295047
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Set up data for test
    msg = 'Test Message'
    version = '1.2.3'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    # Execute the method under test
    result = dsc.__getitem__(1)

    # Verify results
    assert result == value[1]



# Generated at 2022-06-20 13:52:14.509466
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common import _DeprecatedSequenceConstant
    d = _DeprecatedSequenceConstant(["a", "b", "c"], "msg", "version")
    assert len(d) == 3
    assert d[0] == "a"
    assert d[1] == "b"
    assert d[2] == "c"

# Generated at 2022-06-20 13:52:17.002056
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(["a", "b", "c"], "msg", (1,0))
    assert len(c) == 3


# Generated at 2022-06-20 13:52:57.572482
# Unit test for function set_constant
def test_set_constant():
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    p = dict()
    set_constant('foo', 'bar', export=p)
    assert p['foo'] == 'bar'
    set_constant('foo', 'baz', export=p)
    assert p['foo'] == 'bar'
    set_constant('baz', 'bam', export=p)
    assert p['baz'] == 'bam'
    set_constant('Display', Display, export=p)
    assert p['Display'] == Display


# Make constants available to any class inheriting from
# ansible.utils.module_docs_fragments.AnsibleModule

# Generated at 2022-06-20 13:53:00.266881
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = 'test value'
    test_msg = 'test msg'
    test_version = 'test version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_object[0] == test_value[0]

# Generated at 2022-06-20 13:53:06.841302
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    def _test__DeprecatedSequenceConstant___len__(msg, version):
        val = 'hello'
        dsc = _DeprecatedSequenceConstant(val, msg, version)

        assert isinstance(dsc, _DeprecatedSequenceConstant) is True
        assert isinstance(dsc, Sequence) is True
        assert len(dsc) == len(val)

    _test__DeprecatedSequenceConstant___len__('This is a test', '2.5')

# Generated at 2022-06-20 13:53:12.640573
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    test = unittest.TestCase()

    dc = _DeprecatedSequenceConstant([1, 2, 3], 'a message', 'a version')
    test.assertEqual(len(dc), 3)
    test.assertEqual(list(dc), [1, 2, 3])
    test.assertEqual(dc[1], 2)
    test.assertEqual(dc, [1, 2, 3])

# Generated at 2022-06-20 13:53:15.741980
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "message"
    version = "version"
    value = [1, 2]
    x = _DeprecatedSequenceConstant(value, msg, version)
    assert x[0] == value[0]
    assert x[1] == value[1]



# Generated at 2022-06-20 13:53:18.738943
# Unit test for function set_constant
def test_set_constant():
    const_vars = vars().copy()
    set_constant('foo', 'bar')
    set_constant('boo', 'qux')
    assert 'foo' in vars()
    assert 'boo' in vars()


# Generated at 2022-06-20 13:53:25.456746
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'foo')
    assert __builtins__['test'] == 'foo'


if DEFAULT_BECOME_PASS is None:
    # FIXME: should get this from config
    DEFAULT_BECOME_PASS = 'ansible'

# For backwards compat, we need to maintain the old-style namespace for this for the time being
DEFAULT_SUBSET = DEFAULT_SUBSET or 'all'

# DEPRECATED
# FIXME: move to config, before any other imports (but after config)
#        should be renamed to DEFAULT_INTERNAL_POLL_INTERVAL
INTERNAL_POLL_INTERVAL = 1.0

# FIXME: remove once plugins/__init__.py is removed
# Plugin configuration paths

# directly in the config file
DEFAULT_PLUG

# Generated at 2022-06-20 13:53:27.316231
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    with _DeprecatedSequenceConstant(value=[], msg='', version=None) as obj:
        assert len(obj) == 0


# Generated at 2022-06-20 13:53:30.797539
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_const_test = _DeprecatedSequenceConstant([1, 2, 3, 4], 'This is a test', '2.8')
    assert len(seq_const_test) == 4

test__DeprecatedSequenceConstant___len__()
