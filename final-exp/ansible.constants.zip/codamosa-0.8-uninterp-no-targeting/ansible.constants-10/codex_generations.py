

# Generated at 2022-06-20 13:43:42.226028
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test msg', '2.9')) == 3


# Generated at 2022-06-20 13:43:53.864928
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_val = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '1.2')
    assert len(test_val) == 3 and test_val[0] == 1 and isinstance(test_val, Sequence)
    assert len(test_val) == 3 and test_val[0] == 1 and isinstance(test_val, Sequence)
    assert isinstance(test_val, Sequence)
    assert len(test_val) == 3 and test_val[0] == 1

# some local settings, which override config
from os.path import expanduser
from ansible.module_utils.six import string_types


# Generated at 2022-06-20 13:43:57.416726
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = ["one", "two", "three", "four"]
    t = _DeprecatedSequenceConstant(l, "msg", "version")
    assert len(t) == 4
for i, v in enumerate(l):
    assert t[i] == v


# Generated at 2022-06-20 13:44:02.981363
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''
    tests construction of class (_DeprecatedSequenceConstant)
    check that Class instance has all the properties of a sequence

    '''
    test_value = ['1', '2']
    test_msg = 'test warning'
    test_version = 'test version'
    test_instance = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert isinstance(test_instance, Sequence)
    assert test_instance[0] is test_value[0]

# Generated at 2022-06-20 13:44:05.179288
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(a) == 3


# Generated at 2022-06-20 13:44:06.633749
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=('a','b','c','d'), msg='test', version='0.0')) == 4

# Generated at 2022-06-20 13:44:10.677394
# Unit test for function set_constant
def test_set_constant():
    ''' this is only used for unit tests to change the value of a setting '''
    set_constant('DEFAULT_UNDERSCORE_VARS', True)

# Generated at 2022-06-20 13:44:15.039005
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert(_DeprecatedSequenceConstant([], "test_warning", 0.1).__len__() == 0)
    assert(_DeprecatedSequenceConstant([], "test_warning", 0.1).__getitem__(1) == None)

# Generated at 2022-06-20 13:44:27.875831
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    import sys

    class Test_DeprecatedSequenceConstant(unittest.TestCase):

        def setUp(self):
            self.stdout_stream = sys.stdout
            sys.stdout = sys.stderr
            self.deprecatedList = _DeprecatedSequenceConstant(['test'], 'test message', 'test version')

        def tearDown(self):
            sys.stdout = self.stdout_stream

        def test_len(self):
            self.assertEqual(len(self.deprecatedList), 1)

        def test_getitem(self):
            self.assertEqual(self.deprecatedList[0], 'test')

    return unittest.makeSuite(Test_DeprecatedSequenceConstant)

# Generated at 2022-06-20 13:44:35.840358
# Unit test for function set_constant
def test_set_constant():
    import sys
    from ansible.utils.display import Display
    display = Display()
    display.deprecated = lambda _a, _b: sys.stderr.write(_a)

    # test overriding a value
    set_constant('ANSIBLE_TEST_OLD_VALUE', 'OLD_VALUE')
    set_constant('ANSIBLE_TEST_OLD_VALUE', 'NEW_VALUE')
    assert 'NEW_VALUE' == globals()['ANSIBLE_TEST_OLD_VALUE']

    # test specifying a value on the command line with --extra-vars
    set_constant('ANSIBLE_TEST_EXTRA_VARS', 'OLD_VALUE')

# Generated at 2022-06-20 13:44:43.003153
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(COLOR_CODES['yellow'], string_types)


# Backwards compat for getting config values
# FIXME: remove when fully migrated to settings API

# Generated at 2022-06-20 13:44:49.211078
# Unit test for function set_constant
def test_set_constant():
    set_constant('A', 'a')
    set_constant('B', 'b', locals())
    set_constant('C', 'c', vars())
    try:
        from ansible.module_utils.ansible_release import __version__
        assert __version__ == value
    except ImportError:
        pass



# Generated at 2022-06-20 13:44:54.265668
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_CACHE_PLUGIN == 'memory'
    assert DEFAULT_CACHE_PLUGIN == 'memory'
    assert MACOS_DEFAULT_INTERPRETER == '/usr/bin/python'

# Add some aliases
LOCALHOST_ALIASES = ('localhost', )

# Generated at 2022-06-20 13:44:57.333281
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for valid length
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'any message', '1.0')) == 3
    # Test for invalid length
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'any message', '1.0')) != 4


# Generated at 2022-06-20 13:45:08.164109
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test using a list
    test_obj = _DeprecatedSequenceConstant(
        value=['foo', 'bar'],
        msg='Test message',
        version='2.0'
    )

    assert(len(test_obj) == 2)
    assert(test_obj[0] == 'foo')
    assert(test_obj[1] == 'bar')

    # Test using a tuple
    test_obj = _DeprecatedSequenceConstant(
        value=('foo', 'bar'),
        msg='Test message',
        version='2.0'
    )

    assert(len(test_obj) == 2)
    assert(test_obj[0] == 'foo')
    assert(test_obj[1] == 'bar')



# Generated at 2022-06-20 13:45:12.391024
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(list('test'), 'msg', 'version')
    assert len(dsc) == 4


# Generated at 2022-06-20 13:45:14.198073
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], 'test', '2.0')) == 0



# Generated at 2022-06-20 13:45:18.409055
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test a valid value.
    d = _DeprecatedSequenceConstant([], 'message', 'version')
    assert len(d) == 0
    # Test a bad value.
    d = _DeprecatedSequenceConstant(None, 'message', 'version')
    try:
        len(d)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-20 13:45:23.552424
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test_deprecated_sequence_constant_init: constructor of class _DeprecatedSequenceConstant
    try:
        _DeprecatedSequenceConstant(1, "msg", "version")
        return True
    except Exception:
        return False

if __name__ == '__main__':
    import pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-20 13:45:26.459358
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'This option is not available.', version='2.9')
    assert len(dsc) == 3


# Generated at 2022-06-20 13:45:33.337491
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = _DeprecatedSequenceConstant([1,2,3,4], "test msg","2.9")
    len(test_seq)


# Generated at 2022-06-20 13:45:39.343059
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test class without msg, version
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], None, None)
    assert len(seq) == 3

    # Test class with msg and version
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'xyz', '1.1')
    assert len(seq) == 3

# Generated at 2022-06-20 13:45:44.717995
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    example_value = ['a', 'b', 'c']
    example_message = "using deprecated constant"
    example_version = "2.0"
    example_sequence = _DeprecatedSequenceConstant(example_value, example_message, example_version)
    for index, example in enumerate(example_value):
        assert example_sequence[index] == example

# Generated at 2022-06-20 13:45:58.784216
# Unit test for function set_constant
def test_set_constant():
    # Check with some basic values
    assert DEFAULT_BECOME_PASS == None
    assert DEFAULT_PASSWORD_CHARS == u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'
    assert DEFAULT_REMOTE_PASS == None
    assert DEFAULT_SUBSET == None
    assert INTERNAL_RESULT_KEYS == ('add_host', 'add_group')
    assert LOCALHOST == ('127.0.0.1', 'localhost', '::1')
    assert RESTRICTED_RESULT_KEYS == ('ansible_rsync_path', 'ansible_playbook_python', 'ansible_facts')
    assert TREE_DIR == None
    assert VAULT_VERSION_MIN

# Generated at 2022-06-20 13:46:03.111307
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test error message
    res = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg1', '1.2')
    len(res)
    assert res[0] == 'a'



# Generated at 2022-06-20 13:46:07.443005
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], 'msg', 'version') is not None
    assert _DeprecatedSequenceConstant([], 'msg', 'version') is not None


# Generated at 2022-06-20 13:46:10.866456
# Unit test for function set_constant
def test_set_constant():
    assert HAS_JINJA2 is True
    if HAS_JINJA2:
        assert HOST_KEY_CHECKING is True
        assert HASH_BEHAVIOUR == "replace"

# Generated at 2022-06-20 13:46:15.579585
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = "test"
    object1 = _DeprecatedSequenceConstant(test_seq, "this is test message", "1.0")
    len1 = len(test_seq)
    len2 = len(object1)
    assert len1 == len2


# Generated at 2022-06-20 13:46:23.441102
# Unit test for function set_constant
def test_set_constant():
    class _Exported(dict):
        _exported = True

    d = _Exported()
    set_constant('TRUE', True, export=d)
    assert d['TRUE'], 'TRUE constant not in export'
    assert d._exported, '_exported should be True'
    set_constant('BAD', '{{not_templatable}}', export=d)
    assert d['BAD'] == '{{not_templatable}}', 'BAD constant should not have been templated'


# Convert the magic variable mapping dict above into a cache
# for quick lookup

# Generated at 2022-06-20 13:46:27.607456
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant([1, 2, 3], 'This is a message', '1.2')
    assert len(deprecated) == 3
    assert deprecated[1] == 2


# Generated at 2022-06-20 13:46:38.256992
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from nose.tools import assert_equal
    seq = _DeprecatedSequenceConstant(['a', 'b'], "msg", "version")
    # should be 2
    assert_equal(len(seq), 2)

# Generated at 2022-06-20 13:46:52.959168
# Unit test for function set_constant
def test_set_constant():
    from ansible.constants import DEFAULT_BECOME_METHOD
    from ansible.module_utils.six import PY2
    _set_constant = set_constant
    test_constant_name = 'TEST_CONSTANT'
    test_constant_value = 'test_constant_value'
    test_constant_value_fallback = 'test_constant_value_fallback'

# Generated at 2022-06-20 13:46:55.128147
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1, 2, 3], "some message", "some version")
    assert len(x) == len([1, 2, 3])

# Generated at 2022-06-20 13:47:03.748727
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # create a DeprecatedSequenceConstant object
    sequence_constant = _DeprecatedSequenceConstant(value = [1, 2, 3],
                                                    msg = 'Message',
                                                    version = '2.0')
    # assert
    assert sequence_constant[1] == 2


# Generated at 2022-06-20 13:47:08.113895
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_HOST_KEY_CHECKING', True)
    assert ANSIBLE_HOST_KEY_CHECKING == True


# Add Ansible version
set_constant('__version__', __version__)

# Generated at 2022-06-20 13:47:10.835773
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    new_object = _DeprecatedSequenceConstant([1,2,3], "foobar", "foobar")
    assert new_object[0] == 1 and new_object[1] == 2 and new_object[2] == 3


# Generated at 2022-06-20 13:47:15.649215
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constantList = ['Foo', 'Bar', 'Baz']
    sequenceConstant = _DeprecatedSequenceConstant(constantList, 'Testing deprecated sequence constant', '2.13')
    assert len(sequenceConstant) == 3

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:47:21.481724
# Unit test for function set_constant
def test_set_constant():
    for key, value in vars().items():
        if key.startswith('BECOME'):
            assert value == bool(value)

# Generated at 2022-06-20 13:47:24.855385
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='test')
    assert len(seq) == 3
    assert seq[0] == 1


# Generated at 2022-06-20 13:47:30.013857
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import mock

    with mock.patch('ansible.utils._warnings.deprecated') as deprecated:
        obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
        assert obj[1] == 2
        deprecated.assert_called_once_with('msg', version='version')

# Generated at 2022-06-20 13:47:48.918527
# Unit test for function set_constant
def test_set_constant():
    """Test that set_constant uses an existing dictionary as export destination"""
    d = dict()
    set_constant('foo', 'bar', export=d)
    assert d['foo'] == 'bar'



# Generated at 2022-06-20 13:47:58.056112
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1,2,3]
    msg = 'This is deprecated sequence constant'
    version = '2.9'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]


# FIXME: remove once play_context mangling is removed
# this is a gross hack, but we're late in the release cycle
# and I don't want to break all the modules out there
NEEDS_TMPPATH = ('fetch', 'slurp', 'unarchive', 'script')


# wrapper to provide backwards compat with old settings

# Generated at 2022-06-20 13:48:01.651238
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """Tests for constructor of class _DeprecatedSequenceConstant."""
    msg = 'This is a warning message'
    version = '1.0'
    value = 'test-value'
    constant = _DeprecatedSequenceConstant(value, msg, version)
    if not (len(constant) == 1 and constant[0] == value):
        raise AssertionError('Constructor of class _DeprecatedSequenceConstant did not set correct value for the constant.')


# Generated at 2022-06-20 13:48:11.591259
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Basic testing of simple list.
    test_list = ['a', 'b', 'c']
    dc = _DeprecatedSequenceConstant(test_list, "msg", "0.0")
    assert len(dc) == 3
    assert dc[0] == 'a'
    assert dc[1] == 'b'
    assert dc[2] == 'c'
    # Basic testing of simple tuple.
    test_tuple = ('a', 'b', 'c')
    dc = _DeprecatedSequenceConstant(test_tuple, "msg", "0.0")
    assert len(dc) == 3
    assert dc[0] == 'a'
    assert dc[1] == 'b'
    assert dc[2] == 'c'
    # Basic testing of list of tuples.

# Generated at 2022-06-20 13:48:16.473801
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test msg'
    test_version = '2.0'
    dsc = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert dsc._value == test_value
    assert dsc._msg == test_msg
    assert dsc._version == test_version
    assert dsc[0] == test_value[0]
    assert len(dsc) == len(test_value)


# Generated at 2022-06-20 13:48:20.200484
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1,2,3], "Should be a tuple", "2.0")
    assert seq[0] == 1


# Generated at 2022-06-20 13:48:27.650849
# Unit test for function set_constant
def test_set_constant():

    # Build dictionary of lowercase configuration settings
    config_names = [setting.name.lower() for setting in config.data.get_settings()]

    # Check that all module constants have a corresponding setting in the config
    for key in vars().keys():
        if key.isupper():
            if key.lower() not in config_names:
                raise AssertionError('Constant %s was not found in Ansible configuration' % key)


# VALIDATION FUNCTIONS ###

# Generated at 2022-06-20 13:48:31.650429
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    import sys

    global _deprecated
    _deprecated = lambda msg, version: sys.stderr.write(msg)

    v = [0]
    d = _DeprecatedSequenceConstant(v, 'test', '1.0')

    assert d[0] == 0

# Generated at 2022-06-20 13:48:39.050455
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', globals())
    assert globals()['FOO'] == 'baz'

# Generated at 2022-06-20 13:48:43.720082
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def _test_helper(value, msg, version):
        dsc = _DeprecatedSequenceConstant(value, msg, version)
        assert len(dsc) == len(value)
    _test_helper(('foo', 'bar', 'baz'), 'test warning', 'test version')


# Generated at 2022-06-20 13:49:24.105934
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Try with good values
    test_name = 'test_name'
    test_value = [1, 2, 3]

    test_msg = 'test_msg'
    test_version = '1.0.0'

    dsc = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert len(dsc) == len(test_value)
    assert dsc[0] == test_value[0]
    assert dsc[1] == test_value[1]

    # Try with wrong values
    wrong_test_value = (1, 2, 3)

    dsc = _DeprecatedSequenceConstant(wrong_test_value, test_msg, test_version)

    failed = False

# Generated at 2022-06-20 13:49:25.869575
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([], "", "")
    assert len(sequence) == 0



# Generated at 2022-06-20 13:49:28.973882
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO_BAR', 'hello')
    assert 'hello' == FOO_BAR


# Generated at 2022-06-20 13:49:37.895410
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.six import PY2
    seq = _DeprecatedSequenceConstant(['foo', 'bar'], "1st message", "1.0")
    if PY2:
        try:
            len(seq)
            raise RuntimeError("Did not get warned")
        except Warning:
            pass
        try:
            list(seq)
            raise RuntimeError("Did not get warned")
        except Warning:
            pass
        try:
            for x in seq:
                raise RuntimeError("Did not get warned")
        except Warning:
            pass
    else:
        assert len(seq) == 2
        assert list(seq) == ['foo', 'bar']
        for x in seq:
            pass


if __name__ == '__main__':
    import sys
    import os

# Generated at 2022-06-20 13:49:45.991603
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(['a', 'b'], 'msg', '1.0')
    assert c[0] == 'a'
    assert c[1] == 'b'



# Generated at 2022-06-20 13:49:57.304282
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.config.manager import _DeprecatedSequenceConstant as _DSC

    # Check for normal behavior for negative test
    try:
        dsc = _DSC(list(range(10)), 'test message', 'test version')
        n = len(dsc)
        assert n == 10
        i = dsc[0]
        assert i == 0
        e = dsc[5]
        assert e == 5
    except Exception as e:
        print(e)
        assert False

    # Check for normal behavior for positive test

# Generated at 2022-06-20 13:50:07.497406
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils._text import to_bytes

    # Captor for stderr
    stderr_captor = io.StringIO()
    sys.stderr = stderr_captor

    # Unit test
    example_list = ['test1', 'test2']
    constant = _DeprecatedSequenceConstant(value=example_list, msg='test_msg', version='test_version')
    assert constant[0] == 'test1'

    # Reset stderr
    sys.stderr = sys.__stderr__

    # Test the output from stderr
    captured_stderr = stderr_captor.getvalue()
    assert captured_stderr.startswith(' ')

# Generated at 2022-06-20 13:50:10.449578
# Unit test for function set_constant
def test_set_constant():
    a = dict()
    set_constant('test_key', 'value', a)
    assert a.get('test_key') == 'value'



# Generated at 2022-06-20 13:50:12.576678
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', 'v2.9')) == 3

# Generated at 2022-06-20 13:50:14.651167
# Unit test for function set_constant
def test_set_constant():
    my_dict = {}
    set_constant('test', 'hello world', export=my_dict)
    assert my_dict['test'] == 'hello world'



# Generated at 2022-06-20 13:51:49.934698
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(('a', 'b', 'c'), '', '')
    assert len(obj) == 3


# Generated at 2022-06-20 13:51:51.988753
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')) == 3



# Generated at 2022-06-20 13:51:54.210190
# Unit test for function set_constant
def test_set_constant():
    assert COMMAND_WARNINGS == ['Always quote command arguments containing spaces']


# Generated at 2022-06-20 13:51:57.000859
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', '2.9')
    assert len(constant) == 3


# Generated at 2022-06-20 13:51:59.784459
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_constant = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', '2.x')
    assert len(seq_constant) == 3
    assert seq_constant[0] == 'a'



# Generated at 2022-06-20 13:52:08.923053
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import ast

    # Test normal case
    test = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='test', version='1.0')
    assert len(test) == 3
    assert test[0] == 'a'
    assert test[-1] == 'c'

    # Test normal slice
    slice_test = test[:2]
    assert isinstance(slice_test, list)
    assert len(slice_test) == 2
    assert slice_test[0] == 'a'
    assert slice_test[1] == 'b'

    # Test getitem with ast.Index
    index_test = ast.Index(test)
    assert index_test.value == test
    assert index_test.ctx == ast.Load()
    assert index_test.slice.value == 2


# Generated at 2022-06-20 13:52:12.986781
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # positive test
    d = _DeprecatedSequenceConstant(['a'], 'a', 'a')
    assert(len(d) == 1)
    assert(d[0] == 'a')
    # negative test
    assert(len(_DeprecatedSequenceConstant([], '', 'a')) == 0)

# Generated at 2022-06-20 13:52:19.357217
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant(['foo', 'bar'], 'Test Message', 'Now')

    # Test for good input.
    test_constant[0]

    try:
        # Test for bad input.
        test_constant['foo']
    except Exception:
        pass
    else:
        raise AssertionError('_DeprecatedSequenceConstant __getitem__ did not raise exception for bad input.')

# Generated at 2022-06-20 13:52:22.950645
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    instance = _DeprecatedSequenceConstant((1, 2, 3, 4), 'test message', 'v2.5')
    assert instance.__getitem__(3) == 4


# Generated at 2022-06-20 13:52:28.010500
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "msg1", "3.3")
    dsc_len = dsc.__len__()
    assert dsc_len == 3
    dsc_get = dsc.__getitem__(1)
    assert dsc_get == 2