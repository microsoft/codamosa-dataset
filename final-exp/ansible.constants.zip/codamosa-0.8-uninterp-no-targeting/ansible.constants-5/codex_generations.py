

# Generated at 2022-06-20 13:43:43.612694
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = 'a,b'
    msg = 'test warning'
    version = 'test'
    result = _DeprecatedSequenceConstant(value, msg, version)
    assert len(result) == 2

# Generated at 2022-06-20 13:43:46.551046
# Unit test for function set_constant
def test_set_constant():
    ''' Ensure that constants were defined as non-None '''
    assert not any(x for x in vars().values() if isinstance(x, string_types) and x.startswith('{{') and x.endswith('}}'))

# Generated at 2022-06-20 13:43:52.937635
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(['A'], 'test_msg', '2.5')
    assert obj._msg == 'test_msg'
    assert obj._version == '2.5'
    assert obj._value == ['A']
    assert len(obj) == 1
    assert obj[0] == 'A'


# Generated at 2022-06-20 13:43:56.416602
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant((1, 2, 3, 4), 'This is a message', '1.0.0')
    assert isinstance(value, Sequence)
    assert len(value) == 4
    assert value[1] == 2

# Generated at 2022-06-20 13:44:02.886770
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    temp = _DeprecatedSequenceConstant([], msg='msg', version='version')
    assert len(temp) == 0
    with pytest.raises(AssertionError):
        len(temp) == 1


# Generated at 2022-06-20 13:44:09.603700
# Unit test for function set_constant
def test_set_constant():
    assert(TO_TEXT == '{{ TO_TEXT }}')
    assert(CACHE_PLUGIN == 'jsonfile')
    assert(CACHE_PLUGIN_CONNECTION == '')
    assert(CACHE_PLUGIN_TIMEOUT == 3600)
    assert(CACHE_PLUGIN_DATAFILE == '~/.ansible/tmp/ansible-local')
    assert(DEFAULT_TIMEOUT == 10)
    assert(DEFAULT_MODULE_NAME == 'command')
    assert(DEFAULT_MODULE_PATH == [u'/usr/share/ansible/plugins/modules', u'/usr/share/ansible/plugins/module_utils'])
    assert(DEFAULT_MODULE_LANG == 'en_US.UTF-8')

# Generated at 2022-06-20 13:44:15.339630
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dc = _DeprecatedSequenceConstant(('a', 'b'), 'test reason', '2.0')
    assert len(dc) == 2
    assert dc[0] == 'a'
    assert dc[1] == 'b'


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:44:19.414331
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    m = "This is my test message"
    v = "1.9"
    s = _DeprecatedSequenceConstant([], m, v)
    assert len(s) == 0
    assert m == s._msg
    assert v == s._version
    assert _ACTION_ALL_INCLUDES == s._value

# Generated at 2022-06-20 13:44:22.307827
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_MODULE_NAME is 'command', DEFAULT_MODULE_NAME
    assert DEFAULT_SUDO_PASS is None, DEFAULT_SUDO_PASS
    assert UNREACHABLE_STRING is "<unreachable>"

# Generated at 2022-06-20 13:44:23.982565
# Unit test for function set_constant
def test_set_constant():
    ns = {}
    set_constant('foo', 'bar', export=ns)
    assert 'foo' in ns
    assert ns['foo'] == 'bar'

# Generated at 2022-06-20 13:44:40.929807
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test when the value is not a sequence
    test_obj = _DeprecatedSequenceConstant('test', 'test msg', 'test version')
    try:
        test_obj.__getitem__(0)
        assert False
    except TypeError as exc:
        assert "'str' object has no attribute '__getitem__'" == str(exc)

    # Test when the value is a sequence
    value_list = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value_list, 'test msg', 'test version')
    for index in range(3):
        assert index == test_obj.__getitem__(index)

    # Test the whole scenario of getting values from nested sequences

# Generated at 2022-06-20 13:44:48.830253
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_constant = _DeprecatedSequenceConstant('some_text', 'this is a msg', '1.1')
    assert seq_constant.__getitem__(0) == 's', 'Value does not match'
    assert seq_constant.__getitem__(1) == 'o', 'Value does not match'
    assert seq_constant.__getitem__(2) == 'm', 'Value does not match'

# Generated at 2022-06-20 13:44:56.259934
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def test_range_getitem(a, b):
        return all([_DeprecatedSequenceConstant(range(0, 10), 'msg', 'version')[i] == range(0, 10)[i] for i in range(a, b)])

    assert test_range_getitem(0, 5) is True
    assert test_range_getitem(5, 10) is True
    assert test_range_getitem(0, 10) is True
    assert test_range_getitem(5, 5) is True



# Generated at 2022-06-20 13:44:59.054368
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(list(_DeprecatedSequenceConstant(['a', 'b', 'c', 'd'], 'msg', 'version'))) == 4



# Generated at 2022-06-20 13:45:05.674756
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def _test(input_value, output_value):
        msg = 'msg'
        version = 'version'
        ds = _DeprecatedSequenceConstant(input_value, msg, version)
        assert output_value == ds[0]

    # Test cases below
    _test([1, 2], [1, 2])
    _test((1, 2), [1, 2])


# Generated at 2022-06-20 13:45:06.708826
# Unit test for function set_constant
def test_set_constant():
    assert FOO_BAR == 'baz'

# Generated at 2022-06-20 13:45:13.701767
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 3], 'test', '2.11')._value == ['a', 3]
    assert _DeprecatedSequenceConstant(['a', 3], 'test', '2.11')._msg == 'test'
    assert _DeprecatedSequenceConstant(['a', 3], 'test', '2.11')._version == '2.11'
    assert _DeprecatedSequenceConstant(['a', 3], 'test', '2.11').__len__() == 2
    assert _DeprecatedSequenceConstant(['a', 3], 'test', '2.11').__getitem__(1) == 3

# Generated at 2022-06-20 13:45:16.566816
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant = _DeprecatedSequenceConstant((1,2), 'deprecated msg', '3.0')
    assert len(deprecated_constant) == 2
    assert deprecated_constant[0] == 1

# Generated at 2022-06-20 13:45:27.122071
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import DeprecatedDict
    global config
    config = ConfigManager()
    dsc = _DeprecatedSequenceConstant([], 'test message', '2.8.0')
    dsc.config = config
    dsc._value = {'a': 1, 'b': 2}
    dsc.__getitem__('a')
    messages = [x['msg'] for x in config._log_messages if isinstance(x['msg'], DeprecatedDict)]
    assert messages[0].entry['msg'] == 'test message'
    assert messages[0].entry['version'] == '2.8.0'

# Generated at 2022-06-20 13:45:33.976535
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    message = 'This is a test'
    version = '1.0'
    value = [1, 2, 3]
    t = _DeprecatedSequenceConstant(value, message, version)
    assert t[0] == value[0]



# Generated at 2022-06-20 13:45:57.625016
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_1 = ['1','2','3','4','5']
    warning_message = 'This is a test'
    version = '2.0'
    dep_seq_const_1 = _DeprecatedSequenceConstant(list_1, warning_message, version)
    assert len(dep_seq_const_1) == len(list_1)


# Generated at 2022-06-20 13:46:06.775057
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant(1, 'msg', 'version')
    assert s == 1
    assert len(s) == 1
    assert s[0] == 1


# Legacy constants from old settings
DEFAULT_SUDO_PASS = DEFAULT_BECOME_PASS
DEFAULT_SUDO_EXE = None
DEFAULT_SUDO_FLAGS = None
DEFAULT_SU_EXE = None
DEFAULT_SU_FLAGS = None
DEFAULT_SU = False
DEFAULT_SUDO = False
DEFAULT_SU_USER = None
DEFAULT_SUDO_USER = None
DEFAULT_ASK_SUDO_PASS = False
DEFAULT_ASK_SU_PASS = False
DEFAULT_REMOTE_PORT = None
DEFAULT_REMOTE_USER = None
DEFAULT_

# Generated at 2022-06-20 13:46:10.311002
# Unit test for function set_constant
def test_set_constant():
    set_constant('MY_CONST', 1)
    assert MY_CONST == 1
    assert 'MY_CONST' in vars()



# Generated at 2022-06-20 13:46:12.988235
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(None, msg="msg", version="version")
    assert len(seq) == 0



# Generated at 2022-06-20 13:46:18.735620
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'
    set_constant('FOO', 'BAZ', dict())
    assert FOO == 'BAR'
    d = dict()
    set_constant('FOO', 'BAZ', d)
    assert d['FOO'] == 'BAZ'


# Generated at 2022-06-20 13:46:29.137407
# Unit test for function set_constant
def test_set_constant():
    ''' test set_constant '''
    set_constant('FOOBAR', 'teststring')
    set_constant('FOOBAR2', True)
    set_constant('FOOBAR3', False)
    set_constant('FOOBAR4', ['test', 'list'])
    set_constant('FOOBAR5', {'test':'dict'})
    assert FOOBAR == 'teststring'
    assert FOOBAR2 is True
    assert FOOBAR3 is False
    assert FOOBAR4 == ['test', 'list']
    assert FOOBAR5 == {'test':'dict'}

# Generated at 2022-06-20 13:46:33.747526
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    listtest = [1,2,3]
    dsc_test = _DeprecatedSequenceConstant(listtest, 'test message', '1.0')
    assert dsc_test[1] == 2
    assert dsc_test[2] == 3



# Generated at 2022-06-20 13:46:39.463452
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['foo', 'bar']
    msg = 'Here is a deprecated message'
    version = '2.1'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 2
    assert value[1] == dsc[1]


# When adding a new config setting here, please ensure that there is a related "Type:" comment in the top level
# docstring of ansible-config so that the docs can be built properly.

# Generated at 2022-06-20 13:46:42.022082
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    actual = _DeprecatedSequenceConstant((1, 2, 3, 4), '', '').__getitem__(2)
    assert actual == 3


# Generated at 2022-06-20 13:46:47.943941
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'foo'
    version = '1.0'

    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-20 13:47:36.044981
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((), '', '')) == 0



# Generated at 2022-06-20 13:47:39.734919
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import ansible.constants
    seq_constant = _DeprecatedSequenceConstant([1], 'example', '2.10.0')

    assert len(seq_constant) == 1
    assert len(seq_constant) == 1


# Generated at 2022-06-20 13:47:47.175908
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_value = _DeprecatedSequenceConstant(['foo', 'bar'], 'Sequence is deprecated', '2.12')

    assert(len(deprecated_value) == len(['foo', 'bar']))
    assert(deprecated_value[0] == 'foo')
    assert(deprecated_value[1] == 'bar')

CONFIG_ERRORS = tuple(__name__ + '.' + x for x in config.FAILED_SETTINGS)
CONFIG_WARN = tuple(__name__ + '.' + x for x in config.WARNINGS)
CONFIG_TRUE = tuple(__name__ + '.' + x for x in config.BOOLEANS_TRUE)
CONFIG_FALSE = tuple(__name__ + '.' + x for x in config.BOOLEANS_FALSE)
CON

# Generated at 2022-06-20 13:47:58.027036
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Negative test cases with non-existing items

    # Empty list
    lst = []
    dsc = _DeprecatedSequenceConstant(lst, 'msg', 'version')
    if dsc[0] is not None:
        raise AssertionError('Expected to return None for dsc[0] for an empty list')
    if dsc['abc'] is not None:
        raise AssertionError('Expected to return None for dsc[\'abc\'] for an empty list')
    if dsc[100] is not None:
        raise AssertionError('Expected to return None for dsc[100] for an empty list')

    # Non-empty list
    lst = ['abc', 'def', 'ghi']
    dsc = _DeprecatedSequenceConstant(lst, 'msg', 'version')
   

# Generated at 2022-06-20 13:48:11.185457
# Unit test for function set_constant
def test_set_constant():
    # Test that set_constant() sets constants in provided
    # namespace.
    test_dict = {}
    set_constant('test', 'test_value', export=test_dict)
    assert test_dict['test'] == 'test_value'

    # Test that set_constant() sets constants in module
    # global namespace when no namespace is provided.
    set_constant('test', 'test_value')
    assert 'test' in globals()

    # Test that set_constant() raises ValueError if a constant
    # already exists in the namespace.
    try:
        set_constant('test', 'test_value', export=test_dict)
    except ValueError:
        assert test_dict['test'] == 'test_value'
    else:
        assert 'test' in globals()


# FIXME:

# Generated at 2022-06-20 13:48:12.483250
# Unit test for function set_constant
def test_set_constant():
    set_constant('A', 'B')
    assert A == 'B'

# Generated at 2022-06-20 13:48:14.835804
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], "msg", "version")) == 2
    assert len(_DeprecatedSequenceConstant([], "msg", "version")) == 0


# Generated at 2022-06-20 13:48:28.648993
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    This is a unit test for method __getitem__ of class _DeprecatedSequenceConstant
    '''
    import sys

    class MockDisplay(object):
        def deprecated(self, msg, version):
            sys.stderr.write(' [DEPRECATED] %s, to be removed in %s\n' % (msg, version))

    obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='dummy message', version='2.2')
    original__getitem__ = obj.__getitem__

    with MockDisplay():
        assert original__getitem__(1) == 2
        assert original__getitem__(1) == 2
        assert len(sys.stderr.getvalue().split('\n')) == 2



# Generated at 2022-06-20 13:48:38.054420
# Unit test for function set_constant
def test_set_constant():
    import copy
    import os
    import os.path
    import pwd
    import sys
    import tempfile
    import shutil
    import stat

    # the following constants are not expected to be overwritten by set_constant
    DUMMY_CONSTANT = 'dummy_value'
    DUMMY_HASH = 'Dummy Hash'
    DUMMY_TEST = 'Dummy Test'
    DUMMY_VALUE = 'dummy_value'

    # test setup
    DIR_TMP = tempfile.mkdtemp()
    DIR_TEST = os.path.join(DIR_TMP, 'test')
    FILE_TEST = os.path.join(DIR_TEST, 'ansible.cfg')

    # create test directory and test file

# Generated at 2022-06-20 13:48:41.154482
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant([1], "test", "2.0")
    res = test_obj[0]
    assert res == 1

# Generated at 2022-06-20 13:50:35.235229
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    data = _DeprecatedSequenceConstant((1, 2, 3), "foo", "bar")
    assert(isinstance(data, Sequence))
    assert(len(data) == 3)
    assert(data[0] == 1)

# Generated at 2022-06-20 13:50:44.106942
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class Test():
        """
        Test the constructor of the class _DeprecatedSequenceConstant
        """
        def __init__(self):
            """
            Constructor of Test class

            """
            self.value = 123
            self.msg = "this is a test"
            self.version = "1.0"

        def test_msg(self, message):
            """
            Test the format of the message
            """
            if (self.msg in message):
                return True
            else:
                return False

    my_test = Test()
    my_seq = _DeprecatedSequenceConstant(my_test.value, my_test.msg, my_test.version)

    assert my_test.test_msg(_deprecated.__doc__)
    assert my_seq.__len__() == 3
    assert my

# Generated at 2022-06-20 13:50:47.704676
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], "Deprecated", "version")
    actual_len = len(deprecated_sequence_constant)
    expected_value_of_actual_len = 3
    assert actual_len == expected_value_of_actual_len


# Generated at 2022-06-20 13:50:53.210892
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test call to _DeprecatedSequenceConstant.__getitem__ with no
    # assertions. This function is currently only used internally.
    # It should be modified when the use cases change.
    msg = 'test message'
    version = 'test version'
    obj = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    obj[0]


# Generated at 2022-06-20 13:50:56.346714
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = [1, 2]
    y = _DeprecatedSequenceConstant(x, 'test', '2.9')
    assert len(x) == len(y)


# Generated at 2022-06-20 13:51:03.907111
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_native
    import tempfile
    import io

    # Create a io.StringIO() or io.BytesIO() instance
    result = io.StringIO()
    # Create a temporary file with tempfile module
    f = tempfile.TemporaryFile()
    obj = _DeprecatedSequenceConstant([1, 2], 'The msg', 'The version')
    length = len(obj)
    result.write(to_native(length))
    f.write(result.getvalue().encode('utf-8'))
    f.seek(0)
    content = f.readlines()
    f.close()


# Generated at 2022-06-20 13:51:10.778389
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Fails with no arg
    try:
        res = _DeprecatedSequenceConstant(['a'], 'test_warn', (1, 0)).__getitem__()
        assert res == False, 'This test should have failed because it has no arg'
    except Exception:
        pass

    # Fails with bad arg
    try:
        res = _DeprecatedSequenceConstant(['a'], 'test_warn', (1, 0)).__getitem__([])
        assert res == False, 'This test should have failed because it has an invalid arg'
    except Exception:
        pass

    # Succeeds with good arg
    res = _DeprecatedSequenceConstant(['a'], 'test_warn', (1, 0)).__getitem__(0)
    assert res == 'a', 'This test should have succeeded'


# Generated at 2022-06-20 13:51:13.997380
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert a[1] == 2
    assert a[0] == 1
    assert a[2] == 3


# Generated at 2022-06-20 13:51:16.318820
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([],'test', '2.0').__len__() == 0

# Generated at 2022-06-20 13:51:21.897590
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for a list
    value = [1, 2, 3]
    msg = 'foo'
    version = '1.0'
    expected = 3
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert(expected == len(dsc))
    # Test for a tuple
    value = (1, 2, 3)
    msg = 'foo'
    version = '1.0'
    expected = 3
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert(expected == len(dsc))
