

# Generated at 2022-06-20 13:43:43.016288
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(('', ), 'This should be printed', '2.8')
    try:
        assert 'This should be printed' == test_obj[0]
    except AssertionError:
        raise AssertionError('_DeprecatedSequenceConstant.__getitem__ test fail')

# Generated at 2022-06-20 13:43:45.154276
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('foo', 'bar', export)
    assert 'foo' in export
    assert export['foo'] == 'bar'

# Generated at 2022-06-20 13:43:46.986730
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', 'test version')
    assert len(dsc) == 3


# Generated at 2022-06-20 13:43:49.105163
# Unit test for function set_constant
def test_set_constant():
    actual = set_constant('TEST_CONSTANT', 1, export=dict())
    assert actual['TEST_CONSTANT'] == 1

# Generated at 2022-06-20 13:43:55.116318
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'message', '2.9')
    assert len(dsc) == 3
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

if __name__ == '__main__':
    import pytest
    pytest.main(['-xrf'])

# Generated at 2022-06-20 13:44:03.224381
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([], '', '')
    assert len(seq) == 0

    seq = _DeprecatedSequenceConstant([1,2], '', '')
    assert len(seq) == 2


# Generated at 2022-06-20 13:44:07.271255
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant_value = [1, 2, 3]
    constant_msg = 'test is deprecated'
    constant_version = '2.11'
    sequence_object = _DeprecatedSequenceConstant(constant_value, constant_msg, constant_version)
    sequence_object_len = len(sequence_object)
    assert(sequence_object_len == len(constant_value))


# Generated at 2022-06-20 13:44:15.389209
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_values = ('test_string', ('test_tuple', 'of_strings'), ['test_list', 'of_strings'])
    for value in test_values:
        # Make a DeprecatedSequenceConstant object
        dsc_test = _DeprecatedSequenceConstant(value, 'This method is deprecated', '2.8')
        # Test that the length is the same as the length of sequence
        assert len(value) == len(dsc_test)

# Generated at 2022-06-20 13:44:19.746253
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Initialize
    l = _DeprecatedSequenceConstant('test', "Test Message", "Ansible 3.0")

    # Shouldn't throw a deprecation warning
    l[0]
    # Should print a deprecation warning
    l[1]

#Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-20 13:44:27.001006
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(('a','b','c','d','e','f','g'),
            'This is a test of the emergency broadcast system', '2.0')
    assert(dsc[2] == 'c')
    assert(len(dsc) == 7)

# Generated at 2022-06-20 13:44:34.229781
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # TypeError: 'NoneType' object is not callable
    obj = _DeprecatedSequenceConstant(None, None, None)



# Generated at 2022-06-20 13:44:41.920392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_deprecated_sequence_constants = [
        _DeprecatedSequenceConstant(value=('abc', 'xyz'), msg='old deprecated message', version='2.0'),
        _DeprecatedSequenceConstant(value=('abc', 'xyz'), msg='old deprecated message', version='2.0'),
        _DeprecatedSequenceConstant(value=('abc', 'xyz'), msg='old deprecated message', version='2.0'),
        _DeprecatedSequenceConstant(value=('abc', 'xyz'), msg='old deprecated message', version='2.0'),
    ]
    test_deprecated_sequence_constants[0].__getitem__(0)
    test_deprecated_sequence_constants[1].__getitem__(1)
    test_deprecated_sequence_constants[2].__getitem__

# Generated at 2022-06-20 13:44:50.110808
# Unit test for function set_constant
def test_set_constant():
    # Test base case, setting a constant and exporting
    set_constant('a', '1')
    assert vars()['a'] == '1'

    # Test setting a constant, not exporting it
    set_constant('b', '2', export=dict())
    assert 'b' not in vars()

    # Test setting a constant and exporting as a different name
    set_constant('c', '3', export=dict(c='d'))
    assert vars()['d'] == '3'

# Generated at 2022-06-20 13:44:58.037551
# Unit test for function set_constant
def test_set_constant():
    class Dummy(object):
        pass
    export = Dummy()
    for setting in config.config.get_settings():
        # Skip our special settings set by set_constant
        if setting.name in ('BECOME_PASS', 'DEFAULT_BECOME_PASS', 'REMOTE_PASS'):
            continue
        set_constant(setting.name, True, export)

    return export

# Map settings to deprecated names

# Generated at 2022-06-20 13:45:00.799540
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert list(_DeprecatedSequenceConstant((1, 2, 3), 'message', 'version')._value) == [1, 2, 3]

# Generated at 2022-06-20 13:45:03.605196
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant('foo', 'msg', 'version')
    assert c[0] == 'foo'


# Generated at 2022-06-20 13:45:07.847089
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import collections
    test_obj = _DeprecatedSequenceConstant(value=list(), msg='Test message', version='Test version')
    assert isinstance(test_obj, collections.Sequence)
    assert len(test_obj) == 0
    assert test_obj[0] is None


# Generated at 2022-06-20 13:45:16.345514
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    from ansible.constants import VAULT_VERSION_MIN

    # Test normal value
    sequence_constant = _DeprecatedSequenceConstant(list(range(10)), "foo", "2.2")
    assert sequence_constant[0] == 0
    assert sequence_constant[-1] == 9

    # Test exception
    sequence_constant = _DeprecatedSequenceConstant(list(range(10)), "foo", "2.2")
    try:
        sequence_constant[10]
    except IndexError as e:
        assert str(e) == 'list index out of range'

    # Test deprecated warning
    sequence_constant = _DeprecatedSequenceConstant(list(range(10)), "foo", "2.2")
    assert sequence_constant[0] == 0

# Generated at 2022-06-20 13:45:28.020873
# Unit test for function set_constant
def test_set_constant():
    tmp_globals=globals().copy()
    set_constant('foo', 'bar', export=tmp_globals)
    assert 'foo' in tmp_globals
    assert tmp_globals['foo'] == 'bar'


# DEPRECATED CONSTANTS ###

# removed in 2.8
WIN_DEFAULT_SYSTEM_DRIVE = None
_WIN_DEFAULT_SYSTEM_DRIVE = FROZENSET((add_internal_fqcns(('system_drive', ))))

# Generated at 2022-06-20 13:45:30.466090
# Unit test for function set_constant
def test_set_constant():
    foo = {}
    set_constant("test", "foo", export=foo)
    assert foo['test'] == 'foo'



# Generated at 2022-06-20 13:45:39.343266
# Unit test for function set_constant
def test_set_constant():
    global boolean_false
    import sys
    if sys.version_info < (3,):
        set_constant('boolean_false', 'xxxx', export=globals())
    else:
        set_constant('boolean_false', 'xxxx')
    assert boolean_false is False

# Generated at 2022-06-20 13:45:40.522272
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=1, msg='msg', version='version')[0] == 1


# Generated at 2022-06-20 13:45:43.177467
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert len(x) == 3

# Generated at 2022-06-20 13:45:51.399611
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a message to be displayed"
    version = "2.10"
    value = ['a', 'b', 'c']
    c = _DeprecatedSequenceConstant(value, msg, version)
    assert len(c) == len(value)
    assert c[0] == value[0]
    assert c[1] == value[1]
    assert c[2] == value[2]

# Generated at 2022-06-20 13:45:55.186601
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    dc = _DeprecatedSequenceConstant(['foo'], msg, version)
    assert dc[0] == 'foo'


# Generated at 2022-06-20 13:45:58.231395
# Unit test for function set_constant
def test_set_constant():
    assert 'BECOME_PASS' not in vars()
    set_constant('BECOME_PASS', 'BecomePass', export=vars())
    assert vars()['BECOME_PASS'] == 'BecomePass'

# Generated at 2022-06-20 13:46:00.060668
# Unit test for function set_constant
def test_set_constant():
    constants = dict()
    set_constant('a', 1, export=constants)
    assert constants.get('a') == 1

test_set_constant()

# Generated at 2022-06-20 13:46:07.009072
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class FakeDisplay_warning():
        def __init__(self):
            self.warn = ""

        def warning(self, msg):
            self.warn = msg

    fakedisplay = FakeDisplay_warning()
    msg = "msg"
    version = "version"
    # tests Sequence
    test_value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value=test_value, msg=msg, version=version)
    assert test_value[0] == deprecated_sequence_constant[0]
    assert test_value[1] == deprecated_sequence_constant[1]
    assert test_value[2] == deprecated_sequence_constant[2]
    # tests _deprecated
    _deprecated(msg, version)

# Generated at 2022-06-20 13:46:09.297396
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_con = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    result = len(seq_con) == 3 and seq_con[1] == 2
    assert result, 'constructor of class _DeprecatedSequenceConstant failed'


test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:46:15.694759
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.constant_loader import set_constant
    name = 'ANSIBLE_TEST'
    value = 'test'
    # make a copy of globals so we don't mess with other tests
    export = dict(globals())
    set_constant(name, value, export)
    assert export[name] == value

# Generated at 2022-06-20 13:46:26.005463
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert (_DeprecatedSequenceConstant(['a', 'b', 'c'], 'message', 'version').__len__() == 3)

# Generated at 2022-06-20 13:46:37.796212
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''test the constructor of class _DeprecatedSequenceConstant'''
    import sys

    test_stdout = sys.stdout
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_value = (1, 2, 3)
    test_stdout.write('Testing the class _DeprecatedSequenceConstant:\n')
    test = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    test_stdout.write('  Testing the method __len__:\n')
    test_stdout.write('    test.__len__(): ')
    test_stdout.write(str(test.__len__()))
    test_stdout.write('\n  Testing the method __getitem__:\n')

# Generated at 2022-06-20 13:46:44.746285
# Unit test for function set_constant
def test_set_constant():
    from ansible.constants import set_constant
    from ansible.release import __version__

    assert set_constant('TEST_CONST', 'test_const_value') == dict(config.data.get_settings(), TEST_CONST='test_const_value')
    assert set_constant('TEST_CONST_2', '{{ ansible_version }}') == dict(config.data.get_settings(), TEST_CONST='test_const_value', TEST_CONST_2=__version__)

# Generated at 2022-06-20 13:46:49.382940
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test_msg', '2.9')
    assert constant[0] == 'a'
    assert constant[-1] == 'c'
    assert constant[1:2] == ['b']

# Generated at 2022-06-20 13:46:57.578731
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-20 13:47:02.416135
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Setup test
    test = _DeprecatedSequenceConstant("test", "msg", "1")

    # Execute code
    result = len(test)

    # Verify results
    assert result == 4


# Generated at 2022-06-20 13:47:15.364174
# Unit test for function set_constant
def test_set_constant():
    _const = {}
    set_constant('FOO', 3, _const)
    assert _const['FOO'] == 3

# Has to be lower case or it's not a constant because upper
# case is used for documentation as title.
assert DEFAULT_BECOME_METHOD == 'sudo'
assert DEFAULT_BECOME_USER == 'root'
assert DEFAULT_FORKS == 5
assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'
assert DEFAULT_MODULE_NAME == 'command'
assert DEFAULT_MODULE_PATH == None
assert DEFAULT_PATTERN == '*'
assert DEFAULT_REMOTE_USER == 'root'
assert DEFAULT_SUBSET == None
assert DEFAULT_SUDO_EXE == 'sudo'

# Generated at 2022-06-20 13:47:22.972617
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'test', '0.0')
    assert len(constant) == 3
test__DeprecatedSequenceConstant___len__()


# Generated at 2022-06-20 13:47:32.242789
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from textwrap import dedent

    # test with empty list
    value = []
    msg = dedent('''\
    This is a deprecation warning and the feature will be removed in a future release. \
    See the documentation for further details.
    ''')
    version = '2.8'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 0, \
        "test__DeprecatedSequenceConstant___len__() failed with empty list as value"

    # test with standard list
    value = [1,2,3,4,5]
    dsc = _DeprecatedSequenceConstant(value, msg, version)

# Generated at 2022-06-20 13:47:37.858485
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Given
    value = ['1', '2', '3']
    msg = 'This is deprecated'
    version = '1.0'
    # When
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    # Then
    result = deprecated_sequence_constant[0]
    assert result == value[0]

# Generated at 2022-06-20 13:47:59.179055
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    A = _DeprecatedSequenceConstant([1, 2, 3, 4, 5], "A", "2.0")
    assert A[2] == 3
    assert A[-2] == 4
    assert A[-1] == 5
    assert A[1:3] == [2, 3]
    assert A[2:] == [3, 4, 5]
    assert A[:-1] == [1, 2, 3, 4]
    assert A[2:-2] == [3, 4]
    assert A[1:] == [2, 3, 4, 5]


# Generated at 2022-06-20 13:48:01.508464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], "Test warn message", '2.9') == [1, 2, 3]
    assert _DeprecatedSequenceConstant("test", "Test warn message", '2.9') == "test"

test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:48:11.560180
# Unit test for function set_constant
def test_set_constant():
    assert bin_ansible_call == config.data.get_config_value('bin_ansible_call')
    assert callback_whitelist == config.data.get_config_value('callback_whitelist')
    assert DEFAULT_BECOME_PASS == config.data.get_config_value('DEFAULT_BECOME_PASS')
    assert DEFAULT_PASSWORD_CHARS == config.data.get_config_value('DEFAULT_PASSWORD_CHARS')
    assert DEFAULT_REMOTE_PASS == config.data.get_config_value('DEFAULT_REMOTE_PASS')
    assert DEFAULT_SUBSET == config.data.get_config_value('DEFAULT_SUBSET')

# Generated at 2022-06-20 13:48:16.680400
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Test class _DeprecatedSequenceConstant method __getitem__"""
    seqa = _DeprecatedSequenceConstant(['abc', 'def'], 'test', '1.2.3')
    assert seqa[0] == 'abc'
    assert seqa[1] == 'def'
    seqa = _DeprecatedSequenceConstant(['abc', 'def'], 'test', '1.2.3')
    assert seqa[0] == 'abc'
    assert seqa[-1] == 'def'



# Generated at 2022-06-20 13:48:19.756316
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class_ = _DeprecatedSequenceConstant([], '', '')
    assert len(class_) == 0


# Generated at 2022-06-20 13:48:25.554814
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert len(a) == 3
    # Test that the warning is printed

#
# NOTE: when adding things to this file, please
# add it right above this comment, so that the
# constants are alphabetized for sanity sake
#

# Generated at 2022-06-20 13:48:36.210203
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import pytest

    # _DeprecatedSequenceConstant is a sequence.
    assert isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'Some message', '2.4'), Sequence)

    # Test the deprecated message when use property .len()
    with pytest.warns(DeprecationWarning) as warning_record:
        assert 3 == len(_DeprecatedSequenceConstant([1, 2, 3], 'Some message', '2.4'))
        assert warning_record[0].message.args[0] == "_DeprecatedSequenceConstant(['1', '2', '3'], 'Some message', '2.4')"
        assert warning_record[0].message.args[1] == "Some message"
        assert warning_record[0].message.args[2] == '2.4'

    # Test

# Generated at 2022-06-20 13:48:38.587417
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant(('test'), 'test_msg', 'test_version')
    assert len(test_obj) == 1

# Generated at 2022-06-20 13:48:43.800673
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    print("test__DeprecatedSequenceConstant___len__: ", end = '')
    dsc_i = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    if len(dsc_i) == 3:
        print("passed")
    else:
        print("failed")


# Generated at 2022-06-20 13:48:46.044424
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(("foo", "bar"), "msg", "version")) == 2

# Generated at 2022-06-20 13:49:23.812770
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test when value is list
    value = [1,2,3]
    msg = "This is a test"
    version = "1.0"
    sequences = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequences) == 3
    # test when value is tuple
    value = (4,5,6)
    sequences = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequences) == 3
    # test when value is other type
    value = "abc123"
    sequences = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequences) == 0


# Generated at 2022-06-20 13:49:26.714613
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert test[0] == 1
    assert test[1] == 2

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:49:36.338432
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def check(data, msg, version, expected_data, expected_msg, expected_version):
        obj = _DeprecatedSequenceConstant(data, msg, version)
        actual_data = obj._value
        actual_msg = obj._msg
        actual_version = obj._version

        assert actual_data == expected_data
        assert actual_msg == expected_msg
        assert actual_version == expected_version

    check(1, 'some message', 'some version', 1, 'some message', 'some version')
    check(1, 2, 3, 1, 2, 3)
    check([1, 2, 3], 'some message', 'some version', [1, 2, 3], 'some message', 'some version')



# Generated at 2022-06-20 13:49:43.032582
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.10') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.10')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.10')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.10')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.10')[2] == 3


# Generated at 2022-06-20 13:49:46.866795
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert len(d) == 2
    assert d[0] == 'foo'

# Generated at 2022-06-20 13:49:52.077067
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Setup
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    # Assert
    assert len(test_obj) == 3

# Generated at 2022-06-20 13:49:53.917503
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-20 13:50:03.792839
# Unit test for function set_constant
def test_set_constant():
    ''' Tests for function set_constant '''

    # test for vars dict
    x = dict()
    set_constant('ANSIBLE_TEST_CONSTANT', 'TEST_VALUE', x)
    assert x['ANSIBLE_TEST_CONSTANT'] == 'TEST_VALUE'

    # test for class variable dict
    class X(object):
        def __init__(self):
            self.__dict__['ANSIBLE_TEST_CONSTANT'] = None

    x = X()
    set_constant('ANSIBLE_TEST_CONSTANT', 'TEST_VALUE', x.__dict__)
    assert x.__dict__['ANSIBLE_TEST_CONSTANT'] == 'TEST_VALUE'

# Generated at 2022-06-20 13:50:05.461071
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'


# Generated at 2022-06-20 13:50:11.770277
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # set some test variables
    value = [1, 2, 3]
    msg = 'This is a test message'
    version = '2.0.0'

    # construct the object
    test_object = _DeprecatedSequenceConstant(value, msg, version)

    # assert the values of the initializers are correct
    assert test_object._value == value
    assert test_object._msg == msg
    assert test_object._version == version

# Generated at 2022-06-20 13:51:30.332189
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    with patch('sys.stderr') as mock_stderr:
        mock_stderr.write = lambda x: x

        t = _DeprecatedSequenceConstant(list(), 'msg', 'version')
        t[1]
        assert mock_stderr.write.call_count == 1
        t[1]
        assert mock_stderr.write.call_count == 2



# Generated at 2022-06-20 13:51:33.980823
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'success')
    if 'TEST_CONSTANT' != TEST_CONSTANT:
        raise Exception('set_constant function did not set constant')

TEST_CONSTANT = ''
test_set_constant()

# Generated at 2022-06-20 13:51:36.794578
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(range(10), "msg", "1.0")
    assert sequence[2] == 2



# Generated at 2022-06-20 13:51:40.537167
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    foo = _DeprecatedSequenceConstant(value=[1, 2, 3, 4], msg='test warning', version='2.7')
    assert len(foo) == 4
    assert foo[0] == 1
    assert foo[1] == 2
    assert foo[2] == 3
    assert foo[3] == 4


# Generated at 2022-06-20 13:51:42.596144
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(list(range(10)), 'warn', 'version')
    assert x[0] == 0


# Generated at 2022-06-20 13:51:47.505616
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    lst = [1,2,3]
    lst2 = _DeprecatedSequenceConstant(lst, 'testing deprecated msg', '1.0')
    lenlst = len(lst)
    lenlst2 = len(lst2)
    assert lenlst == lenlst2


# Generated at 2022-06-20 13:51:49.925700
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    global __name__
    __name__ = 'test_import_config'
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0


# Generated at 2022-06-20 13:51:50.748348
# Unit test for function set_constant
def test_set_constant():
    set_constant('FARTS', 'toot')
    assert FARTS == 'toot'

# Generated at 2022-06-20 13:51:58.087018
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is deprecated message'
    version = '2.11'
    value = ['ansible', 'ansible-playbook']

    deprecated_seq_constant = _DeprecatedSequenceConstant(value, msg, version)

    # FIXME: no way we can test this
    # Maybe we should make _DeprecatedSequenceConstant to a callable and call it to show the deprecation
    # which will allow us to test the deprecation
    assert len(deprecated_seq_constant) == len(value)
    assert deprecated_seq_constant[0] == value[0]


# Generated at 2022-06-20 13:52:04.005852
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    dummy_output = []
    sys.stderr.write = lambda x: dummy_output.append(x)
    deprecated_constant = _DeprecatedSequenceConstant(["a", "b"], "foo", "2.0")
    try:
        deprecated_constant[2]
    except IndexError:
        pass
    else:
        assert False, "IndexError exception expected"
    assert '[DEPRECATED] foo, to be removed in 2.0\n' in dummy_output
