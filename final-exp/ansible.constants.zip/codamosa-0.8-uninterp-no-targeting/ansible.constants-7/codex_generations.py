

# Generated at 2022-06-20 13:43:45.908829
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.release import __version__
    import sys
    class DummyDisplay(object):
        def __init__(self):
            self.warns = []
        def deprecated(self, msg, version=None):
            assert 'display is not guaranteed here' not in msg
            self.warns.append(msg)

    msg = 'this is a test'
    version = __version__

    original_display = sys.modules.get('ansible.utils.display')
    dummy_display = DummyDisplay()
    sys.modules['ansible.utils.display'] = dummy_display
    constant = _DeprecatedSequenceConstant((1, 2, 3), msg, version)
    constant[0]
    dummy_display.warns[0] == msg
    sys.modules['ansible.utils.display'] = original_display

# Generated at 2022-06-20 13:43:56.588274
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test if value will be the same when the class could not be instantiated
    deprecated_msg = 'this is deprecated'
    deprecated_version = '2.10'
    value = ['test_value']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, deprecated_msg, deprecated_version)
    assert deprecated_sequence_constant[:] == value
    assert len(deprecated_sequence_constant) == len(value)
    # TODO: test deprecated output.  Currently this is not possible
    # see: https://github.com/ansible/ansible/pull/14006#discussion_r53944902

# Generated at 2022-06-20 13:44:02.441769
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected_value = _DeprecatedSequenceConstant([1, 2, 3, 4], 'msg', 'version')
    assert len(expected_value) == 4


# Generated at 2022-06-20 13:44:05.022266
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testSequence = _DeprecatedSequenceConstant('TestString', 'WarningMesssage', 'Version')
    assert testSequence.__len__() == 11


# Generated at 2022-06-20 13:44:06.728262
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    actual = len(_DeprecatedSequenceConstant(value=(1, 2, 3), msg='msg', version='version'))
    assert actual == 3


# Generated at 2022-06-20 13:44:10.318097
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(ADD_HOST_MODULE_ARGS) == len(('hostname', 'groupname', 'port', 'properties'))


# Generated at 2022-06-20 13:44:13.005547
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert(len(_DeprecatedSequenceConstant((1,2), '', '2.6')) == 2)

# Generated at 2022-06-20 13:44:16.702270
# Unit test for function set_constant
def test_set_constant():

    set_constant('foo', 'bar')
    assert foo == 'bar'

    set_constant('foo', 'baz', export={'foo': 'bar'})
    assert foo == 'bar'
    assert export['foo'] == 'baz'

# Generated at 2022-06-20 13:44:18.426393
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(test) == 0
    assert test[0] is None


# Generated at 2022-06-20 13:44:21.047967
# Unit test for function set_constant
def test_set_constant():
    test_value = 'test_value'
    set_constant('TEST_SET_CONSTANT', test_value, export=vars())
    assert TEST_SET_CONSTANT == test_value
    del TEST_SET_CONSTANT

# Generated at 2022-06-20 13:44:32.070055
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "MSG"
    version = "1.0"
    value = [1, 2, 3]
    seq_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert (len(seq_constant) == len(value))



# Generated at 2022-06-20 13:44:36.484480
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(('a', 'b', 'c',), 'msg', 'version')[2] == 'c'
    assert _DeprecatedSequenceConstant((1, 2, 3,), 'msg', 'version')[1] == 2


# Generated at 2022-06-20 13:44:39.990804
# Unit test for function set_constant
def test_set_constant():
    _CONSTANTS = {}
    set_constant('FOO', 'BAR', export=_CONSTANTS)
    assert _CONSTANTS['FOO'] == 'BAR'

# Generated at 2022-06-20 13:44:47.123281
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version') == (1, 2, 3)
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')[0] == 1
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-20 13:44:51.208463
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dep = _DeprecatedSequenceConstant([1, 2], "My message", "v2.9")
    assert len(dep) == 2
    dep = _DeprecatedSequenceConstant([1, 2, 3], "My message", "v2.9")
    assert len(dep) == 3


# Generated at 2022-06-20 13:44:54.191490
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    myseq = _DeprecatedSequenceConstant([1,2,3],"Hey I'm a sequence!", '1.3.3')
    assert len(myseq) == 3
    assert list(myseq) == [1,2,3]

# Generated at 2022-06-20 13:44:56.839894
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test():
        def __len__(self):
            return 2

    t = Test()
    dsc = _DeprecatedSequenceConstant(t, 'this is a test', '2.9')
    assert len(dsc) == 2


# Generated at 2022-06-20 13:45:05.886718
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test for case of valid input
    value = [1, 2, 3, 4]
    msg = "OK"
    version = "1.0"
    seq_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) == len(seq_obj)

    # Test for case of error value i.e. value is None
    value = None
    msg = "ERROR"
    version = "1.0"
    seq_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) is not len(seq_obj)



# Generated at 2022-06-20 13:45:08.866829
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Some message'
    version = '2.1'
    value = [1]

    test = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) == len(test)


# Generated at 2022-06-20 13:45:14.198507
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant((1,2,3),msg='',version='1.1')
    assert len(a) == 3


# Generated at 2022-06-20 13:45:25.443707
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[0, 1, 2], msg='message', version='3.0')
    assert dsc[0] == 0
    assert dsc[1] == 1
    assert dsc[2] == 2


# Generated at 2022-06-20 13:45:31.932921
# Unit test for function set_constant
def test_set_constant():
    foo = {}
    set_constant('foo', 42, globals())
    set_constant('bar', 42, foo)
    assert foo['bar'] == 42
    assert foo['bar'] == globals()['foo']
    assert globals()['foo'] == 42
    assert globals()['foo'] == 42



# Generated at 2022-06-20 13:45:34.386908
# Unit test for function set_constant
def test_set_constant():
    # Test for setting constants
    set_constant('MY_CONSTANT', 'test value')
    assert MY_CONSTANT == 'test value'

# Generated at 2022-06-20 13:45:39.826811
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')
    assert isinstance(seq, Sequence)
    assert len(seq) == 2
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq._msg == 'msg'
    assert seq._version == 'version'

# Generated at 2022-06-20 13:45:43.526382
# Unit test for function set_constant
def test_set_constant():

    assert DEFAULT_BECOME_PASS is None
    set_constant('DEFAULT_BECOME_PASS', 'foo')
    assert DEFAULT_BECOME_PASS == 'foo'


# Generated at 2022-06-20 13:45:45.724163
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = _DeprecatedSequenceConstant([1, 2, 3], "test msg", "2.0")
    assert len(test_seq) == 3


# Generated at 2022-06-20 13:45:52.163544
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    old_stderr = sys.stderr

    from ansible.utils.display import Display
    from io import StringIO
    output = StringIO()
    sys.stderr = output

    def cleanup():
        sys.stderr = old_stderr


# Generated at 2022-06-20 13:45:56.135102
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == value[0]


# Generated at 2022-06-20 13:46:03.510440
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import inspect
    import sys
    import traceback
    import io

    # Capture the output of the function:
    # https://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call
    def capture_stdout(func, *args, **kwargs):
        old_stdout = sys.stdout
        result = io.StringIO()
        sys.stdout = result
        try:
            func(*args, **kwargs)
        except Exception:
            traceback.print_exc()
        sys.stdout = old_stdout

        return result.getvalue()

    # Redefine _deprecated():
    # https://stackoverflow.com/questions/12214801/print-a-traceback-from-inside-a-

# Generated at 2022-06-20 13:46:07.864074
# Unit test for function set_constant
def test_set_constant():
    set_constant("new constant", 2)
    assert new_constant == 2

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 13:46:23.081246
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "not a real deprecation"
    version = "2.0.0"
    seq = ("a", "b", "c")
    depr = _DeprecatedSequenceConstant(seq, msg, version)
    assert (len(depr) == len(seq))
    assert ("b" in depr)
    # Now check that the deprecation occurred
    assert (_deprecated.called and msg in _deprecated.call_args[0][0] and version in _deprecated.call_args[0][0])

if __name__ == '__main__':
    import mock

    _deprecated = mock.Mock()
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:46:27.958335
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Creating a new _DeprecatedSequenceConstant object and trying to get the length of it
    list_len = len( _DeprecatedSequenceConstant( [1, 2, 3], "test warning", "version") )
    assert list_len == 3

# Generated at 2022-06-20 13:46:38.256811
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.path import makedirs_safe
    import os
    import sys

    if os.path.exists('./constants_test'):
        makedirs_safe('./constants_test/constants')
        copy_dir('./ansible/constants/', './constants_test/constants')

    sys.path.insert(0, './constants_test')
    from constants import _DeprecatedSequenceConstant
    test = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert test.__getitem__(0) == 1
    assert test.__getitem__(1) == 2
    assert len(test) == 2



# Generated at 2022-06-20 13:46:45.409019
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'test'
    version = 'test'
    value = 'test'
    test_instance = _DeprecatedSequenceConstant(value, msg, version)
    assert test_instance.__len__() == len(value)

# Generated at 2022-06-20 13:46:47.991974
# Unit test for function set_constant
def test_set_constant():
    config = ConfigManager()
    config.parse([])
    assert len(config.data.get_settings()) == len(vars())

# Generated at 2022-06-20 13:46:52.607596
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant([2, 3, 4], 'test', '1.2.3')
    assert(len(test_obj) == 3)
    assert(test_obj[1] == 3)

# Lookup obj for dynamic variables
CONSTANTS = globals()



# Generated at 2022-06-20 13:46:54.496040
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(['a', 'b'], "msg", "version")
    assert(len(x) == 2)

# Generated at 2022-06-20 13:46:59.895254
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], 'msg', 'version') == _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(_DeprecatedSequenceConstant([1, 2], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant([1, 2], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([3, 4], 'msg', 'version')[1] == 4

test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:47:06.848421
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "test message", "99.99")
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3
    assert seq[-1] == 3
    assert seq[-2] == 2
    assert seq[-3] == 1


# Generated at 2022-06-20 13:47:11.760474
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleVaultEncryptedUnicode
    sequence = _DeprecatedSequenceConstant("one", "two", "three")
    assert sequence.__len__() == 3
    assert is_sequence(sequence)
    assert isinstance(sequence, AnsibleSequence)
    assert isinstance(sequence, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 13:47:46.424155
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(value=['foo'], msg='msg', version='version')
    b = a[0]
    assert b == 'foo'


# Generated at 2022-06-20 13:47:51.469093
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test = _DeprecatedSequenceConstant(('a', 'b', 'c'), "Testing the __len__ method of class _DeprecatedSequenceConstant", 2.4)
    assert len(test) == 3


# Generated at 2022-06-20 13:47:59.870766
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        from ansible.utils.display import Display
        display = Display()
    except Exception:
        import sys
        display = sys.stderr

    # Setup a mock display object to capture written warnings
    display.warning = lambda msg: display.__dict__.setdefault('warnings', []).append(msg)

    # Setup _DeprecatedSequenceConstant for test
    value = (1, 2, 3)
    msg = 'This is a test message'
    version = '2.0'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)

    # Test method __getitem__ of _DeprecatedSequenceConstant
    assert deprecated_sequence_constant[0] == 1

# Generated at 2022-06-20 13:48:01.888955
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This will be deprecated"
    version = "2.14"
    value = [1, 2, 3, 4, 5]
    data = _DeprecatedSequenceConstant(value, msg, version)
    assert len(data) == 5
    assert data[0] == 1

# Generated at 2022-06-20 13:48:05.916791
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'this is a test', '2.2')[2] == 'c'


# Generated at 2022-06-20 13:48:09.720920
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Arrange
    seq_constant = _DeprecatedSequenceConstant([1, 2, 3], 'my_msg', '1.0')

    # Act
    value = seq_constant[0]

    # Assert
    assert value == 1, '_DeprecatedSequenceConstant[0] should return {}'.format(value)


# Generated at 2022-06-20 13:48:11.949492
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([0, 1, 2], 'test_msg', 'test_version').__len__() == 3

# Generated at 2022-06-20 13:48:15.959819
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecation_msg = 'this is a sequence constant'
    version = '2.9'
    seq_var = ['hello', 'world']
    cons = _DeprecatedSequenceConstant(seq_var, deprecation_msg, version)
    assert len(cons) == 2
    assert cons[1] == 'world'

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:48:21.318074
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    c = _DeprecatedSequenceConstant(l, "Ahoj", "1.9")
    assert len(c) == 3
    assert c[1] == 2


# Generated at 2022-06-20 13:48:23.750557
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    your_value = [1,2,3]
    value = _DeprecatedSequenceConstant(your_value, 'msg', 'version')

    assert value.__getitem__(1) == your_value[1]

# Generated at 2022-06-20 13:50:02.734826
# Unit test for function set_constant
def test_set_constant():
    res = set_constant('ANSIBLE_INVENTORY', {'localhost': 'localhost'})
    assert res == locals()
    res = set_constant('ANSIBLE_INVENTORY', {'localhost': '127.0.0.1'})
    assert res == locals()

# Unit tests for function set_constant

# Generated at 2022-06-20 13:50:06.299629
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import nose
    import ansible.constants as C

    v = C._DeprecatedSequenceConstant([1, 2], 'msg', '9999')
    assert len(v) == 2
    assert v[1] == 2

if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-20 13:50:15.906012
# Unit test for function set_constant
def test_set_constant():
    set_constant('BAR', 2)
    assert BAR == 2

CACHE_PLUGINS = ('facts', 'memory', 'jsonfile')

# Fix-up some values
ANSIBLE_NOCOWS = ConfigManager.nocows
if ANSIBLE_NOCOWS is None:
    # set the default value
    ANSIBLE_NOCOWS = 1 if (sys.platform.startswith('linux') and
                           sys.stdout.isatty()) else 0

VAULT_VERSION = VAULT_VERSION_MIN if config.data.get_config_value('vault_version', 1, 'constants') is True else VAULT_VERSION_MAX

REPLACER = None

# DEPRECATED OPTIONS

ANSIBLE_VARIABLE_START_MARKER = '{{'
ANS

# Generated at 2022-06-20 13:50:17.667603
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant([1,2,3], 'message', 'version')
    assert sequence_constant[1] == 2


# Generated at 2022-06-20 13:50:23.870525
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dummy_obj = _DeprecatedSequenceConstant('dummy_value', 'dummy_msg', 'dummy_version')
    assert repr(dummy_obj) == "dummy_value"
    assert len(dummy_obj) == 10
    assert dummy_obj[0] == 'd'

# Generated at 2022-06-20 13:50:30.735883
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class __DeprecatedSequenceConstant(object):
        def __init__(self):
            self.msg = None
            self.version = None
            self.value = None
        def __getitem__(self, index):
            _deprecated(self.msg, self.version)
            return self.value[index]
    c = __DeprecatedSequenceConstant()
    c.msg = 'description of deprecation'
    c.version = '2.8'
    c.value = [0, 1, 2]
    assert c[0] == 0
    assert c[1] == 1
    assert c[2] == 2

# Generated at 2022-06-20 13:50:36.342119
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test value of _SequenceConstant
    value = [1, 2, 3]
    assert value == [1, 2, 3]

    msg = "msg"
    version = "version"

    sut = _DeprecatedSequenceConstant(value, msg, version)

    # test result
    result = sut.__len__()
    assert 3 == result



# Generated at 2022-06-20 13:50:40.740996
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _Test(_DeprecatedSequenceConstant):
        def __init__(self):
            super(self.__class__, self).__init__(value=list(range(10)), msg='msg', version='version')

    test = _Test()
    assert test[0] == 0
    assert test[-1] == 9
    assert test[1:3] == [1, 2]

# Generated at 2022-06-20 13:50:47.682006
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # try _DeprecatedSequenceConstant constructor
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Print settings')
    parser.add_argument('--list', dest='list', action='store_true', help='list settings (default)')
    parser.add_argument('--name', dest='name', action='store', default=None, help='name of setting to print')
    parser.add_argument('--show-defaults', dest='show_defaults', action='store_true', default=False, help='Only show defaults')

# Generated at 2022-06-20 13:50:57.578028
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import is_sequence
    assert isinstance(
        _DeprecatedSequenceConstant(
            'value', 'msg', 'version'
        ), _DeprecatedSequenceConstant
    )
    assert is_sequence(_DeprecatedSequenceConstant('value', 'msg', 'version'))
    assert len(_DeprecatedSequenceConstant('value', 'msg', 'version')) == 6
    assert _DeprecatedSequenceConstant('value', 'msg', 'version')[3] == 'u'
    assert _DeprecatedSequenceConstant('value', 'msg', 'version')[-1] == 'n'

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()