

# Generated at 2022-06-20 13:43:43.070076
# Unit test for function set_constant
def test_set_constant():
    # set export
    export = dict(hoge='hoge')

    # set constant
    set_constant('hoge', 'foo', export)

    assert export['hoge'] == 'foo'

# Generated at 2022-06-20 13:43:45.067506
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1,2,3], 'test message', '2.0'), Sequence)

# Generated at 2022-06-20 13:43:46.925047
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=('test message', ), msg='test', version='test')
    assert dsc[0] == 'test message'


# Generated at 2022-06-20 13:43:50.301754
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([], '', '')
    # test for correct length
    assert len(c) == 0


# Generated at 2022-06-20 13:43:54.045732
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 1234)
    assert TEST_SET_CONSTANT == 1234


# Generated at 2022-06-20 13:44:01.347857
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c1 = _DeprecatedSequenceConstant([1, 2, 3], 'test message 1', '1.0')
    assert len(c1) == 3
    assert c1[0] == 1
    assert c1[1] == 2
    assert c1[2] == 3
    assert list(c1) == [1, 2, 3]
    # _deprecated method with message level 'WARNING'
    # Unit test for _deprecated method in module constants
    # The test case is skipped if the version of Ansible is 2.9 or earlier.
    # The test case is skipped if module display is not imported.
    # Otherwise, the test case is passed when a warning message is displayed.
    from ansible.utils.display import Display
    from distutils.version import LooseVersion

# Generated at 2022-06-20 13:44:06.062407
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant((), '', '')
    d2 = _DeprecatedSequenceConstant([], '', '')
    d3 = _DeprecatedSequenceConstant(['a', 'b'], '', '')
    assert len(d) == 0
    assert len(d2) == 0
    assert len(d3) == 2

# Generated at 2022-06-20 13:44:11.701479
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(sc) == 3
    assert sc[1] == 2
    assert len(sc) == 3
    assert sc[1] == 2

# Old deprecated constants, referenced from many places, don't want to remove yet
HOST_VARS_FILE = add_internal_fqcns(('host_vars', 'group_vars', 'hostvars', 'groupvars'))
DEFAULT_HOST_LIST = add_internal_fqcns(('defaults', 'all'))

# Generated at 2022-06-20 13:44:16.375103
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # var = _DeprecatedSequenceConstant(value, msg, version)
    expected = "this is some msg"
    obj = _DeprecatedSequenceConstant(['a'], expected, '1.0')
    assert obj[0] == 'a'
    assert obj._msg == expected

# Generated at 2022-06-20 13:44:18.849994
# Unit test for function set_constant
def test_set_constant():
    value = 'test'
    name = 'TEST'
    export = {}
    set_constant(name, value, export=export)
    assert export[name] == value

# Generated at 2022-06-20 13:44:25.622508
# Unit test for function set_constant
def test_set_constant():
    # Simple test
    d = {}
    set_constant('ONE', 1, export=d)
    assert d['ONE'] == 1

    # Ensure that invalid types are rejected
    class Foo(object):
        pass
    try:
        set_constant('TWO', Foo(), export=d)
    except TypeError:
        pass
    else:
        assert False, "did not fail for invalid type"


# Generated at 2022-06-20 13:44:28.262892
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant((), "", "")
    assert isinstance(test, _DeprecatedSequenceConstant)
    assert isinstance(test, Sequence)

# Generated at 2022-06-20 13:44:34.132894
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "msg", "17.9")
    assert dsc[0] == 1

# Generated at 2022-06-20 13:44:38.819204
# Unit test for function set_constant
def test_set_constant():

    # Test setting constant
    constant = 'foo'
    value = 'bar'
    export = {}
    set_constant(constant, value, export)
    assert export[constant] == value, 'Constant %s was not set to %s' % (constant, value)


# Generated at 2022-06-20 13:44:49.686358
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ANSIBLE_INTERNAL_MSG = 'The xxx described in this document does not exist'
    ANSIBLE_INTERNAL_VERSION = '2.10'
    for item in _DeprecatedSequenceConstant(['_ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS', '_ACTION_ALL_INCLUDE_ROLE_TASKS'], ANSIBLE_INTERNAL_MSG, ANSIBLE_INTERNAL_VERSION):
        assert item in ['_ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS', '_ACTION_ALL_INCLUDE_ROLE_TASKS']

# Generated at 2022-06-20 13:44:52.533121
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(None, 'message', 'version')[0] is None

# Generated at 2022-06-20 13:44:58.766866
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]

    dsc = _DeprecatedSequenceConstant(value, msg, version)

    assert len(dsc) == len(value)
    assert dsc[1] == value[1]

# Generated at 2022-06-20 13:45:03.235314
# Unit test for function set_constant
def test_set_constant():
    set_constant('constant', 5)
    set_constant('constant', 6)
    set_constant('constant', 8, locals())
    assert constant == 5
    assert 'constant' in globals()



# Generated at 2022-06-20 13:45:06.838369
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constants = _DeprecatedSequenceConstant([1, 2, 3, 4], 'testing', '2.7')
    assert(constants.__len__() == 4)
    assert(constants.__getitem__(2) == 3)

# Generated at 2022-06-20 13:45:11.090305
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Arrange
    value = 'value'
    msg = 'msg'
    version = 'version'
    instance = _DeprecatedSequenceConstant(value, msg, version)

    # Act
    result = instance.__getitem__(0)

    # Assert
    assert result == value

# Generated at 2022-06-20 13:45:16.833804
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ls = _DeprecatedSequenceConstant([1, 2, 3], "A:", __version__)
    assert len(ls) == 3


# Generated at 2022-06-20 13:45:26.034515
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    Test the __len__ method of class _DeprecatedSequenceConstant
    """
    value = [1, 2]
    msg = 'This should be deprected'
    version = '1.0'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    try:
        assert len(deprecated_sequence_constant) == len(value)
    except AssertionError:
        print('Failed to test __len__ method of class _DeprecatedSequenceConstant')


# Generated at 2022-06-20 13:45:37.085781
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(['foo', 'bar'], "this is msg", "this is version")
    assert len(c) == 2
    assert c[0] == 'foo'
    assert c[1] == 'bar'

if __name__ == "__main__":
    import unittest
    from ansible.module_utils import basic
    # We have to do this weird thing because the module_utils imports are based on the
    # path of the package, which is not normally on the path.
    import sys
    BASEDIR = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.dirname(BASEDIR))
    basic._ANSIBLE_ARGS = None
    import test.utils


# Generated at 2022-06-20 13:45:47.824965
# Unit test for function set_constant
def test_set_constant():
    '''Tests for `ansible.constants.set_constant`'''
    # Test for successful constant creation
    test_dict = {}
    set_constant('FOO', 'bar', export=test_dict)
    assert test_dict['FOO'] == 'bar'
    # Test for constant creation with type conversion
    set_constant('ANSIBLE_FOO', '2', export=test_dict)
    assert test_dict['ANSIBLE_FOO'] == 2
    set_constant('ANSIBLE_BAR', 'True', export=test_dict)
    assert test_dict['ANSIBLE_BAR']

    # Test for constant creation with templating
    with open('test_constants_set_constant.txt', 'w+') as f:
        f.write('FOO')

    set_const

# Generated at 2022-06-20 13:45:58.194475
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    assert isinstance(BOOLEANS_TRUE, Sequence)
    assert BOOLEANS_TRUE == _DeprecatedSequenceConstant(to_text(BOOLEANS_TRUE), 'Booleans_true is deprecated; use BOOLEANS_TRUE', '2.12')
    assert 'yes' == BOOLEANS_TRUE[0]
    assert 'foobar' == BOOLEANS_TRUE[-1]


# Generated at 2022-06-20 13:46:05.963637
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self):
            self.value = [1,2,3]
            self.msg = 'some message'
            self.version = '1.0'

        def test(self):
            const = _DeprecatedSequenceConstant(self.value, self.msg, self.version)
            assert const.__getitem__(0) == 1
            assert const.__getitem__(1) == 2
            assert const.__getitem__(-1) == 3
            # list index out of range
            try:
                const.__getitem__(3)
            except IndexError:
                assert True
    Test().test()


# Generated at 2022-06-20 13:46:12.422463
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is an error"
    version = "2.9"

    cst = _DeprecatedSequenceConstant(["a", "b"], msg, version)

    assert cst._msg == msg
    assert cst._version == version

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-20 13:46:23.817651
# Unit test for function set_constant
def test_set_constant():
    tmp_export = {}
    for raw_setting in config.data.get_settings():
        x = raw_setting.value
        if raw_setting.origin == 'default' and \
           isinstance(raw_setting.value, string_types) and \
           (raw_setting.value.startswith('{{') and raw_setting.value.endswith('}}')):
            try:
                t = Template(raw_setting.value)
                x = t.render(vars())
                try:
                    x = literal_eval(x)
                except ValueError:
                    pass  # not a python data structure
            except ValueError:
                pass  # not templatable

        set_constant(raw_setting.name, ensure_type(x, raw_setting.type), tmp_export)

    assert tmp_export == export

# Generated at 2022-06-20 13:46:27.169583
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    if len(list(_DeprecatedSequenceConstant([], 'foo', '2.0').__getitem__(1))) == 0:
        return 0
    else:
        return 1

# Generated at 2022-06-20 13:46:36.440732
# Unit test for function set_constant
def test_set_constant():
    # For test, we use empty dictionary
    test_dict = {}

    # Test whether set_constant creates new key
    set_constant('new_key', 'new value', test_dict)
    assert test_dict['new_key'] == 'new value'

    # Test whether set_constant updates existing key
    set_constant('new_key', 'updated value', test_dict)
    assert test_dict['new_key'] == 'updated value'

    # Test whether set_constant returns updated dictionary
    assert set_constant('another_key', 123, test_dict) == test_dict

# Generated at 2022-06-20 13:46:42.452736
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = 4
    actual = _DeprecatedSequenceConstant(value=(5, 2, 8, 4), msg='', version='')[3]
    assert actual == expected

# Generated at 2022-06-20 13:46:52.064501
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'this is deprecated', '0.0.0')

    # Test get valid value
    assert deprecated_sequence_constant[2] == 3
    assert deprecated_sequence_constant[0] == 1

    # Test get invalid value
    try:
        deprecated_sequence_constant[3]
    except IndexError:
        pass
    else:
        assert False

    try:
        deprecated_sequence_constant[-1]
    except IndexError:
        pass
    else:
        assert False



# Generated at 2022-06-20 13:47:01.405612
# Unit test for function set_constant
def test_set_constant():
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    conf = ConfigManager()

    cfg_bool = conf.data.get_setting('DEFAULT_KEEP_REMOTE_FILES')
    set_constant(cfg_bool.name, cfg_bool.value, globals())
    assert DEFAULT_KEEP_REMOTE_FILES in BOOLEANS_TRUE

# filter out the options that don't have a default
# and are not in _COMMON_CONNECTION_VARS or MAGIC_VARIABLE_MAPPING


# Generated at 2022-06-20 13:47:05.805344
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(('a','b','c','d','e'), 'This is a message', '2.6')
    assert(len(obj) == 5)


# Generated at 2022-06-20 13:47:08.280934
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', True)
    assert globals()['TEST_CONSTANT'] == True

# Generated at 2022-06-20 13:47:12.041947
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'this is deprecated.'
    version = '2.0'
    test_constant = _DeprecatedSequenceConstant(['a'], msg, version)
    assert(hasattr(test_constant, '_msg'))
    assert(hasattr(test_constant, '_version'))
    assert(hasattr(test_constant, '_value'))

# Generated at 2022-06-20 13:47:13.834845
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(["version"], "test", "version")) > 0

# Generated at 2022-06-20 13:47:16.283288
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = ('a', 'b')
    obj = _DeprecatedSequenceConstant(seq, 'msg', 'version')
    assert len(obj) == len(seq)


# Generated at 2022-06-20 13:47:21.481462
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list('abc'), "This is a test message", '2.10')) == 3


# Generated at 2022-06-20 13:47:31.733927
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def _test_deprecated_sequence_constant(deprecated_sequence_constant, value, msg, version, test_type='len', index=1):
        if test_type == 'len':
            assert len(deprecated_sequence_constant) == len(value)
        else:
            assert deprecated_sequence_constant[index] == value[index]

    test_deprecated_sequence_constant = _DeprecatedSequenceConstant(
        value=[1, 2, 3], msg='Fake deprecation', version='2.9'
    )

    _test_deprecated_sequence_constant(
        deprecated_sequence_constant=test_deprecated_sequence_constant,
        value=[1, 2, 3],
        msg='Fake deprecation',
        version='2.9'
    )

    _test_

# Generated at 2022-06-20 13:47:43.947746
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('my_constant', '1') == {'my_constant': '1'}


# Generated at 2022-06-20 13:47:48.061745
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    msg = "a"
    version = "b"
    c = _DeprecatedSequenceConstant(l, msg, version)
    assert c[0] == 1


# Generated at 2022-06-20 13:47:53.199359
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert len(dsc) == 2


# Generated at 2022-06-20 13:47:54.162370
# Unit test for function set_constant
def test_set_constant():
    constant_test = dict()
    set_constant('test', '1', constant_test)
    assert constant_test['test'] == '1'

# Generated at 2022-06-20 13:47:57.167201
# Unit test for function set_constant
def test_set_constant():
    empty_dict = {}
    set_constant("a", 2, empty_dict)
    assert empty_dict["a"] == 2
    set_constant("a", 3, empty_dict)
    assert empty_dict["a"] == 2

# Generated at 2022-06-20 13:48:06.360017
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test that method _DeprecatedSequenceConstant.__len__ is working correctly."""
    import sys
    sys.stderr = open('/dev/null', 'w')
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "", "")) == 3
    sys.stderr = sys.__stderr__

# Generated at 2022-06-20 13:48:09.205748
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3


# Generated at 2022-06-20 13:48:12.484201
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert hasattr(_DeprecatedSequenceConstant, '__iter__')
    assert hasattr(_DeprecatedSequenceConstant, '__len__')

# import Jinja2 now that we've done the config and constants
from ansible.template import Templar

# Generated at 2022-06-20 13:48:13.668280
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(CONNECTION_PLUGIN_PATH) == 2


# Generated at 2022-06-20 13:48:21.163503
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant(list("abc"), "message", "version")
    assert t[0] == "a"
    assert t[1] == "b"
    assert t[2] == "c"


# Generated at 2022-06-20 13:48:44.174648
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # pylint: disable=undefined-variable
    # Unit test for constructor of class _DeprecatedSequenceConstant
    # Create an instance of class _DeprecatedSequenceConstant
    msg = 'This key has been deprecated.'
    version = '2.8'
    sequence_constant = _DeprecatedSequenceConstant(['1', '2', '3'], msg, version)
    assert sequence_constant._value == ['1', '2', '3']
    assert sequence_constant._msg == msg
    assert sequence_constant._version == version
    # pylint: enable=undefined-variable

# Generated at 2022-06-20 13:48:46.975144
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'length', '2.0')
    assert 3 == len(c)


# Generated at 2022-06-20 13:48:50.061038
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant(
        value=[1, 2, 3], msg="This is a test", version="1.0")
    output = test_sequence.__len__()
    assert output == 3

# Generated at 2022-06-20 13:48:56.303203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import pytest
    sys.modules['__main__'].__builtins__._ansible_warnings = []
    c = _DeprecatedSequenceConstant((1,2,3,4,5), 'test warning', '2.9')
    assert c[1] == 2 # test expected behavior
    assert c[2] == 3 # test expected behavior
    assert 'test warning' in sys.modules['__main__'].__builtins__._ansible_warnings
    assert 'to be removed in 2.9' in sys.modules['__main__'].__builtins__._ansible_warnings
    del sys.modules['__main__'].__builtins__._ansible_warnings


# Generated at 2022-06-20 13:48:57.717048
# Unit test for function set_constant
def test_set_constant():

    assert display_skipped_hosts is True


# Generated at 2022-06-20 13:49:01.753592
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    data = {'name': 'John', 'surname': 'Doe'}
    dsc = _DeprecatedSequenceConstant(data, 'msg', 'version')
    print(dsc.__len__())



# Generated at 2022-06-20 13:49:03.927067
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar', export={})
    assert foo == 'bar'



# Generated at 2022-06-20 13:49:06.607838
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "Test", "0.0")
    assert len(dsc) == 3


# Generated at 2022-06-20 13:49:13.657581
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result = _DeprecatedSequenceConstant(['1', '2', '3'], 'test', '1.0')
    assert len(result) == len(['1', '2', '3'])
    assert result[0] == '1'

# Generated at 2022-06-20 13:49:16.021092
# Unit test for function set_constant
def test_set_constant():
    export = dict()
    set_constant('test', 'test', export)
    assert 'test' in export
    assert export['test'] == 'test'


# Generated at 2022-06-20 13:49:32.295027
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test'
    version = '2.0'
    test = _DeprecatedSequenceConstant(['test'], msg, version)
    assert isinstance(test, Sequence)
    assert len(test) is 1
    assert test[0] == 'test'


# Generated at 2022-06-20 13:49:37.352714
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None


DOCUMENT_SPEC = {
    'options': {
        'required': True,
        'allow_aliases': False
    },
    'notes': {},
}

TREE_IGNORE_FILES = IGNORE_FILES
TREE_IGNORE_EXT = REJECT_EXTS

# Internals for optional dependecy loading
_BECOME_LOADED = False
_CRYPT_LOADED = False
_SELINUX_LOADED = False

# Generated at 2022-06-20 13:49:40.474078
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    message = u"This is deprecated"
    version = u"2.9"
    dep_seq_const = _DeprecatedSequenceConstant([], message, version)
    assert len(dep_seq_const) == 0, "The sequence is not empty"

# Generated at 2022-06-20 13:49:54.018808
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_msg = "[TEST] test_msg"
    test_version = "test_version"
    test_value = ["TEST", "VALUE"]
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

# JOB_TIMEOUT is a special case as it was is calculated from a formula with
# other settings, but it is not a setting itself, so we need to add it here manually
if JOB_TIMEOUT < 4 * TIMEOUT:
    JOB_TIMEOUT = 4 * TIMEOUT

if DEFAULT_PLUGIN_PATH is None:
    # still None, has not been initialized
    base_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..'))
    DEFAULT_PLUGIN

# Generated at 2022-06-20 13:50:04.611002
# Unit test for function set_constant
def test_set_constant():
    dict_in = {}
    dict_in['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    dict_in['ANSIBLE_MODULE_COMPRESSION'] = 'bzip2'
    dict_in['ANSIBLE_MODULE_UDP_COMPRESSION'] = 'bzip2'
    dict_in['ANSIBLE_GATHERING'] = 'smart'
    dict_in['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    dict_in['ANSIBLE_HOST_KEY_CHECKING_STRICT'] = 'False'
    dict_in['ANSIBLE_INVENTORY'] = 'inventory'
    dict_in['ANSIBLE_LIBRARY'] = 'library'
    dict_in['ANSIBLE_MODULE_SETUP'] = 'True'

# Generated at 2022-06-20 13:50:07.281572
# Unit test for function set_constant
def test_set_constant():
    # 1. Should not raise an exception
    set_constant('test', 'test')

    # 2. Should set a constant
    set_constant('test2', 'test2')
    import __main__
    assert __main__.test2 == 'test2'


# Generated at 2022-06-20 13:50:13.062892
# Unit test for function set_constant
def test_set_constant():
    from collections import OrderedDict
    constants = OrderedDict([
        ('const1', 'default1'),
        ('const2', 'default2'),
        ('const3', 'default3'),
        ('const4', 'default4'),
        ('const5', 'default5'),
    ])
    export = {}
    for name, value in constants.items():
        set_constant(name, value, export)
    return export

# Generated at 2022-06-20 13:50:15.450464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_const = _DeprecatedSequenceConstant([1,2,3], 'Test Message', '2.10')
    assert len(seq_const) == 3
    assert seq_const[1] == 2

# Generated at 2022-06-20 13:50:18.745517
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # verify the constructor works correctly
    msg1 = 'Test message'
    version1 = 'Test version'
    value1 = []
    test_constant = _DeprecatedSequenceConstant(value1, msg1, version1)
    assert test_constant._msg == msg1
    assert test_constant._version == version1
    assert test_constant._value == value1

# Generated at 2022-06-20 13:50:21.642795
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '')[1] == 2


# Generated at 2022-06-20 13:50:36.850878
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(value=(1,), msg='foo', version='2.0')
    assert c[0] == 1

# Generated at 2022-06-20 13:50:45.141201
# Unit test for function set_constant
def test_set_constant():
    tmp_dict = {}
    set_constant('foo', 'bar', export=tmp_dict)
    assert tmp_dict['foo'] == 'bar'

# Make a few things that are used a lot more accessible
DEFAULT_HOST_LIST = HOST_LIST = DEFAULT_HOSTS = HOSTS = DEFAULT_SUBSET = SUBSET = DEFAULT_SUBSET
DEFAULT_MODULE_NAME = MODULE_NAME = DEFAULT_MODULE_PATH = MODULE_PATH = DEFAULT_MODULE_PATH
DEFAULT_PATTERN = PATTERN = DEFAULT_PATTERN
DEFAULT_FORKS = FORKS = DEFAULT_FORKS
DEFAULT_REMOTE_USER = REMOTE_USER = DEFAULT_REMOTE_USER
DEFAULT_REMOTE_PORT = REMOTE_PORT = DEFAULT_REMOTE_PORT

# Generated at 2022-06-20 13:50:50.073258
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1,2,3], '', '2.10').__getitem__(0) == 1
    assert _DeprecatedSequenceConstant([1,2,3], '', '2.10').__getitem__(1) == 2
    assert _DeprecatedSequenceConstant([1,2,3], '', '2.10').__getitem__(2) == 3

# Unit tests for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-20 13:51:00.236045
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert __test_constant__ == 'test_value'


# SECRET VARIABLE NAMES ###

# This is the list of variable names which are considered to
# contain secrets, as opposed to other sensitive data.
# By default, variable names matching any regular expression
# from this list will be censored when they would otherwise
# be logged.
SECRET_NAMES = (
    'password',
    'secret',
    'ssh_pass',
    'become_pass',
    'api_key',
    'access_key',
    'secret_key',
    'private_key',
)

# This is the regular expression which matches variable names
# which are encrypted with a vault.
# By default, any variable names matching this regular expression
# will not be considered

# Generated at 2022-06-20 13:51:01.549463
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list(), 'message', 'version')) == 0


# Generated at 2022-06-20 13:51:09.578132
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class A:
        pass
    a = A()
    a.x = "test"
    a.y = "test"
    a.z = "test"
    a.o = "test"
    test = _DeprecatedSequenceConstant(value=a, msg="test", version="test")
    assert test.__len__() == 4, test.__len__()
    assert test.__getitem__("x") == "test", test.__getitem__("x")
    assert test.__getitem__("y") == "test", test.__getitem__("y")
    assert test.__getitem__("z") == "test", test.__getitem__("z")
    assert test.__getitem__("o") == "test", test.__getitem__("o")
    assert test.__getitem

# Generated at 2022-06-20 13:51:13.797735
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        if setting.name not in ['DEFAULT_UNDEFINED_VAR_BEHAVIOR', 'DEFAULT_UNDEFINED_VAR_BEHAVIOUR']:
            assert value == config.get_config_value(setting.name)
        else:
            assert value is None

# prevent issues with deepcopy
MAGIC_VARIABLE_MAPPING.pop('become_pass', None)
MAGIC_VARIABLE_MAPPING['become_pass'] = ('ansible_become_password', 'ansible_become_pass')

# Generated at 2022-06-20 13:51:18.294495
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sample_sequence = [1, 2, 3, 4]
    sample_msg = 'sample message'
    sample_version = '2.8.0'

    deprecated_instance = _DeprecatedSequenceConstant(sample_sequence, sample_msg, sample_version)

    assert len(sample_sequence) == len(deprecated_instance)


# Generated at 2022-06-20 13:51:19.992235
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', test_dict)
    assert test_dict['foo'] == 'bar'

# Generated at 2022-06-20 13:51:21.863889
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test = _DeprecatedSequenceConstant(list(range(10, 15)), 'msg', 'version')
    assert len(test) == 5


# Generated at 2022-06-20 13:51:53.806222
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.0')

# Generated at 2022-06-20 13:51:57.202750
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg1', 'version1')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-20 13:51:58.371971
# Unit test for function set_constant
def test_set_constant():
    assert 'DEBUG' in vars()
    config.cleanup()



# Generated at 2022-06-20 13:52:00.503567
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(['first item'], 'this is a warning', '2.5')

    assert len(sequence) == 1


# Generated at 2022-06-20 13:52:07.578588
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_CONSTANT', 'ANSIBLE_CONSTANT2')
    assert ANSIBLE_CONSTANT == 'ANSIBLE_CONSTANT2'


# make a constant for the current version, but don't override user settings
set_constant('__version__', __version__, globals(), export=True)

__all__ = [
    'COMMON_CONNECTION_VARS',
    'INVALID_VARIABLE_NAMES',
    'MAGIC_VARIABLE_MAPPING',
    'MODULE_REQUIRE_ARGS',
    'MODULE_NO_JSON',
]

# Generated at 2022-06-20 13:52:14.961304
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = ['first', 'second', 'third', 'fourth']
    b = ['fifth', 'sixth', 'seventh', 'eighth']
    c = _DeprecatedSequenceConstant(a, "test_message", "0.1.0")
    assert c[2] == 'third'
    c = _DeprecatedSequenceConstant(a + b, "test_message", "0.1.0")
    assert c[4] == 'fourth'
    assert c[5] == 'fifth'


# Generated at 2022-06-20 13:52:17.053397
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert 'foo' in vars()


# Generated at 2022-06-20 13:52:19.879052
# Unit test for function set_constant
def test_set_constant():
    settings = dict()
    set_constant('a', 'b', settings)
    assert settings.get('a') == 'b'

    set_constant('a', 3, settings)
    assert settings.get('a') == 3

# Generated at 2022-06-20 13:52:26.343882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('one', 'two', 'three')
    msg = 'This is a test.'
    version = '2.9'
    constant = _DeprecatedSequenceConstant(value, msg, version)
    for i in value:
        assert i == constant[i]
    assert value[0] == constant[0]
    assert value[-1] == constant[-1]
    assert len(value) == len(constant)

# Generated at 2022-06-20 13:52:37.493743
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(tuple(add_internal_fqcns(('import_playbook', ))),
                                msg="the 'import_playbook' action is deprecated", version='2.12')
    _DeprecatedSequenceConstant(tuple(add_internal_fqcns(('import_role', ))),
                                msg="the 'import_role' action is deprecated", version='2.12')
    _DeprecatedSequenceConstant(tuple(add_internal_fqcns(('include_role', ))),
                                msg="the 'include_role' action is deprecated", version='2.12')