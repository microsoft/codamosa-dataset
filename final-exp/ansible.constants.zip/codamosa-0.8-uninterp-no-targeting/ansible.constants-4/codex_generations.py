

# Generated at 2022-06-20 13:43:45.500795
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len([1, 2, 3]) == len(c)


# Generated at 2022-06-20 13:43:49.471740
# Unit test for function set_constant
def test_set_constant():
    """ConfigManager: Test set_constant function
    """
    # Test export
    export = {}
    name = 'ANSIBLE_TEST_SET_CONSTANT'
    val = 'ANSIBLE_TEST_SET_CONSTANT_VALUE'
    set_constant(name, val, export)
    assert name in export
    assert export[name] == val



# Generated at 2022-06-20 13:43:58.155303
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io

    out = io.StringIO()
    sys.stdout = out

    original__stderr__write = sys.stderr.write

    def reset():
        sys.stdout = sys.__stdout__
        sys.stderr.write = original__stderr__write

    try:
        test = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version1")
        test[1]
        test[:2]
    finally:
        reset()
    result = out.getvalue().strip()
    assert result == '[DEPRECATED] msg, to be removed in version1'



# Generated at 2022-06-20 13:44:00.116697
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list_1 = [1, 2, 3]
    test_instance = _DeprecatedSequenceConstant(test_list_1, 'test warning', '2.10')
    assert len(test_instance) == 3



# Generated at 2022-06-20 13:44:04.355007
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(range(5), 'I am deprecated', '2.8')
    # Error: Bad index in call to __getitem__ of class _DeprecatedSequenceConstant
    seq[5]


# Generated at 2022-06-20 13:44:08.223818
# Unit test for function set_constant
def test_set_constant():
    # Test if the function can set a constant
    set_constant('constant', 'constant')
    assert vars()['constant'] == 'constant'
    # Test if the function is case sensitive
    set_constant('COnStaNt', 'constant')
    assert vars()['COnStaNt'] == 'constant'
    assert config.config.get_config_value('COnStaNt') == 'constant'



# Generated at 2022-06-20 13:44:10.177386
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_constant = _DeprecatedSequenceConstant(range(10), "Test message", "2.0")
    assert seq_constant[-1] == 9
    assert seq_constant[4:7] == [4, 5, 6]

# Generated at 2022-06-20 13:44:13.718615
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1,2,3], 'Something is deprecated', '2.8')
    assert seq[1] == 2


# Generated at 2022-06-20 13:44:19.463839
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3, 4], 'this is a deprecated list', '2.0')
    _DeprecatedSequenceConstant({'key1': 'val1', 'key2': 'val2'}, 'this is a deprecated dict', '2.0')
    _DeprecatedSequenceConstant(('a', 'b', 'c', 'd'), 'this is a deprecated tuple', '2.0')


# Generated at 2022-06-20 13:44:21.411679
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.0')
    assert len(a) == 3


# Generated at 2022-06-20 13:44:35.226099
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(value=['a', 'b'], msg='test', version='test')
    assert obj[0] == 'a'
    assert obj[1] == 'b'


# Generated at 2022-06-20 13:44:41.786237
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.11')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.11')[-1] == 3

# Generated at 2022-06-20 13:44:45.655717
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(["a", "b", "c"], "msg", "version")
    assert len(c) == 3
    assert c[0] == "a"

# Generated at 2022-06-20 13:44:51.416893
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    options = {'ANISIBLE_SSH_PIPELINING': 'False', 'ANSIBLE_SSH_PIPELINING': 'foo'}
    manager = ConfigManager(options, None)
    manager.parse_configuration_file()
    for warn in manager.WARNINGS:
        _warning(warn)

    assert len(MAGIC_VARIABLE_MAPPING['pipelining']) == 2



# Generated at 2022-06-20 13:44:53.389314
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'bar')
    assert len(a) == 3

# Generated at 2022-06-20 13:45:06.457188
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # initialization of _DeprecatedSequenceConstant
    test_obj1 = _DeprecatedSequenceConstant([5, 2, 3], "test1_msg", "test1_version")
    test_obj2 = _DeprecatedSequenceConstant("test_string", "test2_msg", "test2_version")
    assert test_obj1._msg == "test1_msg"
    assert test_obj2._version == "test2_version"
    assert test_obj1._value == [5, 2, 3]
    assert test_obj2._value == "test_string"
    # test getitem
    assert test_obj1._value[0] == 5
    assert test_obj2._value[2] == "i"
    # test len
    assert len(test_obj1) == 3

# Generated at 2022-06-20 13:45:15.630583
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import types
    import pytest
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(HostVars({}), use_cache=False)

    value = ['foobar']
    msg = u'This is a deprecated test message.'
    version = u'2.8'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'foobar'


# Generated at 2022-06-20 13:45:19.439706
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant((True, True), 'foo', '2.4')

    assert len(a) == 2
    assert a[0]

# Generated at 2022-06-20 13:45:25.341358
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_VAULT_PASSWORD_FILE' in locals()
    set_constant('TEST_CONSTANT', 'TEST_CONSTANT_VALUE')
    assert vars()['TEST_CONSTANT'] == 'TEST_CONSTANT_VALUE'
    del vars()['TEST_CONSTANT']

# Generated at 2022-06-20 13:45:29.868432
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-20 13:45:47.393928
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant((1, 2, 3), 'This is a test message', '3.0')
    assert(test[0] == 1)
    assert(test[1] == 2)
    assert(test[2] == 3)
    assert(len(test) == 3)

# Generated at 2022-06-20 13:45:55.696913
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import is_sequence

    obj = _DeprecatedSequenceConstant("abc", "message", "version")
    if is_sequence(obj):
        if len(obj) != len("abc"):
            raise AssertionError("Test of method __len__ of class _DeprecatedSequenceConstant failed")
    else:
        raise AssertionError("Test of method __len__ of class _DeprecatedSequenceConstant failed")

# Generated at 2022-06-20 13:45:58.642339
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert sequence_constant[0] == 1
    assert sequence_constant[1] == 2
    assert sequence_constant[2] == 3

# Generated at 2022-06-20 13:46:06.800456
# Unit test for function set_constant
def test_set_constant():
    """Confirm the constant being set correctly"""
    constant_name = 'ansible_test_function'
    value = 'success'
    set_constant(constant_name, value)
    assert constant_name in globals()
    assert globals()[constant_name] == value

# DEPRECATED, remove in 2.10
# the magic variable mapping dictionary below is used to
# translate host/inventory variables to fields in the PlayContext
# object. The dictionary values are tuples, to account for aliases
# in variable names.

# Generated at 2022-06-20 13:46:08.517991
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant(range(3), 'This is just a test', '0.1')
    assert test_sequence[0] == 0
    assert test_sequence[1] == 1
    assert test_sequence[2] == 2

# Generated at 2022-06-20 13:46:09.880916
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_options = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert deprecated_options[0] == 1


# Generated at 2022-06-20 13:46:14.395322
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "The config option `some_setting` is deprecated"
    deprecated_seq = _DeprecatedSequenceConstant([1, 2, 3], msg, "2.10")
    assert deprecated_seq[1] == 2



# Generated at 2022-06-20 13:46:18.386508
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg='this is a message', version='0.6')[0] == 1

# Generated at 2022-06-20 13:46:24.271742
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from collections import UserList

    # _DeprecatedSequenceConstant extends Sequence, which extends UserList
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', '1.0')
    assert isinstance(dsc, _DeprecatedSequenceConstant)
    assert isinstance(dsc, Sequence)
    assert isinstance(dsc, UserList)
    assert dsc == dsc._value


del config
del set_constant

# Generated at 2022-06-20 13:46:31.183975
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant(['a', 'b'], 'Test warning', '2.12')
    assert len(test_obj) == 2
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'


# Basic sanity test for setting debug to a non-falsy value
# as a string and bool with a warning message

# Generated at 2022-06-20 13:47:14.451785
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(1, 'msg', 'version')
    assert a._value == 1 and a._msg == 'msg' and a._version == 'version'

# Generated at 2022-06-20 13:47:18.400794
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    invalid_values = [None, [], {}, 1]
    for value in invalid_values:
        try:
            _DeprecatedSequenceConstant(value, 'message', 'version')
            raise AssertionError(
                "Invalid value {0} should raise "
                "TypeError".format(value))
        except TypeError:
            pass
    valid_value = [1, 2, 3]
    _DeprecatedSequenceConstant(valid_value, 'message', 'version')

# Generated at 2022-06-20 13:47:20.759755
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert obj[0] == 1


# Generated at 2022-06-20 13:47:27.182032
# Unit test for function set_constant
def test_set_constant():
    # define the constant
    test_constant = "test"

    # check that the constant is not set yet
    assert not test_constant

    # set the constant
    set_constant("test_constant", test_constant)

    # check that the constant is set
    assert globals()[test_constant] == test_constant

# Generated at 2022-06-20 13:47:30.013784
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 'a', 'b'], 'msg', 'version')
    assert deprecated_sequence_constant[2] == 'a'


# Generated at 2022-06-20 13:47:33.353188
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testlist = [1, 2, 3]
    test_dpc = _DeprecatedSequenceConstant(testlist, "Warning", "2.0")
    assert len(test_dpc) == 3


# Generated at 2022-06-20 13:47:35.912029
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant('val', 'msg', 'ver')
    assert dsc[0] == 'v'


# Generated at 2022-06-20 13:47:43.569283
# Unit test for function set_constant
def test_set_constant():
    def test_export(export):
        assert export['test'] == 'test_value'

    set_constant("test", "test_value", export=test_export)

# DEFAULT PRIVATE METHODS ###

# This is a private copy of boolean() that is used by
# env_fallback() to check if an env value is a string
# boolean.  These functions do not use the built-in
# boolean() to avoid recursion.
_BOOLEAN_TRUE_STRINGS = ("True", "true", "1")
_BOOLEAN_FALSE_STRINGS = ("False", "false", "0")



# Generated at 2022-06-20 13:47:45.770627
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant((1, 2, 3), 'Test msg', '1.9')
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert len(obj) == 3

# Generated at 2022-06-20 13:47:55.043373
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(
        value=[{"msg": "a", "version": "1.2"}, {"msg": "b", "version": "3.4"}],
        msg="",
        version=""
    )[0]["msg"] == "a"
    assert _DeprecatedSequenceConstant(
        value=[{"msg": "a", "version": "1.2"}, {"msg": "b", "version": "3.4"}],
        msg="",
        version=""
    )[-1]["msg"] == "b"


# Generated at 2022-06-20 13:49:10.342794
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant('foobar', msg='test message', version='1.0')
    assert len(dsc) == 6


# Generated at 2022-06-20 13:49:17.917201
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Object(object):
        def __init__(self):
            self._value = 0
            self._msg = ''
            self._version = ''
        def __len__(self):
            self._value += 1
            return self._value
    obj = Object()
    deprecated_obj = _DeprecatedSequenceConstant(obj, 'test', '2.0')
    assert len(deprecated_obj) == 1
    assert len(deprecated_obj) == 2
    assert len(deprecated_obj) == 3


# Generated at 2022-06-20 13:49:25.079871
# Unit test for function set_constant
def test_set_constant():
    set_constant("ANSIBLE_TEST_CONSTANT", True)
    assert ANSIBLE_TEST_CONSTANT is True
    set_constant("ANSIBLE_TEST_CONSTANT", False)
    assert ANSIBLE_TEST_CONSTANT is False


# TODO: remove once play_context mangling is removed
# backport magic_variable_mapping to Ansible 2.4 for older playbooks
for v, aliases in MAGIC_VARIABLE_MAPPING.items():
    for alias in aliases:
        MAGIC_VARIABLE_MAPPING[alias] = v

# backport _DeprecatedSequenceConstant to Ansible 2.4 for older playbooks

# Generated at 2022-06-20 13:49:31.886044
# Unit test for function set_constant
def test_set_constant():
    assert 'foobar' == set_constant('foobar', 'foobar')
    assert 10 == set_constant('foobar', 10)
    assert 10.1 == set_constant('foobar', 10.1)
    assert None == set_constant('foobar', None)


# Generated at 2022-06-20 13:49:34.918100
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'msg'
    version = 'version'
    value = 'value'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]


# Generated at 2022-06-20 13:49:38.482212
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = ['a', 'b', 'c']
    deprecated_sequence = _DeprecatedSequenceConstant(sequence, '', '')
    assert len(sequence) == len(deprecated_sequence)



# Generated at 2022-06-20 13:49:50.597635
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''Unit test for method __len__ of class _DeprecatedSequenceConstant
       Test case for empty list
       Expected: returns 0
    '''
    assert len(_DeprecatedSequenceConstant(value=[], msg='Message', version='1.2')) == 0

    '''Test case for non empty list
       Expected: returns 4 
    '''
    assert len(_DeprecatedSequenceConstant(value=['foo', 'bar', 'gate', 'monkey'], msg='Message', version='1.2')) == 4


# Generated at 2022-06-20 13:49:54.512806
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], "SO COOL. I'm a deprecated Sequence", '2.0')
    assert len(x) == 3
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3

# Generated at 2022-06-20 13:49:56.964519
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'ver')
    assert len(dsc) == 2

# Generated at 2022-06-20 13:50:06.603235
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import os
    import re

    def test_value(v):
        from ansible.module_utils.six import StringIO

        msg = "Test message"
        version = "Test version"
        seq = _DeprecatedSequenceConstant(v, msg, version)

        fd = StringIO()
        with os.dup(sys.stderr.fileno()):
            os.dup2(fd, sys.stderr.fileno())
            l = len(seq)
            os.dup2(sys.stderr.fileno(), sys.stderr.fileno())

        res = fd.getvalue()
        assert re.match("^ \[DEPRECATED\] %s, to be removed in %s\n$" % (msg, version), res)

        fd = StringIO()
       

# Generated at 2022-06-20 13:51:36.262372
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 1



# Generated at 2022-06-20 13:51:37.157287
# Unit test for function set_constant
def test_set_constant():
    assert pattern_type == 'regex'

# Generated at 2022-06-20 13:51:43.494459
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_sequence_constant_value = 'test_sequence_constant_value'
    test_sequence_constant_msg = 'test_sequence_constant_msg'
    test_sequence_constant_version = 'test_sequence_constant_version'
    test_sequence_constant = _DeprecatedSequenceConstant(test_sequence_constant_value, test_sequence_constant_msg, test_sequence_constant_version)
    assert len(test_sequence_constant) == len(test_sequence_constant_value)
    for test_sequence_constant_index in range(len(test_sequence_constant_value)):
        assert test_sequence_constant[test_sequence_constant_index] == test_sequence_constant_value[test_sequence_constant_index]

# Generated at 2022-06-20 13:51:46.324449
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('constant_test', True) == None
    constant_test_value = True

    assert eval('global constant_test_value; constant_test_value') == True


# Generated at 2022-06-20 13:51:50.524351
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1, 2, 3]
    msg = 'This is a deprecated value and will be removed.'
    version = '2.9'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 1


# Generated at 2022-06-20 13:51:54.210753
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('TEST_CONSTANT', 'TEST_VALUE', export=test_dict)
    assert test_dict['TEST_CONSTANT'] == 'TEST_VALUE'


# Generated at 2022-06-20 13:52:03.051700
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(["foo"], "test message", "2.9")
    assert len(obj) == 1
    assert obj[0] == "foo"

# NOTE: the PluginManager uses this
ALL_PLUGIN_TYPES = (
    'action_plugin',
    'become_plugin',
    'cache_plugin',
    'callback_plugin',
    'cliconf_plugin',
    'connection_plugin',
    'filter_plugin',
    'httpapi_plugin',
    'inventory_plugin',
    'lookup_plugin',
    'netconf_plugin',
    'shell_plugin',
    'strategy_plugin',
    'terminal_plugin',
    'vars_plugin',
)

# Generated at 2022-06-20 13:52:07.792234
# Unit test for function set_constant
def test_set_constant():

    def check_value(name, value):
        """ helper function to return dict value """
        try:
            return(vars()[name])
        except KeyError:
            raise AssertionError('expected %s to be defined in vars' % name)

    set_constant('test_constant', 'test_value')
    assert check_value('test_constant', 'test_value') == 'test_value'


# Generated at 2022-06-20 13:52:10.430989
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # No exception raised
    test = _DeprecatedSequenceConstant((), '', '')
    assert isinstance(test, Sequence)

# Generated at 2022-06-20 13:52:17.134539
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    env_val = set(['AAA', 'BBB', 'CCC'])
    msg = 'msg'
    version = 'version'

    dep_env_val = _DeprecatedSequenceConstant(env_val, msg, version)

    # Test method __len__
    assert len(env_val) == len(dep_env_val)
    assert len(env_val) == 3
    assert len(dep_env_val) == 3
