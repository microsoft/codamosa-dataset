

# Generated at 2022-06-20 13:43:47.077205
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    current_version = "2.9"
    msg = "you used something."
    sequence = ['ansible.executor.task_result', ]
    test_object = _DeprecatedSequenceConstant(sequence, msg, current_version)
    assert test_object.__getitem__(0) == 'ansible.executor.task_result'


# Generated at 2022-06-20 13:43:49.782514
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    warn_msg = "test warning"
    version = __version__
    seq = _DeprecatedSequenceConstant([], warn_msg, version)
    len(seq)
    seq[0]



# Generated at 2022-06-20 13:43:52.187907
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_class = _DeprecatedSequenceConstant(['test'], 'test msg', 'test version')
    assert len(test_class) == 1

# Generated at 2022-06-20 13:43:56.923176
# Unit test for function set_constant
def test_set_constant():
    ''' test for set_constant '''
    test_var = 'the_test_var'
    test_val = 'the_test_val'
    set_constant(test_var, test_val, vars())
    assert test_var in vars()
    assert vars()[test_var] == test_val

# Generated at 2022-06-20 13:44:07.804577
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    for obj in [_DeprecatedSequenceConstant([], 'test', '1.0'),
                _DeprecatedSequenceConstant([], 'test', '1.0'),
                _DeprecatedSequenceConstant(set(), 'test', '1.0'),
                _DeprecatedSequenceConstant(tuple(), 'test', '1.0'),
                _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0'),
                _DeprecatedSequenceConstant('test', 'test', '1.0')]:
        assert len(obj) == 0
        for _ in obj:
            pass


if __name__ == '__main__':
    for constant in [x for x in vars() if x.isupper()]:
        print(constant)

# Generated at 2022-06-20 13:44:11.055479
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(tuple(), 'test message', '2.0')
    return len(dsc) == 0



# Generated at 2022-06-20 13:44:17.515469
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Python 2
    d = _DeprecatedSequenceConstant(('a', 'b', 'c', 'd'), 'message', '1.2.3')
    assert len(d) == 4

    # Python 3
    d = _DeprecatedSequenceConstant(('a', 'b', 'c', 'd'), 'message', '1.2.3')
    assert len(d) == 4


# Generated at 2022-06-20 13:44:20.190130
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    lst = []
    for item in _DeprecatedSequenceConstant(list(range(10)), 'message', '2.9'):
        lst.append(item)
    assert lst == list(range(10))



# Generated at 2022-06-20 13:44:31.188041
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    coll = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'a message', '1.6')
    assert len(coll) == 3
    assert coll[0] == 'a'
    assert coll[1] == 'b'
    assert coll[2] == 'c'
    assert coll[3] == 3
    assert coll[-1] == 'c'

__all__ = sorted(name for name in dir() if not name.startswith('_') and not callable(getattr(__name__, name)))
__all__ = tuple(sorted(__all__ + ['COLOR_CODES']))

# Generated at 2022-06-20 13:44:34.713810
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3,4], "test", "2.9")) == 4


# Generated at 2022-06-20 13:44:41.299419
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant([0, 1, 2], msg='some warning', version='1.0.0')[0]  # does not fail

# Generated at 2022-06-20 13:44:46.034201
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_test = ['ansible', 'ansible-inventory']
    obj = _DeprecatedSequenceConstant(list_test, 'this is a test', '3.0')
    assert len(obj) == 2


# Generated at 2022-06-20 13:44:50.187225
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant([1, 2, 3], "some message", "some version")
    assert value == [1, 2, 3]
    assert len(value) == 3
    assert value[0] == 1
    assert value[2] == 3


# Generated at 2022-06-20 13:44:54.338046
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    set_constant("M_TEST_DEPRECATED", (1, 2, 3))
    assert M_TEST_DEPRECATED[0] == 1
    assert M_TEST_DEPRECATED[1] == 2
    assert M_TEST_DEPRECATED[2] == 3


# Generated at 2022-06-20 13:44:56.499067
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = _DeprecatedSequenceConstant(('hello', 'world'), msg='this is a deprecation message', version='2.0')
    assert 2 == len(test_seq)


# Generated at 2022-06-20 13:45:03.837326
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="0.0.0")[0] == 1
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="0.0.0")[1] == 2
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="0.0.0")[2] == 3


# Generated at 2022-06-20 13:45:08.009631
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', export=test_dict)
    set_constant('bam', 'baz', export=test_dict)
    assert test_dict['foo'] == 'bar'
    assert test_dict['bam'] == 'baz'

# Generated at 2022-06-20 13:45:10.583810
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(['1', '2'], 'msg', 'ver')
    assert len(seq) == 2


# Generated at 2022-06-20 13:45:15.653032
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import warnings
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        obj = _DeprecatedSequenceConstant(['one', 'two', 'three'], 'This is a test.', '2.13')
        assert obj[0] == 'one'
        assert obj[1] == 'two'
        assert obj[2] == 'three'
        assert len(w) == 3
        assert w[0].message.args[0] == 'This is a test.'
        assert w[0].message.version == '2.13'


# Generated at 2022-06-20 13:45:27.693245
# Unit test for function set_constant
def test_set_constant():
    import os.path
    import shutil
    import tempfile
    import unittest
    from ansible import constants

    class TestSetConstant(unittest.TestCase):
        """ Unit test class for testing set_constant function.
        """
        def setUp(self):
            # Create test config
            self.test_config_dir = tempfile.mkdtemp()
            self.test_config_path = os.path.join(self.test_config_dir, 'test.cfg')
            test_config = u'[defaults]\ntest_config=test\n'
            with open(self.test_config_path, 'w') as f:
                f.write(test_config)

            # Store default configuration file paths
            self.cwd = os.path.abspath('.')
            self

# Generated at 2022-06-20 13:45:37.515296
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a test message'
    version = '2.0.0'
    value = ['t1', 't2', 't3']
    # Create test object
    d_c = _DeprecatedSequenceConstant(value, msg, version)
    assert d_c[2] == value[2]


# Generated at 2022-06-20 13:45:39.479288
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'warning', '3.0')) == 3

# Generated at 2022-06-20 13:45:42.663211
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(['read', 'write', 'execute'], 'This is a deprecated warning message.', '3.0.0')
    assert len(sequence) == 3

# Generated at 2022-06-20 13:45:46.050219
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    foo = _DeprecatedSequenceConstant(['foo', 'bar'], "warning message", "version")
    assert foo[0] == 'foo'
    assert foo[1] == 'bar'
    try:
        assert foo[2]
    except IndexError:
        pass

# Generated at 2022-06-20 13:45:49.279069
# Unit test for function set_constant
def test_set_constant():
    """Function to unit test function set_constant"""
    set_constant('TEST_FOO', 'foo')
    assert TEST_FOO == 'foo'

    set_constant('TEST_BAR', 'bar')
    assert TEST_BAR == 'bar'

# Generated at 2022-06-20 13:45:59.974301
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', export=test_dict)
    assert 'foo' in test_dict
    # check to see if the function actually sets the variable
    assert test_dict['foo'] == bar

# -----

# INTROSPECTION SPECIFIC SETTINGS ###

INTROSPECTION_IGNORE_VARS = {
    'ansible_module_generated',
    'ansible_facts_module_name',
    'ansible_facts_module_version',
    'ansible_version',
    # TODO: remove from here and add to introspection_files
    'ansible_env',
    'ansible_system_capabilities',
    'ansible_facts',
}

# FIXME: the following should be auto-generated
#        create a new combined constants type


# Generated at 2022-06-20 13:46:06.985830
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    correct_value = []
    correct_msg = "This message is correct"
    correct_version = "2.9"
    wrong_value = "This is not a list"
    wrong_msg = []
    wrong_version = ""
    test_obj = _DeprecatedSequenceConstant(correct_value, correct_msg, correct_version)
    assert test_obj._value == correct_value
    assert test_obj._msg == correct_msg
    assert test_obj._version == correct_version

    # will throw exception for this function, because value is not a list
    with pytest.raises(Exception):
        _DeprecatedSequenceConstant(wrong_value, correct_msg, correct_version)


# Generated at 2022-06-20 13:46:08.537577
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant((1, 2, 3), "test", 1.0)
    assert test[0] == 1
    assert test[1] == 2
    assert test[2] == 3

# Generated at 2022-06-20 13:46:11.131089
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_array = ["test1", "test2"]
    test_msg = "This is a test."
    test_version = "2.3"
    test_wrapper = _DeprecatedSequenceConstant(test_array, test_msg, test_version)
    return test_wrapper[0] == "test1"

# Generated at 2022-06-20 13:46:16.565818
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant(['/tmp/foo'], 'Deprecation warning', '2.0')

    assert s[0] == '/tmp/foo', 'Expected /tmp/foo, got: %s' % s
    assert len(s) == 1, 'Expected len of 1, got: %s' % len(s)

# Generated at 2022-06-20 13:46:29.811125
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2], "TestMsg", "1.0")
    assert len(x) == 2
    assert x[0] == 1
    assert x[1] == 2

# Generated at 2022-06-20 13:46:32.886164
# Unit test for function set_constant
def test_set_constant():
    '''
    >>> test_vars = {}
    >>> set_constant('FOO', 'bar', test_vars)
    >>> test_vars['FOO']
    'bar'

    >>> try:
    ...    set_constant('FOO', 'baz', test_vars)
    ... except RuntimeError as e:
    ...     print(e)  # doctest: +ELLIPSIS
    dict already has key 'FOO' ...
    '''

# Generated at 2022-06-20 13:46:36.529821
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant = _DeprecatedSequenceConstant(value=('a', 'b'), msg='The constant is deprecated', version='2.0')
    assert deprecated_constant == ('a', 'b')
    assert len(deprecated_constant) == 2

# Generated at 2022-06-20 13:46:39.334256
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test', '2.0')
    assert test_obj.__len__() == 4
    assert test_obj.__getitem__(1) == 2

# Generated at 2022-06-20 13:46:42.170592
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        if setting.origin != 'default':
            continue
        assert globals()[setting.name] == setting.value
        # TODO: test for templatability

# Generated at 2022-06-20 13:46:54.354352
# Unit test for function set_constant
def test_set_constant():
    import sys
    import os

    # Initialize
    constants = {}

    # Setting a constant
    set_constant('TEST_CONSTANT', 'Constants can be set using this function', constants)

    # Assert it was set correctly
    if sys.version_info[0] == 3:
        assert constants['TEST_CONSTANT'] == 'Constants can be set using this function', \
            "set_constant() was not setting constants correctly"
    else:
        assert constants['TEST_CONSTANT'] == u'Constants can be set using this function', \
            "set_constant() was not setting constants correctly"

    # Unset the TEST_CONSTANT
    if 'TEST_CONSTANT' in constants:
        del constants['TEST_CONSTANT']



# Generated at 2022-06-20 13:47:00.049783
# Unit test for function set_constant
def test_set_constant():
    import ansible.config.settings as settings
    set_constant('TEST_CONSTANT', 'test')
    assert settings.TEST_CONSTANT == 'test'

# Generated at 2022-06-20 13:47:05.501338
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="Testing the constructor of _DeprecatedSequenceConstant class", version=__version__)
    assert len(dsc_obj) == 3
    assert dsc_obj[2] == 3

# Generated at 2022-06-20 13:47:17.259054
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('DEFAULT_KEEP_REMOTE_FILES', True)
        assert DEFAULT_KEEP_REMOTE_FILES == True
    except NameError:
        raise RuntimeError("set_constant function failed")

test_set_constant()

# Determine generic constants
TREE_DIR = config.get_config_value('DEFAULT_ROLES_PATH', missing_value=None)

# Default subdir of ~/.ansible to place temporary files for inventory, fact gathering, and caching
CACHE_PLUGIN_FILENAME = config.get_cache_plugin_options()['CACHE_PLUGIN_FILENAME']

# Default directory (relative to the playbook root) containing roles to be applied to the playbook run
DEFAULT_ROLES_PATH = config.get_config_

# Generated at 2022-06-20 13:47:21.932352
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3, 4], "msg", "1.3")
    assert dsc[0] == 1


# Generated at 2022-06-20 13:47:53.566372
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert s[0] == 'v'
    assert len(s) == 5
    # check unicode output from deprecated call
    assert isinstance(s[0], to_text)
    assert isinstance(len(s), int)
    assert isinstance(s, Sequence)
    assert not isinstance(s, tuple)
    assert not isinstance(s, str)

# Generated at 2022-06-20 13:47:57.045692
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for x, y in ((0, range(1, 4)), (1, range(4, 7)), (2, range(7, 10)), (3, range(10, 13))):
        assert len(_DeprecatedSequenceConstant(y, "msg", "version")) == x

# Generated at 2022-06-20 13:48:10.514580
# Unit test for function set_constant
def test_set_constant():
    def my_function():
        pass

    set_constant('MY_NAME', 'foo')
    set_constant('MY_INTEGER', 42)
    set_constant('MY_FLOAT', 42.42)
    set_constant('MY_DICTIONARY', {'foo': 'bar'})
    set_constant('MY_LIST', ['foo', 'bar'])
    set_constant('MY_TUPLE', ('foo', 'bar'))
    set_constant('MY_SET', set(['foo', 'bar']))
    set_constant('MY_BOOLEAN_TRUE', True)
    set_constant('MY_BOOLEAN_FALSE', False)
    set_constant('MY_FUNCTION', my_function)


# Generated at 2022-06-20 13:48:17.807048
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        from ansible.utils.display import Display
    except Exception:
        import sys
        sys.stderr.write(' [WARNING] %s\n' % ('test__DeprecatedSequenceConstant depends on Display, which is not available.'))
        return

    from io import StringIO
    buf = StringIO()
    Display.verbosity = 3
    Display.stderr = buf
    d = _DeprecatedSequenceConstant([], 'msg1', '2.9')
    len(d)
    buf.seek(0)
    assert buf.read() == '[DEPRECATED] msg1, to be removed in 2.9\n'
    d = _DeprecatedSequenceConstant(d, 'msg2', '3.0')
    len(d)
    buf.seek(0)

# Generated at 2022-06-20 13:48:21.224470
# Unit test for function set_constant
def test_set_constant():
    assert len(host_record_as_dict) == 3
    for key in host_record_as_dict:
        assert key in ('host', 'port', 'user')

# Generated at 2022-06-20 13:48:26.738454
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ['a', 'b', 'c']
    msg = 'test msg'
    version = 'test version'
    ds = _DeprecatedSequenceConstant(value, msg, version)
    assert ds[1] == 'b'

test__DeprecatedSequenceConstant___getitem__()


# Generated at 2022-06-20 13:48:30.837727
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert 'TEST_CONSTANT' in globals()
    assert globals()['TEST_CONSTANT'] == 'test_value'
    assert TEST_CONSTANT == 'test_value'


# Generated at 2022-06-20 13:48:33.182330
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'Test_Constant_Value')
    assert TEST_CONSTANT == 'Test_Constant_Value'


# Generated at 2022-06-20 13:48:38.637460
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from nose.tools import assert_removed
    from ansible.constants import _DeprecatedSequenceConstant
    set_constant('__DEPRECATED_IN_VERSION__', '1.8.0')
    x = _DeprecatedSequenceConstant(list(range(0, 100)), 'a' * 200, __DEPRECATED_IN_VERSION__)
    with assert_removed(deprecated_in='1.8.0'):
        x.__len__()


# Generated at 2022-06-20 13:48:40.327770
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], None, None)) == 0
    assert len(_DeprecatedSequenceConstant((0,), None, None)) == 1
    assert len(_DeprecatedSequenceConstant(['a','b','c'], None, None)) == 3



# Generated at 2022-06-20 13:49:39.348133
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'

if __version__.startswith('1.'):
    _deprecated('The configuration setting `strategy` is replaced by `strategy_plugins`.  Please update your configuration files to use the new setting.  '
                'The 1.x strategy setting will be removed in Ansible 2.9', 'Ansible 2.9')
    STRATEGY_PLUGINS = ensure_type(STRATEGY_PLUGINS, list) + ensure_type(STRATEGY, list)

STRATEGY_PLUGINS = ensure_type(STRATEGY_PLUGINS, list)

# Generated at 2022-06-20 13:49:42.050593
# Unit test for function set_constant
def test_set_constant():
    """Function testset_constant"""
    test_dict = {}
    set_constant('test_test_test', "value", test_dict)
    assert 'test_test_test' in test_dict and test_dict['test_test_test'] == "value"

# Generated at 2022-06-20 13:49:47.800518
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = 'value'

    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant.__getitem__(0) == value


# Generated at 2022-06-20 13:49:49.495457
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant([], 'msg', 'version')


# Generated at 2022-06-20 13:49:51.803967
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    tmp_value = ('foo', 'bar')
    tmp_msg = 'value'
    tmp_version = '1.0'
    tmp_deprecated = _DeprecatedSequenceConstant(tmp_value, tmp_msg, tmp_version)

    assert len(tmp_deprecated) == len(tmp_value)


# Generated at 2022-06-20 13:49:57.268831
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ('value1', 'value2', 'value3')
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    for index, value in enumerate(test_value):
        assert value == test_object[index]

# Generated at 2022-06-20 13:49:59.674909
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2], 'test', 'version')
    assert len(a) == 2


# Generated at 2022-06-20 13:50:02.093917
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(['test'], 'test message', 'test version')
    assert len(c) == 1

# Generated at 2022-06-20 13:50:04.736496
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant((0, 1, 2), 'a', 'b')
    assert x[0] == 0
    assert x[1] == 1
    assert x[2] == 2

# Generated at 2022-06-20 13:50:10.170011
# Unit test for function set_constant
def test_set_constant():
    # Test with long values
    long_value = 'a' * 1000
    set_constant('long_constant', long_value, export=vars())
    assert long_value == long_constant

    # Test with bool value
    bool_value = True
    set_constant('bool_constant', bool_value, export=vars())
    assert bool_value == bool_constant

    # Test with int value
    int_value = 7
    set_constant('int_constant', int_value, export=vars())
    assert int_value == int_constant

    # Test with dict
    dict_value = dict({'a': 'b'})
    set_constant('dict_constant', dict_value, export=vars())
    assert dict_value == dict_constant

    # Test with

# Generated at 2022-06-20 13:52:04.163730
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    import warnings
    import sys

    class WarnCaller(object):
        def __call__(self, *args, **kwargs):
            pass

    class ModuleUtils(object):
        def __init__(self):
            self.warn = WarnCaller()

    class Display(object):
        def __init__(self):
            self.MODULE_UTILS = ModuleUtils()

        def deprecated(self, msg, version=None):
            pass

    sys.modules['ansible.utils.display'] = Display()

    value = ['test1', 'test2']
    msg = 'test'
    version = '0.0.1'

    c = _DeprecatedSequenceConstant(value, msg, version)

    # test if the _DeprecatedSequ

# Generated at 2022-06-20 13:52:11.156607
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.collection_loader import _DeprecatedSequenceConstant
    import unittest

    class TestDeprecatedSequenceConstant(unittest.TestCase):
        def test__DeprecatedSequenceConstant(self):
            mock_value = [1, 2, 3]
            mock_msg = 'warn message'
            mock_version = 'version'
            mock_class = _DeprecatedSequenceConstant(mock_value, mock_msg, mock_version)
            self.assertEqual(len(mock_class), len(mock_value))
            self.assertEqual(mock_class[0], mock_value[0])

    unittest.main(verbosity=2)

# Generated at 2022-06-20 13:52:15.403554
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([], '', '')
    assert len(dsc) == 0

    dsc = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(dsc) == 3



# Generated at 2022-06-20 13:52:22.951392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Setup
    value = ['apple', 'banana', 'cat']
    msg = 'This is a test'
    version = '2.8'
    obj = _DeprecatedSequenceConstant(value, msg, version)
    expected_result = 'apple'

    # Test
    result = obj.__getitem__(0)

    # Verify
    assert result == expected_result

__all__ = tuple(name for name, value in locals().items() if not name.startswith('_'))

# Add internal fqcns to the import globals for back-compat
# There is a potential for collisions here.  We are assuming that there is only one constant with a given name
add_internal_fqcns(locals())

# Generated at 2022-06-20 13:52:26.303524
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    with pytest.raises(DeprecationWarning):
        len(_DeprecatedSequenceConstant(value=[1], msg='test', version='2.0'))

# Generated at 2022-06-20 13:52:28.223313
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant('foo', 'msg', 'version')
    assert len(obj) == 3

# Generated at 2022-06-20 13:52:32.434374
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'this is my warning', 'v2.10')
    assert test[2] == 'c'
    assert test[0] == 'a'
    assert len(test) == 3

# Generated at 2022-06-20 13:52:34.105348
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANOTHER_TEST', 123)
    assert ANOTHER_TEST == 123



# Generated at 2022-06-20 13:52:42.631523
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test 1
    d = _DeprecatedSequenceConstant([1,2,3,4], 'foo', 'this')
    assert 1 == d[0]
    assert 1 == d[-4]
    assert 2 == d[1]
    assert 2 == d[-3]
    assert 3 == d[2]
    assert 3 == d[-2]
    assert 4 == d[3]
    assert 4 == d[-1]
    # Test 2
    d = _DeprecatedSequenceConstant([1,2,3,4], 'foo', 'this')
    assert 1 == d[0:1][0]
    assert [1,2,3,4] == d[:]
    assert [1,2,3,4] == d[0:4]
    # Test 3
    d = _DeprecatedSequence

# Generated at 2022-06-20 13:52:45.365245
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'test msg'
    version = 'test version'
    test_value = 2
    data = [1, 2]
    test_data = _DeprecatedSequenceConstant(data, msg, version)
    assert test_data.__len__() == test_value