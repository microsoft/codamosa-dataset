

# Generated at 2022-06-20 13:43:43.764206
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    version = "2.9"
    msg = "This is a test warning message"
    value = ["a", "b"]
    x = _DeprecatedSequenceConstant(value, msg, version)

    assert x._value == value
    assert x._msg == msg
    assert x._version == version

# Generated at 2022-06-20 13:43:45.582333
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2

# Generated at 2022-06-20 13:43:47.078122
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([], 'message', 'version')
    assert isinstance(dsc, _DeprecatedSequenceConstant)

# Generated at 2022-06-20 13:43:57.269181
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestDeprecatedSequenceConstant(unittest.TestCase):
        def setUp(self):
            self.sequence = _DeprecatedSequenceConstant(["test", "value"],
                                                        "test message",
                                                        "test version")

        def test__DeprecatedSequenceConstant_len(self):
            self.assertEqual(len(self.sequence), 2)

        def test__DeprecatedSequenceConstant_getitem(self):
            self.assertEqual(self.sequence[0], "test")

        def tearDown(self):
            self.sequence = None

# Make sure the constant sequence types do not have the append method

# Generated at 2022-06-20 13:44:01.606806
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(None, None, None)
    len(obj)

# Generated at 2022-06-20 13:44:06.229275
# Unit test for function set_constant
def test_set_constant():
    ''' test that constants exist after config is loaded '''
    # TEST CONFIG FILE PARSING

    # ANSIBLE_DEBUG is loaded as a string
    assert isinstance(ANSIBLE_DEBUG, string_types)

    # ANSIBLE_RETRY_FILES_ENABLED is now false
    assert not ANSIBLE_RETRY_FILES_ENABLED


# Generated at 2022-06-20 13:44:16.030883
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test for the constructor of class ANSIBLE_CONSTANTS
    test_value = ['a', 'b', 'c']
    test_msg = "the test msg"
    test_version = "the test version"
    test = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test._value == test_value and test._msg == test_msg and test._version == test_version

test__DeprecatedSequenceConstant()


# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-20 13:44:29.315853
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import Mapping
    import sys
    import re
    import unittest
    import logging

    class _MockStdOut:
        def __init__(self):
            self.lines = []

        def write(self, line):
            self.lines.append(line)

    class _TestDeprecatedSequenceConstant(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            # Capture stdout to a MockStdOut object
            cls.sys_stdout = sys.stdout
            sys.stdout = cls.mock_stdout = _MockStdOut()

            # Create a DeprecatedSequenceConstant object
            cls.value = ['one', 'two', 'three', 'four']

# Generated at 2022-06-20 13:44:38.969727
# Unit test for function set_constant
def test_set_constant():

    global TEST_SET_CONSTANT
    module = "ansible.constant_test"
    export = {}
    set_constant('TEST_SET_CONSTANT', True, export=export)
    assert 'TEST_SET_CONSTANT' in export
    assert 'TEST_SET_CONSTANT' in globals()
    assert 'TEST_SET_CONSTANT' in add_internal_fqcns(('test_set_constant',), export, module)



# Generated at 2022-06-20 13:44:44.355476
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = (1, 2, 3)
    msg = 'This is a message'
    version = '1.2.3'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[1] == 2


# Generated at 2022-06-20 13:44:57.741539
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class Test:
        def __init__(self):
            self.test_value = _DeprecatedSequenceConstant([1, 2, 3], 'message', '2.2')

    if not isinstance(Test().test_value, Sequence):
        raise AssertionError
    if len(Test().test_value) != 3:
        raise AssertionError
    if Test().test_value[0] != 1:
        raise AssertionError

# FIXME: remove this once play_context mangling is removed
# these are used by the PlayContext object, but need to be
# populated here for backwards compatibility
for key in MAGIC_VARIABLE_MAPPING.keys():
    set_constant(key, MAGIC_VARIABLE_MAPPING[key])

# Generated at 2022-06-20 13:45:00.896231
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(value=(1, 2, 3), msg="test", version="2.0")
    assert d[1] == 2



# Generated at 2022-06-20 13:45:05.544541
# Unit test for function set_constant
def test_set_constant():
    set_constant('color_codes', COLOR_CODES)
    assert 'color_codes' in vars()

    set_constant('color_codes', COLOR_CODES, export=globals())
    assert 'color_codes' in globals()

# Generated at 2022-06-20 13:45:08.333157
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant((1, 2), 'testmsg', '2.10')
    assert dsc[0] == 1
    assert dsc[1] == 2



# Generated at 2022-06-20 13:45:11.564835
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant((1,2), 'test message', '2.9')
    assert seq[0] == 1
    assert seq[1] == 2


# Generated at 2022-06-20 13:45:17.729089
# Unit test for function set_constant
def test_set_constant():
    __tracebackhide__ = True
    test_constant = 'test_constant'
    set_constant(test_constant, 1)
    assert vars()[test_constant] == 1

# Deprecated constants
DEFAULT_HOST_LIST = _DeprecatedSequenceConstant(DEFAULT_HOST_LIST,
                                                 'DEFAULT_HOST_LIST',
                                                 version='2.12')



# Generated at 2022-06-20 13:45:22.884957
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')
    assert d[0] == 1
    assert len(d) == 3

# unit test for variables

# Generated at 2022-06-20 13:45:30.174279
# Unit test for function set_constant
def test_set_constant():

    from types import BooleanType, NoneType, StringType
    t_bool = BooleanType()
    t_none = NoneType()
    t_string = StringType()

    assert DEFAULT_SUBSET is None
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_REMOTE_PASS is None
    assert TREE_DIR is None
    assert VAULT_VERSION_MIN == 1.0

    assert type(COLLECTION_PTYPE_COMPAT) == dict
    assert type(DEFAULT_PASSWORD_CHARS) == t_string
    assert type(REJECT_EXTS) == tuple
    assert type(BOOL_TRUE) == tuple
    assert type(CONFIGURABLE_PLUGINS) == tuple
    assert type(IGNORE_FILES) == tuple

# Generated at 2022-06-20 13:45:34.033854
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1,2,3], 'this is a warning', 'version')
    assert len(a) == 3
    assert a[1] == 2
    assert a.__getitem__(0) == 1

# Generated at 2022-06-20 13:45:37.961684
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "test"
    version = "1.2.3"
    assert _DeprecatedSequenceConstant([1, 2,], msg, version).__len__() == 3



# Generated at 2022-06-20 13:45:48.221607
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = (1, 2, 3)
    msg = 'test msg'
    version = 'test version'
    assert len(_DeprecatedSequenceConstant(value, msg, version)) == 3

# Generated at 2022-06-20 13:45:51.444518
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('1', '2', '3'), 'msg', '1.0')) == 3


# Generated at 2022-06-20 13:45:55.047384
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('BECOME_METHOD', 'some_method', vars()) == {'BECOME_METHOD': 'some_method'}


# Generated at 2022-06-20 13:45:58.117456
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'Deprecated message', '2.0')
    assert len(s) == 3
    assert s[0] == 1 and s[1] == 2 and s[2] == 3


# Generated at 2022-06-20 13:46:02.586447
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], "test", "2.10")
    assert len(sequence) == 3


# Generated at 2022-06-20 13:46:04.846287
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), msg="", version="")) == 3


# Generated at 2022-06-20 13:46:08.792437
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'ver')
    assert sequence_constant.__len__() == 3

# Generated at 2022-06-20 13:46:19.463298
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant should be a subclass of Sequence
    assert issubclass(_DeprecatedSequenceConstant, Sequence)

    # _DeprecatedSequenceConstant should have a constructor method
    assert hasattr(_DeprecatedSequenceConstant, '__init__')

    # _DeprecatedSequenceConstant constructor should have three paramters
    assert _DeprecatedSequenceConstant.__init__.__code__.co_argcount == 3

    # _DeprecatedSequenceConstant should have a __len__ method
    assert hasattr(_DeprecatedSequenceConstant, '__len__')

    # _DeprecatedSequenceConstant should have a __getitem__ method
    assert hasattr(_DeprecatedSequenceConstant, '__getitem__')



# Generated at 2022-06-20 13:46:35.514892
# Unit test for function set_constant
def test_set_constant():
    import ansible.constants as C

    # Test to see that we can set constant to string type
    set_constant('FOO', 'BAR')
    assert C.FOO == 'BAR'

    # Test to see that we can set constant to boolean type
    set_constant('FOO', True)
    assert C.FOO

    # Test to see that we can set constant to None type
    set_constant('FOO', None)
    assert C.FOO is None

    # Test to see that we can set constant to integer type
    set_constant('FOO', 42)
    assert C.FOO == 42

    # Test to see that we can set constant to float type
    set_constant('FOO', 3.1415)
    assert C.FOO == 3.1415

    # Test to see

# Generated at 2022-06-20 13:46:43.139353
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Sequence of module names with some duplicates for testing
    # [{'ansible.builtin.syslog_facility'}, {'syslog_facility'}, {'win_syslog_facility'}]
    modules = add_internal_fqcns(('syslog_facility', 'win_syslog_facility'))
    test_obj = _DeprecatedSequenceConstant(modules, "TEST_MSG", "TEST_VER")

    # Check that all names were included as expected
    assert len(modules) == len(test_obj)
    assert {'syslog_facility', 'win_syslog_facility'} == set([x for x in test_obj])



# Generated at 2022-06-20 13:47:08.069358
# Unit test for function set_constant
def test_set_constant():

    set_constant('ANSIBLE_TEST_SET_CONSTANT', 'This is a test string')
    set_constant('ANSIBLE_TEST_SET_CONSTANT_INT', 10)
    set_constant('ANSIBLE_TEST_SET_CONSTANT_BOOL', True)

    assert ANSIBLE_TEST_SET_CONSTANT == 'This is a test string'
    assert ANSIBLE_TEST_SET_CONSTANT_INT == 10
    assert ANSIBLE_TEST_SET_CONSTANT_BOOL is True

# Generated at 2022-06-20 13:47:12.030760
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(None, None, None)
    assert c._value is None
    assert c._msg is None
    assert c._version is None
    assert len(c) == 0
    assert c[0] == None


# Generated at 2022-06-20 13:47:19.106947
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(['apple', 'orange', 'banana'], 'Use a list instead', 'version')
    assert c[0] == 'apple'
    assert c[-1] == 'banana'
    assert c[1:3] == ['orange', 'banana']


# Generated at 2022-06-20 13:47:20.769928
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-20 13:47:23.813225
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant([], '', '')
    with pytest.raises(NotImplementedError):
        test_object.__getitem__(0)

# Generated at 2022-06-20 13:47:28.223115
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'this is a test', '1.0')
    assert len(dsc) == 3


# Generated at 2022-06-20 13:47:30.759575
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    real_seq = ['a', 'b', 'c']
    deprecated_seq = _DeprecatedSequenceConstant(real_seq, 'msg', 'version')
    assert 'b' == deprecated_seq[1]



# Generated at 2022-06-20 13:47:39.746755
# Unit test for function set_constant
def test_set_constant():
    """
    This function tests the set_constant function, which is used to set constants in 'constants.py'.
    """

    # Test to ensure that setting constants does not raise any exceptions

    var1 = 'test_1'
    var2 = 'test_2'
    var3 = 'test_3'
    val1 = 1
    val2 = 'test'
    val3 = True

    # Test that it sets constants without error
    try:
        set_constant(var1, val1)
        set_constant(var2, val2)
        set_constant(var3, val3)
    except Exception as e:
        print(e)
        raise AssertionError("set_constant function raised an exception when setting constants.")

    # Test that it overwrites constants with the same name

# Generated at 2022-06-20 13:47:45.681781
# Unit test for function set_constant
def test_set_constant():
    export = {}
    assert not set_constant('TESTING_CONSTANT', 'foo', export=export)
    assert 'TESTING_CONSTANT' in export
    assert export['TESTING_CONSTANT'] == 'foo'


# TODO: remove the following once we fully deprecate anything using the following

MAGIC_VARIABLE_MAPPING['ssh'] = ('ansible_connection', )
MAGIC_VARIABLE_MAPPING['ssh_args'] = ('ansible_ssh_common_args', 'ansible_ssh_extra_args')

# TODO: remove with Ansible 2.8
_dep_msg = 'This option is deprecated, use "%s" instead'

# Generated at 2022-06-20 13:47:48.119884
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0


# Generated at 2022-06-20 13:48:28.102398
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import logging
    import sys
    log = logging.getLogger('test_deprecated_sequence_constant')
    log.setLevel(logging.WARNING)
    stderr_handler = logging.StreamHandler(sys.stderr)
    log.addHandler(stderr_handler)
    log.setLevel(logging.WARNING)
    test_sequence = _DeprecatedSequenceConstant(value=['test', 'value'], msg='test_msg', version='test_version')
    assert test_sequence[0] == 'test'
    assert test_sequence[1] == 'value'
    assert len(test_sequence) == 2


# Generated at 2022-06-20 13:48:36.732961
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys

    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = None, None

    try:
        # test call
        result = _DeprecatedSequenceConstant([1,2,3], msg='message', version='2.5')[1]

        # assert type and result
        assert isinstance(result, int), "Incorrect returned type from _DeprecatedSequenceConstant[1]"
        assert result == 2, "Incorrect returned type from _DeprecatedSequenceConstant[1]"
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr

# Generated at 2022-06-20 13:48:44.997997
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # empty sequence which is instance of tuple
    v = _DeprecatedSequenceConstant((), 'msg', 'version')
    assert isinstance(v, Sequence) and isinstance(v, tuple) and len(v) == 0

    # sequence contains items which is instance of tuple
    v = _DeprecatedSequenceConstant((1, 'a', 'b'), 'msg', 'version')
    assert isinstance(v, Sequence) and isinstance(v, tuple) and len(v) == 3 and v[0] == 1


# specific hacks to get the display class loaded early

# Generated at 2022-06-20 13:48:48.245427
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    const = _DeprecatedSequenceConstant([1, 2, 3], 'test warning', '2.6')
    assert len(const) == 3
    assert const[0] == 1


# Generated at 2022-06-20 13:48:53.976304
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')[2] == 3
    assert len(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version')) == 3

# Generated at 2022-06-20 13:48:58.821607
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant((1, 2, 3), "msg", "1.0")
    assert a[0] == 1
    with pytest.deprecated_call():
        assert a[1] == 2
        assert a[2] == 3


# Generated at 2022-06-20 13:49:02.110804
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    testobj = _DeprecatedSequenceConstant(value=['a'], msg='testmsg', version='1.0')
    assert testobj[0] == 'a'

# Generated at 2022-06-20 13:49:05.113651
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([2, 3], "test message", "test_version")

    assert seq[1] == 3



# Generated at 2022-06-20 13:49:07.101733
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert test_obj[0] == 1


# Generated at 2022-06-20 13:49:13.658391
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Setup
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')

    # Exercise
    result = len(dsc)

    # Verify
    assert result == 2



# Generated at 2022-06-20 13:50:26.061893
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], msg="This is a test", version="2.99")
    assert len(sequence) == 3
    assert sequence[0] == 1


# FIXME: remove once play_context mangling is removed
# place the magic variable mapping into the PlayContext class itself

from ansible.playbook.play_context import PlayContext

# the actual field names are different than the legacy variable names
# and are in the appropriate underscore format.
for legacy, real in MAGIC_VARIABLE_MAPPING.items():
    for r in real:
        setattr(PlayContext, legacy, property(lambda self, r=r: getattr(self, r), lambda self, value, r=r: setattr(self, r, value)))

# Generated at 2022-06-20 13:50:28.365570
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = _DeprecatedSequenceConstant([1], 'warning', '2.9')
    assert value[0] == 1


# Generated at 2022-06-20 13:50:30.177426
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(value=[1,2,3], msg='a', version='1.0')
    assert len(a) == 3

# Generated at 2022-06-20 13:50:37.617590
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # set a constant
    constant = _DeprecatedSequenceConstant(['test1', 'test2'], 'This is a deprecation message', 'ansible 2.9')

    # test the constant
    assert isinstance(constant, Sequence)

    # test the constant
    assert isinstance(constant, Sequence)

    # test the length of the constant
    assert len(constant) == 2

    # test the first element of the list
    assert constant[0] == 'test1'

    # test the second element of the list
    assert constant[1] == 'test2'

# Generated at 2022-06-20 13:50:44.178226
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    export = {}
    set_constant('CONST_1', 1, export)
    set_constant('CONST_2', 'data', export)
    set_constant('CONST_3', ImmutableDict(a=0, b=1), export)
    assert export['CONST_1'] == 1
    assert export['CONST_2'] == 'data'
    assert export['CONST_3'] == {'a':0, 'b':1}

# Generated at 2022-06-20 13:50:47.767386
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    tmpl = 'The value is: %s'
    msg = 'Deprecated message for test'
    version = '2.10.0'
    dsc = _DeprecatedSequenceConstant('test value', msg, version)
    assert dsc[0] == 't'
    assert dsc[:4] == 'test'

# Generated at 2022-06-20 13:50:49.162197
# Unit test for function set_constant
def test_set_constant():
    set_constant("foo", "bar")
    assert foo == "bar"



# Generated at 2022-06-20 13:50:57.162594
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ''' unit test for class _DeprecatedSequenceConstant '''

    value = [1, 2, 3]

    constant = _DeprecatedSequenceConstant(value, 'message', 'version')

    assert type(constant) == _DeprecatedSequenceConstant
    assert constant._value == [1, 2, 3]
    assert constant._msg == 'message'
    assert constant._version == 'version'
    assert len(constant) == 3
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3

# Generated at 2022-06-20 13:51:03.420735
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def test(msg, version, v, y, expected):
        d = _DeprecatedSequenceConstant(v, msg, version)
        actual = d.__getitem__(y)
        assert expected == actual

    test('msg1', '2.0', 'abc', 0, 'a')
    test('msg2', '2.0', {'a': 4}, 'a', 4)
    test('msg3', '2.0', {1: 4}, 1, 4)

if __name__ == '__main__':
    import sys

    if '--test' in sys.argv:
        test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-20 13:51:06.383051
# Unit test for function set_constant
def test_set_constant():
    configuration = dict()
    set_constant('ANSIBLE_HOST_KEY_CHECKING', 'False', configuration)
    set_constant('ANSIBLE_DEPRECATION_WARNINGS', 'False', configuration)

    assert False == configuration['ANSIBLE_HOST_KEY_CHECKING']
    assert False == configuration['ANSIBLE_DEPRECATION_WARNINGS']

# Generated at 2022-06-20 13:53:14.486882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-20 13:53:16.741201
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(["a","b"], "test", "0.1")) == 2


# Generated at 2022-06-20 13:53:19.451527
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 'b')
    assert 'b' == a
    set_constant('c', 'd', {'e': 'f'})
    assert 'f' == e
    assert 'd' not in globals()


# Generated at 2022-06-20 13:53:26.019857
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        assert setting.name in vars()

# Generate deprecated sequence constants from config
for setting in config.data.get_settings():
    if hasattr(setting, 'deprecate_as') and setting.deprecate_as is not None:
        msg = "%s is set via '%s' as of Ansible %s and the option is deprecated since Ansible %s" % (setting.deprecate_as, setting.name, __version__, setting.version_added)
        if setting.removed_at_date:
            msg += ", and will be removed in Ansible %s" % setting.removed_at_date

# Generated at 2022-06-20 13:53:29.284911
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_const = _DeprecatedSequenceConstant(('test', ), 'This is a test', '2.8')
    assert seq_const[0] == 'test'

# Unit tests for constants defined above

# Generated at 2022-06-20 13:53:32.474548
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant([1, 2, 3], 'Test msg.', 'v3.0')
    assert test_constant[0] == 1
    assert test_constant[1] == 2
    assert test_constant[2] == 3

# Generated at 2022-06-20 13:53:34.278357
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='foo', version='1.2')[0] == 'a'

# Generated at 2022-06-20 13:53:38.342083
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        ds = _DeprecatedSequenceConstant([1, 2], 'test message', 'test version')
        assert len(ds) == 2
        assert ds[0] == 1
    except AssertionError:
        raise AssertionError('test__DeprecatedSequenceConstant failed')