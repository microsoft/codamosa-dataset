

# Generated at 2022-06-20 13:43:42.653154
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant(range(10), 'Test Message', 'version')[0]
    assert result == 0


# Generated at 2022-06-20 13:43:45.512066
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Arrange.
    value = ['foo', 'bar']
    msg = 'test'
    version = '2.0'
    c = _DeprecatedSequenceConstant(value, msg, version)

    # Act and assert.
    for i in range(len(value)):
        assert value[i] == value[i]


# Generated at 2022-06-20 13:43:54.169487
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import mock
    import pytest

    test_msg = 'test message'
    test_version = '1.0'
    test_value = ['test', 'value']

    constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    index = 1

    with mock.patch('ansible.utils.plugin_docs.DeprecatedSequenceConstant._deprecated') as mocked_deprecated:
        result = constant.__getitem__(index)

    mocked_deprecated.assert_called_once_with(test_msg, test_version)
    assert result == test_value[index]


# Generated at 2022-06-20 13:44:01.421372
# Unit test for function set_constant
def test_set_constant():
    scope = {}
    set_constant("test", "a", export=scope)
    assert scope['test'] == "a"
    set_constant("test", "b", export=scope)
    assert scope['test'] == "b"
    set_constant("test", "c")
    assert scope['test'] == "c"
    set_constant("test", "d")
    assert scope['test'] == "d"

if __version__.startswith('1.9.'):
    # set these to None as they don't exist in 2.0
    FACT_CACHE_TIMEOUT = None
    GATHERING = None
    HOSTVARS = None
    GROUP_VARS = None
    HOST_VARS = None
    JINJA2_NATIVE = None
    MODULE_CACHE

# Generated at 2022-06-20 13:44:05.315672
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, '3'], 'message', '1.99')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == '3'



# Generated at 2022-06-20 13:44:07.283154
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value=["test"], msg="test", version="2.8")

    assert deprecated_sequence_constant[0] == "test"

# Generated at 2022-06-20 13:44:18.644610
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    empty_s = _DeprecatedSequenceConstant(value=[], msg="", version="")
    assert(len(empty_s) == 0)
    assert(empty_s[:] == [])

    non_empty_s = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg="", version="")
    assert(len(non_empty_s) == 3)
    assert(non_empty_s[0] == 'a')
    assert(non_empty_s[-1] == 'c')
    assert(non_empty_s[:2] == ['a', 'b'])
    assert(non_empty_s[-3:] == ['a', 'b', 'c'])


# Generated at 2022-06-20 13:44:25.677203
# Unit test for function set_constant
def test_set_constant():
    """
    Test to see if set_constant works.

    This is primarily for readability, it is not expected for any
    AnsibleConfig class to actually exist.
    """
    try:
        from ansible.config import AnsibleConfig
    except ImportError:
        class AnsibleConfig(object):
            def __init__(self):
                self.foo = 'bar'
                self.baz = 'qux'
    config = AnsibleConfig()
    # verify that config object has all the vars we want
    assert config.foo == 'bar'
    assert config.baz == 'qux'

    # save current globals as a dict to reset them after tests
    globals_copy = globals()

    # clear globals docstring because pylint complains about it

# Generated at 2022-06-20 13:44:28.279271
# Unit test for function set_constant
def test_set_constant():
    test_source = {'test_playbook_path': '/test/test_playbook'}
    test_dest = {}
    for test_pair in test_source.items():
        set_constant(*test_pair, export=test_dest)
    assert test_source == test_dest

# Generated at 2022-06-20 13:44:35.473399
# Unit test for function set_constant
def test_set_constant():
    assert not hasattr(constants, '__TEST__')
    set_constant('__TEST__', 1)
    assert hasattr(constants, '__TEST__')
    set_constant('__TEST__', 2)
    assert constants.__TEST__ == 2

# Generated at 2022-06-20 13:44:50.186828
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    set_constant('FOO', ['1', '2'])
    set_constant('ANSIBLE_FOO', _DeprecatedSequenceConstant(['3', '4'],
                                                            'The ANSIBLE_FOO setting has been deprecated, please use the FOO setting instead.',
                                                            '2.6'))
    assert FOO == ['1', '2']
    assert ANSIBLE_FOO == ['3', '4']
    assert FOO[0] == '1'
    assert FOO[1] == '2'
    assert ANSIBLE_FOO[0] == '3'
    assert ANSIBLE_FOO[1] == '4'



# Generated at 2022-06-20 13:44:55.326878
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 13:44:57.766634
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(s) == 3


# Generated at 2022-06-20 13:45:08.832581
# Unit test for function set_constant
def test_set_constant():
    ''' unit testing for function set_constant '''
    values = dict(dict=dict(b='123', a='foo'),
                  list=['a', 'b', 'c'],
                  string='string',
                  number=123,
                  )
    for value_type in values:
        set_constant('_TEST_SET_CONSTANT_%s' % value_type.upper(), values[value_type])
        assert vars()['_TEST_SET_CONSTANT_%s' % value_type.upper()] == values[value_type]

# CONSTANT VALUES BASED ON CONFIG SETTINGS ###
# The majority of this section should be refactored out of constants.py with
# the values being passed in through init or read from the config.

ACTION_WARNINGS = _DeprecatedSequenceCon

# Generated at 2022-06-20 13:45:12.667996
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_ANSIBLE_VERSION')
    assert globals()['ANSIBLE_ANSIBLE_VERSION'], "ANSIBLE_ANSIBLE_VERSION set"



# Generated at 2022-06-20 13:45:20.747892
# Unit test for function set_constant
def test_set_constant():

    def assert_set_constant_eq(name, value, expected, export=vars()):
        set_constant(name, value, export)
        assert export[name] == expected

    assert_set_constant_eq('MY_STR', '{{foo}}', '{{foo}}')
    assert_set_constant_eq('MY_INT', '42', '42')
    assert_set_constant_eq('MY_FLOAT', 42.0, 42.0)
    assert_set_constant_eq('MY_BOOL_T', 1, True)
    assert_set_constant_eq('MY_BOOL_T', '1', True)
    assert_set_constant_eq('MY_BOOL_T', 'on', True)

# Generated at 2022-06-20 13:45:27.756314
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Testing():
        def __init__(self, n):
            self._n = n

        def __len__(self):
            return self._n

    length = 3
    msg = "Unittest"
    version = "1.1"

    t = Testing(length)
    dsc = _DeprecatedSequenceConstant(t, msg, version)
    assert len(dsc) == length
    assert len(dsc._value) == length
    assert dsc._msg == msg
    assert dsc._version == version

# Generated at 2022-06-20 13:45:31.004552
# Unit test for function set_constant
def test_set_constant():

    # Set config constants
    set_constant('TEST_CONSTANT', value=1)

    # Assert that the constant has been set and is correct
    assert TEST_CONSTANT == 1


# Generated at 2022-06-20 13:45:42.955772
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS == None
    assert DEFAULT_PASSWORD_CHARS == u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'
    assert DEFAULT_REMOTE_PASS == None
    assert DEFAULT_SUBSET == None
    assert DOCUMENTABLE_PLUGINS == (
        'become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell',
        'vars', 'module', 'strategy')
    assert IGNORE_FILES == ("COPYING", "CONTRIBUTING", "LICENSE", "README", "VERSION", "GUIDELINES")
    assert LOCALHOST

# Generated at 2022-06-20 13:45:47.168765
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert len(s) == 2, 'Len of _DeprecatedSequenceConstant not working'
    assert s[0] == 'a', 'Indexing of _DeprecatedSequenceConstant not working'

# Generated at 2022-06-20 13:45:58.784367
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test with no message, version
    assert isinstance(_DeprecatedSequenceConstant([1, 4, 6, 8, 3], 'msg', None), _DeprecatedSequenceConstant)

    # Test with message, and a version
    assert isinstance(_DeprecatedSequenceConstant([1, 4, 6, 8, 3], 'msg', '2.8'), _DeprecatedSequenceConstant)

    # Test with no message, no version
    assert isinstance(_DeprecatedSequenceConstant([1, 4, 6, 8, 3], '', None), _DeprecatedSequenceConstant)

# Generated at 2022-06-20 13:46:03.589230
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant([1], 'msg', 'version')

    assert len(test_obj) == 1
    assert test_obj[0] == 1
    assert test_obj[-1] == 1
    assert test_obj[0:1] == [1]

del config

# Generated at 2022-06-20 13:46:08.381076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(['a', 'b', 'c'], "Test deprecated", "ansible 2.0")
    assert len(a) == 3
    assert a[1] == 'b'

# Generated at 2022-06-20 13:46:12.371445
# Unit test for function set_constant
def test_set_constant():
    test_value = 'hello'
    set_constant('TEST_CONSTANT', test_value, vars())
    assert vars()['TEST_CONSTANT'] == test_value

# Generated at 2022-06-20 13:46:23.371568
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = 'FooBar'
    msg = 'FooBar has been deprecated'
    version = 'X.Y.Z'

    test_value = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(test_value, _DeprecatedSequenceConstant)

    test_value = _DeprecatedSequenceConstant(value, 'FooBar has been deprecated', 'X.Y.Z')
    assert isinstance(test_value, _DeprecatedSequenceConstant)

    test_value = _DeprecatedSequenceConstant('FooBar', 'FooBar has been deprecated', 'X.Y.Z')
    assert isinstance(test_value, _DeprecatedSequenceConstant)

    test_value = _DeprecatedSequenceConstant('FooBar', msg, version)

# Generated at 2022-06-20 13:46:26.947854
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'
    set_constant('foo', 'baz', locals())
    assert foo == 'baz'

# Generated at 2022-06-20 13:46:31.235556
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')

    expected = 1
    actual = constant.__getitem__(0)
    assert actual == expected



# Generated at 2022-06-20 13:46:37.950162
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant_name = "CONSTANT_VAR"
    constant_value = ('a', 'b', 'c')
    constant = _DeprecatedSequenceConstant(constant_value, msg='', version='')
    assert constant[0] == 'a', 'failed to get value at index 0'
    assert constant[1] == 'b', 'failed to get value at index 1'
    assert constant[2] == 'c', 'failed to get value at index 2'


# Generated at 2022-06-20 13:46:45.409092
# Unit test for function set_constant
def test_set_constant():
    set_constant('_TEST_BOOL', True)
    assert _TEST_BOOL is True

    set_constant('_TEST_STR', 'ansible')
    assert _TEST_STR == 'ansible'

# Generated at 2022-06-20 13:46:51.141294
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ['one', 'two', 'three']
    test_msg = "This is a test message"
    test_version = '1.0'

    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)

    assert len(test_obj) == 3


# Generated at 2022-06-20 13:47:10.904443
# Unit test for function set_constant
def test_set_constant():
    from ansible.utils.constants import set_constant
    assert 'ANSIBLE_HOST_KEY_CHECKING' in globals()
    assert 'ANSIBLE_SSH_RETRIES' in globals()
    assert 'ANSIBLE_TEST_CONSTANT' not in globals()
    set_constant('ANSIBLE_TEST_CONSTANT', True)
    assert 'ANSIBLE_TEST_CONSTANT' in globals()
    set_constant('ANSIBLE_TEST_CONSTANT', False)
    assert 'ANSIBLE_TEST_CONSTANT' in globals()
    assert globals()['ANSIBLE_TEST_CONSTANT'] is False

# DEPRECATED
version_info = tuple(int(i) for i in __version__.split('.')[0:2])
__version

# Generated at 2022-06-20 13:47:13.949575
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    ssc = _DeprecatedSequenceConstant(['a', 'b'],'Test', '1.0.0')
    assert len(ssc)==2


# Generated at 2022-06-20 13:47:15.870169
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1,2,3], _msg='Test message', version='2.4')

# Generated at 2022-06-20 13:47:18.955255
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import mock
    a = _DeprecatedSequenceConstant('a','b','c')
    a.__len__()
    mock.assert_called_once_with('b','c')


# Generated at 2022-06-20 13:47:21.225741
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['test'], 'test message', 'test version')[0] == 'test'


# Generated at 2022-06-20 13:47:30.575320
# Unit test for function set_constant
def test_set_constant():
    # call set_constant without export parameter
    set_constant('FOOBAR', 'foobar')
    assert FOOBAR == 'foobar'

    # call set_constant with export parameter
    export = {}
    set_constant('FOOBAR2', 'foobar2', export=export)
    assert export['FOOBAR2'] == 'foobar2'

    # call set_constant with export parameter containing a value
    export = {'FOOBAR2': 'foobar2'}
    set_constant('FOOBAR2', 'foobar', export=export)
    assert export['FOOBAR2'] == 'foobar'

# Generated at 2022-06-20 13:47:39.623147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Constructor of class _DeprecatedSequenceConstant
    internal_fqcns_list = add_internal_fqcns(('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                                              'ansible.windows.win_shell', 'raw', 'script'))
    value = _DeprecatedSequenceConstant(internal_fqcns_list, msg='This is deprecated', version='2.9')
    assert len(value) == len(internal_fqcns_list)
    assert value[0] == 'command'
    assert value[1] == 'win_command'
    assert value[2] == 'ansible.windows.win_command'
    assert value[3] == 'shell'
    assert value[4] == 'win_shell'


# Generated at 2022-06-20 13:47:40.850986
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(tuple(range(10)), '', '')

# Generated at 2022-06-20 13:47:45.956711
# Unit test for function set_constant
def test_set_constant():
    s = dict()
    set_constant('test', 'foo', export=s)
    assert s['test'] == 'foo'



# Generated at 2022-06-20 13:47:50.991497
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3], "test", "2.9")
    assert len(d) == 3
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3

# Generated at 2022-06-20 13:48:12.131492
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    obj = _DeprecatedSequenceConstant((1, 2, 3), msg="deprecated message", version="1.3")

    assert len(obj) == 3
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3

# Generated at 2022-06-20 13:48:17.254647
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest
    from ansible.vars.manager import DeprecationWarning

    value = ['toto', 'titi', 'tata']
    msg = "this option is deprecated"
    version = "2.13"
    deprecated_value = _DeprecatedSequenceConstant(value, msg, version)
    with pytest.warns(DeprecationWarning):
        assert deprecated_value[0] == 'toto'
        assert deprecated_value[1] == 'titi'
        assert deprecated_value[2] == 'tata'


# Generated at 2022-06-20 13:48:21.306721
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('TEST_SET_CONSTANT', 'value', test_dict)
    assert test_dict['TEST_SET_CONSTANT'] == 'value'

# Generated at 2022-06-20 13:48:24.421429
# Unit test for function set_constant
def test_set_constant():
    bogus_constant = 'THIS IS A BOGUS CONSTANT'
    assert bogus_constant not in globals()
    set_constant(bogus_constant, 'bogus_value')
    assert globals()[bogus_constant] == 'bogus_value'
    del globals()[bogus_constant]

# Generated at 2022-06-20 13:48:27.506220
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('123', 'test')
    msg = 'this is a message'
    version = '2.0'
    _DeprecatedSequenceConstant(value, msg, version)

# Generated at 2022-06-20 13:48:30.279955
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant(['foo'], 'test', '1.0')
    assert len(s) == 1
    assert s[0] == 'foo'

# Generated at 2022-06-20 13:48:33.020515
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2]
    d = _DeprecatedSequenceConstant(l, 'Test msg', '2.0')
    assert d[0] == 1
    assert d[1] == 2


# Generated at 2022-06-20 13:48:46.447828
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_value = [1, 2]
    test_msg = 'Test message.'
    test_version = '2.0'
    test_object = _DeprecatedSequenceConstant(value=test_value, msg=test_msg, version=test_version)

    if not isinstance(test_object, Sequence):
        return {'failed': True, 'msg': 'Instance of class "_DeprecatedSequenceConstant" is not instance of class "Sequence".'}

    if not len(test_object) == len(test_value):
        return {'failed': True, 'msg': 'Instance of class "_DeprecatedSequenceConstant" has incorrect length.'}


# Generated at 2022-06-20 13:48:49.326895
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_info = _DeprecatedSequenceConstant((1,2), "test", "2.0")
    assert list(deprecated_info) == [1,2]


# Generated at 2022-06-20 13:48:56.058093
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for different type of values
    input_to_assert = [
        ('a', 'b', 'c'),
        (True, True, True),
        (1, 2, 3),
        (1.0, 2.0, 3.0),
        (b'a', b'b', b'c'),
        (set(), set(), set()),
        ({'a': 1}, {'b': 2}, {'c': 3}),
        # add more test cases if required
    ]
    for input_v in input_to_assert:
        for i in range(len(input_v)):
            assert input_v[i] == _DeprecatedSequenceConstant(input_v, 'a', 'b')[i]

# Generated at 2022-06-20 13:49:35.810476
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert(_DeprecatedSequenceConstant([], "MESSAGE", "VERSION") == [])

# Generated at 2022-06-20 13:49:38.440304
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant({'a': 1}, 'test warning', '2.6')
    assert constant['a'] == 1

# Generated at 2022-06-20 13:49:53.968164
# Unit test for function set_constant
def test_set_constant():
    # Let's see that a string is correctly translated to a boolean
    set_constant('ANSIBLE_DURING_UNIT_TESTS', 'string_value')
    assert ANSIBLE_DURING_UNIT_TESTS is True

    # Let's see that a int is correctly translated to a boolean
    set_constant('ANSIBLE_DURING_UNIT_TESTS', 1)
    assert ANSIBLE_DURING_UNIT_TESTS is True


# Base constants after config

PASSLIB_AVAILABLE = True

# Generated at 2022-06-20 13:49:57.947334
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence = _DeprecatedSequenceConstant(('a', 'b'), 'Test message', '1.1')
    assert len(deprecated_sequence) == 2
    assert deprecated_sequence[0] == 'a'
    assert deprecated_sequence[1] == 'b'

# Generated at 2022-06-20 13:50:00.823410
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant(("test1", "test2"), "test message", "test version")
    assert len(test_obj) == 2

# Generated at 2022-06-20 13:50:03.467791
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my = _DeprecatedSequenceConstant(['a', 'b'], 'foo', version='1.4')
    assert len(my) == 2


# Generated at 2022-06-20 13:50:05.419897
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], "Test", "Test")) == len([1,2,3])


# Generated at 2022-06-20 13:50:07.652836
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(value=[1, 2], msg='msg', version='version')
    assert constant[0] == 1


# Generated at 2022-06-20 13:50:16.730168
# Unit test for function set_constant
def test_set_constant():
    test_constant = 'test_set_constant'
    # The first argument is the exported list, which should be modified
    set_constant(test_constant, 'barf')
    assert(test_constant == 'barf')
    # The first argument should default to __builtin__
    set_constant(test_constant, 'glarble')
    assert(globals()[test_constant] == 'glarble')
    # Make sure the global is re-defined only in the export list
    set_constant(test_constant, 'aalgarve', locals())
    assert(globals()[test_constant] == 'glarble')
    assert(locals()[test_constant] == 'aalgarve')


# Set constants from config

# Generated at 2022-06-20 13:50:23.519814
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # testing with no deprecation warning, just for coverage
    const = _DeprecatedSequenceConstant([1, 2, 3], None, None)
    assert len(const) == 3
    assert const[0] == 1
    assert const[1] == 2
    assert const[2] == 3
    assert const[0:2] == [1, 2]

# Generated at 2022-06-20 13:51:44.958947
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        t_DeprecatedSequenceConstant = _DeprecatedSequenceConstant([None, None], "deprecated", "2.9")
        assert len(t_DeprecatedSequenceConstant) == 2
        assert t_DeprecatedSequenceConstant[0] == t_DeprecatedSequenceConstant[1] == None
    except Exception:
        _warning('Unit test failed for _DeprecatedSequenceConstant')

# Generated at 2022-06-20 13:51:48.973569
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # The method being tested is invoked by the constructor of _DeprecatedSequenceConstant
    # We have no access to the actual constructor of that class
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert len(dsc) == 3

# Generated at 2022-06-20 13:51:58.497335
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for index of 0
    ds = _DeprecatedSequenceConstant([1, 2], 'test_message', 'test_version')
    assert ds[0] == 1

    # Test for index of 1
    ds = _DeprecatedSequenceConstant([1, 2], 'test_message', 'test_version')
    assert ds[1] == 2

    # Test for index of -1
    ds = _DeprecatedSequenceConstant([1, 2], 'test_message', 'test_version')
    assert ds[-1] == 2

    # Test for index of 2 (Failure case)
    ds = _DeprecatedSequenceConstant([1, 2], 'test_message', 'test_version')

# Generated at 2022-06-20 13:51:59.985512
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), None, None)) == 3


# Generated at 2022-06-20 13:52:07.723439
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from six import StringIO
    from io import TextIOWrapper
    import sys

    # Before - sys.stderr is stderr
    if not isinstance(sys.stderr, (StringIO, TextIOWrapper)):
        stderr = sys.stderr
        sys.stderr = StringIO()

    # Test
    value = ('a', )
    msg = 'test'
    version = '1.0'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'

    # After - sys.stderr is stderr
    if stderr is not None:
        sys.stderr = stderr

# Generated at 2022-06-20 13:52:13.616029
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a deprecated value."
    v = _DeprecatedSequenceConstant(value = ['a', 'b'], msg = msg, version = '2.9')
    assert len(v) == 2
    assert v[0] == 'a'
    assert v[1] == 'b'
    assert v._value == ['a', 'b']
    assert v._msg == msg
    assert v._version == '2.9'

# Generated at 2022-06-20 13:52:16.639149
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')) == 2


# Generated at 2022-06-20 13:52:21.253726
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.display import Display
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.become import BecomeBase
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    t = _DeprecatedSequenceConstant([1, 2, 3], 'TEST_MSG', '2.9')

    assert t[1] == 2


# Generated at 2022-06-20 13:52:21.763354
# Unit test for function set_constant
def test_set_constant():
    pass

# Generated at 2022-06-20 13:52:24.768355
# Unit test for function set_constant
def test_set_constant():
    '''
    >>> set_constant('FOO', 1)
    >>> FOO == 1
    True
    '''
    pass