

# Generated at 2022-06-22 19:30:34.494098
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class Dummy:
        def __init__(self):
            pass

    class DummyDisplay:
        def __init__(self):
            pass

        def deprecated(self, msg, version=None):
            Dummy.deprecated_called_msg = msg
            Dummy.deprecated_called_version = version

    Dummy.display = DummyDisplay()
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'foo', 'bar')
    x = dsc[1]
    assert x == 'b'
    assert Dummy.deprecated_called_msg == 'foo'
    assert Dummy.deprecated_called_version == 'bar'

# Generated at 2022-06-22 19:30:39.594783
# Unit test for function set_constant
def test_set_constant():
    # Original value should be equal
    original = 'Original'
    set_constant('original', original)
    assert original == original
    # Unequal values should return error
    set_constant('original', 'New')
    assert original != 'New'



# Generated at 2022-06-22 19:30:50.070532
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_all_constant = _DeprecatedSequenceConstant(_ACTION_ALL_INCLUDES, "test_all_constant", "2.12")
    assert test_all_constant.__len__() == len(_ACTION_ALL_INCLUDES)
    assert test_all_constant.__getitem__(0) == _ACTION_ALL_INCLUDES[0]
    assert test_all_constant._msg == "test_all_constant"
    assert test_all_constant._version == "2.12"

# This magic variable can be used to reference the active ansible version
# ansible_version['full'] gives the git commit hash
# ansible_version['major'] gives only the major version
# ansible_version['minor'] gives only the minor version
# ansible_version['revision'] gives only

# Generated at 2022-06-22 19:30:52.654578
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_VAR', '1', globals())
    assert TEST_VAR == '1'


# Generated at 2022-06-22 19:30:56.069634
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.constants import DEFAULT_SUDO_PASS
    assert type(DEFAULT_SUDO_PASS) == type(_DeprecatedSequenceConstant([], "", ""))
    assert type(DEFAULT_SUDO_PASS[0]) == type("")


# Generated at 2022-06-22 19:31:04.110867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Testing constructor of class _DeprecatedSequenceConstant
    test_constant = _DeprecatedSequenceConstant((), "MSG", "2.6")
    # Testing __len__() of class _DeprecatedSequenceConstant
    assert len(test_constant) == 0
    # Testing __getitem__() of class _DeprecatedSequenceConstant
    assert test_constant.__getitem__(0) == None



# Generated at 2022-06-22 19:31:15.863662
# Unit test for function set_constant
def test_set_constant():
    my_env = {}
    set_constant('FOO', 'BAR', my_env)
    assert my_env['FOO'] == 'BAR'


# Usable in templates
TEMPLATE_STRING_IF_INVALID = "%s, You must pass a valid string value"
TEMPLATE_BOOLEAN_IF_INVALID = "%s, You must pass a valid boolean value"
TEMPLATE_INT_IF_INVALID = "%s, You must pass a valid integer value"
TEMPLATE_FLOAT_IF_INVALID = "%s, You must pass a valid float value"
TEMPLATE_LIST_IF_INVALID = "%s, You must pass a valid list value"

# Generated at 2022-06-22 19:31:17.995328
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert(FOO == 'bar')



# Generated at 2022-06-22 19:31:21.647315
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant(['test'], 'test warning', 'test version')
    assert t[0] == 'test'


# Generated at 2022-06-22 19:31:31.262490
# Unit test for function set_constant
def test_set_constant():
    try:
        from ansible.utils.display import Display
    except Exception:
        # set_constant is supposed to work even if Display isn't available
        class Display(object):
            @staticmethod
            def warning(*args, **kwargs):
                return ' [WARNING] %s\n' % (args[0])

        Display = Display()

    # Just make sure that Display() works without crashing
    assert Display is not None

    # Just make sure that DEFAULT_DEBUG doesn't exist yet
    assert 'DEFAULT_DEBUG' not in vars()

    # Set it
    set_constant('DEFAULT_DEBUG', True)
    # Make sure it's set correctly
    assert vars()['DEFAULT_DEBUG'] is True

# Generated at 2022-06-22 19:31:34.921818
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant('test', "testing", "")
    assert len(obj) == 4


# Generated at 2022-06-22 19:31:37.167984
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1, 2], 'test message', '2.9'), _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:31:47.795777
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    IDENTITY_MATRIX_4_MSG = 'The identity matrix 4 is deprecated and will be removed in Ansible 2.9; ' \
                            'use identity_matrix instead.'
    IDENTITY_MATRIX_4_VERSION = '2.9'
    IDENTITY_MATRIX_4 = _DeprecatedSequenceConstant(((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)),
                                                     IDENTITY_MATRIX_4_MSG, IDENTITY_MATRIX_4_VERSION)
    assert len(IDENTITY_MATRIX_4) == 4
    assert IDENTITY_MATRIX_4[1] == (0, 1, 0, 0)
    assert IDENTITY_MATRI

# Generated at 2022-06-22 19:31:52.503510
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'a message', 'a version')
    assert obj[0] == 'a'
    assert obj[1] == 'b'
    assert obj[2] == 'c'



# Generated at 2022-06-22 19:32:03.544421
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest.mock as mock
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant

    test_obj = _DeprecatedSequenceConstant(["ansible.builtin.ec2_instance", "ansible.windows.win_ec2_instance"], "Test message", "1.0")
    n_index = len(test_obj)

    with mock.patch('ansible.module_utils.common.collections._deprecated') as mocked_deprecated:
        assert mocked_deprecated.call_count == 0
        assert test_obj[0] == "ansible.builtin.ec2_instance"
        assert test_obj[1] == "ansible.windows.win_ec2_instance"
        assert mocked_deprecated.call_count == n_index

# Generated at 2022-06-22 19:32:06.096366
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant((1, 2, 3), 'mymessage', 'myversion')
    assert len(constant) == 3


# Generated at 2022-06-22 19:32:12.765105
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Result:
        pass
    if hasattr(Result(), 'skipped'):
        msg = "Use of the 'skipped' field will be removed in 2.11 and can be replaced with 'skipped_when' which is the standardized way to skip tasks based on conditions."
        ver = '2.11'
        tmp = _DeprecatedSequenceConstant((1, 2, 3, 4), msg, ver)
        r = Result()
        if hasattr(r, 'skipped'):
            _deprecated(msg, ver)
        tmp[2]
        r.skipped
        del r.skipped
        tmp[2]


if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:32:15.699797
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((), 'msg', 'version')) == 0
    assert len(_DeprecatedSequenceConstant('a', 'msg', 'version')) == 1


# Generated at 2022-06-22 19:32:19.790450
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    defined_msg = 'This is defined message'
    defined_version = 2.1
    d = _DeprecatedSequenceConstant([1,2,3,4], defined_msg, defined_version)
    assert defined_msg == d._msg
    assert defined_version == d._version
    for i in range(len(d._value)):
        assert d[i] == d._value[i]

del config

# Generated at 2022-06-22 19:32:27.551834
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import io
    import sys
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    value = [1]
    msg = 'Deprecated'
    version = '2.9'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    try:
        assert dsc[0] == 1
        assert sys.stderr.getvalue() == '[DEPRECATED] Deprecated, to be removed in 2.9\n'
    finally:
        sys.stderr = old_stderr


# Generated at 2022-06-22 19:32:29.932622
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="0.0.0")) == 3

# Generated at 2022-06-22 19:32:38.439264
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import pytest
    # input and expected output

# Generated at 2022-06-22 19:32:42.171622
# Unit test for function set_constant
def test_set_constant():
    namespace = {}
    set_constant('KEY_ONE', 'foo', export=namespace)
    set_constant('KEY_TWO', 'baz', export=namespace)
    assert namespace == {'KEY_ONE': 'foo', 'KEY_TWO': 'baz'}

# Generated at 2022-06-22 19:32:51.629623
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _test_obj = _DeprecatedSequenceConstant(list(BOOLEANS_TRUE[0]), 'Test message for DeprecatedSequenceConstant', '1.0')
    assert isinstance(_test_obj, _DeprecatedSequenceConstant)
    assert len(_test_obj) == 1
    assert _test_obj[0] == BOOLEANS_TRUE[0]
    assert repr(_test_obj) == repr(_test_obj._value)

BOOL_TRUE = _DeprecatedSequenceConstant(BOOLEANS_TRUE, "BOOLEANS_TRUE is deprecated in favor of BOOLEANS_FALSE", '2.12')

# Generated at 2022-06-22 19:32:53.311112
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_length = 10
    test_object = _DeprecatedSequenceConstant([None for _ in range(test_length)], "", "")
    assert len(test_object) == test_length

# Generated at 2022-06-22 19:33:05.496289
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['test', 'test1']
    msg = 'This is a test'
    version = '2.14'

    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert isinstance(dsc, Sequence)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version

if __name__ == "__main__":
    import sys
    from ansible.parsing.utils.yaml import from_yaml

    settings = from_yaml("""
constants:
  boolean_true: [ true, yes, on, y, 1 ]
  deprecated_list:
    - c
    - c1
    - c2
""")


# Generated at 2022-06-22 19:33:16.151028
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    class _DeprecatedSequenceConstantTest(list, _DeprecatedSequenceConstant):

        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    # create a _DeprecatedSequenceConstantTest instance
    dsc = _DeprecatedSequenceConstantTest("value", "msg", "version")
    # test if the length of the dsc is equal to expected
    assert len(dsc) == 6  # expect len(_value) to be 6
    # test

# Generated at 2022-06-22 19:33:26.622646
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    msg = "This is a warning message for unit test."
    version = "2.11"
    l = [1, 2]
    c = _DeprecatedSequenceConstant(l, msg, version)
    assert l[1] == c[1]



# Generated at 2022-06-22 19:33:33.174585
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep = _DeprecatedSequenceConstant([3,4,5], 'This is not a test', '1.0')
    #len is defined for dep, so it should be true
    assert len(dep) == 3
    #getitem returns the value so it should be true
    assert dep[0] == 3

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:33:37.477895
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert d[0] == 'v'
    assert d[1] == 'a'

# Generated at 2022-06-22 19:33:46.962296
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', True, export=globals())
    assert 'TEST_CONSTANT' in globals()
    assert 'test_constant' not in globals()
    assert globals()['TEST_CONSTANT'] is True
    del globals()['TEST_CONSTANT']


# in order to avoid repeating the full config for every section,
# we seek to reuse as much of the definition as possible

# cut/paste from defaults to avoid needing to update multiple places
_CONN_DEFAULT_COMMON = 'ssh'
_CONN_DEFAULT_BSD = 'paramiko'
_CONN_DEFAULT_NETOPS = 'network_cli'
_CONN_DEFAULT_WINDOWS = 'winrm'

# cut/paste from defaults to avoid needing to update multiple places
_REM

# Generated at 2022-06-22 19:33:53.326397
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    foo = _DeprecatedSequenceConstant([1,2,3], "hello", "2.2")
    assert isinstance(foo, Sequence)



# Generated at 2022-06-22 19:34:02.163356
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_name = 'ansible.constants.DEFAULT_MODULE_PATH'
    assert _DeprecatedSequenceConstant([], '%s is deprecated' % class_name, '2.3')._value == []
    assert _DeprecatedSequenceConstant([1, 2, 3], '%s is deprecated' % class_name, '2.3')._msg == '%s is deprecated' % class_name
    assert _DeprecatedSequenceConstant([1, 2, 3], '%s is deprecated' % class_name, '2.3')._version == '2.3'

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:34:03.890742
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

# deprecated backwards compat

# Generated at 2022-06-22 19:34:08.718361
# Unit test for function set_constant
def test_set_constant():
    set_constant('test1', 'test1')
    set_constant('test2', 'test2', export=globals())
    set_constant('test3', 'test3', export={'test3': 'test3'})
    set_constant('test4', 'test4', export={})
    assert test1 != 'test1'
    assert test2 == 'test2'
    assert test3 != 'test3'
    assert test4 != 'test4'



# Generated at 2022-06-22 19:34:12.580046
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _constant = _DeprecatedSequenceConstant([1,2,3], "this is a test", "1.0")
    assert len(_constant) == 3


# Generated at 2022-06-22 19:34:21.548138
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    '''
    Unit test for constructor of class _DeprecatedSequenceConstant
    '''

    # Test no error occurs when the message is '%s'
    _DeprecatedSequenceConstant(range(10), '%s', '2.0')

    # Test error occurs when the message doesn't contain '%s'
    try:
        _DeprecatedSequenceConstant(range(10), '', '2.0')
    except ValueError as e:
        assert str(e) == 'msg must contain %s for the plugin name'
    else:
        raise AssertionError('Expected a ValueError to be raised')



# Generated at 2022-06-22 19:34:29.805349
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # arrange
    def mock_msg(msg, version):
        return '{msg} msg, to be removed in {version}'.format(msg=msg, version=version)

    sequence = tuple(['item1', 'item2', 'item3'])
    msg = 'Msg deprecation'
    version = '3.3'
    sequence_constant = _DeprecatedSequenceConstant(sequence, msg, version)

    expected = 'item1'
    expected_msg = mock_msg(msg, version)

    # act
    actual = sequence_constant[0]
    actual_msg = None

    # assert
    assert actual == expected
    assert actual_msg == expected_msg

# Generated at 2022-06-22 19:34:34.353178
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for invalid variable name
    ansible_action_plugins = _DeprecatedSequenceConstant(value=frozenset(), msg="", version="1.0")
    assert(len(ansible_action_plugins) == 0)


# Generated at 2022-06-22 19:34:38.903138
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_a', 1)
    set_constant('test_b', 2, export={})
    assert test_a == 1
    try:
        test_b
        raise AssertionError('test_b should not be defined')
    except NameError:
        pass

    export_dict = {}
    set_constant('test_b', 3, export=export_dict)
    assert export_dict['test_b'] == 3

# Generated at 2022-06-22 19:34:41.149883
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(list(range(2)), 'msg', 'version')
    assert len(a) == 2


# Generated at 2022-06-22 19:34:46.881224
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a_list = ['one', 'two', 'three']
    dsc = _DeprecatedSequenceConstant(a_list, 'msg', 'version')
    assert len(dsc) == len(a_list)


# Generated at 2022-06-22 19:34:50.878260
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = "Test message"
    version = "2.9"
    test_object = _DeprecatedSequenceConstant(value, msg, version)
    assert test_object[0] == 1
    assert test_object[1] == 2
    assert test_object == value


# Generated at 2022-06-22 19:35:00.367284
# Unit test for function set_constant
def test_set_constant():
    # test with no namespace
    namespace = {}
    set_constant('greeting', 'Hello', export=namespace)
    assert namespace['greeting'] == 'Hello'

    # test with namespace
    namespace = {}
    set_constant('greeting', 'Good Morning', export=namespace)
    assert namespace['greeting'] == 'Good Morning'

    # test changing the value
    namespace = {}
    set_constant('greeting', 'Hello', export=namespace)
    assert namespace['greeting'] == 'Hello'



# Generated at 2022-06-22 19:35:03.190889
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(list(range(10)), "msg", "version")
    assert len(c) == 10
    # Check that all members of _DeprecatedSequenceConstant are also members of Sequence
    assert set(dir(c)).issuperset(set(dir(Sequence())))

# Generated at 2022-06-22 19:35:11.195468
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    # Testing for True
    tmp_file = tempfile.NamedTemporaryFile()
    try:
        tmp_file_name = tmp_file.name
        set_constant('ANSIBLE_TEST_SET_CONSTANT_CONFIG', tmp_file_name)
        assert globals()['ANSIBLE_TEST_SET_CONSTANT_CONFIG'] == tmp_file_name
    finally:
        del globals()['ANSIBLE_TEST_SET_CONSTANT_CONFIG']
        tmp_file.close()

# Generated at 2022-06-22 19:35:16.659900
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    res = _DeprecatedSequenceConstant([1,2,3], msg='this is a test', version='2.9')
    assert(res._value == [1,2,3])
    assert(res._msg == 'this is a test')
    assert(res._version == '2.9')
    assert(len(res) == 3)
    assert(res[1] == 2)

# Generated at 2022-06-22 19:35:24.120602
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    class A:
        def write(self, x):
            sys.stdout.write(x + '\n')

    sys.stdout, sys.stderr = A(), A()

    obj = _DeprecatedSequenceConstant('value', 'msg', 'version')
    assert len(obj) == len('value')
    assert obj[0] == 'v'

    sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__

# Generated at 2022-06-22 19:35:31.192930
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3
    assert len(constant) == 3
    print("Test passed.")

if __name__ == "__main__":
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:35:35.805328
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = {'test_value': 'test_value'}
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    test_result = test_obj['test_value']
    assert test_result == 'test_value'


# Generated at 2022-06-22 19:35:38.810449
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    #arrange
    value = [1,2,3]
    msg = "msg"
    version = "version"

    #act
    seq = _DeprecatedSequenceConstant(value, msg, version)
    actual = len(seq)

    #assert
    assert len(value) == actual


# Generated at 2022-06-22 19:35:44.621915
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    except AssertionError:
        raise AssertionError('Unit test for method __getitem__ of class _DeprecatedSequenceConstant failed.')



# Generated at 2022-06-22 19:35:46.479843
# Unit test for function set_constant
def test_set_constant():
    set_constant("name", "value")
    assert name == "value"

# Generated at 2022-06-22 19:35:49.641172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.0')
    assert len(c) == 3
    assert c[1] == 2


# Generated at 2022-06-22 19:35:54.118101
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='This is a deprecated message', version='3.3')
    assert len(deprecated_sequence_constant) == 3

# Generated at 2022-06-22 19:36:00.048271
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_msg = 'msg'
    test_version = 'test version'
    test_sequence = ('test', 'sequence', 'to', 'index')
    test_index = 2
    test_sequence_constant = _DeprecatedSequenceConstant(test_sequence, test_msg, test_version)

    result = test_sequence_constant.__getitem__(test_index)
    assert result == test_sequence[test_index]

# Generated at 2022-06-22 19:36:03.873198
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_getitem_sequence_constant = _DeprecatedSequenceConstant([1, 2], 'test message', '2.10')
    assert test_getitem_sequence_constant[0] == 1
    assert test_getitem_sequence_constant[1] == 2


# Generated at 2022-06-22 19:36:15.599602
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def redirect_stdout(new_target):
        old_target, sys.stdout = sys.stdout, new_target  # replace sys.stdout
        try:
            yield new_target  # run some code with the replaced stdout
        finally:
            sys.stdout = old_target  # restore to the previous value

    s = StringIO()
    my_sequence = _DeprecatedSequenceConstant('TEST', 'TEST DEPRECATION', 'TEST VERSION')  # two objects

# Generated at 2022-06-22 19:36:21.393226
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([], "", "2.4")) == 0
    assert _DeprecatedSequenceConstant([1, 2, 3], "", "2.4")[0] == 1
    assert _DeprecatedSequenceConstant([1, 2], "", "2.5")[1] == 2

# Generated at 2022-06-22 19:36:25.633547
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_of_dicts = [{"test": "1"}]
    first = _DeprecatedSequenceConstant(list_of_dicts, "Message", "Version")
    assert len(list_of_dicts) == len(first)


# Generated at 2022-06-22 19:36:28.499889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant("value", "msg", "version")
    assert isinstance(x, Sequence)
    assert len(x) is 1
    assert x[0] == "value"


# Generated at 2022-06-22 19:36:31.948678
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    message = "Use 'var' instead of 'var2' in Ansible 2.0"
    version = '2.0'
    constant = _DeprecatedSequenceConstant(('abc',), message, version)
    assert len(constant) == 1
    assert constant[0] == 'abc'

# Generated at 2022-06-22 19:36:35.954793
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant(["test_sequence"], "This is test message", "2.8")
    assert len(d) == 1
    assert d[0] == "test_sequence"

# Generated at 2022-06-22 19:36:38.841474
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'bar')
    assert len(c) == 3

# Generated at 2022-06-22 19:36:42.329748
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result = _DeprecatedSequenceConstant(None, None, None)
    assert isinstance(result, _DeprecatedSequenceConstant)


# Generated at 2022-06-22 19:36:49.992803
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def function():
        pass

    tests = [
        (function, 'test', '10.0'),
        ([], 'test', '10.0'),
        ({}, 'test', '10.0'),
        ('', 'test', '10.0'),
    ]

    for test in tests:
        value = _DeprecatedSequenceConstant(test[0], test[1], test[2])
        if hasattr(value, '__getitem__'):
            value.__getitem__(0)

# Generated at 2022-06-22 19:36:53.990006
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    value = ('a', 'b', 'c')
    msg = 'test message'
    version = 'test version'

    t1 = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)

    assert len(t1) == len(value)


# Generated at 2022-06-22 19:37:06.622053
# Unit test for function set_constant
def test_set_constant():
    '''
    Tests function set_constant

    :return:
    '''
    from ansible.config.manager import ConfigManager, ConfigData, ConfigSetting
    from ansible.module_utils.common.collections import ImmutableDict

    config = ConfigManager()
    #FIXME: add tests for constants that are dependent on other constants
    c = ConfigData()
    c.add_setting(ConfigSetting('PERSISTENT_CONNECTION_PLUGINS', 'dummy, netconf', 'core', 'ini'))
    c.add_setting(ConfigSetting('NETCONF_SSH_PORT', '8642', 'core', 'ini'))
    config.set_config_data(c)

    constants = {}

    for setting in config.data.get_settings():
        value = setting.value

# Generated at 2022-06-22 19:37:12.020307
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for seq in ([], (), [1, 2, 3], (4, 5, 6)):
        seq_const = _DeprecatedSequenceConstant(seq, 'This is a deprecated constant', '2.10')
        assert len(seq) == len(seq_const)

# Generated at 2022-06-22 19:37:18.479343
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    warn = "Use 'ansible-config dump --only-changed' instead of 'ansible-config dump --check'."
    deprecated = _DEPRECATED_ALWAYS_MERGED = _DeprecatedSequenceConstant(_ALWAYS_MERGED, warn, '2.11')
    len_of_deprecated = len(deprecated)
    assert isinstance(len_of_deprecated, int)
    assert len_of_deprecated == len(_ALWAYS_MERGED)


# Generated at 2022-06-22 19:37:33.167371
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    set_constant('_TEST__DeprecatedSequenceConstant', ['foo', 'bar'], export=globals())
    assert len(_TEST__DeprecatedSequenceConstant) == 2
    assert _TEST__DeprecatedSequenceConstant[0] == 'foo'
    assert _TEST__DeprecatedSequenceConstant[1] == 'bar'

set_constant('_TEST_INTERNAL_RESULT_KEYS', _DeprecatedSequenceConstant(INTERNAL_RESULT_KEYS,
                                                                       'The INTERNAL_RESULT_KEYS constant is deprecated. '
                                                                       'Use RESULT_KEYS_WHITELIST instead.',
                                                                       '2.12'), export=globals())


# Generated at 2022-06-22 19:37:37.712500
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONST', 'test', {'ansible': dict(TEST_CONST='success')})
    assert 'success' not in globals()
    assert 'test' in globals()
    assert ansible['TEST_CONST'] == 'test'

# Generated at 2022-06-22 19:37:41.198791
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([], '', '')
    assert len(sequence) == 0

    sequence = _DeprecatedSequenceConstant([1, 3, 5], '', '')
    assert len(sequence) == 3



# Generated at 2022-06-22 19:37:44.511515
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Set up
    d = _DeprecatedSequenceConstant(['a'], "test", "2.0")

    # Exercise
    r = d[0]

    # Verify
    assert r == "a"

# Generated at 2022-06-22 19:37:45.755534
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(
        [],
        msg='test message',
        version='version',
    )
    assert len(sequence) == 0

# Generated at 2022-06-22 19:37:51.734944
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant(('0', '1', '2', '3'), 'test_msg', 'ansible-2.8')
    assert sequence_constant[0] == '0'
    assert sequence_constant[1] == '1'
    assert sequence_constant[2] == '2'
    assert sequence_constant[3] == '3'


# Generated at 2022-06-22 19:37:54.881897
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant((), 'msg', 'version')
    assert len(x) == 0
    x = _DeprecatedSequenceConstant((1,2,3), 'msg', 'version')
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3


# Generated at 2022-06-22 19:37:58.362317
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant(list(), 'message', '1.1'), _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:38:07.811233
# Unit test for function set_constant
def test_set_constant():
    import os
    from string import digits, ascii_letters
    set_constant('test', 'string', export=vars())
    assert 'test' in globals()
    assert test == 'string'
    del test
    set_constant('test', 1, export=vars())
    assert 'test' in globals()
    assert test == 1
    del test
    set_constant('test', [0, 1, 2], export=vars())
    assert 'test' in globals()
    assert test == [0, 1, 2]
    del test
    set_constant('test', (0, 1, 2), export=vars())
    assert 'test' in globals()
    assert test == (0, 1, 2)
    del test

# Generated at 2022-06-22 19:38:10.087113
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg="msg1", version="version1")) == 0


# Generated at 2022-06-22 19:38:22.829782
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _Test__DeprecatedSequenceConstant:
        from ansible.module_utils.common.collections import Sequence
        import re
        _regex = re.compile(r'^[\d\W]|[^\w]')
        data = _DeprecatedSequenceConstant(INVALID_VARIABLE_NAMES, 'this is a test message', 'this is a test version')

    assert isinstance(_Test__DeprecatedSequenceConstant.data, _Test__DeprecatedSequenceConstant.Sequence)
    assert hasattr(_Test__DeprecatedSequenceConstant.data, '_value')
    assert hasattr(_Test__DeprecatedSequenceConstant.data, '_msg')
    assert hasattr(_Test__DeprecatedSequenceConstant.data, '_version')

# Generated at 2022-06-22 19:38:26.373896
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(['test'], 'test warning', 'test version')
    assert 'test' in seq
test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:38:29.898704
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(['test'], 'test', 'test')
    assert test_obj[0] == 'test'


# Generated at 2022-06-22 19:38:37.265532
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import sys
    import unittest
    import unittest.mock

    if sys.version_info >= (3, 0):
        import io
        stdout = io.StringIO()
    else:
        stdout = None

    @unittest.mock.patch('sys.stdout', new=stdout)
    def _test__DeprecatedSequenceConstant___len__():
        # preceding import needed to mock sys.stdout
        import sys
        import ansible.constants
        c = ansible.constants._DeprecatedSequenceConstant([1, 2], msg='this is a test', version='2.8')
        l = len(c)
        assert l == 2

        got_warning = False

# Generated at 2022-06-22 19:38:40.504716
# Unit test for function set_constant
def test_set_constant():
    global COLOR_CODES
    set_constant('COLOR_CODES', {'test': '1'})
    assert COLOR_CODES == {'test': '1'}

# Generated at 2022-06-22 19:38:43.973136
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    data = ('1', '2')
    value = _DeprecatedSequenceConstant(data, 'msg', '1.0')
    assert len(value) == len(data)
    assert value[0] == data[0]

# Generated at 2022-06-22 19:38:49.634463
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant('test', 'msg', '1.2')
    if obj.__len__() == 4:
        print("Unit test test__DeprecatedSequenceConstant___len__ is OK.")
    else:
        print("Unit test test__DeprecatedSequenceConstant___len__ is NOT OK.")


# Generated at 2022-06-22 19:38:53.360577
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d_string = _DeprecatedSequenceConstant(["ansible"], "this is a test warning message", "2.10")
    assert len(d_string) == 1
    assert d_string[0] == 'ansible'

# Generated at 2022-06-22 19:39:04.401533
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'foo')
    assert globals()['FOO'] == 'foo'


if DEFAULT_PRIVATE_KEY_FILE:
    DEFAULT_PRIVATE_KEY_FILE = DEFAULT_PRIVATE_KEY_FILE.replace('~', '~/')

if DEFAULT_MODULE_PATH:
    DEFAULT_MODULE_PATH = [p.replace('~', '~/') for p in DEFAULT_MODULE_PATH]

# make sure this dict is always sorted in alphabetical order

# Generated at 2022-06-22 19:39:07.046826
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), 'msg', '1.0')) == 2


# Generated at 2022-06-22 19:39:10.578195
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'a', 'b')
    assert len(a) == 3, 'Length of _DeprecatedSequenceConstant is not 3'
    assert a[0] == 1, 'First element of _DeprecatedSequenceConstant is not 1'

# Generated at 2022-06-22 19:39:19.245428
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'foo')
    assert test == 'foo'
    set_constant('test', 'bar')
    assert test == 'bar'
    set_constant('test2', 'foobar')
    assert test2 == 'foobar'
    set_constant('test', 'foo', vars(config))
    assert test == 'foo'
    assert test2 == 'foobar'
    assert vars(config)['test'] == 'foo'
    assert vars(config)['test2'] == 'foobar'


# Generated at 2022-06-22 19:39:22.483570
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['homu','mami','mado'], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 'homu'

# Generated at 2022-06-22 19:39:31.048312
# Unit test for function set_constant
def test_set_constant():
    # try to override value of a constant string
    set_constant('RANDOM_PASSWORD_CHARS', 'some string')
    assert(RANDOM_PASSWORD_CHARS == DEFAULT_PASSWORD_CHARS)


# TODO: make this dynamic based on teams and unit tests

# Generated at 2022-06-22 19:39:35.505340
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for v in [None, '', 1, 3.14, [], [1], [1, 2], [1, 2, 3], range(10)]:
        assert len(v) == len(_DeprecatedSequenceConstant(v, 'msg', "2.11"))

# Generated at 2022-06-22 19:39:39.481229
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'bad!', '2.9')
    assert dsc.__getitem__(0) == 'a'



# Generated at 2022-06-22 19:39:49.702266
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.parsing.convert_bool import boolean
    a = set_constant('a', '1')
    assert a == [1]
    b = set_constant('b', '2')
    assert b == [2]
    c = set_constant('c', 'a')
    assert c == ['a']
    d = set_constant('d', 'b')
    assert d == ['b']
    e = set_constant('e', 'True')
    assert e == boolean(True)
    f = set_constant('f', 'False')
    assert f == boolean(False)
    g = set_constant('g', 'False')
    assert g == boolean(False)
    h = set_constant('h', 'True')
    assert h == boolean(True)

# Generated at 2022-06-22 19:39:55.241725
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    set_constant('DEPRECATED_FOO', _DeprecatedSequenceConstant([], "msg", "version"))
    set_constant('DEPRECATED_FOO', _DeprecatedSequenceConstant([], "msg2", "version2"))
    assert len(DEPRECATED_FOO) == len(DEPRECATED_FOO)


# Generated at 2022-06-22 19:39:58.337370
# Unit test for function set_constant
def test_set_constant():
    assert len(DEFAULT_VAULT_PASSWORD_FILE) == 0
    assert DEFAULT_TIMEOUT == 10
    assert DEFAULT_REMOTE_PASS == 'password'


# Generated at 2022-06-22 19:40:01.290919
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='deprecated', version='1.1.1')
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3


# Generated at 2022-06-22 19:40:06.343710
# Unit test for function set_constant
def test_set_constant():
    TEST_CONSTANT_NAME = 'ANSIBLE_TEST_CONSTANT'
    TEST_CONSTANT_VALUE = 'ANSIBLE_TEST_CONSTANT_VALUE'
    set_constant(TEST_CONSTANT_NAME, TEST_CONSTANT_VALUE)
    assert TEST_CONSTANT_NAME in globals()
    assert globals()[TEST_CONSTANT_NAME] == TEST_CONSTANT_VALUE


# Generated at 2022-06-22 19:40:14.862025
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_cases = [
        ([], 1, '', ''),
        ([1, 2, 3], 1, 'msg', 'version'),
        (1, 1, 'msg', 'version'),
    ]

    for case in test_cases:

        value = case[0]
        key = case[1]
        msg = case[2]
        version = case[3]

        deprec_seq = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)

        assert deprec_seq[key] == value[key]

# Generated at 2022-06-22 19:40:23.572511
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check __init__()
    t = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', '2.10')
    assert(t._value == [1, 2, 3])
    assert(t._msg == 'test msg')
    assert(t._version == '2.10')

    # Check __len__()
    len_t_1 = len(t)
    len_t_2 = len(t)
    assert(len_t_1 == len_t_2 == 3)

    # Check __getitem__()
    assert(t[0] == 1)
    assert(t[1] == 2)
    assert(t[2] == 3)

# Generated at 2022-06-22 19:40:35.345611
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This method is deprecated"
    version = "2.9"
    value = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(value) == 3
    assert value[0] == 'a'
    assert value[1] == 'b'
    assert value[2] == 'c'


# NOTE: this doesn't work with @add_internal_fqcns.  I don't think it's needed, because
#       the names here are only used here, so maybe it doesn't matter if they're ambiguous?
#       if we ever try to import these using dot notation, they'd get the 'internal' fqcn,
#       which would be fine there.

MAGIC_VARIABLE_MAPPING['network_user'] = MAGIC_VARIABLE_