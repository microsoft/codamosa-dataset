

# Generated at 2022-06-22 19:30:36.983112
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ''' Check if class _DeprecatedSequenceConstant has been created '''
    class_name = '_DeprecatedSequenceConstant'
    msg = 'This is a test'
    version = '1.0'
    value = ['test1', 'test2']

    # create new instance of class _DeprecatedSequenceConstant
    test_class = _DeprecatedSequenceConstant(value, msg, version)
    # Check if class is instance of class _DeprecatedSequenceConstant
    assert(isinstance(test_class, _DeprecatedSequenceConstant))

    # Test __len__ function
    len(test_class)
    # Test __getitem__ function
    test_class[0]

# Run unit test
test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:30:45.059464
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # test that it returns len and returns warning
    test = _DeprecatedSequenceConstant(
        value=['a', 'b', 'c'],
        msg='test message',
        version='2.0'
    )

    # We import '_deprecated' here because we don't want to interfere with the test run of this file
    import ansible.constants
    import mock
    import sys

    test_stderr = mock.MagicMock()
    with mock.patch.dict(ansible.constants.__dict__, {'_deprecated': test_stderr}):
        len(test)

    # Test that it returns 3
    assert len(test) == 3

    # Test that it returns warning

# Generated at 2022-06-22 19:30:56.376712
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    for k in ('directory', 'inventory_directory', 'remote_tmp'):
        assert getattr(defaults, k) is not None
        assert isinstance(getattr(defaults, k), string_types)

    assert defaults.active_plugins is not None
    assert isinstance(defaults.active_plugins, list)

    assert defaults.default_vars is not None
    assert isinstance(defaults.default_vars, list)

    assert defaults.hash_behaviour is not None
    assert isinstance(defaults.hash_behaviour, string_types)

    assert defaults.new_vault_password_file is not None

# Generated at 2022-06-22 19:30:59.416537
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(sequence_constant) == 3

# Generated at 2022-06-22 19:31:09.222219
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for method __len__(...) of class _DeprecatedSequenceConstant
    # Returns 0/len of value on call, and also calls _deprecated, but only
    # once
    # Causes the _DeprecatedSequenceConstant class to print the
    # Deprecated warning
    # message, but only once.
    c = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(c) == 3

    # Causes the _DeprecatedSequenceConstant class to print the
    # Deprecated warning
    # message, but only once.
    assert len(c) == 3



# Generated at 2022-06-22 19:31:11.839097
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant((1,2,3), 'foo', '2.0')[2]

# Generated at 2022-06-22 19:31:15.910669
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "A sequence", "1.1")
    assert len(seq) == 3


# Generated at 2022-06-22 19:31:21.103277
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(ANSIBLE_DEBUG, bool)
    assert isinstance(ANSIBLE_CONFIG, string_types)
    assert isinstance(ANSIBLE_PYTHON_INTERPRETER, string_types)
    assert isinstance(ANSIBLE_REMOTE_TEMP, string_types)

test_set_constant()

# Generated at 2022-06-22 19:31:24.118330
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', 'test version')[1] == 'b'

# Generated at 2022-06-22 19:31:28.540616
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(('one', 'two', 'three'), 'foo', '2.12')
    assert dsc.__getitem__(1) == 'two'
    assert dsc[1] == 'two'



# Generated at 2022-06-22 19:31:36.089020
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    def test_getitem(self, x):
        return self._value[x]

    def test_len(self):
        return len(self._value)

    class MyClass:
        getitem = test_getitem
        len = test_len

    # test when the correct message is displayed
    dep_constant = _DeprecatedSequenceConstant([0, 1, 2], 'Something is deprecated.', '2.9')
    MyClass.getitem(dep_constant, 1)
    MyClass.len(dep_constant)
    assert dep_constant[1] == 1
    assert len(dep_constant) == 3

    # test when the correct message is displayed when DEPRECATION_WARNINGS is enabled

# Generated at 2022-06-22 19:31:41.097644
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1)
    set_constant('b', 2)
    set_constant('c', 3, vars())
    assert vars()['a'] == 1
    assert vars()['b'] == 2
    assert 'c' not in vars()
    assert vars()['c'] == 3

# Generated at 2022-06-22 19:31:44.356409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([], '', '1.0')
    assert len(sequence) == 0


# Generated at 2022-06-22 19:31:50.397178
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ''' test the constructor of class _DeprecatedSequenceConstant'''
    value = ['test']
    msg = 'test deprecated message'
    version = 'testversion'
    dep = _DeprecatedSequenceConstant(value, msg, version)
    assert dep._value == ['test']
    assert dep._msg == 'test deprecated message'
    assert dep._version == 'testversion'

# Generated at 2022-06-22 19:31:54.515215
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    instance_of_class_under_test = _DeprecatedSequenceConstant(['foo', 'bar'], 'message', 'version')

    assert 1 == len(instance_of_class_under_test)
    assert 2 == len(instance_of_class_under_test)

# Generated at 2022-06-22 19:32:00.970474
# Unit test for function set_constant
def test_set_constant():
    exported = {}
    set_constant('value1', '2', exported)
    assert exported['value1'] == '2'

    exported = {}
    set_constant('value1', 2, exported)
    assert exported['value1'] == 2

    exported = {}
    set_constant('value1', '2', exported)
    exported['value15'] = '3'
    set_constant('value1', '15', exported)
    assert exported['value1'] == '15'
    assert exported['value15'] == '3'

# REPLACEMENTS FOR INI SETTINGS ###
# If a setting name changes, we can add a new value to the tuple, and point to it
# in the docs via the ACI.

# TODO: The constants defined here should be moved out as they don't make sense in the config

# Generated at 2022-06-22 19:32:11.615273
# Unit test for function set_constant
def test_set_constant():
    ''' only run this test if we are in the unit test environment '''
    import os
    import sys
    if os.environ.get('_ANSIBLE_TEST_', None):
        fake_constants = {}
        set_constant('FAKE_CONSTANT', 'fake_value', fake_constants)
        assert fake_constants['FAKE_CONSTANT'] == 'fake_value'
        sys.modules[__name__].set_constant = set_constant

MAGIC_VARIABLE_MAPPING.update({'SUBSET': DEFAULT_SUBSET})
MAGIC_VARIABLE_MAPPING.update({'BECOME_PASS': DEFAULT_BECOME_PASS})

# Generated at 2022-06-22 19:32:15.577500
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 'b', locals())
    assert a == 'b'
    assert locals()['a'] == 'b'
    set_constant('c', 'd', dict(a='c'))
    assert 'c' == dict(a='c')['c']

# Generated at 2022-06-22 19:32:18.099145
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq1 = _DeprecatedSequenceConstant([], "test")
    assert len(seq1) == 0
    seq2 = _DeprecatedSequenceConstant([1, 2, 3], "test")
    assert len(seq2) == 3

# Generated at 2022-06-22 19:32:25.514069
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR == 'True'
    assert ANSIBLE_HOST_KEY_CHECKING == 'True'
    assert ANSIBLE_SSH_PIPELINING == 'True'
    assert ANSIBLE_DEPRECATION_WARNINGS == 'True'
    assert DEFAULT_MODULE_NAME == 'command'
    assert DEFAULT_SUDO_USER == 'root'
    assert DEFAULT_MODULE_PATH == '~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules'

# Generated at 2022-06-22 19:32:28.426504
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    lst = ['a', 'b']
    lst = _DeprecatedSequenceConstant(lst, 'msg', 'version')
    assert len(lst) == 2

# Generated at 2022-06-22 19:32:34.634510
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_instance = _DeprecatedSequenceConstant(
        value=[True, False, True],
        msg="MsgTest",
        version="1.4.0"
    )
    if test_instance[0] != True:
        return False

    if test_instance[1] != False:
        return False

    if test_instance[2] != True:
        return False

    return True


# Generated at 2022-06-22 19:32:38.102253
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    seq = (1, 2, 3, 4)
    dsc = _DeprecatedSequenceConstant(seq, msg, version)
    assert dsc[1] == 2


# Generated at 2022-06-22 19:32:40.242464
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(('a', ), 'msg', 'version')
    assert len(a) == 1


# Generated at 2022-06-22 19:32:42.362079
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant('string', 'msg', 'version')
    assert dsc[0] == 's'

# Generated at 2022-06-22 19:32:45.423425
# Unit test for function set_constant
def test_set_constant():
    export = {}
    test_val = ('test', )
    set_constant('test', test_val, export)
    assert 'test' in export
    assert export['test'] == test_val



# Generated at 2022-06-22 19:32:50.587106
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('TEST_CONSTANT', 'TEST_VALUE', export=export)
    assert export['TEST_CONSTANT'] == 'TEST_VALUE'
    assert export['TEST_CONSTANT'] == config.get_config_value('TEST_CONSTANT')

# Generated at 2022-06-22 19:32:51.456401
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    empty = _DeprecatedSequenceConstant(value=[], msg='', version='')
    assert empty[0] == []

# Generated at 2022-06-22 19:32:53.802494
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # getitem
    result = _DeprecatedSequenceConstant('value', 'msg', 'ver').__getitem__(0)
    assert result == 'value'



# Generated at 2022-06-22 19:32:57.537836
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1,2,3], "Testing deprecated message 1.", "2.8")) == 3
    assert _DeprecatedSequenceConstant([1,2,3], "Testing deprecated message 2.", "2.7")[0] == 1


# Generated at 2022-06-22 19:33:04.097948
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj_1 = _DeprecatedSequenceConstant([], 'This is fake message.', '1.0.0')
    assert isinstance(test_obj_1, _DeprecatedSequenceConstant)
    assert len(test_obj_1) == 0
    assert isinstance(test_obj_1[0], type(None))

# Generated at 2022-06-22 19:33:08.991405
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['foo', 'bar', 'baz']
    msg = "Deprecated message. This is a test"
    version = '2.0'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc == value
    assert len(dsc) == 3

# Generated at 2022-06-22 19:33:11.458556
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('a', 1.0) == 1.0
    assert set_constant('b', 'foo') == 'foo'

# Generated at 2022-06-22 19:33:15.877139
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'test message', '1.0').__len__() == 2
    assert _DeprecatedSequenceConstant((1, 2), 'test message', '1.0').__len__() == 2

# Generated at 2022-06-22 19:33:18.761409
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['foo'], 'warning message', 'version')
    assert len(dsc) == 1
    assert dsc[0] == 'foo'

# Generated at 2022-06-22 19:33:21.359047
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version'), Sequence)

# Generated at 2022-06-22 19:33:25.206024
# Unit test for function set_constant
def test_set_constant():
    exec('set_constant("TEST_CONSTANT", "test")')
    assert 'TEST_CONSTANT' in vars()
    assert vars()['TEST_CONSTANT'] == 'test'
    del vars()['TEST_CONSTANT']

# Generated at 2022-06-22 19:33:27.441742
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test():
        def __init__(self):
            self.msg = 'test'
            self.version = '1.2.3'

        def __len__(self):
            return 5

    t = Test()
    assert len(_DeprecatedSequenceConstant(t, t.msg, t.version)) == 5

# Generated at 2022-06-22 19:33:29.869904
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = '0.0.0'
    c = _DeprecatedSequenceConstant(('foo', ), msg, version)

    assert c[0] == 'foo'

    try:
        c[1]
    except IndexError:
        pass
    else:
        assert False



# Generated at 2022-06-22 19:33:32.858599
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(['a', 'b'], 'not to long', '2.9')
    assert x.__getitem__(0) == 'a'

# Generated at 2022-06-22 19:33:38.783446
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant([], 'test warning', 'ANSIBLE 2.0')

    # check if the value has expected type
    assert isinstance(value, Sequence)

    # check if warning is triggered
    assert len(value)
    assert value[0]

# Generated at 2022-06-22 19:33:39.780396
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    return


# Generated at 2022-06-22 19:33:42.279608
# Unit test for function set_constant
def test_set_constant():
    tmp_dict = {}
    set_constant('FOO', "foo", export=tmp_dict)
    assert tmp_dict['FOO'] == "foo"

# Generated at 2022-06-22 19:33:43.972919
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant("a", "msg", "version")
    assert constant[0] == "a"


# Generated at 2022-06-22 19:33:45.058782
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_SUBSET == "all"

# END CONSTANTS

# Generated at 2022-06-22 19:33:46.506726
# Unit test for function set_constant
def test_set_constant():
    setup = {}
    set_constant("foo", "bar", setup)
    assert setup["foo"] == "bar"

# Generated at 2022-06-22 19:33:52.063464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = ('', '', '')
    msg = "msg"
    version = "version"
    deprecated = _DeprecatedSequenceConstant(seq, msg, version)
    assert len(deprecated) == 3
    assert deprecated[0] == ''
    assert deprecated[1] == ''
    assert deprecated[2] == ''


# Generated at 2022-06-22 19:33:54.346046
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), "msg", "1.0")) == 3

# Generated at 2022-06-22 19:33:55.866172
# Unit test for function set_constant
def test_set_constant():
    set_constant('EXAMPLE_CONSTANT', 1234, export=globals())
    assert EXAMPLE_CONSTANT == 1234

# Generated at 2022-06-22 19:34:06.205140
# Unit test for function set_constant
def test_set_constant():
    # Test that a constant is set and retrievable
    try:
        set_constant('ANSIBLE_TEST_SET_CONSTANT', 'a_value')
        assert ANSIBLE_TEST_SET_CONSTANT == 'a_value'
        del(ANSIBLE_TEST_SET_CONSTANT)
    except AssertionError:
        raise AssertionError('Unable to set and access a constant using set_constant')

    # Test that constants can be overwritten

# Generated at 2022-06-22 19:34:09.801653
# Unit test for function set_constant
def test_set_constant():
    set_constant("TEST_VAR", "Hello world")
    assert 'TEST_VAR' in globals()


# Generated at 2022-06-22 19:34:14.578474
# Unit test for function set_constant
def test_set_constant():
    ''' verify that setting constants in the ansible namespace works as
    expected '''
    set_constant('FOO', 'bar')
    assert FOO == 'bar'


# FIXME: no longer needed once we remove play_context mangling

# Generated at 2022-06-22 19:34:25.864581
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.3')
    try:
        len(obj)
        getattr(obj, 1)
        assert True
    except Exception:
        assert False

# Override the above constants as needed via environment
# variables. This must be done after config population because
# environment variable values should override config file values.
config = ConfigManager()
for setting in config.data.get_settings():
    if setting.env:
        env_var = setting.env.upper().replace('.', '_')
        if env_var in os.environ:
            set_constant(setting.name, ensure_type(os.environ[env_var], setting.type))

# Generated at 2022-06-22 19:34:30.107906
# Unit test for function set_constant
def test_set_constant():
    constant = {}
    set_constant('FOO', 'foo', constant)
    # Assertions must be == for comparisons with boolean truth values
    assert constant == {'FOO': 'foo'}
    assert constant['FOO'] == 'foo'

# Generated at 2022-06-22 19:34:35.270519
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert test_object._value == [1, 2, 3]
    assert test_object._msg == "msg"
    assert test_object._version == "version"


# Generated at 2022-06-22 19:34:40.412176
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert 2 == len(d)
    d = _DeprecatedSequenceConstant('abc', 'msg', 'version')
    assert 3 == len(d)


# Generated at 2022-06-22 19:34:42.451382
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'A', '1.3')) == 2

# Generated at 2022-06-22 19:34:44.303376
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')
    assert d[0] == 'a'
    assert d[1] == 'b'


# Generated at 2022-06-22 19:34:49.700191
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    seq = _DeprecatedSequenceConstant(('foo', 'bar'), 'Test warning', '2.1')

    assert seq[0] == 'foo'
    assert seq[1] == 'bar'
    assert len(seq) == 2




# Generated at 2022-06-22 19:34:52.951719
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert c[0] == 1


# Generated at 2022-06-22 19:35:04.412802
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test __getitem__ of class _DeprecatedSequenceConstant (callable object)

    msg = 'test_message'

    version = 'version_1_1'

    # Test __getitem__ of class _DeprecatedSequenceConstant (callable object)
    # Create an object _DeprecatedSequenceConstant
    constant = _DeprecatedSequenceConstant(value=[1, 2, 3], msg=msg, version=version)

    # Test __getitem__ of class _DeprecatedSequenceConstant (callable object)
    # Call function __getitem__ of class _DeprecatedSequenceConstant
    assert constant[0] == 1

    # Test __getitem__ of class _DeprecatedSequenceConstant (callable object)
    # Call function __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 19:35:15.722906
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', True)
    assert test_constant
    del test_constant
    assert not 'test_constant' in globals()

# TODO: this needs to be moved to somewhere where it can be overriden, perhaps
# to be a setting or plugin.  The problem here is that a vault password file
# needs to be used only once after which it must be regenerated.  However,
# there is no way to guarantee this in a forked/threaded environment.
# Until that is solved, we are basically disabling the use of vault in
# forked/threaded environments.
#
# def vault_password_should_be_regenerated():
#     return multiprocessing.current_process()._identity[0] == 1

# make sure argv is properly set for multiprocessing forks

# Generated at 2022-06-22 19:35:19.995003
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3


# Generated at 2022-06-22 19:35:23.933298
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    teststr = _DeprecatedSequenceConstant([1, 2, 3], 'this is a test', version='2.9')
    assert teststr == [1, 2, 3]
    assert teststr[2] == 3
    assert len(teststr) == 3


del config

# Generated at 2022-06-22 19:35:27.015164
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.3')
    assert len(d) == 3
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3

# Generated at 2022-06-22 19:35:31.240646
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1), msg='Hello', version='1.1.1')) == 1
    assert len(_DeprecatedSequenceConstant((), msg='Hello', version='1.1.1')) == 0



# Generated at 2022-06-22 19:35:33.545804
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'test'
    version = '1.0'
    assert len(_DeprecatedSequenceConstant((1, 2), msg, version)) == 2

# Generated at 2022-06-22 19:35:40.863082
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common.collections import ImmutableDict
    new_dict = {}
    set_constant('my_value', 'goodbye', new_dict)
    assert new_dict['my_value'] == 'goodbye'

    set_constant('my_value', 2, new_dict)
    assert new_dict['my_value'] == 2

    set_constant('my_value', '{{template}}', new_dict)
    assert new_dict['my_value'] == '{{template}}'

    set_constant('my_value', '{{my_value}}', new_dict)
    assert new_dict['my_value'] == '{{my_value}}'

    set_constant('ansible_version', '{{ansible_version}}', new_dict)

# Generated at 2022-06-22 19:35:53.153231
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from collections import Sequence
    import sys
    import io

    import pytest
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    mocked_stdout = io.StringIO()
    sys.modules[__name__].sys.stderr = mocked_stdout

    # check __getitem__ with good msg, good version, gets
    dsc1 = _DeprecatedSequenceConstant(BOOLEANS_TRUE, 'test_message', 'test_version')
    ret = dsc1[0]
    assert ret == 'true'
    assert mocked_stdout.getvalue().endswith(' [DEPRECATED] test_message, to be removed in test_version\n')

    # check __getitem__ with good msg, bad version, error

# Generated at 2022-06-22 19:35:55.867999
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list = ['b', 'a', 'l', 'l']
    a = _DeprecatedSequenceConstant(list, 'msg', 'version')
    assert len(a) == len(list)


# Generated at 2022-06-22 19:36:04.646937
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Test that _DeprecatedSequenceConstant returns the deprecated value in its constant
    _DeprecatedSequenceConstant_constant = _DeprecatedSequenceConstant(['a_string'], "Depreciation message", "2.0")
    assert _DeprecatedSequenceConstant_constant[0] == 'a_string'

    # Test that _DeprecatedSequenceConstant returns the deprecated value in its constant
    # EVEN when accessing a list of lists
    _DeprecatedSequenceConstant_constant = _DeprecatedSequenceConstant([['a_string']], "Depreciation message", "2.0")
    assert _DeprecatedSequenceConstant_constant[0][0] == 'a_string'

# Generated at 2022-06-22 19:36:12.274302
# Unit test for function set_constant
def test_set_constant():
    test_1 = dict()
    test_2 = dict()
    test_3 = dict()

    set_constant('key_one', 'value one', export=test_1)
    set_constant('key_two', 'value two', export=test_2)
    set_constant('key_three', 'value three')

    assert test_1['key_one'] == 'value one'
    assert test_2['key_two'] == 'value two'
    assert test_3['key_three'] == 'value three'

# Generated at 2022-06-22 19:36:15.496251
# Unit test for function set_constant
def test_set_constant():
    global TEST_VAR
    set_constant('TEST_VAR', 'foo')
    assert TEST_VAR == 'foo'



# Generated at 2022-06-22 19:36:20.138973
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    message = 'message'
    version = 'version'
    mylist = [1, 2, 3]
    t = _DeprecatedSequenceConstant(mylist, message, version)

    assert len(t) == len(mylist)
    assert t[1] == mylist[1]

# Generated at 2022-06-22 19:36:28.286599
# Unit test for function set_constant
def test_set_constant():
    def test_export(name, value):
        return globals()['test_export'][name] == value

    globals()['test_export'] = {}

    set_constant('test', 'success', export=globals()['test_export'])
    assert test_export('test', 'success') is True

    globals()['test_export'] = {}

    set_constant('test', '{{ ansible_version }}', export=globals()['test_export'])
    assert test_export('test', __version__) is True

test_set_constant()

del config

# Generated at 2022-06-22 19:36:35.999745
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check __len__ and __getitem__ of the class
    dsc = _DeprecatedSequenceConstant(['Not', 'LOL'], 'msg', 'version')
    assert len(dsc) == 2
    assert dsc[0] == 'Not'
    assert dsc[1] == 'LOL'
    # Assert that the DeprecationWarning has been thrown
    import warnings
    with warnings.catch_warnings(record=True) as w:
        dsc = _DeprecatedSequenceConstant([], 'msg', 'version')
        len(dsc)
        dsc[0]
        assert len(w) == 2
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "msg" in str(w[-1].message)

# Generated at 2022-06-22 19:36:39.348351
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seqconst = _DeprecatedSequenceConstant((1,2,3,4,5), 'test message', '2.10')
    assert seqconst[1] == 2

# Generated at 2022-06-22 19:36:44.963141
# Unit test for function set_constant
def test_set_constant():
    set_constant('key1', 'value1')
    assert 'value1' == globals()['key1']

    set_constant('key2', 'value2', export={'key2': 'not_value2'})
    assert 'value2' == export['key2']



# Generated at 2022-06-22 19:36:46.915819
# Unit test for function set_constant
def test_set_constant():
    value = 'bar'
    set_constant('foo', value)
    assert value == 'bar'

# Generated at 2022-06-22 19:36:49.554622
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], msg='this is a test object', version='2.9')


# Generated at 2022-06-22 19:36:57.640031
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass


# Generated at 2022-06-22 19:37:01.270049
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    name = u'name'
    msg = u'message'
    version = u'2.0'
    constant = _DeprecatedSequenceConstant(42, msg, version)
    assert constant[0] == 42

# Generated at 2022-06-22 19:37:08.168554
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import pytest

    sequence_constant = _DeprecatedSequenceConstant((1,2,3), 'message', 'version')
    assert len(sequence_constant) == 3
    for i in range(len(sequence_constant)):
        assert sequence_constant[i] == (i + 1)
    with pytest.raises(TypeError):
        sequence_constant[0:1] = (4,)
    with pytest.raises(TypeError):
        del sequence_constant[0]


# Generated at 2022-06-22 19:37:12.842602
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    ds = _DeprecatedSequenceConstant([1, 2, 3], 'test message', '2.2')
    assert ds[2] == 3, 'test__DeprecatedSequenceConstant___getitem__ has failed'


# Generated at 2022-06-22 19:37:18.391162
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """
    Test for _DeprecatedSequenceConstant.__getitem__()
    """
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[-1] == 'c'
    assert dsc[0:1] == ('a',)



# Generated at 2022-06-22 19:37:33.168606
# Unit test for function set_constant
def test_set_constant():
    for test_value in [2, 2.0, '2', u'2', '2.0', u'2.0']:
        set_constant('test_value', test_value)
        assert type(test_value) == type(config.test_value)

    test_value = '{{ ansible_distribution }}'
    set_constant('test_value', test_value)
    assert type(config.test_value) == type(config.distribution)

    test_value = '{{ ansible_version }}'
    set_constant('test_value', test_value)
    assert type(config.test_value) == type(config.version)

    test_value = '{{ ansible_python_version }}'
    set_constant('test_value', test_value)

# Generated at 2022-06-22 19:37:35.273699
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(value=list(), msg='this is a test', version='2.8')
    assert len(seq) == 0

# Generated at 2022-06-22 19:37:40.232901
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dc = _DeprecatedSequenceConstant(['a','b','c'], 'testing', '1.0')
    assert dc[1] == 'b'
    assert dc[2] == 'c'
    assert dc[-1] == 'c'
    try:
        dc[3]
    except IndexError as e:
        assert "out of range" in str(e)

# Generated at 2022-06-22 19:37:52.022215
# Unit test for function set_constant
def test_set_constant():
    global DEFAULT_HOST_LIST
    # Check if there is any exception thrown
    set_constant("DEFAULT_HOST_LIST", ["[::1]", "localhost"], locals())
    # Check if the constant set properly
    assert DEFAULT_HOST_LIST == "[::1],localhost"
    # Check if the constant still works after update
    set_constant("DEFAULT_HOST_LIST", "localhost", locals())
    assert DEFAULT_HOST_LIST == "localhost"

    class MyClass:
        pass

    export = MyClass()
    set_constant("DEFAULT_HOST_LIST", "localhost", export)
    assert export.DEFAULT_HOST_LIST == "localhost"

test_set_constant()

# FIXME: remove once play_context mangling is removed
OLDSTYLE_IN

# Generated at 2022-06-22 19:37:54.057529
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant('foo', 'bar', 'baz')
    assert len(obj) == 3


# Generated at 2022-06-22 19:37:57.656167
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test for get item
    test_seq = _DeprecatedSequenceConstant(('test_item', ), 'test', '2.1')
    assert test_seq[0] == 'test_item'
    # test for negative index
    assert test_seq[-1] == 'test_item'

# Generated at 2022-06-22 19:38:04.817243
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    expected_msg = None
    expected_version = None
    expected_value = ['test_value']
    obj = _DeprecatedSequenceConstant(expected_value, expected_msg, expected_version)

    actual_msg = obj._msg
    assert actual_msg == expected_msg

    actual_version = obj._version
    assert actual_version == expected_version

    actual_value = obj._value
    assert actual_value == expected_value

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:38:09.351883
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import random
    from string import ascii_letters

    for x in range(0, 100):
        length = random.randint(1, 10)
        seq = [random.choice(ascii_letters) for _ in range(length)]
        assert len(_DeprecatedSequenceConstant(seq, '', '2.9')) == length

# Generated at 2022-06-22 19:38:11.763585
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    some_list = [1, 2, 3, 4]
    msg = "Some message"
    version = "1.0"
    seq_const = _DeprecatedSequenceConstant(some_list, msg, version)

    assert len(some_list) == len(seq_const)


# Generated at 2022-06-22 19:38:15.842465
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3



# Generated at 2022-06-22 19:38:27.307706
# Unit test for function set_constant
def test_set_constant():
    assert vars().pop("VAR_WITH_VALUES", None) is None
    set_constant("VAR_WITH_VALUES", (1,2,3))
    assert vars().pop("VAR_WITH_VALUES", None) == (1,2,3)
    set_constant("VAR_WITH_VALUES", (4,5,6), locals())
    assert locals().pop("VAR_WITH_VALUES", None) == (4,5,6)
    try:
        set_constant("VAR_WITH_VALUES", (4,5,6), None)
    except TypeError:
        pass
    else:
        assert False, "'export' expected to be None"

# CONSTANT DECLARATIONS ###


# Generated at 2022-06-22 19:38:31.779261
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert seq[0] == 'a'
    assert seq[2] == 'c'
    assert seq[-1] == 'c'



# Generated at 2022-06-22 19:38:38.115336
# Unit test for function set_constant
def test_set_constant():
    ret = set_constant('ANSIBLE_TEST1', True)
    assert ret is None, 'The function must return None.'
    ret = set_constant('ANSIBLE_TEST2', False)
    assert ret is None, 'The function must return None.'
    assert ANSIBLE_TEST1 is True, 'ANSIBLE_TEST1 should be True.'
    assert ANSIBLE_TEST2 is False, 'ANSIBLE_TEST1 should be False.'

# Generated at 2022-06-22 19:38:45.835237
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    old_stdout = sys.stdout
    result = io.StringIO()
    sys.stdout = result

    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test message', '2.10')

    # Test __getitem__
    test_value = sequence_constant[0]
    assert test_value == 1

    # Assert we get the deprecation message
    assert '[DEPRECATED] test message, to be removed in 2.10' in result.getvalue()

    # Reset stdout
    sys.stdout = old_stdout

# Generated at 2022-06-22 19:38:54.527012
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    class Test_Stderr():
        def __init__(self):
            self.messages = []
        def write(self, msg):
            self.messages.append(msg)
    original_stderr = sys.stderr
    sys.stderr = Test_Stderr()
    message = "[DEPRECATED] The 'DeprecatedOption' option, to be removed in 2.14"
    version = '2.14'
    dsc = _DeprecatedSequenceConstant([1,2,3], message, version)
    assert len(sys.stderr.messages) == 0
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert len(sys.stderr.messages) == 3
    assert sys

# Generated at 2022-06-22 19:38:56.957931
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test(object):
        def __init__(self):
            self._value = ()
            self._msg = 'test'
            self._version = '0.0.0'

    test = Test()
    assert len(_DeprecatedSequenceConstant(test._value, test._msg, test._version)) == 0

# Generated at 2022-06-22 19:39:10.153338
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence

    # Verify class _DeprecatedSequenceConstant (call function __len__)
    def verify_class(_class):
        if isinstance(_class, Sequence) and hasattr(_class, '__len__'):
            len(_class)

            # check each class property
            for prop in _class.__dict__:
                # if prop is an embedded class, verify it
                if isinstance(_class.__dict__[prop], type):
                    verify_class(_class.__dict__[prop])
                # if prop is an embedded object, verify class of this object

# Generated at 2022-06-22 19:39:21.860276
# Unit test for function set_constant
def test_set_constant():
    ''' set_constant should ensure constants are set, and that the export kwarg works as expected '''
    orig_len = len(vars())
    local_vars = {}
    set_constant('dummy_const', 'dummy_const_value', local_vars)
    assert len(local_vars) == 1
    assert local_vars['dummy_const'] == 'dummy_const_value'
    assert len(vars()) == orig_len + 1
    assert vars()['dummy_const'] == 'dummy_const_value'


# values for configuration which should be numeric
# FIXME: put these in config schema and make ConfigManager do this conversion based on schema

# Generated at 2022-06-22 19:39:30.568360
# Unit test for function set_constant
def test_set_constant():
    constants = {}
    set_constant('FOO', 'BAR', export=constants)
    assert constants['FOO'] == 'BAR'

if __version__.startswith('2.9'):
    FALLBACK_DEFAULT_VAULT_ID_MATCH = (r'^[A-Za-z0-9+/]{32}(:.+)?$', r'^\$ANSIBLE_VAULT;\d+;[0-9a-fA-F]+$')

# Generated at 2022-06-22 19:39:33.162715
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([], "Test", "1.0")
    len(seq)
    seq[0]

# Generated at 2022-06-22 19:39:45.406853
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.errors import AnsibleDeprecationWarning
    import warnings
    with warnings.catch_warnings(record=True) as w:
        msg = 'The "include_vars" task is deprecated. Use "vars_files" or a "vars:" block instead.'
        version = '2.12'
        value = [{'tasks': [{'include_tasks': 'tasks/main.yml'}]}]
        d = _DeprecatedSequenceConstant(value, msg, version)
        assert len(w) == 0
        assert d[0]['tasks'][0]['include_tasks'] == 'tasks/main.yml'
        assert d[0]['tasks'][0] == {'include_tasks': 'tasks/main.yml'}

# Generated at 2022-06-22 19:39:50.613092
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(list(range(3)), 'foo', 'bar')
    assert len(c) == 3
    assert c[0] == 0
    assert c[1] == 1
    assert c[2] == 2

# Generated at 2022-06-22 19:39:51.866548
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_SUBSET == 'all'

# Generated at 2022-06-22 19:39:55.619064
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = 'abc'
    msg = 'no msg'
    version = '3.0.0'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'


# Generated at 2022-06-22 19:39:57.411510
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2], 'msg', 'v')) == 2

# Generated at 2022-06-22 19:40:00.061841
# Unit test for function set_constant
def test_set_constant():
    set_constant('TESTING_CONSTANT', 'foo')
    import ansible
    assert ansible.TESTING_CONSTANT == 'foo'

# Generated at 2022-06-22 19:40:07.131826
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is True


## The following modules have been deprecated or are being replaced.  These have
## been moved to core/deprecated_modules, but we still need to maintain their
## names in this list for backwards compatibility.
DEPRECATED_MODULES = {
    'add_host': 'The module documentation details page may explain more about this rationale.',
    'async_status': 'The module documentation details page may explain more about this rationale.',
    'fetch': 'fetches a file from remote nodes',
    'pause': 'pause/wait/sleep module',
    'service': 'Controls services on remote hosts.',
}

# Generated at 2022-06-22 19:40:09.664165
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
   assert len(_DeprecatedSequenceConstant(list(range(10)), "msg", "1.0")) == 10

# Generated at 2022-06-22 19:40:12.240276
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_UNTAR_OPTIONS == '--strip=1'
    assert DEFAULT_UNZIP_OPTIONS == ''

# Generated at 2022-06-22 19:40:17.927994
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'TEST', export=globals())
    assert TEST_CONSTANT == 'TEST'
    assert TEST_CONSTANT != 'ANSIBLE_TEST'
    del TEST_CONSTANT


# Generated at 2022-06-22 19:40:26.813912
# Unit test for function set_constant
def test_set_constant():
    # Ensure the function works at all
    set_constant('test_constant', 'test_value')
    assert 'test_constant' in globals()

    # Ensure the function populates the export arg
    test_export = {}
    set_constant('test_constant_2', 'test_value', test_export)
    assert 'test_constant_2' in test_export

    # Ensure the function doesn't modify the global namespace when export is defined
    global_namespace = globals().copy()
    set_constant('test_constant_3', 'test_value', test_export)
    assert global_namespace == globals()


TREE_DIR = getattr(config, 'TREE_DIR', None)

# FIXME: these should be moved to the module_utils
DEFAULT_KEEP_REM

# Generated at 2022-06-22 19:40:30.988749
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # _DeprecatedSequenceConstant object with a list of length 4
    _DeprecatedSequenceConstant_ = _DeprecatedSequenceConstant([1,2,3,4], 'msg', 'version')
    assert len(_DeprecatedSequenceConstant_) == 4

