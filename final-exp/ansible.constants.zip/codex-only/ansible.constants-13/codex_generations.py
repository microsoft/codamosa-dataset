

# Generated at 2022-06-22 19:30:36.341205
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import mock

    def test_func(self, y):
        return self._value[y]

    inst = _DeprecatedSequenceConstant('test', 'test', 'test')
    assert test_func(inst, 1) == 'e'

    with mock.patch('ansible.module_utils.basic._warning') as m:
        inst = _DeprecatedSequenceConstant([1, 2, 3], 'test', 'test')
        length = len(inst)
        assert length == 3

        assert m.call_count == length
        assert m.call_args_list[0][0] == ('test', )
        assert m.call_args_list[0][1] == {'version': 'test'}
        assert m.call_args_list[1][0] == ('test', )
        assert m

# Generated at 2022-06-22 19:30:41.153358
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import mock
    from ansible.utils.display import Display

    with mock.patch.object(Display, 'warning') as mock_warning:
        _DeprecatedSequenceConstant(['item1'], 'this is a msg', '2.9')
    mock_warning.assert_called_once_with('Variable "action_plugins" is deprecated and will be removed in 2.9. \n'
                                         'Use `action_plugins` in ansible.cfg instead (or `action_plugins_path` if you\'re \n'
                                         'using a non-standard location).', version='2.9')


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:30:45.085071
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # given
    ds = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    # then
    assert ds.__len__() == 3


# Generated at 2022-06-22 19:30:56.407831
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    tpl = '{class_name}({value}, {msg}, {version})'
    msg = 'test msg'
    version = None


# Generated at 2022-06-22 19:31:04.696954
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([], '', '2.9')) == 0
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '2.9')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '2.9')[2] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '2.9')[-1] == 3

# Generated at 2022-06-22 19:31:16.396240
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(DEFAULT_BECOME_PASS, string_types)
    assert isinstance(DEFAULT_REMOTE_PASS, string_types)
    assert isinstance(DEFAULT_SUBSET, string_types)
    assert isinstance(MODULE_REQUIRE_ARGS, tuple)
    assert isinstance(MODULE_NO_JSON, tuple)
    assert isinstance(INVALID_VARIABLE_NAMES, type(re.compile('')))
    assert isinstance(DOCUMENTABLE_PLUGINS, tuple)
    assert isinstance(CONFIGURABLE_PLUGINS, tuple)
    assert isinstance(REMOTE_TEMP_PATH, string_types)
    assert isinstance(REMOTE_TEMP_PLUGIN_PATH, string_types)

# Generated at 2022-06-22 19:31:20.229544
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2], 'test msg', '1.0')
    assert len(a) == 2
    assert a[0] == 1
    assert a[1] == 2

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:31:24.924591
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = ['bar', 'baz']
    s = _DeprecatedSequenceConstant(l, 'the msg', '2.7')
    assert s[0] == 'bar'
    assert s[1] == 'baz'


# Generated at 2022-06-22 19:31:27.672046
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    out = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='test', version='test')
    assert out[2] == 3

# Generated at 2022-06-22 19:31:30.106169
# Unit test for function set_constant
def test_set_constant():
    assert ansible_version == __version__

# for backwards compatibility (not used in the codebase anymore):
DEFAULT_SUDO_PASS = DEFAULT_BECOME_PASS

# Generated at 2022-06-22 19:31:33.230236
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(value=[], msg='test message', version='1.0').__len__() == 0

# Generated at 2022-06-22 19:31:35.176563
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_const', 'test_value')
    assert test_const == 'test_value'

# Generated at 2022-06-22 19:31:37.065089
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")[1] == 2

# Generated at 2022-06-22 19:31:39.336748
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(['a','b','c'], "Test warning message", "2.5")
    assert len(constant) == 3


# Generated at 2022-06-22 19:31:47.251640
# Unit test for function set_constant
def test_set_constant():
    set_constant('_TESTING', 'foo', locals())
    assert _TESTING == 'foo'
    # to cover in 1.x
    set_constant('_SOMEMORE', 'bar', locals())
    assert _SOMEMORE == 'bar'
    # to cover in 2.x
    set_constant('_SOMEMORE', 'bar', None)
    assert _SOMEMORE == 'bar'
    # to cover in 3.x
    set_constant('_SOMEMORE', 'bar')
    assert _SOMEMORE == 'bar'

# Generated at 2022-06-22 19:31:51.405034
# Unit test for function set_constant
def test_set_constant():
    ''' tests set_constant method '''
    name, value = 'foo', 'bar'
    set_constant(name, value, export=vars())
    assert globals()[name] == value

# Generated at 2022-06-22 19:31:53.835497
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version").__len__() == 3

# Generated at 2022-06-22 19:32:00.874965
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_constant = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='This is a test', version='2.4')
    assert seq_constant._msg == 'This is a test'
    assert seq_constant._version == '2.4'
    assert seq_constant._value == ['a', 'b', 'c']
    assert len(seq_constant) == 3
    assert seq_constant[1] == 'b'

# Generated at 2022-06-22 19:32:04.517121
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 19:32:07.260285
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep_constant = _DeprecatedSequenceConstant(value=[1,2,3], msg="msg", version="version")
    assert len(dep_constant) == 3
    assert dep_constant[0] == 1

# Generated at 2022-06-22 19:32:10.280496
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(value=('a', 'b'), msg='msg', version='version')
    assert len(c) == 2
    assert c[0] == 'a'
    assert c[1] == 'b'


# Generated at 2022-06-22 19:32:12.717220
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test of method __len__ of class _DeprecatedSequenceConstant"""
    assert True



# Generated at 2022-06-22 19:32:15.193734
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c1 = _DeprecatedSequenceConstant([1, 2], "msg", "version")
    assert c1.__len__() == 2


# Generated at 2022-06-22 19:32:17.886395
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "Foo"
    version = "1.0"
    obj = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert len(obj) == 3
    assert obj[0] == 1

# Generated at 2022-06-22 19:32:22.237192
# Unit test for function set_constant
def test_set_constant():
    def fn1(**kwargs):
        pass
    set_constant('fn1', fn1)
    assert __builtins__['fn1'] == fn1



# Generated at 2022-06-22 19:32:31.287558
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE

    assert isinstance(DEFAULT_VAULT_PASSWORD_FILE, _DeprecatedSequenceConstant)
    assert DEFAULT_VAULT_PASSWORD_FILE[0] == '/etc/ansible/vault_pass.txt'
    assert DEFAULT_VAULT_PASSWORD_FILE[1] == '~/.vault_pass.txt'
    assert DEFAULT_VAULT_PASSWORD_FILE[2] == '~/vault-pass.txt'

# Generated at 2022-06-22 19:32:39.222607
# Unit test for function set_constant
def test_set_constant():
    # test without export
    set_constant('ANSIBLE_COW_SELECTION', ['cow1', 'cow2'])
    assert ANSIBLE_COW_SELECTION == ['cow1', 'cow2']

    # test with export
    # test without export
    export = {}
    set_constant('ANSIBLE_COW_SELECTION', ['moo'], export=export)
    assert ANSIBLE_COW_SELECTION == ['cow1', 'cow2']
    assert export['ANSIBLE_COW_SELECTION'] == ['moo']


# check if constants are correctly loaded from config

# Generated at 2022-06-22 19:32:47.075375
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    This method allows to use the class _DeprecatedSequenceConstant as a Sequence
    It will be used by the class _get_action()
    This Unit test is to check that the method returns a DeprecatedSequenceConstant object
    with the appropriate fields
    '''
    CONSTANT_SEQUENCE_VALUE = (1, 2, 3) # test Sequence
    CONSTANT_SEQUENCE_MSG = "Sequence message" # test message
    CONSTANT_SEQUENCE_VERSION = "2.9.0"
    constant_sequence = _DeprecatedSequenceConstant(CONSTANT_SEQUENCE_VALUE, CONSTANT_SEQUENCE_MSG, CONSTANT_SEQUENCE_VERSION)
    assert constant_sequence._value == CONSTANT_SEQUENCE_VALUE
    assert constant_sequence._msg

# Generated at 2022-06-22 19:32:50.046898
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 1)
    assert TEST_SET_CONSTANT == 1

# Unit tests for function ensure_type

# Generated at 2022-06-22 19:32:57.863552
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('xyz', 'abcd') == {'xyz': 'abcd'}
    assert set_constant('xyz', 'abcd', {}) == {'xyz': 'abcd'}


# Constants that were previously in the config file but are not set at runtime
# This will also be used for any options removed from the config file
# If the option is marked as removed but does not have a constant, it will be removed from the config file
# If the option is marked as removed but does have a constant, it will be preserved in the config file but its name will be changed
# If the option is marked as removed but does have a constant and the value is set to None, it will be removed from the config file

# Generated at 2022-06-22 19:33:02.533195
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SETTING', True)
    assert TEST_SETTING is True
TEST_SETTING = None

C.DEFAULT_HOST_LIST = DEFAULT_HOST_LIST

# Generated at 2022-06-22 19:33:12.398334
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    test for method __getitem__ of class _DeprecatedSequenceConstant
    args:
        var _DeprecatedSequenceConstant contains _DeprecatedSequenceConstant('value', 'msg', 'version')
        var value contains return value of __getitem__
    '''

    value = _DeprecatedSequenceConstant(['item1', 'item2'], 'msg', 'version')[0]
    value = _DeprecatedSequenceConstant(['item1', 'item2'], 'msg', 'version')[1]
    value = _DeprecatedSequenceConstant(['item1', 'item2'], 'msg', 'version')[2]



# Generated at 2022-06-22 19:33:15.807988
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1, 2, 3], "test", "2.2")
    assert len(s) == len([1, 2, 3])


# Generated at 2022-06-22 19:33:17.590782
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'Test')
    assert test == 'Test', "The test failed!"

# Generated at 2022-06-22 19:33:29.052770
# Unit test for function set_constant
def test_set_constant():
    locals_dict = locals().copy()
    set_constant('ANSIBLE_TEST_VAR', 'xyzzy')
    assert locals_dict['ANSIBLE_TEST_VAR'] == 'xyzzy'
    set_constant('ANSIBLE_TEST_VAR', 'yzzy')
    assert locals_dict['ANSIBLE_TEST_VAR'] == 'yzzy'
    set_constant('ANSIBLE_TEST_VAR', 'yzzx', export=globals())
    assert locals_dict['ANSIBLE_TEST_VAR'] == 'yzzy'
    assert globals()['ANSIBLE_TEST_VAR'] == 'yzzx'

DEFAULT_CACHE_PLUGIN = config.data.get_config_value('defaults', 'action_plugins') + '/cache.py'


# Generated at 2022-06-22 19:33:38.818345
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import mock
    import unittest
    import sys

    msg = 'this message should be displayed'

    class MockStderr(object):
        def __init__(self):
            self.contents = ''
        def write(self, msg):
            self.contents += msg

    stderr = MockStderr()
    with mock.patch.object(sys, 'stderr', stderr):
        # Test retrieving first element of list
        constant = _DeprecatedSequenceConstant([1], msg, '2.12')
        constant[0]
        assert(stderr.contents == ' [DEPRECATED] {}\n'.format(msg))

        # Test retrieving element in the middle of list
        stderr.contents = ''

# Generated at 2022-06-22 19:33:42.091004
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'Message', '1.0')
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3


# Generated at 2022-06-22 19:33:44.507409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '1.0')
    assert len(obj) == 3


# Generated at 2022-06-22 19:33:46.320579
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([], 'TestCase', '2.4')
    assert len(seq) == 0
    assert seq[1:] == []


# Generated at 2022-06-22 19:33:48.432693
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'some message', '2.11')
    assert len(d) == 3


# Generated at 2022-06-22 19:33:52.686364
# Unit test for function set_constant
def test_set_constant():
    const = {
        'FOO_BAR': 123,
        'FOO_BAZ': 'abc'
    }
    set_constant('FOO_BAR', 123, const)
    set_constant('FOO_BAZ', 'abc', const)
    assert const == {
        'FOO_BAR': 123,
        'FOO_BAZ': 'abc'
    }

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-22 19:34:03.934463
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_string', 'value')
    set_constant('test_integer', 5)
    set_constant('test_boolean', 'true')
    set_constant('test_fqcn', 'ansible.module_utils.common.network.default.Default')

    assert test_string == 'value'
    assert test_integer == 5
    assert test_boolean is True
    assert test_fqcn == add_internal_fqcns(('ansible.module_utils.common.network.default.Default',))


MAGIC_VARIABLE_MAPPING = _DeprecatedSequenceConstant(MAGIC_VARIABLE_MAPPING, "MAGIC_VARIABLE_MAPPING is deprecated, use VARS_TO_TRANSFORM", "2.11")
COMMON

# Generated at 2022-06-22 19:34:05.096073
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], 'msg', 'version')) == 2


# Generated at 2022-06-22 19:34:11.588936
# Unit test for function set_constant
def test_set_constant():
    import sys
    import os
    import tempfile
    reload(sys)

    with tempfile.NamedTemporaryFile() as named_temp_file:
        fixed_path = os.path.basename(named_temp_file.name)

        os.environ['ANSIBLE_TEST_SET_CONSTANT'] = "new_value"
        os.environ['ANSIBLE_TEST_SET_CONSTANT_FROM_CONFIG'] = "new_value2"


# Generated at 2022-06-22 19:34:24.063762
# Unit test for function set_constant
def test_set_constant():
    import os
    import sys
    import tempfile
    import unittest

    os_path = os.path
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_path = tmp_file.name
    tmp_file.close()

    def clean_sys_modules():
        """
        Try to clean sys.modules of any references to the ansible.constants module.
        """
        for key in list(sys.modules.keys()):
            if key.startswith('ansible.constants'):
                sys.modules.pop(key)

    class TestSetConstant(unittest.TestCase):
        """
        Test the set_constant function
        """

        def setUp(self):
            self.export = {}

        def tearDown(self):
            self.export = None
            clean

# Generated at 2022-06-22 19:34:25.705637
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(None, None, None)) == 0

# Generated at 2022-06-22 19:34:28.755295
# Unit test for function set_constant
def test_set_constant():
    assert_equal(set_constant('foo', 'bar'), {'foo': 'bar'})

# vim: set foldmethod=marker:

# Generated at 2022-06-22 19:34:35.046025
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    config_constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], "message", "version")
    assert(isinstance(config_constant, Sequence))
    assert(len(config_constant) == 3)
    assert(config_constant[0] == 'a')
    assert(config_constant[1] == 'b')
    assert(config_constant[2] == 'c')

# Generated at 2022-06-22 19:34:39.107206
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    string = "string"
    example = _DeprecatedSequenceConstant(string, "", "")
    assert len(example) == len(string)
    assert len(example) == len(string)


# Generated at 2022-06-22 19:34:51.462342
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test__len(self):
            deprecated_sequence_constant = _DeprecatedSequenceConstant((), 'msg', 'version')
            self.assertIsInstance(deprecated_sequence_constant.__len__(), int)
        def test__getitem__(self):
            deprecated_sequence_constant = _DeprecatedSequenceConstant(('val1','val2','val3'), 'msg', 'version')
            self.assertEqual(deprecated_sequence_constant[0], 'val1')
    unittest.main(module='__main__', exit=False)

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:34:57.281242
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_data = 'test data'
    msg = 'msg'
    version = '2.9.0'
    t = _DeprecatedSequenceConstant(test_data, msg, version)
    assert t.__getitem__('test item') == test_data.__getitem__('test item')



# Generated at 2022-06-22 19:34:59.402086
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(['foo', 'bar'], 'message', 'version') == 2


# Generated at 2022-06-22 19:35:10.206027
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def _check(obj, expected_msg, expected_version):
        warnings = []
        def _warning(msg):
            warnings.append((msg,))

        def _deprecated(msg, version):
            warnings.append((msg, version))

        try:
            from ansible.utils.display import Display
            original_warning = Display.warning
            original_deprecated = Display.deprecated
            Display.warning = _warning
            Display.deprecated = _deprecated
            obj.__getitem__(0)
        finally:
            Display.warning = original_warning
            Display.deprecated = original_deprecated

        assert len(warnings) == 1
        if expected_version is None:
            assert warnings[0] == (expected_msg,)
        else:
            assert warnings[0] == (expected_msg, expected_version)

# Generated at 2022-06-22 19:35:14.015181
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'A string'
    version = 'A string'
    set_constant('test_value', 'ABC')
    constant = _DeprecatedSequenceConstant(['ABC'], msg, version)
    assert constant[0] == 'ABC'


# Generated at 2022-06-22 19:35:24.788467
# Unit test for function set_constant
def test_set_constant():
    def test_fn():
        pass
    set_constant('test', test_fn)
    assert vars()['test'] == test_fn

# FIXME: remove later

# FIXME: remove this once ansible.utils.unicode is no longer used
try:
    string_types = (basestring,)
except NameError:
    string_types = (str, bytes)

# FIXME: remove this once the usage of ANSIBLE_VAULT_IDENTITY_LIST is removed
try:
    vault_ids = literal_eval(os.environ.get('ANSIBLE_VAULT_IDENTITY_LIST', '[]'))
    if not isinstance(vault_ids, list):
        vault_ids = []
except Exception:
    vault_ids = []

# Generated at 2022-06-22 19:35:31.923331
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecatedSequenceConstant = _DeprecatedSequenceConstant([1, 2, 3], "test message", "1.0")
    assert len(deprecatedSequenceConstant) == 3
    assert deprecatedSequenceConstant[0] == 1
    assert deprecatedSequenceConstant[1] == 2
    assert deprecatedSequenceConstant[2] == 3
    assert deprecatedSequenceConstant[:2] == [1, 2]

# Generated at 2022-06-22 19:35:33.395857
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'warning', 'version')
    assert obj[0] == 'a'

# Generated at 2022-06-22 19:35:35.230272
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['1', '2'], 'this is a message', 'version')) == 2

# Generated at 2022-06-22 19:35:48.082440
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test case 1
    test_class = _DeprecatedSequenceConstant([1], 'test_case1_msg', 'test_case1_version')
    assert len(test_class) == 1
    # when call len(test_class), it prints the deprecated message
    # [DEPRECATED]test_case1_msg, to be removed in test_case1_version

    # test case 2
    test_class = _DeprecatedSequenceConstant([2, 3], 'test_case2_msg', 'test_case2_version')
    assert test_class[0] == 2
    # when call test_class[0], it prints the deprecated message
    # [DEPRECATED]test_case2_msg, to be removed in test_case2_version

if __name__ == '__main__':
    test__Deprecated

# Generated at 2022-06-22 19:35:56.083456
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """Unit test for constructor of class _DeprecatedSequenceConstant."""
    _DeprecatedSequenceConstant(value=(0, 1, 2, 3), msg='test message 1', version='test version 1')
    _DeprecatedSequenceConstant(value=(0, 1, 2, 3), msg='test message 2', version='test version 2')
    _DeprecatedSequenceConstant(value=(0, 1, 2, 3), msg='test message 3', version='test version 3')


# Generated at 2022-06-22 19:36:05.939175
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Constants:
        def __init__(self):
            self.ANSIBLE_INTERNAL_TASKS = _DeprecatedSequenceConstant(['include_role', 'import_role', 'include_tasks', 'import_tasks'], 'ANSIBLE_INTERNAL_TASKS is deprecated, use ACTION_INTERNAL_TASKS', '2.12')
            self.ANSIBLE_INTERNAL_MODULES = _DeprecatedSequenceConstant(['include', 'include_role', 'import_role', 'include_tasks', 'import_tasks'], 'ANSIBLE_INTERNAL_MODULES is deprecated, use ACTION_INTERNAL_MODULES', '2.12')

# Generated at 2022-06-22 19:36:08.932051
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_attr = _DeprecatedSequenceConstant([], "test warning", "test version")
    assert dep_attr.__getitem__(0) == []


# Generated at 2022-06-22 19:36:11.989395
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(['a', 'b'], 'foo', '2.0')
    assert len(a) == 2


# Generated at 2022-06-22 19:36:16.763416
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(('a', 'b'), "message", "2.0")
    assert d[0] == 'a'
    assert d[1] == 'b'

# Generated at 2022-06-22 19:36:21.342717
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert 0 == len(_DeprecatedSequenceConstant([], 'msg', 'version'))
    assert 1 == len(_DeprecatedSequenceConstant([1], 'msg', 'version'))
    assert 2 == len(_DeprecatedSequenceConstant([1, 2], 'msg', 'version'))

# Generated at 2022-06-22 19:36:28.392610
# Unit test for function set_constant
def test_set_constant():
    config = ConfigManager()
    for setting in config.data.get_settings():
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render(vars())
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not templatable

            value = ensure_type(value, setting.type)

        set_constant(setting.name, value)

    for warn in config.WARNINGS:
        _warning(warn)


# Generated at 2022-06-22 19:36:32.479006
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant("FOOBAR", "homer")
    set_constant("foo", "bar", export)
    if FOOBAR != "homer":
        raise AssertionError("FOOBAR should be a constant")
    if export['foo'] != "bar":
        raise AssertionError("export['foo'] should be bar")


# Generated at 2022-06-22 19:36:42.147802
# Unit test for function set_constant
def test_set_constant():
    _test_dict = {}
    _test_var = "foo"
    _test_val = "bar"
    set_constant(_test_var, _test_val, export=_test_dict)
    assert _test_var in _test_dict
    assert _test_dict[_test_var] == _test_val


__version__ = __version__.replace("-dev", "")  # kludge until we make this dynamic


# Generated at 2022-06-22 19:36:45.309594
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_constant = _DeprecatedSequenceConstant(value=['foo'], msg='foo', version='bar')
    assert 1 == len(deprecated_constant)


# Generated at 2022-06-22 19:36:56.554699
# Unit test for function set_constant
def test_set_constant():
    env = {}
    set_constant('FOO', 1, export=env)
    assert env == dict(FOO=1)


# The following are all legacy
_C = config.data
DEFAULT_KEEP_REMOTE_FILES = _C.getboolean('DEFAULT_KEEP_REMOTE_FILES', False)
DEFAULT_PRIVATE_KEY_FILE = _C.get('DEFAULT_PRIVATE_KEY_FILE', None)
DEFAULT_SUDO_EXE = _C.get('DEFAULT_SUDO_EXE', 'sudo')
DEFAULT_SUDO_FLAGS = _C.get('DEFAULT_SUDO_FLAGS', None)
DEFAULT_SUDO_USER = _C.get('DEFAULT_SUDO_USER', 'root')
DEFAULT_

# Generated at 2022-06-22 19:37:07.577502
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Tests for module_utils.config_data
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE, BOOLEANS_TRUE
    from ansible.module_utils.config_data import _DeprecatedSequenceConstant
    len_result = len(_DeprecatedSequenceConstant(BOOLEANS_FALSE, 'msg', 'version'))
    assert (len(BOOLEANS_FALSE) == len_result)

    # Test for module_utils.six
    from ansible.module_utils.six import string_types
    len_result = len(_DeprecatedSequenceConstant(string_types, 'msg', 'version'))
    assert (len(string_types) == len_result)


# Generated at 2022-06-22 19:37:10.294803
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list(range(1)), '', '2.9.0')) == 1

# Generated at 2022-06-22 19:37:14.165705
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep_obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.8')
    assert dep_obj[1] == 2
    assert len(dep_obj) == 3

# Generated at 2022-06-22 19:37:23.864575
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_string_value = 'test'
    test_string_msg = 'This is a message'
    test_string_version = '2.0'
    test_string_constructor_instance = _DeprecatedSequenceConstant(test_string_value, test_string_msg, test_string_version)
    # test _DeprecatedSequenceConstant instantiation with a string
    assert isinstance(test_string_constructor_instance, _DeprecatedSequenceConstant)
    assert test_string_constructor_instance[0] == test_string_value
    assert test_string_constructor_instance.__len__() == len(test_string_value)

    test_list_value = ['test', 'test']
    test_list_msg = 'This is a message'
    test_list_version = '2.0'

# Generated at 2022-06-22 19:37:31.513137
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''
    _DeprecatedSequenceConstant should consume more space than the input string.
    '''

    test_str = 'This is a test'
    test_str_len = len(test_str)

    w = _DeprecatedSequenceConstant(test_str, test_str, test_str)
    w_len = len(w)

    assert w_len > test_str_len



# Generated at 2022-06-22 19:37:36.372549
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant(list(), "msg1", "2.9.0").__len__() == 0
    assert _DeprecatedSequenceConstant(list(range(0, 5)), "msg2", "2.9.0").__len__() == 5

# Generated at 2022-06-22 19:37:47.862388
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # __getitem__
    obj = _DeprecatedSequenceConstant('value', 'msg', 'version')
    # Should not raise any exception
    obj[0]
    # __len__
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    # Should not raise any exception
    len(obj)
    # __getitem__
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    # Should not raise any exception
    obj[1]
    # __getitem__
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    # Should not raise any exception
    obj[1:2]
test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:37:52.968731
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'blah'
    version = '1.0'
    value = ['1', '2', '3']
    foo = _DeprecatedSequenceConstant(value, msg, version)
    assert len(foo) == 3
    assert foo[0] == '1'

# Generated at 2022-06-22 19:37:57.256531
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "hello"
    version = "1.2.3"
    old_string_constant = 'string'
    old_sequence_constant = ['a', 'b', 'c']
    s = _DeprecatedSequenceConstant(old_string_constant, msg, version)
    assert s[0] == 's'  # Slicing a string produces a substring
    assert s.__len__() == 6
    s = _DeprecatedSequenceConstant(old_sequence_constant, msg, version)
    assert s[0] == 'a'  # Slicing a sequence produces an element
    assert s.__len__() == 3

# Generated at 2022-06-22 19:38:01.725576
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Test'
    version = '2.9'
    value = [1, 2, 3]
    dep_seq_const = _DeprecatedSequenceConstant(value, msg, version)
    assert dep_seq_const.__len__() == 3


# Generated at 2022-06-22 19:38:05.190986
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = 'ansible.module_utils.basic.__len__'
    msg = 'foo'
    version = '2.0.0'
    obj = _DeprecatedSequenceConstant(s, msg, version)
    assert len(obj) == len(s)


# Generated at 2022-06-22 19:38:14.383022
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(t) == 0
    assert t[0] == None


# FIXME: the following should be refactored into a plugin
# FIXME: hardcoding this list here is ugly, but there are so many places this is used
# in the code that it should probably be done so that all of the plugins can be
# properly dynamically loaded, and not just these few special cases


# Generated at 2022-06-22 19:38:17.147928
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.parsing.convert_bool import boolean

    msg = 'foo'
    version = 'bar'
    s = _DeprecatedSequenceConstant(boolean(['yes']), msg, version)
    assert len(s) == 1
    assert s[0] is True

del test__DeprecatedSequenceConstant

# Generated at 2022-06-22 19:38:22.100938
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1,2], 'foo', '1.0') == [1,2]
    assert len(_DeprecatedSequenceConstant([1,2], 'foo', '1.0')) == 2
    assert _DeprecatedSequenceConstant([1,2], 'foo', '1.0')[1] == 2

# Generated at 2022-06-22 19:38:31.867203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    seq = _DeprecatedSequenceConstant(1, "", "")
    with pytest.raises(TypeError):
        int(seq)

    seq = _DeprecatedSequenceConstant([1,2], "", "")
    assert seq[0] == 1
    assert seq[1] == 2

    seq = _DeprecatedSequenceConstant((1,2), "", "")
    assert seq[0] == 1
    assert seq[1] == 2

    seq = _DeprecatedSequenceConstant("12", "", "")
    assert seq[0] == "1"
    assert seq[1] == "2"

# Generated at 2022-06-22 19:38:33.974574
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3, 4), 'test_msg', '1.0')
    assert len(dsc) == 4


# Generated at 2022-06-22 19:38:40.301773
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")

    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3

    try:
        dsc[10]
        assert False
    except IndexError:
        assert True


# Generated at 2022-06-22 19:38:44.880086
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # create a constant
    const = _DeprecatedSequenceConstant(
        value = (1, 2, 3),
        msg = 'list is deprecated',
        version = '2.8',
    )

    # no exception is thrown
    len(const)
# /Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 19:38:47.985521
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert isinstance(_DeprecatedSequenceConstant([], '', ''), Sequence)
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], '', '')['b'] == 'b'
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '')[1] == 2

# Generated at 2022-06-22 19:38:50.219218
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 42)
    assert test_constant == 42


# Generated at 2022-06-22 19:38:55.366870
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    global test_name, test_count
    import os
    import sys
    import tempfile
    import unittest

    try:
        from ansible.utils.display import Display
    except ImportError:
        sys.stderr.write('SKIP: ansible.utils.display (missing: Display)\n')
        sys.exit(0)

    class TestDeprecatedSequenceConstant(unittest.TestCase):
        def setUp(self):
            ''' Setup for unit test '''
            self.save_stdout = sys.stdout
            self.save_stderr = sys.stderr
            fd, self.warn_out = tempfile.mkstemp(prefix='ansible-test-')
            os.close(fd)

# Generated at 2022-06-22 19:38:57.545308
# Unit test for function set_constant
def test_set_constant():
    set_constant('variable_name', 'variable_value')


# Generated at 2022-06-22 19:39:01.781653
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constants = ['foo', 'bar']
    tester = _DeprecatedSequenceConstant(value=constants, msg='this is a message', version='2.10')
    assert len(tester) == 2
    assert tester[0] == 'foo'
    assert tester[1] == 'bar'

# Generated at 2022-06-22 19:39:07.011808
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    C = _DeprecatedSequenceConstant(['foo', 'bar'], 'message', '2.8')
    assert C[0] == 'foo'
    assert C[1] == 'bar'
    assert C['foo'] == 'bar'
    assert C['bar'] == 'foo'


# Generated at 2022-06-22 19:39:10.194253
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(d) == 3
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3

# Generated at 2022-06-22 19:39:13.629624
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = ('a', 'b', 'c')

    assert len(_DeprecatedSequenceConstant(test_seq, '', '2.10')) == 3


# Generated at 2022-06-22 19:39:19.888264
# Unit test for function set_constant
def test_set_constant():

    constants_before = vars()

    test_value = 'test_value'
    test_name = 'test_name'
    set_constant(test_name, test_value)

    assert test_name in constants_before

    constants_after = vars()
    assert test_name in constants_after

    assert constants_after[test_name] == test_value

test_set_constant()

# Generated at 2022-06-22 19:39:29.266552
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = [
        "The ANSIBLE_*_INTERPRETER variables have been deprecated in favor of the new interpreter in config. Please update your config file accordingly.",
        "The ANSIBLE_*_INTERPRETER variables have been deprecated in favor of the new interpreter in config. Please update your config file.",
        "The ANSIBLE_*_INTERPRETER variables have been deprecated in favor of the new interpreter in config."
    ]

    version = [
        "2.9.0",
        "2.8"
    ]

    value = ["", "", ""]


# Generated at 2022-06-22 19:39:31.658600
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant('', '', ''), _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:39:34.587317
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'Oops', '2.0')) == 3

# Generated at 2022-06-22 19:39:46.382859
# Unit test for function set_constant
def test_set_constant():
    namespace = {}
    set_constant('FOO', 1, namespace)
    assert(namespace['FOO'] == 1)


# FIXME: remove this or find a way to generate it dynamically
MAX_VARS_PER_HOST = getattr(config, 'MAX_VARS_PER_HOST', 512)
MAX_FAIL_PERCENTAGE = getattr(config, 'MAX_FAIL_PERCENTAGE', 50)

# DEFAULTS ###
DEFAULT_DEBUG = False
DEFAULT_HOST_LIST = '/etc/ansible/hosts'
DEFAULT_MODULE_NAME = 'command'
DEFAULT_MODULE_PATH = None
DEFAULT_PATTERN = '*'
DEFAULT_REMOTE_TMP = '$HOME/.ansible/tmp'
DEFAULT_TIMEOUT = 10
DEFAULT_

# Generated at 2022-06-22 19:39:51.135222
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    cons1 = _DeprecatedSequenceConstant(_ACTION_ALL_INCLUDES, 'Test Message', '2.10')
    assert len(cons1) == 3, 'Unexpected sequence length'
    item1 = cons1[0]
    assert item1 == 'include', 'Unexpected sequence item 1'
    assert cons1._msg == 'Test Message', 'Unexpected constant message'
    assert cons1._version == '2.10', 'Unexpected constant message'



# Generated at 2022-06-22 19:40:02.447078
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'This is a test', '2.9') == [1, 2, 3]
    try:
        assert _DeprecatedSequenceConstant([1, 2, 3], 'This is a test', '2.9')[0] == 1
    except DeprecationWarning:
        pass
    try:
        assert _DeprecatedSequenceConstant([1, 2, 3], 'This is a test', '2.9')[1] == 2
    except DeprecationWarning:
        pass
    try:
        assert _DeprecatedSequenceConstant([1, 2, 3], 'This is a test', '2.9')[2] == 3
    except DeprecationWarning:
        pass

# Generated at 2022-06-22 19:40:07.807938
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'this is a test', '2.9')
    assert dsc[1] == 2
    # 1.0 should be added
    assert dsc[0] == 1
    # 1.0 should be added
    assert dsc[-1] == 3



# Generated at 2022-06-22 19:40:09.524941
# Unit test for function set_constant
def test_set_constant():
    name = 'TEST_CONSTANT'
    value = 'TEST_VALUE'
    set_constant(name, value)
    assert name in globals()
    assert value == globals()[name]

# Generated at 2022-06-22 19:40:14.621633
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='XXXXX', version='v99.99')
    assert seq[0] == 1
    assert seq[1:] == (2, 3)
    assert seq[-1:] == (3,)
    assert seq[1:2] == (2,)
    assert len(seq) == 3


# Generated at 2022-06-22 19:40:20.667683
# Unit test for function set_constant
def test_set_constant():
    import os
    test_dict = {}
    set_constant('ANSIBLE_PYTHON_INTERPRETER', os.environ.get('ANSIBLE_PYTHON_INTERPRETER'), test_dict)
    assert test_dict['ANSIBLE_PYTHON_INTERPRETER'] == os.environ.get('ANSIBLE_PYTHON_INTERPRETER')


# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-22 19:40:32.253382
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a positive scenario
    value = [1]
    msg = "This is a test message"
    version = "1.0.0"
    deprecated_sequence_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert "1" == str(deprecated_sequence_obj[0])
    # Test for a negative scenario
    value = [1]
    msg = "This is a test message"
    version = "1.0.0"
    deprecated_sequence_obj = _DeprecatedSequenceConstant(value, msg, version)
    try:
        assert "1" == str(deprecated_sequence_obj[1])
    except IndexError:
        print("IndexError is raised, test case passed")
        assert True

