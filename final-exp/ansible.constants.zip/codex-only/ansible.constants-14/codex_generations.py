

# Generated at 2022-06-22 19:30:32.015472
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprec = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'test', '0.x')
    assert(len(deprec) == 3)
    assert(deprec[0] == 'a')
    assert(deprec[1] == 'b')
    assert(deprec[2] == 'c')


# Generated at 2022-06-22 19:30:42.270895
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # testing with a list
    test_value = [1, 2, 3]
    test_msg = "test message"
    test_version = "test version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj.__getitem__(0) == 1, \
        "__getitem__ returned incorrect value for positive index"
    assert test_obj.__getitem__(-1) == 3, \
        "__getitem__ returned incorrect value for negative index"
    try:
        test_obj.__getitem__(3)
    except IndexError:
        pass
    else:
        assert False, \
            "__getitem__ did not raise IndexError on out of range index"

# Generated at 2022-06-22 19:30:47.735673
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Tests for _DeprecatedSequenceConstant
    assert len(_DeprecatedSequenceConstant(('a', 'b', ), 'msg', 'ver')) == 3

    # Cannot test _deprecated() since it uses Display
    # from ansible.utils.display
    # assert _DeprecatedSequenceConstant(('a', 'b', ), 'msg', 'ver')[0] == 'a'

# Generated at 2022-06-22 19:30:50.278492
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    actual = _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')
    assert 2 == len(actual)


# Generated at 2022-06-22 19:30:53.843025
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 19:30:59.847280
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible import constants as C
    from ansible.module_utils.six import PY2
    try:
        # Python 2 compatibility: range was replaced with xrange in Python 3
        range = xrange
    except NameError:
        pass
    expected = ' [DEPRECATED] DEFAULT_PRIVATE_ROOT_KEY_FILENAME, now set from ansible.cfg, to be removed in 2.10'

    for i in range(len(C.DEFAULT_PRIVATE_ROOT_KEY_FILENAME)):
        if not PY2:
            assert isinstance(i, int)
        C.DEFAULT_PRIVATE_ROOT_KEY_FILENAME[i]
        _deprecated.assert_called_with(expected, '2.10')

# Generated at 2022-06-22 19:31:01.827957
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class_ = _DeprecatedSequenceConstant(value=[1], msg="msg", version="12.3")
    result = len(class_)
    assert class_._value[0] == result


# Generated at 2022-06-22 19:31:04.110542
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(None, None, None)) == 0

# Generated at 2022-06-22 19:31:10.353150
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test whether _DeprecatedSequenceConstant.__len__ returns its value
    _dsc = _DeprecatedSequenceConstant('value', 'message', '2.10')
    _len = len(_dsc)
    assert _len == len('value'), '_DeprecatedSequenceConstant.__len__ returns wrong value'



# Generated at 2022-06-22 19:31:13.909889
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], '', '')) == 3


# Generated at 2022-06-22 19:31:20.174748
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq_constant = _DeprecatedSequenceConstant(value=[1,2,3,4], msg='msg', version='version')
    assert dep_seq_constant.__getitem__(0) == 1
    assert dep_seq_constant.__getitem__(3) == 4
    assert dep_seq_constant.__getitem__(-1) == 4

# Generated at 2022-06-22 19:31:25.304527
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert s[0] == 'a'
    assert s[1] == 'b'
    assert s[2] == 'c'


# Generated at 2022-06-22 19:31:34.295764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 19:31:40.468428
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """ Unit test class _DeprecatedSequenceConstant """
    list_of_tuple = (('msg', 'version'), ('msg1', 'version1'), ('msg2', 'version2'))
    dsc = _DeprecatedSequenceConstant(list_of_tuple, 'Test msg', 'Test version')
    assert len(dsc) == len(list_of_tuple)
    assert dsc[0] == ('msg', 'version')

# Generated at 2022-06-22 19:31:45.852931
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    original_seq = [1, 2, 3]
    deprecated_msg = 'foo is deprecated'
    version = 'test version'
    dseq = _DeprecatedSequenceConstant(original_seq, deprecated_msg, version)

    assert dseq[0] == 1
    assert dseq[1] == 2
    assert dseq[2] == 3

# Generated at 2022-06-22 19:31:49.415110
# Unit test for function set_constant
def test_set_constant():
    var = {}
    set_constant('foo', 'bar', export=var)
    assert var['foo'] == 'bar'


# Generated at 2022-06-22 19:31:53.327802
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(['a', 'b'], 'msg', '2.10')
    assert len(seq) == 2
    assert seq[0] == 'a'
    assert seq[1] == 'b'

# Generated at 2022-06-22 19:31:55.383835
# Unit test for function set_constant
def test_set_constant():
    # set_constant should not be called from an external module
    # and cannot be tested.
    pass


# Generated at 2022-06-22 19:31:57.911510
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c1 = _DeprecatedSequenceConstant(list(range(10)), "test", "2.10")
    assert len(c1) == 10



# Generated at 2022-06-22 19:32:02.189136
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dep = _DeprecatedSequenceConstant((1, 2, 3), 'test', '2.12')
    assert len(dep) == 3
    assert dep[0] == 1
    assert dep[1] == 2
    assert dep[2] == 3

# Generated at 2022-06-22 19:32:07.913268
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ('foo', 'bar')
    test_msg = 'msg'
    test_version = '1.2.3'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    for index in range(len(test_value)):
        assert test_obj[index] == test_value[index]

# Generated at 2022-06-22 19:32:09.996296
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], "test_msg", "test_version")
    assert 2 == test_object[1]


# Generated at 2022-06-22 19:32:15.837463
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(['foo', 'bar'], 'this is a test', '2.10')
    assert len(seq) == 2
    assert seq[1] == 'bar'

# Generated at 2022-06-22 19:32:18.754061
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO_TEST_CONST', 'FOO')
    if not FOO_TEST_CONST == 'FOO':
        raise AssertionError("set_constant function failed to set global variable")
    del FOO_TEST_CONST

# Generated at 2022-06-22 19:32:21.524052
# Unit test for function set_constant
def test_set_constant():
    assert config.paths != {}


# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-22 19:32:25.564598
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(('1', '2'), 'msg', 'version')
    result = seq[0]
    assert isinstance(result, str)
    assert result == '1'


# Generated at 2022-06-22 19:32:31.172823
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.six import PY3

    foo = _DeprecatedSequenceConstant((1, 2, 3), 'Dummy message', '0.0')
    assert foo[-1] == 3

    if PY3:
        assert foo[0] == 1
    else:
        foo[0]



# Generated at 2022-06-22 19:32:35.087747
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    len_of_seq = len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg="test", version="2.6"))
    assert len_of_seq == 3

test__DeprecatedSequenceConstant___len__()


# Generated at 2022-06-22 19:32:38.121189
# Unit test for function set_constant
def test_set_constant():
    ''' test that constants are set correctly '''
    x = {}
    set_constant('FOO', 'bar', export=x)
    set_constant('BAR', ('bar', 'barr'), export=x)

    assert x['FOO'] == 'bar'
    assert x['BAR'] == ('bar', 'barr')

# Generated at 2022-06-22 19:32:47.570384
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test method __len__ of class _DeprecatedSequenceConstant with regular strings
    assert len(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version')) == 3
    # Test method __len__ of class _DeprecatedSequenceConstant with non-string object
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0
    # Test method __len__ of class _DeprecatedSequenceConstant with non-iterable object
    assert len(_DeprecatedSequenceConstant("", 'msg', 'version')) == 0
    # Test method __len__ of class _DeprecatedSequenceConstant with empty iterable object
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0


# Generated at 2022-06-22 19:32:51.263347
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'ver')) == 3
    assert _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'ver')[1] == 'b'

# Generated at 2022-06-22 19:32:53.634744
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'This is deprecated', '2.7')
    assert len(sequence) == len([1, 2, 3])

# Generated at 2022-06-22 19:32:57.674979
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    inst = _DeprecatedSequenceConstant([1, "a"], "msg", "version")
    try:
        inst[0]  # pylint: disable=pointless-statement
        inst[1]  # pylint: disable=pointless-statement
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 19:33:03.327935
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')
    assert len(test_dsc) == len([1, 2, 3])
    assert len(test_dsc) == 3

# Generated at 2022-06-22 19:33:07.384981
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([], "", "")
    assert len(sequence) == 0
    sequence = _DeprecatedSequenceConstant([1, 2, 3], "", "")
    assert len(sequence) == 3


# Generated at 2022-06-22 19:33:17.256184
# Unit test for function set_constant
def test_set_constant():
    # set the TEST_CONST_1 and TEST_CONST_2 from config
    TEST_CONST_1 = 'foo'
    TEST_CONST_2 = 'bar'
    set_constant("TEST_CONST_1", 'foo', export=vars())
    set_constant("TEST_CONST_2", 'bar')

    # verify the constants are set
    assert TEST_CONST_1 == 'foo'
    assert TEST_CONST_2 == 'bar'


# Generated at 2022-06-22 19:33:19.384100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(self, [1,2,3], "msg", "version")
    assert s[2] == 3

# Generated at 2022-06-22 19:33:25.586298
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_item']
    test_msg = 'test message'
    test_version = '1.0'
    test_seq_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_seq_constant) == len(test_value)
    assert test_seq_constant[0] == test_value[0]

# Generated at 2022-06-22 19:33:28.605129
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'testing', '2.1')) == 3


# Generated at 2022-06-22 19:33:33.223710
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "This is just a test"
    version = "9.9"
    value = (1, 2, 3)
    object_ = _DeprecatedSequenceConstant(value, msg, version)
    for element in value:
        assert object_[value.index(element)] == element


# Generated at 2022-06-22 19:33:38.006905
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'msg', 'ver')
    assert dsc[0] == 1


# Generated at 2022-06-22 19:33:41.490953
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = [y for y in range(10)]
    message = 'This is a test'
    version = '2.9'
    dseq = _DeprecatedSequenceConstant(seq, message, version)
    assert len(dseq) == 10

# Generated at 2022-06-22 19:33:43.931274
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t = _DeprecatedSequenceConstant((1, 2, 3), 'sample message', '2.9')
    assert t[1] == 2



# Generated at 2022-06-22 19:33:46.233630
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert x.__len__() == 3


# Generated at 2022-06-22 19:33:51.348238
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    disp_msg = 'This is a test message'
    disp_ver = '2.0'
    seq_const = _DeprecatedSequenceConstant('abcde', disp_msg, disp_ver)
    # test the len() function of _DeprecatedSequenceConstant
    assert len(seq_const) == 5, "len() function of  _DeprecatedSequenceConstant failed"
    # test the __getitem__() function of _DeprecatedSequenceConstant
    assert seq_const[0] == 'a', "__getitem__() function of  _DeprecatedSequenceConstant failed"

# Generated at 2022-06-22 19:34:03.029099
# Unit test for function set_constant
def test_set_constant():
    assert 'CONFIG_FILE' in vars()
    assert ALLOWED_INTERNAL_ADDRESSES == [u'127.0.0.1']
    assert ANSIBLE_MODULE_EXTS == [u'.ps1', u'.py']
    assert ANSIBLE_MODULE_REQUIRE == set(MODULE_REQUIRE_ARGS)
    assert ANSIBLE_MODULE_NO_JSON == set(MODULE_NO_JSON)
    assert ANSIBLE_FORCE_COLOR == True
    assert DEFAULT_HASH_BEHAVIOUR == [u'replace']
    assert DEFAULT_LOG_PATH == u'/dev/null'
    assert DEFAULT_MODULE_NAME == u'command'
    assert DEFAULT_MODULE_PATH == [u'/usr/share/ansible/plugins/modules']
   

# Generated at 2022-06-22 19:34:04.049015
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0


# Generated at 2022-06-22 19:34:16.818860
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        assert locals()[setting.name] == setting.value

# LEGACY MAPPING ###
# TODO: remove the legacy parts
# legacy vars
DEFAULT_SUDO_PASS = DEFAULT_BECOME_PASS
DEFAULT_SUDO_EXE = DEFAULT_BECOME_EXE
DEFAULT_SUDO_FLAGS = DEFAULT_BECOME_FLAGS
DEFAULT_SU_PASS = DEFAULT_BECOME_PASS

# FIXME: remove the following; used to be actual constants
# these are now members of the Options class
DEFAULT_ROLES_PATH = 'roles'
DEFAULT_MODULE_PATH = 'library'
DEFAULT_ACTION_PLUGIN_PATH = 'action_plugins'
DEFAULT_CACHE_

# Generated at 2022-06-22 19:34:20.665187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    if not isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version'), _DeprecatedSequenceConstant):
        raise AssertionError("_DeprecatedSequenceConstant constructor is not working")


# Generated at 2022-06-22 19:34:27.874172
# Unit test for function set_constant
def test_set_constant():

    # Create a dict to pass as export
    def_dict = dict()

    # Add a setting that is absent in config
    set_constant('foo_setting', 'foo_value', export=def_dict)

    # Check if the setting is present in dict
    assert('foo_setting' in def_dict)

    # Check if the value is equal to the expected
    assert(def_dict['foo_setting'] == 'foo_value')

# Generated at 2022-06-22 19:34:34.568825
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Define data
    value = ['foo', 'bar']
    msg = 'This is deprecated'
    version = '2.9'

    # Remove all items of a list
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == 'foo'
    assert deprecated_sequence_constant[1] == 'bar'



# Generated at 2022-06-22 19:34:36.688436
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(["a", "b"], "msg", "version")
    assert a[0] == "a"
    assert a[1] == "b"

# Generated at 2022-06-22 19:34:38.724802
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj1 = _DeprecatedSequenceConstant([1,2,3], msg='msg', version='version')
    assert len(obj1) == 3


# Generated at 2022-06-22 19:34:42.578711
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = 'test value'
    test_msg = 'test message'
    test_version = 'test version'
    test_sequence_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_sequence_constant[0] == test_value[0]
    assert test_sequence_constant[-1] == test_value[-1]



# Generated at 2022-06-22 19:34:45.039506
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'hello'
    version = '10.0'
    test_list = [1, 2, 3]
    assert _DeprecatedSequenceConstant(test_list, msg, version) == test_list

# Generated at 2022-06-22 19:34:50.299159
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for method __len__ (1/2)
    test_len_1_2 = _DeprecatedSequenceConstant([1, 2, 3], "Test deprecated sequence", "2.0")
    assert len(test_len_1_2) == 3


# Generated at 2022-06-22 19:34:54.184948
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    data = (_DeprecatedSequenceConstant(['foo'], "This is a test message", "3.0"),)
    assert data[0][0] == 'foo'
    assert len(data[0]) == 1

# Generated at 2022-06-22 19:35:04.183741
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class CustomException(Exception):
        pass

    test_value = 'test'
    test_msg = 'test message'
    test_version = '2.0'

    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    assert test_obj['test'] == test_value
    assert test_obj['test'] == test_value
    assert test_obj['test'] == test_value
    try:
        test_obj['test']
        raise CustomException('AnsibleDeprecationWarning not raised')
    except AnsibleDeprecationWarning as e:
        assert test_msg in str(e)
        assert test_version in str(e)

# Generated at 2022-06-22 19:35:11.803700
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test with valid data
    test_value = ['one', 'two', 'three']
    dsc = _DeprecatedSequenceConstant(test_value, 'msg', 'version')
    assert len(dsc) == len(test_value)

    # Test with invalid data
    test_value = set(['one', 'two', 'three'])
    dsc = _DeprecatedSequenceConstant(test_value, 'msg', 'version')
    assert len(dsc) == len(test_value)


# Generated at 2022-06-22 19:35:14.681630
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import ansible.constants as consts
    assert consts._DeprecatedSequenceConstant(['a'], 'msg', 'version')[0] == 'a'


# Generated at 2022-06-22 19:35:17.497102
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('foo', 'bar', export)
    assert export['foo'] == 'bar'


# FIXME: remove once play_context mangling is removed

# Generated at 2022-06-22 19:35:20.473701
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('FOO', 'bar', export=d)
    assert d['FOO'] == 'bar'

# Generated at 2022-06-22 19:35:23.215082
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_LIBRARY == '/ansible/library'
    assert DEFAULT_VAULT_ID_MATCH == '^$'


# Generated at 2022-06-22 19:35:27.035743
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'a test message', '2.8')
    assert len(constant) == 3
    assert constant[0] == 'a'
    assert constant[1] == 'b'
    assert constant[2] == 'c'

# Generated at 2022-06-22 19:35:34.058080
# Unit test for function set_constant
def test_set_constant():
    # Make sure set_constant works as expected
    # Simpler to test this here than in test/unit/conftest.py
    # Change the constant value
    set_constant('FOO', 123)
    assert FOO == 123
    # Make sure a exception is raised when the constant already exists
    try:
        set_constant('FOO', 234)
        raise Exception("Trying to set an existing constant did not fail!")
    except ValueError:
        pass  # this is the expected behavior

# Generated at 2022-06-22 19:35:37.793560
# Unit test for function set_constant
def test_set_constant():
    assert not '_TEST_CONSTANT' in locals()
    set_constant('_TEST_CONSTANT', 'foo')
    assert locals().get('_TEST_CONSTANT') == 'foo'
    del _TEST_CONSTANT

# Generated at 2022-06-22 19:35:49.281280
# Unit test for function set_constant
def test_set_constant():
    set_constant.__globals__['__builtins__']['__name__'] = '__main__'
    set_constant('testing', 'foo')
    assert testing == 'foo'

    # file name can be anything, but must have an extension
    templatable_filename = ''.join(['{{ ansible_version }}', '{{ansible_python_interpreter|basename}}'])
    set_constant('testing', templatable_filename)
    assert testing == __version__ + '/python'

# vault version to write out
set_constant('DEFAULT_VAULT_ID_MATCH', None)
set_constant('DEFAULT_VAULT_ID', None)

# Generated at 2022-06-22 19:35:53.735230
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant((1, 2, 3), msg='', version='')
    assert constant[0] == 1
    assert constant[1] == 2
    assert constant[2] == 3


# Generated at 2022-06-22 19:35:56.621321
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "This is deprecated"
    version = "2.12.0"
    lst = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert lst[0] == 1
    assert lst[1] == 2
    assert lst[2] == 3


# Generated at 2022-06-22 19:36:03.656000
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my_value = ['item1', 'item2']
    my_msg = 'This is my test message'
    my_version = '2.9'
    test_sequence_constant = _DeprecatedSequenceConstant(my_value, my_msg, my_version)
    assert len(test_sequence_constant) == 2
    assert test_sequence_constant[0] == 'item1'
    assert test_sequence_constant[1] == 'item2'


# Generated at 2022-06-22 19:36:08.402095
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant('ansible.constants.MAGIC_VARIABLE_MAPPING', 'This is a deprecated message', '3.0')
    assert len(deprecated)
    assert deprecated[0]
    assert deprecated[1]
    assert deprecated._msg
    assert deprecated._version
    assert deprecated._value

# Generated at 2022-06-22 19:36:11.817562
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    m = "testing"
    v = "2.7"
    x = _DeprecatedSequenceConstant([1,2,3], m, v)
    len(x)
    x[0]


# Generated at 2022-06-22 19:36:15.656293
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create an instance of _DeprecatedSequenceConstant with value [1,2,3] and an arbitrary message
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "Unit test", "2.9")
    # Assert that the length of dsc is 3
    assert len(dsc) == 3
    # Assert that dsc[0] is 1
    assert dsc[0] == 1

# Generated at 2022-06-22 19:36:25.957994
# Unit test for function set_constant
def test_set_constant():

    def test_values(value, expected):

        # Test to make sure we don't break the value or type
        test_value = value
        expected = expected
        set_constant('test', value, locals())
        assert test_value == expected

    test_values(None, None)
    test_values('test', 'test')
    test_values('{{ ansible_version }}', __version__)
    test_values('{{ 5 }}', 5)

    # Test for boolean
    test_values('False', False)
    test_values('True', True)
    test_values(True, True)
    test_values(False, False)

    # Test for lists
    test_values('{{ [5, 6] }}', [5, 6])

    # Test for dictionaries

# Generated at 2022-06-22 19:36:27.604547
# Unit test for function set_constant
def test_set_constant():
    x = {}
    set_constant('FOO', True, export=x)
    assert x['FOO'] is True
    assert FOO is True


# Generated at 2022-06-22 19:36:32.845451
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant(value=[], msg='test', version='test')
    assert len(c) == 0
    c = _DeprecatedSequenceConstant(value=[1], msg='test', version='test')
    assert len(c) == 1


# Generated at 2022-06-22 19:36:38.390123
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """
    >>> test__DeprecatedSequenceConstant()
    0
    """
    l = _DeprecatedSequenceConstant([1,2,3], "msg", "version")
    return 0

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 19:36:47.175242
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor with a string msg
    constant = _DeprecatedSequenceConstant(["hello", "world"], "deprecation msg", "2.4")

    assert constant._value == ["hello", "world"]
    assert constant._msg == "deprecation msg"
    assert constant._version == "2.4"

    # Test constructor with a list msg
    constant = _DeprecatedSequenceConstant(["hello", "world"], ["deprecation", "msg"], "2.4")

    assert constant._value == ["hello", "world"]
    assert constant._msg == ["deprecation", "msg"]
    assert constant._version == "2.4"

    # Test constructor with a dict msg
    constant = _DeprecatedSequenceConstant(["hello", "world"], {"deprecation": "msg"}, "2.4")

    assert constant

# Generated at 2022-06-22 19:36:49.802079
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    foo = _DeprecatedSequenceConstant(value=[], msg='bar', version='0')
    assert foo[0] == []



# Generated at 2022-06-22 19:36:57.779544
# Unit test for function set_constant
def test_set_constant():
    constants = dict()
    set_constant('TEST_CONSTANT', True, export=constants)
    set_constant('TEST_CONSTANT_TEMPLATE', '{{TEST_CONSTANT}}', export=constants)
    set_constant('TEST_CONSTANT_INT', 1, export=constants)
    set_constant('TEST_CONSTANT_TEMPLATE2', '{{TEST_CONSTANT_INT}}', export=constants)

    assert constants['TEST_CONSTANT'] is True
    assert constants['TEST_CONSTANT_TEMPLATE'] == 'True'
    assert constants['TEST_CONSTANT_INT'] == 1
    assert constants['TEST_CONSTANT_TEMPLATE2'] == '1'



# Generated at 2022-06-22 19:37:04.165417
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # _DeprecatedSequenceConstant implements the method __getitem__
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="msg", version="1.2.2")
    dsc_item1 = dsc[0]
    dsc_item2 = dsc[1]
    assert dsc_item1 == 1
    assert dsc_item2 == 2

# Generated at 2022-06-22 19:37:15.752513
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(('foo', 'bar', 'baz'), 'test message', '2.9')
    assert test[0] == 'foo'
    assert test[1] == 'bar'
    assert test[2] == 'baz'
    assert test[-1] == 'baz'
    assert test[-2] == 'bar'
    assert test[-3] == 'foo'
    assert len(test) == 3

# FIXME: remove once deprecations are removed
# the following are deprecated (and intended to be removed in
# Ansible 2.0)

# Generated at 2022-06-22 19:37:25.789315
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def _test_len(seq):
        assert len(seq) == len(seq._value)

    seq = _DeprecatedSequenceConstant([1, 2, 3], 'xx', '2.11')
    _test_len(seq)

    seq = _DeprecatedSequenceConstant((1, 2, 3), 'xx', '2.11')
    _test_len(seq)

    seq = _DeprecatedSequenceConstant('123', 'xx', '2.11')
    _test_len(seq)


# Generated at 2022-06-22 19:37:36.200293
# Unit test for function set_constant
def test_set_constant():
    assert not hasattr(test_set_constant, 'test1')
    assert not hasattr(test_set_constant, 'test2')
    c = {'test1': 1}
    set_constant('test1', 1, c)
    assert hasattr(test_set_constant, 'test1')
    assert test_set_constant.test1 == 1
    set_constant('test2', 2, c)
    assert hasattr(test_set_constant, 'test2')
    assert test_set_constant.test2 == 2

# Generated at 2022-06-22 19:37:43.512946
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class TestClass:
        def __init__(self, iterable):
            self._value = iterable

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test_getitem_at_zero(self):
            dep_seq_const = _DeprecatedSequenceConstant(TestClass([1, 2, 3]), 'msg', 'ver')
            self.assertEqual(dep_seq_const[0], 1)

        def test_getitem_at_one(self):
            dep_seq_const = _DeprecatedSequenceConstant(TestClass([1, 2, 3]), 'msg', 'ver')

# Generated at 2022-06-22 19:37:47.335810
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([], '', ''), Sequence)
    assert len(_DeprecatedSequenceConstant([1, 2], '', '')) == 2

# Generated at 2022-06-22 19:37:51.403188
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(value=['test'], msg='sample', version='2.0')
    assert dsc.__len__() == 1
    assert dsc.__getitem__(0) == 'test'

test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:37:53.348523
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list('123'), 'msg', 'version')) == 3

# Generated at 2022-06-22 19:37:55.235443
# Unit test for function set_constant
def test_set_constant():
    test_var = 'random_var'
    test_val = 'ansible_var'
    set_constant(test_var, test_val)
    assert(test_var == test_val)



# Generated at 2022-06-22 19:38:00.001643
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class DSC(object):
        def __len__(self):
            return 500

    dsc = DSC()

    dsc_wrapper = _DeprecatedSequenceConstant(dsc, msg="msg", version="version")
    pass

    return

# Generated at 2022-06-22 19:38:04.652582
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence = tuple(range(1, 11))
    deprecated = _DeprecatedSequenceConstant(sequence, 'TEST', '2.9')
    assert len(deprecated) == 10
    assert len([_ for _ in deprecated]) == 10
    assert deprecated[3] == 4
    assert deprecated[-1] == 10



# Generated at 2022-06-22 19:38:06.560762
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST', 'ok')
    assert ANSIBLE_TEST == 'ok'


# Generated at 2022-06-22 19:38:13.579173
# Unit test for function set_constant
def test_set_constant():
    v = {'foo': 'test'}
    set_constant('test_set_constant_foo', 'test', v)
    set_constant('test.set.constant.dotted.foo', 'test', v)
    set_constant('test_set_constant_bar', u'test', v)

    assert v['test_set_constant_foo'] == 'test'
    assert v['test.set.constant.dotted.foo'] == 'test'
    assert v['test_set_constant_bar'] == u'test'

# Generated at 2022-06-22 19:38:16.652302
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([1,2], "xxxx", "2.7")
    assert len(x) == 2
    assert len(x) == 2  # make sure warning is printed only once

# Generated at 2022-06-22 19:38:20.551785
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.utils.collection_loader import _DeprecatedSequenceConstant
    f = _DeprecatedSequenceConstant([1, 2, 3], 'foo', '2.0')
    assert len(f) == 3


# Generated at 2022-06-22 19:38:26.430753
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = 'test version'

    test_value = [1, 2, 3]
    test_constant = _DeprecatedSequenceConstant(test_value, msg, version)
    assert(len(test_constant) == len(test_value))
    assert(test_constant[1] == test_value[1])



# Generated at 2022-06-22 19:38:35.754675
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.collection_loader import _get_collection_role_paths
    collection_paths = _get_collection_role_paths()
    for fqcn, dirs in collection_paths.items():
        # For now, skip ansible_galaxy.
        if fqcn == 'ansible_galaxy':
            continue

        # _get_collection_role_paths() returns a dictionary keyed by FQCN.
        # But _DeprecatedSequenceConstant expects a FQCN list with index 0.
        fqcn_list = [fqcn]
        dep = _DeprecatedSequenceConstant(value=fqcn_list, msg='', version='2.10')
        assert(dep[0] is fqcn_list[0])

# Generated at 2022-06-22 19:38:36.990288
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant([1, 2, 3], "This should be deprecated", "2.5").__len__()


# Generated at 2022-06-22 19:38:39.850234
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(list(), 'Some message', '2.9')

    assert dsc[-1] == []



# Generated at 2022-06-22 19:38:42.214482
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert len(sequence) == 3


# Generated at 2022-06-22 19:38:49.785708
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test 1 - test that the number of elements returned by __len__ of _DeprecatedSequenceConstant matches the length of the input
    input_sequence = ['Hello World', 'This is a test', 'test', 'TEST']
    message = 'This is a test'
    version = '12.34.56'
    assert len(input_sequence) == len(_DeprecatedSequenceConstant(input_sequence, message, version))

    # Test 2 - test that the number of elements returned by __len__ of _DeprecatedSequenceConstant matches the length of the input
    input_sequence = ['Hello World', 'This is a test', 'test', 'TEST']
    message = 'This is a test'
    version = '12.34.56'

# Generated at 2022-06-22 19:38:52.297877
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], "msg", "ver")
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3

# Generated at 2022-06-22 19:38:57.489639
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.constants import _DeprecatedSequenceConstant
    assert len(_DeprecatedSequenceConstant((1, 3, 4), 'this is a test', '2.9')) is 3

# Generated at 2022-06-22 19:38:59.051724
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant((1, 2, 3), "Test warning", "2.9")
    assert len(constant) == 3
    assert len(constant) == 3


# Generated at 2022-06-22 19:39:10.886324
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest

    class ConstructorTest(unittest.TestCase):
        pass

    val = (1, 2, 3)
    msg = 'This is a test'
    version = '2.9.0'
    dconst = _DeprecatedSequenceConstant(val, msg, version)

    def test_equal():
        assert len(dconst) == len(val)
        for x in range(0, len(val)):
            assert dconst[x] == val[x]

    ConstructorTest.test_equal = test_equal
    setattr(ConstructorTest, 'test_equal', test_equal)

    unittest.main(ConstructorTest, exit=False)

# Generated at 2022-06-22 19:39:14.866132
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # _DeprecatedSequenceConstant([0, 1, 2], 'msg', '0.1').__len__()
    assert 5 == _DeprecatedSequenceConstant((0,1,2,3,4), 'msg', '0.1').__len__()


# Generated at 2022-06-22 19:39:16.692405
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 19:39:20.131916
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    testConstant = _DeprecatedSequenceConstant(['test'], 'test message', 'test version')
    assert len(testConstant) == 1
    assert testConstant[0] == 'test'

# Generated at 2022-06-22 19:39:25.129610
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_list = ["This", "is", "a", "test", "List"]
    dsc = _DeprecatedSequenceConstant(test_list, "This is a test message", "2.8")
    assert dsc.__len__() == 5
    assert dsc.__getitem__(2) == "a"

# Generated at 2022-06-22 19:39:35.362104
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    def f(value, length):
        c = _DeprecatedSequenceConstant(value, 'msg', 'version')
        try:
            len(c)
        except Exception:
            return False
        return len(c) == length

    # True cases
    true_cases = [
        ([], 0),
        (['A'], 1),
    ]
    for value, length in true_cases:
        if not f(value, length):
            raise AssertionError('test__DeprecatedSequenceConstant___len__() failed at case {}.'.format(value))

    # False cases
    false_cases = [
        ([], 1),
        (['A'], 0),
    ]

# Generated at 2022-06-22 19:39:47.185817
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant(('a','b','c'), 'msg', 'version')
    assert test[0] == 'a'
    assert test[1] == 'b'
    assert test[2] == 'c'
    # Checks that deprecation message occurs
    # when using method __getitem__ of class _DeprecatedSequenceConstant
    import warnings
    import unittest.mock as mock_module
    with warnings.catch_warnings(record=True) as warning_list:
        u = test[0]
        assert test[0] == 'a'
        assert isinstance(u, mock_module.Mock)
    # Check that message has correct format
    assert len(warning_list) == 1

# Generated at 2022-06-22 19:39:54.046199
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test1', 'test2', 'test3']
    test_msg = 'test message'
    test_version = 'some version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == 3
    assert test_object[0] == 'test1'

# Generated at 2022-06-22 19:39:56.241481
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_CONFIG', '/tmp/ansible.cfg')
    assert ANSIBLE_CONFIG == '/tmp/ansible.cfg'

# Generated at 2022-06-22 19:40:06.943112
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test for __len__ if __getitem__ is not implemented
    class _SequenceTestClass_1(object):
        pass
    obj = _SequenceTestClass_1()
    obj.__len__ = _DeprecatedSequenceConstant.__len__
    obj._value = [1]
    obj._msg = "test messsage"
    obj._version = "2.6"
    assert len(obj) == 1

    # Test for __len__ if __getitem__ is implemented
    class _SequenceTestClass_2(object):
        def __getitem__(self, key):
            return self._value[key]
    obj = _SequenceTestClass_2()
    obj.__len__ = _DeprecatedSequenceConstant.__len__
    obj._value = [1]

# Generated at 2022-06-22 19:40:09.494315
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_sequence = _DeprecatedSequenceConstant([1, 2], "test", "2.0")
    assert len(test_sequence) == 2
    assert test_sequence[1] == 2

# Generated at 2022-06-22 19:40:16.736614
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(['item1', 'item2', 'item3'], 'msg', 'version')
    assert x[0] == 'item1' and x[1] == 'item2' and x[2] == 'item3'
    assert x[-1] == 'item3' and x[-2] == 'item2' and x[-3] == 'item1'



# Generated at 2022-06-22 19:40:26.003128
# Unit test for function set_constant
def test_set_constant():
    tmp_config = config.foo
    set_constant('ansible_foo', 'override', locals())
    assert(ansible_foo == 'override')
    set_constant('ansible_foo', tmp_config, locals())


# Now we add the variables that don't come from config files
# this has to be done after the config file is loaded, so that
# defaults are set before they are overridden

# FIXME: remove vault_*
set_constant("vault_version", VAULT_VERSION_MIN)
set_constant("vault_version_max", VAULT_VERSION_MAX)
set_constant("__version__", __version__)
set_constant("INVALID_VARIABLE_NAMES", INVALID_VARIABLE_NAMES)

# Set the following into local scope

# Generated at 2022-06-22 19:40:29.269534
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], "msg", "version")) == 0
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3
