

# Generated at 2022-06-22 19:30:31.782820
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ["first", "second"]
    test_msg = "Message from the future!"
    test_version = "1.0"

    seq = _DeprecatedSequenceConstant(test_value, test_msg, test_version)

    seq[0]
    seq[1]



# Generated at 2022-06-22 19:30:36.284245
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    sequence = _DeprecatedSequenceConstant([], '', '')
    assert len(sequence) == 0

    sequence = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert len(sequence) == 3



# Generated at 2022-06-22 19:30:41.857725
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(value='test_value',
                                           msg='test_msg',
                                           version='test_version')
    assert len(constant) != 0
    assert constant[0] == 'test_value'

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 19:30:46.294236
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    s = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert isinstance(s, Sequence)
    assert len(s) == 3


# Generated at 2022-06-22 19:30:51.656170
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1,2,3], "test _DeprecatedSequenceConstant", "2.0")
    assert len(a) == 3
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3

# Generated at 2022-06-22 19:30:56.602099
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for invalid values to constructor
    try:
        # Non-sequence object
        sequence = 'A'
        msg = 'Test Msg'
        version = 'Test version'
        deprecated_sequence_constant = _DeprecatedSequenceConstant(sequence, msg, version)
    except ValueError as e:
        assert 'ValueError' in str(e), \
               "_DeprecatedSequenceConstant accepts non-sequence object as argument"


# Generated at 2022-06-22 19:31:00.555410
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant(value=[1,2,3], msg="msg", version="version")
    assert result[1] == 2


# Generated at 2022-06-22 19:31:05.980418
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant('the value', 'the message', 'the version')
    assert c[0] == 'the value'[0]
    assert c[-1] == 'the value'[-1]
    assert len(c) == len('the value')



# Generated at 2022-06-22 19:31:12.690454
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(['1', '2', '3'], 'msg', 'version')
    assert constant[0] == '1'
    assert constant[1] == '2'
    assert constant[2] == '3'


# Generated at 2022-06-22 19:31:19.795339
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest
    msg = "foo"
    version = "bar"
    test_options = {'foo': 'bar'}
    dsc = _DeprecatedSequenceConstant(test_options, msg, version)
    class Test_DeprecatedSequenceConstant(unittest.TestCase):
        def test___getitem__(self):
            assert dsc[0] == 'bar'
    unittest.main()


# Generated at 2022-06-22 19:31:27.859407
# Unit test for function set_constant
def test_set_constant():
    ''' assert constant creation works '''
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

    set_constant('TEST_CONSTANT_INT', 5, export=globals())
    assert isinstance(TEST_CONSTANT_INT, int)
    assert TEST_CONSTANT_INT == 5

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-22 19:31:30.605301
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = 'test_value'
    dsc = _DeprecatedSequenceConstant(expected, 'test_msg', 'test_version')
    actual = dsc[0]
    assert expected == actual


# Generated at 2022-06-22 19:31:34.254210
# Unit test for function set_constant
def test_set_constant():
    namespace = {}
    set_constant('FOO', True, export=namespace)
    assert namespace['FOO'] is True


# Generated at 2022-06-22 19:31:41.257153
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import is_sequence
    msg = 'This is a test.'
    version = '2.11'
    value = ['A', 'B']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert is_sequence(dsc)
    assert dsc[1] == 'B'
    assert len(dsc) == 2

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:31:45.481212
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(['a1', 'b2', 'c3'], "msg", "version")
    assert sequence[0] == "a1"
    assert sequence[-1] == "c3"



# Generated at 2022-06-22 19:31:50.281378
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    S = _DeprecatedSequenceConstant(['foo', 'bar'], "foo is deprecated", "2.15")
    assert len(S) == 2
    assert S[0] == 'foo'
    assert S[1] == 'bar'

# Generated at 2022-06-22 19:31:53.269773
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([], '', 'version_string')
    assert callable(a.__len__())
    assert callable(a.__getitem__())

# Generated at 2022-06-22 19:31:56.776524
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([True, False], 'test', '2.0')
    assert dsc[0] is True
    assert dsc[1] is False
    assert len(dsc) == 2


# Generated at 2022-06-22 19:31:59.115232
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], u'This is deprecated', u'v2.10')
    test_val = len(test_obj)
    assert test_val == 3


# Generated at 2022-06-22 19:32:03.454312
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    data = [1, 2, 3, 4]
    message = 'The deprecation message'
    version = '2.9'
    constant = _DeprecatedSequenceConstant(data, message, version)
    assert constant[2] == 3


# Generated at 2022-06-22 19:32:07.091478
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dummy = ['a', 'b', 'c']
    example = _DeprecatedSequenceConstant(dummy, 'msg', '0.0')
    for i in range(len(dummy)):
        assert example[i] == dummy[i]

# Generated at 2022-06-22 19:32:09.250552
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant([1, 2, 3], 'Sequence deprecated', '2.9')
    assert len(l) == 3


# Generated at 2022-06-22 19:32:18.287180
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Make sure that len() returns a value
    seq = _DeprecatedSequenceConstant(1, 'A', '1.0')
    assert len(seq) is not None

    # Make sure that the values are retrieved correctly
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'A', '1.0')
    assert seq[0] == 1
    assert seq[1] == 2

    # Make sure that the deprecation warning is raised when values are retrieved
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'A', '1.0')
    with pytest.warns(DeprecationWarning):
        assert seq[0] == 1
        assert seq[1] == 2

# Generated at 2022-06-22 19:32:23.082948
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(SOURCE_HIGHLIGHT_CONF, string_types)
    assert isinstance(SOURCE_HIGHLIGHT_STYLE, string_types)
    assert isinstance(DEFAULT_VAULT_IDENTITY_LIST, list)

# Generated at 2022-06-22 19:32:32.418040
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    for x in [
        "['test1']",
        "{'test2'}",
        "test3",
        ]:

        dsc = _DeprecatedSequenceConstant(x, "msg", "version")
        assert len(dsc) == 1

        for y in [
            0,
            -1,
            len(x),
            ]:
            assert dsc[y] == x[y]


# special generation of module_utils deprecation warnings
# this is used by AnsibleCollectionFinder, so needs to be defined after the constants

# Generated at 2022-06-22 19:32:35.217547
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_string = 'Test String'
    dep_seq_const = _DeprecatedSequenceConstant(test_string, 'Ms', '1.0')
    assert len(dep_seq_const) == len(test_string)


# Generated at 2022-06-22 19:32:44.689787
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert list(range(10)) == _DeprecatedSequenceConstant(value=range(10), msg='Error', version='1.0')
    assert list(range(10)) == _DeprecatedSequenceConstant(value=range(10), msg='Error', version='1.0')[:]
    assert list(range(10)) == _DeprecatedSequenceConstant(value=range(10), msg='Error', version='1.0')[0:10]
    assert list(range(10)) == _DeprecatedSequenceConstant(value=range(10), msg='Error', version='1.0')[0:5:2]
    assert list(range(10)) == _DeprecatedSequenceConstant(value=range(10), msg='Error', version='1.0')[::1]
    assert list(range(10)) == _Dep

# Generated at 2022-06-22 19:32:48.803599
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant((1,2,3), 'test_msg', 'test_version')
    result = test_obj.__len__()
    assert result == 3


# Generated at 2022-06-22 19:32:51.398055
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'msg', '17.5.5')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 19:32:53.194133
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(None,'msg', 'ver')
    assert constant.__len__ == len(constant._value)

# Generated at 2022-06-22 19:32:55.754361
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    observed = _DeprecatedSequenceConstant((1, 2, 3, 4), "test message", "test version")
    assert len(observed) == 4


# Generated at 2022-06-22 19:33:03.787025
# Unit test for function set_constant
def test_set_constant():
    dummy_dict = {}

    # Test value assignment
    set_constant("test_constant", "test_value", export=dummy_dict)
    assert(dummy_dict['test_constant'] == "test_value")

    # Test that the constant cannot be overwritten
    set_constant("test_constant", "test_value2", export=dummy_dict)
    assert(dummy_dict['test_constant'] == "test_value")


# Generated at 2022-06-22 19:33:07.815339
# Unit test for function set_constant
def test_set_constant():
    x = dict()
    assert x.get('ANSIBLE_CONFIG') is None
    set_constant('ANSIBLE_CONFIG', 'foo', x)
    assert x.get('ANSIBLE_CONFIG') == 'foo'


# Generated at 2022-06-22 19:33:10.208134
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "1.2.3")[1] == 2


# Generated at 2022-06-22 19:33:16.339944
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # TODO: move to unit tests
    test_value = [1, 2, 3]
    test_instance = _DeprecatedSequenceConstant(test_value, 'msg', 'ver')
    assert test_instance[1] == test_value[1]
    assert test_instance[0] == test_value[0]
    assert test_instance[2] == test_value[2]

# Generated at 2022-06-22 19:33:23.425091
# Unit test for function set_constant
def test_set_constant():
    ''' unit test for set_constant '''

    # good constant
    set_constant('FOO', 'bar', export=globals())

    # good constant
    set_constant('FOO2', 'baz', export=locals())

    # not real constant
    def foo():
        pass

    if hasattr(foo, '__code__'):
        set_constant('FOO2', 'baz', export=foo.__code__.co_names)
    else:
        set_constant('FOO2', 'baz', export=foo.func_code.co_names)

    locals()['FOO3'] = 'bar'


# Generated at 2022-06-22 19:33:35.291842
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test invalid input
    invalid_inputs = [None, '', [], {}, (), 0]
    for bad_input in invalid_inputs:
        c = _DeprecatedSequenceConstant(['a', 'b', 'c'], None, None)
        try:
            c.__getitem__(bad_input)
        except Exception:
            pass
        else:
            assert False, 'bad input: %s' % bad_input

    # test valid input
    c = _DeprecatedSequenceConstant(['a', 'b', 'c'], None, None)
    assert c.__getitem__(0) == 'a'
    assert c.__getitem__(1) == 'b'
    assert c.__getitem__(2) == 'c'

# Generated at 2022-06-22 19:33:38.736622
# Unit test for function set_constant
def test_set_constant():
    v = {}
    set_constant("FOO", "BAR", v)
    assert v['FOO'] == "BAR"

# Generated at 2022-06-22 19:33:44.200095
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_subject = _DeprecatedSequenceConstant(
        _ACTION_INCLUDE_TASKS,
        'include_tasks is deprecated in Ansible 2.8 and will be removed in Ansible 2.12. '
        'Include tasks from files explicitly using the import_tasks module instead.',
        '2.12')

    assert len(test_subject) == len(_ACTION_INCLUDE_TASKS)



# Generated at 2022-06-22 19:33:48.525119
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    testmsg = 'this is a test message'
    testversion = '1.0'
    test = _DeprecatedSequenceConstant((1, 2, 3), testmsg, testversion)
    test[1]
    test["one"]
    test[-1]
    test[0:2:1]
    test[0:2:2]
    test[::1]
    test[::-1]

# Generated at 2022-06-22 19:33:51.674690
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'Unittest __getitem__'
    version = '2.8'
    sequence = ['apple', 'banana', 'orange']
    value = _DeprecatedSequenceConstant(sequence, msg, version)
    assert value[0] == 'apple'
    assert value[1] == 'banana'
    assert value[2] == 'orange'


# Generated at 2022-06-22 19:33:55.081450
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'deprecated'
    version = '2.9'
    test_list = ['test_string', ]
    test_list_obj = _DeprecatedSequenceConstant(value=test_list, msg=msg, version=version)
    assert test_list_obj[0] == 'test_string'



# Generated at 2022-06-22 19:34:00.958705
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class TestClass:
        def __init__(self):
            self.warned = 0

        def warning(self, msg):
            self.warned += 1

    display = TestClass()
    dsc = _DeprecatedSequenceConstant([1,2,3], "test", "version")
    len(dsc)
    assert(display.warned == 1)

# Generated at 2022-06-22 19:34:05.205585
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Make sure _DeprecatedSequenceConstant can be constructed.
    value = _DeprecatedSequenceConstant(['test'], 'test', '1.0')

    assert value._value == ['test']
    assert value._msg == 'test'
    assert value._version == '1.0'

    assert len(value) == 1



# Generated at 2022-06-22 19:34:07.616948
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert 0 == __DeprecatedSequenceConstant([], 'msg', 'version')


# Generated at 2022-06-22 19:34:19.955413
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from unittest import TestCase
    from ansible.module_utils.common.collections import Sequence
    class _Test(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            super(_Test, self).__init__(value, msg, version)
    test = _Test(['a', 'b', 'c'], 'message', 'version')
    assert test[1] == 'b'
    assert test[0] == 'a'
    assert test[2] == 'c'
    try:
        _ = test[3]
        assert False
    except IndexError:
        assert True

if __name__ == '__main__':
    # Run local unit tests
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:34:26.076182
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    T = _DeprecatedSequenceConstant((1, 2, 3), "foobar", "2.0")

    sys.stderr = io.StringIO()
    T[0]
    r = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = sys.__stderr__

    assert r == " [DEPRECATED] foobar, to be removed in 2.0\n"



# Generated at 2022-06-22 19:34:29.838690
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = [1, 2]
    d = _DeprecatedSequenceConstant(x, 'msg', '1.2')
    assert d[1] == x[1]



# Generated at 2022-06-22 19:34:40.272993
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant('ansible.windows.win_command', 'deprecated', '1.0')
    assert isinstance(value, _DeprecatedSequenceConstant)
    assert hasattr(value, '_msg')
    assert hasattr(value, '_version')
    assert hasattr(value, '_value')
    assert len(value) == 1
    assert value[0] == 'ansible.windows.win_command'
    assert value._msg == 'deprecated'
    assert value._version == '1.0'

# Run unit tests
test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:34:46.036363
# Unit test for function set_constant
def test_set_constant():

    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

    set_constant('FOO', 42)
    assert FOO == 42

    set_constant('FOO', True)
    assert FOO is True

    set_constant('FOO', None)
    assert FOO is None

    set_constant('FOO', [])
    assert FOO == []

    set_constant('FOO', {})
    assert FOO == {}



# Generated at 2022-06-22 19:34:50.345360
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_LIBEXEC_PATH == '/some/path'
    assert ANSIBLE_LOG_PATH == '/some/other/path'
    assert ANSIBLE_RETRY_FILES_ENABLED == True


# Generated at 2022-06-22 19:35:00.314247
# Unit test for function set_constant
def test_set_constant():

    # Test set_constant
    set_constant('TEST_CONSTANT', "test")
    assert TEST_CONSTANT == "test"

    # Test setting a float constant
    set_constant('TEST_CONSTANT', 2.3)
    assert TEST_CONSTANT == 2.3

    # Test setting a boolean constant
    set_constant('TEST_CONSTANT', True)
    assert TEST_CONSTANT is True

    try:
        del TEST_CONSTANT
    except NameError:
        pass


if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-22 19:35:05.195927
# Unit test for function set_constant
def test_set_constant():
    ''' Test set_constant function '''

    # Default values
    assert ansible_become_method == 'sudo'
    assert ansible_become_user == 'root'

    # Set values
    set_constant('ansible_become_method', 'su')
    set_constant('ansible_become_user', 'admin')

    # Verify new values
    assert ansible_become_method == 'su'
    assert ansible_become_user == 'admin'

    # Reset values
    set_constant('ansible_become_method', 'sudo')
    set_constant('ansible_become_user', 'root')

# Generated at 2022-06-22 19:35:08.809683
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(('foo', 'bar'), 'msg', 'version')
    assert obj[0] == 'foo'
    assert obj[1] == 'bar'


# Generated at 2022-06-22 19:35:11.691256
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant((1,2,3), 'msg', 'version')
    assert len(obj) == 3


# Generated at 2022-06-22 19:35:15.343151
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = {'answer': 42}
    t = _DeprecatedSequenceConstant(test_value, 'msg', 'v3.0.0')
    # The main test
    assert t['answer'] == 42



# Generated at 2022-06-22 19:35:16.955545
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_deprecated_host_key_checking) == 1


# Generated at 2022-06-22 19:35:22.444699
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constants = ['foo', 'bar', 'baz']
    msg = 'This is a test message'
    version = '2.0'
    assert _DeprecatedSequenceConstant(constants, msg, version).__len__() == 3

# Load settings without defaults that have a global default
# This can be removed after deprecation on 2.10

# Generated at 2022-06-22 19:35:26.351472
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    const = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'TEST', 'TEST')
    assert len(const) == 3
    assert const[0] == 'a'
    assert const[1] == 'b'
    assert const[2] == 'c'

# Generated at 2022-06-22 19:35:28.691826
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is the message of the deprecated warning'
    version = '2.1'
    _DeprecatedSequenceConstant(['test', 'Sequence'], msg, version)

# Generated at 2022-06-22 19:35:37.584227
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class TestClass__DeprecatedSequenceConstant___len__(object):
        def test_type(self):
            self.setting.name = 'test_setting_name'
            self.setting.value = 'test_setting_value'
            self.setting.origin = 'test_setting_origin'
            self.setting.type = 'test_setting_type'
            self.setting.section = 'test_setting_section'

            self.add_constant_patcher = patch('ansible.constants.set_constant')
            self.add_constant_mock = self.add_constant_patcher.start()

            add_constant(self.setting)

            self.add_constant_mock.assert_called_with(self.setting.name, self.setting.value, export=vars())

            self

# Generated at 2022-06-22 19:35:41.766994
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for valid input
    input_sentence = _DeprecatedSequenceConstant((1,2,3), "Test of _DeprecatedSequenceConstant", "Version 1")
    assert len(input_sentence) == 3

# Generated at 2022-06-22 19:35:45.941279
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(['foo', 'bar', 'baz'], 'test message', '2.10')
    assert len(dsc) == 3


# Generated at 2022-06-22 19:35:47.979102
# Unit test for function set_constant
def test_set_constant():
    # TODO: redirect stdout to test output
    set_constant('test', '123')


# Generated at 2022-06-22 19:35:54.926938
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    l1 = ['1', '2', '3', '4']
    m = 'this is a message'
    v = '2.2'
    l2 = _DeprecatedSequenceConstant(l1, m, v)
    assert len(l2) == 4
    l1[1] = 'X'
    assert l2[1] == 'X'

# Generated at 2022-06-22 19:35:57.085337
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant(1, 'Test', '1.1')
    assert test_sequence[0] == 1

# Generated at 2022-06-22 19:36:06.703519
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    seq_const = _DeprecatedSequenceConstant([1, 2, 3],
                                            "Testing warning.", "2.10")
    assert len(seq_const) == 3
    assert seq_const[0] == 1
    assert seq_const[1] == 2
    assert seq_const[2] == 3

    # Test with a tuple
    seq_const = _DeprecatedSequenceConstant(("a", "b", "c"),
                                            "Testing warning.", "2.10")
    assert len(seq_const) == 3
    assert seq_const[0] == "a"
    assert seq_const[1] == "b"
    assert seq_const[2] == "c"


# Generated at 2022-06-22 19:36:08.554434
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant('abc', 'test_msg', '2.9')) == 3

# Generated at 2022-06-22 19:36:16.940097
# Unit test for function set_constant
def test_set_constant():
    import os
    import sys
    import tempfile
    new_config = "ansible_managed = true"
    old_config = DEFAULT_CONFIG_FILE

    # Create a new test config
    ansible_cfg = tempfile.NamedTemporaryFile(delete=False)
    tmp_filename = ansible_cfg.name
    ansible_cfg.write(to_text(new_config))
    ansible_cfg.close()

    # save old config for restore
    if old_config:
        old_config_filename = open(old_config).name

    # update environment and defaults with the test config
    os.environ['ANSIBLE_CONFIG'] = tmp_filename
    DEFAULT_CONFIG_FILE = tmp_filename
    reload(sys.modules['ansible.constants'])

    # check if the new test

# Generated at 2022-06-22 19:36:24.841321
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest
    from ansible.parsing.utils.template import _DeprecatedSequenceConstant

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test__DeprecatedSequenceConstant__getitem__(self):

            test_subject = _DeprecatedSequenceConstant([1,2,3], 'test message', '2.0')
            self.assertEqual(1, test_subject[0])
            self.assertEqual(2, test_subject[1])
            self.assertEqual(3, test_subject[2])

    unittest.main()

# Generated at 2022-06-22 19:36:26.772787
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    _DeprecatedSequenceConstant([], msg, version)
    _DeprecatedSequenceConstant(None, msg, version)


# Generated at 2022-06-22 19:36:30.835285
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test __len__()
    test_deprecated_sequence_constant = _DeprecatedSequenceConstant((1, 2, 3), 'Test_message', '1.0')
    assert len(test_deprecated_sequence_constant) == 3



# Generated at 2022-06-22 19:36:36.962503
# Unit test for function set_constant
def test_set_constant():
    ''' sets constants and returns resolved options dict '''

    a = {}
    set_constant('test1', 'value1')
    set_constant('test2', 'value2', a)
    assert 'value1' == test1
    assert 'value2' == a['test2']



# Generated at 2022-06-22 19:36:42.244397
# Unit test for function set_constant
def test_set_constant():
    # Ensure the setting is const.
    set_constant('UNIT_TEST_CONSTANT', 42)
    assert UNIT_TEST_CONSTANT == 42
    try:
        UNIT_TEST_CONSTANT = 1337
    except Exception:
        pass
    else:
        raise Exception('UNIT_TEST_CONSTANT is not immutable')

# Generated at 2022-06-22 19:36:53.413305
# Unit test for function set_constant
def test_set_constant():
    # Test that set_constant works with string values
    set_constant('test_string', 'string')
    assert test_string == 'string'
    set_constant('test_string', 'string', globals())
    assert test_string == 'string'
    # Test that set_constant works with int values
    set_constant('test_int', 1)
    assert test_int == 1
    set_constant('test_int', 1, globals())
    assert test_int == 1
    # Test that set_constant works with boolean values
    set_constant('test_bool', True)
    assert test_bool == True
    set_constant('test_bool', True, globals())
    assert test_bool == True
    # Test that set_constant works with tuple values

# Generated at 2022-06-22 19:36:56.400033
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = add_internal_fqcns(['debug', 'action', 'add_host'])
    deprecated_sequence = _DeprecatedSequenceConstant(sequence, 'msg', 'version')
    assert len(deprecated_sequence) == 3
    assert isinstance(deprecated_sequence, Sequence)

# Generated at 2022-06-22 19:37:07.904237
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    import pytest
    from ansible.module_utils.six import text_type

    # Should return the full value received in the constructor
    assert _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'foo')._value == [1, 2, 3]

    # Should return the index of the value received in the constructor
    assert _DeprecatedSequenceConstant([1, 2, 3], 'foo', 'foo')[0] == 1

    # Should return a _DeprecatedSequenceConstant with the value received in the constructor
    assert isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'foo', 'foo'), _DeprecatedSequenceConstant) is True

    # Should return a _DeprecatedSequenceConstant with the value received in the constructor
   

# Generated at 2022-06-22 19:37:12.500211
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('TEST_ANSIBLE_MODULE_PATH', 'TEST/ANSIBLE/MODULE/PATH') == {'TEST_ANSIBLE_MODULE_PATH': 'TEST/ANSIBLE/MODULE/PATH'}


# Generated at 2022-06-22 19:37:17.018914
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert 'bar' == foo
    assert 'bar' == vars()['foo']


# CONFIGS WHICH WERE CONVERTED TO CONSTANTS AND ARE NO LONGER USED
# FIXME: remove once branches are rebased to 2.8

# Generated at 2022-06-22 19:37:20.604943
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=(), msg="", version="")) == 0
    assert len(_DeprecatedSequenceConstant(value=(1,), msg="", version="")) == 1
    assert len(_DeprecatedSequenceConstant(value=(1,2,3), msg="", version="")) == 3

# Generated at 2022-06-22 19:37:25.395885
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("TEST", "foo") == {'TEST': 'foo'}
    test_dict = dict()
    assert set_constant("TEST", "foo", export=test_dict) == test_dict
    assert test_dict["TEST"] == "foo"

# Generated at 2022-06-22 19:37:32.703497
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _deprecated('[Deprecated] sequence constant', '2.14')
    _DSC_instant = _DeprecatedSequenceConstant(['_DeprecatedSequenceConstant','is','instantiated'], '[Deprecated] sequence constant', '2.14')
    assert len(_DSC_instant) == 3
    assert _DSC_instant[2] == 'instantiated'

# Generated at 2022-06-22 19:37:40.715858
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest
    from collections import abc
    from io import StringIO
    import sys
    seq = ['a', 'b']
    msg = 'this is a warning'
    version = '2.9'
    d = _DeprecatedSequenceConstant(seq, msg, version)
    with pytest.warns(UserWarning) as rec:
        d[1]
    assert len(rec) == 1
    assert issubclass(rec[0].category, UserWarning)
    assert msg in str(rec[0].message)
    assert version in str(rec[0].message)


# Generated at 2022-06-22 19:37:46.039618
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "The test message"
    version = "1.1"
    value = ['test', 'test2']
    x = _DeprecatedSequenceConstant(value, msg, version)
    assert len(x) == 2
    assert x[0] == 'test'
    assert x[1] == 'test2'

# Generated at 2022-06-22 19:37:48.020277
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == '/path/to/ansible.cfg'

# Generated at 2022-06-22 19:37:58.603934
# Unit test for function set_constant
def test_set_constant():
    from ansible.compat.tests import unittest
    from ansible.config.manager import Setting, DataLoader

    class TestConfigManager(ConfigManager):
        def __init__(self, loader=None):
            if loader is None:
                loader = DataLoader()
            super(TestConfigManager, self).__init__(loader)

            # Once set_constant can correctly update exported dicts.
            # we can remove this dict.
            self.long_setting_dict = {}

        def get_setting(self, name):
            setting = Setting(name=name)
            return setting

    def test_string_is_unchanged():
        value = "Hello, World!"
        set_constant(setting.name, value)
        self.assertEquals(value, exported_vars[setting.name])


# Generated at 2022-06-22 19:38:04.142354
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS == None
    assert DEFAULT_REMOTE_PASS == None
    assert DEFAULT_SUBSET == None
    assert TREE_DIR == None
    assert DEFAULT_PASSWORD_CHARS == u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'

# Generated at 2022-06-22 19:38:05.738201
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test
    assert len(_DeprecatedSequenceConstant(('1', '2'), 'msg', 'version')) == 2

# Generated at 2022-06-22 19:38:11.482716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test if two objects of _DeprecatedSequenceConstant are the same
    obj = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    obj1 = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert obj[1] == obj1[1]

    # test if a error message is displayed
    assert repr(obj[0]) == '2'


# Generated at 2022-06-22 19:38:20.284015
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_METHOD == 'sudo'
    assert not COLLECTION_PLAYBOOK_PATHS
    assert config.data['DEFAULT_BECOME_METHOD'] == DEFAULT_BECOME_METHOD
    assert config.data['COLLECTION_PLAYBOOK_PATHS'] == COLLECTION_PLAYBOOK_PATHS
    assert config.data['COLLECTION_PLAYBOOK_PATHS'] is COLLECTION_PLAYBOOK_PATHS
    assert config.data['DEFAULT_BECOME_METHOD'] is DEFAULT_BECOME_METHOD

# Generated at 2022-06-22 19:38:24.779923
# Unit test for function set_constant
def test_set_constant():
    constants = dict()
    set_constant('a_constant', 'a_value', constants)
    set_constant('another_constant', 5, constants)

    assert constants['a_constant'] == 'a_value'
    assert constants['another_constant'] == 5



# Generated at 2022-06-22 19:38:27.040291
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'value', export=vars())


# Generated at 2022-06-22 19:38:36.286861
# Unit test for function set_constant
def test_set_constant():
    # Test constants declarations
    assert ANSIBLE_CACHE_PLUGIN == 'jsonfile'
    assert ANSIBLE_CACHE_PLUGIN_CONNECTION == '/tmp/ansible-cache'
    assert ANSIBLE_CACHE_PLUGIN_TIMEOUT == 3600
    assert DEFAULT_ASK_PASS == False
    assert DEFAULT_CACHE_PLUGIN == 'memory'
    assert DEFAULT_CACHE_PLUGIN_CONNECTION == ''
    assert DEFAULT_CACHE_PLUGIN_TIMEOUT == 0
    assert DEFAULT_DEBUG == False
    assert DEFAULT_HASH_BEHAVIOUR == 'replace'
    assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'
    assert DEFAULT_HOST_KEY_CHECKING == True


# Generated at 2022-06-22 19:38:46.459541
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import contextlib
    # Disable logging of python warnings
    with contextlib.redirect_stderr(sys.stderr) as redirect_stderr, contextlib.redirect_stdout(io.StringIO()):
        import logging
        logging.disable(logging.WARNING)
        # set up the test
        msg = 'This is deprecated'
        version = '2.2'
        _DeprecatedSequenceConstant(['a'], msg, version)[0]
    # get the output from the redirected stdout and std err
    err = redirect_stderr.getvalue()
    # check if the msg and the version are in the output of the warning
    assert 'DEPRECATED' in err
    assert msg in err
    assert 'to be removed in' in err
    assert version in err



# Generated at 2022-06-22 19:38:51.211267
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_string = "test_string"
    test_msg = "test_msg"
    test_version = "test_version"
    test_obj = _DeprecatedSequenceConstant(test_string, test_msg, test_version)
    assert len(test_obj) == len(test_string)


# Generated at 2022-06-22 19:38:54.442360
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[1] == 'b'


# Generated at 2022-06-22 19:39:05.048188
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    try:
        sys.stderr = sys.__stderr__
    except Exception:
        sys.stderr = object()

    # Given
    def _deprecated(msg, version):
        raise Exception(msg)

    expect = 'The constants `CLI_OPTIONS` and `BECOME_METHODS` are deprecated, to be removed in 2.4'
    mock_version = '2.4'
    mock_name = 'CLI_OPTIONS'
    mock_value = {'modify_command': 'yes'}
    mock_export = dict()

    # When
    target = _DeprecatedSequenceConstant(mock_value, expect, mock_version)
    set_constant(mock_name, target, mock_export)

# Generated at 2022-06-22 19:39:09.668840
# Unit test for function set_constant
def test_set_constant():
    set_constant('A', 1)
    set_constant('B', 2, export=globals())
    set_constant('C', 3, export=locals())
    assert A == 1
    assert B == 2
    assert C == 3
    assert globals()['B'] == 2
    assert locals()['C'] == 3


# Generated at 2022-06-22 19:39:11.954582
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2), "msg", "version")) == 2



# Generated at 2022-06-22 19:39:23.306428
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(list(range(0, 10)), 'just test', '2.0')
    assert c[0] == 0
    assert c[1] == 1
    assert c[2] == 2
    assert c[3] == 3
    assert c[4] == 4
    assert c[5] == 5
    assert c[6] == 6
    assert c[7] == 7
    assert c[8] == 8
    assert c[9] == 9
    assert c[-1] == 9
    assert c[-2] == 8
    assert c[-3] == 7
    assert c[-4] == 6
    assert c[-5] == 5
    assert c[-6] == 4
    assert c[-7] == 3
    assert c[-8] == 2


# Generated at 2022-06-22 19:39:27.054200
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Ensures that _DeprecatedSequenceConstant provides access to an item in a collection as if it were accessible
    # through the collection itself
    anItem = _DeprecatedSequenceConstant(['a', 'b'], 'a message', 'a version')
    assert anItem[1] == 'b'

# Generated at 2022-06-22 19:39:30.209567
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# Generated at 2022-06-22 19:39:31.684945
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    assert len(_DeprecatedSequenceConstant([1, 2, 3], '', '')) == 3

# Generated at 2022-06-22 19:39:36.236563
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'Test', '2.10')
    assert len(sequence) == 3
    assert sequence[0] == 1
    assert sequence[1] == 2
    assert sequence[2] == 3

# Generated at 2022-06-22 19:39:38.934500
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('TEST_constant', 'value') == {'TEST_constant': 'value'}


# Generated at 2022-06-22 19:39:41.534805
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    my_deprecated_meaningless_constant_value = ['a', 'b', 'c']
    my_deprecated_meaningless_constant = _DeprecatedSequenceConstant(my_deprecated_meaningless_constant_value, 'This function has no meaning', '2.9')
    return (my_deprecated_meaningless_constant[1] == my_deprecated_meaningless_constant_value[1])

# Generated at 2022-06-22 19:39:50.917415
# Unit test for function set_constant
def test_set_constant():
    ''' extra functions for the test suite '''
    from ansible.utils.path import makedirs_safe
    from ansible.config.manager import ConfigManager, Setting
    from os import environ, remove
    from tempfile import mkstemp
    from shutil import rmtree
    from ansible.module_utils._text import to_text

    config = ConfigManager(['/dev/null'])
    assert len(config.data.get_settings()) == 0

    # Temporary directory for settings configuration file
    (d_fd, d_name) = mkstemp()
    config_path = '%s/ansible.cfg' % d_name
    makedirs_safe(d_name)

    # Contents of configuration settings file

# Generated at 2022-06-22 19:39:59.636106
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    if not isinstance(_ACTION_ALL_INCLUDE_IMPORT_TASKS, _DeprecatedSequenceConstant):
        raise Exception('_ACTION_ALL_INCLUDE_IMPORT_TASKS is not instance of _DeprecatedSequenceConstant')
    if not isinstance(_ACTION_ALL_INCLUDE_IMPORT_TASKS, Sequence):
        raise Exception('_ACTION_ALL_INCLUDE_IMPORT_TASKS is not instance of Sequence')

    try:
        _ACTION_ALL_INCLUDE_IMPORT_TASKS[0]
    except Exception as e:
        raise Exception('_ACTION_ALL_INCLUDE_IMPORT_TASKS[0] raise an exception: %s' % to_text(e))


# Generated at 2022-06-22 19:40:05.731187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    options = dict()
    options['msg'] = "WARNING"
    options['version'] = 1.0
    options['value'] = ('tup1', 'tup2')
    deprecated_obj = _DeprecatedSequenceConstant(options['value'], options['msg'], options['version'])
    assert(len(deprecated_obj) == 2)
    assert(deprecated_obj[0] == 'tup1')
    assert(deprecated_obj[1] == 'tup2')

# Generated at 2022-06-22 19:40:12.619627
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    sequence = _DeprecatedSequenceConstant(["abc", "def", "ghi"], "msg", "version")
    assert sequence[0] == "abc"
    assert sequence[1] == "def"
    assert sequence[2] == "ghi"


# Generated at 2022-06-22 19:40:14.374170
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), 'msg', '1.2')) == 2

# Generated at 2022-06-22 19:40:21.222285
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], msg="this is a message", version="2.9")
    # It has to be iterable, because it's a Sequence
    assert list(x) == [1, 2, 3]
    # It supports len
    assert len(x) == 3
    # It supports indexing
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3

# Generated at 2022-06-22 19:40:27.248134
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_msg = 'test message'
    test_vers = 'test version'
    test_value = (1,2,3)
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_vers)
    len_test = len(test_obj)
    assert len_test == len(test_value)