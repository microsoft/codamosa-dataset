

# Generated at 2022-06-22 19:30:30.924221
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2]
    msg = 'Test'
    version = '2.8'
    obj = _DeprecatedSequenceConstant(
        value=value,
        msg=msg,
        version=version)

    assert len(obj) == len(value)


# Generated at 2022-06-22 19:30:32.805991
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(value=('a', 'b'), msg='unused', version='2.5')
    assert len(x) == 2



# Generated at 2022-06-22 19:30:36.656500
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'a', 'b')
    assert len(sequence_constant) == 3
    assert sequence_constant[0] == 1

# Generated at 2022-06-22 19:30:44.834206
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}

    set_constant("TEST_CONSTANT_INT", 10, export=test_dict)
    assert test_dict["TEST_CONSTANT_INT"] == 10

    set_constant("TEST_CONSTANT_STR", "10", export=test_dict)
    assert test_dict["TEST_CONSTANT_STR"] == "10"



# Generated at 2022-06-22 19:30:56.216279
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'asdf')
    assert TEST_CONSTANT == 'asdf'
    assert vars()['TEST_CONSTANT'] == 'asdf'


# Py3 Update:
#
# The following constants are no longer needed and will be removed in Ansible 2.9
#
# Action-specific constants:
#
# ALLOW_UNKNOWN_ERRORS_TO_PASS
# COMPILE_TEMPLATE_FILTER_REGEX
# FORKS_VALUE
# MODULE_REQUIRE_ARGS
# MODULE_NO_JSON
# MODULE_REQUIRE_JSON
# MODULE_COMPLEX_ARGS
# MODULE_COMPLEX_AS_COMPLEX
# MODULE_COMPLEX_AS_COMPLEX_DEFAULT
# MODULE_COMPLEX_AS_COMPLEX_NUMBER
# MODULE

# Generated at 2022-06-22 19:30:59.201720
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'
    assert vars()['foo'] == 'bar'

# Generated at 2022-06-22 19:31:02.908381
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant([1, 2], msg='msg', version='version')
    assert sequence[0] == 1
    assert sequence[1] == 2

# Generated at 2022-06-22 19:31:06.994188
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    testinstance = _DeprecatedSequenceConstant((1,2), 'msg', 'version')
    if len(testinstance) != 2:
        raise AssertionError("Wrong __len__ of class _DeprecatedSequenceConstant.")


# Generated at 2022-06-22 19:31:09.659855
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    l1 = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert len(l1) == 3
    assert l1[1] == 2



# Generated at 2022-06-22 19:31:13.867354
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('test', ), 'test', 'test')) == 1
    assert len(_DeprecatedSequenceConstant(('test1', 'test2'), 'test', 'test')) == 2


# Generated at 2022-06-22 19:31:22.248241
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    message = 'warning message'
    version = '0.0.0'
    obj = _DeprecatedSequenceConstant([1, 2, 3], message, version)
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    # tests for __getitem__ on a empty object
    obj = _DeprecatedSequenceConstant([], message, version)
    assert obj[0] == None


# Generated at 2022-06-22 19:31:26.994976
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant([8, 6, 5], 'this is just a test', 1.0)
    assert len(s) == 3
    assert s[0] == 8
    assert s[1] == 6
    assert s[2] == 5

# Generated at 2022-06-22 19:31:32.066883
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected_result = 'abc'
    msg = 'test'
    version = '2.0'
    d = _DeprecatedSequenceConstant([expected_result], msg, version)
    result = d[0]
    if result == expected_result:
        print("test__DeprecatedSequenceConstant___getitem__: PASS")
    else:
        print("test__DeprecatedSequenceConstant___getitem__: FAIL")


# Generated at 2022-06-22 19:31:36.437908
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2, 3]
    msg = 'msg'
    version = '2017.06'
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert len(seq) == len(value)

# Generated at 2022-06-22 19:31:38.880096
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    i = _DeprecatedSequenceConstant(list(range(10)), "msg", "version")
    assert len(i) == 10


# Generated at 2022-06-22 19:31:48.773938
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create an instance of _DeprecatedSequenceConstant
    item = ["a", "b", "c"]
    msg = "this is a message"
    version = "5.3"
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value=item, msg=msg, version=version)

    # Call the __getitem__ method and compare with expected result
    # 1st position
    r = deprecated_sequence_constant[0]
    assert r == "a"
    # last position (negative number)
    r = deprecated_sequence_constant[-1]
    assert r == "c"
    # invalid position (positive number)
    try:
        deprecated_sequence_constant[3]
    except IndexError:
        pass
    # invalid position (negative number)

# Generated at 2022-06-22 19:31:59.893391
# Unit test for function set_constant
def test_set_constant():
    x = {}
    set_constant('FOO', True, export=x)
    assert x['FOO']
    assert FOO
    set_constant('BAR', False, export=x)
    assert not x['BAR']
    assert not BAR
    set_constant('FOO', 'bar', export=x)
    assert x['FOO'] == 'bar'
    assert FOO == 'bar'


# FIXME: hard for other code to find, consider moving this to the jinja2 scope
# rather than globals()
FILTER_PLUGINS = ['complex', 'ipaddr', 'ipaddrs']

DEFAULT_JINJA2_NATIVE_TYPES = (bool, int, list, dict, text_type)

# FIXME: too tightly coupled to the action plugin loader, move to that

# Generated at 2022-06-22 19:32:04.715889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    #Create object of _DeprecatedSequenceConstant class
    obj1 = _DeprecatedSequenceConstant(value=['test1','test2','test3'],
                                       msg='This is a deprecated test msg',
                                       version='v2.8')

    #Assert len of list in object
    assert len(obj1) == 3


# Generated at 2022-06-22 19:32:10.511321
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(
        ('a', 'b'), 'warning message', 'version') == ('a', 'b')
    assert _DeprecatedSequenceConstant(
        ('a', 'b'), 'warning message', 'version')._value == ('a', 'b')
    assert _DeprecatedSequenceConstant(
        ('a', 'b'), 'warning message', 'version')._msg == 'warning message'
    assert _DeprecatedSequenceConstant(
        ('a', 'b'), 'warning message', 'version')._version == 'version'

# Generated at 2022-06-22 19:32:15.237495
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import __main__ as main
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'test warning message', '3.0.0')
    assert constant[0] == 1


if __name__ == "__main__":
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:32:17.701149
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant(['a', 'b'], 'no message', '0.00')
    assert sequence[0] == 'a'
    assert sequence[1] == 'b'

# Generated at 2022-06-22 19:32:20.577522
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_constant = _DeprecatedSequenceConstant(_ACTION_ALL_INCLUDE_IMPORT_TASKS, 'This constant is deprecated', '2.10')
    assert isinstance(deprecated_constant, Sequence)


# update CONFIG_VERSION if you change this
CONFIG_VERSION = 2.0

# Generated at 2022-06-22 19:32:22.174169
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_BECOME_PASS' in globals()

# Generated at 2022-06-22 19:32:25.464041
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('1', '2', '3'), 'Hello', 'Moon')) == 3


# Generated at 2022-06-22 19:32:31.931567
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'A deprecated list.', '2.10') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'A deprecated list.', '2.10')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'A deprecated list.', '2.10')[2] == 3

# Generated at 2022-06-22 19:32:35.366329
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    arr = _DeprecatedSequenceConstant([1,2,3,4], 'This is test message', '1.0.0')
    assert len(arr) == 4
    assert arr[1] == 2


# Generated at 2022-06-22 19:32:44.804049
# Unit test for function set_constant
def test_set_constant():
    constant = {'ANSIBLE_CONFIG': '/etc/ansible.cfg'}
    for key, val in constant.items():
        set_constant(key, val)
        assert key in globals()
        assert globals()[key] == val

if __version__.split('.')[0] == '2':
    _warning("Using the '%s' branch of Ansible is deprecated and will be removed in the future. "
             "Please use the '%s.x' branch instead." % (__version__.split('.')[0], __version__.split('.')[0]))


# Generated at 2022-06-22 19:32:48.215440
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    val = _DeprecatedSequenceConstant(('a'), 'message', '1.0')
    assert len(val) == 1
    assert val[0] == 'a'

# Generated at 2022-06-22 19:32:52.098274
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(['foo', 'bar'], 'dummy warning message', 'dummy version')
    if len(a) != 2:
        raise AssertionError()
    if len(a) != 2:
        raise AssertionError()

# Generated at 2022-06-22 19:32:54.403979
# Unit test for function set_constant
def test_set_constant():
    """
    Ensure we can set constants and they're added to the export dict.
    """
    export = {}
    set_constant("FOO", "BAR", export=export)
    assert export["FOO"] == "BAR"



# Generated at 2022-06-22 19:32:57.053039
# Unit test for function set_constant
def test_set_constant():
    ldict = locals()
    set_constant('FOO_BAR', "BAZ", export=ldict)
    assert ldict['FOO_BAR'] == "BAZ"

# Generated at 2022-06-22 19:33:00.582656
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(['foo'], "bar", "baz")
    assert(['foo'] == a[0])



# Generated at 2022-06-22 19:33:05.597920
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = "test_string"
    test_msg = "test message"
    test_version = "test version"
    dsc = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(dsc) == len(test_value)


# Generated at 2022-06-22 19:33:10.017957
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(value=tuple(['debug', 'something', 'else']), msg='something', version='1.0.0')
    assert obj.__getitem__(0) == 'debug', 'Object does not have expected item at index 0'

# Generated at 2022-06-22 19:33:22.003535
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def test_getitem_with_list_value(self):
            empty_list = []
            sequence_constant = _DeprecatedSequenceConstant(empty_list, None, None)
            self.assertEqual(0, len(sequence_constant))
            self.assertEqual(sequence_constant, empty_list)

        def test_getitem_with_string_value(self):
            empty_string = ''
            sequence_constant = _DeprecatedSequenceConstant(empty_string, None, None)
            self.assertEqual(0, len(sequence_constant))
            self.assertEqual(sequence_constant, empty_string)

# Generated at 2022-06-22 19:33:25.709654
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''
    Unit test for method __len__ of class _DeprecatedSequenceConstant
    '''
    test_subject = _DeprecatedSequenceConstant([1,2,3], 'test', 'unit_test')
    assert len(test_subject) == 3

# Generated at 2022-06-22 19:33:29.935175
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_object = _DeprecatedSequenceConstant(value='value', msg='This is a test message', version='v3.0')
    assert len(test_object) == 5
    assert test_object[0] == 'v'

# Generated at 2022-06-22 19:33:32.911382
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_constant = _DeprecatedSequenceConstant(['A', 'B', 'C'], 'test_message', '1.0')

    assert len(test_constant) == 3

# Generated at 2022-06-22 19:33:39.173864
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Message'
    version = '1.2.3'
    x = _DeprecatedSequenceConstant(list(range(10)), msg, version)
    assert len(x) == 10

# Unit tests for methods __eq__, __lt__, __gt__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 19:33:41.306916
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = _DeprecatedSequenceConstant(['a', 'b'], 'msg', '2.0.0')
    assert len(l) == 2

# Generated at 2022-06-22 19:33:45.506653
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant1 = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'This is deprecated', '3.0')
    assert len(constant1) == 3
    constant2 = _DeprecatedSequenceConstant((), 'This is deprecated', '3.0')
    assert len(constant2) == 0


# Generated at 2022-06-22 19:33:47.911530
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert(len(x) == len([1, 2, 3]))
    assert(x[0] == 1)

# Generated at 2022-06-22 19:34:01.242763
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """
    Unit test for constructor of class _DeprecatedSequenceConstant
    """

    # Test 1
    test_msg = "test msg"
    dep_seq_const = _DeprecatedSequenceConstant([1, 2, 3], test_msg, "2.10")
    assert dep_seq_const._value == [1, 2, 3]
    assert dep_seq_const._msg == test_msg
    assert dep_seq_const._version == "2.10"

    # Test 2
    test_msg = "test msg"
    dep_seq_const = _DeprecatedSequenceConstant([1], test_msg, "2.10")
    assert dep_seq_const._value == [1]
    assert dep_seq_const._msg == test_msg

# Generated at 2022-06-22 19:34:09.444488
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest

    def check_deprecation_warning(value, msg, version):
        """
        Check if deprecation warning will be printed with the correct format.
        """
        with unittest.mock.patch('ansible.utils.display.Display') as mock_display:
            dsc = _DeprecatedSequenceConstant(value, msg, version)
            mock_display.deprecated.assert_called_with(msg, version=version)

    class TestAnsibleDeprecatedSequenceConstant(unittest.TestCase):
        """
        Test class _DeprecatedSequenceConstant
        """

        def test__DeprecatedSequenceConstant_len(self):
            """
            Test _DeprecatedSequenceConstant.__len__ method
            """
            value = ('test', 'len')

# Generated at 2022-06-22 19:34:13.898798
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant((1, 2), "msg", "1.0")
    assert len(a) == 2
    assert a[0] == 1
    assert a[1] == 2

# Generated at 2022-06-22 19:34:21.160521
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    global _deprecated_msg
    _deprecated_msg = ''
    def _deprecated(msg, version):
        global _deprecated_msg
        _deprecated_msg = msg

    o = _DeprecatedSequenceConstant(['foo', 'bar'], 'Oops!', '1.0')
    assert len(o) == 2
    assert o[1] == 'bar'
    assert _deprecated_msg == 'Oops!, to be removed in 1.0'


# Generated at 2022-06-22 19:34:25.528776
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    msg = "this is a test"
    version = "1.0"
    value = "test"
    sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(sequence_constant) == len(value)


# Generated at 2022-06-22 19:34:30.947758
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a warning message'
    version = '2.8'
    test1 = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert test1[0] == 1
    assert test1._msg == msg
    assert test1._version == version


# Generated at 2022-06-22 19:34:32.815581
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(('foo', 'bar'), 'warning', '2.5')

# Generated at 2022-06-22 19:34:33.982736
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert 0 == len(_DeprecatedSequenceConstant([], '', ''))

# Generated at 2022-06-22 19:34:38.652493
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        deprecated_constant = _DeprecatedSequenceConstant(6, "test message", "test version")
        len(deprecated_constant)
    except Exception:
        assert False, "test__DeprecatedSequenceConstant failed"

# Generated at 2022-06-22 19:34:40.759877
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    inner_list = [1, 2, 3]
    d = _DeprecatedSequenceConstant(inner_list, 'Test Message', 'Version')

    assert len(d) == len(inner_list)

# Generated at 2022-06-22 19:34:42.549322
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    DEPSEQ = _DeprecatedSequenceConstant(('foo', 'bar'), 'test', 'version')
    assert len(DEPSEQ) == len(('foo', 'bar'))

# Generated at 2022-06-22 19:34:53.673227
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value, msg, version):
            self.value = value
            self.msg = msg
            self.version = version

        def warn(self, msg, version=None):
            if msg == self.msg and version == self.version:
                return True
            return False

    test = Test([1, 2, 3], "Test warning message", "2.0")
    dep = _DeprecatedSequenceConstant([1, 2, 3], "Test warning message", "2.0")
    assert len(dep) == len([1, 2, 3])
    assert dep[0] == 1
    assert dep[1] == 2
    assert dep[2] == 3
    assert dep[-1] == 3
    assert dep[-2] == 2
    assert dep[-3] == 1

# Generated at 2022-06-22 19:35:03.199731
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant is a subclass of Sequence
    assert issubclass(_DeprecatedSequenceConstant, Sequence)
    # Check that __init__ gets called
    class _DeprecatedSequenceConstantTester(Sequence):
        def __init__(self, value, msg, version):
            self.value = value
            self.msg = msg
            self.version = version
    s = _DeprecatedSequenceConstantTester('value', 'msg', 'version')
    assert s.value == 'value'
    assert s.msg == 'msg'
    assert s.version == 'version'
test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:35:06.328326
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'Test message', '3.3')
    assert len(dsc) == 3



# Generated at 2022-06-22 19:35:10.162629
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'deprecated'
    version = 'version'
    msg_version = 'Deprecated: %s, to be removed in %s' % (msg, version)
    lst = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(lst, msg, version)
    assert(dsc[1] == lst[1])
    assert(msg_version in repr(dsc[1]))


# Generated at 2022-06-22 19:35:16.814072
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test1 = _DeprecatedSequenceConstant(value=('test', 'test2'), msg='hello',
                                        version='1.0')
    test2 = _DeprecatedSequenceConstant(value=('test', 'test2'), msg='hello',
                                        version='1.0')
    assert len(test1) == 2
    assert len(test2) == 2
    assert test1[0] == 'test'
    assert test2[1] == 'test2'

# Generated at 2022-06-22 19:35:19.729160
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg='Warning Message', version='Some Version')) == 0


# Generated at 2022-06-22 19:35:25.832486
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ['foo', 'bar']
    msg = "123"
    version = "456"
    v = _DeprecatedSequenceConstant(value, msg, version)
    assert v[0] == 'foo'
    assert v[1] == 'bar'
    assert v[-2] == 'foo'
    assert v[-1] == 'bar'
    assert v[-3] is None
    assert v[-4] is None


# Generated at 2022-06-22 19:35:30.480767
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_seq = ['a', 'b']
    test_obj = _DeprecatedSequenceConstant(test_seq, 'message', 'version')
    assert len(test_obj) == len(test_seq)


# Generated at 2022-06-22 19:35:32.826978
# Unit test for function set_constant
def test_set_constant():
    fake_export = {}
    set_constant('FOO', 'BAR', fake_export)
    assert fake_export['FOO'] == 'BAR'

# Generated at 2022-06-22 19:35:35.367366
# Unit test for function set_constant
def test_set_constant():
    value = object()
    my_vars = {}
    set_constant('my_constant', value, export=my_vars)
    assert my_vars['my_constant'] == value


# Generated at 2022-06-22 19:35:36.960203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert list(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == ['a', 'b']


# Generated at 2022-06-22 19:35:38.678656
# Unit test for function set_constant
def test_set_constant():
    set_constant('MYCONSTANT', 42)
    assert MYCONSTANT == 42

# Generated at 2022-06-22 19:35:51.370938
# Unit test for function set_constant
def test_set_constant():
    # Testing for the values for which type is string
    test = 0

# Generated at 2022-06-22 19:35:54.839813
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _deprecated = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert _deprecated[0] == 1
    assert _deprecated[1] == 2


# Generated at 2022-06-22 19:35:57.665520
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(['a', 'b'], 'test', 'v1')

    assert a[0] == 'a'
    assert a[-1] == 'b'


# Generated at 2022-06-22 19:36:02.055779
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_set_constant_mytest', u'foo')
    assert 'test_set_constant_mytest' in globals()
    assert getattr(globals()['test_set_constant_mytest'], 'foo')

# Generated at 2022-06-22 19:36:03.942013
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant('xyz', 'bad', '2.0')
    assert s[1] == 'y'

# Generated at 2022-06-22 19:36:05.935215
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([0, 1, 2], "msg", "1.3")
    assert seq[0] == 0


# Generated at 2022-06-22 19:36:08.553301
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant([1,2,3], 'item: %s', '2.9').__getitem__(0)

# Generated at 2022-06-22 19:36:21.683844
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def assert_deprecated__DeprecatedSequenceConstant___getitem__(value, version, msg):
        c = _DeprecatedSequenceConstant(value, msg, version)
        # When c[0] is called, _deprecated(msg, version) should be called
        c[0]
        # When len(c) is called, _deprecated(msg, version) should be called
        len(c)


# Generated at 2022-06-22 19:36:26.312233
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((), 'foo', 'bar')) == 0
    assert len(_DeprecatedSequenceConstant((1,), 'foo', 'bar')) == 1
    assert len(_DeprecatedSequenceConstant((1, 2), 'foo', 'bar')) == 2


# Generated at 2022-06-22 19:36:28.413360
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    de = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(de) == 3


# Generated at 2022-06-22 19:36:32.446201
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], "This is the deprecated message", "1.0")
    assert isinstance(test_constant, Sequence)
    assert len(test_constant) == 3
    assert test_constant[1] == 'b'
    assert test_constant[0] == 'a'

# Generated at 2022-06-22 19:36:35.001180
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['1'], 'msg', 'version')) == 1
    assert _DeprecatedSequenceConstant(['1'], 'msg', 'version')[0] == '1'

# Generated at 2022-06-22 19:36:42.664981
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # _DeprecatedSequenceConstant.__getitem__(item)
    # Raises DeprecatedWarning when called and returns
    # the value of the item passing through
    my_value = [1, 2, 3, 4]
    my_msg = "Testing the DeprecatedWarning"
    my_version = "2.9"

    my_test = _DeprecatedSequenceConstant(my_value, my_msg, my_version)

    for item in my_value:
        assert my_test[item] == my_value[item]

# Generated at 2022-06-22 19:36:46.667824
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(range(100), 'This is a test', '2.0')
    assert(len(x) == 100)
    assert(x[0] == 0)
    assert(x[99] == 99)

# Generated at 2022-06-22 19:36:50.483773
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_object = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert test_object[0] == 1
    assert test_object[1] == 2
    assert test_object[2] == 3

# Generated at 2022-06-22 19:36:58.844841
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_SUBSET' in vars()
    assert 'DEFAULT_BECOME_PASS' in vars()
    assert 'DEFAULT_PASSWORD_CHARS' in vars()
    assert 'DEFAULT_REMOTE_PASS' in vars()
    assert 'COLOR_CODES' in vars()
    assert 'REJECT_EXTS' in vars()
    assert 'BOOL_TRUE' in vars()
    assert 'COLLECTION_PTYPE_COMPAT' in vars()
    assert 'IGNORE_FILES' in vars()
    assert 'RESTRICTED_RESULT_KEYS' in vars()
    assert 'MODULE_REQUIRE_ARGS' in vars()
    assert 'MODULE_NO_JSON' in vars()

# Generated at 2022-06-22 19:37:04.326881
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'test message', '2.0')
    # test __len__ method of class _DeprecatedSequenceConstant
    assert len(dsc) == 3

    # test __getitem__ method of class _DeprecatedSequenceConstant
    assert dsc[0] == 1

# Generated at 2022-06-22 19:37:12.394670
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    sys.stderr = io.StringIO()
    msg = 'DEPRECATED MESSAGE'
    version = 'v2.8'
    a = _DeprecatedSequenceConstant(['test'], msg, version)
    a[0]
    err_msg = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__
    assert err_msg == ' [DEPRECATED] DEPRECATED MESSAGE, to be removed in v2.8\n'

# Generated at 2022-06-22 19:37:17.300158
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Create an instance of _DeprecatedSequenceConstant
    dsc = _DeprecatedSequenceConstant({1, 2, 3}, 'This is a test', '2.1')

    # Test the method __len__ of class _DeprecatedSequenceConstant
    result = len(dsc)
    assert(result == 3)



# Generated at 2022-06-22 19:37:23.062675
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.collection_loader import _DeprecatedSequenceConstant
    my_array = ['first', 'second']
    test_string = 'foo'
    test_version = '2.10'
    my_constant = _DeprecatedSequenceConstant(my_array, test_string, test_version)
    assert len(my_constant) == 2
    assert my_constant[1] == 'second'

# Generated at 2022-06-22 19:37:37.712460
# Unit test for function set_constant
def test_set_constant():
    ''' test set_constant '''

    # Test to make sure we're not overwriting existing constants
    try:
        set_constant('INTERNAL_RESULT_KEYS', 'foo')
    except Exception:
        assert True
    else:
        assert False

    # Test to make sure we are actually setting the right value
    assert INTERNAL_RESULT_KEYS == ('add_host', 'add_group')

    # Test to make sure we can't override these constants
    for name in ['INTERNAL_RESULT_KEYS', 'MODULE_NO_JSON']:
        try:
            set_constant(name, 'foo')
        except Exception:
            assert True
        else:
            assert False

    # Test to make sure we get the templated value set
    assert DEFAULT_BECOME_

# Generated at 2022-06-22 19:37:43.261296
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # ok
    _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', '1.1').__len__() == 3
    # fail
    try:
        len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', '1.1')) == 3  # len will not trigger my message
    except Exception as e:
        raise e


# Generated at 2022-06-22 19:37:48.126028
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        _DeprecatedSequenceConstant([], "", "")
    except (TypeError, ValueError):
        raise AssertionError("Constructor of class _DeprecatedSequenceConstant failed test.")


# Generated at 2022-06-22 19:37:51.123087
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(d) == 3


# Generated at 2022-06-22 19:37:59.883996
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export={})
    assert FOO == 'bar'
    new_export = {}
    set_constant('FOO', 'baz', export=new_export)
    assert new_export['FOO'] == 'baz'


# This is a temporary workaround until we fix ansible.runner.display to allow display object inheritance
# (see https://github.com/ansible/ansible/pull/33244)

# FIXME: remove the warning when we are displaying the full class
_warning("ansible.utils.display is deprecated and will be removed in a future version. "
         "Migrate to ansible.utils.display.Display()")



# Generated at 2022-06-22 19:38:08.159452
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest
    import ansible.constants as C

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        """ Test __getitem__ of class _DeprecatedSequenceConstant """

        def setUp(self):
            self.msg = 'message'
            self.version = '2.1'
            self.value = (1, 2, 3, 4)
            self.dsc = C._DeprecatedSequenceConstant(self.value, self.msg, self.version)

        def test_ok(self):
            for i in self.value:
                self.assertEqual(self.dsc[self.value.index(i)], i)

    unittest.main()



# Generated at 2022-06-22 19:38:10.455100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['foo', 'bar'], 'test', '1.0')[0] == 'foo'


# Generated at 2022-06-22 19:38:12.756501
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], '', '2.5')
    assert len(constant) == 3


# Generated at 2022-06-22 19:38:18.562392
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ver = '2.6'
    msg = 'foo'
    expected_value = [1, 2, 3]
    dep_seq = _DeprecatedSequenceConstant(expected_value, msg, ver)
    assert dep_seq._value == expected_value
    assert dep_seq._msg == msg
    assert dep_seq._version == ver
    assert dep_seq == expected_value



# Generated at 2022-06-22 19:38:22.880324
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    expected = [1, 2, 3]
    msg = 'foo'
    version = '2.0'
    sequence_constant = _DeprecatedSequenceConstant(expected, msg, version)
    assert len(sequence_constant) == len(expected)
    assert sequence_constant[0] == expected[0]

# Generated at 2022-06-22 19:38:28.993005
# Unit test for function set_constant
def test_set_constant():

    assert ANSIBLE_TEST_CONSTANT is None
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'

    assert ANSIBLE_TEST_CONSTANT2 is None
    set_constant('ANSIBLE_TEST_CONSTANT2', 'bar')
    assert ANSIBLE_TEST_CONSTANT2 == 'bar'

# Generated at 2022-06-22 19:38:33.675153
# Unit test for function set_constant
def test_set_constant():
    var = {}
    set_constant('var1', 'abc', var)
    set_constant('var2', 123, var)
    assert var['var1'] == 'abc'
    assert var['var2'] == 123
    try:
        set_constant('var2', 'def', var)
        assert False
    except NameError:
        pass


# Generated at 2022-06-22 19:38:35.157898
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # FIXME: Add unit tests for this method
    pass


# Generated at 2022-06-22 19:38:45.864615
# Unit test for function set_constant
def test_set_constant():
    set_constant('action_plugins', 'action_plugins')
    set_constant('lookup_plugins', 'lookup_plugins')
    set_constant('module_utils', 'module_utils')
    set_constant('filter_plugins', 'filter_plugins')
    set_constant('callback_whitelist', 'callback_whitelist')
    set_constant('callback_plugins', 'callback_plugins')
    set_constant('vault_password_file', 'vault_password_file')
    set_constant('default_vars_path', 'default_vars_path')
    set_constant('host_key_checking', 'host_key_checking')
    set_constant('nocows', 'nocows')

# Generated at 2022-06-22 19:38:48.203306
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test the length of a list
    constant = _DeprecatedSequenceConstant(['a'], 'test', '2.9')
    assert len(constant) == 1

    # Test the length of a dict
    constant = _DeprecatedSequenceConstant({'a':'b'}, 'test', '2.9')
    assert len(constant) == 1


# Generated at 2022-06-22 19:38:55.535629
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant constructor should raise TypeError if msg is not str type
    try:
        _DeprecatedSequenceConstant('string', [], '2.8')
    except TypeError:
        pass
    else:
        raise AssertionError("_DeprecatedSequenceConstant constructor should raise TypeError if msg is not str type")

    # _DeprecatedSequenceConstant constructor should raise TypeError if version is not str type
    try:
        _DeprecatedSequenceConstant('string', 'message', ['2.8'])
    except TypeError:
        pass
    else:
        raise AssertionError("_DeprecatedSequenceConstant constructor should raise TypeError if version is not str type")

# Execute unit test
test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:39:01.405264
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest

    msg = "Hello"
    _v = _DeprecatedSequenceConstant(["warning1", "warning2"], msg, "2.0")
    assert _v[0] == "warning1"
    assert _v[1] == "warning2"

    with pytest.raises(IndexError):
        assert _v[2]


# Generated at 2022-06-22 19:39:08.369585
# Unit test for function set_constant
def test_set_constant():
    test_constants = {
        'var1': 'test',
        'var2': '{{var1}}',
    }
    export = {'var1': 'foo'}

    # Populate constants and make sure nested expressions are rendered
    # correctly
    for name, value in test_constants.items():
        set_constant(name, value, export)

    return export['var2'] == 'test'


# Generated at 2022-06-22 19:39:15.611567
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Test _DeprecatedSequenceConstant'
    version = '1.0'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)  # instantiate
    assert len(deprecated_sequence_constant) == 3  # test __len__
    assert deprecated_sequence_constant[1] == 2  # test __getitem__

# FIXME: remove this once we remove `C.ANSIBLE_CONFIG`
ANSIBLE_CONFIG = to_text(config.config_file, nonstring='passthru')

# FIXME: remove these once we remove `C.ANSIBLE_VAULT_IDENTITY_LIST` and `C.DEFAULT_VAULT_IDENTITY_LIST`
DEFAULT_VAULT_IDENTITY_LIST = config

# Generated at 2022-06-22 19:39:19.087700
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], msg="msg", version="version")
    assert dsc[0] == 1
    assert dsc[1] == 2


# Generated at 2022-06-22 19:39:20.927988
# Unit test for function set_constant
def test_set_constant():
    set_constant('A', 'B', {})
    assert({'A':'B'} == locals())

# Generated at 2022-06-22 19:39:28.555145
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    assert isinstance(_DeprecatedSequenceConstant(value=[], msg="foo", version='1.0'), Sequence)

    my_constants = _DeprecatedSequenceConstant(value=[1, 2, 3], msg="foo", version='1.0')
    assert len(my_constants) == 3
    # Test if the warning is printed
    assert to_text(' [DEPRECATED] foo, to be removed in 1.0\n') in my_constants._msg


# Generated at 2022-06-22 19:39:33.572302
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    data_1 = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.5')
    data_2 = _DeprecatedSequenceConstant([1, 2], 'test', '2.5')
    assert len(data_1) == 3
    assert len(data_2) == 2

# Generated at 2022-06-22 19:39:40.878032
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test msg'
    version = '2.8'
    test_a = _DeprecatedSequenceConstant([], msg, version)
    test_b = _DeprecatedSequenceConstant([1], msg, version)
    assert isinstance(test_a, _DeprecatedSequenceConstant)
    assert isinstance(test_b, _DeprecatedSequenceConstant)
    assert len(test_a) == 0
    assert len(test_b) == 1


# Generated at 2022-06-22 19:39:41.874813
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 1)
    assert FOO == 1

# Generated at 2022-06-22 19:39:50.116884
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    status = 0
    default_sequence = '{{ test_sequence_default }}'

    # Test for an empty sequence
    sequence_constant = _DeprecatedSequenceConstant('', 'test message - should fail', '2.9')
    try:
        sequence_constant[0]
    except IndexError:
        status = 1

    # Test for index value out of range
    sequence_constant = _DeprecatedSequenceConstant(default_sequence, 'test message - should fail', '2.9')
    try:
        sequence_constant[99]
    except IndexError:
        status = 1

    # Test for valid index value
    sequence_constant = _DeprecatedSequenceConstant(default_sequence, 'test message - should pass', '2.9')

# Generated at 2022-06-22 19:39:51.342152
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2], None, None)) == 2


# Generated at 2022-06-22 19:39:54.510767
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    const = _DeprecatedSequenceConstant(value=range(0, 10), msg='msg', version='version')
    assert len(const) == 10
    assert const[5] == 5

# Generated at 2022-06-22 19:40:02.969472
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3, 4]
    assert _DeprecatedSequenceConstant(l, 'TEST', 'TEST').__getitem__(0) == l[0]
    assert _DeprecatedSequenceConstant(l, 'TEST', 'TEST').__getitem__(3) == l[3]
    assert _DeprecatedSequenceConstant(l, 'TEST', 'TEST').__getitem__(2) == l[2]
    assert _DeprecatedSequenceConstant(l, 'TEST', 'TEST').__getitem__(1) == l[1]


# Generated at 2022-06-22 19:40:12.610244
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    fake_option = {'msg': 'Fake option', 'version': '1.0'}

    # Test default constructor
    sequence_constant = _DeprecatedSequenceConstant(('one', 'two'), fake_option['msg'], fake_option['version'])
    assert len(sequence_constant) == 2
    assert sequence_constant[0] == 'one'
    assert sequence_constant[1] == 'two'

    # Test init with an empty tuple
    sequence_constant = _DeprecatedSequenceConstant(tuple(), fake_option['msg'], fake_option['version'])
    assert len(sequence_constant) == 0

    # Test init with an empty list
    sequence_constant = _DeprecatedSequenceConstant([], fake_option['msg'], fake_option['version'])
    assert len

# Generated at 2022-06-22 19:40:16.473990
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_class = _DeprecatedSequenceConstant(('test', ), 'test', 'version')
    assert len(test_class) == 1

# Generated at 2022-06-22 19:40:20.237427
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import pytest

    dsc = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    assert dsc[0] == 'a'

    with pytest.raises(TypeError):
        dsc[2] = 5

# Generated at 2022-06-22 19:40:28.377045
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import os
    import sys
    import tests.support

    # Get the name of the message to be shown
    name = tests.support.get_caller_name()

    # Save original stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    # Redirect stdout and stderr to file
    new_stdout = open(os.devnull, 'w')
    new_stderr = open(name + '.log', 'w')
    sys.stdout = new_stdout
    sys.stderr = new_stderr

    # Create configuration file
    filename = 'ansible.cfg'
    file = open(filename, 'w')

    # Add content to the configuration file
    file.write('[defaults]\n')
    file