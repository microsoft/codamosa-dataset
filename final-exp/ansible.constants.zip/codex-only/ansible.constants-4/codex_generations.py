

# Generated at 2022-06-22 19:30:28.875203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    assert isinstance([], Sequence)
    # Init and test
    _DeprecatedSequenceConstant([], "msg", "v").__getitem__(0)

# Generated at 2022-06-22 19:30:31.437157
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant_invalid_groups = _DeprecatedSequenceConstant(value=['foo', 'bar'], msg='invalid groups', version='2.12')
    assert constant_invalid_groups[0] == 'foo'

# Generated at 2022-06-22 19:30:34.550634
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(list(),
                                    'This is a test',
                                    'ansible 2.8')
    for i in range(2):
        x[0]
        _DeprecatedSequenceConstant.__getitem__(x, 0)


# Generated at 2022-06-22 19:30:46.917842
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1)
    if not a == 1:
        raise AssertionError()
    if not vars()['a'] == 1:
        raise AssertionError()

    set_constant('b', 2, export={'b': 4})
    if not b == 2:
        raise AssertionError()
    if not vars()['b'] == 4:
        raise AssertionError()

test_set_constant()

VAULT_VERSION_MIN = 1.0
VAULT_VERSION_MAX = 1.0

# Module specific constants
# TODO: move to plugins

# Generated at 2022-06-22 19:30:50.946992
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [0, 1, 2]
    r = _DeprecatedSequenceConstant(test_value, "Test msg", "Test version")
    assert r[1] == 1


# Generated at 2022-06-22 19:30:55.756737
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor with invalid params
    passed = False
    try:
        test_obj = _DeprecatedSequenceConstant(None, None, None)
    except ValueError:
        passed = True
    assert passed

    # Test constructor with valid params
    passed = False
    try:
        test_obj = _DeprecatedSequenceConstant([], 'message', 'version')
    except ValueError:
        passed = True
    assert not passed


# Generated at 2022-06-22 19:31:03.506864
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This should generate a deprecation notice'
    version = '1.0'
    test_sequence = ['a', 'b', 'c']
    deprecated_sequence = _DeprecatedSequenceConstant(test_sequence, msg, version)
    assert len(deprecated_sequence) == len(test_sequence)
    assert deprecated_sequence[0] == test_sequence[0]  # This calls the __getitem__ method on the class


# Generated at 2022-06-22 19:31:09.919990
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_dict = {
        'value': ['a', 'b', 'c'],
        'msg': 'This is a test message',
        'version': '2.5'
    }

    test_obj = _DeprecatedSequenceConstant(**test_dict)

    test_obj.__len__()
    test_obj.__getitem__(1)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:31:14.283809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    list_length = 10
    message = 'List length'
    version = '2.0'
    dep_list = _DeprecatedSequenceConstant([1] * list_length, message, version)
    assert(len(dep_list) == list_length)

# Generated at 2022-06-22 19:31:20.875460
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')
    assert len(obj) == 3
    assert obj[1] == 2
    assert obj == [1, 2, 3]
    assert obj != [1, 2]
    assert obj != [1, 2, 3, 4]
    assert obj != [1, 2, 4]

# Generated at 2022-06-22 19:31:23.956808
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['foo', 'bar'], 'this is a warning', '2.6')) == 2

# Generated at 2022-06-22 19:31:27.205455
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant = _DeprecatedSequenceConstant(value=2, msg='Message', version='2.0')
    assert test_constant[0] == 2

# Generated at 2022-06-22 19:31:30.063464
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(list(range(5)), msg, version)
    assert len(dsc) == 5


# Generated at 2022-06-22 19:31:35.779303
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected = 'msg'
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', '2.0')
    actual = dsc[0]
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-22 19:31:38.126318
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(value='', msg='', version='')
    assert isinstance(d, Sequence)
    pass

# Generated at 2022-06-22 19:31:42.869094
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1, 2]
    msg = 'Test'
    version = '2.0'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[1] == value[1]

# Generated at 2022-06-22 19:31:50.101467
# Unit test for function set_constant
def test_set_constant():
    """Test that set_constant correctly sets constants from the config"""
    secrets_filename = config.data.get_setting_value('DEFAULT_SECRETS_PLUGIN_CONFIG')
    config.set_setting_value('DEFAULT_SECRETS_PLUGIN_CONFIG', '/tmp/test/test')
    set_constant('DEFAULT_SECRETS_PLUGIN_CONFIG', '/tmp/test/test')
    assert config.data.get_setting_value('DEFAULT_SECRETS_PLUGIN_CONFIG') == DEFAULT_SECRETS_PLUGIN_CONFIG
    config.set_setting_value('DEFAULT_SECRETS_PLUGIN_CONFIG', secrets_filename)

# Generated at 2022-06-22 19:31:52.275728
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_const = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg1', 'ver1')
    assert len(deprecated_const) == 3

# Generated at 2022-06-22 19:31:57.868742
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    dsc = _DeprecatedSequenceConstant(_ACTION_ALL_INCLUDES, "DEPRECATED MESSAGE", version="2.10")
    assert len(dsc) == 3
    assert dsc[0] == _ACTION_INCLUDE
    assert dsc[1] == _ACTION_INCLUDE_TASKS
    assert dsc[2] == _ACTION_INCLUDE_ROLE

# Generated at 2022-06-22 19:32:02.142605
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = (1, 2, 3)
    msg = 'msg'
    version = 'version'

    test_result = _DeprecatedSequenceConstant(value, msg, version)
    assert test_result[0] == value[0]

# Generated at 2022-06-22 19:32:07.588161
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    seq = _DeprecatedSequenceConstant(
        ['hello', 'world'],
        msg="This is a test",
        version="2.8.0"
    )
    len_val = len(seq)
    assert len_val == 2



# Generated at 2022-06-22 19:32:12.716972
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    v = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert len(v) == 2
    assert v[0] == 'a'



# Generated at 2022-06-22 19:32:15.682514
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(dsc) == 3


# Generated at 2022-06-22 19:32:18.457188
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
  seq = _DeprecatedSequenceConstant(('c', 'b', 'a'), 'test', '1')
  assert seq[0] == 'c'
  assert seq[1] == 'b'
  assert seq[2] == 'a'


# Generated at 2022-06-22 19:32:20.138086
# Unit test for function set_constant
def test_set_constant():
    assert TREE_DIR is not None

# Generated at 2022-06-22 19:32:25.013711
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'A string_type message'
    version = 'A string_type version'
    value = (1, 2, 3)
    dep_seq_const = _DeprecatedSequenceConstant(value, msg, version)
    assert(len(dep_seq_const) == len(value))



# Generated at 2022-06-22 19:32:29.814743
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('a', 'b', 'c')
    msg = 'Deprecated message to display'
    version = '1.3'
    d = _DeprecatedSequenceConstant(value, msg, version)
    assert len(d) == len(value)
    assert d[1] == 'b'

del config

# Generated at 2022-06-22 19:32:35.410683
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([], "msg", "version"), Sequence)
    assert _DeprecatedSequenceConstant([], "msg", "version") == []
    assert len(_DeprecatedSequenceConstant([], "msg", "version")) == 0
    assert _DeprecatedSequenceConstant([0, 1, 2], "msg", "version")[1] == 1

# Generated at 2022-06-22 19:32:44.828959
# Unit test for function set_constant
def test_set_constant():
    assert C.ANSIBLE_DISPLAY_OK_HOSTS != '{{ ANSIBLE_DISPLAY_OK_HOSTS }}'
    assert C.ANSIBLE_DISPLAY_SKIPPED_HOSTS != '{{ ANSIBLE_DISPLAY_SKIPPED_HOSTS }}'

# Deprecate the use of some options:
_deprecated(C.DEFAULT_PRIVATE_ROLE_VARS, '2.9')
_deprecated(C.DEFAULT_PRIVATE_GROUP_VARS, '2.9')
_deprecated(C.DEFAULT_PRIVATE_HOST_VARS, '2.9')

# Deprecate the use of some config options:
_deprecated(C.ANSIBLE_KEEP_REMOTE_FILES, '2.12')

# Generated at 2022-06-22 19:32:50.390749
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create Instance
    instance = _DeprecatedSequenceConstant(['foo','bar','baz'], 'Test message', '999.0')
    assert instance[1] == 'bar'

if __name__ == "__main__":
    # Run testcases
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:32:53.193279
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(['a', 1], 'test', '2.0')
    assert len(dsc) == 2


# Generated at 2022-06-22 19:32:59.333528
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for empty string warning message
    dsc = _DeprecatedSequenceConstant([], '', '2.9')
    assert dsc[0] == []

    # Test for non empty string warning message
    dsc = _DeprecatedSequenceConstant([], 'test', '2.9')
    assert dsc[0] == []
    assert dsc.__str__() == 'test, to be removed in 2.9'

# Generated at 2022-06-22 19:33:03.786986
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'test', '0')
    assert len(dsc) == 3
    assert dsc[0] == 1



# Generated at 2022-06-22 19:33:14.938697
# Unit test for function set_constant
def test_set_constant():
    test_value = 'test_value'
    set_constant('TEST_VAL', test_value)
    assert globals().get('TEST_VAL') is test_value


# These don't fit in the config manager setup, or we don't want them to show up
# in the config docs

# This is used to detect if the version of ansible we are running is
# a development version
# DEVELOPMENT_VERSION defined in Makefile
try:
    DEVELOPMENT_VERSION
except NameError:
    DEVELOPMENT_VERSION = False

# needed for backwards compat
# FIXME: remove in >= 2.13
set_constant('VAULT_VERSION', 1)

# a simple flag that we use multiple places, to indicate the process environment
# is running in Python3.
# NOTE: this is used by the targets in

# Generated at 2022-06-22 19:33:20.112227
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([0, 1, 2], 'This is a warning message.', '2.1')) == 3
    assert _DeprecatedSequenceConstant([0, 1, 2], 'Another warning message.', '2.1')[1] == 1


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:33:21.571807
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    self = _DeprecatedSequenceConstant(('1','2','3'), 'msg', '1.0')
    assert self[0] == '1'

# Generated at 2022-06-22 19:33:23.908832
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    TEST = _DeprecatedSequenceConstant((1,2,3), 'message', 'version')
    assert len(TEST) == 3


# Generated at 2022-06-22 19:33:26.929584
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 19:33:32.541077
# Unit test for function set_constant
def test_set_constant():
    '''
    Verify the function set_constant works correctly.
    '''
    constants = {}
    set_constant('SET_CONSTANT_TEST', 'set_constant_test', export=constants)
    assert constants['SET_CONSTANT_TEST'] == 'set_constant_test'



# Generated at 2022-06-22 19:33:41.726096
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """Ensure a DeprecatedSequenceConstant behaves as a Sequence and
    can be iterated over.
    """

    msg = "This is a deprecation message."
    version = "2.12"
    l = [1, 2, 3]

    c = _DeprecatedSequenceConstant(l, msg, version)

    # Check that the __len__ method works
    assert len(l) == len(c)

    # Check that the __getitem__ method works
    assert l == c


# Note: the following functions have the same name as ones in the module_utils modules but they have the same
# behavior in their respective namespace
validate_boolean = config.get_config_value('DEFAULT_BOOLEAN_REPRESENTATION', 'bool')

# Generated at 2022-06-22 19:33:48.054444
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    #test for the constructor
    result = _DeprecatedSequenceConstant(['ansible.builtin.wait_for', 'ansible.builtin.wait_for_connection'], 'this is a test', '0.1.1')

    assert len(result) == 2
    assert result[0] == 'ansible.builtin.wait_for'
    assert result[1] == 'ansible.builtin.wait_for_connection'

    #test for error when try to get a value out of range
    try:
        result[3]
    except IndexError:
        pass

# Generated at 2022-06-22 19:33:54.065962
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.six import PY3
    v = _DeprecatedSequenceConstant((1, 2, 3), 'test', 'test')
    assert len(v) == 3
    assert PY3 == True or isinstance(v[1], int)

del config

# Generated at 2022-06-22 19:34:03.891210
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    global _deprecated_called
    _deprecated_called = False
    def _deprecated_side_effect(*args, **kwargs):
        global _deprecated_called
        _deprecated_called = True
    global _deprecated
    _deprecated_original = _deprecated
    _deprecated = _deprecated_side_effect
    try:
        seq = _DeprecatedSequenceConstant(['foo', 'bar'], 'message', 'version')
        assert seq[0] == 'foo'
        assert _deprecated_called
        _deprecated_called = False
        assert seq[1] == 'bar'
        assert _deprecated_called
    finally:
        _deprecated = _deprecated_original

# Generated at 2022-06-22 19:34:16.477326
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    msg = 'foo'
    version = '2.4'
    after_value = 'bar'
    value = [1, 2, 3, 'foo', 42]
    value_proxy = AnsibleUnsafeText(value)
    dsc = _DeprecatedSequenceConstant(value_proxy, msg, version)
    assert isinstance(dsc, Sequence)

    assert len(dsc) == 5
    _deprecated.calls = 0
    assert dsc[2] == 3
    assert _deprecated.calls == 1
    _deprecated.calls = 0
    assert list(dsc) == value
    assert _deprecated.calls == 1
    _deprecated.calls = 0
    assert sum(dsc) == 48

# Generated at 2022-06-22 19:34:17.151402
# Unit test for function set_constant
def test_set_constant():
    pass



# Generated at 2022-06-22 19:34:21.210052
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('ANSIBLE_TEST_CONSTANT', True, export=test_dict)
    if test_dict['ANSIBLE_TEST_CONSTANT'] is not True:
        raise AssertionError('set_constant did not update the dictionary')

# Generated at 2022-06-22 19:34:26.056489
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    value = [1, 2, 3]
    deprecated = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated[0] == value[0]


# Generated at 2022-06-22 19:34:27.362751
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "", "1.2.3")) == 3

# Generated at 2022-06-22 19:34:33.123387
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test = _DeprecatedSequenceConstant(('a', 'b', 'c',), 'test1', 'test_version')
    assert len(test) == 3
    assert test[0] == 'a'
    assert test[1] == 'b'
    assert test[2] == 'c'

# FIXME: move to test_config
# check for value inconsistencies between config and constants

# Generated at 2022-06-22 19:34:38.902407
# Unit test for function set_constant
def test_set_constant():

    set_constant('ANSIBLE_TEST_SET_CONSTANT', 'foo', export=vars())
    assert ANSIBLE_TEST_SET_CONSTANT == 'foo'

    set_constant('ANSIBLE_TEST_SET_CONSTANT', 'bar', export=vars())
    assert ANSIBLE_TEST_SET_CONSTANT == 'bar'

    set_constant('ANSIBLE_TEST_SET_CONSTANT', 'baz', export=vars())
    assert ANSIBLE_TEST_SET_CONSTANT == 'baz'

# Generated at 2022-06-22 19:34:40.504726
# Unit test for function set_constant
def test_set_constant():
    globals()['set_constant']('TEST', 123)
    assert TEST == 123

# Generated at 2022-06-22 19:34:41.675367
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None

# Generated at 2022-06-22 19:34:47.899063
# Unit test for function set_constant
def test_set_constant():
    # check that constants are not overwritten without force
    try:
        set_constant('DEFAULT_BECOME_PASS', 'blah')
    except AssertionError:
        pass
    else:
        raise Exception("Can overwrite constant without force.")

    # check that we can overwrite with force
    try:
        set_constant('DEFAULT_BECOME_PASS', 'blah', force=True)
    except AssertionError:
        raise Exception("Cannot overwrite constant with force.")

    # check that we can set new constants
    try:
        set_constant('BLAH_BLAH_BLAH', 'blah')
    except AssertionError:
        raise Exception("Cannot set constant.")


test_set_constant()

# Generated at 2022-06-22 19:34:55.605830
# Unit test for function set_constant

# Generated at 2022-06-22 19:34:58.374432
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONST', 'test')
    assert TEST_CONST == 'test'

# Generated at 2022-06-22 19:35:01.127738
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')
    assert c[1] == 2


# Generated at 2022-06-22 19:35:08.521548
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    import sys

    d = _DeprecatedSequenceConstant('dummy', 'msg', 'version')
    assert(isinstance(d, Sequence))
    assert(isinstance(len(d), int))
    assert(len(d) == len('dummy'))
    assert(sys.exc_info()[0] == None)



# Generated at 2022-06-22 19:35:19.031707
# Unit test for function set_constant
def test_set_constant():
    import types
    my_dict = {}
    set_constant('TEST', 'TEST_VALUE', my_dict)
    assert my_dict['TEST'] == 'TEST_VALUE'
    assert isinstance(my_dict['TEST'], types.StringTypes)

    set_constant('TEST2', True, my_dict)
    assert my_dict['TEST2'] is True
    assert isinstance(my_dict['TEST2'], bool)

    set_constant('TEST3', 1234, my_dict)
    assert my_dict['TEST3'] == 1234
    assert isinstance(my_dict['TEST3'], type(1234))

# Generated at 2022-06-22 19:35:28.770467
# Unit test for function set_constant
def test_set_constant():
    config = ConfigManager()
    configuration = {'foo': 'bar', 'baz': '{{ansible_user}}'}
    for setting in config.data.get_settings():
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render(vars())
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not templatable

        set_constant(setting.name, value, configuration)
    assert configuration == vars()


# NOTE:

# Generated at 2022-06-22 19:35:31.280863
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def _assert(assertion, msg):
        assert assertion, msg

    _assert(True == False, 'No test was performed!')


# Generated at 2022-06-22 19:35:32.558610
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')['a']


# Generated at 2022-06-22 19:35:36.187364
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Message:
        pass
    a = Message()
    a.w = 'warning'
    a.v = '2.0'
    s = _DeprecatedSequenceConstant(['p', 'q'], 'warning', '2.0')
    assert s[0] == 'p'
    assert s[1] == 'q'
    assert isinstance(s, Sequence)


# Generated at 2022-06-22 19:35:48.934167
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class CheckDeprecated():
        def __init__(self, msg, version):
            self.msg = msg
            self.version = version

        def deprecated(self, msg, version):
            assert self.msg == msg, 'Expected: %s, but got: %s' % (self.msg, msg)
            assert self.version == version, 'Expected: %s, but got: %s' % (self.version, version)

    import sys
    old_stderr = sys.stderr


# Generated at 2022-06-22 19:35:51.092478
# Unit test for function set_constant
def test_set_constant():
    set_constant('PATH', '/usr/bin')
    assert PATH == '/usr/bin'


# Generated at 2022-06-22 19:36:01.391097
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT_1', 'TEST_VALUE_1')

    if TEST_CONSTANT_1 != 'TEST_VALUE_1':
        raise Exception(
            'Value of TEST_CONSTANT_1 should be TEST_VALUE_1, '
            'but it\'s ' + TEST_CONSTANT_1
        )

    set_constant('TEST_CONSTANT_2', 'TEST_VALUE_2', globals())

    if TEST_CONSTANT_2 != 'TEST_VALUE_2':
        raise Exception(
            'Value of TEST_CONSTANT_2 should be TEST_VALUE_2, '
            'but it\'s ' + TEST_CONSTANT_2
        )


# Generated at 2022-06-22 19:36:05.281274
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'test_message', '2.9'), _DeprecatedSequenceConstant)
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test_message', '2.9')) == 3

# Generated at 2022-06-22 19:36:08.604680
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant(value, msg, version)
    _DeprecatedSequenceConstant([1, 2, 3], 'The SequenceConstant', '2.8')


# Generated at 2022-06-22 19:36:16.969616
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import tempfile
    from io import StringIO

    # Ensure sys.stderr is a StringIO (a StringIO of a StringIO ?)
    std_err = StringIO()
    sys.stderr = std_err

# Generated at 2022-06-22 19:36:21.953026
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    set_constant('_TEST_DEPRECATED_SEQUENCE_CONSTANT', _DeprecatedSequenceConstant([True, False], 'test_msg', '2.10'))
    assert len(_TEST_DEPRECATED_SEQUENCE_CONSTANT) == 2


# Generated at 2022-06-22 19:36:31.730278
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dummy_value = ['dummy value']
    dummy_msg = 'dummy msg'
    dummy_version = 'dummy version'
    assert len(dummy_value) == len(_DeprecatedSequenceConstant(dummy_value, dummy_msg, dummy_version))
    assert dummy_value[0] == _DeprecatedSequenceConstant(dummy_value, dummy_msg, dummy_version)[0]


# Force an import of plugins for which we can configure default settings
# to ensure their constants are available for use in settings
# We don't import their module directly as the modules themselves can
# require settings before importing them (test_plugin.py)
import ansible.plugins.action  # noqa
import ansible.plugins.cache  # noqa
import ansible.plugins.callback  # noqa
import ansible.plugins.cliconf

# Generated at 2022-06-22 19:36:36.109161
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    results = ['correct']
    class_ = _DeprecatedSequenceConstant(
        value=results,
        msg='some msg',
        version='2.9',
    )
    assert class_[0] == results[0]


# Generated at 2022-06-22 19:36:38.598341
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test = _DeprecatedSequenceConstant([1,2,3,4], "This is a test", "2.4")
    assert len(test) == 4


# Generated at 2022-06-22 19:36:40.753506
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], '1234', 'v2.10')) == 3

# Generated at 2022-06-22 19:36:44.197090
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(c) == 3
    assert isinstance(c, Sequence)
    assert c[1] == 2

# Generated at 2022-06-22 19:36:46.037197
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "test_msg", "test_version")) == 3


# Generated at 2022-06-22 19:36:49.055771
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    val = _DeprecatedSequenceConstant([1, 2, 3], 'this is a message', '2.6')
    assert len(val) == 3

# Generated at 2022-06-22 19:36:53.874417
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''
    A test to verify __len__ of class _DeprecatedSequenceConstant
    '''
    my_list = [1, 2]
    my_dep_seq = _DeprecatedSequenceConstant(my_list, "msg", "version")
    my_len = len(my_dep_seq)
    assert my_len == 2



# Generated at 2022-06-22 19:36:56.048238
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    instance = _DeprecatedSequenceConstant(['foo', 'bar'], 'This is a message', '2.9')
    assert instance[0] == 'foo'
    assert instance[1] == 'bar'

# Generated at 2022-06-22 19:37:00.779791
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], "test msg", "test.version")
    assert len(test_obj) == len([1, 2, 3])


# Generated at 2022-06-22 19:37:04.165116
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert 'a' == _DeprecatedSequenceConstant('a', 'test', '2.12')[0], "__getitem__ function of class _DeprecatedSequenceConstant does not work properly"



# Generated at 2022-06-22 19:37:07.904859
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    class Test:
        def __init__(self):
            self.testVar = _DeprecatedSequenceConstant('test', 'test message', '2.9')
    assert 'test' == Test().testVar

# Test for function _warning

# Generated at 2022-06-22 19:37:10.954378
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg="some message", version="2.9")) == 0


# Generated at 2022-06-22 19:37:13.243603
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant((1,2,3),'msg','version')[1]


# Generated at 2022-06-22 19:37:23.346000
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(DEFAULT_SUBSET, _DeprecatedSequenceConstant)
    assert isinstance(DEFAULT_SUBSET, Sequence)
    assert not hasattr(DEFAULT_SUBSET, '__next__')
    assert len(DEFAULT_SUBSET) == 0
    assert list(DEFAULT_SUBSET) == []
    assert tuple(DEFAULT_SUBSET) == ()
    assert DEFAULT_SUBSET[:] == []
    try:
        DEFAULT_SUBSET[0]
    except IndexError:
        pass
    else:
        assert False, "Did not raise IndexError"
    try:
        iter(DEFAULT_SUBSET)
    except TypeError as e:
        assert str(e) == "'_DeprecatedSequenceConstant' object is not iterable"

# Generated at 2022-06-22 19:37:28.183109
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(value = ['a', 'b'], msg = 'test value', version = '')
    assert x._value == ['a', 'b']
    assert x._msg == 'test value'
    assert x._version == ''

# Generated at 2022-06-22 19:37:33.051909
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ds = _DeprecatedSequenceConstant([1, 2, 3], "message", "Version 1.0")
    assert len(ds) == 3
    assert ds[2] == 3
    assert ds._msg == "message"

# Generated at 2022-06-22 19:37:38.296360
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_name', 'test value')
    assert test_name == 'test value'
    assert test_name == CONFIG_DATA_SECTION_VARS['test_name']
    assert test_name == config.data.get_config_value('test_name', failover=None)
    del test_name



# Generated at 2022-06-22 19:37:40.669727
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([], '', '3.0.0')
    assert isinstance(a, Sequence)

# Generated at 2022-06-22 19:37:43.577055
# Unit test for function set_constant
def test_set_constant():
    _test = {}
    set_constant("test_key", "test_value", _test)
    assert _test.get("test_key", None) == "test_value"

# Generated at 2022-06-22 19:37:47.389954
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Hello World'
    from ansible import constants
    version = constants.__version__
    constants._DeprecatedSequenceConstant((1,2), msg, version)

# Generated at 2022-06-22 19:37:51.444790
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_data = [1, 2, 3, 4, 5]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(list_data, "test", "2.0")
    assert len(list_data) == len(deprecated_sequence_constant)

# Generated at 2022-06-22 19:37:54.146949
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_list = _DeprecatedSequenceConstant([1, 2, 3], 'Test msg', '2.9')
    assert len(deprecated_list) == 3


# Generated at 2022-06-22 19:37:57.929098
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version'), _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:38:02.984306
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'DEPRECATED'
    version = None
    value = [1, 2, 3]
    fixture = _DeprecatedSequenceConstant(value, msg, version)
    assert len(fixture) == 3
    assert fixture[0] == 1
    assert fixture[1] == 2
    assert fixture[2] == 3

# Generated at 2022-06-22 19:38:13.067422
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common._collections_compat import Mapping

    seq_constant = _DeprecatedSequenceConstant([1, 2, 3], "Test msg", "2.9")
    assert isinstance(seq_constant, Sequence)
    assert seq_constant != [1, 2, 3]
    assert len(seq_constant) == 3
    assert seq_constant[0] == 1

    mapping = Mapping()
    mapping['a'] = 1
    mapping['b'] = 2

    # __getitem__ method is not supported for Mapping object
    mapping_constant = _DeprecatedSequenceConstant(mapping, "Test", "2.9")
    assert isinstance(mapping_constant, Sequence)
    assert mapping

# Generated at 2022-06-22 19:38:20.226633
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['host1', 'host2'], 'host_list cannot be used', '2.0')._value == ['host1', 'host2']
    assert len(_DeprecatedSequenceConstant(['host1', 'host2'], 'host_list cannot be used', '2.0')) == 2
    assert _DeprecatedSequenceConstant(['host1', 'host2'], 'host_list cannot be used', '2.0')[0] == 'host1'


# Generated at 2022-06-22 19:38:22.053554
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'debug', 'test')) == 3

# Generated at 2022-06-22 19:38:23.643745
# Unit test for function set_constant
def test_set_constant():
    assert vars()['DEFAULT_HOST_LIST'] == "/etc/ansible/hosts"

# Generated at 2022-06-22 19:38:27.433407
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2]
    msg = 'test message'
    version = 'test version'
    assert len(_DeprecatedSequenceConstant(value, msg, version)) == 2


# Generated at 2022-06-22 19:38:29.872764
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    length = 1
    value = ['ansible.builtin.debug']
    msg = 'The use of "debug" is deprecated'
    version = '2.12'
    assert (len(_DeprecatedSequenceConstant(value, msg, version)) == length)

# Generated at 2022-06-22 19:38:34.508640
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'asdf')
    if vars()['test'] != 'asdf':
        raise AssertionError('failed to set a constant')

    vars().pop('test')
    set_constant('test', 'asdf', dict())
    if 'test' not in dict():
        raise AssertionError('failed to set a constant in a dict()')

test_set_constant()

# Generated at 2022-06-22 19:38:36.673044
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant([1, 2, 3], '', '')[0]

# Generated at 2022-06-22 19:38:46.603555
# Unit test for function set_constant
def test_set_constant():
    value = False
    set_constant('value', value)
    assert value is False


# DEPRECATED CONSTANTS ###

# the following constants are deprecated and will be removed in Ansible 2.0
# they should not be used in modules or plugins

# Modules which support check_mode.  If not set, we default to all.
ACTION_CHECK_MODE = frozenset(add_internal_fqcns(('service', 'raw', 'script', 'command', 'win_service', 'ansible.windows.win_service', 'win_raw', 'ansible.windows.win_raw', 'win_script', 'ansible.windows.win_script', 'win_command', 'ansible.windows.win_command', 'user')))  # DEPRECATED

# Generated at 2022-06-22 19:38:49.948751
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Test of class _DeprecatedSequenceConstant'
    version = '2.10'
    tmp = _DeprecatedSequenceConstant((), msg, version)
    # FIXME: may need to test actual warnings raised

# Generated at 2022-06-22 19:38:52.473977
# Unit test for function set_constant
def test_set_constant():
    assert COLOR_CODES == vars()['COLOR_CODES']
    assert COLLECTION_PTYPE_COMPAT == vars()['COLLECTION_PTYPE_COMPAT']

# Generated at 2022-06-22 19:38:57.951006
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('a', 1, export=d)
    assert d == {'a': 1}
    set_constant('a', 2, export=d)
    assert d == {'a': 2}

# Generated at 2022-06-22 19:39:08.125161
# Unit test for function set_constant
def test_set_constant():
    ''' set_constant is used when populating all values, a test of it is
    very important.  This function tests that a few settings were properly
    loaded and processed by set_constant, which we can be confident is
    acting properly since we just used it to load the constants. '''

    assert CACHE_PLUGIN_NAME == 'jsonfile'
    assert CACHE_PLUGIN_CONNECTION == "~/.ansible/tmp"
    assert MIN_ANSIBLE_VERSION == (2, 4)

# Generated at 2022-06-22 19:39:10.110813
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant('testing','deprecation','2.0')

    assert len(test_sequence) == 7

# Generated at 2022-06-22 19:39:14.598912
# Unit test for function set_constant
def test_set_constant():
    '''
    Used for unit testing
    '''
    foo = {}
    set_constant('bar', 'foo')
    set_constant('baz', 'foo', foo)
    assert bar == 'foo'
    assert foo['baz'] == 'foo'

# Generated at 2022-06-22 19:39:19.679065
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class_test = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test msg', version='2.9')
    assert len(class_test) == len([1, 2, 3])
    assert class_test[0] == 1
    assert class_test[1] == 2

# Generated at 2022-06-22 19:39:22.522083
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant(value=[1,2], msg='', version='2.9')
    assert len(sequence) == 2


# Generated at 2022-06-22 19:39:27.121123
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test case 1
    sequence = _DeprecatedSequenceConstant(('a'), 'test', '2.0')
    assert len(sequence) == 1
    # test case 2
    sequence = _DeprecatedSequenceConstant(('b'), 'test', '2.0')
    assert len(sequence) == 1


# Generated at 2022-06-22 19:39:37.116830
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is True
    assert DEFAULT_CACHE_PLUGIN == 'jsonfile'
    assert DEFAULT_CACHE_PLUGIN_CONNECTION is None
    assert DEFAULT_CACHE_PLUGIN_TIMEOUT == 3600


# Create deprecated constants
for setting in config.data.get_settings():
    if setting.deprecated and setting.deprecated is not 'removed':
        set_constant(setting.name.upper(), _DeprecatedSequenceConstant(setting.value, setting.deprecated, setting.removed_in))

for warn in config.WARNINGS:
    _warning(warn)


# LEGACY CONSTANTS ###
# TODO: remove in 2.10
# These are constants as they are hard-coded to the settings and should
# generally not be

# Generated at 2022-06-22 19:39:41.041094
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(['hi','there','world'], "DEPRECATION", "0.1")
    assert s[0:3] == ['hi', 'there', 'world']


# Generated at 2022-06-22 19:39:47.961447
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant([0, 1, 2], 'test message', '2.0')
    # when called, __getitem__ will call _deprecated with the message
    assert seq[0] == 0
    assert seq[1] == 1
    assert seq[2] == 2
    assert len(seq) == 3
    try:
        assert seq[3]
        assert False
    except IndexError:
        pass
    assert seq[-1] == 2



# Generated at 2022-06-22 19:39:57.363325
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import sys
    if sys.version_info[0] == 2:
        import StringIO
        out = StringIO.StringIO()
    else:
        import io
        out = io.StringIO()

    # Capture stderr
    stderr = sys.stderr
    sys.stderr = out

    # Test method
    s = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(s, 'Test warning message.', 'v2.0')
    assert len(dsc) == len(s)

    # Restore stderr
    sys.stderr = stderr

# Generated at 2022-06-22 19:40:00.241772
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(list(range(10)), 'msg', 'version')
    assert len(a) == 10



# Generated at 2022-06-22 19:40:02.490071
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('foo', 'bar', export=export)
    assert export['foo'] == 'bar'



# Generated at 2022-06-22 19:40:07.387109
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.collection_loader import _DeprecatedSequenceConstant

    assert isinstance(_DeprecatedSequenceConstant((1, ), ("msg", "version"), "version"), Sequence)
    assert isinstance(_DeprecatedSequenceConstant([1, ], ("msg", "version"), "version"), Sequence)

# Generated at 2022-06-22 19:40:18.912100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Test exception handling.
    class TestException(Exception):
        pass

    # Test the case "_warning" returns None, i.e. using sys.stderr.write, which
    # causes the call to _warning to raise an exception.
    try:
        import sys
        import sys
        import types
        old_stderr = sys.stderr
        sys.stderr = types.ModuleType('sys.stderr')
        sys.stderr.write = lambda s: None
        try:
            _DeprecatedSequenceConstant(['a','b'], 'msg', 'version')[1]
            assert False
        except TestException:
            sys.stderr = old_stderr
            return
        assert False
    except TestException:
        assert False
    except Exception:
        assert True
       

# Generated at 2022-06-22 19:40:27.575381
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test the case where given item is exist
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'

    # Test the case where given item is not exist
    try:
        dsc[4]
    except Exception as e:
        assert type(e) == IndexError

    # Test the case where given item is out of range
    try:
        dsc[-4]
    except Exception as e:
        assert type(e) == IndexError