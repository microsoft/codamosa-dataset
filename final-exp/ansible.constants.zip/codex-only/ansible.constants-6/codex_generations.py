

# Generated at 2022-06-22 19:30:34.122037
# Unit test for function set_constant
def test_set_constant():
    test_export = {}
    set_constant('foo', 'bar', export=test_export)
    assert 'foo' in test_export
    assert test_export['foo'] == 'bar'


#.  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .  .

# Generated at 2022-06-22 19:30:43.180641
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import pytest
    warning_list = []
    def warning_func(msg):
        nonlocal warning_list
        warning_list.append(msg)
    _warning(None)
    _warning = warning_func
    # test any type that can be convert to list
    for v in (1, 'str', (), [], {}, object(), object()):
        _DeprecatedSequenceConstant(v, 'msg', 'version')
    # test for list
    _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert warning_list == [' [DEPRECATED] msg, to be removed in version'] * 6
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 19:30:48.748972
# Unit test for function set_constant
def test_set_constant():
    export_dict = {}
    set_constant('test1', 1, export=export_dict)
    set_constant('test2', 2, export=export_dict)
    set_constant('test3', 3, export=export_dict)
    assert export_dict['test1'] == 1
    assert export_dict['test2'] == 2
    assert export_dict['test3'] == 3

# Generated at 2022-06-22 19:30:51.493018
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert len(dsc) == 2


# Generated at 2022-06-22 19:30:54.641987
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    import mock

    x = _DeprecatedSequenceConstant('value', 'msg', 'version')

    assert x[0] == 'v'

# Generated at 2022-06-22 19:30:59.310439
# Unit test for function set_constant
def test_set_constant():
    locals = {}
    set_constant('foo', 'bar', export=locals)
    assert locals['foo'] == 'bar'
    set_constant('foo', 'baz', export=locals)
    assert locals['foo'] == 'bar'


# Generated at 2022-06-22 19:31:03.066558
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(('test_test_test', ), 'test_test_test', 'test_test_test')[0] == 'test_test_test'

# Generated at 2022-06-22 19:31:12.335857
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(HOST_KEY_CHECKING, bool)
    assert isinstance(HOST_KEY_CHECKING_POLICY, string_types)
    assert isinstance(DEFAULT_HOST_LIST, string_types)
    assert isinstance(DEFAULT_PRIVATE_KEY_FILE, string_types)
    assert isinstance(DEFAULT_MODULE_LANG, string_types)
    assert isinstance(DEFAULT_MODULE_NAME, string_types)
    assert isinstance(DEFAULT_MODULE_PATH, string_types)
    assert isinstance(DEFAULT_PLAYBOOK_PATH, string_types)
    assert isinstance(DEFAULT_CACHE_PLUGIN, string_types)
    assert isinstance(DEFAULT_CACHE_PLUGIN_CONNECTION, string_types)

# Generated at 2022-06-22 19:31:18.757823
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    test = _DeprecatedSequenceConstant(value, msg, version)
    assert test._value == value
    assert test._msg == msg
    assert test._version == version
    assert test[0] == 1
    assert len(test) == 3


# Generated at 2022-06-22 19:31:21.962109
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    unit = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert unit[0] is None


# Generated at 2022-06-22 19:31:24.318056
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    SC = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'a test', '1.0')
    assert(list(SC) == ['a', 'b', 'c'])


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:31:28.147342
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'foo'
    version = '2.9.1'

    try:
        v = _DeprecatedSequenceConstant([], msg, version)
    except Exception:
        assert False, '_DeprecatedSequenceConstant constructor with empty list raises exception'

    try:
        v = _DeprecatedSequenceConstant(['foo'], msg, version)
    except Exception:
        assert False, '_DeprecatedSequenceConstant constructor with non-empty list raises exception'

# Generated at 2022-06-22 19:31:30.168413
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    tmp = _DeprecatedSequenceConstant('foo', 'message', '1.2')
    assert tmp.__len__(), 3
    assert tmp.__getitem__(1), 'o'

# Stub out deprecation warnings for use in unit tests

# Generated at 2022-06-22 19:31:33.286548
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(s) == 0

# Generated at 2022-06-22 19:31:36.855765
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1, 2, 3]
    msg = 'msg'
    version = '2.0'
    x = _DeprecatedSequenceConstant(value, msg, version)

    assert len(x) == 3


# Generated at 2022-06-22 19:31:46.423810
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    CONTSTANT = _DeprecatedSequenceConstant(['foo', 'bar', 'baz'], 'msg', 'version')
    assert CONTSTANT[0] == 'foo'
    assert CONTSTANT[1] == 'bar'
    assert CONTSTANT[2] == 'baz'
    for i in range(-3, 4):
        try:
            CONTSTANT[i]
        except IndexError:
            pass
        else:
            assert False, 'IndexError not raised for index: %s' % i
    for item in ('foo', 'bar', 'baz'):
        assert item in CONTSTANT
    assert 'qux' not in CONTSTANT


# Generated at 2022-06-22 19:31:52.667010
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_values = [
        (('first', 'second'), 'testing message', 'testing version'),
        (('third', 'fourth'), 'test message', 'test version')
    ]
    for value, msg, version in test_values:
        test_obj = _DeprecatedSequenceConstant(value, msg, version)
        assert len(test_obj) == len(value)

# Generated at 2022-06-22 19:32:03.318898
# Unit test for function set_constant
def test_set_constant():
    old_path = '%s/redhat' % sys.path[0]
    new_path = '%s/debian' % sys.path[0]
    set_constant('PATH', new_path)
    assert PATH == new_path, 'PATH is wrong'
    set_constant('PATH', old_path)
    assert PATH == old_path, 'PATH is wrong'
    try:
        assert BAR == 'BAR', 'unset variable BAR is wrong'
        assert False, 'BAR should not be set'
    except NameError:
        pass
    set_constant('BAR', 'BAR')
    assert BAR == 'BAR', 'BAR should be BAR'

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-22 19:32:11.703516
# Unit test for function set_constant
def test_set_constant():
    # Test for module level constants
    assert set_constant('token', '42') == {'token': '42'}

    # Test for module level constants in local namespace
    var = {}
    set_constant('token', '43', export=var)
    assert var['token'] == '43'

    # Test for an invalid constant name
    try:
        set_constant(None, '44')
    except AttributeError:
        pass
    except Exception as e:
        raise AssertionError('Expected AttributeError with wrong constant name. Got: %s' % e)
    else:
        raise AssertionError('Expected AttributeError with wrong constant name. Got no exception.')

    # Test for an invalid constant value

# Generated at 2022-06-22 19:32:13.724383
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', None)
    assert 'foo' in globals()


# Generated at 2022-06-22 19:32:17.440637
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], "msg", "version")) == 0
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3
    assert len(_DeprecatedSequenceConstant([1, 2, 3, 4, 5], "msg", "version")) == 5

# Generated at 2022-06-22 19:32:28.244299
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # __len__ must return the same length for any of the sequences
    assert len(_DeprecatedSequenceConstant(_ACTION_HAS_CMD, "", "2.11")) == 3
    assert len(_DeprecatedSequenceConstant(_ACTION_ALL_INCLUDE_TASKS, "", "2.11")) == 4
    assert len(_DeprecatedSequenceConstant(_ACTION_ALL_INCLUDE_ROLE_TASKS, "", "2.11")) == 5
    assert len(_DeprecatedSequenceConstant(_ACTION_ALL_INCLUDE_IMPORT_TASKS, "", "2.11")) == 6
    assert len(_DeprecatedSequenceConstant(_ACTION_FACT_GATHERING, "", "2.11")) == 2

# Generated at 2022-06-22 19:32:31.172599
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3, 4, 5], 'foo', '999.999')) == 5


# Generated at 2022-06-22 19:32:34.924481
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Dummy:
        def __len__(self):
            return 2

    test_deprecated_sequence_constant = _DeprecatedSequenceConstant(Dummy(), 'msg', 'version')
    assert len(test_deprecated_sequence_constant) == 2



# Generated at 2022-06-22 19:32:38.794647
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant((1,2), "warning message", "2.11")
    assert sequence[0] == 1 and sequence[1] == 2

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:32:40.573864
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3], 'test', 'X.Y')

# Generated at 2022-06-22 19:32:52.416008
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from unittest import TestCase, main
    from ansible.module_utils._text import to_bytes

    class TestSequence(Sequence):
        def __init__(self, value):
            self._value = value

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]

    class Test_DeprecatedSequenceConstant(TestCase):
        def test__getitem__(self):
            dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='dummy_msg', version='dummy_version')
            self.assertIsInstance(dsc, TestSequence)

# Generated at 2022-06-22 19:32:55.198239
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(('a', 'b'), "message", "2.0")
    assert len(obj) == 2
    assert obj[0] == 'a'
    assert obj[1] == 'b'

# Generated at 2022-06-22 19:32:57.399385
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert s[1] == 2


# Generated at 2022-06-22 19:33:10.674197
# Unit test for function set_constant
def test_set_constant():
    test_dir = 'unittest_data/set_constant_config/'
    test_constant = 'ANOTHER_TEST_CONSTANT'
    test_origin = 'UNIT_TEST'
    test_value = 'test_value'
    test_type = 'str'

    # Make sure constant doesn't exist yet
    assert not globals().get(test_constant, None)

    # Use forced config to add a setting to config.data.SETTINGS
    forced_config = {test_constant: {'default': test_value, 'type': test_type, 'origin': test_origin}}

    # Test set_constant
    set_constant(test_constant, test_value, forced_config)
    assert forced_config[test_constant] == test_value

    # Test that set

# Generated at 2022-06-22 19:33:13.108865
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), 'msg', 'version')) == 3


# Generated at 2022-06-22 19:33:16.234245
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant((1,2,3), msg='', version='999').__len__() == 3


# Generated at 2022-06-22 19:33:25.118480
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test for type tuple/list
    test_value = (1, 2, 3, 4)
    test_msg = 'Test'
    test_version = '2.0'
    dsc_test = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(dsc_test) == len(test_value)

    test_value = [1, 2, 3, 4]
    dsc_test = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(dsc_test) == len(test_value)


# Generated at 2022-06-22 19:33:28.796473
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Simple test to guarantee the returned value is proper while it is not a DeprecatedClass
    assert len(ANSIBLE_LIBRARY) == len(ANSIBLE_CALLBACK_PLUGINS) == len(ANSIBLE_ACTION_PLUGINS) == len(ANSIBLE_LIBRARY_PATHS) == 0
    # Simple test to guarantee the returned value is proper while it is an instance of DeprecatedClass
    assert len(_DeprecatedSequenceConstant([1, 2], '', '')) == 2


# Generated at 2022-06-22 19:33:33.020980
# Unit test for function set_constant
def test_set_constant():
    '''
    Test the set_constant function using the __builtin__ module.
    '''

    from __builtin__ import max as max_func  #
    set_constant('max_func', max_func)
    assert max_func is max_func

# Generated at 2022-06-22 19:33:35.468325
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant(tuple(), 'msg', '1.0')
    assert len(dsc) == len(tuple())


# Generated at 2022-06-22 19:33:39.921756
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Foo():
        def __getitem__(self, y):
            return y

    dsc = _DeprecatedSequenceConstant(Foo(), "foo", "bar")

    assert dsc[2] == 2


# Generated at 2022-06-22 19:33:44.244681
# Unit test for function set_constant
def test_set_constant():
    """
    >>> assert isinstance(DEFAULT_ASK_SUDO_PASS, bool)
    >>> assert isinstance(DEFAULT_ASK_SU_PASS, bool)
    >>> assert isinstance(DEFAULT_BECOME, bool)
    >>> assert isinstance(DEFAULT_BECOME_ASK_PASS, bool)
    """

# Generated at 2022-06-22 19:33:47.444583
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'unused', '2.0')
    assert c[2] == 3
    assert len(c) == 3

    assert not _DeprecatedSequenceConstant([1], 'unused', '2.0')

# Generated at 2022-06-22 19:33:54.465135
# Unit test for function set_constant
def test_set_constant():
    # test default value
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None

    # set new value
    set_constant('DEFAULT_BECOME_PASS', 'test')
    set_constant('DEFAULT_REMOTE_PASS', 'test')
    set_constant('DEFAULT_SUBSET', 'test')

    # test new value
    assert DEFAULT_BECOME_PASS == 'test'
    assert DEFAULT_REMOTE_PASS == 'test'
    assert DEFAULT_SUBSET == 'test'


# Make sure __version__ is a float

# Generated at 2022-06-22 19:34:02.013130
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    actual = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', 'test_version')
    expected = [1, 2, 3]
    assert len(actual) == len(expected)
    assert list(actual) == list(expected)
    assert actual[0] == expected[0]
    assert actual[1] == expected[1]
    assert actual[2] == expected[2]


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:34:09.864527
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence

    class test_method(Sequence):
        def __getitem__(self, i):
            return i

    test = test_method()
    assert isinstance(test, Sequence)
    assert test[1] == 1
    assert test[1:] == slice(1, None) # __getitem__(slice(1, None)) == slice(1, None)

    test = test_method()
    # __getitem__(slice(start, end, step)) with indices out of range
    assert test[100:] == slice(100, None)
    assert test[100:1000] == slice(100, 1000)
    assert test[100:1000:2] == slice(100, 1000, 2)

# Generated at 2022-06-22 19:34:22.001954
# Unit test for function set_constant
def test_set_constant():
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.utils.fqcn import add_internal_fqcns
    config = ConfigManager()
    for setting in config.data.get_settings():
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render()
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not

# Generated at 2022-06-22 19:34:25.914696
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    l = [1,2,3]
    dsc = _DeprecatedSequenceConstant(l, 'msg', 'version')
    assert dsc.__len__() == 3

# Generated at 2022-06-22 19:34:29.105074
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert c[0] == 1
    assert len(c) == 3

# Generated at 2022-06-22 19:34:39.016573
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value):
            self._value = value

        def __getitem__(self, y):
            return self._value[y]

    msg = 'Error Message !'
    value = Test([10,20,30,40])
    obj = _DeprecatedSequenceConstant(value, msg, '1.3')
    assert len(obj) == len(value)
    assert obj[0] == 10
    assert obj[1] == 20
    assert obj[2] == 30
    assert obj[3] == 40


# Generated at 2022-06-22 19:34:41.149420
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'foo', 'bar')) == 3


# Generated at 2022-06-22 19:34:43.868189
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0

# Generated at 2022-06-22 19:34:48.676440
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a'], 'a', '1.0')[0] == 'a'
    assert len(_DeprecatedSequenceConstant(['a'], 'a', '1.0')) == 1

# Generated at 2022-06-22 19:34:54.334458
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is the message'
    version = '2.8'
    constant = _DeprecatedSequenceConstant(value=[1, 2, 3, 4], msg=msg, version=version)
    # try to get index
    assert constant[1] == 2
    assert constant[0] == 1
    assert constant[2] == 3
    assert constant[3] == 4
    # try with out of index
    try:
        assert constant[4]
    except IndexError:
        pass
    else:
        assert False


# Generated at 2022-06-22 19:34:57.047857
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert isinstance(_DeprecatedSequenceConstant([1, 2], "", "n/a"), Sequence)

# Generated at 2022-06-22 19:35:03.738107
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    for data in (
        (['foo', 'bar'], 'msg', 'version'),
        ('foobar', 'msg', 'version'),
    ):
        assert isinstance(_DeprecatedSequenceConstant(*data), _DeprecatedSequenceConstant)
        assert len(_DeprecatedSequenceConstant(*data)) == len(data[0])
        assert _DeprecatedSequenceConstant(*data)[0] == data[0][0]

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:35:09.763530
# Unit test for function set_constant
def test_set_constant():
    from tempfile import mkdtemp
    from ansible.parsing.vault import VaultLib
    d = mkdtemp()
    vault_password = VaultLib.get_vault_password(d, 'secrets.yml')
    assert vault_password == ''

varRegex = re.compile(r'\$\{([^\}]+)\}')


# Generated at 2022-06-22 19:35:12.691333
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = ['test1', 'test2']
    msg = 'test_msg'
    version = 'test_version'
    _DeprecatedSequenceConstant(value, msg, version)


# Generated at 2022-06-22 19:35:16.362217
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    example = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert example[0] == 1
    assert example[1] == 2
    assert example[2] == 3



# Generated at 2022-06-22 19:35:19.246022
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(
        _DeprecatedSequenceConstant(['foo', 'bar'], 'testmsg', '2.9'),
        _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:35:23.270364
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', '2.10')
    assert len(t) == 3
    assert t[0] == 1
    assert t[1] == 2
    assert t[2] == 3

# Generated at 2022-06-22 19:35:30.707300
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['foo', 'bar', 'baz'], 'dsc test', '2.9')
    assert len(dsc) == 3
    assert dsc[2] == 'baz'
    assert 'foo' in dsc
    assert 'foobar' not in dsc



# Generated at 2022-06-22 19:35:33.713521
# Unit test for function set_constant
def test_set_constant():
    def check_constant(name, value):
        assert globals()[name] == value

    set_constant('FOO', {'a': 'b'})
    check_constant('FOO', {'a': 'b'})

# Generated at 2022-06-22 19:35:35.694409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version'))

# Generated at 2022-06-22 19:35:41.467870
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import _DEPRECATED_OPTIONS
    for msg, msg_version, option, option_version in _DEPRECATED_OPTIONS:
        assert len(_DeprecatedSequenceConstant(option.split(), msg, msg_version)) == len(option.split())


# Generated at 2022-06-22 19:35:53.722483
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_SUDO_EXE' in vars()
    assert 'DEFAULT_SUDO_FLAGS' in vars()
    assert 'DEFAULT_SUDO_USER' in vars()
    assert DEFAULT_SUDO_EXE is None
    assert DEFAULT_SUDO_FLAGS is None
    assert DEFAULT_SUDO_USER is None

    # Make sure the settings subdir is legit
    assert isinstance(CLICONF_PLUGINS, list)
    assert isinstance(DEFAULT_VAULT_IDENTITY_LIST, list)
    assert isinstance(HOST_KEY_CHECKING, bool)
    assert isinstance(JINJA2_EXTENSIONS, list)
    assert isinstance(DEFAULT_TIMEOUT, float)

# Generated at 2022-06-22 19:35:56.252878
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    o = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(o) == 3
    assert o[1] == 2

# Remove this test if we ever remove the deprecated foo

# Generated at 2022-06-22 19:36:06.117146
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_constant = [1, 2, 3]
    list_constant_getter = _DeprecatedSequenceConstant(list_constant, 'test_warning', '2.9')
    assert list_constant_getter[0] == 1
    assert list_constant_getter[1] == 2
    assert list_constant_getter[2] == 3
    # test negative index
    assert list_constant_getter[-1] == 3
    assert list_constant_getter[-2] == 2
    assert list_constant_getter[-3] == 1
    # test slice
    assert list_constant_getter[0:2] == [1, 2]
    assert list_constant_getter[1:2] == [2]
    assert list_constant_get

# Generated at 2022-06-22 19:36:19.054973
# Unit test for function set_constant
def test_set_constant():
    # Test string constant
    s = 'hello world'
    set_constant('TEST', s)
    assert TEST == s

    # Test int constant
    n = 1234
    set_constant('TEST2', n)
    assert TEST2 == n

    # Test boolean constant
    b = True
    set_constant('TEST3', b)
    assert TEST3 == b

    # Test tuple constant
    t = (1, 2, 3, 4)
    set_constant('TEST4', t)
    assert TEST4 == t

    # Test list constant
    l = [1, 2, 3, 4]
    set_constant('TEST5', l)
    assert TEST5 == l

    # Test dict constant

# Generated at 2022-06-22 19:36:21.908833
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert len(seq) == 2


# Generated at 2022-06-22 19:36:25.388553
# Unit test for function set_constant
def test_set_constant():
    global foo, bar
    set_constant('foo', 'something')
    assert foo == 'something'
    set_constant('bar', 'something', export={'bar': 'else'})
    assert bar == 'else'

# Generated at 2022-06-22 19:36:33.769885
# Unit test for function set_constant
def test_set_constant():
    # Needs to import within the function in order to keep from
    #  causing a circular import.
    from ansible.module_utils._text import to_native
    def get_constant_value(name, export=vars()):
        return export[name]

    for name in config.data.get_settings():
        set_constant(name.name, 'test')
        assert get_constant_value(name.name) == 'test'
        set_constant('%s_test' % name.name, 'test')
        assert get_constant_value('%s_test' % name.name) == 'test'
        set_constant(to_native('%s_test' % name.name), 'test')
        assert get_constant_value(to_native('%s_test' % name.name))

# Generated at 2022-06-22 19:36:40.788949
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l1 = ['test_message_1', 'test_message_2', 'test_message_3']
    l2 = _DeprecatedSequenceConstant(l1, 'test_message_1', 'test_version_1')
    assert l2[0] == 'test_message_1'
    assert l2[1] == 'test_message_2'
    assert l2[2] == 'test_message_3'


# Generated at 2022-06-22 19:36:43.355295
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([1, 2, 3], u"test_msg", u"test_ver")
    assert c[1] == 2

# Generated at 2022-06-22 19:36:46.228362
# Unit test for function set_constant
def test_set_constant():
    set_constant('a_constant', 1)
    if 'a_constant' not in globals():
        raise Exception("unit test failed")
    return True

# Generated at 2022-06-22 19:36:51.234986
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    >>> from ansible.constants import _DeprecatedSequenceConstant
    >>> a = [1, 2, 3]
    >>> test = _DeprecatedSequenceConstant(a, "message", "version")
    >>> test[1]
    >>> test.__getitem__(1)
    '''


# Generated at 2022-06-22 19:36:53.714529
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(['x'], 'a', 'b')
    assert len(seq) == 1
    assert seq[0] == 'x'


# Generated at 2022-06-22 19:36:56.668824
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant([1, 2, 3], 'test', _version)


# Generated at 2022-06-22 19:37:01.331319
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.2.3') == [1, 2, 3]
    assert _DeprecatedSequenceConstant(1, 'test', '1.2.3') == 1
    assert _DeprecatedSequenceConstant('1', 'test', '1.2.3') == '1'
    assert _DeprecatedSequenceConstant(('1', 2, 3), 'test', '1.2.3') == ('1', 2, 3)
    assert _DeprecatedSequenceConstant({1, 2, 3}, 'test', '1.2.3') == {1, 2, 3}
    assert _DeprecatedSequenceConstant({1, 2, 3}, 'test', '1.2.3') == {1, 2, 3}
    assert _DeprecatedSequ

# Generated at 2022-06-22 19:37:04.702643
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.2')
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3

# Generated at 2022-06-22 19:37:07.701094
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = [1, 2, 3]
    c = _DeprecatedSequenceConstant(l, "msg", "version")
    assert c[0] == 1
    assert c[1] == 2
    assert c[2] == 3


# Generated at 2022-06-22 19:37:19.161475
# Unit test for function set_constant
def test_set_constant():
    set_constant('CONST_TEST_STRING', 'test string')
    assert CONST_TEST_STRING == 'test string'

    set_constant('CONST_TEST_INT', 1)
    assert CONST_TEST_INT == 1

    set_constant('CONST_TEST_LIST', [])
    assert CONST_TEST_LIST == []

    set_constant('CONST_TEST_DICT', {})
    assert CONST_TEST_DICT == {}

    set_constant('CONST_TEST_BOOL', True)
    assert CONST_TEST_BOOL is True

    set_constant('CONST_TEST_PRIVATE', '_private_test')
    assert CONST_TEST_PRIVATE == '_private_test'

# Generated at 2022-06-22 19:37:21.773593
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), msg='msg', version='version')) == 2

# Generated at 2022-06-22 19:37:35.529647
# Unit test for function set_constant
def test_set_constant():
    ''' set_constant should replace __builtin__.setattr, so we test the exception thrown if the type
        conflicts with the existing value.  The function is called by the ConfigManager constructor
        so this is executed at import time.
    '''
    try:
        # set the base class of some internal classes to something invalid,
        # and then reset it to the original value
        set_constant('_AnsibleModule__module_class', int)
        set_constant('_AnsibleModule__module_class', str)
        set_constant('_AnsibleModule__warnings', int)
        set_constant('_AnsibleModule__warnings', list)
    except TypeError:
        # this is the desired exception.  If it occurs, all is well,
        # so do nothing
        pass

# Generated at 2022-06-22 19:37:37.961501
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'test msg', 'test version')
    a[0]
    len(a)

# Generated at 2022-06-22 19:37:50.127594
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_str', 'string_constant')
    assert 'test_str' in globals()
    assert globals()['test_str'] == 'string_constant'
    set_constant('test_int', 1000)
    assert 'test_int' in globals()
    assert globals()['test_int'] == 1000
    set_constant('test_list', [1, 2, 3])
    assert 'test_list' in globals()
    assert globals()['test_list'] == [1, 2, 3]
    set_constant('test_dict', {'a': 1, 'b': 2})
    assert 'test_dict' in globals()
    assert globals()['test_dict'] == {'a': 1, 'b': 2}

# Generated at 2022-06-22 19:37:54.528157
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "The setting 'add_files' is deprecated. Please use 'files' instead"
    version = '2.10'
    example_sequence = ["file1", "file2"]
    dep = _DeprecatedSequenceConstant(example_sequence, msg, version)
    assert example_sequence == dep
    assert example_sequence == dep._value
    assert msg == dep._msg
    assert version == dep._version


# Generated at 2022-06-22 19:38:01.213941
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    with pytest.raises(AssertionError):
        _DeprecatedSequenceConstant(value=[1,2,3], msg='msg', version='version')
        _DeprecatedSequenceConstant(value='foo', msg=None, version='version')
        _DeprecatedSequenceConstant(value=[1,2,3], msg='msg', version=None)

# Generated at 2022-06-22 19:38:02.187047
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-22 19:38:12.342620
# Unit test for function set_constant
def test_set_constant():

    # set the constants
    set_constant('TEST_CONSTANT_FOO', True)
    set_constant('TEST_CONSTANT_BAR', False)
    set_constant('TEST_CONSTANT_BAZ', 'HURZ')
    set_constant('TEST_CONSTANT_URKEL', dict(a=1, b='zwei'))

    # ensure the values were set
    assert TEST_CONSTANT_FOO
    assert not TEST_CONSTANT_BAR
    assert TEST_CONSTANT_BAZ == 'HURZ'
    assert TEST_CONSTANT_URKEL == dict(a=1, b='zwei')


# TEST MODULE ###

# Generated at 2022-06-22 19:38:15.560204
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Should display the deprecation warning message
    assert _DeprecatedSequenceConstant(['one', 'two'], 'This is a deprecation warning', '2.11').__getitem__(1) == 'two'

# Generated at 2022-06-22 19:38:19.330362
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Unit test for method __len__ of class _DeprecatedSequenceConstant.
    dep_seq_const = _DeprecatedSequenceConstant((1, 2, 3), 'msg', '2.10')
    assert len(dep_seq_const) == 3

# Generated at 2022-06-22 19:38:31.645838
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import unittest

    class _Test_DeprecatedSequenceConstant(unittest.TestCase):
        def test___getitem__(self):
            from ansible.constants import _warning, _deprecated
            import re

            class _StdOutMock(object):
                def __init__(self):
                    self._lines = []

                def write(self, line):
                    self._lines.append(line)

            _warning_mock_stderr = _StdOutMock()
            _deprecated_mock_stderr = _StdOutMock()

            _original_warning = _warning
            _original_deprecated = _deprecated

            class _TestException(Exception):
                pass

            def _warning_mock(*args, **kwargs):
                _warning_mock

# Generated at 2022-06-22 19:38:34.555625
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    i = _DeprecatedSequenceConstant([1,2,3], "some message", "some version")
    assert len(i) == 3
    assert i[0] == 1
    assert i[1] == 2
    assert i[2] == 3

# Generated at 2022-06-22 19:38:45.502648
# Unit test for function set_constant
def test_set_constant():
    class Foo(object):
        def __init__(self, output):
            self.output = output

    # Create dict for testing purposes
    test_dict = dict()
    test_value = 'bar'
    test_value2 = 'bar-bar'
    test_key = Foo('foo')

    # Testing that value is added to dict and does not throw exception
    set_constant(test_key, test_value, export=test_dict)
    try:
        assert test_dict[test_key] == test_value
    except AssertionError:
        raise AssertionError('Value not added to dictionary')

    # Testing that a warning is printed to the display
    try:
        set_constant(test_key, test_value2, export=test_dict)
    except KeyError:
        raise AssertionError

# Generated at 2022-06-22 19:38:47.940157
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'foo', 'bar')) == 3


# Generated at 2022-06-22 19:38:51.874262
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ['', '', '', '', '']
    test_obj = _DeprecatedSequenceConstant(test_list, 'test_msg', '2.9')
    length = len(test_obj)
    assert length == len(test_list)


# Generated at 2022-06-22 19:38:55.938821
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 123)
    set_constant('test_constant', 456)
    assert test_constant == 456



# Generated at 2022-06-22 19:39:04.577138
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Verify empty string
    dsc = _DeprecatedSequenceConstant([], 'This is a message', '3.1')
    assert dsc

# Error checking for MAGIC_VARIABLE_MAPPING
for key, values in MAGIC_VARIABLE_MAPPING.items():
    for value in values:
        if INVALID_VARIABLE_NAMES.match(value) is not None:
            raise Exception('Invalid value in MAGIC_VARIABLE_MAPPING: %s' % value)

del config
del add_internal_fqcns
del ensure_type
del to_text
del test__DeprecatedSequenceConstant

# Generated at 2022-06-22 19:39:09.913539
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected_version = '2.11'
    expected_msg = 'Test message'
    expected_value = ['first_value', 'second_value']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(expected_value, expected_msg, expected_version)
    _deprecated(expected_msg, expected_version)
    assert len(deprecated_sequence_constant) == len(expected_value)


# Generated at 2022-06-22 19:39:13.928546
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_seq = _DeprecatedSequenceConstant(seq=[0, 1], msg='msg', version='v1')
    assert 0 == test_seq[0]
    assert 1 == test_seq[1]


# Generated at 2022-06-22 19:39:18.411319
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    msg = 'test'
    version = '1.0'
    test_value = ['test', 'test']
    test_instance = _DeprecatedSequenceConstant(test_value, msg, version)

    assert test_instance[0] == test_value[0]


# Generated at 2022-06-22 19:39:21.120934
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    instance = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '1.0')
    assert len(instance) == 3


# Generated at 2022-06-22 19:39:24.761270
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

   dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
   assert dsc[0] == 1
   assert dsc[1] == 2
   assert dsc[2] == 3


# Generated at 2022-06-22 19:39:26.685382
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'dummy', '2.10')
    assert constant[1] == 2

# Generated at 2022-06-22 19:39:32.973016
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Simple case
    value = (1, 2, 3)
    c = _DeprecatedSequenceConstant(value, 'msg', 'version')
    assert len(c) == 3

    # Empty
    value = ()
    c = _DeprecatedSequenceConstant(value, 'msg', 'version')
    assert len(c) == 0



# Generated at 2022-06-22 19:39:35.547702
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='version')[0] == 1


# Generated at 2022-06-22 19:39:47.318440
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest
    import unittest.mock

    # We will mock stdout, stderr to test when _DeprecatedSequenceConstant displays a message.
    # We will use io.StringIO to capture the stdout and stderr.
    stdout_stream = io.StringIO()
    stderr_stream = io.StringIO()
    stdout_mock = sys.stdout
    stderr_mock = sys.stderr
    sys.stdout = stdout_stream
    sys.stderr = stderr_stream

    # We will mock the warnings.warn method, to see if the function will display the message as warning.
    mock_warnings = unittest.mock.Mock()

# Generated at 2022-06-22 19:39:50.274500
# Unit test for function set_constant
def test_set_constant():
    set_constant('DEF_VAL', 'test')
    assert DEF_VAL == 'test'

# Generated at 2022-06-22 19:39:53.459511
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], "This has been deprecated", "2.9")
    assert len(constant) == 3



# Generated at 2022-06-22 19:40:00.398098
# Unit test for function set_constant
def test_set_constant():
    for warning in config.WARNINGS:
        set_constant('TEST_STRING_CONSTANT', warning)
        if not warning in globals():
            raise Exception('test_set_constant: setting string constant failed!')
    set_constant('TEST_BOOLEAN_CONSTANT', True)
    if not True == globals()['TEST_BOOLEAN_CONSTANT']:
        raise Exception('test_set_constant: setting boolean constant failed!')

# Generated at 2022-06-22 19:40:01.710018
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[0, 1, 2], msg='msg', version='version')) == 3

# Generated at 2022-06-22 19:40:04.300148
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(COLLECTION_PTYPE_COMPAT) == 1


# Generated at 2022-06-22 19:40:06.545847
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0.0')[1] == 2


# Generated at 2022-06-22 19:40:17.929071
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from unittest import TestCase
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.six import PY3

    class Test__DeprecatedSequenceConstant(TestCase):

        def test_empty(self):
            d = _DeprecatedSequenceConstant([], "", "")
            self.assertEqual(len(d), 0)
            if PY3:
                self.assertRaises(IndexError, d.__getitem__, 0)
            else:
                self.assertRaises(IndexError, d.__getitem__, -1)

        def test_not_empty(self):
            d = _DeprecatedSequenceConstant([1, 2, 3, 4], "msg", "1.0")
            self.assertEqual(len(d), 4)

# Generated at 2022-06-22 19:40:24.203886
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = u"Warning: this is a test."
    version = u"2.6"
    v_list = [1,2,3]
    test = _DeprecatedSequenceConstant(v_list, msg, version)
    assert test[1] == v_list[1]


# Generated at 2022-06-22 19:40:27.253341
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    string = 'string'
    msg = 'msg'
    version = 'version'

    test = _DeprecatedSequenceConstant(string, msg, version)

    assert len(test) == len(string)
    assert test[0] == string[0]
