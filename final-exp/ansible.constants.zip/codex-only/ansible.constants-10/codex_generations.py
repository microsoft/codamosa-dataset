

# Generated at 2022-06-22 19:30:29.868328
# Unit test for function set_constant
def test_set_constant():
    assert MAGIC_VARIABLE_MAPPING['connection'] == ('ansible_connection',)
    assert DEFAULT_HASH_BEHAVIOUR == ['sha1', 'md5']
    assert DEFAULT_SUDO_PASS == None
    assert DEFAULT_SUDO_USER == 'root'


# Generated at 2022-06-22 19:30:33.997263
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], "test", "1.0")
    assert sequence_constant[0] == 1
    assert sequence_constant[1] == 2
    assert sequence_constant[2] == 3

# Generated at 2022-06-22 19:30:37.969769
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    new_obj = _DeprecatedSequenceConstant(['value'], 'msg', 'version')
    assert hasattr(new_obj, '_value')
    assert hasattr(new_obj, '_msg')
    assert hasattr(new_obj, '_version')



# Generated at 2022-06-22 19:30:42.421507
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    list1 = [1,2,3]
    test_class = _DeprecatedSequenceConstant(list1, "This is a test", "v1.1")
    assert( test_class[0] == 1)
    assert( test_class[1] == 2)
    assert( test_class[2] == 3)
    assert( len(test_class) == 3 )


# Generated at 2022-06-22 19:30:45.627090
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant((1, 2), '', '2.10')
    constant.__len__()
    constant.__getitem__(0)

# Generated at 2022-06-22 19:30:49.611612
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), "msg", "version")
    assert len(dsc) == 3


# Generated at 2022-06-22 19:30:51.713822
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    for i in range(3):
        assert test[i] == i + 1


# Generated at 2022-06-22 19:30:59.202877
# Unit test for function set_constant
def test_set_constant():

    from ansible.config.data import ConfigData
    from ansible.config.manager import ConfigManager

    config_data = ConfigData()
    config_data.add(b'const1', 'const1', origin='default')
    config_manager = ConfigManager(config_data=config_data)
    config_manager.load_config_file()
    # Verify that set_constant is working
    assert not hasattr(const1, 'const1')
    set_constant('const1', config_data.const1.value, export=vars())
    assert hasattr(const1, 'const1')
    assert const1.const1 == 'const1'

    # Test constant defined in constants.py
    assert not hasattr(vars(), 'ANSIBLE_TEST')

# Generated at 2022-06-22 19:31:05.553895
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value1 = [1]
    msg1 = "DEPRECATED message"
    version1 = "2.9"
    dsc1 = _DeprecatedSequenceConstant(value1, msg1, version1)
    value2 = dsc1.__getitem__(0)
    assert value1 == value2



# Generated at 2022-06-22 19:31:08.888504
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(['foo', 'bar'], 'msg', 'version')
    assert len(a) == 2
    assert a[0] == 'foo'
    assert a[1] == 'bar'



# Generated at 2022-06-22 19:31:14.283555
# Unit test for function set_constant
def test_set_constant():
    new_export = {}
    set_constant('test_k', 'test_v', new_export)
    assert new_export.get('test_k') == 'test_v'


# FIXME: remove once play_context mangling is removed
# this function updates the PlayContext based on
# the variables that were set in the play

# Generated at 2022-06-22 19:31:17.338066
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'An error message', '1.2.3')) == 2

# Generated at 2022-06-22 19:31:28.108266
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'foo', '2.12')
    assert(constant[0] == 'a')
    assert(constant[1] == 'b')
    assert(constant[2] == 'c')
    assert(constant[-1] == 'c')
    assert(constant[-2] == 'b')
    assert(constant[-3] == 'a')

    # test error cases
    try:
        constant[3]
        assert(False)
    except IndexError:
        pass
    try:
        constant[-4]
        assert(False)
    except IndexError:
        pass

# Generated at 2022-06-22 19:31:30.429930
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expected_value = 'foo'
    msg = 'test msg'
    version = 'test version'
    dsc = _DeprecatedSequenceConstant((expected_value,), msg, version)
    assert expected_value == dsc[0]



# Generated at 2022-06-22 19:31:43.414552
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', True)
    assert FOO is True

    set_constant('BAR', 1)
    assert BAR == 1

    set_constant('BAZ', 'one')
    assert BAZ == 'one'


# Apply deprecations from config
for deprecation in config.data.get_deprecations():
    if deprecation.name in vars():
        name = deprecation.name
        version = deprecation.version
        if 'removed' in deprecation.details:
            msg = '%s is slated for removal in Ansible %s.' % (name, deprecation.version)
        else:
            msg = '%s is deprecated in Ansible %s.' % (name, deprecation.version)
        msg += ' %s' % deprecation.details
       

# Generated at 2022-06-22 19:31:46.842860
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['test'], 'this is a test', '2.9')
    assert (dsc[0] == 'test')
    assert (len(dsc) == 1)

# Generated at 2022-06-22 19:31:52.666642
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "test msg"
    version = "test version"
    value = ['a', 'b', 'c']
    deprecated_object = _DeprecatedSequenceConstant(value, msg, version)

    assert len(deprecated_object) == len(value)
    assert deprecated_object[1] == value[1]



# Generated at 2022-06-22 19:31:54.670896
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test __getitem__
    sequence_constant = _DeprecatedSequenceConstant(['test'], 'test__DeprecatedSequenceConstant___getitem__', '2.10')
    assert 'test' == sequence_constant[0]


# Generated at 2022-06-22 19:31:56.360355
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant(value=['a'], msg='test', version='2.0')
    assert isinstance(constant, Sequence)

# Generated at 2022-06-22 19:31:57.520233
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 2)
    assert TEST_CONSTANT == 2



# Generated at 2022-06-22 19:32:02.840085
# Unit test for function set_constant
def test_set_constant():
    test_constant = 'bar'
    try:
        foo
    except NameError:
        set_constant('foo', test_constant)
    else:
        assert False, "Test set_constant() failed!"
    assert foo == test_constant, "Test set_constant() failed!"


# Generated at 2022-06-22 19:32:07.260095
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test msg', '2.9')
    dsc_len = len(dsc)
    assert dsc_len == 3
    dsc_getitem = dsc[0]
    assert dsc_getitem == 'a'

# Generated at 2022-06-22 19:32:09.341579
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "The test_msg"
    version = "The test_version"
    test_value = [1, 2, 3]
    test = _DeprecatedSequenceConstant(test_value, msg, version)
    assert len(test) == len(test_value)

# Generated at 2022-06-22 19:32:19.359494
# Unit test for function set_constant
def test_set_constant():
    assert len(__version__) > 0, "Failed to generate version information"
    assert len(DEFAULT_BECOME_PASS) > 0, "Failed to generate DEFAULT_BECOME_PASS"
    assert len(DEFAULT_REMOTE_PASS) > 0, "Failed to generate DEFAULT_REMOTE_PASS"
    assert DEFAULT_SUBSET == ':all', "Failed to generate DEFAULT_SUBSET"
    assert TREE_DIR == 'v2' or TREE_DIR == 'v2.0', "Failed to generate TREE_DIR"
    assert len(INTERNAL_RESULT_KEYS) > 0, "Failed to generate INTERNAL_RESULT_KEYS"

# Generated at 2022-06-22 19:32:24.476365
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = ['foo', 'bar']
    dsc = _DeprecatedSequenceConstant(seq, 'Test warning message', '3.0')
    assert dsc[0] == 'foo'
    assert dsc[1] == 'bar'
    assert len(dsc) == 2

# Unit test

# Generated at 2022-06-22 19:32:27.136877
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([], 'msg', '2.0')
    seq[0]
    seq['foo']

# Generated at 2022-06-22 19:32:38.196293
# Unit test for function set_constant
def test_set_constant():
    import os
    import platform
    import pwd
    import sys

    def check_constant(export, name, value):
        assert name in export
        assert export[name] == value

    # The following constants are chosen to make sure:
    # - that string, integer and boolean values are set correctly
    # - that values are processed even if they are enclosed in quotes
    # - that environment variables and our own constants are resolved
    export = {}
    set_constant('HOME', '"{{HOME}}"')
    check_constant(export, 'HOME', pwd.getpwuid(os.getuid()).pw_dir)
    set_constant('HOSTNAME', '{{inventory_hostname}}')
    check_constant(export, 'HOSTNAME', platform.node().lower())

# Generated at 2022-06-22 19:32:41.854686
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class A:
        def __len__(self):
            return 1

    _deprecated_constant = _DeprecatedSequenceConstant(A(), '_msg', '0.0')
    assert len(_deprecated_constant) == 1


# Generated at 2022-06-22 19:32:53.196694
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.six.moves import builtins
    original_print = builtins.print

# Generated at 2022-06-22 19:32:57.304517
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """Test the constructor of _DeprecatedSequenceConstant
    """
    a = _DeprecatedSequenceConstant([1,2,3], 'Do not use this feature', '3.0')
    assert a == [1,2,3]
    assert len(a) == 3


# Generated at 2022-06-22 19:33:01.861065
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'list', '2.0')
    assert len(x) == 3
    assert x.__len__() == 3

# Generated at 2022-06-22 19:33:04.471724
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'set_constant')
    assert test == 'set_constant', 'test set_constant failed'



# Generated at 2022-06-22 19:33:15.465347
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'testing', '2.9')) == 3, 'Vector should be [1, 2, 3]'


#
#  Mock settings used for testing
#


# Generated at 2022-06-22 19:33:23.214856
# Unit test for function set_constant
def test_set_constant():
    import set_constant
    set_constant.set_constant('TEST_1', 'success')
    assert set_constant.TEST_1 == 'success'

    set_constant.set_constant('TEST_2', 'success2', vars())
    assert set_constant.TEST_2 == 'success2'

    set_constant.set_constant('TEST_3', 'success3', set_constant)
    assert set_constant.TEST_3 == 'success3'

# Generated at 2022-06-22 19:33:35.248962
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_should_return_warnings = __version__ == "2.10.3.dev0"
    import warnings
    test_msg = "WARNING:2.10:some_value:some_version"
    test_version = "some_version"
    test_data = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(test_data, test_msg, test_version)
    _deprecated = warnings.warn
    warnings.warn = lambda msg, stacklevel=3: print('WARNING:%s:%s:%s' % (__version__, msg, 'some_version'))
    ans = test_obj[1]
    warnings.warn = _deprecated
    assert isinstance(test_obj, _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:33:39.128310
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "", "")
    result = len(dsc)
    assert result == 3


# Generated at 2022-06-22 19:33:43.103788
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((), '', '')) == 0
    assert len(_DeprecatedSequenceConstant((1, 2, 3), '', '')) == 3
    assert len(_DeprecatedSequenceConstant((1, 2, 3), '', '')) == 3


# Generated at 2022-06-22 19:33:44.508613
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant([], '', '')
    x[0]


# Generated at 2022-06-22 19:33:53.355198
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from . import callback_default_values
    from ansible.module_utils.common.collections import Sequence
    seq_obj = _DeprecatedSequenceConstant(callback_default_values.DEFAULT_CALLBACK_WHITELIST, 'test msg', '1.5.0')
    assert isinstance(seq_obj, Sequence)
    assert len(seq_obj) == len(callback_default_values.DEFAULT_CALLBACK_WHITELIST)
    index = len(callback_default_values.DEFAULT_CALLBACK_WHITELIST)
    try:
        seq_obj[index]
    except IndexError as e:
        assert True
    else:
        assert False

# Generated at 2022-06-22 19:33:54.315445
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(CONNECTION_PLUGIN_PATH) == 2


# Generated at 2022-06-22 19:33:59.112503
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1,2,3]
    message = "Message of test"
    version = "1.1.1"
    sequence = _DeprecatedSequenceConstant(test_value, message, version)
    assert len(sequence) == len(test_value)


# Generated at 2022-06-22 19:34:06.003451
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_value = _DeprecatedSequenceConstant(value=['test_value'], msg="msg", version="version")
    # check value
    assert deprecated_value[0] == 'test_value'

    # check if deprecation warning is generated
    import sys
    import io
    from contextlib import redirect_stdout
    f = io.StringIO()
    with redirect_stdout(f):
        deprecated_value[0]
    assert "[DEPRECATED] msg, to be removed in version" in f.getvalue()


# Generated at 2022-06-22 19:34:13.660585
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    args = (tuple(range(10)), 'msg', 'version')
    dsc = _DeprecatedSequenceConstant(*args)
    assert len(dsc) == len(args[0])

    dsc = _DeprecatedSequenceConstant(list(range(10)), 'msg', 'version')
    assert len(dsc) == len(args[0])



# Generated at 2022-06-22 19:34:16.651365
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    q = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert(len(q) == len([1, 2, 3]))


# Generated at 2022-06-22 19:34:18.573286
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None

    set_constant('DEFAULT_BECOME_PASS', 'test-pass')
    assert DEFAULT_BECOME_PASS == 'test-pass'



# Generated at 2022-06-22 19:34:22.924391
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('my_int_constant', 1, d)
    assert d['my_int_constant'] == 1
    set_constant('my_str_constant', "ONE", d)
    assert d['my_str_constant'] == "ONE"


# Generated at 2022-06-22 19:34:32.585060
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    Test method __getitem__ of class _DeprecatedSequenceConstant.
    '''
    msg = 'This test is deprecated'
    version = 'no version'

    seq = _DeprecatedSequenceConstant(list(range(3)), msg, version)
    assert seq[0] == 0
    assert seq[1] == 1
    assert seq[2] == 2
    try:
        seq[3]
        raise Exception('Test failed: method __getitem__ of class _DeprecatedSequenceConstant'
                        ' does not raise an IndexError when called with invalid index')
    except IndexError:
        pass
    del seq
    seq = _DeprecatedSequenceConstant((0, 1, 2), msg, version)
    assert seq[0] == 0
    assert seq[1] == 1

# Generated at 2022-06-22 19:34:35.604699
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'test', '2.9')) == 3
    assert _DeprecatedSequenceConstant((1, 2, 3), 'test', '2.9')[0] == 1


# Generated at 2022-06-22 19:34:39.225111
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test(object):
        def __init__(self):
            pass
    test = Test()
    test._a = ['a', 'b', 'c']
    test._b = _DeprecatedSequenceConstant(test._a, 'test', '2.4')
    assert len(test._b) == 3


# Generated at 2022-06-22 19:34:41.274669
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "msg"
    version = "version"
    value = "value"
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 1

# Generated at 2022-06-22 19:34:47.588540
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Sub(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            self.__value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self.__value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self.__value[y]

    sub = Sub([1,2,3], 'test', '0.0.0')
    assert len(sub) == 3
    sub.__len__()
    sub.__getitem__(1)


# Generated at 2022-06-22 19:34:50.798980
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my_sequence = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert 3 == len(my_sequence)
    assert 2 == my_sequence[1]

# Generated at 2022-06-22 19:35:02.629716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Unit test for method __getitem__ of class _DeprecatedSequenceConstant"""
    def test_func():
        """Unit test for method __getitem__ of class _DeprecatedSequenceConstant"""
        pass

    test_constant = _DeprecatedSequenceConstant(("value1", "value2"), "test message", "test version")

    # test the first element of the sequence
    test_func.__doc__ = "Unit test for method __getitem__ of class _DeprecatedSequenceConstant"
    assert test_constant[0] == "value1"

    # test the last element of the sequence
    test_func.__doc__ = "Unit test for method __getitem__ of class _DeprecatedSequenceConstant"
    assert test_constant[1] == "value2"

# Generated at 2022-06-22 19:35:06.292649
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'ver')
    assert len(obj) == 3


# Generated at 2022-06-22 19:35:09.915508
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    msg = "Test Warning Message"
    version = "2.99"
    value = [1, 2, 3, 4, 5]

    instance_of_DeprecatedSequenceConstant = _DeprecatedSequenceConstant(value, msg, version)

    assert len(instance_of_DeprecatedSequenceConstant) == 5
    assert instance_of_DeprecatedSequenceConstant[3] == 4

# Generated at 2022-06-22 19:35:14.792399
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant(['some_value_1', 'some_value_2', 'some_value_3'], 'test_msg', '2.11.0')
    assert len(test_sequence) == 3
    # We don't check the output of the deprecated message because that is tested in unit test 'test_warnings'

# Generated at 2022-06-22 19:35:21.614075
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_constant = _DeprecatedSequenceConstant([1, 2, 3], 'This is a test.', '2.10')
    assert seq_constant[0] == 1
    assert seq_constant[1] == 2
    assert seq_constant[2] == 3

__all__ = [set_constant, _DeprecatedSequenceConstant, config, test__DeprecatedSequenceConstant___getitem__]

# Generated at 2022-06-22 19:35:24.255580
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant((1, 2), 'msg', 'version')
    assert x.__len__() == (1, 2).__len__()



# Generated at 2022-06-22 19:35:35.608979
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'testvalue')
    assert __name__ == 'ansible.constants'
    assert test_constant == 'testvalue'

# SET DEFAULTS  ###

DEFAULT_VAULT_ID_MATCH = "^.*$"  # match anything else
DEFAULT_ASK_VAULT_PASS = None  # never ask for a vault password
DEFAULT_VAULT_PASSWORD_FILES = ["~/.vault_pass.txt", "~/.ansible/vault"]
DEFAULT_VAULT_IDENTITY_LIST = []
DEFAULT_DEPRECATION_VERSION = "2.10"

# We need to set the constants here because the options are loaded
# from the config and would overwrite the constants.

BECOME_ALLOW_SAME_USER = True
BEC

# Generated at 2022-06-22 19:35:38.628990
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    for value in ({'k1': 'v1'}, [], ()):
        obj = _DeprecatedSequenceConstant(value, '', '')
        assert len(obj) == len(value)
        for i in range(len(value)):
            assert obj[i] == value[i]

# Generated at 2022-06-22 19:35:51.333112
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # Test case 1
    constant_name = 'CONSTANT_NAME'
    constant_value = 'Constant Value'
    msg = 'This is deprecated'
    version = 'v1.0'
    c = _DeprecatedSequenceConstant(constant_value, msg, version)

    assert c[0] == constant_value
    assert len(c) == 1

    # Test case 2
    constant_name = 'CONSTANT_NAME'
    constant_value_list = ['Constant', 'Value', 'List']
    msg = 'This is deprecated'
    version = 'v1.0'
    c = _DeprecatedSequenceConstant(constant_value_list, msg, version)

    for i in range(3):
        assert c[i] == constant_value_list
    assert len(c) == 3

# Generated at 2022-06-22 19:36:02.784696
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant((), 'foo', '1.2.3'), Sequence)
    assert isinstance(_DeprecatedSequenceConstant([], 'foo', '1.2.3'), Sequence)
    assert isinstance(_DeprecatedSequenceConstant(set(), 'foo', '1.2.3'), Sequence)
    assert len(_DeprecatedSequenceConstant((), 'foo', '1.2.3')) == 0
    assert len(_DeprecatedSequenceConstant([], 'foo', '1.2.3')) == 0
    assert len(_DeprecatedSequenceConstant(set(), 'foo', '1.2.3')) == 0
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'foo', '1.2.3')) == 3

# Generated at 2022-06-22 19:36:04.738713
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 19:36:13.115431
# Unit test for function set_constant
def test_set_constant():

    # test defined constants
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')  # characters included in auto-generated passwords

    # test re-defined constants
    set_constant('DEFAULT_PASSWORD_CHARS', '0123456789')
    assert DEFAULT_PASSWORD_CHARS == '0123456789'

    # test new constants
    set_constant('TEST_CONSTANT', 'some_value')
    assert TEST_CONSTANT == 'some_value'



# Generated at 2022-06-22 19:36:18.566088
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(('item1', 'item2', ), 'test message', '2.9')
    assert dsc[0] == 'item1'
    assert dsc[1] == 'item2'

# Generated at 2022-06-22 19:36:28.894897
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    dsc = _DeprecatedSequenceConstant([1, 2, 3], '', '')
    assert isinstance(dsc, Sequence)
    assert len(dsc) == 3
    assert dsc[0] == 1
    dsc = _DeprecatedSequenceConstant([AnsibleUnsafeText('1'), AnsibleUnsafeText('2'), AnsibleUnsafeText('3')], '', '')
    assert isinstance(dsc, Sequence)
    assert len(dsc) == 3
    assert isinstance(dsc[0], AnsibleUnsafeText)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:36:33.170404
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    DEPRECATED_CONSTANT = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert DEPRECATED_CONSTANT.__getitem__(0) is None


# Generated at 2022-06-22 19:36:37.773115
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([], 'msg', 'version')
    # test get a single item
    assert dsc[0] == []
    # test get a slice
    assert dsc[:] == []


# Generated at 2022-06-22 19:36:43.024717
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert d[1] == 'b'
    d = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert d[-2] == 'b'


# Generated at 2022-06-22 19:36:45.008100
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert c[0] == []

# Generated at 2022-06-22 19:36:48.524148
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # pylint: disable=protected-access
    collection = _DeprecatedSequenceConstant('Some Message', 'This is deprecated', '2.9')
    assert collection[0] == 'Some'



# Generated at 2022-06-22 19:36:52.390953
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(None, '', '2.10')
    # Test should pass

# Generated at 2022-06-22 19:36:55.052628
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import types
    dep = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dep) == 3
    assert isinstance(len(dep), types.IntType)

# Generated at 2022-06-22 19:37:05.026371
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONST_STR', 'test_str')
    assert TEST_CONST_STR == 'test_str'
    set_constant('TEST_CONST_INT', 0)
    assert TEST_CONST_INT == 0
    set_constant('TEST_CONST_BOOL', True)
    assert TEST_CONST_BOOL is True
    set_constant('TEST_CONST_LIST', ['test1', 'test2'])
    assert TEST_CONST_LIST == ['test1', 'test2']

# Generated at 2022-06-22 19:37:16.361493
# Unit test for function set_constant
def test_set_constant():
    module_name = 'test_set_constant_module'
    module_path = 'test_set_constant_path'
    module_args = 'test_set_constant_args'
    module_lang = 'test_set_constant_lang'
    module_timeout = 'test_set_constant_timeout'
    module_connection = 'test_set_constant_connection'
    module_ssh_executable = 'test_set_constant_ssh_executable'
    module_ssh_common_args = 'test_set_constant_ssh_common_args'
    module_sftp_extra_args = 'test_set_constant_sftp_extra_args'
    module_scp_extra_args = 'test_set_constant_scp_extra_args'
    module_

# Generated at 2022-06-22 19:37:21.938826
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'a msg',
    version = '2.0'
    an_object = _DeprecatedSequenceConstant(['a', 'b', 'c'], msg, version)
    assert len(an_object) == 3
    assert an_object[1] == 'b'

# Generated at 2022-06-22 19:37:24.262997
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([], 'hello', '1.0')[0] == []

# Generated at 2022-06-22 19:37:27.887351
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant([1, 2], 'message', '1.5')
    assert len(s) == 2
    assert s[0] == 1

# Generated at 2022-06-22 19:37:35.251275
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant((), 'msg', 'version')
    assert len(dsc) == 0, 'an empty sequence dsc should have length 0'
    assert dsc[0] is None, 'accessing an empty sequence dsc[0] should return None'

if __name__ == '__main__':
    # Run unit tests
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:37:38.706512
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant(value=['A','B','C','D'],msg='hello',version='1.0')
    assert len(seq) == 4
    assert seq[1] == 'B'


# Generated at 2022-06-22 19:37:41.147817
# Unit test for function set_constant
def test_set_constant():
    vars = {}
    set_constant('testvar', 'testvalue', export=vars)
    assert vars['testvar'] == 'testvalue'

# Generated at 2022-06-22 19:37:45.663130
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.10')
    assert d[0] == 1
    assert d[1] == 2
    assert d[2] == 3


# Generated at 2022-06-22 19:37:50.979097
# Unit test for function set_constant
def test_set_constant():
    global TREE_DIR
    test_constant = 'test_constant'
    test_value = 'test_value'
    set_constant(test_constant, test_value)
    assert test_value == test_constant
    # Make sure the function does not modify the global dict
    assert TREE_DIR is None


# Generated at 2022-06-22 19:37:52.503125
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 19:37:54.547444
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    result = _DeprecatedSequenceConstant((1, 2, 3, 4), "msg", 0)
    assert result[1] == 2



# Generated at 2022-06-22 19:38:05.848679
# Unit test for function set_constant
def test_set_constant():
    class AnsibleOptions:
        pass

    opts = AnsibleOptions()

    set_constant('foo', 'bar', opts)
    assert opts.foo == 'bar'
    # Check if the value could be set to a correct value
    set_constant('foo', 'spam', opts)
    assert opts.foo == 'spam'
    # Check if the value could be set to a incorrect value
    try:
        set_constant('foo', {'eggs': 'ham'}, opts)
    except ValueError:
        pass
    else:
        assert 'Could set incorrect value'

    set_constant('foo', '{{ bar }}', opts)
    assert opts.foo == '{{ bar }}'
    # Set a correct value and test if it's overridable

# Generated at 2022-06-22 19:38:10.182716
# Unit test for function set_constant
def test_set_constant():
    """Test that set_constant returns the resolved option dict"""

    # Create a dictionary object to store constants
    export = dict()

    set_constant('name', 'value', export)
    assert export['name'] == 'value'
    assert config.get_config_value('name') == 'value'



# Generated at 2022-06-22 19:38:14.345373
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(None, None, None)
    assert dsc.__getitem__(0) == None


# Generated at 2022-06-22 19:38:20.338969
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    mock_value = (1, 2, 3)
    mock_msg = 'test'
    mock_version = '2.0'
    obj = _DeprecatedSequenceConstant(mock_value, mock_msg, mock_version)
    assert obj.__getitem__(0) == mock_value[0]
    assert obj.__getitem__(1) == mock_value[1]


# Generated at 2022-06-22 19:38:27.041312
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This string is used for testing."
    version = "1.0"

    item1 = _DeprecatedSequenceConstant(["a", "b"], msg, version)
    item2 = _DeprecatedSequenceConstant(None, msg, version)

    assert(len(item1) == 2)
    assert(item1[1] == "b")
    assert(item2[0] is None)

# Generated at 2022-06-22 19:38:29.748955
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('TEST_VAR', True) == globals()['TEST_VAR'] == True

# Generated at 2022-06-22 19:38:32.587502
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(['foo', 'bar'], 'This is a test', '3.0')
    assert deprecated_sequence_constant[1] == 'bar'

# Generated at 2022-06-22 19:38:33.937438
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    o = _DeprecatedSequenceConstant('', '', '')
    assert o.__len__() == 0

# Generated at 2022-06-22 19:38:38.486318
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant can be used to display warnings
    # when deprecated constants are used in code

    _DeprecatedSequenceConstant(
        value=['foo', 'bar'],
        msg='This is a deprecated sequence constant',
        version='2.11'
    )

# Generated at 2022-06-22 19:38:47.803512
# Unit test for function set_constant
def test_set_constant():
    local_export = {}
    set_constant('test_constant', 'test_value', export=local_export)
    assert 'test_constant' in local_export
    assert local_export['test_constant'] == 'test_value'


DEFAULT_MODULE_PATH = config.data.DEFAULT_MODULE_PATH
DEFAULT_ROLES_PATH = config.data.DEFAULT_ROLES_PATH
DEFAULT_TASKS_PATH = config.data.DEFAULT_TASKS_PATH
DEFAULTS_PATH = config.data.DEFAULTS_PATH
HOST_KEY_CHECKING = config.data.HOST_KEY_CHECKING
LIBRARY = config.data.DEFAULT_MODULE_PATH
MODULE_PATH = config.data.DEFAULT_MODULE_PATH
ROLE_PATH

# Generated at 2022-06-22 19:38:50.039585
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant([1, 2, 3], 'Test warning!', '1.0')

# Generated at 2022-06-22 19:38:52.545526
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'this is a test'
    version = '2.9'
    value = ('a', 'b')
    assert len(_DeprecatedSequenceConstant(value, msg, version)) == len(value)

# Generated at 2022-06-22 19:39:04.192325
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('test_constant_key', 'test_constant_value', export=test_dict)
    assert 'test_constant_key' in test_dict
    assert test_dict['test_constant_key'] == 'test_constant_value'


# SECRETS ###
# Dumped from utils/constants.py, the real secret stuff is auto-generated
VAULT_VERSION_1_0 = '$ANSIBLE_VAULT;1.0;AES256'
STRING_REPLACEMENT_RAW = '$string_replacement_placeholder$'
STRING_REPLACEMENT_JSON = '$STRING_REPLACEMENT_PLACEHOLDER$'
DEFAULT_RESULT_HOST_NAME_KEY = 'item'
CLI_ERROR_

# Generated at 2022-06-22 19:39:07.923570
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dep_seq_constant = _DeprecatedSequenceConstant(('this', 'is', 'a', 'tuple'), 'This is a message', 'version 2.9')
    assert len(dep_seq_constant) == 4

# Generated at 2022-06-22 19:39:09.940636
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(('a',), 'msg', 'version')[0] == 'a'


# Generated at 2022-06-22 19:39:21.564151
# Unit test for function set_constant
def test_set_constant():
    '''Calculates the fibonacci sequence to the given integer'''
    global LOCALHOST, cache_timeout, debug
    ansible_test_constant = "test constant"
    set_constant("ansible_test_constant", ansible_test_constant)
    assert ansible_test_constant == ansible_test_constant

# flake8 can't handle the long string below
# flake8: noqa
_TEXT_TRANSLATIONS = {'yes': True, 'on': True, 'true': True, '1': True, 'y': True, 'no': False, 'off': False, 'false': False, '0': False, 'n': False, 'none': None, 'null': None, 'nil': None}

# Generated at 2022-06-22 19:39:24.083958
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('name', 'value', d)
    assert d == {'name': 'value'}


# Generated at 2022-06-22 19:39:32.929309
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_seq = [1,2,3,4,5]
    test_warn_msg = 'test_warn: dummy warning'
    test_version = 'test_version: dummy version'
    test_seq_const = _DeprecatedSequenceConstant(value=test_seq, msg=test_warn_msg, version=test_version)
    assert(len(test_seq_const) == 5)
    test_seq_const[0]
    test_seq_const[4]
    test_seq_const[1:4]
    test_seq_const[-1]
    try:
        test_seq_const[5]
    except IndexError:
        pass
    else:
        raise AssertionError('Index out of bounds was not caught!')

# NOTE: run this once at the end to compile regexes

# Generated at 2022-06-22 19:39:38.024144
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    ''' test__DeprecatedSequenceConstant___getitem__: unit test for __getitem__ method'''

    constant_object = _DeprecatedSequenceConstant([1, 2, 3, 4], 'message', '1.0')
    assert constant_object[1] == 2

# Generated at 2022-06-22 19:39:42.687312
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import pytest
    with pytest.raises(DeprecationWarning):
        dsc = _DeprecatedSequenceConstant([0, 1, 2], "dummy", "1.0")
        assert len(dsc) == 3


# Generated at 2022-06-22 19:39:45.503225
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_seq = _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.9')
    assert len(test_seq) == 2



# Generated at 2022-06-22 19:39:54.560410
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # The constructor of class _DeprecatedSequenceConstant
    # takes 3 arguments: (1) value of seq, (2) msg for warning,
    # and (3) version for deprecation
    seq = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')
    assert len(seq) == 3, "Failed to return proper length of sequence"
    assert seq[1] == 'b', "Failed to return proper value of sequence"

# Generated at 2022-06-22 19:39:58.555722
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='This is a test.', version='2.9')
    assert dc[0] == 1
    assert dc[1] == 2
    assert dc[2] == 3
    assert dc[-1] == 3


# Generated at 2022-06-22 19:40:05.038822
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [u'string1', u'string2']
    test_msg = u'test_msg'
    test_version = u'test_version'
    test_default = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    # verify the mock _deprecated function is called
    test_default[0]
    # verify the mock _deprecated function is not called
    t = test_default._value
    t[0]



# Generated at 2022-06-22 19:40:08.754237
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    set_constant('ANSIBLE_TEST_LIST', ["one", "two", "three", "four", "five"], export=globals())
    assert len(_DeprecatedSequenceConstant(ANSIBLE_TEST_LIST, "Mocked deprecated message", "2.1.0.0")) == 5

# Generated at 2022-06-22 19:40:14.413905
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class __DeprecatedSequenceConstant___getitem__Test(unittest.TestCase):
        def test__DeprecatedSequenceConstant___getitem__(self):
            dsc = _DeprecatedSequenceConstant([0, '1', 2.0, True], 'test', '2.0')
            self.assertEqual(dsc[0], 0)

    unittest.main()

# Generated at 2022-06-22 19:40:26.877114
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ('a', 'b', 'c')
    msg = 'test msg'
    version = 'test version'
    old = _DeprecatedSequenceConstant(value, msg, version)
    assert value == old._value
    assert msg == old._msg
    assert version == old._version
    assert len(value) == len(old)
    assert value[0] == old[0]
    return True
