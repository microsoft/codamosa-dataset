

# Generated at 2022-06-22 19:30:30.622769
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = [1, 2, 3]
    s = _DeprecatedSequenceConstant(a, "", "")
    assert (s[1] == 2)

# Generated at 2022-06-22 19:30:34.807809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test1: Check length of a list
    seq_list = _DeprecatedSequenceConstant(['a','b','c','d'], "msg", "version")
    assert(len(seq_list) == 4)

    # Test2: Check length of a tuple
    seq_tuple = _DeprecatedSequenceConstant((1,2,3,4), "msg", "version")
    assert(len(seq_tuple) == 4)

# Generated at 2022-06-22 19:30:40.783874
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = [1, 2, 3]
    deprecated_seq = _DeprecatedSequenceConstant(seq, 'msg', 'version')

    assert len(deprecated_seq) == 3, 'len(deprecated_seq) must be 3.'
    assert deprecated_seq[1] == 2, 'deprecated_seq[1] must be 2.'

# Generated at 2022-06-22 19:30:50.108872
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant((), 'The object is empty', '1.2')) == 0
    assert len(_DeprecatedSequenceConstant((1,), 'The object is empty', '1.2')) == 1
    assert len(_DeprecatedSequenceConstant((1,), 'The object is empty', '1.2')) == 1
    assert _DeprecatedSequenceConstant((1,), 'The object is empty', '1.2')[0] == 1
    assert _DeprecatedSequenceConstant((1, 2,), 'The object is empty', '1.2')[1] == 2


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:30:52.426315
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Return sequence at index"""
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.0')
    assert constant[1] == 2


# Generated at 2022-06-22 19:30:55.578947
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'warn_msg'
    version = 'warn_version'
    value = 'value1'
    obj = _DeprecatedSequenceConstant([value], msg, version)
    assert obj[0] == value
    assert len(obj) == 1

# Generated at 2022-06-22 19:31:01.918123
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([0, 1, 2], 'no longer supported', '2.8')
    assert dsc[1] == 1
    assert dsc[2] == 2
    try:
        dsc[3]
        assert False
    except IndexError:
        pass
    assert isinstance(dsc, Sequence)


# Generated at 2022-06-22 19:31:09.098615
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    mylist = [1, 2, 3]
    msg = 'this is a msg'
    version = '1.1'
    deprecated_list = _DeprecatedSequenceConstant(mylist, msg, version)
    assert len(deprecated_list) == len(mylist)
    assert deprecated_list[0] == mylist[0]
    assert deprecated_list[1] == mylist[1]
    assert deprecated_list[2] == mylist[2]

# Generated at 2022-06-22 19:31:12.308291
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([], 'msg', 'version')
    _DeprecatedSequenceConstant({}, 'msg', 'version')


# Generated at 2022-06-22 19:31:25.466951
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test message', 'test version')
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert obj[3] == 4
    assert obj[-1] == 4
    assert obj[-2] == 3
    assert obj[-3] == 2
    assert obj[-4] == 1
    assert obj[:] == [1, 2, 3, 4]
    assert obj[:2] == [1, 2]
    assert obj[2:] == [3, 4]
    assert obj[::2] == [1, 3]
    assert obj[1::2] == [2, 4]
    assert obj[::-2] == [4, 2]

# Generated at 2022-06-22 19:31:34.432917
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class TestException(Exception):
        pass

    class Mock_display():
        def __init__(self, msg, version):
            self.msg = msg
            self.version = version

        def deprecated(self, msg, version):
            if msg != self.msg:
                raise TestException("Expected error message: {}. Got: {}".format(self.msg, msg))
            if version != self.version:
                raise TestException("Expected version: {}. Got: {}".format(self.version, version))

    class Mock_sys():
        def __init__(self, msg):
            self.msg = msg

        def stderr_write(self, msg):
            msg = msg.strip("\n")

# Generated at 2022-06-22 19:31:38.881764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([], 'msg', 'ver')
    assert dsc[0] is None

    dsc = _DeprecatedSequenceConstant([1, 2], 'msg', 'ver')
    assert dsc[0] == 1
    assert dsc[1] == 2



# Generated at 2022-06-22 19:31:41.645573
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = "test_value"
    test_msg = "test_msg"
    test_version = "test_version"
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert(len(test_value) == len(test_object))


# Generated at 2022-06-22 19:31:44.623346
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 100)
    assert vars()['a'] == 100
    # Reset
    vars().pop('a')

# Generated at 2022-06-22 19:31:46.665950
# Unit test for function set_constant
def test_set_constant():
    set_constant('C', 'D', locals())
    assert locals()['C'] == 'D'



# Generated at 2022-06-22 19:31:51.077179
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant('123', 'msg', 'version')
    assert(len(d) == 3)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-22 19:31:54.924763
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    tmp_constant = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert tmp_constant[0] == 'a'
    assert tmp_constant[1] == 'b'


# Generated at 2022-06-22 19:31:57.130517
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('__test_const', 'test')
        assert '__test_const' in globals()
    finally:
        del globals()['__test_const']



# Generated at 2022-06-22 19:32:02.910988
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_msg = 'test message'
    test_version = 'test version'
    sequence_constant = _DeprecatedSequenceConstant(('item1', 'item2'), test_msg, test_version)
    assert len(sequence_constant) == 2
    assert sequence_constant[0] == 'item1'
    assert sequence_constant[1] == 'item2'

# Generated at 2022-06-22 19:32:05.142695
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant((1, 2, 3), 'msg', '1.0')
    assert len(constant) == 3
    assert constant[1] == 2

# Generated at 2022-06-22 19:32:07.790783
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_const = _DeprecatedSequenceConstant(value=[1,2,3], msg="Test _DeprecatedSequenceConstant __len__", version="2.4")
    assert len(seq_const) == 3

# Generated at 2022-06-22 19:32:14.683142
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    global deprecated_sequence_constant

    deprecated_sequence_constant = _DeprecatedSequenceConstant(
        value=['some', 'list'],
        msg='This is a test',
        version='2.0'
    )
    assert isinstance(deprecated_sequence_constant, Sequence)
    assert len(deprecated_sequence_constant) == 2
    assert 'some' in deprecated_sequence_constant

# FIXME: remove once play_context mangling is removed
if __name__ == '__main__':
    # Unit tests
    test__DeprecatedSequenceConstant()
    assert hasattr(config, 'WARNINGS')
    assert hasattr(config, 'CACHE_PLUGIN')
    assert hasattr(config, 'CACHE_PLUGIN_CONNECTION')

# Generated at 2022-06-22 19:32:17.272487
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "", "now")) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], "", "now")[1] == 2

# Generated at 2022-06-22 19:32:21.723839
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sec = _DeprecatedSequenceConstant([0, 1], "This is a test", "3.0.0")
    assert 2 == len(sec)



# Generated at 2022-06-22 19:32:27.334107
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_seq = _DeprecatedSequenceConstant([1, 2, 3], 'Will be deprecated in the future', '2.9')
    t1 = len(test_seq)
    t2 = test_seq[0]
    assert t1 == 3
    assert t2 == 1



# Generated at 2022-06-22 19:32:28.850860
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')

# Generated at 2022-06-22 19:32:33.081829
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "Cannot get item"
    version = "2.0"
    value = "default"
    seq = _DeprecatedSequenceConstant(value, msg, version)
    assert seq[0] == "default"
    return


# Generated at 2022-06-22 19:32:35.548946
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    foo = _DeprecatedSequenceConstant([1, 2, 3, 4], 'test_msg', 'test_version')
    assert (len(foo) == 4)


# Generated at 2022-06-22 19:32:38.288435
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq_const = _DeprecatedSequenceConstant((1, 2, 3), "This is a test message.", '2.5')
    assert dep_seq_const[0] == 1

# Generated at 2022-06-22 19:32:46.538841
# Unit test for function set_constant
def test_set_constant():  # pylint: disable=too-complex
    '''
    This test verifies that set_constant() populates the module global
    namespace and returns a dict with resolved option values.
    '''
    # get a config before we test the function
    _config = ConfigManager()
    _config._get_config_data()

    # empty dict to hold constants
    export = {}

    # generate constants
    for setting in _config.data.get_settings():
        set_constant(setting.name, setting.value, export)

    # check that exported items are correct type
    for key, value in export.items():
        setting = _config.data.get_setting(key)

        # config items without a type are typically modules and should be
        # ignored and not checked for type
        if setting.type is None:
            continue

       

# Generated at 2022-06-22 19:32:49.159176
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant = _DeprecatedSequenceConstant([], 'test message', '1.0')
    assert len(sequence_constant) == 0

# Generated at 2022-06-22 19:32:55.047327
# Unit test for function set_constant
def test_set_constant():
    # Verify that set_constant sets constants correctly
    my_dict = {}
    set_constant('myvalue', 'my_string', export=my_dict)
    set_constant('myvalue2', 3, export=my_dict)

    # Verify that my_dict now contains the two constants
    assert 'myvalue' in my_dict and my_dict['myvalue'] == 'my_string'
    assert 'myvalue2' in my_dict and my_dict['myvalue2'] == 3


# Generated at 2022-06-22 19:33:02.252229
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    theclass = _DeprecatedSequenceConstant(('a', 'b'), 'test', '1.2')
    assert theclass[0] == 'a'
    assert theclass[1] == 'b'
    try:
        theclass[2]
    except IndexError:
        pass
    else:
        raise AssertionError(u"The exception was not raised")


# Generated at 2022-06-22 19:33:06.346113
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant([], msg, version)
    assert ''.join(dsc) == ''
    assert dsc[0] == None


# Generated at 2022-06-22 19:33:08.088685
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import os
    import sys
    import warnings

    def error_filter(record, module_name=None):
        ''' Filter messages that are not warnings sent by the module identified by module_name '''

# Generated at 2022-06-22 19:33:17.721363
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar', locals())
    assert foo == 'bar'
    set_constant('baz', 'qux', globals())
    assert baz == 'qux'
    try:
        set_constant('baz', 'quz', locals())
    except TypeError as e:
        assert 'read only' in str(e)
    else:
        assert False, 'expected exception'


# add documentation about the config file and default locations to the config manager

# Generated at 2022-06-22 19:33:20.003329
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='some', version='2.9')) == 3


# Generated at 2022-06-22 19:33:25.632219
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my_const = ('value1', 'value2', 'value3')
    my_msg = "This is a test warning message."
    my_version = "1.0.0"
    my_DeprecatedSequenceConstant = _DeprecatedSequenceConstant(my_const, my_msg, my_version)
    assert len(my_DeprecatedSequenceConstant) == 3

# Generated at 2022-06-22 19:33:36.741380
# Unit test for function set_constant
def test_set_constant():
    from tempfile import NamedTemporaryFile
    from ansible.config.manager import ConfigManager

    # Create a temporary config file
    config_file = NamedTemporaryFile(delete=False)
    config_file.write(b'[defaults]\n')
    config_file.write(b'roles_path = /fake/roles/path\n')
    config_file.close()

    # Assert the constants are empty
    assert 'roles_path' not in globals()

    # Create a ConfigManager using the temporary config file path
    config = ConfigManager(config_file.name)

    # Populate settings
    for setting in config.data.get_settings():
        set_constant(setting.name, setting.value)

    # Ensure that test_set_constant updated the constants

# Generated at 2022-06-22 19:33:46.439315
# Unit test for function set_constant
def test_set_constant():
    # Test on constants that have string value
    assert 'debug' == DEFAULT_DEBUG
    assert isinstance(DEFAULT_DEBUG, six.string_types)
    # Test on constants that have boolean values
    assert False == DEFAULT_GATHERING_SUBSET
    assert isinstance(DEFAULT_GATHERING_SUBSET, bool)
    # Test on constants that have numeric values
    assert 7 == DEFAULT_GATHERING_TIMEOUT
    assert isinstance(DEFAULT_GATHERING_TIMEOUT, int)
    # Test on constants that have sequence
    assert _ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES == ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES
    # Test on constants that have dict
    assert MAGIC_VARIABLE_MAPPING == MAGIC

# Generated at 2022-06-22 19:33:58.516148
# Unit test for function set_constant
def test_set_constant():
    # To test the set_constant function, we will create a test function and
    # pass it to set_constant. The function will try to read from a global
    # variable which will be set by set_constant.
    #
    # Note that this test is not fully self contained. set_constant reads from
    # the global namespace which is why we need to add to locals() here.

    def test_function(key=None):
        if key is None:
            key = 'VARIABLE_FROM_CONFIG'
        try:
            return globals()[key]
        except KeyError:
            raise AssertionError('Key %s not found in globals' % key)

    # Now use set_constant to set a global variable and read it from inside
    # our test function.

# Generated at 2022-06-22 19:34:07.943940
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__(): # pylint: disable=invalid-name
    import sys
    import mock
    from textwrap import dedent

    expected_output = dedent('''\
        [DEPRECATED] msg, to be removed in version
        [DEPRECATED] msg, to be removed in version
    ''')

    def display(msg):
        sys.stderr.write(msg + '\n')


# Generated at 2022-06-22 19:34:15.966641
# Unit test for function set_constant
def test_set_constant():
    TEST_SETTINGS = {'ANSIBLE_INTERNAL_DATA_DIR': 'test', 'ANSIBLE_CALLBACK_WHITELIST': ['test'], 'ANSIBLE_HASH_BEHAVIOUR': 'replace'}
    for setting in TEST_SETTINGS.keys():
        set_constant(setting, TEST_SETTINGS[setting])
        assert vars()[setting] == TEST_SETTINGS[setting]


# Generated at 2022-06-22 19:34:26.398328
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'TEST_CONSTANT')
    assert TEST_CONSTANT == 'TEST_CONSTANT'


# FIXME: remove once play_context mangling is removed
# this update magic_variable_mapping below is used to translate
# host/inventory variables to fields in the PlayContext
# object. The dictionary values are tuples, to account for aliases
# in variable names.


# Generated at 2022-06-22 19:34:39.697687
# Unit test for function set_constant
def test_set_constant():
    assert_equal = lambda a, b: 'Expected: %s, got %s' % (a, b)
    namespace = {}
    set_constant('test_string', 'test_string', namespace)
    assert namespace['test_string'] == 'test_string', assert_equal('test_string', namespace['test_string'])
    set_constant('test_int', 5, namespace)
    assert namespace['test_int'] == 5, assert_equal(5, namespace['test_int'])
    set_constant('test_float', 5.5, namespace)
    assert namespace['test_float'] == 5.5, assert_equal(5.5, namespace['test_float'])
    set_constant('test_bool', True, namespace)

# Generated at 2022-06-22 19:34:46.579852
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ''' test to ensure _DeprecatedSequenceConstant() constructor works '''
    test_list = ['test1', 'test2', 'test3']
    test_msg = 'This message is a test'
    test_version = '3.0'
    deprecated_seq_constant = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    try:
        assert(isinstance(deprecated_seq_constant, Sequence))
        assert(isinstance(deprecated_seq_constant, _DeprecatedSequenceConstant))
    except Exception:
        raise


# Generated at 2022-06-22 19:34:54.507572
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.six import moves
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant

    sequence_constant = _DeprecatedSequenceConstant([0, 1], 'test__DeprecatedSequenceConstant___getitem__', '1.0.0')
    sequence_constant[0] == 0
    sequence_constant[1] == 1

    try:
        sequence_constant[10]
    except IndexError:
        pass

# Generated at 2022-06-22 19:35:06.274752
# Unit test for function set_constant
def test_set_constant():
    assert 'ANSIBLE_TEST_CONSTANT_EXTERNAL' not in globals()
    set_constant('ANSIBLE_TEST_CONSTANT', 'OK', export=globals())
    assert 'ANSIBLE_TEST_CONSTANT' in globals()
    assert globals()['ANSIBLE_TEST_CONSTANT'] == 'OK'
    set_constant('ANSIBLE_TEST_CONSTANT_EXTERNAL', 'OK')
    assert 'ANSIBLE_TEST_CONSTANT_EXTERNAL' not in globals()


# DEFAULT PRIVATE SETTINGS ###
DEFAULT_HOST_LIST = '/etc/ansible/hosts'
DEFAULT_MODULE_NAME = 'command'
DEFAULT_MODULE_PATH = None
DEFAULT_MODULE_UTILS_PATH = None

# Generated at 2022-06-22 19:35:17.275674
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(('item1', 'item2', 'item3'), "Message", "1.0")) == 3
    assert _DeprecatedSequenceConstant(('item1', 'item2', 'item3'), "Message", "1.0")[0] == 'item1'
    assert _DeprecatedSequenceConstant(('item1', 'item2', 'item3'), "Message", "1.0")[1] == 'item2'
    assert _DeprecatedSequenceConstant(('item1', 'item2', 'item3'), "Message", "1.0")[2] == 'item3'

#
# The block of constants below will be replaced by constants generated from config defined in constants.ini.
# This block is just for reference.
#

# # Generate constants from config
# def _pop

# Generated at 2022-06-22 19:35:27.886587
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(value=(1,2), msg='warning_msg', version='2.9')) == 2
    assert len(_DeprecatedSequenceConstant(value=(1,), msg='warning_msg', version='2.9')) == 1
    assert len(_DeprecatedSequenceConstant(value=('a','b'), msg='warning_msg', version='2.9')) == 2


# Generate constants from config
for setting in config.data.get_setting():
    set_constant(setting.name, setting.value)

# Populate constants from other places
set_constant('CONFIGURABLE_PLUGINS', CONFIGURABLE_PLUGINS)

if config.data.get_config_value('DEFAULT_BECOME_PASS', 'defaults') is not None:
    DEFAULT

# Generated at 2022-06-22 19:35:35.689138
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def test_getitem(self):
            from ansible.constants import _DeprecatedSequenceConstant
            source = ('a', 'b', 'c')
            msg = 'msg'
            version = 'version'
            dsc = _DeprecatedSequenceConstant(source, msg, version)
            for x, y in enumerate(source):
                self.assertEqual(dsc[x], y)

    import ansible_test

    ansible_test.run_tests(Test__DeprecatedSequenceConstant___getitem__)

# Generated at 2022-06-22 19:35:37.303468
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert len(obj) == 3

# Generated at 2022-06-22 19:35:45.476679
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "The option `tests` is deprecated and will be removed in version 2.12.  See https://docs.ansible.com/ansible/latest/reference_appendices/deprecated_features.html#test-module-options"
    value = ['test1', 'test2']
    version = '2.12'
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(obj) == 2

# Generated at 2022-06-22 19:35:48.029768
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(['test'], 'test message', 'test version')
    assert len(constant) == 1

# Generated at 2022-06-22 19:35:51.985772
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', export=test_dict)
    assert test_dict['foo'] == 'bar'



# Generated at 2022-06-22 19:35:57.039700
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "my message"
    obj = _DeprecatedSequenceConstant(
        value=('foo', ),
        msg=msg,
        version="1.0",
    )
    assert isinstance(obj, Sequence)
    assert obj._value == ('foo', )
    assert obj._msg == msg
    assert obj._version == "1.0"

# Generated at 2022-06-22 19:36:03.126117
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Prepare test data
    lst = [1, 2, 3, 4]
    deprecated_lst = _DeprecatedSequenceConstant(lst, 'test', '2.0')
    # Call method __len__ of class _DeprecatedSequenceConstant and assert result
    assert len(deprecated_lst) == len(lst)


# Generated at 2022-06-22 19:36:08.605408
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check that the constructor for _DeprecatedSequenceConstant
    # initializes the instance variables correctly.
    const = _DeprecatedSequenceConstant([1, 2, 3, 4], "Hello World", "Version 2.0")

    assert const._value == [1, 2, 3, 4]
    assert const._msg == "Hello World"
    assert const._version == "Version 2.0"


# Generated at 2022-06-22 19:36:18.747195
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    b = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    c = _DeprecatedSequenceConstant('string', 'msg', 'version')
    assert len(a) == len(b) == len(c) == 3
    assert a[0] == b[0] == c[0] == 1
    assert a[1] == b[1] == c[1] == 2
    assert a[2] == b[2] == c[2] == 3

# Generated at 2022-06-22 19:36:21.288945
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([5, 4, 3, 2, 1], 'msg', 'version')) == 5

# Generated at 2022-06-22 19:36:23.943891
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    my_class = _DeprecatedSequenceConstant([], "this is a test", "1.0")
    assert len(my_class) == 0

# Generated at 2022-06-22 19:36:26.215740
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(None, None, None)
    assert len(dsc) == 0


# Generated at 2022-06-22 19:36:29.371197
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant((1, 2), 'msg', 'version')
    assert len(obj) == 2
    assert obj[0] == 1

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:36:32.374511
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant = _DeprecatedSequenceConstant((1,2,3), 'Test message', '2.0')
    assert constant._value == (1,2,3)
    assert constant._msg == 'Test message'
    assert constant._version == '2.0'

# Generated at 2022-06-22 19:36:34.471719
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], 'msg', 'version')


del config

# Generated at 2022-06-22 19:36:40.220505
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = ('foo', 'bar', 'baz')
    msg = 'no longer supported'
    warn = _DeprecatedSequenceConstant(sequence, msg, '2.13')
    assert warn[0] == 'foo'
    assert warn[1] == 'bar'
    assert warn[2] == 'baz'



# Generated at 2022-06-22 19:36:51.570261
# Unit test for function set_constant
def test_set_constant():

    # test string
    set_constant('test_string', 'foo')
    assert test_string == 'foo'

    # test tuple
    set_constant('test_tuple', ('foo', 'bar'))
    assert test_tuple == ('foo', 'bar')

    # test dict
    set_constant('test_dict', {'foo': 'bar'})
    assert test_dict == {'foo': 'bar'}

    # test bool
    set_constant('test_bool_true', True)
    set_constant('test_bool_false', False)
    assert test_bool_true == True
    assert test_bool_false == False

    # test int
    set_constant('test_int', 42)
    assert test_int == 42

    # test list

# Generated at 2022-06-22 19:36:54.123586
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', 'test version')
    assert len(my) == 3
    assert my[0] == 'a'
    assert my[1] == 'b'
    assert my[2] == 'c'

# Generated at 2022-06-22 19:37:00.727856
# Unit test for function set_constant
def test_set_constant():
    import ansible.constants as C

    set_constant('FOO', 'bar')
    set_constant('BAR', True)
    set_constant('BAZ', 123)

    assert C.FOO == 'bar'
    assert C.BAR is True
    assert C.BAZ == 123

# Generated at 2022-06-22 19:37:09.946640
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([2, 3], 'test', '2.0'), _DeprecatedSequenceConstant)


#
#   Docs at the bottom of this file
#

C.DEFAULT_ROLES_PATH = _DeprecatedSequenceConstant(C.DEFAULT_ROLES_PATH, 'C.DEFAULT_ROLES_PATH is deprecated, please use C.DEFAULT_ROLES_PATH_ANSIBLE_COLLECTIONS instead', '2.11')
C.DEFAULT_ROLES_PATHS = _DeprecatedSequenceConstant(C.DEFAULT_ROLES_PATHS, 'C.DEFAULT_ROLES_PATHS is deprecated, please use C.DEFAULT_ROLES_PATH_ANSIBLE_COLLECTIONS instead', '2.11')



# Generated at 2022-06-22 19:37:14.340973
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    data = [1, 2, 3]

    # Call __len__ to get the length of the list data.
    o = _DeprecatedSequenceConstant(data, "test", "2.9")
    assert len(o) == 3

# Generated at 2022-06-22 19:37:16.691488
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant(['1', '2'], "msg", "version")
    assert(len(seq) == 2)

# Generated at 2022-06-22 19:37:22.042114
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant((1,2,3), "test", "2.0")
    assert test_obj._value == (1,2,3)
    assert test_obj._msg == "test"
    assert test_obj._version == "2.0"
    assert len(test_obj) == 3
    assert test_obj[0] == 1

# Generated at 2022-06-22 19:37:25.787216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'This is a test for method __getitem__', '2.10')[0] == 'a'


# Generated at 2022-06-22 19:37:31.632886
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a warning message'
    version = '2.0'
    test_obj = _DeprecatedSequenceConstant(['the'], msg, version)

    # Test
    assert test_obj[0] == 'the'



# Generated at 2022-06-22 19:37:40.927920
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class TestSequence(Sequence):
        def __init__(self, value):
            self._value = value

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]
    sequence = TestSequence((1, 2, 3))
    assert len(sequence) == len(TestSequence((1, 2, 3)))
    assert sequence[0] == 1

    deprecated_sequence = _DeprecatedSequenceConstant((sequence, 'test', '2.7'), 'test', '2.7')
    assert len(deprecated_sequence) == len(sequence)
    assert deprecated_sequence[0] == 1

# Generated at 2022-06-22 19:37:42.153661
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3], 'A message', '99.99')

# Generated at 2022-06-22 19:37:49.773668
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    set1 = _DeprecatedSequenceConstant(['yo'], '', '2.8')
    set2 = _DeprecatedSequenceConstant({'yo'}, '', '2.8')
    assert len(set1) == 1
    assert len(set2) == 1
    assert set1[0] == 'yo'
    assert set2[0] == 'yo'
    return True

# Unit tests for constants

# Generated at 2022-06-22 19:37:52.514347
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    s = _DeprecatedSequenceConstant(('test',), msg="test", version="10.0")
    assert s[0] == 'test'
    assert len(s) == 1

# Generated at 2022-06-22 19:37:54.995024
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    message = "test_message"
    sequence_len = 321

    sequence = tuple(range(sequence_len))
    deprecated_sequence = _DeprecatedSequenceConstant(sequence, message, "1.0.0")

    assert len(deprecated_sequence) == sequence_len

# Generated at 2022-06-22 19:38:00.249838
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    DSC = _DeprecatedSequenceConstant(value=['a'], msg="testing", version="1.0")
    assert DSC._value == ['a']
    assert DSC._msg == "testing"
    assert DSC._version == "1.0"

# Generated at 2022-06-22 19:38:08.129189
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    warnings = []

    class MockDisplay:
        def deprecated(self, *args):
            warnings.append(args)

    import sys
    original_display = sys.modules['ansible.utils.display'].Display

    try:
        sys.modules['ansible.utils.display'].Display = MockDisplay
        lst = [1, 2, 3]
        lst_depr = _DeprecatedSequenceConstant(lst, msg='deprecated', version='99.0')

        len(lst_depr)
        assert len(warnings) == 1 and len(warnings[0]) == 2
    finally:
        sys.modules['ansible.utils.display'].Display = original_display



# Generated at 2022-06-22 19:38:11.120193
# Unit test for function set_constant
def test_set_constant():
    data = {'key': 'value'}

    set_constant('key', 'value', export=data)
    assert 'key' in data
    assert data.get('key') == 'value'



# Generated at 2022-06-22 19:38:17.016898
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test__DeprecatedSequenceConstant(self):
            msg, version = 'message', 'version'
            seq = _DeprecatedSequenceConstant((1, 2), msg, version)
            self.assertEqual(len(seq), 2)
            self.assertEqual(seq[1], 2)
            self.assertEqual(seq[0], 1)
            self.assertEqual(seq[-1], 2)
            self.assertEqual(seq[-2], 1)
            self.assertEqual(seq[1:1], [])

    unittest.main()

# Generated at 2022-06-22 19:38:26.090752
# Unit test for function set_constant
def test_set_constant():
    _test_constant_dict = dict()
    set_constant('VALID_CONSTANT_NAME_3', 'CAN_BE_A_STRING', export=_test_constant_dict)
    assert _test_constant_dict['VALID_CONSTANT_NAME_3'] == 'CAN_BE_A_STRING'
    set_constant('VALID_CONSTANT_NAME_4', 'CAN_BE_A_STRING', export=_test_constant_dict)
    assert _test_constant_dict['VALID_CONSTANT_NAME_3'] == 'CAN_BE_A_STRING'
    assert _test_constant_dict['VALID_CONSTANT_NAME_4'] == 'CAN_BE_A_STRING'

# Generated at 2022-06-22 19:38:28.707272
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "version")) == 3



# Generated at 2022-06-22 19:38:31.779483
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_constant_obj = _DeprecatedSequenceConstant([1, 2, 3], "Deprecated test msg", "2.3")
    assert len(seq_constant_obj) == 3


# Generated at 2022-06-22 19:38:33.286490
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['foo'], 'bar', 'baz')[0] == 'foo'

# Generated at 2022-06-22 19:38:36.773683
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2], 'Testing message', '2.0')
    assert dsc[0] == 1
    assert dsc[1] == 2


# Generated at 2022-06-22 19:38:41.386163
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c', 'd']
    msg = 'msg'
    version = 'version'
    const = _DeprecatedSequenceConstant(value, msg, version)
    assert len(const) == 4
    assert const[2] == 'c'
    assert const[0] == 'a'

# Generated at 2022-06-22 19:38:50.957744
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.six import StringIO

    def _get_out(out_str):
        out = StringIO()
        out.write(out_str)
        out.seek(0)
        return out

    import sys
    old_stderr = sys.stderr
    sys.stderr = _get_out('')  # silence warning

    cons = _DeprecatedSequenceConstant(list(range(10)), 'msg', '1.2')
    assert cons[3] == 3

    sys.stderr = old_stderr
    assert len(sys.stderr.read()) == 0  # warning was silenced

# Generated at 2022-06-22 19:38:55.885347
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant([], '', '')
    assert test[0] == None


if __name__ == '__main__':
    print(COLOR_CODES)
    print(INVALID_VARIABLE_NAMES)

# Generated at 2022-06-22 19:39:00.117780
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    testObj = _DeprecatedSequenceConstant(['a', 'b'], 'test message', '1.0')

    result = testObj[1]
    assert result == 'b', "Expected 'b' but got '%s'" % result

# Generated at 2022-06-22 19:39:06.091416
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(['a', 'b'], 'This is a test', '1.1')
    assert len(c) == 2
    assert c[0] == 'a'
    assert c[1] == 'b'


# Generated at 2022-06-22 19:39:14.371614
# Unit test for function set_constant
def test_set_constant():
    # Test boolean
    set_constant('TEST_BOOLEAN', 'true')
    assert TEST_BOOLEAN is True
    set_constant('TEST_BOOLEAN', 'false')
    assert TEST_BOOLEAN is False

    # Test integers
    set_constant('TEST_INTEGER', '2')
    assert TEST_INTEGER == 2
    set_constant('TEST_INTEGER', 3)
    assert TEST_INTEGER == 3

    # Test floats
    set_constant('TEST_FLOAT', '2.14')
    assert TEST_FLOAT == 2.14
    set_constant('TEST_FLOAT', 3.14)
    assert TEST_FLOAT == 3.14

    # Test strings

# Generated at 2022-06-22 19:39:17.067037
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert sequence[-1] == 3


# Generated at 2022-06-22 19:39:19.677796
# Unit test for function set_constant
def test_set_constant():
    assert TREE_DIR is not None

# SECRET KEY ###
SECRET_KEY = None  # FIXME: replace with loaded value or generated key

# Generated at 2022-06-22 19:39:23.764888
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # msg = 'msg', version = 'version'
    sequence_constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(sequence_constant) == 3
    assert sequence_constant[0] == 'a'

# Generated at 2022-06-22 19:39:31.886452
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_constant_1 = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'To be deprecated', '2.10')
    test_constant_2 = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'To be deprecated', '2.10')
    test_constant_3 = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'To be deprecated', '2.10')
    test_constant_4 = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'To be deprecated', '2.10')

    test_data_1 = len(test_constant_1)
    assert test_data_1 == 3, "Test data expected 3, got %s" % test_data_1


# Generated at 2022-06-22 19:39:42.909655
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # This is the value the mock object will return
    value = ('set_host_var', 'template', 'include', 'include_role')

    # The class we are testing. The class only accepts one variable in constructor,
    # which is the tuple to be returned, and the message/version for deprecated
    obj = _DeprecatedSequenceConstant(value, 'msg', 'version')

    # The first element of the tuple
    assert obj[0] == obj._value[0]

    # The last element of the tuple
    assert obj[-1] == obj._value[-1]

    # An element that doesn't exist
    assert obj[100] == obj._value[100]

# Generated at 2022-06-22 19:39:46.472003
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    s = _DeprecatedSequenceConstant(value=[1,2,3], msg='test', version='2.0')
    assert s[0] == 1
    assert s[1] == 2
    assert s[2] == 3


# Generated at 2022-06-22 19:39:48.755929
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # init with list
    d = _DeprecatedSequenceConstant([], 'msg', 'version')

    assert d[0] == []
    assert d[1] == []

# Generated at 2022-06-22 19:39:52.021694
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ('test_list_element_1', 'test_list_element_2')
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(test_list) == len(test_object)


# Generated at 2022-06-22 19:39:54.619396
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    d = _DeprecatedSequenceConstant((1, 2, 3), 'test', '1.0')
    assert len(d) == 3

# Generated at 2022-06-22 19:39:56.391928
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], 'test_message', '2.9')) == 0


# Generated at 2022-06-22 19:40:06.453786
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    if __name__ == '__main__':
        from ansible.utils.display import Display
        Display._alphanumeric_re = re.compile(r'\w+')
    
    # Test case of empty message
    d = _DeprecatedSequenceConstant(value=None, msg='', version='2.0')
    assert d._msg == ''
    assert d._version == '2.0'

    # Test case of invalid message
    d = _DeprecatedSequenceConstant(value=None, msg=None, version='2.0')
    assert d._msg == ''
    assert d._version == '2.0'

    # Test case of invalid version
    d = _DeprecatedSequenceConstant(value=None, msg='test', version='')
    assert d._msg == 'test'
    assert d._

# Generated at 2022-06-22 19:40:18.133181
# Unit test for function set_constant
def test_set_constant():
    config = ConfigManager()
    test_settings = config.data.get_settings()
    for setting in test_settings:
        test_value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                test_value = t.render(vars())
                try:
                    test_value = literal_eval(test_value)
                except ValueError:
                    pass
            except Exception:
                pass

        set_constant(setting.name, test_value)

# Generated at 2022-06-22 19:40:21.098195
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant(1, 'msg', 'version')
    assert 1 == len(s)

# vim: set expandtab shiftwidth=4 softtabstop=4 textwidth=79:

# Generated at 2022-06-22 19:40:24.901055
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(('a', 'b'), 'a', 'b')[0] == 'a'


# Generated at 2022-06-22 19:40:36.647417
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', True)
    assert TEST_CONSTANT

# NOTE: not a constant, may be changed/overridden by config
try:
    DEFAULT_LOCAL_TMP = ensure_type(config.get_config_value('DEFAULT_LOCAL_TMP', 'DEFAULT_TMP'), check_type=string_types)
except KeyError:
    DEFAULT_LOCAL_TMP = u'/tmp'

# NOTE: not a constant, may be changed/overridden by config
if config.get_config_value('CACHE_PLUGIN', 'CACHE', 'plugin'):
    CACHE_PLUGIN = config.get_config_value('CACHE_PLUGIN', 'CACHE', 'plugin')
else:
    CACHE_PLUG